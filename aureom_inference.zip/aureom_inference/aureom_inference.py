#!/usr/bin/env python3
"""
aureom_inference: Bayesian inference and Monte Carlo tools for Aureom.AI's LLM.

The module gives the LLM (through its orchestration layer) callable tools to

* update hypotheses when structured evidence arrives (log-space Bayes);
* track evidence provenance so the same or correlated evidence is not counted twice;
* propagate uncertainty through calculations by Monte Carlo simulation;
* compare competing explanations and competing alternatives;
* value candidate research actions (expected information gain, expected value of
  sample information, Thompson sampling over observed search usefulness);
* filter actions against separate money / token / call / time budgets; and
* decide whether to stop, with explicit reasons, prior-sensitivity results and
  model assumptions.

Scope and limits
----------------
* Inputs are structured data supplied by the LLM or a retrieval system. The module
  does not modify model weights and does not read hidden model reasoning.
* Every result is conditional on the supplied hypothesis set, priors, likelihood and
  observation models, and dependence policy. Correct arithmetic does not make those
  inputs correct, and a strong posterior does not show that the evidence is
  comprehensive.
* An LLM's verbal confidence ("I am 90% sure") is never converted into a likelihood
  ratio. Heuristic relevance scores and LLM annotations live in separate fields and
  never enter posterior calculations.
* Whether these tools improve the LLM's answer accuracy must be established by
  evaluation on labelled tasks. Correct inference calculations alone do not
  establish that improvement.

Trust boundary
--------------
Trusted Python callers may pass arbitrary callables (samplers and vectorised outcome
functions). The JSON dispatcher :func:`run_tool` accepts only named, validated
distribution and expression specifications. It never evaluates generated code, never
calls ``eval`` or ``exec`` and never unpickles data.

Usage
-----
    python aureom_inference.py                # demonstration, then self-checks
    python aureom_inference.py --demo
    python aureom_inference.py --self-check
    python aureom_inference.py --tools        # machine-readable tool definitions
    python aureom_inference.py --call TOOL --args '{"...": ...}'

Requires Python >= 3.9, NumPy and SciPy.
"""
from __future__ import annotations

import argparse
import functools
import itertools
import json
import math
import sys
import warnings
from dataclasses import dataclass, field, fields, is_dataclass
from enum import Enum
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
from scipy import special, stats

__version__ = "1.0.0"

__all__ = [
    # structured inputs and results
    "Hypothesis", "HypothesisSet", "Evidence", "ProvenanceGroup", "ResourceCost",
    "ResourceBudget", "ResearchAction", "UsefulnessBelief", "StopCriteria",
    "ExclusionRecord", "AdmissionReport", "PosteriorResult", "BetaPosterior",
    "MonteCarloEstimate", "ActionEvaluation", "ActionRanking", "StopAssessment",
    "ActionRecommendation", "LikelihoodModel", "LikelihoodBasis", "StopReason",
    # Bayesian updating
    "update_binary_posterior", "update_categorical_posterior", "update_beta_bernoulli",
    "posterior_predictive", "prior_sensitivity", "admit_evidence", "assess_evidence",
    # Monte Carlo
    "monte_carlo_expectation", "propagate_uncertainty", "probability_of_event",
    "compare_alternatives",
    # research actions
    "expected_information_gain", "expected_value_of_information", "thompson_select",
    "record_usefulness_outcome", "rank_research_actions",
    # budget and stopping
    "filter_affordable_actions", "recommend_next_action", "should_stop",
    # LLM tool interface
    "run_tool", "run_tool_json", "tool_definitions", "to_jsonable",
    # errors
    "InferenceError", "ValidationError", "NonFiniteInputError", "DimensionError",
    "ImpossibleEvidenceError", "LimitExceededError", "UnjustifiedInputError",
    # demonstration and verification
    "run_demo", "run_self_checks",
]

# =============================================================================
# 0. Constants, errors, validation and JSON conversion
# =============================================================================

LN2 = math.log(2.0)
SIMPLEX_TOL = 1e-6              # probability vectors must sum to 1 within this
PROB_TOL = 1e-12                # slack allowed above 1 for a probability
MAX_DRAWS_LIMIT = 20_000_000    # hard cap for trusted Python callers
MAX_BATCH = 1_000_000
JSON_MAX_DRAWS = 2_000_000
JSON_MAX_BATCH = 200_000
JSON_MAX_WORK = 4_000_000       # JSON calls: max_draws x number of simulated outputs
SUMMARY_STORE_LIMIT = 200_000   # input draws kept for input summaries
MAX_HYPOTHESES = 200
MAX_OUTCOMES = 200
MAX_DECISIONS = 100
MAX_ITEMS = 2_000
MAX_INPUTS = 50
MAX_ALTERNATIVES = 20
MAX_STR = 4_000
MAX_EXPR_NODES = 500
MAX_EXPR_DEPTH = 40
MAX_JSON_DEPTH = 40
MAX_JSON_NODES = 500_000
MAX_ENUMERATION_LIMIT = 200_000
MAX_EIG_WORK = 5_000_000        # hypotheses x outcome configurations (exact enumeration)
MAX_EIG_SAMPLE_WORK = 10_000_000  # samples x max(hypotheses, outcomes) (Monte Carlo)
DEFAULT_QUANTILES = (0.05, 0.25, 0.5, 0.75, 0.95)
MAX_MAGNITUDE = 1e150           # simulated values, distribution parameters and utilities stay within +/- this
MAX_RESOURCE = 1e15             # sanity bound for cost and budget figures
MAX_BETA_PARAM = 1e12           # sanity bound for Beta parameters


class InferenceError(ValueError):
    """Base error with a machine-readable ``code`` and JSON-safe ``details``."""

    default_code = "invalid_arguments"

    def __init__(self, message: str, *, code: Optional[str] = None,
                 details: Optional[Mapping[str, Any]] = None) -> None:
        super().__init__(message)
        self.code = code or self.default_code
        self.details = dict(details or {})

    def to_dict(self) -> Dict[str, Any]:
        """Structured error for the JSON dispatcher."""
        return {"code": self.code, "message": str(self), "details": to_jsonable(self.details)}


class ValidationError(InferenceError):
    """Malformed, out-of-range or inconsistent input."""
    default_code = "invalid_arguments"


class NonFiniteInputError(InferenceError):
    """NaN or infinity in an input, or a calculation that produced one."""
    default_code = "non_finite_input"


class DimensionError(InferenceError):
    """Arrays or mappings whose sizes or keys do not match."""
    default_code = "dimension_mismatch"


class ImpossibleEvidenceError(InferenceError):
    """Every hypothesis with non-zero prior gives the evidence zero probability."""
    default_code = "impossible_evidence"


class LimitExceededError(InferenceError):
    """A size or computation limit was exceeded."""
    default_code = "limit_exceeded"


class UnjustifiedInputError(InferenceError):
    """Input this module refuses to treat as statistical data."""
    default_code = "unjustified_input"


def _num(x: Any, name: str, *, lo: Optional[float] = None, hi: Optional[float] = None,
         lo_open: bool = False, hi_open: bool = False) -> float:
    """Validate a finite real scalar (booleans rejected) within optional bounds."""
    if isinstance(x, (bool, np.bool_)) or not isinstance(x, (int, float, np.integer, np.floating)):
        raise ValidationError(f"'{name}' must be a real number.", details={"argument": name})
    try:
        v = float(x)
    except OverflowError:
        raise NonFiniteInputError(f"'{name}' is too large to represent.",
                                  details={"argument": name}) from None
    if not math.isfinite(v):
        raise NonFiniteInputError(f"'{name}' must be finite; NaN and infinity are rejected.",
                                  details={"argument": name})
    if lo is not None and (v < lo or (lo_open and v == lo)):
        raise ValidationError(f"'{name}' must be {'>' if lo_open else '>='} {lo:g}; got {v:g}.",
                              code="out_of_range", details={"argument": name, "value": v})
    if hi is not None and (v > hi or (hi_open and v == hi)):
        raise ValidationError(f"'{name}' must be {'<' if hi_open else '<='} {hi:g}; got {v:g}.",
                              code="out_of_range", details={"argument": name, "value": v})
    return v


def _opt_num(x: Any, name: str, **bounds: Any) -> Optional[float]:
    return None if x is None else _num(x, name, **bounds)


def _int(x: Any, name: str, *, lo: Optional[int] = None, hi: Optional[int] = None,
         hi_code: str = "out_of_range") -> int:
    """Validate an integer (integral floats accepted, booleans rejected)."""
    if isinstance(x, (bool, np.bool_)):
        raise ValidationError(f"'{name}' must be an integer.", details={"argument": name})
    if isinstance(x, (int, np.integer)):
        v = int(x)
    elif isinstance(x, (float, np.floating)) and math.isfinite(float(x)) and float(x).is_integer():
        v = int(x)
    else:
        raise ValidationError(f"'{name}' must be an integer.", details={"argument": name})
    if lo is not None and v < lo:
        raise ValidationError(f"'{name}' must be >= {lo}; got {v}.", code="out_of_range",
                              details={"argument": name, "value": v})
    if hi is not None and v > hi:
        err = LimitExceededError if hi_code == "limit_exceeded" else ValidationError
        raise err(f"'{name}' must be <= {hi}; got {v}.", code=hi_code,
                  details={"argument": name, "value": v})
    return v


def _str(x: Any, name: str, *, allow_empty: bool = False, max_len: int = MAX_STR) -> str:
    if not isinstance(x, str):
        raise ValidationError(f"'{name}' must be a string.", details={"argument": name})
    if not allow_empty and not x.strip():
        raise ValidationError(f"'{name}' must be a non-empty string.", details={"argument": name})
    if len(x) > max_len:
        raise LimitExceededError(f"'{name}' exceeds {max_len} characters.", details={"argument": name})
    return x


def _bool(x: Any, name: str) -> bool:
    if not isinstance(x, (bool, np.bool_)):
        raise ValidationError(f"'{name}' must be a boolean.", details={"argument": name})
    return bool(x)


def _enum(cls: Any, value: Any, name: str) -> Any:
    if isinstance(value, cls):
        return value
    try:
        return cls(value)
    except (ValueError, TypeError):
        allowed = [m.value for m in cls]
        raise ValidationError(f"'{name}' must be one of {allowed}; got {str(value)[:80]!r}.",
                              details={"argument": name, "allowed": allowed}) from None


def _arr(x: Any, name: str, *, ndim: Optional[int] = None, nonneg: bool = False,
         promote_scalar: bool = False) -> np.ndarray:
    """Validate a finite, non-empty numeric array (booleans and ragged input rejected)."""
    try:
        arr = np.asarray(x)
    except (ValueError, TypeError):
        raise ValidationError(f"'{name}' must be a rectangular numeric array.",
                              details={"argument": name}) from None
    if arr.dtype == bool or arr.dtype.kind not in "iuf":
        raise ValidationError(f"'{name}' must contain only real numbers.", details={"argument": name})
    arr = arr.astype(float)
    if promote_scalar and arr.ndim == 0:
        arr = arr.reshape(1)
    if ndim is not None and arr.ndim != ndim:
        raise DimensionError(f"'{name}' must be {ndim}-dimensional; got shape {arr.shape}.",
                             details={"argument": name, "shape": list(arr.shape)})
    if arr.size == 0:
        raise ValidationError(f"'{name}' must not be empty.", details={"argument": name})
    if not np.isfinite(arr).all():
        raise NonFiniteInputError(f"'{name}' contains NaN or infinite values.", details={"argument": name})
    if nonneg and (arr < 0).any():
        raise ValidationError(f"'{name}' must be non-negative.", code="out_of_range",
                              details={"argument": name})
    return arr


def _simplex(x: Any, name: str, n: Optional[int] = None) -> np.ndarray:
    """Validate a probability vector summing to 1 (renormalised to remove rounding)."""
    p = _arr(x, name, ndim=1, nonneg=True)
    if n is not None and p.size != n:
        raise DimensionError(f"'{name}' must have length {n}; got {p.size}.", details={"argument": name})
    if (p > 1.0 + PROB_TOL).any():
        raise ValidationError(f"'{name}' contains a probability above 1.", code="probability_out_of_range",
                              details={"argument": name})
    total = float(p.sum())
    if abs(total - 1.0) > SIMPLEX_TOL:
        raise ValidationError(f"'{name}' must sum to 1 (got {total:.8g}).", code="probability_out_of_range",
                              details={"argument": name, "sum": total})
    return p / total


def _ids(ids: Optional[Sequence[str]], n: int, name: str, prefix: str = "H") -> List[str]:
    if ids is None:
        return [f"{prefix}{i + 1}" for i in range(n)]
    if isinstance(ids, str) or not isinstance(ids, (list, tuple)):
        raise ValidationError(f"'{name}' must be a list of strings.", details={"argument": name})
    out = [_str(v, f"{name}[{i}]", max_len=200) for i, v in enumerate(ids)]
    if len(out) != n:
        raise DimensionError(f"'{name}' must have {n} entries; got {len(out)}.", details={"argument": name})
    if len(set(out)) != n:
        raise ValidationError(f"'{name}' must be unique.", details={"argument": name})
    return out


def _log(x: Any) -> np.ndarray:
    """Natural log with log(0) = -inf and no warning."""
    with np.errstate(divide="ignore"):
        return np.log(np.asarray(x, dtype=float))


def _entropy_bits(p: np.ndarray, axis: int = 0) -> np.ndarray:
    """Shannon entropy in bits along ``axis`` (0 log 0 = 0)."""
    return special.entr(p).sum(axis=axis) / LN2


def _safe_exp(x: float) -> float:
    """exp(x) with overflow mapped to +inf (emitted as null in JSON)."""
    if x == -math.inf:
        return 0.0
    if x > 709.0:
        return math.inf
    return math.exp(x)


def _qkey(q: float) -> str:
    return f"q{q:g}"


def to_jsonable(obj: Any) -> Any:
    """Convert results to strict JSON values. Non-finite floats become ``None``."""
    if obj is None:
        return None
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, (bool, np.bool_)):
        return bool(obj)
    if isinstance(obj, (int, np.integer)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        v = float(obj)
        return v if math.isfinite(v) else None
    if isinstance(obj, str):
        return obj
    if isinstance(obj, np.ndarray):
        return to_jsonable(obj.tolist())
    if is_dataclass(obj) and not isinstance(obj, type):
        return {f.name: to_jsonable(getattr(obj, f.name)) for f in fields(obj) if not f.name.startswith("_")}
    if isinstance(obj, Mapping):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, (set, frozenset)):
        return sorted(to_jsonable(v) for v in obj)
    raise TypeError(f"Cannot convert {type(obj).__name__} to JSON.")


# =============================================================================
# 1. Structured inputs and results
# =============================================================================

class LikelihoodModel(str, Enum):
    """How an observation's likelihood is specified."""
    CATEGORICAL = "categorical"            # P(e | h) for every hypothesis
    LIKELIHOOD_RATIO = "likelihood_ratio"  # two hypotheses: P(e | numerator) / P(e | other)
    NONE = "none"                          # recorded only; never changes the posterior


class LikelihoodBasis(str, Enum):
    """Where a likelihood or observation model came from."""
    CALIBRATED_ON_LABELLED_DATA = "calibrated_on_labelled_data"
    PUBLISHED_TEST_CHARACTERISTICS = "published_test_characteristics"
    MECHANISTIC_MODEL = "mechanistic_model"
    DOCUMENTED_EXPERT_ELICITATION = "documented_expert_elicitation"
    LLM_VERBAL_CONFIDENCE = "llm_verbal_confidence"   # never accepted as a likelihood
    UNSPECIFIED = "unspecified"                       # never accepted as a likelihood


#: Bases that allow a likelihood or observation model to change the posterior.
JUSTIFIED_BASES = frozenset({
    LikelihoodBasis.CALIBRATED_ON_LABELLED_DATA,
    LikelihoodBasis.PUBLISHED_TEST_CHARACTERISTICS,
    LikelihoodBasis.MECHANISTIC_MODEL,
    LikelihoodBasis.DOCUMENTED_EXPERT_ELICITATION,
})


class StopReason(str, Enum):
    """Machine-readable reasons reported by :func:`should_stop`."""
    NO_AFFORDABLE_ACTION = "no_affordable_action"
    BUDGET_EXHAUSTED = "budget_exhausted"
    EIG_BELOW_THRESHOLD = "expected_information_gain_below_threshold"
    NO_POSITIVE_NET_VOI = "no_positive_net_value_of_information"
    MISSING_OBSERVATION_MODEL = "missing_observation_model"
    MORE_EVIDENCE_REQUIRED = "more_evidence_required"
    POSTERIOR_THRESHOLD_MET = "posterior_threshold_met_within_model"


#: Sources of binary outcomes accepted for Beta-Bernoulli and Thompson updates.
ACCEPTED_OUTCOME_SOURCES = frozenset({
    "independent_human_label", "verified_against_ground_truth", "validated_automatic_check"})
_REJECTED_OUTCOME_SOURCES = {
    "simulated": "simulated successes are not observations",
    "llm_self_rating": "an LLM rating its own result is not an independent label",
    "unvalidated_llm_rating": "LLM ratings must be validated against labels before use",
}

#: Suggested values for ResearchAction.kind (not enforced).
KNOWN_ACTION_KINDS = ("search_new_source_collection", "retrieve_primary_document",
                      "seek_contradictory_evidence", "verify_extracted_claim", "run_model_call")

#: (cost field, budget limit field, budget spent field, units), tracked separately.
RESOURCES = (
    ("money", "money_limit", "money_spent", "currency units (e.g. USD)"),
    ("tokens", "token_limit", "tokens_spent", "tokens"),
    ("calls", "call_limit", "calls_spent", "model or tool calls"),
    ("seconds", "time_limit_seconds", "seconds_elapsed", "seconds of wall-clock time"),
)


def _check_outcome_source(source: Any, name: str = "outcome_source") -> str:
    s = _str(source, name, max_len=100)
    if s in ACCEPTED_OUTCOME_SOURCES:
        return s
    why = _REJECTED_OUTCOME_SOURCES.get(s, "it is not an accepted source of actual observed outcomes")
    raise UnjustifiedInputError(
        f"Outcome source '{s}' rejected: {why}. Beta-Bernoulli and Thompson updates use only actual "
        "binary outcomes.", details={"argument": name, "accepted": sorted(ACCEPTED_OUTCOME_SOURCES)})


def _likelihood_map(m: Any, name: str, is_density: bool) -> Dict[str, float]:
    if not isinstance(m, Mapping) or not m:
        raise ValidationError(f"'{name}' must be a non-empty mapping hypothesis_id -> likelihood.")
    if len(m) > MAX_HYPOTHESES:
        raise LimitExceededError(f"'{name}' has too many entries.")
    out: Dict[str, float] = {}
    for k, v in m.items():
        key = _str(k, f"{name} key", max_len=200)
        val = _num(v, f"{name}['{key}']", lo=0.0, hi=None if is_density else 1.0 + PROB_TOL)
        out[key] = val if is_density else min(val, 1.0)
    return out


def _str_tuple(x: Any, name: str) -> Tuple[str, ...]:
    if isinstance(x, str) or not isinstance(x, (list, tuple)):
        raise ValidationError(f"'{name}' must be a list of strings.")
    out = tuple(_str(v, f"{name}[{i}]", max_len=200) for i, v in enumerate(x))
    if len(set(out)) != len(out):
        raise ValidationError(f"'{name}' must not contain duplicates.")
    return out


@dataclass(frozen=True)
class Hypothesis:
    """A candidate explanation with an explicit prior probability and its basis."""
    id: str
    prior: float
    description: str = ""
    prior_basis: str = ""

    def __post_init__(self) -> None:
        _str(self.id, "hypothesis.id", max_len=200)
        object.__setattr__(self, "prior", _num(self.prior, f"prior of '{self.id}'", lo=0.0, hi=1.0))
        _str(self.description, "hypothesis.description", allow_empty=True)
        _str(self.prior_basis, "hypothesis.prior_basis", allow_empty=True)


@dataclass(frozen=True)
class HypothesisSet:
    """Mutually exclusive, jointly exhaustive hypotheses whose priors sum to 1."""
    hypotheses: Tuple[Hypothesis, ...]

    def __post_init__(self) -> None:
        hs = tuple(self.hypotheses)
        if len(hs) < 2:
            raise ValidationError("At least two hypotheses are required.")
        if len(hs) > MAX_HYPOTHESES:
            raise LimitExceededError(f"At most {MAX_HYPOTHESES} hypotheses are supported.")
        if not all(isinstance(h, Hypothesis) for h in hs):
            raise ValidationError("HypothesisSet entries must be Hypothesis objects.")
        ids = [h.id for h in hs]
        if len(set(ids)) != len(ids):
            raise ValidationError("Hypothesis ids must be unique.", details={"ids": ids})
        _simplex([h.prior for h in hs], "hypothesis priors")
        object.__setattr__(self, "hypotheses", hs)

    @classmethod
    def from_priors(cls, priors: Mapping[str, float]) -> "HypothesisSet":
        """Build from ``{id: prior}``."""
        return cls(tuple(Hypothesis(k, v) for k, v in priors.items()))

    @property
    def ids(self) -> List[str]:
        return [h.id for h in self.hypotheses]

    @property
    def prior(self) -> np.ndarray:
        return _simplex([h.prior for h in self.hypotheses], "hypothesis priors")


@dataclass(frozen=True)
class Evidence:
    """One observation, its source, provenance group and likelihood model.

    Statistical inputs (``likelihoods`` or ``likelihood_ratio`` with a justified
    ``likelihood_basis``) are kept apart from heuristic and LLM fields
    (``relevance_score``, ``llm_annotation``, ``llm_stated_confidence``), which are
    recorded but never used in posterior calculations.
    """
    evidence_id: str
    source: str
    provenance_group: str
    likelihood_model: LikelihoodModel
    likelihood_basis: LikelihoodBasis = LikelihoodBasis.UNSPECIFIED
    likelihood_justification: str = ""
    likelihoods: Optional[Mapping[str, float]] = None   # P(e | h) by hypothesis id
    likelihood_ratio: Optional[float] = None            # P(e | numerator) / P(e | other)
    ratio_numerator: Optional[str] = None
    is_density: bool = False                 # likelihoods are densities of a continuous observation
    designated: bool = False                 # representative of its provenance group
    content_fingerprint: Optional[str] = None  # e.g. a hash of the retrieved text
    description: str = ""
    # Heuristic and LLM fields: recorded, never used by the inference.
    relevance_score: Optional[float] = None
    llm_annotation: Optional[str] = None
    llm_stated_confidence: Optional[float] = None

    def __post_init__(self) -> None:
        eid = _str(self.evidence_id, "evidence_id", max_len=200)
        _str(self.source, f"evidence '{eid}'.source", max_len=500)
        _str(self.provenance_group, f"evidence '{eid}'.provenance_group", max_len=200)
        object.__setattr__(self, "likelihood_model",
                           _enum(LikelihoodModel, self.likelihood_model, f"evidence '{eid}'.likelihood_model"))
        object.__setattr__(self, "likelihood_basis",
                           _enum(LikelihoodBasis, self.likelihood_basis, f"evidence '{eid}'.likelihood_basis"))
        _str(self.likelihood_justification, f"evidence '{eid}'.likelihood_justification", allow_empty=True)
        _bool(self.is_density, f"evidence '{eid}'.is_density")
        _bool(self.designated, f"evidence '{eid}'.designated")
        if self.likelihoods is not None:
            object.__setattr__(self, "likelihoods", _likelihood_map(
                self.likelihoods, f"evidence '{eid}'.likelihoods", self.is_density))
        if self.likelihood_ratio is not None:
            object.__setattr__(self, "likelihood_ratio",
                               _num(self.likelihood_ratio, f"evidence '{eid}'.likelihood_ratio", lo=0.0))
        if self.ratio_numerator is not None:
            _str(self.ratio_numerator, f"evidence '{eid}'.ratio_numerator", max_len=200)
        if self.likelihood_model is LikelihoodModel.CATEGORICAL and self.likelihoods is None:
            raise ValidationError(f"Evidence '{eid}': the categorical likelihood model requires 'likelihoods'.")
        if self.likelihood_model is LikelihoodModel.LIKELIHOOD_RATIO and (
                self.likelihood_ratio is None or self.ratio_numerator is None):
            raise ValidationError(f"Evidence '{eid}': the likelihood_ratio model requires "
                                  "'likelihood_ratio' and 'ratio_numerator'.")
        if self.content_fingerprint is not None:
            _str(self.content_fingerprint, f"evidence '{eid}'.content_fingerprint", max_len=500)
        _str(self.description, f"evidence '{eid}'.description", allow_empty=True)
        if self.relevance_score is not None:
            object.__setattr__(self, "relevance_score",
                               _num(self.relevance_score, f"evidence '{eid}'.relevance_score"))
        if self.llm_annotation is not None:
            _str(self.llm_annotation, f"evidence '{eid}'.llm_annotation", allow_empty=True)
        if self.llm_stated_confidence is not None:
            object.__setattr__(self, "llm_stated_confidence", _num(
                self.llm_stated_confidence, f"evidence '{eid}'.llm_stated_confidence", lo=0.0, hi=1.0))


@dataclass(frozen=True)
class ProvenanceGroup:
    """Observations sharing an origin (same press release, dataset or model call).

    Optionally carries a justified joint likelihood P(e_1, ..., e_k | h) for the
    listed ``joint_evidence_ids``; it is then applied once in place of the members'
    individual likelihoods.
    """
    group_id: str
    description: str = ""
    designated_evidence_id: Optional[str] = None
    joint_evidence_ids: Tuple[str, ...] = ()
    joint_likelihoods: Optional[Mapping[str, float]] = None
    joint_likelihood_basis: LikelihoodBasis = LikelihoodBasis.UNSPECIFIED
    joint_justification: str = ""
    is_density: bool = False

    def __post_init__(self) -> None:
        gid = _str(self.group_id, "group_id", max_len=200)
        _str(self.description, f"group '{gid}'.description", allow_empty=True)
        if self.designated_evidence_id is not None:
            _str(self.designated_evidence_id, f"group '{gid}'.designated_evidence_id", max_len=200)
        object.__setattr__(self, "joint_evidence_ids",
                           _str_tuple(self.joint_evidence_ids, f"group '{gid}'.joint_evidence_ids"))
        object.__setattr__(self, "joint_likelihood_basis",
                           _enum(LikelihoodBasis, self.joint_likelihood_basis, f"group '{gid}'.joint_likelihood_basis"))
        _str(self.joint_justification, f"group '{gid}'.joint_justification", allow_empty=True)
        _bool(self.is_density, f"group '{gid}'.is_density")
        if self.joint_likelihoods is not None:
            if not self.joint_evidence_ids:
                raise ValidationError(f"Group '{gid}': joint_likelihoods requires joint_evidence_ids.")
            object.__setattr__(self, "joint_likelihoods", _likelihood_map(
                self.joint_likelihoods, f"group '{gid}'.joint_likelihoods", self.is_density))


@dataclass(frozen=True)
class ResourceCost:
    """Resources one action may consume (``None`` = unknown).

    ``kind`` states whether the figures are guaranteed ``"upper_bound"`` values or
    uncertain ``"estimate"`` values.
    """
    money: Optional[float] = None      # currency units
    tokens: Optional[float] = None
    calls: Optional[float] = None
    seconds: Optional[float] = None
    kind: str = "estimate"

    def __post_init__(self) -> None:
        for res, *_ in RESOURCES:
            object.__setattr__(self, res, _opt_num(getattr(self, res), f"cost.{res}", lo=0.0, hi=MAX_RESOURCE))
        if self.kind not in ("upper_bound", "estimate"):
            raise ValidationError("cost.kind must be 'upper_bound' or 'estimate'.")


@dataclass(frozen=True)
class ResourceBudget:
    """Separate limits and consumption for money, tokens, calls and elapsed time.

    A limit of ``None`` means that resource is not limited.
    """
    money_limit: Optional[float] = None
    token_limit: Optional[float] = None
    call_limit: Optional[float] = None
    time_limit_seconds: Optional[float] = None
    money_spent: float = 0.0
    tokens_spent: float = 0.0
    calls_spent: float = 0.0
    seconds_elapsed: float = 0.0

    def __post_init__(self) -> None:
        for _res, lim, spent, _units in RESOURCES:
            object.__setattr__(self, lim, _opt_num(getattr(self, lim), lim, lo=0.0, hi=MAX_RESOURCE))
            object.__setattr__(self, spent, _num(getattr(self, spent), spent, lo=0.0, hi=MAX_RESOURCE))

    def remaining(self) -> Dict[str, Optional[float]]:
        """Remaining amount per resource (``None`` = unlimited; negative if overspent)."""
        out: Dict[str, Optional[float]] = {}
        for res, lim, spent, _units in RESOURCES:
            limit = getattr(self, lim)
            out[res] = None if limit is None else limit - getattr(self, spent)
        return out

    def exhausted(self) -> List[str]:
        """Resources whose limit has been reached or exceeded."""
        return [r for r, rem in self.remaining().items() if rem is not None and rem <= 0.0]


@dataclass(frozen=True)
class ResearchAction:
    """A candidate research step with a finite outcome set and an observation model.

    ``observation_model[h]`` lists P(outcome | h) for each entry of ``outcomes``
    (each row sums to 1). The model must be conditional on the evidence already
    applied: re-reading evidence that was already used carries little new
    information and needs a correspondingly flat model.
    """
    action_id: str
    description: str = ""
    kind: str = "other"
    outcomes: Tuple[str, ...] = ()
    observation_model: Optional[Mapping[str, Sequence[float]]] = None
    observation_model_basis: LikelihoodBasis = LikelihoodBasis.UNSPECIFIED
    observation_model_justification: str = ""
    cost: ResourceCost = field(default_factory=ResourceCost)
    cost_in_utility_units: Optional[float] = None   # only with a justified conversion
    usefulness_arm: Optional[str] = None            # links to a UsefulnessBelief
    llm_annotation: Optional[str] = None            # heuristic note; never used

    def __post_init__(self) -> None:
        aid = _str(self.action_id, "action_id", max_len=200)
        _str(self.description, f"action '{aid}'.description", allow_empty=True)
        _str(self.kind, f"action '{aid}'.kind", max_len=200)
        outs = _str_tuple(self.outcomes, f"action '{aid}'.outcomes")
        if len(outs) > MAX_OUTCOMES:
            raise LimitExceededError(f"Action '{aid}' has more than {MAX_OUTCOMES} outcomes.")
        object.__setattr__(self, "outcomes", outs)
        object.__setattr__(self, "observation_model_basis", _enum(
            LikelihoodBasis, self.observation_model_basis, f"action '{aid}'.observation_model_basis"))
        _str(self.observation_model_justification, f"action '{aid}'.observation_model_justification",
             allow_empty=True)
        if self.observation_model is not None:
            if not isinstance(self.observation_model, Mapping) or not self.observation_model:
                raise ValidationError(f"Action '{aid}': observation_model must be a non-empty mapping.")
            if not outs:
                raise ValidationError(f"Action '{aid}': an observation model needs a non-empty 'outcomes' list.")
            model: Dict[str, Tuple[float, ...]] = {}
            for h, row in self.observation_model.items():
                key = _str(h, f"action '{aid}'.observation_model key", max_len=200)
                path = f"action '{aid}'.observation_model['{key}']"
                r = _arr(row, path, ndim=1, nonneg=True)
                if r.size != len(outs):
                    raise DimensionError(f"{path} must have one probability per outcome ({len(outs)}).")
                if (r > 1.0 + PROB_TOL).any():
                    raise ValidationError(f"{path} contains a probability above 1.", code="probability_out_of_range")
                s = float(r.sum())
                if abs(s - 1.0) > SIMPLEX_TOL:
                    raise ValidationError(f"{path} must sum to 1 over the action's exhaustive outcomes (got {s:.6g}).",
                                          code="probability_out_of_range")
                model[key] = tuple(float(v) for v in r / s)
            object.__setattr__(self, "observation_model", model)
        if not isinstance(self.cost, ResourceCost):
            raise ValidationError(f"Action '{aid}': cost must be a ResourceCost.")
        object.__setattr__(self, "cost_in_utility_units",
                           _opt_num(self.cost_in_utility_units, f"action '{aid}'.cost_in_utility_units", lo=0.0,
                                    hi=MAX_MAGNITUDE))
        if self.usefulness_arm is not None:
            _str(self.usefulness_arm, f"action '{aid}'.usefulness_arm", max_len=200)
        if self.llm_annotation is not None:
            _str(self.llm_annotation, f"action '{aid}'.llm_annotation", allow_empty=True)

    def observation_model_status(self) -> Tuple[bool, Optional[str]]:
        """(usable, reason if not usable)."""
        if self.observation_model is None:
            return False, "no observation model supplied"
        if self.observation_model_basis not in JUSTIFIED_BASES:
            return False, (f"observation model basis '{self.observation_model_basis.value}' "
                           "is not a justified basis")
        return True, None

    def likelihood_matrix(self, hypotheses: HypothesisSet) -> np.ndarray:
        """P(outcome | h) as an array of shape (n_hypotheses, n_outcomes)."""
        if self.observation_model is None:
            raise ValidationError(f"Action '{self.action_id}' has no observation model.")
        ids = hypotheses.ids
        missing = [h for h in ids if h not in self.observation_model]
        extra = [h for h in self.observation_model if h not in ids]
        if missing or extra:
            raise DimensionError(f"Action '{self.action_id}': observation-model keys must match the hypothesis ids.",
                                 details={"missing": missing, "unexpected": extra})
        return np.array([self.observation_model[h] for h in ids], dtype=float)


@dataclass(frozen=True)
class UsefulnessBelief:
    """Beta(alpha, beta) belief that an action type or source yields a useful result.

    Update only with :func:`record_usefulness_outcome`, from actual independently
    labelled binary outcomes, never from simulated successes or unvalidated LLM ratings.
    """
    arm_id: str
    alpha: float = 1.0
    beta: float = 1.0
    n_successes: int = 0
    n_failures: int = 0

    def __post_init__(self) -> None:
        _str(self.arm_id, "arm_id", max_len=200)
        object.__setattr__(self, "alpha", _num(self.alpha, "alpha", lo=0.0, lo_open=True, hi=MAX_BETA_PARAM))
        object.__setattr__(self, "beta", _num(self.beta, "beta", lo=0.0, lo_open=True, hi=MAX_BETA_PARAM))
        object.__setattr__(self, "n_successes", _int(self.n_successes, "n_successes", lo=0))
        object.__setattr__(self, "n_failures", _int(self.n_failures, "n_failures", lo=0))


@dataclass(frozen=True)
class StopCriteria:
    """Thresholds used by :func:`should_stop`.

    ``stop_on_posterior_threshold`` is off by default: a strong posterior does not by
    itself show that the evidence is comprehensive.
    """
    eig_threshold_bits: float = 0.02
    voi_threshold: float = 0.0
    posterior_threshold: float = 0.95
    min_independent_groups: int = 2
    require_prior_robust: bool = True
    stop_on_posterior_threshold: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(self, "eig_threshold_bits", _num(self.eig_threshold_bits, "eig_threshold_bits", lo=0.0))
        object.__setattr__(self, "voi_threshold", _num(self.voi_threshold, "voi_threshold"))
        object.__setattr__(self, "posterior_threshold",
                           _num(self.posterior_threshold, "posterior_threshold", lo=0.0, hi=1.0))
        object.__setattr__(self, "min_independent_groups",
                           _int(self.min_independent_groups, "min_independent_groups", lo=0, hi=MAX_ITEMS))
        _bool(self.require_prior_robust, "require_prior_robust")
        _bool(self.stop_on_posterior_threshold, "stop_on_posterior_threshold")


@dataclass
class ExclusionRecord:
    """An observation that was not applied, and why."""
    evidence_id: str
    reason: str
    explanation: str


@dataclass
class AdmissionReport:
    """Outcome of duplicate, justification and dependence screening."""
    applied: List[Dict[str, Any]]
    excluded: List[ExclusionRecord]
    recorded_only: List[ExclusionRecord]
    independent_groups_used: int
    policy: str
    policy_note: str
    warnings: List[str]
    _log_likelihood: Any = field(default=None, repr=False)
    _absolute_scale: bool = field(default=True, repr=False)

    @property
    def applied_evidence_ids(self) -> List[str]:
        return [e for item in self.applied for e in item["evidence_ids"]]


@dataclass
class PosteriorResult:
    """Posterior over hypotheses with provenance, sensitivity and assumptions.

    ``log_likelihood`` is the summed log P(admitted evidence | h); in JSON, ``null``
    marks -infinity (a zero likelihood). When only likelihood ratios were supplied it
    is defined up to an additive constant and ``log_marginal_likelihood`` is ``None``.
    """
    hypothesis_ids: List[str]
    prior: List[float]
    posterior: List[float]
    map_hypothesis: str
    max_posterior: float
    entropy_bits: float
    log_likelihood: List[float]
    log_likelihood_scale: str
    log_marginal_likelihood: Optional[float]
    applied: List[Dict[str, Any]]
    applied_evidence_ids: List[str]
    excluded: List[ExclusionRecord]
    recorded_only: List[ExclusionRecord]
    independent_groups_used: int
    binary: Optional[Dict[str, Any]]
    prior_sensitivity: Optional[Dict[str, Any]]
    assumptions: List[str]
    warnings: List[str]

    def posterior_dict(self) -> Dict[str, float]:
        return dict(zip(self.hypothesis_ids, self.posterior))

    def summary(self) -> Dict[str, Any]:
        """Compact view for prompts and logs."""
        sens = self.prior_sensitivity or {}
        return {
            "posterior": self.posterior_dict(),
            "map_hypothesis": self.map_hypothesis,
            "max_posterior": self.max_posterior,
            "entropy_bits": self.entropy_bits,
            "independent_groups_used": self.independent_groups_used,
            "applied_evidence_ids": list(self.applied_evidence_ids),
            "excluded_evidence_ids": [r.evidence_id for r in self.excluded],
            "recorded_only_evidence_ids": [r.evidence_id for r in self.recorded_only],
            "conclusion_robust_to_prior": sens.get("conclusion_robust_to_prior"),
            "contamination_bounds_for_map": (sens.get("contamination_bounds") or {}).get(self.map_hypothesis),
        }

    def to_dict(self) -> Dict[str, Any]:
        return to_jsonable(self)


@dataclass
class BetaPosterior:
    """Beta posterior for a Bernoulli success probability theta.

    ``credible_interval`` describes uncertainty about theta. The next binary outcome
    is Bernoulli with probability ``predictive_next_success`` (the posterior mean of
    theta); that outcome stays uncertain however narrow the interval is.
    """
    prior_alpha: float
    prior_beta: float
    successes: int
    failures: int
    outcome_source: str
    alpha: float
    beta: float
    mean: float
    sd: float
    mode: Optional[float]
    credible_level: float
    credible_interval: List[float]
    predictive_next_success: float
    interpretation: List[str]


@dataclass
class MonteCarloEstimate:
    """Monte Carlo estimate of E[Y], keeping outcome spread and numerical error apart.

    ``std``, ``quantiles`` and ``outcome_interval`` describe the distribution of the
    simulated quantity (uncertainty propagated from the inputs). ``mc_standard_error``
    and ``mean_numerical_interval`` describe only the Monte Carlo error of the
    estimated mean and shrink as draws increase.
    """
    mean: float
    std: float
    mc_standard_error: float
    n_draws: int
    n_batches: int
    stopping_reason: str
    seed: int
    quantiles: Dict[str, float]
    outcome_interval: Optional[List[float]]
    outcome_interval_level: Optional[float]
    mean_numerical_interval: List[float]
    numerical_interval_method: str
    precision_target: Dict[str, Any]
    adaptive_stopping: bool
    notes: List[str]
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ActionEvaluation:
    """Value and affordability of one candidate action under the current belief."""
    action_id: str
    kind: str
    description: str
    has_observation_model: bool
    observation_model_issue: Optional[str]
    affordable: bool
    affordability_reasons: List[str]
    budget_compliance: str
    cost: Dict[str, Optional[float]]
    cost_kind: str
    cost_in_utility_units: Optional[float]
    expected_information_gain_bits: Optional[float] = None
    eig_method: Optional[str] = None
    eig_mc_standard_error: Optional[float] = None
    predictive_outcome_probabilities: Optional[Dict[str, float]] = None
    evsi: Optional[float] = None
    evsi_mc_standard_error: Optional[float] = None
    net_value_of_information: Optional[float] = None
    decision_rule: Optional[Dict[str, str]] = None
    heuristic_score: Optional[float] = None
    rank: Optional[int] = None
    notes: List[str] = field(default_factory=list)


@dataclass
class ActionRanking:
    """Evaluated actions in rank order and the criterion used."""
    evaluations: List[ActionEvaluation]
    criterion: str
    criterion_is_heuristic: bool
    criterion_description: str
    belief: Dict[str, float]
    seed: int
    budget_report: Optional[Dict[str, Any]]
    notes: List[str]


@dataclass
class StopAssessment:
    """Whether to stop researching, why, and how to describe the evidence."""
    should_stop: bool
    outcome: str
    reasons: List[str]
    stop_reasons: List[str]
    evidence_status: str
    insufficiency: List[str]
    answer_guidance: str
    details: Dict[str, Any]
    prior_sensitivity: Optional[Dict[str, Any]]
    model_assumptions: List[str]
    caveats: List[str]


@dataclass
class ActionRecommendation:
    """The next action (or none), the ranking behind it and the stopping assessment."""
    recommended_action_id: Optional[str]
    policy: str
    selection_criterion: str
    criterion_is_heuristic: bool
    stop_assessment: StopAssessment
    ranking: ActionRanking
    posterior_summary: Dict[str, Any]
    thompson: Optional[Dict[str, Any]]
    notes: List[str]


# =============================================================================
# 2. Bayesian updating
# =============================================================================

DEPENDENCE_POLICY_NOTE = (
    "Simplifying dependence policy: when observations share a provenance group and no justified joint "
    "likelihood is supplied, only one designated observation per group is applied (the least informative "
    "one if none is designated). This avoids multiplying correlated evidence as if it were independent, but "
    "it is not a model of the true dependence and may discard information. Supply a joint likelihood "
    "P(e_1, ..., e_k | h) to use the whole group.")

BASE_ASSUMPTIONS = (
    "Hypotheses are treated as mutually exclusive and jointly exhaustive; no probability is reserved for "
    "unlisted explanations (add an explicit 'other' hypothesis if one is plausible).",
    "Supplied likelihoods are taken as correct; this module does not verify their calibration.",
    "Heuristic relevance scores, LLM annotations and LLM-stated confidence were not used.",
)
EVIDENCE_ASSUMPTIONS = BASE_ASSUMPTIONS + (
    "Observations in different provenance groups are treated as conditionally independent given each hypothesis.",
    DEPENDENCE_POLICY_NOTE,
)


def _normalise(log_prior: np.ndarray, log_lik: np.ndarray, ids: Sequence[str],
               evidence_ids: Sequence[str] = ()) -> Tuple[np.ndarray, float, np.ndarray]:
    """Return (posterior, log marginal likelihood, log joint), normalised with logsumexp."""
    log_joint = log_prior + log_lik
    if not np.isfinite(log_joint).any():
        raise ImpossibleEvidenceError(
            "Every hypothesis with non-zero prior assigns zero probability to the evidence, so the posterior is "
            "undefined and no update was applied. Likely causes: the hypothesis set is incomplete, a likelihood "
            "is misspecified, or the observation is erroneous.",
            details={"hypotheses_with_nonzero_prior": [ids[i] for i in np.flatnonzero(np.isfinite(log_prior))],
                     "evidence_ids": list(evidence_ids)})
    log_ml = float(special.logsumexp(log_joint))
    post = np.exp(log_joint - log_ml)
    return post / post.sum(), log_ml, log_joint


def _posterior_result(ids: Sequence[str], prior: Any, log_lik: Any, *, evidence_ids: Sequence[str],
                      applied: Sequence[Dict[str, Any]], excluded: Sequence[ExclusionRecord] = (),
                      recorded: Sequence[ExclusionRecord] = (), groups_used: int,
                      assumptions: Sequence[str], warnings_: Sequence[str] = (),
                      absolute_scale: bool = True,
                      sensitivity_epsilon: Optional[float] = 0.1) -> PosteriorResult:
    prior = np.asarray(prior, dtype=float)
    ll = np.asarray(log_lik, dtype=float)
    post, log_ml, log_joint = _normalise(_log(prior), ll, ids, evidence_ids)
    warn = list(warnings_)
    eliminated = [ids[i] for i in range(len(ids)) if prior[i] > 0 and np.isneginf(ll[i])]
    if eliminated:
        warn.append(f"Hypotheses {eliminated} were eliminated by a zero likelihood; later evidence cannot revive "
                    "them. Use a small non-zero likelihood unless the observation is logically impossible under them.")
    if not evidence_ids:
        warn.append("No evidence was applied; the posterior equals the prior.")
    k = int(np.argmax(post))
    if int(np.sum(np.isclose(post, post[k], rtol=0.0, atol=1e-12))) > 1:
        warn.append("Two or more hypotheses tie for the highest posterior.")
    binary = None
    if len(ids) == 2:
        with np.errstate(invalid="ignore"):
            lbf = float(ll[0] - ll[1])
            plo = float(log_joint[0] - log_joint[1])
        binary = {"numerator_hypothesis": ids[0], "log_bayes_factor": lbf, "bayes_factor": _safe_exp(lbf),
                  "posterior_log_odds": plo, "posterior_odds": _safe_exp(plo),
                  "note": f"Bayes factor = P(evidence | {ids[0]}) / P(evidence | {ids[1]}); "
                          "null denotes an infinite value."}
    sens = None
    if sensitivity_epsilon is not None:
        sens = prior_sensitivity(prior, ll, hypothesis_ids=ids, epsilon=sensitivity_epsilon)
    return PosteriorResult(
        hypothesis_ids=list(ids), prior=prior.tolist(), posterior=post.tolist(),
        map_hypothesis=ids[k], max_posterior=float(post[k]), entropy_bits=float(_entropy_bits(post)),
        log_likelihood=ll.tolist(),
        log_likelihood_scale=("absolute" if absolute_scale else
                              "relative (likelihood ratios only; defined up to an additive constant)"),
        log_marginal_likelihood=log_ml if absolute_scale else None,
        applied=list(applied), applied_evidence_ids=list(evidence_ids), excluded=list(excluded),
        recorded_only=list(recorded), independent_groups_used=int(groups_used), binary=binary,
        prior_sensitivity=sens, assumptions=list(assumptions), warnings=warn)


def update_binary_posterior(prior: float, likelihood_ratios: Any, *,
                            hypothesis_ids: Sequence[str] = ("H1", "H0"),
                            sensitivity_epsilon: Optional[float] = 0.1) -> PosteriorResult:
    """Posterior for H1 vs H0: posterior odds = prior odds x product of likelihood ratios.

    ``prior`` is P(H1). Each likelihood ratio is P(e | H1) / P(e | H0) from a justified
    likelihood model (for example a test's sensitivity divided by its false-positive
    rate measured on labelled data), never an LLM's stated confidence. Several ratios
    are summed in log space, which assumes the observations are conditionally
    independent given each hypothesis. A ratio of 0 rules H1 out; if P(H1) = 1 as
    well, the evidence is impossible and ImpossibleEvidenceError is raised.
    """
    p = _num(prior, "prior", lo=0.0, hi=1.0)
    lrs = _arr(likelihood_ratios, "likelihood_ratios", ndim=1, nonneg=True, promote_scalar=True)
    if lrs.size > MAX_ITEMS:
        raise LimitExceededError(f"At most {MAX_ITEMS} likelihood ratios per call.")
    ids = _ids(hypothesis_ids, 2, "hypothesis_ids")
    log_bf = float(_log(lrs).sum())
    return _posterior_result(
        ids, [p, 1.0 - p], np.array([log_bf, 0.0]),
        evidence_ids=[f"likelihood_ratio[{i}]" for i in range(lrs.size)],
        applied=[{"mode": "likelihood_ratios", "evidence_ids": [f"likelihood_ratio[{i}]" for i in range(lrs.size)],
                  "values": lrs.tolist()}],
        groups_used=lrs.size,
        assumptions=BASE_ASSUMPTIONS + ("Multiple likelihood ratios are treated as conditionally independent "
                                        "observations given each hypothesis.",),
        absolute_scale=False, sensitivity_epsilon=sensitivity_epsilon)


def update_categorical_posterior(prior: Any, likelihoods: Any, *, hypothesis_ids: Optional[Sequence[str]] = None,
                                 is_density: bool = False,
                                 sensitivity_epsilon: Optional[float] = 0.1) -> PosteriorResult:
    """posterior[h] proportional to prior[h] x product_k P(e_k | h), computed with logsumexp.

    ``likelihoods`` has shape (n_hypotheses,) for one observation or
    (n_observations, n_hypotheses) for observations that are conditionally independent
    given each hypothesis. Values are probabilities of a discrete observation (<= 1)
    unless ``is_density`` is True. Raises ImpossibleEvidenceError when every hypothesis
    with non-zero prior gives the evidence zero probability.
    """
    p = _simplex(prior, "prior")
    if p.size > MAX_HYPOTHESES:
        raise LimitExceededError(f"At most {MAX_HYPOTHESES} hypotheses are supported.")
    ids = _ids(hypothesis_ids, p.size, "hypothesis_ids")
    lik = _arr(likelihoods, "likelihoods", nonneg=True)
    if lik.ndim == 1:
        lik = lik[None, :]
    if lik.ndim != 2 or lik.shape[1] != p.size:
        raise DimensionError(f"'likelihoods' must have shape ({p.size},) or (n_observations, {p.size}); "
                             f"got {lik.shape}.")
    if lik.shape[0] > MAX_ITEMS:
        raise LimitExceededError(f"At most {MAX_ITEMS} observations per call.")
    if not _bool(is_density, "is_density") and (lik > 1.0 + PROB_TOL).any():
        raise ValidationError("Likelihoods of a discrete observation must be <= 1; set is_density=True for "
                              "densities of a continuous observation.", code="probability_out_of_range")
    obs_ids = [f"observation[{i}]" for i in range(lik.shape[0])]
    return _posterior_result(
        ids, p, _log(lik).sum(axis=0), evidence_ids=obs_ids,
        applied=[{"mode": "likelihood_vectors", "evidence_ids": obs_ids}], groups_used=lik.shape[0],
        assumptions=BASE_ASSUMPTIONS + ("Rows of 'likelihoods' are treated as conditionally independent "
                                        "observations given each hypothesis.",),
        sensitivity_epsilon=sensitivity_epsilon)


def update_beta_bernoulli(successes: int, failures: int, *, outcome_source: str,
                          prior_alpha: float = 1.0, prior_beta: float = 1.0,
                          credible_level: float = 0.95) -> BetaPosterior:
    """Conjugate Beta-Bernoulli update from actual binary outcomes.

    Use for observed outcomes such as "did this completed search return a result that
    an independent labeller judged useful?". ``outcome_source`` must be one of
    ACCEPTED_OUTCOME_SOURCES; simulated successes and unvalidated LLM ratings are
    rejected. Returns Beta(alpha, beta), the mean, sd and equal-tailed credible
    interval for theta, and the predictive probability that the next outcome succeeds.
    """
    src = _check_outcome_source(outcome_source)
    a0 = _num(prior_alpha, "prior_alpha", lo=0.0, lo_open=True, hi=MAX_BETA_PARAM)
    b0 = _num(prior_beta, "prior_beta", lo=0.0, lo_open=True, hi=MAX_BETA_PARAM)
    s = _int(successes, "successes", lo=0, hi=10 ** 12)
    f = _int(failures, "failures", lo=0, hi=10 ** 12)
    lvl = _num(credible_level, "credible_level", lo=0.0, hi=1.0, lo_open=True, hi_open=True)
    a, b = a0 + s, b0 + f
    lo, hi = (float(v) for v in stats.beta.ppf([(1.0 - lvl) / 2.0, (1.0 + lvl) / 2.0], a, b))
    mean = a / (a + b)
    sd = math.sqrt(a * b / ((a + b) ** 2 * (a + b + 1.0)))
    mode = (a - 1.0) / (a + b - 2.0) if a > 1.0 and b > 1.0 else None
    return BetaPosterior(
        prior_alpha=a0, prior_beta=b0, successes=s, failures=f, outcome_source=src, alpha=a, beta=b,
        mean=mean, sd=sd, mode=mode, credible_level=lvl, credible_interval=[lo, hi],
        predictive_next_success=mean,
        interpretation=[
            f"Uncertainty about the success probability theta: {lvl * 100:g}% credible interval "
            f"[{lo:.4f}, {hi:.4f}].",
            f"Predictive probability that the next outcome is a success: {mean:.4f}. The next outcome is still a "
            "Bernoulli event; a narrow interval for theta does not make it predictable.",
        ])


def _observation_matrix(x: Any, n_h: int, name: str = "observation_likelihoods") -> np.ndarray:
    """Validate P(outcome | h): shape (n_h, n_outcomes), each row summing to 1."""
    if x is None:
        raise ValidationError(f"'{name}' is required.")
    lik = _arr(x, name, ndim=2, nonneg=True)
    if lik.shape[0] != n_h:
        raise DimensionError(f"'{name}' must have one row per hypothesis ({n_h}); got {lik.shape[0]}.")
    if lik.shape[1] > MAX_OUTCOMES:
        raise LimitExceededError(f"'{name}' has more than {MAX_OUTCOMES} outcomes.")
    if (lik > 1.0 + PROB_TOL).any():
        raise ValidationError(f"'{name}' contains a probability above 1.", code="probability_out_of_range")
    rows = lik.sum(axis=1)
    if np.any(np.abs(rows - 1.0) > SIMPLEX_TOL):
        raise ValidationError(f"Each row of '{name}' must sum to 1 over the action's exhaustive outcomes.",
                              code="probability_out_of_range", details={"row_sums": rows.tolist()})
    return lik / rows[:, None]


def _beta_binomial_predictive(a: float, b: float, n_future: Any) -> Dict[str, Any]:
    n = _int(n_future, "n_future", lo=1, hi=10_000)
    pmf = stats.betabinom.pmf(np.arange(n + 1), n, a, b)
    return {"type": "beta_binomial", "alpha": a, "beta": b, "n_future": n,
            "p_next_success": a / (a + b), "expected_successes": n * a / (a + b),
            "pmf_number_of_successes": pmf.tolist(),
            "note": "Predictive distribution of future binary outcomes, integrating over uncertainty in theta."}


def posterior_predictive(posterior: Any, observation_likelihoods: Any = None, *,
                         outcomes: Optional[Sequence[str]] = None,
                         hypothesis_ids: Optional[Sequence[str]] = None, n_future: int = 1) -> Dict[str, Any]:
    """Predictive distribution of the next observation(s).

    * ``BetaPosterior``: beta-binomial distribution of the number of successes in the
      next ``n_future`` trials; ``p_next_success`` = alpha / (alpha + beta).
    * Hypothesis posterior (``PosteriorResult`` or probability vector) with an
      observation model P(o | h) of shape (n_hypotheses, n_outcomes):
      P(o) = sum_h P(h) P(o | h), plus the posterior each outcome would produce.
    """
    if isinstance(posterior, BetaPosterior):
        return _beta_binomial_predictive(posterior.alpha, posterior.beta, n_future)
    if isinstance(posterior, PosteriorResult):
        probs, ids = posterior.posterior, posterior.hypothesis_ids
    else:
        probs, ids = posterior, hypothesis_ids
    p = _simplex(probs, "posterior")
    ids = _ids(ids, p.size, "hypothesis_ids")
    lik = _observation_matrix(observation_likelihoods, p.size)
    outs = _ids(outcomes, lik.shape[1], "outcomes", prefix="outcome_")
    joint = p[:, None] * lik
    po = joint.sum(axis=0)
    given = {o: (None if po[j] <= 0 else dict(zip(ids, (joint[:, j] / po[j]).tolist())))
             for j, o in enumerate(outs)}
    return {"type": "categorical_mixture", "outcome_probabilities": dict(zip(outs, po.tolist())),
            "posterior_given_outcome": given,
            "note": "P(o) = sum_h P(h) P(o | h); assumes the observation model is conditional on the evidence "
                    "already applied."}


def prior_sensitivity(prior: Any, log_likelihoods: Any, *, hypothesis_ids: Optional[Sequence[str]] = None,
                      epsilon: float = 0.1,
                      alternative_priors: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    """How strongly the conclusion depends on the prior.

    ``log_likelihoods`` is the summed log P(evidence | h) per hypothesis (-inf allowed
    for a zero likelihood; an additive constant is irrelevant). Reports the posterior
    under a uniform prior, exact posterior bounds over the epsilon-contamination class
    {(1 - eps) * prior + eps * q : q any distribution} (extremes occur at point-mass q),
    the posterior under caller-supplied alternative priors, and whether the leading
    hypothesis stays the leading one under all of them.
    """
    p = _simplex(prior, "prior")
    n = p.size
    ids = _ids(hypothesis_ids, n, "hypothesis_ids")
    try:
        ll = np.asarray(log_likelihoods, dtype=float)
    except (TypeError, ValueError):
        raise ValidationError("'log_likelihoods' must be numeric.") from None
    if ll.shape != (n,):
        raise DimensionError(f"'log_likelihoods' must have shape ({n},); got {ll.shape}.")
    if np.isnan(ll).any() or np.isposinf(ll).any():
        raise NonFiniteInputError("'log_likelihoods' may contain -inf (zero likelihood) but not NaN or +inf.")
    eps = _num(epsilon, "epsilon", lo=0.0, hi=1.0, hi_open=True)
    finite = np.isfinite(ll)
    if not finite.any():
        raise ImpossibleEvidenceError("Every hypothesis assigns zero probability to the evidence.")
    lt = np.zeros(n)
    lt[finite] = np.exp(ll[finite] - ll[finite].max())       # scaled likelihoods, max = 1
    m = float(p @ lt)
    if m <= 0.0:
        raise ImpossibleEvidenceError("Every hypothesis with non-zero prior assigns zero probability to the "
                                      "evidence.", details={"hypothesis_ids": ids})
    base = p * lt / m
    uniform = lt / lt.sum()
    order = np.argsort(-lt, kind="stable")
    others_max = np.where(np.arange(n) == order[0], lt[order[1]], lt[order[0]])
    upper = ((1 - eps) * p * lt + eps * lt) / ((1 - eps) * m + eps * lt)
    lower = ((1 - eps) * p * lt) / ((1 - eps) * m + eps * others_max)
    k = int(np.argmax(base))
    tie = int(np.sum(np.isclose(base, base[k], rtol=0.0, atol=1e-12))) > 1
    margins = [(1 - eps) * (p[k] * lt[k] - p[j] * lt[j]) - eps * lt[j] for j in range(n) if j != k]
    robust_contamination = (not tie) and all(mg > 0 for mg in margins)
    map_uniform = ids[int(np.argmax(uniform))]
    alt_out: Dict[str, Any] = {}
    alt_stable = True
    for name, q in (alternative_priors or {}).items():
        qv = _simplex(q, f"alternative_priors['{name}']", n)
        mq = float(qv @ lt)
        if mq <= 0:
            alt_out[str(name)] = {"posterior": None, "map_hypothesis": None,
                                  "note": "the evidence is impossible under this prior"}
            alt_stable = False
            continue
        pq = qv * lt / mq
        j = int(np.argmax(pq))
        alt_out[str(name)] = {"posterior": dict(zip(ids, pq.tolist())), "map_hypothesis": ids[j]}
        alt_stable = alt_stable and j == k
    robust = robust_contamination and map_uniform == ids[k] and alt_stable
    binary = None
    if n == 2 and finite.all():
        lbf = float(ll[0] - ll[1])
        binary = {"hypothesis": ids[0], "log_bayes_factor": lbf,
                  "prior_needed_for_posterior": {f"{t:g}": float(special.expit(special.logit(t) - lbf))
                                                 for t in (0.5, 0.9, 0.95, 0.99)},
                  "note": f"Prior P({ids[0]}) at which this evidence would give each posterior value."}
    return {
        "epsilon": eps,
        "base_posterior": dict(zip(ids, base.tolist())),
        "uniform_prior_posterior": dict(zip(ids, uniform.tolist())),
        "map_hypothesis": ids[k],
        "map_under_uniform_prior": map_uniform,
        "contamination_bounds": {h: [float(lower[i]), float(upper[i])] for i, h in enumerate(ids)},
        "map_robust_to_contamination": robust_contamination,
        "alternative_priors": alt_out,
        "conclusion_robust_to_prior": robust,
        "binary": binary,
        "interpretation": (f"With eps = {eps:g}, P({ids[k]} | evidence) lies in [{lower[k]:.4f}, {upper[k]:.4f}] "
                           "for every prior of the form (1 - eps) * prior + eps * q. The leading hypothesis is "
                           f"{'robust' if robust else 'NOT robust'} to these prior checks (uniform prior, "
                           "contamination class and any alternative priors)."),
    }


# =============================================================================
# 3. Evidence dependence
# =============================================================================

def _mapping_to_loglik(mapping: Mapping[str, float], ids: Sequence[str], name: str) -> np.ndarray:
    missing = [h for h in ids if h not in mapping]
    extra = [h for h in mapping if h not in ids]
    if missing or extra:
        raise DimensionError(f"'{name}' must give a likelihood for exactly the hypotheses {list(ids)}.",
                             details={"missing": missing, "unexpected": extra})
    return _log([mapping[h] for h in ids])


def _evidence_loglik(ev: Evidence, ids: List[str]) -> np.ndarray:
    if ev.likelihood_model is LikelihoodModel.CATEGORICAL:
        return _mapping_to_loglik(ev.likelihoods, ids, f"evidence '{ev.evidence_id}'.likelihoods")
    if len(ids) != 2:
        raise DimensionError(f"Evidence '{ev.evidence_id}': a likelihood ratio needs exactly two hypotheses; "
                             "use categorical likelihoods instead.")
    if ev.ratio_numerator not in ids:
        raise ValidationError(f"Evidence '{ev.evidence_id}': ratio_numerator must be one of {ids}.")
    ll = np.zeros(2)
    ll[ids.index(ev.ratio_numerator)] = -math.inf if ev.likelihood_ratio == 0 else math.log(ev.likelihood_ratio)
    return ll


def _unjustified(ev: Evidence) -> Optional[Tuple[str, str]]:
    """(reason, explanation) if the observation must be recorded only."""
    if ev.likelihood_basis is LikelihoodBasis.LLM_VERBAL_CONFIDENCE:
        return ("llm_verbal_confidence_not_a_likelihood",
                "Recorded only: an LLM's stated confidence is not a likelihood ratio and is never converted into one.")
    if ev.likelihood_model is LikelihoodModel.NONE:
        return ("no_likelihood_model",
                "Recorded only: no likelihood model was supplied, so it cannot change the posterior.")
    if ev.likelihood_basis not in JUSTIFIED_BASES:
        return ("unjustified_likelihood_model",
                f"Recorded only: likelihood basis '{ev.likelihood_basis.value}' is not a justified basis.")
    return None


def _choose_representative(eligible: List[Tuple[Evidence, np.ndarray]], group: Optional[ProvenanceGroup],
                           supported: np.ndarray, warn: List[str]) -> Tuple[Tuple[Evidence, np.ndarray], str]:
    ids = [m.evidence_id for m, _ in eligible]
    gid = eligible[0][0].provenance_group
    if group is not None and group.designated_evidence_id is not None:
        if group.designated_evidence_id in ids:
            return eligible[ids.index(group.designated_evidence_id)], "designated by the provenance group"
        warn.append(f"Group '{gid}': designated observation '{group.designated_evidence_id}' is not among its "
                    "eligible observations; another observation was chosen.")
    flagged = [i for i, (m, _) in enumerate(eligible) if m.designated]
    if flagged:
        if len(flagged) > 1:
            warn.append(f"Group '{gid}': several observations are marked designated; '{ids[flagged[0]]}' was used.")
        return eligible[flagged[0]], "designated on the observation"
    spreads = []
    for _, ll in eligible:
        s = ll[supported]
        spreads.append(math.inf if np.isneginf(s).any() else float(s.max() - s.min()))
    i = int(np.argmin(spreads))
    return eligible[i], "least informative observation in the group (none designated)"


def admit_evidence(hypotheses: HypothesisSet, evidence: Sequence[Evidence], *,
                   provenance_groups: Sequence[ProvenanceGroup] = (),
                   already_applied_ids: Sequence[str] = ()) -> AdmissionReport:
    """Screen evidence for duplicates, unjustified likelihoods and shared provenance.

    * An evidence_id listed in ``already_applied_ids``, a repeated evidence_id, or a
      repeated ``content_fingerprint`` is excluded so no observation is applied twice.
    * Observations without a justified likelihood model are recorded only.
    * Within a provenance group, a justified joint likelihood covering the listed
      observations is applied once; otherwise one designated observation per group is
      admitted (DEPENDENCE_POLICY_NOTE) and the rest are reported as excluded.
    """
    if not isinstance(hypotheses, HypothesisSet):
        raise ValidationError("'hypotheses' must be a HypothesisSet.")
    ev_list = list(evidence)
    if len(ev_list) > MAX_ITEMS:
        raise LimitExceededError(f"At most {MAX_ITEMS} observations per call.")
    ids = hypotheses.ids
    supported = hypotheses.prior > 0
    groups: Dict[str, ProvenanceGroup] = {}
    for g in provenance_groups or ():
        if not isinstance(g, ProvenanceGroup):
            raise ValidationError("provenance_groups entries must be ProvenanceGroup objects.")
        if g.group_id in groups:
            raise ValidationError(f"Duplicate provenance group '{g.group_id}'.")
        groups[g.group_id] = g
    previously = set(already_applied_ids or ())
    excluded: List[ExclusionRecord] = []
    recorded: List[ExclusionRecord] = []
    warn: List[str] = []
    seen_ids: set = set()
    seen_fp: Dict[str, str] = {}
    unique: List[Evidence] = []
    for ev in ev_list:
        if not isinstance(ev, Evidence):
            raise ValidationError("evidence entries must be Evidence objects.")
        fp = ev.content_fingerprint
        if ev.evidence_id in previously:
            excluded.append(ExclusionRecord(ev.evidence_id, "already_applied",
                                            "Incorporated in an earlier update; applying it again would double-count it."))
        elif ev.evidence_id in seen_ids:
            excluded.append(ExclusionRecord(ev.evidence_id, "duplicate_evidence_id",
                                            "The same evidence_id was submitted more than once; only the first "
                                            "occurrence is considered."))
        elif fp is not None and fp in seen_fp:
            excluded.append(ExclusionRecord(ev.evidence_id, "duplicate_content",
                                            f"Same content_fingerprint as '{seen_fp[fp]}'; treated as the same observation."))
        else:
            seen_ids.add(ev.evidence_id)
            if fp is not None:
                seen_fp[fp] = ev.evidence_id
            unique.append(ev)
    by_group: Dict[str, List[Evidence]] = {}
    for ev in unique:
        by_group.setdefault(ev.provenance_group, []).append(ev)

    applied: List[Dict[str, Any]] = []
    total = np.zeros(len(ids))
    absolute = True
    for gid, members in by_group.items():
        g = groups.get(gid)
        if g is not None and g.joint_likelihoods is not None:
            present = {m.evidence_id for m in members}
            missing = [e for e in g.joint_evidence_ids if e not in present]
            if g.joint_likelihood_basis not in JUSTIFIED_BASES:
                warn.append(f"Group '{gid}': joint likelihood not applied (basis "
                            f"'{g.joint_likelihood_basis.value}' is not justified).")
            elif missing:
                warn.append(f"Group '{gid}': joint likelihood not applied; it covers observations that were not "
                            f"submitted or were excluded as duplicates: {missing}.")
            else:
                total = total + _mapping_to_loglik(g.joint_likelihoods, ids, f"joint likelihood of group '{gid}'")
                covered = set(g.joint_evidence_ids)
                applied.append({"mode": "joint", "provenance_group": gid, "evidence_ids": list(g.joint_evidence_ids),
                                "likelihood_basis": g.joint_likelihood_basis.value,
                                "selection": "joint likelihood supplied for the group"})
                for m in members:
                    if m.evidence_id in covered:
                        continue
                    why = _unjustified(m)
                    if why:
                        recorded.append(ExclusionRecord(m.evidence_id, *why))
                    else:
                        excluded.append(ExclusionRecord(
                            m.evidence_id, "dependent_not_in_joint_model",
                            f"Shares provenance group '{gid}' but is not covered by its joint likelihood; applying it "
                            "separately would treat dependent evidence as independent."))
                continue
        eligible: List[Tuple[Evidence, np.ndarray]] = []
        for m in members:
            why = _unjustified(m)
            if why:
                recorded.append(ExclusionRecord(m.evidence_id, *why))
            else:
                eligible.append((m, _evidence_loglik(m, ids)))
        if not eligible:
            continue
        if len(eligible) == 1:
            (chosen, ll), how = eligible[0], "only eligible observation in its provenance group"
        else:
            (chosen, ll), how = _choose_representative(eligible, g, supported, warn)
            for m, _ in eligible:
                if m is not chosen:
                    excluded.append(ExclusionRecord(
                        m.evidence_id, "shared_provenance_one_per_group",
                        f"Shares provenance group '{gid}' with applied observation '{chosen.evidence_id}' ({how}). "
                        "Excluded by the simplifying one-per-group dependence policy; supply a joint likelihood "
                        "to use it."))
        total = total + ll
        if chosen.likelihood_model is LikelihoodModel.LIKELIHOOD_RATIO:
            absolute = False
        applied.append({"mode": "single", "provenance_group": gid, "evidence_ids": [chosen.evidence_id],
                        "likelihood_model": chosen.likelihood_model.value,
                        "likelihood_basis": chosen.likelihood_basis.value, "selection": how})
    return AdmissionReport(applied=applied, excluded=excluded, recorded_only=recorded,
                           independent_groups_used=len(applied),
                           policy="one_designated_observation_per_provenance_group",
                           policy_note=DEPENDENCE_POLICY_NOTE, warnings=warn,
                           _log_likelihood=total, _absolute_scale=absolute)


def assess_evidence(hypotheses: HypothesisSet, evidence: Sequence[Evidence], *,
                    provenance_groups: Sequence[ProvenanceGroup] = (),
                    already_applied_ids: Sequence[str] = (),
                    sensitivity_epsilon: Optional[float] = 0.1) -> PosteriorResult:
    """Screen evidence (duplicates, justification, provenance) and update the prior.

    Returns the posterior with the applied, excluded and recorded-only observations,
    prior-sensitivity results and the model assumptions behind the number.
    """
    rep = admit_evidence(hypotheses, evidence, provenance_groups=provenance_groups,
                         already_applied_ids=already_applied_ids)
    return _posterior_result(
        hypotheses.ids, hypotheses.prior, rep._log_likelihood, evidence_ids=rep.applied_evidence_ids,
        applied=rep.applied, excluded=rep.excluded, recorded=rep.recorded_only,
        groups_used=rep.independent_groups_used, assumptions=EVIDENCE_ASSUMPTIONS, warnings_=rep.warnings,
        absolute_scale=rep._absolute_scale, sensitivity_epsilon=sensitivity_epsilon)


# =============================================================================
# 4. Monte Carlo calculations
# =============================================================================

Sampler = Callable[[np.random.Generator, int], Any]

MC_INTERVAL_NOTE = (
    "outcome_interval and quantiles describe the spread of the simulated quantity (uncertainty propagated from "
    "the inputs). mc_standard_error and mean_numerical_interval describe only Monte Carlo error in the estimated "
    "mean; they shrink as draws increase while the outcome spread does not.")
MC_IID_NOTE = "Draws are assumed independent; mc_standard_error = sample sd / sqrt(n_draws)."
MC_ADAPTIVE_NOTE = (
    "Adaptive stopping was used: the precision target was checked after every batch. Repeatedly inspecting a "
    "fixed-sample normal interval and stopping once it is narrow enough does not guarantee nominal coverage, so "
    "the numerical interval is an approximate precision indicator, not a guaranteed confidence interval.")


@dataclass(frozen=True)
class _MCConfig:
    seed: int
    batch_size: int
    max_draws: int
    min_draws: int
    abs_tol: Optional[float]
    rel_tol: Optional[float]
    quantiles: Tuple[float, ...]
    interval_level: float
    precision_z: float

    @property
    def adaptive(self) -> bool:
        return self.abs_tol is not None or self.rel_tol is not None

    def target(self) -> Dict[str, Any]:
        rule = ("stop when precision_z x mc_standard_error <= abs_tol + rel_tol x |mean| (checked after each batch, "
                "once min_draws is reached)" if self.adaptive else "fixed number of draws (max_draws)")
        return {"abs_tol": self.abs_tol, "rel_tol": self.rel_tol, "precision_z": self.precision_z,
                "min_draws": self.min_draws, "max_draws": self.max_draws, "batch_size": self.batch_size,
                "rule": rule}


def _resolve_seed(seed: Any) -> int:
    """Use the caller's seed, or draw a fresh one that is reported for reproducibility."""
    if seed is None:
        return int(np.random.SeedSequence().generate_state(1, dtype=np.uint32)[0])
    return _int(seed, "seed", lo=0, hi=2 ** 63 - 1)


def _mc_config(seed: Optional[int] = None, batch_size: int = 10_000, max_draws: int = 200_000,
               min_draws: int = 1_000, abs_tol: Optional[float] = None, rel_tol: Optional[float] = None,
               quantiles: Sequence[float] = DEFAULT_QUANTILES, interval_level: float = 0.90,
               precision_z: float = 1.96) -> _MCConfig:
    max_d = _int(max_draws, "max_draws", lo=2, hi=MAX_DRAWS_LIMIT, hi_code="limit_exceeded")
    batch = min(_int(batch_size, "batch_size", lo=1, hi=MAX_BATCH, hi_code="limit_exceeded"), max_d)
    min_d = min(_int(min_draws, "min_draws", lo=2), max_d)
    if isinstance(quantiles, (str, bytes)) or not isinstance(quantiles, (list, tuple, np.ndarray)):
        raise ValidationError("'quantiles' must be a list of probabilities.")
    if len(quantiles) > 99:
        raise LimitExceededError("At most 99 quantiles.")
    qs = tuple(_num(q, f"quantiles[{i}]", lo=0.0, hi=1.0) for i, q in enumerate(quantiles))
    return _MCConfig(seed=_resolve_seed(seed), batch_size=batch, max_draws=max_d, min_draws=min_d,
                     abs_tol=_opt_num(abs_tol, "abs_tol", lo=0.0, lo_open=True, hi=MAX_MAGNITUDE),
                     rel_tol=_opt_num(rel_tol, "rel_tol", lo=0.0, lo_open=True, hi=1e6), quantiles=qs,
                     interval_level=_num(interval_level, "interval_level", lo=0.0, hi=1.0, lo_open=True, hi_open=True),
                     precision_z=_num(precision_z, "precision_z", lo=0.0, hi=10.0, lo_open=True))


def _check_outcomes(y: Any, b: int, k: int, binary: bool, what: str = "outcome function") -> np.ndarray:
    """Validate one batch of simulated values: shape (b, k), finite, 0/1 if binary."""
    try:
        arr = np.asarray(y)
    except (TypeError, ValueError):
        raise ValidationError(f"The {what} must return a numeric array.") from None
    if arr.dtype == bool:
        arr = arr.astype(float)
    elif arr.dtype.kind not in "iuf":
        raise ValidationError(f"The {what} must return numeric or boolean values.")
    arr = arr.astype(float, copy=False)
    if k == 1 and arr.shape == (b,):
        arr = arr.reshape(b, 1)
    if arr.shape != (b, k):
        expected = f"({b},)" if k == 1 else f"({b}, {k})"
        raise DimensionError(f"The {what} must be vectorised: expected shape {expected} for a batch of {b} draws; "
                             f"got {arr.shape}.")
    if not np.isfinite(arr).all():
        raise NonFiniteInputError(
            f"The {what} produced non-finite values (for example division by zero or the log of a non-positive "
            "number).", code="non_finite_result",
            details={"non_finite_count": int((~np.isfinite(arr)).sum()), "batch_size": b})
    if float(np.abs(arr).max()) > MAX_MAGNITUDE:
        raise LimitExceededError(
            f"The {what} produced values beyond +/-{MAX_MAGNITUDE:g}, where summary statistics would overflow; "
            "rescale the model (for example change units).", code="numeric_range_exceeded")
    if binary and not np.isin(arr, (0.0, 1.0)).all():
        raise ValidationError("An event function must return booleans (or 0/1 values).")
    return arr


def _merge_moments(n: int, mean: np.ndarray, m2: np.ndarray, y: np.ndarray) -> Tuple[int, np.ndarray, np.ndarray]:
    """Chan et al. parallel update of the running mean and co-moment matrix."""
    nb = y.shape[0]
    mb = y.mean(axis=0)
    d = y - mb
    tot = n + nb
    delta = mb - mean
    return tot, mean + delta * (nb / tot), m2 + d.T @ d + np.outer(delta, delta) * (n * nb / tot)


def _precision_reached(n: int, mean: np.ndarray, m2: np.ndarray, cfg: _MCConfig, binary: bool) -> bool:
    if binary:
        pt = (mean * n + 0.5) / (n + 1.0)   # smoothed, so an estimate of 0 or 1 does not fake zero error
        var = pt * (1.0 - pt)
    else:
        var = np.maximum(np.diag(m2) / (n - 1), 0.0)
    half = cfg.precision_z * np.sqrt(var / n)
    tol = (cfg.abs_tol or 0.0) + (cfg.rel_tol or 0.0) * np.abs(mean)
    return bool(np.all(half <= tol))


def _mc_loop(draw: Callable[[np.random.Generator, int], Any], cfg: _MCConfig, *, n_outputs: int = 1,
             binary: bool = False, what: str = "outcome function") -> Tuple[np.ndarray, int, str]:
    """Draw bounded batches until the precision target or max_draws is reached."""
    rng = np.random.default_rng(cfg.seed)
    chunks: List[np.ndarray] = []
    n, mean, m2 = 0, np.zeros(n_outputs), np.zeros((n_outputs, n_outputs))
    batches, reason = 0, None
    while n < cfg.max_draws:
        b = min(cfg.batch_size, cfg.max_draws - n)
        y = _check_outcomes(draw(rng, b), b, n_outputs, binary, what)
        chunks.append(y)
        n, mean, m2 = _merge_moments(n, mean, m2, y)
        batches += 1
        if cfg.adaptive and n >= cfg.min_draws and _precision_reached(n, mean, m2, cfg, binary):
            reason = "precision_target_met"
            break
    if reason is None:
        reason = "max_draws_reached_before_precision_target" if cfg.adaptive else "fixed_draw_count_completed"
    return np.concatenate(chunks, axis=0), batches, reason


def _summarise(y: np.ndarray, cfg: _MCConfig, reason: str, batches: int, *, binary: bool = False) -> MonteCarloEstimate:
    n = int(y.size)
    mean = float(np.mean(y))
    sd = float(np.std(y, ddof=1)) if n > 1 else 0.0
    se = sd / math.sqrt(n)
    notes = [MC_IID_NOTE]
    if binary:
        k = int(round(float(y.sum())))
        level = float(2.0 * stats.norm.cdf(cfg.precision_z) - 1.0)
        a = 1.0 - level
        lo = 0.0 if k == 0 else float(stats.beta.ppf(a / 2.0, k + 0.5, n - k + 0.5))
        hi = 1.0 if k == n else float(stats.beta.ppf(1.0 - a / 2.0, k + 0.5, n - k + 0.5))
        num_int = [lo, hi]
        method = f"Jeffreys interval for a binomial proportion (level {level:.3f}); Monte Carlo error only"
        quant: Dict[str, float] = {}
        oi, oil = None, None
        notes.insert(0, "Event indicator: the simulated outcome is Bernoulli(p), so outcome quantiles are omitted. "
                        "mean is the estimated event probability under the input model; mean_numerical_interval "
                        "reflects only Monte Carlo error.")
    else:
        half = cfg.precision_z * se
        num_int = [mean - half, mean + half]
        method = (f"mean +/- {cfg.precision_z:g} x mc_standard_error (normal approximation); "
                  "Monte Carlo error only")
        qv = np.quantile(y, cfg.quantiles) if cfg.quantiles else []
        quant = {_qkey(q): float(v) for q, v in zip(cfg.quantiles, qv)}
        tail = (1.0 - cfg.interval_level) / 2.0
        lo, hi = (float(v) for v in np.quantile(y, [tail, 1.0 - tail]))
        oi, oil = [lo, hi], cfg.interval_level
        notes.insert(0, MC_INTERVAL_NOTE)
    if cfg.adaptive:
        notes.append(MC_ADAPTIVE_NOTE)
    return MonteCarloEstimate(mean=mean, std=sd, mc_standard_error=se, n_draws=n, n_batches=batches,
                              stopping_reason=reason, seed=cfg.seed, quantiles=quant, outcome_interval=oi,
                              outcome_interval_level=oil, mean_numerical_interval=num_int,
                              numerical_interval_method=method, precision_target=cfg.target(),
                              adaptive_stopping=cfg.adaptive, notes=notes)


def monte_carlo_expectation(sampler: Sampler, outcome_fn: Optional[Callable[[Any], Any]] = None,
                            **mc_options: Any) -> MonteCarloEstimate:
    """Estimate E[g(X)] where ``sampler(rng, n)`` draws n values of X and ``g`` is vectorised.

    Trusted Python callers only (arbitrary callables). ``mc_options``: seed, batch_size,
    max_draws, min_draws, abs_tol, rel_tol, quantiles, interval_level, precision_z.
    With abs_tol or rel_tol, sampling stops once precision_z x standard error <=
    abs_tol + rel_tol x |mean|; see MC_ADAPTIVE_NOTE (no nominal-coverage guarantee).
    """
    cfg = _mc_config(**mc_options)
    if not callable(sampler) or (outcome_fn is not None and not callable(outcome_fn)):
        raise ValidationError("sampler and outcome_fn must be callables.")

    def draw(rng: np.random.Generator, b: int) -> Any:
        x = sampler(rng, b)
        return x if outcome_fn is None else outcome_fn(x)

    y, batches, reason = _mc_loop(draw, cfg)
    return _summarise(y[:, 0], cfg, reason, batches)


def propagate_uncertainty(input_samplers: Optional[Mapping[str, Sampler]],
                          model_fn: Callable[[Dict[str, np.ndarray]], Any], *,
                          joint_sampler: Optional[Callable[[np.random.Generator, int], Mapping[str, Any]]] = None,
                          **mc_options: Any) -> MonteCarloEstimate:
    """Propagate input uncertainty through a vectorised model ``y = model_fn(inputs)``.

    ``input_samplers`` maps names to independent samplers, drawn in the given order from
    one seeded Generator. For dependent inputs pass ``joint_sampler(rng, n) -> {name:
    array}`` instead. ``extra`` reports input summaries and Spearman rank correlations
    with the output (a descriptive indicator of which inputs drive the spread, not a
    variance decomposition).
    """
    cfg = _mc_config(**mc_options)
    if (input_samplers is None) == (joint_sampler is None):
        raise ValidationError("Supply exactly one of input_samplers or joint_sampler.")
    if not callable(model_fn):
        raise ValidationError("model_fn must be callable.")
    names: List[str] = []
    if input_samplers is not None:
        if not isinstance(input_samplers, Mapping) or not input_samplers:
            raise ValidationError("input_samplers must be a non-empty mapping name -> sampler.")
        if len(input_samplers) > MAX_INPUTS:
            raise LimitExceededError(f"At most {MAX_INPUTS} inputs.")
        names = [_str(k, "input name", max_len=64) for k in input_samplers]
    kept: Dict[str, List[np.ndarray]] = {}
    kept_n = [0]
    first_keys: List[Optional[Tuple[str, ...]]] = [None]

    def draw(rng: np.random.Generator, b: int) -> Any:
        if joint_sampler is not None:
            raw = joint_sampler(rng, b)
            if not isinstance(raw, Mapping) or not raw:
                raise ValidationError("joint_sampler must return a non-empty mapping name -> array.")
            keys = tuple(str(k) for k in raw)
            if first_keys[0] is None:
                first_keys[0] = keys
            elif keys != first_keys[0]:
                raise ValidationError("joint_sampler must return the same input names for every batch.")
            xs = {str(k): _check_outcomes(v, b, 1, False, f"joint_sampler output '{k}'")[:, 0] for k, v in raw.items()}
        else:
            xs = {nm: _check_outcomes(input_samplers[nm](rng, b), b, 1, False, f"sampler for input '{nm}'")[:, 0]
                  for nm in names}
        if kept_n[0] < SUMMARY_STORE_LIMIT:
            for nm, v in xs.items():
                kept.setdefault(nm, []).append(v)
            kept_n[0] += b
        return model_fn(xs)

    y, batches, reason = _mc_loop(draw, cfg, what="model function")
    est = _summarise(y[:, 0], cfg, reason, batches)
    m = kept_n[0]
    y_kept = y[:m, 0]
    summaries: Dict[str, Any] = {}
    corr: Dict[str, Optional[float]] = {}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for nm, chunks in kept.items():
            x = np.concatenate(chunks)[:m]
            qv = np.quantile(x, (0.05, 0.5, 0.95))
            summaries[nm] = {"mean": float(x.mean()), "std": float(x.std(ddof=1)) if x.size > 1 else 0.0,
                             "q0.05": float(qv[0]), "q0.5": float(qv[1]), "q0.95": float(qv[2])}
            corr[nm] = (float(stats.spearmanr(x, y_kept)[0])
                        if np.ptp(x) > 0 and np.ptp(y_kept) > 0 else None)
    est.extra = {"inputs": summaries, "spearman_rank_correlation_with_output": corr, "summary_draws_used": m,
                 "input_dependence": ("joint sampler supplied by caller" if joint_sampler is not None
                                      else "inputs sampled independently")}
    est.notes.append("Inputs were sampled independently unless a joint sampler was supplied; ignoring real "
                     "dependence between inputs can understate or overstate the output spread.")
    return est


def probability_of_event(sampler: Sampler, event_fn: Callable[[Any], Any], **mc_options: Any) -> MonteCarloEstimate:
    """Estimate P(event) where ``event_fn`` maps a batch of draws to booleans.

    ``mean`` is the estimated probability and ``mean_numerical_interval`` a Jeffreys
    interval for its Monte Carlo error. Adaptive stopping uses a smoothed variance so an
    estimate of 0 or 1 does not report zero error.
    """
    cfg = _mc_config(**mc_options)
    if not callable(sampler) or not callable(event_fn):
        raise ValidationError("sampler and event_fn must be callables.")
    y, batches, reason = _mc_loop(lambda rng, b: event_fn(sampler(rng, b)), cfg, binary=True,
                                  what="event function")
    est = _summarise(y[:, 0], cfg, reason, batches, binary=True)
    est.extra = {"event_count": int(round(float(y.sum())))}
    return est


def compare_alternatives(sampler: Sampler, alternatives: Mapping[str, Callable[[Any], Any]], *,
                         higher_is_better: bool = True, **mc_options: Any) -> Dict[str, Any]:
    """Compare alternatives on the same simulated scenarios (common random numbers).

    Returns per-alternative Monte Carlo estimates, the best alternative by expected
    outcome, paired differences from it with Monte Carlo standard errors, and the
    fraction of scenarios in which each alternative is best (a scenario-level frequency,
    not the probability that its expected outcome is highest). Adaptive precision
    targets apply to every alternative's mean.
    """
    cfg = _mc_config(**mc_options)
    if not isinstance(alternatives, Mapping) or not 2 <= len(alternatives) <= MAX_ALTERNATIVES:
        raise ValidationError(f"Supply between 2 and {MAX_ALTERNATIVES} alternatives.")
    names = [_str(k, "alternative name", max_len=64) for k in alternatives]
    fns = [alternatives[k] for k in alternatives]
    hib = _bool(higher_is_better, "higher_is_better")

    def draw(rng: np.random.Generator, b: int) -> np.ndarray:
        x = sampler(rng, b)
        return np.column_stack([_check_outcomes(fn(x), b, 1, False, f"alternative '{nm}'")[:, 0]
                                for nm, fn in zip(names, fns)])

    y, batches, reason = _mc_loop(draw, cfg, n_outputs=len(names), what="alternatives")
    per = {nm: _summarise(y[:, i], cfg, reason, batches) for i, nm in enumerate(names)}
    signed = y if hib else -y
    best = int(np.argmax(signed.mean(axis=0)))
    diffs: Dict[str, Any] = {}
    for j, nm in enumerate(names):
        if j == best:
            continue
        d = signed[:, best] - signed[:, j]
        se = float(d.std(ddof=1) / math.sqrt(d.size))
        md = float(d.mean())
        half = cfg.precision_z * se
        diffs[nm] = {"mean_advantage_of_best": md, "mc_standard_error": se,
                     "approx_numerical_interval": [md - half, md + half],
                     "resolved_at_this_precision": bool(md - half > 0)}
    top = signed.max(axis=1, keepdims=True)
    is_top = signed == top
    share = (is_top / is_top.sum(axis=1, keepdims=True)).mean(axis=0)
    notes = [
        "All alternatives were evaluated on the same draws (common random numbers), so paired differences have lower "
        "Monte Carlo error than separate runs.",
        "scenario_win_frequency is the fraction of simulated scenarios in which each alternative is best; it is not "
        "the probability that its expected outcome is highest.",
        "resolved_at_this_precision uses an approximate normal interval for Monte Carlo error only; it says nothing "
        "about model error.",
    ]
    if cfg.adaptive:
        notes.append(MC_ADAPTIVE_NOTE)
    return {"alternatives": per, "orientation": "higher_is_better" if hib else "lower_is_better",
            "best_by_expected_outcome": names[best],
            "expected_outcomes": dict(zip(names, y.mean(axis=0).tolist())),
            "differences_from_best": diffs, "scenario_win_frequency": dict(zip(names, share.tolist())),
            "n_draws": int(y.shape[0]), "n_batches": batches, "stopping_reason": reason, "seed": cfg.seed,
            "notes": notes}


# =============================================================================
# 5. Choosing the next research action
# =============================================================================

def _multinomial_logp(counts: np.ndarray, lik: np.ndarray, n_repeats: int) -> np.ndarray:
    """log multinomial pmf of each count vector (rows of ``counts``) under each hypothesis' row of ``lik``."""
    coef = special.gammaln(n_repeats + 1.0) - special.gammaln(counts + 1.0).sum(axis=1)
    return np.stack([coef + special.xlogy(counts, lik[h]).sum(axis=1) for h in range(lik.shape[0])])


def _config_logp(lik: np.ndarray, n_repeats: int, max_enumeration: int) -> Optional[np.ndarray]:
    """log P(configuration | h), shape (n_h, n_configs), or None if enumeration is too large.

    With n_repeats conditionally independent repeats, configurations are outcome-count
    vectors (a sufficient statistic), enumerated exactly.
    """
    n_h, n_o = lik.shape
    if n_repeats == 1:
        return _log(lik)
    count = math.comb(n_o + n_repeats - 1, n_repeats)
    if count > max_enumeration or count * n_h > MAX_EIG_WORK:
        return None
    counts = np.array([np.bincount(c, minlength=n_o)
                       for c in itertools.combinations_with_replacement(range(n_o), n_repeats)], dtype=float)
    return _multinomial_logp(counts, lik, n_repeats)


def _sample_config_logp(prior: np.ndarray, lik: np.ndarray, n_repeats: int, n: int,
                        rng: np.random.Generator) -> np.ndarray:
    """Draw (h, outcome counts) from the joint model; return log P(counts | h') for every h'."""
    n_h, n_o = lik.shape
    hs = rng.choice(n_h, size=n, p=prior)
    counts = np.zeros((n, n_o))
    for h in range(n_h):
        idx = np.flatnonzero(hs == h)
        if idx.size:
            counts[idx] = rng.multinomial(n_repeats, lik[h], size=idx.size)
    return _multinomial_logp(counts, lik, n_repeats)


def _preposterior(prior: np.ndarray, logp: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (log P(config), posterior for each config with P > 0, mask of those configs)."""
    log_joint = _log(prior)[:, None] + logp
    with warnings.catch_warnings(), np.errstate(all="ignore"):
        warnings.simplefilter("ignore", RuntimeWarning)
        log_pc = special.logsumexp(log_joint, axis=0)
    keep = np.isfinite(log_pc)
    post = np.exp(log_joint[:, keep] - log_pc[keep])
    return log_pc, post, keep


def _action_inputs(prior: Any, observation_likelihoods: Any, hypothesis_ids: Optional[Sequence[str]],
                   outcomes: Optional[Sequence[str]], n_repeats: Any, method: Any,
                   max_enumeration: Any) -> Tuple[np.ndarray, np.ndarray, List[str], List[str], int, str, int]:
    if isinstance(prior, PosteriorResult):
        hypothesis_ids = hypothesis_ids or prior.hypothesis_ids
        prior = prior.posterior
    p = _simplex(prior, "prior")
    lik = _observation_matrix(observation_likelihoods, p.size)
    ids = _ids(hypothesis_ids, p.size, "hypothesis_ids")
    outs = _ids(outcomes, lik.shape[1], "outcomes", prefix="outcome_")
    k = _int(n_repeats, "n_repeats", lo=1, hi=1_000, hi_code="limit_exceeded")
    m = _str(method, "method")
    if m not in ("auto", "exact", "monte_carlo"):
        raise ValidationError("'method' must be 'auto', 'exact' or 'monte_carlo'.")
    max_enum = _int(max_enumeration, "max_enumeration", lo=1, hi=MAX_ENUMERATION_LIMIT, hi_code="limit_exceeded")
    return p, lik, ids, outs, k, m, max_enum


def _mc_sample_count(n_samples: Any, lik: np.ndarray) -> int:
    n = _int(n_samples, "n_samples", lo=100, hi=1_000_000, hi_code="limit_exceeded")
    if n * max(lik.shape) > MAX_EIG_SAMPLE_WORK:
        raise LimitExceededError("n_samples x max(n_hypotheses, n_outcomes) exceeds the Monte Carlo work limit.")
    return n


def expected_information_gain(prior: Any, observation_likelihoods: Any, *, n_repeats: int = 1,
                              method: str = "auto", max_enumeration: int = 50_000, n_samples: int = 20_000,
                              seed: Optional[int] = None, hypothesis_ids: Optional[Sequence[str]] = None,
                              outcomes: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    """Expected reduction in hypothesis entropy (bits) from observing an action's outcome.

    EIG = H(prior) - sum_o P(o) H(posterior | o), the mutual information between the
    hypothesis and the outcome. ``observation_likelihoods`` is P(o | h) with shape
    (n_hypotheses, n_outcomes). ``n_repeats`` conditionally independent repeats are
    handled through outcome counts. ``method``: "exact" (enumeration), "monte_carlo",
    or "auto" (exact when the number of outcome configurations is at most
    ``max_enumeration``).
    """
    p, lik, ids, outs, k, m, max_enum = _action_inputs(prior, observation_likelihoods, hypothesis_ids, outcomes,
                                                       n_repeats, method, max_enumeration)
    h0 = float(_entropy_bits(p))
    logp = None if m == "monte_carlo" else _config_logp(lik, k, max_enum)
    if m == "exact" and logp is None:
        raise LimitExceededError(f"Exact enumeration needs {math.comb(lik.shape[1] + k - 1, k)} outcome configurations, "
                                 "above the enumeration limit; use method='monte_carlo'.")
    res: Dict[str, Any] = {"units": "bits", "prior_entropy_bits": h0, "n_repeats": k}
    if logp is not None:
        log_pc, post, keep = _preposterior(p, logp)
        pc = np.exp(log_pc[keep])
        pc = pc / pc.sum()
        eh = float(pc @ _entropy_bits(post, axis=0))
        res.update(method="exact", expected_information_gain_bits=min(max(h0 - eh, 0.0), h0),
                   expected_posterior_entropy_bits=eh, n_outcome_configurations=int(logp.shape[1]),
                   mc_standard_error=None)
        if k == 1:
            full = np.zeros(lik.shape[1])
            full[keep] = pc
            res["outcome_probabilities"] = dict(zip(outs, full.tolist()))
            res["posterior_by_outcome"] = {outs[j]: dict(zip(ids, post[:, c].tolist()))
                                           for c, j in enumerate(np.flatnonzero(keep))}
    else:
        n = _mc_sample_count(n_samples, lik)
        s = _resolve_seed(seed)
        _, post_s, _ = _preposterior(p, _sample_config_logp(p, lik, k, n, np.random.default_rng(s)))
        hs = _entropy_bits(post_s, axis=0)
        eh = float(hs.mean())
        res.update(method="monte_carlo", expected_information_gain_bits=h0 - eh, expected_posterior_entropy_bits=eh,
                   mc_standard_error=float(hs.std(ddof=1) / math.sqrt(n)), n_samples=n, seed=s,
                   note="Monte Carlo over (hypothesis, outcome) draws with the exact posterior entropy of each draw; "
                        "the estimate can fall slightly outside [0, H(prior)] by sampling error.")
    return res


def expected_value_of_information(prior: Any, observation_likelihoods: Any, utility: Any, *,
                                  decision_ids: Optional[Sequence[str]] = None,
                                  hypothesis_ids: Optional[Sequence[str]] = None,
                                  outcomes: Optional[Sequence[str]] = None,
                                  cost_in_utility_units: Optional[float] = None, n_repeats: int = 1,
                                  method: str = "auto", max_enumeration: int = 50_000, n_samples: int = 20_000,
                                  seed: Optional[int] = None) -> Dict[str, Any]:
    """Expected value of sample information (EVSI) for a decision problem.

    EVSI = expected optimal utility after observing the outcome minus the optimal
    expected utility now: E_o[max_d sum_h P(h | o) U(d, h)] - max_d sum_h P(h) U(d, h).
    ``utility`` has shape (n_decisions, n_hypotheses) in caller-defined utility units.
    The action's cost is subtracted (net value) only when ``cost_in_utility_units`` is
    given, i.e. when the caller has a justified conversion into those units. Also
    reports EVPI, the upper bound on the value of any information.
    """
    p, lik, ids, outs, k, m, max_enum = _action_inputs(prior, observation_likelihoods, hypothesis_ids, outcomes,
                                                       n_repeats, method, max_enumeration)
    u = _arr(utility, "utility", ndim=2)
    if u.shape[1] != p.size:
        raise DimensionError(f"'utility' must have shape (n_decisions, {p.size}); got {u.shape}.")
    if u.shape[0] > MAX_DECISIONS:
        raise LimitExceededError(f"At most {MAX_DECISIONS} decisions.")
    if float(np.abs(u).max()) > MAX_MAGNITUDE:
        raise LimitExceededError(f"Utilities must lie within +/-{MAX_MAGNITUDE:g}.", code="numeric_range_exceeded")
    dids = _ids(decision_ids, u.shape[0], "decision_ids", prefix="decision_")
    cost = _opt_num(cost_in_utility_units, "cost_in_utility_units", lo=0.0, hi=MAX_MAGNITUDE)
    eu = u @ p
    d0 = int(np.argmax(eu))
    v0 = float(eu[d0])
    evpi = max(float(p @ u.max(axis=0)) - v0, 0.0)
    logp = None if m == "monte_carlo" else _config_logp(lik, k, max_enum)
    if m == "exact" and logp is None:
        raise LimitExceededError("Exact enumeration exceeds the limit; use method='monte_carlo'.")
    res: Dict[str, Any] = {"units": "caller-defined utility units", "prior_expected_utility": dict(zip(dids, eu.tolist())),
                           "prior_optimal_decision": dids[d0], "evpi": evpi, "n_repeats": k}
    if logp is not None:
        log_pc, post, keep = _preposterior(p, logp)
        pc = np.exp(log_pc[keep])
        pc = pc / pc.sum()
        eu_post = u @ post
        gain = eu_post.max(axis=0) - eu_post[d0]      # >= 0 for every configuration
        evsi = float(pc @ gain)
        res.update(method="exact", evsi=evsi, mc_standard_error=None)
        if k == 1:
            res["decision_rule"] = {outs[j]: dids[int(np.argmax(eu_post[:, c]))]
                                    for c, j in enumerate(np.flatnonzero(keep))}
    else:
        n = _mc_sample_count(n_samples, lik)
        s = _resolve_seed(seed)
        _, post_s, _ = _preposterior(p, _sample_config_logp(p, lik, k, n, np.random.default_rng(s)))
        eu_post = u @ post_s
        gain = eu_post.max(axis=0) - eu_post[d0]
        evsi = float(gain.mean())
        res.update(method="monte_carlo", evsi=evsi, mc_standard_error=float(gain.std(ddof=1) / math.sqrt(n)),
                   n_samples=n, seed=s)
    res.update(expected_utility_with_information=v0 + evsi, cost_in_utility_units=cost,
               net_value_of_information=None if cost is None else evsi - cost,
               note=("Net value = EVSI - cost, with the cost supplied in utility units." if cost is not None else
                     "No cost in utility units was supplied, so no net value is computed; compare resource costs "
                     "separately."))
    return res


def record_usefulness_outcome(belief: UsefulnessBelief, useful: bool, *, outcome_source: str) -> UsefulnessBelief:
    """Return the belief updated with one actual, independently labelled binary outcome."""
    if not isinstance(belief, UsefulnessBelief):
        raise ValidationError("'belief' must be a UsefulnessBelief.")
    _check_outcome_source(outcome_source)
    u = _bool(useful, "useful")
    return UsefulnessBelief(belief.arm_id, belief.alpha + (1.0 if u else 0.0), belief.beta + (0.0 if u else 1.0),
                            belief.n_successes + int(u), belief.n_failures + int(not u))


def thompson_select(beliefs: Sequence[UsefulnessBelief], *, eligible_arm_ids: Optional[Sequence[str]] = None,
                    seed: Optional[int] = None, n_probability_draws: int = 10_000) -> Dict[str, Any]:
    """Thompson sampling: draw theta_a ~ Beta(alpha_a, beta_a) for each eligible arm, pick the largest.

    The Beta parameters must come only from actual recorded binary outcomes (see
    :func:`record_usefulness_outcome`). Also estimates each arm's probability of having
    the highest usefulness. Thompson sampling balances exploration and exploitation over
    repeated searches; it is not an information-gain calculation for the current question.
    """
    bl = list(beliefs)
    if not bl or not all(isinstance(b, UsefulnessBelief) for b in bl):
        raise ValidationError("'beliefs' must be a non-empty list of UsefulnessBelief objects.")
    if len({b.arm_id for b in bl}) != len(bl):
        raise ValidationError("Arm ids must be unique.")
    if eligible_arm_ids is not None:
        allowed = set(eligible_arm_ids)
        bl = [b for b in bl if b.arm_id in allowed]
        if not bl:
            raise ValidationError("No eligible arms.")
    n = _int(n_probability_draws, "n_probability_draws", lo=100, hi=1_000_000, hi_code="limit_exceeded")
    s = _resolve_seed(seed)
    rng = np.random.default_rng(s)
    a = np.array([b.alpha for b in bl])
    bb = np.array([b.beta for b in bl])
    theta = rng.beta(a, bb)
    sel = int(np.argmax(theta))
    wins = np.bincount(np.argmax(rng.beta(a, bb, size=(n, len(bl))), axis=1), minlength=len(bl)) / n
    ids = [b.arm_id for b in bl]
    return {"selected_arm_id": ids[sel], "sampled_usefulness": dict(zip(ids, theta.tolist())),
            "posterior_mean_usefulness": dict(zip(ids, (a / (a + bb)).tolist())),
            "probability_best_estimate": dict(zip(ids, wins.tolist())),
            "probability_best_mc_standard_error": dict(zip(ids, np.sqrt(wins * (1 - wins) / n).tolist())),
            "observed_outcomes": {b.arm_id: {"successes": b.n_successes, "failures": b.n_failures} for b in bl},
            "seed": s,
            "notes": ["Beta parameters must reflect only actual, independently labelled binary outcomes.",
                      "The selection is randomised by design (exploration); probability_best_estimate is a Monte "
                      "Carlo estimate under the current Beta beliefs."]}


def _belief_vector(belief: Any, hypotheses: HypothesisSet) -> np.ndarray:
    if belief is None:
        return hypotheses.prior
    if isinstance(belief, PosteriorResult):
        if sorted(belief.hypothesis_ids) != sorted(hypotheses.ids):
            raise DimensionError("The posterior's hypothesis ids do not match the hypothesis set.")
        m = belief.posterior_dict()
        return _simplex([m[h] for h in hypotheses.ids], "belief")
    return _simplex(belief, "belief", len(hypotheses.ids))


def _heuristic_weights(w: Optional[Mapping[str, float]]) -> Dict[str, float]:
    if not w:
        return {}
    allowed = [r for r, *_ in RESOURCES]
    out = {}
    for k, v in w.items():
        if k not in allowed:
            raise ValidationError(f"heuristic_weights keys must be among {allowed}.")
        out[k] = _num(v, f"heuristic_weights['{k}']", lo=0.0, hi=1e6)
    return out


def _heuristic_score(eig: float, cost: ResourceCost, weights: Mapping[str, float]) -> Optional[float]:
    total = eig
    for r, wt in weights.items():
        c = getattr(cost, r)
        if c is None:
            return None
        total -= wt * c
    return total


def rank_research_actions(hypotheses: HypothesisSet, actions: Sequence[ResearchAction], *, belief: Any = None,
                          budget: Optional[ResourceBudget] = None, utility: Any = None,
                          decision_ids: Optional[Sequence[str]] = None,
                          heuristic_weights: Optional[Mapping[str, float]] = None, eig_method: str = "auto",
                          n_samples: int = 20_000, seed: Optional[int] = None, require_upper_bounds: bool = False,
                          estimate_safety_factor: float = 1.0, allow_unknown_costs: bool = False) -> ActionRanking:
    """Evaluate and rank candidate actions under the current belief.

    Criterion: net value of information when a utility model is given and every
    modelled action has a cost in utility units; EVSI (costs reported separately, not
    subtracted) when a utility model is given otherwise; expected information gain in
    bits (resource costs reported separately) without a utility model. If
    ``heuristic_weights`` (bits per unit of a resource) are supplied without a utility
    model, ranking uses the explicitly labelled heuristic EIG - sum(weight x cost).
    """
    if not isinstance(hypotheses, HypothesisSet):
        raise ValidationError("'hypotheses' must be a HypothesisSet.")
    acts = list(actions)
    if len(acts) > MAX_ITEMS or not all(isinstance(a, ResearchAction) for a in acts):
        raise ValidationError("'actions' must be a list of ResearchAction objects.")
    if len({a.action_id for a in acts}) != len(acts):
        raise ValidationError("Action ids must be unique.")
    p = _belief_vector(belief, hypotheses)
    u = None
    if utility is not None:
        u = _arr(utility, "utility", ndim=2)
        if u.shape[1] != len(hypotheses.ids):
            raise DimensionError(f"'utility' must have shape (n_decisions, {len(hypotheses.ids)}).")
    dids = _ids(decision_ids, u.shape[0], "decision_ids", prefix="decision_") if u is not None else None
    weights = _heuristic_weights(heuristic_weights)
    root = _resolve_seed(seed)
    child_seeds = [int(c.generate_state(1)[0]) for c in np.random.SeedSequence(root).spawn(len(acts))]
    report = (filter_affordable_actions(acts, budget, require_upper_bounds=require_upper_bounds,
                                        estimate_safety_factor=estimate_safety_factor,
                                        allow_unknown_costs=allow_unknown_costs) if budget is not None else None)
    evals: List[ActionEvaluation] = []
    for i, a in enumerate(acts):
        ok, issue = a.observation_model_status()
        if report is not None:
            info = report["per_action"][a.action_id]
            affordable, reasons, compliance = info["affordable"], list(info["reasons"]), info["compliance"]
        else:
            affordable, reasons, compliance = True, [], "no_budget_supplied"
        ev = ActionEvaluation(action_id=a.action_id, kind=a.kind, description=a.description,
                              has_observation_model=ok, observation_model_issue=issue, affordable=affordable,
                              affordability_reasons=reasons, budget_compliance=compliance,
                              cost={r: getattr(a.cost, r) for r, *_ in RESOURCES}, cost_kind=a.cost.kind,
                              cost_in_utility_units=a.cost_in_utility_units)
        if ok:
            lik = a.likelihood_matrix(hypotheses)
            g = expected_information_gain(p, lik, method=eig_method, n_samples=n_samples, seed=child_seeds[i],
                                          hypothesis_ids=hypotheses.ids, outcomes=list(a.outcomes))
            ev.expected_information_gain_bits = g["expected_information_gain_bits"]
            ev.eig_method = g["method"]
            ev.eig_mc_standard_error = g.get("mc_standard_error")
            ev.predictive_outcome_probabilities = g.get("outcome_probabilities")
            if u is not None:
                v = expected_value_of_information(p, lik, u, decision_ids=dids, hypothesis_ids=hypotheses.ids,
                                                  outcomes=list(a.outcomes),
                                                  cost_in_utility_units=a.cost_in_utility_units, method=eig_method,
                                                  n_samples=n_samples, seed=child_seeds[i])
                ev.evsi = v["evsi"]
                ev.evsi_mc_standard_error = v.get("mc_standard_error")
                ev.net_value_of_information = v["net_value_of_information"]
                ev.decision_rule = v.get("decision_rule")
            if weights:
                ev.heuristic_score = _heuristic_score(ev.expected_information_gain_bits, a.cost, weights)
        else:
            ev.notes.append(f"Not valued: {issue}. Supply an observation model P(outcome | hypothesis) with a "
                            "justified basis.")
        evals.append(ev)
    modelled = [e for e in evals if e.has_observation_model]
    if u is not None:
        if modelled and all(e.net_value_of_information is not None for e in modelled):
            crit, heur = "net_value_of_information", False
            desc = "EVSI minus cost, both in the caller's utility units (decision-theoretic)."
        else:
            crit, heur = "evsi", False
            desc = ("Expected value of sample information in utility units. Costs are not in utility units, so they "
                    "are reported separately and not subtracted.")
    elif weights:
        crit, heur = "heuristic_score", True
        desc = ("HEURISTIC: expected information gain (bits) minus caller-chosen exchange rates (bits per resource "
                "unit) x cost. Not a decision-theoretic quantity.")
    else:
        crit, heur = "expected_information_gain_bits", False
        desc = ("Expected reduction in hypothesis entropy (bits). Resource costs are reported separately and not "
                "combined with it.")

    def key(e: ActionEvaluation) -> Tuple[Any, ...]:
        v = getattr(e, crit)
        money = e.cost.get("money")
        return (0 if e.affordable else 1, 0 if e.has_observation_model else 1,
                -(v if v is not None else -math.inf), money if money is not None else math.inf, e.action_id)

    evals.sort(key=key)
    rank = 0
    for e in evals:
        if e.affordable and e.has_observation_model:
            rank += 1
            e.rank = rank
    notes = ["Observation models are taken as conditional on the evidence already applied; an action that re-reads "
             "evidence already used needs a correspondingly flat model.",
             "Information gain is in bits; money, tokens, calls and seconds stay in their own units unless a utility "
             "model with costs in utility units is supplied."]
    unmodelled = [e.action_id for e in evals if not e.has_observation_model]
    if unmodelled:
        notes.append(f"Actions without a usable observation model were not valued: {unmodelled}.")
    return ActionRanking(evaluations=evals, criterion=crit, criterion_is_heuristic=heur, criterion_description=desc,
                         belief=dict(zip(hypotheses.ids, p.tolist())), seed=root, budget_report=report, notes=notes)


# =============================================================================
# 6. Budget and stopping logic
# =============================================================================

def filter_affordable_actions(actions: Sequence[ResearchAction], budget: ResourceBudget, *,
                              require_upper_bounds: bool = False, estimate_safety_factor: float = 1.0,
                              allow_unknown_costs: bool = False) -> Dict[str, Any]:
    """Split actions into affordable and unaffordable, checking each resource separately.

    Upper-bound costs are compared directly; estimated costs are first multiplied by
    ``estimate_safety_factor`` (or rejected if ``require_upper_bounds``). A cost left
    unknown for a limited resource excludes the action unless ``allow_unknown_costs``.
    Passing the filter with estimated or unknown costs does not guarantee budget
    compliance; with upper bounds it does only if the bounds themselves are correct.
    """
    if not isinstance(budget, ResourceBudget):
        raise ValidationError("'budget' must be a ResourceBudget.")
    acts = list(actions)
    if not all(isinstance(a, ResearchAction) for a in acts):
        raise ValidationError("'actions' must be ResearchAction objects.")
    if len({a.action_id for a in acts}) != len(acts):
        raise ValidationError("Action ids must be unique.")
    sf = _num(estimate_safety_factor, "estimate_safety_factor", lo=1.0, hi=100.0)
    req = _bool(require_upper_bounds, "require_upper_bounds")
    allow = _bool(allow_unknown_costs, "allow_unknown_costs")
    remaining = budget.remaining()
    per: Dict[str, Any] = {}
    ok_ids: List[str] = []
    bad: List[str] = []
    for a in acts:
        bound = a.cost.kind == "upper_bound"
        reasons: List[str] = []
        notes: List[str] = []
        checked: Dict[str, float] = {}
        unknown = False
        if req and not bound:
            reasons.append("cost_is_estimate_but_upper_bound_required")
        for res, _lim, _spent, _units in RESOURCES:
            rem = remaining[res]
            if rem is None:
                continue
            cost = getattr(a.cost, res)
            if cost is None:
                if allow:
                    unknown = True
                    notes.append(f"{res} cost unknown (allowed by caller)")
                else:
                    reasons.append(f"{res}_cost_unknown_for_limited_resource")
                continue
            eff = cost if bound else cost * sf
            checked[res] = eff
            if eff > rem + 1e-12 * max(1.0, abs(rem)):
                reasons.append(f"{res}_exceeds_remaining")
        affordable = not reasons
        if not affordable:
            compliance = "not_affordable"
        elif all(v is None for v in remaining.values()):
            compliance = "no_limits_set"
        elif bound and not unknown:
            compliance = "within_limits_if_supplied_upper_bounds_are_correct"
        else:
            compliance = "estimated_only_not_guaranteed"
        per[a.action_id] = {"affordable": affordable, "reasons": reasons, "cost_kind": a.cost.kind,
                            "cost_checked": checked, "compliance": compliance, "notes": notes}
        (ok_ids if affordable else bad).append(a.action_id)
    return {"affordable": ok_ids, "unaffordable": [{"action_id": i, "reasons": per[i]["reasons"]} for i in bad],
            "per_action": per, "remaining": remaining, "exhausted_resources": budget.exhausted(),
            "estimate_safety_factor": sf, "require_upper_bounds": req, "allow_unknown_costs": allow,
            "units": {res: units for res, _l, _s, units in RESOURCES},
            "notes": ["Each resource is checked separately against its own remaining limit.",
                      "Estimated costs are multiplied by estimate_safety_factor before checking; passing the filter "
                      "does not guarantee the action will stay within budget.",
                      "Upper-bound costs guarantee compliance only if the supplied bounds are correct."]}


_VOI_CRITERIA = ("net_value_of_information", "evsi")


def _clears_threshold(e: ActionEvaluation, criterion: str, c: StopCriteria) -> bool:
    if criterion in _VOI_CRITERIA:
        v = getattr(e, criterion)
        return v is not None and v > c.voi_threshold
    v = e.expected_information_gain_bits
    return v is not None and v >= c.eig_threshold_bits


def should_stop(posterior: PosteriorResult, ranking: ActionRanking, budget: Optional[ResourceBudget] = None,
                criteria: Optional[StopCriteria] = None) -> StopAssessment:
    """Decide whether to stop researching, with explicit reasons.

    Stop reasons: budget exhausted, no affordable action, missing observation models,
    expected information gain below threshold, no positive (net) value of information,
    and, only if ``criteria.stop_on_posterior_threshold``, a posterior threshold met
    within the model. Separately, the evidence is flagged "more evidence required" when
    the leading posterior is below the threshold, the conclusion is not robust to the
    prior, or too few independent provenance groups contributed. A strong posterior is
    never reported as proof that the evidence is comprehensive or the model correct.
    """
    if not isinstance(posterior, PosteriorResult) or not isinstance(ranking, ActionRanking):
        raise ValidationError("should_stop needs a PosteriorResult and an ActionRanking.")
    c = criteria or StopCriteria()
    stop: List[StopReason] = []
    evals = ranking.evaluations
    exhausted = budget.exhausted() if budget is not None else []
    if exhausted:
        stop.append(StopReason.BUDGET_EXHAUSTED)
    affordable = [e for e in evals if e.affordable]
    if not affordable:
        stop.append(StopReason.NO_AFFORDABLE_ACTION)
    modelled = [e for e in affordable if e.has_observation_model]
    if affordable and not modelled:
        stop.append(StopReason.MISSING_OBSERVATION_MODEL)
    best_eig = max((e.expected_information_gain_bits for e in modelled), default=None)
    best_value = None
    if modelled:
        if ranking.criterion in _VOI_CRITERIA:
            best_value = max(getattr(e, ranking.criterion) for e in modelled)
            if best_value <= c.voi_threshold:
                stop.append(StopReason.NO_POSITIVE_NET_VOI)
        elif best_eig < c.eig_threshold_bits:
            stop.append(StopReason.EIG_BELOW_THRESHOLD)
    sens = posterior.prior_sensitivity
    robust = None if sens is None else bool(sens.get("conclusion_robust_to_prior"))
    insufficient: List[str] = []
    if posterior.max_posterior < c.posterior_threshold:
        insufficient.append(f"Leading hypothesis '{posterior.map_hypothesis}' has posterior "
                            f"{posterior.max_posterior:.4f}, below the threshold {c.posterior_threshold:g}.")
    if c.require_prior_robust and robust is not True:
        insufficient.append("The leading hypothesis is not robust to the prior-sensitivity checks." if robust is False
                            else "Prior sensitivity was not computed, so robustness to the prior is unknown.")
    if posterior.independent_groups_used < c.min_independent_groups:
        insufficient.append(f"Only {posterior.independent_groups_used} independent provenance group(s) contributed "
                            f"(minimum {c.min_independent_groups}).")
    status = "insufficient" if insufficient else "posterior_threshold_met_within_model"
    if not insufficient and c.stop_on_posterior_threshold:
        stop.append(StopReason.POSTERIOR_THRESHOLD_MET)
    should = bool(stop)
    reasons = [r.value for r in stop] + ([StopReason.MORE_EVIDENCE_REQUIRED.value] if insufficient else [])
    leader = posterior.map_hypothesis
    if should and insufficient:
        outcome = "stop_report_insufficient_evidence"
        guidance = ("Stop researching and say the evidence is insufficient to settle the question: give the posterior "
                    "with its prior-sensitivity range, the stopping reasons, and the excluded or unmodelled evidence.")
    elif should:
        outcome = "stop_report_within_model_conclusion"
        guidance = (f"Stop researching. Report '{leader}' as the conclusion within the stated model, with its "
                    "posterior, the prior-sensitivity range and the assumptions; do not describe the evidence as "
                    "comprehensive or the model as verified.")
    elif insufficient:
        outcome = "continue_research"
        guidance = "Continue: run the recommended action, then update the posterior with its actual outcome."
    else:
        outcome = "continue_research_optional"
        guidance = ("The posterior threshold is met within the model, but an affordable action still clears the value "
                    "threshold. Continue (for example, seek contradictory evidence) unless a deadline requires an "
                    "answer now.")
    missing = [e.action_id for e in evals if not e.has_observation_model]
    caveats = ["A high posterior is conditional on the hypothesis set, the likelihood models and the dependence policy; "
               "it does not show that the evidence is comprehensive or that those models are correct.",
               "Budget checks on estimated costs are not guarantees of compliance."]
    if posterior.recorded_only:
        caveats.append(f"{len(posterior.recorded_only)} observation(s) had no justified likelihood model and did not "
                       f"affect the posterior: {[r.evidence_id for r in posterior.recorded_only]}.")
    if posterior.excluded:
        caveats.append(f"{len(posterior.excluded)} submission(s) were excluded as duplicates or dependent: "
                       f"{[r.evidence_id for r in posterior.excluded]}.")
    if missing:
        caveats.append(f"Actions without a usable observation model could not be valued: {missing}.")
    details = {"leading_hypothesis": leader, "max_posterior": posterior.max_posterior,
               "posterior_threshold": c.posterior_threshold,
               "independent_groups_used": posterior.independent_groups_used,
               "min_independent_groups": c.min_independent_groups, "conclusion_robust_to_prior": robust,
               "criterion": ranking.criterion, "criterion_is_heuristic": ranking.criterion_is_heuristic,
               "best_affordable_eig_bits": best_eig, "eig_threshold_bits": c.eig_threshold_bits,
               "best_affordable_value": best_value, "voi_threshold": c.voi_threshold,
               "exhausted_resources": exhausted, "affordable_actions": [e.action_id for e in affordable],
               "actions_missing_observation_model": missing}
    return StopAssessment(should_stop=should, outcome=outcome, reasons=reasons, stop_reasons=[r.value for r in stop],
                          evidence_status=status, insufficiency=insufficient, answer_guidance=guidance,
                          details=details, prior_sensitivity=sens, model_assumptions=list(posterior.assumptions),
                          caveats=caveats)


def recommend_next_action(hypotheses: HypothesisSet, posterior: PosteriorResult, actions: Sequence[ResearchAction],
                          budget: Optional[ResourceBudget] = None, *, utility: Any = None,
                          decision_ids: Optional[Sequence[str]] = None,
                          heuristic_weights: Optional[Mapping[str, float]] = None, policy: str = "auto",
                          usefulness_beliefs: Optional[Sequence[UsefulnessBelief]] = None,
                          criteria: Optional[StopCriteria] = None, seed: Optional[int] = None,
                          eig_method: str = "auto", n_samples: int = 20_000, require_upper_bounds: bool = False,
                          estimate_safety_factor: float = 1.0, allow_unknown_costs: bool = False) -> ActionRecommendation:
    """Rank affordable actions, assess stopping, and recommend the next action (or none).

    ``policy="auto"`` takes the top-ranked action that clears the value threshold.
    ``policy="thompson"`` applies Thompson sampling over ``usefulness_beliefs`` (linked
    through ``ResearchAction.usefulness_arm``) among those same candidates.
    """
    if not isinstance(posterior, PosteriorResult):
        raise ValidationError("'posterior' must be a PosteriorResult (use assess_evidence or an update function).")
    pol = _str(policy, "policy")
    if pol not in ("auto", "thompson"):
        raise ValidationError("'policy' must be 'auto' or 'thompson'.")
    c = criteria or StopCriteria()
    ranking = rank_research_actions(hypotheses, actions, belief=posterior, budget=budget, utility=utility,
                                    decision_ids=decision_ids, heuristic_weights=heuristic_weights,
                                    eig_method=eig_method, n_samples=n_samples, seed=seed,
                                    require_upper_bounds=require_upper_bounds,
                                    estimate_safety_factor=estimate_safety_factor,
                                    allow_unknown_costs=allow_unknown_costs)
    stop = should_stop(posterior, ranking, budget, c)
    rec: Optional[str] = None
    thompson = None
    notes = ["The recommendation is only as good as the observation models and costs supplied."]
    if not stop.should_stop:
        candidates = [e for e in ranking.evaluations
                      if e.affordable and e.has_observation_model and _clears_threshold(e, ranking.criterion, c)]
        if pol == "thompson":
            arm_of = {a.action_id: a.usefulness_arm for a in actions}
            beliefs = {b.arm_id: b for b in (usefulness_beliefs or ())}
            eligible = [e for e in candidates if arm_of.get(e.action_id) in beliefs]
            if eligible:
                arms = list(dict.fromkeys(arm_of[e.action_id] for e in eligible))
                thompson = thompson_select([beliefs[a] for a in arms], seed=ranking.seed)
                rec = next(e.action_id for e in eligible if arm_of[e.action_id] == thompson["selected_arm_id"])
            else:
                notes.append("Thompson policy requested, but no candidate action has a usefulness belief; the ranking "
                             "criterion was used instead.")
        if rec is None and candidates:
            rec = candidates[0].action_id
    else:
        notes.append("No action is recommended because the stopping assessment says to stop.")
    return ActionRecommendation(recommended_action_id=rec, policy=pol, selection_criterion=ranking.criterion,
                                criterion_is_heuristic=ranking.criterion_is_heuristic, stop_assessment=stop,
                                ranking=ranking, posterior_summary=posterior.summary(), thompson=thompson, notes=notes)


# =============================================================================
# 7. LLM tool interface (allowlisted JSON dispatcher)
# =============================================================================

# --- 7a. Named distributions (the only samplers reachable from JSON) ---------

def _p_real(v: Any, p: str) -> float:
    return _num(v, p, lo=-MAX_MAGNITUDE, hi=MAX_MAGNITUDE)


def _p_pos(v: Any, p: str) -> float:
    return _num(v, p, lo=0.0, lo_open=True, hi=MAX_MAGNITUDE)


def _p_rate(v: Any, p: str) -> float:
    return _num(v, p, lo=0.0, hi=1e12)


def _p_prob(v: Any, p: str) -> float:
    return _num(v, p, lo=0.0, hi=1.0)


def _p_count(v: Any, p: str) -> int:
    return _int(v, p, lo=0, hi=10 ** 9)


def _p_reals(v: Any, p: str) -> List[float]:
    if not isinstance(v, list) or not 1 <= len(v) <= 10_000:
        raise ValidationError(f"'{p}' must be an array of 1 to 10000 numbers.")
    return [_p_real(x, f"{p}[{i}]") for i, x in enumerate(v)]


def _ordered(path: str, low: float, mode: float, high: float) -> None:
    if not (low <= mode <= high and low < high):
        raise ValidationError(f"'{path}' needs low <= mode <= high and low < high.")


def _d_constant(path: str, value: float) -> Sampler:
    return lambda rng, n: np.full(n, value)


def _d_normal(path: str, mean: float, sd: float) -> Sampler:
    return lambda rng, n: rng.normal(mean, sd, n)


def _d_lognormal(path: str, mu: float, sigma: float) -> Sampler:
    return lambda rng, n: rng.lognormal(mu, sigma, n)


def _d_uniform(path: str, low: float, high: float) -> Sampler:
    if not low < high:
        raise ValidationError(f"'{path}' needs low < high.")
    return lambda rng, n: rng.uniform(low, high, n)


def _d_triangular(path: str, low: float, mode: float, high: float) -> Sampler:
    _ordered(path, low, mode, high)
    return lambda rng, n: rng.triangular(low, mode, high, n)


def _d_pert(path: str, low: float, mode: float, high: float) -> Sampler:
    _ordered(path, low, mode, high)
    a = 1.0 + 4.0 * (mode - low) / (high - low)
    b = 1.0 + 4.0 * (high - mode) / (high - low)
    return lambda rng, n: low + (high - low) * rng.beta(a, b, n)


def _d_beta(path: str, alpha: float, beta: float) -> Sampler:
    return lambda rng, n: rng.beta(alpha, beta, n)


def _d_gamma(path: str, shape: float, scale: float) -> Sampler:
    return lambda rng, n: rng.gamma(shape, scale, n)


def _d_exponential(path: str, scale: float) -> Sampler:
    return lambda rng, n: rng.exponential(scale, n)


def _d_student_t(path: str, df: float, loc: float, scale: float) -> Sampler:
    return lambda rng, n: loc + scale * rng.standard_t(df, n)


def _d_truncated_normal(path: str, mean: float, sd: float, low: float, high: float) -> Sampler:
    if not low < high:
        raise ValidationError(f"'{path}' needs low < high.")
    dist = stats.truncnorm((low - mean) / sd, (high - mean) / sd, loc=mean, scale=sd)
    return lambda rng, n: dist.rvs(size=n, random_state=rng)


def _d_bernoulli(path: str, p: float) -> Sampler:
    return lambda rng, n: (rng.random(n) < p).astype(float)


def _d_binomial(path: str, trials: int, p: float) -> Sampler:
    return lambda rng, n: rng.binomial(trials, p, n).astype(float)


def _d_poisson(path: str, rate: float) -> Sampler:
    return lambda rng, n: rng.poisson(rate, n).astype(float)


def _d_discrete(path: str, values: List[float], probabilities: List[float]) -> Sampler:
    vals = np.array(values, dtype=float)
    probs = _simplex(probabilities, f"{path}.probabilities", vals.size)
    return lambda rng, n: rng.choice(vals, size=n, p=probs)


_DISTRIBUTIONS: Dict[str, Tuple[Tuple[Tuple[str, Callable[[Any, str], Any]], ...], Callable[..., Sampler]]] = {
    "constant": ((("value", _p_real),), _d_constant),
    "normal": ((("mean", _p_real), ("sd", _p_pos)), _d_normal),
    "lognormal": ((("mu", _p_real), ("sigma", _p_pos)), _d_lognormal),
    "uniform": ((("low", _p_real), ("high", _p_real)), _d_uniform),
    "triangular": ((("low", _p_real), ("mode", _p_real), ("high", _p_real)), _d_triangular),
    "pert": ((("low", _p_real), ("mode", _p_real), ("high", _p_real)), _d_pert),
    "beta": ((("alpha", _p_pos), ("beta", _p_pos)), _d_beta),
    "gamma": ((("shape", _p_pos), ("scale", _p_pos)), _d_gamma),
    "exponential": ((("scale", _p_pos),), _d_exponential),
    "student_t": ((("df", _p_pos), ("loc", _p_real), ("scale", _p_pos)), _d_student_t),
    "truncated_normal": ((("mean", _p_real), ("sd", _p_pos), ("low", _p_real), ("high", _p_real)),
                         _d_truncated_normal),
    "bernoulli": ((("p", _p_prob),), _d_bernoulli),
    "binomial": ((("trials", _p_count), ("p", _p_prob)), _d_binomial),
    "poisson": ((("rate", _p_rate),), _d_poisson),
    "discrete": ((("values", _p_reals), ("probabilities", _p_reals)), _d_discrete),
}

DISTRIBUTION_DOC = (
    "Named distribution object {'distribution': name, ...parameters}. Allowed: constant(value); normal(mean, sd>0); "
    "lognormal(mu, sigma>0) [parameters of log X]; uniform(low<high); triangular(low<=mode<=high); "
    "pert(low<=mode<=high) [beta-PERT]; beta(alpha>0, beta>0); gamma(shape>0, scale>0); exponential(scale>0); "
    "student_t(df>0, loc, scale>0); truncated_normal(mean, sd>0, low<high); bernoulli(p in [0,1]); "
    "binomial(trials integer>=0, p); poisson(rate in [0, 1e12]); discrete(values[], probabilities[] summing to 1). "
    f"Real parameters must lie within +/-{MAX_MAGNITUDE:g}. Values are in the units of the quantity being modelled.")


def _dist_conv(v: Any, path: str) -> Sampler:
    if not isinstance(v, dict):
        raise ValidationError(f"'{path}' must be a distribution object.")
    kind = v.get("distribution")
    if not isinstance(kind, str) or kind not in _DISTRIBUTIONS:
        raise ValidationError(f"'{path}.distribution' must be one of {sorted(_DISTRIBUTIONS)}.",
                              details={"allowed": sorted(_DISTRIBUTIONS)})
    params, build = _DISTRIBUTIONS[kind]
    names = [k for k, _ in params]
    unknown = sorted(set(v) - {"distribution"} - set(names))
    if unknown:
        raise ValidationError(f"Unknown parameter(s) {unknown} for distribution '{kind}' in '{path}'.",
                              details={"allowed": names})
    kw = {}
    for k, conv in params:
        if v.get(k) is None:
            raise ValidationError(f"Missing parameter '{path}.{k}' for distribution '{kind}'.")
        kw[k] = conv(v[k], f"{path}.{k}")
    sampler = build(path, **kw)

    def guarded(rng: np.random.Generator, n: int) -> Any:
        with np.errstate(all="ignore"):
            try:
                return sampler(rng, n)
            except (ValueError, OverflowError) as exc:
                raise ValidationError(f"'{path}': parameters are outside the range the '{kind}' sampler supports "
                                      f"({type(exc).__name__}).") from None

    return guarded


# --- 7b. Expression trees (the only calculations reachable from JSON) --------

def _reduce(op: Callable[[Any, Any], Any]) -> Callable[..., Any]:
    return lambda *a: functools.reduce(op, a)


_ARITH_OPS: Dict[str, Tuple[int, Optional[int], Callable[..., Any]]] = {
    "add": (2, None, _reduce(np.add)), "mul": (2, None, _reduce(np.multiply)),
    "sub": (2, 2, np.subtract), "div": (2, 2, np.divide), "pow": (2, 2, np.power),
    "neg": (1, 1, np.negative), "exp": (1, 1, np.exp), "log": (1, 1, np.log), "log1p": (1, 1, np.log1p),
    "sqrt": (1, 1, np.sqrt), "abs": (1, 1, np.abs), "logistic": (1, 1, special.expit),
    "min": (2, None, _reduce(np.minimum)), "max": (2, None, _reduce(np.maximum)),
    "clip": (3, 3, lambda x, lo, hi: np.minimum(np.maximum(x, lo), hi)),
    "gt": (2, 2, np.greater), "ge": (2, 2, np.greater_equal), "lt": (2, 2, np.less), "le": (2, 2, np.less_equal),
}
_LOGIC_OPS: Dict[str, Tuple[int, Optional[int], Callable[..., Any]]] = {
    "and": (2, None, _reduce(np.logical_and)), "or": (2, None, _reduce(np.logical_or)),
    "not": (1, 1, np.logical_not),
}

EXPRESSION_DOC = (
    "Expression tree evaluated element-wise over the simulated draws; no code is executed. A node is a number, "
    "{'const': number}, {'var': input_name} or {'op': name, 'args': [node, ...]}. Ops: add, mul, min, max, and, or "
    "(2 or more args); sub, div, pow, gt, ge, lt, le (2); neg, exp, log, log1p, sqrt, abs, logistic, not (1); "
    "clip(x, lo, hi) and where(condition, a, b) (3). Comparisons return booleans. Non-finite results (for example "
    f"division by zero) are rejected. At most {MAX_EXPR_NODES} nodes and depth {MAX_EXPR_DEPTH}.")


def _compile_expr(node: Any, variables: set, path: str) -> Callable[[Mapping[str, np.ndarray], int], np.ndarray]:
    """Validate an expression tree up front and return a vectorised evaluator."""
    counter = [0]

    def as_float(a: Any) -> np.ndarray:
        return np.asarray(a, dtype=float)

    def comp(nd: Any, depth: int, p: str) -> Callable[[Mapping[str, np.ndarray]], Any]:
        counter[0] += 1
        if counter[0] > MAX_EXPR_NODES:
            raise LimitExceededError(f"Expression '{path}' has more than {MAX_EXPR_NODES} nodes.")
        if depth > MAX_EXPR_DEPTH:
            raise LimitExceededError(f"Expression '{path}' is nested deeper than {MAX_EXPR_DEPTH}.")
        if isinstance(nd, bool):
            raise ValidationError(f"'{p}': booleans are not valid expression literals.")
        if isinstance(nd, (int, float)):
            v = _num(nd, p)
            return lambda env: v
        if not isinstance(nd, dict):
            raise ValidationError(f"'{p}' must be a number, {{'const'}}, {{'var'}} or {{'op', 'args'}} node.")
        if "const" in nd:
            if set(nd) != {"const"}:
                raise ValidationError(f"'{p}': a const node has only the key 'const'.")
            v = _num(nd["const"], f"{p}.const")
            return lambda env: v
        if "var" in nd:
            if set(nd) != {"var"}:
                raise ValidationError(f"'{p}': a var node has only the key 'var'.")
            name = _str(nd["var"], f"{p}.var", max_len=64)
            if name not in variables:
                raise ValidationError(f"'{p}': unknown variable '{name}'.", details={"variables": sorted(variables)})
            return lambda env: env[name]
        if "op" in nd:
            if not set(nd) <= {"op", "args"}:
                raise ValidationError(f"'{p}': an op node has only the keys 'op' and 'args'.")
            op = nd["op"]
            allowed = sorted(set(_ARITH_OPS) | set(_LOGIC_OPS) | {"where"})
            if not isinstance(op, str) or op not in allowed:
                raise ValidationError(f"'{p}.op' must be one of {allowed}.", details={"allowed": allowed})
            args = nd.get("args", [])
            if not isinstance(args, list):
                raise ValidationError(f"'{p}.args' must be an array.")
            lo, hi, fn = (3, 3, None) if op == "where" else (_ARITH_OPS.get(op) or _LOGIC_OPS[op])
            if len(args) < lo or (hi is not None and len(args) > hi):
                arity = f"{lo}" if lo == hi else f"at least {lo}"
                raise ValidationError(f"'{p}': op '{op}' takes {arity} argument(s); got {len(args)}.")
            subs = [comp(a, depth + 1, f"{p}.args[{i}]") for i, a in enumerate(args)]
            if op == "where":
                return lambda env: np.where(np.asarray(subs[0](env), dtype=bool), as_float(subs[1](env)),
                                            as_float(subs[2](env)))
            if op in _LOGIC_OPS:
                return lambda env: fn(*[np.asarray(s(env), dtype=bool) for s in subs])
            return lambda env: fn(*[as_float(s(env)) for s in subs])
        raise ValidationError(f"'{p}' must contain 'const', 'var' or 'op'.")

    root = comp(node, 0, path)

    def evaluate(env: Mapping[str, np.ndarray], n: int) -> np.ndarray:
        with np.errstate(all="ignore"):
            try:
                out = np.asarray(root(env))
            except (ValueError, TypeError, FloatingPointError, OverflowError) as exc:
                raise ValidationError(f"Expression '{path}' could not be evaluated ({type(exc).__name__}).") from None
        if out.ndim == 0:
            out = np.full(n, out.item(), dtype=out.dtype)
        return out

    return evaluate


# --- 7c. Argument specifications: validation and JSON Schema from one source --

@dataclass(frozen=True)
class _Arg:
    required: bool
    conv: Callable[[Any, str], Any]
    schema: Dict[str, Any]


def _sn(desc: str, **bounds: Any) -> Dict[str, Any]:
    return {"type": "number", "description": desc, **bounds}


def _sa(items: Dict[str, Any], desc: str, **kw: Any) -> Dict[str, Any]:
    return {"type": "array", "description": desc, "items": items, **kw}


def _sm(values: Dict[str, Any], desc: str) -> Dict[str, Any]:
    return {"type": "object", "description": desc, "additionalProperties": values}


def _obj_schema(spec: Mapping[str, _Arg], desc: str) -> Dict[str, Any]:
    return {"type": "object", "description": desc, "properties": {k: a.schema for k, a in spec.items()},
            "required": [k for k, a in spec.items() if a.required], "additionalProperties": False}


def _fields(d: Any, path: str, spec: Mapping[str, _Arg]) -> Dict[str, Any]:
    """Validate a JSON object against a spec: unknown keys rejected, required keys enforced."""
    if not isinstance(d, dict):
        raise ValidationError(f"'{path}' must be a JSON object.")
    unknown = sorted(set(d) - set(spec))
    if unknown:
        raise ValidationError(f"Unknown field(s) in '{path}': {unknown}.", details={"allowed": sorted(spec)})
    out: Dict[str, Any] = {}
    for key, arg in spec.items():
        v = d.get(key)
        if v is None:
            if arg.required:
                raise ValidationError(f"Missing required field '{path}.{key}'.", details={"field": f"{path}.{key}"})
            continue
        out[key] = arg.conv(v, f"{path}.{key}")
    return out


def _bounds_conv(bounds: Mapping[str, Any]) -> Dict[str, Any]:
    return {"lo": bounds.get("minimum", bounds.get("exclusiveMinimum")),
            "hi": bounds.get("maximum", bounds.get("exclusiveMaximum")),
            "lo_open": "exclusiveMinimum" in bounds, "hi_open": "exclusiveMaximum" in bounds}


def _arg_num(desc: str, required: bool = False, **bounds: Any) -> _Arg:
    b = _bounds_conv(bounds)
    return _Arg(required, lambda v, p: _num(v, p, **b), _sn(desc, **bounds))


def _arg_int(desc: str, required: bool = False, minimum: Optional[int] = None, maximum: Optional[int] = None) -> _Arg:
    bounds = {k: v for k, v in (("minimum", minimum), ("maximum", maximum)) if v is not None}
    return _Arg(required, lambda v, p: _int(v, p, lo=minimum, hi=maximum, hi_code="limit_exceeded"),
                {"type": "integer", "description": desc, **bounds})


def _arg_str(desc: str, required: bool = False, enum: Optional[Sequence[str]] = None,
             allow_empty: bool = False) -> _Arg:
    def conv(v: Any, p: str) -> str:
        s = _str(v, p, allow_empty=allow_empty)
        if enum is not None and s not in enum:
            raise ValidationError(f"'{p}' must be one of {list(enum)}; got {s[:80]!r}.", details={"allowed": list(enum)})
        return s
    schema: Dict[str, Any] = {"type": "string", "description": desc}
    if enum is not None:
        schema["enum"] = list(enum)
    return _Arg(required, conv, schema)


def _arg_bool(desc: str, required: bool = False) -> _Arg:
    return _Arg(required, _bool, {"type": "boolean", "description": desc})


def _list_conv(item_conv: Callable[[Any, str], Any], min_items: int = 0,
               max_items: int = MAX_ITEMS) -> Callable[[Any, str], List[Any]]:
    def conv(v: Any, p: str) -> List[Any]:
        if not isinstance(v, list):
            raise ValidationError(f"'{p}' must be a JSON array.")
        if len(v) > max_items:
            raise LimitExceededError(f"'{p}' has more than {max_items} entries.")
        if len(v) < min_items:
            raise ValidationError(f"'{p}' needs at least {min_items} entries.")
        return [item_conv(x, f"{p}[{i}]") for i, x in enumerate(v)]
    return conv


def _arg_numlist(desc: str, required: bool = False, min_items: int = 1, max_items: int = MAX_ITEMS,
                 **item_bounds: Any) -> _Arg:
    b = _bounds_conv(item_bounds)
    return _Arg(required, _list_conv(lambda v, p: _num(v, p, **b), min_items, max_items),
                _sa(_sn("Number.", **item_bounds), desc, minItems=min_items, maxItems=max_items))


def _arg_strlist(desc: str, required: bool = False, max_items: int = MAX_ITEMS) -> _Arg:
    return _Arg(required, _list_conv(lambda v, p: _str(v, p, max_len=200), 0, max_items),
                _sa({"type": "string"}, desc, maxItems=max_items))


def _matrix_conv(v: Any, p: str) -> List[List[float]]:
    rows = _list_conv(_list_conv(lambda x, q: _num(x, q), 1, MAX_ITEMS), 1, MAX_ITEMS)(v, p)
    if len({len(r) for r in rows}) != 1:
        raise DimensionError(f"'{p}' must be a rectangular array of arrays.")
    return rows


def _arg_matrix(desc: str, required: bool = False) -> _Arg:
    return _Arg(required, _matrix_conv, _sa(_sa(_sn("Number."), "Row."), desc, minItems=1))


def _numdict_conv(v: Any, p: str) -> Dict[str, float]:
    if not isinstance(v, dict) or not v:
        raise ValidationError(f"'{p}' must be a non-empty JSON object.")
    if len(v) > MAX_HYPOTHESES:
        raise LimitExceededError(f"'{p}' has too many entries.")
    return {k: _num(x, f"{p}.{k}", lo=0.0) for k, x in v.items()}


def _rowdict_conv(v: Any, p: str) -> Dict[str, List[float]]:
    if not isinstance(v, dict) or not v:
        raise ValidationError(f"'{p}' must be a non-empty JSON object.")
    if len(v) > MAX_HYPOTHESES:
        raise LimitExceededError(f"'{p}' has too many entries.")
    row = _list_conv(lambda x, q: _num(x, q, lo=0.0), 1, MAX_OUTCOMES)
    return {k: row(r, f"{p}.{k}") for k, r in v.items()}


def _arg_obj(spec: Mapping[str, _Arg], desc: str, build: Callable[..., Any], required: bool = False) -> _Arg:
    return _Arg(required, lambda v, p: build(**_fields(v, p, spec)), _obj_schema(spec, desc))


def _arg_objlist(spec: Mapping[str, _Arg], desc: str, build: Callable[..., Any], required: bool = False,
                 min_items: int = 0, max_items: int = MAX_ITEMS) -> _Arg:
    conv = _list_conv(lambda v, p: build(**_fields(v, p, spec)), min_items, max_items)
    return _Arg(required, conv, _sa(_obj_schema(spec, "Item."), desc, minItems=min_items, maxItems=max_items))


def _passthrough(v: Any, p: str) -> Any:
    return v


def _inputs_conv(v: Any, p: str) -> Dict[str, Sampler]:
    if not isinstance(v, dict) or not v:
        raise ValidationError(f"'{p}' must be a non-empty object input_name -> distribution.")
    if len(v) > MAX_INPUTS:
        raise LimitExceededError(f"At most {MAX_INPUTS} inputs.")
    return {_str(k, f"{p} key", max_len=64): _dist_conv(spec, f"{p}.{k}") for k, spec in v.items()}


def _expr_map_conv(v: Any, p: str) -> Dict[str, Any]:
    if not isinstance(v, dict) or not 2 <= len(v) <= MAX_ALTERNATIVES:
        raise ValidationError(f"'{p}' must be an object with 2 to {MAX_ALTERNATIVES} named expressions.")
    return {_str(k, f"{p} key", max_len=64): e for k, e in v.items()}


def _named_vectors_conv(v: Any, p: str) -> Dict[str, List[float]]:
    if not isinstance(v, dict) or len(v) > 50:
        raise ValidationError(f"'{p}' must be an object name -> probability vector (at most 50).")
    vec = _list_conv(lambda x, q: _num(x, q, lo=0.0, hi=1.0), 2, MAX_HYPOTHESES)
    return {_str(k, f"{p} key", max_len=64): vec(q, f"{p}.{k}") for k, q in v.items()}


_BASIS_DOC = ("Basis of a likelihood or observation model. Only " + ", ".join(sorted(b.value for b in JUSTIFIED_BASES))
              + " can change the posterior; 'llm_verbal_confidence' and 'unspecified' are recorded only.")
_BASIS_ENUM = [b.value for b in LikelihoodBasis]
_S_EXPR = {"description": EXPRESSION_DOC, "anyOf": [{"type": "number"}, {"type": "object"}]}
_S_DIST = {"type": "object", "description": DISTRIBUTION_DOC, "additionalProperties": True,
           "properties": {"distribution": {"type": "string", "enum": sorted(_DISTRIBUTIONS)}},
           "required": ["distribution"]}

_HYPOTHESIS_SPEC = {
    "id": _arg_str("Unique hypothesis id.", True),
    "prior": _arg_num("Prior probability; priors over all hypotheses sum to 1.", True, minimum=0, maximum=1),
    "description": _arg_str("Description.", allow_empty=True),
    "prior_basis": _arg_str("How the prior was set (base rate, policy, uniform).", allow_empty=True),
}
_ARG_HYPOTHESES = _Arg(
    True,
    lambda v, p: HypothesisSet(tuple(_list_conv(lambda x, q: Hypothesis(**_fields(x, q, _HYPOTHESIS_SPEC)),
                                                2, MAX_HYPOTHESES)(v, p))),
    _sa(_obj_schema(_HYPOTHESIS_SPEC, "Hypothesis."),
        "Mutually exclusive, jointly exhaustive hypotheses with explicit priors.", minItems=2, maxItems=MAX_HYPOTHESES))
_ARG_LIKELIHOOD_MAP = _Arg(False, _numdict_conv, _sm(
    _sn("P(evidence | h).", minimum=0),
    "Object hypothesis_id -> P(evidence | h), for every hypothesis; values <= 1 unless is_density."))

_EVIDENCE_SPEC = {
    "evidence_id": _arg_str("Unique observation id; a repeated id is excluded as a duplicate.", True),
    "source": _arg_str("Where the observation came from.", True),
    "provenance_group": _arg_str("Shared-origin group (same press release, dataset or model call). Without a joint "
                                 "likelihood only one observation per group is applied.", True),
    "likelihood_model": _arg_str("'categorical' (P(e|h) for every hypothesis in 'likelihoods'), 'likelihood_ratio' "
                                 "(two hypotheses; 'likelihood_ratio' and 'ratio_numerator') or 'none' (recorded "
                                 "only).", True, enum=[m.value for m in LikelihoodModel]),
    "likelihood_basis": _arg_str(_BASIS_DOC, enum=_BASIS_ENUM),
    "likelihood_justification": _arg_str("How the likelihoods were obtained.", allow_empty=True),
    "likelihoods": _ARG_LIKELIHOOD_MAP,
    "likelihood_ratio": _arg_num("P(e | ratio_numerator) / P(e | other hypothesis).", minimum=0),
    "ratio_numerator": _arg_str("Hypothesis id in the likelihood ratio's numerator."),
    "is_density": _arg_bool("True if the likelihoods are densities of a continuous observation."),
    "designated": _arg_bool("Mark as the representative observation of its provenance group."),
    "content_fingerprint": _arg_str("Optional content hash; a repeated fingerprint is excluded as a duplicate."),
    "description": _arg_str("Description.", allow_empty=True),
    "relevance_score": _arg_num("HEURISTIC retrieval relevance score; recorded, never used in inference."),
    "llm_annotation": _arg_str("LLM note; recorded, never used in inference.", allow_empty=True),
    "llm_stated_confidence": _arg_num("LLM-stated confidence; recorded, never converted into a likelihood.",
                                      minimum=0, maximum=1),
}
_GROUP_SPEC = {
    "group_id": _arg_str("Provenance group id (matches Evidence.provenance_group).", True),
    "description": _arg_str("Description.", allow_empty=True),
    "designated_evidence_id": _arg_str("Observation applied under the one-per-group policy."),
    "joint_evidence_ids": _arg_strlist("Observations covered by the joint likelihood."),
    "joint_likelihoods": _Arg(False, _numdict_conv, _sm(_sn("P(e_1, ..., e_k | h).", minimum=0),
                                                        "Object hypothesis_id -> joint likelihood of the covered "
                                                        "observations.")),
    "joint_likelihood_basis": _arg_str(_BASIS_DOC, enum=_BASIS_ENUM),
    "joint_justification": _arg_str("How the joint likelihood was obtained.", allow_empty=True),
    "is_density": _arg_bool("True if the joint likelihoods are densities."),
}
_COST_SPEC = {
    "money": _arg_num("Monetary cost in currency units (e.g. USD).", minimum=0, maximum=MAX_RESOURCE),
    "tokens": _arg_num("Token cost.", minimum=0, maximum=MAX_RESOURCE),
    "calls": _arg_num("Number of model or tool calls.", minimum=0, maximum=MAX_RESOURCE),
    "seconds": _arg_num("Wall-clock time in seconds.", minimum=0, maximum=MAX_RESOURCE),
    "kind": _arg_str("'upper_bound' (guaranteed maximum) or 'estimate' (uncertain).", enum=["upper_bound", "estimate"]),
}
_ACTION_SPEC = {
    "action_id": _arg_str("Unique action id.", True),
    "description": _arg_str("Description.", allow_empty=True),
    "kind": _arg_str("Action type, e.g. " + ", ".join(KNOWN_ACTION_KINDS) + "."),
    "outcomes": _arg_strlist("Exhaustive list of possible observations from the action.", max_items=MAX_OUTCOMES),
    "observation_model": _Arg(False, _rowdict_conv, _sm(
        _sa(_sn("P(outcome | h).", minimum=0, maximum=1), "Row."),
        "Object hypothesis_id -> [P(outcome | h) for each outcome]; each row sums to 1. Must be conditional on the "
        "evidence already applied.")),
    "observation_model_basis": _arg_str(_BASIS_DOC, enum=_BASIS_ENUM),
    "observation_model_justification": _arg_str("How the observation model was obtained.", allow_empty=True),
    "cost": _arg_obj(_COST_SPEC, "Resource cost of the action; omitted fields are unknown.", ResourceCost),
    "cost_in_utility_units": _arg_num("Cost in the utility matrix's units; supply only with a justified conversion.",
                                      minimum=0, maximum=MAX_MAGNITUDE),
    "usefulness_arm": _arg_str("Arm id of the UsefulnessBelief used by the Thompson policy."),
    "llm_annotation": _arg_str("LLM note; recorded, never used.", allow_empty=True),
}
_BUDGET_SPEC = {
    "money_limit": _arg_num("Money limit in currency units; omit for no limit.", minimum=0, maximum=MAX_RESOURCE),
    "token_limit": _arg_num("Token limit; omit for no limit.", minimum=0, maximum=MAX_RESOURCE),
    "call_limit": _arg_num("Call limit; omit for no limit.", minimum=0, maximum=MAX_RESOURCE),
    "time_limit_seconds": _arg_num("Elapsed-time limit in seconds; omit for no limit.", minimum=0,
                                   maximum=MAX_RESOURCE),
    "money_spent": _arg_num("Money already spent.", minimum=0, maximum=MAX_RESOURCE),
    "tokens_spent": _arg_num("Tokens already used.", minimum=0, maximum=MAX_RESOURCE),
    "calls_spent": _arg_num("Calls already made.", minimum=0, maximum=MAX_RESOURCE),
    "seconds_elapsed": _arg_num("Seconds already elapsed.", minimum=0, maximum=MAX_RESOURCE),
}
_ARM_SPEC = {
    "arm_id": _arg_str("Arm id (an action type or source collection).", True),
    "alpha": _arg_num("Beta alpha: prior alpha plus recorded actual successes.", exclusiveMinimum=0,
                      maximum=MAX_BETA_PARAM),
    "beta": _arg_num("Beta beta: prior beta plus recorded actual failures.", exclusiveMinimum=0,
                     maximum=MAX_BETA_PARAM),
    "n_successes": _arg_int("Recorded actual successes (audit).", minimum=0),
    "n_failures": _arg_int("Recorded actual failures (audit).", minimum=0),
}
_CRITERIA_SPEC = {
    "eig_threshold_bits": _arg_num("Stop when the best affordable EIG is below this (bits). Default 0.02.", minimum=0),
    "voi_threshold": _arg_num("Stop when the best affordable (net) value of information is <= this. Default 0."),
    "posterior_threshold": _arg_num("Posterior needed for 'threshold met within model'. Default 0.95.",
                                    minimum=0, maximum=1),
    "min_independent_groups": _arg_int("Independent provenance groups required. Default 2.", minimum=0,
                                       maximum=MAX_ITEMS),
    "require_prior_robust": _arg_bool("Require robustness to the prior checks. Default true."),
    "stop_on_posterior_threshold": _arg_bool("Allow stopping once the threshold is met within the model. "
                                             "Default false."),
}

_ARG_EVIDENCE = _arg_objlist(_EVIDENCE_SPEC, "Observations; duplicates and dependent copies are screened.",
                             Evidence, max_items=MAX_ITEMS)
_ARG_GROUPS = _arg_objlist(_GROUP_SPEC, "Provenance groups with optional designated observation or joint likelihood.",
                           ProvenanceGroup, max_items=MAX_ITEMS)
_ARG_ACTIONS = _arg_objlist(_ACTION_SPEC, "Candidate research actions.", ResearchAction, True, max_items=MAX_ITEMS)
_ARG_BUDGET = _arg_obj(_BUDGET_SPEC, "Separate limits and consumption for money, tokens, calls and time.",
                       ResourceBudget)
_ARG_ARMS = _arg_objlist(_ARM_SPEC, "Beta usefulness beliefs built from actual labelled outcomes.", UsefulnessBelief,
                         max_items=MAX_ITEMS)
_ARG_SEED = _arg_int("Seed for numpy.random.Generator; omit for a fresh seed (reported in the output).",
                     minimum=0, maximum=2 ** 63 - 1)
_ARG_EPS = _arg_num("Epsilon for epsilon-contamination prior-sensitivity bounds. Default 0.1.",
                    minimum=0, exclusiveMaximum=1)
_ARG_PVEC = _arg_numlist("Probabilities in hypothesis order; must sum to 1 (tolerance 1e-6).", True, min_items=2,
                         max_items=MAX_HYPOTHESES, minimum=0, maximum=1)
_ARG_OBS = _arg_matrix("Observation model P(outcome | hypothesis): one row per hypothesis (hypothesis order), one "
                       "column per exhaustive outcome; rows sum to 1.", True)
_ARG_SAFETY = _arg_num("Multiplier applied to estimated (not upper-bound) costs before budget checks. Default 1.",
                       minimum=1, maximum=100)
# The enum guides the model; the module itself refuses other sources with code 'unjustified_input'.
_ARG_OUTCOME_SOURCE = _Arg(True, lambda v, p: _str(v, p, max_len=100), {
    "type": "string", "enum": sorted(ACCEPTED_OUTCOME_SOURCES),
    "description": "Source of the actual binary outcome(s). Simulated successes and unvalidated LLM ratings are "
                   "refused (error code unjustified_input)."})

_MC_SPEC = {
    "seed": _ARG_SEED,
    "batch_size": _arg_int("Draws per batch. Default 10000.", minimum=1, maximum=JSON_MAX_BATCH),
    "max_draws": _arg_int("Maximum number of draws. Default 200000.", minimum=2, maximum=JSON_MAX_DRAWS),
    "min_draws": _arg_int("Minimum draws before an adaptive stop. Default 1000.", minimum=2, maximum=JSON_MAX_DRAWS),
    "abs_tol": _arg_num("Absolute precision target for the mean, in the outcome's units: stop when precision_z x "
                        "Monte Carlo standard error <= abs_tol + rel_tol x |mean|.", exclusiveMinimum=0,
                        maximum=MAX_MAGNITUDE),
    "rel_tol": _arg_num("Relative precision target (fraction of |mean|).", exclusiveMinimum=0, maximum=1e6),
    "quantiles": _arg_numlist("Quantile levels of the outcome distribution to report.", min_items=0, max_items=99,
                              minimum=0, maximum=1),
    "interval_level": _arg_num("Level of the central outcome interval. Default 0.9.", exclusiveMinimum=0,
                               exclusiveMaximum=1),
    "precision_z": _arg_num("Normal multiplier for the numerical interval and the precision rule. Default 1.96.",
                            exclusiveMinimum=0, maximum=10),
}
_ARG_INPUTS = _Arg(True, _inputs_conv, _sm(_S_DIST, "Object input_name -> named distribution. Inputs are sampled "
                                                    "independently, in the given order, from one seeded generator."))

_EVIDENCE_ARGS = {
    "hypotheses": _ARG_HYPOTHESES, "evidence": _ARG_EVIDENCE, "provenance_groups": _ARG_GROUPS,
    "already_applied_ids": _arg_strlist("Evidence ids already incorporated into the supplied priors."),
    "sensitivity_epsilon": _ARG_EPS,
}
_RANK_ARGS = {
    "hypotheses": _ARG_HYPOTHESES, "actions": _ARG_ACTIONS, "budget": _ARG_BUDGET,
    "utility": _arg_matrix("Utility matrix U[decision][hypothesis] in caller-defined utility units."),
    "decision_ids": _arg_strlist("Decision ids, one per utility row."),
    "heuristic_weights": _Arg(False, lambda v, p: _heuristic_weights(_numdict_conv(v, p)), _sm(
        _sn("Bits per resource unit.", minimum=0, maximum=1e6),
        "HEURISTIC exchange rates resource -> bits per unit (money, tokens, calls, seconds), used only without a "
        "utility model.")),
    "eig_method": _arg_str("EIG method. Default auto.", enum=["auto", "exact", "monte_carlo"]),
    "n_samples": _arg_int("Monte Carlo samples when EIG/EVSI cannot be enumerated. Default 20000.", minimum=100,
                          maximum=200_000),
    "seed": _ARG_SEED,
    "require_upper_bounds": _arg_bool("Reject actions whose costs are only estimates."),
    "estimate_safety_factor": _ARG_SAFETY,
    "allow_unknown_costs": _arg_bool("Allow actions whose cost for a limited resource is unknown."),
}
_RECOMMEND_ARGS = {
    **_EVIDENCE_ARGS, **_RANK_ARGS,
    "policy": _arg_str("'auto' (top-ranked action) or 'thompson' (Thompson sampling over usefulness beliefs).",
                       enum=["auto", "thompson"]),
    "usefulness_beliefs": _ARG_ARMS,
    "criteria": _arg_obj(_CRITERIA_SPEC, "Stopping thresholds.", StopCriteria),
}


# --- 7d. Tool registry ---------------------------------------------------------

@dataclass(frozen=True)
class _Tool:
    name: str
    description: str
    spec: Dict[str, _Arg]
    handler: Callable[[Dict[str, Any]], Any]
    output: Dict[str, Any]


_TOOLS: Dict[str, _Tool] = {}


def _register(name: str, description: str, spec: Dict[str, _Arg], output: Dict[str, Any]) -> Callable[..., Any]:
    def deco(fn: Callable[[Dict[str, Any]], Any]) -> Callable[[Dict[str, Any]], Any]:
        _TOOLS[name] = _Tool(name, description, dict(spec), fn, output)
        return fn
    return deco


_OUT_POSTERIOR = {"type": "PosteriorResult", "fields": {
    "posterior": "posterior probabilities in hypothesis order (hypothesis_ids)",
    "map_hypothesis, max_posterior": "leading hypothesis and its posterior",
    "entropy_bits": "posterior entropy in bits",
    "log_likelihood": "summed log P(evidence | h); null marks -infinity",
    "log_marginal_likelihood": "log P(evidence); null when only likelihood ratios were used",
    "applied, excluded, recorded_only": "which observations were used, excluded (with reasons) or only recorded",
    "independent_groups_used": "number of provenance groups that contributed",
    "binary": "two hypotheses only: Bayes factor and posterior odds (null = infinite)",
    "prior_sensitivity": "uniform-prior posterior, epsilon-contamination bounds, robustness flag",
    "assumptions, warnings": "model assumptions behind the numbers"}}
_OUT_MC = {"type": "MonteCarloEstimate", "fields": {
    "mean": "estimated mean", "std": "standard deviation of simulated outcomes",
    "quantiles, outcome_interval": "spread of the simulated quantity",
    "mc_standard_error, mean_numerical_interval": "Monte Carlo error of the mean only",
    "n_draws, n_batches, stopping_reason, seed": "run metadata", "precision_target": "stopping rule used",
    "notes": "interpretation, including the adaptive-stopping caveat", "extra": "tool-specific details"}}
_OUT_RANKING = {"type": "ActionRanking", "fields": {
    "evaluations": "per action: EIG (bits), EVSI / net value if a utility model is given, costs by resource, "
                   "affordability with reasons, rank",
    "criterion, criterion_is_heuristic, criterion_description": "what the ranking optimises",
    "budget_report": "affordability filter output", "notes": "assumptions"}}


@_register("update_binary_posterior",
           "Posterior for two hypotheses from P(H1) and likelihood ratios P(e|H1)/P(e|H0) taken from justified "
           "likelihood models (never from an LLM's stated confidence). Several ratios are treated as conditionally "
           "independent.",
           {"prior": _arg_num("Prior P(H1).", True, minimum=0, maximum=1),
            "likelihood_ratios": _Arg(True, lambda v, p: (_list_conv(lambda x, q: _num(x, q, lo=0.0), 1, MAX_ITEMS)(v, p)
                                                          if isinstance(v, list) else [_num(v, p, lo=0.0)]),
                                      {"description": "One likelihood ratio or an array of them (each >= 0).",
                                       "anyOf": [{"type": "number", "minimum": 0},
                                                 {"type": "array", "items": {"type": "number", "minimum": 0},
                                                  "minItems": 1}]}),
            "hypothesis_ids": _arg_strlist("Two ids, H1 first. Default ['H1', 'H0'].", max_items=2),
            "sensitivity_epsilon": _ARG_EPS},
           _OUT_POSTERIOR)
def _t_binary(kw: Dict[str, Any]) -> Any:
    return update_binary_posterior(kw["prior"], kw["likelihood_ratios"],
                                   hypothesis_ids=kw.get("hypothesis_ids", ("H1", "H0")),
                                   sensitivity_epsilon=kw.get("sensitivity_epsilon", 0.1))


@_register("update_categorical_posterior",
           "Posterior over several hypotheses: posterior[h] proportional to prior[h] x P(e|h), in log space. Rows of a "
           "likelihood matrix are treated as conditionally independent observations.",
           {"prior": _ARG_PVEC,
            "likelihoods": _Arg(True, lambda v, p: (_matrix_conv(v, p) if isinstance(v, list) and v and
                                                    isinstance(v[0], list) else
                                                    _list_conv(lambda x, q: _num(x, q), 1, MAX_ITEMS)(v, p)),
                                {"description": "P(e|h) per hypothesis (array), or an array of such arrays for several "
                                                "observations.",
                                 "anyOf": [_sa(_sn("Likelihood.", minimum=0), "One observation."),
                                           _sa(_sa(_sn("Likelihood.", minimum=0), "Row."), "Several observations.")]}),
            "hypothesis_ids": _arg_strlist("Hypothesis ids in order."),
            "is_density": _arg_bool("True if the likelihoods are densities (may exceed 1)."),
            "sensitivity_epsilon": _ARG_EPS},
           _OUT_POSTERIOR)
def _t_categorical(kw: Dict[str, Any]) -> Any:
    return update_categorical_posterior(kw["prior"], kw["likelihoods"], hypothesis_ids=kw.get("hypothesis_ids"),
                                        is_density=kw.get("is_density", False),
                                        sensitivity_epsilon=kw.get("sensitivity_epsilon", 0.1))


def _assess_from_kw(kw: Dict[str, Any]) -> PosteriorResult:
    return assess_evidence(kw["hypotheses"], kw.get("evidence", []), provenance_groups=kw.get("provenance_groups", ()),
                           already_applied_ids=kw.get("already_applied_ids", ()),
                           sensitivity_epsilon=kw.get("sensitivity_epsilon", 0.1))


@_register("assess_evidence",
           "Screen structured evidence (duplicates, provenance groups, justified likelihoods) and update the prior. "
           "Unjustified evidence and LLM confidence are recorded but do not change the posterior.",
           _EVIDENCE_ARGS, _OUT_POSTERIOR)
def _t_assess(kw: Dict[str, Any]) -> Any:
    return _assess_from_kw(kw)


@_register("update_beta_bernoulli",
           "Beta-Bernoulli update of a success probability from actual binary outcomes (e.g. whether completed searches "
           "returned an independently labelled useful result). Returns the credible interval for theta and, separately, "
           "the predictive probability of the next outcome.",
           {"successes": _arg_int("Observed successes.", True, minimum=0, maximum=10 ** 12),
            "failures": _arg_int("Observed failures.", True, minimum=0, maximum=10 ** 12),
            "outcome_source": _ARG_OUTCOME_SOURCE,
            "prior_alpha": _arg_num("Prior alpha. Default 1.", exclusiveMinimum=0, maximum=MAX_BETA_PARAM),
            "prior_beta": _arg_num("Prior beta. Default 1.", exclusiveMinimum=0, maximum=MAX_BETA_PARAM),
            "credible_level": _arg_num("Credible level. Default 0.95.", exclusiveMinimum=0, exclusiveMaximum=1)},
           {"type": "BetaPosterior", "fields": {"alpha, beta": "posterior parameters",
                                                "mean, sd, mode, credible_interval": "uncertainty about theta",
                                                "predictive_next_success": "P(next outcome = success)"}})
def _t_beta(kw: Dict[str, Any]) -> Any:
    return update_beta_bernoulli(kw["successes"], kw["failures"], outcome_source=kw["outcome_source"],
                                 prior_alpha=kw.get("prior_alpha", 1.0), prior_beta=kw.get("prior_beta", 1.0),
                                 credible_level=kw.get("credible_level", 0.95))


@_register("posterior_predictive",
           "Predictive distribution of the next observation. mode 'categorical': P(o) = sum_h P(h) P(o|h) for a "
           "hypothesis posterior and an observation model. mode 'beta_binomial': successes in the next n_future trials "
           "under Beta(alpha, beta).",
           {"mode": _arg_str("'categorical' or 'beta_binomial'.", True, enum=["categorical", "beta_binomial"]),
            "posterior": _arg_numlist("categorical: posterior probabilities in hypothesis order.", min_items=2,
                                      max_items=MAX_HYPOTHESES, minimum=0, maximum=1),
            "observation_likelihoods": _arg_matrix("categorical: P(outcome | hypothesis), rows sum to 1."),
            "outcomes": _arg_strlist("categorical: outcome names."),
            "hypothesis_ids": _arg_strlist("categorical: hypothesis ids."),
            "alpha": _arg_num("beta_binomial: Beta alpha.", exclusiveMinimum=0),
            "beta": _arg_num("beta_binomial: Beta beta.", exclusiveMinimum=0),
            "n_future": _arg_int("beta_binomial: number of future trials. Default 1.", minimum=1, maximum=10_000)},
           {"type": "object", "fields": {"outcome_probabilities, posterior_given_outcome": "categorical mode",
                                         "p_next_success, pmf_number_of_successes": "beta_binomial mode"}})
def _t_predictive(kw: Dict[str, Any]) -> Any:
    if kw["mode"] == "beta_binomial":
        for k in ("alpha", "beta"):
            if k not in kw:
                raise ValidationError(f"Missing required field 'arguments.{k}' for mode 'beta_binomial'.")
        return _beta_binomial_predictive(kw["alpha"], kw["beta"], kw.get("n_future", 1))
    for k in ("posterior", "observation_likelihoods"):
        if k not in kw:
            raise ValidationError(f"Missing required field 'arguments.{k}' for mode 'categorical'.")
    return posterior_predictive(kw["posterior"], kw["observation_likelihoods"], outcomes=kw.get("outcomes"),
                                hypothesis_ids=kw.get("hypothesis_ids"))


@_register("prior_sensitivity",
           "How much the conclusion depends on the prior: uniform-prior posterior, exact epsilon-contamination bounds, "
           "alternative priors, and a robustness flag. Supply exactly one of likelihoods or log_likelihoods.",
           {"prior": _ARG_PVEC,
            "likelihoods": _arg_numlist("Combined P(all evidence | h) per hypothesis (>= 0).", min_items=2,
                                        max_items=MAX_HYPOTHESES, minimum=0),
            "log_likelihoods": _arg_numlist("Combined log P(all evidence | h) per hypothesis.", min_items=2,
                                            max_items=MAX_HYPOTHESES),
            "hypothesis_ids": _arg_strlist("Hypothesis ids in order."),
            "epsilon": _ARG_EPS,
            "alternative_priors": _Arg(False, _named_vectors_conv, _sm(
                _sa(_sn("Probability.", minimum=0, maximum=1), "Prior vector."),
                "Object name -> alternative prior vector (hypothesis order)."))},
           {"type": "object", "fields": {"contamination_bounds": "[lower, upper] posterior per hypothesis",
                                         "conclusion_robust_to_prior": "whether the leading hypothesis survives all checks",
                                         "binary": "two hypotheses: prior needed for each posterior level"}})
def _t_sensitivity(kw: Dict[str, Any]) -> Any:
    if ("likelihoods" in kw) == ("log_likelihoods" in kw):
        raise ValidationError("Supply exactly one of 'likelihoods' or 'log_likelihoods'.")
    ll = (_log(_arr(kw["likelihoods"], "arguments.likelihoods", ndim=1, nonneg=True)) if "likelihoods" in kw
          else np.asarray(kw["log_likelihoods"], dtype=float))
    return prior_sensitivity(kw["prior"], ll, hypothesis_ids=kw.get("hypothesis_ids"),
                             epsilon=kw.get("epsilon", 0.1), alternative_priors=kw.get("alternative_priors"))


def _split_mc(kw: Dict[str, Any], n_outputs: int = 1) -> Dict[str, Any]:
    mc = {k: kw.pop(k) for k in list(kw) if k in _MC_SPEC}
    if mc.get("max_draws", 200_000) * n_outputs > JSON_MAX_WORK:
        raise LimitExceededError(f"max_draws x number of outputs must not exceed {JSON_MAX_WORK}.")
    return mc


def _joint_from(samplers: Mapping[str, Sampler]) -> Sampler:
    def draw(rng: np.random.Generator, n: int) -> Dict[str, np.ndarray]:
        return {k: _check_outcomes(s(rng, n), n, 1, False, f"input '{k}'")[:, 0] for k, s in samplers.items()}
    return draw


def _batch_len(xs: Mapping[str, np.ndarray]) -> int:
    return len(next(iter(xs.values())))


@_register("monte_carlo_expectation",
           "Monte Carlo estimate of E[g(X)] for a named distribution X and an optional transform expression over the "
           "variable 'x'.",
           {"distribution": _Arg(True, _dist_conv, _S_DIST),
            "transform": _Arg(False, _passthrough, {**_S_EXPR, "description": "Optional expression over the variable "
                                                                              "'x'. " + EXPRESSION_DOC}),
            **_MC_SPEC},
           _OUT_MC)
def _t_expectation(kw: Dict[str, Any]) -> Any:
    mc = _split_mc(kw)
    sampler = kw["distribution"]
    if "transform" in kw:
        expr = _compile_expr(kw["transform"], {"x"}, "arguments.transform")
        return monte_carlo_expectation(sampler, lambda x: expr({"x": x}, len(x)), **mc)
    return monte_carlo_expectation(sampler, **mc)


@_register("propagate_uncertainty",
           "Propagate uncertainty from named input distributions through an expression model; reports the outcome "
           "spread, the Monte Carlo error of the mean, and rank correlations of each input with the output.",
           {"inputs": _ARG_INPUTS, "model": _Arg(True, _passthrough, _S_EXPR), **_MC_SPEC}, _OUT_MC)
def _t_propagate(kw: Dict[str, Any]) -> Any:
    mc = _split_mc(kw)
    samplers = kw["inputs"]
    expr = _compile_expr(kw["model"], set(samplers), "arguments.model")
    return propagate_uncertainty(samplers, lambda xs: expr(xs, _batch_len(xs)), **mc)


@_register("probability_of_event",
           "Monte Carlo probability that a boolean expression over named input distributions is true, with a Jeffreys "
           "interval for the Monte Carlo error.",
           {"inputs": _ARG_INPUTS, "event": _Arg(True, _passthrough, {**_S_EXPR, "description": "Boolean expression "
                                                                                                "(comparisons, and/or/not). "
                                                                                                + EXPRESSION_DOC}),
            **_MC_SPEC},
           _OUT_MC)
def _t_event(kw: Dict[str, Any]) -> Any:
    mc = _split_mc(kw)
    samplers = kw["inputs"]
    expr = _compile_expr(kw["event"], set(samplers), "arguments.event")
    return probability_of_event(_joint_from(samplers), lambda xs: expr(xs, _batch_len(xs)), **mc)


@_register("compare_alternatives",
           "Compare 2 to 20 alternatives (expressions over the same named inputs) on common random numbers: expected "
           "outcomes, paired differences from the best with Monte Carlo error, and scenario win frequencies.",
           {"inputs": _ARG_INPUTS,
            "alternatives": _Arg(True, _expr_map_conv, _sm(_S_EXPR, "Object alternative_name -> expression.")),
            "higher_is_better": _arg_bool("Orientation of the outcome. Default true."),
            **_MC_SPEC},
           {"type": "object", "fields": {"best_by_expected_outcome": "best alternative",
                                         "differences_from_best": "paired differences with Monte Carlo error",
                                         "scenario_win_frequency": "fraction of scenarios each alternative wins",
                                         "alternatives": "MonteCarloEstimate per alternative"}})
def _t_compare(kw: Dict[str, Any]) -> Any:
    raw = kw["alternatives"]
    mc = _split_mc(kw, n_outputs=len(raw))
    samplers = kw["inputs"]
    compiled = {nm: _compile_expr(e, set(samplers), f"arguments.alternatives.{nm}") for nm, e in raw.items()}
    alts = {nm: (lambda xs, f=f: f(xs, _batch_len(xs))) for nm, f in compiled.items()}
    return compare_alternatives(_joint_from(samplers), alts, higher_is_better=kw.get("higher_is_better", True), **mc)


_ACTION_MATH_ARGS = {
    "prior": _ARG_PVEC, "observation_likelihoods": _ARG_OBS,
    "n_repeats": _arg_int("Conditionally independent repeats of the observation. Default 1.", minimum=1, maximum=1000),
    "method": _arg_str("auto (exact when small), exact, or monte_carlo. Default auto.",
                       enum=["auto", "exact", "monte_carlo"]),
    "max_enumeration": _arg_int("Largest outcome-configuration count enumerated exactly. Default 50000.", minimum=1,
                                maximum=MAX_ENUMERATION_LIMIT),
    "n_samples": _arg_int("Monte Carlo samples. Default 20000.", minimum=100, maximum=200_000),
    "seed": _ARG_SEED,
    "hypothesis_ids": _arg_strlist("Hypothesis ids in order."),
    "outcomes": _arg_strlist("Outcome names in column order."),
}


@_register("expected_information_gain",
           "Expected reduction in hypothesis entropy (bits) from observing an action with the given observation model; "
           "exact enumeration where practical, Monte Carlo otherwise.",
           _ACTION_MATH_ARGS,
           {"type": "object", "fields": {"expected_information_gain_bits": "EIG in bits",
                                         "prior_entropy_bits, expected_posterior_entropy_bits": "entropy terms",
                                         "outcome_probabilities, posterior_by_outcome": "single-observation detail",
                                         "method, mc_standard_error": "how it was computed"}})
def _t_eig(kw: Dict[str, Any]) -> Any:
    return expected_information_gain(kw["prior"], kw["observation_likelihoods"], **{
        k: kw[k] for k in ("n_repeats", "method", "max_enumeration", "n_samples", "seed", "hypothesis_ids", "outcomes")
        if k in kw})


@_register("expected_value_of_information",
           "Expected value of sample information for a decision problem with a utility matrix: expected optimal utility "
           "after the observation minus optimal expected utility now. The cost is subtracted only if given in utility "
           "units.",
           {**_ACTION_MATH_ARGS, "utility": _arg_matrix("Utility matrix U[decision][hypothesis] in utility units.", True),
            "decision_ids": _arg_strlist("Decision ids, one per utility row."),
            "cost_in_utility_units": _arg_num("Action cost in the same utility units (only with a justified "
                                              "conversion).", minimum=0, maximum=MAX_MAGNITUDE)},
           {"type": "object", "fields": {"evsi": "expected value of sample information (utility units)",
                                         "evpi": "expected value of perfect information (upper bound)",
                                         "net_value_of_information": "evsi - cost, or null without a utility-unit cost",
                                         "decision_rule": "best decision for each outcome"}})
def _t_evsi(kw: Dict[str, Any]) -> Any:
    return expected_value_of_information(kw["prior"], kw["observation_likelihoods"], kw["utility"], **{
        k: kw[k] for k in ("decision_ids", "cost_in_utility_units", "n_repeats", "method", "max_enumeration",
                           "n_samples", "seed", "hypothesis_ids", "outcomes") if k in kw})


@_register("thompson_select",
           "Thompson sampling over Beta usefulness beliefs that were built only from actual labelled binary outcomes.",
           {"arms": _Arg(True, _ARG_ARMS.conv, _ARG_ARMS.schema),
            "eligible_arm_ids": _arg_strlist("Restrict selection to these arms (e.g. affordable ones)."),
            "seed": _ARG_SEED,
            "n_probability_draws": _arg_int("Draws used to estimate P(best). Default 10000.", minimum=100,
                                            maximum=200_000)},
           {"type": "object", "fields": {"selected_arm_id": "chosen arm",
                                         "probability_best_estimate": "Monte Carlo P(arm has highest usefulness)"}})
def _t_thompson(kw: Dict[str, Any]) -> Any:
    return thompson_select(kw["arms"], eligible_arm_ids=kw.get("eligible_arm_ids"), seed=kw.get("seed"),
                           n_probability_draws=kw.get("n_probability_draws", 10_000))


@_register("record_usefulness_outcome",
           "Update one usefulness belief with an actual, independently labelled binary outcome. Simulated successes and "
           "unvalidated LLM ratings are rejected.",
           {"arm": _arg_obj(_ARM_SPEC, "Current belief.", UsefulnessBelief, True),
            "useful": _arg_bool("Whether the completed action produced a useful result.", True),
            "outcome_source": _ARG_OUTCOME_SOURCE},
           {"type": "UsefulnessBelief", "fields": {"alpha, beta, n_successes, n_failures": "updated belief"}})
def _t_record(kw: Dict[str, Any]) -> Any:
    return record_usefulness_outcome(kw["arm"], kw["useful"], outcome_source=kw["outcome_source"])


@_register("filter_affordable_actions",
           "Check each action against the remaining money, token, call and time limits separately. Estimated costs are "
           "padded by estimate_safety_factor; passing does not guarantee compliance.",
           {"actions": _ARG_ACTIONS, "budget": _Arg(True, _ARG_BUDGET.conv, _ARG_BUDGET.schema),
            "require_upper_bounds": _RANK_ARGS["require_upper_bounds"],
            "estimate_safety_factor": _ARG_SAFETY, "allow_unknown_costs": _RANK_ARGS["allow_unknown_costs"]},
           {"type": "object", "fields": {"affordable": "action ids", "unaffordable": "action ids with reasons",
                                         "per_action": "checked costs and compliance status",
                                         "exhausted_resources": "resources at or over their limit"}})
def _t_filter(kw: Dict[str, Any]) -> Any:
    return filter_affordable_actions(kw["actions"], kw["budget"], **{
        k: kw[k] for k in ("require_upper_bounds", "estimate_safety_factor", "allow_unknown_costs") if k in kw})


@_register("rank_research_actions",
           "Value candidate actions under a belief: EIG in bits with costs kept separate, or EVSI / net value with a "
           "utility model; affordability per resource.",
           {**_RANK_ARGS, "belief": _arg_numlist("Current probabilities in hypothesis order; defaults to the priors.",
                                                 min_items=2, max_items=MAX_HYPOTHESES, minimum=0, maximum=1)},
           _OUT_RANKING)
def _t_rank(kw: Dict[str, Any]) -> Any:
    hyps, acts = kw.pop("hypotheses"), kw.pop("actions")
    return rank_research_actions(hyps, acts, **kw)


def _recommend_from_kw(kw: Dict[str, Any], post: PosteriorResult) -> ActionRecommendation:
    opts = {k: kw[k] for k in ("utility", "decision_ids", "heuristic_weights", "eig_method", "n_samples", "seed",
                               "require_upper_bounds", "estimate_safety_factor", "allow_unknown_costs", "policy",
                               "usefulness_beliefs", "criteria") if k in kw}
    return recommend_next_action(kw["hypotheses"], post, kw["actions"], kw.get("budget"), **opts)


_OUT_RECOMMEND = {"type": "object", "fields": {
    "posterior": "PosteriorResult after screening the evidence",
    "recommendation.recommended_action_id": "next action, or null when stopping",
    "recommendation.stop_assessment": "should_stop, reasons, evidence_status, answer_guidance, prior sensitivity, "
                                      "assumptions and caveats",
    "recommendation.ranking": "ActionRanking"}}


@_register("recommend_next_action",
           "One call for a research step: screen the evidence, compute the posterior, rank affordable actions, assess "
           "stopping, and recommend the next action (or none) with reasons.",
           _RECOMMEND_ARGS, _OUT_RECOMMEND)
def _t_recommend(kw: Dict[str, Any]) -> Any:
    post = _assess_from_kw(kw)
    return {"posterior": post, "recommendation": _recommend_from_kw(kw, post)}


@_register("should_stop",
           "Stopping assessment only: explicit reasons (budget exhausted, no affordable action, EIG below threshold, no "
           "positive net value, missing observation model, more evidence required) plus prior sensitivity and model "
           "assumptions.",
           _RECOMMEND_ARGS,
           {"type": "object", "fields": {"stop_assessment": "StopAssessment",
                                         "posterior_summary": "compact posterior",
                                         "recommended_action_id": "next action if not stopping"}})
def _t_should_stop(kw: Dict[str, Any]) -> Any:
    post = _assess_from_kw(kw)
    rec = _recommend_from_kw(kw, post)
    return {"stop_assessment": rec.stop_assessment, "posterior_summary": post.summary(),
            "recommended_action_id": rec.recommended_action_id}


@_register("list_tools", "List the available tools with their input schemas and output descriptions.",
           {"api_format": _arg_bool("Return only name, description and input_schema.")},
           {"type": "array", "fields": {"name, description, input_schema, output": "tool definitions"}})
def _t_list(kw: Dict[str, Any]) -> Any:
    return tool_definitions(api_format=kw.get("api_format", False))


def tool_definitions(api_format: bool = False) -> List[Dict[str, Any]]:
    """Machine-readable tool definitions generated from the same specs that validate arguments.

    Each definition has ``name``, ``description`` and a JSON Schema ``input_schema``; with
    ``api_format=False`` it also has ``output``. The schemas use numeric bounds and
    map-valued objects, so they are meant for non-strict tool use; :func:`run_tool`
    validates every argument itself.
    """
    out = []
    for t in _TOOLS.values():
        d: Dict[str, Any] = {"name": t.name, "description": t.description,
                             "input_schema": _obj_schema(t.spec, f"Arguments for {t.name}.")}
        if not api_format:
            d["output"] = t.output
        out.append(json.loads(json.dumps(d)))
    return out


def _scan_json(obj: Any, depth: int = 0, counter: Optional[List[int]] = None) -> None:
    """Reject anything that is not plain, finite JSON, and enforce size limits."""
    counter = counter if counter is not None else [0]
    counter[0] += 1
    if counter[0] > MAX_JSON_NODES:
        raise LimitExceededError("Arguments are too large.")
    if depth > MAX_JSON_DEPTH:
        raise LimitExceededError("Arguments are nested too deeply.")
    if obj is None or isinstance(obj, (bool, int)):
        return
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise NonFiniteInputError("Arguments contain NaN or infinity; only finite numbers are accepted.")
        return
    if isinstance(obj, str):
        if len(obj) > MAX_STR:
            raise LimitExceededError("A string argument exceeds the length limit.")
        return
    if isinstance(obj, list):
        for v in obj:
            _scan_json(v, depth + 1, counter)
        return
    if isinstance(obj, dict):
        for k, v in obj.items():
            if not isinstance(k, str):
                raise ValidationError("Object keys must be strings.")
            _scan_json(v, depth + 1, counter)
        return
    raise ValidationError(f"Unsupported argument type '{type(obj).__name__}'; only JSON values are accepted.")


def run_tool(tool_name: str, arguments: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Allowlisted JSON dispatcher for the LLM.

    Looks ``tool_name`` up in a fixed registry, validates ``arguments`` (plain finite JSON,
    known fields only, typed and range-checked), runs the calculation, and returns
    ``{"ok": true, "tool", "result"}`` or ``{"ok": false, "tool", "error": {code,
    message, details}}``. Results are strict JSON (non-finite numbers become null).
    It never executes generated code, uses eval, or unpickles objects.
    """
    name = tool_name if isinstance(tool_name, str) else None
    if name not in _TOOLS:
        return {"ok": False, "tool": name, "error": {"code": "unknown_tool",
                                                      "message": f"Unknown tool {str(tool_name)[:80]!r}.",
                                                      "details": {"available": sorted(_TOOLS)}}}
    try:
        args = {} if arguments is None else arguments
        if not isinstance(args, dict):
            raise ValidationError("'arguments' must be a JSON object.")
        _scan_json(args)
        tool = _TOOLS[name]
        result = tool.handler(_fields(args, "arguments", tool.spec))
        payload = {"ok": True, "tool": name, "result": to_jsonable(result)}
        json.dumps(payload, allow_nan=False)
        return payload
    except InferenceError as exc:
        return {"ok": False, "tool": name, "error": exc.to_dict()}
    except Exception as exc:  # never leak internals or tracebacks to the model
        return {"ok": False, "tool": name, "error": {"code": "internal_error",
                                                      "message": f"Unexpected {type(exc).__name__}; no result produced.",
                                                      "details": {}}}


def _reject_constant(name: str) -> Any:
    raise NonFiniteInputError(f"JSON constant '{name}' is not allowed; only finite numbers are accepted.")


def run_tool_json(request: str) -> str:
    """Strict JSON-in, JSON-out wrapper: ``{"tool": name, "arguments": {...}}`` -> JSON string."""
    try:
        if not isinstance(request, str):
            raise ValidationError("The request must be a JSON string.")
        if len(request) > 20_000_000:
            raise LimitExceededError("The request is too large.")
        msg = json.loads(request, parse_constant=_reject_constant)
        if not isinstance(msg, dict) or "tool" not in msg or set(msg) - {"tool", "arguments"}:
            raise ValidationError("The request must be an object {'tool': name, 'arguments': {...}}.")
        out = run_tool(msg["tool"], msg.get("arguments", {}))
    except InferenceError as exc:
        out = {"ok": False, "tool": None, "error": exc.to_dict()}
    except (json.JSONDecodeError, RecursionError) as exc:
        detail = exc.msg if isinstance(exc, json.JSONDecodeError) else "nesting too deep"
        out = {"ok": False, "tool": None, "error": {"code": "invalid_json",
                                                     "message": f"The request is not valid JSON: {detail}.",
                                                     "details": {}}}
    return json.dumps(out, allow_nan=False)


# =============================================================================
# 8. Demonstration (fictional inputs) and self-checks
# =============================================================================

def _hr(title: str) -> None:
    print("\n" + title)
    print("-" * len(title))


def _f(v: Optional[float], spec: str = ".3f") -> str:
    return "n/a" if v is None else format(v, spec)


def _print_ranking(r: ActionRanking, with_value: bool) -> None:
    head = f"  {'action':<20}{'EIG bits':>9}"
    if with_value:
        head += f"{'EVSI':>8}{'net':>8}"
    head += f"{'money':>7}{'tokens':>8}{'calls':>6}{'secs':>6}  {'cost kind':<12}{'affordable':<11}rank"
    print(head)
    for e in r.evaluations:
        line = f"  {e.action_id:<20}{_f(e.expected_information_gain_bits):>9}"
        if with_value:
            line += f"{_f(e.evsi, '.2f'):>8}{_f(e.net_value_of_information, '.2f'):>8}"
        line += (f"{_f(e.cost['money'], '.2f'):>7}{_f(e.cost['tokens'], '.0f'):>8}{_f(e.cost['calls'], '.0f'):>6}"
                 f"{_f(e.cost['seconds'], '.0f'):>6}  {e.cost_kind:<12}{'yes' if e.affordable else 'no':<11}"
                 f"{e.rank if e.rank is not None else '-'}")
        print(line)
        if not e.affordable:
            print(f"      not affordable: {', '.join(e.affordability_reasons)}")
    print(f"  Criterion: {r.criterion} (heuristic: {r.criterion_is_heuristic}). {r.criterion_description}")


def _print_stop(sa: StopAssessment) -> None:
    print(f"  should_stop = {sa.should_stop}; outcome = {sa.outcome}")
    print(f"  reasons     = {sa.reasons}")
    print(f"  evidence    = {sa.evidence_status}")
    for d in sa.insufficiency:
        print(f"    - {d}")
    print(f"  guidance    : {sa.answer_guidance}")


def run_demo() -> None:
    """Walk through one fictional research question end to end."""
    print("=" * 78)
    print("Aureom.AI inference module: demonstration")
    print("ALL INPUTS ARE FICTIONAL. Names, sources, likelihoods, costs and utilities are invented.")
    print("=" * 78)
    print("Question (fictional): did 'Norrvik Instruments Ltd' move its head office to Leeds in 2025?")

    # 1-2. Two competing hypotheses with an explicit prior.
    hyps = HypothesisSet((
        Hypothesis("moved", 0.30, "Head office moved to Leeds in 2025",
                   "Fictional base rate: 30% of announced relocations in a fictional reference set completed in a year."),
        Hypothesis("not_moved", 0.70, "Head office did not move", "Complement of the fictional base rate."),
    ))
    _hr("1-2. Hypotheses and explicit prior")
    for h in hyps.hypotheses:
        print(f"  {h.id:<10} prior {h.prior:.2f}  ({h.prior_basis})")

    # 3-5. Supporting evidence, independent contradictory evidence, a duplicate, a dependent copy, an LLM note.
    cal = LikelihoodBasis.CALIBRATED_ON_LABELLED_DATA
    note = "Fictional: rates measured on labelled relocation cases."
    evidence = [
        Evidence(evidence_id="ev-jobs-01", source="fictional-job-board", provenance_group="job-board",
                 likelihood_model="categorical", likelihood_basis=cal, likelihood_justification=note,
                 likelihoods={"moved": 0.80, "not_moved": 0.10}, relevance_score=0.91,
                 description="Job board lists 40 vacancies at a new Leeds head office."),
        Evidence(evidence_id="ev-news-07", source="fictional-trade-weekly", provenance_group="press-release-2025-03",
                 likelihood_model="categorical", likelihood_basis=cal, likelihood_justification=note,
                 likelihoods={"moved": 0.70, "not_moved": 0.20}, designated=True,
                 description="Trade-press article on the move, based on the company's press release."),
        Evidence(evidence_id="ev-news-12", source="fictional-news-aggregator", provenance_group="press-release-2025-03",
                 likelihood_model="categorical", likelihood_basis=cal, likelihood_justification=note,
                 likelihoods={"moved": 0.70, "not_moved": 0.20},
                 description="Syndicated copy of the same press release on another site."),
        Evidence(evidence_id="ev-dir-03", source="fictional-business-directory", provenance_group="business-directory",
                 likelihood_model="categorical", likelihood_basis=cal, likelihood_justification=note,
                 likelihoods={"moved": 0.35, "not_moved": 0.90},
                 description="Directory still lists the old Sheffield address (contradicts the move)."),
        Evidence(evidence_id="ev-jobs-01", source="fictional-job-board", provenance_group="job-board",
                 likelihood_model="categorical", likelihood_basis=cal, likelihood_justification=note,
                 likelihoods={"moved": 0.80, "not_moved": 0.10},
                 description="The same job-board observation, returned a second time by retrieval."),
        Evidence(evidence_id="ev-llm-note", source="aureom-llm-draft", provenance_group="llm-draft",
                 likelihood_model="none", likelihood_basis=LikelihoodBasis.LLM_VERBAL_CONFIDENCE,
                 description="Draft answer: 'I am 90% confident the firm moved.'",
                 llm_annotation="Model believes the move is likely.", llm_stated_confidence=0.90),
    ]
    post = assess_evidence(hyps, evidence)
    _hr("3-5, 7. Evidence screening and posterior")
    for item in post.applied:
        ev = next(e for e in evidence if e.evidence_id == item["evidence_ids"][0])
        lr = ev.likelihoods["moved"] / ev.likelihoods["not_moved"]
        print(f"  APPLIED   {item['evidence_ids'][0]:<12} LR(moved:not) = {lr:5.2f}  [{item['selection']}]")
    for r in post.excluded:
        print(f"  EXCLUDED  {r.evidence_id:<12} {r.reason}")
    for r in post.recorded_only:
        print(f"  RECORDED  {r.evidence_id:<12} {r.reason} (not applied)")
    print(f"  Posterior P(moved) = {post.posterior_dict()['moved']:.4f} from prior 0.30; Bayes factor "
          f"{post.binary['bayes_factor']:.2f}; {post.independent_groups_used} independent provenance groups.")
    naive = update_binary_posterior(0.30, [8.0, 8.0, 3.5, 3.5, 0.35 / 0.90], hypothesis_ids=("moved", "not_moved"))
    print(f"  For contrast, multiplying in the duplicate and the syndicated copy as if independent would give "
          f"{naive.posterior[0]:.4f}.")
    sens = post.prior_sensitivity
    lo, hi = sens["contamination_bounds"]["moved"]
    print(f"  Prior sensitivity: uniform prior gives {sens['uniform_prior_posterior']['moved']:.4f}; eps = "
          f"{sens['epsilon']:g} contamination bounds [{lo:.4f}, {hi:.4f}]; robust: {sens['conclusion_robust_to_prior']}.")
    print(f"  With this evidence, the prior P(moved) would need to be "
          f"{sens['binary']['prior_needed_for_posterior']['0.95']:.3f} for a posterior of 0.95.")

    # 6. Three research actions with different observation models and costs, and a budget.
    actions = [
        ResearchAction("retrieve-filing", "Retrieve the primary registry filing (change of registered office).",
                       kind="retrieve_primary_document",
                       outcomes=("filing_confirms_move", "filing_shows_no_change", "filing_unavailable"),
                       observation_model={"moved": (0.85, 0.03, 0.12), "not_moved": (0.02, 0.86, 0.12)},
                       observation_model_basis=cal, observation_model_justification="Fictional retrieval audit.",
                       cost=ResourceCost(money=0.50, tokens=8_000, calls=2, seconds=30, kind="upper_bound"),
                       cost_in_utility_units=0.5, usefulness_arm="registry-api"),
        ResearchAction("search-archive", "Search a new news-archive collection for independent reports.",
                       kind="search_new_source_collection", outcomes=("independent_report_found", "nothing_found"),
                       observation_model={"moved": (0.55, 0.45), "not_moved": (0.10, 0.90)},
                       observation_model_basis=cal, observation_model_justification="Fictional archive audit.",
                       cost=ResourceCost(money=0.15, tokens=70_000, calls=4, seconds=60, kind="estimate"),
                       cost_in_utility_units=0.3, usefulness_arm="news-archive-B"),
        ResearchAction("seek-contradiction", "Search for reports that the move was cancelled or reversed.",
                       kind="seek_contradictory_evidence", outcomes=("cancellation_report_found", "none_found"),
                       observation_model={"moved": (0.05, 0.95), "not_moved": (0.30, 0.70)},
                       observation_model_basis=cal, observation_model_justification="Fictional search audit.",
                       cost=ResourceCost(money=0.05, tokens=15_000, calls=2, seconds=20, kind="estimate"),
                       cost_in_utility_units=0.1, usefulness_arm="news-archive-A"),
    ]
    budget = ResourceBudget(money_limit=2.00, token_limit=120_000, call_limit=20, time_limit_seconds=600,
                            money_spent=0.80, tokens_spent=45_000, calls_spent=7, seconds_elapsed=240)
    _hr("6. Three candidate research actions and the budget")
    for a in actions:
        rows = "; ".join(f"{h}: {', '.join(f'{v:.2f}' for v in a.observation_model[h])}" for h in hyps.ids)
        print(f"  {a.action_id:<19} outcomes {list(a.outcomes)}")
        print(f"  {'':<19} P(outcome | h) = {rows}")
        print(f"  {'':<19} cost: money {a.cost.money:.2f}, tokens {a.cost.tokens:.0f}, calls {a.cost.calls:.0f}, "
              f"seconds {a.cost.seconds:.0f} ({a.cost.kind})")
    rem = budget.remaining()
    print(f"  Remaining budget: money {rem['money']:.2f}, tokens {rem['tokens']:.0f}, calls {rem['calls']:.0f}, "
          f"seconds {rem['seconds']:.0f} (each tracked separately).")
    filt = filter_affordable_actions(actions, budget, estimate_safety_factor=1.25)
    print(f"  Affordable with estimates padded x1.25: {filt['affordable']}")
    for u in filt["unaffordable"]:
        print(f"  Not affordable: {u['action_id']} ({', '.join(u['reasons'])}: 70000 x 1.25 = 87500 > 75000)")

    # 8. Monte Carlo propagation of calibration uncertainty, through the JSON tool interface.
    _hr("8. Monte Carlo uncertainty propagation (JSON tool calls)")
    num = {"op": "mul", "args": [0.30, {"var": "jobs_if_moved"}, {"var": "news_if_moved"}, {"var": "dir_if_moved"}]}
    alt = {"op": "mul", "args": [0.70, {"var": "jobs_if_not"}, {"var": "news_if_not"}, {"var": "dir_if_not"}]}
    call = {"inputs": {"jobs_if_moved": {"distribution": "beta", "alpha": 121, "beta": 31},
                       "jobs_if_not": {"distribution": "beta", "alpha": 16, "beta": 136},
                       "news_if_moved": {"distribution": "beta", "alpha": 71, "beta": 31},
                       "news_if_not": {"distribution": "beta", "alpha": 21, "beta": 81},
                       "dir_if_moved": {"distribution": "beta", "alpha": 36, "beta": 66},
                       "dir_if_not": {"distribution": "beta", "alpha": 91, "beta": 11}},
            "model": {"op": "div", "args": [num, {"op": "add", "args": [num, alt]}]},
            "seed": 20251107, "batch_size": 20_000, "min_draws": 20_000, "max_draws": 400_000, "abs_tol": 0.0005}
    r = run_tool("propagate_uncertainty", call)["result"]
    corr = r["extra"]["spearman_rank_correlation_with_output"]
    top = max(corr, key=lambda k: abs(corr[k] or 0.0))
    print("  (a) The applied likelihoods were estimated from fictional labelled counts, so each is given a Beta")
    print("      distribution and the posterior P(moved) is recomputed for every draw.")
    print(f"  Mean posterior P(moved) {r['mean']:.4f}; 90% interval across calibration uncertainty "
          f"[{r['outcome_interval'][0]:.3f}, {r['outcome_interval'][1]:.3f}].")
    print(f"  Monte Carlo standard error of the mean {r['mc_standard_error']:.5f} after {r['n_draws']} draws "
          f"({r['stopping_reason']}, seed {r['seed']}).")
    print("  The interval is uncertainty in the posterior caused by uncertain likelihoods; the standard error is "
          "simulation noise only.")
    print(f"  Input with the strongest rank correlation with the posterior: {top} ({corr[top]:+.2f}).")
    pe = run_tool("probability_of_event", {
        "inputs": {"tokens": {"distribution": "lognormal", "mu": math.log(70_000), "sigma": 0.25}},
        "event": {"op": "gt", "args": [{"var": "tokens"}, 75_000]}, "seed": 7, "max_draws": 200_000})["result"]
    print(f"  (b) If search-archive's token use is lognormal around its 70k estimate, P(it exceeds the 75k tokens "
          f"left) = {pe['mean']:.3f}")
    print(f"      (Jeffreys interval for Monte Carlo error [{pe['mean_numerical_interval'][0]:.3f}, "
          f"{pe['mean_numerical_interval'][1]:.3f}]); this is why estimates are padded and never treated as bounds.")

    _hr("9. Action recommendation")
    rank_eig = rank_research_actions(hyps, actions, belief=post, budget=budget, estimate_safety_factor=1.25, seed=11)
    print("  (a) Factual research without a utility model: information gain, with costs kept separate")
    _print_ranking(rank_eig, with_value=False)
    utility = [[10.0, -20.0], [-20.0, 10.0], [2.0, 2.0]]
    decisions = ["state_moved", "state_not_moved", "state_uncertain"]
    print("  (b) With a fictional utility model: stating the right answer +10, the wrong one -20, 'uncertain' +2;")
    print("      each action's cost is also given in these utility units, so net value can be computed.")
    rec = recommend_next_action(hyps, post, actions, budget, utility=utility, decision_ids=decisions,
                                estimate_safety_factor=1.25, seed=11)
    _print_ranking(rec.ranking, with_value=True)
    print(f"  Recommended next action: {rec.recommended_action_id}")

    _hr("10. Stopping assessment")
    _print_stop(rec.stop_assessment)

    _hr("Round 2 (fictional result): the filing confirms the move")
    filing = Evidence(evidence_id="ev-filing-01", source="fictional-companies-registry",
                      provenance_group="registry-filing", likelihood_model="categorical", likelihood_basis=cal,
                      likelihood_justification="Observation model of action 'retrieve-filing'.",
                      likelihoods={"moved": 0.85, "not_moved": 0.02},
                      description="Primary filing confirms the new registered office.")
    post2 = assess_evidence(hyps, evidence + [filing])
    budget2 = ResourceBudget(money_limit=2.00, token_limit=120_000, call_limit=20, time_limit_seconds=600,
                             money_spent=1.30, tokens_spent=53_000, calls_spent=9, seconds_elapsed=270)
    rec2 = recommend_next_action(hyps, post2, actions[1:], budget2, utility=utility, decision_ids=decisions,
                                 estimate_safety_factor=1.25, seed=12)
    lo2, hi2 = post2.prior_sensitivity["contamination_bounds"]["moved"]
    print(f"  Posterior P(moved) = {post2.posterior_dict()['moved']:.4f} ({post2.independent_groups_used} groups; "
          f"contamination bounds [{lo2:.4f}, {hi2:.4f}]).")
    _print_ranking(rec2.ranking, with_value=True)
    _print_stop(rec2.stop_assessment)
    print("  Caveats reported with the answer:")
    for c in rec2.stop_assessment.caveats:
        print(f"    - {c}")

    _hr("Thompson sampling over observed search usefulness (JSON tool calls)")
    arms = [{"arm_id": "news-archive-A", "alpha": 7, "beta": 15, "n_successes": 6, "n_failures": 14},
            {"arm_id": "news-archive-B", "alpha": 10, "beta": 7, "n_successes": 9, "n_failures": 6},
            {"arm_id": "registry-api", "alpha": 13, "beta": 4, "n_successes": 12, "n_failures": 3}]
    print("  Beliefs are Beta(1, 1) priors plus fictional labelled outcomes of past searches.")
    upd = run_tool("record_usefulness_outcome", {"arm": arms[1], "useful": True,
                                                 "outcome_source": "independent_human_label"})
    print(f"  Labelled success recorded for news-archive-B -> alpha {upd['result']['alpha']:g}, "
          f"beta {upd['result']['beta']:g}.")
    bad = run_tool("record_usefulness_outcome", {"arm": arms[1], "useful": True, "outcome_source": "simulated"})
    print(f"  A 'simulated' success is refused: {bad['error']['code']}.")
    ts = run_tool("thompson_select", {"arms": [arms[0], upd["result"], arms[2]], "seed": 5})["result"]
    pb = ", ".join(f"{k} {v:.2f}" for k, v in ts["probability_best_estimate"].items())
    print(f"  Thompson draw selects {ts['selected_arm_id']}; estimated P(best): {pb}.")

    _hr("Raw JSON tool call (strict JSON in and out)")
    request = json.dumps({"tool": "expected_information_gain",
                          "arguments": {"prior": [0.8235, 0.1765],
                                        "observation_likelihoods": [[0.05, 0.95], [0.30, 0.70]],
                                        "outcomes": ["cancellation_report_found", "none_found"]}})
    print(f"  request : {request}")
    reply = json.loads(run_tool_json(request))
    print(f"  result  : ok={reply['ok']}, EIG = {reply['result']['expected_information_gain_bits']:.4f} bits, "
          f"method = {reply['result']['method']}")

    print("\nNote: these calculations are only as good as their inputs. Whether they improve the LLM's answer "
          "accuracy must be established by evaluation on labelled tasks; correct inference arithmetic alone does "
          "not establish that improvement.")


_SELF_CHECKS: List[Tuple[str, Callable[[], None]]] = []


def _self_check(name: str) -> Callable[[Callable[[], None]], Callable[[], None]]:
    def deco(fn: Callable[[], None]) -> Callable[[], None]:
        _SELF_CHECKS.append((name, fn))
        return fn
    return deco


def _expect(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def _close(a: float, b: float, tol: float, msg: str) -> None:
    if a is None or b is None or not abs(a - b) <= tol:
        raise AssertionError(f"{msg}: {a!r} vs {b!r} (tolerance {tol})")


def _expect_raises(exc: type, fn: Callable[[], Any], msg: str) -> None:
    try:
        fn()
    except exc:
        return
    raise AssertionError(f"{msg}: expected {exc.__name__}")


@_self_check("Posterior matches Bayes' theorem (binary, categorical, log space)")
def _check_analytic() -> None:
    exact = 0.01 * 0.9 / (0.01 * 0.9 + 0.99 * 0.05)
    _close(update_binary_posterior(0.01, 0.9 / 0.05).posterior[0], exact, 1e-12, "binary")
    r = update_categorical_posterior([0.01, 0.99], [0.9, 0.05])
    _close(r.posterior[0], exact, 1e-12, "categorical")
    _close(r.log_marginal_likelihood, math.log(0.01 * 0.9 + 0.99 * 0.05), 1e-12, "log evidence")
    prior = np.array([0.5, 0.3, 0.2])
    lik = np.array([[0.2, 0.6, 0.9], [0.5, 0.5, 0.1]])
    expect = prior * lik.prod(axis=0)
    expect /= expect.sum()
    _expect(np.allclose(update_categorical_posterior(prior, lik).posterior, expect, rtol=0, atol=1e-12),
            "three hypotheses")
    many = np.tile([1e-5, 2e-5], (1000, 1))   # the linear-space product underflows to 0
    r = update_categorical_posterior([0.5, 0.5], many, sensitivity_epsilon=None)
    _close(r.binary["posterior_log_odds"], 1000 * math.log(0.5), 1e-6, "log-space stability")
    _close(r.posterior[1], 1.0, 1e-12, "dominant hypothesis")


@_self_check("Beta-Bernoulli update, credible interval and predictive")
def _check_beta() -> None:
    b = update_beta_bernoulli(7, 3, outcome_source="independent_human_label")
    _expect((b.alpha, b.beta) == (8.0, 4.0), "posterior parameters")
    _close(b.mean, 2 / 3, 1e-12, "mean")
    lo, hi = stats.beta.ppf([0.025, 0.975], 8, 4)
    _close(b.credible_interval[0], float(lo), 1e-12, "lower bound")
    _close(b.credible_interval[1], float(hi), 1e-12, "upper bound")
    _close(b.predictive_next_success, 2 / 3, 1e-12, "predictive")
    _close(posterior_predictive(b, n_future=2)["pmf_number_of_successes"][2], 8 * 9 / (12 * 13), 1e-12,
           "beta-binomial")
    _expect_raises(UnjustifiedInputError, lambda: update_beta_bernoulli(5, 0, outcome_source="simulated"),
                   "simulated outcomes")
    bel = record_usefulness_outcome(UsefulnessBelief("arm"), True, outcome_source="verified_against_ground_truth")
    _expect((bel.alpha, bel.beta, bel.n_successes) == (2.0, 1.0, 1), "usefulness update")
    _expect_raises(UnjustifiedInputError, lambda: record_usefulness_outcome(
        UsefulnessBelief("arm"), True, outcome_source="llm_self_rating"), "LLM self-rating")


@_self_check("Duplicate, dependent and unjustified evidence is not double-counted")
def _check_dupes() -> None:
    hyps = HypothesisSet.from_priors({"A": 0.5, "B": 0.5})
    cal = LikelihoodBasis.CALIBRATED_ON_LABELLED_DATA

    def ev(eid: str, group: str, la: float, lb: float, **kw: Any) -> Evidence:
        return Evidence(evidence_id=eid, source="test", provenance_group=group, likelihood_model="categorical",
                        likelihood_basis=cal, likelihoods={"A": la, "B": lb}, **kw)

    llm = Evidence(evidence_id="e5", source="llm", provenance_group="g5", likelihood_model="categorical",
                   likelihood_basis="llm_verbal_confidence", likelihoods={"A": 0.9, "B": 0.1},
                   llm_stated_confidence=0.9)
    items = [ev("e1", "g1", 0.8, 0.2), ev("e1", "g1", 0.8, 0.2), ev("e2", "g1", 0.6, 0.3),
             ev("e3", "g3", 0.3, 0.5, content_fingerprint="abc"), ev("e4", "g4", 0.3, 0.5, content_fingerprint="abc"),
             llm]
    r = assess_evidence(hyps, items)
    _expect(r.applied_evidence_ids == ["e2", "e3"], f"applied {r.applied_evidence_ids}")
    reasons = {(x.evidence_id, x.reason) for x in r.excluded}
    _expect(reasons == {("e1", "duplicate_evidence_id"), ("e4", "duplicate_content"),
                        ("e1", "shared_provenance_one_per_group")}, f"excluded {reasons}")
    _expect([(x.evidence_id, x.reason) for x in r.recorded_only] ==
            [("e5", "llm_verbal_confidence_not_a_likelihood")], "LLM confidence recorded only")
    ref = update_categorical_posterior([0.5, 0.5], [[0.6, 0.3], [0.3, 0.5]])
    _expect(np.allclose(r.posterior, ref.posterior, rtol=0, atol=1e-12), "posterior uses each observation once")
    r2 = assess_evidence(hyps, [ev("e1", "g1", 0.8, 0.2, designated=True), ev("e2", "g1", 0.6, 0.3)])
    _expect(r2.applied_evidence_ids == ["e1"], "designated observation used")
    joint = ProvenanceGroup("g1", joint_evidence_ids=("e1", "e2"), joint_likelihoods={"A": 0.5, "B": 0.05},
                            joint_likelihood_basis=cal)
    r3 = assess_evidence(hyps, items[:4], provenance_groups=[joint])
    _close(r3.posterior[0], (0.5 * 0.3) / (0.5 * 0.3 + 0.05 * 0.5), 1e-12, "joint likelihood applied once")
    r4 = assess_evidence(hyps, items[:4], already_applied_ids=["e3"])
    _expect(("e3", "already_applied") in {(x.evidence_id, x.reason) for x in r4.excluded}, "already applied")
    r5 = assess_evidence(hyps, [llm])
    _expect(r5.posterior == [0.5, 0.5], "LLM confidence leaves the posterior unchanged")


@_self_check("Impossible evidence is rejected explicitly")
def _check_impossible() -> None:
    _expect_raises(ImpossibleEvidenceError, lambda: update_categorical_posterior([0.5, 0.5], [0.0, 0.0]), "all zero")
    _expect_raises(ImpossibleEvidenceError, lambda: update_categorical_posterior([1.0, 0.0], [0.0, 0.7]),
                   "only the zero-prior hypothesis allows it")
    _expect_raises(ImpossibleEvidenceError, lambda: update_binary_posterior(1.0, 0.0), "certain prior, LR 0")
    _expect_raises(ImpossibleEvidenceError,
                   lambda: update_categorical_posterior([0.5, 0.5], [[0.0, 0.4], [0.3, 0.0]]), "jointly impossible")
    resp = run_tool("update_categorical_posterior", {"prior": [0.5, 0.5], "likelihoods": [0, 0]})
    _expect(not resp["ok"] and resp["error"]["code"] == "impossible_evidence", "dispatcher error code")
    r = update_categorical_posterior([0.5, 0.5], [0.0, 0.4])
    _expect(r.posterior == [0.0, 1.0] and any("eliminated" in w for w in r.warnings), "elimination warning")


@_self_check("Seeded simulations are reproducible")
def _check_seed() -> None:
    def s(rng: np.random.Generator, n: int) -> np.ndarray:
        return rng.normal(0.0, 1.0, n)
    a = monte_carlo_expectation(s, np.exp, seed=123, max_draws=50_000)
    b = monte_carlo_expectation(s, np.exp, seed=123, max_draws=50_000)
    c = monte_carlo_expectation(s, np.exp, seed=124, max_draws=50_000)
    _expect(a.mean == b.mean and a.quantiles == b.quantiles, "same seed, same result")
    _expect(a.mean != c.mean, "different seed, different result")
    args = {"inputs": {"x": {"distribution": "gamma", "shape": 2.0, "scale": 1.5}},
            "model": {"op": "sqrt", "args": [{"var": "x"}]}, "seed": 99, "max_draws": 20_000}
    _expect(run_tool("propagate_uncertainty", args) == run_tool("propagate_uncertainty", args), "JSON tool")
    lik = [[0.7, 0.3], [0.2, 0.8]]
    _expect(expected_information_gain([0.5, 0.5], lik, method="monte_carlo", seed=5) ==
            expected_information_gain([0.5, 0.5], lik, method="monte_carlo", seed=5), "EIG Monte Carlo")
    arms = [UsefulnessBelief("a", 2, 3), UsefulnessBelief("b", 3, 2)]
    _expect(thompson_select(arms, seed=8) == thompson_select(arms, seed=8), "Thompson sampling")


@_self_check("Monte Carlo agrees with analytical expectations")
def _check_mc() -> None:
    est = monte_carlo_expectation(lambda rng, n: rng.normal(1.0, 2.0, n), lambda x: x ** 2, seed=7,
                                  max_draws=1_000_000, rel_tol=0.005)
    _expect(abs(est.mean - 5.0) <= 4 * est.mc_standard_error, f"E[X^2] = {est.mean}")
    _expect(est.stopping_reason == "precision_target_met", "adaptive stop")
    r = run_tool("monte_carlo_expectation", {"distribution": {"distribution": "lognormal", "mu": 0.0, "sigma": 0.5},
                                             "seed": 3, "max_draws": 400_000})["result"]
    _expect(abs(r["mean"] - math.exp(0.125)) <= 4 * r["mc_standard_error"], "lognormal mean")
    p = probability_of_event(lambda rng, n: rng.standard_normal(n), lambda z: z > 1.5, seed=11, max_draws=400_000)
    _expect(abs(p.mean - float(stats.norm.sf(1.5))) <= 4 * p.mc_standard_error, "event probability")
    rare = probability_of_event(lambda rng, n: rng.random(n), lambda u: u < 0.0, seed=1, max_draws=50_000,
                                abs_tol=1e-3)
    _expect(rare.mean == 0.0 and rare.mean_numerical_interval[1] > 0.0, "zero count keeps a positive upper bound")
    cmp = compare_alternatives(lambda rng, n: rng.normal(0.0, 1.0, n), {"a": lambda x: x, "b": lambda x: x + 0.1},
                               seed=2, max_draws=10_000)
    d = cmp["differences_from_best"]["a"]
    _expect(cmp["best_by_expected_outcome"] == "b", "best alternative")
    _close(d["mean_advantage_of_best"], 0.1, 1e-9, "common random numbers")
    _expect(d["mc_standard_error"] < 1e-9, "paired difference has no noise")


@_self_check("Information gain and value of information")
def _check_eig() -> None:
    _close(expected_information_gain([0.5, 0.5], [[1, 0], [0, 1]])["expected_information_gain_bits"], 1.0, 1e-12,
           "perfect test = 1 bit")
    _close(expected_information_gain([0.5, 0.5], [[0.5, 0.5], [0.5, 0.5]])["expected_information_gain_bits"], 0.0,
           1e-12, "uninformative test = 0 bits")
    prior = np.array([0.2, 0.5, 0.3])
    lik = np.array([[0.7, 0.2, 0.1], [0.1, 0.6, 0.3], [0.3, 0.3, 0.4]])
    joint = prior[:, None] * lik
    mi = float(np.sum(joint * np.log2(joint / (prior[:, None] * joint.sum(axis=0)[None, :]))))
    _close(expected_information_gain(prior, lik)["expected_information_gain_bits"], mi, 1e-12, "mutual information")
    mc = expected_information_gain(prior, lik, method="monte_carlo", n_samples=200_000, seed=1)
    _expect(abs(mc["expected_information_gain_bits"] - mi) <= 4 * mc["mc_standard_error"], "Monte Carlo EIG")
    pairs = np.einsum("ha,hb->hab", lik, lik).reshape(3, 9)
    _close(expected_information_gain(prior, lik, n_repeats=2)["expected_information_gain_bits"],
           expected_information_gain(prior, pairs)["expected_information_gain_bits"], 1e-12, "repeat enumeration")
    u = [[10.0, -20.0], [-20.0, 10.0], [2.0, 2.0]]
    perfect = expected_value_of_information([0.6, 0.4], [[1, 0], [0, 1]], u)
    _close(perfect["evsi"], perfect["evpi"], 1e-12, "EVSI of perfect information = EVPI")
    noisy = expected_value_of_information([0.6, 0.4], [[0.8, 0.2], [0.3, 0.7]], u, cost_in_utility_units=0.5)
    _close(noisy["evsi"], 1.2, 1e-12, "analytical EVSI")
    _close(noisy["net_value_of_information"], 0.7, 1e-12, "net value")
    mcv = expected_value_of_information([0.6, 0.4], [[0.8, 0.2], [0.3, 0.7]], u, method="monte_carlo",
                                        n_samples=200_000, seed=4)
    _expect(abs(mcv["evsi"] - 1.2) <= 4 * mcv["mc_standard_error"], "Monte Carlo EVSI")


@_self_check("Prior-sensitivity bounds are exact and robustness is flagged")
def _check_sensitivity() -> None:
    prior = np.array([0.6, 0.3, 0.1])
    lik = np.array([0.2, 0.5, 0.9])
    eps = 0.2
    s = prior_sensitivity(prior, np.log(lik), hypothesis_ids=["a", "b", "c"], epsilon=eps)
    qs = list(np.random.default_rng(0).dirichlet(np.ones(3), size=2000)) + list(np.eye(3))
    for q in qs:
        pi = (1 - eps) * prior + eps * q
        post = pi * lik / (pi @ lik)
        for i, h in enumerate("abc"):
            lo, hi = s["contamination_bounds"][h]
            _expect(lo - 1e-12 <= post[i] <= hi + 1e-12, "posterior inside the bounds")
    for i, h in enumerate("abc"):
        pi = (1 - eps) * prior + eps * np.eye(3)[i]
        _close(float((pi * lik / (pi @ lik))[i]), s["contamination_bounds"][h][1], 1e-12, "upper bound attained")
    fragile = prior_sensitivity([0.9, 0.1], np.log([0.3, 0.6]))
    _expect(fragile["conclusion_robust_to_prior"] is False, "prior-driven conclusion flagged")


@_self_check("Budget filtering per resource, bounds versus estimates, and stopping")
def _check_budget() -> None:
    budget = ResourceBudget(money_limit=1.0, token_limit=10_000, money_spent=0.4, tokens_spent=2_000)
    acts = [ResearchAction("fits", cost=ResourceCost(money=0.5, tokens=1_000, kind="upper_bound")),
            ResearchAction("too-dear", cost=ResourceCost(money=0.7, tokens=1_000, kind="upper_bound")),
            ResearchAction("padded-estimate", cost=ResourceCost(money=0.55, tokens=1_000, kind="estimate")),
            ResearchAction("unknown-tokens", cost=ResourceCost(money=0.1, kind="upper_bound")),
            ResearchAction("too-many-tokens", cost=ResourceCost(money=0.1, tokens=9_000, kind="upper_bound"))]
    f = filter_affordable_actions(acts, budget, estimate_safety_factor=1.2)
    reasons = {u["action_id"]: u["reasons"] for u in f["unaffordable"]}
    _expect(f["affordable"] == ["fits"], f"affordable {f['affordable']}")
    _expect(reasons == {"too-dear": ["money_exceeds_remaining"], "padded-estimate": ["money_exceeds_remaining"],
                        "unknown-tokens": ["tokens_cost_unknown_for_limited_resource"],
                        "too-many-tokens": ["tokens_exceeds_remaining"]}, f"reasons {reasons}")
    _expect(f["per_action"]["fits"]["compliance"] == "within_limits_if_supplied_upper_bounds_are_correct", "bound")
    g = filter_affordable_actions(acts, budget, allow_unknown_costs=True)
    _expect(set(g["affordable"]) == {"fits", "padded-estimate", "unknown-tokens"}, "unpadded and unknown allowed")
    _expect(g["per_action"]["padded-estimate"]["compliance"] == "estimated_only_not_guaranteed", "estimate flagged")
    _expect("padded-estimate" not in filter_affordable_actions(acts, budget, require_upper_bounds=True)["affordable"],
            "upper bounds required")
    hyps = HypothesisSet.from_priors({"A": 0.5, "B": 0.5})
    probe = ResearchAction("probe", outcomes=("pos", "neg"), observation_model={"A": (0.9, 0.1), "B": (0.2, 0.8)},
                           observation_model_basis="calibrated_on_labelled_data",
                           cost=ResourceCost(calls=1, kind="upper_bound"))
    rec = recommend_next_action(hyps, assess_evidence(hyps, []), [probe], ResourceBudget(call_limit=5, calls_spent=5))
    sa = rec.stop_assessment
    _expect(rec.recommended_action_id is None and sa.should_stop, "stops when the budget is exhausted")
    _expect({"budget_exhausted", "no_affordable_action", "more_evidence_required"} <= set(sa.reasons), "reasons")
    _expect(sa.outcome == "stop_report_insufficient_evidence", "insufficient evidence reported")
    blind = ResearchAction("blind", cost=ResourceCost(calls=1, kind="upper_bound"))
    rec2 = recommend_next_action(hyps, assess_evidence(hyps, []), [blind], ResourceBudget(call_limit=5))
    _expect("missing_observation_model" in rec2.stop_assessment.reasons, "missing observation model")


@_self_check("JSON dispatcher is allowlisted, strict and finite")
def _check_json() -> None:
    _expect(run_tool("eval", {})["error"]["code"] == "unknown_tool", "unknown tool")
    _expect(run_tool("update_binary_posterior", {"prior": float("nan"), "likelihood_ratios": [2.0]})["error"]["code"]
            == "non_finite_input", "NaN rejected")
    _expect(run_tool("update_binary_posterior", {"prior": True, "likelihood_ratios": [2.0]})["error"]["code"]
            == "invalid_arguments", "boolean is not a number")
    _expect(run_tool("update_binary_posterior", {"prior": 0.5, "likelihood_ratios": [2.0], "extra": 1})["error"]["code"]
            == "invalid_arguments", "unknown field rejected")
    reply = json.loads(run_tool_json('{"tool": "update_binary_posterior", '
                                     '"arguments": {"prior": 0.5, "likelihood_ratios": [Infinity]}}'))
    _expect(reply["error"]["code"] == "non_finite_input", "Infinity literal rejected")
    normal = {"x": {"distribution": "normal", "mean": 0, "sd": 1}}
    _expect(run_tool("propagate_uncertainty", {"inputs": normal, "model": {"op": "__import__", "args": ["os"]}})
            ["error"]["code"] == "invalid_arguments", "unlisted operation rejected")
    zero_div = {"op": "div", "args": [1, {"op": "sub", "args": [{"var": "x"}, {"var": "x"}]}]}
    _expect(run_tool("propagate_uncertainty", {"inputs": normal, "model": zero_div, "seed": 1, "max_draws": 1_000})
            ["error"]["code"] == "non_finite_result", "non-finite result rejected")
    _expect(run_tool("propagate_uncertainty", {"inputs": {"x": {"distribution": "normal", "mean": 0, "sd": -1}},
                                               "model": {"var": "x"}})["error"]["code"] == "out_of_range",
            "invalid distribution parameter")
    ok = run_tool("update_binary_posterior", {"prior": 0.5, "likelihood_ratios": [0.0]})
    json.dumps(ok, allow_nan=False)
    _expect(ok["ok"] and ok["result"]["binary"]["log_bayes_factor"] is None, "infinities emitted as null")
    defs = tool_definitions()
    _expect({d["name"] for d in defs} == set(_TOOLS), "every tool has a definition")
    json.dumps(defs, allow_nan=False)


def run_self_checks(verbose: bool = True) -> bool:
    """Run the focused self-checks; return True if all pass."""
    results = []
    for name, fn in _SELF_CHECKS:
        try:
            fn()
            results.append((name, True, ""))
        except Exception as exc:  # report every failure, keep going
            results.append((name, False, f"{type(exc).__name__}: {exc}"))
    if verbose:
        print("\n" + "=" * 78)
        print("Self-checks")
        print("=" * 78)
        for name, ok, err in results:
            print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"\n         {err}" if err else ""))
        passed = sum(ok for _, ok, _ in results)
        print(f"  {passed}/{len(results)} checks passed.")
    return all(ok for _, ok, _ in results)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Aureom.AI Bayesian inference and Monte Carlo tools.")
    parser.add_argument("--demo", action="store_true", help="run the demonstration")
    parser.add_argument("--self-check", action="store_true", help="run the self-checks")
    parser.add_argument("--tools", action="store_true", help="print machine-readable tool definitions")
    parser.add_argument("--api-format", action="store_true", help="with --tools: only name, description, input_schema")
    parser.add_argument("--call", metavar="TOOL", help="run one tool with --args and print the JSON reply")
    parser.add_argument("--args", default="{}", help="JSON object of tool arguments for --call")
    ns = parser.parse_args(argv)
    if ns.tools:
        print(json.dumps(tool_definitions(api_format=ns.api_format), indent=2))
        return 0
    if ns.call:
        reply = run_tool_json('{"tool": ' + json.dumps(ns.call) + ', "arguments": ' + ns.args + "}")
        print(json.dumps(json.loads(reply), indent=2))
        return 0 if json.loads(reply)["ok"] else 2
    do_demo = ns.demo or not ns.self_check
    do_checks = ns.self_check or not ns.demo
    if do_demo:
        run_demo()
    ok = run_self_checks() if do_checks else True
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
