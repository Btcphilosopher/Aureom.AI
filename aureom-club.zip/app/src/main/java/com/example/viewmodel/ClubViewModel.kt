package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.ClubRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

sealed class Screen {
    object Home : Screen()
    object Fixtures : Screen()
    data class FixtureDetail(val fixtureId: String) : Screen()
    object Tickets : Screen()
    data class SeatSelection(val fixtureId: String) : Screen()
    data class Checkout(val fixtureId: String, val stand: String, val block: String, val seats: List<String>, val totalPricePence: Int) : Screen()
    data class Payment(val orderId: String, val totalPricePence: Int, val fixtureId: String, val seats: List<String>, val stand: String) : Screen()
    object TicketWallet : Screen()
    data class TicketDetail(val ticketId: String) : Screen()
    object StaffScanner : Screen()
    object Club : Screen()
    object Shop : Screen()
    object Profile : Screen()
    object AdminConsole : Screen()
    object DemoWalkthrough : Screen()
}

class ClubViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ClubRepository

    init {
        val dao = AppDatabase.getDatabase(application).clubDao()
        repository = ClubRepository(dao)
        viewModelScope.launch {
            repository.seedInitialData()
        }
    }

    val fixtures: StateFlow<List<FixtureEntity>> = repository.fixtures
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<TicketEntity>> = repository.tickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memberships: StateFlow<List<MembershipEntity>> = repository.memberships
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val merchandise: StateFlow<List<MerchandiseEntity>> = repository.merchandise
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val announcements: StateFlow<List<AnnouncementEntity>> = repository.announcements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.auditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _selectedSportFilter = MutableStateFlow("All")
    val selectedSportFilter: StateFlow<String> = _selectedSportFilter.asStateFlow()

    // Scanner state
    private val _scanResult = MutableStateFlow<ScanResultState?>(null)
    val scanResult: StateFlow<ScanResultState?> = _scanResult.asStateFlow()

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun setSportFilter(sport: String) {
        _selectedSportFilter.value = sport
    }

    fun simulatePaymentAndIssueTickets(fixtureId: String, stand: String, seats: List<String>, totalPricePence: Int) {
        viewModelScope.launch {
            val fixture = repository.fixtures.first().find { it.id == fixtureId }
            val fixtureTitle = fixture?.title ?: "Pennine Fixture"
            val venue = fixture?.venue ?: "Holconbe Park"

            val newTickets = seats.mapIndexed { index, seat ->
                val ticketId = "TIX-" + (1000..9999).random()
                TicketEntity(
                    id = ticketId,
                    fixtureId = fixtureId,
                    fixtureTitle = fixtureTitle,
                    venue = venue,
                    stand = stand,
                    block = "Block B",
                    row = "Row 4",
                    seatNumber = seat,
                    category = "Adult Member",
                    pricePence = totalPricePence / seats.size,
                    status = "ISSUED",
                    qrSignature = "PAC-SIG-$ticketId-${System.currentTimeMillis()}",
                    purchaserName = "Arthur Pendelton",
                    attendeeName = if (index == 0) "Arthur Pendelton" else "Guest Supporter",
                    purchaseDate = System.currentTimeMillis()
                )
            }

            for (t in newTickets) {
                repository.insertTicket(t)
            }

            repository.insertAuditLog(
                AuditLogEntity(
                    id = UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    action = "PAYMENT_SUCCESS_TICKETS_ISSUED",
                    details = "Successfully processed payment of £${String.format("%.2f", totalPricePence / 100.0)} for ${seats.size} tickets in $stand for $fixtureTitle.",
                    staffEmail = "system@aureomclub.co.uk"
                )
            )

            navigateTo(Screen.TicketWallet)
        }
    }

    fun scanTicketCode(ticketIdOrSig: String) {
        viewModelScope.launch {
            val allTicks = tickets.first()
            val match = allTicks.find { it.id.equals(ticketIdOrSig, ignoreCase = true) || it.qrSignature.equals(ticketIdOrSig, ignoreCase = true) }
            if (match == null) {
                _scanResult.value = ScanResultState.Invalid("Invalid Signature / Ticket Not Found")
                return@launch
            }
            if (match.status == "USED") {
                _scanResult.value = ScanResultState.AlreadyUsed(match)
                return@launch
            }
            if (match.status == "REFUNDED" || match.status == "CANCELLED") {
                _scanResult.value = ScanResultState.CancelledOrRefunded(match)
                return@launch
            }

            // Mark as used atomically
            repository.updateTicketStatus(match.id, "USED")
            repository.insertAuditLog(
                AuditLogEntity(
                    id = UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    action = "GATE_ENTRY_SUCCESS",
                    details = "Ticket ${match.id} (${match.seatNumber}) successfully scanned and redeemed at Holconbe Park Turnstile 3.",
                    staffEmail = "scanner.operator@aureomclub.co.uk"
                )
            )
            _scanResult.value = ScanResultState.Valid(match)
        }
    }

    fun clearScanResult() {
        _scanResult.value = null
    }

    fun transferTicket(ticketId: String, recipientEmail: String) {
        viewModelScope.launch {
            repository.updateTicketStatus(ticketId, "TRANSFERRED")
            repository.insertAuditLog(
                AuditLogEntity(
                    id = UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    action = "TICKET_TRANSFERRED",
                    details = "Ticket $ticketId successfully transferred to $recipientEmail. Previous credential invalidated.",
                    staffEmail = "arthur@ahyx.org"
                )
            )
        }
    }

    fun requestRefund(ticketId: String) {
        viewModelScope.launch {
            repository.updateTicketStatus(ticketId, "REFUNDED")
            repository.insertAuditLog(
                AuditLogEntity(
                    id = UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    action = "REFUND_PROCESSED",
                    details = "Refund approved and processed for ticket $ticketId. Funds returned to original payment card.",
                    staffEmail = "finance@aureomclub.co.uk"
                )
            )
        }
    }

    fun publishAnnouncement(title: String, message: String, category: String) {
        viewModelScope.launch {
            val ann = AnnouncementEntity(
                id = "ANN-" + (100..999).random(),
                title = title,
                message = message,
                category = category,
                timestamp = System.currentTimeMillis(),
                targetGroup = "ALL",
                isRead = false
            )
            repository.insertAnnouncement(ann)
            repository.insertAuditLog(
                AuditLogEntity(
                    id = UUID.randomUUID().toString(),
                    timestamp = System.currentTimeMillis(),
                    action = "ANNOUNCEMENT_PUBLISHED",
                    details = "Staff published announcement: $title",
                    staffEmail = "staff@aureomclub.co.uk"
                )
            )
        }
    }
}

sealed class ScanResultState {
    data class Valid(val ticket: TicketEntity) : ScanResultState()
    data class AlreadyUsed(val ticket: TicketEntity) : ScanResultState()
    data class CancelledOrRefunded(val ticket: TicketEntity) : ScanResultState()
    data class Invalid(val reason: String) : ScanResultState()
}
