package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TicketEntity
import com.example.viewmodel.ClubViewModel
import com.example.viewmodel.Screen

@Composable
fun TicketWalletScreen(
    viewModel: ClubViewModel,
    tickets: List<TicketEntity>
) {
    var selectedTicket by remember { mutableStateOf<TicketEntity?>(null) }
    var showTransferDialog by remember { mutableStateOf(false) }
    var transferEmail by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Digital Ticket Wallet",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
            )
            IconButton(onClick = { viewModel.navigateTo(Screen.StaffScanner) }) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = "Staff Scanner Mode", tint = MaterialTheme.colorScheme.primary)
            }
        }

        if (tickets.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.ConfirmationNumber, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No tickets in your wallet yet.", style = MaterialTheme.typography.bodyLarge)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tickets) { ticket ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedTicket = ticket }
                            .testTag("ticket_card_${ticket.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Badge(
                                    containerColor = when (ticket.status) {
                                        "ISSUED" -> MaterialTheme.colorScheme.primaryContainer
                                        "USED" -> MaterialTheme.colorScheme.surfaceVariant
                                        else -> MaterialTheme.colorScheme.errorContainer
                                    }
                                ) {
                                    Text(ticket.status, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                                Text("£${String.format("%.2f", ticket.pricePence / 100.0)}", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(ticket.fixtureTitle, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("${ticket.venue} • ${ticket.stand} • ${ticket.seatNumber}", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp))
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { selectedTicket = ticket },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Show Pass", fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = { selectedTicket = ticket; showTransferDialog = true },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Transfer", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Ticket Detail & QR Dialog
    if (selectedTicket != null && !showTransferDialog) {
        AlertDialog(
            onDismissRequest = { selectedTicket = null },
            title = { Text(selectedTicket!!.fixtureTitle) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text("Holder: ${selectedTicket!!.attendeeName}", style = MaterialTheme.typography.titleMedium)
                    Text("${selectedTicket!!.stand} • ${selectedTicket!!.seatNumber}", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        modifier = Modifier.size(180.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                            Icon(Icons.Default.QrCode2, contentDescription = "QR Code", modifier = Modifier.size(140.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Signature: ${selectedTicket!!.qrSignature}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                Button(onClick = { selectedTicket = null }) {
                    Text("Close")
                }
            }
        )
    }

    // Transfer Dialog
    if (selectedTicket != null && showTransferDialog) {
        AlertDialog(
            onDismissRequest = { showTransferDialog = false; selectedTicket = null },
            title = { Text("Transfer Ticket to Supporter") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter recipient's registered email address:")
                    OutlinedTextField(
                        value = transferEmail,
                        onValueChange = { transferEmail = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (transferEmail.isNotBlank()) {
                            viewModel.transferTicket(selectedTicket!!.id, transferEmail)
                            showTransferDialog = false
                            selectedTicket = null
                            transferEmail = ""
                        }
                    }
                ) {
                    Text("Confirm Transfer")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTransferDialog = false; selectedTicket = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
