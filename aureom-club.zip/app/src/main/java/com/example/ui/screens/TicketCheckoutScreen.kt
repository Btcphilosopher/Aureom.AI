package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.ClubViewModel
import com.example.viewmodel.Screen

@Composable
fun TicketCheckoutScreen(
    viewModel: ClubViewModel,
    fixtureId: String,
    stand: String,
    block: String,
    seats: List<String>,
    subtotalPence: Int
) {
    val bookingFeePence = 150 // £1.50 booking fee
    val totalPence = subtotalPence + bookingFeePence

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateTo(Screen.SeatSelection(fixtureId)) }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Order Review & Hold",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        // Inventory Hold Timer Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Timer, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Temporary Inventory Hold Active", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer))
                    Text("Seats reserved for 04:59 minutes. Complete payment to secure tickets.", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f), fontSize = 13.sp))
                }
            }
        }

        // Summary Breakdown Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Ticket Details", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Divider()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Stand / Area:", style = MaterialTheme.typography.bodyMedium)
                    Text(stand, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Selected Seats:", style = MaterialTheme.typography.bodyMedium)
                    Text(seats.joinToString(", "), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Subtotal (${seats.size} tickets):", style = MaterialTheme.typography.bodyMedium)
                    Text("£${String.format("%.2f", subtotalPence / 100.0)}", style = MaterialTheme.typography.bodyMedium)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Club Booking & Processing Fee:", style = MaterialTheme.typography.bodyMedium)
                    Text("£${String.format("%.2f", bookingFeePence / 100.0)}", style = MaterialTheme.typography.bodyMedium)
                }
                Divider()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Amount (GBP):", style = MaterialTheme.typography.titleLarge.copy(color = MaterialTheme.colorScheme.primary))
                    Text("£${String.format("%.2f", totalPence / 100.0)}", style = MaterialTheme.typography.titleLarge.copy(color = MaterialTheme.colorScheme.primary))
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = {
                viewModel.navigateTo(Screen.Payment(
                    orderId = "ORD-" + (10000..99999).random(),
                    totalPricePence = totalPence,
                    fixtureId = fixtureId,
                    seats = seats,
                    stand = stand
                ))
            },
            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("proceed_to_payment_button")
        ) {
            Icon(Icons.Default.Lock, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Proceed to Secure Payment (£${String.format("%.2f", totalPence / 100.0)})", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}
