package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.ClubViewModel
import com.example.viewmodel.Screen

@Composable
fun SeatSelectionScreen(
    viewModel: ClubViewModel,
    fixtureId: String
) {
    var selectedStand by remember { mutableStateOf("Holconbe Stand") }
    val seatsList = remember { (1..12).map { "Seat $it" } }
    val selectedSeats = remember { mutableStateMapOf<String, Boolean>() }

    val standPrices = mapOf(
        "Holconbe Stand" to 2200, // £22.00
        "The Clough Terrace" to 1500, // £15.00
        "Boardroom Suite & Hospitality" to 4500 // £45.00
    )

    val currentPricePence = standPrices[selectedStand] ?: 2200

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Back Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateTo(Screen.Fixtures) }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Select Stand & Seats",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        // Stand Selector
        Text("Choose Admission Area / Stand", style = MaterialTheme.typography.titleMedium)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Holconbe Stand", "The Clough Terrace", "Boardroom Suite").forEach { stand ->
                FilterChip(
                    selected = selectedStand == stand,
                    onClick = { selectedStand = stand; selectedSeats.clear() },
                    label = { Text(stand, fontSize = 12.sp) }
                )
            }
        }

        // Pitch Indicator Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "PITCH DIRECTION ⚽",
                    style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                )
            }
        }

        Text("Select Available Seats (Block B, Row 4)", style = MaterialTheme.typography.titleMedium)

        // Seats Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(seatsList) { seat ->
                val isSelected = selectedSeats[seat] == true
                val isSold = seat == "Seat 3" || seat == "Seat 7" // Simulated occupied seat

                val bgCol = when {
                    isSold -> MaterialTheme.colorScheme.surfaceVariant
                    isSelected -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.surface
                }
                val txtCol = when {
                    isSold -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    isSelected -> MaterialTheme.colorScheme.onPrimary
                    else -> MaterialTheme.colorScheme.onSurface
                }

                Box(
                    modifier = Modifier
                        .height(55.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(bgCol)
                        .clickable(enabled = !isSold) {
                            if (isSelected) selectedSeats.remove(seat) else selectedSeats[seat] = true
                        }
                        .testTag("seat_button_$seat"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            if (isSold) Icons.Default.Block else Icons.Default.EventSeat,
                            contentDescription = null,
                            tint = txtCol,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(seat, style = MaterialTheme.typography.labelSmall.copy(color = txtCol, fontSize = 11.sp))
                    }
                }
            }
        }

        // Summary & Checkout CTA
        val chosenSeatsList = selectedSeats.keys.toList()
        val totalPence = chosenSeatsList.size * currentPricePence

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Selected: ${if (chosenSeatsList.isEmpty()) "None" else chosenSeatsList.joinToString(", ")}", style = MaterialTheme.typography.bodyMedium)
                    Text("Total: £${String.format("%.2f", totalPence / 100.0)}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                }
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        viewModel.navigateTo(Screen.Checkout(fixtureId, selectedStand, "Block B", chosenSeatsList, totalPence))
                    },
                    enabled = chosenSeatsList.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("proceed_checkout_button")
                ) {
                    Text("Proceed to Secure Checkout (${chosenSeatsList.size} seats)")
                }
            }
        }
    }
}
