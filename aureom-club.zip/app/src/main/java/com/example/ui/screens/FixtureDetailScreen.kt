package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FixtureEntity
import com.example.viewmodel.ClubViewModel
import com.example.viewmodel.Screen

@Composable
fun FixtureDetailScreen(
    viewModel: ClubViewModel,
    fixtureId: String,
    fixtures: List<FixtureEntity>
) {
    val fixture = fixtures.find { it.id == fixtureId } ?: fixtures.firstOrNull()

    if (fixture == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Fixture not found")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Back Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateTo(Screen.Fixtures) }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Fixture Details",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        // Main Fixture Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                        Text(fixture.competition, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                    }
                    Text(fixture.sport, style = MaterialTheme.typography.labelLarge.copy(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold))
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    fixture.title,
                    style = MaterialTheme.typography.headlineMedium.copy(fontSize = 22.sp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Divider()
                Spacer(modifier = Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Event, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Date & Time: ${fixture.dateString} at ${fixture.timeString}", style = MaterialTheme.typography.bodyLarge)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Venue: ${fixture.venue}", style = MaterialTheme.typography.bodyLarge)
                }
                if (fixture.broadcast != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tv, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Broadcast: ${fixture.broadcast}", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }

        // Matchday & Transport Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Matchday & Ground Instructions", style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp))
                Spacer(modifier = Modifier.height(8.dp))
                Text("• Turnstiles open 90 minutes before kick-off.", style = MaterialTheme.typography.bodyMedium)
                Text("• Bar & catering available in the Clough Pavilion.", style = MaterialTheme.typography.bodyMedium)
                Text("• Public transport: Skipton station shuttle bus runs every 15 mins.", style = MaterialTheme.typography.bodyMedium)
            }
        }

        // Action Buttons
        if (fixture.status != "COMPLETED") {
            Button(
                onClick = { viewModel.navigateTo(Screen.SeatSelection(fixture.id)) },
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("select_seats_action_button")
            ) {
                Icon(Icons.Default.ConfirmationNumber, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Select Tickets & Seats", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Final Result", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("${fixture.homeScore} - ${fixture.awayScore}", style = MaterialTheme.typography.displayLarge.copy(fontSize = 32.sp))
                    Text("Source: ${fixture.source}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
