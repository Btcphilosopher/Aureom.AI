package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PennineGold,
    onPrimary = PennineNavy,
    primaryContainer = PennineBurgundy,
    onPrimaryContainer = PennineIvory,
    secondary = PennineBurgundy,
    onSecondary = Color.White,
    background = PennineNavy,
    onBackground = PennineIvory,
    surface = PennineSurfaceDark,
    onSurface = PennineIvory
)

private val LightColorScheme = lightColorScheme(
    primary = PennineNavy,
    onPrimary = Color.White,
    primaryContainer = PennineBurgundy,
    onPrimaryContainer = Color.White,
    secondary = PennineBurgundy,
    onSecondary = Color.White,
    background = PennineIvory,
    onBackground = PennineNavy,
    surface = Color.White,
    onSurface = PennineNavy
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use custom club identity colors by default
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
