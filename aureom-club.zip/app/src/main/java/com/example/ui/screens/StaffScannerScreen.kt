package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.ClubViewModel
import com.example.viewmodel.ScanResultState
import com.example.viewmodel.Screen

@Composable
fun StaffScannerScreen(
    viewModel: ClubViewModel,
    scanResult: ScanResultState?
) {
    var ticketInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateTo(Screen.TicketWallet) }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Staff Turnstile Scanner Console",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Text("Scan Supporter QR Pass or Enter Ticket ID", style = MaterialTheme.typography.bodyLarge)

        OutlinedTextField(
            value = ticketInput,
            onValueChange = { ticketInput = it },
            label = { Text("Ticket ID or Signature (e.g. TIX-9988)") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                if (ticketInput.isNotBlank()) {
                    viewModel.scanTicketCode(ticketInput.trim())
                    ticketInput = ""
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("simulate_scan_button")
        ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Simulate Optical QR Scan")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Scan Result Feedback Display
        when (scanResult) {
            is ScanResultState.Valid -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("ADMISSION GRANTED ✓", style = MaterialTheme.typography.headlineMedium.copy(color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Holder: ${scanResult.ticket.attendeeName}", style = MaterialTheme.typography.titleMedium)
                        Text("${scanResult.ticket.stand} • ${scanResult.ticket.seatNumber}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            is ScanResultState.AlreadyUsed -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("REJECTED: ALREADY USED ⚠️", style = MaterialTheme.typography.headlineMedium.copy(color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("This ticket was already scanned and redeemed at turnstile.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            is ScanResultState.CancelledOrRefunded -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("REJECTED: CANCELLED / REFUNDED", style = MaterialTheme.typography.headlineMedium.copy(color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("This ticket has been cancelled or refunded.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            is ScanResultState.Invalid -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Error, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("INVALID SIGNATURE ❌", style = MaterialTheme.typography.headlineMedium.copy(color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(scanResult.reason, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            null -> {
                Text("Waiting for scan input...", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
            }
        }
    }
}
