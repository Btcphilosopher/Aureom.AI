package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.ClubViewModel

@Composable
fun PaymentScreen(
    viewModel: ClubViewModel,
    orderId: String,
    totalPricePence: Int,
    fixtureId: String,
    seats: List<String>,
    stand: String
) {
    var isProcessing by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(20.dp))
        Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        Text("Secure Payment Gateway", style = MaterialTheme.typography.headlineMedium)
        Text("Order ref: $orderId", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Payment Method", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                OutlinedTextField(
                    value = "•••• •••• •••• 4242 (Visa)",
                    onValueChange = {},
                    label = { Text("Saved Card") },
                    modifier = Modifier.fillMaxWidth(),
                    readOnly = true
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Expiry: 12/28", style = MaterialTheme.typography.bodyMedium)
                    Text("CVV: •••", style = MaterialTheme.typography.bodyMedium)
                }
                Divider()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Amount to Charge:", style = MaterialTheme.typography.titleMedium)
                    Text("£${String.format("%.2f", totalPricePence / 100.0)}", style = MaterialTheme.typography.titleLarge.copy(color = MaterialTheme.colorScheme.primary))
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        if (isProcessing) {
            CircularProgressIndicator()
            Text("Authorising payment & issuing encrypted tickets...", style = MaterialTheme.typography.bodyMedium)
        } else {
            Button(
                onClick = {
                    isProcessing = true
                    viewModel.simulatePaymentAndIssueTickets(fixtureId, stand, seats, totalPricePence)
                },
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("pay_now_button")
            ) {
                Icon(Icons.Default.Lock, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Pay £${String.format("%.2f", totalPricePence / 100.0)} Now", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
