package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.ClubViewModel
import com.example.viewmodel.Screen

@Composable
fun DemoWalkthroughScreen(viewModel: ClubViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateTo(Screen.Home) }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = "Demonstration & Test Suite",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
        }

        Text(
            "Execute and verify all 12 key ticketing and club operational flows:",
            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                DemoStepCard(
                    number = "1",
                    title = "Browse Fixtures & Select Match",
                    description = "View Pennine Athletic vs Yorkshire Wanderers at Holconbe Park.",
                    onClick = { viewModel.navigateTo(Screen.Fixtures) }
                )
            }
            item {
                DemoStepCard(
                    number = "2",
                    title = "Reserve Seats & Choose Stand",
                    description = "Select Holconbe Stand Block B seats with temporary hold.",
                    onClick = { viewModel.navigateTo(Screen.SeatSelection("FIX-001")) }
                )
            }
            item {
                DemoStepCard(
                    number = "3",
                    title = "Simulate Secure Payment",
                    description = "Process GBP payment via secure gateway with order recovery.",
                    onClick = { viewModel.navigateTo(Screen.Payment("ORD-8829", 4400, "FIX-001", listOf("Seat 12", "Seat 13"), "Holconbe Stand")) }
                )
            }
            item {
                DemoStepCard(
                    number = "4",
                    title = "Open Digital Ticket Wallet",
                    description = "Inspect issued passes with encrypted QR codes and signatures.",
                    onClick = { viewModel.navigateTo(Screen.TicketWallet) }
                )
            }
            item {
                DemoStepCard(
                    number = "5",
                    title = "Staff Turnstile Gate Scanner",
                    description = "Scan tickets, verify valid admissions, and test repeat scan rejection.",
                    onClick = { viewModel.navigateTo(Screen.StaffScanner) }
                )
            }
            item {
                DemoStepCard(
                    number = "6",
                    title = "Staff Administration Console",
                    description = "Monitor audit logs, publish matchday notices, and view financial reconciliation.",
                    onClick = { viewModel.navigateTo(Screen.AdminConsole) }
                )
            }
        }
    }
}

@Composable
fun DemoStepCard(number: String, title: String, description: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Text(number, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer))
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 15.sp))
                Text(description, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
            }
            IconButton(onClick = onClick) {
                Icon(Icons.Default.ArrowForward, contentDescription = "Run Step", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
