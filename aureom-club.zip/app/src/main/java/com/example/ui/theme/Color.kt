package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PennineNavy = Color(0xFF0F2038)
val PennineBurgundy = Color(0xFF7A1C2E)
val PennineGold = Color(0xFFD4AF37)
val PennineIvory = Color(0xFFF7F4EF)
val PennineSurfaceDark = Color(0xFF162840)
val PennineCardBg = Color(0xFFFFFFFF)
val PennineCardDarkBg = Color(0xFF1E3352)
val PennineGreenSuccess = Color(0xFF1B5E20)
val PennineRedError = Color(0xFFB71C1C)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
