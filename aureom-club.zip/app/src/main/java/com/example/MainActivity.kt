package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ClubViewModel
import com.example.viewmodel.Screen

class MainActivity : ComponentActivity() {
    private val viewModel: ClubViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
                val fixtures by viewModel.fixtures.collectAsStateWithLifecycle()
                val tickets by viewModel.tickets.collectAsStateWithLifecycle()
                val merchandise by viewModel.merchandise.collectAsStateWithLifecycle()
                val announcements by viewModel.announcements.collectAsStateWithLifecycle()
                val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()
                val scanResult by viewModel.scanResult.collectAsStateWithLifecycle()

                val showBottomBar = currentScreen is Screen.Home ||
                        currentScreen is Screen.Fixtures ||
                        currentScreen is Screen.TicketWallet ||
                        currentScreen is Screen.Club ||
                        currentScreen is Screen.Shop ||
                        currentScreen is Screen.Profile

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (showBottomBar) {
                            NavigationBar {
                                NavigationBarItem(
                                    selected = currentScreen is Screen.Home,
                                    onClick = { viewModel.navigateTo(Screen.Home) },
                                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                    label = { Text("Home") }
                                )
                                NavigationBarItem(
                                    selected = currentScreen is Screen.Fixtures,
                                    onClick = { viewModel.navigateTo(Screen.Fixtures) },
                                    icon = { Icon(Icons.Default.SportsSoccer, contentDescription = "Fixtures") },
                                    label = { Text("Fixtures") }
                                )
                                NavigationBarItem(
                                    selected = currentScreen is Screen.TicketWallet,
                                    onClick = { viewModel.navigateTo(Screen.TicketWallet) },
                                    icon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = "Tickets") },
                                    label = { Text("Tickets") }
                                )
                                NavigationBarItem(
                                    selected = currentScreen is Screen.Shop,
                                    onClick = { viewModel.navigateTo(Screen.Shop) },
                                    icon = { Icon(Icons.Default.Store, contentDescription = "Shop") },
                                    label = { Text("Shop") }
                                )
                                NavigationBarItem(
                                    selected = currentScreen is Screen.Club,
                                    onClick = { viewModel.navigateTo(Screen.Club) },
                                    icon = { Icon(Icons.Default.Shield, contentDescription = "Club") },
                                    label = { Text("Club") }
                                )
                                NavigationBarItem(
                                    selected = currentScreen is Screen.Profile,
                                    onClick = { viewModel.navigateTo(Screen.Profile) },
                                    icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                                    label = { Text("Profile") }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (val screen = currentScreen) {
                            is Screen.Home -> HomeScreen(viewModel, fixtures, tickets, announcements)
                            is Screen.Fixtures -> FixturesScreen(viewModel, fixtures)
                            is Screen.FixtureDetail -> FixtureDetailScreen(viewModel, screen.fixtureId, fixtures)
                            is Screen.SeatSelection -> SeatSelectionScreen(viewModel, screen.fixtureId)
                            is Screen.Checkout -> TicketCheckoutScreen(viewModel, screen.fixtureId, screen.stand, screen.block, screen.seats, screen.totalPricePence)
                            is Screen.Payment -> PaymentScreen(viewModel, screen.orderId, screen.totalPricePence, screen.fixtureId, screen.seats, screen.stand)
                            is Screen.TicketWallet -> TicketWalletScreen(viewModel, tickets)
                            is Screen.StaffScanner -> StaffScannerScreen(viewModel, scanResult)
                            is Screen.Club -> ClubScreen(viewModel)
                            is Screen.Shop -> ShopScreen(viewModel, merchandise)
                            is Screen.Profile -> ProfileScreen(viewModel)
                            is Screen.AdminConsole -> AdminConsoleScreen(viewModel, auditLogs, fixtures)
                            is Screen.DemoWalkthrough -> DemoWalkthroughScreen(viewModel)
                            else -> HomeScreen(viewModel, fixtures, tickets, announcements)
                        }
                    }
                }
            }
        }
    }
}
