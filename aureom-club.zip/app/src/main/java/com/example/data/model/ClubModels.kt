package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fixtures")
data class FixtureEntity(
    @PrimaryKey val id: String,
    val title: String,
    val opponent: String,
    val sport: String, // Football, Rugby, Cricket, Hockey
    val competition: String, // Northern Premier, FA Trophy, Friendly, National League
    val dateString: String,
    val timeString: String,
    val timestamp: Long,
    val venue: String,
    val homeOrAway: String, // HOME, AWAY
    val status: String, // UPCOMING, LIVE, COMPLETED, POSTPONED
    val homeScore: Int?,
    val awayScore: Int?,
    val broadcast: String?,
    val source: String,
    val lastUpdated: Long
)

@Entity(tableName = "tickets")
data class TicketEntity(
    @PrimaryKey val id: String,
    val fixtureId: String,
    val fixtureTitle: String,
    val venue: String,
    val stand: String,
    val block: String,
    val row: String,
    val seatNumber: String,
    val category: String, // Adult, Concession, Junior, Family, Accessible
    val pricePence: Int,
    val status: String, // ISSUED, USED, TRANSFERRED, REFUNDED, CANCELLED
    val qrSignature: String,
    val purchaserName: String,
    val attendeeName: String,
    val purchaseDate: Long
)

@Entity(tableName = "memberships")
data class MembershipEntity(
    @PrimaryKey val id: String,
    val tierName: String, // Gold Life Supporter, Season Pass 25/26, Junior Cub
    val pricePence: Int,
    val startDate: String,
    val endDate: String,
    val status: String, // ACTIVE, RENEWAL_DUE, EXPIRED
    val benefits: String,
    val barcode: String
)

@Entity(tableName = "merchandise")
data class MerchandiseEntity(
    @PrimaryKey val id: String,
    val name: String,
    val category: String, // Apparel, Souvenirs, Matchday
    val pricePence: Int,
    val stockCount: Int,
    val description: String,
    val sizes: String // S, M, L, XL
)

@Entity(tableName = "announcements")
data class AnnouncementEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val category: String, // URGENT, MATCHDAY, GENERAL
    val timestamp: Long,
    val targetGroup: String, // ALL, SEASON_HOLDERS, GENERAL
    val isRead: Boolean
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val action: String,
    val details: String,
    val staffEmail: String
)

data class CartItem(
    val fixtureId: String,
    val fixtureTitle: String,
    val venue: String,
    val stand: String,
    val block: String,
    val row: String,
    val seatNumber: String,
    val category: String,
    val pricePence: Int
)
