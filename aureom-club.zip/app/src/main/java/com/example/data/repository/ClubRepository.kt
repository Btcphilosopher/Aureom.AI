package com.example.data.repository

import com.example.data.dao.ClubDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ClubRepository(private val clubDao: ClubDao) {

    val fixtures: Flow<List<FixtureEntity>> = clubDao.getAllFixtures()
    val tickets: Flow<List<TicketEntity>> = clubDao.getAllTickets()
    val memberships: Flow<List<MembershipEntity>> = clubDao.getAllMemberships()
    val merchandise: Flow<List<MerchandiseEntity>> = clubDao.getAllMerchandise()
    val announcements: Flow<List<AnnouncementEntity>> = clubDao.getAllAnnouncements()
    val auditLogs: Flow<List<AuditLogEntity>> = clubDao.getAllAuditLogs()

    suspend fun seedInitialData() {
        val seedFixtures = listOf(
            FixtureEntity(
                id = "FIX-001",
                title = "Pennine Athletic vs Yorkshire Wanderers",
                opponent = "Yorkshire Wanderers",
                sport = "Football",
                competition = "Northern Premier League",
                dateString = "Sat 29 Nov 2025",
                timeString = "15:00",
                timestamp = 1764428400000L,
                venue = "Holconbe Park",
                homeOrAway = "HOME",
                status = "UPCOMING",
                homeScore = null,
                awayScore = null,
                broadcast = "Pennine TV Live",
                source = "Official Club Feed",
                lastUpdated = System.currentTimeMillis()
            ),
            FixtureEntity(
                id = "FIX-002",
                title = "Pennine RFC vs Dales Raiders",
                opponent = "Dales Raiders",
                sport = "Rugby",
                competition = "National League North",
                dateString = "Sat 6 Dec 2025",
                timeString = "14:30",
                timestamp = 1765031400000L,
                venue = "Holconbe Park",
                homeOrAway = "HOME",
                status = "UPCOMING",
                homeScore = null,
                awayScore = null,
                broadcast = null,
                source = "Official Club Feed",
                lastUpdated = System.currentTimeMillis()
            ),
            FixtureEntity(
                id = "FIX-003",
                title = "Lancashire United vs Pennine Athletic",
                opponent = "Lancashire United",
                sport = "Football",
                competition = "FA Trophy Cup",
                dateString = "Tue 16 Nov 2025",
                timeString = "19:45",
                timestamp = 1763322300000L,
                venue = "Ewood Stadium",
                homeOrAway = "AWAY",
                status = "COMPLETED",
                homeScore = 1,
                awayScore = 2,
                broadcast = "BBC Sport Online",
                source = "Verified Result Feed",
                lastUpdated = System.currentTimeMillis()
            )
        )
        clubDao.insertFixtures(seedFixtures)

        val seedTickets = listOf(
            TicketEntity(
                id = "TIX-9988",
                fixtureId = "FIX-001",
                fixtureTitle = "Pennine Athletic vs Yorkshire Wanderers",
                venue = "Holconbe Park",
                stand = "Holconbe Stand",
                block = "Block B",
                row = "Row 4",
                seatNumber = "Seat 12",
                category = "Adult Member",
                pricePence = 2200,
                status = "ISSUED",
                qrSignature = "PENNINE-SECURE-SIG-9988-ABC",
                purchaserName = "Arthur Pendelton",
                attendeeName = "Arthur Pendelton",
                purchaseDate = System.currentTimeMillis() - 86400000L
            )
        )
        clubDao.insertTickets(seedTickets)

        val seedMemberships = listOf(
            MembershipEntity(
                id = "MEM-01",
                tierName = "Gold Life Supporter",
                pricePence = 25000,
                startDate = "01 Aug 2025",
                endDate = "31 Jul 2026",
                status = "ACTIVE",
                benefits = "Priority booking, 15% club shop discount, Access to Boardroom lounge, Free matchday programme.",
                barcode = "PAC-GOLD-882910"
            ),
            MembershipEntity(
                id = "MEM-02",
                tierName = "Season Pass 25/26",
                pricePence = 39500,
                startDate = "01 Aug 2025",
                endDate = "31 Jul 2026",
                status = "ACTIVE",
                benefits = "Guaranteed admission to all 23 home league fixtures, Cup priority.",
                barcode = "PAC-SP-449102"
            )
        )
        clubDao.insertMemberships(seedMemberships)

        val seedMerch = listOf(
            MerchandiseEntity(
                id = "MERCH-01",
                name = "Pennine Home Match Jersey 25/26",
                category = "Apparel",
                pricePence = 6500,
                stockCount = 142,
                description = "Tailored vintage-modern home jersey in deep navy and rich burgundy stripes with gold collar piping.",
                sizes = "S, M, L, XL"
            ),
            MerchandiseEntity(
                id = "MERCH-02",
                name = "Heritage Wool Crest Scarf",
                category = "Souvenirs",
                pricePence = 2000,
                stockCount = 85,
                description = "Traditional spun wool supporters scarf with embroidered Pennine rose emblem.",
                sizes = "One Size"
            ),
            MerchandiseEntity(
                id = "MERCH-03",
                name = "Ceramic Club Crest Mug",
                category = "Souvenirs",
                pricePence = 1200,
                stockCount = 210,
                description = "Heavyweight ceramic mug featuring the gold and navy club crest.",
                sizes = "Standard"
            ),
            MerchandiseEntity(
                id = "MERCH-04",
                name = "Pennine All-Weather Training Fleece",
                category = "Apparel",
                pricePence = 4500,
                stockCount = 64,
                description = "Water-resistant half-zip training fleece worn by squad staff during Pennine winter sessions.",
                sizes = "M, L, XL"
            )
        )
        clubDao.insertMerchandise(seedMerch)

        val seedAnnouncements = listOf(
            AnnouncementEntity(
                id = "ANN-01",
                title = "Matchday Parking Advisory",
                message = "Supporters attending Saturday's fixture against Yorkshire Wanderers are advised that Holconbe Park car park opens at 12:30. Shuttle buses run from Skipton Station every 15 minutes.",
                category = "MATCHDAY",
                timestamp = System.currentTimeMillis() - 3600000L,
                targetGroup = "ALL",
                isRead = false
            ),
            AnnouncementEntity(
                id = "ANN-02",
                title = "Manager Pre-Match Update",
                message = "Manager Arthur Pendelton confirms a fully fit squad for Saturday's top-of-the-table clash. Tickets remaining in the Clough Terrace.",
                category = "GENERAL",
                timestamp = System.currentTimeMillis() - 72000000L,
                targetGroup = "ALL",
                isRead = true
            )
        )
        clubDao.insertAnnouncements(seedAnnouncements)

        clubDao.insertAuditLog(
            AuditLogEntity(
                id = UUID.randomUUID().toString(),
                timestamp = System.currentTimeMillis(),
                action = "SYSTEM_INITIALIZED",
                details = "Pennine Athletic Club database seeded successfully with fixtures, memberships, tickets, and merchandise.",
                staffEmail = "admin@aureomclub.co.uk"
            )
        )
    }

    suspend fun insertFixture(fixture: FixtureEntity) = clubDao.insertFixture(fixture)
    suspend fun insertTicket(ticket: TicketEntity) = clubDao.insertTicket(ticket)
    suspend fun updateTicketStatus(ticketId: String, status: String) = clubDao.updateTicketStatus(ticketId, status)
    suspend fun insertAuditLog(log: AuditLogEntity) = clubDao.insertAuditLog(log)
    suspend fun getTicketById(ticketId: String) = clubDao.getTicketById(ticketId)
    suspend fun insertAnnouncement(announcement: AnnouncementEntity) = clubDao.insertAnnouncement(announcement)
}
