# Privacy & Security Architecture

## 1. Zero Silent Telemetry
Bharat Browser operates under zero-tracking principles:
- Typed searches, phonetic transliteration inputs, and reading clips are never transmitted to advertising networks.
- Local processing is preferred across all linguistic and transliteration operations.

## 2. Real Tracker Defense Filter
The browser enforces an active blocking filter against third-party analytics and ad network domains (`doubleclick.net`, `google-analytics.com`, `scorecardresearch.com`, etc.).

## 3. Data Transparency Panel
Every network or model event is catalogued with:
- **What was sent**
- **Why it was sent**
- **Destination**
- **Retention policy**

## 4. Private Browsing Mode
In Private Browsing Mode:
- Browsing history is not persisted to disk.
- Cookie jars and cache partitions are isolated in volatile memory and purged upon exit.
