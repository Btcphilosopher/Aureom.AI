# Bharat Browser Architecture

```
Bharat Browser Architecture
│
├── language-core/
│   ├── LanguageRegistry.kt          (Typed profiles for 14 Indian languages)
│   ├── ScriptDetector.kt            (Unicode range detection & RTL analysis)
│   ├── IndicTypography.kt           (NFC normalization & grapheme clustering)
│   ├── TransliterationEngine.kt     (Roman-to-Indic phonetic candidate engine)
│   └── TranslationEngine.kt         (Bilingual paragraph alignment & translation)
│
├── search-core/
│   ├── SearchCore.kt                (Omnibar intent parsing & query expansion)
│   └── IndiaPortals.kt              (Curated authentic Indian regional portals)
│
├── ai-core/
│   └── BharatAIAssistant.kt         (Page content extraction vs AI interpretation)
│
├── voice-core/
│   └── SpeechService.kt             (Text-To-Speech with Indian language locales)
│
└── ui/
    ├── BharatOmnibar.kt             (Universal search & address bar)
    ├── NewTabScreen.kt              (India-First homepage & fast language switch)
    ├── BrowserWebView.kt            (Dual-engine WebView & portal renderer)
    ├── ReaderModeScreen.kt          (Bilingual reading & typography controls)
    ├── TabManagerScreen.kt          (Tabs grid, groups, and search)
    ├── ResearchWorkspaceScreen.kt   (Bharat Research clippings & citations)
    ├── PrivacyDashboardScreen.kt    (Trackers blocked, HTTPS & Data Transparency)
    ├── SettingsScreen.kt            (Language matrix, UI language, AI modes)
    └── BharatAIPanel.kt             (Interactive AI research inspector)
```

## Data Isolation & Security Principles
1. **Local-First Processing**: Transliteration and script detection run entirely on-device without remote telemetry.
2. **Data Transparency**: The Data Transparency Panel records every internal data flow, purpose, destination, and retention rule.
3. **Indic Text Preservation**: Text truncation, copying, and rendering never split combining characters, nuktas, or viramas.
