# Indic Rendering & Typography

## Typography & Script Engine
1. **Unicode NFC Canonical Normalization**: Text undergoes `Normalizer.normalize(text, Normalizer.Form.NFC)` before rendering, indexing, or clipboard operations to prevent split diacritics.
2. **Grapheme Cluster Awareness**: In `IndicTypography.kt`, substring splitting and character truncation identify combining marks (matras, nuktas, halants/viramas), Zero-Width Joiner (`\u200D`), and Zero-Width Non-Joiner (`\u200C`) to keep conjunct syllables intact.
3. **Indian Number Formatting**: Respects the Indian numbering system (`₹1,25,00,000` rather than Western `₹12,500,000`).
4. **Urdu Bidirectional Support (RTL)**: Automatic RTL text alignment and Unicode directional isolation for Arabic-derived Urdu text runs.
