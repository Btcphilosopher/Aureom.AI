# Bharat Browser: Multilingual Language Engine

## Supported Language Registry
Bharat Browser supports 14 Indian languages via typed `LanguageProfile` models:

| Language | Script | Direction | Locale | Code |
| :--- | :--- | :--- | :--- | :--- |
| **हिन्दी (Hindi)** | Devanagari | LTR | `hi-IN` | `hi` |
| **English** | Latin | LTR | `en-IN` | `en` |
| **বাংলা (Bengali)** | Bengali | LTR | `bn-IN` | `bn` |
| **मराठी (Marathi)** | Devanagari | LTR | `mr-IN` | `mr` |
| **ગુજરાતી (Gujarati)** | Gujarati | LTR | `gu-IN` | `gu` |
| **ਪੰਜਾਬੀ (Punjabi)** | Gurmukhi | LTR | `pa-IN` | `pa` |
| **தமிழ் (Tamil)** | Tamil | LTR | `ta-IN` | `ta` |
| **తెలుగు (Telugu)** | Telugu | LTR | `te-IN` | `te` |
| **ಕನ್ನಡ (Kannada)** | Kannada | LTR | `kn-IN` | `kn` |
| **മലയാളം (Malayalam)**| Malayalam | LTR | `ml-IN` | `ml` |
| **ଓଡ଼ିଆ (Odia)** | Odia | LTR | `or-IN` | `or` |
| **অসমীয়া (Assamese)**| Bengali-Assamese | LTR | `as-IN` | `as` |
| **اردو (Urdu)** | Arabic-derived (Nastaliq) | RTL | `ur-IN` | `ur` |
| **संस्कृतम् (Sanskrit)**| Devanagari | LTR | `sa-IN` | `sa` |

## Key Architectural Invariants
1. **Language ≠ Script**: Users can enter Romanised Indic text (`namaste bharat`), Devanagari (`नमस्ते भारत`), or mixed English/Hindi without artificial mode boundaries.
2. **Independent Settings Matrix**:
   - Browser UI Language
   - Webpage Content Language
   - Translation Target Language
   - Input Language
