package com.example

import com.example.bharatbrowser.language.IndicTypography
import com.example.bharatbrowser.language.LocalTransliterationProvider
import com.example.bharatbrowser.language.ScriptDetector
import com.example.bharatbrowser.language.TranslationEngine
import com.example.bharatbrowser.model.IndicScript
import com.example.bharatbrowser.model.TextDirection
import com.example.bharatbrowser.search.SearchCore
import com.example.bharatbrowser.search.SearchIntent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testScriptDetection() {
        assertEquals(IndicScript.DEVANAGARI, ScriptDetector.detectScript("नमस्ते भारत"))
        assertEquals(IndicScript.TAMIL, ScriptDetector.detectScript("வணக்கம் தமிழ்நாடு"))
        assertEquals(IndicScript.BENGALI, ScriptDetector.detectScript("নমস্কার বাংলা"))
        assertEquals(IndicScript.GUJARATI, ScriptDetector.detectScript("કેમ છો ગુજરાત"))
        assertEquals(IndicScript.GURMUKHI, ScriptDetector.detectScript("ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ"))
        assertEquals(IndicScript.TELUGU, ScriptDetector.detectScript("నమస్కారం"))
        assertEquals(IndicScript.KANNADA, ScriptDetector.detectScript("ನಮಸ್ಕಾರ ಕರ್ನಾಟಕ"))
        assertEquals(IndicScript.MALAYALAM, ScriptDetector.detectScript("നമസ്കാരം കേരളം"))
        assertEquals(IndicScript.ARABIC_URDU, ScriptDetector.detectScript("شکریہ اردو"))
        assertEquals(IndicScript.LATIN, ScriptDetector.detectScript("Bharat Browser"))
    }

    @Test
    fun testUrduRTLDetection() {
        assertTrue(ScriptDetector.isRTL("شکریہ اردو"))
        assertEquals(TextDirection.RTL, ScriptDetector.getDirection("آداب جناب"))
        assertEquals(TextDirection.LTR, ScriptDetector.getDirection("नमस्ते भारत"))
    }

    @Test
    fun testTransliterationEngine() {
        val provider = LocalTransliterationProvider()

        val hiCandidates = provider.transliterate("namaste", "hi")
        assertTrue(hiCandidates.contains("नमस्ते"))

        val taCandidates = provider.transliterate("vanakkam", "ta")
        assertTrue(taCandidates.contains("வணக்கம்"))

        val guCandidates = provider.transliterate("kem cho", "gu")
        assertTrue(guCandidates.any { it.contains("કેમ") })
    }

    @Test
    fun testIndicNumberFormatting() {
        // Indian grouping: 1,25,00,000 instead of 12,500,000
        val formatted = IndicTypography.formatIndianNumber(12500000L)
        assertEquals("1,25,00,000", formatted)

        val currency = IndicTypography.formatIndianCurrency(2500000L)
        assertEquals("₹25,00,000", currency)
    }

    @Test
    fun testGraphemeClusterIntegrity() {
        val text = "नमस्ते"
        val clusters = IndicTypography.getGraphemeClusters(text)
        // Ensure combining matras are clustered properly with base consonants
        assertTrue(clusters.isNotEmpty())
        assertEquals("नमस्ते", clusters.joinToString(""))
    }

    @Test
    fun testSearchCoreOmnibarParsing() {
        // Direct URL
        val urlIntent = SearchCore.parseInput("https://digitalindia.gov.in")
        assertTrue(urlIntent is SearchIntent.DirectUrl)

        // Math expression
        val mathIntent = SearchCore.parseInput("25 * 4")
        assertTrue(mathIntent is SearchIntent.Calculator)
        if (mathIntent is SearchIntent.Calculator) {
            assertEquals("100", mathIntent.result)
        }

        // Web Search with transliteration
        val queryIntent = SearchCore.parseInput("dilli ka mausam")
        assertTrue(queryIntent is SearchIntent.WebSearch)
    }

    @Test
    fun testTranslationEngine() {
        val original = "भारत में डिजिटल अर्थव्यवस्था तेजी से विकसित हो रही है।"
        val translated = TranslationEngine.translateSentence(original, "hi", "en")
        assertEquals("India's digital economy is developing rapidly.", translated)
    }
}
