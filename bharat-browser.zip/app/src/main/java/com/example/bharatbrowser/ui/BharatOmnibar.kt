package com.example.bharatbrowser.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bharatbrowser.model.IndicScript
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SaffronDeep
import com.example.ui.theme.SaffronWarm
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun BharatOmnibar(
    viewModel: BharatBrowserViewModel,
    modifier: Modifier = Modifier
) {
    val omnibarText by viewModel.omnibarText.collectAsState()
    val isFocused by viewModel.isOmnibarFocused.collectAsState()
    val candidates by viewModel.transliterationCandidates.collectAsState()
    val detectedScript by viewModel.detectedInputScript.collectAsState()
    val calculatorResult by viewModel.calculatorResult.collectAsState()
    val transliterationOn by viewModel.transliterationEnabled.collectAsState()
    val uiLang by viewModel.uiLanguage.collectAsState()
    val activeScreen by viewModel.activeScreen.collectAsState()
    val currentArticle by viewModel.currentArticle.collectAsState()
    val liveUrl by viewModel.liveWebUrl.collectAsState()
    val isPrivate by viewModel.isPrivateBrowsing.collectAsState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(if (isPrivate) Slate900 else MaterialTheme.colorScheme.surface)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        // Main address and search pill
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("bharat_omnibar"),
            shape = RoundedCornerShape(26.dp),
            color = if (isPrivate) Slate800 else MaterialTheme.colorScheme.surfaceVariant,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // HTTPS security lock / Privacy icon
                Icon(
                    imageVector = if (isPrivate) Icons.Outlined.Security else Icons.Default.Lock,
                    contentDescription = "Security Status",
                    tint = if (isPrivate) SaffronWarm else EmeraldGreen,
                    modifier = Modifier
                        .size(18.dp)
                        .clickable { viewModel.navigateToScreen(ActiveScreen.PRIVACY) }
                        .testTag("omnibar_security_icon")
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Script Indicator Tag
                if (detectedScript != IndicScript.LATIN) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(SaffronWarm.copy(alpha = 0.18f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = detectedScript.displayName.take(5),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SaffronDeep
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }

                // Text Input Field
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (omnibarText.isEmpty()) {
                        Text(
                            text = if (activeScreen == ActiveScreen.BROWSER_HOME) {
                                uiLang.greetingsPrompt
                            } else {
                                currentArticle?.title ?: liveUrl ?: "खोजें या URL दर्ज करें"
                            },
                            style = TextStyle(
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    BasicTextField(
                        value = omnibarText,
                        onValueChange = { viewModel.onOmnibarTextChanged(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("omnibar_input_field"),
                        textStyle = TextStyle(
                            fontSize = 15.sp,
                            color = if (isPrivate) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Normal
                        ),
                        singleLine = true,
                        cursorBrush = SolidColor(SaffronDeep),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { viewModel.submitOmnibar() })
                    )
                }

                // Transliteration Toggle Button (EN ↔ Indic)
                IconButton(
                    onClick = { viewModel.toggleTransliteration() },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("omnibar_translit_toggle")
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (transliterationOn) SaffronDeep else Color.Transparent)
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (transliterationOn) "लिपि" else "EN",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (transliterationOn) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Clear button or Reader Mode / Voice Search
                if (omnibarText.isNotEmpty()) {
                    IconButton(
                        onClick = { viewModel.onOmnibarTextChanged("") },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear Input",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                } else {
                    // Reader Mode Quick Toggle if on article
                    if (currentArticle != null) {
                        IconButton(
                            onClick = { viewModel.toggleReaderMode() },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("omnibar_reader_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.MenuBook,
                                contentDescription = "Reader Mode",
                                tint = if (activeScreen == ActiveScreen.READER_MODE) SaffronDeep else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Voice / Mic Search
                    IconButton(
                        onClick = {
                            viewModel.showNotice("आवाज पहचान सक्रिय: कृपया बोलें...")
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("omnibar_voice_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Input",
                            tint = SaffronDeep,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Live Transliteration Candidates & Calculator Suggestions Row
        AnimatedVisibility(visible = candidates.isNotEmpty() || calculatorResult != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
            ) {
                // Calculator math chip if present
                if (calculatorResult != null) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = EmeraldGreen.copy(alpha = 0.12f),
                        modifier = Modifier
                            .padding(bottom = 4.dp)
                            .clickable {
                                viewModel.onOmnibarTextChanged(calculatorResult!!)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "गणितीय उत्तर: = ${calculatorResult!!}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldGreen
                            )
                        }
                    }
                }

                // Indic Candidate Chips
                if (candidates.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "सुझाव:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        candidates.forEach { candidate ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clickable {
                                        viewModel.applyTransliterationCandidate(candidate)
                                    }
                                    .testTag("translit_candidate_$candidate")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = candidate,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = SaffronDeep
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
