package com.example.bharatbrowser.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SaffronDeep
import com.example.ui.theme.SaffronWarm
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun MainBrowserScreen(
    viewModel: BharatBrowserViewModel
) {
    val activeScreen by viewModel.activeScreen.collectAsState()
    val tabs by viewModel.tabs.collectAsState()
    val statusNotice by viewModel.statusNotice.collectAsState()
    val isPrivate by viewModel.isPrivateBrowsing.collectAsState()

    var showMenuDropdown by remember { mutableStateOf(false) }

    // Handle back gesture smoothly
    BackHandler(enabled = activeScreen != ActiveScreen.BROWSER_HOME) {
        when (activeScreen) {
            ActiveScreen.READER_MODE -> viewModel.navigateToScreen(ActiveScreen.WEB_PAGE)
            ActiveScreen.AI_PANEL -> viewModel.navigateToScreen(ActiveScreen.WEB_PAGE)
            ActiveScreen.RESEARCH -> viewModel.navigateToScreen(ActiveScreen.WEB_PAGE)
            ActiveScreen.TAB_MANAGER -> viewModel.navigateToScreen(ActiveScreen.BROWSER_HOME)
            ActiveScreen.BOOKMARKS -> viewModel.navigateToScreen(ActiveScreen.BROWSER_HOME)
            ActiveScreen.HISTORY -> viewModel.navigateToScreen(ActiveScreen.BROWSER_HOME)
            ActiveScreen.PRIVACY -> viewModel.navigateToScreen(ActiveScreen.BROWSER_HOME)
            ActiveScreen.SETTINGS -> viewModel.navigateToScreen(ActiveScreen.BROWSER_HOME)
            ActiveScreen.WEB_PAGE -> viewModel.navigateToScreen(ActiveScreen.BROWSER_HOME)
            ActiveScreen.BROWSER_HOME -> { /* system handles exiting */ }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars),
        containerColor = if (isPrivate) Slate900 else MaterialTheme.colorScheme.background,
        topBar = {
            // Omnibar shown when on Home, Web Page, or when needed
            if (activeScreen == ActiveScreen.BROWSER_HOME || activeScreen == ActiveScreen.WEB_PAGE) {
                BharatOmnibar(viewModel = viewModel)
            }
        },
        bottomBar = {
            // Unified Bottom Mobile Action Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars),
                color = if (isPrivate) Slate800 else MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Back
                    IconButton(
                        onClick = {
                            if (activeScreen != ActiveScreen.BROWSER_HOME) {
                                viewModel.navigateToScreen(ActiveScreen.BROWSER_HOME)
                            }
                        },
                        modifier = Modifier.testTag("nav_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Home
                    IconButton(
                        onClick = { viewModel.navigateToScreen(ActiveScreen.BROWSER_HOME) },
                        modifier = Modifier.testTag("nav_home_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Home",
                            tint = if (activeScreen == ActiveScreen.BROWSER_HOME) SaffronDeep else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Bharat Research Workspace
                    IconButton(
                        onClick = { viewModel.navigateToScreen(ActiveScreen.RESEARCH) },
                        modifier = Modifier.testTag("nav_research_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "Research Workspace",
                            tint = if (activeScreen == ActiveScreen.RESEARCH) SaffronDeep else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Tabs Switcher with count badge
                    IconButton(
                        onClick = { viewModel.navigateToScreen(ActiveScreen.TAB_MANAGER) },
                        modifier = Modifier.testTag("nav_tabs_btn")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (activeScreen == ActiveScreen.TAB_MANAGER) SaffronDeep
                                    else MaterialTheme.colorScheme.surfaceVariant
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${tabs.size}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (activeScreen == ActiveScreen.TAB_MANAGER) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Menu Overflow
                    Box {
                        IconButton(
                            onClick = { showMenuDropdown = true },
                            modifier = Modifier.testTag("nav_menu_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Menu",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        DropdownMenu(
                            expanded = showMenuDropdown,
                            onDismissRequest = { showMenuDropdown = false },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                        ) {
                            DropdownMenuItem(
                                text = { Text("नया टैब (New Tab)") },
                                onClick = {
                                    showMenuDropdown = false
                                    viewModel.openNewTab()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("रीडर मोड (Reader Mode)") },
                                onClick = {
                                    showMenuDropdown = false
                                    viewModel.toggleReaderMode()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Bharat AI सारांश") },
                                onClick = {
                                    showMenuDropdown = false
                                    viewModel.openAIAssistant()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("बुकमार्क (Bookmarks)") },
                                onClick = {
                                    showMenuDropdown = false
                                    viewModel.navigateToScreen(ActiveScreen.BOOKMARKS)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("इतिहास (History)") },
                                onClick = {
                                    showMenuDropdown = false
                                    viewModel.navigateToScreen(ActiveScreen.HISTORY)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("गोपनीयता एवं सुरक्षा (Privacy)") },
                                onClick = {
                                    showMenuDropdown = false
                                    viewModel.navigateToScreen(ActiveScreen.PRIVACY)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("सेटिंग्स (Settings)") },
                                onClick = {
                                    showMenuDropdown = false
                                    viewModel.navigateToScreen(ActiveScreen.SETTINGS)
                                }
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (activeScreen) {
                ActiveScreen.BROWSER_HOME -> {
                    NewTabScreen(viewModel = viewModel)
                }
                ActiveScreen.WEB_PAGE -> {
                    BrowserWebView(viewModel = viewModel)
                }
                ActiveScreen.READER_MODE -> {
                    ReaderModeScreen(viewModel = viewModel)
                }
                ActiveScreen.TAB_MANAGER -> {
                    TabManagerScreen(viewModel = viewModel)
                }
                ActiveScreen.BOOKMARKS -> {
                    BookmarksAndHistoryScreen(viewModel = viewModel, initialTab = 0)
                }
                ActiveScreen.HISTORY -> {
                    BookmarksAndHistoryScreen(viewModel = viewModel, initialTab = 1)
                }
                ActiveScreen.RESEARCH -> {
                    ResearchWorkspaceScreen(viewModel = viewModel)
                }
                ActiveScreen.PRIVACY -> {
                    PrivacyDashboardScreen(viewModel = viewModel)
                }
                ActiveScreen.SETTINGS -> {
                    SettingsScreen(viewModel = viewModel)
                }
                ActiveScreen.AI_PANEL -> {
                    BharatAIPanel(viewModel = viewModel)
                }
            }

            // Status Notice Toast Pill at Bottom
            AnimatedVisibility(
                visible = statusNotice != null,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 16.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Slate900.copy(alpha = 0.94f),
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .clickable { viewModel.dismissNotice() }
                        .padding(horizontal = 20.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = statusNotice ?: "",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
