package com.example.bharatbrowser.language

import com.example.bharatbrowser.model.IndicScript
import com.example.bharatbrowser.model.TextDirection

object ScriptDetector {

    fun detectScript(text: String): IndicScript {
        if (text.isBlank()) return IndicScript.LATIN

        var devanagariCount = 0
        var bengaliCount = 0
        var gujaratiCount = 0
        var gurmukhiCount = 0
        var tamilCount = 0
        var teluguCount = 0
        var kannadaCount = 0
        var malayalamCount = 0
        var odiaCount = 0
        var urduCount = 0
        var latinCount = 0

        for (codePoint in text.codePoints()) {
            when (codePoint) {
                in 0x0900..0x097F -> devanagariCount++
                in 0x0980..0x09FF -> bengaliCount++
                in 0x0A80..0x0AFF -> gujaratiCount++
                in 0x0A00..0x0A7F -> gurmukhiCount++
                in 0x0B80..0x0BFF -> tamilCount++
                in 0x0C00..0x0C7F -> teluguCount++
                in 0x0C80..0x0CFF -> kannadaCount++
                in 0x0D00..0x0D7F -> malayalamCount++
                in 0x0B00..0x0B7F -> odiaCount++
                in 0x0600..0x06FF -> urduCount++
                in 0x0041..0x005A, in 0x0061..0x007A -> latinCount++
            }
        }

        val counts = listOf(
            IndicScript.DEVANAGARI to devanagariCount,
            IndicScript.BENGALI to bengaliCount,
            IndicScript.GUJARATI to gujaratiCount,
            IndicScript.GURMUKHI to gurmukhiCount,
            IndicScript.TAMIL to tamilCount,
            IndicScript.TELUGU to teluguCount,
            IndicScript.KANNADA to kannadaCount,
            IndicScript.MALAYALAM to malayalamCount,
            IndicScript.ODIA to odiaCount,
            IndicScript.ARABIC_URDU to urduCount,
            IndicScript.LATIN to latinCount
        )

        val max = counts.maxByOrNull { it.second }
        return if (max != null && max.second > 0) max.first else IndicScript.LATIN
    }

    fun isRTL(text: String): Boolean {
        for (codePoint in text.codePoints()) {
            if (codePoint in 0x0600..0x06FF || codePoint in 0x0750..0x077F || codePoint in 0xFB50..0xFDFF || codePoint in 0xFE70..0xFEFF) {
                return true
            }
        }
        return false
    }

    fun getDirection(text: String): TextDirection {
        return if (isRTL(text)) TextDirection.RTL else TextDirection.LTR
    }
}
