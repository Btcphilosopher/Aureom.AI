package com.example.bharatbrowser.search

import com.example.bharatbrowser.language.ScriptDetector
import com.example.bharatbrowser.model.IndicScript

sealed class SearchIntent {
    data class DirectUrl(val url: String) : SearchIntent()
    data class BrowserCommand(val command: String, val arg: String = "") : SearchIntent()
    data class Calculator(val expression: String, val result: String) : SearchIntent()
    data class WebSearch(
        val rawQuery: String,
        val detectedScript: IndicScript,
        val transliteratedSuggestion: String? = null,
        val expandedQueries: List<String> = emptyList(),
        val languageCode: String
    ) : SearchIntent()
}

object SearchCore {

    private val urlRegex = Regex("^(https?://|www\\.)?[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(/.*)?$")

    fun parseInput(input: String, currentLangCode: String = "hi"): SearchIntent {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            return SearchIntent.WebSearch(
                rawQuery = "",
                detectedScript = IndicScript.LATIN,
                languageCode = currentLangCode
            )
        }

        // 1. Internal commands (:reader, :privacy, :research, :settings, :offline, :tabs)
        if (trimmed.startsWith(":")) {
            val parts = trimmed.substring(1).split(" ", limit = 2)
            val cmd = parts[0].lowercase()
            val arg = if (parts.size > 1) parts[1] else ""
            return SearchIntent.BrowserCommand(cmd, arg)
        }

        // 2. Calculator expressions (e.g., 25 * 4, 125000 / 12, 100 + 45)
        val mathMatch = evaluateMathExpression(trimmed)
        if (mathMatch != null) {
            return SearchIntent.Calculator(trimmed, mathMatch)
        }

        // 3. Direct URL detection
        if (isUrl(trimmed)) {
            val normalizedUrl = if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
                "https://$trimmed"
            } else {
                trimmed
            }
            return SearchIntent.DirectUrl(normalizedUrl)
        }

        // 4. Script and language detection
        val script = ScriptDetector.detectScript(trimmed)

        // 5. Transliterated candidate check if typed in Latin
        var transliterated: String? = null
        if (script == IndicScript.LATIN) {
            val provider = com.example.bharatbrowser.language.LocalTransliterationProvider()
            val candidates = provider.transliterate(trimmed, currentLangCode)
            if (candidates.isNotEmpty() && candidates.first() != trimmed) {
                transliterated = candidates.first()
            }
        }

        // 6. Multilingual query expansions
        val expansions = generateExpansions(trimmed, script)

        return SearchIntent.WebSearch(
            rawQuery = trimmed,
            detectedScript = script,
            transliteratedSuggestion = transliterated,
            expandedQueries = expansions,
            languageCode = currentLangCode
        )
    }

    private fun isUrl(text: String): Boolean {
        if (text.contains(" ") || text.contains("\n")) return false
        if (text.startsWith("http://") || text.startsWith("https://") || text.startsWith("file://") || text.startsWith("about:")) return true
        if (text.endsWith(".in") || text.endsWith(".gov.in") || text.endsWith(".org") ||
            text.endsWith(".com") || text.endsWith(".net") || text.endsWith(".edu") || text.endsWith(".nic.in")) {
            return true
        }
        return urlRegex.matches(text)
    }

    private fun evaluateMathExpression(expr: String): String? {
        val clean = expr.replace(" ", "").replace("₹", "")
        if (!clean.matches(Regex("^[0-9]+[+\\-*/][0-9]+$"))) return null

        try {
            val opIndex = clean.indexOfFirst { it == '+' || it == '-' || it == '*' || it == '/' }
            if (opIndex <= 0 || opIndex >= clean.lastIndex) return null

            val left = clean.substring(0, opIndex).toLongOrNull() ?: return null
            val op = clean[opIndex]
            val right = clean.substring(opIndex + 1).toLongOrNull() ?: return null

            val result = when (op) {
                '+' -> (left + right).toDouble()
                '-' -> (left - right).toDouble()
                '*' -> (left * right).toDouble()
                '/' -> if (right == 0L) return "Divide by zero" else (left.toDouble() / right)
                else -> return null
            }

            return if (result % 1.0 == 0.0) {
                result.toLong().toString()
            } else {
                "%.2f".format(result)
            }
        } catch (e: Exception) {
            return null
        }
    }

    private fun generateExpansions(query: String, script: IndicScript): List<String> {
        val expansions = mutableListOf<String>()
        val lower = query.lowercase()

        when {
            lower.contains("railway") || lower.contains("train") -> {
                expansions.add("भारतीय रेलवे")
                expansions.add("Indian Railways IRCTC")
                expansions.add("ரயில்வே")
            }
            query.contains("रेलवे") || query.contains("ट्रेन") -> {
                expansions.add("Indian Railways")
                expansions.add("Train Status & Booking")
            }
            lower.contains("weather") || lower.contains("mausam") -> {
                expansions.add("मौसम पूर्वानुमान")
                expansions.add("வானிலை அறிக்கை")
            }
            query.contains("मौसम") -> {
                expansions.add("Weather forecast India")
                expansions.add("வானிலை")
            }
            lower.contains("economy") || lower.contains("gdp") -> {
                expansions.add("भारतीय अर्थव्यवस्था")
                expansions.add("India GDP Growth & RBI")
            }
            query.contains("अर्थव्यवस्था") -> {
                expansions.add("India Economy & DPI")
                expansions.add("பொருளாதாரம்")
            }
        }
        return expansions
    }
}
