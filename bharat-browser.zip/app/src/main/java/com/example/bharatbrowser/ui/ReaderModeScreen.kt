package com.example.bharatbrowser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bharatbrowser.language.TranslationEngine
import com.example.bharatbrowser.model.ReaderTheme
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SaffronDeep
import com.example.ui.theme.SaffronWarm
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun ReaderModeScreen(
    viewModel: BharatBrowserViewModel,
    modifier: Modifier = Modifier
) {
    val article by viewModel.currentArticle.collectAsState()
    val readerSettings by viewModel.readerSettings.collectAsState()
    val isSpeaking by viewModel.speechService.isSpeaking.collectAsState()
    val translationTarget by viewModel.translationTargetLanguage.collectAsState()

    val currentTheme = readerSettings.theme
    val bgColor = Color(currentTheme.bgHex)
    val textColor = Color(currentTheme.textHex)

    val content = article?.fullContent ?: "रीडर मोड में प्रदर्शित करने के लिए कोई लेख उपलब्ध नहीं है।"
    val title = article?.title ?: "वेब लेख"
    val author = article?.author ?: "Bureau"
    val date = article?.date ?: "2026"
    val source = article?.sourceName ?: "Bharat Web"

    val isBilingual = readerSettings.bilingualLayout
    val bilingualParagraphs = if (isBilingual) {
        TranslationEngine.createBilingualParagraphs(
            text = content,
            sourceLang = article?.languageCode ?: "hi",
            targetLang = readerSettings.translationTargetLang
        )
    } else {
        emptyList()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        // Top Reader Navigation & Control Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = bgColor,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.toggleReaderMode() },
                        modifier = Modifier.testTag("reader_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Exit Reader Mode",
                            tint = textColor
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    Text(
                        text = "रीडर मोड • Reader",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = textColor
                    )
                }

                // Audio Read Aloud / Listen Button
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = if (isSpeaking) EmeraldGreen else SaffronDeep,
                    modifier = Modifier
                        .clickable {
                            if (isSpeaking) {
                                viewModel.stopListening()
                            } else {
                                viewModel.listenToArticle()
                            }
                        }
                        .testTag("reader_tts_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                            contentDescription = "Listen",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isSpeaking) "रोकें (Stop)" else "सुनें / Listen",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // Reader Controls Bar (Font Size, Theme, Bilingual Toggle)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = bgColor.copy(alpha = 0.95f),
            tonalElevation = 1.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Font Size Adjuster (- / +)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(textColor.copy(alpha = 0.08f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    IconButton(
                        onClick = {
                            if (readerSettings.fontSizeSp > 12) {
                                viewModel.updateReaderSettings(fontSizeSp = readerSettings.fontSizeSp - 2)
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("A-", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = textColor)
                    }

                    Text(
                        text = "${readerSettings.fontSizeSp}sp",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = textColor,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    IconButton(
                        onClick = {
                            if (readerSettings.fontSizeSp < 32) {
                                viewModel.updateReaderSettings(fontSizeSp = readerSettings.fontSizeSp + 2)
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("A+", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = textColor)
                    }
                }

                // Theme Palette Selector (Ivory, Sepia, Graphite, Night)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ReaderTheme.values().forEach { theme ->
                        val isSelected = currentTheme == theme
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(theme.bgHex))
                                .clickable { viewModel.updateReaderSettings(theme = theme) }
                                .then(
                                    if (isSelected) Modifier.background(
                                        SaffronDeep.copy(alpha = 0.3f),
                                        CircleShape
                                    ) else Modifier
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(Color(theme.bgHex))
                            )
                        }
                    }
                }

                // Bilingual Reading Toggle
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(textColor.copy(alpha = 0.08f))
                        .clickable {
                            viewModel.updateReaderSettings(bilingual = !readerSettings.bilingualLayout)
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("reader_bilingual_toggle")
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Bilingual",
                        tint = if (isBilingual) SaffronDeep else textColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBilingual) "द्विभाषी (ON)" else "द्विभाषी (Bilingual)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isBilingual) SaffronDeep else textColor
                    )
                }

                // Clip to Research
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = textColor.copy(alpha = 0.08f),
                    modifier = Modifier.clickable {
                        viewModel.saveResearchExcerpt()
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "Clip",
                            tint = SaffronDeep,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "उद्धरण सहेजें",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = textColor
                        )
                    }
                }
            }
        }

        HorizontalDivider(color = textColor.copy(alpha = 0.12f))

        // Main Reader Content Scroll Area
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 18.dp)
        ) {
            // Source & Metas
            Text(
                text = "$source • $date",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = textColor.copy(alpha = 0.65f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Article Title
            Text(
                text = title,
                fontSize = (readerSettings.fontSizeSp + 6).sp,
                fontWeight = FontWeight.Bold,
                lineHeight = (readerSettings.fontSizeSp + 14).sp,
                color = textColor
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "लेखक: $author",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = textColor.copy(alpha = 0.75f)
            )

            Spacer(modifier = Modifier.height(18.dp))
            HorizontalDivider(color = textColor.copy(alpha = 0.12f))
            Spacer(modifier = Modifier.height(18.dp))

            // Bilingual layout vs Standard layout
            if (isBilingual && bilingualParagraphs.isNotEmpty()) {
                bilingualParagraphs.forEachIndexed { index, p ->
                    // Original Paragraph
                    Text(
                        text = p.original,
                        fontSize = readerSettings.fontSizeSp.sp,
                        lineHeight = (readerSettings.fontSizeSp * readerSettings.lineSpacingMultiplier).sp,
                        fontWeight = FontWeight.Normal,
                        color = textColor
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Aligned Translation Box
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = textColor.copy(alpha = 0.05f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "English Translation:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SaffronDeep
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = p.translation,
                                fontSize = (readerSettings.fontSizeSp - 1).sp,
                                lineHeight = ((readerSettings.fontSizeSp - 1) * 1.5f).sp,
                                color = textColor.copy(alpha = 0.9f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }
            } else {
                // Standard Single-Language Layout
                val paragraphs = content.split("\n\n").filter { it.isNotBlank() }
                paragraphs.forEach { p ->
                    Text(
                        text = p.trim(),
                        fontSize = readerSettings.fontSizeSp.sp,
                        lineHeight = (readerSettings.fontSizeSp * readerSettings.lineSpacingMultiplier).sp,
                        color = textColor
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
