package com.example.bharatbrowser.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NorthEast
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.bharatbrowser.model.LanguageProfile
import com.example.bharatbrowser.model.LanguageRegistry
import com.example.bharatbrowser.search.IndiaPortals
import com.example.bharatbrowser.search.PortalArticle
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SaffronDeep
import com.example.ui.theme.SaffronLight
import com.example.ui.theme.SaffronWarm
import com.example.ui.theme.SepiaVedic
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.WarmIvory

data class QuickPortalLink(
    val title: String,
    val subtitle: String,
    val url: String,
    val icon: ImageVector,
    val color: Color,
    val articleId: String? = null
)

@Composable
fun NewTabScreen(
    viewModel: BharatBrowserViewModel,
    modifier: Modifier = Modifier
) {
    val uiLang by viewModel.uiLanguage.collectAsState()
    val isPrivate by viewModel.isPrivateBrowsing.collectAsState()
    val privacyStats by viewModel.privacyStats.collectAsState()
    val isLiteMode by viewModel.isLiteMode.collectAsState()

    val quickPortals = listOf(
        QuickPortalLink(
            title = "डिजिटल इण्डिया",
            subtitle = "DPI & वित्तीय समावेशन",
            url = "https://digitalindia.gov.in/dpi-progress-2026",
            icon = Icons.Outlined.AccountBalance,
            color = SaffronDeep,
            articleId = "dpi-india-hi"
        ),
        QuickPortalLink(
            title = "भारतीय रेल",
            subtitle = "वंदे भारत & आरक्षण",
            url = "https://indianrailways.gov.in/vande-bharat-expansion",
            icon = Icons.Default.Train,
            color = Color(0xFF1D4ED8),
            articleId = "railways-vande-bharat"
        ),
        QuickPortalLink(
            title = "ISRO विज्ञान",
            subtitle = "गगनयान & आदित्य-L1",
            url = "https://isro.gov.in/missions/deep-space-advances-2026",
            icon = Icons.Outlined.Science,
            color = EmeraldGreen,
            articleId = "isro-chandrayaan-science"
        ),
        QuickPortalLink(
            title = "தமிழ் செய்தி",
            subtitle = "பசுமை ஆற்றல் மையம்",
            url = "https://seithi.tn.gov.in/green-energy-semiconductor-2026",
            icon = Icons.Default.MenuBook,
            color = Color(0xFF9333EA),
            articleId = "tamil-nadu-green-tech"
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(if (isPrivate) Slate900 else MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 80.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(28.dp))

        // Center Identity Emblem
        Box(
            modifier = Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(SaffronWarm.copy(alpha = 0.25f), Color.Transparent)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_bharat_logo),
                contentDescription = "Bharat Browser Emblem",
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Title and Subtitle
        Text(
            text = if (uiLang.code == "en") "BHARAT BROWSER" else "भारत ब्राउज़र",
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.2.sp,
            color = if (isPrivate) Color.White else Slate900
        )

        Text(
            text = "भारतीय बहुभाषी वेब ब्राउज़र • Native Indic Computing",
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Central Quick Search Bar Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .clickable {
                    viewModel.setOmnibarFocus(true)
                }
                .testTag("newtab_search_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isPrivate) Slate800 else MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = SaffronDeep,
                    modifier = Modifier.size(22.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = uiLang.greetingsPrompt,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isPrivate) Color.White else Slate900
                    )
                    Text(
                        text = "URL, हिन्दी, English, தமிழ், বাংলা...",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SaffronWarm.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "भारत बार",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SaffronDeep,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Global Language Fast-Switch Bar (12 first-class languages)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language",
                        tint = SaffronDeep,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "भाषा चयन / Change Language",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "${uiLang.nativeName} (${uiLang.displayName})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SaffronDeep
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Horizontally scrollable language selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LanguageRegistry.allLanguages.forEach { lang ->
                    val isSelected = uiLang.code == lang.code
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) SaffronDeep else (if (isPrivate) Slate800 else MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier
                            .clickable { viewModel.setUiLanguage(lang) }
                            .testTag("lang_chip_${lang.code}")
                    ) {
                        Text(
                            text = lang.nativeName,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Weather & Regional Information Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .clickable {
                    viewModel.executeWebSearch("मौसम पूर्वानुमान")
                },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isPrivate) Slate800 else WarmIvory
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(EmeraldGreen.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cloud,
                            contentDescription = "Weather",
                            tint = EmeraldGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "राष्ट्रीय मौसम एवं वायु गुणवत्ता",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPrivate) Color.White else Slate900
                        )
                        Text(
                            text = "नई दिल्ली, मुम्बई, चेन्नई, कोलकाता: 28°C • सुखद हवा",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.NorthEast,
                    contentDescription = "Go",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Curated Indian Portals (Favourites)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            Text(
                text = "प्रमुख राष्ट्रीय मंच / Quick Portals",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            quickPortals.forEach { portal ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .clickable {
                            if (portal.articleId != null) {
                                val art = IndiaPortals.articles.find { it.id == portal.articleId }
                                if (art != null) {
                                    viewModel.openPortalArticle(art)
                                    return@clickable
                                }
                            }
                            viewModel.navigateToUrl(portal.url)
                        }
                        .testTag("portal_item_${portal.title}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPrivate) Slate800 else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(portal.color.copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = portal.icon,
                                contentDescription = portal.title,
                                tint = portal.color,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = portal.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isPrivate) Color.White else Slate900
                            )
                            Text(
                                text = portal.subtitle,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.NorthEast,
                            contentDescription = "Open",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Privacy & Connectivity Indicator Glance
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .clickable { viewModel.navigateToScreen(ActiveScreen.PRIVACY) },
            shape = RoundedCornerShape(14.dp),
            color = if (isPrivate) Slate800 else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "Privacy Shield",
                        tint = EmeraldGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "सुरक्षा ढाल: ${privacyStats.trackersBlocked} ट्रैकर अवरुद्ध • ${privacyStats.formattedDataSaved} डेटा बचत",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = "विवरण",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SaffronDeep
                )
            }
        }
    }
}
