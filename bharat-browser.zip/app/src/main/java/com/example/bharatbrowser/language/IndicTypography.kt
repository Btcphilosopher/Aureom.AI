package com.example.bharatbrowser.language

import java.text.Normalizer

object IndicTypography {

    /**
     * Normalizes text using Unicode Canonical Decomposition followed by Canonical Composition (NFC).
     * Essential for Indic scripts where combining vowel marks and viramas must remain in standard canonical form.
     */
    fun normalizeNFC(text: String): String {
        return Normalizer.normalize(text, Normalizer.Form.NFC)
    }

    /**
     * Splits text into grapheme clusters to ensure Indic conjuncts, viramas, and nuktas
     * are never severed or corrupted during truncation, selection, or wrapping.
     */
    fun getGraphemeClusters(text: String): List<String> {
        val normalized = normalizeNFC(text)
        val clusters = mutableListOf<String>()
        val sb = StringBuilder()

        var i = 0
        while (i < normalized.length) {
            val cp = normalized.codePointAt(i)
            val charCount = Character.charCount(cp)
            val currentChunk = normalized.substring(i, i + charCount)

            // Indic combining characters, viramas (halants), vowel signs, matras, ZWJ (U+200D), ZWNJ (U+200C)
            val isCombining = isIndicCombiningOrJoiner(cp)

            if (isCombining && sb.isNotEmpty()) {
                sb.append(currentChunk)
            } else {
                if (sb.isNotEmpty()) {
                    clusters.add(sb.toString())
                    sb.clear()
                }
                sb.append(currentChunk)
            }
            i += charCount
        }

        if (sb.isNotEmpty()) {
            clusters.add(sb.toString())
        }

        return clusters
    }

    private fun isIndicCombiningOrJoiner(cp: Int): Boolean {
        // ZWJ & ZWNJ
        if (cp == 0x200D || cp == 0x200C) return true
        // Combining Diacritical Marks & Indic vowel signs / viramas across scripts
        val type = Character.getType(cp)
        if (type == Character.NON_SPACING_MARK.toInt() ||
            type == Character.COMBINING_SPACING_MARK.toInt() ||
            type == Character.ENCLOSING_MARK.toInt()) {
            return true
        }
        // Specific Indic Viramas / Matras ranges
        return when (cp) {
            in 0x0901..0x0903, in 0x093E..0x094F, in 0x0951..0x0957 -> true // Devanagari
            in 0x0981..0x0983, in 0x09BE..0x09CD, 0x09D7 -> true // Bengali
            in 0x0A01..0x0A03, in 0x0A3E..0x0A4D -> true // Gurmukhi
            in 0x0A81..0x0A83, in 0x0ABE..0x0ACD -> true // Gujarati
            in 0x0B01..0x0B03, in 0x0B3E..0x0B4D -> true // Odia
            0x0B82, in 0x0BBE..0x0BCD, 0x0BD7 -> true // Tamil
            in 0x0C01..0x0C03, in 0x0C3E..0x0C4D, in 0x0C55..0x0C56 -> true // Telugu
            in 0x0C82..0x0C83, in 0x0CBE..0x0CCD, in 0x0CD5..0x0CD6 -> true // Kannada
            in 0x0D02..0x0D03, in 0x0D3E..0x0D4D, 0x0D57 -> true // Malayalam
            in 0x064B..0x065F, 0x0670 -> true // Arabic / Urdu Tashkeel
            else -> false
        }
    }

    /**
     * Formats numbers using the Indian numbering system:
     * e.g. 1,25,00,000 instead of Western 12,500,000.
     */
    fun formatIndianNumber(number: Long): String {
        val s = number.toString()
        if (s.length <= 3) return s

        val lastThree = s.substring(s.length - 3)
        var remaining = s.substring(0, s.length - 3)

        val parts = mutableListOf<String>()
        while (remaining.length > 2) {
            parts.add(0, remaining.substring(remaining.length - 2))
            remaining = remaining.substring(0, remaining.length - 2)
        }
        if (remaining.isNotEmpty()) {
            parts.add(0, remaining)
        }

        return parts.joinToString(",") + ",$lastThree"
    }

    fun formatIndianCurrency(amount: Long): String {
        return "₹" + formatIndianNumber(amount)
    }

    /**
     * Safe truncation that respects grapheme clusters so ligatures or conjuncts are never cut in half.
     */
    fun safeTruncate(text: String, maxGraphemes: Int): String {
        val clusters = getGraphemeClusters(text)
        if (clusters.size <= maxGraphemes) return text
        return clusters.take(maxGraphemes).joinToString("") + "…"
    }
}
