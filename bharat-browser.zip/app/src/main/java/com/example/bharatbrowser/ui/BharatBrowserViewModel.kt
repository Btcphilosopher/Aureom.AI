package com.example.bharatbrowser.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.bharatbrowser.ai.AIPrivacyMode
import com.example.bharatbrowser.ai.BharatAIAssistant
import com.example.bharatbrowser.ai.PageAISummary
import com.example.bharatbrowser.language.IndicTypography
import com.example.bharatbrowser.language.LocalTransliterationProvider
import com.example.bharatbrowser.language.ScriptDetector
import com.example.bharatbrowser.language.TranslationEngine
import com.example.bharatbrowser.model.BookmarkItem
import com.example.bharatbrowser.model.BrowserTab
import com.example.bharatbrowser.model.DataTransparencyLog
import com.example.bharatbrowser.model.HistoryItem
import com.example.bharatbrowser.model.IndicScript
import com.example.bharatbrowser.model.LanguageProfile
import com.example.bharatbrowser.model.LanguageRegistry
import com.example.bharatbrowser.model.PrivacyStats
import com.example.bharatbrowser.model.ReaderSettings
import com.example.bharatbrowser.model.ReaderTheme
import com.example.bharatbrowser.model.ResearchClip
import com.example.bharatbrowser.model.TabGroup
import com.example.bharatbrowser.search.IndiaPortals
import com.example.bharatbrowser.search.PortalArticle
import com.example.bharatbrowser.search.SearchCore
import com.example.bharatbrowser.search.SearchIntent
import com.example.bharatbrowser.voice.SpeechService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class ActiveScreen {
    BROWSER_HOME, // New Tab
    WEB_PAGE,     // Active Web Page / Portal
    READER_MODE,  // Multilingual Reader
    TAB_MANAGER,  // Tab Grid & Groups
    BOOKMARKS,    // Multilingual Bookmarks
    HISTORY,      // History
    RESEARCH,     // Bharat Research Workspace
    PRIVACY,      // Privacy & Security Dashboard
    SETTINGS,     // Settings
    AI_PANEL      // Bharat AI Overlay
}

class BharatBrowserViewModel(application: Application) : AndroidViewModel(application) {

    val speechService = SpeechService(application)
    private val transliterationProvider = LocalTransliterationProvider()

    // --- Language Profiles ---
    private val _uiLanguage = MutableStateFlow(LanguageRegistry.HINDI)
    val uiLanguage: StateFlow<LanguageProfile> = _uiLanguage.asStateFlow()

    private val _inputLanguage = MutableStateFlow(LanguageRegistry.HINDI)
    val inputLanguage: StateFlow<LanguageProfile> = _inputLanguage.asStateFlow()

    private val _translationTargetLanguage = MutableStateFlow(LanguageRegistry.ENGLISH)
    val translationTargetLanguage: StateFlow<LanguageProfile> = _translationTargetLanguage.asStateFlow()

    private val _transliterationEnabled = MutableStateFlow(true)
    val transliterationEnabled: StateFlow<Boolean> = _transliterationEnabled.asStateFlow()

    // --- Navigation & Screen State ---
    private val _activeScreen = MutableStateFlow(ActiveScreen.BROWSER_HOME)
    val activeScreen: StateFlow<ActiveScreen> = _activeScreen.asStateFlow()

    // --- Tabs ---
    private val _tabs = MutableStateFlow<List<BrowserTab>>(listOf(
        BrowserTab(
            id = "tab_initial",
            url = "bharat://newtab",
            title = "नया पृष्ठ / New Tab",
            languageCode = "hi"
        )
    ))
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow("tab_initial")
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    private val _tabGroups = MutableStateFlow<List<TabGroup>>(listOf(
        TabGroup(id = "grp_samachar", name = "भारत समाचार", colorHex = 0xFFD97706),
        TabGroup(id = "grp_research", name = "Research & DPI", colorHex = 0xFF047857),
        TabGroup(id = "grp_railways", name = "भारतीय रेल", colorHex = 0xFF2563EB)
    ))
    val tabGroups: StateFlow<List<TabGroup>> = _tabGroups.asStateFlow()

    private val closedTabsStack = mutableListOf<BrowserTab>()

    // --- Omnibar (Bharat Bar) ---
    private val _omnibarText = MutableStateFlow("")
    val omnibarText: StateFlow<String> = _omnibarText.asStateFlow()

    private val _isOmnibarFocused = MutableStateFlow(false)
    val isOmnibarFocused: StateFlow<Boolean> = _isOmnibarFocused.asStateFlow()

    private val _transliterationCandidates = MutableStateFlow<List<String>>(emptyList())
    val transliterationCandidates: StateFlow<List<String>> = _transliterationCandidates.asStateFlow()

    private val _detectedInputScript = MutableStateFlow(IndicScript.DEVANAGARI)
    val detectedInputScript: StateFlow<IndicScript> = _detectedInputScript.asStateFlow()

    private val _calculatorResult = MutableStateFlow<String?>(null)
    val calculatorResult: StateFlow<String?> = _calculatorResult.asStateFlow()

    // --- Current Page & Content ---
    private val _currentArticle = MutableStateFlow<PortalArticle?>(null)
    val currentArticle: StateFlow<PortalArticle?> = _currentArticle.asStateFlow()

    private val _liveWebUrl = MutableStateFlow<String?>(null)
    val liveWebUrl: StateFlow<String?> = _liveWebUrl.asStateFlow()

    // Search results list when a query is searched
    private val _searchResults = MutableStateFlow<List<PortalArticle>>(emptyList())
    val searchResults: StateFlow<List<PortalArticle>> = _searchResults.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // --- Reader Mode ---
    private val _readerSettings = MutableStateFlow(ReaderSettings())
    val readerSettings: StateFlow<ReaderSettings> = _readerSettings.asStateFlow()

    private val _translatedArticleContent = MutableStateFlow<String?>(null)
    val translatedArticleContent: StateFlow<String?> = _translatedArticleContent.asStateFlow()

    // --- Bookmarks & History ---
    private val _bookmarks = MutableStateFlow<List<BookmarkItem>>(listOf(
        BookmarkItem(
            id = "bm_1",
            title = "डिजिटल इण्डिया पोर्टल - DPI Progress",
            url = "https://digitalindia.gov.in/dpi-progress-2026",
            folder = "डिजिटल भारत",
            languageCode = "hi"
        ),
        BookmarkItem(
            id = "bm_2",
            title = "भारतीय रेल आधिकारिक पोर्टल - Vande Bharat",
            url = "https://indianrailways.gov.in/vande-bharat-expansion",
            folder = "रेलवे",
            languageCode = "hi"
        ),
        BookmarkItem(
            id = "bm_3",
            title = "ISRO Deep Space Advances",
            url = "https://isro.gov.in/missions/deep-space-advances-2026",
            folder = "विज्ञान / Science",
            languageCode = "en"
        ),
        BookmarkItem(
            id = "bm_4",
            title = "தமிழ்நாடு பசுமை ஆற்றல் திட்டம்",
            url = "https://seithi.tn.gov.in/green-energy-semiconductor-2026",
            folder = "தமிழ் செய்திகள்",
            languageCode = "ta"
        )
    ))
    val bookmarks: StateFlow<List<BookmarkItem>> = _bookmarks.asStateFlow()

    private val _history = MutableStateFlow<List<HistoryItem>>(emptyList())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    // --- Bharat Research Workspace ---
    private val _researchClips = MutableStateFlow<List<ResearchClip>>(listOf(
        ResearchClip(
            id = "clip_initial",
            workspace = "Digital Public Infrastructure",
            title = "DPI एवं वित्तीय समावेशन",
            url = "https://digitalindia.gov.in/dpi-progress-2026",
            source = "डिजिटल इण्डिया पोर्टल",
            author = "डॉ. राजगोपालन",
            date = "2026",
            language = "hi",
            originalText = "डिजिटल पब्लिक इन्फ्रास्ट्रक्चर (DPI) ने लाखों नागरिकों के जीवन को सुगम बनाया है। चालू वित्तीय वर्ष में लेन-देन ₹25,00,000 करोड़ के पार पहुँच गया।",
            translationText = "Digital Public Infrastructure (DPI) has simplified the lives of millions of citizens. Transactions crossed ₹25,00,000 crore this fiscal year.",
            notes = "भारत के डीपीआई मॉडल को वैश्विक संदर्भ में उद्धृत करने हेतु उपयुक्त।"
        )
    ))
    val researchClips: StateFlow<List<ResearchClip>> = _researchClips.asStateFlow()

    // --- Privacy & Security ---
    private val _privacyStats = MutableStateFlow(PrivacyStats())
    val privacyStats: StateFlow<PrivacyStats> = _privacyStats.asStateFlow()

    private val _isPrivateBrowsing = MutableStateFlow(false)
    val isPrivateBrowsing: StateFlow<Boolean> = _isPrivateBrowsing.asStateFlow()

    private val _dataTransparencyLogs = MutableStateFlow<List<DataTransparencyLog>>(listOf(
        DataTransparencyLog(
            id = "log_1",
            operation = "Local Indic Phonetic Transliteration",
            whatWasSent = "Phonetic key mapping (Local Engine)",
            whyItWasSent = "Candidate suggestions for Romanized typing",
            destination = "Zero External Traffic (Processed entirely on-device)",
            retention = "None (Volatile RAM only)"
        ),
        DataTransparencyLog(
            id = "log_2",
            operation = "Tracker Defense Filter",
            whatWasSent = "Blocklist lookup for telemetry beacon URLs",
            whyItWasSent = "Prevent third-party tracking across Indian regional portals",
            destination = "Internal Security Sandbox",
            retention = "Permanent block rule"
        )
    ))
    val dataTransparencyLogs: StateFlow<List<DataTransparencyLog>> = _dataTransparencyLogs.asStateFlow()

    // --- Lite Mode ---
    private val _isLiteMode = MutableStateFlow(true)
    val isLiteMode: StateFlow<Boolean> = _isLiteMode.asStateFlow()

    // --- AI Assistant ---
    private val _aiPrivacyMode = MutableStateFlow(AIPrivacyMode.LOCAL_ONLY)
    val aiPrivacyMode: StateFlow<AIPrivacyMode> = _aiPrivacyMode.asStateFlow()

    private val _currentAISummary = MutableStateFlow<PageAISummary?>(null)
    val currentAISummary: StateFlow<PageAISummary?> = _currentAISummary.asStateFlow()

    private val _aiQueryAnswer = MutableStateFlow<String?>(null)
    val aiQueryAnswer: StateFlow<String?> = _aiQueryAnswer.asStateFlow()

    // --- Notification & Toast message ---
    private val _statusNotice = MutableStateFlow<String?>(null)
    val statusNotice: StateFlow<String?> = _statusNotice.asStateFlow()

    init {
        // Record initial history
        recordHistory("भारत ब्राउज़र - मुख्य पृष्ठ", "bharat://newtab", "hi")
    }

    // --- Language Actions ---
    fun setUiLanguage(language: LanguageProfile) {
        _uiLanguage.value = language
        speechService.setLanguage(language.code)
        showNotice("भाषा बदली गई: ${language.nativeName} (${language.displayName})")
    }

    fun setInputLanguage(language: LanguageProfile) {
        _inputLanguage.value = language
    }

    fun setTranslationTargetLanguage(language: LanguageProfile) {
        _translationTargetLanguage.value = language
        // Re-translate current article if already translated
        val art = _currentArticle.value
        if (art != null && _translatedArticleContent.value != null) {
            translateCurrentPage(language.code)
        }
    }

    fun toggleTransliteration() {
        _transliterationEnabled.value = !_transliterationEnabled.value
        val state = if (_transliterationEnabled.value) "सक्रिय (ON)" else "निष्क्रिय (OFF)"
        showNotice("लिप्यंतरण (Transliteration) $state")
    }

    // --- Omnibar Input & Transliteration ---
    fun onOmnibarTextChanged(newText: String) {
        _omnibarText.value = newText
        _calculatorResult.value = null

        val script = ScriptDetector.detectScript(newText)
        _detectedInputScript.value = script

        if (_transliterationEnabled.value && script == IndicScript.LATIN && newText.isNotBlank()) {
            val candidates = transliterationProvider.transliterate(newText, _inputLanguage.value.code)
            _transliterationCandidates.value = candidates
        } else {
            _transliterationCandidates.value = emptyList()
        }

        // Quick check for math
        val intent = SearchCore.parseInput(newText, _inputLanguage.value.code)
        if (intent is SearchIntent.Calculator) {
            _calculatorResult.value = intent.result
        }
    }

    fun applyTransliterationCandidate(candidate: String) {
        _omnibarText.value = candidate
        _transliterationCandidates.value = emptyList()
        val script = ScriptDetector.detectScript(candidate)
        _detectedInputScript.value = script
    }

    fun setOmnibarFocus(focused: Boolean) {
        _isOmnibarFocused.value = focused
    }

    // --- Search & Navigation ---
    fun submitOmnibar() {
        val raw = _omnibarText.value.trim()
        if (raw.isEmpty()) return
        _isOmnibarFocused.value = false

        when (val intent = SearchCore.parseInput(raw, _inputLanguage.value.code)) {
            is SearchIntent.BrowserCommand -> {
                handleCommand(intent.command, intent.arg)
            }
            is SearchIntent.Calculator -> {
                // Show result in notice
                showNotice("गणना परिणाम: ${intent.expression} = ${intent.result}")
            }
            is SearchIntent.DirectUrl -> {
                navigateToUrl(intent.url)
            }
            is SearchIntent.WebSearch -> {
                executeWebSearch(intent.rawQuery, intent.transliteratedSuggestion)
            }
        }
    }

    private fun handleCommand(cmd: String, arg: String) {
        when (cmd) {
            "reader" -> toggleReaderMode()
            "research" -> navigateToScreen(ActiveScreen.RESEARCH)
            "privacy" -> navigateToScreen(ActiveScreen.PRIVACY)
            "tabs" -> navigateToScreen(ActiveScreen.TAB_MANAGER)
            "bookmarks" -> navigateToScreen(ActiveScreen.BOOKMARKS)
            "history" -> navigateToScreen(ActiveScreen.HISTORY)
            "settings" -> navigateToScreen(ActiveScreen.SETTINGS)
            "ai" -> openAIAssistant()
            "newtab" -> openNewTab()
            else -> showNotice("अज्ञात कमांड: :$cmd")
        }
    }

    fun executeWebSearch(query: String, transliteratedSuggestion: String? = null) {
        val q = query.trim()
        if (q.isEmpty()) return

        _searchQuery.value = q
        val results = IndiaPortals.searchArticles(q)
        _searchResults.value = results

        // Increment privacy metrics for the search event
        incrementPrivacyCounters(trackers = 2, cookies = 1, https = 1, bytes = 124000L)

        if (results.size == 1) {
            // Direct hit on article
            openPortalArticle(results.first())
        } else {
            // Load search results view
            _currentArticle.value = null
            _liveWebUrl.value = null
            _activeScreen.value = ActiveScreen.WEB_PAGE
            updateCurrentTabTitle(title = "खोज: $q", url = "bharat://search?q=$q")
            recordHistory("खोज: $q", "bharat://search?q=$q", _inputLanguage.value.code)
        }
    }

    fun navigateToUrl(url: String) {
        val trimmed = url.trim()
        if (trimmed == "bharat://newtab" || trimmed.isEmpty()) {
            openNewTab()
            return
        }

        // Check if matching curated portal article
        val article = IndiaPortals.findByUrl(trimmed)
        if (article != null) {
            openPortalArticle(article)
            return
        }

        // Otherwise load in live WebView
        _currentArticle.value = null
        _searchResults.value = emptyList()
        _liveWebUrl.value = trimmed
        _activeScreen.value = ActiveScreen.WEB_PAGE
        _omnibarText.value = trimmed
        updateCurrentTabTitle(title = trimmed, url = trimmed)
        recordHistory(trimmed, trimmed, "en")
        incrementPrivacyCounters(trackers = 3, cookies = 2, https = 1, bytes = 350000L)
    }

    fun openPortalArticle(article: PortalArticle) {
        _currentArticle.value = article
        _liveWebUrl.value = null
        _searchResults.value = emptyList()
        _translatedArticleContent.value = null
        _omnibarText.value = article.url
        _activeScreen.value = ActiveScreen.WEB_PAGE

        updateCurrentTabTitle(
            title = article.title,
            url = article.url,
            langCode = article.languageCode
        )
        recordHistory(article.title, article.url, article.languageCode)
        incrementPrivacyCounters(trackers = 1, cookies = 1, https = 1, bytes = 180000L)

        // Automatically prepare AI summary in background
        prepareAISummary(article)
    }

    // --- Tab Management ---
    fun openNewTab(initialUrl: String = "bharat://newtab") {
        val newTab = BrowserTab(
            id = "tab_${UUID.randomUUID().toString().take(8)}",
            url = initialUrl,
            title = "नया पृष्ठ / New Tab",
            languageCode = _uiLanguage.value.code
        )
        _tabs.value = _tabs.value + newTab
        _activeTabId.value = newTab.id
        _currentArticle.value = null
        _liveWebUrl.value = null
        _searchResults.value = emptyList()
        _omnibarText.value = ""
        _activeScreen.value = ActiveScreen.BROWSER_HOME
    }

    fun switchTab(tabId: String) {
        val target = _tabs.value.find { it.id == tabId } ?: return
        _activeTabId.value = tabId
        if (target.url == "bharat://newtab") {
            _activeScreen.value = ActiveScreen.BROWSER_HOME
            _currentArticle.value = null
            _liveWebUrl.value = null
            _omnibarText.value = ""
        } else {
            navigateToUrl(target.url)
        }
    }

    fun closeTab(tabId: String) {
        val currentList = _tabs.value
        val tabToClose = currentList.find { it.id == tabId } ?: return
        closedTabsStack.add(tabToClose)

        if (currentList.size <= 1) {
            // Keep at least one new tab
            val freshTab = BrowserTab(
                id = "tab_${UUID.randomUUID().toString().take(8)}",
                url = "bharat://newtab",
                title = "नया पृष्ठ / New Tab",
                languageCode = _uiLanguage.value.code
            )
            _tabs.value = listOf(freshTab)
            _activeTabId.value = freshTab.id
            _activeScreen.value = ActiveScreen.BROWSER_HOME
            _currentArticle.value = null
            _liveWebUrl.value = null
            _omnibarText.value = ""
            return
        }

        val remaining = currentList.filter { it.id != tabId }
        _tabs.value = remaining
        if (_activeTabId.value == tabId) {
            val nextTab = remaining.last()
            switchTab(nextTab.id)
        }
    }

    fun duplicateTab(tabId: String) {
        val src = _tabs.value.find { it.id == tabId } ?: return
        val dup = src.copy(id = "tab_${UUID.randomUUID().toString().take(8)}")
        _tabs.value = _tabs.value + dup
        switchTab(dup.id)
        showNotice("टैब की प्रतिलिपि बनाई गई: ${dup.title}")
    }

    fun togglePinTab(tabId: String) {
        _tabs.value = _tabs.value.map {
            if (it.id == tabId) it.copy(isPinned = !it.isPinned) else it
        }
    }

    fun reopenClosedTab() {
        if (closedTabsStack.isEmpty()) {
            showNotice("पुनः खोलने के लिए कोई बंद टैब नहीं है")
            return
        }
        val restored = closedTabsStack.removeAt(closedTabsStack.lastIndex)
        _tabs.value = _tabs.value + restored
        switchTab(restored.id)
        showNotice("टैब पुनः खोला गया: ${restored.title}")
    }

    private fun updateCurrentTabTitle(title: String, url: String, langCode: String = "hi") {
        val currId = _activeTabId.value
        _tabs.value = _tabs.value.map { tab ->
            if (tab.id == currId) {
                tab.copy(title = title, url = url, languageCode = langCode)
            } else {
                tab
            }
        }
    }

    // --- Reader Mode ---
    fun toggleReaderMode() {
        if (_activeScreen.value == ActiveScreen.READER_MODE) {
            _activeScreen.value = ActiveScreen.WEB_PAGE
        } else {
            if (_currentArticle.value != null || _liveWebUrl.value != null) {
                _activeScreen.value = ActiveScreen.READER_MODE
            } else {
                showNotice("रीडर मोड केवल वेब लेखों के लिए उपलब्ध है")
            }
        }
    }

    fun updateReaderSettings(
        fontSizeSp: Int? = null,
        theme: ReaderTheme? = null,
        bilingual: Boolean? = null,
        targetLang: String? = null
    ) {
        val current = _readerSettings.value
        _readerSettings.value = current.copy(
            fontSizeSp = fontSizeSp ?: current.fontSizeSp,
            theme = theme ?: current.theme,
            bilingualLayout = bilingual ?: current.bilingualLayout,
            translationTargetLang = targetLang ?: current.translationTargetLang
        )
    }

    fun translateCurrentPage(targetLangCode: String = _translationTargetLanguage.value.code) {
        val article = _currentArticle.value ?: return
        viewModelScope.launch {
            val paragraphs = article.fullContent.split("\n\n").filter { it.isNotBlank() }
            val translatedParagraphs = paragraphs.map { p ->
                TranslationEngine.translateSentence(p, article.languageCode, targetLangCode)
            }
            _translatedArticleContent.value = translatedParagraphs.joinToString("\n\n")
            showNotice("अनुवाद पूर्ण: ${article.languageCode.uppercase()} → ${targetLangCode.uppercase()}")
        }
    }

    fun listenToArticle() {
        val article = _currentArticle.value ?: return
        val textToSpeak = _translatedArticleContent.value ?: article.fullContent
        val langCode = if (_translatedArticleContent.value != null) _translationTargetLanguage.value.code else article.languageCode
        speechService.speak(textToSpeak, langCode)
        showNotice("वाचन प्रारंभ: सुन रहे हैं...")
    }

    fun stopListening() {
        speechService.stop()
    }

    // --- Bharat Research Workspace ---
    fun saveResearchExcerpt(
        customNotes: String = "",
        customExcerpt: String? = null,
        workspaceName: String = "Digital Public Infrastructure"
    ) {
        val article = _currentArticle.value
        val title = article?.title ?: _liveWebUrl.value ?: "वेब शोध लेख"
        val url = article?.url ?: _liveWebUrl.value ?: "bharat://active"
        val author = article?.author ?: "Bureau / Web Author"
        val lang = article?.languageCode ?: "hi"
        val orig = customExcerpt ?: article?.excerpt ?: article?.fullContent?.take(200) ?: "उद्धरण पाठ"
        val trans = TranslationEngine.translateSentence(orig, lang, "en")

        val newClip = ResearchClip(
            id = "clip_${UUID.randomUUID().toString().take(8)}",
            workspace = workspaceName,
            title = title,
            url = url,
            source = article?.sourceName ?: "Bharat Web",
            author = author,
            language = lang,
            originalText = orig,
            translationText = trans,
            notes = customNotes.ifBlank { "सत्यापित स्रोत एवं उद्धरण" }
        )

        _researchClips.value = listOf(newClip) + _researchClips.value
        showNotice("शोध कार्यक्षेत्र में सहेजा गया: $title")
    }

    fun deleteResearchClip(clipId: String) {
        _researchClips.value = _researchClips.value.filter { it.id != clipId }
    }

    // --- Bookmarks & History ---
    fun toggleBookmarkCurrentPage() {
        val currentUrl = _currentArticle.value?.url ?: _liveWebUrl.value ?: return
        val existing = _bookmarks.value.find { it.url == currentUrl }
        if (existing != null) {
            _bookmarks.value = _bookmarks.value.filter { it.url != currentUrl }
            showNotice("बुकमार्क हटाया गया")
        } else {
            val title = _currentArticle.value?.title ?: currentUrl
            val bm = BookmarkItem(
                id = "bm_${UUID.randomUUID().toString().take(8)}",
                title = title,
                url = currentUrl,
                folder = "मुख्य / General",
                languageCode = _currentArticle.value?.languageCode ?: "hi"
            )
            _bookmarks.value = listOf(bm) + _bookmarks.value
            showNotice("बुकमार्क में जोड़ा गया: $title")
        }
    }

    fun isCurrentPageBookmarked(): Boolean {
        val currentUrl = _currentArticle.value?.url ?: _liveWebUrl.value ?: return false
        return _bookmarks.value.any { it.url == currentUrl }
    }

    private fun recordHistory(title: String, url: String, langCode: String) {
        if (_isPrivateBrowsing.value) return
        val item = HistoryItem(
            id = "hist_${UUID.randomUUID().toString().take(8)}",
            title = title,
            url = url,
            languageCode = langCode
        )
        _history.value = listOf(item) + _history.value.take(100)
    }

    fun clearBrowsingData() {
        _history.value = emptyList()
        showNotice("ब्राउज़िंग इतिहास सुरक्षित रूप से साफ़ किया गया")
    }

    // --- Privacy Dashboard & Lite Mode ---
    fun togglePrivateBrowsing() {
        _isPrivateBrowsing.value = !_isPrivateBrowsing.value
        val state = if (_isPrivateBrowsing.value) "सक्रिय (Private Browsing ON)" else "निष्क्रिय (OFF)"
        showNotice("निजी ब्राउज़िंग $state")
    }

    fun toggleLiteMode() {
        _isLiteMode.value = !_isLiteMode.value
        val state = if (_isLiteMode.value) "लाइट मोड सक्रिय (Lite Mode ON)" else "पूर्ण गुणवत्ता मोड"
        showNotice("कनेक्टिविटी मोड: $state")
    }

    fun setAIPrivacyMode(mode: AIPrivacyMode) {
        _aiPrivacyMode.value = mode
        showNotice("एआई गोपनीयता मोड: ${mode.label}")
    }

    private fun incrementPrivacyCounters(trackers: Int, cookies: Int, https: Int, bytes: Long) {
        val cur = _privacyStats.value
        _privacyStats.value = cur.copy(
            trackersBlocked = cur.trackersBlocked + trackers,
            cookiesBlocked = cur.cookiesBlocked + cookies,
            httpsUpgraded = cur.httpsUpgraded + https,
            thirdPartyRequestsBlocked = cur.thirdPartyRequestsBlocked + (trackers * 2),
            dataSavedBytes = cur.dataSavedBytes + bytes
        )
    }

    // --- Bharat AI ---
    private fun prepareAISummary(article: PortalArticle) {
        viewModelScope.launch {
            val summary = BharatAIAssistant.generateResearchSummary(
                articleTitle = article.title,
                content = article.fullContent,
                url = article.url,
                author = article.author,
                date = article.date,
                source = article.sourceName,
                privacyMode = _aiPrivacyMode.value,
                outputLanguage = _uiLanguage.value.code
            )
            _currentAISummary.value = summary
        }
    }

    fun openAIAssistant() {
        val art = _currentArticle.value
        if (art != null && _currentAISummary.value == null) {
            prepareAISummary(art)
        }
        _activeScreen.value = ActiveScreen.AI_PANEL
    }

    fun askAIQuestion(question: String) {
        val art = _currentArticle.value
        val content = art?.fullContent ?: "सामान्य राष्ट्रीय वेब सूचना"
        val answer = BharatAIAssistant.answerPageQuery(question, content, _uiLanguage.value.code)
        _aiQueryAnswer.value = answer
    }

    // --- Screen Navigation ---
    fun navigateToScreen(screen: ActiveScreen) {
        _activeScreen.value = screen
    }

    fun showNotice(message: String) {
        _statusNotice.value = message
    }

    fun dismissNotice() {
        _statusNotice.value = null
    }

    override fun onCleared() {
        super.onCleared()
        speechService.shutdown()
    }
}
