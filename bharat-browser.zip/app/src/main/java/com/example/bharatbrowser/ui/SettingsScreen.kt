package com.example.bharatbrowser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DataUsage
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bharatbrowser.ai.AIPrivacyMode
import com.example.bharatbrowser.model.LanguageRegistry
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SaffronDeep
import com.example.ui.theme.SaffronWarm
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun SettingsScreen(
    viewModel: BharatBrowserViewModel,
    modifier: Modifier = Modifier
) {
    val uiLang by viewModel.uiLanguage.collectAsState()
    val inputLang by viewModel.inputLanguage.collectAsState()
    val transTargetLang by viewModel.translationTargetLanguage.collectAsState()
    val translitOn by viewModel.transliterationEnabled.collectAsState()
    val isLiteMode by viewModel.isLiteMode.collectAsState()
    val aiPrivacyMode by viewModel.aiPrivacyMode.collectAsState()
    val isPrivate by viewModel.isPrivateBrowsing.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(if (isPrivate) Slate900 else MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateToScreen(ActiveScreen.WEB_PAGE) },
                modifier = Modifier.testTag("settings_back_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Column {
                Text(
                    text = "ब्राउज़र सेटिंग्स / Settings",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "भाषा, लिपि, गोपनीयता एवं कनेक्टिविटी प्राथमिकताएं",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Multilingual Language Matrix
            item {
                SettingsSectionHeader(title = "भाषा एवं लिपि सेटिंग्स (Languages & Scripts)")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        // Browser UI Language
                        SettingItemRow(
                            icon = Icons.Default.Language,
                            title = "ब्राउज़र यूआई भाषा (Browser UI Language)",
                            subtitle = "वर्तमान: ${uiLang.nativeName} (${uiLang.displayName})",
                            trailing = {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = SaffronDeep,
                                    modifier = Modifier.clickable {
                                        // Cycle through prominent languages
                                        val next = when (uiLang.code) {
                                            "hi" -> LanguageRegistry.ENGLISH
                                            "en" -> LanguageRegistry.TAMIL
                                            "ta" -> LanguageRegistry.BENGALI
                                            "bn" -> LanguageRegistry.MARATHI
                                            else -> LanguageRegistry.HINDI
                                        }
                                        viewModel.setUiLanguage(next)
                                    }
                                ) {
                                    Text(
                                        text = "बदलें",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                        // Default Translation Target
                        SettingItemRow(
                            icon = Icons.Default.Translate,
                            title = "डिफ़ॉल्ट अनुवाद लक्ष्य (Translation Target)",
                            subtitle = "वर्तमान: ${transTargetLang.nativeName} (${transTargetLang.displayName})",
                            trailing = {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.clickable {
                                        val next = if (transTargetLang.code == "en") LanguageRegistry.HINDI else LanguageRegistry.ENGLISH
                                        viewModel.setTranslationTargetLanguage(next)
                                    }
                                ) {
                                    Text(
                                        text = transTargetLang.code.uppercase(),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SaffronDeep,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                        // Transliteration Toggle
                        SettingItemRow(
                            icon = Icons.Default.Keyboard,
                            title = "रोमन → भारतीय लिप्यंतरण (Phonetic Transliteration)",
                            subtitle = "उदा. 'namaste' टाइप करने पर 'नमस्ते' का स्वतः सुझाव।",
                            trailing = {
                                Switch(
                                    checked = translitOn,
                                    onCheckedChange = { viewModel.toggleTransliteration() },
                                    colors = SwitchDefaults.colors(checkedThumbColor = SaffronDeep),
                                    modifier = Modifier.testTag("settings_translit_switch")
                                )
                            }
                        )
                    }
                }
            }

            // Section 2: Privacy & AI Research
            item {
                SettingsSectionHeader(title = "भारत एआई एवं गोपनीयता मोड (Bharat AI & Privacy)")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        AIPrivacyMode.values().forEach { mode ->
                            val isSelected = aiPrivacyMode == mode
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.setAIPrivacyMode(mode) }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { viewModel.setAIPrivacyMode(mode) },
                                    colors = RadioButtonDefaults.colors(selectedColor = SaffronDeep)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = mode.label,
                                        fontSize = 14.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = mode.description,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Section 3: Performance & India Lite Mode
            item {
                SettingsSectionHeader(title = "कनेक्टिविटी एवं लाइट मोड (Connectivity Mode)")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        SettingItemRow(
                            icon = Icons.Default.DataUsage,
                            title = "भारत लाइट मोड (Data Saver)",
                            subtitle = "कम बैंडविड्थ पर तेज़ टेक्स्ट प्राथमिकता एवं कैशिंग।",
                            trailing = {
                                Switch(
                                    checked = isLiteMode,
                                    onCheckedChange = { viewModel.toggleLiteMode() },
                                    colors = SwitchDefaults.colors(checkedThumbColor = EmeraldGreen)
                                )
                            }
                        )
                    }
                }
            }

            // Section 4: About Bharat Browser
            item {
                SettingsSectionHeader(title = "भारत ब्राउज़र के बारे में (About)")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "BHARAT BROWSER • भारतीय बहुभाषी वेब ब्राउज़र",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = SaffronDeep
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "संस्करण: v1.0.0 (Production Architecture 2026)",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "स्वदेशी कम्प्यूटिंग, भारतीय लिपियां, ओपनटाइप शेपिंग एवं शून्य-ट्रैकर वास्तुकला।",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = SaffronDeep,
        modifier = Modifier.padding(start = 4.dp, top = 4.dp)
    )
}

@Composable
private fun SettingItemRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = SaffronDeep,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))
        trailing()
    }
}
