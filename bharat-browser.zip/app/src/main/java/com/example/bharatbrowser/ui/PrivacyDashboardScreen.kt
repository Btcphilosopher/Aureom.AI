package com.example.bharatbrowser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cookie
import androidx.compose.material.icons.filled.DataUsage
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bharatbrowser.model.DataTransparencyLog
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.SaffronDeep
import com.example.ui.theme.SaffronWarm
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun PrivacyDashboardScreen(
    viewModel: BharatBrowserViewModel,
    modifier: Modifier = Modifier
) {
    val privacyStats by viewModel.privacyStats.collectAsState()
    val isPrivate by viewModel.isPrivateBrowsing.collectAsState()
    val isLiteMode by viewModel.isLiteMode.collectAsState()
    val transparencyLogs by viewModel.dataTransparencyLogs.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(if (isPrivate) Slate900 else MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateToScreen(ActiveScreen.WEB_PAGE) },
                modifier = Modifier.testTag("privacy_back_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Column {
                Text(
                    text = "गोपनीयता एवं सुरक्षा डैशबोर्ड",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Privacy & Security Control Center",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Event Metrics Grid
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "आज के लाइव सुरक्षा आंकड़े (Today's Shield Events):",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = SaffronDeep
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MetricItem(
                                title = "Trackers Blocked",
                                hindi = "अवरुद्ध ट्रैकर",
                                value = privacyStats.trackersBlocked.toString(),
                                color = EmeraldGreen
                            )
                            MetricItem(
                                title = "Cookies Sandboxed",
                                hindi = "सैंडबॉक्स्ड कुकीज़",
                                value = privacyStats.cookiesBlocked.toString(),
                                color = Color(0xFF2563EB)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MetricItem(
                                title = "HTTPS Secured",
                                hindi = "सुरक्षित कनेक्शन्स",
                                value = privacyStats.httpsUpgraded.toString(),
                                color = SaffronDeep
                            )
                            MetricItem(
                                title = "Data Saved",
                                hindi = "बचाया गया डेटा",
                                value = privacyStats.formattedDataSaved,
                                color = EmeraldGreen
                            )
                        }
                    }
                }
            }

            // Private Browsing Toggle Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPrivate) Slate800 else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VisibilityOff,
                                contentDescription = "Private Mode",
                                tint = if (isPrivate) SaffronWarm else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "निजी ब्राउज़िंग (Private Browsing)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPrivate) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "इतिहास, कुकीज़ और खोज रिकॉर्ड पूरी तरह शून्य रखे जाते हैं।",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Switch(
                            checked = isPrivate,
                            onCheckedChange = { viewModel.togglePrivateBrowsing() },
                            colors = SwitchDefaults.colors(checkedThumbColor = SaffronDeep),
                            modifier = Modifier.testTag("privacy_mode_switch")
                        )
                    }
                }
            }

            // Connectivity Lite Mode Toggle Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DataUsage,
                                contentDescription = "Lite Mode",
                                tint = EmeraldGreen,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "भारत लाइट मोड (Lite Data Mode)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "कमजोर नेटवर्क हेतु त्वरित टेक्स्ट रेंडरिंग एवं डेटा संपीड़न।",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Switch(
                            checked = isLiteMode,
                            onCheckedChange = { viewModel.toggleLiteMode() },
                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldGreen),
                            modifier = Modifier.testTag("lite_mode_switch")
                        )
                    }
                }
            }

            // Data Transparency Panel (MANDATORY REQUIREMENT)
            item {
                Text(
                    text = "डेटा पारदर्शिता पैनल / Data Transparency Panel",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            items(transparencyLogs) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = log.operation,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = SaffronDeep
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "क्या भेजा गया (What was sent): ${log.whatWasSent}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "कारण (Why): ${log.whyItWasSent}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "गंतव्य (Destination): ${log.destination}",
                            fontSize = 11.sp,
                            color = EmeraldGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "डेटा प्रतिधारण (Retention): ${log.retention}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Clear browsing data button
            item {
                Button(
                    onClick = { viewModel.clearBrowsingData() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("clear_browsing_data_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear History",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ब्राउज़िंग इतिहास और कैश साफ़ करें",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
private fun MetricItem(
    title: String,
    hindi: String,
    value: String,
    color: Color
) {
    Column(modifier = Modifier.width(140.dp)) {
        Text(
            text = value,
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            color = color
        )
        Text(
            text = hindi,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = title,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
