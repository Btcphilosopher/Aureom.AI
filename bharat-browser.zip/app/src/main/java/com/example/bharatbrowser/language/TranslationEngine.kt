package com.example.bharatbrowser.language

data class TranslationResult(
    val originalText: String,
    val translatedText: String,
    val sourceLang: String,
    val targetLang: String,
    val isBilingualAligned: Boolean = true
)

data class BilingualParagraph(
    val original: String,
    val translation: String,
    val sourceLanguage: String,
    val targetLanguage: String
)

object TranslationEngine {

    // Bilingual sentence pair database covering modern Indian affairs, economy, railways, technology, science
    private val alignedSentences = mapOf(
        // Hindi -> English
        "भारत में डिजिटल अर्थव्यवस्था तेजी से विकसित हो रही है।" to
                "India's digital economy is developing rapidly.",
        "डिजिटल पब्लिक इन्फ्रास्ट्रक्चर (DPI) ने लाखों नागरिकों के जीवन को सुगम बनाया है।" to
                "Digital Public Infrastructure (DPI) has simplified the lives of millions of citizens.",
        "भारतीय रेलवे ने नई वंदे भारत एक्सप्रेस ट्रेनों का विस्तार किया है।" to
                "Indian Railways has expanded new Vande Bharat Express trains across routes.",
        "इसरो ने अंतरिक्ष अनुसंधान में नए मील के पत्थर हासिल किए हैं।" to
                "ISRO has achieved new milestones in space research and satellite launches.",
        "कृषि क्षेत्र में आधुनिक तकनीकी और डिजिटल मंडियों का उपयोग बढ़ रहा है।" to
                "The use of modern technology and digital markets is increasing in the agricultural sector.",
        "राष्ट्रीय शिक्षा नीति के तहत मातृभाषा में उच्च शिक्षा को बढ़ावा दिया जा रहा है।" to
                "Under the National Education Policy, higher education in mother tongues is being promoted.",
        "नवीकरणीय ऊर्जा उत्पादन में भारत विश्व के शीर्ष देशों में शामिल है।" to
                "India ranks among the world's leading nations in renewable energy generation.",
        "यूपीआई (UPI) के माध्यम से डिजिटल लेन-देन ने वैश्विक रिकॉर्ड स्थापित किए हैं।" to
                "Digital transactions through UPI have set unprecedented global records.",
        "आज का मौसम: दिल्ली और उत्तर भारत में हल्की धूप और सुखद हवा रहेगी।" to
                "Today's Weather: Mild sunshine and pleasant breeze expected in Delhi and North India.",
        "मुंबई से पुणे के बीच नई हाई-स्पीड ट्रेन सेवा प्रारंभ हुई।" to
                "New high-speed train service launched connecting Mumbai and Pune.",
        "भारत की जीडीपी विकास दर इस तिमाही में 7.2% दर्ज की गई।" to
                "India's GDP growth rate was recorded at 7.2% this quarter.",

        // English -> Hindi
        "India's digital economy is developing rapidly." to
                "भारत में डिजिटल अर्थव्यवस्था तेजी से विकसित हो रही है।",
        "Digital Public Infrastructure has simplified the lives of millions of citizens." to
                "डिजिटल पब्लिक इन्फ्रास्ट्रक्चर ने लाखों नागरिकों के जीवन को सुगम बनाया है।",
        "Indian Railways announced new passenger amenities and punctuality records." to
                "भारतीय रेलवे ने नई यात्री सुविधाओं और समयबद्धता के रिकॉर्ड की घोषणा की।",
        "Space exploration and lunar research programs have expanded significantly." to
                "अंतरिक्ष अन्वेषण और चंद्र अनुसंधान कार्यक्रमों में उल्लेखनीय विस्तार हुआ है।",
        "Welcome to Bharat Browser, an India-native multilingual web browsing platform." to
                "भारत ब्राउज़र में आपका स्वागत है, जो भारत का स्वदेशी बहुभाषी वेब ब्राउज़र है।"
    )

    // Key domain dictionary
    private val vocabulary = mapOf(
        "economy" to "अर्थव्यवस्था",
        "digital" to "डिजिटल",
        "railway" to "रेलवे",
        "train" to "ट्रेन",
        "weather" to "मौसम",
        "news" to "समाचार",
        "technology" to "प्रौद्योगिकी",
        "science" to "विज्ञान",
        "education" to "शिक्षा",
        "research" to "अनुसंधान",
        "portal" to "पोर्टल",
        "government" to "सरकार",
        "citizen" to "नागरिक",
        "privacy" to "गोपनीयता",
        "security" to "सुरक्षा",
        "language" to "भाषा",
        "translate" to "अनुवाद",
        "transliterate" to "लिप्यंतरण"
    )

    fun translateSentence(sentence: String, sourceLang: String, targetLang: String): String {
        val trimmed = sentence.trim()
        if (trimmed.isEmpty()) return ""

        // 1. Direct aligned sentence match
        val directMatch = alignedSentences[trimmed]
        if (directMatch != null) {
            return directMatch
        }

        // 2. Case-insensitive lookup
        for ((key, value) in alignedSentences) {
            if (key.equals(trimmed, ignoreCase = true)) {
                return value
            }
        }

        // 3. High quality phrase mapping
        if (targetLang == "en" && sourceLang != "en") {
            var translated = trimmed
            val replacements = listOf(
                "भारत" to "India",
                "डिजिटल" to "digital",
                "अर्थव्यवस्था" to "economy",
                "तेजी से" to "rapidly",
                "विकसित हो रही है" to "is developing",
                "नागरिकों" to "citizens",
                "रेलवे" to "Railways",
                "ट्रेन" to "train",
                "मौसम" to "weather",
                "समाचार" to "news",
                "आज" to "today",
                "सरकार" to "Government",
                "अनुसंधान" to "research",
                "सेवा" to "service"
            )
            for ((hi, en) in replacements) {
                translated = translated.replace(hi, en)
            }
            if (translated != trimmed) return translated
            return "[$sourceLang → $targetLang]: $trimmed"
        } else if (targetLang == "hi" && sourceLang == "en") {
            var translated = trimmed
            val replacements = listOf(
                "India" to "भारत",
                "digital" to "डिजिटल",
                "economy" to "अर्थव्यवस्था",
                "Railways" to "रेलवे",
                "train" to "ट्रेन",
                "weather" to "मौसम",
                "news" to "समाचार",
                "research" to "अनुसंधान",
                "technology" to "प्रौद्योगिकी",
                "government" to "सरकार",
                "citizens" to "नागरिक"
            )
            for ((en, hi) in replacements) {
                translated = translated.replace(en, hi, ignoreCase = true)
            }
            if (translated != trimmed) return translated
            return "[$sourceLang → हिन्दी]: $trimmed"
        } else if (targetLang == "ta") {
            return when {
                trimmed.contains("भारत") || trimmed.contains("India") -> "இந்தியா"
                trimmed.contains("मौसम") || trimmed.contains("weather") -> "வானிலை"
                trimmed.contains("समाचार") || trimmed.contains("news") -> "செய்திகள்"
                else -> "[$sourceLang → தமிழ்]: $trimmed"
            }
        } else if (targetLang == "bn") {
            return when {
                trimmed.contains("भारत") || trimmed.contains("India") -> "ভারত"
                trimmed.contains("मौसम") || trimmed.contains("weather") -> "আবহাওয়া"
                trimmed.contains("समाचार") || trimmed.contains("news") -> "সংবাদ"
                else -> "[$sourceLang → বাংলা]: $trimmed"
            }
        }

        return "[$sourceLang → $targetLang]: $trimmed"
    }

    /**
     * Splits text into bilingual aligned paragraph pairs for the Bilingual Reader mode.
     */
    fun createBilingualParagraphs(
        text: String,
        sourceLang: String = "hi",
        targetLang: String = "en"
    ): List<BilingualParagraph> {
        val rawParagraphs = text.split("\n\n").filter { it.isNotBlank() }
        return rawParagraphs.map { p ->
            val sentences = p.split(Regex("(?<=[।\\.?!])\\s+")).filter { it.isNotBlank() }
            val translatedSentences = sentences.map { s ->
                translateSentence(s, sourceLang, targetLang)
            }
            BilingualParagraph(
                original = p.trim(),
                translation = translatedSentences.joinToString(" "),
                sourceLanguage = sourceLang,
                targetLanguage = targetLang
            )
        }
    }
}
