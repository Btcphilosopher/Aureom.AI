package com.example.bharatbrowser.model

enum class TextDirection {
    LTR,
    RTL
}

enum class IndicScript(val displayName: String, val unicodeRange: Pair<Int, Int>) {
    DEVANAGARI("Devanagari", 0x0900 to 0x097F),
    LATIN("Latin", 0x0020 to 0x007F),
    BENGALI("Bengali", 0x0980 to 0x09FF),
    GUJARATI("Gujarati", 0x0A80 to 0x0AFF),
    GURMUKHI("Gurmukhi", 0x0A00 to 0x0A7F),
    TAMIL("Tamil", 0x0B80 to 0x0BFF),
    TELUGU("Telugu", 0x0C00 to 0x0C7F),
    KANNADA("Kannada", 0x0C80 to 0x0CFF),
    MALAYALAM("Malayalam", 0x0D00 to 0x0D7F),
    ODIA("Odia", 0x0B00 to 0x0B7F),
    ARABIC_URDU("Urdu (Nastaliq/Arabic)", 0x0600 to 0x06FF),
    UNKNOWN("Universal", 0 to 0)
}

data class LanguageProfile(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val script: IndicScript,
    val direction: TextDirection = TextDirection.LTR,
    val locale: String,
    val fontFallback: String = "sans-serif",
    val hasTransliteration: Boolean = true,
    val hasSpeechSynthesis: Boolean = true,
    val greetingsPrompt: String = "आज क्या खोजें?"
)

object LanguageRegistry {
    val HINDI = LanguageProfile(
        code = "hi",
        displayName = "Hindi",
        nativeName = "हिन्दी",
        script = IndicScript.DEVANAGARI,
        direction = TextDirection.LTR,
        locale = "hi-IN",
        greetingsPrompt = "आज क्या खोजें?"
    )

    val ENGLISH = LanguageProfile(
        code = "en",
        displayName = "English",
        nativeName = "English",
        script = IndicScript.LATIN,
        direction = TextDirection.LTR,
        locale = "en-IN",
        greetingsPrompt = "What would you like to explore today?"
    )

    val BENGALI = LanguageProfile(
        code = "bn",
        displayName = "Bengali",
        nativeName = "বাংলা",
        script = IndicScript.BENGALI,
        direction = TextDirection.LTR,
        locale = "bn-IN",
        greetingsPrompt = "আজ কি খুঁজতে চান?"
    )

    val MARATHI = LanguageProfile(
        code = "mr",
        displayName = "Marathi",
        nativeName = "मराठी",
        script = IndicScript.DEVANAGARI,
        direction = TextDirection.LTR,
        locale = "mr-IN",
        greetingsPrompt = "आज काय शोधायचे आहे?"
    )

    val GUJARATI = LanguageProfile(
        code = "gu",
        displayName = "Gujarati",
        nativeName = "ગુજરાતી",
        script = IndicScript.GUJARATI,
        direction = TextDirection.LTR,
        locale = "gu-IN",
        greetingsPrompt = "આજે શું શોધવું છે?"
    )

    val PUNJABI = LanguageProfile(
        code = "pa",
        displayName = "Punjabi",
        nativeName = "ਪੰਜਾਬੀ",
        script = IndicScript.GURMUKHI,
        direction = TextDirection.LTR,
        locale = "pa-IN",
        greetingsPrompt = "ਅੱਜ ਕੀ ਖੋਜਣਾ ਹੈ?"
    )

    val TAMIL = LanguageProfile(
        code = "ta",
        displayName = "Tamil",
        nativeName = "தமிழ்",
        script = IndicScript.TAMIL,
        direction = TextDirection.LTR,
        locale = "ta-IN",
        greetingsPrompt = "இன்று எதைத் தேட விரும்புகிறீர்கள்?"
    )

    val TELUGU = LanguageProfile(
        code = "te",
        displayName = "Telugu",
        nativeName = "తెలుగు",
        script = IndicScript.TELUGU,
        direction = TextDirection.LTR,
        locale = "te-IN",
        greetingsPrompt = "ఈ రోజు ఏమి వెతకాలి?"
    )

    val KANNADA = LanguageProfile(
        code = "kn",
        displayName = "Kannada",
        nativeName = "ಕನ್ನಡ",
        script = IndicScript.KANNADA,
        direction = TextDirection.LTR,
        locale = "kn-IN",
        greetingsPrompt = "ಇಂದು ಏನನ್ನು ಹುಡುಕಲು ಬಯಸುತ್ತೀರಿ?"
    )

    val MALAYALAM = LanguageProfile(
        code = "ml",
        displayName = "Malayalam",
        nativeName = "മലയാളം",
        script = IndicScript.MALAYALAM,
        direction = TextDirection.LTR,
        locale = "ml-IN",
        greetingsPrompt = "ഇന്ന് എന്താണ് തിരയേണ്ടത്?"
    )

    val ODIA = LanguageProfile(
        code = "or",
        displayName = "Odia",
        nativeName = "ଓଡ଼ିଆ",
        script = IndicScript.ODIA,
        direction = TextDirection.LTR,
        locale = "or-IN",
        greetingsPrompt = "ଆଜି କ’ଣ ସନ୍ଧାନ କରିବେ?"
    )

    val ASSAMESE = LanguageProfile(
        code = "as",
        displayName = "Assamese",
        nativeName = "অসমীয়া",
        script = IndicScript.BENGALI,
        direction = TextDirection.LTR,
        locale = "as-IN",
        greetingsPrompt = "আজি কি সন্ধান কৰিব?"
    )

    val URDU = LanguageProfile(
        code = "ur",
        displayName = "Urdu",
        nativeName = "اردو",
        script = IndicScript.ARABIC_URDU,
        direction = TextDirection.RTL,
        locale = "ur-IN",
        greetingsPrompt = "آج کیا تلاش کرنا چاہتے ہیں؟"
    )

    val SANSKRIT = LanguageProfile(
        code = "sa",
        displayName = "Sanskrit",
        nativeName = "संस्कृतम्",
        script = IndicScript.DEVANAGARI,
        direction = TextDirection.LTR,
        locale = "sa-IN",
        greetingsPrompt = "अद्य किं अन्वेष्टव्यम्?"
    )

    val allLanguages: List<LanguageProfile> = listOf(
        HINDI, ENGLISH, TAMIL, BENGALI, MARATHI, GUJARATI,
        TELUGU, KANNADA, MALAYALAM, PUNJABI, ODIA, URDU, ASSAMESE, SANSKRIT
    )

    fun findByCode(code: String): LanguageProfile {
        return allLanguages.find { it.code.equals(code, ignoreCase = true) } ?: HINDI
    }
}
