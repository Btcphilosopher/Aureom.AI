package com.example.bharatbrowser.model

enum class ReaderTheme(val title: String, val bgHex: Long, val textHex: Long) {
    IVORY("Warm Ivory", 0xFFFDFBF7, 0xFF1E293B),
    SEPIA("Vedic Sepia", 0xFFF7F2E7, 0xFF3D3222),
    GRAPHITE("Graphite Dark", 0xFF1E293B, 0xFFF8FAFC),
    NIGHT("Deep Night", 0xFF090D16, 0xFFE2E8F0)
}

data class BrowserTab(
    val id: String,
    val url: String,
    val title: String,
    val languageCode: String = "hi",
    val isLoading: Boolean = false,
    val progress: Float = 0f,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isPinned: Boolean = false,
    val groupId: String? = null,
    val isReaderActive: Boolean = false,
    val isBilingualActive: Boolean = false,
    val isOfflineCached: Boolean = false
)

data class TabGroup(
    val id: String,
    val name: String,
    val colorHex: Long
)

data class BookmarkItem(
    val id: String,
    val title: String,
    val url: String,
    val folder: String = "मुख्य / General",
    val languageCode: String = "hi",
    val tags: List<String> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
)

data class HistoryItem(
    val id: String,
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis(),
    val languageCode: String = "hi",
    val isPrivate: Boolean = false
)

data class ResearchClip(
    val id: String,
    val workspace: String = "Digital Public Infrastructure",
    val title: String,
    val url: String,
    val source: String,
    val author: String = "Bureau / Author",
    val date: String = "2026",
    val language: String = "hi",
    val originalText: String,
    val translationText: String,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class PrivacyStats(
    val trackersBlocked: Int = 184,
    val cookiesBlocked: Int = 62,
    val httpsUpgraded: Int = 97,
    val thirdPartyRequestsBlocked: Int = 311,
    val dataSavedBytes: Long = 88080384L // ~84 MB
) {
    val formattedDataSaved: String
        get() {
            val mb = dataSavedBytes / (1024 * 1024.0)
            return "%.1f MB".format(mb)
        }
}

data class ReaderSettings(
    val fontSizeSp: Int = 18,
    val lineSpacingMultiplier: Float = 1.6f,
    val theme: ReaderTheme = ReaderTheme.IVORY,
    val fontFamily: String = "System Indic Serif",
    val bilingualLayout: Boolean = false,
    val translationTargetLang: String = "en"
)

data class DataTransparencyLog(
    val id: String,
    val operation: String,
    val whatWasSent: String,
    val whyItWasSent: String,
    val destination: String,
    val retention: String,
    val timestamp: Long = System.currentTimeMillis()
)
