package com.example.bharatbrowser.search

data class PortalArticle(
    val id: String,
    val title: String,
    val url: String,
    val sourceName: String,
    val category: String,
    val date: String,
    val languageCode: String,
    val excerpt: String,
    val fullContent: String,
    val author: String = "विशेष संवाददाता / Bureau",
    val keyStats: List<String> = emptyList(),
    val keyEntities: List<String> = emptyList()
)

object IndiaPortals {

    val articles: List<PortalArticle> = listOf(
        // 1. Digital Economy & DPI (Hindi)
        PortalArticle(
            id = "dpi-india-hi",
            title = "भारत में डिजिटल अर्थव्यवस्था और डीपीआई (DPI) की अभूतपूर्व प्रगति",
            url = "https://digitalindia.gov.in/dpi-progress-2026",
            sourceName = "डिजिटल इण्डिया पोर्टल",
            category = "प्रौद्योगिकी एवं शासन",
            date = "09 अक्टूबर 2026",
            languageCode = "hi",
            excerpt = "भारत में डिजिटल अर्थव्यवस्था तेजी से विकसित हो रही है। डिजिटल पब्लिक इन्फ्रास्ट्रक्चर (DPI) ने लाखों नागरिकों के जीवन को सुगम बनाया है।",
            fullContent = """
भारत में डिजिटल अर्थव्यवस्था तेजी से विकसित हो रही है।

डिजिटल पब्लिक इन्फ्रास्ट्रक्चर (DPI) ने लाखों नागरिकों के जीवन को सुगम बनाया है। यूपीआई (UPI), आधार और डिजिलॉकर के समावेशी समन्वय ने वित्तीय समावेशन को अंतिम व्यक्ति तक पहुँचाया है।

चालू वित्तीय वर्ष में डिजिटल लेन-देन का कुल मूल्य ₹25,00,000 करोड़ के ऐतिहासिक आंकड़े को पार कर गया है। टियर-2 और टियर-3 शहरों में 74% व्यापारी अब पूरी तरह से कैशलेस क्यूआर समाधानों का उपयोग कर रहे हैं।

भारतीय रिज़र्व बैंक (RBI) और इलेक्ट्रॉनिकी एवं सूचना प्रौद्योगिकी मंत्रालय (MeitY) ने अगली पीढ़ी के बहुभाषी एआई-संचालित वित्तीय सहायक लॉन्च किए हैं जो हिन्दी, तमिल, तेलुगु और बांग्ला में आवाज द्वारा बैंकिंग की सुविधा देते हैं।
            """.trimIndent(),
            author = "डॉ. राजगोपालन, मुख्य आर्थिक सलाहकार",
            keyStats = listOf("लेन-देन मूल्य: ₹25,00,000 करोड़", "74% व्यापारी डिजिटल", "मासिक सक्रिय उपयोगकर्ता: 52 करोड़"),
            keyEntities = listOf("UPI", "MeitY", "RBI", "डिजिलॉकर", "आधार")
        ),

        // 2. Indian Railways (Hindi / English Dual)
        PortalArticle(
            id = "railways-vande-bharat",
            title = "भारतीय रेलवे: 100 नई वंदे भारत और अमृत भारत ट्रेनों का राष्ट्रव्यापी परिचालन",
            url = "https://indianrailways.gov.in/vande-bharat-expansion",
            sourceName = "भारतीय रेल आधिकारिक पोर्टल",
            category = "परिवहन एवं अवसंरचना",
            date = "08 अक्टूबर 2026",
            languageCode = "hi",
            excerpt = "भारतीय रेलवे ने नई वंदे भारत एक्सप्रेस ट्रेनों का विस्तार किया है। मुंबई से पुणे और दिल्ली से वाराणसी मार्गों पर यात्रा समय में 40% की कमी दर्ज की गई है।",
            fullContent = """
भारतीय रेलवे ने नई वंदे भारत एक्सप्रेस ट्रेनों का विस्तार किया है।

मुंबई से पुणे के बीच नई हाई-स्पीड ट्रेन सेवा प्रारंभ हुई। इस रूट पर अत्याधुनिक कवच (KAVACH 4.0) स्वचालित ट्रेन सुरक्षा प्रणाली सक्रिय है।

यात्री सुविधाओं के मामले में नई स्लीपर वंदे भारत ट्रेनों में क्षेत्रीय भाषाओं में लाइव सूचना प्रणाली, स्वचालित बायो-वैक्यूम प्रसाधन और त्वरित वाई-फाई हॉटस्पॉट स्थापित किए गए हैं।

रेल मंत्रालय के आंकड़ों के अनुसार, समयबद्धता दर 96.8% तक पहुँच चुकी है, जो पिछले दशक का सर्वोत्तम रिकॉर्ड है।
            """.trimIndent(),
            author = "रेलवे सूचना ब्यूरो, नई दिल्ली",
            keyStats = listOf("100 नई ट्रेनें", "समयबद्धता दर: 96.8%", "यात्रा समय बचत: 40%"),
            keyEntities = listOf("वंदे भारत एक्सप्रेस", "कवच 4.0", "मुंबई-पुणे कॉरिडोर", "रेल मंत्रालय")
        ),

        // 3. Space and Science (English)
        PortalArticle(
            id = "isro-chandrayaan-science",
            title = "ISRO Lunar Research Station Milestone and Solar Observatory Discoveries",
            url = "https://isro.gov.in/missions/deep-space-advances-2026",
            sourceName = "ISRO Science Bureau",
            category = "Science & Space",
            date = "07 October 2026",
            languageCode = "en",
            excerpt = "Space exploration and lunar research programs have expanded significantly with international scientific collaboration.",
            fullContent = """
Space exploration and lunar research programs have expanded significantly.

ISRO has achieved new milestones in space research and satellite launches. The indigenous cryo-engine stages and autonomous docking mechanisms have paved the way for India's upcoming crewed space habitat.

Data from the Aditya-L1 solar observatory has unlocked unprecedented insights into coronal mass ejections and space weather, protecting global satellite infrastructure from major geomagnetic disturbances.

Over 45 private Indian aerospace startups are now actively manufacturing propulsion subsystems and nanosatellite constellations in Bengaluru and Hyderabad.
            """.trimIndent(),
            author = "Scientific Reporting Team, Bengaluru",
            keyStats = listOf("45+ Aerospace Startups", "Aditya-L1 Data Points: 1.2 Terabytes/day", "Indigenous Propulsion: 99.4% Reliability"),
            keyEntities = listOf("ISRO", "Aditya-L1", "Gaganyaan", "Bengaluru Space Center")
        ),

        // 4. Tamil Nadu Tech & Green Energy (Tamil)
        PortalArticle(
            id = "tamil-nadu-green-tech",
            title = "தமிழ்நாடு: பசுமை ஆற்றல் மற்றும் செமிகண்டக்டர் உற்பத்தியில் புதிய மைல்கல்",
            url = "https://seithi.tn.gov.in/green-energy-semiconductor-2026",
            sourceName = "தமிழ்நாடு செய்தி மலர்",
            category = "தொழில்நுட்பம் & வளர்ச்சி",
            date = "06 அக்டோபர் 2026",
            languageCode = "ta",
            excerpt = "தமிழ்நாட்டில் சூரிய மற்றும் காற்றாலை ஆற்றல் உற்பத்தி புதிய சாதனையை படைத்துள்ளது. சென்னை மற்றும் கோவையில் புதிய ஆராய்ச்சி மையங்கள் திறக்கப்பட்டுள்ளன.",
            fullContent = """
தமிழ்நாட்டில் சூரிய மற்றும் காற்றாலை ஆற்றல் உற்பத்தி புதிய சாதனையை படைத்துள்ளது.

சென்னை மற்றும் கோவையில் புதிய ஆராய்ச்சி மையங்கள் திறக்கப்பட்டுள்ளன. மாநிலத்தின் மொத்த மின் தேவையில் 58% இப்போது தூய புதுப்பிக்கத்தக்க மூலங்களிலிருந்து பெறப்படுகிறது.

மின்னணு மற்றும் செமிகண்டக்டர் உபகரணங்கள் உற்பத்தியில் சர்வதேச முதலீடுகள் ஈர்க்கப்பட்டு, 85,000 புதிய வேலைவாய்ப்புகள் இளைஞர்களுக்கு உருவாக்கப்பட்டுள்ளன.

மாணவர்களுக்கு தாய்மொழியான தமிழில் செயற்கை நுண்ணறிவு மற்றும் மென்பொருள் பொறியியல் பயிற்றுவிக்கும் திட்டத்திற்கு பெரும் வரவேற்பு கிடைத்துள்ளது.
            """.trimIndent(),
            author = "மு. இளங்கோவன், செய்திப் பிரிவு",
            keyStats = listOf("58% பசுமை ஆற்றல்", "85,000 வேலைவாய்ப்புகள்", "புதிய முதலீடு: ₹18,500 கோடி"),
            keyEntities = listOf("சென்னை", "கோயம்புத்தூர்", "தமிழ்நாடு மின் வாரியம்", "செமிகண்டக்டர் மையம்")
        ),

        // 5. Bengal Heritage & Quantum Computing (Bengali)
        PortalArticle(
            id = "bengal-quantum-science",
            title = "কলকাতায় নতুন কোয়ান্টাম গবেষণা হাব: ভারতীয় বিজ্ঞানীদের যুগান্তকারী আবিষ্কার",
            url = "https://banglabarta.in/quantum-kolkata-breakthrough",
            sourceName = "বাংলা বার্তা বিজ্ঞান",
            category = "বিজ্ঞান ও প্রযুক্তি",
            date = "05 অক্টোবর 2026",
            languageCode = "bn",
            excerpt = "কলকাতায় সত্যেন্দ্রনাথ বসু ইনস্টিটিউটে নতুন কোয়ান্টাম প্রসেসর সফলভাবে পরীক্ষিত হয়েছে।",
            fullContent = """
কলকাতায় সত্যেন্দ্রনাথ বসু ইনস্টিটিউটে নতুন কোয়ান্টাম প্রসেসর সফলভাবে পরীক্ষিত হয়েছে।

ভারতীয় বিজ্ঞানীরা দেশীয় নকশায় তৈরি অ্যালগরিদম ব্যবহার করে ওষুধ আবিষ্কার এবং আবহাওয়া পূর্বাভাসের জটিল সমস্যার সমাধান করেছেন।

ঐতিহাসিক বসু বিজ্ঞান মন্দির এবং যাদবপুর বিশ্ববিদ্যালয়ের যৌথ উদ্যোগে বাংলা ভাষায় প্রথম ওপেন-সোর্স কোয়ান্টাম লার্নিং প্ল্যাটফর্ম উন্মোচন করা হয়েছে, যার মাধ্যমে গ্রামীণ পড়ুয়ারাও উচ্চমানের কোডিং শিখতে পারবে।
            """.trimIndent(),
            author = "অনিন্দ্য সেনগুপ্ত, বিজ্ঞান বিভাগ",
            keyStats = listOf("128-Qubit প্রসেসর", "যৌথ গবেষণা অনুদান: ₹450 কোটি", "বাংলা কোয়ান্টাম লাইব্রেরি"),
            keyEntities = listOf("এস এন বোস ইনস্টিটিউট", "কলকাতা", "বসু বিজ্ঞান মন্দির", "যাদবপুর")
        ),

        // 6. Urdu Roznama Cultural & Tech Synthesis (Urdu RTL)
        PortalArticle(
            id = "urdu-roznama-culture",
            title = "روزنامہ بھارت: دلی اور حیدرآباد میں اردو ڈیجیٹل خطاطی اور مصنوعی ذہانت کا نیا نمائش",
            url = "https://roznama-bharat.in/urdu-ai-calligraphy",
            sourceName = "روزنامہ بھارت",
            category = "ثقافت و سائنس",
            date = "04 اکتوبر 2026",
            languageCode = "ur",
            excerpt = "اردو نستعلیق خطاطی کو جدید کمپیوٹر فونٹس اور اوپن ടائپ ٹیکنالوجی کے ذریعے عالمی معیار پر لانے کا تاریخی منصوبہ مکمل ہو گیا۔",
            fullContent = """
اردو نستعلیق خطاطی کو جدید کمپیوٹر فونٹس اور اوپن ടائپ ٹیکنالوجی کے ذریعے عالمی معیار پر لانے کا تاریخی منصوبہ مکمل ہو گیا۔

دلی، حیدرآباد اور لکھنؤ کے ماہرینِ لسانیات نے یونیکوڈ کنسورشیم کے تعاون سے نستعلیق کے تمام پیچیدہ جوڑوں اور اعراب کو خودکار رینڈرنگ سسٹم سے ہم آہنگ کیا ہے۔

اس پیش رفت سے اردو زبان میں ویب سائٹ ڈیزائننگ، ای بکس اور عدالتی دستاویزات کی فوری تلاش اور ترجمہ بے حد آسان اور خوبصورت ہو گیا ہے۔
            """.trimIndent(),
            author = "محمد عاصم رضوی، نئی دہلی",
            keyStats = listOf("نستعلیق فونٹس: 100% ہم آہنگ", "یونیکوڈ اعراب سپورٹ", "3 تاریخی مراکز"),
            keyEntities = listOf("نستعلیق", "حیدرآباد", "دلی", "لکھنؤ", "یونیکوڈ")
        ),

        // 7. National Weather & Agriculture (Hindi)
        PortalArticle(
            id = "weather-imd-agro",
            title = "राष्ट्रीय मौसम पूर्वानुमान: उत्तर और मध्य भारत में अनुकूल मॉनसून एवं कृषि परामर्श",
            url = "https://mausam.imd.gov.in/national-bulletin-october",
            sourceName = "भारत मौसम विज्ञान विभाग (IMD)",
            category = "मौसम एवं पर्यावरण",
            date = "09 अक्टूबर 2026",
            languageCode = "hi",
            excerpt = "आज का मौसम: दिल्ली और उत्तर भारत में हल्की धूप और सुखद हवा रहेगी। कृषि क्षेत्र में आधुनिक तकनीकी और डिजिटल मंडियों का उपयोग बढ़ रहा है।",
            fullContent = """
आज का मौसम: दिल्ली और उत्तर भारत में हल्की धूप और सुखद हवा रहेगी।

कृषि क्षेत्र में आधुनिक तकनीकी और डिजिटल मंडियों का उपयोग बढ़ रहा है। किसानों को स्थानीय भाषाओं में रबी फसलों की बुवाई के संबंध में सटीक वर्षा और तापमान के आंकड़े सीधे मोबाइल पर भेजे जा रहे हैं।

गंगा के मैदानी इलाकों में तापमान 24°C से 31°C के मध्य बना रहेगा। वायु गुणवत्ता सूचकांक (AQI) में पिछले सप्ताह की तुलना में निरंतर सुधार दर्ज किया गया है।
            """.trimIndent(),
            author = "कृषि मौसम सेवा प्रभाग, पूसा नई दिल्ली",
            keyStats = listOf("औसत तापमान: 27°C", "वायु गुणवत्ता: संतोषजनक", "कृषि सलाह संदेश: 4.2 करोड़ किसान"),
            keyEntities = listOf("IMD", "पूसा संस्थान", "रबी फसलें", "गंगा मैदान")
        )
    )

    fun searchArticles(query: String): List<PortalArticle> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return articles

        // Match against title, content, keywords, or language
        return articles.filter { article ->
            article.title.lowercase().contains(q) ||
                    article.fullContent.lowercase().contains(q) ||
                    article.category.lowercase().contains(q) ||
                    article.sourceName.lowercase().contains(q) ||
                    article.keyEntities.any { it.lowercase().contains(q) } ||
                    article.keyStats.any { it.lowercase().contains(q) }
        }
    }

    fun findByUrl(url: String): PortalArticle? {
        val clean = url.trim().lowercase().removePrefix("https://").removePrefix("http://")
        return articles.find { article ->
            val artClean = article.url.lowercase().removePrefix("https://").removePrefix("http://")
            clean == artClean || clean.contains(article.id)
        }
    }
}
