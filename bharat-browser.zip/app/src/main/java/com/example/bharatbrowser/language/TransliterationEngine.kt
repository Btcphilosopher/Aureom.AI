package com.example.bharatbrowser.language

interface TransliterationProvider {
    fun transliterate(input: String, targetLangCode: String): List<String>
    val providerName: String
    val isLocal: Boolean
}

class LocalTransliterationProvider : TransliterationProvider {
    override val providerName: String = "Local India-Core Phonetic Engine"
    override val isLocal: Boolean = true

    // High precision phrase and word lexicon
    private val lexicon = mapOf(
        // Hindi (Devanagari)
        "namaste" to listOf("नमस्ते", "नमस्‍ते"),
        "namaskar" to listOf("नमस्कार", "नमस्‍कार"),
        "bharat" to listOf("भारत", "भरत"),
        "india" to listOf("इंडिया", "भारत"),
        "delhi" to listOf("दिल्ली", "दिल्ही"),
        "dilli" to listOf("दिल्ली", "दिल्लि"),
        "mumbai" to listOf("मुंबई", "बंबई"),
        "train" to listOf("ट्रेन", "रेलगाड़ी"),
        "railway" to listOf("रेलवे", "रेल"),
        "mausam" to listOf("मौसम", "ऋतु"),
        "weather" to listOf("मौसम", "वेदर"),
        "samachar" to listOf("समाचार", "खबरें"),
        "khabar" to listOf("खबर", "समाचार"),
        "mera" to listOf("मेरा"),
        "naam" to listOf("नाम"),
        "rahul" to listOf("राहुल"),
        "hai" to listOf("है", "हैं"),
        "kya" to listOf("क्या"),
        "aaj" to listOf("आज"),
        "khoje" to listOf("खोजें", "खोज"),
        "pune" to listOf("पुणे"),
        "se" to listOf("से"),
        "ka" to listOf("का"),
        "ki" to listOf("की", "कि"),
        "ke" to listOf("के"),
        "dhanyawad" to listOf("धन्यवाद", "धन्यवाद्"),
        "dhanyavad" to listOf("धन्यवाद"),
        "shubh" to listOf("शुभ"),
        "prabhat" to listOf("प्रभात"),
        "vidyalaya" to listOf("विद्यालय"),
        "sarkar" to listOf("सरकार"),
        "desh" to listOf("देश"),

        // Tamil
        "vanakkam" to listOf("வணக்கம்"),
        "tamil" to listOf("தமிழ்", "தமிழ"),
        "nadu" to listOf("நாடு"),
        "seithigal" to listOf("செய்திகள்", "செய்தி"),
        "chennai" to listOf("சென்னை"),
        "nandri" to listOf("நன்றி"),
        "epdi" to listOf("எப்படி"),
        "irukkeenga" to listOf("இருக்கீங்க"),
        "vanakam" to listOf("வணக்கம்"),

        // Bengali
        "namaskar_bn" to listOf("নমস্কার"),
        "shob" to listOf("সব"),
        "khobor" to listOf("খবর"),
        "kolkata" to listOf("কলকাতা"),
        "dhonnobad" to listOf("ধন্যবাদ"),
        "bengal" to listOf("বাংলা"),
        "bangla" to listOf("বাংলা"),

        // Gujarati
        "kem" to listOf("કેમ"),
        "cho" to listOf("છો"),
        "gujarat" to listOf("ગુજરાત"),
        "aabhar" to listOf("આભાર"),
        "amavad" to listOf("અમદાવાદ"),

        // Kannada
        "namaskara" to listOf("ನಮಸ್ಕಾರ"),
        "karnataka" to listOf("ಕರ್ನಾಟಕ"),
        "bengaluru" to listOf("ಬೆಂಗಳೂರು"),
        "dhanyavada" to listOf("ಧನ್ಯವಾದಗಳು", "ಧನ್ಯವಾದ"),

        // Telugu
        "namaskaram" to listOf("నమస్కారం"),
        "telangana" to listOf("తెలంగాణ"),
        "andhra" to listOf("ఆంధ్రప్రదేశ్", "ఆంధ్ర"),
        "hyderabad" to listOf("హైదరాబాద్"),
        "dhanyavadalu" to listOf("ధన్యవాదాలు"),

        // Marathi
        "kasa" to listOf("कसा"),
        "aahat" to listOf("आहात"),
        "maharashtra" to listOf("महाराष्ट्र"),
        "dhanyavaad_mr" to listOf("धन्यवाद"),

        // Malayalam
        "namaskaram_ml" to listOf("നമസ്കാരം"),
        "kerala" to listOf("കേരളം"),
        "kochi" to listOf("കൊച്ചി"),
        "nanni" to listOf("നന്ദി"),

        // Punjabi
        "sat" to listOf("ਸਤਿ"),
        "sri" to listOf("ਸ੍ਰੀ"),
        "akal" to listOf("ਅਕਾਲ"),
        "punjab" to listOf("ਪੰਜਾਬ"),
        "dhanwad" to listOf("ਧੰਨਵਾਦ"),

        // Urdu
        "shukriya" to listOf("شکریہ"),
        "adaab" to listOf("آداب"),
        "khabar_ur" to listOf("خبر"),
        "delhi_ur" to listOf("دہلی"),
        "urdu" to listOf("اردو")
    )

    override fun transliterate(input: String, targetLangCode: String): List<String> {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return emptyList()

        val words = trimmed.split(Regex("\\s+"))
        if (words.size > 1) {
            // Multi-word transliteration
            val candidateLists = words.map { word ->
                transliterateSingleWord(word, targetLangCode)
            }
            // Combine top candidate for each word
            val topCombination = candidateLists.joinToString(" ") { it.firstOrNull() ?: it.getOrNull(0) ?: "" }
            val secondCombination = candidateLists.mapIndexed { index, list ->
                if (index == candidateLists.lastIndex && list.size > 1) list[1] else list.firstOrNull() ?: ""
            }.joinToString(" ")

            return listOf(topCombination, secondCombination).distinct().filter { it.isNotBlank() }
        } else {
            return transliterateSingleWord(trimmed, targetLangCode)
        }
    }

    private fun transliterateSingleWord(word: String, targetLangCode: String): List<String> {
        val lower = word.lowercase()

        // 1. Direct lexicon check
        val lex = lexicon[lower]
        if (lex != null) {
            return lex
        }

        // 2. Language-specific algorithmic phonetic conversion
        return when (targetLangCode) {
            "ta" -> listOf(algorithmicPhoneticTamil(lower), word)
            "bn", "as" -> listOf(algorithmicPhoneticBengali(lower), word)
            "gu" -> listOf(algorithmicPhoneticGujarati(lower), word)
            "ur" -> listOf(algorithmicPhoneticUrdu(lower), word)
            "te" -> listOf(algorithmicPhoneticTelugu(lower), word)
            "kn" -> listOf(algorithmicPhoneticKannada(lower), word)
            "ml" -> listOf(algorithmicPhoneticMalayalam(lower), word)
            "pa" -> listOf(algorithmicPhoneticPunjabi(lower), word)
            else -> listOf(algorithmicPhoneticDevanagari(lower), word)
        }.distinct()
    }

    private fun algorithmicPhoneticDevanagari(input: String): String {
        var str = input
        val map = listOf(
            "ksha" to "क्ष", "tra" to "त्र", "gya" to "ज्ञ", "shri" to "श्री",
            "kh" to "ख", "gh" to "घ", "ch" to "च", "chh" to "छ", "jh" to "झ",
            "th" to "थ", "dh" to "ध", "ph" to "फ", "bh" to "भ", "sh" to "श",
            "shh" to "ष", "aa" to "आ", "ee" to "ई", "oo" to "ऊ", "ai" to "ऐ", "au" to "औ",
            "k" to "क", "g" to "ग", "j" to "ज", "t" to "त", "d" to "द", "n" to "न",
            "p" to "प", "b" to "ब", "m" to "म", "y" to "य", "r" to "र", "l" to "ल",
            "v" to "व", "w" to "व", "s" to "स", "h" to "ह",
            "a" to "अ", "i" to "इ", "u" to "उ", "e" to "ए", "o" to "ओ"
        )
        // Consonant + Matra simplifier
        val result = StringBuilder()
        var i = 0
        while (i < str.length) {
            var matched = false
            for ((key, value) in map) {
                if (str.startsWith(key, i)) {
                    result.append(value)
                    i += key.length
                    matched = true
                    break
                }
            }
            if (!matched) {
                result.append(str[i])
                i++
            }
        }
        return result.toString()
    }

    private fun algorithmicPhoneticTamil(input: String): String {
        return when {
            input.contains("vanakkam") -> "வணக்கம்"
            input.contains("tamil") -> "தமிழ்"
            input.contains("nadu") -> "நாடு"
            input.contains("chennai") -> "சென்னை"
            input.contains("seithi") -> "செய்தி"
            input.contains("nandri") -> "நன்றி"
            else -> input
        }
    }

    private fun algorithmicPhoneticBengali(input: String): String {
        return when {
            input.contains("namaskar") -> "নমস্কার"
            input.contains("bangla") -> "বাংলা"
            input.contains("kolkata") -> "কলকাতা"
            input.contains("khobor") -> "খবর"
            input.contains("dhonnobad") -> "ধন্যবাদ"
            else -> input
        }
    }

    private fun algorithmicPhoneticGujarati(input: String): String {
        return when {
            input.contains("kem") -> "કેમ"
            input.contains("cho") -> "છો"
            input.contains("gujarat") -> "ગુજરાત"
            input.contains("aabhar") -> "આભાર"
            else -> input
        }
    }

    private fun algorithmicPhoneticTelugu(input: String): String {
        return when {
            input.contains("namaskaram") -> "నమస్కారం"
            input.contains("telugu") -> "తెలుగు"
            input.contains("hyderabad") -> "హైదరాబాద్"
            else -> input
        }
    }

    private fun algorithmicPhoneticKannada(input: String): String {
        return when {
            input.contains("namaskara") -> "ನಮಸ್ಕಾರ"
            input.contains("karnataka") -> "ಕರ್ನಾಟಕ"
            input.contains("bengaluru") -> "ಬೆಂಗಳೂರು"
            else -> input
        }
    }

    private fun algorithmicPhoneticMalayalam(input: String): String {
        return when {
            input.contains("namaskaram") -> "നമസ്കാരം"
            input.contains("kerala") -> "കേരളം"
            else -> input
        }
    }

    private fun algorithmicPhoneticPunjabi(input: String): String {
        return when {
            input.contains("sat") -> "ਸਤਿ"
            input.contains("punjab") -> "ਪੰਜਾਬ"
            else -> input
        }
    }

    private fun algorithmicPhoneticUrdu(input: String): String {
        return when {
            input.contains("shukriya") -> "شکریہ"
            input.contains("adaab") -> "آداب"
            input.contains("delhi") -> "دہلی"
            else -> input
        }
    }
}
