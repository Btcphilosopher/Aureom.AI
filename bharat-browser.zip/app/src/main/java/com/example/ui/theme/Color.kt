package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bharat Browser Slate & Warm Palette
val Slate900 = Color(0xFF0E1A2F)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate300 = Color(0xFFCBD5E1)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Restrained Indian Copper / Warm Saffron Accent
val SaffronWarm = Color(0xFFD97706)
val SaffronDeep = Color(0xFFB45309)
val SaffronLight = Color(0xFFFEF3C7)

// Restrained Forest Green (National symbol tone)
val EmeraldGreen = Color(0xFF047857)
val EmeraldLight = Color(0xFFD1FAE5)

// Warm Ivory / Paper tones for Indic reading
val WarmIvory = Color(0xFFFDFBF7)
val SepiaVedic = Color(0xFFF7F2E7)
val SepiaText = Color(0xFF3D3222)

// Night reading slate
val NightBg = Color(0xFF090D16)
val NightCard = Color(0xFF131B2E)

// UI accents
val BlueIndigo = Color(0xFF2563EB)
val CoralRed = Color(0xFFDC2626)
