# BHARAT BROWSER (भारतीय बहुभाषी वेब ब्राउज़र)

**BHARAT BROWSER** is an India-native multilingual web browsing and research computing platform designed from first principles for India's languages, scripts, typography, search behaviour, connectivity environments, and privacy requirements.

---

## 1. Architectural Philosophy
- **Language ≠ Script**: Distinguishes languages from the orthographic scripts used to write them (e.g. Hindi in Devanagari vs Romanised Hindi).
- **Translation ≠ Transliteration**: Strictly separates phonetic Roman-to-Indic transliteration from semantic translation.
- **First-Class Indic Computing**: Treats Hindi, English, Bengali, Tamil, Telugu, Marathi, Gujarati, Kannada, Malayalam, Punjabi, Odia, Assamese, and Urdu (RTL) as primary computing languages.
- **Zero-Compromise Indic Typography**: NFC Unicode normalization, conjunct preservation, syllable clustering, zero-width joiner (ZWJ/ZWNJ) safety, and Indian numbering grouping (`₹1,25,00,000`).

---

## 2. Core Functional Modules

### **Bharat Bar (Universal Omnibar)**
- One unified field handling:
  - URLs and domain destinations
  - Indic script queries ("दिल्ली का मौसम", "தமிழ்நாடு செய்திகள்")
  - Romanised phonetic queries ("dilli ka mausam" → "दिल्ली का मौसम")
  - Real-time phonetic transliteration candidate chips
  - Arithmetic expressions (`25 * 4 = 100`, `125000 / 12`)
  - Direct browser commands (`:reader`, `:research`, `:privacy`, `:settings`)

### **Reader Mode & Bilingual Reading**
- Distraction-free typography for all 12 supported Indian scripts.
- Font scaling, line spacing, and theme palettes (Warm Ivory, Vedic Sepia, Graphite, Deep Night).
- **Bilingual Reading Mode**: Displays original Indic text side-by-side or stacked with English reference translation.
- **Listen / Read Aloud (सुनें)**: Text-to-speech with Indian language locales (`hi-IN`, `ta-IN`, `bn-IN`, etc.).

### **Bharat Research Workspace**
- Browser-native research repository for students, journalists, civil servants, and professionals.
- Captures citation metadata: Title, URL, Source, Author, Date, Original Text, Translation, and custom research notes.
- One-tap export to clipboard.

### **Privacy & Security Shield**
- Built-in tracker defense filter blocking tracking beacons and telemetry.
- HTTPS connection enforcement.
- **Data Transparency Panel**: Explicitly documents what was processed, why, where it was sent, and data retention rules.
- Private Browsing Mode (zero disk persistence).

### **Bharat AI Research Assistant**
- Distinguishes **PAGE CONTENT** from **AI INTERPRETATION**.
- Extracts key statistics (₹, Lakh, Crore), entities (UPI, ISRO, RBI), and verified citations.
- Privacy modes: **LOCAL ONLY**, **PRIVATE**, and **STANDARD**.

### **India Connectivity (Lite Mode)**
- Designed for constrained network conditions with aggressive caching and text-first rendering.
- Real-time measured data savings counter.
