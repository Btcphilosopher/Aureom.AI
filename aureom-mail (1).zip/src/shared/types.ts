export type ProviderType = 'microsoft_graph' | 'gmail_api' | 'imap_smtp';
export type AccountKind = 'work' | 'personal' | 'shared_mailbox';
export type SyncStateStatus = 'synced' | 'syncing' | 'error' | 'offline';

export interface Account {
  id: string;
  displayName: string;
  email: string;
  kind: AccountKind;
  provider: ProviderType;
  isSimulatedAdapter: boolean;
  colorHex: string;
  signatureHtml: string;
  signatureText: string;
  syncStatus: SyncStateStatus;
  lastSyncedAt: string | null;
  lastSyncError: string | null;
  uidValidity?: number;
  highestModSeq?: string;
  deltaToken?: string;
  historyId?: string;
  unreadCount: number;
  quotaUsedMb: number;
  quotaLimitMb: number;
  retentionDays: number;
}

export interface SharedMailboxPermission {
  accountId: string;
  userEmail: string;
  canRead: boolean;
  canFile: boolean;
  canReply: boolean;
  canSendAs: boolean;
  canManageRules: boolean;
}

export type FolderRole =
  | 'inbox'
  | 'sent'
  | 'drafts'
  | 'archive'
  | 'junk'
  | 'deleted'
  | 'custom';

export interface MailFolder {
  id: string;
  accountId: string;
  parentId: string | null;
  name: string;
  role: FolderRole;
  providerPathOrLabel: string;
  uidValidity?: number;
  unreadCount: number;
  totalCount: number;
  order: number;
}

export interface EmailParticipant {
  name: string;
  email: string;
}

export interface EmailAttachment {
  id: string;
  messageId: string;
  accountId: string;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  contentPreview: string;
  scanStatus: 'clean' | 'quarantined' | 'unscanned';
  isInline?: boolean;
  contentId?: string;
  createdAt: string;
}

export interface AuthVerificationSummary {
  spf: 'pass' | 'fail' | 'neutral' | 'none';
  dkim: 'pass' | 'fail' | 'none';
  dmarc: 'pass' | 'fail' | 'none';
  suppliedByProvider: string;
  independentlyVerifiedByApp: boolean;
  suspiciousSenderWarning: string | null;
  replyToMismatchWarning: string | null;
}

export interface InternalNote {
  id: string;
  authorEmail: string;
  authorName: string;
  text: string;
  createdAt: string;
}

export interface EmailMessage {
  id: string;
  threadId: string;
  accountId: string;
  folderId: string;
  providerUid: number;
  uidValidity: number;
  internetMessageId: string;
  from: EmailParticipant;
  replyTo: EmailParticipant | null;
  to: EmailParticipant[];
  cc: EmailParticipant[];
  bcc: EmailParticipant[];
  subject: string;
  snippet: string;
  bodyHtmlRaw: string;
  bodyText: string;
  isRead: boolean;
  isFlagged: boolean;
  followUpDate: string | null;
  isPinned: boolean;
  snoozedUntil: string | null;
  categories: string[];
  attachments: EmailAttachment[];
  receivedAt: string;
  sentAt: string | null;
  headers: Record<string, string>;
  authSummary: AuthVerificationSummary;
  assignedTo: string | null;
  internalNotes: InternalNote[];
  version: number;
}

export type OutboxStatus =
  | 'draft'
  | 'delayed_pending'
  | 'queued_offline'
  | 'submitting'
  | 'submitted'
  | 'uncertain_outcome'
  | 'failed';

export interface OutboxDraft {
  id: string;
  accountId: string;
  sendAsAddress: string;
  replyToMessageId: string | null;
  forwardMessageId: string | null;
  mode: 'new' | 'reply' | 'replyAll' | 'forward';
  to: EmailParticipant[];
  cc: EmailParticipant[];
  bcc: EmailParticipant[];
  subject: string;
  bodyHtml: string;
  bodyText: string;
  isRichText: boolean;
  attachments: {
    id: string;
    filename: string;
    mimeType: string;
    sizeBytes: number;
    contentPreview: string;
  }[];
  inlineImages: { id: string; alt: string; dataUrl: string }[];
  scheduledFor: string | null;
  sendDelaySeconds: number;
  delayedUntil: string | null;
  status: OutboxStatus;
  idempotencyKey: string;
  retryCount: number;
  lastError: string | null;
  deliveryNote: string;
  updatedAt: string;
  version: number;
}

export interface CalendarInfo {
  id: string;
  accountId: string;
  name: string;
  colorHex: string;
  isVisible: boolean;
  isPrimary: boolean;
}

export interface EventAttendee {
  email: string;
  name: string;
  response: 'accepted' | 'tentative' | 'declined' | 'needsAction';
  availability?: 'free' | 'busy' | 'tentative';
}

export interface CalendarEvent {
  id: string;
  calendarId: string;
  accountId: string;
  seriesMasterId: string | null;
  isRecurring: boolean;
  recurrenceRule: 'DAILY' | 'WEEKLY' | 'MONTHLY' | null;
  recurrenceExceptions: string[];
  isExceptionInstance: boolean;
  originalStartUtc: string | null;
  title: string;
  description: string;
  location: string;
  conferencingProvider: 'aureom_meet_mock' | 'none';
  conferencingUrl: string | null;
  startLocal: string;
  endLocal: string;
  timezone: string;
  startUtc: string;
  endUtc: string;
  isAllDay: boolean;
  organizer: EmailParticipant;
  attendees: EventAttendee[];
  myResponse: 'accepted' | 'tentative' | 'declined' | 'needsAction';
  invitationStatus: 'local_only' | 'invitation_sent' | 'received_invite';
  reminderMinutes: number;
  linkedMessageId: string | null;
  version: number;
}

export interface ContactRecord {
  id: string;
  accountId: string;
  displayName: string;
  firstName: string;
  lastName: string;
  emails: { address: string; label: string; isPrimary: boolean }[];
  phones: { number: string; label: string }[];
  organization: string;
  jobTitle: string;
  notes: string;
  categories: string[];
  isFavourite: boolean;
  trustLevel: 'saved_contact' | 'autocomplete_suggestion';
  mergedFromIds: string[];
  updatedAt: string;
}

export interface TaskChecklistItem {
  id: string;
  text: string;
  done: boolean;
}

export interface TaskItem {
  id: string;
  listName: string;
  accountId: string;
  title: string;
  notes: string;
  dueDate: string | null;
  reminderAt: string | null;
  priority: 'low' | 'normal' | 'high';
  status: 'todo' | 'in_progress' | 'completed';
  completedAt: string | null;
  isMyDay: boolean;
  isRecurring: boolean;
  recurrencePattern: 'daily' | 'weekly' | 'monthly' | null;
  checklist: TaskChecklistItem[];
  linkedMessageId: string | null;
  linkedEventId: string | null;
  createdAt: string;
  version: number;
}

export interface RuleCondition {
  field: 'sender' | 'recipient' | 'subject' | 'account';
  operator: 'contains' | 'equals' | 'endsWith';
  value: string;
}

export interface RuleAction {
  type:
    | 'move_folder'
    | 'apply_category'
    | 'mark_read'
    | 'flag'
    | 'notify'
    | 'forward_explicit';
  value?: string;
  explicitForwardConfirmed?: boolean;
}

export interface MailRule {
  id: string;
  name: string;
  accountId: string;
  scope: 'application' | 'provider';
  enabled: boolean;
  priority: number;
  stopProcessing: boolean;
  conditions: RuleCondition[];
  actions: RuleAction[];
  loopGuardCount: number;
  lastRunAt: string | null;
}

export interface SavedSearch {
  id: string;
  name: string;
  query: string;
  accountId: string | null;
  hasAttachment: boolean;
  category: string | null;
}

export interface AiActionRecord {
  id: string;
  timestamp: string;
  actionType:
    | 'summarize'
    | 'draft_reply'
    | 'rewrite'
    | 'translate'
    | 'extract_actions'
    | 'meeting_brief'
    | 'find_relevant'
    | 'suggest_filing';
  promptSummary: string;
  accountScope: string[];
  sourceMessageIds: string[];
  confirmedFacts: string[];
  inferredSuggestions: string[];
  proposedAction?: {
    kind: 'create_task' | 'propose_meeting' | 'apply_filing' | 'insert_draft';
    payload: Record<string, unknown>;
    summary: string;
  } | null;
  requiresApproval: boolean;
  approvalStatus: 'not_required' | 'pending' | 'approved' | 'rejected';
  modelUsed: string;
  tokensEstimate: number;
  resultText: string;
  promptInjectionDetected?: boolean;
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system';
  density: 'comfortable' | 'compact';
  readingPanePosition: 'right' | 'bottom' | 'hidden';
  showRightSidebar: boolean;
  conversationGrouping: boolean;
  defaultSendDelaySeconds: number;
  blockRemoteImages: boolean;
  offlineCacheDays: number;
  offlineModeSimulated: boolean;
}

export interface OfflineQueuedOp {
  id: string;
  createdAt: string;
  kind: 'mark_read' | 'move_folder' | 'flag' | 'category' | 'task_update';
  description: string;
  payload: Record<string, unknown>;
  status: 'pending' | 'reconciled' | 'conflict';
  retryCount: number;
}

export interface WorkspaceBootstrap {
  schemaVersion: number;
  currentUserEmail: string;
  accounts: Account[];
  sharedPermissions: SharedMailboxPermission[];
  folders: MailFolder[];
  messages: EmailMessage[];
  outbox: OutboxDraft[];
  calendars: CalendarInfo[];
  events: CalendarEvent[];
  contacts: ContactRecord[];
  tasks: TaskItem[];
  rules: MailRule[];
  savedSearches: SavedSearch[];
  aiHistory: AiActionRecord[];
  aiTokenBudgetLimit: number;
  aiTokensUsed: number;
  offlineQueue: OfflineQueuedOp[];
  preferences: UserPreferences;
  templates: { id: string; name: string; subject: string; bodyHtml: string }[];
}
