import type {AuthVerificationSummary, EmailParticipant} from './types';

export interface SanitizedHtmlResult {
  html: string;
  hasRemoteImages: boolean;
  blockedImageCount: number;
  suspiciousLinks: {displayText: string; href: string}[];
}

const ALLOWED_TAGS = new Set([
  'p',
  'br',
  'div',
  'span',
  'strong',
  'b',
  'em',
  'i',
  'u',
  's',
  'blockquote',
  'ul',
  'ol',
  'li',
  'h1',
  'h2',
  'h3',
  'h4',
  'pre',
  'code',
  'a',
  'img',
  'table',
  'thead',
  'tbody',
  'tr',
  'th',
  'td',
  'hr',
]);

const STRIP_WITH_CONTENT_TAGS = [
  'script',
  'style',
  'iframe',
  'object',
  'embed',
  'noscript',
  'svg',
  'math',
  'form',
  'template',
];

const SAFE_URL_PROTOCOLS = /^(https?:|mailto:|tel:|cid:)/i;
const SAFE_INLINE_DATA_IMAGE =
  /^data:image\/(png|jpeg|jpg|gif|webp);base64,[A-Za-z0-9+/=]+$/i;

function escapeHtmlAttr(value: string): string {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function decodeBasicEntities(value: string): string {
  return value
    .replaceAll('&amp;', '&')
    .replaceAll('&quot;', '"')
    .replaceAll('&#39;', "'")
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>');
}

export function sanitizeEmailHtml(
  rawHtml: string,
  options: {allowRemoteImages?: boolean} = {},
): SanitizedHtmlResult {
  const allowRemoteImages = Boolean(options.allowRemoteImages);
  let cleaned = rawHtml || '';

  // Remove HTML comments
  cleaned = cleaned.replace(/<!--[\s\S]*?-->/g, '');

  // Strip dangerous tags and their inner payloads
  for (const tag of STRIP_WITH_CONTENT_TAGS) {
    const pairRegex = new RegExp(`<${tag}\\b[^>]*>[\\s\\S]*?<\\/${tag}>`, 'gi');
    cleaned = cleaned.replace(pairRegex, '');
    const selfRegex = new RegExp(`<${tag}\\b[^>]*\\/?>`, 'gi');
    cleaned = cleaned.replace(selfRegex, '');
  }

  let hasRemoteImages = false;
  let blockedImageCount = 0;
  const suspiciousLinks: {displayText: string; href: string}[] = [];

  // Detect deceptive anchor links where visible text looks like a different domain
  cleaned = cleaned.replace(
    /<a\b([^>]*)>([\s\S]*?)<\/a>/gi,
    (_full, attrs: string, inner: string) => {
      const hrefMatch = /href\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(
        attrs,
      );
      const rawHref = decodeBasicEntities(
        (hrefMatch?.[1] ?? hrefMatch?.[2] ?? hrefMatch?.[3] ?? '').trim(),
      );
      const safeHref = SAFE_URL_PROTOCOLS.test(rawHref) ? rawHref : '#blocked';

      const plainInner = inner.replace(/<[^>]+>/g, '').trim();
      if (
        /^https?:\/\//i.test(plainInner) &&
        safeHref !== '#blocked' &&
        !safeHref.toLowerCase().startsWith(plainInner.toLowerCase().slice(0, 20))
      ) {
        suspiciousLinks.push({displayText: plainInner, href: safeHref});
      }

      if (safeHref === '#blocked') {
        return `<span class="text-rose-700 underline decoration-dotted" title="Blocked unsafe link">${inner}</span>`;
      }

      return `<a href="${escapeHtmlAttr(safeHref)}" target="_blank" rel="noopener noreferrer" data-safe-link="true">${inner}</a>`;
    },
  );

  // Filter all remaining tags strictly through the allowlist
  cleaned = cleaned.replace(
    /<(\/?)([a-zA-Z0-9-]+)([^>]*)>/g,
    (_match, slash: string, rawTag: string, rawAttrs: string) => {
      const tag = rawTag.toLowerCase();
      if (!ALLOWED_TAGS.has(tag)) {
        return '';
      }
      if (slash === '/') {
        return `</${tag}>`;
      }
      if (tag === 'a') {
        // Already sanitized above; preserve safe attributes only
        const hrefMatch = /href="([^"]*)"/i.exec(rawAttrs);
        const href = hrefMatch?.[1] ?? '#blocked';
        return `<a href="${href}" target="_blank" rel="noopener noreferrer" data-safe-link="true">`;
      }
      if (tag === 'img') {
        const srcMatch = /src\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(
          rawAttrs,
        );
        const altMatch = /alt\s*=\s*(?:"([^"]*)"|'([^']*)')/i.exec(rawAttrs);
        const rawSrc = decodeBasicEntities(
          (srcMatch?.[1] ?? srcMatch?.[2] ?? srcMatch?.[3] ?? '').trim(),
        );
        const alt = escapeHtmlAttr(altMatch?.[1] ?? altMatch?.[2] ?? 'Image');

        if (SAFE_INLINE_DATA_IMAGE.test(rawSrc)) {
          return `<img src="${escapeHtmlAttr(rawSrc)}" alt="${alt}" referrerpolicy="no-referrer" style="max-width:100%;height:auto;" />`;
        }

        if (/^https?:\/\//i.test(rawSrc)) {
          hasRemoteImages = true;
          if (!allowRemoteImages) {
            blockedImageCount += 1;
            return `<span data-blocked-remote-image="true" data-blocked-src="${escapeHtmlAttr(rawSrc)}" style="display:inline-block;padding:6px 10px;border:1px dashed #94a3b8;border-radius:6px;font-size:12px;color:#475569;background:#f8fafc;">[Remote image blocked: ${alt}]</span>`;
          }
          return `<img src="${escapeHtmlAttr(rawSrc)}" alt="${alt}" referrerpolicy="no-referrer" style="max-width:100%;height:auto;" />`;
        }

        return '';
      }

      if (tag === 'br' || tag === 'hr') {
        return `<${tag} />`;
      }
      return `<${tag}>`;
    },
  );

  return {
    html: cleaned,
    hasRemoteImages,
    blockedImageCount,
    suspiciousLinks,
  };
}

export function analyzeSenderAuthenticity(
  from: EmailParticipant,
  replyTo: EmailParticipant | null,
  headers: Record<string, string>,
  providerName: string,
): AuthVerificationSummary {
  const fromDomain = from.email.split('@')[1]?.toLowerCase() ?? '';
  const replyDomain = replyTo?.email.split('@')[1]?.toLowerCase() ?? '';

  let replyToMismatchWarning: string | null = null;
  if (replyTo && replyDomain && fromDomain && replyDomain !== fromDomain) {
    replyToMismatchWarning = `Reply-To (${replyTo.email}) differs from sender domain (${fromDomain}). Verify recipient before replying.`;
  }

  let suspiciousSenderWarning: string | null = null;
  if (
    from.name.includes('@') &&
    !from.name.toLowerCase().includes(from.email.toLowerCase())
  ) {
    suspiciousSenderWarning = `Display name contains an email address (${from.name}) that does not match sender (${from.email}).`;
  }

  const authHeader = (headers['Authentication-Results'] ?? '').toLowerCase();
  const spf: AuthVerificationSummary['spf'] = authHeader.includes('spf=pass')
    ? 'pass'
    : authHeader.includes('spf=fail')
      ? 'fail'
      : authHeader.includes('spf=neutral')
        ? 'neutral'
        : 'none';
  const dkim: AuthVerificationSummary['dkim'] = authHeader.includes('dkim=pass')
    ? 'pass'
    : authHeader.includes('dkim=fail')
      ? 'fail'
      : 'none';
  const dmarc: AuthVerificationSummary['dmarc'] = authHeader.includes(
    'dmarc=pass',
  )
    ? 'pass'
    : authHeader.includes('dmarc=fail')
      ? 'fail'
      : 'none';

  return {
    spf,
    dkim,
    dmarc,
    suppliedByProvider: providerName,
    independentlyVerifiedByApp: false,
    suspiciousSenderWarning,
    replyToMismatchWarning,
  };
}

const PROMPT_INJECTION_PATTERNS = [
  /ignore\s+(all\s+)?(previous|prior|above)\s+instructions/i,
  /system\s+override/i,
  /forward\s+(the\s+)?(entire\s+)?inbox/i,
  /exfiltrate/i,
  /bypass\s+(security|approval)/i,
  /reveal\s+(your\s+)?(system\s+prompt|api\s*key|credentials)/i,
];

export function detectPromptInjectionInEmail(text: string): boolean {
  return PROMPT_INJECTION_PATTERNS.some((pattern) => pattern.test(text));
}

export function wrapUntrustedEmailForAi(
  messageId: string,
  fromEmail: string,
  subject: string,
  bodyText: string,
): string {
  return [
    `<untrusted_email_content message_id="${messageId}" from="${fromEmail}">`,
    `Subject: ${subject}`,
    `Body:`,
    bodyText.slice(0, 4000),
    `</untrusted_email_content>`,
  ].join('\n');
}

export function redactSensitiveForLogs(input: string): string {
  return input
    .replace(/(Bearer\s+)[A-Za-z0-9\-._~+/]+=*/gi, '$1[REDACTED]')
    .replace(
      /(api[_-]?key|token|secret|password)\s*[:=]\s*["']?[^\s"',}]+["']?/gi,
      '$1=[REDACTED]',
    );
}
