export interface TimezoneOption {
  id: string;
  label: string;
}

export const SUPPORTED_TIMEZONES: TimezoneOption[] = [
  {id: 'America/Los_Angeles', label: 'Pacific Time (US & Canada)'},
  {id: 'America/New_York', label: 'Eastern Time (US & Canada)'},
  {id: 'Europe/London', label: 'London (GMT/BST)'},
  {id: 'Europe/Berlin', label: 'Berlin / Central Europe'},
  {id: 'Asia/Tokyo', label: 'Tokyo (JST)'},
  {id: 'UTC', label: 'Coordinated Universal Time (UTC)'},
];

/**
 * Computes the UTC offset in minutes for a specific IANA timezone at a given UTC Date.
 * Uses Intl.DateTimeFormat so historical and future DST transitions are respected.
 */
export function getTimezoneOffsetMinutes(
  utcDate: Date,
  timeZone: string,
): number {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
  const parts = formatter.formatToParts(utcDate);
  const lookup = (type: Intl.DateTimeFormatPartTypes) =>
    Number(parts.find((p) => p.type === type)?.value ?? '0');

  let hour = lookup('hour');
  if (hour === 24) {
    hour = 0;
  }

  const zonedAsUtc = Date.UTC(
    lookup('year'),
    lookup('month') - 1,
    lookup('day'),
    hour,
    lookup('minute'),
    lookup('second'),
  );
  return Math.round((zonedAsUtc - utcDate.getTime()) / 60000);
}

/**
 * Converts a wall-clock local date-time string ('YYYY-MM-DDTHH:mm') in an IANA timezone
 * to an exact UTC ISO string, preserving DST boundary behavior.
 */
export function localDateTimeToUtcIso(
  localDateTime: string,
  timeZone: string,
): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(
    localDateTime.trim(),
  );
  if (!match) {
    return new Date(localDateTime).toISOString();
  }
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const hour = Number(match[4]);
  const minute = Number(match[5]);

  const approxUtc = new Date(Date.UTC(year, month - 1, day, hour, minute, 0));
  const offset1 = getTimezoneOffsetMinutes(approxUtc, timeZone);
  const candidate = new Date(approxUtc.getTime() - offset1 * 60000);
  const offset2 = getTimezoneOffsetMinutes(candidate, timeZone);
  if (offset2 !== offset1) {
    return new Date(approxUtc.getTime() - offset2 * 60000).toISOString();
  }
  return candidate.toISOString();
}

/**
 * Formats a UTC ISO timestamp into a wall-clock string ('YYYY-MM-DDTHH:mm')
 * in the target timezone.
 */
export function utcIsoToLocalDateTime(
  utcIso: string,
  timeZone: string,
): string {
  const date = new Date(utcIso);
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
  const parts = formatter.formatToParts(date);
  const get = (t: Intl.DateTimeFormatPartTypes) =>
    parts.find((p) => p.type === t)?.value ?? '00';
  let hour = get('hour');
  if (hour === '24') hour = '00';
  return `${get('year')}-${get('month')}-${get('day')}T${hour}:${get('minute')}`;
}

export function formatTimeInTimezone(
  utcIso: string,
  timeZone: string,
): string {
  return new Intl.DateTimeFormat('en-US', {
    timeZone,
    hour: 'numeric',
    minute: '2-digit',
    timeZoneName: 'short',
  }).format(new Date(utcIso));
}

export function formatDateTimeInTimezone(
  utcIso: string,
  timeZone: string,
): string {
  return new Intl.DateTimeFormat('en-US', {
    timeZone,
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    timeZoneName: 'short',
  }).format(new Date(utcIso));
}
