import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import type {MailFolder} from '../../shared/types';
import {
  SanitizedClientMessage,
  WorkspaceStore,
} from '../core/workspace.store';

@Component({
  selector: 'app-mail-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="flex h-full min-h-0 flex-1 overflow-hidden">
      <!-- PANE 1: Folder Navigation -->
      <aside
        aria-label="Mail folders"
        class="hidden w-56 shrink-0 flex-col border-r border-slate-200 bg-[#F8FAFC] md:flex dark:border-slate-800 dark:bg-slate-950"
      >
        <div class="flex items-center justify-between px-3 py-2.5">
          <span class="font-display text-xs font-semibold tracking-wide text-slate-500 dark:text-slate-400">
            Mailboxes
          </span>
          <button
            type="button"
            (click)="creatingFolder.set(!creatingFolder())"
            class="rounded p-1 text-slate-500 hover:bg-slate-200/70 dark:text-slate-400 dark:hover:bg-slate-800"
            title="New custom folder"
          >
            <mat-icon class="!text-[16px]">create_new_folder</mat-icon>
          </button>
        </div>

        @if (creatingFolder()) {
          <div class="mx-2 mb-2 space-y-1.5 rounded-lg border border-slate-200 bg-white p-2 dark:border-slate-700 dark:bg-slate-900">
            <input
              type="text"
              [value]="newFolderName()"
              (input)="newFolderName.set($any($event.target).value)"
              placeholder="Folder name..."
              class="w-full rounded border border-slate-200 px-2 py-1 text-xs focus:border-[#0078D4] focus:outline-none dark:border-slate-700 dark:bg-slate-800"
            />
            <div class="flex justify-end gap-1">
              <button
                type="button"
                (click)="creatingFolder.set(false)"
                class="rounded px-2 py-0.5 text-[11px] text-slate-500"
              >
                Cancel
              </button>
              <button
                type="button"
                (click)="submitNewFolder()"
                class="rounded bg-[#0078D4] px-2 py-0.5 text-[11px] font-medium text-white"
              >
                Create
              </button>
            </div>
          </div>
        }

        <div class="flex-1 space-y-4 overflow-y-auto px-2 pb-4">
          <!-- Smart Quick Buckets -->
          <div class="space-y-0.5">
            <button
              type="button"
              (click)="selectBucket('unified_inbox')"
              [class]="
                store.smartBucket() === 'unified_inbox'
                  ? 'bg-[#0078D4]/10 text-[#0078D4] font-semibold dark:bg-sky-500/15 dark:text-sky-300'
                  : 'text-slate-700 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-slate-800/70'
              "
              class="flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-xs transition-colors"
            >
              <span class="flex items-center gap-2">
                <mat-icon class="!text-[16px]">all_inbox</mat-icon>
                <span>Unified Inbox</span>
              </span>
              <span class="tabular-nums text-[11px]">{{ store.unreadTotal() }}</span>
            </button>

            <button
              type="button"
              (click)="selectBucket('flagged')"
              [class]="
                store.smartBucket() === 'flagged'
                  ? 'bg-[#0078D4]/10 text-[#0078D4] font-semibold dark:bg-sky-500/15 dark:text-sky-300'
                  : 'text-slate-700 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-slate-800/70'
              "
              class="flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-xs transition-colors"
            >
              <span class="flex items-center gap-2">
                <mat-icon class="!text-[16px]">flag</mat-icon>
                <span>Flagged</span>
              </span>
              <span class="tabular-nums text-[11px]">{{ flaggedCount() }}</span>
            </button>

            <button
              type="button"
              (click)="selectBucket('snoozed')"
              [class]="
                store.smartBucket() === 'snoozed'
                  ? 'bg-[#0078D4]/10 text-[#0078D4] font-semibold dark:bg-sky-500/15 dark:text-sky-300'
                  : 'text-slate-700 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-slate-800/70'
              "
              class="flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-xs transition-colors"
            >
              <span class="flex items-center gap-2">
                <mat-icon class="!text-[16px]">schedule</mat-icon>
                <span>Snoozed</span>
              </span>
              <span class="tabular-nums text-[11px]">{{ snoozedCount() }}</span>
            </button>

            <button
              type="button"
              (click)="selectBucket('outbox')"
              [class]="
                store.smartBucket() === 'outbox'
                  ? 'bg-[#0078D4]/10 text-[#0078D4] font-semibold dark:bg-sky-500/15 dark:text-sky-300'
                  : 'text-slate-700 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-slate-800/70'
              "
              class="flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-xs transition-colors"
            >
              <span class="flex items-center gap-2">
                <mat-icon class="!text-[16px]">outbox</mat-icon>
                <span>Outbox &amp; Drafts</span>
              </span>
              <span class="tabular-nums text-[11px]">{{ store.outbox().length }}</span>
            </button>
          </div>

          <!-- Per-Account Folder Trees (Drag & Drop targets) -->
          @for (acc of visibleAccounts(); track acc.id) {
            <div class="space-y-0.5">
              <div class="flex items-center justify-between px-2 py-1">
                <span class="truncate text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  {{ acc.displayName }}
                </span>
                @if (acc.syncStatus === 'error') {
                  <button
                    type="button"
                    (click)="openSyncSettings()"
                    class="text-[11px] font-medium text-rose-600 hover:underline dark:text-rose-400"
                    title="Sync error — click to inspect and recover"
                  >
                    Sync Error
                  </button>
                }
              </div>

              @for (folder of foldersForAccount(acc.id); track folder.id) {
                <button
                  type="button"
                  (click)="selectFolder(folder)"
                  (dragover)="onFolderDragOver($event, folder.id)"
                  (dragleave)="dragHoverFolderId.set(null)"
                  (drop)="onFolderDrop($event, folder)"
                  [class]="
                    dragHoverFolderId() === folder.id
                      ? 'ring-2 ring-[#0078D4] bg-[#0078D4]/10'
                      : store.selectedFolderId() === folder.id && !store.smartBucket()
                        ? 'bg-[#0078D4]/10 text-[#0078D4] font-semibold dark:bg-sky-500/15 dark:text-sky-300'
                        : 'text-slate-700 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-slate-800/70'
                  "
                  class="flex w-full items-center justify-between rounded-md px-2.5 py-1.5 text-xs transition-colors"
                >
                  <span
                    class="flex items-center gap-2 truncate"
                    [class.pl-4]="folder.parentId !== null"
                  >
                    <mat-icon class="!text-[15px] text-slate-400">
                      {{ folderIcon(folder.role) }}
                    </mat-icon>
                    <span class="truncate">{{ folder.name }}</span>
                  </span>
                  @if (folder.unreadCount > 0) {
                    <span class="tabular-nums text-[11px] font-semibold">
                      {{ folder.unreadCount }}
                    </span>
                  }
                </button>
              }
            </div>
          }
        </div>
      </aside>

      <!-- PANE 2 & PANE 3 Wrapper (supports Right / Bottom / Hidden Reading Pane) -->
      <div
        class="flex min-w-0 flex-1 overflow-hidden"
        [class.flex-row]="store.preferences().readingPanePosition !== 'bottom'"
        [class.flex-col]="store.preferences().readingPanePosition === 'bottom'"
      >
        <!-- PANE 2: Message List / Outbox List -->
        @if (
          !store.mobileShowingReading() ||
          store.preferences().readingPanePosition === 'hidden'
        ) {
          <section
            aria-label="Message list"
            [class]="
              store.preferences().readingPanePosition === 'hidden'
                ? 'flex-1'
                : store.preferences().readingPanePosition === 'bottom'
                  ? 'h-1/2 border-b'
                  : 'w-full md:w-[360px] lg:w-[390px] border-r'
            "
            class="flex shrink-0 flex-col border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
          >
            <!-- List Header & Filters -->
            <div class="border-b border-slate-200 px-3 py-2.5 dark:border-slate-800">
              <div class="flex items-center justify-between gap-2">
                <h2 class="font-display truncate text-sm font-semibold text-slate-900 dark:text-slate-100">
                  {{ currentListTitle() }}
                </h2>
                <div class="flex items-center gap-1">
                  <button
                    type="button"
                    (click)="toggleGrouping()"
                    [title]="
                      store.preferences().conversationGrouping
                        ? 'Grouped by conversation'
                        : 'Individual messages'
                    "
                    class="rounded px-2 py-1 text-[11px] font-medium text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                  >
                    {{ store.preferences().conversationGrouping ? 'Threads' : 'Flat' }}
                  </button>
                  <select
                    aria-label="Sort messages"
                    [value]="store.mailSort()"
                    (change)="store.mailSort.set($any($event.target).value)"
                    class="rounded border border-slate-200 bg-transparent px-1.5 py-1 text-[11px] text-slate-600 dark:border-slate-700 dark:text-slate-300"
                  >
                    <option value="date_desc">Newest</option>
                    <option value="date_asc">Oldest</option>
                    <option value="sender">Sender</option>
                    <option value="subject">Subject</option>
                  </select>
                </div>
              </div>

              @if (store.smartBucket() !== 'outbox') {
                <div class="mt-2 flex flex-wrap items-center gap-1">
                  @for (f of filterTabs; track f.id) {
                    <button
                      type="button"
                      (click)="store.mailFilter.set(f.id)"
                      [class]="
                        store.mailFilter() === f.id
                          ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                          : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                      "
                      class="rounded-md px-2 py-0.5 text-[11px] font-medium whitespace-nowrap transition-colors"
                    >
                      {{ f.label }}
                    </button>
                  }
                </div>
              }

              <!-- Bulk Actions Bar -->
              @if (store.checkedMessageIds().size > 0) {
                <div
                  class="mt-2 flex flex-wrap items-center justify-between gap-1 rounded-md border border-[#0078D4]/30 bg-[#0078D4]/5 px-2.5 py-1.5 text-xs"
                >
                  <span class="tabular-nums font-medium text-[#0078D4] dark:text-sky-300">
                    {{ store.checkedMessageIds().size }} selected
                  </span>
                  <div class="flex items-center gap-1">
                    <button
                      type="button"
                      (click)="runBulk('mark_read')"
                      class="rounded px-2 py-0.5 text-[11px] hover:bg-white dark:hover:bg-slate-800"
                    >
                      Read
                    </button>
                    <button
                      type="button"
                      (click)="runBulk('flag')"
                      class="rounded px-2 py-0.5 text-[11px] hover:bg-white dark:hover:bg-slate-800"
                    >
                      Flag
                    </button>
                    <button
                      type="button"
                      (click)="runBulk('archive')"
                      class="rounded px-2 py-0.5 text-[11px] hover:bg-white dark:hover:bg-slate-800"
                    >
                      Archive
                    </button>
                    <button
                      type="button"
                      (click)="runBulk('delete')"
                      class="rounded px-2 py-0.5 text-[11px] text-rose-600 hover:bg-white dark:text-rose-400 dark:hover:bg-slate-800"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              }
            </div>

            <!-- Outbox View OR Message Rows -->
            <div class="flex-1 divide-y divide-slate-100 overflow-y-auto dark:divide-slate-800/80">
              @if (store.smartBucket() === 'outbox') {
                @if (store.outbox().length === 0) {
                  <div class="p-6 text-center text-xs text-slate-500">
                    <p>No drafts, delayed sends, or queued offline items.</p>
                    <button
                      type="button"
                      (click)="store.openNewComposer()"
                      class="mt-3 rounded-lg bg-[#0078D4] px-3 py-1.5 text-xs font-medium text-white"
                    >
                      Compose Message
                    </button>
                  </div>
                }
                @for (draft of store.outbox(); track draft.id) {
                  <div class="space-y-1.5 p-3 hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <div class="flex items-center justify-between gap-2">
                      <span class="truncate text-xs font-semibold text-slate-900 dark:text-slate-100">
                        {{ draft.subject || '(No subject)' }}
                      </span>
                      <span class="shrink-0 text-[11px] font-medium text-[#0078D4] dark:text-sky-300">
                        {{ outboxStatusLabel(draft.status) }}
                      </span>
                    </div>
                    <p class="text-[11px] text-slate-500 dark:text-slate-400">
                      To: {{ formatParticipants(draft.to) || '(No recipients)' }} · From {{ draft.sendAsAddress }}
                    </p>
                    <p class="text-[11px] text-slate-600 dark:text-slate-300">
                      {{ draft.deliveryNote }}
                    </p>
                    <div class="flex flex-wrap items-center gap-2 pt-1">
                      @if (draft.status === 'delayed_pending') {
                        <button
                          type="button"
                          (click)="store.cancelDelayedDraft(draft.id)"
                          class="rounded bg-amber-600 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-amber-700"
                        >
                          Undo Delay &amp; Edit
                        </button>
                        <button
                          type="button"
                          (click)="store.submitDelayedDraftNow(draft.id)"
                          class="rounded border border-slate-200 px-2.5 py-1 text-[11px] font-medium text-slate-700 dark:border-slate-700 dark:text-slate-200"
                        >
                          Send Immediately
                        </button>
                      } @else if (draft.status === 'uncertain_outcome' || draft.status === 'failed') {
                        <button
                          type="button"
                          (click)="store.submitDelayedDraftNow(draft.id)"
                          class="rounded bg-[#0078D4] px-2.5 py-1 text-[11px] font-medium text-white"
                        >
                          Verify &amp; Retry Safely
                        </button>
                      } @else if (draft.status === 'draft') {
                        <button
                          type="button"
                          (click)="reopenDraft(draft)"
                          class="rounded border border-slate-200 px-2.5 py-1 text-[11px] font-medium text-slate-700 dark:border-slate-700 dark:text-slate-200"
                        >
                          Resume Draft
                        </button>
                      }
                    </div>
                  </div>
                }
              } @else {
                @if (store.visibleMessages().length === 0) {
                  <div class="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                    <p>No messages match the current folder or filter.</p>
                    @if (store.searchQuery()) {
                      <button
                        type="button"
                        (click)="store.searchQuery.set('')"
                        class="mt-2 text-[#0078D4] hover:underline"
                      >
                        Clear search query
                      </button>
                    }
                  </div>
                }

                @for (msg of store.visibleMessages(); track msg.id) {
                  <div
                    draggable="true"
                    (dragstart)="onMessageDragStart($event, msg.id)"
                    (click)="store.selectMessage(msg)"
                    (keydown.enter)="store.selectMessage(msg)"
                    tabindex="0"
                    role="button"
                    [class]="
                      store.selectedMessageId() === msg.id
                        ? 'bg-[#0078D4]/8 dark:bg-sky-500/12'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    "
                    class="msg-row group flex cursor-pointer items-start gap-2.5 px-3 transition-colors focus-visible:outline-2 focus-visible:outline-[#0078D4]"
                  >
                    <input
                      type="checkbox"
                      [checked]="store.checkedMessageIds().has(msg.id)"
                      (click)="$event.stopPropagation(); store.toggleCheckedMessage(msg.id)"
                      [attr.aria-label]="'Select ' + msg.subject"
                      class="mt-1.5 rounded border-slate-300"
                    />

                    <div class="min-w-0 flex-1">
                      <div class="flex items-center justify-between gap-2">
                        <span
                          class="truncate text-xs"
                          [class.font-semibold]="!msg.isRead"
                          [class.text-slate-900]="!msg.isRead"
                          [class.dark:text-white]="!msg.isRead"
                          [class.text-slate-700]="msg.isRead"
                          [class.dark:text-slate-300]="msg.isRead"
                        >
                          {{ msg.from.name || msg.from.email }}
                        </span>
                        <span class="tabular-nums shrink-0 text-[11px] text-slate-400">
                          {{ msg.receivedAt.slice(5, 16).replace('T', ' ') }}
                        </span>
                      </div>

                      <div class="mt-0.5 flex items-center gap-1.5">
                        @if (msg.isPinned) {
                          <mat-icon class="!text-[13px] text-[#0078D4]">push_pin</mat-icon>
                        }
                        @if (msg.isFlagged) {
                          <mat-icon class="!text-[13px] text-amber-600">flag</mat-icon>
                        }
                        <span
                          class="truncate text-xs"
                          [class.font-semibold]="!msg.isRead"
                          [class.text-slate-900]="!msg.isRead"
                          [class.dark:text-slate-100]="!msg.isRead"
                          [class.text-slate-600]="msg.isRead"
                          [class.dark:text-slate-300]="msg.isRead"
                        >
                          {{ msg.subject }}
                        </span>
                      </div>

                      <p class="mt-0.5 truncate text-[11px] text-slate-500 dark:text-slate-400">
                        {{ msg.snippet }}
                      </p>

                      <!-- Unboxed zero-pill metadata line -->
                      <div class="mt-1 flex items-center gap-1.5 text-[11px] text-slate-400">
                        <span>{{ accountShortName(msg.accountId) }}</span>
                        @if (msg.categories.length > 0) {
                          <span aria-hidden="true">·</span>
                          <span class="truncate text-slate-500 dark:text-slate-400">
                            {{ msg.categories.join(', ') }}
                          </span>
                        }
                        @if (msg.attachments.length > 0) {
                          <span aria-hidden="true">·</span>
                          <span class="inline-flex items-center gap-0.5 tabular-nums">
                            <mat-icon class="!text-[12px]">attach_file</mat-icon>
                            {{ msg.attachments.length }}
                          </span>
                        }
                        @if (msg.authSummary.replyToMismatchWarning || msg.authSummary.suspiciousSenderWarning) {
                          <span aria-hidden="true">·</span>
                          <span class="font-medium text-rose-600 dark:text-rose-400">
                            Auth Warning
                          </span>
                        }
                      </div>
                    </div>
                  </div>
                }
              }
            </div>
          </section>
        }

        <!-- PANE 3: Reading Pane -->
        @if (store.preferences().readingPanePosition !== 'hidden') {
          <section
            aria-label="Reading pane"
            class="flex min-w-0 flex-1 flex-col overflow-hidden bg-white dark:bg-slate-900"
          >
            @if (store.selectedMessage(); as activeMsg) {
              <!-- Reading Action Toolbar -->
              <div
                class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-4 py-2.5 dark:border-slate-800"
              >
                <div class="flex flex-wrap items-center gap-1">
                  @if (store.mobileShowingReading()) {
                    <button
                      type="button"
                      (click)="store.mobileShowingReading.set(false)"
                      class="mr-1 inline-flex items-center gap-1 rounded px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 md:hidden dark:text-slate-300"
                    >
                      <mat-icon class="!text-[16px]">arrow_back</mat-icon>
                      <span>Back</span>
                    </button>
                  }

                  <button
                    type="button"
                    (click)="store.openReplyComposer(activeMsg, 'reply')"
                    class="inline-flex items-center gap-1 rounded-md bg-[#0078D4] px-2.5 py-1 text-xs font-medium text-white hover:bg-[#0263B0]"
                  >
                    <mat-icon class="!text-[15px]">reply</mat-icon>
                    <span>Reply</span>
                  </button>
                  <button
                    type="button"
                    (click)="store.openReplyComposer(activeMsg, 'replyAll')"
                    class="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    <mat-icon class="!text-[15px]">reply_all</mat-icon>
                    <span>Reply All</span>
                  </button>
                  <button
                    type="button"
                    (click)="store.openReplyComposer(activeMsg, 'forward')"
                    class="inline-flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                  >
                    <mat-icon class="!text-[15px]">forward</mat-icon>
                    <span>Forward</span>
                  </button>
                </div>

                <div class="flex flex-wrap items-center gap-1">
                  <button
                    type="button"
                    (click)="
                      store.bulkMessageAction(
                        [activeMsg.id],
                        activeMsg.isFlagged ? 'unflag' : 'flag'
                      )
                    "
                    class="inline-flex items-center gap-1 rounded px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                    title="Flag for follow-up"
                  >
                    <mat-icon
                      class="!text-[16px]"
                      [class.text-amber-600]="activeMsg.isFlagged"
                    >
                      flag
                    </mat-icon>
                    <span>{{ activeMsg.isFlagged ? 'Flagged' : 'Flag' }}</span>
                  </button>

                  <button
                    type="button"
                    (click)="
                      store.bulkMessageAction(
                        [activeMsg.id],
                        activeMsg.isPinned ? 'unpin' : 'pin'
                      )
                    "
                    class="inline-flex items-center gap-1 rounded px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                  >
                    <mat-icon
                      class="!text-[16px]"
                      [class.text-[#0078D4]]="activeMsg.isPinned"
                    >
                      push_pin
                    </mat-icon>
                    <span>{{ activeMsg.isPinned ? 'Pinned' : 'Pin' }}</span>
                  </button>

                  <button
                    type="button"
                    (click)="
                      store.bulkMessageAction(
                        [activeMsg.id],
                        activeMsg.snoozedUntil ? 'unsnooze' : 'snooze'
                      )
                    "
                    class="inline-flex items-center gap-1 rounded px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                  >
                    <mat-icon class="!text-[16px]">snooze</mat-icon>
                    <span>{{ activeMsg.snoozedUntil ? 'Unsnooze' : 'Snooze' }}</span>
                  </button>

                  <button
                    type="button"
                    (click)="store.createTaskFromMessage(activeMsg)"
                    class="inline-flex items-center gap-1 rounded px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                    title="Create a task without removing this email"
                  >
                    <mat-icon class="!text-[16px]">add_task</mat-icon>
                    <span>Create Task</span>
                  </button>

                  <button
                    type="button"
                    (click)="summarizeWithCopilot(activeMsg)"
                    class="inline-flex items-center gap-1 rounded border border-[#0078D4]/30 bg-[#0078D4]/5 px-2 py-1 text-xs font-medium text-[#0078D4] hover:bg-[#0078D4]/10 dark:text-sky-300"
                  >
                    <mat-icon class="!text-[15px]">assistant</mat-icon>
                    <span>Summarize</span>
                  </button>

                  <button
                    type="button"
                    (click)="store.togglePlainText(activeMsg.id)"
                    class="rounded px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                  >
                    {{
                      store.plainTextMessageIds().has(activeMsg.id)
                        ? 'HTML View'
                        : 'Plain Text'
                    }}
                  </button>

                  <button
                    type="button"
                    (click)="exportEml(activeMsg)"
                    class="rounded px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                    title="Export message as .eml"
                  >
                    Export
                  </button>

                  <button
                    type="button"
                    (click)="store.bulkMessageAction([activeMsg.id], 'delete')"
                    class="rounded p-1 text-slate-500 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40"
                    aria-label="Delete message"
                  >
                    <mat-icon class="!text-[17px]">delete_outline</mat-icon>
                  </button>
                </div>
              </div>

              <!-- Reading Content Scroll Area -->
              <div class="flex-1 space-y-5 overflow-y-auto px-6 py-5">
                <div>
                  <h1 class="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
                    {{ activeMsg.subject }}
                  </h1>
                  <div class="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span>{{ accountShortName(activeMsg.accountId) }}</span>
                    @if (activeMsg.categories.length > 0) {
                      <span aria-hidden="true">·</span>
                      <span>Categories: {{ activeMsg.categories.join(', ') }}</span>
                    }
                    <span aria-hidden="true">·</span>
                    <button
                      type="button"
                      (click)="addQuickCategory(activeMsg)"
                      class="text-[#0078D4] hover:underline"
                    >
                      + Tag
                    </button>
                  </div>
                </div>

                <!-- Security Warnings (Suspicious Sender / Reply-To Mismatch) -->
                @if (
                  activeMsg.authSummary.replyToMismatchWarning ||
                  activeMsg.authSummary.suspiciousSenderWarning ||
                  activeMsg.suspiciousLinks.length > 0
                ) {
                  <div
                    role="alert"
                    class="rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-900 dark:border-rose-900/60 dark:bg-rose-950/40 dark:text-rose-200"
                  >
                    <div class="flex items-center gap-2 font-semibold">
                      <mat-icon class="!text-[17px] text-rose-600">gpp_maybe</mat-icon>
                      <span>Sender &amp; Link Verification Warning</span>
                    </div>
                    @if (activeMsg.authSummary.suspiciousSenderWarning) {
                      <p class="mt-1">{{ activeMsg.authSummary.suspiciousSenderWarning }}</p>
                    }
                    @if (activeMsg.authSummary.replyToMismatchWarning) {
                      <p class="mt-1">{{ activeMsg.authSummary.replyToMismatchWarning }}</p>
                    }
                    @if (activeMsg.suspiciousLinks.length > 0) {
                      <p class="mt-1">
                        Deceptive link detected: displays "{{ activeMsg.suspiciousLinks[0]?.displayText }}"
                        but points to "{{ activeMsg.suspiciousLinks[0]?.href }}".
                      </p>
                    }
                  </div>
                }

                <!-- Conversation Messages -->
                @for (item of store.selectedThreadMessages(); track item.id) {
                  <article
                    class="rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-950/40"
                  >
                    <div class="flex flex-wrap items-start justify-between gap-2 border-b border-slate-100 pb-3 dark:border-slate-800">
                      <div class="flex items-center gap-3">
                        <div
                          class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#0F2544] text-xs font-semibold text-white dark:bg-sky-800"
                        >
                          {{ initials(item.from.name || item.from.email) }}
                        </div>
                        <div class="min-w-0">
                          <div class="flex flex-wrap items-center gap-1.5 text-xs">
                            <span class="font-semibold text-slate-900 dark:text-slate-100">
                              {{ item.from.name }}
                            </span>
                            <span class="font-mono text-[11px] text-slate-500">
                              &lt;{{ item.from.email }}&gt;
                            </span>
                          </div>
                          <div class="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                            To: {{ formatParticipants(item.to) }}
                            @if (item.cc.length > 0) {
                              <span> · Cc: {{ formatParticipants(item.cc) }}</span>
                            }
                            @if (item.replyTo) {
                              <span> · Reply-To: {{ item.replyTo.email }}</span>
                            }
                          </div>
                        </div>
                      </div>

                      <div class="text-right text-[11px] text-slate-500 dark:text-slate-400">
                        <div class="tabular-nums">
                          {{ item.receivedAt.replace('T', ' ').slice(0, 19) }} UTC
                        </div>
                        <div class="mt-0.5 flex items-center justify-end gap-2">
                          <span>
                            SPF {{ item.authSummary.spf }} · DKIM {{ item.authSummary.dkim }} · DMARC {{ item.authSummary.dmarc }}
                          </span>
                          <button
                            type="button"
                            (click)="toggleHeaders(item.id)"
                            class="text-[#0078D4] hover:underline"
                          >
                            {{ expandedHeaders().has(item.id) ? 'Hide headers' : 'Headers' }}
                          </button>
                        </div>
                      </div>
                    </div>

                    @if (expandedHeaders().has(item.id)) {
                      <div
                        class="mt-3 rounded bg-slate-50 p-2.5 font-mono text-[11px] text-slate-700 dark:bg-slate-900 dark:text-slate-300"
                      >
                        <div class="mb-1 font-sans text-[11px] font-medium text-slate-500">
                          Provider-supplied headers ({{ item.authSummary.suppliedByProvider }} — not independently verified by client):
                        </div>
                        <div>UID: {{ item.providerUid }} · UIDVALIDITY: {{ item.uidValidity }}</div>
                        @for (entry of headerEntries(item.headers); track entry[0]) {
                          <div>{{ entry[0] }}: {{ entry[1] }}</div>
                        }
                      </div>
                    }

                    <!-- Remote Image Blocking Control -->
                    @if (item.hasRemoteImages && item.blockedImageCount > 0) {
                      <div
                        class="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200"
                      >
                        <span>
                          {{ item.blockedImageCount }} remote image(s) blocked to protect privacy.
                        </span>
                        <button
                          type="button"
                          (click)="store.allowRemoteImagesForMessage(item.id)"
                          class="font-semibold text-[#0078D4] hover:underline dark:text-sky-300"
                        >
                          Load remote images for this message
                        </button>
                      </div>
                    }

                    <!-- Isolated Message Content -->
                    <div class="mt-3">
                      @if (store.plainTextMessageIds().has(item.id)) {
                        <pre class="whitespace-pre-wrap font-mono text-xs leading-relaxed text-slate-800 dark:text-slate-200">{{ item.bodyText }}</pre>
                      } @else {
                        <div
                          class="prose prose-sm max-w-none text-sm leading-relaxed text-slate-800 dark:prose-invert dark:text-slate-200"
                          [innerHTML]="item.bodyHtmlSanitized"
                        ></div>
                      }
                    </div>

                    <!-- Attachments -->
                    @if (item.attachments.length > 0) {
                      <div class="mt-4 border-t border-slate-100 pt-3 dark:border-slate-800">
                        <div class="mb-2 text-xs font-medium text-slate-500">
                          Attachments ({{ item.attachments.length }})
                        </div>
                        <div class="flex flex-wrap gap-2">
                          @for (att of item.attachments; track att.id) {
                            <button
                              type="button"
                              (click)="store.previewAttachment.set(att)"
                              class="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-left text-xs hover:border-[#0078D4] dark:border-slate-700 dark:bg-slate-800"
                            >
                              <mat-icon class="!text-[16px] text-[#0078D4]">description</mat-icon>
                              <div>
                                <div class="font-medium text-slate-900 dark:text-slate-100">
                                  {{ att.filename }}
                                </div>
                                <div class="tabular-nums text-[11px] text-slate-500">
                                  {{ Math.max(1, Math.round(att.sizeBytes / 1024)) }} KB · Scan: {{ att.scanStatus }}
                                </div>
                              </div>
                            </button>
                          }
                        </div>
                      </div>
                    }

                    <!-- Shared Mailbox Internal Collaboration Notes -->
                    @if (isSharedAccount(item.accountId)) {
                      <div class="mt-4 rounded-lg border border-indigo-200/70 bg-indigo-50/60 p-3 text-xs dark:border-indigo-900/50 dark:bg-indigo-950/30">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                          <span class="font-semibold text-indigo-900 dark:text-indigo-200">
                            Shared Mailbox Collaboration (Internal only — never sent externally)
                          </span>
                          <span class="text-indigo-700 dark:text-indigo-300">
                            Owner: {{ item.assignedTo || 'Unassigned' }}
                          </span>
                        </div>
                        @for (note of item.internalNotes; track note.id) {
                          <div class="mt-2 border-t border-indigo-200/50 pt-1.5 text-slate-700 dark:border-indigo-800/50 dark:text-slate-300">
                            <span class="font-medium">{{ note.authorName }}:</span>
                            {{ note.text }}
                          </div>
                        }
                        <div class="mt-2 flex gap-2">
                          <input
                            type="text"
                            [value]="noteDraft()"
                            (input)="noteDraft.set($any($event.target).value)"
                            placeholder="Add internal team note..."
                            class="flex-1 rounded border border-indigo-200 bg-white px-2.5 py-1 text-xs focus:outline-none dark:border-indigo-800 dark:bg-slate-900"
                          />
                          <button
                            type="button"
                            (click)="submitInternalNote(item.id)"
                            class="rounded bg-indigo-700 px-3 py-1 text-xs font-medium text-white hover:bg-indigo-800"
                          >
                            Save Note
                          </button>
                        </div>
                      </div>
                    }
                  </article>
                }
              </div>
            } @else {
              <div class="flex flex-1 flex-col items-center justify-center p-8 text-center text-sm text-slate-500">
                <mat-icon class="!text-[36px] text-slate-300 dark:text-slate-600">mark_email_read</mat-icon>
                <p class="mt-2 font-medium text-slate-700 dark:text-slate-300">
                  Select a conversation to read
                </p>
              </div>
            }
          </section>
        }
      </div>
    </div>

    <!-- Attachment Preview Modal -->
    @if (store.previewAttachment(); as att) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4"
        role="dialog"
        aria-modal="true"
        aria-label="Attachment preview"
      >
        <div class="w-full max-w-xl rounded-xl border border-slate-200 bg-white p-5 shadow-xl dark:border-slate-700 dark:bg-slate-900">
          <div class="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
            <div>
              <h3 class="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                {{ att.filename }}
              </h3>
              <p class="tabular-nums text-xs text-slate-500">
                {{ att.mimeType }} · {{ Math.max(1, Math.round(att.sizeBytes / 1024)) }} KB · Malware Scan: {{ att.scanStatus }}
              </p>
            </div>
            <button
              type="button"
              (click)="store.previewAttachment.set(null)"
              class="rounded p-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <mat-icon class="!text-[18px]">close</mat-icon>
            </button>
          </div>
          <pre class="mt-4 max-h-80 overflow-auto rounded-lg bg-slate-50 p-3 font-mono text-xs text-slate-800 dark:bg-slate-950 dark:text-slate-200">{{ att.contentPreview }}</pre>
        </div>
      </div>
    }
  `,
})
export class MailWorkspace {
  protected Math = Math;
  store = inject(WorkspaceStore);

  readonly creatingFolder = signal(false);
  readonly newFolderName = signal('');
  readonly dragHoverFolderId = signal<string | null>(null);
  readonly expandedHeaders = signal<Set<string>>(new Set());
  readonly noteDraft = signal('');

  readonly filterTabs = [
    {id: 'all' as const, label: 'All'},
    {id: 'unread' as const, label: 'Unread'},
    {id: 'flagged' as const, label: 'Flagged'},
    {id: 'pinned' as const, label: 'Pinned'},
    {id: 'attachments' as const, label: 'Attachments'},
  ];

  readonly visibleAccounts = computed(() => {
    const sel = this.store.selectedAccountId();
    const all = this.store.accounts();
    return sel === 'all' ? all : all.filter((a) => a.id === sel);
  });

  readonly flaggedCount = computed(
    () => this.store.messages().filter((m) => m.isFlagged).length,
  );

  readonly snoozedCount = computed(
    () => this.store.messages().filter((m) => Boolean(m.snoozedUntil)).length,
  );

  readonly currentListTitle = computed(() => {
    if (this.store.searchQuery()) return `Search: "${this.store.searchQuery()}"`;
    const bucket = this.store.smartBucket();
    if (bucket === 'unified_inbox') return 'Unified Inbox';
    if (bucket === 'flagged') return 'Flagged Follow-ups';
    if (bucket === 'snoozed') return 'Snoozed Messages';
    if (bucket === 'outbox') return 'Outbox, Delays & Drafts';
    const fld = this.store
      .folders()
      .find((f) => f.id === this.store.selectedFolderId());
    return fld ? fld.name : 'Messages';
  });

  foldersForAccount(accountId: string): MailFolder[] {
    return this.store
      .folders()
      .filter((f) => f.accountId === accountId)
      .sort((a, b) => a.order - b.order);
  }

  folderIcon(role: MailFolder['role']): string {
    switch (role) {
      case 'inbox':
        return 'inbox';
      case 'sent':
        return 'send';
      case 'drafts':
        return 'drafts';
      case 'archive':
        return 'archive';
      case 'junk':
        return 'report';
      case 'deleted':
        return 'delete';
      default:
        return 'folder';
    }
  }

  selectBucket(
    bucket: 'unified_inbox' | 'flagged' | 'snoozed' | 'outbox',
  ): void {
    this.store.smartBucket.set(bucket);
    this.store.selectedFolderId.set(null);
    this.store.mobileShowingReading.set(false);
  }

  selectFolder(folder: MailFolder): void {
    this.store.smartBucket.set(null);
    this.store.selectedFolderId.set(folder.id);
    this.store.mobileShowingReading.set(false);
    const first = this.store.visibleMessages()[0];
    if (first) this.store.selectedMessageId.set(first.id);
  }

  async submitNewFolder(): Promise<void> {
    const name = this.newFolderName().trim();
    if (!name) return;
    const accId =
      this.store.selectedAccountId() !== 'all'
        ? this.store.selectedAccountId()
        : (this.store.accounts()[0]?.id ?? 'acc_work');
    await this.store.createFolder(accId, name);
    this.newFolderName.set('');
    this.creatingFolder.set(false);
  }

  onMessageDragStart(event: DragEvent, messageId: string): void {
    event.dataTransfer?.setData('text/plain', messageId);
  }

  onFolderDragOver(event: DragEvent, folderId: string): void {
    event.preventDefault();
    this.dragHoverFolderId.set(folderId);
  }

  onFolderDrop(event: DragEvent, folder: MailFolder): void {
    event.preventDefault();
    this.dragHoverFolderId.set(null);
    const messageId = event.dataTransfer?.getData('text/plain');
    if (messageId) {
      void this.store.bulkMessageAction([messageId], 'move_folder', folder.id);
    }
  }

  toggleGrouping(): void {
    const curr = this.store.preferences().conversationGrouping;
    void this.store.updatePreferences({conversationGrouping: !curr});
  }

  runBulk(action: string): void {
    const ids = Array.from(this.store.checkedMessageIds());
    void this.store.bulkMessageAction(ids, action);
  }

  accountShortName(accountId: string): string {
    return (
      this.store.accounts().find((a) => a.id === accountId)?.email ?? accountId
    );
  }

  isSharedAccount(accountId: string): boolean {
    return (
      this.store.accounts().find((a) => a.id === accountId)?.kind ===
      'shared_mailbox'
    );
  }

  initials(name: string): string {
    return name
      .split(/\s+/)
      .slice(0, 2)
      .map((p) => p[0]?.toUpperCase() ?? '')
      .join('');
  }

  formatParticipants(list: {name: string; email: string}[]): string {
    return list.map((p) => p.name || p.email).join(', ');
  }

  toggleHeaders(id: string): void {
    this.expandedHeaders.update((set) => {
      const next = new Set(set);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  headerEntries(headers: Record<string, string>): [string, string][] {
    return Object.entries(headers);
  }

  async addQuickCategory(msg: SanitizedClientMessage): Promise<void> {
    await this.store.bulkMessageAction([msg.id], 'add_category', 'Follow-Up');
  }

  async submitInternalNote(messageId: string): Promise<void> {
    const text = this.noteDraft().trim();
    if (!text) return;
    await this.store.addInternalNote(
      messageId,
      text,
      this.store.data()?.currentUserEmail ?? null,
    );
    this.noteDraft.set('');
  }

  async summarizeWithCopilot(msg: SanitizedClientMessage): Promise<void> {
    const threadIds = this.store
      .selectedThreadMessages()
      .map((m) => m.id);
    this.store.copilotDrawerOpen.set(true);
    await this.store.runCopilotAssist({
      actionType: 'summarize',
      messageIds: threadIds.length > 0 ? threadIds : [msg.id],
    });
  }

  outboxStatusLabel(status: string): string {
    switch (status) {
      case 'delayed_pending':
        return 'Delay Window Active';
      case 'queued_offline':
        return 'Queued Offline (Not Sent)';
      case 'uncertain_outcome':
        return 'Uncertain Outcome';
      case 'submitted':
        return 'Submitted';
      case 'failed':
        return 'Failed';
      default:
        return 'Draft';
    }
  }

  reopenDraft(draft: ReturnType<WorkspaceStore['outbox']>[number]): void {
    this.store.activeDraft.set(draft);
    this.store.composerOpen.set(true);
  }

  openSyncSettings(): void {
    this.store.settingsTab.set('accounts');
    this.store.settingsOpen.set(true);
  }

  exportEml(msg: SanitizedClientMessage): void {
    const eml = [
      `From: ${msg.from.name} <${msg.from.email}>`,
      `To: ${msg.to.map((p) => `${p.name} <${p.email}>`).join(', ')}`,
      `Subject: ${msg.subject}`,
      `Date: ${msg.receivedAt}`,
      `Message-ID: ${msg.internetMessageId}`,
      '',
      msg.bodyText,
    ].join('\r\n');
    const blob = new Blob([eml], {type: 'message/rfc822'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${msg.id}.eml`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
