import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import {FormBuilder, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {ContactRecord, EmailParticipant} from '../../shared/types';
import {WorkspaceStore} from '../core/workspace.store';

@Component({
  selector: 'app-composer-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.composerOpen()) {
      <div
        class="fixed inset-0 z-50 flex items-end justify-end bg-slate-950/30 p-3 sm:p-6"
        role="dialog"
        aria-modal="true"
        aria-label="Message Composer"
      >
        <div
          class="flex h-[88vh] w-full max-w-3xl flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl dark:border-slate-700 dark:bg-slate-900"
        >
          <!-- Composer Header -->
          <div
            class="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-800 dark:bg-slate-950"
          >
            <div class="flex items-center gap-2.5">
              <mat-icon class="text-[#0078D4] !text-[20px]">edit_note</mat-icon>
              <h2 class="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                {{ form.controls.subject.value || 'New Message' }}
              </h2>
              @if (autosaveStatus()) {
                <span class="text-xs text-slate-500 dark:text-slate-400">
                  · {{ autosaveStatus() }}
                </span>
              }
            </div>
            <div class="flex items-center gap-2">
              <button
                type="button"
                (click)="discardDraft()"
                class="inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                <mat-icon class="!text-[16px]">delete_outline</mat-icon>
                <span>Discard</span>
              </button>
              <button
                type="button"
                (click)="closeComposer()"
                aria-label="Close composer"
                class="rounded-lg p-1.5 text-slate-500 hover:bg-slate-200/70 dark:text-slate-400 dark:hover:bg-slate-800"
              >
                <mat-icon class="!text-[18px]">close</mat-icon>
              </button>
            </div>
          </div>

          <!-- Sending Identity & Recipients -->
          <form
            [formGroup]="form"
            class="flex flex-1 flex-col overflow-hidden"
          >
            <div class="space-y-2 border-b border-slate-200 px-4 py-3 text-xs dark:border-slate-800">
              <!-- From Identity -->
              <div class="flex flex-wrap items-center gap-2">
                <label
                  for="composer-from"
                  class="w-14 shrink-0 font-medium text-slate-500 dark:text-slate-400"
                >
                  From
                </label>
                <select
                  id="composer-from"
                  formControlName="accountId"
                  (change)="onAccountChange()"
                  class="rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-900 focus:border-[#0078D4] focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                >
                  @for (acc of store.accounts(); track acc.id) {
                    <option [value]="acc.id">
                      {{ acc.displayName }} &lt;{{ acc.email }}&gt;
                      @if (acc.kind === 'shared_mailbox') {
                        (Shared Send-As)
                      }
                    </option>
                  }
                </select>
                @if (selectedAccount()?.kind === 'shared_mailbox') {
                  <span
                    class="text-xs font-medium text-indigo-700 dark:text-indigo-300"
                  >
                    Sending as shared mailbox: {{ selectedAccount()?.email }}
                  </span>
                }
              </div>

              <!-- To Field with Autocomplete -->
              <div class="relative flex flex-wrap items-center gap-1.5">
                <span class="w-14 shrink-0 font-medium text-slate-500 dark:text-slate-400">
                  To
                </span>
                @for (rcpt of toList(); track rcpt.email) {
                  <span
                    class="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-xs text-slate-800 dark:bg-slate-800 dark:text-slate-200"
                  >
                    <span>{{ rcpt.name || rcpt.email }}</span>
                    <button
                      type="button"
                      (click)="removeRecipient('to', rcpt.email)"
                      class="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                      aria-label="Remove recipient"
                    >
                      ×
                    </button>
                  </span>
                }
                <input
                  type="text"
                  [value]="toInput()"
                  (input)="onRecipientInput('to', $any($event.target).value)"
                  (keydown.enter)="$event.preventDefault(); commitRawRecipient('to')"
                  placeholder="Type name or email address..."
                  class="min-w-[180px] flex-1 bg-transparent py-1 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-slate-100"
                />
                <button
                  type="button"
                  (click)="showCcBcc.set(!showCcBcc())"
                  class="text-xs font-medium text-[#0078D4] hover:underline"
                >
                  {{ showCcBcc() ? 'Hide Cc/Bcc' : 'Cc / Bcc' }}
                </button>

                @if (autocompleteTarget() === 'to' && suggestions().length > 0) {
                  <div
                    class="absolute top-full left-14 z-20 mt-1 w-80 rounded-lg border border-slate-200 bg-white py-1 shadow-lg dark:border-slate-700 dark:bg-slate-800"
                  >
                    @for (sug of suggestions(); track sug.id) {
                      <button
                        type="button"
                        (click)="pickSuggestion('to', sug)"
                        class="flex w-full items-center justify-between px-3 py-1.5 text-left hover:bg-slate-100 dark:hover:bg-slate-700"
                      >
                        <div>
                          <div class="font-medium text-slate-900 dark:text-slate-100">
                            {{ sug.displayName }}
                          </div>
                          <div class="text-[11px] text-slate-500 dark:text-slate-400">
                            {{ sug.emails[0]?.address }}
                          </div>
                        </div>
                        <span class="text-[10px] font-medium text-slate-500 dark:text-slate-400">
                          {{
                            sug.trustLevel === 'saved_contact'
                              ? 'Saved Contact'
                              : 'Recent Suggestion'
                          }}
                        </span>
                      </button>
                    }
                  </div>
                }
              </div>

              @if (showCcBcc()) {
                <div class="flex flex-wrap items-center gap-1.5">
                  <span class="w-14 shrink-0 font-medium text-slate-500 dark:text-slate-400">
                    Cc
                  </span>
                  @for (rcpt of ccList(); track rcpt.email) {
                    <span
                      class="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-xs text-slate-800 dark:bg-slate-800 dark:text-slate-200"
                    >
                      <span>{{ rcpt.email }}</span>
                      <button
                        type="button"
                        (click)="removeRecipient('cc', rcpt.email)"
                      >
                        ×
                      </button>
                    </span>
                  }
                  <input
                    type="text"
                    [value]="ccInput()"
                    (input)="ccInput.set($any($event.target).value)"
                    (keydown.enter)="$event.preventDefault(); commitRawRecipient('cc')"
                    placeholder="Add Cc email and press Enter..."
                    class="min-w-[160px] flex-1 bg-transparent py-1 text-xs text-slate-900 focus:outline-none dark:text-slate-100"
                  />
                </div>
                <div class="flex flex-wrap items-center gap-1.5">
                  <span class="w-14 shrink-0 font-medium text-slate-500 dark:text-slate-400">
                    Bcc
                  </span>
                  @for (rcpt of bccList(); track rcpt.email) {
                    <span
                      class="inline-flex items-center gap-1 rounded bg-slate-100 px-2 py-0.5 text-xs text-slate-800 dark:bg-slate-800 dark:text-slate-200"
                    >
                      <span>{{ rcpt.email }}</span>
                      <button
                        type="button"
                        (click)="removeRecipient('bcc', rcpt.email)"
                      >
                        ×
                      </button>
                    </span>
                  }
                  <input
                    type="text"
                    [value]="bccInput()"
                    (input)="bccInput.set($any($event.target).value)"
                    (keydown.enter)="$event.preventDefault(); commitRawRecipient('bcc')"
                    placeholder="Add Bcc email and press Enter..."
                    class="min-w-[160px] flex-1 bg-transparent py-1 text-xs text-slate-900 focus:outline-none dark:text-slate-100"
                  />
                </div>
              }

              <!-- Subject -->
              <div class="flex items-center gap-2 pt-0.5">
                <label
                  for="composer-subject"
                  class="w-14 shrink-0 font-medium text-slate-500 dark:text-slate-400"
                >
                  Subject
                </label>
                <input
                  id="composer-subject"
                  type="text"
                  formControlName="subject"
                  placeholder="Add a clear subject"
                  class="flex-1 bg-transparent py-1 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-slate-100"
                />
              </div>
            </div>

            <!-- Formatting, Templates, Attachments & Copilot Toolbar -->
            <div
              class="flex flex-wrap items-center gap-1.5 border-b border-slate-200 bg-slate-50/70 px-4 py-2 dark:border-slate-800 dark:bg-slate-950/60"
            >
              <button
                type="button"
                (click)="toggleRichMode()"
                class="inline-flex items-center gap-1 rounded border border-slate-200 bg-white px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <mat-icon class="!text-[14px]">text_format</mat-icon>
                <span>{{ isRichText() ? 'Rich Text' : 'Plain Text' }}</span>
              </button>

              @if (isRichText()) {
                <button
                  type="button"
                  (click)="appendSnippet('**Important:** ')"
                  class="rounded px-2 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:bg-slate-800"
                  title="Insert emphasis"
                >
                  B
                </button>
                <button
                  type="button"
                  (click)="appendSnippet('- Action item: ')"
                  class="inline-flex items-center rounded px-2 py-1 text-xs text-slate-700 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:bg-slate-800"
                  title="Insert bullet"
                >
                  <mat-icon class="!text-[15px]">format_list_bulleted</mat-icon>
                </button>
              }

              <select
                aria-label="Insert email template"
                (change)="insertTemplate($any($event.target).value); $any($event.target).value = ''"
                class="rounded border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <option value="">Insert template...</option>
                @for (tpl of store.data()?.templates ?? []; track tpl.id) {
                  <option [value]="tpl.id">{{ tpl.name }}</option>
                }
              </select>

              <label
                class="inline-flex cursor-pointer items-center gap-1 rounded border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <mat-icon class="!text-[14px]">attach_file</mat-icon>
                <span>Attach</span>
                <input
                  type="file"
                  class="hidden"
                  (change)="onFilePicked($event)"
                />
              </label>

              <button
                type="button"
                (click)="attachInlineDiagram()"
                class="inline-flex items-center gap-1 rounded border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <mat-icon class="!text-[14px]">image</mat-icon>
                <span>Inline Image</span>
              </button>

              <div class="ml-auto flex items-center gap-1.5">
                <button
                  type="button"
                  [disabled]="aiBusy()"
                  (click)="rewriteWithCopilot('concise')"
                  class="inline-flex items-center gap-1 rounded border border-[#0078D4]/30 bg-[#0078D4]/5 px-2.5 py-1 text-xs font-medium text-[#0078D4] hover:bg-[#0078D4]/10 disabled:opacity-50 dark:text-sky-300"
                >
                  <mat-icon class="!text-[14px]">auto_fix_high</mat-icon>
                  <span>{{ aiBusy() ? 'Working...' : 'Copilot Rewrite' }}</span>
                </button>
                <button
                  type="button"
                  [disabled]="aiBusy()"
                  (click)="translateWithCopilot('French')"
                  class="inline-flex items-center gap-1 rounded border border-slate-200 bg-white px-2 py-1 text-xs text-slate-700 hover:bg-slate-100 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                >
                  <mat-icon class="!text-[14px]">translate</mat-icon>
                  <span>Translate</span>
                </button>
              </div>
            </div>

            <!-- Message Body -->
            <div class="flex flex-1 flex-col overflow-y-auto p-4">
              <textarea
                formControlName="bodyText"
                rows="12"
                placeholder="Write your message..."
                class="min-h-[220px] w-full flex-1 resize-none bg-transparent text-sm leading-relaxed text-slate-900 placeholder:text-slate-400 focus:outline-none dark:text-slate-100"
              ></textarea>

              @if (attachments().length > 0) {
                <div class="mt-3 flex flex-wrap gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                  @for (att of attachments(); track att.id) {
                    <div
                      class="inline-flex items-center gap-2 rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1 text-xs text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                    >
                      <mat-icon class="!text-[15px] text-slate-500">description</mat-icon>
                      <span>{{ att.filename }}</span>
                      <span class="tabular-nums text-[11px] text-slate-400">
                        {{ Math.max(1, Math.round(att.sizeBytes / 1024)) }} KB
                      </span>
                      <button
                        type="button"
                        (click)="removeAttachment(att.id)"
                        class="text-slate-400 hover:text-rose-600"
                        aria-label="Remove attachment"
                      >
                        ×
                      </button>
                    </div>
                  }
                </div>
              }
            </div>

            <!-- Schedule, Delayed-Send & Submit Bar -->
            <div
              class="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-800 dark:bg-slate-950"
            >
              <div class="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
                <label class="inline-flex items-center gap-1.5">
                  <span>Delay:</span>
                  <select
                    formControlName="sendDelaySeconds"
                    class="rounded border border-slate-200 bg-white px-2 py-1 text-xs tabular-nums dark:border-slate-700 dark:bg-slate-800"
                  >
                    <option [value]="0">0s (Immediate)</option>
                    <option [value]="5">5s undo window</option>
                    <option [value]="10">10s undo window</option>
                    <option [value]="20">20s undo window</option>
                  </select>
                </label>

                <label class="inline-flex items-center gap-1.5">
                  <span>Schedule:</span>
                  <input
                    type="datetime-local"
                    formControlName="scheduledFor"
                    class="rounded border border-slate-200 bg-white px-2 py-1 text-xs tabular-nums dark:border-slate-700 dark:bg-slate-800"
                  />
                </label>

                <label class="inline-flex items-center gap-1.5 text-[11px] text-amber-700 dark:text-amber-300">
                  <input
                    type="checkbox"
                    [checked]="simulateUncertain()"
                    (change)="simulateUncertain.set($any($event.target).checked)"
                    class="rounded border-slate-300"
                  />
                  <span>Simulate uncertain timeout</span>
                </label>
              </div>

              <div class="flex items-center gap-2">
                <button
                  type="button"
                  (click)="saveDraftNow()"
                  class="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                >
                  <mat-icon class="!text-[15px]">save</mat-icon>
                  <span>Save Draft</span>
                </button>
                <button
                  type="button"
                  [disabled]="sending()"
                  (click)="sendMessage()"
                  class="inline-flex items-center gap-1.5 rounded-lg bg-[#0078D4] px-4 py-1.5 text-xs font-semibold text-white hover:bg-[#0263B0] disabled:opacity-50"
                >
                  <mat-icon class="!text-[16px]">send</mat-icon>
                  <span>
                    @if (store.isOfflineMode()) {
                      Queue Offline
                    } @else if (form.controls.scheduledFor.value) {
                      Schedule Send
                    } @else if (Number(form.controls.sendDelaySeconds.value) > 0) {
                      Send ({{ form.controls.sendDelaySeconds.value }}s Delay)
                    } @else {
                      Send Now
                    }
                  </span>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    }
  `,
})
export class ComposerModal {
  protected Math = Math;
  protected Number = Number;
  store = inject(WorkspaceStore);
  private fb = inject(FormBuilder);

  readonly showCcBcc = signal(false);
  readonly isRichText = signal(true);
  readonly toList = signal<EmailParticipant[]>([]);
  readonly ccList = signal<EmailParticipant[]>([]);
  readonly bccList = signal<EmailParticipant[]>([]);
  readonly toInput = signal('');
  readonly ccInput = signal('');
  readonly bccInput = signal('');
  readonly autocompleteTarget = signal<'to' | 'cc' | 'bcc' | null>(null);
  readonly attachments = signal<
    {
      id: string;
      filename: string;
      mimeType: string;
      sizeBytes: number;
      contentPreview: string;
    }[]
  >([]);
  readonly autosaveStatus = signal('');
  readonly sending = signal(false);
  readonly aiBusy = signal(false);
  readonly simulateUncertain = signal(false);
  private currentDraftId = signal<string | undefined>(undefined);
  private currentIdempotencyKey = signal<string | undefined>(undefined);

  form = this.fb.group({
    accountId: ['acc_work'],
    subject: [''],
    bodyText: [''],
    sendDelaySeconds: [10],
    scheduledFor: [''],
  });

  readonly selectedAccount = computed(() =>
    this.store.accounts().find((a) => a.id === this.form.controls.accountId.value),
  );

  readonly suggestions = computed(() => {
    const q = this.toInput().trim().toLowerCase();
    if (!q) return [];
    return this.store
      .contacts()
      .filter((c) => {
        const hay = `${c.displayName} ${c.emails.map((e) => e.address).join(' ')}`.toLowerCase();
        return hay.includes(q);
      })
      .slice(0, 5);
  });

  constructor() {
    effect(() => {
      const draft = this.store.activeDraft();
      if (draft && this.store.composerOpen()) {
        this.currentDraftId.set(draft.id);
        this.currentIdempotencyKey.set(draft.idempotencyKey);
        this.form.patchValue(
          {
            accountId: draft.accountId ?? 'acc_work',
            subject: draft.subject ?? '',
            bodyText: draft.bodyText ?? '',
            sendDelaySeconds:
              draft.sendDelaySeconds ??
              this.store.preferences().defaultSendDelaySeconds,
            scheduledFor: draft.scheduledFor ?? '',
          },
          {emitEvent: false},
        );
        this.toList.set(draft.to ?? []);
        this.ccList.set(draft.cc ?? []);
        this.bccList.set(draft.bcc ?? []);
        this.showCcBcc.set(
          (draft.cc?.length ?? 0) > 0 || (draft.bcc?.length ?? 0) > 0,
        );
        this.attachments.set(draft.attachments ?? []);
        this.isRichText.set(draft.isRichText ?? true);
        this.autosaveStatus.set('');
      }
    });
  }

  onAccountChange(): void {
    const acc = this.selectedAccount();
    if (!acc) return;
    const current = this.form.controls.bodyText.value ?? '';
    if (!current.trim()) {
      this.form.patchValue({bodyText: `\n\n${acc.signatureText}`});
    }
  }

  onRecipientInput(field: 'to' | 'cc' | 'bcc', value: string): void {
    if (field === 'to') this.toInput.set(value);
    this.autocompleteTarget.set(value.trim() ? field : null);
  }

  pickSuggestion(field: 'to' | 'cc' | 'bcc', contact: ContactRecord): void {
    const email = contact.emails[0]?.address;
    if (!email) return;
    const item = {name: contact.displayName, email};
    if (field === 'to') {
      this.toList.update((l) =>
        l.some((x) => x.email === email) ? l : [...l, item],
      );
      this.toInput.set('');
    }
    this.autocompleteTarget.set(null);
  }

  commitRawRecipient(field: 'to' | 'cc' | 'bcc'): void {
    const raw = (
      field === 'to'
        ? this.toInput()
        : field === 'cc'
          ? this.ccInput()
          : this.bccInput()
    ).trim();
    if (!raw || !raw.includes('@')) return;
    const entry = {name: raw.split('@')[0] ?? raw, email: raw};
    if (field === 'to') {
      this.toList.update((l) => [...l, entry]);
      this.toInput.set('');
    } else if (field === 'cc') {
      this.ccList.update((l) => [...l, entry]);
      this.ccInput.set('');
    } else {
      this.bccList.update((l) => [...l, entry]);
      this.bccInput.set('');
    }
    this.autocompleteTarget.set(null);
  }

  removeRecipient(field: 'to' | 'cc' | 'bcc', email: string): void {
    if (field === 'to') {
      this.toList.update((l) => l.filter((x) => x.email !== email));
    } else if (field === 'cc') {
      this.ccList.update((l) => l.filter((x) => x.email !== email));
    } else {
      this.bccList.update((l) => l.filter((x) => x.email !== email));
    }
  }

  toggleRichMode(): void {
    this.isRichText.update((v) => !v);
  }

  appendSnippet(snippet: string): void {
    const curr = this.form.controls.bodyText.value ?? '';
    this.form.patchValue({bodyText: `${curr}${curr ? '\n' : ''}${snippet}`});
  }

  insertTemplate(templateId: string): void {
    if (!templateId) return;
    const tpl = this.store
      .data()
      ?.templates.find((t) => t.id === templateId);
    if (!tpl) return;
    const plain = tpl.bodyHtml.replace(/<[^>]+>/g, '\n').trim();
    this.form.patchValue({
      subject: this.form.controls.subject.value || tpl.subject,
      bodyText: `${plain}\n\n${this.selectedAccount()?.signatureText ?? ''}`,
    });
  }

  onFilePicked(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    const forbidden = /\.(exe|bat|cmd|scr|js|vbs)$/i;
    if (forbidden.test(file.name)) {
      this.store.pushNotification(
        'Blocked attachment type',
        `Executable file "${file.name}" rejected by attachment security policy.`,
        'error',
      );
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      this.store.pushNotification(
        'Attachment exceeds 10 MB limit',
        file.name,
        'error',
      );
      return;
    }
    this.attachments.update((list) => [
      ...list,
      {
        id: `att_${Date.now().toString(36)}`,
        filename: file.name,
        mimeType: file.type || 'application/octet-stream',
        sizeBytes: file.size,
        contentPreview: `Attached local file: ${file.name} (${file.size} bytes)`,
      },
    ]);
    input.value = '';
  }

  attachInlineDiagram(): void {
    this.attachments.update((list) => [
      ...list,
      {
        id: `att_img_${Date.now().toString(36)}`,
        filename: 'cutover-topology-inline.png',
        mimeType: 'image/png',
        sizeBytes: 24800,
        contentPreview: '[Inline PNG Diagram: Regional Cutover Topology]',
      },
    ]);
    this.appendSnippet('[Inline Image: cutover-topology-inline.png]');
  }

  removeAttachment(id: string): void {
    this.attachments.update((list) => list.filter((a) => a.id !== id));
  }

  async rewriteWithCopilot(tone: 'concise' | 'executive'): Promise<void> {
    this.aiBusy.set(true);
    try {
      const record = await this.store.runCopilotAssist({
        actionType: 'rewrite',
        tone,
        draftText: this.form.controls.bodyText.value ?? '',
      });
      this.form.patchValue({bodyText: record.resultText});
      this.store.pushNotification(
        'Draft rewritten by Copilot',
        'Review updated text before sending.',
        'info',
      );
    } finally {
      this.aiBusy.set(false);
    }
  }

  async translateWithCopilot(targetLanguage: string): Promise<void> {
    this.aiBusy.set(true);
    try {
      const record = await this.store.runCopilotAssist({
        actionType: 'translate',
        targetLanguage,
        draftText: this.form.controls.bodyText.value ?? '',
      });
      this.form.patchValue({bodyText: record.resultText});
    } finally {
      this.aiBusy.set(false);
    }
  }

  private buildPayload() {
    this.commitRawRecipient('to');
    this.commitRawRecipient('cc');
    this.commitRawRecipient('bcc');
    const v = this.form.getRawValue();
    const accountId = v.accountId ?? 'acc_work';
    const acc = this.store.accounts().find((a) => a.id === accountId);
    const bodyText = v.bodyText ?? '';
    return {
      id: this.currentDraftId(),
      idempotencyKey: this.currentIdempotencyKey(),
      accountId,
      sendAsAddress: acc?.email ?? 'alex.mercer@aureom-demo.org',
      replyToMessageId: this.store.activeDraft()?.replyToMessageId ?? null,
      forwardMessageId: this.store.activeDraft()?.forwardMessageId ?? null,
      mode: this.store.activeDraft()?.mode ?? 'new',
      to: this.toList(),
      cc: this.ccList(),
      bcc: this.bccList(),
      subject: v.subject ?? '',
      bodyText,
      bodyHtml: this.isRichText()
        ? `<p>${bodyText.replace(/\n/g, '<br/>')}</p>`
        : `<pre>${bodyText}</pre>`,
      isRichText: this.isRichText(),
      attachments: this.attachments(),
      scheduledFor: v.scheduledFor || null,
      sendDelaySeconds: Number(v.sendDelaySeconds ?? 10),
    };
  }

  async saveDraftNow(): Promise<void> {
    const saved = await this.store.saveOrSendDraft(
      this.buildPayload(),
      'save_draft',
    );
    this.currentDraftId.set(saved.id);
    this.currentIdempotencyKey.set(saved.idempotencyKey);
    this.autosaveStatus.set('Saved locally');
  }

  async sendMessage(): Promise<void> {
    const payload = this.buildPayload();
    if (payload.to.length === 0) {
      this.store.pushNotification(
        'Recipient required',
        'Add at least one recipient in the To field.',
        'warning',
      );
      return;
    }

    this.sending.set(true);
    try {
      const delaySec = payload.sendDelaySeconds;
      const action =
        !this.store.isOfflineMode() && delaySec > 0 && !this.simulateUncertain()
          ? 'schedule_delay'
          : 'send_now';
      const saved = await this.store.saveOrSendDraft(payload, action, {
        simulateUncertain: this.simulateUncertain(),
      });
      this.currentDraftId.set(saved.id);
      this.currentIdempotencyKey.set(saved.idempotencyKey);
      this.store.composerOpen.set(false);
    } finally {
      this.sending.set(false);
    }
  }

  discardDraft(): void {
    this.store.composerOpen.set(false);
    this.store.activeDraft.set(null);
  }

  closeComposer(): void {
    void this.saveDraftNow();
    this.store.composerOpen.set(false);
  }
}
