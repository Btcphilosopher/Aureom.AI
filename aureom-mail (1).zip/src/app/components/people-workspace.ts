import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {FormBuilder, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {ContactRecord} from '../../shared/types';
import {WorkspaceStore} from '../core/workspace.store';

@Component({
  selector: 'app-people-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="flex h-full min-h-0 flex-1 overflow-hidden">
      <!-- Contact List Pane -->
      <aside class="flex w-full shrink-0 flex-col border-r border-slate-200 bg-white md:w-80 dark:border-slate-800 dark:bg-slate-900">
        <div class="space-y-2 border-b border-slate-200 p-3 dark:border-slate-800">
          <div class="flex items-center justify-between">
            <h2 class="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
              People &amp; Organizations
            </h2>
            <button
              type="button"
              (click)="creatingContact.set(true)"
              class="inline-flex items-center gap-1 rounded-md bg-[#0078D4] px-2.5 py-1 text-xs font-medium text-white"
            >
              <mat-icon class="!text-[15px]">person_add</mat-icon>
              <span>Add</span>
            </button>
          </div>

          <input
            type="search"
            [value]="query()"
            (input)="query.set($any($event.target).value)"
            placeholder="Filter contacts or organizations..."
            class="w-full rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs focus:border-[#0078D4] focus:outline-none dark:border-slate-700 dark:bg-slate-800"
          />

          <div class="flex items-center gap-1">
            <button
              type="button"
              (click)="trustFilter.set('saved_contact')"
              [class]="
                trustFilter() === 'saved_contact'
                  ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                  : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
              "
              class="rounded px-2.5 py-1 text-[11px] font-medium"
            >
              Saved Contacts
            </button>
            <button
              type="button"
              (click)="trustFilter.set('autocomplete_suggestion')"
              [class]="
                trustFilter() === 'autocomplete_suggestion'
                  ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                  : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
              "
              class="rounded px-2.5 py-1 text-[11px] font-medium"
            >
              Suggestions
            </button>
          </div>
        </div>

        <div class="flex-1 divide-y divide-slate-100 overflow-y-auto dark:divide-slate-800">
          @for (c of filteredContacts(); track c.id) {
            <button
              type="button"
              (click)="selectedId.set(c.id)"
              [class]="
                activeContact()?.id === c.id
                  ? 'bg-[#0078D4]/8 dark:bg-sky-500/15'
                  : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
              "
              class="flex w-full items-center justify-between gap-2 px-3 py-2.5 text-left"
            >
              <div class="min-w-0">
                <div class="flex items-center gap-1.5 text-xs font-semibold text-slate-900 dark:text-slate-100">
                  <span class="truncate">{{ c.displayName }}</span>
                  @if (c.isFavourite) {
                    <mat-icon class="!text-[14px] text-amber-500">star</mat-icon>
                  }
                </div>
                <div class="truncate text-[11px] text-slate-500 dark:text-slate-400">
                  {{ c.jobTitle ? c.jobTitle + ' · ' : '' }}{{ c.organization }}
                </div>
                <div class="truncate font-mono text-[11px] text-slate-400">
                  {{ c.emails[0]?.address }}
                </div>
              </div>
            </button>
          }
        </div>
      </aside>

      <!-- Detail & Duplicate Merge Pane -->
      <section class="flex-1 overflow-y-auto bg-[#F8FAFC] p-6 dark:bg-slate-950">
        @if (potentialDuplicatePair(); as pair) {
          <div class="mb-5 rounded-xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-950 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
            <div class="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div class="font-semibold">Potential Duplicate Contact Detected</div>
                <p class="mt-0.5">
                  "{{ pair.primary.displayName }}" ({{ pair.primary.emails[0]?.address }}) and
                  "{{ pair.duplicate.displayName }}" ({{ pair.duplicate.emails[0]?.address }}) share matching name &amp; organization.
                </p>
              </div>
              <button
                type="button"
                (click)="store.mergeContacts(pair.primary.id, pair.duplicate.id)"
                class="rounded-lg bg-amber-700 px-3 py-1.5 font-semibold text-white hover:bg-amber-800"
              >
                Review &amp; Merge Preserving Records
              </button>
            </div>
          </div>
        }

        @if (activeContact(); as c) {
          <div class="max-w-3xl space-y-5 rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
            <div class="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
              <div>
                <h1 class="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
                  {{ c.displayName }}
                </h1>
                <p class="text-xs text-slate-500 dark:text-slate-400">
                  {{ c.jobTitle }} · {{ c.organization }} ·
                  {{ c.trustLevel === 'saved_contact' ? 'Saved Contact' : 'Unverified Autocomplete Suggestion' }}
                </p>
              </div>

              <div class="flex flex-wrap items-center gap-2">
                @if (c.trustLevel === 'autocomplete_suggestion') {
                  <button
                    type="button"
                    (click)="store.updateContact(c.id, {trustLevel: 'saved_contact'})"
                    class="rounded-lg bg-[#0078D4] px-3 py-1.5 text-xs font-medium text-white"
                  >
                    Promote to Saved Contact
                  </button>
                }
                <button
                  type="button"
                  (click)="store.updateContact(c.id, {isFavourite: !c.isFavourite})"
                  class="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 dark:border-slate-700 dark:text-slate-200"
                >
                  <mat-icon class="!text-[15px]">{{ c.isFavourite ? 'star' : 'star_border' }}</mat-icon>
                  <span>{{ c.isFavourite ? 'Favourited' : 'Favourite' }}</span>
                </button>
                <button
                  type="button"
                  (click)="composeToContact(c)"
                  class="inline-flex items-center gap-1 rounded-lg bg-[#0078D4] px-3 py-1.5 text-xs font-medium text-white"
                >
                  <mat-icon class="!text-[15px]">mail</mat-icon>
                  <span>Email</span>
                </button>
              </div>
            </div>

            <div class="grid gap-5 sm:grid-cols-2">
              <div>
                <div class="text-xs font-semibold text-slate-500 dark:text-slate-400">Email Addresses</div>
                <div class="mt-2 space-y-1.5 text-xs">
                  @for (em of c.emails; track em.address) {
                    <div class="flex items-center justify-between">
                      <span class="font-mono text-slate-800 dark:text-slate-200">{{ em.address }}</span>
                      <span class="text-slate-400">{{ em.label }}</span>
                    </div>
                  }
                </div>
              </div>
              <div>
                <div class="text-xs font-semibold text-slate-500 dark:text-slate-400">Phone Numbers</div>
                <div class="mt-2 space-y-1.5 text-xs">
                  @if (c.phones.length === 0) {
                    <span class="text-slate-400">No phone numbers recorded.</span>
                  }
                  @for (ph of c.phones; track ph.number) {
                    <div class="flex items-center justify-between">
                      <span class="tabular-nums text-slate-800 dark:text-slate-200">{{ ph.number }}</span>
                      <span class="text-slate-400">{{ ph.label }}</span>
                    </div>
                  }
                </div>
              </div>
            </div>

            <div>
              <div class="text-xs font-semibold text-slate-500 dark:text-slate-400">Notes &amp; Categories</div>
              <p class="mt-1 text-xs text-slate-700 dark:text-slate-300">{{ c.notes || 'None' }}</p>
              <p class="mt-1 text-[11px] text-slate-400">Categories: {{ c.categories.join(', ') || 'None' }}</p>
            </div>

            <div class="border-t border-slate-200 pt-4 dark:border-slate-800">
              <div class="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Authorized Interaction History
              </div>
              <div class="mt-2 space-y-2">
                @for (msg of interactionMessages(c); track msg.id) {
                  <div class="flex items-center justify-between rounded border border-slate-100 bg-slate-50 px-3 py-2 text-xs dark:border-slate-800 dark:bg-slate-950/60">
                    <span class="truncate font-medium text-slate-800 dark:text-slate-200">{{ msg.subject }}</span>
                    <span class="tabular-nums text-[11px] text-slate-400">{{ msg.receivedAt.slice(0, 10) }}</span>
                  </div>
                }
              </div>
            </div>
          </div>
        }
      </section>
    </div>

    @if (creatingContact()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4" role="dialog" aria-modal="true">
        <form
          [formGroup]="newForm"
          (ngSubmit)="submitNewContact()"
          class="w-full max-w-md space-y-3 rounded-xl border border-slate-200 bg-white p-5 shadow-xl dark:border-slate-700 dark:bg-slate-900"
        >
          <h3 class="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">New Contact</h3>
          <input type="text" formControlName="displayName" placeholder="Full name" class="w-full rounded border border-slate-200 px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800" />
          <input type="email" formControlName="email" placeholder="Email address" class="w-full rounded border border-slate-200 px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800" />
          <input type="text" formControlName="organization" placeholder="Organization" class="w-full rounded border border-slate-200 px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800" />
          <input type="text" formControlName="jobTitle" placeholder="Job title" class="w-full rounded border border-slate-200 px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800" />
          <div class="flex justify-end gap-2 pt-2">
            <button type="button" (click)="creatingContact.set(false)" class="rounded px-3 py-1.5 text-xs text-slate-500">Cancel</button>
            <button type="submit" class="rounded bg-[#0078D4] px-3 py-1.5 text-xs font-medium text-white">Save Contact</button>
          </div>
        </form>
      </div>
    }
  `,
})
export class PeopleWorkspace {
  store = inject(WorkspaceStore);
  private fb = inject(FormBuilder);

  readonly query = signal('');
  readonly trustFilter = signal<'saved_contact' | 'autocomplete_suggestion'>(
    'saved_contact',
  );
  readonly selectedId = signal<string | null>(null);
  readonly creatingContact = signal(false);

  newForm = this.fb.group({
    displayName: [''],
    email: [''],
    organization: [''],
    jobTitle: [''],
  });

  readonly filteredContacts = computed(() => {
    const q = this.query().trim().toLowerCase();
    const trust = this.trustFilter();
    return this.store.contacts().filter((c) => {
      if (c.trustLevel !== trust) return false;
      if (!q) return true;
      return `${c.displayName} ${c.organization} ${c.emails.map((e) => e.address).join(' ')}`
        .toLowerCase()
        .includes(q);
    });
  });

  readonly activeContact = computed<ContactRecord | null>(() => {
    const list = this.filteredContacts();
    const id = this.selectedId();
    return list.find((c) => c.id === id) ?? list[0] ?? null;
  });

  readonly potentialDuplicatePair = computed(() => {
    const all = this.store.contacts();
    const primary = all.find((c) => c.id === 'con_marcus_1');
    const duplicate = all.find((c) => c.id === 'con_marcus_dup');
    if (primary && duplicate) return {primary, duplicate};
    return null;
  });

  interactionMessages(c: ContactRecord) {
    const addrs = new Set(c.emails.map((e) => e.address.toLowerCase()));
    return this.store
      .messages()
      .filter(
        (m) =>
          addrs.has(m.from.email.toLowerCase()) ||
          m.to.some((t) => addrs.has(t.email.toLowerCase())),
      );
  }

  composeToContact(c: ContactRecord): void {
    const email = c.emails[0]?.address;
    this.store.openNewComposer({
      to: email ? [{name: c.displayName, email}] : [],
    });
  }

  async submitNewContact(): Promise<void> {
    const v = this.newForm.getRawValue();
    if (!v.displayName?.trim() || !v.email?.trim()) return;
    await this.store.createContact({
      displayName: v.displayName.trim(),
      emails: [{address: v.email.trim(), label: 'Work', isPrimary: true}],
      organization: v.organization ?? '',
      jobTitle: v.jobTitle ?? '',
      trustLevel: 'saved_contact',
    });
    this.newForm.reset();
    this.creatingContact.set(false);
  }
}
