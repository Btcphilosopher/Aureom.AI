import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {FormBuilder, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import type {TaskItem} from '../../shared/types';
import {WorkspaceStore} from '../core/workspace.store';

@Component({
  selector: 'app-tasks-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="flex h-full min-h-0 flex-1 overflow-hidden">
      <!-- Lists Navigation -->
      <aside class="hidden w-56 shrink-0 flex-col border-r border-slate-200 bg-[#F8FAFC] p-3 md:flex dark:border-slate-800 dark:bg-slate-950">
        <div class="space-y-1">
          @for (tab of buckets; track tab.id) {
            <button
              type="button"
              (click)="activeBucket.set(tab.id)"
              [class]="
                activeBucket() === tab.id
                  ? 'bg-[#0078D4]/10 text-[#0078D4] font-semibold dark:bg-sky-500/15 dark:text-sky-300'
                  : 'text-slate-700 hover:bg-slate-200/60 dark:text-slate-300 dark:hover:bg-slate-800'
              "
              class="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-xs"
            >
              <mat-icon class="!text-[16px]">{{ tab.icon }}</mat-icon>
              <span>{{ tab.label }}</span>
            </button>
          }
        </div>
      </aside>

      <!-- Main Tasks Content -->
      <section class="flex-1 overflow-y-auto bg-white p-6 dark:bg-slate-900">
        <div class="mx-auto max-w-3xl space-y-5">
          <div class="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h1 class="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
                {{ bucketTitle() }}
              </h1>
              <p class="text-xs text-slate-500 dark:text-slate-400">
                Email-linked tasks preserve the original message in its folder.
              </p>
            </div>
          </div>

          <!-- Quick Add Task -->
          <form
            [formGroup]="taskForm"
            (ngSubmit)="addTask()"
            class="flex flex-wrap items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 p-2.5 dark:border-slate-700 dark:bg-slate-950"
          >
            <input
              type="text"
              formControlName="title"
              placeholder="Add a task to My Day..."
              class="min-w-[200px] flex-1 bg-transparent px-2 py-1 text-xs text-slate-900 focus:outline-none dark:text-slate-100"
            />
            <input
              type="date"
              formControlName="dueDate"
              class="rounded border border-slate-200 bg-white px-2 py-1 text-xs tabular-nums dark:border-slate-700 dark:bg-slate-800"
            />
            <select
              formControlName="priority"
              class="rounded border border-slate-200 bg-white px-2 py-1 text-xs dark:border-slate-700 dark:bg-slate-800"
            >
              <option value="normal">Normal</option>
              <option value="high">High</option>
              <option value="low">Low</option>
            </select>
            <button
              type="submit"
              class="rounded-md bg-[#0078D4] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#0263B0]"
            >
              Add Task
            </button>
          </form>

          <!-- Task Rows -->
          <div class="divide-y divide-slate-200 rounded-xl border border-slate-200 dark:divide-slate-800 dark:border-slate-800">
            @if (filteredTasks().length === 0) {
              <div class="p-6 text-center text-xs text-slate-500">
                No tasks in this view.
              </div>
            }
            @for (task of filteredTasks(); track task.id) {
              <div class="space-y-2 p-4">
                <div class="flex items-start justify-between gap-3">
                  <div class="flex items-start gap-2.5">
                    <input
                      type="checkbox"
                      [checked]="task.status === 'completed'"
                      (change)="toggleComplete(task)"
                      class="mt-0.5 rounded border-slate-300"
                    />
                    <div>
                      <div
                        class="text-sm font-medium"
                        [class.line-through]="task.status === 'completed'"
                        [class.text-slate-400]="task.status === 'completed'"
                        [class.text-slate-900]="task.status !== 'completed'"
                        [class.dark:text-slate-100]="task.status !== 'completed'"
                      >
                        {{ task.title }}
                      </div>
                      <div class="mt-0.5 flex flex-wrap items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                        <span>{{ task.listName }}</span>
                        <span>·</span>
                        <span class="capitalize">{{ task.priority }} priority</span>
                        @if (task.dueDate) {
                          <span>·</span>
                          <span class="tabular-nums">Due {{ task.dueDate }}</span>
                        }
                        @if (task.linkedMessageId) {
                          <span>·</span>
                          <button
                            type="button"
                            (click)="jumpToMessage(task.linkedMessageId!)"
                            class="text-[#0078D4] hover:underline"
                          >
                            Open linked email
                          </button>
                        }
                      </div>
                    </div>
                  </div>

                  <div class="flex items-center gap-1">
                    <button
                      type="button"
                      (click)="store.updateTask(task.id, {isMyDay: !task.isMyDay})"
                      class="rounded px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                    >
                      {{ task.isMyDay ? 'In My Day' : '+ My Day' }}
                    </button>
                    <button
                      type="button"
                      (click)="store.deleteTask(task.id)"
                      class="rounded p-1 text-slate-400 hover:text-rose-600"
                      aria-label="Delete task"
                    >
                      <mat-icon class="!text-[16px]">delete_outline</mat-icon>
                    </button>
                  </div>
                </div>

                @if (task.checklist.length > 0) {
                  <div class="ml-6 space-y-1 border-l border-slate-200 pl-3 dark:border-slate-800">
                    @for (chk of task.checklist; track chk.id) {
                      <label class="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                        <input
                          type="checkbox"
                          [checked]="chk.done"
                          (change)="toggleChecklistItem(task, chk.id)"
                          class="rounded border-slate-300"
                        />
                        <span [class.line-through]="chk.done">{{ chk.text }}</span>
                      </label>
                    }
                  </div>
                }
              </div>
            }
          </div>

          @if (activeBucket() === 'my_day') {
            <div class="space-y-2 pt-2">
              <h2 class="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                Flagged Emails &amp; Upcoming Meetings
              </h2>
              @for (m of flaggedEmails(); track m.id) {
                <div class="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-xs dark:border-slate-800">
                  <button
                    type="button"
                    (click)="jumpToMessage(m.id)"
                    class="truncate font-medium text-slate-800 hover:text-[#0078D4] dark:text-slate-200"
                  >
                    [Flagged] {{ m.subject }}
                  </button>
                  <button
                    type="button"
                    (click)="store.createTaskFromMessage(m)"
                    class="shrink-0 text-[#0078D4] hover:underline"
                  >
                    + Convert to Task
                  </button>
                </div>
              }
            </div>
          }
        </div>
      </section>
    </div>
  `,
})
export class TasksWorkspace {
  store = inject(WorkspaceStore);
  private fb = inject(FormBuilder);

  readonly buckets = [
    {id: 'my_day' as const, label: 'My Day', icon: 'wb_sunny'},
    {id: 'all' as const, label: 'All Open Tasks', icon: 'task_alt'},
    {id: 'completed' as const, label: 'Completion History', icon: 'history'},
  ];

  readonly activeBucket = signal<'my_day' | 'all' | 'completed'>('my_day');

  taskForm = this.fb.group({
    title: [''],
    dueDate: ['2026-11-16'],
    priority: ['normal'],
  });

  readonly bucketTitle = computed(() => {
    const b = this.activeBucket();
    if (b === 'my_day') return 'My Day — Tasks, Flagged Emails & Meetings';
    if (b === 'completed') return 'Completion History';
    return 'All Open Tasks';
  });

  readonly filteredTasks = computed(() => {
    const b = this.activeBucket();
    return this.store.tasks().filter((t) => {
      if (b === 'completed') return t.status === 'completed';
      if (b === 'my_day') return t.isMyDay && t.status !== 'completed';
      return t.status !== 'completed';
    });
  });

  readonly flaggedEmails = computed(() =>
    this.store.messages().filter((m) => m.isFlagged),
  );

  async addTask(): Promise<void> {
    const v = this.taskForm.getRawValue();
    if (!v.title?.trim()) return;
    await this.store.createTask({
      title: v.title.trim(),
      dueDate: v.dueDate || null,
      priority: (v.priority as TaskItem['priority']) ?? 'normal',
      isMyDay: true,
    });
    this.taskForm.patchValue({title: ''});
  }

  toggleComplete(task: TaskItem): void {
    const nextStatus = task.status === 'completed' ? 'todo' : 'completed';
    void this.store.updateTask(task.id, {status: nextStatus});
  }

  toggleChecklistItem(task: TaskItem, itemId: string): void {
    const checklist = task.checklist.map((c) =>
      c.id === itemId ? {...c, done: !c.done} : c,
    );
    void this.store.updateTask(task.id, {checklist});
  }

  jumpToMessage(messageId: string): void {
    this.store.selectedMessageId.set(messageId);
    this.store.activeView.set('mail');
  }
}
