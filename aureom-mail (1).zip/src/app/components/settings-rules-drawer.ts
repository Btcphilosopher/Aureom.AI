import {
  ChangeDetectionStrategy,
  Component,
  inject,
} from '@angular/core';
import {FormBuilder, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {WorkspaceStore} from '../core/workspace.store';

@Component({
  selector: 'app-settings-rules-drawer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.settingsOpen()) {
      <div
        class="fixed inset-0 z-50 flex justify-end bg-slate-950/40"
        role="dialog"
        aria-modal="true"
        aria-label="Workspace Settings, Sync, Rules and Demo Guide"
      >
        <div
          class="flex h-full w-full max-w-2xl flex-col border-l border-slate-200 bg-white shadow-xl dark:border-slate-700 dark:bg-slate-900"
        >
          <!-- Header -->
          <div class="flex items-center justify-between border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
            <h2 class="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Workspace Control Center
            </h2>
            <button
              type="button"
              (click)="store.settingsOpen.set(false)"
              class="rounded p-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Close settings"
            >
              <mat-icon class="!text-[20px]">close</mat-icon>
            </button>
          </div>

          <!-- Tabs -->
          <div class="flex flex-wrap gap-1 border-b border-slate-200 bg-slate-50 px-4 py-2 dark:border-slate-800 dark:bg-slate-950">
            @for (tab of tabs; track tab.id) {
              <button
                type="button"
                (click)="store.settingsTab.set(tab.id)"
                [class]="
                  store.settingsTab() === tab.id
                    ? 'bg-white text-[#0078D4] shadow-sm dark:bg-slate-800 dark:text-sky-300'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                "
                class="rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors"
              >
                {{ tab.label }}
              </button>
            }
          </div>

          <!-- Body -->
          <div class="flex-1 space-y-5 overflow-y-auto p-5 text-xs">
            @if (store.settingsTab() === 'general') {
              <div class="space-y-4">
                <div>
                  <div class="font-semibold text-slate-800 dark:text-slate-200">Appearance Theme</div>
                  <div class="mt-2 flex gap-2">
                    @for (t of ['light', 'dark', 'system']; track t) {
                      <button
                        type="button"
                        (click)="store.updatePreferences({theme: $any(t)})"
                        [class]="
                          store.preferences().theme === t
                            ? 'bg-[#0078D4] text-white'
                            : 'border border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-300'
                        "
                        class="rounded-md px-3 py-1.5 font-medium capitalize"
                      >
                        {{ t }}
                      </button>
                    }
                  </div>
                </div>

                <div>
                  <div class="font-semibold text-slate-800 dark:text-slate-200">Workspace Density</div>
                  <div class="mt-2 flex gap-2">
                    @for (d of ['comfortable', 'compact']; track d) {
                      <button
                        type="button"
                        (click)="store.updatePreferences({density: $any(d)})"
                        [class]="
                          store.preferences().density === d
                            ? 'bg-[#0078D4] text-white'
                            : 'border border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-300'
                        "
                        class="rounded-md px-3 py-1.5 font-medium capitalize"
                      >
                        {{ d }}
                      </button>
                    }
                  </div>
                </div>

                <div>
                  <div class="font-semibold text-slate-800 dark:text-slate-200">Reading Pane Position</div>
                  <div class="mt-2 flex gap-2">
                    @for (p of ['right', 'bottom', 'hidden']; track p) {
                      <button
                        type="button"
                        (click)="store.updatePreferences({readingPanePosition: $any(p)})"
                        [class]="
                          store.preferences().readingPanePosition === p
                            ? 'bg-[#0078D4] text-white'
                            : 'border border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-300'
                        "
                        class="rounded-md px-3 py-1.5 font-medium capitalize"
                      >
                        {{ p }}
                      </button>
                    }
                  </div>
                </div>

                <label class="flex items-center gap-2 pt-1 text-slate-700 dark:text-slate-200">
                  <input
                    type="checkbox"
                    [checked]="store.preferences().showRightSidebar"
                    (change)="
                      store.updatePreferences({
                        showRightSidebar: $any($event.target).checked
                      })
                    "
                  />
                  <span>Show collapsible My Day calendar &amp; task sidebar</span>
                </label>

                <label class="flex items-center gap-2 text-slate-700 dark:text-slate-200">
                  <input
                    type="checkbox"
                    [checked]="store.preferences().blockRemoteImages"
                    (change)="
                      store.updatePreferences({
                        blockRemoteImages: $any($event.target).checked
                      })
                    "
                  />
                  <span>Block remote tracking images by default (Recommended)</span>
                </label>
              </div>
            }

            @if (store.settingsTab() === 'accounts') {
              <div class="space-y-4">
                <div class="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950">
                  <div>
                    <div class="font-semibold text-slate-900 dark:text-slate-100">
                      Offline Mode &amp; Durable Queue Simulation
                    </div>
                    <p class="mt-0.5 text-slate-500">
                      Queued operations: {{ store.offlineQueue().length }} · Never labels queued items as sent.
                    </p>
                  </div>
                  <button
                    type="button"
                    (click)="store.toggleOfflineMode(!store.isOfflineMode())"
                    [class]="
                      store.isOfflineMode()
                        ? 'bg-emerald-600 text-white'
                        : 'bg-amber-600 text-white'
                    "
                    class="rounded-md px-3 py-1.5 font-medium"
                  >
                    {{ store.isOfflineMode() ? 'Reconnect & Reconcile' : 'Simulate Offline' }}
                  </button>
                </div>

                @for (acc of store.accounts(); track acc.id) {
                  <div class="space-y-2 rounded-xl border border-slate-200 p-4 dark:border-slate-800">
                    <div class="flex items-start justify-between gap-2">
                      <div>
                        <div class="font-semibold text-slate-900 dark:text-slate-100">
                          {{ acc.displayName }} ({{ acc.email }})
                        </div>
                        <div class="text-[11px] text-slate-500">
                          Provider: {{ acc.provider }} (Explicit Simulated Adapter) · Last synced:
                          {{ acc.lastSyncedAt || 'Never' }}
                        </div>
                      </div>
                      <span
                        [class]="
                          acc.syncStatus === 'error'
                            ? 'text-rose-600 font-semibold'
                            : acc.syncStatus === 'offline'
                              ? 'text-amber-600 font-semibold'
                              : 'text-emerald-700 font-semibold'
                        "
                        class="uppercase text-[11px]"
                      >
                        {{ acc.syncStatus }}
                      </span>
                    </div>

                    @if (acc.uidValidity) {
                      <div class="font-mono text-[11px] text-slate-500">
                        IMAP UIDVALIDITY: {{ acc.uidValidity }} · HIGHESTMODSEQ: {{ acc.highestModSeq }}
                      </div>
                    } @else if (acc.deltaToken) {
                      <div class="font-mono text-[11px] text-slate-500">
                        Graph DeltaToken: {{ acc.deltaToken }}
                      </div>
                    } @else if (acc.historyId) {
                      <div class="font-mono text-[11px] text-slate-500">
                        Gmail HistoryId: {{ acc.historyId }}
                      </div>
                    }

                    @if (acc.lastSyncError) {
                      <div class="rounded bg-rose-50 p-2 text-rose-900 dark:bg-rose-950/40 dark:text-rose-200">
                        {{ acc.lastSyncError }}
                      </div>
                    }

                    <div class="flex flex-wrap gap-2 pt-1">
                      <button
                        type="button"
                        (click)="store.syncAccount(acc.id, {forceResetUidValidity: true})"
                        class="rounded bg-[#0078D4] px-3 py-1 font-medium text-white"
                      >
                        Sync / Recover Now
                      </button>
                      <button
                        type="button"
                        (click)="store.syncAccount(acc.id, {simulateFailure: true})"
                        class="rounded border border-slate-200 px-3 py-1 font-medium text-slate-700 dark:border-slate-700 dark:text-slate-300"
                      >
                        Simulate Sync Failure
                      </button>
                      <button
                        type="button"
                        (click)="store.purgeAccountCache(acc.id)"
                        class="rounded border border-rose-200 px-3 py-1 font-medium text-rose-700 dark:border-rose-900 dark:text-rose-300"
                      >
                        Purge Local Cache
                      </button>
                    </div>
                  </div>
                }
              </div>
            }

            @if (store.settingsTab() === 'rules') {
              <div class="space-y-4">
                <div class="rounded-lg border border-slate-200 bg-slate-50 p-3 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300">
                  <strong>Provider vs Application Rules:</strong> Provider-side rules execute on the mail server even when Aureom Mail is offline. Application-side rules run locally inside Aureom whenever messages sync, include loop-prevention counters, and require explicit user confirmation before external forwarding.
                </div>

                <form
                  [formGroup]="ruleForm"
                  (ngSubmit)="createRule()"
                  class="space-y-2 rounded-xl border border-slate-200 p-3 dark:border-slate-800"
                >
                  <div class="font-semibold text-slate-900 dark:text-slate-100">Create New Rule</div>
                  <div class="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    <input type="text" formControlName="name" placeholder="Rule name" class="rounded border border-slate-200 px-2.5 py-1.5 dark:border-slate-700 dark:bg-slate-800" />
                    <select formControlName="scope" class="rounded border border-slate-200 px-2.5 py-1.5 dark:border-slate-700 dark:bg-slate-800">
                      <option value="application">Application-side rule</option>
                      <option value="provider">Provider-side rule</option>
                    </select>
                    <input type="text" formControlName="subjectContains" placeholder="If subject contains..." class="rounded border border-slate-200 px-2.5 py-1.5 dark:border-slate-700 dark:bg-slate-800" />
                    <input type="text" formControlName="applyCategory" placeholder="Apply category (e.g. Priority)" class="rounded border border-slate-200 px-2.5 py-1.5 dark:border-slate-700 dark:bg-slate-800" />
                  </div>
                  <div class="flex items-center justify-between pt-1">
                    <label class="inline-flex items-center gap-1.5">
                      <input type="checkbox" formControlName="stopProcessing" />
                      <span>Stop processing further rules</span>
                    </label>
                    <div class="flex gap-2">
                      <button type="button" (click)="store.runRulesNow()" class="rounded border border-slate-200 px-3 py-1 font-medium dark:border-slate-700">
                        Run Rules Now
                      </button>
                      <button type="submit" class="rounded bg-[#0078D4] px-3 py-1 font-medium text-white">
                        Add Rule
                      </button>
                    </div>
                  </div>
                </form>

                @for (r of store.rules(); track r.id) {
                  <div class="flex items-center justify-between rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                    <div>
                      <div class="font-semibold text-slate-900 dark:text-slate-100">
                        {{ r.priority }}. {{ r.name }} ({{ r.scope }})
                      </div>
                      <div class="text-[11px] text-slate-500">
                        Loop guard count: {{ r.loopGuardCount }} · Stop processing: {{ r.stopProcessing ? 'Yes' : 'No' }}
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      [checked]="r.enabled"
                      (change)="store.toggleRule(r.id, $any($event.target).checked)"
                    />
                  </div>
                }
              </div>
            }

            @if (store.settingsTab() === 'security') {
              <div class="space-y-3 text-slate-700 dark:text-slate-300">
                <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                  <div class="font-semibold text-slate-900 dark:text-slate-100">Untrusted Content &amp; HTML Sanitization</div>
                  <p class="mt-1">
                    All incoming HTML bodies pass through an allowlist sanitizer stripping scripts, iframes, event handlers, and unsafe URLs. Remote images are blocked by default until allowed per message.
                  </p>
                </div>
                <div class="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                  <div class="font-semibold text-slate-900 dark:text-slate-100">Retention &amp; Cache Deletion Notice</div>
                  <p class="mt-1">
                    Deleting or purging local cache removes cached previews and local index copies from this browser/workspace only. It does not delete provider-held copies or messages already delivered to recipients.
                  </p>
                </div>
                <button
                  type="button"
                  (click)="store.resetDemoData()"
                  class="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 font-medium text-rose-800 hover:bg-rose-100 dark:border-rose-900 dark:bg-rose-950/30 dark:text-rose-200"
                >
                  Reset Demonstration Dataset to Factory Seed
                </button>
              </div>
            }

            @if (store.settingsTab() === 'demo') {
              <div class="space-y-2.5">
                <p class="text-slate-600 dark:text-slate-300">
                  Step directly to any demonstration capability:
                </p>
                <div class="grid gap-2">
                  <button type="button" (click)="jumpMail('msg_101')" class="rounded-lg border border-slate-200 p-2.5 text-left hover:border-[#0078D4] dark:border-slate-800">
                    1. Open Q4 Structural Gateway conversation &amp; inspect attachments
                  </button>
                  <button type="button" (click)="jumpSearch('regional_latency_budget')" class="rounded-lg border border-slate-200 p-2.5 text-left hover:border-[#0078D4] dark:border-slate-800">
                    2. Search for related attachment across authorized accounts
                  </button>
                  <button type="button" (click)="jumpCopilot()" class="rounded-lg border border-slate-200 p-2.5 text-left hover:border-[#0078D4] dark:border-slate-800">
                    3–4. Generate cited thread summary &amp; approve AI-drafted reply
                  </button>
                  <button type="button" (click)="jumpMail('msg_105')" class="rounded-lg border border-slate-200 p-2.5 text-left hover:border-[#0078D4] dark:border-slate-800">
                    5. Inspect Reply-To mismatch phishing &amp; prompt-injection test email
                  </button>
                  <button type="button" (click)="store.activeView.set('calendar'); store.settingsOpen.set(false)" class="rounded-lg border border-slate-200 p-2.5 text-left hover:border-[#0078D4] dark:border-slate-800">
                    6. Propose meeting across PST / GMT / JST timezones &amp; edit recurring exceptions
                  </button>
                  <button type="button" (click)="store.settingsTab.set('accounts')" class="rounded-lg border border-slate-200 p-2.5 text-left hover:border-[#0078D4] dark:border-slate-800">
                    7. Recover simulated IMAP UIDVALIDITY sync error &amp; test Offline Queue
                  </button>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    }
  `,
})
export class SettingsRulesDrawer {
  store = inject(WorkspaceStore);
  private fb = inject(FormBuilder);

  readonly tabs = [
    {id: 'general' as const, label: 'Appearance & Layout'},
    {id: 'accounts' as const, label: 'Accounts, Sync & Offline'},
    {id: 'rules' as const, label: 'Rules & Automation'},
    {id: 'security' as const, label: 'Security & Retention'},
    {id: 'demo' as const, label: 'Demo Tour'},
  ];

  ruleForm = this.fb.group({
    name: ['Highlight Cutover Updates'],
    scope: ['application'],
    subjectContains: ['Cutover'],
    applyCategory: ['Priority'],
    stopProcessing: [false],
  });

  async createRule(): Promise<void> {
    const v = this.ruleForm.getRawValue();
    await this.store.createRule({
      name: v.name ?? 'Custom Rule',
      scope: (v.scope as 'application' | 'provider') ?? 'application',
      accountId: 'acc_work',
      stopProcessing: Boolean(v.stopProcessing),
      conditions: [
        {
          field: 'subject',
          operator: 'contains',
          value: v.subjectContains ?? '',
        },
      ],
      actions: [
        {type: 'apply_category', value: v.applyCategory ?? 'Priority'},
      ],
    });
  }

  jumpMail(msgId: string): void {
    this.store.smartBucket.set(null);
    this.store.selectedMessageId.set(msgId);
    this.store.activeView.set('mail');
    this.store.settingsOpen.set(false);
  }

  jumpSearch(q: string): void {
    this.store.searchQuery.set(q);
    this.store.activeView.set('mail');
    this.store.settingsOpen.set(false);
  }

  jumpCopilot(): void {
    this.store.activeView.set('copilot');
    this.store.settingsOpen.set(false);
  }
}
