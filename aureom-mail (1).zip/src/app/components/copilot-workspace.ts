import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {WorkspaceStore} from '../core/workspace.store';

@Component({
  selector: 'app-copilot-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="flex h-full min-h-0 flex-1 flex-col overflow-hidden bg-white dark:bg-slate-900">
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
        <div>
          <h1 class="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Aureom Copilot — Controlled AI Workspace
          </h1>
          <p class="text-xs text-slate-500 dark:text-slate-400">
            Read-only by default · Cited source links · Strict untrusted-email isolation · Approval required for actions
          </p>
        </div>

        <div class="tabular-nums text-xs text-slate-500 dark:text-slate-400">
          Budget: {{ store.data()?.aiTokensUsed ?? 0 }} / {{ store.data()?.aiTokenBudgetLimit ?? 50000 }} est. tokens
        </div>
      </div>

      <div class="flex-1 overflow-y-auto p-5">
        <div class="mx-auto max-w-4xl space-y-5">
          <!-- Action Controls -->
          <div class="rounded-xl border border-slate-200 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-950/60">
            <div class="text-xs font-semibold text-slate-700 dark:text-slate-200">
              Active Thread Context:
              <span class="font-normal text-slate-500">
                {{ store.selectedMessage()?.subject || 'All authorized inbox messages' }}
              </span>
            </div>

            <div class="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                [disabled]="busy()"
                (click)="run('summarize')"
                class="inline-flex items-center gap-1.5 rounded-lg bg-[#0078D4] px-3 py-1.5 text-xs font-medium text-white hover:bg-[#0263B0] disabled:opacity-50"
              >
                <mat-icon class="!text-[15px]">summarize</mat-icon>
                <span>Cited Summary</span>
              </button>
              <button
                type="button"
                [disabled]="busy()"
                (click)="run('draft_reply')"
                class="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <mat-icon class="!text-[15px]">reply</mat-icon>
                <span>Draft Reply (Approval Required)</span>
              </button>
              <button
                type="button"
                [disabled]="busy()"
                (click)="run('extract_actions')"
                class="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <mat-icon class="!text-[15px]">add_task</mat-icon>
                <span>Extract Proposed Task</span>
              </button>
              <button
                type="button"
                [disabled]="busy()"
                (click)="run('meeting_brief')"
                class="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <mat-icon class="!text-[15px]">event_note</mat-icon>
                <span>Cited Meeting Brief</span>
              </button>
              <button
                type="button"
                [disabled]="busy()"
                (click)="run('suggest_filing')"
                class="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <mat-icon class="!text-[15px]">folder_open</mat-icon>
                <span>Suggest Filing</span>
              </button>
              <button
                type="button"
                [disabled]="busy()"
                (click)="testInjectionDefense()"
                class="inline-flex items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-3 py-1.5 text-xs font-medium text-rose-800 hover:bg-rose-100 disabled:opacity-50 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-200"
              >
                <mat-icon class="!text-[15px]">security</mat-icon>
                <span>Test Prompt-Injection Defense</span>
              </button>
            </div>

            <div class="mt-3 flex gap-2">
              <input
                type="text"
                [value]="queryText()"
                (input)="queryText.set($any($event.target).value)"
                (keydown.enter)="findAuthorized()"
                placeholder="Ask Copilot to search authorized mailboxes (e.g., latency, TLS, Kyoto)..."
                class="flex-1 rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs focus:border-[#0078D4] focus:outline-none dark:border-slate-700 dark:bg-slate-800"
              />
              <button
                type="button"
                [disabled]="busy()"
                (click)="findAuthorized()"
                class="rounded-md bg-slate-900 px-3 py-1.5 text-xs font-medium text-white dark:bg-slate-100 dark:text-slate-900"
              >
                Find Messages
              </button>
            </div>
          </div>

          <!-- Action History & Results -->
          @if (store.aiHistory().length === 0) {
            <div class="rounded-xl border border-dashed border-slate-300 p-8 text-center text-xs text-slate-500 dark:border-slate-700">
              Run a Copilot action above to inspect cited summaries, confirmed facts vs inferred suggestions, and approval workflows.
            </div>
          }

          @for (rec of store.aiHistory(); track rec.id) {
            <article class="space-y-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-950/40">
              <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2 text-xs dark:border-slate-800">
                <div class="font-semibold text-slate-900 dark:text-slate-100">
                  {{ rec.actionType }} · {{ rec.promptSummary }}
                </div>
                <div class="tabular-nums text-[11px] text-slate-500">
                  {{ rec.modelUsed }} · ~{{ rec.tokensEstimate }} tokens
                </div>
              </div>

              @if (rec.promptInjectionDetected) {
                <div class="rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-900 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-200">
                  Prompt-injection guard triggered: untrusted email instructions were isolated and denied authority.
                </div>
              }

              <p class="whitespace-pre-line text-sm leading-relaxed text-slate-800 dark:text-slate-200">
                {{ rec.resultText }}
              </p>

              @if (rec.confirmedFacts.length > 0) {
                <div class="rounded-md bg-slate-50 p-3 text-xs dark:bg-slate-900">
                  <div class="font-semibold text-slate-700 dark:text-slate-200">
                    Confirmed Details (Grounded in Cited Messages)
                  </div>
                  <ul class="mt-1 list-disc space-y-1 pl-4 text-slate-600 dark:text-slate-300">
                    @for (fact of rec.confirmedFacts; track fact) {
                      <li>{{ fact }}</li>
                    }
                  </ul>
                </div>
              }

              @if (rec.inferredSuggestions.length > 0) {
                <div class="rounded-md bg-sky-50/60 p-3 text-xs dark:bg-sky-950/30">
                  <div class="font-semibold text-sky-900 dark:text-sky-200">
                    Inferred Next Steps (Not Confirmed Commitments)
                  </div>
                  <ul class="mt-1 list-disc space-y-1 pl-4 text-sky-800 dark:text-sky-300">
                    @for (inf of rec.inferredSuggestions; track inf) {
                      <li>{{ inf }}</li>
                    }
                  </ul>
                </div>
              }

              <!-- Cited Source Message Links -->
              @if (rec.sourceMessageIds.length > 0) {
                <div class="flex flex-wrap items-center gap-2 text-xs">
                  <span class="text-slate-500">Sources:</span>
                  @for (mid of rec.sourceMessageIds; track mid) {
                    <button
                      type="button"
                      (click)="jumpToSource(mid)"
                      class="font-mono text-[11px] text-[#0078D4] hover:underline dark:text-sky-300"
                    >
                      [{{ mid }}]
                    </button>
                  }
                </div>
              }

              <!-- Approval Bar -->
              @if (rec.requiresApproval && rec.proposedAction) {
                <div class="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-3 text-xs dark:border-slate-800">
                  <span class="font-medium text-slate-700 dark:text-slate-200">
                    Proposed Action: {{ rec.proposedAction.summary }}
                  </span>
                  @if (rec.approvalStatus === 'pending') {
                    <div class="flex items-center gap-2">
                      <button
                        type="button"
                        (click)="store.decideCopilotApproval(rec.id, 'rejected')"
                        class="rounded border border-slate-200 px-3 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                      >
                        Reject
                      </button>
                      <button
                        type="button"
                        (click)="store.decideCopilotApproval(rec.id, 'approved')"
                        class="rounded bg-[#0078D4] px-3 py-1 text-xs font-semibold text-white hover:bg-[#0263B0]"
                      >
                        Approve &amp; Apply
                      </button>
                    </div>
                  } @else {
                    <span class="font-semibold capitalize text-emerald-700 dark:text-emerald-300">
                      {{ rec.approvalStatus }}
                    </span>
                  }
                </div>
              }
            </article>
          }
        </div>
      </div>
    </div>
  `,
})
export class CopilotWorkspace {
  store = inject(WorkspaceStore);
  readonly busy = signal(false);
  readonly queryText = signal('');

  async run(
    actionType:
      | 'summarize'
      | 'draft_reply'
      | 'extract_actions'
      | 'meeting_brief'
      | 'suggest_filing',
  ): Promise<void> {
    this.busy.set(true);
    try {
      const threadIds = this.store
        .selectedThreadMessages()
        .map((m) => m.id);
      await this.store.runCopilotAssist({
        actionType,
        messageIds: threadIds.length > 0 ? threadIds : ['msg_101', 'msg_103'],
      });
    } finally {
      this.busy.set(false);
    }
  }

  async testInjectionDefense(): Promise<void> {
    this.busy.set(true);
    try {
      await this.store.runCopilotAssist({
        actionType: 'summarize',
        messageIds: ['msg_105'],
      });
    } finally {
      this.busy.set(false);
    }
  }

  async findAuthorized(): Promise<void> {
    const q = this.queryText().trim();
    if (!q) return;
    this.busy.set(true);
    try {
      await this.store.runCopilotAssist({
        actionType: 'find_relevant',
        query: q,
      });
    } finally {
      this.busy.set(false);
    }
  }

  jumpToSource(messageId: string): void {
    this.store.selectedMessageId.set(messageId);
    this.store.activeView.set('mail');
    this.store.copilotDrawerOpen.set(false);
  }
}
