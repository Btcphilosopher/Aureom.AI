import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import type {EmailAttachment} from '../../shared/types';
import {WorkspaceStore} from '../core/workspace.store';

@Component({
  selector: 'app-files-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="flex-1 overflow-y-auto bg-white p-6 dark:bg-slate-900">
      <div class="mx-auto max-w-5xl space-y-5">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4 dark:border-slate-800">
          <div>
            <h1 class="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
              Files &amp; Attachment Discovery
            </h1>
            <p class="text-xs text-slate-500 dark:text-slate-400">
              Scoped strictly to accounts and shared mailboxes where you hold read permissions.
            </p>
          </div>

          <div class="flex items-center gap-2">
            <input
              type="search"
              [value]="filterQuery()"
              (input)="filterQuery.set($any($event.target).value)"
              placeholder="Filter filename or sender..."
              class="rounded-md border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs focus:border-[#0078D4] focus:outline-none dark:border-slate-700 dark:bg-slate-800"
            />
            <select
              aria-label="Group attachments by"
              [value]="groupBy()"
              (change)="groupBy.set($any($event.target).value)"
              class="rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
            >
              <option value="date">Group by Date</option>
              <option value="sender">Group by Sender</option>
              <option value="type">Group by Type</option>
            </select>
          </div>
        </div>

        @for (group of groupedFiles(); track group.key) {
          <div class="space-y-2">
            <h2 class="font-display text-xs font-semibold tracking-wide text-slate-500 dark:text-slate-400">
              {{ group.key }}
            </h2>
            <div class="divide-y divide-slate-200 rounded-xl border border-slate-200 dark:divide-slate-800 dark:border-slate-800">
              @for (row of group.items; track row.att.id) {
                <div class="flex flex-wrap items-center justify-between gap-3 px-4 py-3 text-xs hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <div class="flex min-w-0 items-center gap-3">
                    <mat-icon class="!text-[20px] text-[#0078D4]">description</mat-icon>
                    <div class="min-w-0">
                      <div class="truncate font-semibold text-slate-900 dark:text-slate-100">
                        {{ row.att.filename }}
                      </div>
                      <div class="text-[11px] text-slate-500 dark:text-slate-400">
                        From {{ row.sender }} · Source: {{ row.subject }} · Scan: {{ row.att.scanStatus }}
                      </div>
                    </div>
                  </div>

                  <div class="flex items-center gap-3">
                    <span class="tabular-nums text-[11px] text-slate-500">
                      {{ Math.max(1, Math.round(row.att.sizeBytes / 1024)) }} KB
                    </span>
                    <button
                      type="button"
                      (click)="store.previewAttachment.set(row.att)"
                      class="rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-white dark:border-slate-700 dark:text-slate-200"
                    >
                      Preview
                    </button>
                    <button
                      type="button"
                      (click)="openSourceMessage(row.att.messageId)"
                      class="rounded bg-[#0078D4]/10 px-2.5 py-1 text-xs font-medium text-[#0078D4] hover:bg-[#0078D4]/20 dark:text-sky-300"
                    >
                      Open Email
                    </button>
                  </div>
                </div>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class FilesWorkspace {
  protected Math = Math;
  store = inject(WorkspaceStore);

  readonly filterQuery = signal('');
  readonly groupBy = signal<'date' | 'sender' | 'type'>('date');

  readonly groupedFiles = computed(() => {
    const q = this.filterQuery().trim().toLowerCase();
    const mode = this.groupBy();
    const rows: {
      att: EmailAttachment;
      sender: string;
      subject: string;
      date: string;
    }[] = [];

    for (const msg of this.store.messages()) {
      for (const att of msg.attachments) {
        const hay = `${att.filename} ${msg.from.name} ${msg.subject}`.toLowerCase();
        if (q && !hay.includes(q)) continue;
        rows.push({
          att,
          sender: msg.from.name || msg.from.email,
          subject: msg.subject,
          date: att.createdAt.slice(0, 10),
        });
      }
    }

    const buckets = new Map<string, typeof rows>();
    for (const r of rows) {
      const key =
        mode === 'sender'
          ? r.sender
          : mode === 'type'
            ? r.att.mimeType
            : r.date;
      const list = buckets.get(key) ?? [];
      list.push(r);
      buckets.set(key, list);
    }

    return Array.from(buckets.entries()).map(([key, items]) => ({key, items}));
  });

  openSourceMessage(messageId: string): void {
    this.store.selectedMessageId.set(messageId);
    this.store.activeView.set('mail');
  }
}
