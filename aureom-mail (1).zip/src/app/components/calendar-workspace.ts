import {HttpClient} from '@angular/common/http';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import {FormBuilder, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {firstValueFrom} from 'rxjs';
import {
  SUPPORTED_TIMEZONES,
  formatDateTimeInTimezone,
  formatTimeInTimezone,
  localDateTimeToUtcIso,
} from '../../shared/timezone';
import type {CalendarEvent} from '../../shared/types';
import {WorkspaceStore} from '../core/workspace.store';

type CalendarViewMode = 'day' | 'work_week' | 'week' | 'month' | 'agenda';

@Component({
  selector: 'app-calendar-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="flex h-full min-h-0 flex-1 overflow-hidden">
      <!-- Left Calendar Sidebar -->
      <aside
        class="hidden w-60 shrink-0 flex-col border-r border-slate-200 bg-[#F8FAFC] p-4 md:flex dark:border-slate-800 dark:bg-slate-950"
      >
        <button
          type="button"
          (click)="openNewEvent()"
          class="flex w-full items-center justify-center gap-2 rounded-lg bg-[#0078D4] px-3 py-2 text-xs font-semibold text-white hover:bg-[#0263B0]"
        >
          <mat-icon class="!text-[17px]">event_available</mat-icon>
          <span>New Event</span>
        </button>

        <div class="mt-5">
          <div class="text-xs font-semibold text-slate-500 dark:text-slate-400">
            My Calendars
          </div>
          <div class="mt-2 space-y-1.5">
            @for (cal of store.calendars(); track cal.id) {
              <label class="flex cursor-pointer items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
                <input
                  type="checkbox"
                  [checked]="visibleCalendarIds().has(cal.id)"
                  (change)="toggleCalendar(cal.id)"
                  class="rounded border-slate-300"
                />
                <span class="truncate">{{ cal.name }}</span>
              </label>
            }
          </div>
        </div>

        <div class="mt-5">
          <label
            for="cal-tz-select"
            class="block text-xs font-semibold text-slate-500 dark:text-slate-400"
          >
            Display Timezone
          </label>
          <select
            id="cal-tz-select"
            [value]="activeTimezone()"
            (change)="activeTimezone.set($any($event.target).value)"
            class="mt-1.5 w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
          >
            @for (tz of timezones; track tz.id) {
              <option [value]="tz.id">{{ tz.label }}</option>
            }
          </select>
        </div>

        <div class="mt-auto space-y-2 border-t border-slate-200 pt-4 dark:border-slate-800">
          <a
            href="/api/events/export/ics"
            class="flex w-full items-center justify-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <mat-icon class="!text-[15px]">download</mat-icon>
            <span>Export .ICS</span>
          </a>
          <label
            class="flex w-full cursor-pointer items-center justify-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
          >
            <mat-icon class="!text-[15px]">upload</mat-icon>
            <span>Import .ICS</span>
            <input type="file" accept=".ics,text/calendar" class="hidden" (change)="onImportIcs($event)" />
          </label>
        </div>
      </aside>

      <!-- Main Calendar Surface -->
      <div class="flex min-w-0 flex-1 flex-col overflow-hidden bg-white dark:bg-slate-900">
        <!-- Toolbar -->
        <div
          class="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-5 py-3 dark:border-slate-800"
        >
          <div class="flex items-center gap-3">
            <h2 class="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              November 2026
            </h2>
            <span class="text-xs text-slate-500 dark:text-slate-400">
              Timezone: {{ activeTimezone() }}
            </span>
          </div>

          <div class="flex flex-wrap items-center gap-2">
            <div class="flex items-center rounded-lg bg-slate-100 p-0.5 dark:bg-slate-800">
              @for (v of viewOptions; track v.id) {
                <button
                  type="button"
                  (click)="viewMode.set(v.id)"
                  [class]="
                    viewMode() === v.id
                      ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white'
                      : 'text-slate-600 dark:text-slate-300'
                  "
                  class="rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap transition-colors"
                >
                  {{ v.label }}
                </button>
              }
            </div>
            <button
              type="button"
              (click)="openNewEvent()"
              class="inline-flex items-center gap-1 rounded-lg bg-[#0078D4] px-3 py-1.5 text-xs font-medium text-white md:hidden"
            >
              <mat-icon class="!text-[15px]">add</mat-icon>
              <span>Event</span>
            </button>
          </div>
        </div>

        <!-- Calendar Grid / Agenda -->
        <div class="flex-1 overflow-y-auto p-5">
          @if (viewMode() === 'agenda') {
            <div class="max-w-3xl space-y-3">
              @for (ev of filteredEvents(); track ev.id) {
                <div
                  class="rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-950/50"
                >
                  <div class="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <div class="flex items-center gap-2">
                        <h3 class="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                          {{ ev.title }}
                        </h3>
                        @if (ev.isRecurring) {
                          <span class="text-[11px] text-slate-500">· Repeats {{ ev.recurrenceRule }}</span>
                        }
                        @if (ev.isExceptionInstance) {
                          <span class="text-[11px] font-medium text-amber-700 dark:text-amber-300">
                            · Exception instance
                          </span>
                        }
                      </div>
                      <p class="mt-0.5 tabular-nums text-xs text-slate-600 dark:text-slate-300">
                        {{ formatStartEnd(ev) }}
                        <span class="text-slate-400">
                          (Origin: {{ ev.startLocal.replace('T', ' ') }} {{ ev.timezone }})
                        </span>
                      </p>
                      <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">
                        {{ ev.description }}
                      </p>
                    </div>

                    <div class="flex items-center gap-1.5">
                      <button
                        type="button"
                        (click)="openEditEvent(ev)"
                        class="rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200"
                      >
                        Edit
                      </button>
                    </div>
                  </div>

                  <div class="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2.5 text-xs dark:border-slate-800">
                    <div class="flex flex-wrap items-center gap-2 text-slate-500 dark:text-slate-400">
                      <span>
                        {{
                          ev.invitationStatus === 'local_only'
                            ? 'Saved locally (no invites sent)'
                            : ev.invitationStatus === 'invitation_sent'
                              ? 'Invitation sent to attendees'
                              : 'Received meeting invite'
                        }}
                      </span>
                      @if (ev.conferencingUrl) {
                        <span aria-hidden="true">·</span>
                        <span class="font-mono text-[11px] text-[#0078D4] dark:text-sky-300">
                          {{ ev.conferencingUrl }}
                        </span>
                      }
                    </div>

                    @if (ev.invitationStatus === 'received_invite') {
                      <div class="flex items-center gap-1">
                        @for (r of rsvpOptions; track r) {
                          <button
                            type="button"
                            (click)="store.respondToEvent(ev.id, r)"
                            [class]="
                              ev.myResponse === r
                                ? 'bg-[#0078D4] text-white'
                                : 'border border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-300'
                            "
                            class="rounded px-2 py-0.5 text-[11px] font-medium capitalize"
                          >
                            {{ r }}
                          </button>
                        }
                      </div>
                    }
                  </div>
                </div>
              }
            </div>
          } @else {
            <!-- Multi-day / Week / Month Grid -->
            <div
              class="grid gap-3"
              [class.grid-cols-1]="viewMode() === 'day'"
              [class.md:grid-cols-5]="viewMode() === 'work_week'"
              [class.md:grid-cols-7]="viewMode() === 'week' || viewMode() === 'month'"
            >
              @for (day of gridDays(); track day.isoDate) {
                <div
                  class="flex min-h-[150px] flex-col rounded-lg border border-slate-200 bg-slate-50/50 p-2.5 dark:border-slate-800 dark:bg-slate-950/40"
                >
                  <div class="mb-2 flex items-center justify-between border-b border-slate-200/70 pb-1.5 dark:border-slate-800">
                    <span class="text-xs font-semibold text-slate-800 dark:text-slate-200">
                      {{ day.label }}
                    </span>
                    <span class="tabular-nums text-[11px] text-slate-400">
                      {{ day.isoDate.slice(5) }}
                    </span>
                  </div>

                  <div class="space-y-1.5">
                    @for (ev of eventsForDay(day.isoDate); track ev.id) {
                      <button
                        type="button"
                        (click)="openEditEvent(ev)"
                        class="w-full rounded-md border border-slate-200 bg-white p-2 text-left text-xs hover:border-[#0078D4] dark:border-slate-700 dark:bg-slate-900"
                      >
                        <div class="tabular-nums text-[11px] font-medium text-[#0078D4] dark:text-sky-300">
                          {{ formatTime(ev.startUtc) }}
                        </div>
                        <div class="mt-0.5 truncate font-semibold text-slate-900 dark:text-slate-100">
                          {{ ev.title }}
                        </div>
                        <div class="mt-0.5 truncate text-[11px] text-slate-500">
                          {{ ev.myResponse }} · {{ ev.attendees.length }} attendee(s)
                        </div>
                      </button>
                    }
                  </div>
                </div>
              }
            </div>
          }
        </div>
      </div>
    </div>

    <!-- Event Create / Edit Modal -->
    @if (modalOpen()) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4"
        role="dialog"
        aria-modal="true"
        aria-label="Event editor"
      >
        <form
          [formGroup]="eventForm"
          (ngSubmit)="saveEvent()"
          class="w-full max-w-xl rounded-xl border border-slate-200 bg-white p-5 shadow-xl dark:border-slate-700 dark:bg-slate-900"
        >
          <div class="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
            <h3 class="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
              {{ editingEvent() ? 'Edit Event' : 'New Calendar Event' }}
            </h3>
            <button
              type="button"
              (click)="modalOpen.set(false)"
              class="rounded p-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <mat-icon class="!text-[18px]">close</mat-icon>
            </button>
          </div>

          <div class="mt-4 space-y-3 text-xs">
            @if (editingEvent()?.isRecurring) {
              <div class="rounded-lg border border-amber-200 bg-amber-50 p-2.5 text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
                <div class="font-semibold">Recurring series edit scope</div>
                <div class="mt-1.5 flex gap-4">
                  <label class="inline-flex items-center gap-1.5">
                    <input
                      type="radio"
                      name="editScope"
                      [checked]="editScope() === 'this_occurrence'"
                      (change)="editScope.set('this_occurrence')"
                    />
                    <span>This occurrence only (creates exception)</span>
                  </label>
                  <label class="inline-flex items-center gap-1.5">
                    <input
                      type="radio"
                      name="editScope"
                      [checked]="editScope() === 'entire_series'"
                      (change)="editScope.set('entire_series')"
                    />
                    <span>Entire series</span>
                  </label>
                </div>
              </div>
            }

            <div>
              <label for="ev-title" class="block font-medium text-slate-600 dark:text-slate-300">Title</label>
              <input
                id="ev-title"
                type="text"
                formControlName="title"
                class="mt-1 w-full rounded-md border border-slate-200 bg-white px-3 py-1.5 text-sm dark:border-slate-700 dark:bg-slate-800"
              />
            </div>

            <div class="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <label for="ev-start" class="block font-medium text-slate-600 dark:text-slate-300">Start</label>
                <input
                  id="ev-start"
                  type="datetime-local"
                  formControlName="startLocal"
                  class="mt-1 w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs tabular-nums dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div>
                <label for="ev-end" class="block font-medium text-slate-600 dark:text-slate-300">End</label>
                <input
                  id="ev-end"
                  type="datetime-local"
                  formControlName="endLocal"
                  class="mt-1 w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs tabular-nums dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div>
                <label for="ev-tz" class="block font-medium text-slate-600 dark:text-slate-300">Timezone</label>
                <select
                  id="ev-tz"
                  formControlName="timezone"
                  class="mt-1 w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                >
                  @for (tz of timezones; track tz.id) {
                    <option [value]="tz.id">{{ tz.id }}</option>
                  }
                </select>
              </div>
            </div>

            <!-- Live Cross-Timezone Preview -->
            <div class="rounded-md bg-slate-50 px-3 py-2 text-[11px] text-slate-600 dark:bg-slate-800/70 dark:text-slate-300">
              <span>Cross-timezone preview: </span>
              <span class="tabular-nums font-medium">{{ crossTzPreview() }}</span>
            </div>

            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label for="ev-attendees" class="block font-medium text-slate-600 dark:text-slate-300">
                  Attendees (comma-separated emails)
                </label>
                <input
                  id="ev-attendees"
                  type="text"
                  formControlName="attendeesCsv"
                  placeholder="priya.nair@meridian-demo.org, kenji.takahashi@meridian-demo.org"
                  class="mt-1 w-full rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                />
              </div>
              <div class="flex items-end gap-2">
                <button
                  type="button"
                  (click)="checkAvailability()"
                  class="rounded-md border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200"
                >
                  Check Availability
                </button>
              </div>
            </div>

            @if (availabilitySummary()) {
              <div class="rounded border border-slate-200 bg-slate-50 px-3 py-2 text-[11px] dark:border-slate-700 dark:bg-slate-800">
                {{ availabilitySummary() }}
              </div>
            }

            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label for="ev-recur" class="block font-medium text-slate-600 dark:text-slate-300">Recurrence</label>
                <select
                  id="ev-recur"
                  formControlName="recurrenceRule"
                  class="mt-1 w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                >
                  <option value="">Does not repeat</option>
                  <option value="DAILY">Daily</option>
                  <option value="WEEKLY">Weekly</option>
                  <option value="MONTHLY">Monthly</option>
                </select>
              </div>
              <div>
                <label for="ev-conf" class="block font-medium text-slate-600 dark:text-slate-300">Conferencing</label>
                <select
                  id="ev-conf"
                  formControlName="conferencingProvider"
                  class="mt-1 w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
                >
                  <option value="aureom_meet_mock">Aureom Meet (Mock Adapter)</option>
                  <option value="none">No video link</option>
                </select>
              </div>
            </div>

            <div>
              <label for="ev-desc" class="block font-medium text-slate-600 dark:text-slate-300">Description</label>
              <textarea
                id="ev-desc"
                formControlName="description"
                rows="2"
                class="mt-1 w-full rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-800"
              ></textarea>
            </div>
          </div>

          <div class="mt-5 flex flex-wrap items-center justify-end gap-2 border-t border-slate-200 pt-3 dark:border-slate-800">
            <button
              type="button"
              (click)="saveEventMode.set('local_only'); saveEvent()"
              class="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200"
            >
              Save Locally Only
            </button>
            <button
              type="submit"
              (click)="saveEventMode.set('invitation_sent')"
              class="rounded-lg bg-[#0078D4] px-4 py-1.5 text-xs font-semibold text-white hover:bg-[#0263B0]"
            >
              Save &amp; Send Invitation
            </button>
          </div>
        </form>
      </div>
    }
  `,
})
export class CalendarWorkspace {
  store = inject(WorkspaceStore);
  private http = inject(HttpClient);
  private fb = inject(FormBuilder);

  readonly timezones = SUPPORTED_TIMEZONES;
  readonly rsvpOptions = ['accepted', 'tentative', 'declined'] as const;
  readonly viewOptions: {id: CalendarViewMode; label: string}[] = [
    {id: 'day', label: 'Day'},
    {id: 'work_week', label: 'Work Week'},
    {id: 'week', label: 'Week'},
    {id: 'month', label: 'Month'},
    {id: 'agenda', label: 'Agenda'},
  ];

  readonly viewMode = signal<CalendarViewMode>('agenda');
  readonly activeTimezone = signal<string>('America/Los_Angeles');
  readonly hiddenCalendarIds = signal<Set<string>>(new Set());
  readonly modalOpen = signal(false);
  readonly editingEvent = signal<CalendarEvent | null>(null);
  readonly editScope = signal<'this_occurrence' | 'entire_series'>(
    'this_occurrence',
  );
  readonly saveEventMode = signal<'local_only' | 'invitation_sent'>(
    'invitation_sent',
  );
  readonly availabilitySummary = signal('');

  eventForm = this.fb.group({
    title: ['Cross-Timezone Architecture Review'],
    startLocal: ['2026-11-17T09:00'],
    endLocal: ['2026-11-17T10:00'],
    timezone: ['America/Los_Angeles'],
    attendeesCsv: ['priya.nair@meridian-demo.org, kenji.takahashi@meridian-demo.org'],
    recurrenceRule: [''],
    conferencingProvider: ['aureom_meet_mock'],
    description: [''],
  });

  readonly visibleCalendarIds = computed(() => {
    const hidden = this.hiddenCalendarIds();
    return new Set(
      this.store
        .calendars()
        .filter((c) => !hidden.has(c.id))
        .map((c) => c.id),
    );
  });

  readonly filteredEvents = computed(() => {
    const visible = this.visibleCalendarIds();
    return this.store
      .events()
      .filter((e) => visible.has(e.calendarId))
      .sort((a, b) => a.startUtc.localeCompare(b.startUtc));
  });

  readonly gridDays = computed(() => {
    const mode = this.viewMode();
    if (mode === 'day') {
      return [{isoDate: '2026-11-14', label: 'Sat Nov 14'}];
    }
    if (mode === 'work_week') {
      return [
        {isoDate: '2026-11-16', label: 'Mon 16'},
        {isoDate: '2026-11-17', label: 'Tue 17'},
        {isoDate: '2026-11-18', label: 'Wed 18'},
        {isoDate: '2026-11-19', label: 'Thu 19'},
        {isoDate: '2026-11-20', label: 'Fri 20'},
      ];
    }
    if (mode === 'week') {
      return [
        {isoDate: '2026-11-14', label: 'Sat 14'},
        {isoDate: '2026-11-15', label: 'Sun 15'},
        {isoDate: '2026-11-16', label: 'Mon 16'},
        {isoDate: '2026-11-17', label: 'Tue 17'},
        {isoDate: '2026-11-18', label: 'Wed 18'},
        {isoDate: '2026-11-19', label: 'Thu 19'},
        {isoDate: '2026-11-20', label: 'Fri 20'},
      ];
    }
    // 14-day condensed month window centered on mid-November 2026
    const days: {isoDate: string; label: string}[] = [];
    for (let d = 9; d <= 22; d++) {
      const iso = `2026-11-${String(d).padStart(2, '0')}`;
      days.push({isoDate: iso, label: `Nov ${d}`});
    }
    return days;
  });

  toggleCalendar(id: string): void {
    this.hiddenCalendarIds.update((set) => {
      const next = new Set(set);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  eventsForDay(isoDate: string): CalendarEvent[] {
    return this.filteredEvents().filter(
      (e) =>
        e.startLocal.startsWith(isoDate) ||
        (e.isRecurring &&
          e.recurrenceRule === 'WEEKLY' &&
          isoDate === '2026-11-16' &&
          !e.recurrenceExceptions.includes(e.startUtc)),
    );
  }

  formatTime(utcIso: string): string {
    return formatTimeInTimezone(utcIso, this.activeTimezone());
  }

  formatStartEnd(ev: CalendarEvent): string {
    return `${formatDateTimeInTimezone(ev.startUtc, this.activeTimezone())} – ${formatTimeInTimezone(ev.endUtc, this.activeTimezone())}`;
  }

  crossTzPreview(): string {
    const v = this.eventForm.getRawValue();
    if (!v.startLocal || !v.timezone) return '';
    const utc = localDateTimeToUtcIso(v.startLocal, v.timezone);
    return `${formatTimeInTimezone(utc, 'America/Los_Angeles')} · ${formatTimeInTimezone(utc, 'Europe/London')} · ${formatTimeInTimezone(utc, 'Asia/Tokyo')}`;
  }

  openNewEvent(): void {
    this.editingEvent.set(null);
    this.availabilitySummary.set('');
    this.eventForm.reset({
      title: 'Cross-Timezone Sync',
      startLocal: '2026-11-17T09:00',
      endLocal: '2026-11-17T09:45',
      timezone: this.activeTimezone(),
      attendeesCsv: 'priya.nair@meridian-demo.org',
      recurrenceRule: '',
      conferencingProvider: 'aureom_meet_mock',
      description: '',
    });
    this.modalOpen.set(true);
  }

  openEditEvent(ev: CalendarEvent): void {
    this.editingEvent.set(ev);
    this.editScope.set('this_occurrence');
    this.availabilitySummary.set('');
    this.eventForm.patchValue({
      title: ev.title,
      startLocal: ev.startLocal,
      endLocal: ev.endLocal,
      timezone: ev.timezone,
      attendeesCsv: ev.attendees.map((a) => a.email).join(', '),
      recurrenceRule: ev.recurrenceRule ?? '',
      conferencingProvider: ev.conferencingProvider,
      description: ev.description,
    });
    this.modalOpen.set(true);
  }

  async checkAvailability(): Promise<void> {
    const v = this.eventForm.getRawValue();
    const emails = (v.attendeesCsv ?? '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    const startUtc = localDateTimeToUtcIso(
      v.startLocal ?? '2026-11-17T09:00',
      v.timezone ?? 'UTC',
    );
    const endUtc = localDateTimeToUtcIso(
      v.endLocal ?? '2026-11-17T10:00',
      v.timezone ?? 'UTC',
    );
    const res = await firstValueFrom(
      this.http.post<{
        providerLabel: string;
        availability: Record<string, string>;
      }>('/api/availability', {
        accountId: 'acc_work',
        attendeeEmails: emails,
        startUtc,
        endUtc,
      }),
    );
    const summary = Object.entries(res.availability)
      .map(([email, status]) => `${email}: ${status}`)
      .join(' · ');
    this.availabilitySummary.set(
      `${res.providerLabel}: ${summary || 'No attendees specified'}`,
    );
  }

  async saveEvent(): Promise<void> {
    const v = this.eventForm.getRawValue();
    const attendees = (v.attendeesCsv ?? '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .map((email) => ({
        email,
        name: email.split('@')[0] ?? email,
        response: 'needsAction' as const,
      }));

    const existing = this.editingEvent();
    if (existing) {
      await this.store.editEvent(
        existing.id,
        {
          title: v.title ?? existing.title,
          startLocal: v.startLocal ?? existing.startLocal,
          endLocal: v.endLocal ?? existing.endLocal,
          timezone: v.timezone ?? existing.timezone,
          description: v.description ?? '',
          attendees,
          invitationStatus: this.saveEventMode(),
        },
        existing.isRecurring ? this.editScope() : 'entire_series',
        existing.startUtc,
      );
    } else {
      await this.store.createEvent({
        accountId: 'acc_work',
        calendarId: 'cal_work',
        title: v.title ?? 'New Event',
        startLocal: v.startLocal ?? '2026-11-17T09:00',
        endLocal: v.endLocal ?? '2026-11-17T10:00',
        timezone: v.timezone ?? 'America/Los_Angeles',
        description: v.description ?? '',
        attendees,
        isRecurring: Boolean(v.recurrenceRule),
        recurrenceRule: v.recurrenceRule || null,
        conferencingProvider: v.conferencingProvider ?? 'aureom_meet_mock',
        invitationStatus: this.saveEventMode(),
      });
    }
    this.modalOpen.set(false);
  }

  onImportIcs(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      void this.store.importIcs(
        String(reader.result ?? ''),
        'acc_work',
        'cal_work',
      );
    };
    reader.readAsText(file);
  }
}
