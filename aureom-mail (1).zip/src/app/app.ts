import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import {MatIconModule} from '@angular/material/icon';
import {CalendarWorkspace} from './components/calendar-workspace';
import {ComposerModal} from './components/composer-modal';
import {CopilotWorkspace} from './components/copilot-workspace';
import {FilesWorkspace} from './components/files-workspace';
import {MailWorkspace} from './components/mail-workspace';
import {PeopleWorkspace} from './components/people-workspace';
import {SettingsRulesDrawer} from './components/settings-rules-drawer';
import {TasksWorkspace} from './components/tasks-workspace';
import {ActiveAppView, WorkspaceStore} from './core/workspace.store';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    MatIconModule,
    MailWorkspace,
    CalendarWorkspace,
    PeopleWorkspace,
    TasksWorkspace,
    FilesWorkspace,
    CopilotWorkspace,
    ComposerModal,
    SettingsRulesDrawer,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
  host: {
    '(window:keydown)': 'onGlobalKey($event)',
  },
})
export class App implements OnInit {
  store = inject(WorkspaceStore);
  readonly savedSearchMenuOpen = signal(false);

  readonly navItems: {id: ActiveAppView; label: string; icon: string}[] = [
    {id: 'mail', label: 'Mail', icon: 'mail'},
    {id: 'calendar', label: 'Calendar', icon: 'calendar_month'},
    {id: 'people', label: 'People', icon: 'people'},
    {id: 'tasks', label: 'Tasks', icon: 'check_circle'},
    {id: 'files', label: 'Files', icon: 'folder_copy'},
    {id: 'copilot', label: 'Copilot', icon: 'assistant'},
  ];

  readonly myDayTasks = computed(() =>
    this.store
      .tasks()
      .filter((t) => t.isMyDay && t.status !== 'completed')
      .slice(0, 6),
  );

  readonly upcomingMeetings = computed(() =>
    this.store
      .events()
      .slice()
      .sort((a, b) => a.startUtc.localeCompare(b.startUtc))
      .slice(0, 4),
  );

  ngOnInit(): void {
    void this.store.initialize();
  }

  onGlobalKey(event: KeyboardEvent): void {
    const target = event.target as HTMLElement | null;
    const isTyping =
      target?.tagName === 'INPUT' ||
      target?.tagName === 'TEXTAREA' ||
      target?.tagName === 'SELECT';
    if (event.key === 'Escape') {
      this.store.composerOpen.set(false);
      this.store.settingsOpen.set(false);
      this.store.notificationsOpen.set(false);
      this.store.copilotDrawerOpen.set(false);
      this.savedSearchMenuOpen.set(false);
      return;
    }
    if (isTyping) return;

    if (event.key.toLowerCase() === 'c') {
      event.preventDefault();
      this.store.openNewComposer();
    } else if (event.key === '/') {
      event.preventDefault();
      const input = document.getElementById('aureom-unified-search');
      input?.focus();
    }
  }

  applySavedSearch(savedId: string): void {
    const item = this.store.savedSearches().find((s) => s.id === savedId);
    if (!item) return;
    this.store.searchQuery.set(item.query);
    this.store.selectedAccountId.set(item.accountId ?? 'all');
    this.store.searchHasAttachment.set(item.hasAttachment);
    this.store.searchCategory.set(item.category);
    this.store.activeView.set('mail');
    this.savedSearchMenuOpen.set(false);
  }

  saveCurrentSearch(): void {
    const q = this.store.searchQuery().trim();
    if (!q) return;
    void this.store.saveSearch(`Search: ${q}`);
    this.savedSearchMenuOpen.set(false);
  }

  openDemoGuide(): void {
    this.store.settingsTab.set('demo');
    this.store.settingsOpen.set(true);
  }

  openSyncPanel(): void {
    this.store.settingsTab.set('accounts');
    this.store.settingsOpen.set(true);
  }

  toggleRightSidebar(): void {
    const curr = this.store.preferences().showRightSidebar;
    void this.store.updatePreferences({showRightSidebar: !curr});
  }
}
