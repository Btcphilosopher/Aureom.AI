import {describe, expect, it} from 'vitest';
import {buildStorageCompositeKey} from '../server/adapters';
import {copilotService} from '../server/copilot';
import {AureomDatabase, searchService} from '../server/db';
import {
  analyzeSenderAuthenticity,
  detectPromptInjectionInEmail,
  sanitizeEmailHtml,
} from '../shared/security';
import {localDateTimeToUtcIso, utcIsoToLocalDateTime} from '../shared/timezone';

describe('Aureom Mail Core Security, Sync, Outbox, Calendar & Copilot Suite', () => {
  it('sanitizes dangerous HTML, strips scripts, blocks remote images by default, and flags deceptive links', () => {
    const raw =
      '<p>Hello</p><script>alert(1)</script><iframe src="https://evil.example"></iframe>' +
      '<img src="https://tracker.example/pixel.png" alt="Tracker" />' +
      '<a href="https://evil.example/steal">https://meridian-demo.org/verify</a>';

    const blocked = sanitizeEmailHtml(raw, {allowRemoteImages: false});
    expect(blocked.html).not.toContain('<script');
    expect(blocked.html).not.toContain('<iframe');
    expect(blocked.hasRemoteImages).toBe(true);
    expect(blocked.blockedImageCount).toBe(1);
    expect(blocked.html).toContain('data-blocked-remote-image="true"');
    expect(blocked.suspiciousLinks.length).toBe(1);

    const allowed = sanitizeEmailHtml(raw, {allowRemoteImages: true});
    expect(allowed.blockedImageCount).toBe(0);
    expect(allowed.html).toContain('<img src="https://tracker.example/pixel.png"');
  });

  it('detects Reply-To domain mismatch and display-name spoofing honestly without claiming independent verification', () => {
    const summary = analyzeSenderAuthenticity(
      {name: 'finance@meridian-demo.org', email: 'alert@lookalike.example'},
      {name: 'Collect', email: 'payout@offshore.example'},
      {'Authentication-Results': 'spf=fail; dkim=fail; dmarc=fail'},
      'Microsoft Graph (simulated)',
    );
    expect(summary.spf).toBe('fail');
    expect(summary.independentlyVerifiedByApp).toBe(false);
    expect(summary.suspiciousSenderWarning).toBeTruthy();
    expect(summary.replyToMismatchWarning).toBeTruthy();
  });

  it('enforces shared-mailbox permissions and restricts unauthorized shared content from search', () => {
    const db = new AureomDatabase({persistToDisk: false});
    const state = db.getState();

    // Grant vs revoke shared mailbox read permission
    expect(
      db.checkSharedPermission('acc_shared_ops', 'alex.mercer@aureom-demo.org', 'canRead'),
    ).toBe(true);
    expect(
      db.checkSharedPermission('acc_shared_ops', 'unauthorized@aureom-demo.org', 'canRead'),
    ).toBe(false);

    const allowedIds = db.getAuthorizedAccountIds('unauthorized@aureom-demo.org');
    expect(allowedIds).not.toContain('acc_shared_ops');

    const results = searchService.search(state, {
      query: 'TLS Wildcard',
      authorizedAccountIds: allowedIds,
    });
    expect(results.messages.length).toBe(0);
  });

  it('supports draft recovery, optimistic concurrency, duplicate-send prevention, and uncertain outcomes', async () => {
    const db = new AureomDatabase({persistToDisk: false});
    const draft = db.upsertOutboxDraft({
      accountId: 'acc_work',
      to: [{name: 'Elena', email: 'elena.rostova@meridian-demo.org'}],
      subject: 'Idempotency Test',
      bodyText: 'Testing durable outbox',
      idempotencyKey: 'idem_fixed_key_1',
    });
    expect(draft.version).toBe(1);

    // Optimistic concurrency conflict check
    expect(() =>
      db.upsertOutboxDraft({
        id: draft.id,
        accountId: 'acc_work',
        subject: 'Stale write',
        version: 0,
      }),
    ).toThrow('CONFLICT_OUTBOX_VERSION');

    // Uncertain outcome preserves uncertainty instead of claiming sent
    const uncertain = await db.submitOutboxDraft(draft.id, {
      simulateUncertain: true,
    });
    expect(uncertain.status).toBe('uncertain_outcome');

    // Successful submit then duplicate retry is idempotent
    const sent = await db.submitOutboxDraft(draft.id);
    expect(sent.status).toBe('submitted');
    const sentCountBefore = db
      .getState()
      .messages.filter((m) => m.subject === 'Idempotency Test').length;
    expect(sentCountBefore).toBe(1);

    const retry = await db.submitOutboxDraft(draft.id);
    expect(retry.deliveryNote).toContain('Duplicate send prevented');
    const sentCountAfter = db
      .getState()
      .messages.filter((m) => m.subject === 'Idempotency Test').length;
    expect(sentCountAfter).toBe(1);
  });

  it('cancels delayed send locally before submission without sending', () => {
    const db = new AureomDatabase({persistToDisk: false});
    const draft = db.upsertOutboxDraft({
      accountId: 'acc_work',
      subject: 'Delayed Send Cancel Test',
      status: 'delayed_pending',
      delayedUntil: new Date(Date.now() + 10000).toISOString(),
    });
    const cancelled = db.cancelDelayedDraft(draft.id);
    expect(cancelled.status).toBe('draft');
    expect(cancelled.delayedUntil).toBeNull();
  });

  it('tracks IMAP UIDVALIDITY composite keys and recovers from sync failure', async () => {
    const db = new AureomDatabase({persistToDisk: false});
    const msg = db.getState().messages.find((m) => m.accountId === 'acc_shared_ops')!;
    expect(buildStorageCompositeKey(msg)).toBe('acc_shared_ops:fld_ops_inbox:10441:5501');

    const failRes = await db.syncAccount('acc_shared_ops', {simulateFailure: true});
    expect(failRes.account.syncStatus).toBe('error');

    const okRes = await db.syncAccount('acc_shared_ops', {forceResetUidValidity: true});
    expect(okRes.account.syncStatus).toBe('synced');
    expect(okRes.account.uidValidity).toBe(10442);
  });

  it('handles recurring calendar exceptions without mutating the series master', () => {
    const db = new AureomDatabase({persistToDisk: false});
    const masterBefore = db.getState().events.find((e) => e.id === 'evt_mon_standup')!;
    const origStart = masterBefore.startUtc;

    const exception = db.editCalendarEvent(
      'evt_mon_standup',
      {title: 'Standup (Moved 1 Hour)', startLocal: '2026-11-16T09:30', endLocal: '2026-11-16T10:15'},
      'this_occurrence',
      origStart,
    );

    expect(exception.isExceptionInstance).toBe(true);
    expect(exception.seriesMasterId).toBe('evt_mon_standup');
    expect(masterBefore.title).toBe('Architecture & Reliability Weekly Sync');
    expect(masterBefore.recurrenceExceptions).toContain(origStart);
  });

  it('preserves daylight-saving transitions accurately between local time and UTC', () => {
    // 2026-11-01 is US Fall Back (PDT UTC-7 -> PST UTC-8)
    const beforeFallBack = localDateTimeToUtcIso('2026-10-31T10:00', 'America/Los_Angeles');
    const afterFallBack = localDateTimeToUtcIso('2026-11-02T10:00', 'America/Los_Angeles');
    expect(beforeFallBack).toBe('2026-10-31T17:00:00.000Z');
    expect(afterFallBack).toBe('2026-11-02T18:00:00.000Z');
    expect(utcIsoToLocalDateTime(afterFallBack, 'America/Los_Angeles')).toBe('2026-11-02T10:00');
  });

  it('queues offline sends without labeling them sent and reconciles cleanly on reconnect', async () => {
    const db = new AureomDatabase({persistToDisk: false});
    db.getState().preferences.offlineModeSimulated = true;
    const draft = db.upsertOutboxDraft({
      accountId: 'acc_work',
      to: [{name: 'Elena', email: 'elena.rostova@meridian-demo.org'}],
      subject: 'Offline Queued Mail',
      bodyText: 'Should remain queued offline',
    });
    const queued = await db.submitOutboxDraft(draft.id);
    expect(queued.status).toBe('queued_offline');
    expect(queued.deliveryNote).toContain('NOT been sent');

    // Reconnect and submit
    db.getState().preferences.offlineModeSimulated = false;
    const sent = await db.submitOutboxDraft(draft.id);
    expect(sent.status).toBe('submitted');
  });

  it('blocks malicious prompt-injection instructions in email bodies and enforces AI approval gates', async () => {
    const db = new AureomDatabase({persistToDisk: false});
    const phish = db.getState().messages.find((m) => m.id === 'msg_105')!;
    expect(detectPromptInjectionInEmail(phish.bodyText)).toBe(true);

    const injectionRes = await copilotService.assist(db, {
      actionType: 'summarize',
      messageIds: ['msg_105'],
      userEmail: 'alex.mercer@aureom-demo.org',
    });
    expect(injectionRes.promptInjectionDetected).toBe(true);
    expect(injectionRes.resultText).toContain('refused any unauthorized forwarding');

    const extractRes = await copilotService.assist(db, {
      actionType: 'extract_actions',
      messageIds: ['msg_101'],
      userEmail: 'alex.mercer@aureom-demo.org',
    });
    expect(extractRes.requiresApproval).toBe(true);
    expect(extractRes.approvalStatus).toBe('pending');
  });
});
