import {isPlatformBrowser} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {
  Injectable,
  PLATFORM_ID,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import {firstValueFrom} from 'rxjs';
import type {
  Account,
  AiActionRecord,
  CalendarEvent,
  ContactRecord,
  EmailAttachment,
  EmailMessage,
  MailFolder,
  MailRule,
  OfflineQueuedOp,
  OutboxDraft,
  SavedSearch,
  TaskItem,
  UserPreferences,
  WorkspaceBootstrap,
} from '../../shared/types';

export type ActiveAppView =
  | 'mail'
  | 'calendar'
  | 'people'
  | 'tasks'
  | 'files'
  | 'copilot';

export type SmartMailBucket =
  | 'unified_inbox'
  | 'flagged'
  | 'snoozed'
  | 'outbox'
  | null;

export interface SanitizedClientMessage extends EmailMessage {
  bodyHtmlSanitized: string;
  hasRemoteImages: boolean;
  blockedImageCount: number;
  suspiciousLinks: {displayText: string; href: string}[];
}

export interface BootstrapPayload extends WorkspaceBootstrap {
  messages: SanitizedClientMessage[];
  providerCapabilities: {
    provider: string;
    label: string;
    isSimulated: boolean;
    supportsOAuth: boolean;
    supportsNestedFolders: boolean;
    supportsLabels: boolean;
    supportsDeltaSync: boolean;
    supportsUidValidity: boolean;
    supportsAvailability: boolean;
    supportsProviderRules: boolean;
    rateLimitPerMinute: number;
  }[];
}

export interface WorkspaceNotification {
  id: string;
  title: string;
  detail: string;
  kind: 'info' | 'success' | 'warning' | 'error';
  createdAt: string;
}

@Injectable({providedIn: 'root'})
export class WorkspaceStore {
  private http = inject(HttpClient);
  private platformId = inject(PLATFORM_ID);
  private isBrowser = isPlatformBrowser(this.platformId);

  readonly loading = signal<boolean>(true);
  readonly error = signal<string | null>(null);
  readonly data = signal<BootstrapPayload | null>(null);

  // Navigation & layout state
  readonly activeView = signal<ActiveAppView>('mail');
  readonly selectedAccountId = signal<string>('all');
  readonly selectedFolderId = signal<string | null>(null);
  readonly smartBucket = signal<SmartMailBucket>('unified_inbox');
  readonly selectedMessageId = signal<string | null>(null);
  readonly checkedMessageIds = signal<Set<string>>(new Set());

  // List filters
  readonly mailFilter = signal<
    'all' | 'unread' | 'flagged' | 'pinned' | 'attachments'
  >('all');
  readonly mailSort = signal<'date_desc' | 'date_asc' | 'sender' | 'subject'>(
    'date_desc',
  );
  readonly searchQuery = signal<string>('');
  readonly searchCategory = signal<string | null>(null);
  readonly searchHasAttachment = signal<boolean>(false);

  // Drawers & modals
  readonly composerOpen = signal<boolean>(false);
  readonly activeDraft = signal<Partial<OutboxDraft> | null>(null);
  readonly copilotDrawerOpen = signal<boolean>(false);
  readonly settingsOpen = signal<boolean>(false);
  readonly settingsTab = signal<
    'general' | 'accounts' | 'rules' | 'security' | 'demo'
  >('general');
  readonly notificationsOpen = signal<boolean>(false);
  readonly mobileShowingReading = signal<boolean>(false);
  readonly remoteImageAllowedIds = signal<Set<string>>(new Set());
  readonly plainTextMessageIds = signal<Set<string>>(new Set());
  readonly previewAttachment = signal<EmailAttachment | null>(null);

  // Live notifications & delayed-send timers
  readonly notifications = signal<WorkspaceNotification[]>([]);
  readonly delayTimers = new Map<string, ReturnType<typeof setTimeout>>();

  // Derived signals
  readonly preferences = computed<UserPreferences>(
    () =>
      this.data()?.preferences ?? {
        theme: 'light',
        density: 'comfortable',
        readingPanePosition: 'right',
        showRightSidebar: true,
        conversationGrouping: true,
        defaultSendDelaySeconds: 10,
        blockRemoteImages: true,
        offlineCacheDays: 30,
        offlineModeSimulated: false,
      },
  );

  readonly accounts = computed<Account[]>(() => this.data()?.accounts ?? []);
  readonly folders = computed<MailFolder[]>(() => this.data()?.folders ?? []);
  readonly messages = computed<SanitizedClientMessage[]>(
    () => this.data()?.messages ?? [],
  );
  readonly outbox = computed<OutboxDraft[]>(() => this.data()?.outbox ?? []);
  readonly events = computed<CalendarEvent[]>(() => this.data()?.events ?? []);
  readonly calendars = computed(() => this.data()?.calendars ?? []);
  readonly contacts = computed<ContactRecord[]>(
    () => this.data()?.contacts ?? [],
  );
  readonly tasks = computed<TaskItem[]>(() => this.data()?.tasks ?? []);
  readonly rules = computed<MailRule[]>(() => this.data()?.rules ?? []);
  readonly savedSearches = computed<SavedSearch[]>(
    () => this.data()?.savedSearches ?? [],
  );
  readonly aiHistory = computed<AiActionRecord[]>(
    () => this.data()?.aiHistory ?? [],
  );
  readonly offlineQueue = computed<OfflineQueuedOp[]>(
    () => this.data()?.offlineQueue ?? [],
  );

  readonly isOfflineMode = computed(
    () => this.preferences().offlineModeSimulated,
  );

  readonly pendingDelayedDrafts = computed(() =>
    this.outbox().filter((d) => d.status === 'delayed_pending'),
  );

  readonly visibleMessages = computed<SanitizedClientMessage[]>(() => {
    const all = this.messages();
    const accFilter = this.selectedAccountId();
    const bucket = this.smartBucket();
    const folderId = this.selectedFolderId();
    const filter = this.mailFilter();
    const q = this.searchQuery().trim().toLowerCase();
    const cat = this.searchCategory();
    const attOnly = this.searchHasAttachment();

    const folders = this.folders();

    let filtered = all.filter((m) => {
      if (accFilter !== 'all' && m.accountId !== accFilter) return false;

      if (q) {
        const corpus = [
          m.subject,
          m.bodyText,
          m.from.name,
          m.from.email,
          ...m.categories,
          ...m.attachments.map((a) => a.filename),
        ]
          .join(' ')
          .toLowerCase();
        if (!corpus.includes(q)) return false;
      } else if (bucket === 'unified_inbox') {
        const f = folders.find((fl) => fl.id === m.folderId);
        if (!f || f.role !== 'inbox') return false;
        if (m.snoozedUntil) return false;
      } else if (bucket === 'flagged') {
        if (!m.isFlagged) return false;
      } else if (bucket === 'snoozed') {
        if (!m.snoozedUntil) return false;
      } else if (folderId) {
        if (m.folderId !== folderId) return false;
      }

      if (cat && !m.categories.includes(cat)) return false;
      if (attOnly && m.attachments.length === 0) return false;

      if (filter === 'unread' && m.isRead) return false;
      if (filter === 'flagged' && !m.isFlagged) return false;
      if (filter === 'pinned' && !m.isPinned) return false;
      if (filter === 'attachments' && m.attachments.length === 0) return false;

      return true;
    });

    // Conversation grouping collapses same threadId to latest message in list
    if (this.preferences().conversationGrouping && !q) {
      const seenThreads = new Set<string>();
      const sortedFirst = [...filtered].sort((a, b) =>
        b.receivedAt.localeCompare(a.receivedAt),
      );
      filtered = sortedFirst.filter((m) => {
        if (seenThreads.has(m.threadId)) return false;
        seenThreads.add(m.threadId);
        return true;
      });
    }

    const sortMode = this.mailSort();
    return [...filtered].sort((a, b) => {
      if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
      if (sortMode === 'date_asc') {
        return a.receivedAt.localeCompare(b.receivedAt);
      }
      if (sortMode === 'sender') {
        return a.from.name.localeCompare(b.from.name);
      }
      if (sortMode === 'subject') {
        return a.subject.localeCompare(b.subject);
      }
      return b.receivedAt.localeCompare(a.receivedAt);
    });
  });

  readonly selectedMessage = computed<SanitizedClientMessage | null>(() => {
    const id = this.selectedMessageId();
    if (!id) return null;
    return this.messages().find((m) => m.id === id) ?? null;
  });

  readonly selectedThreadMessages = computed<SanitizedClientMessage[]>(() => {
    const msg = this.selectedMessage();
    if (!msg) return [];
    if (!this.preferences().conversationGrouping) return [msg];
    return this.messages()
      .filter((m) => m.threadId === msg.threadId)
      .sort((a, b) => a.receivedAt.localeCompare(b.receivedAt));
  });

  readonly unreadTotal = computed(() =>
    this.accounts().reduce((sum, a) => sum + a.unreadCount, 0),
  );

  readonly hasAnySyncError = computed(() =>
    this.accounts().some((a) => a.syncStatus === 'error'),
  );

  constructor() {
    if (this.isBrowser) {
      effect(() => {
        const prefs = this.preferences();
        const prefersDark =
          typeof window !== 'undefined' &&
          window.matchMedia?.('(prefers-color-scheme: dark)').matches;
        const useDark =
          prefs.theme === 'dark' || (prefs.theme === 'system' && prefersDark);
        document.documentElement.classList.toggle('dark', useDark);
        document.body.classList.toggle(
          'density-compact',
          prefs.density === 'compact',
        );
        document.body.classList.toggle(
          'density-comfortable',
          prefs.density !== 'compact',
        );
      });
    }
  }

  async initialize(): Promise<void> {
    if (!this.isBrowser) {
      this.loading.set(false);
      return;
    }
    this.loading.set(true);
    this.error.set(null);
    try {
      const payload = await firstValueFrom(
        this.http.get<BootstrapPayload>('/api/bootstrap'),
      );
      this.data.set(payload);
      if (!this.selectedMessageId() && payload.messages.length > 0) {
        const firstInbox = payload.messages.find((m) => {
          const fl = payload.folders.find((f) => f.id === m.folderId);
          return fl?.role === 'inbox';
        });
        if (firstInbox) {
          this.selectedMessageId.set(firstInbox.id);
        }
      }
    } catch (err) {
      this.error.set(
        err instanceof Error ? err.message : 'Failed to load workspace data.',
      );
    } finally {
      this.loading.set(false);
    }
  }

  pushNotification(
    title: string,
    detail: string,
    kind: WorkspaceNotification['kind'] = 'info',
  ): void {
    const item: WorkspaceNotification = {
      id: `ntf_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
      title,
      detail,
      kind,
      createdAt: new Date().toISOString(),
    };
    this.notifications.update((list) => [item, ...list].slice(0, 20));
  }

  selectMessage(message: SanitizedClientMessage): void {
    this.selectedMessageId.set(message.id);
    this.mobileShowingReading.set(true);
    if (!message.isRead) {
      void this.bulkMessageAction([message.id], 'mark_read');
    }
  }

  async allowRemoteImagesForMessage(messageId: string): Promise<void> {
    const updated = await firstValueFrom(
      this.http.get<SanitizedClientMessage>(
        `/api/messages/${messageId}?allowRemoteImages=true`,
      ),
    );
    this.remoteImageAllowedIds.update((set) => {
      const next = new Set(set);
      next.add(messageId);
      return next;
    });
    this.data.update((curr) => {
      if (!curr) return curr;
      return {
        ...curr,
        messages: curr.messages.map((m) => (m.id === messageId ? updated : m)),
      };
    });
    this.pushNotification(
      'Remote images loaded',
      'Remote images enabled only for this message.',
      'info',
    );
  }

  togglePlainText(messageId: string): void {
    this.plainTextMessageIds.update((set) => {
      const next = new Set(set);
      if (next.has(messageId)) next.delete(messageId);
      else next.add(messageId);
      return next;
    });
  }

  toggleCheckedMessage(messageId: string): void {
    this.checkedMessageIds.update((set) => {
      const next = new Set(set);
      if (next.has(messageId)) next.delete(messageId);
      else next.add(messageId);
      return next;
    });
  }

  clearCheckedMessages(): void {
    this.checkedMessageIds.set(new Set());
  }

  async updatePreferences(patch: Partial<UserPreferences>): Promise<void> {
    const res = await firstValueFrom(
      this.http.patch<{preferences: UserPreferences}>('/api/preferences', patch),
    );
    this.data.update((curr) =>
      curr ? {...curr, preferences: res.preferences} : curr,
    );
  }

  async bulkMessageAction(
    messageIds: string[],
    action: string,
    value?: string,
  ): Promise<void> {
    if (messageIds.length === 0) return;
    try {
      const res = await firstValueFrom(
        this.http.patch<{updatedIds: string[]; bootstrap: BootstrapPayload}>(
          '/api/messages/bulk',
          {messageIds, action, value},
        ),
      );
      this.data.set(res.bootstrap);
      this.clearCheckedMessages();
      if (action === 'archive' || action === 'delete' || action === 'move_folder') {
        const stillVisible = this.visibleMessages();
        if (
          this.selectedMessageId() &&
          !stillVisible.some((m) => m.id === this.selectedMessageId())
        ) {
          this.selectedMessageId.set(stillVisible[0]?.id ?? null);
        }
      }
    } catch (err) {
      this.pushNotification(
        'Action blocked',
        (err as {error?: {error?: string}})?.error?.error ??
          'Could not complete action.',
        'error',
      );
    }
  }

  async addInternalNote(
    messageId: string,
    text: string,
    assignedTo?: string | null,
  ): Promise<void> {
    const updated = await firstValueFrom(
      this.http.post<SanitizedClientMessage>(
        `/api/messages/${messageId}/notes`,
        {text, assignedTo},
      ),
    );
    this.data.update((curr) =>
      curr
        ? {
            ...curr,
            messages: curr.messages.map((m) =>
              m.id === messageId ? updated : m,
            ),
          }
        : curr,
    );
    this.pushNotification(
      'Internal note saved',
      'Saved internally only; never included in outgoing replies.',
      'success',
    );
  }

  async createFolder(
    accountId: string,
    name: string,
    parentId: string | null = null,
  ): Promise<void> {
    await firstValueFrom(
      this.http.post('/api/folders', {accountId, name, parentId}),
    );
    await this.initialize();
    this.pushNotification('Folder created', `Created "${name}"`, 'success');
  }

  openNewComposer(preset?: Partial<OutboxDraft>): void {
    const defaultAccId =
      this.selectedAccountId() !== 'all'
        ? this.selectedAccountId()
        : (this.accounts()[0]?.id ?? 'acc_work');
    const acc = this.accounts().find((a) => a.id === defaultAccId);

    this.activeDraft.set({
      accountId: defaultAccId,
      sendAsAddress: acc?.email ?? 'alex.mercer@aureom-demo.org',
      mode: 'new',
      to: [],
      cc: [],
      bcc: [],
      subject: '',
      bodyHtml: acc?.signatureHtml ?? '',
      bodyText: acc?.signatureText ?? '',
      isRichText: true,
      attachments: [],
      inlineImages: [],
      sendDelaySeconds: this.preferences().defaultSendDelaySeconds,
      ...preset,
    });
    this.composerOpen.set(true);
  }

  openReplyComposer(
    msg: SanitizedClientMessage,
    mode: 'reply' | 'replyAll' | 'forward',
  ): void {
    const acc = this.accounts().find((a) => a.id === msg.accountId);
    const replyTarget = msg.replyTo ?? msg.from;
    const to =
      mode === 'forward'
        ? []
        : [replyTarget];
    const cc =
      mode === 'replyAll'
        ? msg.to
            .concat(msg.cc)
            .filter(
              (p) =>
                p.email.toLowerCase() !== acc?.email.toLowerCase() &&
                p.email.toLowerCase() !== replyTarget.email.toLowerCase(),
            )
        : [];
    const prefix = mode === 'forward' ? 'Fwd: ' : 'Re: ';
    const subject = msg.subject.startsWith(prefix)
      ? msg.subject
      : `${prefix}${msg.subject}`;
    const quoted = `\n\n--- On ${msg.receivedAt.slice(0, 16)}, ${msg.from.name} <${msg.from.email}> wrote:\n${msg.bodyText}`;

    this.openNewComposer({
      accountId: msg.accountId,
      sendAsAddress: acc?.email ?? 'alex.mercer@aureom-demo.org',
      replyToMessageId: mode === 'forward' ? null : msg.id,
      forwardMessageId: mode === 'forward' ? msg.id : null,
      mode,
      to,
      cc,
      subject,
      bodyText: `\n\n${acc?.signatureText ?? ''}${quoted}`,
      bodyHtml: `<p></p>${acc?.signatureHtml ?? ''}<blockquote>${msg.bodyHtmlSanitized}</blockquote>`,
    });
  }

  async saveOrSendDraft(
    payload: Partial<OutboxDraft> & {accountId: string},
    action: 'save_draft' | 'schedule_delay' | 'send_now',
    options?: {simulateUncertain?: boolean; simulateFailure?: boolean},
  ): Promise<OutboxDraft> {
    const res = await firstValueFrom(
      this.http.post<{draft: OutboxDraft; bootstrap: BootstrapPayload}>(
        '/api/outbox',
        {
          ...payload,
          action,
          simulateUncertain: options?.simulateUncertain,
          simulateFailure: options?.simulateFailure,
        },
      ),
    );
    this.data.set(res.bootstrap);

    if (action === 'schedule_delay' && res.draft.status === 'delayed_pending') {
      const delayMs = Math.max(1000, (res.draft.sendDelaySeconds || 10) * 1000);
      const existingTimer = this.delayTimers.get(res.draft.id);
      if (existingTimer) clearTimeout(existingTimer);
      const timer = setTimeout(() => {
        this.delayTimers.delete(res.draft.id);
        void this.submitDelayedDraftNow(res.draft.id);
      }, delayMs);
      this.delayTimers.set(res.draft.id, timer);
      this.pushNotification(
        'Send delay active',
        `Scheduled local delay (${res.draft.sendDelaySeconds}s). Click Undo to cancel before submission.`,
        'info',
      );
    } else if (res.draft.status === 'submitted') {
      this.pushNotification('Message submitted', res.draft.deliveryNote, 'success');
    } else if (res.draft.status === 'queued_offline') {
      this.pushNotification(
        'Queued offline (not sent)',
        res.draft.deliveryNote,
        'warning',
      );
    } else if (res.draft.status === 'uncertain_outcome') {
      this.pushNotification(
        'Submission outcome uncertain',
        res.draft.deliveryNote,
        'warning',
      );
    } else if (res.draft.status === 'failed') {
      this.pushNotification(
        'Send failed',
        res.draft.lastError ?? res.draft.deliveryNote,
        'error',
      );
    }

    return res.draft;
  }

  async cancelDelayedDraft(draftId: string): Promise<OutboxDraft> {
    const timer = this.delayTimers.get(draftId);
    if (timer) {
      clearTimeout(timer);
      this.delayTimers.delete(draftId);
    }
    const res = await firstValueFrom(
      this.http.post<{draft: OutboxDraft; bootstrap: BootstrapPayload}>(
        `/api/outbox/${draftId}/cancel`,
        {},
      ),
    );
    this.data.set(res.bootstrap);
    this.activeDraft.set(res.draft);
    this.composerOpen.set(true);
    this.pushNotification(
      'Send cancelled before submission',
      'Local delay was cancelled and draft reopened.',
      'success',
    );
    return res.draft;
  }

  async submitDelayedDraftNow(
    draftId: string,
    options?: {simulateUncertain?: boolean; simulateFailure?: boolean},
  ): Promise<OutboxDraft> {
    const timer = this.delayTimers.get(draftId);
    if (timer) {
      clearTimeout(timer);
      this.delayTimers.delete(draftId);
    }
    const res = await firstValueFrom(
      this.http.post<{draft: OutboxDraft; bootstrap: BootstrapPayload}>(
        `/api/outbox/${draftId}/submit`,
        options ?? {},
      ),
    );
    this.data.set(res.bootstrap);
    if (res.draft.status === 'submitted') {
      this.pushNotification('Message submitted', res.draft.deliveryNote, 'success');
    } else if (res.draft.status === 'uncertain_outcome') {
      this.pushNotification(
        'Uncertain submission outcome',
        res.draft.deliveryNote,
        'warning',
      );
    }
    return res.draft;
  }

  async syncAccount(
    accountId: string,
    options?: {forceResetUidValidity?: boolean; simulateFailure?: boolean},
  ): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{account: Account; note: string; bootstrap: BootstrapPayload}>(
        `/api/sync/${accountId}`,
        options ?? {},
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification(
      res.account.syncStatus === 'error' ? 'Sync error' : 'Sync complete',
      res.note,
      res.account.syncStatus === 'error' ? 'error' : 'success',
    );
  }

  async toggleOfflineMode(offline: boolean): Promise<void> {
    await this.updatePreferences({offlineModeSimulated: offline});
    if (!offline) {
      const res = await firstValueFrom(
        this.http.post<{reconciledCount: number; bootstrap: BootstrapPayload}>(
          '/api/offline/reconcile',
          {},
        ),
      );
      this.data.set(res.bootstrap);
      this.pushNotification(
        'Reconnected & reconciled',
        `Reconciled ${res.reconciledCount} queued offline operation(s) and outbox items.`,
        'success',
      );
    } else {
      this.pushNotification(
        'Simulated offline mode active',
        'Edits and sends are queued locally and will NOT be marked sent until reconnected.',
        'warning',
      );
    }
  }

  async purgeAccountCache(accountId: string): Promise<string> {
    const res = await firstValueFrom(
      this.http.delete<{explanation: string; bootstrap: BootstrapPayload}>(
        `/api/accounts/${accountId}/cache`,
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification('Local cache purged', res.explanation, 'info');
    return res.explanation;
  }

  async createEvent(payload: Record<string, unknown>): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{event: CalendarEvent; bootstrap: BootstrapPayload}>(
        '/api/events',
        payload,
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification(
      res.event.invitationStatus === 'invitation_sent'
        ? 'Meeting invitation sent'
        : 'Appointment saved locally',
      res.event.title,
      'success',
    );
  }

  async editEvent(
    eventId: string,
    updates: Partial<CalendarEvent>,
    scope: 'this_occurrence' | 'entire_series',
    occurrenceOriginalStartUtc?: string,
  ): Promise<void> {
    const res = await firstValueFrom(
      this.http.patch<{event: CalendarEvent; bootstrap: BootstrapPayload}>(
        `/api/events/${eventId}`,
        {updates, scope, occurrenceOriginalStartUtc},
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification(
      scope === 'this_occurrence'
        ? 'Occurrence exception saved'
        : 'Series updated',
      res.event.title,
      'success',
    );
  }

  async respondToEvent(
    eventId: string,
    response: 'accepted' | 'tentative' | 'declined',
  ): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{event: CalendarEvent; bootstrap: BootstrapPayload}>(
        `/api/events/${eventId}/respond`,
        {response},
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification(
      `RSVP: ${response}`,
      res.event.title,
      'success',
    );
  }

  async importIcs(icsText: string, accountId: string, calendarId: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{imported: CalendarEvent[]; bootstrap: BootstrapPayload}>(
        '/api/events/import/ics',
        {icsText, accountId, calendarId},
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification(
      'Calendar imported',
      `Imported ${res.imported.length} event(s) from ICS.`,
      'success',
    );
  }

  async createTask(payload: Partial<TaskItem>): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{task: TaskItem; bootstrap: BootstrapPayload}>(
        '/api/tasks',
        payload,
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification('Task created', res.task.title, 'success');
  }

  async createTaskFromMessage(msg: SanitizedClientMessage): Promise<void> {
    await this.createTask({
      accountId: msg.accountId,
      listName: 'Work Follow-ups',
      title: `Follow up: ${msg.subject}`,
      notes: `Linked from ${msg.from.name} <${msg.from.email}>: ${msg.snippet}`,
      dueDate: msg.followUpDate ?? '2026-11-16',
      priority: msg.isFlagged ? 'high' : 'normal',
      isMyDay: true,
      linkedMessageId: msg.id,
    });
  }

  async updateTask(taskId: string, patch: Partial<TaskItem>): Promise<void> {
    const res = await firstValueFrom(
      this.http.patch<{task: TaskItem; bootstrap: BootstrapPayload}>(
        `/api/tasks/${taskId}`,
        patch,
      ),
    );
    this.data.set(res.bootstrap);
  }

  async deleteTask(taskId: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.delete<{bootstrap: BootstrapPayload}>(`/api/tasks/${taskId}`),
    );
    this.data.set(res.bootstrap);
  }

  async createContact(payload: Partial<ContactRecord>): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{contact: ContactRecord; bootstrap: BootstrapPayload}>(
        '/api/contacts',
        payload,
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification('Contact saved', res.contact.displayName, 'success');
  }

  async updateContact(
    contactId: string,
    patch: Partial<ContactRecord>,
  ): Promise<void> {
    const res = await firstValueFrom(
      this.http.patch<{contact: ContactRecord; bootstrap: BootstrapPayload}>(
        `/api/contacts/${contactId}`,
        patch,
      ),
    );
    this.data.set(res.bootstrap);
  }

  async mergeContacts(primaryId: string, duplicateId: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{contact: ContactRecord; bootstrap: BootstrapPayload}>(
        '/api/contacts/merge',
        {primaryId, duplicateId},
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification(
      'Duplicate contacts merged',
      `Merged into ${res.contact.displayName} while preserving linked history.`,
      'success',
    );
  }

  async saveSearch(name: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{saved: SavedSearch; bootstrap: BootstrapPayload}>(
        '/api/saved-searches',
        {
          name,
          query: this.searchQuery(),
          accountId:
            this.selectedAccountId() === 'all' ? null : this.selectedAccountId(),
          hasAttachment: this.searchHasAttachment(),
          category: this.searchCategory(),
        },
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification('Saved search created', res.saved.name, 'success');
  }

  async createRule(payload: Partial<MailRule>): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{rule: MailRule; bootstrap: BootstrapPayload}>(
        '/api/rules',
        payload,
      ),
    );
    this.data.set(res.bootstrap);
    this.pushNotification('Rule created', res.rule.name, 'success');
  }

  async toggleRule(ruleId: string, enabled: boolean): Promise<void> {
    const res = await firstValueFrom(
      this.http.patch<{rule: MailRule; bootstrap: BootstrapPayload}>(
        `/api/rules/${ruleId}`,
        {enabled},
      ),
    );
    this.data.set(res.bootstrap);
  }

  async runRulesNow(messageId?: string): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{
        matchedCount: number;
        notifications: string[];
        bootstrap: BootstrapPayload;
      }>('/api/rules/run', {messageId}),
    );
    this.data.set(res.bootstrap);
    this.pushNotification(
      'Application rules executed',
      `Processed ${res.matchedCount} matching message(s).`,
      'success',
    );
  }

  async runCopilotAssist(payload: {
    actionType: AiActionRecord['actionType'];
    messageIds?: string[];
    draftText?: string;
    targetLanguage?: string;
    tone?: 'concise' | 'executive' | 'warm' | 'formal';
    query?: string;
  }): Promise<AiActionRecord> {
    const res = await firstValueFrom(
      this.http.post<{record: AiActionRecord; bootstrap: BootstrapPayload}>(
        '/api/copilot/assist',
        payload,
      ),
    );
    this.data.set(res.bootstrap);
    return res.record;
  }

  async decideCopilotApproval(
    recordId: string,
    decision: 'approved' | 'rejected',
  ): Promise<void> {
    const res = await firstValueFrom(
      this.http.post<{record: AiActionRecord; bootstrap: BootstrapPayload}>(
        `/api/copilot/approvals/${recordId}`,
        {decision},
      ),
    );
    this.data.set(res.bootstrap);
    if (decision === 'approved' && res.record.proposedAction?.kind === 'insert_draft') {
      const msgId = String(
        res.record.proposedAction.payload['replyToMessageId'] ?? '',
      );
      const sourceMsg = this.messages().find((m) => m.id === msgId);
      const bodyText = String(
        res.record.proposedAction.payload['bodyText'] ?? res.record.resultText,
      );
      if (sourceMsg) {
        this.openReplyComposer(sourceMsg, 'reply');
        this.activeDraft.update((d) =>
          d
            ? {
                ...d,
                bodyText,
                bodyHtml: `<p>${bodyText.replace(/\n/g, '<br/>')}</p>`,
              }
            : d,
        );
      } else {
        this.openNewComposer({
          bodyText,
          bodyHtml: `<p>${bodyText.replace(/\n/g, '<br/>')}</p>`,
        });
      }
    }
    this.pushNotification(
      `Copilot proposal ${decision}`,
      res.record.proposedAction?.summary ?? res.record.actionType,
      decision === 'approved' ? 'success' : 'info',
    );
  }

  async resetDemoData(): Promise<void> {
    this.loading.set(true);
    try {
      const payload = await firstValueFrom(
        this.http.post<BootstrapPayload>('/api/demo/reset', {}),
      );
      this.data.set(payload);
      this.selectedMessageId.set(payload.messages[0]?.id ?? null);
      this.remoteImageAllowedIds.set(new Set());
      this.pushNotification(
        'Demonstration workspace reset',
        'Restored fresh synthetic accounts, messages, meetings, and tasks.',
        'info',
      );
    } finally {
      this.loading.set(false);
    }
  }
}
