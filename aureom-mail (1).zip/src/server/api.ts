import {Router} from 'express';
import {redactSensitiveForLogs} from '../shared/security';
import type {
  AiActionRecord,
  CalendarEvent,
  ContactRecord,
  MailRule,
  OutboxDraft,
  TaskItem,
  UserPreferences,
} from '../shared/types';
import {getAllProviderCapabilities, getProviderAdapter} from './adapters';
import {copilotService} from './copilot';
import {AureomDatabase, searchService} from './db';

export function createApiRouter(db: AureomDatabase): Router {
  const router = Router();

  const buildSanitizedBootstrap = () => {
    const state = db.getState();
    const allowRemote = !state.preferences.blockRemoteImages;
    return {
      ...state,
      messages: state.messages.map((m) =>
        db.getSanitizedMessageView(m, allowRemote),
      ),
      providerCapabilities: getAllProviderCapabilities(),
    };
  };

  router.get('/health', (_req, res) => {
    res.json({status: 'ok', service: 'aureom-mail-api'});
  });

  router.get('/bootstrap', (_req, res) => {
    res.json(buildSanitizedBootstrap());
  });

  router.post('/demo/reset', (_req, res) => {
    db.resetDemo();
    res.json(buildSanitizedBootstrap());
  });

  router.patch('/preferences', (req, res) => {
    const state = db.getState();
    const patch = req.body as Partial<UserPreferences>;
    state.preferences = {...state.preferences, ...patch};
    db.save();
    res.json({preferences: state.preferences});
  });

  router.post('/folders', (req, res) => {
    try {
      const {accountId, name, parentId} = req.body as {
        accountId: string;
        name: string;
        parentId?: string | null;
      };
      if (!name?.trim()) {
        res.status(400).json({error: 'Folder name is required.'});
        return;
      }
      const folder = db.createFolder(accountId, name, parentId ?? null);
      res.status(201).json(folder);
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  router.get('/messages/:id', (req, res) => {
    const state = db.getState();
    const msg = state.messages.find((m) => m.id === req.params.id);
    if (!msg) {
      res.status(404).json({error: 'Message not found'});
      return;
    }
    if (
      !db.checkSharedPermission(msg.accountId, state.currentUserEmail, 'canRead')
    ) {
      res.status(403).json({error: 'Access denied for shared mailbox'});
      return;
    }
    const allowRemote =
      req.query['allowRemoteImages'] === 'true' ||
      !state.preferences.blockRemoteImages;
    res.json(db.getSanitizedMessageView(msg, allowRemote));
  });

  router.patch('/messages/bulk', (req, res) => {
    const state = db.getState();
    const {
      messageIds,
      action,
      value,
    } = req.body as {
      messageIds: string[];
      action:
        | 'mark_read'
        | 'mark_unread'
        | 'flag'
        | 'unflag'
        | 'pin'
        | 'unpin'
        | 'snooze'
        | 'unsnooze'
        | 'move_folder'
        | 'add_category'
        | 'remove_category'
        | 'archive'
        | 'delete';
      value?: string;
    };

    if (!Array.isArray(messageIds) || messageIds.length === 0) {
      res.status(400).json({error: 'messageIds array required'});
      return;
    }

    const updated: string[] = [];
    for (const id of messageIds) {
      const msg = state.messages.find((m) => m.id === id);
      if (!msg) continue;

      if (
        (action === 'move_folder' || action === 'archive' || action === 'delete') &&
        !db.checkSharedPermission(msg.accountId, state.currentUserEmail, 'canFile')
      ) {
        res.status(403).json({
          error: `Permission denied: lacking filing access on ${msg.accountId}`,
        });
        return;
      }

      if (action === 'mark_read') msg.isRead = true;
      else if (action === 'mark_unread') msg.isRead = false;
      else if (action === 'flag') {
        msg.isFlagged = true;
        msg.followUpDate = value ?? msg.followUpDate ?? '2026-11-16';
      } else if (action === 'unflag') {
        msg.isFlagged = false;
        msg.followUpDate = null;
      } else if (action === 'pin') msg.isPinned = true;
      else if (action === 'unpin') msg.isPinned = false;
      else if (action === 'snooze') {
        msg.snoozedUntil = value ?? '2026-11-16T09:00:00.000Z';
      } else if (action === 'unsnooze') {
        msg.snoozedUntil = null;
      } else if (action === 'move_folder' && value) {
        const folder = state.folders.find(
          (f) => f.id === value && f.accountId === msg.accountId,
        );
        if (folder) msg.folderId = folder.id;
      } else if (action === 'archive') {
        const archive = state.folders.find(
          (f) => f.accountId === msg.accountId && f.role === 'archive',
        );
        if (archive) msg.folderId = archive.id;
      } else if (action === 'delete') {
        const deleted = state.folders.find(
          (f) => f.accountId === msg.accountId && f.role === 'deleted',
        );
        if (deleted && msg.folderId !== deleted.id) {
          msg.folderId = deleted.id;
        } else {
          state.messages = state.messages.filter((m) => m.id !== msg.id);
        }
      } else if (action === 'add_category' && value) {
        if (!msg.categories.includes(value)) msg.categories.push(value);
      } else if (action === 'remove_category' && value) {
        msg.categories = msg.categories.filter((c) => c !== value);
      }

      msg.version += 1;
      updated.push(msg.id);
    }

    if (state.preferences.offlineModeSimulated) {
      state.offlineQueue.push({
        id: `oq_${Date.now().toString(36)}`,
        createdAt: new Date().toISOString(),
        kind:
          action === 'move_folder' || action === 'archive'
            ? 'move_folder'
            : action === 'flag'
              ? 'flag'
              : 'mark_read',
        description: `Offline pending: ${action} on ${updated.length} message(s)`,
        payload: {messageIds: updated, action, value},
        status: 'pending',
        retryCount: 0,
      });
    }

    db.save();
    res.json({
      updatedIds: updated,
      bootstrap: buildSanitizedBootstrap(),
    });
  });

  router.post('/messages/:id/notes', (req, res) => {
    const state = db.getState();
    const msg = state.messages.find((m) => m.id === req.params.id);
    if (!msg) {
      res.status(404).json({error: 'Message not found'});
      return;
    }
    const {text, assignedTo} = req.body as {
      text?: string;
      assignedTo?: string | null;
    };
    if (assignedTo !== undefined) {
      msg.assignedTo = assignedTo;
    }
    if (text?.trim()) {
      msg.internalNotes.push({
        id: `note_${Date.now().toString(36)}`,
        authorEmail: state.currentUserEmail,
        authorName: 'Alex Mercer',
        text: text.trim(),
        createdAt: new Date().toISOString(),
      });
    }
    msg.version += 1;
    db.save();
    res.json(db.getSanitizedMessageView(msg, !state.preferences.blockRemoteImages));
  });

  router.post('/outbox', async (req, res) => {
    try {
      const body = req.body as Partial<OutboxDraft> & {
        accountId: string;
        action?: 'save_draft' | 'schedule_delay' | 'send_now';
        simulateUncertain?: boolean;
        simulateFailure?: boolean;
      };
      const draft = db.upsertOutboxDraft(body);

      if (body.action === 'schedule_delay') {
        const delaySec = Math.max(0, draft.sendDelaySeconds || 10);
        draft.status = 'delayed_pending';
        draft.delayedUntil = new Date(Date.now() + delaySec * 1000).toISOString();
        draft.deliveryNote = `Local send delay active (${delaySec}s). Cancel before submission to prevent sending.`;
        db.save();
        res.json({draft, bootstrap: buildSanitizedBootstrap()});
        return;
      }

      if (body.action === 'send_now') {
        const submitted = await db.submitOutboxDraft(draft.id, {
          simulateUncertain: body.simulateUncertain,
          simulateFailure: body.simulateFailure,
        });
        res.json({draft: submitted, bootstrap: buildSanitizedBootstrap()});
        return;
      }

      res.json({draft, bootstrap: buildSanitizedBootstrap()});
    } catch (err) {
      const message = (err as Error).message;
      if (message === 'CONFLICT_OUTBOX_VERSION') {
        res.status(409).json({
          error:
            'Optimistic concurrency conflict: draft was modified elsewhere. Refresh before saving.',
        });
        return;
      }
      res.status(400).json({error: message});
    }
  });

  router.post('/outbox/:id/cancel', (req, res) => {
    try {
      const draft = db.cancelDelayedDraft(req.params.id);
      res.json({draft, bootstrap: buildSanitizedBootstrap()});
    } catch (err) {
      res.status(409).json({error: (err as Error).message});
    }
  });

  router.post('/outbox/:id/submit', async (req, res) => {
    try {
      const {simulateUncertain, simulateFailure} = (req.body ?? {}) as {
        simulateUncertain?: boolean;
        simulateFailure?: boolean;
      };
      const draft = await db.submitOutboxDraft(req.params.id, {
        simulateUncertain,
        simulateFailure,
      });
      res.json({draft, bootstrap: buildSanitizedBootstrap()});
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  router.delete('/outbox/:id', (req, res) => {
    const state = db.getState();
    state.outbox = state.outbox.filter((d) => d.id !== req.params.id);
    db.save();
    res.json({bootstrap: buildSanitizedBootstrap()});
  });

  router.post('/sync/:accountId', async (req, res) => {
    try {
      const {forceResetUidValidity, simulateFailure} = (req.body ?? {}) as {
        forceResetUidValidity?: boolean;
        simulateFailure?: boolean;
      };
      const result = await db.syncAccount(req.params.accountId, {
        forceResetUidValidity,
        simulateFailure,
      });
      res.json({
        account: result.account,
        note: result.note,
        bootstrap: buildSanitizedBootstrap(),
      });
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  router.delete('/accounts/:accountId/cache', (req, res) => {
    try {
      const result = db.purgeAccountLocalCache(req.params.accountId);
      res.json({
        ...result,
        bootstrap: buildSanitizedBootstrap(),
      });
    } catch (err) {
      res.status(404).json({error: (err as Error).message});
    }
  });

  router.post('/offline/reconcile', async (_req, res) => {
    const state = db.getState();
    state.preferences.offlineModeSimulated = false;

    for (const op of state.offlineQueue) {
      if (op.status === 'pending') {
        op.status = 'reconciled';
      }
    }

    for (const draft of state.outbox) {
      if (draft.status === 'queued_offline') {
        await db.submitOutboxDraft(draft.id);
      }
    }

    for (const acc of state.accounts) {
      if (acc.syncStatus === 'offline') {
        await db.syncAccount(acc.id);
      }
    }

    db.save();
    res.json({
      reconciledCount: state.offlineQueue.length,
      bootstrap: buildSanitizedBootstrap(),
    });
  });

  // Calendar endpoints
  router.post('/events', (req, res) => {
    try {
      const event = db.createCalendarEvent(
        req.body as Parameters<AureomDatabase['createCalendarEvent']>[0],
      );
      res.status(201).json({event, bootstrap: buildSanitizedBootstrap()});
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  router.patch('/events/:id', (req, res) => {
    try {
      const {scope, occurrenceOriginalStartUtc, updates} = req.body as {
        scope?: 'this_occurrence' | 'entire_series';
        occurrenceOriginalStartUtc?: string;
        updates: Partial<CalendarEvent>;
      };
      const event = db.editCalendarEvent(
        req.params.id,
        updates,
        scope ?? 'entire_series',
        occurrenceOriginalStartUtc,
      );
      res.json({event, bootstrap: buildSanitizedBootstrap()});
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  router.post('/events/:id/respond', (req, res) => {
    const state = db.getState();
    const ev = state.events.find((e) => e.id === req.params.id);
    if (!ev) {
      res.status(404).json({error: 'Event not found'});
      return;
    }
    const {response} = req.body as {
      response: 'accepted' | 'tentative' | 'declined';
    };
    ev.myResponse = response;
    const me = ev.attendees.find(
      (a) => a.email.toLowerCase() === state.currentUserEmail.toLowerCase(),
    );
    if (me) {
      me.response = response;
    }
    ev.version += 1;
    db.save();
    res.json({event: ev, bootstrap: buildSanitizedBootstrap()});
  });

  router.get('/events/export/ics', (_req, res) => {
    const ics = db.exportEventsToIcs();
    res.setHeader('Content-Type', 'text/calendar; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="aureom-calendar.ics"',
    );
    res.send(ics);
  });

  router.post('/events/import/ics', (req, res) => {
    const state = db.getState();
    const {icsText, accountId, calendarId} = req.body as {
      icsText: string;
      accountId?: string;
      calendarId?: string;
    };
    if (!icsText?.trim()) {
      res.status(400).json({error: 'ICS content is required'});
      return;
    }
    const imported = db.importEventsFromIcs(
      icsText,
      accountId ?? state.accounts[0]?.id ?? 'acc_work',
      calendarId ?? state.calendars[0]?.id ?? 'cal_work',
    );
    res.json({imported, bootstrap: buildSanitizedBootstrap()});
  });

  router.post('/availability', async (req, res) => {
    const state = db.getState();
    const {accountId, attendeeEmails, startUtc, endUtc} = req.body as {
      accountId: string;
      attendeeEmails: string[];
      startUtc: string;
      endUtc: string;
    };
    const account = state.accounts.find((a) => a.id === accountId);
    if (!account) {
      res.status(404).json({error: 'Account not found'});
      return;
    }
    const adapter = getProviderAdapter(account.provider);
    const availability = await adapter.fetchAvailability(
      account,
      attendeeEmails ?? [],
      startUtc,
      endUtc,
      state.events,
    );
    res.json({
      supportsAvailability: adapter.capabilities.supportsAvailability,
      providerLabel: adapter.capabilities.label,
      availability,
    });
  });

  // Contacts endpoints
  router.post('/contacts', (req, res) => {
    const state = db.getState();
    const payload = req.body as Partial<ContactRecord>;
    const contact: ContactRecord = {
      id: `con_${Date.now().toString(36)}`,
      accountId: payload.accountId ?? 'acc_work',
      displayName: payload.displayName?.trim() || 'New Contact',
      firstName: payload.firstName ?? '',
      lastName: payload.lastName ?? '',
      emails: payload.emails ?? [],
      phones: payload.phones ?? [],
      organization: payload.organization ?? '',
      jobTitle: payload.jobTitle ?? '',
      notes: payload.notes ?? '',
      categories: payload.categories ?? [],
      isFavourite: Boolean(payload.isFavourite),
      trustLevel: payload.trustLevel ?? 'saved_contact',
      mergedFromIds: [],
      updatedAt: new Date().toISOString(),
    };
    state.contacts.unshift(contact);
    db.save();
    res.status(201).json({contact, bootstrap: buildSanitizedBootstrap()});
  });

  router.patch('/contacts/:id', (req, res) => {
    const state = db.getState();
    const contact = state.contacts.find((c) => c.id === req.params.id);
    if (!contact) {
      res.status(404).json({error: 'Contact not found'});
      return;
    }
    Object.assign(contact, req.body, {updatedAt: new Date().toISOString()});
    db.save();
    res.json({contact, bootstrap: buildSanitizedBootstrap()});
  });

  router.post('/contacts/merge', (req, res) => {
    try {
      const {primaryId, duplicateId} = req.body as {
        primaryId: string;
        duplicateId: string;
      };
      const merged = db.mergeDuplicateContacts(primaryId, duplicateId);
      res.json({contact: merged, bootstrap: buildSanitizedBootstrap()});
    } catch (err) {
      res.status(400).json({error: (err as Error).message});
    }
  });

  // Tasks endpoints
  router.post('/tasks', (req, res) => {
    const state = db.getState();
    const payload = req.body as Partial<TaskItem>;
    const task: TaskItem = {
      id: `tsk_${Date.now().toString(36)}`,
      listName: payload.listName ?? 'Work Follow-ups',
      accountId: payload.accountId ?? 'acc_work',
      title: payload.title?.trim() || 'Untitled task',
      notes: payload.notes ?? '',
      dueDate: payload.dueDate ?? null,
      reminderAt: payload.reminderAt ?? null,
      priority: payload.priority ?? 'normal',
      status: payload.status ?? 'todo',
      completedAt: null,
      isMyDay: payload.isMyDay ?? true,
      isRecurring: Boolean(payload.isRecurring),
      recurrencePattern: payload.recurrencePattern ?? null,
      checklist: payload.checklist ?? [],
      linkedMessageId: payload.linkedMessageId ?? null,
      linkedEventId: payload.linkedEventId ?? null,
      createdAt: new Date().toISOString(),
      version: 1,
    };
    state.tasks.unshift(task);
    db.save();
    res.status(201).json({task, bootstrap: buildSanitizedBootstrap()});
  });

  router.patch('/tasks/:id', (req, res) => {
    const state = db.getState();
    const task = state.tasks.find((t) => t.id === req.params.id);
    if (!task) {
      res.status(404).json({error: 'Task not found'});
      return;
    }
    const patch = req.body as Partial<TaskItem>;
    Object.assign(task, patch, {version: task.version + 1});
    if (patch.status === 'completed' && !task.completedAt) {
      task.completedAt = new Date().toISOString();
    } else if (patch.status && patch.status !== 'completed') {
      task.completedAt = null;
    }
    db.save();
    res.json({task, bootstrap: buildSanitizedBootstrap()});
  });

  router.delete('/tasks/:id', (req, res) => {
    const state = db.getState();
    state.tasks = state.tasks.filter((t) => t.id !== req.params.id);
    db.save();
    res.json({bootstrap: buildSanitizedBootstrap()});
  });

  // Permission-aware search
  router.get('/search', (req, res) => {
    const state = db.getState();
    const authorizedAccountIds = db.getAuthorizedAccountIds(
      state.currentUserEmail,
    );
    const results = searchService.search(state, {
      query: String(req.query['q'] ?? ''),
      accountId: req.query['accountId'] ? String(req.query['accountId']) : null,
      folderId: req.query['folderId'] ? String(req.query['folderId']) : null,
      category: req.query['category'] ? String(req.query['category']) : null,
      hasAttachment: req.query['hasAttachment'] === 'true',
      authorizedAccountIds,
    });
    res.json({
      ...results,
      messages: results.messages.map((m) =>
        db.getSanitizedMessageView(m, !state.preferences.blockRemoteImages),
      ),
    });
  });

  router.post('/saved-searches', (req, res) => {
    const state = db.getState();
    const {name, query, accountId, hasAttachment, category} = req.body as {
      name: string;
      query: string;
      accountId?: string | null;
      hasAttachment?: boolean;
      category?: string | null;
    };
    const saved = {
      id: `srch_${Date.now().toString(36)}`,
      name: name.trim(),
      query,
      accountId: accountId ?? null,
      hasAttachment: Boolean(hasAttachment),
      category: category ?? null,
    };
    state.savedSearches.push(saved);
    db.save();
    res.status(201).json({saved, bootstrap: buildSanitizedBootstrap()});
  });

  // Rules endpoints
  router.post('/rules', (req, res) => {
    const state = db.getState();
    const payload = req.body as Partial<MailRule>;
    const hasUnconfirmedForward = (payload.actions ?? []).some(
      (a) => a.type === 'forward_explicit' && !a.explicitForwardConfirmed,
    );
    if (hasUnconfirmedForward) {
      res.status(400).json({
        error:
          'External forwarding rules require explicit user confirmation before creation.',
      });
      return;
    }
    const rule: MailRule = {
      id: `rul_${Date.now().toString(36)}`,
      name: payload.name?.trim() || 'New Mail Rule',
      accountId: payload.accountId ?? 'acc_work',
      scope: payload.scope ?? 'application',
      enabled: payload.enabled ?? true,
      priority: payload.priority ?? state.rules.length + 1,
      stopProcessing: Boolean(payload.stopProcessing),
      conditions: payload.conditions ?? [],
      actions: payload.actions ?? [],
      loopGuardCount: 0,
      lastRunAt: null,
    };
    state.rules.push(rule);
    db.save();
    res.status(201).json({rule, bootstrap: buildSanitizedBootstrap()});
  });

  router.patch('/rules/:id', (req, res) => {
    const state = db.getState();
    const rule = state.rules.find((r) => r.id === req.params.id);
    if (!rule) {
      res.status(404).json({error: 'Rule not found'});
      return;
    }
    Object.assign(rule, req.body);
    db.save();
    res.json({rule, bootstrap: buildSanitizedBootstrap()});
  });

  router.post('/rules/run', (req, res) => {
    const state = db.getState();
    const {messageId} = req.body as {messageId?: string};
    const targets = messageId
      ? state.messages.filter((m) => m.id === messageId)
      : state.messages;

    const notifications: string[] = [];
    let matchedCount = 0;
    for (const msg of targets) {
      const outcome = db.evaluateRulesForMessage(msg);
      if (outcome.appliedRuleIds.length > 0) {
        matchedCount += 1;
      }
      notifications.push(...outcome.notifications);
    }

    res.json({
      matchedCount,
      notifications,
      bootstrap: buildSanitizedBootstrap(),
    });
  });

  // Aureom Copilot endpoints
  router.post('/copilot/assist', async (req, res) => {
    const controller = new AbortController();
    req.on('close', () => controller.abort());
    try {
      const state = db.getState();
      const body = req.body as {
        actionType: AiActionRecord['actionType'];
        messageIds?: string[];
        draftText?: string;
        targetLanguage?: string;
        tone?: 'concise' | 'executive' | 'warm' | 'formal';
        query?: string;
      };
      const record = await copilotService.assist(
        db,
        {
          ...body,
          userEmail: state.currentUserEmail,
        },
        controller.signal,
      );
      res.json({
        record,
        bootstrap: buildSanitizedBootstrap(),
      });
    } catch (err) {
      console.error('Copilot error:', redactSensitiveForLogs(String(err)));
      res.status(400).json({error: (err as Error).message});
    }
  });

  router.post('/copilot/approvals/:id', (req, res) => {
    const state = db.getState();
    const record = state.aiHistory.find((r) => r.id === req.params.id);
    if (!record) {
      res.status(404).json({error: 'AI action record not found'});
      return;
    }
    const {decision} = req.body as {decision: 'approved' | 'rejected'};
    record.approvalStatus = decision;

    if (decision === 'approved' && record.proposedAction) {
      const p = record.proposedAction;
      if (p.kind === 'create_task') {
        const payload = p.payload;
        state.tasks.unshift({
          id: `tsk_${Date.now().toString(36)}`,
          listName: 'Work Follow-ups',
          accountId: String(payload['accountId'] ?? 'acc_work'),
          title: String(payload['title'] ?? 'Copilot Extracted Task'),
          notes: `Created via approved Aureom Copilot extraction (${record.id}).`,
          dueDate: String(payload['dueDate'] ?? '2026-11-16'),
          reminderAt: null,
          priority: 'high',
          status: 'todo',
          completedAt: null,
          isMyDay: true,
          isRecurring: false,
          recurrencePattern: null,
          checklist: [],
          linkedMessageId: payload['linkedMessageId']
            ? String(payload['linkedMessageId'])
            : null,
          linkedEventId: null,
          createdAt: new Date().toISOString(),
          version: 1,
        });
      } else if (p.kind === 'apply_filing') {
        const msgId = String(p.payload['messageId'] ?? '');
        const category = String(p.payload['category'] ?? 'Architecture');
        const msg = state.messages.find((m) => m.id === msgId);
        if (msg && !msg.categories.includes(category)) {
          msg.categories.push(category);
        }
      }
    }

    db.save();
    res.json({record, bootstrap: buildSanitizedBootstrap()});
  });

  return router;
}
