import type {
  Account,
  CalendarEvent,
  EmailMessage,
  OutboxDraft,
  ProviderType,
} from '../shared/types';

export interface ProviderCapabilities {
  provider: ProviderType;
  label: string;
  isSimulated: boolean;
  supportsOAuth: boolean;
  supportsNestedFolders: boolean;
  supportsLabels: boolean;
  supportsDeltaSync: boolean;
  supportsUidValidity: boolean;
  supportsAvailability: boolean;
  supportsProviderRules: boolean;
  rateLimitPerMinute: number;
}

export interface SyncBatchResult {
  accountId: string;
  syncedAt: string;
  newDeltaToken?: string;
  newHistoryId?: string;
  newUidValidity?: number;
  newHighestModSeq?: string;
  fetchedCount: number;
  note: string;
}

export interface SubmissionResult {
  outcome: 'submitted' | 'uncertain_outcome' | 'failed';
  providerMessageId?: string;
  deliveryNote: string;
  error?: string;
}

export interface ProviderAdapter {
  readonly capabilities: ProviderCapabilities;
  syncAccount(
    account: Account,
    options?: {forceResetUidValidity?: boolean; simulateFailure?: boolean},
  ): Promise<SyncBatchResult>;
  submitDraft(
    account: Account,
    draft: OutboxDraft,
    options?: {simulateUncertain?: boolean; simulateFailure?: boolean},
  ): Promise<SubmissionResult>;
  fetchAvailability(
    account: Account,
    attendeeEmails: string[],
    startUtc: string,
    endUtc: string,
    events: CalendarEvent[],
  ): Promise<Record<string, 'free' | 'busy' | 'tentative'>>;
}

class MockMicrosoftGraphAdapter implements ProviderAdapter {
  readonly capabilities: ProviderCapabilities = {
    provider: 'microsoft_graph',
    label: 'Microsoft Graph (Simulated Adapter)',
    isSimulated: true,
    supportsOAuth: true,
    supportsNestedFolders: true,
    supportsLabels: false,
    supportsDeltaSync: true,
    supportsUidValidity: false,
    supportsAvailability: true,
    supportsProviderRules: true,
    rateLimitPerMinute: 120,
  };

  async syncAccount(
    account: Account,
    options?: {simulateFailure?: boolean},
  ): Promise<SyncBatchResult> {
    if (options?.simulateFailure) {
      throw new Error(
        'Microsoft Graph 429 Too Many Requests (simulated rate-limit backoff required).',
      );
    }
    const nextToken = `delta_graph_${Date.now().toString(36)}`;
    return {
      accountId: account.id,
      syncedAt: new Date().toISOString(),
      newDeltaToken: nextToken,
      fetchedCount: 0,
      note: 'Incremental delta sync completed via simulated Microsoft Graph adapter.',
    };
  }

  async submitDraft(
    account: Account,
    draft: OutboxDraft,
    options?: {simulateUncertain?: boolean; simulateFailure?: boolean},
  ): Promise<SubmissionResult> {
    if (options?.simulateFailure) {
      return {
        outcome: 'failed',
        deliveryNote: 'Submission rejected before provider handoff.',
        error: 'Simulated Graph 503 Service Unavailable.',
      };
    }
    if (options?.simulateUncertain) {
      return {
        outcome: 'uncertain_outcome',
        deliveryNote:
          'Connection timed out after transmitting payload to Microsoft Graph. Submission outcome is uncertain — verify Sent folder before retrying to prevent duplicates.',
      };
    }
    return {
      outcome: 'submitted',
      providerMessageId: `<graph-${draft.idempotencyKey}@meridian-demo.org>`,
      deliveryNote: `Accepted by Microsoft Graph sendMail API for ${account.email}. Acceptance confirms provider handoff, not recipient read status.`,
    };
  }

  async fetchAvailability(
    _account: Account,
    attendeeEmails: string[],
    startUtc: string,
    endUtc: string,
    events: CalendarEvent[],
  ): Promise<Record<string, 'free' | 'busy' | 'tentative'>> {
    const startMs = new Date(startUtc).getTime();
    const endMs = new Date(endUtc).getTime();
    const result: Record<string, 'free' | 'busy' | 'tentative'> = {};

    for (const email of attendeeEmails) {
      let state: 'free' | 'busy' | 'tentative' = 'free';
      for (const ev of events) {
        const evStart = new Date(ev.startUtc).getTime();
        const evEnd = new Date(ev.endUtc).getTime();
        const overlaps = startMs < evEnd && endMs > evStart;
        if (!overlaps) continue;
        const att = ev.attendees.find(
          (a) => a.email.toLowerCase() === email.toLowerCase(),
        );
        if (
          att?.response === 'accepted' ||
          ev.organizer.email.toLowerCase() === email.toLowerCase()
        ) {
          state = 'busy';
          break;
        }
        if (att?.response === 'tentative') {
          state = 'tentative';
        }
      }
      result[email] = state;
    }
    return result;
  }
}

class MockGmailApiAdapter implements ProviderAdapter {
  readonly capabilities: ProviderCapabilities = {
    provider: 'gmail_api',
    label: 'Gmail API (Simulated Adapter)',
    isSimulated: true,
    supportsOAuth: true,
    supportsNestedFolders: false,
    supportsLabels: true,
    supportsDeltaSync: true,
    supportsUidValidity: false,
    supportsAvailability: false,
    supportsProviderRules: true,
    rateLimitPerMinute: 250,
  };

  async syncAccount(
    account: Account,
    options?: {simulateFailure?: boolean},
  ): Promise<SyncBatchResult> {
    if (options?.simulateFailure) {
      throw new Error(
        'Gmail OAuth access token expired and refresh returned invalid_grant (simulated).',
      );
    }
    const nextHistory = String(Number(account.historyId ?? '8841209') + 1);
    return {
      accountId: account.id,
      syncedAt: new Date().toISOString(),
      newHistoryId: nextHistory,
      fetchedCount: 0,
      note: `Incremental history.list sync completed (historyId ${nextHistory}).`,
    };
  }

  async submitDraft(
    account: Account,
    draft: OutboxDraft,
    options?: {simulateUncertain?: boolean; simulateFailure?: boolean},
  ): Promise<SubmissionResult> {
    if (options?.simulateFailure) {
      return {
        outcome: 'failed',
        deliveryNote: 'Gmail API returned 400 Bad Request (simulated).',
        error: 'Simulated recipient validation failure.',
      };
    }
    if (options?.simulateUncertain) {
      return {
        outcome: 'uncertain_outcome',
        deliveryNote:
          'Socket closed mid-response after Gmail messages.send call. Check Sent label before retrying.',
      };
    }
    return {
      outcome: 'submitted',
      providerMessageId: `<gmail-${draft.idempotencyKey}@aureom-demo.org>`,
      deliveryNote: `Submitted via Gmail API for ${account.email}. Submission does not verify recipient inbox placement or read receipt.`,
    };
  }

  async fetchAvailability(
    _account: Account,
    attendeeEmails: string[],
  ): Promise<Record<string, 'free' | 'busy' | 'tentative'>> {
    const map: Record<string, 'free' | 'busy' | 'tentative'> = {};
    for (const email of attendeeEmails) {
      map[email] = 'free';
    }
    return map;
  }
}

class MockImapSmtpAdapter implements ProviderAdapter {
  readonly capabilities: ProviderCapabilities = {
    provider: 'imap_smtp',
    label: 'IMAP / SMTP (Simulated Adapter)',
    isSimulated: true,
    supportsOAuth: false,
    supportsNestedFolders: true,
    supportsLabels: false,
    supportsDeltaSync: true,
    supportsUidValidity: true,
    supportsAvailability: false,
    supportsProviderRules: false,
    rateLimitPerMinute: 60,
  };

  async syncAccount(
    account: Account,
    options?: {forceResetUidValidity?: boolean; simulateFailure?: boolean},
  ): Promise<SyncBatchResult> {
    if (options?.simulateFailure) {
      throw new Error(
        `IMAP UIDVALIDITY changed on folder INBOX (expected ${account.uidValidity ?? 10441}, server reported ${(account.uidValidity ?? 10441) + 1}).`,
      );
    }
    const nextUidValidity = options?.forceResetUidValidity
      ? (account.uidValidity ?? 10441) + 1
      : (account.uidValidity ?? 10441);
    const nextModSeq = String(Number(account.highestModSeq ?? '77201') + 2);
    return {
      accountId: account.id,
      syncedAt: new Date().toISOString(),
      newUidValidity: nextUidValidity,
      newHighestModSeq: nextModSeq,
      fetchedCount: 0,
      note: `IMAP mailbox UIDVALIDITY ${nextUidValidity} reconciled cleanly (HIGHESTMODSEQ ${nextModSeq}).`,
    };
  }

  async submitDraft(
    account: Account,
    draft: OutboxDraft,
    options?: {simulateUncertain?: boolean; simulateFailure?: boolean},
  ): Promise<SubmissionResult> {
    if (options?.simulateFailure) {
      return {
        outcome: 'failed',
        deliveryNote: 'SMTP AUTH / 550 relay rejected (simulated).',
        error: 'Simulated SMTP 550 temporary policy rejection.',
      };
    }
    if (options?.simulateUncertain) {
      return {
        outcome: 'uncertain_outcome',
        deliveryNote:
          'SMTP connection dropped right after DATA terminator (CRLF.CRLF). Server acceptance is unconfirmed — inspect Sent mailbox before resending.',
      };
    }
    return {
      outcome: 'submitted',
      providerMessageId: `<smtp-${draft.idempotencyKey}@aureom-demo.org>`,
      deliveryNote: `SMTP 250 2.0.0 OK queued for delivery by ${account.email} relay. SMTP acceptance is not proof of recipient delivery or read.`,
    };
  }

  async fetchAvailability(
    _account: Account,
    attendeeEmails: string[],
  ): Promise<Record<string, 'free' | 'busy' | 'tentative'>> {
    const map: Record<string, 'free' | 'busy' | 'tentative'> = {};
    for (const email of attendeeEmails) {
      map[email] = 'tentative';
    }
    return map;
  }
}

export class MockConferencingAdapter {
  createMeetingLink(title: string): string {
    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 28);
    const suffix = Math.random().toString(36).slice(2, 6);
    return `https://meet.aureom-demo.org/r/${slug || 'room'}-${suffix}`;
  }
}

const adapters: Record<ProviderType, ProviderAdapter> = {
  microsoft_graph: new MockMicrosoftGraphAdapter(),
  gmail_api: new MockGmailApiAdapter(),
  imap_smtp: new MockImapSmtpAdapter(),
};

export function getProviderAdapter(provider: ProviderType): ProviderAdapter {
  return adapters[provider];
}

export function getAllProviderCapabilities(): ProviderCapabilities[] {
  return Object.values(adapters).map((a) => a.capabilities);
}

export const conferencingAdapter = new MockConferencingAdapter();

export function buildStorageCompositeKey(message: EmailMessage): string {
  // Never rely solely on internetMessageId (can collide across folders/copies/malformed senders)
  return `${message.accountId}:${message.folderId}:${message.uidValidity}:${message.providerUid}`;
}
