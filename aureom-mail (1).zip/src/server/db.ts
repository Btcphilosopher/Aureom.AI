import {existsSync, mkdirSync, readFileSync, renameSync, writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {
  analyzeSenderAuthenticity,
  redactSensitiveForLogs,
  sanitizeEmailHtml,
} from '../shared/security';
import {localDateTimeToUtcIso} from '../shared/timezone';
import type {
  Account,
  CalendarEvent,
  ContactRecord,
  EmailAttachment,
  EmailMessage,
  MailFolder,
  OutboxDraft,
  TaskItem,
  WorkspaceBootstrap,
} from '../shared/types';
import {conferencingAdapter, getProviderAdapter} from './adapters';
import {createDemoSeed} from './seed';

export interface SearchQuery {
  query: string;
  accountId?: string | null;
  folderId?: string | null;
  category?: string | null;
  hasAttachment?: boolean;
  fromDate?: string | null;
  toDate?: string | null;
  authorizedAccountIds: string[];
}

export interface SearchResults {
  messages: EmailMessage[];
  attachments: EmailAttachment[];
  contacts: ContactRecord[];
  events: CalendarEvent[];
  tasks: TaskItem[];
  searchEngine: 'local_fts_boundary' | 'postgres_fts';
}

export interface SearchService {
  search(db: WorkspaceBootstrap, params: SearchQuery): SearchResults;
}

/**
 * Permission-aware full-text search service boundary.
 * Mirrors PostgreSQL tsvector/tsquery semantics locally while maintaining a clean
 * interface for swapping in a dedicated PostgreSQL FTS adapter.
 */
export class LocalFtsSearchService implements SearchService {
  search(db: WorkspaceBootstrap, params: SearchQuery): SearchResults {
    const allowed = new Set(params.authorizedAccountIds);
    const terms = params.query
      .trim()
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean);

    const matchesText = (haystack: string): boolean => {
      if (terms.length === 0) return true;
      const lower = haystack.toLowerCase();
      return terms.every((t) => lower.includes(t));
    };

    const messages = db.messages.filter((m) => {
      if (!allowed.has(m.accountId)) return false;
      if (params.accountId && m.accountId !== params.accountId) return false;
      if (params.folderId && m.folderId !== params.folderId) return false;
      if (params.category && !m.categories.includes(params.category))
        return false;
      if (params.hasAttachment && m.attachments.length === 0) return false;
      if (params.fromDate && m.receivedAt < params.fromDate) return false;
      if (params.toDate && m.receivedAt > params.toDate + 'T23:59:59Z')
        return false;

      const corpus = [
        m.subject,
        m.bodyText,
        m.from.name,
        m.from.email,
        ...m.to.map((p) => `${p.name} ${p.email}`),
        ...m.categories,
        ...m.attachments.map((a) => a.filename),
      ].join(' ');
      return matchesText(corpus);
    });

    const attachments = db.messages
      .filter((m) => allowed.has(m.accountId))
      .filter((m) => !params.accountId || m.accountId === params.accountId)
      .flatMap((m) => m.attachments)
      .filter((att) => matchesText(`${att.filename} ${att.contentPreview}`));

    const contacts = db.contacts.filter((c) => {
      if (!allowed.has(c.accountId)) return false;
      if (params.accountId && c.accountId !== params.accountId) return false;
      return matchesText(
        `${c.displayName} ${c.organization} ${c.jobTitle} ${c.emails.map((e) => e.address).join(' ')}`,
      );
    });

    const events = db.events.filter((e) => {
      if (!allowed.has(e.accountId)) return false;
      if (params.accountId && e.accountId !== params.accountId) return false;
      return matchesText(
        `${e.title} ${e.description} ${e.location} ${e.attendees.map((a) => `${a.name} ${a.email}`).join(' ')}`,
      );
    });

    const tasks = db.tasks.filter((t) => {
      if (!allowed.has(t.accountId)) return false;
      if (params.accountId && t.accountId !== params.accountId) return false;
      return matchesText(`${t.title} ${t.notes} ${t.listName}`);
    });

    return {
      messages,
      attachments,
      contacts,
      events,
      tasks,
      searchEngine: 'local_fts_boundary',
    };
  }
}

export const searchService: SearchService = new LocalFtsSearchService();

export class AureomDatabase {
  private dataDir: string;
  private dbPath: string;
  private state: WorkspaceBootstrap;
  private persistToDisk: boolean;
  private submittedIdempotencyKeys = new Set<string>();

  constructor(options?: {dataDir?: string; persistToDisk?: boolean}) {
    this.dataDir =
      options?.dataDir ??
      process.env['AUREOM_DATA_DIR'] ??
      join(process.cwd(), '.data');
    this.dbPath = join(this.dataDir, 'aureom-db.json');
    this.persistToDisk = options?.persistToDisk ?? true;
    this.state = this.loadOrInitialize();
    for (const draft of this.state.outbox) {
      if (draft.status === 'submitted') {
        this.submittedIdempotencyKeys.add(draft.idempotencyKey);
      }
    }
  }

  private loadOrInitialize(): WorkspaceBootstrap {
    if (this.persistToDisk && existsSync(this.dbPath)) {
      try {
        const raw = readFileSync(this.dbPath, 'utf-8');
        const parsed = JSON.parse(raw) as WorkspaceBootstrap;
        return this.migrateSchema(parsed);
      } catch (err) {
        console.warn(
          'Failed to load existing DB, re-seeding:',
          redactSensitiveForLogs(String(err)),
        );
      }
    }
    const seeded = createDemoSeed();
    this.recomputeFolderCounts(seeded);
    if (this.persistToDisk) {
      this.writeState(seeded);
    }
    return seeded;
  }

  private migrateSchema(data: WorkspaceBootstrap): WorkspaceBootstrap {
    const migrated = {...data};
    if (!migrated.schemaVersion || migrated.schemaVersion < 2) {
      migrated.schemaVersion = 2;
      migrated.offlineQueue = migrated.offlineQueue ?? [];
      migrated.aiHistory = migrated.aiHistory ?? [];
      migrated.aiTokenBudgetLimit = migrated.aiTokenBudgetLimit ?? 50000;
      migrated.aiTokensUsed = migrated.aiTokensUsed ?? 0;
    }
    this.recomputeFolderCounts(migrated);
    return migrated;
  }

  private writeState(nextState: WorkspaceBootstrap): void {
    if (!this.persistToDisk) return;
    try {
      if (!existsSync(this.dataDir)) {
        mkdirSync(this.dataDir, {recursive: true});
      }
      const tmpPath = `${this.dbPath}.tmp`;
      writeFileSync(tmpPath, JSON.stringify(nextState, null, 2), 'utf-8');
      renameSync(tmpPath, this.dbPath);
    } catch (err) {
      console.warn(
        'Disk persistence skipped:',
        redactSensitiveForLogs(String(err)),
      );
    }
  }

  save(): void {
    this.recomputeFolderCounts(this.state);
    this.writeState(this.state);
  }

  getState(): WorkspaceBootstrap {
    return this.state;
  }

  resetDemo(): WorkspaceBootstrap {
    this.submittedIdempotencyKeys.clear();
    this.state = createDemoSeed();
    this.save();
    return this.state;
  }

  getAuthorizedAccountIds(userEmail: string): string[] {
    return this.state.accounts
      .filter((acc) => {
        if (acc.kind !== 'shared_mailbox') return true;
        const perm = this.state.sharedPermissions.find(
          (p) =>
            p.accountId === acc.id &&
            p.userEmail.toLowerCase() === userEmail.toLowerCase(),
        );
        return Boolean(perm?.canRead);
      })
      .map((a) => a.id);
  }

  checkSharedPermission(
    accountId: string,
    userEmail: string,
    capability: 'canRead' | 'canFile' | 'canReply' | 'canSendAs' | 'canManageRules',
  ): boolean {
    const account = this.state.accounts.find((a) => a.id === accountId);
    if (!account) return false;
    if (account.kind !== 'shared_mailbox') return true;
    const perm = this.state.sharedPermissions.find(
      (p) =>
        p.accountId === accountId &&
        p.userEmail.toLowerCase() === userEmail.toLowerCase(),
    );
    return Boolean(perm?.[capability]);
  }

  recomputeFolderCounts(target: WorkspaceBootstrap = this.state): void {
    const folderStats = new Map<string, {unread: number; total: number}>();
    for (const f of target.folders) {
      folderStats.set(f.id, {unread: 0, total: 0});
    }
    for (const m of target.messages) {
      const stat = folderStats.get(m.folderId);
      if (stat) {
        stat.total += 1;
        if (!m.isRead) stat.unread += 1;
      }
    }
    for (const f of target.folders) {
      const stat = folderStats.get(f.id);
      if (stat) {
        f.unreadCount = stat.unread;
        f.totalCount = stat.total;
      }
    }
    for (const acc of target.accounts) {
      const inboxFolders = target.folders.filter(
        (f) => f.accountId === acc.id && f.role === 'inbox',
      );
      acc.unreadCount = inboxFolders.reduce((sum, f) => sum + f.unreadCount, 0);
    }
  }

  getSanitizedMessageView(
    message: EmailMessage,
    allowRemoteImages: boolean,
  ): EmailMessage & {
    bodyHtmlSanitized: string;
    hasRemoteImages: boolean;
    blockedImageCount: number;
    suspiciousLinks: {displayText: string; href: string}[];
  } {
    const sanitized = sanitizeEmailHtml(message.bodyHtmlRaw, {
      allowRemoteImages,
    });
    return {
      ...message,
      bodyHtmlSanitized: sanitized.html,
      hasRemoteImages: sanitized.hasRemoteImages,
      blockedImageCount: sanitized.blockedImageCount,
      suspiciousLinks: sanitized.suspiciousLinks,
    };
  }

  createFolder(
    accountId: string,
    name: string,
    parentId: string | null,
  ): MailFolder {
    const account = this.state.accounts.find((a) => a.id === accountId);
    if (!account) throw new Error('Account not found');
    const parent = parentId
      ? this.state.folders.find((f) => f.id === parentId)
      : null;
    const prefix = parent ? `${parent.providerPathOrLabel}/` : '';
    const folder: MailFolder = {
      id: `fld_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
      accountId,
      parentId,
      name: name.trim(),
      role: 'custom',
      providerPathOrLabel: `${prefix}${name.trim()}`,
      uidValidity: account.uidValidity,
      unreadCount: 0,
      totalCount: 0,
      order:
        this.state.folders.filter((f) => f.accountId === accountId).length + 1,
    };
    this.state.folders.push(folder);
    this.save();
    return folder;
  }

  async syncAccount(
    accountId: string,
    options?: {forceResetUidValidity?: boolean; simulateFailure?: boolean},
  ): Promise<{account: Account; note: string}> {
    const account = this.state.accounts.find((a) => a.id === accountId);
    if (!account) throw new Error('Account not found');

    if (this.state.preferences.offlineModeSimulated) {
      account.syncStatus = 'offline';
      account.lastSyncError =
        'Workspace is currently in simulated offline mode. Reconnect to sync.';
      this.save();
      return {account, note: account.lastSyncError};
    }

    const adapter = getProviderAdapter(account.provider);
    try {
      const result = await adapter.syncAccount(account, options);
      account.syncStatus = 'synced';
      account.lastSyncedAt = result.syncedAt;
      account.lastSyncError = null;
      if (result.newDeltaToken) account.deltaToken = result.newDeltaToken;
      if (result.newHistoryId) account.historyId = result.newHistoryId;
      if (result.newUidValidity) account.uidValidity = result.newUidValidity;
      if (result.newHighestModSeq)
        account.highestModSeq = result.newHighestModSeq;
      this.save();
      return {account, note: result.note};
    } catch (err) {
      account.syncStatus = 'error';
      account.lastSyncError =
        err instanceof Error ? err.message : 'Sync failed';
      this.save();
      return {account, note: account.lastSyncError};
    }
  }

  upsertOutboxDraft(
    payload: Partial<OutboxDraft> & {accountId: string},
  ): OutboxDraft {
    const now = new Date().toISOString();
    const existing = payload.id
      ? this.state.outbox.find((d) => d.id === payload.id)
      : undefined;

    if (existing) {
      if (
        payload.version !== undefined &&
        payload.version !== existing.version
      ) {
        throw new Error('CONFLICT_OUTBOX_VERSION');
      }
      Object.assign(existing, payload, {
        updatedAt: now,
        version: existing.version + 1,
      });
      this.save();
      return existing;
    }

    const account = this.state.accounts.find((a) => a.id === payload.accountId);
    if (!account) throw new Error('Account not found');

    const created: OutboxDraft = {
      id:
        payload.id ??
        `out_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
      accountId: payload.accountId,
      sendAsAddress: payload.sendAsAddress ?? account.email,
      replyToMessageId: payload.replyToMessageId ?? null,
      forwardMessageId: payload.forwardMessageId ?? null,
      mode: payload.mode ?? 'new',
      to: payload.to ?? [],
      cc: payload.cc ?? [],
      bcc: payload.bcc ?? [],
      subject: payload.subject ?? '',
      bodyHtml: payload.bodyHtml ?? '',
      bodyText: payload.bodyText ?? '',
      isRichText: payload.isRichText ?? true,
      attachments: payload.attachments ?? [],
      inlineImages: payload.inlineImages ?? [],
      scheduledFor: payload.scheduledFor ?? null,
      sendDelaySeconds:
        payload.sendDelaySeconds ??
        this.state.preferences.defaultSendDelaySeconds,
      delayedUntil: payload.delayedUntil ?? null,
      status: payload.status ?? 'draft',
      idempotencyKey:
        payload.idempotencyKey ??
        `idem_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
      retryCount: 0,
      lastError: null,
      deliveryNote: payload.deliveryNote ?? 'Saved as local draft.',
      updatedAt: now,
      version: 1,
    };

    this.state.outbox.unshift(created);
    this.save();
    return created;
  }

  async submitOutboxDraft(
    draftId: string,
    options?: {simulateUncertain?: boolean; simulateFailure?: boolean},
  ): Promise<OutboxDraft> {
    const draft = this.state.outbox.find((d) => d.id === draftId);
    if (!draft) throw new Error('Draft not found');

    // Prevent duplicate sends via idempotency key tracking
    if (
      draft.status === 'submitted' ||
      this.submittedIdempotencyKeys.has(draft.idempotencyKey)
    ) {
      draft.status = 'submitted';
      draft.deliveryNote =
        'Duplicate send prevented by idempotency key; original submission already succeeded.';
      this.save();
      return draft;
    }

    if (
      !this.checkSharedPermission(
        draft.accountId,
        this.state.currentUserEmail,
        'canSendAs',
      )
    ) {
      draft.status = 'failed';
      draft.lastError =
        'Permission denied: current user lacks Send-As delegation for this mailbox.';
      this.save();
      return draft;
    }

    if (this.state.preferences.offlineModeSimulated) {
      draft.status = 'queued_offline';
      draft.deliveryNote =
        'Queued in durable offline outbox. This message has NOT been sent yet.';
      draft.updatedAt = new Date().toISOString();
      this.save();
      return draft;
    }

    const account = this.state.accounts.find((a) => a.id === draft.accountId);
    if (!account) throw new Error('Account not found');

    const adapter = getProviderAdapter(account.provider);
    const result = await adapter.submitDraft(account, draft, options);

    draft.updatedAt = new Date().toISOString();
    draft.version += 1;

    if (result.outcome === 'submitted') {
      draft.status = 'submitted';
      draft.lastError = null;
      draft.deliveryNote = result.deliveryNote;
      this.submittedIdempotencyKeys.add(draft.idempotencyKey);

      // Record Sent folder copy
      const sentFolder = this.state.folders.find(
        (f) => f.accountId === account.id && f.role === 'sent',
      );
      if (sentFolder) {
        const sanitized = sanitizeEmailHtml(draft.bodyHtml, {
          allowRemoteImages: true,
        });
        const newMsg: EmailMessage = {
          id: `msg_${Date.now().toString(36)}`,
          threadId:
            (draft.replyToMessageId &&
              this.state.messages.find((m) => m.id === draft.replyToMessageId)
                ?.threadId) ??
            `thr_${Date.now().toString(36)}`,
          accountId: account.id,
          folderId: sentFolder.id,
          providerUid: Math.floor(Math.random() * 9000) + 6000,
          uidValidity: account.uidValidity ?? 1,
          internetMessageId:
            result.providerMessageId ?? `<${draft.idempotencyKey}@aureom-demo.org>`,
          from: {name: account.displayName, email: draft.sendAsAddress},
          replyTo: null,
          to: draft.to,
          cc: draft.cc,
          bcc: draft.bcc,
          subject: draft.subject || '(No subject)',
          snippet: draft.bodyText.slice(0, 140),
          bodyHtmlRaw: sanitized.html || `<p>${draft.bodyText}</p>`,
          bodyText: draft.bodyText,
          isRead: true,
          isFlagged: false,
          followUpDate: null,
          isPinned: false,
          snoozedUntil: null,
          categories: [],
          attachments: draft.attachments.map((a) => ({
            id: a.id,
            messageId: '',
            accountId: account.id,
            filename: a.filename,
            mimeType: a.mimeType,
            sizeBytes: a.sizeBytes,
            contentPreview: a.contentPreview,
            scanStatus: 'clean',
            createdAt: new Date().toISOString(),
          })),
          receivedAt: new Date().toISOString(),
          sentAt: new Date().toISOString(),
          headers: {
            'Message-ID':
              result.providerMessageId ?? `<${draft.idempotencyKey}@aureom-demo.org>`,
            'Authentication-Results': `${account.provider}; spf=pass; dkim=pass; dmarc=pass`,
          },
          authSummary: analyzeSenderAuthenticity(
            {name: account.displayName, email: draft.sendAsAddress},
            null,
            {},
            adapter.capabilities.label,
          ),
          assignedTo: null,
          internalNotes: [],
          version: 1,
        };
        for (const att of newMsg.attachments) {
          att.messageId = newMsg.id;
        }
        this.state.messages.unshift(newMsg);
      }
    } else if (result.outcome === 'uncertain_outcome') {
      draft.status = 'uncertain_outcome';
      draft.deliveryNote = result.deliveryNote;
      draft.lastError =
        'Submission timed out after payload handoff; outcome unconfirmed.';
    } else {
      draft.status = 'failed';
      draft.retryCount += 1;
      draft.lastError = result.error ?? 'Unknown submission error';
      draft.deliveryNote = result.deliveryNote;
    }

    this.save();
    return draft;
  }

  cancelDelayedDraft(draftId: string): OutboxDraft {
    const draft = this.state.outbox.find((d) => d.id === draftId);
    if (!draft) throw new Error('Draft not found');
    if (draft.status === 'submitted') {
      throw new Error(
        'Cannot undo: message was already submitted to the provider. Local undo only cancels before submission.',
      );
    }
    draft.status = 'draft';
    draft.delayedUntil = null;
    draft.scheduledFor = null;
    draft.deliveryNote =
      'Local send delay cancelled before provider submission; returned to Drafts.';
    draft.updatedAt = new Date().toISOString();
    draft.version += 1;
    this.save();
    return draft;
  }

  evaluateRulesForMessage(message: EmailMessage): {
    appliedRuleIds: string[];
    notifications: string[];
  } {
    const sortedRules = [...this.state.rules]
      .filter((r) => r.enabled && r.accountId === message.accountId)
      .sort((a, b) => a.priority - b.priority);

    const appliedRuleIds: string[] = [];
    const notifications: string[] = [];

    for (const rule of sortedRules) {
      if (rule.loopGuardCount > 50) {
        continue;
      }

      const matches = rule.conditions.every((cond) => {
        const val = cond.value.toLowerCase();
        let target = '';
        if (cond.field === 'sender') {
          target = `${message.from.name} ${message.from.email}`.toLowerCase();
        } else if (cond.field === 'recipient') {
          target = message.to.map((p) => p.email).join(' ').toLowerCase();
        } else if (cond.field === 'subject') {
          target = message.subject.toLowerCase();
        } else if (cond.field === 'account') {
          target = message.accountId.toLowerCase();
        }

        if (cond.operator === 'equals') return target === val;
        if (cond.operator === 'endsWith') return target.endsWith(val);
        return target.includes(val);
      });

      if (!matches) continue;

      for (const action of rule.actions) {
        if (action.type === 'apply_category' && action.value) {
          if (!message.categories.includes(action.value)) {
            message.categories.push(action.value);
          }
        } else if (action.type === 'mark_read') {
          message.isRead = true;
        } else if (action.type === 'flag') {
          message.isFlagged = true;
        } else if (action.type === 'move_folder' && action.value) {
          const targetFolder = this.state.folders.find(
            (f) => f.id === action.value && f.accountId === message.accountId,
          );
          if (targetFolder) {
            message.folderId = targetFolder.id;
          }
        } else if (action.type === 'notify') {
          notifications.push(`Rule "${rule.name}" matched "${message.subject}"`);
        } else if (
          action.type === 'forward_explicit' &&
          action.explicitForwardConfirmed &&
          action.value
        ) {
          notifications.push(
            `Rule "${rule.name}" queued explicit forward to ${action.value}`,
          );
        }
      }

      rule.loopGuardCount += 1;
      rule.lastRunAt = new Date().toISOString();
      appliedRuleIds.push(rule.id);

      if (rule.stopProcessing) break;
    }

    this.save();
    return {appliedRuleIds, notifications};
  }

  editCalendarEvent(
    eventId: string,
    updates: Partial<CalendarEvent>,
    scope: 'this_occurrence' | 'entire_series',
    occurrenceOriginalStartUtc?: string,
  ): CalendarEvent {
    const existing = this.state.events.find((e) => e.id === eventId);
    if (!existing) throw new Error('Event not found');

    if (existing.isRecurring && scope === 'this_occurrence') {
      const exceptionDate =
        occurrenceOriginalStartUtc ?? existing.startUtc;
      if (!existing.recurrenceExceptions.includes(exceptionDate)) {
        existing.recurrenceExceptions.push(exceptionDate);
      }

      const startLocal = updates.startLocal ?? existing.startLocal;
      const endLocal = updates.endLocal ?? existing.endLocal;
      const timezone = updates.timezone ?? existing.timezone;
      const exceptionInstance: CalendarEvent = {
        ...existing,
        ...updates,
        id: `evt_exc_${Date.now().toString(36)}`,
        seriesMasterId: existing.id,
        isRecurring: false,
        recurrenceRule: null,
        recurrenceExceptions: [],
        isExceptionInstance: true,
        originalStartUtc: exceptionDate,
        startLocal,
        endLocal,
        timezone,
        startUtc: localDateTimeToUtcIso(startLocal, timezone),
        endUtc: localDateTimeToUtcIso(endLocal, timezone),
        version: 1,
      };
      this.state.events.push(exceptionInstance);
      this.save();
      return exceptionInstance;
    }

    const startLocal = updates.startLocal ?? existing.startLocal;
    const endLocal = updates.endLocal ?? existing.endLocal;
    const timezone = updates.timezone ?? existing.timezone;

    Object.assign(existing, updates, {
      startLocal,
      endLocal,
      timezone,
      startUtc: localDateTimeToUtcIso(startLocal, timezone),
      endUtc: localDateTimeToUtcIso(endLocal, timezone),
      version: existing.version + 1,
    });
    this.save();
    return existing;
  }

  createCalendarEvent(
    payload: Partial<CalendarEvent> & {
      accountId: string;
      calendarId: string;
      title: string;
      startLocal: string;
      endLocal: string;
      timezone: string;
    },
  ): CalendarEvent {
    const account = this.state.accounts.find((a) => a.id === payload.accountId);
    if (!account) throw new Error('Account not found');

    const useMeet = payload.conferencingProvider === 'aureom_meet_mock';
    const created: CalendarEvent = {
      id: `evt_${Date.now().toString(36)}`,
      calendarId: payload.calendarId,
      accountId: payload.accountId,
      seriesMasterId: null,
      isRecurring: Boolean(payload.isRecurring),
      recurrenceRule: payload.recurrenceRule ?? null,
      recurrenceExceptions: [],
      isExceptionInstance: false,
      originalStartUtc: null,
      title: payload.title.trim(),
      description: payload.description ?? '',
      location: payload.location ?? (useMeet ? 'Aureom Meet Room' : ''),
      conferencingProvider: payload.conferencingProvider ?? 'none',
      conferencingUrl: useMeet
        ? conferencingAdapter.createMeetingLink(payload.title)
        : null,
      startLocal: payload.startLocal,
      endLocal: payload.endLocal,
      timezone: payload.timezone,
      startUtc: localDateTimeToUtcIso(payload.startLocal, payload.timezone),
      endUtc: localDateTimeToUtcIso(payload.endLocal, payload.timezone),
      isAllDay: Boolean(payload.isAllDay),
      organizer: {name: account.displayName, email: account.email},
      attendees: payload.attendees ?? [],
      myResponse: 'accepted',
      invitationStatus:
        (payload.attendees?.length ?? 0) > 0 &&
        payload.invitationStatus === 'invitation_sent'
          ? 'invitation_sent'
          : 'local_only',
      reminderMinutes: payload.reminderMinutes ?? 15,
      linkedMessageId: payload.linkedMessageId ?? null,
      version: 1,
    };

    this.state.events.push(created);
    this.save();
    return created;
  }

  exportEventsToIcs(): string {
    const lines = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//Aureom Mail//Workspace Calendar//EN',
    ];
    for (const ev of this.state.events) {
      const dtStart = ev.startUtc.replace(/[-:]/g, '').replace(/\.\d{3}/, '');
      const dtEnd = ev.endUtc.replace(/[-:]/g, '').replace(/\.\d{3}/, '');
      lines.push(
        'BEGIN:VEVENT',
        `UID:${ev.id}@aureom-demo.org`,
        `DTSTART:${dtStart}`,
        `DTEND:${dtEnd}`,
        `SUMMARY:${ev.title.replace(/\n/g, ' ')}`,
        `DESCRIPTION:${ev.description.replace(/\n/g, ' ')}`,
        `LOCATION:${ev.location.replace(/\n/g, ' ')}`,
        'END:VEVENT',
      );
    }
    lines.push('END:VCALENDAR');
    return lines.join('\r\n');
  }

  importEventsFromIcs(
    icsText: string,
    accountId: string,
    calendarId: string,
  ): CalendarEvent[] {
    const blocks = icsText.split('BEGIN:VEVENT').slice(1);
    const created: CalendarEvent[] = [];
    for (const block of blocks) {
      const summary = /SUMMARY:(.*)/i.exec(block)?.[1]?.trim() ?? 'Imported Event';
      const desc = /DESCRIPTION:(.*)/i.exec(block)?.[1]?.trim() ?? '';
      const loc = /LOCATION:(.*)/i.exec(block)?.[1]?.trim() ?? '';
      const dtStartRaw = /DTSTART(?:;[^:]*)?:([0-9TZ]+)/i.exec(block)?.[1];
      const dtEndRaw = /DTEND(?:;[^:]*)?:([0-9TZ]+)/i.exec(block)?.[1];

      const parseIcsDate = (raw?: string, fallbackHour = '09:00') => {
        if (!raw || raw.length < 8) return `2026-11-19T${fallbackHour}`;
        const y = raw.slice(0, 4);
        const m = raw.slice(4, 6);
        const d = raw.slice(6, 8);
        const hh = raw.length >= 11 ? raw.slice(9, 11) : fallbackHour.slice(0, 2);
        const mm = raw.length >= 13 ? raw.slice(11, 13) : fallbackHour.slice(3, 5);
        return `${y}-${m}-${d}T${hh}:${mm}`;
      };

      const ev = this.createCalendarEvent({
        accountId,
        calendarId,
        title: summary,
        description: desc,
        location: loc,
        startLocal: parseIcsDate(dtStartRaw, '09:00'),
        endLocal: parseIcsDate(dtEndRaw, '10:00'),
        timezone: 'UTC',
        invitationStatus: 'local_only',
      });
      created.push(ev);
    }
    return created;
  }

  mergeDuplicateContacts(
    primaryId: string,
    duplicateId: string,
  ): ContactRecord {
    const primary = this.state.contacts.find((c) => c.id === primaryId);
    const duplicate = this.state.contacts.find((c) => c.id === duplicateId);
    if (!primary || !duplicate || primary.id === duplicate.id) {
      throw new Error('Valid primary and duplicate contacts are required.');
    }

    for (const email of duplicate.emails) {
      if (
        !primary.emails.some(
          (e) => e.address.toLowerCase() === email.address.toLowerCase(),
        )
      ) {
        primary.emails.push({...email, isPrimary: false});
      }
    }
    for (const phone of duplicate.phones) {
      if (!primary.phones.some((p) => p.number === phone.number)) {
        primary.phones.push(phone);
      }
    }
    for (const cat of duplicate.categories) {
      if (!primary.categories.includes(cat)) {
        primary.categories.push(cat);
      }
    }
    if (duplicate.notes) {
      primary.notes = primary.notes
        ? `${primary.notes}\nMerged note: ${duplicate.notes}`
        : duplicate.notes;
    }
    primary.mergedFromIds = Array.from(
      new Set([...primary.mergedFromIds, duplicate.id, ...duplicate.mergedFromIds]),
    );
    primary.trustLevel = 'saved_contact';
    primary.updatedAt = new Date().toISOString();

    this.state.contacts = this.state.contacts.filter(
      (c) => c.id !== duplicate.id,
    );
    this.save();
    return primary;
  }

  purgeAccountLocalCache(accountId: string): {
    purgedMessages: number;
    explanation: string;
  } {
    const account = this.state.accounts.find((a) => a.id === accountId);
    if (!account) throw new Error('Account not found');

    const countBefore = this.state.messages.filter(
      (m) => m.accountId === accountId,
    ).length;

    // Clear locally cached attachments previews & mark cache reset while preserving note
    for (const m of this.state.messages) {
      if (m.accountId === accountId) {
        for (const att of m.attachments) {
          att.contentPreview =
            '[Local cached preview cleared — available on re-sync from provider]';
        }
      }
    }
    account.lastSyncError = null;
    this.save();
    return {
      purgedMessages: countBefore,
      explanation: `Cleared local attachment cache for ${account.email} (${countBefore} indexed messages). Deleting local cache does NOT delete messages held on the remote mail provider or recipient mailboxes.`,
    };
  }
}
