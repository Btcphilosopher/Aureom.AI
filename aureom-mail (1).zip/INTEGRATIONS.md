# Aureom Mail — Architecture & Integration Guide

## Overview
Aureom Mail is implemented as a full-stack **Angular 21 + Express SSR + TypeScript + Tailwind CSS v4** workspace with persistent JSON/atomic disk storage (`.data/aureom-db.json`), server-side Gemini AI integration (`@google/genai`), and explicit provider adapter boundaries.

## Startup & Verification Commands
- Install dependencies: `npm install`
- Development server (port 3000): `npm run dev`
- Production build: `npm run build`
- Lint check: `npm run lint`
- Unit & integration test suite: `npx vitest run`

## Provider & Integration Boundaries
1. **Mail & Calendar Providers (`src/server/adapters.ts`)**:
   - `MockMicrosoftGraphAdapter`: Simulates Microsoft Graph delta tokens, availability lookup, and sendMail submission.
   - `MockGmailApiAdapter`: Simulates Gmail API `historyId` incremental sync and label mappings.
   - `MockImapSmtpAdapter`: Simulates IMAP `UIDVALIDITY` + `HIGHESTMODSEQ` tracking, sync error recovery, and SMTP submission outcomes (including uncertain timeouts).
   - `MockConferencingAdapter`: Generates deterministic Aureom Meet URLs when no external conferencing provider is configured.
2. **Database & Search Boundary (`src/server/db.ts`)**:
   - Persistent schema-migrating store (`AureomDatabase`) with optimistic concurrency (`version`), idempotent outbox submission, and `SearchService` / `LocalFtsSearchService` boundary mirroring PostgreSQL FTS permission scoping.
3. **Aureom Copilot (`src/server/copilot.ts`)**:
   - Calls `@google/genai` (`gemini-4-hydrogen`) server-side when `GEMINI_API_KEY` is configured in environment secrets.
   - Automatically falls back to deterministic mock mode when `GEMINI_API_KEY` is unset or offline mode is active.
   - Wraps retrieved email content in `<untrusted_email_content>` delimiters and enforces approval gates before mutating actions.
