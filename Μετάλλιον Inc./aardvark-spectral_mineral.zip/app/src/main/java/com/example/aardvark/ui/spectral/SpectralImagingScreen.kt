package com.example.aardvark.ui.spectral

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.ImagingLayerMode
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.components.SpectrumPlot
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.aardvark.ui.components.TelemetryTile
import com.example.aardvark.ui.hud.ImagingViewport
import com.example.ui.theme.*

@Composable
fun SpectralImagingScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val acquisition by viewModel.acquisition.collectAsState()
  val activeLayer by viewModel.activeLayer.collectAsState()
  val nodules by viewModel.nodulesList.collectAsState()
  val selectedNoduleId by viewModel.selectedNoduleId.collectAsState()
  val selectedCoord by viewModel.selectedCoord.collectAsState()
  val spectralPoints by viewModel.spectralProfile.collectAsState()

  val presets = listOf(
    Pair("530 nm", 530 to "Mn⁴⁺ Oxide Absorption Band"),
    Pair("680 nm", 680 to "Visible Red Baseline"),
    Pair("740 nm", 740 to "Ni-Bearing Smectite Metal-OH"),
    Pair("850 nm", 850 to "Fe³⁺ Oxyhydroxide Crystal Field"),
    Pair("980 nm", 980 to "Deep Subsea H₂O/OH Band")
  )

  Row(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
      .padding(8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Left: Imaging Viewport & False-Color controls
    Column(
      modifier = Modifier
        .weight(1.3f)
        .fillMaxHeight(),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      ImagingViewport(
        activeLayer = activeLayer,
        acquisition = acquisition,
        nodules = nodules,
        selectedNoduleId = selectedNoduleId,
        selectedCoord = selectedCoord,
        onSelectCoordinate = { x, y -> viewModel.selectCoordinate(x, y) },
        onSelectNodule = { viewModel.selectNodule(it) },
        onLayerChange = { viewModel.setImagingLayer(it) },
        onToggleFreeze = { viewModel.toggleFreeze() },
        onCaptureCube = { viewModel.captureSpectralCube() },
        onRequestLaserArm = { viewModel.requestLaserArmToggle() },
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      )

      // Band Presets Row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavyGraphite, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("PRESETS:", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.5.sp)
        presets.forEach { (label, data) ->
          val isSelected = acquisition.activeWavelengthNm == data.first
          Box(
            modifier = Modifier
              .background(if (isSelected) TraceAmber else NavySurface, RoundedCornerShape(2.dp))
              .border(1.dp, if (isSelected) TraceAmber else BorderSubtle, RoundedCornerShape(2.dp))
              .clickable { viewModel.setWavelength(data.first) }
              .padding(horizontal = 6.dp, vertical = 3.dp)
          ) {
            Text(
              text = "$label (${data.second.take(12)}...)",
              color = if (isSelected) GraphiteDark else TextPrimary,
              style = MaterialTheme.typography.labelSmall,
              fontSize = 8.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
          }
        }
      }
    }

    // Right: Detailed Spectral Profile Inspector & Analysis
    Column(
      modifier = Modifier
        .weight(1.1f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "SPECTRAL PROFILE INSPECTOR",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          Text(
            text = "Target: ${selectedNoduleId ?: "COORD [${selectedCoord.first}, ${selectedCoord.second}]"}",
            style = MaterialTheme.typography.labelSmall,
            color = TraceCyan
          )
        }
        TechnicalBadge("SAM SIMILARITY: 0.942", badgeColor = CalibrationGreen)
      }

      // Graph Plot
      SpectrumPlot(
        points = spectralPoints,
        activeWavelengthNm = acquisition.activeWavelengthNm,
        onSelectWavelength = { viewModel.setWavelength(it) },
        modifier = Modifier.fillMaxWidth()
      )

      // Key Quantitative Metrics
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        TelemetryTile(
          label = "Active Wavelength",
          value = "${acquisition.activeWavelengthNm}",
          unit = "nm",
          statusColor = TraceAmber,
          modifier = Modifier.weight(1f)
        )
        TelemetryTile(
          label = "Diffraction Band",
          value = "B${acquisition.spectralBandIndex}",
          unit = "/ 224",
          statusColor = TraceCyan,
          modifier = Modifier.weight(1f)
        )
        TelemetryTile(
          label = "Spectral SNR",
          value = "${acquisition.snrDb}",
          unit = "dB",
          statusColor = CalibrationGreen,
          modifier = Modifier.weight(1f)
        )
      }

      // Spectral Angle Mapper & Mineral Fingerprint Match
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Text("SPECTRAL CLASSIFICATION (USGS / CCZ LIBRARY)", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Primary Match:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Todorokite (Mn,Mg,Ca)Mn₃O₇·H₂O", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Secondary Phase:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Ni-bearing Smectite (0.84% Ni inferred)", style = MaterialTheme.typography.bodySmall, color = PhaseNickel, fontWeight = FontWeight.Bold)
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Spectral Angle (SAM):", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("0.082 rad (High Concordance)", style = MaterialTheme.typography.bodySmall, color = CalibrationGreen)
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Calibration Baseline:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Subsea Spectralon 99% Diffuse Reflector", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
      }

      // Actions
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Button(
          onClick = { viewModel.captureSpectralCube() },
          colors = ButtonDefaults.buttonColors(containerColor = SpectralBlue),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("export_spectrum_button")
        ) {
          Text("LOG SPECTRAL SIGNATURE", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
        }
        OutlinedButton(
          onClick = { viewModel.setImagingLayer(ImagingLayerMode.MINERAL) },
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier.weight(1f)
        ) {
          Text("VIEW MINERAL MAP", color = TextPrimary, fontSize = 9.5.sp)
        }
      }
    }
  }
}
