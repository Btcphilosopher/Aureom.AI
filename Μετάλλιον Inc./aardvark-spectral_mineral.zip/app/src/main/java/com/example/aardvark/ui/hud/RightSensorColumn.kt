package com.example.aardvark.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.CalibrationState
import com.example.aardvark.model.SensorChannelId
import com.example.aardvark.model.SensorChannelStatus
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.ui.theme.*

@Composable
fun RightSensorColumn(
  sensorChannels: List<SensorChannelStatus>,
  onCalibrateChannel: (SensorChannelId) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxHeight()
      .background(GraphiteDark)
      .border(1.dp, BorderSubtle)
      .padding(6.dp)
      .verticalScroll(rememberScrollState())
      .testTag("right_sensor_column"),
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "SENSOR ARRAY CHANNELS",
        style = MaterialTheme.typography.labelSmall,
        color = TextSecondary,
        fontWeight = FontWeight.Bold,
        fontSize = 9.sp
      )
      TechnicalBadge("9/9 ONLINE", badgeColor = CalibrationGreen)
    }

    // List of 9 Sensors
    sensorChannels.forEach { channel ->
      SensorChannelCard(
        channel = channel,
        onCalibrate = { onCalibrateChannel(channel.id) }
      )
    }
  }
}

@Composable
private fun SensorChannelCard(
  channel: SensorChannelStatus,
  onCalibrate: () -> Unit
) {
  val isCalibrated = channel.calibrationStatus == CalibrationState.CALIBRATED
  val isCalibrating = channel.calibrationStatus == CalibrationState.IN_PROGRESS

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(NavySurface, RoundedCornerShape(2.dp))
      .border(
        1.dp,
        if (channel.laserArmed) CriticalRed.copy(alpha = 0.7f) else BorderSubtle,
        RoundedCornerShape(2.dp)
      )
      .padding(6.dp)
      .testTag("sensor_card_${channel.id.name.lowercase()}")
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Box(
          modifier = Modifier
            .size(6.dp)
            .background(
              if (channel.hasFault) CriticalRed
              else if (channel.isConnected) CalibrationGreen
              else WarningOrange,
              RoundedCornerShape(3.dp)
            )
        )
        Text(
          text = channel.id.displayName,
          style = MaterialTheme.typography.labelSmall,
          color = TextPrimary,
          fontWeight = FontWeight.SemiBold,
          fontSize = 9.5.sp
        )
      }
      if (channel.laserArmed) {
        TechnicalBadge("LASER ARMED", badgeColor = CriticalRed)
      } else {
        TechnicalBadge("${channel.frameRateFps} Hz", badgeColor = TraceCyan)
      }
    }

    Spacer(modifier = Modifier.height(2.dp))

    Text(
      text = channel.id.bandInfo,
      style = MaterialTheme.typography.labelSmall,
      color = TextMuted,
      fontSize = 8.sp
    )

    Spacer(modifier = Modifier.height(4.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("T: ${channel.temperatureCelsius}°C", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.5.sp)
        Text("SNR: ${channel.snrDb} dB", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.5.sp)
      }

      // Calibration status or Calibrate button
      if (isCalibrating) {
        Text("CALIBRATING...", style = MaterialTheme.typography.labelSmall, color = TraceAmber, fontSize = 8.sp, fontWeight = FontWeight.Bold)
      } else {
        Box(
          modifier = Modifier
            .background(NavySurfaceElevated, RoundedCornerShape(2.dp))
            .border(1.dp, if (isCalibrated) BorderSubtle else WarningOrange, RoundedCornerShape(2.dp))
            .clickable { onCalibrate() }
            .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
          Text(
            text = if (isCalibrated) "CALIBRATED" else "CALIBRATE",
            style = MaterialTheme.typography.labelSmall,
            color = if (isCalibrated) CalibrationGreen else WarningOrange,
            fontSize = 7.5.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
