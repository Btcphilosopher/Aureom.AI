package com.example.aardvark.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class CalibrationState {
  CALIBRATED,
  EXPIRED,
  UNCALIBRATED,
  IN_PROGRESS
}

enum class AcquisitionState {
  IDLE,
  INITIALISING,
  ACQUIRING,
  PROCESSING,
  SAVING,
  PAUSED,
  FAULT,
  DISCONNECTED
}

enum class SyncState {
  SYNCED,
  PENDING_SYNC,
  LOCAL_ONLY
}

enum class SensorChannelId(val displayName: String, val bandInfo: String) {
  RGB("Optical RGB", "400 - 700 nm"),
  NIR("Near-Infrared", "750 - 1000 nm"),
  SWIR("Short-Wave Infrared", "1000 - 2500 nm"),
  HYPERSPECTRAL("Hyperspectral 224-Band", "400 - 1000 nm (2.7nm res)"),
  RAMAN("Raman Spectroscopy", "532 nm Nd:YAG Laser"),
  INFRARED("Thermal / LWIR", "8 - 14 µm Radiometer"),
  FLUORESCENCE("UV-Induced Fluorescence", "365 nm LED Excitation"),
  SONAR("High-Freq Acoustic SAS", "450 kHz Side-Scan"),
  ELECTROMAGNETIC("Silica Flux EM Induction", "10 kHz - 100 kHz Dipole")
}

enum class ImagingLayerMode(val label: String, val description: String) {
  RGB("Optical RGB", "High-intensity subsea LED illumination"),
  MULTISPECTRAL("Multispectral False-Colour", "800nm / 680nm / 550nm composite"),
  HYPERSPECTRAL("Hyperspectral Cube Slice", "Continuous 224-band diffraction grating"),
  RAMAN("Raman D/G Shift Intensity", "1350/1580 cm⁻¹ in-situ laser excitation"),
  CARBON("Carbon Characterisation", "Carbonaceous and organic probability overlay"),
  FLUORESCENCE("UV Fluorescence 365nm", "Organic fluorophore emission mapping"),
  MINERAL("Mineral Phase Classification", "Supervised spectral angle mapper (SAM)"),
  SONAR("Acoustic Backscatter SAS", "450 kHz acoustic seabed texture"),
  ELECTROMAGNETIC("EM Induction Conductivity", "Apparent conductivity & phase response")
}

data class TelemetryData(
  val depthMeters: Double = 4128.4,
  val altitudeMeters: Double = 3.2,
  val headingDegrees: Float = 214.5f,
  val pitchDegrees: Float = -1.2f,
  val rollDegrees: Float = 0.8f,
  val latitude: Double = 13.23944,
  val longitude: Double = 145.53833,
  val speedKnots: Double = 0.45,
  val batteryPercent: Int = 88,
  val batteryVoltage: Double = 48.2,
  val pressureBar: Double = 418.5,
  val internalTempCelsius: Double = 14.2,
  val timestampUtc: String = "13:58:24 UTC",
  val missionId: String = "MDL-PAC-2026-09A",
  val surveyElapsedTime: String = "03:42:18"
)

data class SensorChannelStatus(
  val id: SensorChannelId,
  val isConnected: Boolean = true,
  val isAcquiring: Boolean = true,
  val temperatureCelsius: Float = 14.1f,
  val frameRateFps: Float = 28.4f,
  val snrDb: Float = 48.6f,
  val calibrationStatus: CalibrationState = CalibrationState.CALIBRATED,
  val hasFault: Boolean = false,
  val faultMessage: String? = null,
  val laserArmed: Boolean = false
)

data class NoduleData(
  val id: String,
  val xRel: Float, // 0.0 - 1.0 within camera viewport
  val yRel: Float,
  val widthMm: Float,
  val heightMm: Float,
  val depthMm: Float,
  val estimatedMassGrams: Float,
  val mineralClassification: String,
  val dominantPhase: String,
  val confidenceScore: Float,
  val surfaceCondition: String,
  val associatedSediment: String,
  val mnPercentEst: Float?,
  val niPercentEst: Float?,
  val cuPercentEst: Float?,
  val coPercentEst: Float?,
  val fePercentEst: Float?,
  val carbonResponse: String,
  val organicProbability: Float,
  val ramanDPeakRatio: Float,
  val sonarBackscatterDb: Float,
  val labAssayStandard: String? = null
)

data class MineralPhaseInfo(
  val name: String,
  val formula: String,
  val phaseColor: Color,
  val typicalConcentration: String,
  val primaryAbsorptionBand: String,
  val confidence: Float
)

data class CarbonAnalysisState(
  val selectedCoord: Pair<Int, Int> = Pair(512, 384),
  val carbonaceousClassification: String = "Amorphous kerogen-like carbon",
  val carbonateClassification: String = "Traces of biogenic calcite (CaCO₃)",
  val organicProbability: Float = 0.38f,
  val ramanDIntensity: Float = 4820f,
  val ramanGIntensity: Float = 6210f,
  val dToGRatio: Float = 0.776f,
  val fluorescenceResponseRfu: Float = 142.5f,
  val confidenceScore: Float = 0.89f,
  val calibrationStatus: String = "Calibrated (Silica-Flux REF-92)",
  val measurementQuality: String = "High (SNR > 42 dB)",
  val quantitativeCarbonStatus: String = "Quantitative carbon concentration: Not established",
  val labValidationNotice: String = "Assay verification required before commercial estimation"
)

data class SpectralPoint(
  val wavelengthNm: Int,
  val reflectance: Float,
  val referenceReflectance: Float,
  val endmemberReflectance: Float,
  val snrDb: Float
)

data class RamanPoint(
  val ramanShiftCm1: Int,
  val intensity: Float,
  val baseline: Float
)

data class SonarData(
  val pingRateHz: Float = 6.0f,
  val frequencyKhz: Float = 450.0f,
  val rangeMeters: Float = 150.0f,
  val altitudeSeabedM: Float = 3.2f,
  val acousticBackscatterMeanDb: Float = -18.4f,
  val detectedObstaclesCount: Int = 14
)

data class EmInductionData(
  val transmitterActive: Boolean = true,
  val operatingFrequencyKhz: Float = 39.2f,
  val receivedAmplitudeMv: Float = 24.8f,
  val phaseLagDegrees: Float = 14.6f,
  val apparentConductivityMsM: Float = 1840.5f, // Sea water ~4000 mS/m, seabed nodule response
  val quadratureResponseMv: Float = 18.2f,
  val signalQualityPercent: Int = 96,
  val measurementConfidence: Float = 0.94f,
  val materialLabel: String = "Subsea Nodule Conductive Response (Material only - not direct carbon)"
)

data class AcquisitionControl(
  val state: AcquisitionState = AcquisitionState.ACQUIRING,
  val activeWavelengthNm: Int = 680,
  val exposureMs: Float = 12.5f,
  val integrationTimeMs: Float = 45.0f,
  val spectralBandIndex: Int = 74,
  val totalBands: Int = 224,
  val frameRateFps: Float = 28.4f,
  val throughputMbSec: Float = 142.0f,
  val snrDb: Float = 48.6f,
  val resolution: String = "2048 x 1536",
  val laserSafetyInterlockArmed: Boolean = false,
  val laserHardwareInterlockEngaged: Boolean = true,
  val activePreset: String = "CCZ Polymetallic Survey Default",
  val freezeFrame: Boolean = false
)

data class SurveyRecord(
  val id: String,
  val name: String,
  val missionId: String,
  val areaName: String,
  val vehicleId: String,
  val startTimeUtc: String,
  val durationMinutes: Int,
  val distanceCoveredKm: Float,
  val nodulesCount: Int,
  val cubesAcquired: Int,
  val syncStatus: SyncState,
  val operatorNotes: String
)
