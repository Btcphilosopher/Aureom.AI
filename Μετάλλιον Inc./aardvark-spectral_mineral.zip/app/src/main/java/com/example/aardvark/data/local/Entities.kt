package com.example.aardvark.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "surveys")
data class SurveyEntity(
  @PrimaryKey val id: String,
  val name: String,
  val missionId: String,
  val areaName: String,
  val vehicleId: String,
  val startTimeUtc: String,
  val durationMinutes: Int,
  val distanceCoveredKm: Float,
  val nodulesCount: Int,
  val cubesAcquired: Int,
  val syncStatus: String,
  val operatorNotes: String
)

@Entity(tableName = "nodules")
data class NoduleEntity(
  @PrimaryKey val id: String,
  val surveyId: String,
  val xRel: Float,
  val yRel: Float,
  val widthMm: Float,
  val heightMm: Float,
  val depthMm: Float,
  val estimatedMassGrams: Float,
  val mineralClassification: String,
  val dominantPhase: String,
  val confidenceScore: Float,
  val surfaceCondition: String,
  val associatedSediment: String,
  val mnPercentEst: Float?,
  val niPercentEst: Float?,
  val cuPercentEst: Float?,
  val coPercentEst: Float?,
  val fePercentEst: Float?,
  val carbonResponse: String,
  val organicProbability: Float,
  val ramanDPeakRatio: Float,
  val sonarBackscatterDb: Float,
  val labAssayStandard: String?,
  val timestampUtc: String
)

@Entity(tableName = "spectral_logs")
data class SpectralLogEntity(
  @PrimaryKey(autoGenerate = true) val localId: Long = 0,
  val surveyId: String,
  val objectId: String,
  val wavelengthMinNm: Int,
  val wavelengthMaxNm: Int,
  val bandCount: Int,
  val targetCoordX: Int,
  val targetCoordY: Int,
  val classificationResult: String,
  val samScore: Float,
  val timestampUtc: String
)
