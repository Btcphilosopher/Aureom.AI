package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AardvarkDarkColorScheme = darkColorScheme(
  primary = SpectralBlue,
  onPrimary = GraphiteDark,
  primaryContainer = NavySurfaceElevated,
  onPrimaryContainer = TextPrimary,
  secondary = AcquisitionAmber,
  onSecondary = GraphiteDark,
  secondaryContainer = NavySurface,
  onSecondaryContainer = TextPrimary,
  tertiary = TraceCyan,
  onTertiary = GraphiteDark,
  background = GraphiteMain,
  onBackground = TextPrimary,
  surface = NavyGraphite,
  onSurface = TextPrimary,
  surfaceVariant = NavySurface,
  onSurfaceVariant = TextSecondary,
  outline = BorderSubtle,
  outlineVariant = BorderHighlight,
  error = CriticalRed,
  onError = TextPrimary
)

@Composable
fun AardvarkSpectralTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = AardvarkDarkColorScheme,
    typography = ScientificTypography,
    content = content
  )
}
