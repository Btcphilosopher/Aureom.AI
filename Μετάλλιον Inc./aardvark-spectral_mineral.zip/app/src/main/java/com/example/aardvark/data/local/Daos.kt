package com.example.aardvark.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SurveyDao {
  @Query("SELECT * FROM surveys ORDER BY startTimeUtc DESC")
  fun getAllSurveys(): Flow<List<SurveyEntity>>

  @Query("SELECT * FROM surveys WHERE id = :id LIMIT 1")
  suspend fun getSurveyById(id: String): SurveyEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSurvey(survey: SurveyEntity)

  @Update
  suspend fun updateSurvey(survey: SurveyEntity)

  @Query("DELETE FROM surveys WHERE id = :id")
  suspend fun deleteSurvey(id: String)
}

@Dao
interface NoduleDao {
  @Query("SELECT * FROM nodules WHERE surveyId = :surveyId ORDER BY id ASC")
  fun getNodulesForSurvey(surveyId: String): Flow<List<NoduleEntity>>

  @Query("SELECT * FROM nodules ORDER BY id ASC")
  fun getAllNodules(): Flow<List<NoduleEntity>>

  @Query("SELECT * FROM nodules WHERE id = :id LIMIT 1")
  suspend fun getNoduleById(id: String): NoduleEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNodules(nodules: List<NoduleEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNodule(nodule: NoduleEntity)

  @Query("DELETE FROM nodules WHERE id = :id")
  suspend fun deleteNodule(id: String)
}

@Dao
interface SpectralDao {
  @Query("SELECT * FROM spectral_logs WHERE surveyId = :surveyId ORDER BY localId DESC")
  fun getSpectralLogsForSurvey(surveyId: String): Flow<List<SpectralLogEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSpectralLog(log: SpectralLogEntity)
}
