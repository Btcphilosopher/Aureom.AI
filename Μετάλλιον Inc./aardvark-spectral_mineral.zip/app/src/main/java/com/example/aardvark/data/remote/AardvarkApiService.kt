package com.example.aardvark.data.remote

import com.squareup.moshi.JsonClass
import retrofit2.Response
import retrofit2.http.*

@JsonClass(generateAdapter = true)
data class SystemStatusDto(
  val fpgaStatus: String,
  val firmwareVersion: String,
  val pcieThroughputMbS: Float,
  val bufferUtilisationPercent: Float,
  val laserInterlockEngaged: Boolean,
  val connectedSensors: Int,
  val errorCount: Int
)

@JsonClass(generateAdapter = true)
data class TelemetryDto(
  val depthMeters: Double,
  val altitudeMeters: Double,
  val headingDegrees: Float,
  val pitchDegrees: Float,
  val rollDegrees: Float,
  val latitude: Double,
  val longitude: Double,
  val speedKnots: Double,
  val batteryPercent: Int,
  val batteryVoltage: Double,
  val pressureBar: Double,
  val internalTempCelsius: Double,
  val timestampUtc: String
)

@JsonClass(generateAdapter = true)
data class NoduleDto(
  val id: String,
  val xRel: Float,
  val yRel: Float,
  val widthMm: Float,
  val heightMm: Float,
  val depthMm: Float,
  val estimatedMassGrams: Float,
  val mineralClassification: String,
  val dominantPhase: String,
  val confidenceScore: Float,
  val surfaceCondition: String,
  val associatedSediment: String,
  val mnPercentEst: Float?,
  val niPercentEst: Float?,
  val cuPercentEst: Float?,
  val coPercentEst: Float?,
  val fePercentEst: Float?,
  val carbonResponse: String,
  val organicProbability: Float,
  val ramanDPeakRatio: Float,
  val sonarBackscatterDb: Float,
  val labAssayStandard: String?
)

@JsonClass(generateAdapter = true)
data class AcquisitionCommandDto(
  val command: String,
  val targetWavelengthNm: Int?,
  val exposureMs: Float?,
  val integrationTimeMs: Float?,
  val profileName: String?
)

@JsonClass(generateAdapter = true)
data class GenericApiResponse(
  val status: String,
  val message: String,
  val timestamp: String
)

interface AardvarkApiService {
  @GET("api/v1/system/status")
  suspend fun getSystemStatus(): Response<SystemStatusDto>

  @GET("api/v1/telemetry/live")
  suspend fun getLiveTelemetry(): Response<TelemetryDto>

  @GET("api/v1/nodules")
  suspend fun getDetectedNodules(): Response<List<NoduleDto>>

  @POST("api/v1/acquisition/control")
  suspend fun sendAcquisitionCommand(@Body command: AcquisitionCommandDto): Response<GenericApiResponse>

  @POST("api/v1/laser/interlock/arm")
  suspend fun armLaserSafetyInterlock(@Query("arm") arm: Boolean): Response<GenericApiResponse>
}
