package com.example.aardvark.ui.geology

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.aardvark.ui.components.TelemetryTile
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Geology3dScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val telemetry by viewModel.telemetry.collectAsState()
  val nodules by viewModel.nodulesList.collectAsState()

  // 3D camera rotation and zoom angles
  var rotX by remember { mutableStateOf(35f) }
  var rotY by remember { mutableStateOf(45f) }
  var zoom by remember { mutableStateOf(1.0f) }

  var showBathymetryMesh by remember { mutableStateOf(true) }
  var showSurveyTrack by remember { mutableStateOf(true) }
  var showNodulesCluster by remember { mutableStateOf(true) }

  Row(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
      .padding(8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Left: 3D Interactive Canvas Viewport
    Box(
      modifier = Modifier
        .weight(1.5f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .testTag("geology_3d_viewport")
    ) {
      Canvas(
        modifier = Modifier
          .fillMaxSize()
          .pointerInput(Unit) {
            detectDragGestures { _, dragAmount ->
              rotY += dragAmount.x * 0.4f
              rotX = (rotX - dragAmount.y * 0.4f).coerceIn(10f, 80f)
            }
          }
      ) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f

        val radX = Math.toRadians(rotX.toDouble())
        val radY = Math.toRadians(rotY.toDouble())

        fun project3D(x: Float, y: Float, z: Float): Offset {
          // Rotate around Y axis
          val x1 = x * cos(radY) + z * sin(radY)
          val z1 = -x * sin(radY) + z * cos(radY)

          // Rotate around X axis
          val y2 = y * cos(radX) - z1 * sin(radX)
          val z2 = y * sin(radX) + z1 * cos(radX)

          // Perspective scaling
          val scale = (400f / (400f + z2.toFloat())) * zoom
          return Offset((cx + x1 * scale).toFloat(), (cy + y2 * scale).toFloat())
        }

        // Draw Subsea Bathymetry Mesh Grid (12x12 grid)
        if (showBathymetryMesh) {
          val gridSteps = 10
          val spacing = 28f

          // Elevation function based on distance
          fun getElev(i: Int, j: Int): Float {
            val dist = kotlin.math.sqrt(((i - 5) * (i - 5) + (j - 5) * (j - 5)).toFloat())
            return (sin(dist * 0.8f) * 14f)
          }

          // Latitude lines
          for (i in -gridSteps / 2..gridSteps / 2) {
            val path = Path()
            for (j in -gridSteps / 2..gridSteps / 2) {
              val x = i * spacing
              val z = j * spacing
              val y = getElev(i, j)
              val pt = project3D(x, y, z)
              if (j == -gridSteps / 2) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
            }
            drawPath(path, color = BorderSubtle.copy(alpha = 0.5f), style = Stroke(1f))
          }

          // Longitude lines
          for (j in -gridSteps / 2..gridSteps / 2) {
            val path = Path()
            for (i in -gridSteps / 2..gridSteps / 2) {
              val x = i * spacing
              val z = j * spacing
              val y = getElev(i, j)
              val pt = project3D(x, y, z)
              if (i == -gridSteps / 2) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
            }
            drawPath(path, color = BorderSubtle.copy(alpha = 0.5f), style = Stroke(1f))
          }
        }

        // Draw ROV Survey Track
        if (showSurveyTrack) {
          val trackPath = Path()
          for (k in -8..6) {
            val tx = k * 18f
            val tz = (sin(k * 0.5f) * 45f)
            val ty = -24f // 3.2m above seabed
            val pt = project3D(tx, ty, tz)
            if (k == -8) trackPath.moveTo(pt.x, pt.y) else trackPath.lineTo(pt.x, pt.y)
          }
          drawPath(trackPath, color = TraceAmber, style = Stroke(2.5f))

          // Current ROV Position Dot
          val rovPt = project3D(6 * 18f, -24f, (sin(6 * 0.5f) * 45f))
          drawCircle(TraceCyan, radius = 6f, center = rovPt)
          drawCircle(Color.White, radius = 3f, center = rovPt)
        }

        // Draw Polymetallic Nodule Clusters in 3D
        if (showNodulesCluster) {
          nodules.forEach { nod ->
            val nx = (nod.xRel - 0.5f) * 240f
            val nz = (nod.yRel - 0.5f) * 240f
            val ny = 0f
            val pt = project3D(nx, ny, nz)
            val isSelected = nod.id == "NOD-0481"
            drawCircle(
              color = if (isSelected) TraceAmber else PhaseManganese,
              radius = if (isSelected) 7f else 4.5f,
              center = pt
            )
          }
        }
      }

      // 3D Viewport HUD Overlay
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .align(Alignment.TopStart)
          .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("3D GEOLOGICAL RECONSTRUCTION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
          Text("Clarion-Clipperton Zone Bathymetry (4,128m)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          IconButton(
            onClick = { rotX = 35f; rotY = 45f; zoom = 1.0f },
            modifier = Modifier.size(28.dp).background(NavySurface, RoundedCornerShape(2.dp)).border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          ) {
            Icon(Icons.Default.Refresh, contentDescription = "Reset Camera", tint = TextPrimary, modifier = Modifier.size(16.dp))
          }
          TechnicalBadge("YAW: ${rotY.toInt()}°  PITCH: ${rotX.toInt()}°", badgeColor = TraceCyan)
        }
      }

      // Gestures Instruction overlay
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .align(Alignment.BottomStart)
          .background(GraphiteDark.copy(alpha = 0.8f))
          .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("DRAG TO ROTATE 3D SEABED  |  ZOOM CONTROLS RIGHT", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.5.sp)
        Text("ROV Altitude: ${telemetry.altitudeMeters}m Above Seabed", style = MaterialTheme.typography.labelSmall, color = CalibrationGreen, fontSize = 8.5.sp)
      }
    }

    // Right: 3D Layer Controls & Geological Metrics
    Column(
      modifier = Modifier
        .weight(0.9f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Text("3D RECONSTRUCTION CONTROLS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)

      // Zoom Slider
      Text("CAMERA ZOOM: ${String.format("%.1f", zoom)}x", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
      Slider(
        value = zoom,
        onValueChange = { zoom = it },
        valueRange = 0.5f..2.5f,
        colors = SliderDefaults.colors(thumbColor = SpectralBlue, activeTrackColor = SpectralBlue),
        modifier = Modifier.height(24.dp)
      )

      // Layer Toggles
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text("ACTIVE 3D LAYERS", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Bathymetry Mesh Grid", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
          Switch(checked = showBathymetryMesh, onCheckedChange = { showBathymetryMesh = it })
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("AUV Track Trajectory", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
          Switch(checked = showSurveyTrack, onCheckedChange = { showSurveyTrack = it })
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Nodule Positions", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
          Switch(checked = showNodulesCluster, onCheckedChange = { showNodulesCluster = it })
        }
      }

      // Geological Area Stats
      TelemetryTile(
        label = "Surveyed Area",
        value = "14,800",
        unit = "m²",
        statusColor = TraceCyan,
        subtext = "Swath Width: 32m"
      )

      TelemetryTile(
        label = "Estimated Nodule Density",
        value = "18.4",
        unit = "kg/m²",
        statusColor = TraceAmber,
        subtext = "High Commercial Viability"
      )

      TelemetryTile(
        label = "Seabed Slope Gradient",
        value = "1.4°",
        unit = "gentle",
        statusColor = CalibrationGreen,
        subtext = "Abyssal Plain Facies"
      )
    }
  }
}
