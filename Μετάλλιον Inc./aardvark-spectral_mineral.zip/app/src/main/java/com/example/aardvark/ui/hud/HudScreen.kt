package com.example.aardvark.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.example.aardvark.ui.WorkstationTab
import com.example.aardvark.ui.WorkstationViewModel
import com.example.ui.theme.GraphiteMain

@Composable
fun HudScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val telemetry by viewModel.telemetry.collectAsState()
  val sensors by viewModel.sensorChannels.collectAsState()
  val acquisition by viewModel.acquisition.collectAsState()
  val activeLayer by viewModel.activeLayer.collectAsState()
  val nodules by viewModel.nodulesList.collectAsState()
  val selectedNoduleId by viewModel.selectedNoduleId.collectAsState()
  val selectedCoord by viewModel.selectedCoord.collectAsState()
  val isSimulated by viewModel.isSimulatedMode.collectAsState()
  val isConnected by viewModel.isConnected.collectAsState()
  val currentTab by viewModel.currentTab.collectAsState()

  val config = LocalConfiguration.current
  val isLandscape = config.screenWidthDp > config.screenHeightDp

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
  ) {
    // 1. Top Instrument Bar
    TopInstrumentBar(
      telemetry = telemetry,
      acquisitionState = acquisition.state,
      isSimulated = isSimulated,
      isConnected = isConnected,
      currentTab = currentTab,
      onSelectTab = { viewModel.setTab(it) }
    )

    // 2. Central Section (Telemetry + Imaging Viewport + Sensors)
    if (isLandscape) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      ) {
        // Left Telemetry Column (220dp)
        LeftTelemetryColumn(
          telemetry = telemetry,
          modifier = Modifier
            .width(220.dp)
            .fillMaxHeight()
        )

        // Center Imaging Viewport (Main flexible space)
        ImagingViewport(
          activeLayer = activeLayer,
          acquisition = acquisition,
          nodules = nodules,
          selectedNoduleId = selectedNoduleId,
          selectedCoord = selectedCoord,
          onSelectCoordinate = { x, y -> viewModel.selectCoordinate(x, y) },
          onSelectNodule = { viewModel.selectNodule(it) },
          onLayerChange = { viewModel.setImagingLayer(it) },
          onToggleFreeze = { viewModel.toggleFreeze() },
          onCaptureCube = { viewModel.captureSpectralCube() },
          onRequestLaserArm = { viewModel.requestLaserArmToggle() },
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
        )

        // Right Sensor Status Column (200dp)
        RightSensorColumn(
          sensorChannels = sensors,
          onCalibrateChannel = { viewModel.calibrateSensor(it) },
          modifier = Modifier
            .width(200.dp)
            .fillMaxHeight()
        )
      }
    } else {
      // Portrait Compact Layout
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      ) {
        ImagingViewport(
          activeLayer = activeLayer,
          acquisition = acquisition,
          nodules = nodules,
          selectedNoduleId = selectedNoduleId,
          selectedCoord = selectedCoord,
          onSelectCoordinate = { x, y -> viewModel.selectCoordinate(x, y) },
          onSelectNodule = { viewModel.selectNodule(it) },
          onLayerChange = { viewModel.setImagingLayer(it) },
          onToggleFreeze = { viewModel.toggleFreeze() },
          onCaptureCube = { viewModel.captureSpectralCube() },
          onRequestLaserArm = { viewModel.requestLaserArmToggle() },
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
        )
      }
    }

    // 3. Bottom HUD Ribbon
    BottomHudRibbon(
      acquisition = acquisition,
      selectedNoduleId = selectedNoduleId,
      onWavelengthChange = { viewModel.setWavelength(it) },
      onToggleAcquisition = { viewModel.toggleAcquisition() },
      onCaptureCube = { viewModel.captureSpectralCube() }
    )
  }
}
