package com.example.aardvark.ui.carbon

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.ImagingLayerMode
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.components.RamanPlot
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.aardvark.ui.components.TelemetryTile
import com.example.aardvark.ui.hud.ImagingViewport
import com.example.ui.theme.*

@Composable
fun CarbonScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val carbon by viewModel.carbonAnalysis.collectAsState()
  val ramanPoints by viewModel.ramanProfile.collectAsState()
  val acquisition by viewModel.acquisition.collectAsState()
  val activeLayer by viewModel.activeLayer.collectAsState()
  val nodules by viewModel.nodulesList.collectAsState()
  val selectedNoduleId by viewModel.selectedNoduleId.collectAsState()
  val selectedCoord by viewModel.selectedCoord.collectAsState()

  Row(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
      .padding(8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Left: Imaging Viewport (forced into Carbon layer or Raman)
    Column(
      modifier = Modifier
        .weight(1.3f)
        .fillMaxHeight(),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Carbon Layer Modes Selector
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavyGraphite, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        val carbonLayers = listOf(
          Pair(ImagingLayerMode.CARBON, "Carbonaceous Material"),
          Pair(ImagingLayerMode.RAMAN, "Raman D/G Shift"),
          Pair(ImagingLayerMode.FLUORESCENCE, "UV Fluorescence 365nm"),
          Pair(ImagingLayerMode.RGB, "Optical Reference")
        )
        carbonLayers.forEach { (layer, label) ->
          val isSel = activeLayer == layer
          Box(
            modifier = Modifier
              .background(if (isSel) TraceAmber else NavySurface, RoundedCornerShape(2.dp))
              .clickable { viewModel.setImagingLayer(layer) }
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = label,
              style = MaterialTheme.typography.labelSmall,
              color = if (isSel) GraphiteDark else TextPrimary,
              fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
              fontSize = 8.5.sp
            )
          }
        }
      }

      ImagingViewport(
        activeLayer = activeLayer,
        acquisition = acquisition,
        nodules = nodules,
        selectedNoduleId = selectedNoduleId,
        selectedCoord = selectedCoord,
        onSelectCoordinate = { x, y -> viewModel.selectCoordinate(x, y) },
        onSelectNodule = { viewModel.selectNodule(it) },
        onLayerChange = { viewModel.setImagingLayer(it) },
        onToggleFreeze = { viewModel.toggleFreeze() },
        onCaptureCube = { viewModel.captureSpectralCube() },
        onRequestLaserArm = { viewModel.requestLaserArmToggle() },
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      )
    }

    // Right: Dedicated Carbon Analysis Panel
    Column(
      modifier = Modifier
        .weight(1.1f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "CARBON CHARACTERISATION",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          Text(
            text = "Target: ${selectedNoduleId ?: "COORD [${carbon.selectedCoord.first}, ${carbon.selectedCoord.second}]"}",
            style = MaterialTheme.typography.labelSmall,
            color = TraceAmber
          )
        }
        TechnicalBadge("CONFIDENCE: ${(carbon.confidenceScore * 100).toInt()}%", badgeColor = TraceAmber)
      }

      // MANDATORY DISCLAIMER BANNER (As strictly specified in Section 7)
      Card(
        colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, WarningOrange.copy(alpha = 0.6f), RoundedCornerShape(2.dp))
          .testTag("carbon_validation_banner")
      ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(modifier = Modifier.size(8.dp).background(WarningOrange, RoundedCornerShape(1.dp)))
            Text(
              text = "MEASUREMENT PROVENANCE & ASSAY CLASSIFICATION",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = WarningOrange,
              fontSize = 8.5.sp
            )
          }
          Text(
            text = "Notice: Spectral classifications and model estimates indicate organic / carbonaceous presence only.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 9.sp
          )
          // CRITICAL REQUIREMENT TEXT:
          Text(
            text = carbon.quantitativeCarbonStatus,
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            fontSize = 10.sp
          )
          Text(
            text = "Elemental TOC/TIC requires certified ashore acid-leaching and flash combustion assay.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
            fontSize = 8.sp
          )
        }
      }

      // Raman Spectroscopy Chart
      RamanPlot(points = ramanPoints, modifier = Modifier.fillMaxWidth())

      // Carbon Diagnostic Metrics
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        TelemetryTile(
          label = "Organic Probability",
          value = "${(carbon.organicProbability * 100).toInt()}%",
          unit = "prob",
          statusColor = if (carbon.organicProbability > 0.3f) PhaseOrganic else TextSecondary,
          modifier = Modifier.weight(1f)
        )
        TelemetryTile(
          label = "Raman I(D) / I(G)",
          value = "${String.format("%.3f", carbon.dToGRatio)}",
          unit = "ratio",
          statusColor = TraceAmber,
          modifier = Modifier.weight(1f)
        )
        TelemetryTile(
          label = "Fluorescence",
          value = "${carbon.fluorescenceResponseRfu.toInt()}",
          unit = "RFU",
          statusColor = TraceEmerald,
          modifier = Modifier.weight(1f)
        )
      }

      // Detailed Geological & Spectral Feature Breakdown
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Text("DETAILED CARBON PHASE BREAKDOWN", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Carbonaceous Material:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text(carbon.carbonaceousClassification, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Carbonate Response:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text(carbon.carbonateClassification, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Raman D-Band (Disordered):", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("${carbon.ramanDIntensity.toInt()} counts @ 1350 cm⁻¹", style = MaterialTheme.typography.bodySmall, color = TraceAmber)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Raman G-Band (Graphitic):", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("${carbon.ramanGIntensity.toInt()} counts @ 1580 cm⁻¹", style = MaterialTheme.typography.bodySmall, color = TraceEmerald)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Supporting Sensor Heads:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Raman (532nm) + SWIR + UV (365nm)", style = MaterialTheme.typography.bodySmall, color = TraceCyan)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Calibration Reference:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text(carbon.calibrationStatus, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
      }

      // Laser Arming & Excitation Action
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Button(
          onClick = { viewModel.requestLaserArmToggle() },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (acquisition.laserSafetyInterlockArmed) CriticalRed else NavySurfaceElevated
          ),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .weight(1f)
            .border(
              1.dp,
              if (acquisition.laserSafetyInterlockArmed) CriticalRed else BorderHighlight,
              RoundedCornerShape(2.dp)
            )
        ) {
          Text(
            text = if (acquisition.laserSafetyInterlockArmed) "DISARM 532nm LASER" else "ARM 532nm LASER",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp
          )
        }

        Button(
          onClick = { viewModel.captureSpectralCube() },
          colors = ButtonDefaults.buttonColors(containerColor = SpectralBlue),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier.weight(1f)
        ) {
          Text("LOG CARBON PROFILE", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 9.sp)
        }
      }
    }
  }
}
