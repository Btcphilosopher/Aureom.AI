package com.example.aardvark.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val backendUrl by viewModel.backendUrl.collectAsState()
  val isSimulated by viewModel.isSimulatedMode.collectAsState()
  val isConnected by viewModel.isConnected.collectAsState()

  var inputUrl by remember(backendUrl) { mutableStateOf(backendUrl) }
  var unitsMetric by remember { mutableStateOf(true) }
  var coordFormatDms by remember { mutableStateOf(false) }

  Row(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
      .padding(8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Left: Server & Hardware Telemetry Configuration
    Column(
      modifier = Modifier
        .weight(1.2f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Text(
        text = "BACKEND & HARDWARE CONFIGURATION",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )

      // Backend Connection Settings
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text("FASTAPI SCIENTIFIC BACKEND URL", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)

        OutlinedTextField(
          value = inputUrl,
          onValueChange = { inputUrl = it },
          label = { Text("Base URL", style = MaterialTheme.typography.labelSmall) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("backend_url_input"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = SpectralBlue,
            unfocusedBorderColor = BorderSubtle
          )
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Button(
            onClick = { viewModel.updateBackendUrl(inputUrl) },
            colors = ButtonDefaults.buttonColors(containerColor = SpectralBlue),
            shape = RoundedCornerShape(2.dp)
          ) {
            Text("CONNECT", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 9.sp)
          }

          TechnicalBadge(
            text = if (isConnected) "CONNECTED" else "OFFLINE",
            badgeColor = if (isConnected) CalibrationGreen else CriticalRed
          )
        }
      }

      // Silica Flux FPGA Simulation Mode Toggle
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("SILICA FLUX FPGA SIMULATOR", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
            Text("Generates authentic CCZ nodule telemetry & spectra", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 8.sp)
          }
          Switch(
            checked = isSimulated,
            onCheckedChange = { viewModel.setSimulatedMode(it) },
            modifier = Modifier.testTag("simulator_switch")
          )
        }
      }

      // Unit System & Coordinates
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text("UNITS & COORDINATE DISPLAY", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Standard Metric Units (m, bar, °C)", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
          Switch(checked = unitsMetric, onCheckedChange = { unitsMetric = it })
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("WGS84 Coordinate Format (DD vs DMS)", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
          Switch(checked = coordFormatDms, onCheckedChange = { coordFormatDms = it })
        }
      }
    }

    // Right: Instrument Diagnostics & Firmware Logs
    Column(
      modifier = Modifier
        .weight(1.1f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Text(
        text = "INSTRUMENT & FPGA DIAGNOSTICS",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )

      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Text("SYSTEM SPECIFICATIONS", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Workstation Version:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Aardvark Spectral v2.4.0 (2026)", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("FPGA Gateware:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Silica Flux / SystemVerilog Rev 9", style = MaterialTheme.typography.bodySmall, color = TraceCyan)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("PCIe Bus:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Gen3 x4 DMA Subsystem OK", style = MaterialTheme.typography.bodySmall, color = CalibrationGreen)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Titanium Housing Depth Rating:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("6,000 meters (600 bar certified)", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Laser Hardware Interlock:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Hardware Interlock Engaged (SAFE)", style = MaterialTheme.typography.bodySmall, color = CalibrationGreen)
        }
      }

      // Live Log Terminal Output
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(GraphiteMain, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
      ) {
        Text("AUDIT LOG STREAM (RECENT EVENTS)", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
        Text("[13:52:10] FPGA SystemVerilog deserializer lock acquired (8 lanes @ 1.25 Gbps)", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, color = TextMuted, fontSize = 7.5.sp)
        Text("[13:53:02] Sensor channel Raman 532nm interlock verified in SAFE state", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, color = CalibrationGreen, fontSize = 7.5.sp)
        Text("[13:54:18] Room database initialized: 8 nodule records loaded for CCZ Survey", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, color = TextPrimary, fontSize = 7.5.sp)
        Text("[13:56:44] Side-scan sonar ping rate synchronized @ 6.0 Hz", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, color = TraceAmber, fontSize = 7.5.sp)
        Text("[13:58:20] EM induction dipole receiver amplitude: 24.8 mV (apparent cond: 1840 mS/m)", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, color = TraceCyan, fontSize = 7.5.sp)
      }
    }
  }
}
