package com.example.aardvark.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.CalibrationState
import com.example.aardvark.model.RamanPoint
import com.example.aardvark.model.SpectralPoint
import com.example.ui.theme.*

@Composable
fun TechnicalBadge(
  text: String,
  modifier: Modifier = Modifier,
  badgeColor: Color = SpectralBlue,
  backgroundColor: Color = NavySurface,
  borderColor: Color = BorderSubtle
) {
  Box(
    modifier = modifier
      .background(backgroundColor, RoundedCornerShape(2.dp))
      .border(1.dp, borderColor, RoundedCornerShape(2.dp))
      .padding(horizontal = 6.dp, vertical = 2.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = text,
      color = badgeColor,
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace,
      fontSize = 9.sp
    )
  }
}

@Composable
fun TelemetryTile(
  label: String,
  value: String,
  unit: String,
  modifier: Modifier = Modifier,
  statusColor: Color = TextPrimary,
  subtext: String? = null
) {
  Column(
    modifier = modifier
      .background(NavySurface, RoundedCornerShape(2.dp))
      .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
      .padding(horizontal = 8.dp, vertical = 5.dp)
  ) {
    Text(
      text = label.uppercase(),
      style = MaterialTheme.typography.labelSmall,
      color = TextSecondary,
      fontSize = 9.sp
    )
    Spacer(modifier = Modifier.height(2.dp))
    Row(
      verticalAlignment = Alignment.Bottom,
      horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.titleMedium,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        color = statusColor,
        fontSize = 14.sp
      )
      if (unit.isNotBlank()) {
        Text(
          text = unit,
          style = MaterialTheme.typography.labelSmall,
          fontFamily = FontFamily.Monospace,
          color = TextMuted,
          fontSize = 10.sp,
          modifier = Modifier.padding(bottom = 1.dp)
        )
      }
    }
    if (subtext != null) {
      Text(
        text = subtext,
        style = MaterialTheme.typography.labelSmall,
        color = TextMuted,
        fontSize = 8.5.sp
      )
    }
  }
}

@Composable
fun SpectrumPlot(
  points: List<SpectralPoint>,
  activeWavelengthNm: Int,
  modifier: Modifier = Modifier,
  title: String = "SPECTRAL REFLECTANCE vs WAVELENGTH (400 - 1000 nm)",
  onSelectWavelength: ((Int) -> Unit)? = null
) {
  Column(
    modifier = modifier
      .background(GraphiteDark, RoundedCornerShape(2.dp))
      .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
      .padding(8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        color = TextSecondary,
        fontWeight = FontWeight.SemiBold
      )
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(modifier = Modifier.size(8.dp).background(TraceCyan))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Target Spectrum", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(modifier = Modifier.size(8.dp).background(TraceViolet))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Todorokite Ref", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(modifier = Modifier.size(8.dp).background(TraceAmber))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Active ($activeWavelengthNm nm)", style = MaterialTheme.typography.labelSmall, color = TraceAmber, fontSize = 8.sp)
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(130.dp)
        .testTag("spectrum_canvas")
    ) {
      val w = size.width
      val h = size.height

      // Grid lines
      val gridLinesY = 4
      for (i in 0..gridLinesY) {
        val y = h * (i.toFloat() / gridLinesY)
        drawLine(
          color = BorderSubtle.copy(alpha = 0.5f),
          start = Offset(0f, y),
          end = Offset(w, y),
          strokeWidth = 1f
        )
      }
      val gridLinesX = 6
      for (i in 0..gridLinesX) {
        val x = w * (i.toFloat() / gridLinesX)
        drawLine(
          color = BorderSubtle.copy(alpha = 0.5f),
          start = Offset(x, 0f),
          end = Offset(x, h),
          strokeWidth = 1f
        )
      }

      if (points.isNotEmpty()) {
        val minNm = 400f
        val maxNm = 1000f

        // Draw Reference Curve
        val refPath = Path()
        points.forEachIndexed { idx, pt ->
          val x = ((pt.wavelengthNm - minNm) / (maxNm - minNm)) * w
          val y = h - (pt.referenceReflectance.coerceIn(0f, 1f) * h * 0.9f)
          if (idx == 0) refPath.moveTo(x, y) else refPath.lineTo(x, y)
        }
        drawPath(refPath, color = TraceViolet.copy(alpha = 0.7f), style = Stroke(width = 1.5f))

        // Draw Target Curve
        val targetPath = Path()
        points.forEachIndexed { idx, pt ->
          val x = ((pt.wavelengthNm - minNm) / (maxNm - minNm)) * w
          val y = h - (pt.reflectance.coerceIn(0f, 1f) * h * 0.9f)
          if (idx == 0) targetPath.moveTo(x, y) else targetPath.lineTo(x, y)
        }
        drawPath(targetPath, color = TraceCyan, style = Stroke(width = 2.5f))

        // Draw active wavelength vertical marker
        val activeX = ((activeWavelengthNm - minNm) / (maxNm - minNm)).coerceIn(0f, 1f) * w
        drawLine(
          color = TraceAmber,
          start = Offset(activeX, 0f),
          end = Offset(activeX, h),
          strokeWidth = 2f
        )
      }
    }

    // X-Axis labels
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("400 nm (UV/Blue)", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
      Text("530 nm (Mn⁴⁺)", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
      Text("680 nm (Red)", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
      Text("740 nm (Ni)", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
      Text("980 nm (NIR H₂O)", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
      Text("1000 nm", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
    }
  }
}

@Composable
fun RamanPlot(
  points: List<RamanPoint>,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .background(GraphiteDark, RoundedCornerShape(2.dp))
      .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
      .padding(8.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "IN-SITU RAMAN SPECTROMETRY (532 nm LASER EXCITATION)",
        style = MaterialTheme.typography.labelSmall,
        color = TextSecondary,
        fontWeight = FontWeight.SemiBold
      )
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        TechnicalBadge("D-BAND: 1350 cm⁻¹", badgeColor = TraceAmber)
        TechnicalBadge("G-BAND: 1580 cm⁻¹", badgeColor = TraceEmerald)
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .height(110.dp)
    ) {
      val w = size.width
      val h = size.height
      val minShift = 800f
      val maxShift = 2000f
      val maxIntensity = 12000f

      // Grid
      for (i in 0..3) {
        val y = h * (i.toFloat() / 3)
        drawLine(color = BorderSubtle.copy(alpha = 0.4f), start = Offset(0f, y), end = Offset(w, y), strokeWidth = 1f)
      }

      if (points.isNotEmpty()) {
        val path = Path()
        points.forEachIndexed { idx, pt ->
          val x = ((pt.ramanShiftCm1 - minShift) / (maxShift - minShift)) * w
          val y = h - (pt.intensity / maxIntensity * h * 0.95f)
          if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color = TraceAmber, style = Stroke(width = 2f))

        // D-Band line
        val dx = ((1350f - minShift) / (maxShift - minShift)) * w
        drawLine(color = TraceAmber.copy(alpha = 0.6f), start = Offset(dx, 0f), end = Offset(dx, h), strokeWidth = 1f)

        // G-Band line
        val gx = ((1580f - minShift) / (maxShift - minShift)) * w
        drawLine(color = TraceEmerald.copy(alpha = 0.6f), start = Offset(gx, 0f), end = Offset(gx, h), strokeWidth = 1f)
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("800 cm⁻¹", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
      Text("1350 cm⁻¹ (D-band disordered)", style = MaterialTheme.typography.labelSmall, color = TraceAmber, fontSize = 8.sp)
      Text("1580 cm⁻¹ (G-band graphitic)", style = MaterialTheme.typography.labelSmall, color = TraceEmerald, fontSize = 8.sp)
      Text("2000 cm⁻¹", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
    }
  }
}

@Composable
fun LaserInterlockConfirmationDialog(
  onConfirm: () -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(modifier = Modifier.size(12.dp).background(CriticalRed, RoundedCornerShape(2.dp)))
        Text("ARM RAMAN 532nm EXCITATION LASER", color = CriticalRed, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          "WARNING: Arming the Nd:YAG 532 nm / 100 mW pulsed laser will enable live subsea in-situ Raman excitation.",
          color = TextPrimary,
          style = MaterialTheme.typography.bodyMedium
        )
        Text(
          "• Silica Flux FPGA Hardware Interlock must remain clear\n• Vehicle proximity sensor indicates distance < 0.5m\n• In-situ spectral emission safety protocols engaged",
          color = TextSecondary,
          style = MaterialTheme.typography.bodySmall
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(containerColor = CriticalRed),
        modifier = Modifier.testTag("confirm_laser_arm_button")
      ) {
        Text("ARM LASER EMISSION", color = Color.White, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("ABORT", color = TextSecondary)
      }
    },
    containerColor = NavySurfaceElevated,
    tonalElevation = 8.dp
  )
}
