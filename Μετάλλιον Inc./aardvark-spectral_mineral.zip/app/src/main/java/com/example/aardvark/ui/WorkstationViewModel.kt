package com.example.aardvark.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.aardvark.data.local.NoduleEntity
import com.example.aardvark.data.local.SurveyEntity
import com.example.aardvark.data.repository.AardvarkWorkstationRepository
import com.example.aardvark.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class WorkstationTab(val label: String, val shortCode: String) {
  HUD("Main HUD", "HUD"),
  SPECTRAL("Spectral Imaging", "SPEC"),
  CARBON("Carbon Workstation", "CARB"),
  NODULES("Nodule Intelligence", "NOD"),
  SONAR_EM("Sonar & EM", "SONAR"),
  GEOLOGY_3D("3D Geology", "3D"),
  SENSORS("Sensor Array", "SENS"),
  SURVEYS("Surveys", "SURV"),
  REPORTS("Reports & Export", "RPT"),
  SETTINGS("Settings", "SET")
}

class WorkstationViewModel(application: Application) : AndroidViewModel(application) {
  val repository = AardvarkWorkstationRepository(application)

  val currentTab = MutableStateFlow(WorkstationTab.HUD)
  val showLaserConfirmDialog = MutableStateFlow(false)
  val showNewSurveyDialog = MutableStateFlow(false)
  val exportSuccessMessage = MutableStateFlow<String?>(null)

  // Workstation state streams
  val telemetry: StateFlow<TelemetryData> = repository.telemetry
  val sensorChannels: StateFlow<List<SensorChannelStatus>> = repository.sensorChannels
  val acquisition: StateFlow<AcquisitionControl> = repository.acquisition
  val activeLayer: StateFlow<ImagingLayerMode> = repository.activeLayer
  val selectedNoduleId: StateFlow<String?> = repository.selectedNoduleId
  val selectedCoord: StateFlow<Pair<Int, Int>> = repository.selectedCoord
  val carbonAnalysis: StateFlow<CarbonAnalysisState> = repository.carbonAnalysis
  val sonarData: StateFlow<SonarData> = repository.sonarData
  val emData: StateFlow<EmInductionData> = repository.emData
  val backendUrl: StateFlow<String> = repository.backendUrl
  val isSimulatedMode: StateFlow<Boolean> = repository.isSimulatedMode
  val isConnected: StateFlow<Boolean> = repository.isConnected

  val nodulesList: StateFlow<List<NoduleEntity>> = repository.getAllNodules()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val surveysList: StateFlow<List<SurveyEntity>> = repository.getAllSurveys()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedNodule: StateFlow<NoduleEntity?> = combine(nodulesList, selectedNoduleId) { list, id ->
    list.find { it.id == id } ?: list.firstOrNull()
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val spectralProfile: StateFlow<List<SpectralPoint>> = acquisition.map {
    repository.getSpectralProfile(it.activeWavelengthNm)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val ramanProfile: StateFlow<List<RamanPoint>> = carbonAnalysis.map {
    repository.getRamanSpectrum()
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  fun setTab(tab: WorkstationTab) {
    currentTab.value = tab
  }

  fun setImagingLayer(layer: ImagingLayerMode) {
    repository.setImagingLayer(layer)
  }

  fun selectNodule(id: String?) {
    repository.selectNodule(id)
  }

  fun selectCoordinate(x: Int, y: Int) {
    repository.selectCoordinate(x, y)
  }

  fun setWavelength(nm: Int) {
    repository.setWavelength(nm)
  }

  fun setExposure(ms: Float) {
    repository.setExposure(ms)
  }

  fun setIntegrationTime(ms: Float) {
    repository.setIntegrationTime(ms)
  }

  fun toggleFreeze() {
    repository.toggleFreezeFrame()
  }

  fun captureSpectralCube() {
    repository.captureSpectralCube()
  }

  fun toggleAcquisition() {
    val current = acquisition.value.state
    val next = if (current == AcquisitionState.ACQUIRING) AcquisitionState.PAUSED else AcquisitionState.ACQUIRING
    repository.setAcquisitionState(next)
  }

  fun requestLaserArmToggle() {
    if (!acquisition.value.laserSafetyInterlockArmed) {
      showLaserConfirmDialog.value = true
    } else {
      repository.armLaserSafetyInterlock(false)
    }
  }

  fun confirmLaserArm() {
    repository.armLaserSafetyInterlock(true)
    showLaserConfirmDialog.value = false
  }

  fun cancelLaserArm() {
    showLaserConfirmDialog.value = false
  }

  fun calibrateSensor(channelId: SensorChannelId) {
    repository.executeCalibrationRoutine(channelId)
  }

  fun updateBackendUrl(url: String) {
    repository.updateBackendUrl(url)
  }

  fun setSimulatedMode(simulated: Boolean) {
    repository.setSimulatedMode(simulated)
  }

  fun createNewSurvey(name: String, area: String, operatorNotes: String) {
    viewModelScope.launch {
      val newSurvey = SurveyRecord(
        id = "SURV-${System.currentTimeMillis() % 10000}",
        name = name.ifBlank { "CCZ Subsea Survey Track" },
        missionId = telemetry.value.missionId,
        areaName = area.ifBlank { "Clarion-Clipperton Zone Block 4" },
        vehicleId = "AARDVARK-AUV-03",
        startTimeUtc = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).format(java.util.Date()),
        durationMinutes = 0,
        distanceCoveredKm = 0.0f,
        nodulesCount = nodulesList.value.size,
        cubesAcquired = 0,
        syncStatus = SyncState.LOCAL_ONLY,
        operatorNotes = operatorNotes
      )
      repository.insertSurvey(newSurvey)
      showNewSurveyDialog.value = false
    }
  }

  fun exportCsv(onDone: (String) -> Unit) {
    viewModelScope.launch {
      val csv = repository.exportNodulesCsv()
      exportSuccessMessage.value = "Nodule catalog exported (${nodulesList.value.size} items)"
      onDone(csv)
    }
  }

  fun exportJson(onDone: (String) -> Unit) {
    viewModelScope.launch {
      val json = repository.exportSurveyJson()
      exportSuccessMessage.value = "Scientific survey JSON exported"
      onDone(json)
    }
  }

  fun clearExportMessage() {
    exportSuccessMessage.value = null
  }
}
