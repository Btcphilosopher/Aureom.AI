package com.example.aardvark.ui.surveys

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.data.local.SurveyEntity
import com.example.aardvark.model.SyncState
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.aardvark.ui.components.TelemetryTile
import com.example.ui.theme.*

@Composable
fun SurveysScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val telemetry by viewModel.telemetry.collectAsState()
  val surveys by viewModel.surveysList.collectAsState()
  val nodules by viewModel.nodulesList.collectAsState()

  var showCreateDialog by remember { mutableStateOf(false) }

  Row(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
      .padding(8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Left: Active Survey Telemetry & Metrics
    Column(
      modifier = Modifier
        .weight(1.1f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "ACTIVE SUBSEA MISSION",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          Text(
            text = telemetry.missionId,
            style = MaterialTheme.typography.labelSmall,
            color = TraceCyan
          )
        }
        TechnicalBadge("LOGGING ACTIVE", badgeColor = CalibrationGreen)
      }

      // Active Mission Metrics
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        TelemetryTile(
          label = "Elapsed Survey",
          value = telemetry.surveyElapsedTime,
          unit = "",
          statusColor = TraceAmber,
          modifier = Modifier.weight(1f)
        )
        TelemetryTile(
          label = "Track Distance",
          value = "4.82",
          unit = "km",
          statusColor = TraceCyan,
          modifier = Modifier.weight(1f)
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        TelemetryTile(
          label = "Nodules Catalogued",
          value = "${nodules.size}",
          unit = "targets",
          statusColor = TextPrimary,
          modifier = Modifier.weight(1f)
        )
        TelemetryTile(
          label = "Cubes Acquired",
          value = "48",
          unit = "cubes",
          statusColor = TextPrimary,
          modifier = Modifier.weight(1f)
        )
      }

      // Survey Location Summary
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Text("SURVEY BOUNDING AREA & LOCAL STORAGE", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Sector Area:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Clarion-Clipperton Zone Block 4", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Subsea Vehicle:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("AARDVARK-AUV-03 (Subsea 6000m)", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Local Room DB:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("aardvark_spectral.db (Cached)", style = MaterialTheme.typography.bodySmall, color = CalibrationGreen)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Synchronisation:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Disconnected Remote Workstation", style = MaterialTheme.typography.bodySmall, color = WarningOrange)
        }
      }

      Button(
        onClick = { showCreateDialog = true },
        colors = ButtonDefaults.buttonColors(containerColor = SpectralBlue),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier.fillMaxWidth().testTag("new_survey_button")
      ) {
        Icon(Icons.Default.Add, contentDescription = null, tint = GraphiteDark, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("DEFINE NEW SURVEY TRACK", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
      }
    }

    // Right: Survey History & Database Records
    Column(
      modifier = Modifier
        .weight(1.3f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "RECORDED SURVEY ARCHIVE",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        TechnicalBadge("${surveys.size} ARCHIVED", badgeColor = TraceAmber)
      }

      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        items(surveys) { survey ->
          SurveyItemCard(survey = survey)
        }
      }
    }
  }

  // New Survey Dialog
  if (showCreateDialog) {
    NewSurveyDialog(
      onDismiss = { showCreateDialog = false },
      onCreate = { name, area, notes ->
        viewModel.createNewSurvey(name, area, notes)
        showCreateDialog = false
      }
    )
  }
}

@Composable
private fun SurveyItemCard(survey: SurveyEntity) {
  val sync = try { SyncState.valueOf(survey.syncStatus) } catch (_: Exception) { SyncState.LOCAL_ONLY }
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(NavySurface, RoundedCornerShape(2.dp))
      .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(3.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = survey.name,
        style = MaterialTheme.typography.titleMedium,
        color = TextPrimary,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.sp
      )
      TechnicalBadge(
        text = sync.name,
        badgeColor = when (sync) {
          SyncState.SYNCED -> CalibrationGreen
          SyncState.PENDING_SYNC -> TraceAmber
          SyncState.LOCAL_ONLY -> WarningOrange
        }
      )
    }

    Text(
      text = "ID: ${survey.id}  |  Area: ${survey.areaName}",
      style = MaterialTheme.typography.labelSmall,
      color = TextSecondary,
      fontSize = 8.5.sp
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("Distance: ${survey.distanceCoveredKm} km", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 8.sp)
      Text("Nodules: ${survey.nodulesCount}", style = MaterialTheme.typography.bodySmall, color = TraceCyan, fontSize = 8.sp)
      Text("Cubes: ${survey.cubesAcquired}", style = MaterialTheme.typography.bodySmall, color = TraceAmber, fontSize = 8.sp)
    }

    if (survey.operatorNotes.isNotBlank()) {
      Text(
        text = "Notes: ${survey.operatorNotes}",
        style = MaterialTheme.typography.bodySmall,
        color = TextMuted,
        fontSize = 8.sp
      )
    }
  }
}

@Composable
private fun NewSurveyDialog(
  onDismiss: () -> Unit,
  onCreate: (name: String, area: String, notes: String) -> Unit
) {
  var name by remember { mutableStateOf("CCZ Transverse Transect 04") }
  var area by remember { mutableStateOf("Clarion-Clipperton Zone Sector C") }
  var notes by remember { mutableStateOf("Full 9-channel sensor sweep. Raman laser armed for nodule inspections.") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("DEFINE NEW EXPLORATION SURVEY", style = MaterialTheme.typography.titleMedium, color = TextPrimary) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Survey Name", style = MaterialTheme.typography.labelSmall) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
          value = area,
          onValueChange = { area = it },
          label = { Text("Exploration Sector Area", style = MaterialTheme.typography.labelSmall) },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Operator Notes & Plan", style = MaterialTheme.typography.labelSmall) },
          maxLines = 3,
          modifier = Modifier.fillMaxWidth()
        )
      }
    },
    confirmButton = {
      Button(onClick = { onCreate(name, area, notes) }, colors = ButtonDefaults.buttonColors(containerColor = SpectralBlue)) {
        Text("INITIALISE SURVEY", color = GraphiteDark, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("CANCEL", color = TextSecondary)
      }
    },
    containerColor = NavySurfaceElevated
  )
}
