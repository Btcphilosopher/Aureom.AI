package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aardvark Spectral Design System Palette (2030s Subsea Scientific Workstation)
val GraphiteDark = Color(0xFF090C10)
val GraphiteMain = Color(0xFF0D1117)
val NavyGraphite = Color(0xFF131A24)
val NavySurface = Color(0xFF182230)
val NavySurfaceElevated = Color(0xFF212E40)
val BorderSubtle = Color(0xFF2B3A4F)
val BorderHighlight = Color(0xFF3B4E68)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextMuted = Color(0xFF566271)

val SpectralBlue = Color(0xFF38BDF8)
val SpectralBlueMuted = Color(0xFF1E40AF)
val AcquisitionAmber = Color(0xFFF59E0B)
val WarningOrange = Color(0xFFF97316)
val CriticalRed = Color(0xFFEF4444)
val CalibrationGreen = Color(0xFF10B981)

// Scientific Plot / Phase Channel Traces
val TraceCyan = Color(0xFF22D3EE)
val TraceEmerald = Color(0xFF34D399)
val TraceViolet = Color(0xFFA78BFA)
val TraceAmber = Color(0xFFFBBF24)
val TraceRose = Color(0xFFFB7185)
val TraceBlue = Color(0xFF60A5FA)
val TraceOrange = Color(0xFFFB923C)

// Mineral Phase Specific Colors
val PhaseManganese = Color(0xFF818CF8) // Todorokite/Birnessite
val PhaseNickel = Color(0xFF34D399)    // Ni-smectite
val PhaseCopper = Color(0xFF38BDF8)    // Cu-sulfide/oxide
val PhaseCobalt = Color(0xFFF472B6)    // Co-rich ferromanganese
val PhaseIron = Color(0xFFFB923C)      // Goethite/oxyhydroxide
val PhaseSilicate = Color(0xFF94A3B8)  // Quartz/Feldspar
val PhaseCarbonate = Color(0xFFFBBF24) // Calcite/Siderite
val PhaseOrganic = Color(0xFFA3E635)   // Carbonaceous / organic
