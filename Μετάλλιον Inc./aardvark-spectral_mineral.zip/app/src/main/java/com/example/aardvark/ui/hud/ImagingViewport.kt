package com.example.aardvark.ui.hud

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.data.local.NoduleEntity
import com.example.aardvark.model.AcquisitionControl
import com.example.aardvark.model.ImagingLayerMode
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.ui.theme.*

@Composable
fun ImagingViewport(
  activeLayer: ImagingLayerMode,
  acquisition: AcquisitionControl,
  nodules: List<NoduleEntity>,
  selectedNoduleId: String?,
  selectedCoord: Pair<Int, Int>,
  onSelectCoordinate: (Int, Int) -> Unit,
  onSelectNodule: (String?) -> Unit,
  onLayerChange: (ImagingLayerMode) -> Unit,
  onToggleFreeze: () -> Unit,
  onCaptureCube: () -> Unit,
  onRequestLaserArm: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showGrid by remember { mutableStateOf(true) }
  var showCrosshair by remember { mutableStateOf(true) }
  var showNoduleBoxes by remember { mutableStateOf(true) }

  Box(
    modifier = modifier
      .background(GraphiteDark)
      .border(1.dp, BorderSubtle)
      .testTag("imaging_viewport")
  ) {
    // 1. Base Image Layer (ROV seabed feed or Sonar waterfall)
    if (activeLayer == ImagingLayerMode.SONAR) {
      Image(
        painter = painterResource(id = com.example.R.drawable.subsea_sonar_waterfall_1793628014233),
        contentDescription = "Side-Scan Sonar Acoustic Waterfall",
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop
      )
    } else {
      Image(
        painter = painterResource(id = com.example.R.drawable.subsea_seabed_nodules_1793627998973),
        contentDescription = "Subsea ROV Multispectral Feed",
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop
      )
    }

    // 2. Scientific Overlay Layer (Multispectral false-colour, mineral masks, carbon heatmaps, EM induction)
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(Unit) {
          detectTapGestures { offset ->
            val relX = (offset.x / size.width).coerceIn(0f, 1f)
            val relY = (offset.y / size.height).coerceIn(0f, 1f)
            val pxX = (relX * 1024).toInt()
            val pxY = (relY * 768).toInt()
            onSelectCoordinate(pxX, pxY)
          }
        }
    ) {
      val w = size.width
      val h = size.height

      // Layer-specific overlays
      when (activeLayer) {
        ImagingLayerMode.RGB -> {
          // Clean optical, no extra filter
        }
        ImagingLayerMode.MULTISPECTRAL -> {
          // False-colour composite: highlight NIR/SWIR reflectance differences
          drawRect(
            color = Color(0x3338BDF8),
            blendMode = BlendMode.Screen
          )
          // False-colour spectral hotspots
          nodules.forEach { n ->
            drawCircle(
              color = Color(0x55F472B6),
              radius = (n.widthMm * 0.9f) * (w / 1024f),
              center = Offset(n.xRel * w, n.yRel * h),
              blendMode = BlendMode.ColorDodge
            )
          }
        }
        ImagingLayerMode.HYPERSPECTRAL -> {
          // Diffraction grating slice tint at current wavelength
          val wavelength = acquisition.activeWavelengthNm
          val bandTint = when {
            wavelength < 500 -> Color(0x303B82F6) // Blue
            wavelength < 600 -> Color(0x3010B981) // Green
            wavelength < 750 -> Color(0x30EF4444) // Red
            else -> Color(0x358B5CF6)             // NIR
          }
          drawRect(color = bandTint, blendMode = BlendMode.Overlay)
        }
        ImagingLayerMode.RAMAN -> {
          // Dark background with laser excitation spots
          drawRect(color = Color(0x40000000))
          nodules.forEach { n ->
            val intensity = n.ramanDPeakRatio
            drawCircle(
              color = TraceAmber.copy(alpha = 0.45f * intensity),
              radius = (n.widthMm * 1.1f) * (w / 1024f),
              center = Offset(n.xRel * w, n.yRel * h)
            )
          }
        }
        ImagingLayerMode.CARBON -> {
          // Carbonaceous / organic probability heatmap
          drawRect(color = Color(0x30000000))
          nodules.forEach { n ->
            val orgColor = if (n.organicProbability > 0.35f) PhaseOrganic else PhaseCarbonate
            drawCircle(
              color = orgColor.copy(alpha = 0.5f),
              radius = (n.widthMm * 1.0f) * (w / 1024f),
              center = Offset(n.xRel * w, n.yRel * h)
            )
          }
        }
        ImagingLayerMode.FLUORESCENCE -> {
          // UV 365nm fluorescence dark background with glowing organic emission
          drawRect(color = Color(0x60090C10), blendMode = BlendMode.Multiply)
          nodules.forEach { n ->
            drawCircle(
              color = Color(0x6084CC16),
              radius = (n.widthMm * 0.8f) * (w / 1024f),
              center = Offset(n.xRel * w, n.yRel * h),
              blendMode = BlendMode.Screen
            )
          }
        }
        ImagingLayerMode.MINERAL -> {
          // Distinct colors per dominant mineral phase
          nodules.forEach { n ->
            val phaseColor = when {
              n.dominantPhase.contains("Todorokite", ignoreCase = true) -> PhaseManganese
              n.dominantPhase.contains("Nickel", ignoreCase = true) -> PhaseNickel
              n.dominantPhase.contains("Ferro", ignoreCase = true) -> PhaseIron
              n.dominantPhase.contains("Cobalt", ignoreCase = true) -> PhaseCobalt
              else -> PhaseSilicate
            }
            drawCircle(
              color = phaseColor.copy(alpha = 0.55f),
              radius = (n.widthMm * 1.05f) * (w / 1024f),
              center = Offset(n.xRel * w, n.yRel * h)
            )
          }
        }
        ImagingLayerMode.ELECTROMAGNETIC -> {
          // EM induction apparent conductivity gradient contours
          nodules.forEach { n ->
            drawCircle(
              color = TraceCyan.copy(alpha = 0.3f),
              radius = (n.widthMm * 2.2f) * (w / 1024f),
              center = Offset(n.xRel * w, n.yRel * h),
              style = Stroke(width = 2.5f)
            )
            drawCircle(
              color = TraceCyan.copy(alpha = 0.15f),
              radius = (n.widthMm * 1.5f) * (w / 1024f),
              center = Offset(n.xRel * w, n.yRel * h)
            )
          }
        }
        ImagingLayerMode.SONAR -> {
          // Acoustic range rings
          for (ring in 1..4) {
            drawCircle(
              color = TraceAmber.copy(alpha = 0.25f),
              radius = (w * 0.2f * ring),
              center = Offset(w / 2f, h / 2f),
              style = Stroke(width = 1f)
            )
          }
        }
      }

      // Grid overlay
      if (showGrid) {
        val numX = 8
        val numY = 6
        for (i in 1 until numX) {
          val gx = w * (i.toFloat() / numX)
          drawLine(color = BorderSubtle.copy(alpha = 0.4f), start = Offset(gx, 0f), end = Offset(gx, h), strokeWidth = 1f)
        }
        for (j in 1 until numY) {
          val gy = h * (j.toFloat() / numY)
          drawLine(color = BorderSubtle.copy(alpha = 0.4f), start = Offset(0f, gy), end = Offset(w, gy), strokeWidth = 1f)
        }
      }

      // Nodule Bounding Boxes & Identifiers
      if (showNoduleBoxes && activeLayer != ImagingLayerMode.SONAR) {
        nodules.forEach { n ->
          val cx = n.xRel * w
          val cy = n.yRel * h
          val bw = (n.widthMm * 0.9f) * (w / 1024f)
          val bh = (n.heightMm * 0.9f) * (h / 768f)
          val isSelected = n.id == selectedNoduleId

          val boxColor = if (isSelected) TraceAmber else SpectralBlue.copy(alpha = 0.85f)
          val strokeWidth = if (isSelected) 2.5f else 1.2f

          // Bounding Box
          drawRect(
            color = boxColor,
            topLeft = Offset(cx - bw / 2f, cy - bh / 2f),
            size = Size(bw, bh),
            style = Stroke(width = strokeWidth)
          )

          // Corner Reticles
          val cornerLen = 6f
          drawLine(boxColor, Offset(cx - bw / 2f, cy - bh / 2f), Offset(cx - bw / 2f + cornerLen, cy - bh / 2f), 2f)
          drawLine(boxColor, Offset(cx - bw / 2f, cy - bh / 2f), Offset(cx - bw / 2f, cy - bh / 2f + cornerLen), 2f)
        }
      }

      // Selected Coordinate Reticle / Crosshair
      if (showCrosshair) {
        val crossX = (selectedCoord.first / 1024f) * w
        val crossY = (selectedCoord.second / 768f) * h
        drawLine(TraceCyan, Offset(crossX - 18f, crossY), Offset(crossX + 18f, crossY), 1.5f)
        drawLine(TraceCyan, Offset(crossX, crossY - 18f), Offset(crossX, crossY + 18f), 1.5f)
        drawCircle(TraceCyan, radius = 8f, center = Offset(crossX, crossY), style = Stroke(1.5f))
      }
    }

    // 3. Nodule Labels on Top of Viewport
    if (showNoduleBoxes && activeLayer != ImagingLayerMode.SONAR) {
      nodules.forEach { n ->
        val isSelected = n.id == selectedNoduleId
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(
              start = ((n.xRel * 100) - 4).coerceIn(0f, 90f).dp * 4,
              top = ((n.yRel * 100) - 3).coerceIn(0f, 90f).dp * 2.5f
            )
        ) {
          Surface(
            color = if (isSelected) AcquisitionAmber else NavySurface.copy(alpha = 0.85f),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.clickable { onSelectNodule(n.id) }
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
              Text(
                text = n.id,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) GraphiteDark else TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 8.5.sp
              )
              Text(
                text = "${n.widthMm.toInt()}mm",
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) GraphiteDark else TextSecondary,
                fontSize = 8.sp
              )
            }
          }
        }
      }
    }

    // 4. Viewport Top Controls & Layer Selector
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Layer Mode Selector
      Row(
        modifier = Modifier
          .background(NavyGraphite.copy(alpha = 0.9f), RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
      ) {
        val keyLayers = listOf(
          ImagingLayerMode.RGB,
          ImagingLayerMode.MULTISPECTRAL,
          ImagingLayerMode.HYPERSPECTRAL,
          ImagingLayerMode.RAMAN,
          ImagingLayerMode.CARBON,
          ImagingLayerMode.MINERAL,
          ImagingLayerMode.SONAR,
          ImagingLayerMode.ELECTROMAGNETIC
        )
        keyLayers.forEach { layer ->
          val selected = activeLayer == layer
          Box(
            modifier = Modifier
              .background(
                if (selected) SpectralBlue else Color.Transparent,
                RoundedCornerShape(2.dp)
              )
              .clickable { onLayerChange(layer) }
              .padding(horizontal = 6.dp, vertical = 3.dp)
              .testTag("layer_${layer.name.lowercase()}")
          ) {
            Text(
              text = when (layer) {
                ImagingLayerMode.RGB -> "RGB"
                ImagingLayerMode.MULTISPECTRAL -> "MULTI"
                ImagingLayerMode.HYPERSPECTRAL -> "HYPER"
                ImagingLayerMode.RAMAN -> "RAMAN"
                ImagingLayerMode.CARBON -> "CARBON"
                ImagingLayerMode.MINERAL -> "MINERAL"
                ImagingLayerMode.SONAR -> "SONAR"
                ImagingLayerMode.ELECTROMAGNETIC -> "EM"
                else -> layer.name
              },
              color = if (selected) GraphiteDark else TextPrimary,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
              fontSize = 9.sp
            )
          }
        }
      }

      // Quick Tools (Crosshair, Grid, Freeze, Laser)
      Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Laser Safety Indicator / Arm Button
        Button(
          onClick = onRequestLaserArm,
          colors = ButtonDefaults.buttonColors(
            containerColor = if (acquisition.laserSafetyInterlockArmed) CriticalRed else NavySurface
          ),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier
            .height(26.dp)
            .border(
              1.dp,
              if (acquisition.laserSafetyInterlockArmed) CriticalRed else BorderSubtle,
              RoundedCornerShape(2.dp)
            )
            .testTag("laser_arm_toggle_button")
        ) {
          Text(
            text = if (acquisition.laserSafetyInterlockArmed) "LASER ARMED [532nm]" else "LASER SAFE",
            color = if (acquisition.laserSafetyInterlockArmed) Color.White else TextSecondary,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            fontSize = 8.5.sp
          )
        }

        // Freeze Frame Toggle
        IconButton(
          onClick = onToggleFreeze,
          modifier = Modifier
            .size(26.dp)
            .background(
              if (acquisition.freezeFrame) WarningOrange else NavySurface,
              RoundedCornerShape(2.dp)
            )
            .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
        ) {
          Icon(
            imageVector = if (acquisition.freezeFrame) Icons.Default.PlayArrow else Icons.Default.Pause,
            contentDescription = "Freeze Frame",
            tint = if (acquisition.freezeFrame) GraphiteDark else TextPrimary,
            modifier = Modifier.size(14.dp)
          )
        }

        // Crosshair Toggle
        IconButton(
          onClick = { showCrosshair = !showCrosshair },
          modifier = Modifier
            .size(26.dp)
            .background(if (showCrosshair) NavySurfaceElevated else NavySurface, RoundedCornerShape(2.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
        ) {
          Icon(
            imageVector = Icons.Default.FilterCenterFocus,
            contentDescription = "Toggle Crosshair",
            tint = if (showCrosshair) TraceCyan else TextMuted,
            modifier = Modifier.size(14.dp)
          )
        }

        // Grid Toggle
        IconButton(
          onClick = { showGrid = !showGrid },
          modifier = Modifier
            .size(26.dp)
            .background(if (showGrid) NavySurfaceElevated else NavySurface, RoundedCornerShape(2.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
        ) {
          Icon(
            imageVector = Icons.Default.GridOn,
            contentDescription = "Toggle Grid",
            tint = if (showGrid) TraceCyan else TextMuted,
            modifier = Modifier.size(14.dp)
          )
        }
      }
    }

    // 5. Viewport Bottom Info Readout & Scale
    Row(
      modifier = Modifier
        .align(Alignment.BottomStart)
        .fillMaxWidth()
        .background(GraphiteDark.copy(alpha = 0.85f))
        .border(1.dp, BorderSubtle)
        .padding(horizontal = 8.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        TechnicalBadge("CURSOR: [X:${selectedCoord.first}, Y:${selectedCoord.second}]", badgeColor = TraceCyan)
        TechnicalBadge("LAYER: ${activeLayer.label.uppercase()}", badgeColor = SpectralBlue)
        if (selectedNoduleId != null) {
          TechnicalBadge("TARGET: $selectedNoduleId", badgeColor = TraceAmber)
        }
      }

      // Scale Bar & Distance Legend
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Box(
            modifier = Modifier
              .width(60.dp)
              .height(3.dp)
              .background(TextPrimary)
          )
          Text("10 cm", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 7.5.sp)
        }
        TechnicalBadge("FOV: 1.4m × 1.05m", badgeColor = TextSecondary)
      }
    }
  }
}
