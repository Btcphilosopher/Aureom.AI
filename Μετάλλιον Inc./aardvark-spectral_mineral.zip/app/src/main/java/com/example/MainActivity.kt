package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.aardvark.ui.WorkstationTab
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.carbon.CarbonScreen
import com.example.aardvark.ui.components.LaserInterlockConfirmationDialog
import com.example.aardvark.ui.geology.Geology3dScreen
import com.example.aardvark.ui.hud.HudScreen
import com.example.aardvark.ui.hud.TopInstrumentBar
import com.example.aardvark.ui.nodules.NodulesScreen
import com.example.aardvark.ui.reports.ReportsScreen
import com.example.aardvark.ui.sensors.SensorsScreen
import com.example.aardvark.ui.settings.SettingsScreen
import com.example.aardvark.ui.sonar.SonarEmScreen
import com.example.aardvark.ui.spectral.SpectralImagingScreen
import com.example.aardvark.ui.surveys.SurveysScreen
import com.example.ui.theme.AardvarkSpectralTheme
import com.example.ui.theme.GraphiteMain

class MainActivity : ComponentActivity() {
  private val viewModel: WorkstationViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      AardvarkSpectralTheme {
        Scaffold(
          modifier = Modifier
            .fillMaxSize()
            .background(GraphiteMain)
        ) { innerPadding ->
          MainWorkstationRoot(
            viewModel = viewModel,
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
          )
        }
      }
    }
  }
}

@Composable
fun MainWorkstationRoot(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val currentTab by viewModel.currentTab.collectAsState()
  val telemetry by viewModel.telemetry.collectAsState()
  val acquisition by viewModel.acquisition.collectAsState()
  val isSimulated by viewModel.isSimulatedMode.collectAsState()
  val isConnected by viewModel.isConnected.collectAsState()
  val showLaserConfirm by viewModel.showLaserConfirmDialog.collectAsState()

  // Back handler: return to main HUD if on any sub-workstation
  BackHandler(enabled = currentTab != WorkstationTab.HUD) {
    viewModel.setTab(WorkstationTab.HUD)
  }

  Box(modifier = modifier.background(GraphiteMain)) {
    Column(modifier = Modifier.fillMaxSize()) {
      // In HUD tab, the HudScreen renders its own integrated layout.
      // In other tabs, show the persistent TopInstrumentBar above the dedicated workstation screen.
      if (currentTab != WorkstationTab.HUD) {
        TopInstrumentBar(
          telemetry = telemetry,
          acquisitionState = acquisition.state,
          isSimulated = isSimulated,
          isConnected = isConnected,
          currentTab = currentTab,
          onSelectTab = { viewModel.setTab(it) }
        )
      }

      Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
        when (currentTab) {
          WorkstationTab.HUD -> HudScreen(viewModel = viewModel)
          WorkstationTab.SPECTRAL -> SpectralImagingScreen(viewModel = viewModel)
          WorkstationTab.CARBON -> CarbonScreen(viewModel = viewModel)
          WorkstationTab.NODULES -> NodulesScreen(viewModel = viewModel)
          WorkstationTab.SONAR_EM -> SonarEmScreen(viewModel = viewModel)
          WorkstationTab.GEOLOGY_3D -> Geology3dScreen(viewModel = viewModel)
          WorkstationTab.SENSORS -> SensorsScreen(viewModel = viewModel)
          WorkstationTab.SURVEYS -> SurveysScreen(viewModel = viewModel)
          WorkstationTab.REPORTS -> ReportsScreen(viewModel = viewModel)
          WorkstationTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
        }
      }
    }

    // Safety Interlock Dialog
    if (showLaserConfirm) {
      LaserInterlockConfirmationDialog(
        onConfirm = { viewModel.confirmLaserArm() },
        onDismiss = { viewModel.cancelLaserArm() }
      )
    }
  }
}
