package com.example.aardvark.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [SurveyEntity::class, NoduleEntity::class, SpectralLogEntity::class],
  version = 1,
  exportSchema = false
)
abstract class AardvarkDatabase : RoomDatabase() {
  abstract fun surveyDao(): SurveyDao
  abstract fun noduleDao(): NoduleDao
  abstract fun spectralDao(): SpectralDao

  companion object {
    @Volatile
    private var INSTANCE: AardvarkDatabase? = null

    fun getDatabase(context: Context): AardvarkDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AardvarkDatabase::class.java,
          "aardvark_spectral.db"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
