package com.example.aardvark.ui.sonar

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.ImagingLayerMode
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.aardvark.ui.components.TelemetryTile
import com.example.ui.theme.*

@Composable
fun SonarEmScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val sonar by viewModel.sonarData.collectAsState()
  val em by viewModel.emData.collectAsState()
  val telemetry by viewModel.telemetry.collectAsState()

  Row(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
      .padding(8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Left: High-Frequency Side-Scan Sonar Acoustic Waterfall
    Column(
      modifier = Modifier
        .weight(1.3f)
        .fillMaxHeight(),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = "ACOUSTIC SIDE-SCAN SONAR (SAS)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          TechnicalBadge("${sonar.frequencyKhz.toInt()} kHz", badgeColor = TraceAmber)
        }
        TechnicalBadge("RANGE: ${sonar.rangeMeters.toInt()}m / CHAN", badgeColor = TraceCyan)
      }

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .background(GraphiteDark)
          .border(1.dp, BorderSubtle)
          .testTag("sonar_waterfall_box")
      ) {
        Image(
          painter = painterResource(id = com.example.R.drawable.subsea_sonar_waterfall_1793628014233),
          contentDescription = "Acoustic Sonar Waterfall",
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )

        // Overlay status badges
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomStart)
            .background(GraphiteDark.copy(alpha = 0.8f))
            .padding(6.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Ping Rate: ${sonar.pingRateHz} Hz", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
          Text("Mean Backscatter: ${sonar.acousticBackscatterMeanDb} dB", style = MaterialTheme.typography.labelSmall, color = TraceAmber)
          Text("Obstacles: ${sonar.detectedObstaclesCount} targets", style = MaterialTheme.typography.labelSmall, color = CalibrationGreen)
        }
      }
    }

    // Right: Silica Flux Electromagnetic Induction & Cross-Sensor Comparison
    Column(
      modifier = Modifier
        .weight(1.1f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Text(
        text = "ELECTROMAGNETIC INDUCTION (EM-38 ARRAY)",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )

      // MANDATORY DISCLAIMER BANNER (Section 9):
      Card(
        colors = CardDefaults.cardColors(containerColor = NavySurfaceElevated),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, BorderHighlight, RoundedCornerShape(2.dp))
          .testTag("em_material_label_banner")
      ) {
        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text(
            text = "GEOPHYSICAL MATERIAL RESPONSE CLASSIFICATION",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = TraceCyan,
            fontSize = 8.5.sp
          )
          Text(
            text = "NOTICE: Electromagnetic induction measures conductivity-sensitive material eddy responses and phase lag. It is NOT direct carbon detection.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 9.sp
          )
          Text(
            text = em.materialLabel,
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            color = TraceAmber,
            fontWeight = FontWeight.Bold,
            fontSize = 9.5.sp
          )
        }
      }

      // EM Telemetry Tiles
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        TelemetryTile(
          label = "Apparent Conduct.",
          value = "${em.apparentConductivityMsM.toInt()}",
          unit = "mS/m",
          statusColor = TraceCyan,
          modifier = Modifier.weight(1f)
        )
        TelemetryTile(
          label = "Received Amplitude",
          value = "${em.receivedAmplitudeMv}",
          unit = "mV",
          statusColor = TextPrimary,
          modifier = Modifier.weight(1f)
        )
        TelemetryTile(
          label = "Phase Lag",
          value = "${em.phaseLagDegrees}°",
          unit = "deg",
          statusColor = TraceAmber,
          modifier = Modifier.weight(1f)
        )
      }

      // Detailed EM Channels
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Text("EM COIL TRANSMITTER & RECEIVER TELEMETRY", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Operating Frequency:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("${em.operatingFrequencyKhz} kHz Dipole", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Quadrature Response:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("${em.quadratureResponseMv} mV (In-Phase / Out-of-Phase)", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Measurement Confidence:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("${(em.measurementConfidence * 100).toInt()}%", style = MaterialTheme.typography.bodySmall, color = CalibrationGreen)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Signal Quality:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("${em.signalQualityPercent}% (Low Noise Abyssal Basin)", style = MaterialTheme.typography.bodySmall, color = CalibrationGreen)
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Seabed Penetration:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
          Text("Skin Depth ~1.8m into pelagic clay", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
      }

      // Cross-Sensor Synchronisation
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(NavySurface, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Text("MULTI-MODAL SENSOR CORRELATION", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
        Text(
          "Synchronized acoustic SAS backscatter (-16.2 dB) and high apparent conductivity (1840 mS/m) correlate with Todorokite nodule clusters detected in optical and SWIR channels.",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary,
          fontSize = 9.sp
        )
      }

      Button(
        onClick = { viewModel.setImagingLayer(ImagingLayerMode.ELECTROMAGNETIC) },
        colors = ButtonDefaults.buttonColors(containerColor = SpectralBlue),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text("PROJECT EM CONDUCTIVITY ON HUD", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
      }
    }
  }
}
