package com.example.aardvark.ui.nodules

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.data.local.NoduleEntity
import com.example.aardvark.model.ImagingLayerMode
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.aardvark.ui.components.TelemetryTile
import com.example.ui.theme.*

@Composable
fun NodulesScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val nodules by viewModel.nodulesList.collectAsState()
  val selectedNodule by viewModel.selectedNodule.collectAsState()
  var searchQuery by remember { mutableStateOf("") }
  var sortByMass by remember { mutableStateOf(false) }

  val filteredNodules = remember(nodules, searchQuery, sortByMass) {
    val list = if (searchQuery.isBlank()) nodules else nodules.filter {
      it.id.contains(searchQuery, ignoreCase = true) ||
        it.dominantPhase.contains(searchQuery, ignoreCase = true) ||
        it.mineralClassification.contains(searchQuery, ignoreCase = true)
    }
    if (sortByMass) list.sortedByDescending { it.estimatedMassGrams } else list
  }

  Row(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
      .padding(8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Left: Searchable Nodule Catalogue List
    Column(
      modifier = Modifier
        .weight(1f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "NODULE CATALOGUE",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          Text(
            text = "Clarion-Clipperton Zone (CCZ)",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
          )
        }
        TechnicalBadge("${filteredNodules.size} RECORDED", badgeColor = TraceAmber)
      }

      // Search & Filter
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Filter nodule ID or phase...", style = MaterialTheme.typography.labelSmall, color = TextMuted) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp)) },
        singleLine = true,
        textStyle = MaterialTheme.typography.labelSmall.copy(color = TextPrimary),
        modifier = Modifier
          .fillMaxWidth()
          .height(44.dp)
          .testTag("nodule_search_field"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = NavySurface,
          unfocusedContainerColor = NavySurface,
          focusedBorderColor = SpectralBlue,
          unfocusedBorderColor = BorderSubtle
        )
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        FilterChip(
          selected = sortByMass,
          onClick = { sortByMass = !sortByMass },
          label = { Text("Sort by Mass (g)", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = SpectralBlueMuted,
            selectedLabelColor = TextPrimary
          )
        )

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          Button(
            onClick = { viewModel.exportCsv {} },
            colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceElevated),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.border(1.dp, BorderHighlight, RoundedCornerShape(2.dp)).testTag("export_csv_button")
          ) {
            Icon(Icons.Default.Download, contentDescription = null, tint = TraceCyan, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(2.dp))
            Text("CSV", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontSize = 8.5.sp)
          }
          Button(
            onClick = { viewModel.exportJson {} },
            colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceElevated),
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.border(1.dp, BorderHighlight, RoundedCornerShape(2.dp)).testTag("export_json_button")
          ) {
            Icon(Icons.Default.Download, contentDescription = null, tint = TraceAmber, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(2.dp))
            Text("JSON", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontSize = 8.5.sp)
          }
        }
      }

      // Lazy List of Nodules
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        items(filteredNodules) { item ->
          val isSelected = item.id == selectedNodule?.id
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .background(if (isSelected) NavySurfaceElevated else NavySurface, RoundedCornerShape(2.dp))
              .border(1.dp, if (isSelected) TraceAmber else BorderSubtle, RoundedCornerShape(2.dp))
              .clickable { viewModel.selectNodule(item.id) }
              .padding(6.dp)
              .testTag("nodule_item_${item.id.lowercase()}")
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = item.id,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) TraceAmber else TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
              )
              TechnicalBadge("${item.estimatedMassGrams.toInt()} g", badgeColor = TraceCyan)
            }
            Text(
              text = item.mineralClassification,
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
              fontSize = 8.5.sp
            )
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "${item.widthMm.toInt()}×${item.heightMm.toInt()}×${item.depthMm.toInt()} mm",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                fontSize = 8.sp
              )
              Text(
                text = "Conf: ${(item.confidenceScore * 100).toInt()}%",
                style = MaterialTheme.typography.labelSmall,
                color = CalibrationGreen,
                fontSize = 8.sp
              )
            }
          }
        }
      }
    }

    // Right: Detailed Nodule Inspection Panel
    Column(
      modifier = Modifier
        .weight(1.3f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      if (selectedNodule == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Text("Select a polymetallic nodule to inspect its geological data", color = TextMuted)
        }
      } else {
        val n = selectedNodule!!

        // Title Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "INSPECTION: ${n.id}",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = TraceAmber
            )
            Text(
              text = n.mineralClassification,
              style = MaterialTheme.typography.labelSmall,
              color = TextPrimary
            )
          }
          TechnicalBadge(
            text = "LAB ASSAY: ${n.labAssayStandard ?: "PENDING"}",
            badgeColor = if (n.labAssayStandard != null) CalibrationGreen else WarningOrange
          )
        }

        // Geometry & Mass Readout
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          TelemetryTile(
            label = "Est. Wet Mass",
            value = "${n.estimatedMassGrams}",
            unit = "g",
            statusColor = TraceCyan,
            modifier = Modifier.weight(1f)
          )
          TelemetryTile(
            label = "Triaxial Dimensions",
            value = "${n.widthMm.toInt()}×${n.heightMm.toInt()}",
            unit = "mm",
            statusColor = TextPrimary,
            subtext = "Depth: ${n.depthMm.toInt()} mm",
            modifier = Modifier.weight(1.2f)
          )
          TelemetryTile(
            label = "SAS Backscatter",
            value = "${n.sonarBackscatterDb}",
            unit = "dB",
            statusColor = TraceAmber,
            modifier = Modifier.weight(1f)
          )
        }

        // Elemental Phase Breakdown (Inferred vs Lab Assayed)
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .background(NavySurface, RoundedCornerShape(2.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
            .padding(8.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Text(
            text = "SPECTRALLY INFERRED MINERAL PHASES & ELEMENTAL ESTIMATES",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Validated against CCZ-2026 Core Assay Standards. Exact assay grades require ashore laboratory digestion.",
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
            fontSize = 7.5.sp
          )

          Spacer(modifier = Modifier.height(4.dp))

          // Elemental Bars
          ElementGradeRow("Manganese (Mn⁴⁺ / Todorokite)", n.mnPercentEst ?: 28f, 35f, PhaseManganese)
          ElementGradeRow("Nickel (Ni-bearing smectite)", n.niPercentEst ?: 1.3f, 2.5f, PhaseNickel)
          ElementGradeRow("Copper (Cu phases)", n.cuPercentEst ?: 1.1f, 2.5f, PhaseCopper)
          ElementGradeRow("Cobalt (Co-rich vernadite)", n.coPercentEst ?: 0.25f, 1.0f, PhaseCobalt)
          ElementGradeRow("Iron (Fe³⁺ oxyhydroxides)", n.fePercentEst ?: 6.0f, 20f, PhaseIron)
        }

        // Morphological & Geological Association
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .background(NavySurface, RoundedCornerShape(2.dp))
            .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
            .padding(8.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Text("GEOLOGICAL CONTEXT & TEXTURE", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Dominant Phase:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            Text(n.dominantPhase, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
          }
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Surface Condition:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            Text(n.surfaceCondition, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
          }
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Associated Sediment:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            Text(n.associatedSediment, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
          }
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Carbon Characterisation:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            Text(n.carbonResponse, style = MaterialTheme.typography.bodySmall, color = TraceAmber)
          }
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Raman I(D)/I(G) Ratio:", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            Text("${n.ramanDPeakRatio}", style = MaterialTheme.typography.bodySmall, color = TraceEmerald)
          }
        }

        // Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = { viewModel.setImagingLayer(ImagingLayerMode.MINERAL) },
            colors = ButtonDefaults.buttonColors(containerColor = SpectralBlue),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("VIEW IN MINERAL HUD", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 9.sp)
          }
          Button(
            onClick = { viewModel.setImagingLayer(ImagingLayerMode.CARBON) },
            colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceElevated),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("CARBON WORKSTATION", color = TextPrimary, fontSize = 9.sp)
          }
        }
      }
    }
  }
}

@Composable
private fun ElementGradeRow(
  name: String,
  estimatedPct: Float,
  maxScalePct: Float,
  barColor: Color
) {
  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(name, style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 8.5.sp)
      Text(
        "${String.format("%.2f", estimatedPct)}% wt",
        style = MaterialTheme.typography.labelSmall,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        color = barColor,
        fontSize = 9.sp
      )
    }
    Spacer(modifier = Modifier.height(2.dp))
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(5.dp)
        .background(NavySurfaceElevated, RoundedCornerShape(1.dp))
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth(fraction = (estimatedPct / maxScalePct).coerceIn(0.01f, 1.0f))
          .fillMaxHeight()
          .background(barColor, RoundedCornerShape(1.dp))
      )
    }
  }
}
