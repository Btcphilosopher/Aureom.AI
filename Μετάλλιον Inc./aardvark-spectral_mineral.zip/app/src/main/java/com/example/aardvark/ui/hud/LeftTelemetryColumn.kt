package com.example.aardvark.ui.hud

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.TelemetryData
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.aardvark.ui.components.TelemetryTile
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun LeftTelemetryColumn(
  telemetry: TelemetryData,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxHeight()
      .background(GraphiteDark)
      .border(1.dp, BorderSubtle)
      .padding(6.dp)
      .verticalScroll(rememberScrollState())
      .testTag("left_telemetry_column"),
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "VEHICLE TELEMETRY",
        style = MaterialTheme.typography.labelSmall,
        color = TextSecondary,
        fontWeight = FontWeight.Bold,
        fontSize = 9.sp
      )
      TechnicalBadge("ROV-03", badgeColor = TraceCyan)
    }

    // 1. Primary Depth & Altitude (Large readout)
    TelemetryTile(
      label = "Subsea Depth",
      value = "${telemetry.depthMeters}",
      unit = "m",
      statusColor = TraceCyan,
      subtext = "Datum: WGS84 Abyssal"
    )

    TelemetryTile(
      label = "Seabed Altitude",
      value = "${telemetry.altitudeMeters}",
      unit = "m",
      statusColor = if (telemetry.altitudeMeters < 2.0) WarningOrange else CalibrationGreen,
      subtext = "Alt Echo 670kHz"
    )

    // 2. Compass & Attitude Graphic
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(NavySurface, RoundedCornerShape(2.dp))
        .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
        .padding(6.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = "ATTITUDE & HEADING",
        style = MaterialTheme.typography.labelSmall,
        color = TextSecondary,
        fontSize = 8.5.sp
      )
      Spacer(modifier = Modifier.height(4.dp))
      Canvas(
        modifier = Modifier
          .size(76.dp)
          .testTag("heading_compass_canvas")
      ) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.width / 2f - 4f

        // Outer Ring
        drawCircle(color = BorderSubtle, radius = radius, center = center, style = Stroke(1.5f))
        drawCircle(color = BorderSubtle.copy(alpha = 0.3f), radius = radius * 0.6f, center = center, style = Stroke(1f))

        // Heading Vector
        val rad = Math.toRadians((telemetry.headingDegrees - 90.0)).toFloat()
        val headX = center.x + radius * 0.85f * cos(rad)
        val headY = center.y + radius * 0.85f * sin(rad)
        drawLine(TraceAmber, center, Offset(headX, headY), strokeWidth = 2.5f)

        // North Marker
        val northRad = Math.toRadians(-90.0).toFloat()
        val nx = center.x + radius * cos(northRad)
        val ny = center.y + radius * sin(northRad)
        drawCircle(TraceCyan, radius = 3f, center = Offset(nx, ny))
      }
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("HDG: ${telemetry.headingDegrees.toInt()}°", style = MaterialTheme.typography.labelSmall, color = TraceAmber, fontSize = 9.sp)
        Text("P: ${telemetry.pitchDegrees}°", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
        Text("R: ${telemetry.rollDegrees}°", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
      }
    }

    // 3. Position Lat / Lon
    TelemetryTile(
      label = "Coordinates (CCZ)",
      value = "${String.format("%.4f", telemetry.latitude)}°N",
      unit = "${String.format("%.4f", telemetry.longitude)}°E",
      statusColor = TextPrimary,
      subtext = "Ultra-Short Baseline (USBL)"
    )

    // 4. Vehicle Speed
    TelemetryTile(
      label = "Speed Over Ground",
      value = "${telemetry.speedKnots}",
      unit = "kn",
      statusColor = TraceEmerald,
      subtext = "Doppler Velocity Log (DVL)"
    )

    // 5. Environmental Pressure & Temperature
    TelemetryTile(
      label = "Hydrostatic Pressure",
      value = "${telemetry.pressureBar}",
      unit = "bar",
      statusColor = TextPrimary,
      subtext = "41.8 MPa Ambient"
    )

    TelemetryTile(
      label = "Internal Housing Temp",
      value = "${telemetry.internalTempCelsius}",
      unit = "°C",
      statusColor = if (telemetry.internalTempCelsius > 35.0) WarningOrange else CalibrationGreen,
      subtext = "Cooling: Ti-Housing Radiator"
    )

    // 6. Battery & Power
    TelemetryTile(
      label = "Subsea Battery Bus",
      value = "${telemetry.batteryPercent}%",
      unit = "${telemetry.batteryVoltage}V",
      statusColor = if (telemetry.batteryPercent < 25) CriticalRed else TraceEmerald,
      subtext = "48V Li-Ion Oil-Compensated"
    )
  }
}
