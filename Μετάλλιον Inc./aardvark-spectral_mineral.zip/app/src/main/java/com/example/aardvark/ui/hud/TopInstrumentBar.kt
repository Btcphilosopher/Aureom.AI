package com.example.aardvark.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.AcquisitionState
import com.example.aardvark.model.TelemetryData
import com.example.aardvark.ui.WorkstationTab
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.ui.theme.*

@Composable
fun TopInstrumentBar(
  telemetry: TelemetryData,
  acquisitionState: AcquisitionState,
  isSimulated: Boolean,
  isConnected: Boolean,
  currentTab: WorkstationTab,
  onSelectTab: (WorkstationTab) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(GraphiteDark)
      .border(1.dp, BorderSubtle)
  ) {
    // 1. Branding & Primary System Telemetry Row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 10.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Left: Aardvark & Μετάλλιον Brand
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .background(SpectralBlueMuted, RoundedCornerShape(2.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "AARDVARK",
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        }
        Text(
          text = "SPECTRAL INTELLIGENCE",
          color = TextPrimary,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.SemiBold,
          fontSize = 12.sp
        )
        Text(
          text = "|  Μετάλλιον Inc.",
          color = TextSecondary,
          style = MaterialTheme.typography.labelSmall,
          fontSize = 10.sp
        )
      }

      // Center: Mission & UTC Clock
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        TechnicalBadge("MISSION: ${telemetry.missionId}", badgeColor = TraceCyan)
        TechnicalBadge("UTC: ${telemetry.timestampUtc}", badgeColor = TextPrimary)
        TechnicalBadge("ELAPSED: ${telemetry.surveyElapsedTime}", badgeColor = AcquisitionAmber)
      }

      // Right: Hardware & Connection Status
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Operational Mode Tag
        TechnicalBadge(
          text = if (isSimulated) "FPGA EMULATOR [SILICA FLUX]" else "ONLINE [SUBSEA FASTAPI]",
          badgeColor = if (isSimulated) TraceAmber else CalibrationGreen
        )

        // Acquisition State Tag
        val stateColor = when (acquisitionState) {
          AcquisitionState.ACQUIRING -> CalibrationGreen
          AcquisitionState.PAUSED -> WarningOrange
          AcquisitionState.PROCESSING -> TraceCyan
          AcquisitionState.FAULT -> CriticalRed
          else -> TextMuted
        }
        TechnicalBadge(
          text = acquisitionState.name,
          badgeColor = stateColor,
          borderColor = stateColor.copy(alpha = 0.5f)
        )

        // Connectivity dot
        Box(
          modifier = Modifier
            .size(8.dp)
            .background(if (isConnected) CalibrationGreen else CriticalRed, RoundedCornerShape(4.dp))
        )
      }
    }

    // 2. Workstation Workspace Tab Selector Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(NavyGraphite)
        .padding(horizontal = 6.dp, vertical = 2.dp),
      horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
      WorkstationTab.values().forEach { tab ->
        val selected = currentTab == tab
        Box(
          modifier = Modifier
            .background(
              if (selected) NavySurfaceElevated else Color.Transparent,
              RoundedCornerShape(2.dp)
            )
            .border(
              1.dp,
              if (selected) BorderHighlight else Color.Transparent,
              RoundedCornerShape(2.dp)
            )
            .clickable { onSelectTab(tab) }
            .padding(horizontal = 8.dp, vertical = 5.dp)
            .testTag("tab_${tab.shortCode.lowercase()}")
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            if (selected) {
              Box(modifier = Modifier.size(4.dp).background(SpectralBlue))
            }
            Text(
              text = tab.label.uppercase(),
              color = if (selected) SpectralBlue else TextSecondary,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
              fontSize = 9.sp
            )
          }
        }
      }
    }
  }
}
