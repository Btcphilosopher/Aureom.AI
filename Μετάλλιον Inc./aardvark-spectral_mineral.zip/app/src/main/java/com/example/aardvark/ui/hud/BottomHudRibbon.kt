package com.example.aardvark.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Camera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.AcquisitionControl
import com.example.aardvark.model.AcquisitionState
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.ui.theme.*

@Composable
fun BottomHudRibbon(
  acquisition: AcquisitionControl,
  selectedNoduleId: String?,
  onWavelengthChange: (Int) -> Unit,
  onToggleAcquisition: () -> Unit,
  onCaptureCube: () -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .background(GraphiteDark)
      .border(1.dp, BorderSubtle)
      .padding(horizontal = 8.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    // 1. Wavelength Slider & Readout (400 - 1000 nm)
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.weight(1.8f)
    ) {
      Column {
        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "WAVELENGTH:",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontSize = 9.sp
          )
          Text(
            text = "${acquisition.activeWavelengthNm} nm",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = TraceAmber,
            fontSize = 11.sp
          )
          TechnicalBadge("BAND ${acquisition.spectralBandIndex} / ${acquisition.totalBands}", badgeColor = TraceCyan)
        }
        Slider(
          value = acquisition.activeWavelengthNm.toFloat(),
          onValueChange = { onWavelengthChange(it.toInt()) },
          valueRange = 400f..1000f,
          colors = SliderDefaults.colors(
            thumbColor = TraceAmber,
            activeTrackColor = SpectralBlue,
            inactiveTrackColor = NavySurfaceElevated
          ),
          modifier = Modifier
            .fillMaxWidth()
            .height(24.dp)
            .testTag("wavelength_slider")
        )
      }
    }

    Spacer(modifier = Modifier.width(12.dp))

    // 2. Optical & Sensor Telemetry Badges
    Row(
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.weight(2f)
    ) {
      Column {
        Text("EXPOSURE", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 7.5.sp)
        Text("${acquisition.exposureMs} ms", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
      }
      Column {
        Text("INTEG. TIME", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 7.5.sp)
        Text("${acquisition.integrationTimeMs} ms", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
      }
      Column {
        Text("SENSOR RES", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 7.5.sp)
        Text(acquisition.resolution, style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
      }
      Column {
        Text("THROUGHPUT", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 7.5.sp)
        Text("${acquisition.throughputMbSec} MB/s", style = MaterialTheme.typography.labelSmall, color = TraceCyan, fontWeight = FontWeight.Bold)
      }
      Column {
        Text("IMAGE SNR", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 7.5.sp)
        Text("${acquisition.snrDb} dB", style = MaterialTheme.typography.labelSmall, color = CalibrationGreen, fontWeight = FontWeight.Bold)
      }
      if (selectedNoduleId != null) {
        TechnicalBadge("SELECT: $selectedNoduleId", badgeColor = TraceAmber)
      }
    }

    Spacer(modifier = Modifier.width(8.dp))

    // 3. Primary Action Buttons
    Row(
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Capture Spectral Cube Button
      Button(
        onClick = onCaptureCube,
        colors = ButtonDefaults.buttonColors(containerColor = NavySurfaceElevated),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
          .border(1.dp, BorderHighlight, RoundedCornerShape(2.dp))
          .testTag("capture_cube_button")
      ) {
        Icon(Icons.Default.Camera, contentDescription = null, tint = SpectralBlue, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("CAPTURE CUBE", style = MaterialTheme.typography.labelSmall, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 9.sp)
      }

      // Start/Stop Acquisition Toggle
      val isAcquiring = acquisition.state == AcquisitionState.ACQUIRING
      Button(
        onClick = onToggleAcquisition,
        colors = ButtonDefaults.buttonColors(
          containerColor = if (isAcquiring) WarningOrange else CalibrationGreen
        ),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier.testTag("toggle_acquisition_button")
      ) {
        Icon(
          if (isAcquiring) Icons.Default.Stop else Icons.Default.PlayArrow,
          contentDescription = null,
          tint = GraphiteDark,
          modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = if (isAcquiring) "PAUSE STREAM" else "START STREAM",
          style = MaterialTheme.typography.labelSmall,
          color = GraphiteDark,
          fontWeight = FontWeight.Bold,
          fontSize = 9.sp
        )
      }
    }
  }
}
