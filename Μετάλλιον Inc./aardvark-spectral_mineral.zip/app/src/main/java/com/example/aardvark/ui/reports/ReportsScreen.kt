package com.example.aardvark.ui.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.ui.theme.*

@Composable
fun ReportsScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val nodules by viewModel.nodulesList.collectAsState()
  val telemetry by viewModel.telemetry.collectAsState()
  val exportMsg by viewModel.exportSuccessMessage.collectAsState()

  var previewContent by remember { mutableStateOf("") }
  var activeFormat by remember { mutableStateOf("SUMMARY") }

  LaunchedEffect(activeFormat) {
    if (activeFormat == "CSV") {
      viewModel.exportCsv { previewContent = it }
    } else if (activeFormat == "JSON") {
      viewModel.exportJson { previewContent = it }
    } else {
      previewContent = """
================================================================================
AARDVARK SPECTRAL INTELLIGENCE — SCIENTIFIC SURVEY REPORT
PARENT ENTITY: Μετάλλιον Inc. | MISSION: ${telemetry.missionId}
SURVEY DATE: 2026-11-02 | OPERATING DEPTH: ${telemetry.depthMeters} m
COORDINATES: ${telemetry.latitude}° N, ${telemetry.longitude}° E (Clarion-Clipperton Zone)
================================================================================

1. EXECUTIVE SURVEY SUMMARY
---------------------------
Total Survey Distance: 4.82 km
Seabed Altitude: ${telemetry.altitudeMeters} m
Vehicle Speed Over Ground: ${telemetry.speedKnots} kn
Detected Polymetallic Nodules: ${nodules.size} Catalogued Targets
Hyperspectral Data Cubes Acquired: 48 Cubes (224 Bands, 400 - 1000 nm)

2. MINERAL PHASE CLASSIFICATION (SAM)
-------------------------------------
Dominant Phase: Todorokite-dominant polymetallic nodules (Mn⁴⁺, Ni, Cu, Co)
Secondary Phase: Birnessite & Ni-bearing smectite
Average Estimated Grades (Inferred vs Standard CCZ-2026-STD-A4):
  • Manganese (Mn): ~28.4% wt
  • Nickel (Ni):    ~1.34% wt
  • Copper (Cu):    ~1.12% wt
  • Cobalt (Co):    ~0.24% wt
  • Iron (Fe):      ~5.80% wt

3. CARBON CHARACTERISATION & PROVENANCE
---------------------------------------
Notice: Spectral classifications and model estimates indicate organic presence.
Quantitative Carbon Concentration: Not established (requires certified ashore assay).
Raman In-Situ Excitation: 532 nm Laser
Average Raman D/G Intensity Ratio: 0.776 (Disordered biogenic kerogen traces)
Fluorescence Response: 142 RFU @ 365 nm UV excitation

4. SENSOR HARDWARE PROVENANCE & CALIBRATION
-------------------------------------------
Hardware Array: Silica Flux SystemVerilog FPGA 9-Channel Architecture
Calibration Baseline: Subsea 99% Diffuse Spectralon Target & Titanium Dark Shutter
Data Integrity: SHA-256 Checksum Verified Local Room DB Storage
================================================================================
      """.trimIndent()
    }
  }

  Row(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
      .padding(8.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Left: Export Controls & Selection
    Column(
      modifier = Modifier
        .weight(0.9f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Text(
        text = "REPORTING & DATA EXPORT",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )

      if (exportMsg != null) {
        Surface(
          color = CalibrationGreen.copy(alpha = 0.2f),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier.fillMaxWidth().border(1.dp, CalibrationGreen, RoundedCornerShape(2.dp))
        ) {
          Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CalibrationGreen, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(exportMsg!!, style = MaterialTheme.typography.labelSmall, color = TextPrimary)
          }
        }
      }

      Text("EXPORT FORMAT:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)

      val formats = listOf("SUMMARY", "CSV", "JSON")
      formats.forEach { fmt ->
        val isSel = activeFormat == fmt
        Button(
          onClick = { activeFormat = fmt },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isSel) SpectralBlue else NavySurface
          ),
          shape = RoundedCornerShape(2.dp),
          modifier = Modifier.fillMaxWidth().border(1.dp, if (isSel) SpectralBlue else BorderSubtle, RoundedCornerShape(2.dp))
        ) {
          Text(
            text = when (fmt) {
              "SUMMARY" -> "Scientific Executive Summary"
              "CSV" -> "Nodule Catalogue (CSV)"
              "JSON" -> "Full Survey Schema (JSON)"
              else -> fmt
            },
            color = if (isSel) GraphiteDark else TextPrimary,
            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
            fontSize = 9.sp
          )
        }
      }

      Spacer(modifier = Modifier.weight(1f))

      Button(
        onClick = {
          if (activeFormat == "CSV") viewModel.exportCsv {} else viewModel.exportJson {}
        },
        colors = ButtonDefaults.buttonColors(containerColor = AcquisitionAmber),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier.fillMaxWidth().testTag("export_trigger_button")
      ) {
        Icon(Icons.Default.Download, contentDescription = null, tint = GraphiteDark, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("EXPORT SCIENTIFIC DATASET", color = GraphiteDark, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
      }
    }

    // Right: Scientific Document Preview
    Column(
      modifier = Modifier
        .weight(1.5f)
        .fillMaxHeight()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("DOCUMENT PREVIEW", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
        TechnicalBadge("FORMAT: $activeFormat", badgeColor = TraceCyan)
      }

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .background(NavyGraphite, RoundedCornerShape(2.dp))
          .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
          .padding(8.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Text(
          text = previewContent,
          style = MaterialTheme.typography.bodySmall,
          fontFamily = FontFamily.Monospace,
          color = TextPrimary,
          fontSize = 8.5.sp,
          lineHeight = 12.sp
        )
      }
    }
  }
}
