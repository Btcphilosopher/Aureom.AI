package com.example.aardvark.ui.sensors

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aardvark.model.CalibrationState
import com.example.aardvark.model.SensorChannelStatus
import com.example.aardvark.ui.WorkstationViewModel
import com.example.aardvark.ui.components.TechnicalBadge
import com.example.aardvark.ui.components.TelemetryTile
import com.example.ui.theme.*

@Composable
fun SensorsScreen(
  viewModel: WorkstationViewModel,
  modifier: Modifier = Modifier
) {
  val sensors by viewModel.sensorChannels.collectAsState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteMain)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Top System Architecture & FPGA Diagnostics Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(GraphiteDark)
        .border(1.dp, BorderSubtle)
        .padding(8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
          modifier = Modifier
            .background(SpectralBlueMuted, RoundedCornerShape(2.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
          Text("SILICA FLUX FPGA", style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
        }
        Text(
          "SystemVerilog Hardware Array  |  PCIe Gen3 x4  |  Firmware v3.4.12",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TechnicalBadge("BUFFER: 34% (3.2 GB / 8.0 GB)", badgeColor = TraceCyan)
        TechnicalBadge("DMA THROUGHPUT: 1.42 GB/s", badgeColor = TraceAmber)
        TechnicalBadge("ERROR COUNTERS: 0 FAULTS", badgeColor = CalibrationGreen)
      }
    }

    // 2. Hardware Bus Architecture Diagram Strip
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(NavySurface, RoundedCornerShape(2.dp))
        .border(1.dp, BorderSubtle, RoundedCornerShape(2.dp))
        .padding(horizontal = 10.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "BUS TOPOLOGY: [Sensors] ──LVDS/SerDes──> [Silica Flux FPGA Processing Core] ──PCIe DMA──> [NVIDIA Jetson AGX Compute] ──10GbE──> [Surface HUD]",
        style = MaterialTheme.typography.labelSmall,
        fontFamily = FontFamily.Monospace,
        color = TextPrimary,
        fontSize = 8.5.sp
      )
    }

    // 3. Grid of all 9 Sensor Panels
    LazyVerticalGrid(
      columns = GridCells.Fixed(3),
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .testTag("sensors_grid"),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(sensors) { sensor ->
        SensorDetailPanel(
          sensor = sensor,
          onCalibrate = { viewModel.calibrateSensor(sensor.id) }
        )
      }
    }
  }
}

@Composable
private fun SensorDetailPanel(
  sensor: SensorChannelStatus,
  onCalibrate: () -> Unit
) {
  val isCalibrated = sensor.calibrationStatus == CalibrationState.CALIBRATED
  val isCalibrating = sensor.calibrationStatus == CalibrationState.IN_PROGRESS

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(GraphiteDark, RoundedCornerShape(2.dp))
      .border(
        1.dp,
        if (sensor.laserArmed) CriticalRed else BorderSubtle,
        RoundedCornerShape(2.dp)
      )
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = sensor.id.displayName,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextPrimary,
          fontSize = 11.5.sp
        )
        Text(
          text = sensor.id.bandInfo,
          style = MaterialTheme.typography.labelSmall,
          color = TextMuted,
          fontSize = 8.sp
        )
      }
      TechnicalBadge(
        text = if (sensor.laserArmed) "LASER ARMED" else if (sensor.isConnected) "ONLINE" else "OFFLINE",
        badgeColor = if (sensor.laserArmed) CriticalRed else if (sensor.isConnected) CalibrationGreen else WarningOrange
      )
    }

    Divider(color = BorderSubtle, thickness = 1.dp)

    // Metric Rows
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("Sampling Rate:", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 9.sp)
      Text("${sensor.frameRateFps} fps", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Bold)
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("Internal Sensor Temp:", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 9.sp)
      Text("${sensor.temperatureCelsius} °C", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("Signal-to-Noise (SNR):", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 9.sp)
      Text("${sensor.snrDb} dB", style = MaterialTheme.typography.bodySmall, color = CalibrationGreen, fontWeight = FontWeight.Bold)
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("Estimated Power Bus:", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 9.sp)
      Text("18.4 W @ 24V", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("Calibration Expiry:", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 9.sp)
      Text("42 h Remaining", style = MaterialTheme.typography.bodySmall, color = TextMuted)
    }

    Spacer(modifier = Modifier.height(2.dp))

    // Action Button
    Button(
      onClick = onCalibrate,
      enabled = !isCalibrating,
      colors = ButtonDefaults.buttonColors(
        containerColor = if (isCalibrated) NavySurfaceElevated else WarningOrange
      ),
      shape = RoundedCornerShape(2.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(30.dp)
        .border(1.dp, BorderHighlight, RoundedCornerShape(2.dp))
    ) {
      Text(
        text = if (isCalibrating) "CALIBRATING ZERO LEVEL..." else if (isCalibrated) "RE-RUN CALIBRATION" else "CALIBRATE NOW",
        style = MaterialTheme.typography.labelSmall,
        color = if (isCalibrated) TextPrimary else GraphiteDark,
        fontWeight = FontWeight.Bold,
        fontSize = 8.5.sp
      )
    }
  }
}
