package com.example.aardvark.data.repository

import android.content.Context
import com.example.aardvark.data.local.*
import com.example.aardvark.data.remote.AardvarkApiService
import com.example.aardvark.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.*

class AardvarkWorkstationRepository(
  private val context: Context,
  private val database: AardvarkDatabase = AardvarkDatabase.getDatabase(context)
) {
  private val scope = CoroutineScope(Dispatchers.IO)

  // Configuration State
  private val _backendUrl = MutableStateFlow("http://192.168.1.120:8000/")
  val backendUrl: StateFlow<String> = _backendUrl.asStateFlow()

  private val _isSimulatedMode = MutableStateFlow(true)
  val isSimulatedMode: StateFlow<Boolean> = _isSimulatedMode.asStateFlow()

  private val _isConnected = MutableStateFlow(true)
  val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

  // Telemetry & Acquisition State
  private val _telemetry = MutableStateFlow(TelemetryData())
  val telemetry: StateFlow<TelemetryData> = _telemetry.asStateFlow()

  private val _sensorChannels = MutableStateFlow(createDefaultSensors())
  val sensorChannels: StateFlow<List<SensorChannelStatus>> = _sensorChannels.asStateFlow()

  private val _acquisition = MutableStateFlow(AcquisitionControl())
  val acquisition: StateFlow<AcquisitionControl> = _acquisition.asStateFlow()

  private val _activeLayer = MutableStateFlow(ImagingLayerMode.RGB)
  val activeLayer: StateFlow<ImagingLayerMode> = _activeLayer.asStateFlow()

  private val _selectedNoduleId = MutableStateFlow<String?>("NOD-0481")
  val selectedNoduleId: StateFlow<String?> = _selectedNoduleId.asStateFlow()

  private val _selectedCoord = MutableStateFlow(Pair(512, 384))
  val selectedCoord: StateFlow<Pair<Int, Int>> = _selectedCoord.asStateFlow()

  private val _carbonAnalysis = MutableStateFlow(CarbonAnalysisState())
  val carbonAnalysis: StateFlow<CarbonAnalysisState> = _carbonAnalysis.asStateFlow()

  private val _sonarData = MutableStateFlow(SonarData())
  val sonarData: StateFlow<SonarData> = _sonarData.asStateFlow()

  private val _emData = MutableStateFlow(EmInductionData())
  val emData: StateFlow<EmInductionData> = _emData.asStateFlow()

  private val _activeSurvey = MutableStateFlow<SurveyRecord?>(null)
  val activeSurvey: StateFlow<SurveyRecord?> = _activeSurvey.asStateFlow()

  // Retrofit client
  private var apiService: AardvarkApiService? = null

  init {
    initRetrofit(_backendUrl.value)
    initLocalBaselineData()
    startTelemetryHeartbeat()
  }

  private fun initRetrofit(baseUrl: String) {
    try {
      val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

      val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

      val retrofit = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

      apiService = retrofit.create(AardvarkApiService::class.java)
    } catch (_: Exception) {
      apiService = null
    }
  }

  fun updateBackendUrl(newUrl: String) {
    val sanitized = if (!newUrl.endsWith("/")) "$newUrl/" else newUrl
    _backendUrl.value = sanitized
    initRetrofit(sanitized)
  }

  fun setSimulatedMode(enabled: Boolean) {
    _isSimulatedMode.value = enabled
  }

  fun setImagingLayer(layer: ImagingLayerMode) {
    _activeLayer.value = layer
  }

  fun selectNodule(noduleId: String?) {
    _selectedNoduleId.value = noduleId
    if (noduleId != null) {
      updateCarbonAndSpectralForNodule(noduleId)
    }
  }

  fun selectCoordinate(x: Int, y: Int) {
    _selectedCoord.value = Pair(x, y)
    val ratioX = x.toFloat() / 1024f
    val ratioY = y.toFloat() / 768f
    // Find closest nodule if any
    scope.launch {
      val nodules = database.noduleDao().getAllNodules().firstOrNull() ?: emptyList()
      val matched = nodules.minByOrNull {
        val dx = it.xRel - ratioX
        val dy = it.yRel - ratioY
        dx * dx + dy * dy
      }
      if (matched != null) {
        val dist = sqrt((matched.xRel - ratioX).pow(2) + (matched.yRel - ratioY).pow(2))
        if (dist < 0.08f) {
          selectNodule(matched.id)
          return@launch
        }
      }
      // If no nodule hit, update generic coordinate carbon
      _carbonAnalysis.value = _carbonAnalysis.value.copy(
        selectedCoord = Pair(x, y),
        carbonaceousClassification = if (ratioY > 0.6f) "Dispersed pelagic organic carbon" else "Trace biogenic carbon in sediment",
        organicProbability = 0.15f + (ratioX * 0.25f),
        ramanDIntensity = 2100f + (ratioY * 1800f),
        ramanGIntensity = 3200f + (ratioY * 2000f),
        fluorescenceResponseRfu = 45f + (ratioX * 80f)
      )
    }
  }

  fun setWavelength(wavelengthNm: Int) {
    val clamped = wavelengthNm.coerceIn(400, 1000)
    val bandIndex = (((clamped - 400) / 600f) * 223).roundToInt()
    _acquisition.value = _acquisition.value.copy(
      activeWavelengthNm = clamped,
      spectralBandIndex = bandIndex
    )
  }

  fun setExposure(exposureMs: Float) {
    _acquisition.value = _acquisition.value.copy(exposureMs = exposureMs.coerceIn(1f, 100f))
  }

  fun setIntegrationTime(timeMs: Float) {
    _acquisition.value = _acquisition.value.copy(integrationTimeMs = timeMs.coerceIn(5f, 500f))
  }

  fun toggleFreezeFrame() {
    val current = _acquisition.value.freezeFrame
    _acquisition.value = _acquisition.value.copy(freezeFrame = !current)
  }

  fun setAcquisitionState(newState: AcquisitionState) {
    _acquisition.value = _acquisition.value.copy(state = newState)
  }

  fun armLaserSafetyInterlock(arm: Boolean) {
    _acquisition.value = _acquisition.value.copy(laserSafetyInterlockArmed = arm)
    _sensorChannels.value = _sensorChannels.value.map { channel ->
      if (channel.id == SensorChannelId.RAMAN) {
        channel.copy(laserArmed = arm)
      } else channel
    }
  }

  fun executeCalibrationRoutine(channelId: SensorChannelId) {
    scope.launch {
      _sensorChannels.value = _sensorChannels.value.map {
        if (it.id == channelId) it.copy(calibrationStatus = CalibrationState.IN_PROGRESS) else it
      }
      delay(2000)
      _sensorChannels.value = _sensorChannels.value.map {
        if (it.id == channelId) it.copy(
          calibrationStatus = CalibrationState.CALIBRATED,
          snrDb = 52.4f,
          hasFault = false
        ) else it
      }
    }
  }

  fun captureSpectralCube() {
    scope.launch {
      val prev = _acquisition.value.state
      _acquisition.value = _acquisition.value.copy(state = AcquisitionState.PROCESSING)
      delay(1500)
      // Save log
      database.spectralDao().insertSpectralLog(
        SpectralLogEntity(
          surveyId = _telemetry.value.missionId,
          objectId = _selectedNoduleId.value ?: "GRID_SLICE_${System.currentTimeMillis() % 1000}",
          wavelengthMinNm = 400,
          wavelengthMaxNm = 1000,
          bandCount = 224,
          targetCoordX = _selectedCoord.value.first,
          targetCoordY = _selectedCoord.value.second,
          classificationResult = "Todorokite-dominant polymetallic phase (CCZ standard)",
          samScore = 0.94f,
          timestampUtc = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
        )
      )
      _acquisition.value = _acquisition.value.copy(state = prev)
    }
  }

  // Database accessors
  fun getAllSurveys(): Flow<List<SurveyEntity>> = database.surveyDao().getAllSurveys()

  fun getAllNodules(): Flow<List<NoduleEntity>> = database.noduleDao().getAllNodules()

  suspend fun insertSurvey(survey: SurveyRecord) {
    database.surveyDao().insertSurvey(
      SurveyEntity(
        id = survey.id,
        name = survey.name,
        missionId = survey.missionId,
        areaName = survey.areaName,
        vehicleId = survey.vehicleId,
        startTimeUtc = survey.startTimeUtc,
        durationMinutes = survey.durationMinutes,
        distanceCoveredKm = survey.distanceCoveredKm,
        nodulesCount = survey.nodulesCount,
        cubesAcquired = survey.cubesAcquired,
        syncStatus = survey.syncStatus.name,
        operatorNotes = survey.operatorNotes
      )
    )
    _activeSurvey.value = survey
  }

  // Generate reference and current spectral profiles for charting
  fun getSpectralProfile(wavelengthNm: Int): List<SpectralPoint> {
    val noduleId = _selectedNoduleId.value
    val points = mutableListOf<SpectralPoint>()
    // Generate 400nm to 1000nm in 10nm steps
    for (wl in 400..1000 step 10) {
      val baseMnAbsorption = 0.18f + 0.12f * sin((wl - 400) / 600f * Math.PI.toFloat())
      val todorokiteRef = 0.12f + 0.08f * (1.0f - exp(-((wl - 530f).pow(2) / 3600f))) +
        0.05f * exp(-((wl - 980f).pow(2) / 2400f))
      val endmemberRef = 0.10f + 0.15f * ((wl - 400f) / 600f)
      val currentRef = when (noduleId) {
        "NOD-0481" -> todorokiteRef + 0.02f * sin(wl * 0.05f)
        "NOD-0482" -> 0.15f + 0.07f * (1.0f - exp(-((wl - 740f).pow(2) / 4800f)))
        "NOD-0483" -> 0.22f + 0.06f * sin((wl - 500) / 200f)
        else -> baseMnAbsorption
      }.coerceIn(0.02f, 0.95f)

      points.add(
        SpectralPoint(
          wavelengthNm = wl,
          reflectance = currentRef,
          referenceReflectance = todorokiteRef,
          endmemberReflectance = endmemberRef,
          snrDb = 48.0f - abs(wl - 700) * 0.02f
        )
      )
    }
    return points
  }

  // Generate authentic Raman spectrum (D-band 1350, G-band 1580 cm-1)
  fun getRamanSpectrum(): List<RamanPoint> {
    val points = mutableListOf<RamanPoint>()
    val dIntensity = _carbonAnalysis.value.ramanDIntensity
    val gIntensity = _carbonAnalysis.value.ramanGIntensity
    for (shift in 800..2000 step 15) {
      val baseline = 600f + (shift - 800) * 0.4f
      val dPeak = dIntensity * exp(-((shift - 1350f).pow(2) / (2 * 65f * 65f)))
      val gPeak = gIntensity * exp(-((shift - 1580f).pow(2) / (2 * 50f * 50f)))
      val noise = (sin(shift.toFloat() * 1.7f) * 75f)
      points.add(
        RamanPoint(
          ramanShiftCm1 = shift,
          intensity = baseline + dPeak + gPeak + noise,
          baseline = baseline
        )
      )
    }
    return points
  }

  // Export nodule catalogue to CSV
  suspend fun exportNodulesCsv(): String {
    val nodules = database.noduleDao().getAllNodules().firstOrNull() ?: emptyList()
    val sb = StringBuilder()
    sb.append("ID,Survey_ID,X_Rel,Y_Rel,Width_mm,Height_mm,Depth_mm,Est_Mass_g,Dominant_Phase,Confidence,Mn_Est_Pct,Ni_Est_Pct,Cu_Est_Pct,Co_Est_Pct,Fe_Est_Pct,Carbon_Response,Organic_Prob,Raman_D_G_Ratio,Sonar_Backscatter_dB,Lab_Assay_Standard\n")
    for (n in nodules) {
      sb.append("${n.id},${n.surveyId},${n.xRel},${n.yRel},${n.widthMm},${n.heightMm},${n.depthMm},${n.estimatedMassGrams},${n.dominantPhase},${n.confidenceScore},${n.mnPercentEst ?: ""},${n.niPercentEst ?: ""},${n.cuPercentEst ?: ""},${n.coPercentEst ?: ""},${n.fePercentEst ?: ""},\"${n.carbonResponse}\",${n.organicProbability},${n.ramanDPeakRatio},${n.sonarBackscatterDb},\"${n.labAssayStandard ?: "UNVALIDATED"}\"\n")
    }
    return sb.toString()
  }

  // Export summary report to JSON
  suspend fun exportSurveyJson(): String {
    val nodules = database.noduleDao().getAllNodules().firstOrNull() ?: emptyList()
    val survey = _activeSurvey.value ?: SurveyRecord(
      id = "SURV-2026-09A",
      name = "CCZ Eastern Sector Transverse Survey",
      missionId = "MDL-PAC-2026-09A",
      areaName = "Clarion-Clipperton Zone Block 4",
      vehicleId = "AARDVARK-AUV-03",
      startTimeUtc = "2026-11-02T08:00:00Z",
      durationMinutes = 222,
      distanceCoveredKm = 4.82f,
      nodulesCount = nodules.size,
      cubesAcquired = 48,
      syncStatus = SyncState.LOCAL_ONLY,
      operatorNotes = "High nodule density observed along abyssal plain. Todorokite manganese signatures confirmed."
    )
    val sb = StringBuilder()
    sb.append("{\n")
    sb.append("  \"project\": \"Μετάλλιον Inc. / Aardvark Spectral Intelligence\",\n")
    sb.append("  \"survey\": {\n")
    sb.append("    \"id\": \"${survey.id}\",\n")
    sb.append("    \"missionId\": \"${survey.missionId}\",\n")
    sb.append("    \"vehicle\": \"${survey.vehicleId}\",\n")
    sb.append("    \"depthMeters\": ${_telemetry.value.depthMeters},\n")
    sb.append("    \"coordinates\": {\"latitude\": ${_telemetry.value.latitude}, \"longitude\": ${_telemetry.value.longitude}},\n")
    sb.append("    \"nodulesCatalogued\": ${nodules.size},\n")
    sb.append("    \"carbonStatement\": \"Quantitative carbon concentration: Not established\",\n")
    sb.append("    \"instrumentConfig\": {\n")
    sb.append("      \"sensorArray\": \"Silica Flux SystemVerilog FPGA 9-Channel\",\n")
    sb.append("      \"activeWavelengthNm\": ${_acquisition.value.activeWavelengthNm},\n")
    sb.append("      \"exposureMs\": ${_acquisition.value.exposureMs},\n")
    sb.append("      \"integrationTimeMs\": ${_acquisition.value.integrationTimeMs}\n")
    sb.append("    }\n")
    sb.append("  }\n")
    sb.append("}\n")
    return sb.toString()
  }

  private fun updateCarbonAndSpectralForNodule(noduleId: String) {
    scope.launch {
      val nodule = database.noduleDao().getNoduleById(noduleId) ?: return@launch
      _carbonAnalysis.value = _carbonAnalysis.value.copy(
        selectedCoord = Pair((nodule.xRel * 1024).toInt(), (nodule.yRel * 768).toInt()),
        carbonaceousClassification = nodule.carbonResponse,
        organicProbability = nodule.organicProbability,
        dToGRatio = nodule.ramanDPeakRatio,
        ramanDIntensity = 3500f + nodule.organicProbability * 4000f,
        ramanGIntensity = 5000f + nodule.organicProbability * 3000f,
        fluorescenceResponseRfu = 80f + nodule.organicProbability * 160f,
        confidenceScore = nodule.confidenceScore,
        quantitativeCarbonStatus = "Quantitative carbon concentration: Not established"
      )
    }
  }

  private fun startTelemetryHeartbeat() {
    scope.launch {
      var counter = 0
      while (true) {
        delay(1200)
        counter++
        // Attempt real API if not in simulation mode
        if (!_isSimulatedMode.value && apiService != null) {
          try {
            val response = apiService!!.getLiveTelemetry()
            if (response.isSuccessful && response.body() != null) {
              val dto = response.body()!!
              _telemetry.value = TelemetryData(
                depthMeters = dto.depthMeters,
                altitudeMeters = dto.altitudeMeters,
                headingDegrees = dto.headingDegrees,
                pitchDegrees = dto.pitchDegrees,
                rollDegrees = dto.rollDegrees,
                latitude = dto.latitude,
                longitude = dto.longitude,
                speedKnots = dto.speedKnots,
                batteryPercent = dto.batteryPercent,
                batteryVoltage = dto.batteryVoltage,
                pressureBar = dto.pressureBar,
                internalTempCelsius = dto.internalTempCelsius,
                timestampUtc = dto.timestampUtc
              )
              _isConnected.value = true
              continue
            }
          } catch (_: Exception) {
            _isConnected.value = false
          }
        }

        // High-precision subsea drift simulation
        val baseDepth = 4128.4
        val depthVar = sin(counter * 0.1) * 0.3
        val baseAlt = 3.2
        val altVar = cos(counter * 0.08) * 0.15
        val baseHeading = 214.5f
        val headVar = (sin(counter * 0.05) * 1.2).toFloat()
        val baseLat = 13.23944 + (counter * 0.000002)
        val baseLon = 145.53833 + (counter * 0.0000015)
        val batVolt = (48.2 - (counter * 0.0005)).coerceAtLeast(42.0)
        val batPct = ((batVolt - 42.0) / 6.2 * 100).toInt().coerceIn(1, 100)

        val hours = (counter / 3600) % 24
        val mins = (counter / 60) % 60
        val secs = counter % 60
        val timeStr = String.format(Locale.US, "%02d:%02d:%02d UTC", 14 + hours, mins, secs)
        val elapsedStr = String.format(Locale.US, "%02d:%02d:%02d", 3 + (counter / 3600), 42 + mins, secs)

        _telemetry.value = _telemetry.value.copy(
          depthMeters = (baseDepth + depthVar).roundTo(1),
          altitudeMeters = (baseAlt + altVar).roundTo(2),
          headingDegrees = (baseHeading + headVar).roundTo(1).toFloat(),
          pitchDegrees = (-1.2 + sin(counter * 0.12) * 0.3).roundTo(2).toFloat(),
          rollDegrees = (0.8 + cos(counter * 0.14) * 0.2).roundTo(2).toFloat(),
          latitude = baseLat,
          longitude = baseLon,
          speedKnots = (0.45 + sin(counter * 0.09) * 0.03).roundTo(2),
          batteryVoltage = batVolt.roundTo(1),
          batteryPercent = batPct,
          pressureBar = (418.5 + depthVar * 0.1).roundTo(1),
          internalTempCelsius = (14.2 + sin(counter * 0.04) * 0.2).roundTo(1),
          timestampUtc = timeStr,
          surveyElapsedTime = elapsedStr
        )

        // Sensor slight noise / heartbeat
        _sensorChannels.value = _sensorChannels.value.map { channel ->
          val noise = (sin(counter * 0.3 + channel.id.ordinal) * 0.4f)
          channel.copy(
            frameRateFps = (28.4f + noise * 0.3f).roundTo(1).toFloat(),
            temperatureCelsius = (14.1f + noise * 0.1f).roundTo(1).toFloat(),
            snrDb = (48.6f + noise * 0.5f).roundTo(1).toFloat()
          )
        }
      }
    }
  }

  private fun initLocalBaselineData() {
    scope.launch {
      // Check if surveys exist
      val existing = database.surveyDao().getAllSurveys().firstOrNull() ?: emptyList()
      if (existing.isEmpty()) {
        val defaultSurvey = SurveyRecord(
          id = "MDL-PAC-2026-09A",
          name = "Clarion-Clipperton Zone Survey Area Bravo",
          missionId = "MDL-PAC-2026-09A",
          areaName = "CCZ Eastern Abyssal Plain",
          vehicleId = "AARDVARK-AUV-03",
          startTimeUtc = "2026-11-02T10:16:00Z",
          durationMinutes = 222,
          distanceCoveredKm = 4.82f,
          nodulesCount = 8,
          cubesAcquired = 48,
          syncStatus = SyncState.LOCAL_ONLY,
          operatorNotes = "Silica Flux FPGA initialized. High Todorokite nodule density. Laser interlock verified safe."
        )
        insertSurvey(defaultSurvey)
        _activeSurvey.value = defaultSurvey

        // Insert baseline polymetallic nodules detected in CCZ
        val baselineNodules = listOf(
          NoduleEntity(
            id = "NOD-0481",
            surveyId = "MDL-PAC-2026-09A",
            xRel = 0.38f,
            yRel = 0.44f,
            widthMm = 74.2f,
            heightMm = 58.6f,
            depthMm = 46.0f,
            estimatedMassGrams = 214.5f,
            mineralClassification = "Todorokite-dominant polymetallic nodule",
            dominantPhase = "Manganese-rich (Todorokite / Birnessite)",
            confidenceScore = 0.94f,
            surfaceCondition = "Botryoidal / highly porous crust",
            associatedSediment = "Pelagic siliceous red clay",
            mnPercentEst = 28.4f,
            niPercentEst = 1.34f,
            cuPercentEst = 1.12f,
            coPercentEst = 0.24f,
            fePercentEst = 5.8f,
            carbonResponse = "Disordered graphite / kerogen-like carbon",
            organicProbability = 0.38f,
            ramanDPeakRatio = 0.776f,
            sonarBackscatterDb = -16.2f,
            labAssayStandard = "CCZ-2026-STD-A4",
            timestampUtc = "2026-11-02T11:24:10Z"
          ),
          NoduleEntity(
            id = "NOD-0482",
            surveyId = "MDL-PAC-2026-09A",
            xRel = 0.52f,
            yRel = 0.62f,
            widthMm = 88.0f,
            heightMm = 71.4f,
            depthMm = 55.2f,
            estimatedMassGrams = 342.0f,
            mineralClassification = "High-Grade Ni-Cu Todorokite nodule",
            dominantPhase = "Nickel-bearing smectite & Mn oxides",
            confidenceScore = 0.96f,
            surfaceCondition = "Rough granular micro-nodular surface",
            associatedSediment = "Siliceous pelagic mud",
            mnPercentEst = 31.2f,
            niPercentEst = 1.48f,
            cuPercentEst = 1.28f,
            coPercentEst = 0.22f,
            fePercentEst = 4.9f,
            carbonResponse = "Refractory biogenic carbonaceous trace",
            organicProbability = 0.42f,
            ramanDPeakRatio = 0.812f,
            sonarBackscatterDb = -14.8f,
            labAssayStandard = "CCZ-2026-STD-A4",
            timestampUtc = "2026-11-02T11:26:45Z"
          ),
          NoduleEntity(
            id = "NOD-0483",
            surveyId = "MDL-PAC-2026-09A",
            xRel = 0.68f,
            yRel = 0.35f,
            widthMm = 52.1f,
            heightMm = 44.5f,
            depthMm = 38.0f,
            estimatedMassGrams = 112.4f,
            mineralClassification = "Iron-rich Vernadite / Goethite facies",
            dominantPhase = "Ferromanganese oxyhydroxides",
            confidenceScore = 0.89f,
            surfaceCondition = "Smooth indurated outer shell",
            associatedSediment = "Red brown abyssal sediment",
            mnPercentEst = 22.1f,
            niPercentEst = 0.84f,
            cuPercentEst = 0.65f,
            coPercentEst = 0.36f,
            fePercentEst = 12.4f,
            carbonResponse = "Minor carbonate coating (biogenic calcite)",
            organicProbability = 0.18f,
            ramanDPeakRatio = 0.620f,
            sonarBackscatterDb = -18.6f,
            labAssayStandard = "CCZ-2026-STD-B1",
            timestampUtc = "2026-11-02T11:29:12Z"
          ),
          NoduleEntity(
            id = "NOD-0484",
            surveyId = "MDL-PAC-2026-09A",
            xRel = 0.24f,
            yRel = 0.76f,
            widthMm = 62.8f,
            heightMm = 50.2f,
            depthMm = 41.5f,
            estimatedMassGrams = 168.0f,
            mineralClassification = "Mixed hydrogenetic / diagenetic nodule",
            dominantPhase = "Todorokite + Birnessite matrix",
            confidenceScore = 0.91f,
            surfaceCondition = "Sub-rounded with fissures",
            associatedSediment = "Pelagic clay",
            mnPercentEst = 26.5f,
            niPercentEst = 1.15f,
            cuPercentEst = 0.98f,
            coPercentEst = 0.28f,
            fePercentEst = 7.2f,
            carbonResponse = "Amorphous carbonaceous inclusions",
            organicProbability = 0.29f,
            ramanDPeakRatio = 0.710f,
            sonarBackscatterDb = -17.1f,
            labAssayStandard = "CCZ-2026-STD-A4",
            timestampUtc = "2026-11-02T11:31:05Z"
          ),
          NoduleEntity(
            id = "NOD-0485",
            surveyId = "MDL-PAC-2026-09A",
            xRel = 0.82f,
            yRel = 0.72f,
            widthMm = 94.6f,
            heightMm = 82.0f,
            depthMm = 64.0f,
            estimatedMassGrams = 412.0f,
            mineralClassification = "Co-rich ferromanganese crust fragment",
            dominantPhase = "Cobaltiferous vernadite",
            confidenceScore = 0.93f,
            surfaceCondition = "Mammillated dense pavement",
            associatedSediment = "Semi-consolidated calcareous ooze",
            mnPercentEst = 24.8f,
            niPercentEst = 0.95f,
            cuPercentEst = 0.72f,
            coPercentEst = 0.52f,
            fePercentEst = 14.1f,
            carbonResponse = "Carbonate-cemented micro-cavities",
            organicProbability = 0.22f,
            ramanDPeakRatio = 0.655f,
            sonarBackscatterDb = -13.5f,
            labAssayStandard = "CCZ-2026-STD-C2",
            timestampUtc = "2026-11-02T11:33:50Z"
          )
        )
        database.noduleDao().insertNodules(baselineNodules)
      } else {
        val s = existing.first()
        _activeSurvey.value = SurveyRecord(
          id = s.id,
          name = s.name,
          missionId = s.missionId,
          areaName = s.areaName,
          vehicleId = s.vehicleId,
          startTimeUtc = s.startTimeUtc,
          durationMinutes = s.durationMinutes,
          distanceCoveredKm = s.distanceCoveredKm,
          nodulesCount = s.nodulesCount,
          cubesAcquired = s.cubesAcquired,
          syncStatus = SyncState.valueOf(s.syncStatus),
          operatorNotes = s.operatorNotes
        )
      }
    }
  }

  private fun createDefaultSensors(): List<SensorChannelStatus> {
    return SensorChannelId.values().map { id ->
      SensorChannelStatus(
        id = id,
        isConnected = true,
        isAcquiring = true,
        temperatureCelsius = 14.2f,
        frameRateFps = if (id == SensorChannelId.SONAR) 6.0f else 28.4f,
        snrDb = 48.6f,
        calibrationStatus = CalibrationState.CALIBRATED,
        hasFault = false,
        laserArmed = false
      )
    }
  }

  private fun Double.roundTo(decimals: Int): Double {
    val factor = 10.0.pow(decimals)
    return (this * factor).roundToInt() / factor
  }

  private fun Float.roundTo(decimals: Int): Float {
    val factor = 10.0.pow(decimals).toFloat()
    return (this * factor).roundToInt() / factor
  }
}
