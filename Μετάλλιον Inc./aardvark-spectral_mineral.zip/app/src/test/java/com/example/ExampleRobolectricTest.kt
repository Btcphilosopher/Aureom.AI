package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.aardvark.data.repository.AardvarkWorkstationRepository
import com.example.aardvark.model.AcquisitionState
import com.example.aardvark.model.ImagingLayerMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun testAppNameResource() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Aardvark Spectral", appName)
  }

  @Test
  fun testRepositoryInitializationAndTelemetry() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = AardvarkWorkstationRepository(context)

    val telemetry = repository.telemetry.value
    assertTrue("Depth should be greater than 4000m in abyssal zone", telemetry.depthMeters > 4000.0)
    assertEquals("MDL-PAC-2026-09A", telemetry.missionId)
    assertTrue("Internal temp should be nominal", telemetry.internalTempCelsius in 10.0..30.0)
  }

  @Test
  fun testNoduleAndSpectralSignatures() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = AardvarkWorkstationRepository(context)

    repository.setWavelength(530)
    assertEquals(530, repository.acquisition.value.activeWavelengthNm)

    val points = repository.getSpectralProfile(530)
    assertTrue("Spectral profile must contain 400-1000nm samples", points.size > 20)

    val ramanPoints = repository.getRamanSpectrum()
    assertTrue("Raman points must span 800-2000 cm-1", ramanPoints.isNotEmpty())
    val dBand = ramanPoints.find { it.ramanShiftCm1 in 1340..1360 }
    assertNotNull("D-band must be present in Raman trace", dBand)
  }

  @Test
  fun testLaserInterlockProtocol() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = AardvarkWorkstationRepository(context)

    assertEquals(false, repository.acquisition.value.laserSafetyInterlockArmed)
    repository.armLaserSafetyInterlock(true)
    assertEquals(true, repository.acquisition.value.laserSafetyInterlockArmed)
    repository.armLaserSafetyInterlock(false)
    assertEquals(false, repository.acquisition.value.laserSafetyInterlockArmed)
  }
}
