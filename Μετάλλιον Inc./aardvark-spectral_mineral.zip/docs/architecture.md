# Aardvark Spectral Imaging Workstation — Architecture Specification

## Overview
Aardvark Spectral is a native Android scientific workstation designed for **Μετάλλιον Inc.** subsea exploration operations. It interfaces with the **Silica Flux / SystemVerilog** hardware sensor array and Python FastAPI scientific edge platform.

## Architecture Layers
1. **Presentation Layer (Jetpack Compose + Material 3)**
   - Custom 2030s scientific workstation dark design system
   - Main persistent HUD with five dedicated functional zones (Top Instrument Bar, Left Telemetry, Central Imaging Viewport, Right Sensor Column, Bottom Ribbon)
   - Specialized workstations: Spectral Imaging, Carbon Characterisation, Polymetallic Nodule Intelligence, Sonar/EM Geophysical, 3D Geological Reconstruction, Live Sensor Monitor, Survey Management, Reports & Export, Diagnostics/Settings.

2. **Domain & ViewModel Layer**
   - Clean Architecture + MVVM
   - `WorkstationViewModel` exposing immutable `StateFlow` streams for telemetry, multi-sensor states, imaging layers, nodule catalogues, and spectral profiles.
   - Laser interlock protocol requiring explicit confirmation before enabling hazardous 532 nm Nd:YAG laser excitation.

3. **Data Layer & Persistence**
   - **Local Room Database (`AardvarkDatabase`)**:
     - `SurveyEntity` & `SurveyDao`: Offline survey tracks, duration, nodule counts, and sync queue.
     - `NoduleEntity` & `NoduleDao`: High-density polymetallic nodule coordinates, triaxial dimensions, mass estimates, and assay references.
     - `SpectralLogEntity` & `SpectralDao`: 224-band hyperspectral cubes, spectral angle mapping (SAM) scores, and target coordinates.
   - **Remote Retrofit / OkHttp & WebSockets**:
     - Interfaces with Python FastAPI endpoints (`/api/v1/telemetry`, `/api/v1/nodules`, `/api/v1/system/status`).
     - Graceful offline fallback to the high-precision Silica Flux / SystemVerilog simulation engine when disconnected in abyssal exploration.
