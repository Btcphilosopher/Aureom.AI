# Aardvark Spectral — API Integration & HUD Specification

## FastAPI Scientific Backend Contract
Base URL: `http://<ip-or-host>:8000/api/v1/`

### Key Endpoints:
1. `GET /api/v1/system/status`
   - Returns FPGA status, PCIe DMA throughput, buffer utilization, and error counters.
2. `GET /api/v1/telemetry/live`
   - Returns depth, altitude, heading, pitch, roll, latitude, longitude, pressure, and power telemetry.
3. `GET /api/v1/nodules`
   - Returns list of detected polymetallic nodules with bounding boxes, spectral classifications, and mass estimates.
4. `POST /api/v1/acquisition/control`
   - Dispatches acquisition start/pause, wavelength adjustment, exposure time, and integration parameters.
5. `POST /api/v1/laser/interlock/arm`
   - Arms/disarms 532 nm Nd:YAG Raman laser excitation (requires hardware interlock engagement).

## HUD Design Specification
- **Top Instrument Bar**: Branding, Mission ID, UTC clock, survey elapsed timer, connection status, acquisition state.
- **Left Telemetry Column**: Monospaced numerical readouts for subsea depth (m), altitude (m), heading compass (°), pitch/roll (°), lat/lon coordinates (WGS84), vehicle speed (kn), pressure (bar), internal housing temperature (°C), battery (%).
- **Central Imaging Viewport**:
  - Live optical ROV feed and synthetic aperture sonar (SAS) acoustic backscatter.
  - Interactive multi-layer overlays (RGB, Multispectral false-colour, Hyperspectral slice, Raman intensity, Carbon probability, UV fluorescence 365nm, Mineral classification, EM conductivity).
  - Reticle crosshair with coordinate inspection, distance scale bar (10 cm), and nodule bounding box selector.
- **Right Sensor Column**: 9 independent instrument heads (RGB, NIR, SWIR, Hyperspectral, Raman, Infrared, UV Fluorescence, Sonar, EM induction) with temperature, sampling rate, SNR, and single-click in-situ calibration.
- **Bottom HUD Ribbon**: Continuous wavelength slider (400 - 1000 nm), exposure (ms), integration time (ms), throughput (MB/s), resolution, image SNR, and cube capture trigger.

## Deployment Target
- Industrial Android rugged tablets (Panasonic Toughbook, Samsung Galaxy Tab Active).
- Marine control room touch terminals.
- Native Android handheld and workstation displays.
