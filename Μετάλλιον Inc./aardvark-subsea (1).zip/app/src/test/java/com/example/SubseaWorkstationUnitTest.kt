package com.example

import com.example.data.model.HudWorkstationMode
import com.example.data.repository.SubseaRepository
import com.example.ui.SubseaViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class SubseaWorkstationUnitTest {

  private lateinit var repository: SubseaRepository
  private lateinit var viewModel: SubseaViewModel

  @Before
  fun setup() {
    repository = SubseaRepository()
    viewModel = SubseaViewModel(repository)
  }

  @Test
  fun testNoduleCatalogInitialization() {
    val nodules = repository.nodules.value
    assertTrue("Nodule catalog should contain detected nodules", nodules.isNotEmpty())
    assertEquals(6, nodules.size)

    val target = nodules.first { it.id == "ND-002184" }
    assertEquals("Spheroidal", target.shapeClass)
    assertEquals(84, target.apparentDiameterMm)
    assertEquals(5540, target.estimatedAreaMm2)
    assertNotNull("Should have certified laboratory assay link", target.assayRecord)
    assertEquals("ASY-CCZ-8812", target.assayRecord?.assayId)
    assertEquals(29.40f, target.assayRecord?.mnPercent)
  }

  @Test
  fun testRamanSpectrometryRatios() {
    val raman = repository.ramanData.value
    assertNotNull("Raman spectrum data should be initialized", raman)
    assertEquals(1348.0f, raman!!.dBand.centerCm1, 0.1f)
    assertEquals(1584.0f, raman.gBand.centerCm1, 0.1f)
    assertEquals(0.879f, raman.idIgRatio, 0.05f)
    assertTrue("Carbonate peak at 1085 cm⁻¹ should be present", raman.carbonatePeak1085 > 100f)
  }

  @Test
  fun testHyperspectralBandsAndRoiExtraction() {
    val bands = repository.hyperspectralBands.value
    assertEquals("Should have 61 discrete spectral bands from 400 to 1000 nm", 61, bands.size)
    assertEquals(400, bands.first().wavelengthNm)
    assertEquals(1000, bands.last().wavelengthNm)

    // Sample an ROI point
    repository.sampleRoiSpectralPoint(0.38f, 0.64f)
    val sampled = repository.sampledSpectralCurve.value
    assertEquals(61, sampled.size)
    assertTrue("Reflectance should be within calibrated unitless bounds [0, 1]", sampled.all { it.reflectance in 0.0f..1.0f })
  }

  @Test
  fun testCaliperDistanceCalculation() {
    viewModel.toggleCaliperTool()
    assertTrue(viewModel.isCaliperActive.value)

    viewModel.handleCaliperTap(0.1f, 0.5f)
    viewModel.handleCaliperTap(0.2f, 0.5f)

    val distMm = viewModel.calculatePhysicalDistanceMm()
    assertNotNull("Distance should be computed between two points", distMm)
    // 0.1 normalized delta across 3840mm field of view = ~384 mm
    assertEquals(384.0f, distMm!!, 1.0f)
  }

  @Test
  fun testModeSwitchingAndHudCollapse() {
    assertEquals(HudWorkstationMode.OPTICAL, viewModel.activeMode.value)
    viewModel.setWorkstationMode(HudWorkstationMode.SONAR)
    assertEquals(HudWorkstationMode.SONAR, viewModel.activeMode.value)

    assertFalse(viewModel.isHudCollapsed.value)
    viewModel.toggleHudCollapse()
    assertTrue(viewModel.isHudCollapsed.value)
  }

  @Test
  fun testMissionAnnotationAndExport() {
    val initialCount = repository.missionEvents.value.size
    viewModel.addAnnotation("Station 146 Core Grab", "Recovered 18 kg of nodule pavement")
    assertEquals(initialCount + 1, repository.missionEvents.value.size)

    viewModel.exportMission("PLY")
    assertNotNull(viewModel.exportLog.value)
    assertTrue(viewModel.exportLog.value!!.contains("PLY"))
  }
}
