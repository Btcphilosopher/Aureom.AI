package com.example.data.model

import androidx.compose.ui.graphics.Color
import java.io.Serializable

enum class HudWorkstationMode(val label: String, val code: String) {
  OPTICAL("OPTICAL HUD", "OPT-01"),
  HYPERSPECTRAL("SPECTRUM", "HSI-02"),
  SONAR("SONAR MBES/SSS", "SNR-03"),
  MAPPING_3D("3D MAPPING", "GEO-04"),
  NODULES("NODULES (Μετάλλιον)", "NOD-05"),
  CARBON("CARBON RAMAN", "RMN-06"),
  SURVEY("SURVEY MISSION", "MSN-07"),
  DIAGNOSTICS("FPGA & SENSORS", "DIA-08"),
  SETTINGS("SETTINGS & CRS", "SET-09"),
}

enum class SensorHealth {
  OPTIMAL,
  CALIBRATING,
  DEGRADED,
  FAULT,
  SIMULATED,
}

data class SubseaTelemetry(
  val depthM: Double = 4124.6,
  val altitudeM: Double = 3.24,
  val headingDeg: Float = 214.5f,
  val pitchDeg: Float = -1.2f,
  val rollDeg: Float = 0.8f,
  val speedKnots: Float = 0.48f,
  val verticalVelocityMs: Float = -0.015f,
  val waterTempC: Float = 1.84f,
  val salinityPsu: Float = 34.72f,
  val pressureBar: Float = 418.5f,
  val positionConfidencePct: Float = 98.4f,
  val usblLat: Double = 14.284912,
  val usblLon: Double = -125.820341,
  val timestampUtc: String = "2026-11-02T18:59:12.48Z",
  val surveyTimeSeconds: Long = 14280,
  val isSimulatedBenchmark: Boolean = true,
)

data class SensorDiagnostics(
  val opticalCameraHealth: SensorHealth = SensorHealth.OPTIMAL,
  val hyperspectralHealth: SensorHealth = SensorHealth.OPTIMAL,
  val multibeamHealth: SensorHealth = SensorHealth.OPTIMAL,
  val sidescanHealth: SensorHealth = SensorHealth.OPTIMAL,
  val usblHealth: SensorHealth = SensorHealth.OPTIMAL,
  val ramanHealth: SensorHealth = SensorHealth.OPTIMAL,
  val ctdHealth: SensorHealth = SensorHealth.OPTIMAL,
  val insNavHealth: SensorHealth = SensorHealth.OPTIMAL,
  val sensorHousingTempC: Float = 7.2f,
  val opticalFps: Float = 59.8f,
  val opticalLatencyMs: Float = 16.4f,
  val droppedFrames: Int = 0,
  val exposureMs: Float = 12.5f,
  val analogGainDb: Float = 6.0f,
  val snrDb: Float = 48.2f,
  val fpgaDmaThroughputMbps: Float = 840.5f,
  val fpgaFifoLevelPct: Float = 24.0f,
  val opticalLinkBer: String = "1.2e-12",
  val recordingActive: Boolean = true,
  val storageRemainingGb: Float = 1840.0f,
)

data class NoduleAssay(
  val assayId: String,
  val cruiseId: String,
  val sampleProvenance: String,
  val labCertNumber: String,
  val mnPercent: Float,
  val niPercent: Float,
  val cuPercent: Float,
  val coPercent: Float,
  val fePercent: Float,
  val uncertaintyPct: Float = 0.05f,
  val certifiedLab: String = "BGS Marine Geochemistry Lab (Nottingham / ISO 17025)",
)

data class NoduleDetection(
  val id: String,
  val centerNormX: Float,
  val centerNormY: Float,
  val widthNorm: Float,
  val heightNorm: Float,
  val apparentDiameterMm: Int,
  val estimatedAreaMm2: Int,
  val volumeEstimateCm3: Float,
  val shapeClass: String, // "Spheroidal", "Ellipsoidal", "Polynucleated", "Discoidal"
  val surfaceTexture: String, // "Botryoidal / Nodular", "Smooth", "Rough Micro-nodular"
  val spectralClass: String = "Fe-Mn oxide candidate",
  val detectionConfidence: Float,
  val spatialDensityContributionKgM2: Float,
  val assayRecord: NoduleAssay? = null,
)

data class RamanPeak(
  val name: String,
  val centerCm1: Float,
  val amplitude: Float,
  val fwhmCm1: Float,
)

data class RamanSpectrumData(
  val shiftMinCm1: Float = 800f,
  val shiftMaxCm1: Float = 2000f,
  val rawPoints: List<Pair<Float, Float>>,
  val baselinePoints: List<Pair<Float, Float>>,
  val correctedPoints: List<Pair<Float, Float>>,
  val dBand: RamanPeak,
  val gBand: RamanPeak,
  val idIgRatio: Float,
  val carbonatePeak1085: Float,
  val classificationInterpretation: String,
  val signalQualitySnr: Float = 34.2f,
)

data class HyperspectralBand(
  val wavelengthNm: Int,
  val bandIndex: Int,
  val bandName: String,
  val description: String,
  val atmosphericWaterAbsorptionFlag: Boolean = false,
)

data class SpectralCurvePoint(
  val wavelengthNm: Int,
  val reflectance: Float, // Calibrated unitless reflectance (0.0 to 1.0)
)

data class ReferenceSpectralProfile(
  val label: String,
  val colorHex: Long,
  val dataPoints: List<SpectralCurvePoint>,
  val description: String,
)

data class SeabedVertex(
  val x: Float,
  val y: Float,
  val z: Float,
  val depthM: Float,
  val acousticBackscatter: Float,
  val hasNoduleCluster: Boolean,
)

data class MissionEvent(
  val id: String,
  val timeCode: String,
  val title: String,
  val description: String,
  val depthM: Float,
  val tag: String,
  val isFlagged: Boolean = false,
)

data class ImageEnhancementSettings(
  val redWavelengthAttenuation: Float = 0.72f,
  val blueGreenAttenuation: Float = 0.35f,
  val dehazeDarkChannel: Float = 0.65f,
  val contrastStretch: Float = 1.25f,
  val lowLightGain: Float = 1.15f,
  val noiseReduction: Float = 0.40f,
  val splitScreenSlider: Float = 0.50f, // 0.0 = full enhanced, 1.0 = full raw
  val isSplitScreenEnabled: Boolean = false,
  val showMeasurementReticle: Boolean = true,
  val showScaleBar: Boolean = true,
  val showLaserCalibratorDots: Boolean = true,
  val selectedLaserDistanceMm: Int = 100, // standard calibrated parallel lasers (10 cm)
)

data class SonarDisplaySettings(
  val rangeMeters: Int = 50,
  val frequencyKHz: Int = 900,
  val gainTvgDb: Float = 18.0f,
  val pingRateHz: Float = 12.0f,
  val soundVelocityMs: Float = 1482.5f,
  val colorMap: String = "Cyan / Gold Dual", // "Cyan / Gold", "Sepia Acoustic", "Monochrome"
  val showOverlayOnOptical: Boolean = false,
  val overlayAlpha: Float = 0.45f,
)

typealias SonarSettings = SonarDisplaySettings

