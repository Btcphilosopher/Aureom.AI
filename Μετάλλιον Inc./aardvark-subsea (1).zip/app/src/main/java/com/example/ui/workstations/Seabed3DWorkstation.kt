package com.example.ui.workstations

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NoduleDetection
import com.example.data.model.SubseaTelemetry
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun Seabed3DWorkstation(
  telemetry: SubseaTelemetry,
  nodules: List<NoduleDetection>,
  rotationX: Float,
  rotationZ: Float,
  verticalExaggeration: Float,
  onRotate: (Float, Float) -> Unit,
  onSetExaggeration: (Float) -> Unit,
  onExport: (String) -> Unit,
  exportMessage: String?,
  onDismissExport: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteBlack)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Top Ribbon with 3D Controls
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.ViewInAr, contentDescription = "3D Mapping", tint = SonarCyan, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "3D SEABED RECONSTRUCTION // BATHYMETRIC POINT CLOUD MESH",
          style = MaterialTheme.typography.labelMedium.copy(
            color = IceWhite,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        )
      }

      // Export Buttons (PLY, GeoJSON, CSV)
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("EXPORT:", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.5.sp))
        listOf("PLY", "GeoJSON", "CSV").forEach { fmt ->
          Button(
            onClick = { onExport(fmt) },
            colors = ButtonDefaults.buttonColors(containerColor = InstrumentNavy, contentColor = SonarCyan),
            shape = RoundedCornerShape(4.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(28.dp).testTag("export_$fmt")
          ) {
            Text(fmt, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // Export Feedback Notification Banner
    if (exportMessage != null) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(NoduleTargetEmerald.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
          .border(1.dp, NoduleTargetEmerald, RoundedCornerShape(4.dp))
          .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(text = exportMessage, style = MaterialTheme.typography.bodySmall.copy(color = NoduleTargetEmerald, fontSize = 9.sp))
        IconButton(onClick = onDismissExport, modifier = Modifier.size(20.dp)) {
          Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = NoduleTargetEmerald, modifier = Modifier.size(12.dp))
        }
      }
    }

    // 2. Interactive 3D Projection Canvas (Orbit with drag gestures)
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .background(AbyssBlack, RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .pointerInput(Unit) {
          detectDragGestures { _, dragAmount ->
            onRotate(-dragAmount.y * 0.4f, dragAmount.x * 0.4f)
          }
        }
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f

        val radPitch = Math.toRadians(rotationX.toDouble())
        val radYaw = Math.toRadians(rotationZ.toDouble())

        // 3D Isometric / Perspective Grid Projection
        // Grid size: 16x16 nodes representing 100m x 100m seabed patch
        val gridSize = 16
        val step = 28f
        val startX = -gridSize * step / 2f
        val startY = -gridSize * step / 2f

        // Helper 3D to 2D projection function
        fun project3D(x3: Float, y3: Float, z3: Float): Offset {
          // Rotate around Z (yaw)
          val xRot = x3 * cos(radYaw) - y3 * sin(radYaw)
          val yRot = x3 * sin(radYaw) + y3 * cos(radYaw)

          // Rotate around X (pitch)
          val yFinal = yRot * cos(radPitch) - z3 * sin(radPitch)
          val zFinal = yRot * sin(radPitch) + z3 * cos(radPitch)

          // Orthographic / subtle perspective projection
          val scale = 0.9f
          val px = cx + (xRot * scale).toFloat()
          val py = cy + (yFinal * scale).toFloat()
          return Offset(px, py)
        }

        // Draw Bathymetric Wireframe Grid & Depth Elevation
        val gridPoints = Array(gridSize + 1) { x ->
          Array(gridSize + 1) { y ->
            val worldX = startX + x * step
            val worldY = startY + y * step
            // Seabed undulating bathymetry model (-4120m to -4128m)
            val wave = (sin(x * 0.45) * 12.0 + cos(y * 0.38) * 14.0 + sin((x + y) * 0.3) * 8.0).toFloat()
            val zElevation = -wave * verticalExaggeration
            project3D(worldX, worldY, zElevation)
          }
        }

        // Draw horizontal mesh lines
        for (x in 0..gridSize) {
          val path = Path()
          for (y in 0..gridSize) {
            val pt = gridPoints[x][y]
            if (y == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
          }
          // Depth color tint
          val color = if (x % 4 == 0) SonarCyan.copy(alpha = 0.6f) else BorderNavy.copy(alpha = 0.4f)
          drawPath(path, color = color, style = Stroke(1f))
        }

        // Draw vertical mesh lines
        for (y in 0..gridSize) {
          val path = Path()
          for (x in 0..gridSize) {
            val pt = gridPoints[x][y]
            if (x == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
          }
          val color = if (y % 4 == 0) SonarCyan.copy(alpha = 0.6f) else BorderNavy.copy(alpha = 0.4f)
          drawPath(path, color = color, style = Stroke(1f))
        }

        // Draw ROV Flight Trajectory in 3D
        val rovPath = Path()
        val trajPoints = listOf(
          project3D(-160f, -140f, -50f * verticalExaggeration),
          project3D(-80f, -70f, -40f * verticalExaggeration),
          project3D(0f, 0f, -32f * verticalExaggeration),
          project3D(80f, 60f, -34f * verticalExaggeration),
          project3D(140f, 120f, -35f * verticalExaggeration),
        )
        trajPoints.forEachIndexed { i, pt ->
          if (i == 0) rovPath.moveTo(pt.x, pt.y) else rovPath.lineTo(pt.x, pt.y)
        }
        drawPath(rovPath, color = AmberCaution, style = Stroke(2.5f))

        // Draw Vehicle Position Beacon
        val rovPt = project3D(0f, 0f, -32f * verticalExaggeration)
        drawCircle(AmberCaution, radius = 5f, center = rovPt)
        drawCircle(Color.White, radius = 2f, center = rovPt)

        // Draw Marked Polymetallic Nodule Clusters on Terrain
        nodules.forEach { nodule ->
          val nx = (nodule.centerNormX - 0.5f) * gridSize * step * 0.7f
          val ny = (nodule.centerNormY - 0.5f) * gridSize * step * 0.7f
          val nz = 0f
          val pt = project3D(nx, ny, nz)
          drawCircle(NoduleTargetEmerald, radius = 4f, center = pt)
          drawCircle(NoduleTargetEmerald.copy(alpha = 0.4f), radius = 8f, center = pt, style = Stroke(1f))
        }
      }

      // 3D Viewer Inset Compass & Scale Reference
      Column(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(10.dp)
          .background(GraphiteBlack.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Text(
          text = "COORDINATE FRAME: WGS 84 / UTM ZONE 10N",
          style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        )
        Text(
          text = String.format("ELEVATION: -4124.6 m | VERT EXAG: %.1fx | ORBIT: %.0f° / %.0f°", verticalExaggeration, rotationX, rotationZ),
          style = MaterialTheme.typography.bodySmall.copy(color = IceWhite, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        )
        Text(
          text = "DRAG TO ORBIT / ROTATE TERRAIN IN 3D",
          style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp)
        )
      }

      // Vertical Exaggeration Slider Control (Bottom Right)
      Column(
        modifier = Modifier
          .align(Alignment.BottomEnd)
          .padding(10.dp)
          .width(180.dp)
          .background(GraphiteBlack.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
          .padding(8.dp)
      ) {
        Text(
          text = "VERTICAL EXAGGERATION: ${String.format("%.1fx", verticalExaggeration)}",
          style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontSize = 8.5.sp)
        )
        Slider(
          value = verticalExaggeration,
          onValueChange = onSetExaggeration,
          valueRange = 1.0f..5.0f,
          colors = SliderDefaults.colors(thumbColor = SonarCyan, activeTrackColor = SonarCyan)
        )
      }
    }
  }
}
