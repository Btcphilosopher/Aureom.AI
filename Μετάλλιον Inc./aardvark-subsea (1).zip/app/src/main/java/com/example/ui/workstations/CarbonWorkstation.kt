package com.example.ui.workstations

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RamanSpectrumData
import com.example.ui.theme.*

@Composable
fun CarbonWorkstation(
  ramanData: RamanSpectrumData?,
  isBaselineSubtracted: Boolean,
  onToggleBaseline: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteBlack)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Analytics, contentDescription = "Carbon Raman", tint = SonarCyan, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "IN-SITU RAMAN SPECTROMETRY // 785nm EXCITED CARBON CHARACTERISATION",
          style = MaterialTheme.typography.labelMedium.copy(
            color = IceWhite,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
          onClick = onToggleBaseline,
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isBaselineSubtracted) SonarCyan else InstrumentNavy,
            contentColor = if (isBaselineSubtracted) GraphiteBlack else IceWhite
          ),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
          modifier = Modifier.height(28.dp).testTag("raman_baseline_toggle")
        ) {
          Text(
            text = if (isBaselineSubtracted) "BASELINE: SUBTRACTED" else "BASELINE: RAW",
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    if (ramanData != null) {
      // 2. Main Content Split: Raman Shift Spectral Plot (Left 70%) & Structural Peak Deconvolution (Right 30%)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Raman Shift Plot Canvas
        Box(
          modifier = Modifier
            .weight(1.3f)
            .fillMaxHeight()
            .background(GraphiteBlack, RoundedCornerShape(4.dp))
            .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
            .padding(10.dp)
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val padL = 40f
            val padB = 30f
            val plotW = w - padL - 10f
            val plotH = h - padB - 20f

            // Axes & Frame
            drawLine(BorderNavy, Offset(padL, 10f), Offset(padL, h - padB), 1.5f)
            drawLine(BorderNavy, Offset(padL, h - padB), Offset(w - 10f, h - padB), 1.5f)

            // Grid Lines: Shift from 800 to 2000 cm⁻¹
            val shifts = listOf(800, 1000, 1200, 1400, 1600, 1800, 2000)
            shifts.forEach { s ->
              val x = padL + ((s - 800f) / 1200f) * plotW
              drawLine(GridDivider, Offset(x, 10f), Offset(x, h - padB), 0.8f)
            }

            // Intensity Y Grid
            val maxInt = if (isBaselineSubtracted) 600f else 1100f
            for (i in 0..4) {
              val yVal = i * (maxInt / 4f)
              val y = (h - padB) - (yVal / maxInt) * plotH
              drawLine(GridDivider, Offset(padL, y), Offset(w - 10f, y), 0.8f)
            }

            // Draw Raw or Corrected Curve
            val pts = if (isBaselineSubtracted) ramanData.correctedPoints else ramanData.rawPoints
            val curvePath = Path()
            pts.forEachIndexed { i, (shift, intensity) ->
              val x = padL + ((shift - 800f) / 1200f) * plotW
              val y = (h - padB) - (intensity.coerceIn(0f, maxInt) / maxInt) * plotH
              if (i == 0) curvePath.moveTo(x, y) else curvePath.lineTo(x, y)
            }
            drawPath(curvePath, color = SonarCyan, style = Stroke(2.0f))

            // If raw mode, also draw baseline polynomial curve in subtle amber
            if (!isBaselineSubtracted) {
              val basePath = Path()
              ramanData.baselinePoints.forEachIndexed { i, (shift, base) ->
                val x = padL + ((shift - 800f) / 1200f) * plotW
                val y = (h - padB) - (base.coerceIn(0f, maxInt) / maxInt) * plotH
                if (i == 0) basePath.moveTo(x, y) else basePath.lineTo(x, y)
              }
              drawPath(basePath, color = AmberCaution.copy(alpha = 0.6f), style = Stroke(1.2f))
            }

            // Mark Peak Positions: D-band (1348 cm⁻¹), G-band (1584 cm⁻¹), Carbonate (1085 cm⁻¹)
            val dX = padL + ((ramanData.dBand.centerCm1 - 800f) / 1200f) * plotW
            val gX = padL + ((ramanData.gBand.centerCm1 - 800f) / 1200f) * plotW
            val cX = padL + ((1085f - 800f) / 1200f) * plotW

            // Peak indicator dashed lines
            drawLine(AmberCaution.copy(alpha = 0.5f), Offset(dX, 10f), Offset(dX, h - padB), 1f)
            drawLine(NoduleTargetEmerald.copy(alpha = 0.5f), Offset(gX, 10f), Offset(gX, h - padB), 1f)
            drawLine(IceWhite.copy(alpha = 0.4f), Offset(cX, 10f), Offset(cX, h - padB), 1f)
          }

          // X-Axis Shift Labels Overlay
          Row(
            modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(start = 40.dp, bottom = 4.dp)
              .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            listOf("800", "1000", "1200", "1348 (D)", "1584 (G)", "1800", "2000 cm⁻¹").forEach { label ->
              Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                  color = if (label.contains("D")) AmberCaution else if (label.contains("G")) NoduleTargetEmerald else SteelGrey,
                  fontSize = 8.sp,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold
                )
              )
            }
          }
        }

        // Structural Peak Deconvolution & Science Metrics (Right Pane)
        Column(
          modifier = Modifier
            .weight(0.7f)
            .fillMaxHeight()
            .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
            .padding(10.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = "DECONVOLUTED CARBON BANDS",
            style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontWeight = FontWeight.Bold)
          )

          // Intensity Ratio I_D / I_G Card
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(GraphiteBlack, RoundedCornerShape(4.dp))
              .border(1.dp, SonarCyan.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
              .padding(8.dp)
          ) {
            Column {
              Text("I_D / I_G INTENSITY RATIO", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp))
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = String.format("%.3f", ramanData.idIgRatio),
                style = MaterialTheme.typography.displayMedium.copy(
                  color = AmberCaution,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold
                )
              )
              Text(
                text = "DISORDER LEVEL: HIGH AMORPHOUS FRACTION (KEROGEN-LIKE)",
                style = MaterialTheme.typography.bodySmall.copy(color = IceWhite, fontSize = 8.sp)
              )
            }
          }

          // D-Band & G-Band Metrics
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Box(
              modifier = Modifier
                .weight(1f)
                .background(GraphiteBlack, RoundedCornerShape(4.dp))
                .border(1.dp, AmberCaution.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                .padding(6.dp)
            ) {
              Column {
                Text("D-BAND (DISORDER)", style = MaterialTheme.typography.labelSmall.copy(color = AmberCaution, fontSize = 7.5.sp))
                Text("${ramanData.dBand.centerCm1.toInt()} cm⁻¹", style = MaterialTheme.typography.labelMedium.copy(color = IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold))
                Text("FWHM: ${ramanData.dBand.fwhmCm1.toInt()} cm⁻¹", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp))
              }
            }

            Box(
              modifier = Modifier
                .weight(1f)
                .background(GraphiteBlack, RoundedCornerShape(4.dp))
                .border(1.dp, NoduleTargetEmerald.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                .padding(6.dp)
            ) {
              Column {
                Text("G-BAND (GRAPHITIC)", style = MaterialTheme.typography.labelSmall.copy(color = NoduleTargetEmerald, fontSize = 7.5.sp))
                Text("${ramanData.gBand.centerCm1.toInt()} cm⁻¹", style = MaterialTheme.typography.labelMedium.copy(color = IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold))
                Text("FWHM: ${ramanData.gBand.fwhmCm1.toInt()} cm⁻¹", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp))
              }
            }
          }

          // Carbonate Mineral Substrate (1085 cm⁻¹)
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(GraphiteBlack, RoundedCornerShape(4.dp))
              .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
              .padding(6.dp)
          ) {
            Column {
              Text("CARBONATE SYMMETRIC STRETCH (ν1)", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp))
              Text("1085 cm⁻¹ [CaCO₃ Calcite/Aragonite]", style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold))
              Text("Indicates biogenic/authigenic marine carbonate matrix", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp))
            }
          }

          Spacer(modifier = Modifier.weight(1f))

          // Mandatory Scientific Qualification
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(AlertRed.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
              .border(1.dp, AlertRed.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
              .padding(6.dp)
          ) {
            Text(
              text = "SCIENTIFIC PROTOCOL NOTICE: Raman D and G vibrational modes quantify structural sp² carbon disorder and carbonaceous maturity. They do NOT provide direct quantitative measurements of total organic carbon (TOC) percentage, which requires calibrated combustion/elemental assays.",
              style = MaterialTheme.typography.bodySmall.copy(color = AlertRed, fontSize = 7.5.sp, lineHeight = 10.sp)
            )
          }
        }
      }
    }
  }
}
