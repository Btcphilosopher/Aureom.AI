package com.example.ui.workstations

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.ImageEnhancementSettings
import com.example.data.model.NoduleDetection
import com.example.data.model.SubseaTelemetry
import com.example.ui.theme.*
import kotlin.math.sqrt

@Composable
fun OpticalWorkstation(
  telemetry: SubseaTelemetry,
  nodules: List<NoduleDetection>,
  selectedNodule: NoduleDetection?,
  onSelectNodule: (NoduleDetection) -> Unit,
  imageSettings: ImageEnhancementSettings,
  onUpdateImageSettings: (
    redAttenuation: Float?,
    dehaze: Float?,
    contrast: Float?,
    lowLight: Float?,
    splitScreen: Float?,
    isSplitEnabled: Boolean?,
    showReticle: Boolean?,
    showScaleBar: Boolean?,
  ) -> Unit,
  isCaliperActive: Boolean,
  caliperPointA: Pair<Float, Float>?,
  caliperPointB: Pair<Float, Float>?,
  onToggleCaliper: () -> Unit,
  onCaliperTap: (Float, Float) -> Unit,
  caliperDistanceMm: Float?,
  modifier: Modifier = Modifier,
) {
  var showControlDrawer by remember { mutableStateOf(false) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(AbyssBlack)
  ) {
    // 1. Base Deep Sea Optical Feed
    Image(
      painter = painterResource(id = R.drawable.seabed_nodule_field),
      contentDescription = "Abyssal Seabed Optical Feed",
      contentScale = ContentScale.Crop,
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(isCaliperActive) {
          detectTapGestures { offset ->
            val normX = offset.x / size.width
            val normY = offset.y / size.height
            if (isCaliperActive) {
              onCaliperTap(normX, normY)
            } else {
              // Check if tapped near any nodule
              val tapped = nodules.firstOrNull { n ->
                val dx = n.centerNormX - normX
                val dy = n.centerNormY - normY
                sqrt(dx * dx + dy * dy) < 0.08f
              }
              if (tapped != null) {
                onSelectNodule(tapped)
              }
            }
          }
        }
    )

    // 2. Optical Wavelength Attenuation & Enhancement Shader Overlay (Simulated via Canvas BlendModes)
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height

      // If split screen is active, draw enhanced tone on right side or left side
      if (imageSettings.isSplitScreenEnabled) {
        val splitX = w * imageSettings.splitScreenSlider

        // Raw mode side (slight deep-sea blue-green fog cast)
        drawRect(
          color = Color(0x330A2432),
          topLeft = Offset(0f, 0f),
          size = Size(splitX, h)
        )

        // Divider line between Raw and Enhanced
        drawLine(
          color = AmberCaution,
          start = Offset(splitX, 0f),
          end = Offset(splitX, h),
          strokeWidth = 2.5f
        )
      } else {
        // Full frame enhancement tint: Warm recovery of absorbed red spectrum
        val redBoostAlpha = (imageSettings.redWavelengthAttenuation * 0.18f).coerceIn(0f, 0.4f)
        drawRect(
          color = Color(0x99D2691E).copy(alpha = redBoostAlpha),
          topLeft = Offset.Zero,
          size = size,
          blendMode = BlendMode.ColorDodge
        )
      }

      // 3. Calibrated Laser Scaling Dots (10 cm physical reference dots)
      if (imageSettings.showLaserCalibratorDots) {
        val cx = w * 0.52f
        val cy = h * 0.88f
        val laserSpacingPx = w * 0.12f // 100mm spacing at this altitude
        drawCircle(AlertRed, radius = 4f, center = Offset(cx - laserSpacingPx / 2f, cy))
        drawCircle(Color.White, radius = 1.5f, center = Offset(cx - laserSpacingPx / 2f, cy))
        drawCircle(AlertRed, radius = 4f, center = Offset(cx + laserSpacingPx / 2f, cy))
        drawCircle(Color.White, radius = 1.5f, center = Offset(cx + laserSpacingPx / 2f, cy))
      }

      // 4. Overlaid Polymetallic Nodule Detection Bounding Polygons & Centroids
      nodules.forEach { nodule ->
        val isSelected = nodule.id == selectedNodule?.id
        val nx = nodule.centerNormX * w
        val ny = nodule.centerNormY * h
        val nw = nodule.widthNorm * w
        val nh = nodule.heightNorm * h

        val boxColor = if (isSelected) NoduleTargetEmerald else SonarCyan.copy(alpha = 0.85f)
        val strokeW = if (isSelected) 2.5f else 1.5f

        // Draw bounding box
        drawRect(
          color = boxColor,
          topLeft = Offset(nx - nw / 2f, ny - nh / 2f),
          size = Size(nw, nh),
          style = Stroke(width = strokeW)
        )

        // Corner tick marks
        val tick = 10f
        drawLine(boxColor, Offset(nx - nw / 2f, ny - nh / 2f), Offset(nx - nw / 2f + tick, ny - nh / 2f), strokeW)
        drawLine(boxColor, Offset(nx - nw / 2f, ny - nh / 2f), Offset(nx - nw / 2f, ny - nh / 2f + tick), strokeW)
        drawLine(boxColor, Offset(nx + nw / 2f, ny + nh / 2f), Offset(nx + nw / 2f - tick, ny + nh / 2f), strokeW)
        drawLine(boxColor, Offset(nx + nw / 2f, ny + nh / 2f), Offset(nx + nw / 2f, ny + nh / 2f - tick), strokeW)

        // Center reticle
        drawCircle(boxColor, radius = 2f, center = Offset(nx, ny))
      }

      // 5. Calibrated Central Optical Crosshair & Scale Bar
      if (imageSettings.showMeasurementReticle) {
        val cx = w / 2f
        val cy = h / 2f
        val rSize = 36f

        // Central crosshair ticks
        drawLine(SonarCyan.copy(alpha = 0.7f), Offset(cx - rSize, cy), Offset(cx + rSize, cy), strokeWidth = 1f)
        drawLine(SonarCyan.copy(alpha = 0.7f), Offset(cx, cy - rSize), Offset(cx, cy + rSize), strokeWidth = 1f)
        drawCircle(SonarCyan.copy(alpha = 0.5f), radius = 20f, center = Offset(cx, cy), style = Stroke(1f))

        // Mil-dot ticks
        for (i in -4..4) {
          if (i != 0) {
            drawLine(SonarCyan, Offset(cx + i * 16f, cy - 3f), Offset(cx + i * 16f, cy + 3f), strokeWidth = 1f)
            drawLine(SonarCyan, Offset(cx - 3f, cy + i * 16f), Offset(cx + 3f, cy + i * 16f), strokeWidth = 1f)
          }
        }
      }

      // 6. Caliper Measurement Tool Points & Line
      if (caliperPointA != null) {
        val pa = Offset(caliperPointA.first * w, caliperPointA.second * h)
        drawCircle(AmberCaution, radius = 5f, center = pa)
        drawCircle(Color.White, radius = 2f, center = pa)

        if (caliperPointB != null) {
          val pb = Offset(caliperPointB.first * w, caliperPointB.second * h)
          drawCircle(AmberCaution, radius = 5f, center = pb)
          drawCircle(Color.White, radius = 2f, center = pb)
          drawLine(AmberCaution, pa, pb, strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
        }
      }
    }

    // 7. Top-Left Optical Metadata Banner
    Column(
      modifier = Modifier
        .align(Alignment.TopStart)
        .padding(12.dp)
        .background(GraphiteBlack.copy(alpha = 0.75f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
      Text(
        text = "OPTICAL PRIMARY // SONY IMX586 4K RAW",
        style = MaterialTheme.typography.labelMedium.copy(
          color = SonarCyan,
          fontWeight = FontWeight.Bold
        )
      )
      Text(
        text = String.format("ALTITUDE: %.2fm | ATTEN CORR: %.0f%% | DEHAZE: %.0f%%",
          telemetry.altitudeM,
          imageSettings.redWavelengthAttenuation * 100f,
          imageSettings.dehazeDarkChannel * 100f
        ),
        style = MaterialTheme.typography.labelSmall.copy(
          color = IceWhite,
          fontFamily = FontFamily.Monospace,
          fontSize = 9.sp
        )
      )
      if (imageSettings.isSplitScreenEnabled) {
        Text(
          text = "SPLIT: [RAW CALIBRATED] <|> [ENHANCED SCIENTIFIC]",
          style = MaterialTheme.typography.labelSmall.copy(
            color = AmberCaution,
            fontWeight = FontWeight.Bold,
            fontSize = 8.5.sp
          )
        )
      }
    }

    // 8. Scale Bar Indicator in Bottom Left
    if (imageSettings.showScaleBar) {
      Box(
        modifier = Modifier
          .align(Alignment.BottomStart)
          .padding(start = 12.dp, bottom = 12.dp)
          .background(GraphiteBlack.copy(alpha = 0.75f), RoundedCornerShape(4.dp))
          .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.width(100.dp)
          ) {
            Box(modifier = Modifier.width(1.5.dp).height(8.dp).background(IceWhite))
            Box(modifier = Modifier.weight(1f).height(1.5.dp).background(IceWhite))
            Box(modifier = Modifier.width(1.5.dp).height(8.dp).background(IceWhite))
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "250 mm SCALE (CALIBRATED)",
            style = MaterialTheme.typography.labelSmall.copy(
              color = IceWhite,
              fontSize = 8.sp,
              fontFamily = FontFamily.Monospace
            )
          )
        }
      }
    }

    // 9. Caliper Distance Measurement Floating Badge
    if (isCaliperActive) {
      Box(
        modifier = Modifier
          .align(Alignment.TopCenter)
          .padding(top = 12.dp)
          .background(InstrumentNavy.copy(alpha = 0.9f), RoundedCornerShape(6.dp))
          .border(1.dp, AmberCaution, RoundedCornerShape(6.dp))
          .padding(horizontal = 14.dp, vertical = 6.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Straighten,
            contentDescription = "Caliper Active",
            tint = AmberCaution,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (caliperDistanceMm != null) {
              String.format("MEASURED DISTANCE: %.1f mm (%.2f cm)", caliperDistanceMm, caliperDistanceMm / 10f)
            } else if (caliperPointA != null) {
              "TAP SECOND POINT ON SEABED"
            } else {
              "TAP FIRST POINT TO MEASURE"
            },
            style = MaterialTheme.typography.labelMedium.copy(
              color = IceWhite,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold
            )
          )
        }
      }
    }

    // 10. Floating Image Processing Toolbar (Top Right)
    Row(
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(12.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Caliper Tool Toggle Button
      Button(
        onClick = onToggleCaliper,
        colors = ButtonDefaults.buttonColors(
          containerColor = if (isCaliperActive) AmberCaution else InstrumentNavy.copy(alpha = 0.85f),
          contentColor = if (isCaliperActive) GraphiteBlack else IceWhite
        ),
        shape = RoundedCornerShape(4.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        modifier = Modifier.height(36.dp).testTag("caliper_toggle_btn")
      ) {
        Icon(Icons.Default.Straighten, contentDescription = "Caliper", modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("CALIPER", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
      }

      // Split Screen Toggle
      Button(
        onClick = { onUpdateImageSettings(null, null, null, null, null, !imageSettings.isSplitScreenEnabled, null, null) },
        colors = ButtonDefaults.buttonColors(
          containerColor = if (imageSettings.isSplitScreenEnabled) SonarCyan else InstrumentNavy.copy(alpha = 0.85f),
          contentColor = if (imageSettings.isSplitScreenEnabled) GraphiteBlack else IceWhite
        ),
        shape = RoundedCornerShape(4.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        modifier = Modifier.height(36.dp).testTag("split_screen_btn")
      ) {
        Icon(Icons.Default.Compare, contentDescription = "Split Screen", modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("SPLIT", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
      }

      // Image Enhancement Controls Drawer Toggle
      Button(
        onClick = { showControlDrawer = !showControlDrawer },
        colors = ButtonDefaults.buttonColors(
          containerColor = InstrumentNavy.copy(alpha = 0.85f),
          contentColor = SonarCyan
        ),
        shape = RoundedCornerShape(4.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        modifier = Modifier.height(36.dp).testTag("image_enhancement_drawer_btn")
      ) {
        Icon(Icons.Default.Tune, contentDescription = "Enhancement", modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("ENHANCE", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
      }
    }

    // 11. Enhancement Sliders Flyout Panel
    AnimatedVisibility(
      visible = showControlDrawer,
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(top = 56.dp, end = 12.dp)
    ) {
      Surface(
        color = GraphiteBlack.copy(alpha = 0.95f),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderNavy),
        modifier = Modifier.width(280.dp)
      ) {
        Column(
          modifier = Modifier.padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "UNDERWATER OPTICAL PIPELINE",
              style = MaterialTheme.typography.labelSmall.copy(
                color = SonarCyan,
                fontWeight = FontWeight.Bold
              )
            )
            IconButton(
              onClick = { showControlDrawer = false },
              modifier = Modifier.size(24.dp)
            ) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = SteelGrey, modifier = Modifier.size(14.dp))
            }
          }

          // Red Wavelength Attenuation Slider
          Text(
            text = "RED ATTENUATION RESTORATION: ${(imageSettings.redWavelengthAttenuation * 100).toInt()}%",
            style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontSize = 9.sp)
          )
          Slider(
            value = imageSettings.redWavelengthAttenuation,
            onValueChange = { onUpdateImageSettings(it, null, null, null, null, null, null, null) },
            valueRange = 0.0f..1.0f,
            colors = SliderDefaults.colors(thumbColor = SonarCyan, activeTrackColor = SonarCyan)
          )

          // Dark Channel Dehazing Slider
          Text(
            text = "DARK CHANNEL DEHAZING: ${(imageSettings.dehazeDarkChannel * 100).toInt()}%",
            style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontSize = 9.sp)
          )
          Slider(
            value = imageSettings.dehazeDarkChannel,
            onValueChange = { onUpdateImageSettings(null, it, null, null, null, null, null, null) },
            valueRange = 0.0f..1.0f,
            colors = SliderDefaults.colors(thumbColor = SonarCyan, activeTrackColor = SonarCyan)
          )

          // Contrast Stretching Slider
          Text(
            text = "CONTRAST EXPANSION: ${String.format("%.2fx", imageSettings.contrastStretch)}",
            style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontSize = 9.sp)
          )
          Slider(
            value = imageSettings.contrastStretch,
            onValueChange = { onUpdateImageSettings(null, null, it, null, null, null, null, null) },
            valueRange = 1.0f..2.5f,
            colors = SliderDefaults.colors(thumbColor = SonarCyan, activeTrackColor = SonarCyan)
          )

          // Low Light Sensor Gain
          Text(
            text = "LOW-LIGHT GAIN: ${String.format("%.2fx", imageSettings.lowLightGain)}",
            style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontSize = 9.sp)
          )
          Slider(
            value = imageSettings.lowLightGain,
            onValueChange = { onUpdateImageSettings(null, null, null, it, null, null, null, null) },
            valueRange = 1.0f..3.0f,
            colors = SliderDefaults.colors(thumbColor = SonarCyan, activeTrackColor = SonarCyan)
          )

          Divider(color = BorderNavy, thickness = 1.dp)

          // Toggles for reticle and scale bar
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("SHOW RETICLE", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
            Switch(
              checked = imageSettings.showMeasurementReticle,
              onCheckedChange = { onUpdateImageSettings(null, null, null, null, null, null, it, null) }
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("CALIBRATED SCALE BAR", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
            Switch(
              checked = imageSettings.showScaleBar,
              onCheckedChange = { onUpdateImageSettings(null, null, null, null, null, null, null, it) }
            )
          }
        }
      }
    }
  }
}
