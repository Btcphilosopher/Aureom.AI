package com.example.ui.workstations

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.hud.InstrumentSectionHeader
import com.example.ui.theme.*

@Composable
fun SettingsWorkstation(
  modifier: Modifier = Modifier,
) {
  var selectedRole by remember { mutableStateOf("Senior Surveyor (Full Operations)") }
  var selectedCrs by remember { mutableStateOf("WGS 84 / UTM Zone 10N (EPSG:32610)") }
  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteBlack)
      .padding(8.dp)
      .verticalScroll(scrollState),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(Icons.Default.Settings, contentDescription = "Settings", tint = SonarCyan, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "STATION CONFIGURATION // ACCESS CONTROL & GEODETICS",
        style = MaterialTheme.typography.labelMedium.copy(
          color = IceWhite,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp
        )
      )
    }

    // 2. Role-Based Access Control (RBAC)
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(10.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      InstrumentSectionHeader("ROLE-BASED ACCESS CONTROL (ENTERPRISE SECURITY)")
      Text(
        text = "Active session operator: T. Hawke (Chief Geochemist / Μετάλλιον Ops)",
        style = MaterialTheme.typography.bodySmall.copy(color = IceWhite, fontSize = 9.sp)
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf("Administrator", "Senior Surveyor (Full Operations)", "Read-Only Observer").forEach { role ->
          val isSel = role == selectedRole
          Button(
            onClick = { selectedRole = role },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isSel) SonarCyan else GraphiteBlack,
              contentColor = if (isSel) GraphiteBlack else IceWhite
            ),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.weight(1f).height(32.dp).testTag("role_select_${role.take(4)}")
          ) {
            Text(role, fontSize = 9.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
          }
        }
      }

      Text(
        text = "Permissions: Read-only observers cannot modify physical sensor registers, trigger laser firing, or change sonar range gates.",
        style = MaterialTheme.typography.bodySmall.copy(color = AmberCaution, fontSize = 8.sp)
      )
    }

    // 3. Geodetic & Coordinate Reference Systems
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(10.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      InstrumentSectionHeader("COORDINATE REFERENCE SYSTEMS (CRS)")

      listOf(
        "WGS 84 / UTM Zone 10N (EPSG:32610)" to "Clarion-Clipperton Zone primary survey projection",
        "WGS 84 Ellipsoidal Geographic (EPSG:4326)" to "Raw USBL positioning transceiver frame",
        "Vehicle Hydrodynamic Body Frame (FRD)" to "Forward-Right-Down acoustic lever-arm calibration",
      ).forEach { (crs, desc) ->
        val isSel = crs == selectedCrs
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(if (isSel) SonarCyan.copy(alpha = 0.15f) else GraphiteBlack, RoundedCornerShape(4.dp))
            .border(1.dp, if (isSel) SonarCyan else BorderNavy, RoundedCornerShape(4.dp))
            .padding(8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text(crs, style = MaterialTheme.typography.labelSmall.copy(color = if (isSel) SonarCyan else IceWhite, fontWeight = FontWeight.Bold))
            Text(desc, style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 8.sp))
          }
          RadioButton(selected = isSel, onClick = { selectedCrs = crs })
        }
      }
    }

    // 4. Immutable Audit Log View
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(10.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
      InstrumentSectionHeader("PROVENANCE & SECURITY AUDIT LOG (SHA-256 SIGNED)")

      val auditRecords = listOf(
        "2026-11-02T18:59:00Z | OPERATOR: T. Hawke | EVENT: High-resolution hyperspectral cube 60-band capture saved.",
        "2026-11-02T18:55:12Z | OPERATOR: T. Hawke | EVENT: Nodule target ND-002184 segmented and linked to ICP-MS assay #8812.",
        "2026-11-02T18:50:33Z | SYSTEM: Auto-calibration PTP clock synchronised jitter < 15 microseconds.",
        "2026-11-02T18:45:00Z | SYSTEM: Sonar swath locked at 50 meters range, acoustic TVG applied.",
      )

      auditRecords.forEach { record ->
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(GraphiteBlack, RoundedCornerShape(2.dp))
            .padding(horizontal = 6.dp, vertical = 4.dp)
        ) {
          Text(record, style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontFamily = FontFamily.Monospace, fontSize = 7.5.sp))
        }
      }
    }
  }
}
