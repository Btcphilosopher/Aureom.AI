package com.example.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HudWorkstationMode
import com.example.ui.theme.*

@Composable
fun SubseaBottomRibbon(
  activeMode: HudWorkstationMode,
  onSelectMode: (HudWorkstationMode) -> Unit,
  modifier: Modifier = Modifier,
) {
  val scrollState = rememberScrollState()

  Surface(
    color = GraphiteBlack.copy(alpha = 0.95f),
    contentColor = IceWhite,
    modifier = modifier
      .fillMaxWidth()
      .height(52.dp)
      .border(width = 1.dp, color = BorderNavy)
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 8.dp)
        .horizontalScroll(scrollState),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      HudWorkstationMode.values().forEach { mode ->
        val isSelected = mode == activeMode
        val icon = getModeIcon(mode)

        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(
              if (isSelected) SonarCyan.copy(alpha = 0.18f) else DeepMarineBlue.copy(alpha = 0.5f)
            )
            .border(
              width = 1.dp,
              color = if (isSelected) SonarCyan else BorderNavy,
              shape = RoundedCornerShape(4.dp)
            )
            .clickable { onSelectMode(mode) }
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("tab_${mode.name.lowercase()}")
        ) {
          Icon(
            imageVector = icon,
            contentDescription = mode.label,
            tint = if (isSelected) SonarCyan else SteelGrey,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Column {
            Text(
              text = mode.code,
              style = MaterialTheme.typography.labelSmall.copy(
                color = if (isSelected) SonarCyan else SteelGrey.copy(alpha = 0.7f),
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp
              )
            )
            Text(
              text = mode.label,
              style = MaterialTheme.typography.labelMedium.copy(
                color = if (isSelected) IceWhite else SteelGrey,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                letterSpacing = 0.5.sp
              )
            )
          }
        }
      }
    }
  }
}

private fun getModeIcon(mode: HudWorkstationMode): ImageVector {
  return when (mode) {
    HudWorkstationMode.OPTICAL -> Icons.Default.Videocam
    HudWorkstationMode.HYPERSPECTRAL -> Icons.Default.FilterVintage
    HudWorkstationMode.SONAR -> Icons.Default.GraphicEq
    HudWorkstationMode.MAPPING_3D -> Icons.Default.ViewInAr
    HudWorkstationMode.NODULES -> Icons.Default.Grain
    HudWorkstationMode.CARBON -> Icons.Default.Analytics
    HudWorkstationMode.SURVEY -> Icons.Default.Explore
    HudWorkstationMode.DIAGNOSTICS -> Icons.Default.Memory
    HudWorkstationMode.SETTINGS -> Icons.Default.Settings
  }
}
