package com.example.ui.workstations

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.SonarSettings
import com.example.data.model.SubseaTelemetry
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun SonarWorkstation(
  telemetry: SubseaTelemetry,
  sonarSettings: SonarSettings,
  onUpdateSonarSettings: (rangeM: Int?, freqKHz: Int?, gainDb: Float?, showOverlay: Boolean?) -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteBlack)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Top Sonar Telemetry Ribbon
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.GraphicEq, contentDescription = "Sonar", tint = SonarCyan, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "MULTIBEAM & SIDE-SCAN SONAR // KONGSBERG EM2040 MKII",
          style = MaterialTheme.typography.labelMedium.copy(
            color = IceWhite,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "FREQ: ${sonarSettings.frequencyKHz} kHz",
          style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        )
        Text(
          text = "SVP: ${sonarSettings.soundVelocityMs} m/s",
          style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontFamily = FontFamily.Monospace)
        )
        Text(
          text = "PING: ${sonarSettings.pingRateHz} Hz",
          style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontFamily = FontFamily.Monospace)
        )
        Text(
          text = "SWATH: ${sonarSettings.rangeMeters * 2} m",
          style = MaterialTheme.typography.labelSmall.copy(color = AmberCaution, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        )
      }
    }

    // 2. Main Viewport: Side-Scan Waterfall (Center) + Across-Track Bathymetric Beam Fan (Bottom/Side)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Side-scan Waterfall Display (Left 65%)
      Box(
        modifier = Modifier
          .weight(1.3f)
          .fillMaxHeight()
          .background(AbyssBlack, RoundedCornerShape(4.dp))
          .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
      ) {
        // High-resolution acoustic waterfall echogram
        Image(
          painter = painterResource(id = R.drawable.sonar_waterfall_texture),
          contentDescription = "Side-scan Sonar Waterfall",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Overlay Nadir line, Range Graticule, and Target Markers
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height
          val cx = w / 2f

          // Center Nadir Line (Vehicle Track)
          drawLine(
            color = AmberCaution,
            start = Offset(cx, 0f),
            end = Offset(cx, h),
            strokeWidth = 1.5f
          )

          // Port & Starboard range ticks (-50m to +50m)
          val range = sonarSettings.rangeMeters
          listOf(-0.8f, -0.6f, -0.4f, -0.2f, 0.2f, 0.4f, 0.6f, 0.8f).forEach { frac ->
            val x = cx + frac * (w / 2f)
            drawLine(
              color = SonarCyan.copy(alpha = 0.35f),
              start = Offset(x, 0f),
              end = Offset(x, h),
              strokeWidth = 0.8f
            )
          }

          // Real-time acoustic ping head line
          val pingY = h * 0.92f
          drawLine(
            color = Color.White.copy(alpha = 0.9f),
            start = Offset(0f, pingY),
            end = Offset(w, pingY),
            strokeWidth = 2f
          )
        }

        // Port / Starboard Identifiers
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.TopCenter)
            .padding(horizontal = 16.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "PORT [450 kHz CYAN]",
            style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontWeight = FontWeight.Bold)
          )
          Text(
            text = "STARBOARD [900 kHz GOLD]",
            style = MaterialTheme.typography.labelSmall.copy(color = SonarGold, fontWeight = FontWeight.Bold)
          )
        }

        // Scientific Disclaimer Flag
        Box(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(8.dp)
            .background(GraphiteBlack.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "ACOUSTIC INTENSITY REFLECTS SEABED IMPEDANCE & MICRO-RELIEF ONLY",
            style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp)
          )
        }
      }

      // Multibeam Bathymetry Profile & Controls (Right 35%)
      Column(
        modifier = Modifier
          .weight(0.7f)
          .fillMaxHeight(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Multibeam Cross-Track Fan Profile Canvas
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
            .padding(8.dp)
        ) {
          Column(modifier = Modifier.fillMaxSize()) {
            Text(
              text = "MULTIBEAM CROSS-TRACK BATHYMETRY",
              style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontWeight = FontWeight.Bold)
            )
            Text(
              text = "128 BEAMS (-60° TO +60°) | DEPTH: 4,124.6 m",
              style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.5.sp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Canvas(modifier = Modifier.fillMaxSize()) {
              val w = size.width
              val h = size.height
              val cx = w / 2f
              val topY = 16f
              val bottomY = h - 20f

              // Draw transducer origin point
              drawCircle(AmberCaution, radius = 4f, center = Offset(cx, topY))

              // Draw acoustic beam fan lines (-60° to +60°)
              val angles = listOf(-60f, -45f, -30f, -15f, 0f, 15f, 30f, 45f, 60f)
              angles.forEach { deg ->
                val rad = Math.toRadians(deg.toDouble() + 90.0)
                val ex = cx + (cos(rad) * (bottomY - topY) * 1.1).toFloat()
                val ey = topY + (sin(rad) * (bottomY - topY)).toFloat()
                drawLine(
                  color = SonarCyan.copy(alpha = 0.25f),
                  start = Offset(cx, topY),
                  end = Offset(ex, ey),
                  strokeWidth = 0.8f
                )
              }

              // Draw seabed detected profile
              val profilePath = Path()
              val points = 32
              for (i in 0..points) {
                val frac = i.toFloat() / points
                val x = frac * w
                val distFromCenter = abs(frac - 0.5f) * 2f
                // Seabed micro-bathymetry with nodule mound hummocks
                val zOffset = sin(frac * 14f) * 6f + cos(frac * 8f) * 4f + (distFromCenter * 8f)
                val y = bottomY - 18f + zOffset
                if (i == 0) profilePath.moveTo(x, y) else profilePath.lineTo(x, y)
              }
              drawPath(profilePath, color = NoduleTargetEmerald, style = Stroke(2.5f))

              // Bottom detection gate envelope
              drawRect(
                color = BorderNavy,
                topLeft = Offset(0f, bottomY - 32f),
                size = Size(w, 28f),
                style = Stroke(1f)
              )
            }
          }
        }

        // Sonar Parameter Controls
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
            .padding(8.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Text(
            text = "ACOUSTIC CONTROLS",
            style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontWeight = FontWeight.Bold)
          )

          // Range Selector Buttons
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            listOf(15, 30, 50, 100).forEach { r ->
              val isSel = r == sonarSettings.rangeMeters
              Button(
                onClick = { onUpdateSonarSettings(r, null, null, null) },
                colors = ButtonDefaults.buttonColors(
                  containerColor = if (isSel) SonarCyan else GraphiteBlack,
                  contentColor = if (isSel) GraphiteBlack else IceWhite
                ),
                shape = RoundedCornerShape(4.dp),
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                modifier = Modifier.weight(1f).height(30.dp).testTag("sonar_range_${r}m")
              ) {
                Text("${r}m", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
              }
            }
          }

          // Dual Frequency Toggle
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Button(
              onClick = { onUpdateSonarSettings(null, 450, null, null) },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (sonarSettings.frequencyKHz == 450) SonarCyan else GraphiteBlack,
                contentColor = if (sonarSettings.frequencyKHz == 450) GraphiteBlack else IceWhite
              ),
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.weight(1f).height(30.dp)
            ) {
              Text("450 kHz", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }

            Button(
              onClick = { onUpdateSonarSettings(null, 900, null, null) },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (sonarSettings.frequencyKHz == 900) SonarCyan else GraphiteBlack,
                contentColor = if (sonarSettings.frequencyKHz == 900) GraphiteBlack else IceWhite
              ),
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.weight(1f).height(30.dp)
            ) {
              Text("900 kHz HI-RES", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
          }

          // TVG Gain Slider
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "TVG GAIN: ${sonarSettings.gainTvgDb.toInt()} dB",
              style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 9.sp)
            )
          }
          Slider(
            value = sonarSettings.gainTvgDb,
            onValueChange = { onUpdateSonarSettings(null, null, it, null) },
            valueRange = 0f..40f,
            colors = SliderDefaults.colors(thumbColor = SonarCyan, activeTrackColor = SonarCyan)
          )
        }
      }
    }
  }
}
