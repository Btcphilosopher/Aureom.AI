package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AardvarkColorScheme = darkColorScheme(
  primary = SonarCyan,
  onPrimary = GraphiteBlack,
  primaryContainer = InstrumentNavy,
  onPrimaryContainer = IceWhite,
  secondary = AmberCaution,
  onSecondary = GraphiteBlack,
  secondaryContainer = DeepMarineBlue,
  onSecondaryContainer = IceWhite,
  tertiary = NoduleTargetEmerald,
  onTertiary = GraphiteBlack,
  background = GraphiteBlack,
  onBackground = IceWhite,
  surface = DeepMarineBlue,
  onSurface = IceWhite,
  surfaceVariant = InstrumentNavy,
  onSurfaceVariant = SteelGrey,
  error = AlertRed,
  onError = IceWhite,
  outline = BorderNavy,
  outlineVariant = GridDivider,
)

@Composable
fun AardvarkSubseaTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = AardvarkColorScheme,
    typography = AardvarkTypography,
    content = content
  )
}
