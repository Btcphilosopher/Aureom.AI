package com.example.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NoduleDetection
import com.example.data.model.SensorDiagnostics
import com.example.data.model.SensorHealth
import com.example.data.model.SonarSettings
import com.example.ui.theme.*

@Composable
fun RightInstrumentColumn(
  diagnostics: SensorDiagnostics,
  sonarSettings: SonarSettings,
  activeNodules: List<NoduleDetection>,
  selectedBandWavelength: Int,
  modifier: Modifier = Modifier,
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .width(200.dp)
      .fillMaxHeight()
      .background(GraphiteBlack.copy(alpha = 0.90f))
      .border(width = 1.dp, color = BorderNavy)
      .padding(8.dp)
      .verticalScroll(scrollState),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    InstrumentSectionHeader(title = "SENSOR ACQUISITION")

    // Active Sensor Health Matrix
    SensorHealthGrid(diagnostics = diagnostics)

    // Imaging Parameters Card
    InstrumentSectionHeader(title = "OPTICAL PARAMETERS")
    TelemetryCard(
      label = "FRAME LATENCY / RATE",
      value = String.format("%.1f FPS", diagnostics.opticalFps),
      subValue = String.format("%.1f ms latency | %d drop", diagnostics.opticalLatencyMs, diagnostics.droppedFrames),
      highlightColor = SonarCyan
    )

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Box(modifier = Modifier.weight(1f)) {
        TelemetryCard(
          label = "EXPOSURE",
          value = String.format("%.1f ms", diagnostics.exposureMs),
          subValue = "AUTO-SHUTTER",
          highlightColor = IceWhite
        )
      }
      Box(modifier = Modifier.weight(1f)) {
        TelemetryCard(
          label = "GAIN / SNR",
          value = String.format("%.1fdB", diagnostics.analogGainDb),
          subValue = String.format("SNR: %.1fdB", diagnostics.snrDb),
          highlightColor = IceWhite
        )
      }
    }

    // Active Spectral & Acoustic Range
    InstrumentSectionHeader(title = "CHANNELS & RANGES")
    TelemetryCard(
      label = "SPECTRAL CHANNEL",
      value = "$selectedBandWavelength nm",
      subValue = "FWHM: 8 nm | 60 BANDS",
      highlightColor = SpectralViolet
    )

    TelemetryCard(
      label = "SONAR RANGE",
      value = "${sonarSettings.rangeMeters} m",
      subValue = "${sonarSettings.frequencyKHz} kHz | TVG: ${sonarSettings.gainTvgDb.toInt()}dB",
      highlightColor = SonarCyan
    )

    // Polymetallic Intelligence Stats
    InstrumentSectionHeader(title = "NODULE INTELLIGENCE")
    val totalCount = activeNodules.size
    val totalDensityKgM2 = activeNodules.sumOf { it.spatialDensityContributionKgM2.toDouble() }.toFloat()
    TelemetryCard(
      label = "DETECTED NODULES",
      value = "$totalCount TARGETS",
      subValue = String.format("SPATIAL DENSITY: %.1f kg/m²", totalDensityKgM2),
      highlightColor = NoduleTargetEmerald
    )

    // Storage & Bus Diagnostics
    InstrumentSectionHeader(title = "SYSTEM DATA BUS")
    TelemetryCard(
      label = "FPGA DMA STREAM",
      value = String.format("%.1f Mbps", diagnostics.fpgaDmaThroughputMbps),
      subValue = String.format("FIFO: %.0f%% | BER: %s", diagnostics.fpgaFifoLevelPct, diagnostics.opticalLinkBer),
      highlightColor = IceWhite
    )

    TelemetryCard(
      label = "PAYLOAD NVME",
      value = String.format("%.1f GB", diagnostics.storageRemainingGb),
      subValue = "ZARR / HDF5 STREAMING",
      highlightColor = IceWhite
    )
  }
}

@Composable
fun SensorHealthGrid(diagnostics: SensorDiagnostics) {
  val sensors = listOf(
    "OPT 4K" to diagnostics.opticalCameraHealth,
    "HSI SWIR" to diagnostics.hyperspectralHealth,
    "MBES" to diagnostics.multibeamHealth,
    "SSS" to diagnostics.sidescanHealth,
    "USBL" to diagnostics.usblHealth,
    "RAMAN" to diagnostics.ramanHealth,
    "CTD" to diagnostics.ctdHealth,
    "INS" to diagnostics.insNavHealth,
  )

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
      .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
      .padding(6.dp),
    verticalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    // 2x4 grid
    for (row in 0 until 4) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        for (col in 0 until 2) {
          val (name, health) = sensors[row * 2 + col]
          val (color, text) = when (health) {
            SensorHealth.OPTIMAL -> ActiveGreen to "OK"
            SensorHealth.CALIBRATING -> AmberCaution to "CAL"
            SensorHealth.DEGRADED -> AmberCaution to "WARN"
            SensorHealth.FAULT -> AlertRed to "ERR"
            SensorHealth.SIMULATED -> SonarCyan to "SIM"
          }
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.width(88.dp)
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .background(color, RoundedCornerShape(3.dp))
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = name,
              style = MaterialTheme.typography.labelSmall.copy(
                color = IceWhite,
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace
              )
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
              text = text,
              style = MaterialTheme.typography.labelSmall.copy(
                color = color,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
              )
            )
          }
        }
      }
    }
  }
}
