package com.example.ui.workstations

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HyperspectralBand
import com.example.data.model.ReferenceSpectralProfile
import com.example.data.model.SpectralCurvePoint
import com.example.ui.theme.*

@Composable
fun HyperspectralWorkstation(
  bands: List<HyperspectralBand>,
  selectedBandIndex: Int,
  onSelectBand: (Int) -> Unit,
  referenceProfiles: List<ReferenceSpectralProfile>,
  sampledPoints: List<SpectralCurvePoint>,
  onSamplePoint: (Float, Float) -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedCompositeMode by remember { mutableStateOf("Fe-Mn Nodule Composite (650/540/460nm)") }
  var sampledLocation by remember { mutableStateOf<Pair<Float, Float>?>(0.38f to 0.64f) }

  val currentBand = bands.getOrNull(selectedBandIndex) ?: HyperspectralBand(650, 25, "650 nm", "Red")

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteBlack)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Top Controls Bar: Wavelength Slider & Composite Presets
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.FilterVintage, contentDescription = "HSI", tint = SonarCyan, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "HYPERSPECTRAL WORKSTATION // SPEC-CUBE SWIR-400-1000",
          style = MaterialTheme.typography.labelMedium.copy(
            color = IceWhite,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        )
      }

      // Wavelength quick read
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "ACTIVE BAND: ${currentBand.wavelengthNm} nm",
          style = MaterialTheme.typography.labelMedium.copy(
            color = SonarCyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          )
        )
        if (currentBand.atmosphericWaterAbsorptionFlag) {
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "[H₂O ATTENUATION BAND]",
            style = MaterialTheme.typography.labelSmall.copy(
              color = AmberCaution,
              fontWeight = FontWeight.Bold
            )
          )
        }
      }
    }

    // 2. Main Content Split: Hyperspectral Spatial Viewport (Left) & Spectral Signature Graph (Right)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Hyperspectral Spatial False-Colour Canvas (Left Pane)
      Box(
        modifier = Modifier
          .weight(1.1f)
          .fillMaxHeight()
          .background(AbyssBlack, RoundedCornerShape(4.dp))
          .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
          .pointerInput(Unit) {
            detectTapGestures { offset ->
              val nx = offset.x / size.width
              val ny = offset.y / size.height
              sampledLocation = nx to ny
              onSamplePoint(nx, ny)
            }
          }
      ) {
        // Draw spatial spectral false-color rendering
        Canvas(modifier = Modifier.fillMaxSize()) {
          val w = size.width
          val h = size.height

          // Background false color based on active wavelength
          val bandNorm = (currentBand.wavelengthNm - 400f) / 600f
          val tint = when {
            currentBand.wavelengthNm < 500 -> Color(0xFF0F3854)
            currentBand.wavelengthNm < 600 -> Color(0xFF144D3B)
            currentBand.wavelengthNm < 750 -> Color(0xFF5A3E1B)
            else -> Color(0xFF451A4A) // SWIR false color
          }

          drawRect(color = tint, topLeft = Offset.Zero, size = size)

          // Synthetic spectral nodule absorption shapes
          val nodulePositions = listOf(
            Offset(w * 0.38f, h * 0.64f) to 38f,
            Offset(w * 0.54f, h * 0.52f) to 48f,
            Offset(w * 0.22f, h * 0.72f) to 28f,
            Offset(w * 0.68f, h * 0.74f) to 42f,
            Offset(w * 0.46f, h * 0.82f) to 34f,
            Offset(w * 0.28f, h * 0.44f) to 52f,
          )

          nodulePositions.forEach { (pos, radius) ->
            // Nodule absorption signature varies by wavelength
            val noduleColor = if (currentBand.wavelengthNm < 600) {
              Color(0xFF080D12) // Strong absorption in blue/green
            } else {
              Color(0xFF805230).copy(alpha = 0.8f) // Higher reflectance in NIR
            }
            drawCircle(color = noduleColor, radius = radius, center = pos)
            drawCircle(color = SonarCyan.copy(alpha = 0.5f), radius = radius, center = pos, style = Stroke(1f))
          }

          // Sampled point reticle
          sampledLocation?.let { (sx, sy) ->
            val px = sx * w
            val py = sy * h
            drawLine(AmberCaution, Offset(px - 16f, py), Offset(px + 16f, py), strokeWidth = 1.5f)
            drawLine(AmberCaution, Offset(px, py - 16f), Offset(px, py + 16f), strokeWidth = 1.5f)
            drawCircle(AmberCaution, radius = 8f, center = Offset(px, py), style = Stroke(1.5f))
          }
        }

        // Overlay Instructions
        Box(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(8.dp)
            .background(GraphiteBlack.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "TAP TO EXTRACT REGION-OF-INTEREST (ROI) SPECTRAL PROFILE",
            style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontSize = 8.5.sp)
          )
        }
      }

      // Spectral Curve & Library Comparison (Right Pane)
      Column(
        modifier = Modifier
          .weight(0.9f)
          .fillMaxHeight()
          .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
          .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "SPECTRAL REFLECTANCE CURVE",
            style = MaterialTheme.typography.labelSmall.copy(
              color = SonarCyan,
              fontWeight = FontWeight.Bold
            )
          )
          Text(
            text = "CALIBRATED [0.0 - 1.0]",
            style = MaterialTheme.typography.labelSmall.copy(
              color = SteelGrey,
              fontSize = 8.sp,
              fontFamily = FontFamily.Monospace
            )
          )
        }

        // Spectral Graph Canvas
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .background(GraphiteBlack, RoundedCornerShape(4.dp))
            .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
            .padding(4.dp)
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val padL = 30f
            val padB = 24f
            val plotW = w - padL - 8f
            val plotH = h - padB - 8f

            // Axes & Grid
            drawLine(BorderNavy, Offset(padL, 8f), Offset(padL, h - padB), 1f)
            drawLine(BorderNavy, Offset(padL, h - padB), Offset(w - 8f, h - padB), 1f)

            // Y-Grid (0.0 to 0.5 reflectance)
            for (i in 0..5) {
              val yVal = i * 0.1f
              val y = (h - padB) - (yVal / 0.5f) * plotH
              drawLine(GridDivider, Offset(padL, y), Offset(w - 8f, y), 0.8f)
            }

            // X-Grid (400, 600, 800, 1000 nm)
            val wlTicks = listOf(400, 600, 800, 1000)
            wlTicks.forEach { wl ->
              val x = padL + ((wl - 400f) / 600f) * plotW
              drawLine(GridDivider, Offset(x, 8f), Offset(x, h - padB), 0.8f)
            }

            // Plot Reference Spectral Profiles
            referenceProfiles.forEach { profile ->
              val path = Path()
              profile.dataPoints.forEachIndexed { i, pt ->
                val x = padL + ((pt.wavelengthNm - 400f) / 600f) * plotW
                val y = (h - padB) - (pt.reflectance / 0.5f) * plotH
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
              }
              drawPath(path, color = Color(profile.colorHex).copy(alpha = 0.5f), style = Stroke(1.2f))
            }

            // Plot Sampled ROI Curve (Bold highlight)
            if (sampledPoints.isNotEmpty()) {
              val samplePath = Path()
              sampledPoints.forEachIndexed { i, pt ->
                val x = padL + ((pt.wavelengthNm - 400f) / 600f) * plotW
                val y = (h - padB) - (pt.reflectance.coerceIn(0f, 0.5f) / 0.5f) * plotH
                if (i == 0) samplePath.moveTo(x, y) else samplePath.lineTo(x, y)
              }
              drawPath(samplePath, color = AmberCaution, style = Stroke(2.5f))
            }

            // Vertical line for active selected band
            val activeX = padL + ((currentBand.wavelengthNm - 400f) / 600f) * plotW
            drawLine(
              color = SonarCyan,
              start = Offset(activeX, 8f),
              end = Offset(activeX, h - padB),
              strokeWidth = 1.5f
            )
          }
        }

        // Legend & SAM Match
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
          Text(
            text = "SPECTRAL ANGLE MAPPER (SAM): 0.94 MATCH -> Fe-Mn NODULE STANDARD",
            style = MaterialTheme.typography.labelSmall.copy(
              color = NoduleTargetEmerald,
              fontWeight = FontWeight.Bold,
              fontSize = 8.5.sp
            )
          )
          referenceProfiles.take(3).forEach { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(modifier = Modifier.size(8.dp, 2.dp).background(Color(p.colorHex)))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = p.label,
                style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp)
              )
            }
          }
        }
      }
    }

    // 3. Bottom Wavelength Selector Slider & Band Chips
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "WAVELENGTH TUNER: 400 nm (VIS) — 1000 nm (SWIR)",
          style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.5.sp)
        )
        Text(
          text = "${currentBand.bandName} [BAND #${currentBand.bandIndex + 1}/60]",
          style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        )
      }

      Slider(
        value = selectedBandIndex.toFloat(),
        onValueChange = { onSelectBand(it.toInt()) },
        valueRange = 0f..(bands.size - 1).toFloat(),
        steps = bands.size - 2,
        colors = SliderDefaults.colors(thumbColor = SonarCyan, activeTrackColor = SonarCyan),
        modifier = Modifier.testTag("hyperspectral_band_slider")
      )
    }
  }
}
