package com.example.ui.workstations

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SensorDiagnostics
import com.example.ui.hud.InstrumentSectionHeader
import com.example.ui.hud.TelemetryCard
import com.example.ui.theme.*

@Composable
fun DiagnosticsWorkstation(
  diagnostics: SensorDiagnostics,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteBlack)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Memory, contentDescription = "FPGA Diagnostics", tint = SonarCyan, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "FPGA HARDWARE & SENSOR INTERFACES // SILICA FLUX ARCHITECTURE",
          style = MaterialTheme.typography.labelMedium.copy(
            color = IceWhite,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        )
      }

      Text(
        text = "CLOCK LOCK: 250 MHz PLL | PTP IEEE 1588 SYNC",
        style = MaterialTheme.typography.labelSmall.copy(color = ActiveGreen, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
      )
    }

    // 2. Main Content Split: FPGA Register Map (Left 50%) & Bus / Optical Link Health (Right 50%)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Left Pane: Silica Flux Hardware Register Map
      Column(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight()
          .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
          .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        InstrumentSectionHeader("STANDARDISED HARDWARE REGISTERS (SILICA FLUX)")

        val registers = listOf(
          Triple("0x0000", "REG_STATUS", "0x00000001 (STREAMING ACTIVE | PLL LOCKED)"),
          Triple("0x0004", "REG_CONTROL", "0x00000003 (DMA_EN | TRIGGER_INT)"),
          Triple("0x0008", "REG_TIMESTAMP_LO", "0x6739A014 (32-BIT SUB-NS CLK)"),
          Triple("0x000C", "REG_TIMESTAMP_HI", "0x00000001 (UTC EPOCH S)"),
          Triple("0x0010", "REG_DMA_BURST_SZ", "0x00000400 (1024-WORD BURST)"),
          Triple("0x0014", "REG_FIFO_WATERMARK", "0x0000003C (24% OCCUPANCY)"),
          Triple("0x0018", "REG_ADC_CALIB_OFFSET", "0x00000002 (±0.002V TRIM)"),
          Triple("0x001C", "REG_OPTICAL_BER", "0x00000000 (BER < 10⁻¹²)"),
        )

        LazyColumn(
          modifier = Modifier.fillMaxWidth().weight(1f),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          items(registers.size) { i ->
            val (addr, name, value) = registers[i]
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(GraphiteBlack, RoundedCornerShape(4.dp))
                .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(addr, style = MaterialTheme.typography.labelSmall.copy(color = AmberCaution, fontFamily = FontFamily.Monospace, fontSize = 8.sp))
                  Text(name, style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold))
                }
                Text(value, style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontFamily = FontFamily.Monospace, fontSize = 8.sp))
              }
            }
          }
        }
      }

      // Right Pane: Hardware Diagnostics & Sensor Calibration Metrics
      Column(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight()
          .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
          .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        InstrumentSectionHeader("PHYSICAL TRANSDUCER & OPTICAL FIBRE LINK")

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Box(modifier = Modifier.weight(1f)) {
            TelemetryCard("HOUSING TEMP", String.format("%.1f °C", diagnostics.sensorHousingTempC), "Peltier Cooled", SonarCyan)
          }
          Box(modifier = Modifier.weight(1f)) {
            TelemetryCard("DMA THROUGHPUT", String.format("%.1f Mbps", diagnostics.fpgaDmaThroughputMbps), "PCIe Gen3 x4", IceWhite)
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Box(modifier = Modifier.weight(1f)) {
            TelemetryCard("FIFO BUFFER", String.format("%.0f%%", diagnostics.fpgaFifoLevelPct), "No Overflows", ActiveGreen)
          }
          Box(modifier = Modifier.weight(1f)) {
            TelemetryCard("OPTICAL LINK BER", diagnostics.opticalLinkBer, "Single-Mode Tether", ActiveGreen)
          }
        }

        Spacer(modifier = Modifier.height(4.dp))
        InstrumentSectionHeader("FACTORY CALIBRATION MATRICES")

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(GraphiteBlack, RoundedCornerShape(4.dp))
            .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
            .padding(8.dp)
        ) {
          Column {
            Text("CAMERA INTRINSICS MATRIX (PINHOLE + RADIAL BROWN)", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp))
            Text("fx: 2842.1 | fy: 2841.9 | cx: 1920.0 | cy: 1080.0", style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp))
            Text("k1: -0.142 | k2: 0.082 | p1: 0.0004 | p2: -0.0001", style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp))
          }
        }

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(GraphiteBlack, RoundedCornerShape(4.dp))
            .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
            .padding(8.dp)
        ) {
          Column {
            Text("ACOUSTIC LEVER-ARM TRANSLATION (MBES TO INS)", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp))
            Text("ΔX: +0.450 m | ΔY: 0.000 m | ΔZ: -0.220 m (±0.002m)", style = MaterialTheme.typography.labelSmall.copy(color = AmberCaution, fontFamily = FontFamily.Monospace, fontSize = 8.5.sp))
          }
        }
      }
    }
  }
}
