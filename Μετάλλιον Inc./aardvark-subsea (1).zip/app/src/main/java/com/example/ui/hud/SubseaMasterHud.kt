package com.example.ui.hud

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.HudWorkstationMode
import com.example.ui.SubseaViewModel
import com.example.ui.theme.GraphiteBlack
import com.example.ui.workstations.*

@Composable
fun SubseaMasterHud(
  viewModel: SubseaViewModel,
  modifier: Modifier = Modifier,
) {
  val telemetry by viewModel.telemetry.collectAsState()
  val diagnostics by viewModel.diagnostics.collectAsState()
  val nodules by viewModel.nodules.collectAsState()
  val selectedNodule by viewModel.selectedNodule.collectAsState()
  val hyperspectralBands by viewModel.hyperspectralBands.collectAsState()
  val selectedBandIndex by viewModel.selectedBandIndex.collectAsState()
  val referenceProfiles by viewModel.referenceSpectralProfiles.collectAsState()
  val sampledSpectralPoints by viewModel.sampledSpectralCurve.collectAsState()
  val ramanData by viewModel.ramanData.collectAsState()
  val isRamanBaselineSubtracted by viewModel.isRamanBaselineSubtracted.collectAsState()
  val imageSettings by viewModel.imageSettings.collectAsState()
  val sonarSettings by viewModel.sonarSettings.collectAsState()
  val activeMode by viewModel.activeMode.collectAsState()
  val isHudCollapsed by viewModel.isHudCollapsed.collectAsState()
  val missionEvents by viewModel.missionEvents.collectAsState()
  val isSurveyActive by viewModel.isSurveyActive.collectAsState()
  val exportLog by viewModel.exportLog.collectAsState()

  val isCaliperActive by viewModel.isCaliperActive.collectAsState()
  val caliperPointA by viewModel.caliperPointA.collectAsState()
  val caliperPointB by viewModel.caliperPointB.collectAsState()
  val caliperDistanceMm = remember(caliperPointA, caliperPointB) {
    viewModel.calculatePhysicalDistanceMm()
  }

  val rotationX by viewModel.rotationX.collectAsState()
  val rotationZ by viewModel.rotationZ.collectAsState()
  val verticalExaggeration by viewModel.verticalExaggeration.collectAsState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteBlack)
      .windowInsetsPadding(WindowInsets.safeDrawing)
  ) {
    // 1. TOP BAR
    SubseaHudTopBar(
      telemetry = telemetry,
      diagnostics = diagnostics,
      isHudCollapsed = isHudCollapsed,
      onToggleHudCollapse = { viewModel.toggleHudCollapse() },
      onToggleRecording = { viewModel.toggleRecording() }
    )

    // 2. CENTRAL WORKSTATION AREA (Left Column + Central Viewport + Right Column)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
    ) {
      // LEFT INSTRUMENT COLUMN (Hideable for full-screen imaging)
      AnimatedVisibility(
        visible = !isHudCollapsed,
        enter = fadeIn(),
        exit = fadeOut()
      ) {
        LeftTelemetryColumn(telemetry = telemetry)
      }

      // CENTRAL VIEWPORT
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight()
      ) {
        when (activeMode) {
          HudWorkstationMode.OPTICAL -> {
            OpticalWorkstation(
              telemetry = telemetry,
              nodules = nodules,
              selectedNodule = selectedNodule,
              onSelectNodule = { viewModel.selectNodule(it) },
              imageSettings = imageSettings,
              onUpdateImageSettings = { red, dehaze, cont, low, split, isSplit, ret, scale ->
                viewModel.updateImageEnhancement(red, dehaze, cont, low, split, isSplit, ret, scale)
              },
              isCaliperActive = isCaliperActive,
              caliperPointA = caliperPointA,
              caliperPointB = caliperPointB,
              onToggleCaliper = { viewModel.toggleCaliperTool() },
              onCaliperTap = { x, y -> viewModel.handleCaliperTap(x, y) },
              caliperDistanceMm = caliperDistanceMm
            )
          }

          HudWorkstationMode.HYPERSPECTRAL -> {
            HyperspectralWorkstation(
              bands = hyperspectralBands,
              selectedBandIndex = selectedBandIndex,
              onSelectBand = { viewModel.selectBandIndex(it) },
              referenceProfiles = referenceProfiles,
              sampledPoints = sampledSpectralPoints,
              onSamplePoint = { x, y -> viewModel.sampleRoiPoint(x, y) }
            )
          }

          HudWorkstationMode.SONAR -> {
            SonarWorkstation(
              telemetry = telemetry,
              sonarSettings = sonarSettings,
              onUpdateSonarSettings = { r, f, g, o ->
                viewModel.updateSonarSettings(r, f, g, o)
              }
            )
          }

          HudWorkstationMode.NODULES -> {
            NoduleIntelligenceWorkstation(
              nodules = nodules,
              selectedNodule = selectedNodule,
              onSelectNodule = { viewModel.selectNodule(it) }
            )
          }

          HudWorkstationMode.CARBON -> {
            CarbonWorkstation(
              ramanData = ramanData,
              isBaselineSubtracted = isRamanBaselineSubtracted,
              onToggleBaseline = { viewModel.toggleRamanBaseline() }
            )
          }

          HudWorkstationMode.MAPPING_3D -> {
            Seabed3DWorkstation(
              telemetry = telemetry,
              nodules = nodules,
              rotationX = rotationX,
              rotationZ = rotationZ,
              verticalExaggeration = verticalExaggeration,
              onRotate = { dx, dz -> viewModel.update3DRotation(dx, dz) },
              onSetExaggeration = { viewModel.setVerticalExaggeration(it) },
              onExport = { viewModel.exportMission(it) },
              exportMessage = exportLog,
              onDismissExport = { viewModel.clearExportLog() }
            )
          }

          HudWorkstationMode.SURVEY -> {
            SurveyMissionWorkstation(
              telemetry = telemetry,
              isSurveyActive = isSurveyActive,
              onToggleSurvey = { viewModel.toggleSurveyActive() },
              events = missionEvents,
              onAddAnnotation = { title, notes -> viewModel.addAnnotation(title, notes) },
              onExportMission = { viewModel.exportMission(it) }
            )
          }

          HudWorkstationMode.DIAGNOSTICS -> {
            DiagnosticsWorkstation(
              diagnostics = diagnostics
            )
          }

          HudWorkstationMode.SETTINGS -> {
            SettingsWorkstation()
          }
        }
      }

      // RIGHT INSTRUMENT COLUMN (Hideable for full-screen imaging)
      AnimatedVisibility(
        visible = !isHudCollapsed,
        enter = fadeIn(),
        exit = fadeOut()
      ) {
        val selectedBandWl = hyperspectralBands.getOrNull(selectedBandIndex)?.wavelengthNm ?: 650
        RightInstrumentColumn(
          diagnostics = diagnostics,
          sonarSettings = sonarSettings,
          activeNodules = nodules,
          selectedBandWavelength = selectedBandWl
        )
      }
    }

    // 3. BOTTOM RIBBON
    SubseaBottomRibbon(
      activeMode = activeMode,
      onSelectMode = { viewModel.setWorkstationMode(it) }
    )
  }
}
