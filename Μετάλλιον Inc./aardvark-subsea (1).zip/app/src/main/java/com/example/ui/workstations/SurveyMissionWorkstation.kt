package com.example.ui.workstations

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MissionEvent
import com.example.data.model.SubseaTelemetry
import com.example.ui.theme.*

@Composable
fun SurveyMissionWorkstation(
  telemetry: SubseaTelemetry,
  isSurveyActive: Boolean,
  onToggleSurvey: () -> Unit,
  events: List<MissionEvent>,
  onAddAnnotation: (title: String, notes: String) -> Unit,
  onExportMission: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var showAddDialog by remember { mutableStateOf(false) }
  var noteTitle by remember { mutableStateOf("") }
  var noteContent by remember { mutableStateOf("") }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteBlack)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Mission Metadata Overview Card
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column {
        Text(
          text = "SURVEY MISSION // CCZ-2026-IV (CLARION-CLIPPERTON FRACTURE ZONE)",
          style = MaterialTheme.typography.titleMedium.copy(color = SonarCyan, fontWeight = FontWeight.Bold)
        )
        Text(
          text = "VESSEL: R/V Aardvark Discovery | ROV: DeepScan-IV | CLIENT: Μετάλλιον Inc. | CRS: WGS84 / UTM 10N",
          style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 8.5.sp)
        )
      }

      // Survey Controls (Pause/Resume, Add Note, Export)
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(
          onClick = onToggleSurvey,
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isSurveyActive) AmberCaution else ActiveGreen,
            contentColor = GraphiteBlack
          ),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier.height(32.dp).testTag("survey_state_toggle")
        ) {
          Icon(if (isSurveyActive) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "Survey State", modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(if (isSurveyActive) "PAUSE ACQUISITION" else "RESUME SURVEY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = { showAddDialog = true },
          colors = ButtonDefaults.buttonColors(containerColor = InstrumentNavy, contentColor = IceWhite),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier.height(32.dp).testTag("add_annotation_btn")
        ) {
          Icon(Icons.Default.AddComment, contentDescription = "Annotation", modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("LOG EVENT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 2. Mission Statistics Grid
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Box(modifier = Modifier.weight(1f).background(DeepMarineBlue.copy(alpha = 0.5f), RoundedCornerShape(4.dp)).border(1.dp, BorderNavy, RoundedCornerShape(4.dp)).padding(8.dp)) {
        Column {
          Text("SURVEY DURATION", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp))
          Text(
            String.format("%02dh %02dm %02ds", telemetry.surveyTimeSeconds / 3600, (telemetry.surveyTimeSeconds % 3600) / 60, telemetry.surveyTimeSeconds % 60),
            style = MaterialTheme.typography.titleMedium.copy(color = IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
          )
          Text("TRANSECT T-04 IN PROGRESS", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp))
        }
      }
      Box(modifier = Modifier.weight(1f).background(DeepMarineBlue.copy(alpha = 0.5f), RoundedCornerShape(4.dp)).border(1.dp, BorderNavy, RoundedCornerShape(4.dp)).padding(8.dp)) {
        Column {
          Text("SEABED COVERAGE", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp))
          Text("14,850 m²", style = MaterialTheme.typography.titleMedium.copy(color = SonarCyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold))
          Text("SWATH 50m • OVERLAP 20%", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp))
        }
      }
      Box(modifier = Modifier.weight(1f).background(DeepMarineBlue.copy(alpha = 0.5f), RoundedCornerShape(4.dp)).border(1.dp, BorderNavy, RoundedCornerShape(4.dp)).padding(8.dp)) {
        Column {
          Text("RECOVERED CORES", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp))
          Text("3 BOX CORES", style = MaterialTheme.typography.titleMedium.copy(color = NoduleTargetEmerald, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold))
          Text("BC-01, BC-02, BC-03 SECURED", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp))
        }
      }
      Box(modifier = Modifier.weight(1f).background(DeepMarineBlue.copy(alpha = 0.5f), RoundedCornerShape(4.dp)).border(1.dp, BorderNavy, RoundedCornerShape(4.dp)).padding(8.dp)) {
        Column {
          Text("DATA INTEGRITY", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 8.sp))
          Text("100% SYNCHRONISED", style = MaterialTheme.typography.titleMedium.copy(color = ActiveGreen, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold))
          Text("PTP IEEE 1588 SUB-MS LOCK", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp))
        }
      }
    }

    // 3. Interactive Mission Timeline
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(10.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Text(
        text = "MISSION EVENT TIMELINE (CHRONOLOGICAL SCIENTIFIC LOG)",
        style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontWeight = FontWeight.Bold)
      )

      LazyColumn(
        modifier = Modifier.fillMaxWidth().weight(1f),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        items(events) { evt ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(4.dp))
              .background(if (evt.isFlagged) AmberCaution.copy(alpha = 0.12f) else GraphiteBlack.copy(alpha = 0.7f))
              .border(1.dp, if (evt.isFlagged) AmberCaution else BorderNavy, RoundedCornerShape(4.dp))
              .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // Timecode & Tag
            Column(modifier = Modifier.width(90.dp)) {
              Text(
                text = evt.timeCode,
                style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
              )
              Text(
                text = String.format("%.1fm", evt.depthM),
                style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 8.sp)
              )
            }

            // Divider vertical
            Box(modifier = Modifier.width(1.dp).height(28.dp).background(BorderNavy))
            Spacer(modifier = Modifier.width(8.dp))

            // Event Details
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = evt.title,
                  style = MaterialTheme.typography.labelMedium.copy(color = IceWhite, fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                  modifier = Modifier
                    .background(DeepMarineBlue, RoundedCornerShape(2.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                  Text(text = evt.tag, style = MaterialTheme.typography.labelSmall.copy(color = AmberCaution, fontSize = 7.5.sp))
                }
              }
              Text(
                text = evt.description,
                style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 8.5.sp)
              )
            }
          }
        }
      }
    }
  }

  // Log Event Dialog
  if (showAddDialog) {
    AlertDialog(
      onDismissRequest = { showAddDialog = false },
      title = { Text("LOG SCIENTIFIC MISSION EVENT", style = MaterialTheme.typography.titleMedium.copy(color = SonarCyan)) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = noteTitle,
            onValueChange = { noteTitle = it },
            label = { Text("Event Title") },
            modifier = Modifier.fillMaxWidth().testTag("event_title_input")
          )
          OutlinedTextField(
            value = noteContent,
            onValueChange = { noteContent = it },
            label = { Text("Operational / Geological Notes") },
            modifier = Modifier.fillMaxWidth().testTag("event_notes_input")
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (noteTitle.isNotBlank()) {
              onAddAnnotation(noteTitle, noteContent)
              noteTitle = ""
              noteContent = ""
              showAddDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = SonarCyan, contentColor = GraphiteBlack)
        ) {
          Text("LOG ANNOTATION")
        }
      },
      dismissButton = {
        TextButton(onClick = { showAddDialog = false }) {
          Text("CANCEL", color = SteelGrey)
        }
      },
      containerColor = GraphiteBlack,
      shape = RoundedCornerShape(6.dp)
    )
  }
}
