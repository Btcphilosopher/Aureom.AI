package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.SubseaRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.*

class SubseaViewModel(
  private val repository: SubseaRepository = SubseaRepository()
) : ViewModel() {

  val telemetry = repository.telemetry
  val diagnostics = repository.diagnostics
  val nodules = repository.nodules
  val selectedNodule = repository.selectedNodule
  val hyperspectralBands = repository.hyperspectralBands
  val selectedBandIndex = repository.selectedBandIndex
  val referenceSpectralProfiles = repository.referenceSpectralProfiles
  val sampledSpectralCurve = repository.sampledSpectralCurve
  val ramanData = repository.ramanData
  val imageSettings = repository.imageSettings
  val sonarSettings = repository.sonarSettings
  val activeMode = repository.activeMode
  val isHudCollapsed = repository.isHudCollapsed
  val missionEvents = repository.missionEvents
  val isSurveyActive = repository.isSurveyActive
  val exportLog = repository.exportLog

  // Interactive Caliper / Distance Measurement Tool state
  private val _caliperPointA = MutableStateFlow<Pair<Float, Float>?>(null)
  val caliperPointA: StateFlow<Pair<Float, Float>?> = _caliperPointA.asStateFlow()

  private val _caliperPointB = MutableStateFlow<Pair<Float, Float>?>(null)
  val caliperPointB: StateFlow<Pair<Float, Float>?> = _caliperPointB.asStateFlow()

  private val _isCaliperActive = MutableStateFlow(false)
  val isCaliperActive: StateFlow<Boolean> = _isCaliperActive.asStateFlow()

  // Raman Baseline Subtraction Toggle
  private val _isRamanBaselineSubtracted = MutableStateFlow(true)
  val isRamanBaselineSubtracted: StateFlow<Boolean> = _isRamanBaselineSubtracted.asStateFlow()

  // 3D Seabed Orbit state
  private val _rotationX = MutableStateFlow(35.0f)
  val rotationX: StateFlow<Float> = _rotationX.asStateFlow()

  private val _rotationZ = MutableStateFlow(-25.0f)
  val rotationZ: StateFlow<Float> = _rotationZ.asStateFlow()

  private val _verticalExaggeration = MutableStateFlow(2.0f)
  val verticalExaggeration: StateFlow<Float> = _verticalExaggeration.asStateFlow()

  private var elapsedSeconds = 0.0

  init {
    viewModelScope.launch {
      while (true) {
        delay(600)
        elapsedSeconds += 0.6
        repository.tickSimulationStep(elapsedSeconds)
      }
    }
  }

  fun setWorkstationMode(mode: HudWorkstationMode) {
    repository.setWorkstationMode(mode)
  }

  fun toggleHudCollapse() {
    repository.toggleHudCollapse()
  }

  fun selectNodule(nodule: NoduleDetection?) {
    repository.selectNodule(nodule)
  }

  fun selectBandIndex(index: Int) {
    repository.setSelectedBandIndex(index)
  }

  fun sampleRoiPoint(x: Float, y: Float) {
    repository.sampleRoiSpectralPoint(x, y)
  }

  fun toggleSurveyActive() {
    repository.toggleSurveyActive()
  }

  fun toggleRecording() {
    repository.toggleRecording()
  }

  fun updateImageEnhancement(
    redAttenuation: Float? = null,
    dehaze: Float? = null,
    contrast: Float? = null,
    lowLight: Float? = null,
    splitScreen: Float? = null,
    isSplitEnabled: Boolean? = null,
    showReticle: Boolean? = null,
    showScaleBar: Boolean? = null,
  ) {
    repository.updateImageSettings { current ->
      current.copy(
        redWavelengthAttenuation = redAttenuation ?: current.redWavelengthAttenuation,
        dehazeDarkChannel = dehaze ?: current.dehazeDarkChannel,
        contrastStretch = contrast ?: current.contrastStretch,
        lowLightGain = lowLight ?: current.lowLightGain,
        splitScreenSlider = splitScreen ?: current.splitScreenSlider,
        isSplitScreenEnabled = isSplitEnabled ?: current.isSplitScreenEnabled,
        showMeasurementReticle = showReticle ?: current.showMeasurementReticle,
        showScaleBar = showScaleBar ?: current.showScaleBar,
      )
    }
  }

  fun updateSonarSettings(
    rangeM: Int? = null,
    freqKHz: Int? = null,
    gainDb: Float? = null,
    showOverlay: Boolean? = null,
  ) {
    repository.updateSonarSettings { current ->
      current.copy(
        rangeMeters = rangeM ?: current.rangeMeters,
        frequencyKHz = freqKHz ?: current.frequencyKHz,
        gainTvgDb = gainDb ?: current.gainTvgDb,
        showOverlayOnOptical = showOverlay ?: current.showOverlayOnOptical,
      )
    }
  }

  fun toggleCaliperTool() {
    _isCaliperActive.value = !_isCaliperActive.value
    if (!_isCaliperActive.value) {
      _caliperPointA.value = null
      _caliperPointB.value = null
    }
  }

  fun handleCaliperTap(normX: Float, normY: Float) {
    if (!_isCaliperActive.value) return
    if (_caliperPointA.value == null) {
      _caliperPointA.value = normX to normY
    } else if (_caliperPointB.value == null) {
      _caliperPointB.value = normX to normY
    } else {
      // Reset and set point A
      _caliperPointA.value = normX to normY
      _caliperPointB.value = null
    }
  }

  fun calculatePhysicalDistanceMm(): Float? {
    val a = _caliperPointA.value ?: return null
    val b = _caliperPointB.value ?: return null
    // Camera calibrated FoV: at 3.2m altitude, total horizontal field = ~3.84 meters (3840 mm)
    // Normalized delta
    val dx = (b.first - a.first) * 3840.0f
    val dy = (b.second - a.second) * 2160.0f
    return sqrt(dx * dx + dy * dy)
  }

  fun toggleRamanBaseline() {
    _isRamanBaselineSubtracted.value = !_isRamanBaselineSubtracted.value
  }

  fun update3DRotation(deltaX: Float, deltaZ: Float) {
    _rotationX.value = (_rotationX.value + deltaX).coerceIn(10.0f, 80.0f)
    _rotationZ.value = (_rotationZ.value + deltaZ) % 360f
  }

  fun setVerticalExaggeration(exaggeration: Float) {
    _verticalExaggeration.value = exaggeration
  }

  fun addAnnotation(title: String, notes: String) {
    repository.addMissionAnnotation(title, notes)
  }

  fun exportMission(format: String) {
    repository.exportMissionData(format)
  }

  fun clearExportLog() {
    repository.clearExportLog()
  }
}
