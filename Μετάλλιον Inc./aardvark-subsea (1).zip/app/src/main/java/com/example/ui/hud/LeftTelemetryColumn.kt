package com.example.ui.hud

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SubseaTelemetry
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun LeftTelemetryColumn(
  telemetry: SubseaTelemetry,
  modifier: Modifier = Modifier,
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .width(200.dp)
      .fillMaxHeight()
      .background(GraphiteBlack.copy(alpha = 0.90f))
      .border(width = 1.dp, color = BorderNavy)
      .padding(8.dp)
      .verticalScroll(scrollState),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // Section Header
    InstrumentSectionHeader(title = "VEHICLE TELEMETRY")

    // Depth & Pressure Card
    TelemetryCard(
      label = "VEHICLE DEPTH",
      value = String.format("%.1f m", telemetry.depthM),
      subValue = String.format("%.1f bar / %.2f MPa", telemetry.pressureBar, telemetry.pressureBar * 0.1),
      highlightColor = SonarCyan,
      isPrimary = true
    )

    // Altitude Above Seabed Card
    val isAltitudeCritical = telemetry.altitudeM < 2.0
    TelemetryCard(
      label = "ALTITUDE AGL",
      value = String.format("%.2f m", telemetry.altitudeM),
      subValue = if (isAltitudeCritical) "PROXIMITY WARNING" else "SEABED RADAR LOCKED",
      highlightColor = if (isAltitudeCritical) AlertRed else NoduleTargetEmerald,
      isWarning = isAltitudeCritical
    )

    // Gyro Horizon (Pitch & Roll)
    HorizonGyroWidget(
      pitchDeg = telemetry.pitchDeg,
      rollDeg = telemetry.rollDeg,
      modifier = Modifier
        .fillMaxWidth()
        .height(84.dp)
    )

    // Heading Compass Indicator
    CompassHeadingWidget(
      headingDeg = telemetry.headingDeg,
      modifier = Modifier
        .fillMaxWidth()
        .height(72.dp)
    )

    // Speed & Velocity
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Box(modifier = Modifier.weight(1f)) {
        TelemetryCard(
          label = "SPEED",
          value = String.format("%.2f kn", telemetry.speedKnots),
          subValue = "DVL-GROUND",
          highlightColor = IceWhite
        )
      }
      Box(modifier = Modifier.weight(1f)) {
        TelemetryCard(
          label = "VERT VEL",
          value = String.format("%+.2f m/s", telemetry.verticalVelocityMs),
          subValue = if (telemetry.verticalVelocityMs < 0) "DESCENDING" else "ASCENDING",
          highlightColor = if (abs(telemetry.verticalVelocityMs) > 0.05f) AmberCaution else IceWhite
        )
      }
    }

    // Oceanographic CTD Readings
    InstrumentSectionHeader(title = "CTD WATER COLUMN")
    TelemetryCard(
      label = "IN-SITU TEMPERATURE",
      value = String.format("%.2f °C", telemetry.waterTempC),
      subValue = "ABYSSAL POTENTIAL TEMP",
      highlightColor = SonarCyan
    )
    TelemetryCard(
      label = "SALINITY / COND",
      value = String.format("%.2f PSU", telemetry.salinityPsu),
      subValue = String.format("%.2f mS/cm", telemetry.salinityPsu * 0.98),
      highlightColor = IceWhite
    )

    // Positioning Confidence & USBL Coordinates
    InstrumentSectionHeader(title = "NAVIGATION FIX")
    TelemetryCard(
      label = "USBL / INS FIX",
      value = String.format("%.1f%%", telemetry.positionConfidencePct),
      subValue = String.format("LAT: %.5f°N\nLON: %.5f°W", telemetry.usblLat, abs(telemetry.usblLon)),
      highlightColor = if (telemetry.positionConfidencePct > 90f) NoduleTargetEmerald else AmberCaution
    )
  }
}

@Composable
fun InstrumentSectionHeader(title: String) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 2.dp)
  ) {
    Box(
      modifier = Modifier
        .size(4.dp)
        .background(SonarCyan)
    )
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = title,
      style = MaterialTheme.typography.labelSmall.copy(
        color = SteelGrey,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp
      )
    )
  }
}

@Composable
fun TelemetryCard(
  label: String,
  value: String,
  subValue: String,
  highlightColor: Color = IceWhite,
  isPrimary: Boolean = false,
  isWarning: Boolean = false,
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .background(
        color = if (isWarning) AlertRed.copy(alpha = 0.12f) else DeepMarineBlue.copy(alpha = 0.6f),
        shape = RoundedCornerShape(4.dp)
      )
      .border(
        width = 1.dp,
        color = if (isWarning) AlertRed else if (isPrimary) SonarCyan.copy(alpha = 0.6f) else BorderNavy,
        shape = RoundedCornerShape(4.dp)
      )
      .padding(horizontal = 8.dp, vertical = 6.dp)
  ) {
    Column {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall.copy(
          color = SteelGrey,
          fontSize = 9.sp,
          letterSpacing = 0.5.sp
        )
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        style = (if (isPrimary) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleMedium).copy(
          color = highlightColor,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold
        )
      )
      Text(
        text = subValue,
        style = MaterialTheme.typography.bodySmall.copy(
          color = if (isWarning) AlertRed else SteelGrey,
          fontSize = 8.5.sp,
          lineHeight = 11.sp
        )
      )
    }
  }
}

@Composable
fun HorizonGyroWidget(
  pitchDeg: Float,
  rollDeg: Float,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier
      .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
      .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
      .padding(4.dp)
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val cx = w / 2f
      val cy = h / 2f

      // Clip bounds border
      drawRect(
        color = BorderNavy,
        topLeft = Offset.Zero,
        size = size,
        style = Stroke(width = 1f)
      )

      // Background grid lines
      drawLine(GridDivider, Offset(0f, cy), Offset(w, cy), strokeWidth = 1f)
      drawLine(GridDivider, Offset(cx, 0f), Offset(cx, h), strokeWidth = 1f)

      // Artificial Horizon line rotating with roll and shifting with pitch
      val pitchOffset = (pitchDeg.coerceIn(-20f, 20f) / 20f) * (h * 0.4f)
      rotate(degrees = rollDeg, pivot = Offset(cx, cy)) {
        // Horizon line
        drawLine(
          color = SonarCyan,
          start = Offset(cx - 35f, cy + pitchOffset),
          end = Offset(cx + 35f, cy + pitchOffset),
          strokeWidth = 2f
        )
        // Pitch ladder ticks
        drawLine(
          color = SonarCyan.copy(alpha = 0.6f),
          start = Offset(cx - 15f, cy + pitchOffset - 12f),
          end = Offset(cx + 15f, cy + pitchOffset - 12f),
          strokeWidth = 1f
        )
        drawLine(
          color = SonarCyan.copy(alpha = 0.6f),
          start = Offset(cx - 15f, cy + pitchOffset + 12f),
          end = Offset(cx + 15f, cy + pitchOffset + 12f),
          strokeWidth = 1f
        )
      }

      // Fixed central aircraft/ROV reticle
      drawCircle(AmberCaution, radius = 2.5f, center = Offset(cx, cy))
      drawLine(AmberCaution, Offset(cx - 14f, cy), Offset(cx - 6f, cy), strokeWidth = 2f)
      drawLine(AmberCaution, Offset(cx + 6f, cy), Offset(cx + 14f, cy), strokeWidth = 2f)
      drawLine(AmberCaution, Offset(cx, cy - 6f), Offset(cx, cy - 2f), strokeWidth = 2f)
    }

    // Overlay Pitch & Roll values
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.BottomCenter)
        .padding(horizontal = 4.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        text = String.format("P: %+.1f°", pitchDeg),
        style = MaterialTheme.typography.labelSmall.copy(
          color = SteelGrey,
          fontFamily = FontFamily.Monospace,
          fontSize = 8.sp
        )
      )
      Text(
        text = String.format("R: %+.1f°", rollDeg),
        style = MaterialTheme.typography.labelSmall.copy(
          color = SteelGrey,
          fontFamily = FontFamily.Monospace,
          fontSize = 8.sp
        )
      )
    }
  }
}

@Composable
fun CompassHeadingWidget(
  headingDeg: Float,
  modifier: Modifier = Modifier,
) {
  val cardinal = when {
    headingDeg in 337.5..360.0 || headingDeg in 0.0..22.5 -> "N"
    headingDeg in 22.5..67.5 -> "NE"
    headingDeg in 67.5..112.5 -> "E"
    headingDeg in 112.5..157.5 -> "SE"
    headingDeg in 157.5..202.5 -> "S"
    headingDeg in 202.5..247.5 -> "SW"
    headingDeg in 247.5..292.5 -> "W"
    else -> "NW"
  }

  Box(
    modifier = modifier
      .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
      .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
      .padding(4.dp)
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val cy = h * 0.7f

      // Compass tape background line
      drawLine(BorderNavy, Offset(10f, cy), Offset(w - 10f, cy), strokeWidth = 1f)

      // Draw ticks for +/- 40 degrees around current heading
      val centerH = headingDeg
      for (deg in (centerH.toInt() - 35)..(centerH.toInt() + 35)) {
        if (deg % 5 == 0) {
          val normalizedDeg = ((deg % 360) + 360) % 360
          val offsetDeg = deg - centerH
          val x = (w / 2f) + (offsetDeg * 2.2f)
          if (x in 8f..(w - 8f)) {
            val isMajor = normalizedDeg % 15 == 0
            val tickHeight = if (isMajor) 10f else 5f
            drawLine(
              color = if (isMajor) SonarCyan else SteelGrey,
              start = Offset(x, cy - tickHeight),
              end = Offset(x, cy),
              strokeWidth = if (isMajor) 1.5f else 1f
            )
          }
        }
      }

      // Center pointer index
      val cx = w / 2f
      val path = Path().apply {
        moveTo(cx, cy - 14f)
        lineTo(cx - 4f, cy - 20f)
        lineTo(cx + 4f, cy - 20f)
        close()
      }
      drawPath(path, color = AmberCaution)
    }

    // Heading text in center top
    Row(
      modifier = Modifier
        .align(Alignment.TopCenter)
        .padding(top = 2.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = String.format("%03.0f° %s", headingDeg, cardinal),
        style = MaterialTheme.typography.labelMedium.copy(
          color = SonarCyan,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold
        )
      )
    }
  }
}
