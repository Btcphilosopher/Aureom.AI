package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aardvark Industrial Color Palette
val GraphiteBlack = Color(0xFF10161C)
val AbyssBlack = Color(0xFF090D11)
val DeepMarineBlue = Color(0xFF142534)
val InstrumentNavy = Color(0xFF1C3445)
val SurfaceNavy = Color(0xFF162A38)
val BorderNavy = Color(0xFF24445A)
val SteelGrey = Color(0xFF81929D)
val IceWhite = Color(0xFFEAF1F4)
val SonarCyan = Color(0xFF58B8C7)
val AmberCaution = Color(0xFFE7AA52)
val AlertRed = Color(0xFFD95757)

// Scientific & Overlays
val NoduleTargetEmerald = Color(0xFF4AE290)
val SpectralViolet = Color(0xFF9D65C9)
val SonarGold = Color(0xFFE5B94E)
val GridDivider = Color(0xFF223E52)
val TelemetryGlow = Color(0xFF58B8C7)
val ActiveGreen = Color(0xFF42D685)
