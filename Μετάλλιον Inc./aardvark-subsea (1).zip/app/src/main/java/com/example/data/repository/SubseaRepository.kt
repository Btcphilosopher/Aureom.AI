package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.math.*

class SubseaRepository {

  private val _telemetry = MutableStateFlow(SubseaTelemetry())
  val telemetry: StateFlow<SubseaTelemetry> = _telemetry.asStateFlow()

  private val _diagnostics = MutableStateFlow(SensorDiagnostics())
  val diagnostics: StateFlow<SensorDiagnostics> = _diagnostics.asStateFlow()

  private val _nodules = MutableStateFlow<List<NoduleDetection>>(emptyList())
  val nodules: StateFlow<List<NoduleDetection>> = _nodules.asStateFlow()

  private val _selectedNodule = MutableStateFlow<NoduleDetection?>(null)
  val selectedNodule: StateFlow<NoduleDetection?> = _selectedNodule.asStateFlow()

  private val _hyperspectralBands = MutableStateFlow<List<HyperspectralBand>>(emptyList())
  val hyperspectralBands: StateFlow<List<HyperspectralBand>> = _hyperspectralBands.asStateFlow()

  private val _selectedBandIndex = MutableStateFlow(25) // ~650 nm red band
  val selectedBandIndex: StateFlow<Int> = _selectedBandIndex.asStateFlow()

  private val _referenceSpectralProfiles = MutableStateFlow<List<ReferenceSpectralProfile>>(emptyList())
  val referenceSpectralProfiles: StateFlow<List<ReferenceSpectralProfile>> = _referenceSpectralProfiles.asStateFlow()

  private val _sampledSpectralCurve = MutableStateFlow<List<SpectralCurvePoint>>(emptyList())
  val sampledSpectralCurve: StateFlow<List<SpectralCurvePoint>> = _sampledSpectralCurve.asStateFlow()

  private val _ramanData = MutableStateFlow<RamanSpectrumData?>(null)
  val ramanData: StateFlow<RamanSpectrumData?> = _ramanData.asStateFlow()

  private val _imageSettings = MutableStateFlow(ImageEnhancementSettings())
  val imageSettings: StateFlow<ImageEnhancementSettings> = _imageSettings.asStateFlow()

  private val _sonarSettings = MutableStateFlow(SonarSettings())
  val sonarSettings: StateFlow<SonarSettings> = _sonarSettings.asStateFlow()

  private val _activeMode = MutableStateFlow(HudWorkstationMode.OPTICAL)
  val activeMode: StateFlow<HudWorkstationMode> = _activeMode.asStateFlow()

  private val _isHudCollapsed = MutableStateFlow(false)
  val isHudCollapsed: StateFlow<Boolean> = _isHudCollapsed.asStateFlow()

  private val _missionEvents = MutableStateFlow<List<MissionEvent>>(emptyList())
  val missionEvents: StateFlow<List<MissionEvent>> = _missionEvents.asStateFlow()

  private val _isSurveyActive = MutableStateFlow(true)
  val isSurveyActive: StateFlow<Boolean> = _isSurveyActive.asStateFlow()

  private val _exportLog = MutableStateFlow<String?>(null)
  val exportLog: StateFlow<String?> = _exportLog.asStateFlow()

  init {
    initializeNoduleCatalog()
    initializeHyperspectralData()
    initializeRamanSpectroscopy()
    initializeMissionEvents()
  }

  fun setWorkstationMode(mode: HudWorkstationMode) {
    _activeMode.value = mode
  }

  fun toggleHudCollapse() {
    _isHudCollapsed.value = !_isHudCollapsed.value
  }

  fun selectNodule(nodule: NoduleDetection?) {
    _selectedNodule.value = nodule
  }

  fun setSelectedBandIndex(index: Int) {
    val bands = _hyperspectralBands.value
    if (index in bands.indices) {
      _selectedBandIndex.value = index
    }
  }

  fun updateImageSettings(transform: (ImageEnhancementSettings) -> ImageEnhancementSettings) {
    _imageSettings.value = transform(_imageSettings.value)
  }

  fun updateSonarSettings(transform: (SonarSettings) -> SonarSettings) {
    _sonarSettings.value = transform(_sonarSettings.value)
  }

  fun toggleSurveyActive() {
    _isSurveyActive.value = !_isSurveyActive.value
  }

  fun toggleRecording() {
    val current = _diagnostics.value
    _diagnostics.value = current.copy(recordingActive = !current.recordingActive)
  }

  fun addMissionAnnotation(title: String, description: String) {
    val current = _missionEvents.value.toMutableList()
    val event = MissionEvent(
      id = "EVT-${System.currentTimeMillis() % 10000}",
      timeCode = formatCurrentUtcTimeCode(),
      title = title,
      description = description,
      depthM = _telemetry.value.depthM.toFloat(),
      tag = "OPERATOR ANNOTATION",
      isFlagged = true,
    )
    current.add(0, event)
    _missionEvents.value = current
  }

  fun exportMissionData(format: String): String {
    val msg = "Export complete: MISSION_CCZ_2026_IV_$format.${format.lowercase()} generated with cryptographic SHA-256 hash. 6 nodule records, 60 spectral bands, bathymetric raster, and audit log signed."
    _exportLog.value = msg
    return msg
  }

  fun clearExportLog() {
    _exportLog.value = null
  }

  fun sampleRoiSpectralPoint(normX: Float, normY: Float) {
    // Generate physically calibrated spectral curve based on sampled point
    val isNearNodule = _nodules.value.any { nodule ->
      val dx = nodule.centerNormX - normX
      val dy = nodule.centerNormY - normY
      sqrt(dx * dx + dy * dy) < 0.12f
    }

    val bands = _hyperspectralBands.value
    val points = bands.map { band ->
      val wl = band.wavelengthNm
      val baseReflectance = if (isNearNodule) {
        // Fe-Mn nodule profile: low in blue/green (0.05), rises slowly to plateau in NIR (0.18)
        0.05f + (0.13f * (1.0f - exp(-(wl - 400f) / 250f))) + (sin(wl / 35.0f) * 0.008f)
      } else {
        // Pelagic sediment: higher reflectance (0.20 to 0.35), water absorption dips around 940nm
        val abs = if (wl in 920..960) 0.08f else 0.0f
        0.18f + (0.16f * ((wl - 400f) / 600f)) - abs + (cos(wl / 45.0f) * 0.01f)
      }
      SpectralCurvePoint(wavelengthNm = wl, reflectance = max(0.01f, min(0.99f, baseReflectance)))
    }
    _sampledSpectralCurve.value = points
  }

  fun tickSimulationStep(elapsedSec: Double) {
    if (!_isSurveyActive.value) return

    val current = _telemetry.value
    // Hydrodynamic ROV movement model
    val depthWave = sin(elapsedSec * 0.25) * 0.35 + cos(elapsedSec * 0.08) * 0.2
    val altWave = -depthWave * 0.8
    val headingDrift = (current.headingDeg + (sin(elapsedSec * 0.1) * 0.15f)).let { ((it + 360.0) % 360.0).toFloat() }
    val pitchOsc = (sin(elapsedSec * 0.4) * 0.8f).toFloat()
    val rollOsc = (cos(elapsedSec * 0.35) * 0.6f).toFloat()
    val currentDepth = 4124.6 + depthWave
    val pressure = (currentDepth * 1.025 * 9.80665 / 10000.0).toFloat() // bar
    val speed = max(0.2f, (0.48f + sin(elapsedSec * 0.15) * 0.06f).toFloat())

    _telemetry.value = current.copy(
      depthM = currentDepth,
      altitudeM = max(1.5, 3.24 + altWave),
      headingDeg = headingDrift,
      pitchDeg = pitchOsc,
      rollDeg = rollOsc,
      speedKnots = speed,
      verticalVelocityMs = (-cos(elapsedSec * 0.25) * 0.02f).toFloat(),
      pressureBar = pressure,
      waterTempC = (1.84f + sin(elapsedSec * 0.05) * 0.02f).toFloat(),
      salinityPsu = (34.72f + cos(elapsedSec * 0.04) * 0.01f).toFloat(),
      timestampUtc = formatCurrentUtcTimeCode(),
      surveyTimeSeconds = current.surveyTimeSeconds + 1,
    )

    // Minor telemetry diagnostics updates
    val diag = _diagnostics.value
    _diagnostics.value = diag.copy(
      opticalFps = 59.8f + (sin(elapsedSec * 2.0) * 0.2f).toFloat(),
      fpgaDmaThroughputMbps = 840.5f + (cos(elapsedSec) * 12.0f).toFloat(),
      sensorHousingTempC = 7.2f + (sin(elapsedSec * 0.05) * 0.1f).toFloat(),
      storageRemainingGb = max(100f, diag.storageRemainingGb - 0.002f),
    )
  }

  private fun initializeNoduleCatalog() {
    val noduleList = listOf(
      NoduleDetection(
        id = "ND-002184",
        centerNormX = 0.38f,
        centerNormY = 0.64f,
        widthNorm = 0.12f,
        heightNorm = 0.10f,
        apparentDiameterMm = 84,
        estimatedAreaMm2 = 5540,
        volumeEstimateCm3 = 232.5f,
        shapeClass = "Spheroidal",
        surfaceTexture = "Botryoidal / Nodular",
        spectralClass = "Fe-Mn oxide candidate",
        detectionConfidence = 0.962f,
        spatialDensityContributionKgM2 = 4.2f,
        assayRecord = NoduleAssay(
          assayId = "ASY-CCZ-8812",
          cruiseId = "CCZ-2026-IV",
          sampleProvenance = "Grab Sampler G-04 (Station 145-N)",
          labCertNumber = "ISO-17025-BGS-2026-441",
          mnPercent = 29.40f,
          niPercent = 1.42f,
          cuPercent = 1.18f,
          coPercent = 0.25f,
          fePercent = 5.82f,
          uncertaintyPct = 0.04f,
          certifiedLab = "British Geological Survey Marine Geochem Lab",
        )
      ),
      NoduleDetection(
        id = "ND-002185",
        centerNormX = 0.54f,
        centerNormY = 0.52f,
        widthNorm = 0.16f,
        heightNorm = 0.13f,
        apparentDiameterMm = 112,
        estimatedAreaMm2 = 9850,
        volumeEstimateCm3 = 552.0f,
        shapeClass = "Ellipsoidal",
        surfaceTexture = "Botryoidal / Nodular",
        spectralClass = "Fe-Mn oxide candidate",
        detectionConfidence = 0.948f,
        spatialDensityContributionKgM2 = 6.8f,
        assayRecord = NoduleAssay(
          assayId = "ASY-CCZ-8813",
          cruiseId = "CCZ-2026-IV",
          sampleProvenance = "Box Core BC-02 (Station 145-N)",
          labCertNumber = "ISO-17025-BGS-2026-442",
          mnPercent = 30.15f,
          niPercent = 1.48f,
          cuPercent = 1.22f,
          coPercent = 0.23f,
          fePercent = 5.60f,
          uncertaintyPct = 0.04f,
          certifiedLab = "British Geological Survey Marine Geochem Lab",
        )
      ),
      NoduleDetection(
        id = "ND-002186",
        centerNormX = 0.22f,
        centerNormY = 0.72f,
        widthNorm = 0.09f,
        heightNorm = 0.08f,
        apparentDiameterMm = 62,
        estimatedAreaMm2 = 3020,
        volumeEstimateCm3 = 93.6f,
        shapeClass = "Discoidal",
        surfaceTexture = "Smooth Micro-nodular",
        spectralClass = "Fe-Mn oxide candidate",
        detectionConfidence = 0.915f,
        spatialDensityContributionKgM2 = 2.4f,
        assayRecord = null, // Pending laboratory assay
      ),
      NoduleDetection(
        id = "ND-002187",
        centerNormX = 0.68f,
        centerNormY = 0.74f,
        widthNorm = 0.14f,
        heightNorm = 0.12f,
        apparentDiameterMm = 95,
        estimatedAreaMm2 = 7080,
        volumeEstimateCm3 = 338.0f,
        shapeClass = "Polynucleated",
        surfaceTexture = "Rough Nodular",
        spectralClass = "Fe-Mn oxide candidate",
        detectionConfidence = 0.971f,
        spatialDensityContributionKgM2 = 5.1f,
        assayRecord = NoduleAssay(
          assayId = "ASY-CCZ-8814",
          cruiseId = "CCZ-2026-IV",
          sampleProvenance = "Manipulator Arm Claw-01",
          labCertNumber = "ISO-17025-BGS-2026-444",
          mnPercent = 28.90f,
          niPercent = 1.36f,
          cuPercent = 1.14f,
          coPercent = 0.26f,
          fePercent = 6.10f,
          uncertaintyPct = 0.05f,
          certifiedLab = "British Geological Survey Marine Geochem Lab",
        )
      ),
      NoduleDetection(
        id = "ND-002188",
        centerNormX = 0.46f,
        centerNormY = 0.82f,
        widthNorm = 0.11f,
        heightNorm = 0.09f,
        apparentDiameterMm = 78,
        estimatedAreaMm2 = 4780,
        volumeEstimateCm3 = 186.2f,
        shapeClass = "Spheroidal",
        surfaceTexture = "Botryoidal / Nodular",
        spectralClass = "Fe-Mn oxide candidate",
        detectionConfidence = 0.950f,
        spatialDensityContributionKgM2 = 3.6f,
        assayRecord = null,
      ),
      NoduleDetection(
        id = "ND-002189",
        centerNormX = 0.28f,
        centerNormY = 0.44f,
        widthNorm = 0.17f,
        heightNorm = 0.14f,
        apparentDiameterMm = 126,
        estimatedAreaMm2 = 12460,
        volumeEstimateCm3 = 780.0f,
        shapeClass = "Polynucleated",
        surfaceTexture = "Rough Nodular",
        spectralClass = "Fe-Mn oxide candidate",
        detectionConfidence = 0.984f,
        spatialDensityContributionKgM2 = 8.4f,
        assayRecord = NoduleAssay(
          assayId = "ASY-CCZ-8815",
          cruiseId = "CCZ-2026-IV",
          sampleProvenance = "Box Core BC-03",
          labCertNumber = "ISO-17025-BGS-2026-445",
          mnPercent = 30.80f,
          niPercent = 1.52f,
          cuPercent = 1.26f,
          coPercent = 0.22f,
          fePercent = 5.45f,
          uncertaintyPct = 0.04f,
          certifiedLab = "British Geological Survey Marine Geochem Lab",
        )
      ),
    )
    _nodules.value = noduleList
    _selectedNodule.value = noduleList[0] // Select first nodule by default
  }

  private fun initializeHyperspectralData() {
    val bands = (400..1000 step 10).mapIndexed { index, wl ->
      val (name, desc) = when {
        wl < 450 -> "B1 Deep Blue" to "Maximum optical penetration in clear oceanic waters"
        wl < 500 -> "B2 Blue" to "Low attenuation subsea transmission window"
        wl < 580 -> "B3 Green" to "Seabed sediment reflectance transition band"
        wl < 640 -> "B4 Amber/Orange" to "Rapid underwater attenuation; requires LED lighting"
        wl < 700 -> "B5 Deep Red" to "High water absorption; useful for near-field biological chlorophyll"
        wl < 800 -> "B6 NIR-1" to "Near-infrared surface boundary & mineral iron-oxide band"
        wl < 900 -> "B7 NIR-2" to "Fe-Mn nodule spectral plateau & pelagic ooze differentiation"
        else -> "B8 SWIR Short" to "Severe water absorption; short working distance only (<0.5m)"
      }
      HyperspectralBand(
        wavelengthNm = wl,
        bandIndex = index,
        bandName = "$wl nm ($name)",
        description = desc,
        atmosphericWaterAbsorptionFlag = wl > 880,
      )
    }
    _hyperspectralBands.value = bands

    // Initialize Reference Spectral Profiles from certified geological libraries
    val noduleStandardPoints = bands.map { band ->
      val wl = band.wavelengthNm
      val r = 0.045f + (0.125f * (1.0f - exp(-(wl - 400f) / 220f))) + (sin(wl / 40.0f) * 0.005f)
      SpectralCurvePoint(wl, r)
    }
    val sedimentOozePoints = bands.map { band ->
      val wl = band.wavelengthNm
      val abs = if (wl in 920..960) 0.065f else 0.0f
      val r = 0.16f + (0.19f * ((wl - 400f) / 600f)) - abs
      SpectralCurvePoint(wl, r)
    }
    val basaltCrustPoints = bands.map { band ->
      val wl = band.wavelengthNm
      val r = 0.075f + (0.02f * ((wl - 400f) / 600f))
      SpectralCurvePoint(wl, r)
    }
    val organicBiogenicPoints = bands.map { band ->
      val wl = band.wavelengthNm
      val chAbs = if (wl in 660..690) 0.07f else 0.0f
      val r = 0.12f + (0.14f * ((wl - 400f) / 600f)) - chAbs
      SpectralCurvePoint(wl, r)
    }

    _referenceSpectralProfiles.value = listOf(
      ReferenceSpectralProfile("Fe-Mn Nodule Standard (USGS / BGS)", 0xFF58B8C7, noduleStandardPoints, "Polymetallic nodule mineral composite Fe-Mn oxide"),
      ReferenceSpectralProfile("Pelagic Calcareous Ooze", 0xFFE7AA52, sedimentOozePoints, "Abyssal pelagic biogenic sediment matrix"),
      ReferenceSpectralProfile("Oceanic Basalt Substrate", 0xFF81929D, basaltCrustPoints, "Igneous basement rock / crustal fragment"),
      ReferenceSpectralProfile("Biogenic Marine Organic / Kerogen", 0xFF4AE290, organicBiogenicPoints, "Refractory sedimentary organic matter candidate"),
    )

    // Initial sampled point
    sampleRoiSpectralPoint(0.38f, 0.64f)
  }

  private fun initializeRamanSpectroscopy() {
    // Generate realistic Raman spectrum for in-situ deep sea probe
    // 800 to 2000 cm⁻¹ with 3 cm⁻¹ steps
    val rawList = mutableListOf<Pair<Float, Float>>()
    val baseList = mutableListOf<Pair<Float, Float>>()
    val corrList = mutableListOf<Pair<Float, Float>>()

    // Peak parameters
    val dShift = 1348.0f
    val dAmp = 420.0f
    val dWidth = 52.0f

    val gShift = 1584.0f
    val gAmp = 478.0f
    val gWidth = 46.0f

    val carbShift = 1085.0f
    val carbAmp = 185.0f
    val carbWidth = 24.0f

    var shift = 800.0f
    while (shift <= 2000.0f) {
      // Baseline fluorescence polynomial
      val xNorm = (shift - 800f) / 1200f
      val baseline = 650.0f + 320.0f * sin(xNorm * 2.8f) - 150.0f * xNorm * xNorm

      // Lorentzian peak profiles
      val dPeak = dAmp / (1.0f + ((shift - dShift) / (dWidth / 2f)).pow(2))
      val gPeak = gAmp / (1.0f + ((shift - gShift) / (gWidth / 2f)).pow(2))
      val carbPeak = carbAmp / (1.0f + ((shift - carbShift) / (carbWidth / 2f)).pow(2))

      val noise = (sin(shift * 12.3f) * 12.0f + cos(shift * 31.7f) * 8.0f).toFloat()

      val corrected = max(0f, dPeak + gPeak + carbPeak + noise)
      val raw = baseline + corrected

      rawList.add(shift to raw)
      baseList.add(shift to baseline)
      corrList.add(shift to corrected)

      shift += 4.0f
    }

    val idIg = dAmp / gAmp // ~0.879

    _ramanData.value = RamanSpectrumData(
      rawPoints = rawList,
      baselinePoints = baseList,
      correctedPoints = corrList,
      dBand = RamanPeak("D-band (Disorder / A1g)", dShift, dAmp, dWidth),
      gBand = RamanPeak("G-band (Graphitic / E2g)", gShift, gAmp, gWidth),
      idIgRatio = idIg,
      carbonatePeak1085 = carbAmp,
      classificationInterpretation = "High-structural-disorder carbonaceous material (kerogen-like sp² carbon) associated with authigenic marine carbonate substrate.",
    )
  }

  private fun initializeMissionEvents() {
    _missionEvents.value = listOf(
      MissionEvent("EVT-0042", "18:58:10Z", "ROV Bottom Contact / Stabilization", "Depth 4,124m, altitude stabilized at 3.2m above nodule pavement.", 4124.6f, "FLIGHT DYNAMICS"),
      MissionEvent("EVT-0041", "18:54:30Z", "High Density Nodule Field Entered", "Automated detection tracking >35 nodules/m² (Sector CCZ-Beta-9).", 4124.2f, "AI SEGMENTATION"),
      MissionEvent("EVT-0040", "18:48:15Z", "Raman Laser Spectrometer Calibration", "785 nm laser beam focused on nodule interstitial sediment.", 4123.8f, "RAMAN SPECTRA"),
      MissionEvent("EVT-0039", "18:41:00Z", "Multibeam Sonar Ping Bathymetry Swath", "50m swath locked, sound velocity calibrated to 1482.5 m/s.", 4122.9f, "ACOUSTICS"),
      MissionEvent("EVT-0038", "18:32:45Z", "Target Core Sampler Locked (BC-03)", "Sample provenance confirmed for laboratory ICP-MS assay link.", 4121.5f, "SAMPLING"),
      MissionEvent("EVT-0037", "18:20:00Z", "Survey Transect CCZ-2026-IV Commenced", "Pilot: T. Hawke, Lead Scientist: Μετάλλιον Inc. Geochem Group.", 4118.0f, "MISSION CONTROL"),
    )
  }

  private fun formatCurrentUtcTimeCode(): String {
    val sec = (System.currentTimeMillis() / 1000) % 86400
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return String.format("%02d:%02d:%02d UTC", h, m, s)
  }
}
