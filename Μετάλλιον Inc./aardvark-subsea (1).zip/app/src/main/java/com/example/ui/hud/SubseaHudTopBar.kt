package com.example.ui.hud

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SensorDiagnostics
import com.example.data.model.SubseaTelemetry
import com.example.ui.theme.*

@Composable
fun SubseaHudTopBar(
  telemetry: SubseaTelemetry,
  diagnostics: SensorDiagnostics,
  isHudCollapsed: Boolean,
  onToggleHudCollapse: () -> Unit,
  onToggleRecording: () -> Unit,
  modifier: Modifier = Modifier,
) {
  // Pulsing animation for active recording
  val infiniteTransition = rememberInfiniteTransition(label = "recPulse")
  val recAlpha by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(800, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "recAlpha"
  )

  Surface(
    color = GraphiteBlack.copy(alpha = 0.95f),
    contentColor = IceWhite,
    modifier = modifier
      .fillMaxWidth()
      .height(48.dp)
      .border(width = 1.dp, color = BorderNavy)
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 12.dp)
    ) {
      // Brand & Unit Title
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(10.dp)
            .background(SonarCyan, shape = RoundedCornerShape(2.dp))
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "AARDVARK IMAGING",
          style = MaterialTheme.typography.labelLarge.copy(
            color = IceWhite,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
          )
        )
        Text(
          text = " // SUBSEA INTELLIGENCE WORKSTATION",
          style = MaterialTheme.typography.bodySmall.copy(
            color = SteelGrey,
            letterSpacing = 1.sp
          )
        )
      }

      // Mission & UTC Time
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Mission badge
        Box(
          modifier = Modifier
            .background(InstrumentNavy, shape = RoundedCornerShape(4.dp))
            .border(1.dp, SonarCyan.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
          Text(
            text = "CRUISE: CCZ-2026-IV [Μετάλλιον]",
            style = MaterialTheme.typography.labelSmall.copy(
              color = SonarCyan,
              fontWeight = FontWeight.SemiBold
            )
          )
        }

        // Live UTC Clock
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Schedule,
            contentDescription = "UTC Clock",
            tint = SteelGrey,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = telemetry.timestampUtc,
            style = MaterialTheme.typography.labelMedium.copy(
              color = IceWhite,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold
            )
          )
        }

        // Mandatory Simulation/Benchmark Flag
        Box(
          modifier = Modifier
            .background(AmberCaution.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
            .border(1.dp, AmberCaution.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
          Text(
            text = "HARDWARE SIMULATION [PHYSICAL BENCHMARK]",
            style = MaterialTheme.typography.labelSmall.copy(
              color = AmberCaution,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.5.sp
            )
          )
        }
      }

      // Controls (Recording, Fullscreen toggle)
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Recording status toggle
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (diagnostics.recordingActive) AlertRed.copy(alpha = 0.2f) else DeepMarineBlue)
            .border(1.dp, if (diagnostics.recordingActive) AlertRed else BorderNavy, RoundedCornerShape(4.dp))
            .clickable { onToggleRecording() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("recording_toggle_btn")
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .background(
                color = if (diagnostics.recordingActive) AlertRed.copy(alpha = recAlpha) else SteelGrey,
                shape = RoundedCornerShape(4.dp)
              )
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (diagnostics.recordingActive) "REC ACTIVE" else "REC IDLE",
            style = MaterialTheme.typography.labelSmall.copy(
              color = if (diagnostics.recordingActive) AlertRed else SteelGrey,
              fontWeight = FontWeight.Bold
            )
          )
        }

        // Fullscreen HUD Hide/Show Toggle
        IconButton(
          onClick = onToggleHudCollapse,
          modifier = Modifier
            .size(32.dp)
            .testTag("hud_collapse_btn")
        ) {
          Icon(
            imageVector = if (isHudCollapsed) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
            contentDescription = if (isHudCollapsed) "Show Instruments" else "Fullscreen Viewport",
            tint = SonarCyan,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}
