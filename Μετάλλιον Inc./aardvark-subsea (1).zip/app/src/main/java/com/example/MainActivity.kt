package com.example

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.SubseaViewModel
import com.example.ui.hud.SubseaMasterHud
import com.example.ui.theme.AardvarkSubseaTheme
import com.example.ui.theme.GraphiteBlack

class MainActivity : ComponentActivity() {

  private val viewModel: SubseaViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Professional workstation landscape layout preference
    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

    setContent {
      AardvarkSubseaTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = GraphiteBlack
        ) {
          SubseaMasterHud(viewModel = viewModel)
        }
      }
    }
  }
}
