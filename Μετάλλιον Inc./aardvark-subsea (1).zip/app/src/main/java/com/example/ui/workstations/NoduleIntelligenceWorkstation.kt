package com.example.ui.workstations

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.NoduleDetection
import com.example.ui.theme.*

@Composable
fun NoduleIntelligenceWorkstation(
  nodules: List<NoduleDetection>,
  selectedNodule: NoduleDetection?,
  onSelectNodule: (NoduleDetection) -> Unit,
  modifier: Modifier = Modifier,
) {
  val activeTarget = selectedNodule ?: nodules.firstOrNull()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(GraphiteBlack)
      .padding(8.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    // 1. Header with Μετάλλιον Inc. Partnership Branding
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeepMarineBlue.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
        .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Grain, contentDescription = "Nodules", tint = NoduleTargetEmerald, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "POLYMETALLIC NODULE INTELLIGENCE // Μετάλλιον Inc. GEOSURVEY",
          style = MaterialTheme.typography.labelMedium.copy(
            color = IceWhite,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        )
      }

      val totalDensityKgM2 = nodules.sumOf { it.spatialDensityContributionKgM2.toDouble() }.toFloat()
      Text(
        text = String.format("SECTOR DENSITY: %.1f kg/m² | %d TARGETS SEGMENTED", totalDensityKgM2, nodules.size),
        style = MaterialTheme.typography.labelSmall.copy(
          color = NoduleTargetEmerald,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold
        )
      )
    }

    // 2. Dual Column Layout: Target List (Left 40%) & Detailed Inspection & Assay Sheet (Right 60%)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Left Pane: Nodule Catalog List
      Column(
        modifier = Modifier
          .weight(0.42f)
          .fillMaxHeight()
          .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
          .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
          .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text(
          text = "DETECTED NODULE TARGETS (SORTED BY DIAMETER)",
          style = MaterialTheme.typography.labelSmall.copy(color = SonarCyan, fontWeight = FontWeight.Bold)
        )

        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          items(nodules) { nodule ->
            val isSelected = nodule.id == activeTarget?.id
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(if (isSelected) SonarCyan.copy(alpha = 0.2f) else GraphiteBlack.copy(alpha = 0.7f))
                .border(1.dp, if (isSelected) SonarCyan else BorderNavy, RoundedCornerShape(4.dp))
                .clickable { onSelectNodule(nodule) }
                .padding(8.dp)
                .testTag("nodule_item_${nodule.id}")
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text(
                    text = nodule.id,
                    style = MaterialTheme.typography.labelMedium.copy(
                      color = if (isSelected) SonarCyan else IceWhite,
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold
                    )
                  )
                  Text(
                    text = "${nodule.shapeClass} • ${nodule.surfaceTexture}",
                    style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 8.5.sp)
                  )
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = "${nodule.apparentDiameterMm} mm",
                    style = MaterialTheme.typography.labelMedium.copy(
                      color = NoduleTargetEmerald,
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold
                    )
                  )
                  Text(
                    text = String.format("CONF: %.1f%%", nodule.detectionConfidence * 100f),
                    style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 8.sp)
                  )
                }
              }
            }
          }
        }
      }

      // Right Pane: Deep Target Inspection & Certified Laboratory Assay
      if (activeTarget != null) {
        Column(
          modifier = Modifier
            .weight(0.58f)
            .fillMaxHeight()
            .background(DeepMarineBlue.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
            .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
            .padding(10.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Target Header Card
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "INSPECTION SHEET // ${activeTarget.id}",
                style = MaterialTheme.typography.titleMedium.copy(
                  color = SonarCyan,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold
                )
              )
              Text(
                text = "SPECTRAL CLASSIFICATION: ${activeTarget.spectralClass.uppercase()}",
                style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontSize = 8.5.sp)
              )
            }

            Box(
              modifier = Modifier
                .background(NoduleTargetEmerald.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                .border(1.dp, NoduleTargetEmerald, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = String.format("CONFIDENCE: %.1f%%", activeTarget.detectionConfidence * 100f),
                style = MaterialTheme.typography.labelSmall.copy(color = NoduleTargetEmerald, fontWeight = FontWeight.Bold)
              )
            }
          }

          Divider(color = BorderNavy, thickness = 1.dp)

          // Physical Dimensions Grid
          Text(
            text = "CALIBRATED OPTICAL MORPHOMETRICS",
            style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontWeight = FontWeight.Bold)
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            MetricBox("APPARENT DIAMETER", "${activeTarget.apparentDiameterMm} mm", "Laser Calibrated", Modifier.weight(1f))
            MetricBox("ESTIMATED AREA", "${activeTarget.estimatedAreaMm2} mm²", "Polygon Integral", Modifier.weight(1f))
            MetricBox("ESTIMATED VOLUME", String.format("%.1f cm³", activeTarget.volumeEstimateCm3), "Triangulated Spheroid", Modifier.weight(1f))
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            MetricBox("SHAPE GEOMETRY", activeTarget.shapeClass, "Mardia Ellipticity", Modifier.weight(1f))
            MetricBox("SURFACE TEXTURE", activeTarget.surfaceTexture, "Local Binary Pattern", Modifier.weight(1f))
          }

          Spacer(modifier = Modifier.height(2.dp))
          Divider(color = BorderNavy, thickness = 1.dp)

          // Scientific Assay Section (with strict scientific boundary)
          Text(
            text = "LINKED LABORATORY ELEMENTAL ASSAY (Μετάλλιον Inc.)",
            style = MaterialTheme.typography.labelSmall.copy(color = AmberCaution, fontWeight = FontWeight.Bold)
          )

          if (activeTarget.assayRecord != null) {
            val assay = activeTarget.assayRecord
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .background(GraphiteBlack, RoundedCornerShape(4.dp))
                .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
                .padding(8.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "ASSAY ID: ${assay.assayId} (${assay.cruiseId})",
                  style = MaterialTheme.typography.labelSmall.copy(color = IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                )
                Text(
                  text = "CERTIFIED ICP-MS",
                  style = MaterialTheme.typography.labelSmall.copy(color = NoduleTargetEmerald, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                )
              }

              Text(
                text = "PROVENANCE: ${assay.sampleProvenance} | CERT: ${assay.labCertNumber}",
                style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 8.sp)
              )

              // Elemental Grades Table
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
              ) {
                ElementalGradePill("Mn", assay.mnPercent, SonarCyan, Modifier.weight(1f))
                ElementalGradePill("Ni", assay.niPercent, NoduleTargetEmerald, Modifier.weight(1f))
                ElementalGradePill("Cu", assay.cuPercent, AmberCaution, Modifier.weight(1f))
                ElementalGradePill("Co", assay.coPercent, SpectralViolet, Modifier.weight(1f))
                ElementalGradePill("Fe", assay.fePercent, SteelGrey, Modifier.weight(1f))
              }

              Text(
                text = "LABORATORY: ${assay.certifiedLab} (±${(assay.uncertaintyPct * 100).toInt()}% uncert)",
                style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp)
              )
            }
          } else {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(GraphiteBlack.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
                .padding(12.dp)
            ) {
              Text(
                text = "LABORATORY ASSAY STATUS: PENDING RECOVERY\nOptical inspection classifies object as Fe-Mn candidate based on morphology and spectral reflectance. Chemical assays cannot be inferred without physical sample laboratory ICP-MS.",
                style = MaterialTheme.typography.bodySmall.copy(color = AmberCaution, fontSize = 9.sp, lineHeight = 13.sp)
              )
            }
          }

          // Rigorous Scientific Boundary Disclaimer Banner
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(AlertRed.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
              .border(1.dp, AlertRed.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
              .padding(6.dp)
          ) {
            Text(
              text = "SCIENTIFIC PROTOCOL NOTICE: In accordance with NI 43-101 and JORC reporting standards, optical camera and spectral imaging do not provide direct quantitative elemental concentrations. Grades displayed derive exclusively from linked certified lab assays.",
              style = MaterialTheme.typography.bodySmall.copy(color = AlertRed, fontSize = 7.5.sp, lineHeight = 10.sp)
            )
          }
        }
      }
    }
  }
}

@Composable
fun MetricBox(label: String, value: String, sub: String, modifier: Modifier = Modifier) {
  Box(
    modifier = modifier
      .background(GraphiteBlack, RoundedCornerShape(4.dp))
      .border(1.dp, BorderNavy, RoundedCornerShape(4.dp))
      .padding(6.dp)
  ) {
    Column {
      Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey, fontSize = 7.5.sp))
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.labelMedium.copy(
          color = IceWhite,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold
        )
      )
      Text(text = sub, style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 7.5.sp))
    }
  }
}

@Composable
fun ElementalGradePill(element: String, percent: Float, color: Color, modifier: Modifier = Modifier) {
  Box(
    modifier = modifier
      .background(color.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
      .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
      .padding(vertical = 4.dp, horizontal = 2.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(text = element, style = MaterialTheme.typography.labelSmall.copy(color = color, fontWeight = FontWeight.Bold, fontSize = 8.5.sp))
      Text(
        text = String.format("%.2f%%", percent),
        style = MaterialTheme.typography.labelMedium.copy(color = IceWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 9.sp)
      )
    }
  }
}
