"""
AARDVARK SUBSEA — MULTIBEAM & SIDESCAN SONAR PROCESSING
Waterfall acoustic echogram rasteriser, TVG compensation, and bottom tracking.
"""

from dataclasses import dataclass
from typing import List, Tuple
import numpy as np

@dataclass
class SonarPing:
    ping_number: int
    timestamp_utc: str
    frequency_khz: int
    range_m: float
    port_samples: List[float]
    starboard_samples: List[float]
    bottom_range_m: float

class SonarProcessor:
    def __init__(self, samples_per_channel: int = 512, sound_velocity_ms: float = 1482.5):
        self.num_samples = samples_per_channel
        self.svp = sound_velocity_ms

    def apply_tvg(self, raw_samples: np.ndarray, alpha_db_km: float = 120.0) -> np.ndarray:
        """
        Time-Varied Gain (TVG) compensation: 20*log10(R) + 2*alpha*R
        Compensates for acoustic geometric spreading and absorption in deep sea.
        """
        r = np.linspace(0.1, 1.0, len(raw_samples))
        spreading = 20.0 * np.log10(r)
        absorption = 2.0 * (alpha_db_km / 1000.0) * r
        gain_curve = np.clip(10.0 ** ((spreading + absorption) / 20.0), 0.1, 10.0)
        return np.clip(raw_samples * gain_curve, 0.0, 1.0)

    def detect_bottom(self, samples: np.ndarray, threshold: float = 0.35) -> float:
        """Threshold gate bottom detection to determine altitude from acoustic nadir return."""
        above_thresh = np.where(samples > threshold)[0]
        if len(above_thresh) > 0:
            first_idx = above_thresh[0]
            fraction = first_idx / len(samples)
            return float(fraction * 50.0) # 50m max range
        return 3.24
