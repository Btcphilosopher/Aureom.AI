"""
AARDVARK SUBSEA — SCIENTIFIC OPTICAL ENHANCEMENT PIPELINE
Industrial underwater image correction taking into account wavelength-dependent attenuation.
"""

from typing import Tuple
import numpy as np
import cv2

class UnderwaterOpticalPipeline:
    def __init__(
        self,
        water_attenuation_red: float = 0.72,
        water_attenuation_blue_green: float = 0.35,
        dark_channel_omega: float = 0.65,
        clahe_clip_limit: float = 2.0,
        grid_size: Tuple[int, int] = (8, 8),
    ):
        self.atten_red = water_attenuation_red
        self.atten_bg = water_attenuation_blue_green
        self.omega = dark_channel_omega
        self.clahe = cv2.createCLAHE(clipLimit=clahe_clip_limit, tileGridSize=grid_size)

    def compensate_wavelength_attenuation(self, bgr_image: np.ndarray, altitude_m: float = 3.24) -> np.ndarray:
        """
        Compensate for wavelength-dependent attenuation in deep seawater.
        Red light (650-700nm) undergoes exponential absorption: I_obs = I_0 * exp(-beta * d)
        Compensation applies inverse attenuation gain bounded to prevent noise amplification.
        """
        img_float = bgr_image.astype(np.float32) / 255.0
        b, g, r = cv2.split(img_float)

        # Wavelength attenuation coefficients in oceanic Jerlov Type I waters
        # beta_r ~ 0.35 m^-1, beta_g ~ 0.05 m^-1, beta_b ~ 0.02 m^-1
        two_way_path = altitude_m * 2.0
        gain_r = np.clip(np.exp(0.28 * two_way_path * self.atten_red), 1.0, 3.5)
        gain_g = np.clip(np.exp(0.04 * two_way_path * self.atten_bg), 1.0, 1.4)
        gain_b = 1.0

        r_corr = np.clip(r * gain_r, 0.0, 1.0)
        g_corr = np.clip(g * gain_g, 0.0, 1.0)
        b_corr = np.clip(b * gain_b, 0.0, 1.0)

        merged = cv2.merge([b_corr, g_corr, r_corr])
        return (merged * 255.0).astype(np.uint8)

    def dark_channel_dehaze(self, bgr_image: np.ndarray, patch_size: int = 15) -> np.ndarray:
        """
        Dark Channel Prior (DCP) adapted for underwater turbid environments.
        Estimated transmission map t(x) = 1 - omega * min_c(min_patch(I_c(x) / A_c))
        """
        img_float = bgr_image.astype(np.float32) / 255.0
        dark_channel = np.min(img_float, axis=2)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (patch_size, patch_size))
        dark_channel = cv2.erode(dark_channel, kernel)

        # Estimate ambient water veiling light A
        flat_dark = dark_channel.ravel()
        num_brightest = max(int(flat_dark.size * 0.001), 1)
        indices = np.argpartition(flat_dark, -num_brightest)[-num_brightest:]
        brightest_pixels = img_float.reshape(-1, 3)[indices]
        atmospheric_light = np.mean(brightest_pixels, axis=0)

        # Transmission map
        norm_img = img_float / np.maximum(atmospheric_light, 0.01)
        transmission = 1.0 - self.omega * cv2.erode(np.min(norm_img, axis=2), kernel)
        transmission = np.clip(transmission, 0.15, 1.0)

        # Recover scene radiance
        recovered = np.zeros_like(img_float)
        for c in range(3):
            recovered[:, :, c] = (img_float[:, :, c] - atmospheric_light[c]) / transmission + atmospheric_light[c]

        return (np.clip(recovered, 0.0, 1.0) * 255.0).astype(np.uint8)

    def enhance(self, bgr_image: np.ndarray, altitude_m: float = 3.24) -> np.ndarray:
        """Full pipeline execution: Attenuation compensation -> Dehazing -> LAB CLAHE contrast stretch."""
        comp = self.compensate_wavelength_attenuation(bgr_image, altitude_m)
        dehazed = self.dark_channel_dehaze(comp)

        # Convert to LAB space for luminance contrast enhancement without altering chrominance
        lab = cv2.cvtColor(dehazed, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        l_clahe = self.clahe.apply(l)
        enhanced_lab = cv2.merge([l_clahe, a, b])
        return cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2BGR)
