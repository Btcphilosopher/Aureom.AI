"""
AARDVARK SUBSEA — MULTI-MODAL SENSOR FUSION ENGINE
Temporal synchronisation, lever-arm acoustic registration, and uncertainty propagation.
"""

from dataclasses import dataclass
from typing import List, Tuple
import numpy as np

@dataclass
class TransformedTarget:
    target_id: str
    body_x_m: float
    body_y_m: float
    body_z_m: float
    world_lat: float
    world_lon: float
    confidence: float

class SensorFusionEngine:
    def __init__(
        self,
        camera_offset_frd: Tuple[float, float, float] = (0.35, 0.0, -0.15),
        sonar_offset_frd: Tuple[float, float, float] = (0.45, 0.0, -0.22),
    ):
        self.cam_lever_arm = np.array(camera_offset_frd)
        self.sonar_lever_arm = np.array(sonar_offset_frd)

    def camera_to_body_frame(self, optical_x_m: float, optical_y_m: float, depth_z_m: float) -> np.ndarray:
        """Transforms 3D optical detection coordinates into ROV Forward-Right-Down body frame."""
        pt_cam = np.array([depth_z_m, optical_x_m, optical_y_m])
        return pt_cam + self.cam_lever_arm

    def body_to_geodetic(
        self, body_point: np.ndarray, vehicle_lat: float, vehicle_lon: float, heading_deg: float
    ) -> Tuple[float, float]:
        """Rotates body point by vehicle heading and translates onto WGS84 geographic coordinates."""
        rad = np.radians(heading_deg)
        rot_matrix = np.array([
            [np.cos(rad), -np.sin(rad)],
            [np.sin(rad), np.cos(rad)]
        ])
        horizontal_disp = np.dot(rot_matrix, body_point[:2])
        # 1 deg latitude ~ 111,139 m
        # 1 deg longitude ~ 111,139 * cos(lat) m
        delta_lat = horizontal_disp[0] / 111139.0
        delta_lon = horizontal_disp[1] / (111139.0 * np.cos(np.radians(vehicle_lat)))
        return vehicle_lat + delta_lat, vehicle_lon + delta_lon
