"""
AARDVARK SUBSEA — HYPERSPECTRAL SCIENTIFIC PROCESSING
Spectral cube ingestion, Spectral Angle Mapper (SAM), PCA dimensionality reduction, and ROI spectral extraction.
"""

from dataclasses import dataclass
from typing import Dict, List, Tuple
import numpy as np

@dataclass
class SpectralSignature:
    label: str
    wavelengths_nm: List[int]
    reflectance: List[float]

class HyperspectralProcessor:
    def __init__(self, num_bands: int = 61, start_wl: int = 400, end_wl: int = 1000):
        self.wavelengths = np.linspace(start_wl, end_wl, num_bands).astype(int).tolist()
        self.library = self._init_spectral_library()

    def _init_spectral_library(self) -> Dict[str, np.ndarray]:
        wl = np.array(self.wavelengths, dtype=np.float32)
        # Polymetallic Fe-Mn nodule standard
        fe_mn = 0.045 + 0.125 * (1.0 - np.exp(-(wl - 400.0) / 220.0))
        # Pelagic calcareous ooze
        ooze = 0.16 + 0.19 * ((wl - 400.0) / 600.0)
        # Oceanic basalt crust
        basalt = 0.075 + 0.02 * ((wl - 400.0) / 600.0)
        return {
            "Fe-Mn Nodule Standard": fe_mn,
            "Pelagic Calcareous Ooze": ooze,
            "Oceanic Basalt Substrate": basalt,
        }

    def spectral_angle_mapper(self, pixel_spectrum: np.ndarray, reference_spectrum: np.ndarray) -> float:
        """
        Calculates spectral angle theta (radians) between pixel vector and reference library vector.
        theta = arccos( (t . r) / (||t|| * ||r||) )
        Lower angle implies closer spectral match.
        """
        dot = np.dot(pixel_spectrum, reference_spectrum)
        norm_t = np.linalg.norm(pixel_spectrum)
        norm_r = np.linalg.norm(reference_spectrum)
        if norm_t == 0 or norm_r == 0:
            return float(np.pi / 2.0)
        cos_theta = np.clip(dot / (norm_t * norm_r), -1.0, 1.0)
        return float(np.arccos(cos_theta))

    def classify_pixel(self, pixel_spectrum: np.ndarray) -> Tuple[str, float]:
        """Classify pixel spectrum against the certified scientific library."""
        best_match = "Unclassified"
        min_angle = float("inf")
        for name, ref in self.library.items():
            angle = self.spectral_angle_mapper(pixel_spectrum, ref)
            if angle < min_angle:
                min_angle = angle
                best_match = name
        # Convert angle to normalized confidence [0, 1]
        confidence = float(np.clip(1.0 - (min_angle / (np.pi / 4.0)), 0.0, 1.0))
        return best_match, confidence

    def principal_component_analysis(self, cube: np.ndarray, n_components: int = 3) -> np.ndarray:
        """
        Reduces H x W x B spectral cube to H x W x 3 principal component false-colour composite.
        """
        h, w, b = cube.shape
        flat = cube.reshape(-1, b)
        mean_centered = flat - np.mean(flat, axis=0)
        cov = np.cov(mean_centered, rowvar=False)
        eigenvalues, eigenvectors = np.linalg.eigh(cov)
        # Select top eigenvectors
        idx = np.argsort(eigenvalues)[::-1][:n_components]
        top_eigenvectors = eigenvectors[:, idx]
        projected = np.dot(mean_centered, top_eigenvectors)
        # Normalize to 0-255 RGB
        projected_norm = (projected - projected.min(axis=0)) / np.maximum(projected.ptp(axis=0), 1e-6)
        return (projected_norm.reshape(h, w, n_components) * 255.0).astype(np.uint8)
