"""
AARDVARK SUBSEA — POLYMETALLIC NODULE INTELLIGENCE
Automated detection, morphological segmentation, and spatial density quantification.
"""

from dataclasses import dataclass
from typing import List, Optional, Tuple
import cv2
import numpy as np

@dataclass
class SegmentedNodule:
    id: str
    centroid_px: Tuple[int, int]
    apparent_diameter_mm: float
    surface_area_mm2: float
    estimated_volume_cm3: float
    shape_class: str
    surface_texture: str
    detection_confidence: float
    spatial_density_kg_m2: float

class NoduleSegmentationEngine:
    def __init__(self, camera_fx_px: float = 2842.0, laser_baseline_mm: float = 100.0):
        self.fx = camera_fx_px
        self.laser_baseline = laser_baseline_mm

    def segment_frame(self, image_bgr: np.ndarray, altitude_m: float = 3.24) -> List[SegmentedNodule]:
        """
        Segments nodule targets using adaptive thresholding, morphological opening, and contour analysis.
        Calibrates pixels to millimetres using pinhole model: mm_per_px = (altitude_mm) / fx
        """
        gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (7, 7), 0)

        # Nodules on abyssal plain appear as dark absorbers against lighter biogenic sediment
        thresh = cv2.adaptiveThreshold(
            blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 25, 4
        )

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        cleaned = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)

        contours, _ = cv2.findContours(cleaned, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        altitude_mm = altitude_m * 1000.0
        mm_per_px = altitude_mm / self.fx

        results = []
        counter = 2184

        for c in contours:
            area_px = cv2.contourArea(c)
            # Filter noise and ultra-large boundaries
            if area_px < 150 or area_px > 50000:
                continue

            (x, y), (w_px, h_px), angle = cv2.fitEllipse(c) if len(c) >= 5 else cv2.minAreaRect(c)
            major_mm = max(w_px, h_px) * mm_per_px
            minor_mm = min(w_px, h_px) * mm_per_px
            apparent_diameter = (major_mm + minor_mm) / 2.0
            area_mm2 = area_px * (mm_per_px ** 2)

            # Triaxial ellipsoid volume estimation: V = 4/3 * pi * a * b * c
            # Assuming c (height) ~ 0.8 * minor_mm
            vol_cm3 = (4.0 / 3.0 * np.pi * (major_mm / 20.0) * (minor_mm / 20.0) * (minor_mm * 0.8 / 20.0))

            # Shape classification: Ellipticity = major / minor
            ellipticity = major_mm / max(minor_mm, 1e-2)
            if ellipticity < 1.25:
                shape = "Spheroidal"
            elif ellipticity < 1.6:
                shape = "Ellipsoidal"
            else:
                shape = "Discoidal"

            # Texture from perimeter roughness: circularity = 4 * pi * area / perimeter^2
            perimeter = cv2.arcLength(c, True)
            circularity = (4.0 * np.pi * area_px) / max(perimeter ** 2, 1e-3)
            texture = "Botryoidal / Nodular" if circularity < 0.75 else "Smooth Micro-nodular"

            # Wet bulk nodule density in CCZ is typically ~1.95 g/cm³
            mass_kg = (vol_cm3 * 1.95) / 1000.0

            results.append(
                SegmentedNodule(
                    id=f"ND-{counter:06d}",
                    centroid_px=(int(x), int(y)),
                    apparent_diameter_mm=round(apparent_diameter, 1),
                    surface_area_mm2=round(area_mm2, 1),
                    estimated_volume_cm3=round(vol_cm3, 1),
                    shape_class=shape,
                    surface_texture=texture,
                    detection_confidence=float(np.clip(0.88 + 0.10 * circularity, 0.80, 0.99)),
                    spatial_density_kg_m2=round(mass_kg * 4.5, 2),
                )
            )
            counter += 1

        return results
