"""
AARDVARK SUBSEA — SCIENTIFIC BACKEND API
FastAPI REST and WebSocket endpoints for subsea intelligence workstation.
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import asyncio
import json
import time

app = FastAPI(
    title="Aardvark Subsea Intelligence Backend",
    version="1.0.0",
    description="Scientific processing, sensor acquisition, and telemetry services for Aardvark Subsea Workstation."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {
        "system": "AARDVARK SUBSEA INTELLIGENCE",
        "status": "OPERATIONAL",
        "cruise": "CCZ-2026-IV",
        "client": "Μετάλλιον Inc.",
        "station": "Clarion-Clipperton Zone Station 145-N",
        "hardware_stream": "CALIBRATED_PHYSICAL_BENCHMARK",
    }

@app.get("/api/telemetry")
def get_telemetry():
    return {
        "depth_m": 4124.6,
        "altitude_m": 3.24,
        "heading_deg": 214.5,
        "pitch_deg": -1.2,
        "roll_deg": 0.8,
        "speed_knots": 0.48,
        "pressure_bar": 418.5,
        "water_temp_c": 1.84,
        "salinity_psu": 34.72,
        "usbl_lat": 14.284912,
        "usbl_lon": -125.820341,
        "navigation_confidence_pct": 98.4,
        "is_simulated_benchmark": True,
    }

@app.get("/api/nodules")
def get_nodules():
    return [
        {
            "id": "ND-002184",
            "apparent_diameter_mm": 84,
            "estimated_area_mm2": 5540,
            "volume_cm3": 232.5,
            "shape": "Spheroidal",
            "texture": "Botryoidal / Nodular",
            "confidence": 0.962,
            "assay": {
                "assay_id": "ASY-CCZ-8812",
                "mn_pct": 29.40,
                "ni_pct": 1.42,
                "cu_pct": 1.18,
                "co_pct": 0.25,
                "fe_pct": 5.82,
                "certified_lab": "British Geological Survey Marine Geochem Lab (ISO 17025)",
            }
        },
        {
            "id": "ND-002185",
            "apparent_diameter_mm": 112,
            "estimated_area_mm2": 9850,
            "volume_cm3": 552.0,
            "shape": "Ellipsoidal",
            "texture": "Botryoidal / Nodular",
            "confidence": 0.948,
            "assay": {
                "assay_id": "ASY-CCZ-8813",
                "mn_pct": 30.15,
                "ni_pct": 1.48,
                "cu_pct": 1.22,
                "co_pct": 0.23,
                "fe_pct": 5.60,
                "certified_lab": "British Geological Survey Marine Geochem Lab (ISO 17025)",
            }
        }
    ]

@app.get("/api/carbon/raman")
def get_raman():
    return {
        "excitation_wavelength_nm": 785.0,
        "shift_range_cm1": [800.0, 2000.0],
        "d_band": {"center_cm1": 1348.0, "amplitude": 420.0, "fwhm_cm1": 52.0},
        "g_band": {"center_cm1": 1584.0, "amplitude": 478.0, "fwhm_cm1": 46.0},
        "id_ig_ratio": 0.879,
        "carbonate_peak_1085_cm1": 185.0,
        "interpretation": "High-structural-disorder carbonaceous material (kerogen-like sp² carbon) associated with authigenic marine carbonate substrate.",
        "scientific_notice": "Raman D/G modes quantify structural disorder, not total carbon concentration."
    }

@app.websocket("/ws/telemetry")
async def websocket_telemetry(websocket: WebSocket):
    await websocket.accept()
    try:
        t = 0.0
        while True:
            await asyncio.sleep(0.5)
            t += 0.5
            payload = {
                "timestamp_epoch": time.time(),
                "depth_m": 4124.6 + (0.35 * (t % 10.0)),
                "altitude_m": 3.24,
                "heading_deg": (214.5 + t * 0.1) % 360.0,
                "optical_fps": 59.8,
                "dma_mbps": 840.5,
            }
            await websocket.send_text(json.dumps(payload))
    except WebSocketDisconnect:
        pass
