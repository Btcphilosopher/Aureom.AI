// =============================================================================
// AARDVARK IMAGING — SUBSEA HARDWARE LAYER
// Module: tb_sensor_timing.sv
// Description: Self-checking testbench for sensor_timing_controller.sv
// =============================================================================

`timescale 1ns / 1ps

module tb_sensor_timing;

    logic        clk;
    logic        rst_n;
    logic [31:0] reg_exposure_ticks;
    logic [31:0] reg_frame_period_ticks;
    logic        reg_trigger_enable;
    logic        reg_sync_ptp_pulse;

    logic        sensor_master_trigger;
    logic        sensor_exposure_gate;
    logic        sensor_frame_valid;
    logic [63:0] timestamp_utc_ns;
    logic        timestamp_valid;

    // Instantiate Unit Under Test (UUT)
    sensor_timing_controller #(
        .SYS_CLK_FREQ_HZ(250_000_000),
        .DEFAULT_FPS(60)
    ) uut (
        .clk(clk),
        .rst_n(rst_n),
        .reg_exposure_ticks(reg_exposure_ticks),
        .reg_frame_period_ticks(reg_frame_period_ticks),
        .reg_trigger_enable(reg_trigger_enable),
        .reg_sync_ptp_pulse(reg_sync_ptp_pulse),
        .sensor_master_trigger(sensor_master_trigger),
        .sensor_exposure_gate(sensor_exposure_gate),
        .sensor_frame_valid(sensor_frame_valid),
        .timestamp_utc_ns(timestamp_utc_ns),
        .timestamp_valid(timestamp_valid)
    );

    // 250 MHz Clock Generator (Period = 4ns -> Toggle every 2ns)
    initial clk = 0;
    always #2 clk = ~clk;

    initial begin
        $display("=== AARDVARK SUBSEA HARDWARE TIMING TESTBENCH START ===");
        rst_n                  = 0;
        reg_exposure_ticks     = 32'd50;   // 200ns exposure for test
        reg_frame_period_ticks = 32'd200;  // 800ns period for test
        reg_trigger_enable     = 0;
        reg_sync_ptp_pulse     = 0;

        // Apply reset
        #20 rst_n = 1;
        #20;

        // Verify timestamp counter progresses
        assert (timestamp_valid == 1'b1) else $error("Timestamp valid failed");
        #40;
        assert (timestamp_utc_ns > 0) else $error("Timestamp counter not running");

        // Enable trigger generator
        reg_trigger_enable = 1;

        // Wait for first frame trigger
        @(posedge sensor_master_trigger);
        $display("[PASS] Master trigger asserted at time %0t ns (Timestamp: %0d ns)", $time, timestamp_utc_ns);
        assert (sensor_exposure_gate == 1'b1) else $error("Exposure gate did not open");

        // Wait for exposure gate to close
        @(negedge sensor_exposure_gate);
        $display("[PASS] Exposure gate closed correctly at time %0t ns", $time);

        #1000;
        $display("=== ALL HARDWARE TIMING CHECKS PASSED SUCCESSFULLY ===");
        $finish;
    end

endmodule
