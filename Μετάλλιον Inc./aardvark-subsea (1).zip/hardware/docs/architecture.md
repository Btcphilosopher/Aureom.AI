# AARDVARK SUBSEA — HARDWARE ARCHITECTURE SPECIFICATION
## Silica Flux Standard Sensor Acquisition & Timing Layer

### 1. Overview
The Aardvark Subsea hardware subsystem provides microsecond-synchronised, high-throughput acquisition across multi-modal deep-sea sensors:
- High-Speed 4K Optical Camera (Sony IMX586 via SLVS-EC)
- Specim SWIR Hyperspectral Camera (Camera Link / CoaXPress)
- Kongsberg EM2040 Multibeam & Side-scan Sonar (GigE Vision / UDP)
- In-situ 785nm Raman Spectrometer (USB-TMC / SPI)
- USBL / DVL / INS Navigation Suite (RS-422 / PTP IEEE 1588)

### 2. Clock Domains & Timing
- **System PLL Master Clock**: 250.0 MHz (4.0 ns period)
- **Sensor Pixel Clocks**: 148.5 MHz / 300.0 MHz domain-isolated via asynchronous dual-clock FIFOs
- **Timestamping Engine**: 64-bit nanosecond counter synchronized via PTP IEEE 1588 pulses from subsea INS navigation unit.

### 3. Silica Flux Register Map
| Address Offset | Register Name | Access | Reset Value | Description |
|---|---|---|---|---|
| `0x00` | `REG_STATUS` | RO | `0x00000001` | Bit 0: Streaming Active, Bit 1: PLL Lock, Bit 2: PTP Synced |
| `0x04` | `REG_CONTROL` | RW | `0x00000001` | Bit 0: Trigger Enable, Bit 1: DMA Enable, Bit 2: Laser Firing Permit |
| `0x08` | `REG_TIMESTAMP_LO` | RO | `0x00000000` | UTC Epoch Nanoseconds [31:0] |
| `0x0C` | `REG_TIMESTAMP_HI` | RO | `0x00000000` | UTC Epoch Nanoseconds [63:32] |
| `0x10` | `REG_EXPOSURE` | RW | `3125000` | Shutter exposure duration in 4ns clock ticks (12.5 ms default) |
| `0x14` | `REG_FRAME_PERIOD` | RW | `4166666` | Inter-frame duration in 4ns clock ticks (60.0 FPS default) |
| `0x18` | `REG_DMA_BURST` | RW | `1024` | DMA AXI burst size in 64-bit words |
| `0x1C` | `REG_FIFO_WATERMARK`| RO | `0x003C` | Asynchronous ingress buffer fill level (%) |
| `0x20` | `REG_TEMPERATURE` | RO | `0x1C20` | Sensor housing core temperature in millidegrees Celsius |

### 4. DMA Packet Structure
Every optical and spectral packet transmitted over PCIe Gen3 x4 DMA begins with a standardized 128-bit header:
- `[63:0]`: Magic Sync Word `0x5355425345413031` ("SUBSEA01")
- `[127:64]`: 64-bit PTP Synchronized UTC Nanosecond Timestamp
Followed by sensor pixel payload and CRC-32 cyclic redundancy check trailer.
