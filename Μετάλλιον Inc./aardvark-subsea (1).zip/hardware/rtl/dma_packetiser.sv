// =============================================================================
// AARDVARK IMAGING — SUBSEA HARDWARE LAYER
// Module: dma_packetiser.sv
// Description: Streams formatted pixel/spectral data to host memory via DMA,
//              injecting 64-bit UTC timestamp and packet checksums.
// Architecture: Silica Flux High-Throughput Sensor DMA
// =============================================================================

`timescale 1ns / 1ps

module dma_packetiser #(
    parameter int unsigned DATA_WIDTH = 64
)(
    input  logic                   clk,
    input  logic                   rst_n,

    // Sensor Ingress Stream
    input  logic [DATA_WIDTH-1:0]  sensor_axis_tdata,
    input  logic                   sensor_axis_tvalid,
    input  logic                   sensor_axis_tlast,
    output logic                   sensor_axis_tready,

    // Master Timestamp
    input  logic [63:0]            timestamp_utc_ns,

    // Host DMA Master Egress
    output logic [DATA_WIDTH-1:0]  dma_m_axis_tdata,
    output logic                   dma_m_axis_tvalid,
    output logic                   dma_m_axis_tlast,
    input  logic                   dma_m_axis_tready,

    // Diagnostics
    output logic [15:0]            fifo_occupancy,
    output logic                   overflow_flag
);

    typedef enum logic [1:0] {
        IDLE_HDR,
        SEND_TIMESTAMP,
        STREAM_PAYLOAD,
        SEND_TRAILER
    } state_t;

    state_t state;
    logic [15:0] count;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state              <= IDLE_HDR;
            dma_m_axis_tdata   <= '0;
            dma_m_axis_tvalid  <= 1'b0;
            dma_m_axis_tlast   <= 1'b0;
            sensor_axis_tready <= 1'b0;
            fifo_occupancy     <= 16'd0;
            overflow_flag      <= 1'b0;
            count              <= 16'd0;
        end else begin
            case (state)
                IDLE_HDR: begin
                    if (sensor_axis_tvalid) begin
                        // Transmit 64-bit Sync Word (0x5355425345413031 -> "SUBSEA01")
                        dma_m_axis_tdata   <= 64'h5355425345413031;
                        dma_m_axis_tvalid  <= 1'b1;
                        dma_m_axis_tlast   <= 1'b0;
                        sensor_axis_tready <= 1'b0;
                        if (dma_m_axis_tready) begin
                            state <= SEND_TIMESTAMP;
                        end
                    end else begin
                        dma_m_axis_tvalid  <= 1'b0;
                        sensor_axis_tready <= 1'b1;
                    end
                end

                SEND_TIMESTAMP: begin
                    dma_m_axis_tdata   <= timestamp_utc_ns;
                    dma_m_axis_tvalid  <= 1'b1;
                    dma_m_axis_tlast   <= 1'b0;
                    sensor_axis_tready <= 1'b0;
                    if (dma_m_axis_tready) begin
                        state <= STREAM_PAYLOAD;
                    end
                end

                STREAM_PAYLOAD: begin
                    sensor_axis_tready <= dma_m_axis_tready;
                    dma_m_axis_tdata   <= sensor_axis_tdata;
                    dma_m_axis_tvalid  <= sensor_axis_tvalid;
                    dma_m_axis_tlast   <= sensor_axis_tlast;

                    if (sensor_axis_tvalid && dma_m_axis_tready && sensor_axis_tlast) begin
                        state <= IDLE_HDR;
                    end
                end

                default: state <= IDLE_HDR;
            endcase
        end
    end

endmodule
