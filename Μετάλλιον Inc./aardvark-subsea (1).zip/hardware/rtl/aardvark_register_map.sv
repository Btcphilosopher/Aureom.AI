// =============================================================================
// AARDVARK IMAGING — SUBSEA HARDWARE LAYER
// Module: aardvark_register_map.sv
// Description: Standardized 32-bit memory-mapped register interface
// Architecture: Silica Flux Standard Hardware Register Interface
// =============================================================================

`timescale 1ns / 1ps

module aardvark_register_map (
    input  logic        clk,
    input  logic        rst_n,

    // Host AXI4-Lite / Silica Flux Bus Interface
    input  logic [7:0]  bus_addr,
    input  logic [31:0] bus_wdata,
    input  logic        bus_write_en,
    input  logic        bus_read_en,
    output logic [31:0] bus_rdata,
    output logic        bus_ready,

    // Hardware Status Inputs from Sensors and DMA
    input  logic [31:0] hw_status_bits,
    input  logic [63:0] hw_timestamp_utc,
    input  logic [15:0] hw_fifo_watermark,
    input  logic [15:0] hw_housing_temp_mdeg_c,

    // Hardware Control Outputs to Peripherals
    output logic [31:0] ctrl_reg,
    output logic [31:0] exposure_ticks_reg,
    output logic [31:0] frame_period_ticks_reg,
    output logic [31:0] dma_burst_size_reg,
    output logic        trigger_enable_out
);

    // Register Map Offsets
    localparam logic [7:0] ADDR_STATUS         = 8'h00;
    localparam logic [7:0] ADDR_CONTROL        = 8'h04;
    localparam logic [7:0] ADDR_TIMESTAMP_LO   = 8'h08;
    localparam logic [7:0] ADDR_TIMESTAMP_HI   = 8'h0C;
    localparam logic [7:0] ADDR_EXPOSURE       = 8'h10;
    localparam logic [7:0] ADDR_FRAME_PERIOD   = 8'h14;
    localparam logic [7:0] ADDR_DMA_BURST      = 8'h18;
    localparam logic [7:0] ADDR_FIFO_WATERMARK = 8'h1C;
    localparam logic [7:0] ADDR_TEMPERATURE    = 8'h20;

    // Internal Registers
    logic [31:0] r_control;
    logic [31:0] r_exposure;
    logic [31:0] r_frame_period;
    logic [31:0] r_dma_burst;

    assign ctrl_reg               = r_control;
    assign exposure_ticks_reg     = r_exposure;
    assign frame_period_ticks_reg = r_frame_period;
    assign dma_burst_size_reg     = r_dma_burst;
    assign trigger_enable_out     = r_control[0];

    // Write Logic
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_control      <= 32'h00000001; // Enable streaming by default
            r_exposure     <= 32'd3125000;  // 12.5 ms @ 250 MHz
            r_frame_period <= 32'd4166666;  // 60.0 FPS @ 250 MHz
            r_dma_burst    <= 32'd1024;     // 1024 words per burst
        end else if (bus_write_en) begin
            case (bus_addr)
                ADDR_CONTROL:      r_control      <= bus_wdata;
                ADDR_EXPOSURE:     r_exposure     <= bus_wdata;
                ADDR_FRAME_PERIOD: r_frame_period <= bus_wdata;
                ADDR_DMA_BURST:    r_dma_burst    <= bus_wdata;
                default: ;
            endcase
        end
    end

    // Read Logic
    always_comb begin
        bus_ready = 1'b1;
        case (bus_addr)
            ADDR_STATUS:         bus_rdata = hw_status_bits;
            ADDR_CONTROL:        bus_rdata = r_control;
            ADDR_TIMESTAMP_LO:   bus_rdata = hw_timestamp_utc[31:0];
            ADDR_TIMESTAMP_HI:   bus_rdata = hw_timestamp_utc[63:32];
            ADDR_EXPOSURE:       bus_rdata = r_exposure;
            ADDR_FRAME_PERIOD:   bus_rdata = r_frame_period;
            ADDR_DMA_BURST:      bus_rdata = r_dma_burst;
            ADDR_FIFO_WATERMARK: bus_rdata = {16'h0000, hw_fifo_watermark};
            ADDR_TEMPERATURE:    bus_rdata = {16'h0000, hw_housing_temp_mdeg_c};
            default:             bus_rdata = 32'hDEADBEEF;
        endcase
    end

endmodule
