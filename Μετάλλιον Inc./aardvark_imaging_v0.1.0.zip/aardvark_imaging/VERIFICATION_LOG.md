# Verification log: defects found and fixed

Every entry here was found by a failing test, simulation or measurement, not by inspection. Each one is covered by a test that now passes.

## RTL (found in Verilator simulation)

| # | Module | Defect | Detection | Fix |
|---|---|---|---|---|
| H1 | sf_lvds_aligner | output-valid not gated per frame word; misaligned words leaked during re-lock | slip-injection testbench | per-word frame gating |
| H2 | sf_hsi/ms/swir_controller | trigger during exposure stretched the exposure instead of counting an overrun | controller testbenches | exposure is latched; mid-exposure triggers increment the overrun counter |
| H3 | sf_multispectral_controller | packet band tag sampled after the band advanced | band-in-meta check | context captures `band` at exposure start |
| H4 | sf_multispectral_controller | band sequence restarted from the wrong base after masked bands | LED round-robin check | base fixed |
| H5 | sf_raman_controller | pixel readout not paced by ADC completion; pixels skipped | exact co-add sums | readout waits for ADC done |
| H6 | sf_ir_controller, sf_fluorescence_controller | source switching not aligned to the sample start; on/off windows contaminated | exact lock-in sums | switch on sample boundary |
| H7 | sf_laser_timing | `MAX_ON_HW` literal overflowed the parameter width | Verilator lint | width and literal corrected (3e9 cycles) |

## Testbench defects (the testbench was wrong, not the RTL)

* **CDC testbench:**
  * counted pulses during reset;
  * the asynchronous reset had no edge, so the reset logic was never exercised.
* **Register-file and packetiser testbenches** hung or double-counted handshakes. Two causes: handshakes were sampled at posedge, and several processes wrote one shared vector. Fixed by deciding handshakes at negedge and giving each source private signals.
* **Verilator C++ error:** a struct containing a queue. Replaced with associative arrays.
* **DMA gap check:** placed before trailing drops could be visible. The host only sees a drop when the next packet arrives.
* **Wrong expectations:**
  * off-by-one in the timestamp testbench;
  * synchroniser latency in the laser testbench;
  * word packing in the diagnostics testbench.
* **Full-system testbench** packet-count threshold re-derived from rate arithmetic (150–200; 171 observed).
* **Calibration testbench** stimulus did not reach the clip branch (coverage gap); widened.

## Software and science (found by tests and simulated validation)

| # | Area | Defect | Detection | Fix |
|---|---|---|---|---|
| S1 | environment | seawater index pressure coefficient 10× too small | unit test against published depth dependence | 1.6×10⁻⁴ per MPa |
| S2 | radar | docstring claimed the wrong attenuation | unit test (≈325 dB/m at 100 MHz) | corrected |
| S3 | nodule detection | global Otsu split sediment facies; hot pixels skewed the threshold | simulated validation | median filter, percentile background flattening, threshold capped at 0.55 |
| S4 | carbon | the 1640 cm⁻¹ water bend was fitted as a G band on bare Mn oxide (false carbonaceous detections) | archetype tests | explicit water component in the D/G fit; D1 required |
| S5 | carbon | statistically significant but physically negligible IR/fluorescence signals counted as evidence | archetype tests | systematic floors (0.02 AU; 2 % background) |
| S6 | carbon | absent features gave no evidence against a class | archetype tests | symmetric absence term (factor 0.5) |
| S7 | EMI | platform compensation fitted on the survey data itself (circular) | review of the validation metric | fitted on a separate calibration manoeuvre |
| S8 | grade | Python `hash()` seeding made Monte Carlo results vary between runs | determinism test | zlib.crc32 seeding |
| S9 | performance | simulated survey took ~18 s | timing | vectorised multibeam, fast band assignment (~3 s) |
| S10 | **simulation integrity** | per-nodule HSI unmixing chose its pixel using the *ground-truth* nodule-fraction map (a truth leak into processing) | audit of truth usages in `survey.py` | image-derived choice: darkest valid pixel in a 3×3 window |
| S11 | simulator | DEM-grid fields were nearest-neighbour upsampled, creating hard-edged, nodule-sized dark squares | inspection of a false-positive blob | bilinear resampling |
| S12 | nodule detection | `scipy.ndimage.watershed_ift` (max-arc cost on a quantised image) let one seed flood a touching neighbour | `test_touching_nodules_are_split` | priority-flood watershed of the distance map |
| S13 | nodule detection | elongated nodules over-split into fragments (true 98 mm → 28 mm pieces) | per-nodule error analysis | saddle-based region merge (ratio 0.75) |
| S14 | nodule detection | dark biogenic cover detected as nodules; abundance overestimated 2.3× (16.2 vs 7.1 kg/m²) | new abundance-vs-truth metric | colour test: ln(G/B) of the region versus its annulus. Precision 0.73 → 1.00; recall falls to 0.61–0.72 and abundance is biased low (documented) |
| S15 | API | requested acquisition `duration_s` was consumed by the lazy scene build, which also blocked the event loop | integration test (second start returned 200) | scene built off-loop before the acquisition clock starts |
| S16 | wavelength calibration | an unresolved doublet (Hg 576.96/579.07) was assigned to both lines | synthetic Hg-Ar test | one-to-one matching, ambiguous peaks dropped, robust clipping |
| S17 | HSI classification | pixels with any flagged band were left unclassified (15 % of pixels; visible stripes) | workstation review | classification after interpolation over ≤ 10 % flagged usable bands; cube keeps NaN; count reported |
| S18 | workstation | spectra plotted the water-opaque bands, amplified by the transmission correction to about ±50 reflectance | screenshot review | unusable bands masked, y-range from usable bands |
| S19 | workstation | horizontal page scroll at phone width | Playwright overflow check | scrollable tabs, in-panel table scrolling, secondary columns hidden |
| S20 | packaging | the manifest and frontend were not found from a wheel install | clean-venv install | manifest copy generated into the package; `AARDVARK_FRONTEND_DIR` |
| S21 | storage | API did not persist to SQL; `save_survey` not idempotent on restart | integration test | optional persistence via `AARDVARK_DB_URL`; idempotent save |
| S22 | API helpers | `js()` serialisation and `truth_nodule_fraction` bugs | API smoke test | fixed |

## Test assumptions corrected (the code was right)

* `gain_to_u2_14` raises on out-of-range gain rather than clipping. The test was changed to expect the refusal.
* At 10 kHz and 1 m coil spacing in seawater the induction number is 0.36, so the low-induction-number (LIN) approximation does *not* hold. The test now uses 0.5 m.
* `GridSpec.east0` is a cell centre, not a corner.
* MNF needs spatially correlated signal and is sensitive to outliers in the shift-difference statistics (documented in `docs/spectral_processing.md`).
* The 400 kHz absorption at 4.5 km is about 68 dB/km (the test expectation was too high).
