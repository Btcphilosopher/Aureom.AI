// Lightweight canvas plotting: line plots with axes, raster images with
// colour ramps, categorical maps, horizontal probability bars.

export const C = {
  bg: "#1f2328", grid: "#2c333b", axis: "#8b97a4", text: "#b7c0c9", white: "#f2f4f6",
  blue: "#7ea3cc", amber: "#d6a440", red: "#c9483e", green: "#6f9e7a", steel: "#8b97a4",
};
export const SERIES = ["#7ea3cc", "#d6a440", "#b7c0c9", "#6f9e7a", "#c98a6b", "#9a8fc0"];
export const CATEGORICAL = ["#5b84b1", "#d6a440", "#6f9e7a", "#c98a6b", "#9a8fc0", "#b7c0c9", "#4f9fa6", "#c9483e", "#8b6f4e", "#e3e7ea"];

// navy -> blue -> white perceptual-ish ramp (monotonic luminance)
const RAMP = [[13, 26, 43], [34, 64, 104], [76, 116, 163], [133, 168, 206], [198, 215, 232], [246, 248, 250]];
export function ramp(t) {
  if (!Number.isFinite(t)) return [10, 15, 21];
  t = Math.min(1, Math.max(0, t)) * (RAMP.length - 1);
  const i = Math.min(RAMP.length - 2, Math.floor(t)), f = t - i;
  return RAMP[i].map((a, k) => Math.round(a + f * (RAMP[i + 1][k] - a)));
}
export function rampCss() {
  return `linear-gradient(90deg, ${RAMP.map(c => `rgb(${c})`).join(",")})`;
}
export const hex2rgb = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));

function fit(canvas) {
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth || 600, h = canvas.clientHeight || 240;
  if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
    canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
  }
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return [ctx, w, h];
}

function niceTicks(lo, hi, n = 5) {
  if (!(hi > lo)) { hi = lo + 1; }
  const span = hi - lo, step0 = span / n, mag = 10 ** Math.floor(Math.log10(step0));
  const step = [1, 2, 2.5, 5, 10].map(m => m * mag).find(s => span / s <= n) || 10 * mag;
  const out = [];
  for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-12; v += step) out.push(+v.toPrecision(10));
  return out;
}
const fmt = v => Math.abs(v) >= 1e4 || (Math.abs(v) < 1e-2 && v !== 0) ? v.toExponential(1) : (+v.toPrecision(4)).toString();

/** series: [{x:[], y:[], color, label, dash, width}], opts: {xlabel, ylabel, shade:[[x0,x1],...], markers:[{x,label}]} */
export function linePlot(canvas, series, opts = {}) {
  const [ctx, W, H] = fit(canvas);
  const m = { l: opts.ylabel ? 66 : 50, r: 12, t: 12, b: 34 };
  ctx.fillStyle = C.bg; ctx.fillRect(0, 0, W, H);
  const xs = series.flatMap(s => s.x).filter(Number.isFinite), ys = series.flatMap(s => s.y).filter(Number.isFinite);
  if (!xs.length || !ys.length) { ctx.fillStyle = C.axis; ctx.fillText("no data", W / 2 - 20, H / 2); return; }
  let [x0, x1] = opts.xlim || [Math.min(...xs), Math.max(...xs)];
  let [y0, y1] = opts.ylim || [Math.min(...ys), Math.max(...ys)];
  if (y1 === y0) { y1 += 1; y0 -= 1; }
  const pad = (y1 - y0) * 0.06; y0 -= pad; y1 += pad;
  const X = x => m.l + (x - x0) / (x1 - x0) * (W - m.l - m.r);
  const Y = y => H - m.b - (y - y0) / (y1 - y0) * (H - m.t - m.b);
  ctx.font = "11px ui-monospace, Menlo, monospace";
  for (const [a, b] of opts.shade || []) {
    ctx.fillStyle = "rgba(139,151,164,0.13)";
    ctx.fillRect(X(a), m.t, Math.max(1, X(b) - X(a)), H - m.t - m.b);
  }
  ctx.strokeStyle = C.grid; ctx.lineWidth = 1; ctx.fillStyle = C.axis;
  for (const t of niceTicks(x0, x1, 7)) { ctx.beginPath(); ctx.moveTo(X(t), m.t); ctx.lineTo(X(t), H - m.b); ctx.stroke(); ctx.fillText(fmt(t), X(t) - 12, H - m.b + 14); }
  ctx.textAlign = "right";
  for (const t of niceTicks(y0, y1, 5)) { ctx.beginPath(); ctx.moveTo(m.l, Y(t)); ctx.lineTo(W - m.r, Y(t)); ctx.stroke(); ctx.fillText(fmt(t), m.l - 5, Y(t) + 4); }
  ctx.textAlign = "left";
  ctx.fillStyle = C.text;
  if (opts.xlabel) ctx.fillText(opts.xlabel, W / 2 - opts.xlabel.length * 3, H - 6);
  if (opts.ylabel) { ctx.save(); ctx.translate(11, H / 2 + opts.ylabel.length * 3); ctx.rotate(-Math.PI / 2); ctx.fillText(opts.ylabel, 0, 0); ctx.restore(); }
  series.forEach((s, k) => {
    ctx.strokeStyle = s.color || SERIES[k % SERIES.length]; ctx.lineWidth = s.width || 1.5;
    ctx.setLineDash(s.dash || []); ctx.beginPath(); let pen = false;
    s.x.forEach((x, i) => { const y = s.y[i]; if (!Number.isFinite(x) || !Number.isFinite(y)) { pen = false; return; }
      if (!pen) { ctx.moveTo(X(x), Y(y)); pen = true; } else ctx.lineTo(X(x), Y(y)); });
    ctx.stroke(); ctx.setLineDash([]);
  });
  for (const mk of opts.markers || []) {
    ctx.strokeStyle = C.amber; ctx.fillStyle = C.amber; ctx.beginPath(); ctx.moveTo(X(mk.x), m.t); ctx.lineTo(X(mk.x), m.t + 8); ctx.stroke();
    ctx.save(); ctx.translate(X(mk.x) + 2, m.t + 10); ctx.rotate(Math.PI / 2.5); ctx.fillText(mk.label, 0, 0); ctx.restore();
  }
  const labelled = series.filter(s => s.label);
  const lw = Math.max(0, ...labelled.map(s => ctx.measureText(s.label).width)) + 22;
  if (labelled.length) { ctx.fillStyle = "rgba(31,35,40,0.85)"; ctx.fillRect(W - m.r - lw - 4, m.t, lw + 4, 14 * labelled.length + 6); }
  labelled.forEach((s, k) => { ctx.fillStyle = s.color || SERIES[k]; ctx.fillRect(W - m.r - lw, m.t + 6 + 14 * k, 12, 3); ctx.fillStyle = C.text; ctx.fillText(s.label, W - m.r - lw + 16, m.t + 10 + 14 * k); });
}

/** Draw a 2-D raster (rows = north/line, cols = east/sample) scaled to the canvas width. */
export function raster(canvas, rows, { lo, hi, alpha = null, categorical = null, flipY = false } = {}) {
  const ny = rows.length, nx = rows[0].length;
  const vals = rows.flat().filter(Number.isFinite);
  lo = lo ?? Math.min(...vals); hi = hi ?? Math.max(...vals);
  const off = document.createElement("canvas"); off.width = nx; off.height = ny;
  const octx = off.getContext("2d"); const img = octx.createImageData(nx, ny);
  for (let i = 0; i < ny; i++) for (let j = 0; j < nx; j++) {
    const v = rows[flipY ? ny - 1 - i : i][j], o = 4 * (i * nx + j);
    let c;
    if (categorical) c = v == null || v < 0 ? [10, 15, 21] : hex2rgb(CATEGORICAL[v % CATEGORICAL.length]);
    else c = ramp((v - lo) / (hi - lo || 1));
    const a = alpha ? Math.max(0.15, Math.min(1, alpha[flipY ? ny - 1 - i : i][j] ?? 0)) : 1;
    img.data[o] = c[0]; img.data[o + 1] = c[1]; img.data[o + 2] = c[2]; img.data[o + 3] = v == null || !Number.isFinite(v) && !categorical ? 255 : Math.round(255 * a);
  }
  octx.putImageData(img, 0, 0);
  const W = canvas.clientWidth || 600, scale = W / nx, dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(W * dpr); canvas.height = Math.round(ny * scale * dpr);
  canvas.style.height = `${ny * scale}px`;
  const ctx = canvas.getContext("2d"); ctx.imageSmoothingEnabled = false;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = "#0a0f15"; ctx.fillRect(0, 0, W, ny * scale);
  ctx.drawImage(off, 0, 0, nx * scale, ny * scale);
  return { scale, nx, ny, lo, hi, ctx };
}

export function bars(el, entries, { intervals = null, fmtv = v => v.toFixed(2) } = {}) {
  el.className = "bars";
  el.innerHTML = entries.map(([k, v]) => {
    const ci = intervals && intervals[k];
    const ciHtml = ci ? `<span class="ci" style="left:${100 * ci[0]}%;width:${Math.max(0.5, 100 * (ci[1] - ci[0]))}%"></span>` : "";
    return `<div class="bar"><span>${k.replaceAll("_", " ")}</span><span class="track"><span class="fill" style="width:${Math.max(0, Math.min(100, 100 * v))}%;display:block"></span>${ciHtml}</span><span class="mono">${fmtv(v)}</span></div>`;
  }).join("");
}

export function spark(canvas, values, color = C.blue, empty = "waiting for telemetry") {
  const [ctx, W, H] = fit(canvas);
  ctx.fillStyle = C.bg; ctx.fillRect(0, 0, W, H);
  if (values.length < 2) { ctx.fillStyle = C.axis; ctx.font = "11px ui-monospace, monospace"; ctx.fillText(empty, 6, H / 2 + 4); return; }
  const hi = Math.max(...values, 1), lo = 0;
  ctx.strokeStyle = color; ctx.lineWidth = 1.5; ctx.beginPath();
  values.forEach((v, i) => { const x = i / (values.length - 1) * W, y = H - 4 - (v - lo) / (hi - lo) * (H - 8); i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
  ctx.stroke(); ctx.fillStyle = C.axis; ctx.font = "10px ui-monospace, monospace"; ctx.fillText(`${values[values.length - 1].toFixed(0)} pkt/s`, 4, 12);
}
