// WebGL seabed viewer: lit heightfield coloured by a map layer, nodule points,
// survey track, orbit/zoom camera and CPU-side picking. No dependencies.
//
// World frame: x = east (m), y = up (elevation, exaggerated), z = -north (m),
// centred on the grid. The DEM is bilinearly interpolated onto a finer mesh
// purely for display; picking reports the underlying grid cell value.

const VS_SURF = `
attribute vec3 p; attribute vec3 n; attribute vec3 c;
uniform mat4 mvp; uniform vec3 L;
varying vec3 vc;
void main() {
  gl_Position = mvp * vec4(p, 1.0);
  float d = max(dot(normalize(n), L), 0.0);
  vc = c * (0.38 + 0.62 * d);
}`;
const FS_SURF = `
precision mediump float; varying vec3 vc;
void main() { gl_FragColor = vec4(vc, 1.0); }`;
const VS_PTS = `
attribute vec3 p; attribute vec3 c; attribute float s;
uniform mat4 mvp; uniform float scale;
varying vec3 vc;
void main() {
  gl_Position = mvp * vec4(p, 1.0);
  gl_PointSize = max(2.5, s * scale / gl_Position.w);
  vc = c;
}`;
const FS_PTS = `
precision mediump float; varying vec3 vc; uniform float round;
void main() {
  if (round > 0.5) { vec2 q = gl_PointCoord - 0.5; float r = dot(q, q); if (r > 0.25) discard;
    gl_FragColor = vec4(mix(vc, vec3(0.05), smoothstep(0.16, 0.25, r)), 1.0); }
  else gl_FragColor = vec4(vc, 1.0);
}`;

// ---------------------------------------------------------------- 4x4 math (column-major)
const M = {
  persp(fovy, asp, near, far) {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    return [f / asp, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0];
  },
  lookAt(e, t, u) {
    let z = [e[0] - t[0], e[1] - t[1], e[2] - t[2]]; z = norm(z);
    let x = norm(cross(u, z)); const y = cross(z, x);
    return [x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0,
      -dot(x, e), -dot(y, e), -dot(z, e), 1];
  },
  mul(a, b) {
    const o = new Array(16).fill(0);
    for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
      let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s;
    }
    return o;
  },
  inv(m) {
    const a = m, o = new Array(16);
    const b00 = a[0] * a[5] - a[1] * a[4], b01 = a[0] * a[6] - a[2] * a[4], b02 = a[0] * a[7] - a[3] * a[4],
      b03 = a[1] * a[6] - a[2] * a[5], b04 = a[1] * a[7] - a[3] * a[5], b05 = a[2] * a[7] - a[3] * a[6],
      b06 = a[8] * a[13] - a[9] * a[12], b07 = a[8] * a[14] - a[10] * a[12], b08 = a[8] * a[15] - a[11] * a[12],
      b09 = a[9] * a[14] - a[10] * a[13], b10 = a[9] * a[15] - a[11] * a[13], b11 = a[10] * a[15] - a[11] * a[14];
    let det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
    if (!det) return null; det = 1 / det;
    o[0] = (a[5] * b11 - a[6] * b10 + a[7] * b09) * det; o[1] = (a[2] * b10 - a[1] * b11 - a[3] * b09) * det;
    o[2] = (a[13] * b05 - a[14] * b04 + a[15] * b03) * det; o[3] = (a[10] * b04 - a[9] * b05 - a[11] * b03) * det;
    o[4] = (a[6] * b08 - a[4] * b11 - a[7] * b07) * det; o[5] = (a[0] * b11 - a[2] * b08 + a[3] * b07) * det;
    o[6] = (a[14] * b02 - a[12] * b05 - a[15] * b01) * det; o[7] = (a[8] * b05 - a[10] * b02 + a[11] * b01) * det;
    o[8] = (a[4] * b10 - a[5] * b08 + a[7] * b06) * det; o[9] = (a[1] * b08 - a[0] * b10 - a[3] * b06) * det;
    o[10] = (a[12] * b04 - a[13] * b02 + a[15] * b00) * det; o[11] = (a[9] * b02 - a[8] * b04 - a[11] * b00) * det;
    o[12] = (a[5] * b07 - a[4] * b09 - a[6] * b06) * det; o[13] = (a[0] * b09 - a[1] * b07 + a[2] * b06) * det;
    o[14] = (a[13] * b01 - a[12] * b03 - a[14] * b00) * det; o[15] = (a[8] * b03 - a[9] * b01 + a[10] * b00) * det;
    return o;
  },
  xform(m, v) {
    const x = v[0], y = v[1], z = v[2], w = v[3] ?? 1;
    return [0, 1, 2, 3].map(r => m[r] * x + m[4 + r] * y + m[8 + r] * z + m[12 + r] * w);
  },
};
function cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
function dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
function norm(a) { const l = Math.hypot(...a) || 1; return a.map(v => v / l); }

function compile(gl, vs, fs) {
  const mk = (t, src) => { const s = gl.createShader(t); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
  const p = gl.createProgram();
  gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  return p;
}

/** Fill nulls by nearest valid neighbour (geometry only; colour marks them as no-data). */
function fillNulls(rows) {
  const ny = rows.length, nx = rows[0].length, out = rows.map(r => r.slice());
  const valid = [];
  for (let i = 0; i < ny; i++) for (let j = 0; j < nx; j++) if (Number.isFinite(rows[i][j])) valid.push([i, j]);
  if (!valid.length) return out.map(r => r.map(() => 0));
  for (let i = 0; i < ny; i++) for (let j = 0; j < nx; j++) if (!Number.isFinite(out[i][j])) {
    let best = Infinity, v = 0;
    for (const [a, b] of valid) { const d = (a - i) ** 2 + (b - j) ** 2; if (d < best) { best = d; v = rows[a][b]; } }
    out[i][j] = v;
  }
  return out;
}
function bilinear(rows, fi, fj) {
  const ny = rows.length, nx = rows[0].length;
  fi = Math.min(Math.max(fi, 0), ny - 1); fj = Math.min(Math.max(fj, 0), nx - 1);
  const i0 = Math.min(Math.floor(fi), ny - 2 < 0 ? 0 : ny - 2), j0 = Math.min(Math.floor(fj), nx - 2 < 0 ? 0 : nx - 2);
  const i1 = Math.min(i0 + 1, ny - 1), j1 = Math.min(j0 + 1, nx - 1), u = fi - i0, v = fj - j0;
  return (1 - u) * ((1 - v) * rows[i0][j0] + v * rows[i0][j1]) + u * ((1 - v) * rows[i1][j0] + v * rows[i1][j1]);
}

export class Seabed3D {
  constructor(canvas, { onPick = null, onHover = null } = {}) {
    this.canvas = canvas; this.onPick = onPick; this.onHover = onHover;
    this.gl = canvas.getContext("webgl", { antialias: true, preserveDrawingBuffer: true });
    this.ok = !!this.gl;
    this.exag = 5; this.showNodules = true; this.showTrack = true;
    this.reset(false);
    if (!this.ok) return;
    const gl = this.gl;
    this.pSurf = compile(gl, VS_SURF, FS_SURF);
    this.pPts = compile(gl, VS_PTS, FS_PTS);
    this.buf = {};
    this._bindInput();
    new ResizeObserver(() => this.draw()).observe(canvas);
  }

  reset(redraw = true) { this.yaw = -0.55; this.pitch = 0.62; this.dist = null; if (redraw) this.draw(); }

  /**
   * data: {east[], north[], depth[[...]], color: (i,j) => [r,g,b] 0..255 per grid cell, categorical,
   *        nodules: [{e,n,d,rgb,id}], track: [[e,n],...], cellValue: (i,j) => string}
   */
  setData(data) {
    this.data = data;
    const { east, north } = data;
    this.cx = (east[0] + east[east.length - 1]) / 2; this.cy = (north[0] + north[north.length - 1]) / 2;
    this.span = Math.max(east[east.length - 1] - east[0], north[north.length - 1] - north[0]) + (east[1] - east[0] || 0.25);
    this.res = east.length > 1 ? east[1] - east[0] : 0.25;
    this.dem = fillNulls(data.depth.map(r => r.map(v => v == null ? NaN : -v)));   // elevation = -depth
    const flat = this.dem.flat();
    this.zref = flat.reduce((a, b) => a + b, 0) / flat.length;
    if (this.dist == null) this.dist = 1.7 * this.span;
    this._build();
    this.draw();
  }
  setExaggeration(x) { this.exag = x; this._build(); this.draw(); }
  setVisibility({ nodules, track }) {
    if (nodules != null) this.showNodules = nodules; if (track != null) this.showTrack = track; this.draw();
  }

  // grid index (fractional) for a world east/north
  _gi(n) { return (n - this.data.north[0]) / this.res; }
  _gj(e) { return (e - this.data.east[0]) / this.res; }
  elevAt(e, n) { return bilinear(this.dem, this._gi(n), this._gj(e)); }
  _world(e, n, lift = 0) { return [e - this.cx, (this.elevAt(e, n) - this.zref) * this.exag + lift, -(n - this.cy)]; }

  _build() {
    if (!this.ok || !this.data) return;
    const gl = this.gl, d = this.data, ny = d.north.length, nx = d.east.length;
    const up = Math.max(1, Math.min(8, Math.floor(96 / Math.max(nx, ny))));
    // mesh covers cell edges: from east[0]-res/2 to east[-1]+res/2
    const e0 = d.east[0] - this.res / 2, n0 = d.north[0] - this.res / 2;
    const NX = nx * up + 1, NY = ny * up + 1, step = this.res / up;
    const pos = new Float32Array(NX * NY * 3), col = new Float32Array(NX * NY * 3), nor = new Float32Array(NX * NY * 3);
    for (let a = 0; a < NY; a++) for (let b = 0; b < NX; b++) {
      const e = e0 + b * step, n = n0 + a * step, k = 3 * (a * NX + b);
      const w = this._world(e, n);
      pos[k] = w[0]; pos[k + 1] = w[1]; pos[k + 2] = w[2];
      const ci = Math.min(ny - 1, Math.max(0, Math.floor((n - n0) / this.res))), cj = Math.min(nx - 1, Math.max(0, Math.floor((e - e0) / this.res)));
      const c = d.color(ci, cj, this._gi(n), this._gj(e));
      col[k] = c[0] / 255; col[k + 1] = c[1] / 255; col[k + 2] = c[2] / 255;
    }
    for (let a = 0; a < NY; a++) for (let b = 0; b < NX; b++) {
      const at = (aa, bb) => 3 * (Math.min(NY - 1, Math.max(0, aa)) * NX + Math.min(NX - 1, Math.max(0, bb)));
      const kx1 = at(a, b + 1), kx0 = at(a, b - 1), kz1 = at(a + 1, b), kz0 = at(a - 1, b);
      const dx = [pos[kx1] - pos[kx0], pos[kx1 + 1] - pos[kx0 + 1], pos[kx1 + 2] - pos[kx0 + 2]];
      const dz = [pos[kz1] - pos[kz0], pos[kz1 + 1] - pos[kz0 + 1], pos[kz1 + 2] - pos[kz0 + 2]];
      const nn = norm(cross(dz, dx)), k = 3 * (a * NX + b);
      nor[k] = nn[0]; nor[k + 1] = nn[1]; nor[k + 2] = nn[2];
    }
    const idx = [];
    for (let a = 0; a < NY - 1; a++) for (let b = 0; b < NX - 1; b++) {
      const i = a * NX + b; idx.push(i, i + 1, i + NX, i + 1, i + NX + 1, i + NX);
    }
    // frame: base rectangle and vertical corner posts down to a datum below the surface
    const fmin = Math.min(...this.dem.flat()) - this.zref, base = fmin * this.exag - 0.05 * this.span;
    const ex = [e0 - this.cx, e0 + nx * this.res - this.cx], nz = [-(n0 - this.cy), -(n0 + ny * this.res - this.cy)];
    const frame = [];
    const corners = [[ex[0], nz[0]], [ex[1], nz[0]], [ex[1], nz[1]], [ex[0], nz[1]]];
    for (let k = 0; k < 4; k++) { const [x0, z0] = corners[k], [x1, z1] = corners[(k + 1) % 4]; frame.push(x0, base, z0, x1, base, z1); }
    for (const [x, z] of corners) {
      const e = x + this.cx, n = -z + this.cy; frame.push(x, base, z, x, (this.elevAt(e, n) - this.zref) * this.exag, z);
    }
    // nodules
    const np = [], nc = [], ns = [];
    this.nodWorld = [];
    for (const o of d.nodules || []) {
      const w = this._world(o.e, o.n, 0.004 * this.span);
      np.push(...w); nc.push(...o.rgb.map(v => v / 255)); ns.push(o.d);
      this.nodWorld.push({ w, o });
    }
    const tp = [];
    for (const [e, n] of d.track || []) tp.push(...this._world(e, n, 0.012 * this.span));
    const mk = (name, arr, target = gl.ARRAY_BUFFER) => {
      if (!this.buf[name]) this.buf[name] = gl.createBuffer();
      gl.bindBuffer(target, this.buf[name]); gl.bufferData(target, arr, gl.STATIC_DRAW);
    };
    mk("pos", pos); mk("col", col); mk("nor", nor);
    this.u32 = !!gl.getExtension("OES_element_index_uint") || NX * NY < 65536;
    mk("idx", this.u32 && NX * NY >= 65536 ? new Uint32Array(idx) : new Uint16Array(idx), gl.ELEMENT_ARRAY_BUFFER);
    this.nIdx = idx.length; this.idxType = NX * NY >= 65536 ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT;
    mk("np", new Float32Array(np)); mk("nc", new Float32Array(nc)); mk("ns", new Float32Array(ns)); this.nNod = ns.length;
    mk("tp", new Float32Array(tp)); this.nTrack = tp.length / 3;
    mk("fp", new Float32Array(frame)); this.nFrame = frame.length / 3;
    mk("white", new Float32Array(Math.max(this.nTrack, this.nFrame) * 3).fill(1));
    mk("ones", new Float32Array(Math.max(this.nTrack, this.nFrame)).fill(2));
  }

  _matrices() {
    const W = this.canvas.clientWidth || 800, H = this.canvas.clientHeight || 500;
    const eye = [this.dist * Math.cos(this.pitch) * Math.sin(this.yaw), this.dist * Math.sin(this.pitch), this.dist * Math.cos(this.pitch) * Math.cos(this.yaw)];
    const V = M.lookAt(eye, [0, 0, 0], [0, 1, 0]), P = M.persp(0.75, W / H, 0.01 * this.span, 20 * this.span);
    return { W, H, mvp: M.mul(P, V) };
  }

  draw() {
    if (!this.ok || !this.data) return;
    const gl = this.gl, dpr = window.devicePixelRatio || 1;
    const W = this.canvas.clientWidth || 800, H = this.canvas.clientHeight || 500;
    if (this.canvas.width !== Math.round(W * dpr) || this.canvas.height !== Math.round(H * dpr)) {
      this.canvas.width = Math.round(W * dpr); this.canvas.height = Math.round(H * dpr);
    }
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.clearColor(0.039, 0.059, 0.082, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);
    const { mvp } = this._matrices();
    this.mvp = mvp;
    const attr = (prog, name, buf, size) => {
      const loc = gl.getAttribLocation(prog, name); if (loc < 0) return;
      gl.bindBuffer(gl.ARRAY_BUFFER, this.buf[buf]); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
    };
    // surface
    gl.useProgram(this.pSurf);
    gl.uniformMatrix4fv(gl.getUniformLocation(this.pSurf, "mvp"), false, mvp);
    gl.uniform3fv(gl.getUniformLocation(this.pSurf, "L"), norm([0.4, 0.85, 0.35]));
    attr(this.pSurf, "p", "pos", 3); attr(this.pSurf, "n", "nor", 3); attr(this.pSurf, "c", "col", 3);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.buf.idx);
    gl.drawElements(gl.TRIANGLES, this.nIdx, this.idxType, 0);
    for (let k = 0; k < 4; k++) gl.disableVertexAttribArray(k);
    // points and lines share the point program
    gl.useProgram(this.pPts);
    gl.uniformMatrix4fv(gl.getUniformLocation(this.pPts, "mvp"), false, mvp);
    const scale = (this.canvas.height / 2) / Math.tan(0.375) * 1.0;
    gl.uniform1f(gl.getUniformLocation(this.pPts, "scale"), scale);
    if (this.showNodules && this.nNod) {
      gl.uniform1f(gl.getUniformLocation(this.pPts, "round"), 1);
      attr(this.pPts, "p", "np", 3); attr(this.pPts, "c", "nc", 3); attr(this.pPts, "s", "ns", 1);
      gl.drawArrays(gl.POINTS, 0, this.nNod);
    }
    gl.uniform1f(gl.getUniformLocation(this.pPts, "round"), 0);
    const line = (buf, n, mode, rgb) => {
      const cb = new Float32Array(n * 3); for (let i = 0; i < n; i++) cb.set(rgb, 3 * i);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.buf.white); gl.bufferData(gl.ARRAY_BUFFER, cb, gl.DYNAMIC_DRAW);
      attr(this.pPts, "p", buf, 3); attr(this.pPts, "c", "white", 3); attr(this.pPts, "s", "ones", 1);
      gl.drawArrays(mode, 0, n);
    };
    if (this.nFrame) line("fp", this.nFrame, gl.LINES, [0.35, 0.40, 0.46]);
    if (this.showTrack && this.nTrack > 1) line("tp", this.nTrack, gl.LINE_STRIP, [0.84, 0.64, 0.25]);
    for (let k = 0; k < 4; k++) gl.disableVertexAttribArray(k);
  }

  // ------------------------------------------------------------ picking
  _project(w) {
    const { W, H } = this._matrices(); const c = M.xform(this.mvp, [...w, 1]);
    if (c[3] <= 0) return null;
    return [(c[0] / c[3] * 0.5 + 0.5) * W, (1 - (c[1] / c[3] * 0.5 + 0.5)) * H, c[3]];
  }
  pickNodule(px, py, radius = 9) {
    if (!this.showNodules || !this.nodWorld) return null;
    let best = null, bd = radius * radius;
    for (const nw of this.nodWorld) {
      const s = this._project(nw.w); if (!s) continue;
      const d = (s[0] - px) ** 2 + (s[1] - py) ** 2; if (d < bd) { bd = d; best = nw.o; }
    }
    return best;
  }
  /** Ray-march the heightfield under the cursor; returns {e, n, i, j} or null. */
  pickSurface(px, py) {
    const { W, H, mvp } = this._matrices(); const inv = M.inv(mvp); if (!inv) return null;
    const ndc = [2 * px / W - 1, 1 - 2 * py / H];
    const unp = z => { const v = M.xform(inv, [ndc[0], ndc[1], z, 1]); return [v[0] / v[3], v[1] / v[3], v[2] / v[3]]; };
    const a = unp(-1), b = unp(1), dir = norm([b[0] - a[0], b[1] - a[1], b[2] - a[2]]);
    const stepL = this.span / 400, d = this.data;
    let prevAbove = true;
    for (let t = 0; t < 6 * this.span + this.dist; t += stepL) {
      const p = [a[0] + dir[0] * t, a[1] + dir[1] * t, a[2] + dir[2] * t];
      const e = p[0] + this.cx, n = -p[2] + this.cy;
      const inside = e >= d.east[0] - this.res / 2 && e <= d.east[d.east.length - 1] + this.res / 2 &&
        n >= d.north[0] - this.res / 2 && n <= d.north[d.north.length - 1] + this.res / 2;
      if (!inside) { prevAbove = true; continue; }
      const h = (this.elevAt(e, n) - this.zref) * this.exag;
      if (p[1] <= h && prevAbove) {
        const i = Math.min(d.north.length - 1, Math.max(0, Math.round(this._gi(n)))), j = Math.min(d.east.length - 1, Math.max(0, Math.round(this._gj(e))));
        return { e, n, i, j };
      }
      prevAbove = p[1] > h;
    }
    return null;
  }

  _bindInput() {
    const c = this.canvas; let drag = null, moved = false;
    c.addEventListener("pointerdown", ev => { drag = [ev.clientX, ev.clientY, this.yaw, this.pitch]; moved = false; c.setPointerCapture(ev.pointerId); c.style.cursor = "grabbing"; });
    c.addEventListener("pointermove", ev => {
      const r = c.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top;
      if (drag) {
        const dx = ev.clientX - drag[0], dy = ev.clientY - drag[1];
        if (Math.abs(dx) + Math.abs(dy) > 3) moved = true;
        this.yaw = drag[2] - dx * 0.008; this.pitch = Math.min(1.5, Math.max(0.08, drag[3] + dy * 0.006));
        this.draw(); return;
      }
      if (this.onHover && !this._hoverPending) {
        this._hoverPending = true;
        requestAnimationFrame(() => {
          this._hoverPending = false;
          const nod = this.pickNodule(x, y);
          this.onHover(nod ? { kind: "nodule", nodule: nod, x, y } : (() => { const s = this.pickSurface(x, y); return s ? { kind: "cell", ...s, x, y } : null; })());
        });
      }
    });
    const end = ev => {
      if (!drag) return; c.style.cursor = "grab";
      if (!moved && this.onPick) { const r = c.getBoundingClientRect(); const nod = this.pickNodule(ev.clientX - r.left, ev.clientY - r.top); if (nod) this.onPick(nod); }
      drag = null;
    };
    c.addEventListener("pointerup", end); c.addEventListener("pointercancel", () => { drag = null; });
    c.addEventListener("pointerleave", () => this.onHover && this.onHover(null));
    c.addEventListener("wheel", ev => { ev.preventDefault(); this.dist = Math.min(8 * this.span, Math.max(0.25 * this.span, this.dist * Math.exp(ev.deltaY * 0.0012))); this.draw(); }, { passive: false });
  }
}
