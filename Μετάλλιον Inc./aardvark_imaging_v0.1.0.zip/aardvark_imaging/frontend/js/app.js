// Aardvark Imaging workstation — application controller.
//
// Data source, in order of preference:
//   1. the live instrument API (/api/v1, same origin) with WebSocket telemetry;
//   2. an offline snapshot (assets/snapshot.json, or assets/snapshot.js when
//      opened from file://) of a SIMULATED survey, for demonstration.
// Every value shown carries its data origin; nothing here invents numbers.

import { C, CATEGORICAL, ramp, rampCss, hex2rgb, linePlot, raster, bars, spark } from "./plot.js";
import { Seabed3D } from "./seabed3d.js";

const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const nice = s => String(s ?? "").replaceAll("_", " ");
const fx = (v, d = 2) => v == null || !Number.isFinite(+v) ? "—" : (+v).toFixed(d);
const pct = (v, d = 1) => v == null || !Number.isFinite(+v) ? "—" : `${(100 * v).toFixed(d)} %`;
const params = new URLSearchParams(location.search);
const API_KEY = params.get("api_key");

const S = {
  mode: "connecting", snap: null, status: null, sensors: [], cube: null, cubeQ: null, carbon: null, carbonDetail: {},
  nodules: [], nodDetail: {}, geo: null, raman: null, validation: null, pins: [], pixel: null, selTarget: null,
  selNodule: null, rates: [], lastPackets: null, lastT: null, ws: null, view3d: null, loaded: {},
};

// ------------------------------------------------------------------ data layer
function withTimeout(ms) { const c = new AbortController(); setTimeout(() => c.abort(), ms); return c.signal; }
async function api(path, opts = {}) {
  const headers = { ...(opts.headers || {}) };
  if (API_KEY) headers["X-API-Key"] = API_KEY;
  if (opts.body && typeof opts.body !== "string") { headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(opts.body); }
  const r = await fetch(`/api/v1${path}`, { ...opts, headers, signal: opts.signal || withTimeout(20000) });
  if (!r.ok) throw new Error(`${r.status} ${(await r.text()).slice(0, 200)}`);
  return opts.raw ? r : r.json();
}
function loadScript(src) {
  return new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = () => rej(new Error(`cannot load ${src}`)); document.head.appendChild(s); });
}
async function detectSource() {
  if (location.protocol.startsWith("http") && !params.has("snapshot")) {
    try { S.status = await api("/system/status", { signal: withTimeout(2500) }); S.mode = "live"; return; } catch { /* fall through */ }
  }
  if (!window.AARDVARK_SNAPSHOT) {
    try {
      if (!location.protocol.startsWith("http")) throw new Error("file://");
      const r = await fetch("assets/snapshot.json"); if (!r.ok) throw new Error(r.status); S.snap = await r.json();
    } catch { await loadScript("assets/snapshot.js"); }
  }
  S.snap = S.snap || window.AARDVARK_SNAPSHOT;
  if (!S.snap) throw new Error("no live API and no offline snapshot");
  S.mode = "snapshot"; S.status = S.snap.status;
}
// one accessor so every view works in both modes
async function get(key, live) { return S.mode === "live" ? api(live) : S.snap[key]; }

function decodeCubeQ(q) {
  const bin = atob(q.b64), u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return { ...q, u8 };
}
const cubeVal = (q, l, s, b) => { const v = q.u8[(l * q.shape[1] + s) * q.shape[2] + b]; return v === q.nan_code ? NaN : q.lo[b] + v / 254 * (q.hi[b] - q.lo[b]); };

// one colour per mineral/assessment class, shared by every nodule view
const CLASS_COLORS = { manganese_rich: "#7ea3cc", iron_oxyhydroxide: "#c98a6b", sediment: "#b7c0c9", carbonate: "#e3e7ea",
  silicate: "#9a8fc0", phosphate: "#4f9fa6", biological: "#6f9e7a", unclassified: "#6b7682" };
const classColor = c => CLASS_COLORS[c] || "#d6a440";

// ------------------------------------------------------------------ chrome
function setBadge(el, text, cls) { el.textContent = text; el.className = `badge ${cls || ""}`; }
function notice(msg) { const n = $("notice"); if (!msg) { n.hidden = true; return; } n.hidden = false; n.innerHTML = msg; }
function healthClass(h) { return h === "ok" ? "ok" : h === "fault" ? "fault" : "warn"; }

function initTabs() {
  document.querySelectorAll(".tabs button").forEach(b => b.addEventListener("click", () => showView(b.dataset.view)));
  addEventListener("hashchange", () => showView(location.hash.slice(1) || "dashboard", false));
}
function showView(v, push = true) {
  if (!document.getElementById(`view-${v}`)) v = "dashboard";
  document.querySelectorAll(".tabs button").forEach(b => { const on = b.dataset.view === v; b.classList.toggle("active", on); b.setAttribute("aria-selected", on); });
  document.querySelectorAll(".view").forEach(s => s.classList.toggle("active", s.id === `view-${v}`));
  if (push && location.hash.slice(1) !== v) history.replaceState(null, "", `#${v}`);
  const loader = { spectral: loadSpectral, carbon: loadCarbon, mineral: loadMineral, geology: loadGeology }[v];
  if (loader) loader().catch(err => notice(`Could not load ${v}: ${esc(err.message)}`));
  else requestAnimationFrame(drawSpark);
}

// ------------------------------------------------------------------ dashboard
async function loadDashboard() {
  const [sensors, health, acq, validation, geo, carbon] = await Promise.all([
    get("sensors", "/sensors"), get("health", "/sensors/health"), get("acquisition", "/acquisition/status"),
    get("validation", "/validation"), get("geology", "/geology/map"), get("carbon", "/carbon/map")]);
  S.sensors = sensors; S.validation = validation; S.geo = geo; S.carbon = carbon;
  const st = S.status;
  $("instrument-id").textContent = st.instrument;
  setBadge($("origin-badge"), (st.data_origin || "simulated").toUpperCase(), st.data_origin === "measured" ? "ok" : "warn");
  setBadge($("source-badge"), S.mode === "live" ? "LIVE API" : "OFFLINE SNAPSHOT", S.mode === "live" ? "ok" : "warn");
  setBadge($("health-badge"), `HEALTH ${String(health.status).toUpperCase()}`, healthClass(health.status));
  const notes = [...(st.notices || [])];
  if (S.mode === "snapshot") notes.unshift("OFFLINE SNAPSHOT — the instrument API is not reachable; showing a recorded simulated survey. Acquisition controls are disabled.");
  notice(notes.map(esc).join(" · "));
  $("foot-left").textContent = `Survey ${st.survey_id} · API ${st.api_version} · mode ${st.mode} · ${S.mode === "live" ? "connected" : "snapshot"}`;

  const gs = geo.statistics || {};
  const readouts = [
    ["Survey", st.survey_id, ""], ["Mean depth", fx(st.depth_m, 1), "m"],
    ["Position", `${fx(st.position?.lat, 4)}, ${fx(st.position?.lon, 4)}`, ""],
    ["Nodules", st.nodule_count, ""], ["Abundance", fx(gs.mean_abundance_kg_m2, 1), "kg/m² est."],
    ["Imaged area", fx(gs.imaged_area_m2, 1), "m²"], ["Carbon targets", st.carbon_targets, ""],
    ["Packets", acq.packets ?? 0, ""]];
  $("readouts").innerHTML = readouts.map(([k, v, u], i) => `<div class="readout"><div class="k">${k}</div><div class="v"${i === 7 ? ' id="ro-packets"' : ""}>${esc(v)}<span class="u">${u}</span></div></div>`).join("");

  const cal = st.calibration || {};
  $("sensor-table").tBodies[0].innerHTML = sensors.map(s => {
    const kinds = cal[s.key] || {}, vals = Object.values(kinds);
    const missing = vals.filter(v => v === "missing" || v === "expired").length;
    const supported = vals.filter(v => v !== "unsupported_kind").length;
    const calTxt = !vals.length ? '<span class="dim">n/a</span>'
      : missing ? `<span class="na">${missing} missing</span> / ${vals.length}`
      : supported ? `<span class="dim">${supported} simulated</span>` : '<span class="dim">no registry model</span>';
    const tags = [s.assumed_specification ? '<span class="tag warn" title="engineering assumption in the Silica Flux manifest, not a datasheet value">assumed</span>' : "",
      s.in_reference_rtl === false ? '<span class="tag" title="declared in the manifest but not instantiated in the reference RTL">not in RTL</span>' : ""].join(" ");
    return `<tr><td class="mono">${esc(s.key)}</td><td>${esc(s.name)}</td><td class="dim">${esc(s.interface)}</td><td class="num">${fx(s.sampling_hz, s.sampling_hz < 10 ? 1 : 0)}</td><td class="num">${s.channel_count}</td><td title="${esc(Object.entries(kinds).map(([k, v]) => `${k}: ${v}`).join("\n"))}">${calTxt}</td><td>${tags}</td></tr>`;
  }).join("");

  renderAcq(acq);
  $("health-list").innerHTML = health.items.map(i => `<li><span class="lvl ${i.level}">${esc(i.level.toUpperCase())}</span><span>${esc(nice(i.name))}</span><span class="dim" style="margin-left:auto;text-align:right">${esc(i.detail)}</span></li>`).join("");

  const v = validation.validation, nd = v.nodule_detection || {};
  $("nodule-summary").innerHTML = kv([
    ["Detected", `${nd.detected ?? st.nodule_count}`], ["Mean density", `${fx(gs.mean_density_per_m2, 1)} /m²`],
    ["Mean abundance", `${fx(gs.mean_abundance_kg_m2, 1)} kg/m²`], ["Depth range", gs.depth_range_m ? `${fx(gs.depth_range_m[0], 2)} – ${fx(gs.depth_range_m[1], 2)} m` : "—"],
    ["Precision (sim.)", pct(nd.precision)], ["Recall (sim.)", pct(nd.recall)]]) +
    '<p class="hint">Abundance = Σ estimated mass / imaged area (ESTIMATED from simulated imagery). Precision and recall are against simulated ground truth.</p>';

  const counts = {};
  for (const p of carbon.points) counts[p.top_class] = (counts[p.top_class] || 0) + 1;
  const n = carbon.points.length || 1;
  const el = $("carbon-summary");
  bars(el, Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([k, c]) => [k, c / n]), { fmtv: x => `${Math.round(x * n)}` });
  const lv = [...new Set(carbon.points.map(p => p.quantitation_level))].join(", ");
  el.insertAdjacentHTML("beforeend", `<p class="hint">Top class per point target (${n} targets). Quantitation level: <span class="na">${esc(lv)}</span> — no laboratory-validated TOC/TIC model is attached, so no concentrations are reported.</p>`);

  renderValidation(v);
}
function drawSpark() { spark($("acq-spark"), S.rates, C.blue, S.mode === "live" ? "waiting for telemetry" : "no telemetry in offline snapshot mode"); }
const kv = rows => rows.map(([k, v]) => `<div class="k">${esc(k)}</div><div class="v">${v}</div>`).join("");

function renderAcq(a) {
  a = S.acq = { ...(S.acq || {}), ...a };
  $("acq-panel").innerHTML = kv([["State", a.acquiring ? '<span style="color:var(--green)">ACQUIRING</span>' : "idle"],
    ["Packets", a.packets], ["Recorded", `${fx((a.bytes_recorded || 0) / 1e6, 2)} MB`], ["Spool segments", a.spool_segments],
    ["Sequence gaps", a.sequence_gaps ? `<span class="na">${a.sequence_gaps}</span>` : "0"],
    ["Corrupt packets", a.corrupt_packets ? `<span style="color:var(--red)">${a.corrupt_packets}</span>` : "0"],
    ["Started", a.started_utc ? a.started_utc.replace("T", " ").slice(0, 19) + " UTC" : "—"]]);
  const live = S.mode === "live";
  $("acq-start").disabled = !live || a.acquiring; $("acq-stop").disabled = !live || !a.acquiring;
  $("acq-start").title = live ? "" : "unavailable in offline snapshot mode";
  const ro = $("ro-packets"); if (ro) ro.innerHTML = `${a.packets ?? 0}<span class="u"></span>`;
}

function renderValidation(v) {
  const box = (t, rows, foot = "") => `<div class="vbox"><div class="t">${t}</div><div class="kv">${kv(rows)}</div>${foot ? `<p class="hint">${foot}</p>` : ""}</div>`;
  const nd = v.nodule_detection || {}, d = v.diameter_m || {}, m = v.mass_g || {}, cc = v.carbon_classification || {};
  const g = v.grade_model_Ni || {}, b = v.bathymetry || {}, e = v.emi_compensation || {}, h = v.hsi_pixels || {}, ece = v.carbon_confidence_calibration || {};
  const out = [
    box("Nodule detection", [["True / detected", `${nd.true} / ${nd.detected}`], ["Matched", nd.matched], ["Precision", pct(nd.precision)], ["Recall", pct(nd.recall)]]),
    box("Size (equivalent ⌀)", [["MAE", `${fx(1000 * d.mae, 1)} mm`], ["RMSE", `${fx(1000 * d.rmse, 1)} mm`], ["Bias", `${fx(1000 * d.bias, 1)} mm`], ["n", d.n]],
      d.rmse > 2 * d.mae ? "RMSE well above MAE: a few merged or split detections dominate the error." : ""),
    box("Mass", [["MAE", `${fx(m.mae, 0)} g`], ["RMSE", `${fx(m.rmse, 0)} g`], ["95 % interval coverage", `<span class="${v.mass_interval_coverage_95 < 0.9 ? "na" : ""}">${pct(v.mass_interval_coverage_95, 0)}</span>`]],
      "Volume from a height-ratio prior; coverage below nominal means intervals are too narrow."),
    box("Carbon classification", [["Accuracy", pct(cc.accuracy, 0)], ["Macro F1", fx(cc.macro_f1)], ["ECE", fx(ece.ece, 3)], ["Classes exercised", (cc.labels || []).length]],
      "Self-consistency against simulated archetypes only; not a field accuracy."),
    box("Grade model (Ni)", [["Validated", g.validated ? "yes" : '<span class="na">no — refused</span>'], ["CV R²", fx(g.r2_cv)], ["RMSECV", `${fx(g.rmsecv_wt_pct, 2)} wt %`], ["Assay-linked", g.n_assay_linked]],
      esc((g.reasons || []).join("; "))),
    box("Abundance", [["Estimated", `${fx(v.abundance_kg_m2?.estimated, 1)} kg/m²`], ["Simulated truth", `${fx(v.abundance_kg_m2?.true, 1)} kg/m²`]], "Wet mass per imaged area; missed and merged nodules both bias it."),
    box("Bathymetry", [["RMSE vs truth", `${fx(100 * b.rmse_m, 1)} cm`], ["Cells", b.cells]]),
    box("EMI platform compensation", [["Residual before", fx(e.before, 6)], ["Residual after", fx(e.after, 6)]], "Fitted on a separate calibration manoeuvre."),
    box("HSI pixel classes", [["Nodule px → Mn-oxide", pct(h.nodule_pixels_classified_mn_oxide)], ["Sediment px → Mn-oxide", pct(h.sediment_pixels_classified_mn_oxide)], ["Usable bands", `${h.usable_bands} / ${h.total_bands}`]]),
  ];
  $("validation").innerHTML = out.join("");
}

async function acquisition(cmd) {
  try {
    const a = cmd === "start" ? await api("/acquisition/start", { method: "POST", body: { sensors: ["HSI0", "HK0", "DIAG", "MBES0", "RAM0"], line_rate_hz: 20 } })
      : await api("/acquisition/stop", { method: "POST" });
    renderAcq(a);
  } catch (err) { notice(`Acquisition ${cmd} failed: ${esc(err.message)}`); }
}

function connectTelemetry() {
  if (S.mode !== "live") return;
  const url = `${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/api/v1/stream/telemetry${API_KEY ? `?api_key=${encodeURIComponent(API_KEY)}` : ""}`;
  let ws;
  try { ws = new WebSocket(url); } catch { return; }
  S.ws = ws;
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    const now = performance.now();
    if (m.packets != null) {
      if (S.lastPackets != null && now > S.lastT) {
        S.rates.push(Math.max(0, (m.packets - S.lastPackets) / ((now - S.lastT) / 1000)));
        if (S.rates.length > 120) S.rates.shift();
        if ($("view-dashboard").classList.contains("active")) drawSpark();
      }
      S.lastPackets = m.packets; S.lastT = now;
    }
    if (m.type === "hello" || m.type === "keepalive") renderAcq(m.status || m);
    else if (m.type === "telemetry") {
      if (S._acqTick === undefined || now - S._acqTick > 500) {
        S._acqTick = now;
        renderAcq({ acquiring: m.acquiring, packets: m.packets, bytes_recorded: m.bytes_recorded });
      }
      if (S._statTick === undefined || now - S._statTick > 3000) { S._statTick = now; api("/acquisition/status").then(renderAcq).catch(() => {}); }
    }
  };
  ws.onclose = () => { S.ws = null; setTimeout(connectTelemetry, 3000); };
}

// ------------------------------------------------------------------ spectral
async function loadSpectral() {
  if (!S.loaded.spectral) {
    S.cube = await get("cube", "/spectral/cube");
    if (S.mode === "snapshot" && S.snap.cube_q) S.cubeQ = decodeCubeQ(S.snap.cube_q);
    const c = S.cube, sl = $("wl-slider");
    sl.max = c.wavelength_nm.length - 1; sl.value = c.band;
    $("cube-meta").textContent = `· ${c.shape[0]} lines × ${c.shape[1]} samples × ${c.shape[2]} bands · ${c.units} · ${c.data_origin.toUpperCase()}`;
    $("cube-history").innerHTML = [...c.history.map(esc), `origin: ${esc(c.provenance?.origin)} · source: ${esc(c.provenance?.source)}`,
      ...(c.provenance?.notes || []).map(n => `<span class="dim">${esc(n)}</span>`)].map(x => `<li>${x}</li>`).join("");
    $("class-legend").innerHTML = c.label_names.map((n, i) => `<span><i style="background:${CATEGORICAL[i % CATEGORICAL.length]}"></i>${esc(n)}</span>`).join("") + '<span><i style="background:#0a0f15;border:1px solid #2c333b"></i>unclassified</span>';
    sl.addEventListener("input", () => { clearTimeout(S._bandT); S._bandT = setTimeout(() => drawBand(+sl.value), S.mode === "live" ? 120 : 0); });
    $("overlay-class").addEventListener("change", () => drawBand(+sl.value));
    $("cube-canvas").addEventListener("click", onCubeClick);
    $("pin-spec").addEventListener("click", () => { if (S.pixel) { S.pins.push(S.pixel); if (S.pins.length > 5) S.pins.shift(); drawSpectrum(); } });
    $("clear-pins").addEventListener("click", () => { S.pins = []; drawSpectrum(); });
    addEventListener("resize", () => { if ($("view-spectral").classList.contains("active")) { drawBand(+sl.value, true); drawSpectrum(); } });
    S.loaded.spectral = true;
    await drawBand(c.band);
    const sh = c.shape; await selectPixel(Math.floor(sh[0] / 2), Math.floor(sh[1] / 2));
  } else { await drawBand(+$("wl-slider").value, true); drawSpectrum(); }
}

async function bandImage(b) {
  if (S.mode === "live") {
    if (b !== S.cube.band) { const c = await api(`/spectral/cube?band=${b}`); S.cube.image = c.image; S.cube.band = b; }
    return S.cube.image;
  }
  if (!S.cubeQ) return S.cube.image;
  const q = S.cubeQ, rows = [];
  for (let l = 0; l < q.shape[0]; l++) { const r = new Array(q.shape[1]); for (let s = 0; s < q.shape[1]; s++) r[s] = cubeVal(q, l, s, b); rows.push(r); }
  return rows;
}

async function drawBand(b, keep = false) {
  const c = S.cube, wl = c.wavelength_nm[b], usable = c.usable_bands[b];
  $("wl-label").innerHTML = `${fx(wl, 0)} nm${usable ? "" : ' <span class="na">unusable at this standoff</span>'}`;
  const img = keep && S._bandImg && S._band === b ? S._bandImg : await bandImage(b);
  S._bandImg = img; S._band = b;
  const vals = img.flat().filter(Number.isFinite).sort((x, y) => x - y);
  const lo = vals[Math.floor(0.01 * vals.length)] ?? 0, hi = vals[Math.floor(0.99 * vals.length)] ?? 1;
  const cv = $("cube-canvas");
  const r = raster(cv, img, { lo, hi });
  S._cubeScale = r.scale;
  const ctx = r.ctx;
  if ($("overlay-class").checked) {
    const ny = c.label_map.length, nx = c.label_map[0].length, o = document.createElement("canvas"); o.width = nx; o.height = ny;
    const octx = o.getContext("2d"), id = octx.createImageData(nx, ny);
    for (let i = 0; i < ny; i++) for (let j = 0; j < nx; j++) {
      const v = c.label_map[i][j], k = 4 * (i * nx + j);
      if (v == null || v < 0) { id.data[k] = 10; id.data[k + 1] = 15; id.data[k + 2] = 21; id.data[k + 3] = 200; continue; }
      const [R, G, B] = hex2rgb(CATEGORICAL[v % CATEGORICAL.length]); id.data[k] = R; id.data[k + 1] = G; id.data[k + 2] = B; id.data[k + 3] = 150;
    }
    octx.putImageData(id, 0, 0); ctx.imageSmoothingEnabled = false; ctx.drawImage(o, 0, 0, nx * r.scale, ny * r.scale);
  }
  if (S.pixel) {
    ctx.strokeStyle = C.amber; ctx.lineWidth = 1.5;
    ctx.strokeRect(S.pixel.sample * r.scale - 2, S.pixel.line * r.scale - 2, r.scale + 4, r.scale + 4);
  }
}

function onCubeClick(ev) {
  const rect = ev.target.getBoundingClientRect(), sc = S._cubeScale || 1;
  const s = Math.floor((ev.clientX - rect.left) / sc), l = Math.floor((ev.clientY - rect.top) / sc);
  const sh = S.cube.shape;
  if (l >= 0 && s >= 0 && l < sh[0] && s < sh[1]) selectPixel(l, s);
}

async function selectPixel(line, sample) {
  const c = S.cube;
  let px;
  if (S.mode === "live") {
    const r = await api(`/spectral/scan?line=${line}&sample=${sample}`);
    px = { line, sample, wl: r.wavelength_nm, y: r.spectrum, usable: r.usable_bands, cls: r.classification, labelAt: r.label_at_pixel, note: "full precision (live API)" };
  } else {
    const key = `${line},${sample}`, sc = S.snap.scans?.[key];
    const y = S.cubeQ ? c.wavelength_nm.map((_, b) => cubeVal(S.cubeQ, line, sample, b)) : sc?.spectrum;
    const lab = c.label_map[line][sample];
    px = { line, sample, wl: c.wavelength_nm, y: y || [], usable: c.usable_bands, cls: sc?.classification || null,
      labelAt: lab >= 0 ? c.label_names[lab] : "unclassified", note: S.cubeQ ? "8-bit display quantisation (offline snapshot)" : "" };
  }
  S.pixel = px;
  $("pix-label").textContent = `· line ${line}, sample ${sample}`;
  drawSpectrum();
  const pc = $("pix-class");
  if (px.cls) {
    const ent = Object.entries(px.cls.probabilities).sort((a, b) => b[1] - a[1]).slice(0, 5);
    bars(pc, ent);
    pc.insertAdjacentHTML("beforeend", `<p class="hint">SAM against the parametric VNIR library (SIMULATED library), usable bands only. Best angle ${fx(px.cls.best_angle_rad, 3)} rad, margin ${fx(px.cls.margin_rad, 3)} rad. Survey label map: ${esc(px.labelAt)}.</p>`);
  } else {
    pc.innerHTML = `<div class="kv">${kv([["Survey label map", esc(px.labelAt)]])}</div><p class="hint">Per-pixel class probabilities need the live API; the offline snapshot carries the survey's SAM label map.</p>`;
  }
  drawBand(+$("wl-slider").value, true);
}

function unusableRanges(wl, usable) {
  const out = []; let start = null;
  wl.forEach((w, i) => { if (!usable[i] && start == null) start = i; if ((usable[i] || i === wl.length - 1) && start != null) { out.push([wl[start] - 2.5, wl[usable[i] ? i - 1 : i] + 2.5]); start = null; } });
  return out;
}
// Reflectance in bands where two-way water transmission < 5 % is noise
// amplified by the transmission correction: it is masked, not plotted.
const masked = p => p.y.map((v, i) => p.usable[i] ? v : NaN);
function drawSpectrum() {
  const px = S.pixel; if (!px) return;
  const series = S.pins.map((p, k) => ({ x: p.wl, y: masked(p), color: ["#b7c0c9", "#6f9e7a", "#c98a6b", "#9a8fc0", "#8b97a4"][k % 5], width: 1, dash: [4, 3], label: `pin L${p.line} S${p.sample}` }));
  series.push({ x: px.wl, y: masked(px), color: C.blue, width: 1.8, label: `L${px.line} S${px.sample}` });
  const ys = series.flatMap(s => s.y).filter(Number.isFinite);
  const opts = { xlabel: "wavelength (nm)", ylabel: "reflectance factor", shade: unusableRanges(px.wl, px.usable), xlim: [px.wl[0], px.wl[px.wl.length - 1]] };
  if (ys.length) opts.ylim = [Math.min(0, ...ys), Math.max(...ys) * 1.05];
  linePlot($("spec-plot"), series, opts);
}

// ------------------------------------------------------------------ carbon
function barsCanvas(canvas, entries, intervals) {
  const dpr = devicePixelRatio || 1, W = canvas.clientWidth || 500, H = canvas.clientHeight || 170;
  canvas.width = W * dpr; canvas.height = H * dpr;
  const ctx = canvas.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = C.bg; ctx.fillRect(0, 0, W, H); ctx.font = "11px ui-monospace, Menlo, monospace";
  const lw = 170, rw = 46, rowH = Math.min(22, (H - 8) / entries.length);
  entries.forEach(([k, v], i) => {
    const y = 4 + i * rowH, bw = W - lw - rw;
    ctx.fillStyle = C.text; ctx.fillText(nice(k), 4, y + rowH * 0.65);
    ctx.fillStyle = "#0a0f15"; ctx.fillRect(lw, y + 3, bw, rowH - 6);
    ctx.fillStyle = i === 0 ? C.blue : "#3f5f86"; ctx.fillRect(lw, y + 3, bw * v, rowH - 6);
    const ci = intervals?.[k];
    if (ci) { ctx.strokeStyle = C.white; ctx.beginPath(); ctx.moveTo(lw + bw * ci[0], y + rowH / 2); ctx.lineTo(lw + bw * ci[1], y + rowH / 2);
      ctx.moveTo(lw + bw * ci[0], y + 4); ctx.lineTo(lw + bw * ci[0], y + rowH - 4); ctx.moveTo(lw + bw * ci[1], y + 4); ctx.lineTo(lw + bw * ci[1], y + rowH - 4); ctx.stroke(); }
    ctx.fillStyle = C.text; ctx.fillText(v.toFixed(2), W - rw + 4, y + rowH * 0.65);
  });
}

async function loadCarbon() {
  if (!S.carbon) S.carbon = await get("carbon", "/carbon/map");
  if (!S.raman) S.raman = (await get("raman", "/spectral/raman/examples")).examples;
  if (!S.loaded.carbon) {
    const sel = $("carbon-layer");
    sel.innerHTML = Object.keys(S.carbon.layers).filter(k => !k.endsWith("_confidence"))
      .map(k => `<option value="${k}">${esc(nice(k.replace(/^carbon_/, "")))}</option>`).join("");
    sel.addEventListener("change", drawCarbonMap); $("carbon-conf").addEventListener("change", drawCarbonMap);
    $("carbon-canvas").addEventListener("click", onCarbonClick);
    addEventListener("resize", () => $("view-carbon").classList.contains("active") && (drawCarbonMap(), S.selTarget && selectTarget(S.selTarget)));
    S.loaded.carbon = true;
    drawCarbonMap();
    const first = [...S.carbon.points].sort((a, b) => b.top_probability - a.top_probability)[0];
    if (first) await selectTarget(first.target_id);
  } else { drawCarbonMap(); if (S.selTarget) selectTarget(S.selTarget); }
}

function carbonGeom() {
  const cm = S.carbon, res = cm.east.length > 1 ? cm.east[1] - cm.east[0] : 0.25;
  return { e0: cm.east[0] - res / 2, n0: cm.north[0] - res / 2, res };
}
function drawCarbonMap() {
  const cm = S.carbon, key = $("carbon-layer").value, rows = cm.layers[key];
  const conf = $("carbon-conf").checked ? cm.layers[`${key}_confidence`] : null;
  const r = raster($("carbon-canvas"), rows, { lo: 0, hi: 1, alpha: conf, flipY: true });
  S._carbonR = r;
  const ctx = r.ctx, { e0, n0, res } = carbonGeom(), sc = r.scale / res, H = r.ny * r.scale;
  for (const p of cm.points) {
    const x = (p.east_m - e0) * sc, y = H - (p.north_m - n0) * sc, on = p.target_id === S.selTarget;
    ctx.beginPath(); ctx.arc(x, y, on ? 7 : 5, 0, 2 * Math.PI);
    ctx.fillStyle = CATEGORICAL[Object.keys(p.class_probabilities).indexOf(p.top_class) % CATEGORICAL.length]; ctx.fill();
    ctx.lineWidth = on ? 2 : 1; ctx.strokeStyle = on ? C.amber : "#0a0f15"; ctx.stroke();
  }
  const classes = Object.keys(cm.points[0]?.class_probabilities || {});
  $("carbon-legend").innerHTML = `<span><span class="ramp" style="background:${rampCss()}"></span> 0 → 1 ${esc(nice(key.replace(/^carbon_/, "")))} (interpolated, ESTIMATED)</span>` +
    classes.map((c, i) => `<span><i style="background:${CATEGORICAL[i % CATEGORICAL.length]};border-radius:50%"></i>${esc(nice(c))}</span>`).join("");
}
function onCarbonClick(ev) {
  const r = S._carbonR; if (!r) return;
  const rect = ev.target.getBoundingClientRect(), { e0, n0, res } = carbonGeom(), sc = r.scale / res, H = r.ny * r.scale;
  const x = ev.clientX - rect.left, y = ev.clientY - rect.top;
  let best = null, bd = 14 * 14;
  for (const p of S.carbon.points) { const d = ((p.east_m - e0) * sc - x) ** 2 + (H - (p.north_m - n0) * sc - y) ** 2; if (d < bd) { bd = d; best = p; } }
  if (best) selectTarget(best.target_id);
}

async function selectTarget(id) {
  S.selTarget = id; drawCarbonMap();
  let d = S.carbonDetail[id];
  if (!d) d = S.carbonDetail[id] = S.mode === "live" ? await api("/carbon/analyse", { method: "POST", body: { target_id: id } }) : S.snap.carbon_details?.[id];
  $("ct-id").textContent = `· ${id}`;
  if (!d) { $("ct-level").innerHTML = '<p class="dim">No detail available offline for this target.</p>'; return; }
  const cs = d.carbonaceous_structure;
  $("ct-level").innerHTML = `<div class="kv">${kv([
    ["Top class", `${esc(nice(d.top_class))} (${fx(d.top_probability)})`], ["Organic-carbon probability", fx(d.organic_probability)],
    ["Context", esc(nice(d.context))], ["Quantitation level", `<span class="na">${esc(d.quantitation_level)}</span>`],
    ...(cs ? [["Raman D1 / G centre", `${fx(cs.d1_center, 0)} / ${fx(cs.g_center, 0)} cm⁻¹`], ["R1 = I(D1)/I(G)", `${fx(cs.r1_height_ratio)} · ${esc(nice(cs.order))}`]] : []),
    ...(d.carbonate_mineralogy ? [["Carbonate phase", esc(JSON.stringify(d.carbonate_mineralogy))]] : []),
    ["Calibration", esc(Object.entries(d.calibration_status || {}).map(([k, v]) => `${k} ${v}`).join(", "))],
    ["Data origin", esc(d.data_origin).toUpperCase()]])}</div>` +
    (cs ? '<p class="hint">R1 describes carbon structural order. It is not a carbon concentration.</p>' : "");
  const ent = Object.entries(d.class_probabilities).sort((a, b) => b[1] - a[1]);
  barsCanvas($("ct-probs"), ent, d.probability_intervals);
  $("ct-evidence").tBodies[0].innerHTML = d.evidence.map(e => {
    const top = Object.entries(e.contributions).sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))[0];
    const note = e.note || (top ? `${top[1] >= 0 ? "+" : "−"}${fx(Math.abs(top[1]), 2)} → ${nice(top[0])}` : "");
    return `<tr><td>${esc(e.channel)}</td><td>${esc(nice(e.feature))}</td><td class="num">${fx(e.snr, 1)}</td><td class="num">${fx(e.strength, 2)}</td><td class="dim">${esc(note)}</td></tr>`;
  }).join("");
  const ex = S.raman?.[d.top_class];
  if (ex) {
    const ymax = Math.max(...ex.signal.filter(Number.isFinite));
    linePlot($("ct-raman"), [
      { x: ex.shift, y: ex.signal.map((v, i) => v + 2 * ex.sigma[i]), color: "#3f4a56", width: 1 },
      { x: ex.shift, y: ex.signal.map((v, i) => v - 2 * ex.sigma[i]), color: "#3f4a56", width: 1 },
      { x: ex.shift, y: ex.signal, color: C.blue, width: 1.6, label: `exemplar: ${nice(d.top_class)} (simulated)` }],
      { xlabel: "Raman shift (cm⁻¹)", ylabel: "baseline-corrected counts", ylim: [-0.1 * ymax, 1.15 * ymax],
        markers: (ex.bands || []).filter(b => b.snr >= 3).map(b => ({ x: b.observed_cm1, label: b.phase })) });
  } else {
    linePlot($("ct-raman"), [], {});
  }
  $("ct-limits").innerHTML = [...(d.limitations || []), ...(d.quantitative_refusals || [])].map(x => `<li>${esc(x)}</li>`).join("") +
    "<li>The exemplar spectrum is one simulated measurement of this class, not this target's spectrum; ±2σ band shown.</li>";
}

// ------------------------------------------------------------------ mineral
async function loadMineral() {
  if (!S.loaded.mineral) {
    const r = await get("nodules", "/nodules?limit=10000");
    S.nodules = r.nodules;
    $("nod-count").textContent = `· ${r.count} records · ${String(r.data_origin).toUpperCase()}`;
    $("nod-filter").addEventListener("input", renderNodTable); $("nod-sort").addEventListener("change", renderNodTable);
    $("nod-map").addEventListener("click", onNodMapClick);
    addEventListener("resize", () => $("view-mineral").classList.contains("active") && drawNodMap());
    S.loaded.mineral = true;
    renderNodTable();
    if (!S.selNodule) { const withDetail = S.mode === "snapshot" ? Object.keys(S.snap.nodule_details || {}) : []; selectNodule(withDetail[0] || S.nodules[0]?.nodule_id); }
  } else { drawNodMap(); }
}
function nodClasses() { return [...new Set(S.nodules.map(n => n.top_class))].sort(); }
function filteredNodules() {
  const f = $("nod-filter").value.trim().toLowerCase(), key = $("nod-sort").value;
  return S.nodules.filter(n => !f || n.nodule_id.toLowerCase().includes(f) || n.top_class.toLowerCase().includes(f)).sort((a, b) => (b[key] ?? -1) - (a[key] ?? -1));
}
function renderNodTable() {
  const rows = filteredNodules(), cls = nodClasses();
  $("nod-table").tBodies[0].innerHTML = rows.slice(0, 400).map(n => `<tr data-id="${esc(n.nodule_id)}" class="${n.nodule_id === S.selNodule ? "sel" : ""}"><td class="mono">${esc(n.nodule_id.replace(/^NOD-/, ""))}</td><td class="num">${fx(1000 * n.diameter_m, 1)}</td><td class="num">${fx(n.mass_g, 0)}</td><td><i style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${classColor(n.top_class)};margin-right:6px"></i>${esc(nice(n.top_class))}</td><td class="num">${fx(n.confidence)}</td><td>${n.assays.length ? `<span class="tag">${n.assays.length} assay</span>` : '<span class="dim">—</span>'}</td></tr>`).join("") +
    (rows.length > 400 ? `<tr><td colspan="6" class="dim">${rows.length - 400} more — refine the filter</td></tr>` : "");
  $("nod-table").tBodies[0].querySelectorAll("tr[data-id]").forEach(tr => tr.addEventListener("click", () => selectNodule(tr.dataset.id)));
  drawNodMap();
}
function drawNodMap() {
  const cv = $("nod-map"), dpr = devicePixelRatio || 1, W = cv.clientWidth || 600, H = cv.clientHeight || 240;
  cv.width = W * dpr; cv.height = H * dpr; const ctx = cv.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = "#0a0f15"; ctx.fillRect(0, 0, W, H);
  if (!S.nodules.length) return;
  const E = S.nodules.map(n => n.east_m), N = S.nodules.map(n => n.north_m);
  const e0 = Math.min(...E), e1 = Math.max(...E), n0 = Math.min(...N), n1 = Math.max(...N), pad = 12;
  const sc = Math.min((W - 2 * pad) / (e1 - e0 || 1), (H - 2 * pad) / (n1 - n0 || 1));
  const X = e => pad + (e - e0) * sc, Y = n => H - pad - (n - n0) * sc;
  S._nodMap = { X, Y };
  const shown = new Set(filteredNodules().map(n => n.nodule_id)), cls = nodClasses();
  for (const n of S.nodules) {
    const on = n.nodule_id === S.selNodule;
    ctx.beginPath(); ctx.arc(X(n.east_m), Y(n.north_m), Math.max(2, n.diameter_m / 2 * sc), 0, 2 * Math.PI);
    ctx.fillStyle = classColor(n.top_class); ctx.globalAlpha = shown.has(n.nodule_id) ? 0.9 : 0.15; ctx.fill();
    if (on) { ctx.globalAlpha = 1; ctx.strokeStyle = C.amber; ctx.lineWidth = 2; ctx.stroke(); }
  }
  ctx.globalAlpha = 1; ctx.fillStyle = C.axis; ctx.font = "10px ui-monospace, monospace";
  const bar = 0.5; ctx.fillRect(W - pad - bar * sc, H - 8, bar * sc, 2); ctx.fillText("0.5 m", W - pad - bar * sc, H - 11);
  let lg = $("nod-legend");
  if (!lg) { lg = Object.assign(document.createElement("div"), { id: "nod-legend", className: "legend" }); cv.after(lg); }
  lg.innerHTML = cls.map(c => `<span><i style="background:${classColor(c)};border-radius:50%"></i>${esc(nice(c))}</span>`).join("") + '<span class="dim">circle size = equivalent diameter</span>';
}
function onNodMapClick(ev) {
  if (!S._nodMap) return;
  const r = ev.target.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top;
  let best = null, bd = 100;
  for (const n of S.nodules) { const d = (S._nodMap.X(n.east_m) - x) ** 2 + (S._nodMap.Y(n.north_m) - y) ** 2; if (d < bd) { bd = d; best = n; } }
  if (best) selectNodule(best.nodule_id);
}

const est = (m, scale = 1, d = 1, unit = "") => m == null ? "—" : `${fx(m.value * scale, d)}${unit}${m.interval ? ` <span class="dim">[${fx(m.interval[0] * scale, d)}, ${fx(m.interval[1] * scale, d)}]</span>` : m.std != null ? ` <span class="dim">± ${fx(m.std * scale, d)}</span>` : ""} <span class="tag">${esc(m.origin)}</span>`;

async function selectNodule(id) {
  if (!id) return;
  S.selNodule = id;
  $("nr-id").textContent = `· ${id}`;
  document.querySelectorAll("#nod-table tr[data-id]").forEach(tr => tr.classList.toggle("sel", tr.dataset.id === id));
  drawNodMap();
  let d = S.nodDetail[id];
  if (!d) {
    if (S.mode === "live") d = S.nodDetail[id] = await api(`/nodules/${encodeURIComponent(id)}`);
    else d = S.snap.nodule_details?.[id];
  }
  const body = $("nr-body");
  const row = S.nodules.find(n => n.nodule_id === id);
  if (!d) {
    body.className = ""; body.innerHTML = `<div class="kv">${kv([["Position (E, N)", `${fx(row?.east_m, 3)}, ${fx(row?.north_m, 3)} m`], ["Equivalent ⌀", `${fx(1000 * row?.diameter_m, 1)} mm`], ["Mass", `${fx(row?.mass_g, 0)} g`], ["Spectral class", esc(nice(row?.top_class))]])}</div><p class="hint">The offline snapshot carries full records for the first ${Object.keys(S.snap.nodule_details || {}).length} nodules only; the live API serves every record.</p>`;
    return;
  }
  const rec = d.record, ob = rec.observations[rec.observations.length - 1], m = ob.measurements, ma = d.mineral_assessment, gr = d.grade_report;
  const sec = (t, html) => `<h3>${t}</h3>${html}`;
  const elem = Object.keys(gr.elemental_grade).map(k => [k, gr.elemental_grade[k] == null ? `<span class="na" title="${esc(gr.elemental_grade_basis[k])}">not reported</span>` : est(gr.elemental_grade[k], 1, 2, " wt %")]);
  body.className = "";
  body.innerHTML =
    `<div class="kv">${kv([["Survey", esc(rec.survey_id)], ["Position (E, N)", `${fx(rec.east_m, 3)}, ${fx(rec.north_m, 3)} m ± ${fx(100 * ob.position_std_m, 0)} cm`],
      ["Sensor", esc(ob.sensor)], ["Observed", esc(ob.time_utc.replace("T", " ").slice(0, 19))], ["Observations", rec.observations.length], ["Data origin", esc(ob.data_origin).toUpperCase()]])}</div>` +
    sec("Morphometry (95 % intervals)", `<div class="kv">${kv([["Equivalent ⌀", est(m.equivalent_diameter_m, 1000, 1, " mm")], ["Area", est(m.area_m2, 1e4, 1, " cm²")],
      ["Volume", est(m.volume_cm3, 1, 0, " cm³")], ["Wet mass", est(m.mass_g, 1, 0, " g")], ["Circularity", fx(m.circularity)], ["Elongation", fx(m.elongation)]])}</div>
      <p class="hint">Volume uses a height-ratio prior (nodules are partly buried; height is not observed by a nadir camera).</p>`) +
    sec("Spectral classification (surface, VNIR)", "<div id='nr-cls'></div>") +
    sec("Mn-oxide phase (conditional)", "<div id='nr-mn'></div>") +
    sec("Genesis indicators", "<div id='nr-gen'></div>") +
    sec("Element associations (qualitative)", `<ul class="bullets">${ma.associations.map(a => `<li><b>${esc(a.element)}</b> ↔ ${esc(a.associated_phase)} · likelihood ${fx(a.likelihood)} · requires ${esc(a.requires.join(" / "))}<br><span class="dim">${esc(a.basis)}</span></li>`).join("")}</ul>`) +
    sec("Grade, purity, mass, recoverable metal — kept separate", `<div class="kv">${kv([...elem, ["Mineralogical purity", gr.mineralogical_purity == null ? `<span class="na" title="${esc(gr.purity_basis)}">not reported</span>` : fx(gr.mineralogical_purity)],
      ["Physical mass", est(gr.physical_mass_g, 1, 0, " g")], ["Recoverable metal", Object.values(gr.recoverable_metal_g).every(v => v == null) ? '<span class="na">not reported (needs grade)</span>' : esc(JSON.stringify(gr.recoverable_metal_g))]])}</div>
      <ul class="bullets">${(gr.notes || []).map(n => `<li>${esc(n)}</li>`).join("")}</ul>
      <p class="hint">${esc(Object.values(gr.elemental_grade_basis)[0] || "")}</p>`) +
    sec("Phase abundance (FCLS unmixing, areal)", "<div id='nr-ab'></div>") +
    `<p class="hint">Linked assays: ${rec.assay_sample_ids.length ? rec.assay_sample_ids.map(esc).join(", ") : "none"} · XRD: ${rec.xrd_sample_ids.length ? rec.xrd_sample_ids.map(esc).join(", ") : "none"}</p>`;
  bars($("nr-cls"), Object.entries(ma.class_probabilities).sort((a, b) => b[1] - a[1]));
  bars($("nr-mn"), Object.entries(ma.mn_phase_probabilities || {}).sort((a, b) => b[1] - a[1]));
  bars($("nr-gen"), Object.entries(ma.genesis || {}));
  bars($("nr-ab"), Object.entries(gr.phase_abundance).sort((a, b) => b[1].value - a[1].value).map(([k, v]) => [k, v.value]),
    { fmtv: v => v.toFixed(2) });
}

// ------------------------------------------------------------------ geology
const LAYER_UNITS = { depth: "m", depth_std: "m", nodule_abundance_kg_m2: "kg/m²", nodule_abundance_std_kg_m2: "kg/m²", nodule_coverage_pct: "%", nodule_density_per_m2: "/m²" };
async function loadGeology() {
  if (!S.geo) S.geo = await get("geology", "/geology/map");
  const g = S.geo, m = g.map;
  if (!S.loaded.geology) {
    const keys = Object.keys(m.layers).filter(k => m.layers[k] && k !== "imaged");
    const pref = ["nodule_abundance_kg_m2", "depth", "dominant_mineral_class"];
    $("geo-layer").innerHTML = [...pref.filter(k => keys.includes(k)), ...keys.filter(k => !pref.includes(k))].map(k => `<option value="${k}">${esc(nice(k))}</option>`).join("");
    $("geo-stats").innerHTML = kv([["Imaged area", `${fx(g.statistics.imaged_area_m2, 2)} m²`], ["Grid resolution", `${fx(m.resolution_m, 3)} m`],
      ["Depth range", g.statistics.depth_range_m ? `${fx(g.statistics.depth_range_m[0], 2)} – ${fx(g.statistics.depth_range_m[1], 2)} m` : "—"],
      ["Mean density", `${fx(g.statistics.mean_density_per_m2, 1)} /m²`], ["Mean abundance", `${fx(g.statistics.mean_abundance_kg_m2, 1)} kg/m²`],
      ["Nodules", g.nodules.length], ["Carbon targets", g.carbon_points.length], ["Data origin", esc(g.data_origin).toUpperCase()]]);
    renderExports();
    const cv = $("geo-canvas");
    S.view3d = new Seabed3D(cv, { onPick: n => { location.hash = "mineral"; showView("mineral"); setTimeout(() => selectNodule(n.id), 0); }, onHover: geoHover });
    if (!S.view3d.ok) {
      cv.replaceWith(Object.assign(document.createElement("canvas"), { id: "geo-canvas" }));
      notice("WebGL is unavailable in this browser: the seabed model is shown as a 2-D raster.");
    }
    $("geo-layer").addEventListener("change", drawGeo);
    $("geo-exag").addEventListener("input", () => { $("geo-exag-v").textContent = `${$("geo-exag").value}×`; S.view3d.ok && S.view3d.setExaggeration(+$("geo-exag").value); });
    $("geo-nodules").addEventListener("change", () => S.view3d.setVisibility({ nodules: $("geo-nodules").checked }));
    $("geo-track").addEventListener("change", () => S.view3d.setVisibility({ track: $("geo-track").checked }));
    $("geo-reset").addEventListener("click", () => S.view3d.reset());
    S.view3d.exag = +$("geo-exag").value;
    S.loaded.geology = true;
  }
  drawGeo();
}

function geoColorFn(key) {
  const m = S.geo.map, rows = m.layers[key];
  if (key === "dominant_mineral_class") {
    return { categorical: true,
      legend: m.mineral_classes.map((c, k) => `<span><i style="background:${CATEGORICAL[k % CATEGORICAL.length]}"></i>${esc(nice(c))}</span>`).join("") + '<span><i style="background:#282e36"></i>no nodules</span>' };
  }
  const vals = rows.flat().filter(Number.isFinite).sort((a, b) => a - b);
  // 2nd-98th percentile stretch so one dense cell does not flatten the map
  let lo = vals[Math.floor(0.02 * (vals.length - 1))] ?? 0, hi = vals[Math.ceil(0.98 * (vals.length - 1))] ?? 1; if (hi === lo) hi = lo + 1;
  const invert = key === "depth";   // shallow = light
  return { lo, hi, categorical: false,
    legend: `<span><span class="ramp" style="background:${rampCss()}"></span> ${fx(invert ? hi : lo, 2)} → ${fx(invert ? lo : hi, 2)} ${esc(LAYER_UNITS[key] || "")} (2–98 % stretch) · ${esc(nice(key))}${key.startsWith("carbon_") ? " (interpolated, ESTIMATED)" : ""}</span>`,
    val: (fi, fj) => { const ny = rows.length, nx = rows[0].length; const i = Math.min(ny - 1, Math.max(0, Math.round(fi))), j = Math.min(nx - 1, Math.max(0, Math.round(fj))); return rows[i][j]; },
    t: v => Math.min(1, Math.max(0, invert ? (hi - v) / (hi - lo) : (v - lo) / (hi - lo))) };
}

function drawGeo() {
  const g = S.geo, m = g.map, key = $("geo-layer").value, cf = geoColorFn(key), cls = [...new Set(g.nodules.map(n => n.c))].sort();
  $("geo-legend").innerHTML = cf.legend + ($("geo-nodules").checked ? ` <span class="dim">· nodules:</span> ${cls.map(c => `<span><i style="background:${classColor(c)};border-radius:50%"></i>${esc(nice(c))}</span>`).join("")}` : "") +
    ($("geo-track").checked && m.tracks?.length ? '<span><i style="background:var(--amber);height:3px"></i>survey track</span>' : "");
  if (!S.view3d?.ok) {
    raster($("geo-canvas"), m.layers[key], cf.categorical ? { categorical: true, flipY: true } : { lo: cf.lo, hi: cf.hi, flipY: true });
    return;
  }
  const color = cf.categorical
    ? (i, j) => { const v = m.layers[key][i][j]; return v == null || v < 0 ? [40, 46, 54] : hex2rgb(CATEGORICAL[v % CATEGORICAL.length]); }
    : (i, j) => { const v = m.layers[key][i][j]; return v == null || !Number.isFinite(v) ? [40, 46, 54] : ramp(0.15 + 0.85 * cf.t(v)); };   // lifted so the low end stays visible when lit
  S.view3d.setData({
    east: m.east, north: m.north, depth: m.layers.depth || m.layers[key].map(r => r.map(() => 0)), color,
    nodules: g.nodules.map(n => ({ ...n, rgb: hex2rgb(classColor(n.c)) })), track: (m.tracks || [])[0] || [],
  });
  S._geoKey = key;
}

function geoHover(h) {
  const tip = $("geo-tip");
  if (!h) { tip.hidden = true; return; }
  const m = S.geo.map, key = S._geoKey;
  if (h.kind === "nodule") {
    const n = h.nodule;
    tip.innerHTML = `${esc(n.id)}<br>⌀ ${fx(1000 * n.d, 1)} mm · ${esc(nice(n.c))}<br><span style="color:var(--steel)">click to open record</span>`;
  } else {
    const v = m.layers[key][h.i][h.j], dep = m.layers.depth?.[h.i]?.[h.j];
    const vs = key === "dominant_mineral_class" ? (v == null || v < 0 ? "no nodules" : m.mineral_classes[v]) : fx(v, 3);
    tip.innerHTML = `E ${fx(h.e, 2)} m · N ${fx(h.n, 2)} m<br>${esc(nice(key))}: ${esc(vs)} ${esc(LAYER_UNITS[key] || "")}${dep != null ? `<br>depth ${fx(dep, 3)} m` : ""}`;
  }
  tip.hidden = false; tip.style.left = `${h.x + 14}px`; tip.style.top = `${h.y + 10}px`;
}

function download(name, text, type = "application/json") {
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}
function renderExports() {
  const el = $("exports");
  if (S.mode === "live") {
    const fmts = [["geojson_nodules", "Nodules · GeoJSON"], ["csv_nodules", "Nodules · CSV"], ["geojson_track", "Survey track · GeoJSON"],
      ["esri_ascii", "Selected layer · ESRI ASCII grid"], ["netcdf", "All layers · NetCDF"], ["ply", "Seabed mesh · PLY"], ["json_map", "Map payload · JSON"]];
    el.innerHTML = fmts.map(([f, l]) => `<button class="btn ghost" data-f="${f}">${l}</button>`).join("");
    el.querySelectorAll("button").forEach(b => b.addEventListener("click", async () => {
      b.disabled = true;
      try {
        const r = await api("/export", { method: "POST", body: { format: b.dataset.f, layer: $("geo-layer").value }, raw: true });
        const cd = r.headers.get("content-disposition") || "", name = (cd.match(/filename="?([^";]+)/) || [])[1] || `${b.dataset.f}.dat`;
        const blob = await r.blob(); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click();
      } catch (err) { notice(`Export failed: ${esc(err.message)}`); }
      b.disabled = false;
    }));
  } else {
    el.innerHTML = '<button class="btn ghost" data-f="geojson">Nodules · GeoJSON (local E/N)</button><button class="btn ghost" data-f="csv">Nodules · CSV</button><button class="btn ghost" data-f="map">Map payload · JSON</button><p class="hint">Offline: exports are built in the browser from the snapshot and use local east/north metres. The live API exports georeferenced WGS-84 GeoJSON, ESRI grids, NetCDF and PLY.</p>';
    const g = S.geo;
    el.querySelectorAll("button").forEach(b => b.addEventListener("click", () => {
      if (b.dataset.f === "geojson") download("nodules_local.geojson", JSON.stringify({ type: "FeatureCollection", properties: { data_origin: "simulated", crs: "local east/north metres (not WGS-84)" },
        features: g.nodules.map(n => ({ type: "Feature", geometry: { type: "Point", coordinates: [n.e, n.n] }, properties: { nodule_id: n.id, diameter_m: n.d, top_class: n.c, data_origin: "simulated" } })) }));
      else if (b.dataset.f === "csv") download("nodules.csv", "nodule_id,east_m,north_m,diameter_m,top_class,data_origin\n" + g.nodules.map(n => `${n.id},${n.e},${n.n},${n.d},${n.c},simulated`).join("\n"), "text/csv");
      else download("seabed_map.json", JSON.stringify(g.map));
    }));
  }
}

// ------------------------------------------------------------------ boot
async function boot() {
  initTabs();
  $("acq-start").addEventListener("click", () => acquisition("start"));
  $("acq-stop").addEventListener("click", () => acquisition("stop"));
  try {
    await detectSource();
    await loadDashboard();
    connectTelemetry();
    const v = location.hash.slice(1);
    showView(v || "dashboard", false);
    document.body.dataset.ready = "1";
  } catch (err) {
    setBadge($("source-badge"), "NO DATA", "fault");
    notice(`The workstation could not reach the instrument API and found no offline snapshot (${esc(err.message)}). Start the backend with <span class="mono">aardvark serve</span>.`);
    document.body.dataset.ready = "error";
    console.error(err);
  }
}
boot();
