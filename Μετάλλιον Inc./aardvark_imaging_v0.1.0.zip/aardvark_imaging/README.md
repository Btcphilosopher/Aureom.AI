# Aardvark Imaging × Μετάλλιον Inc.

**Spectral nodule intelligence, carbon characterisation and subsea sensor array (AAI-SSA-1).**

This subsystem contains:

* the Silica Flux hardware manifest and code generator;
* synthesizable SystemVerilog for the sensor electronics, with Verilator testbenches;
* a Python 3.12+ scientific backend;
* a FastAPI service with WebSocket telemetry;
* a browser workstation.

> **Status.** Everything runs and is tested, but the sensor data is **simulated**. No detector has been selected or measured, no calibration is real, and no FPGA has been programmed. Every value carries a data-origin label (`simulated` / `measured` / `estimated` / `lab_validated`). `TECHNICAL_REPORT.md` separates what is implemented, tested and simulated, and lists what laboratory and hardware work comes next.

![Workstation dashboard](docs/screenshots/desktop_dashboard.png)

## Quick start

```bash
pip install -e ".[dev]"                 # Python ≥ 3.12
aardvark serve                          # API + workstation on http://127.0.0.1:8000
pytest -m "not hardware and not ui"     # 203 tests, ~40 s
pytest -m ui                            # workstation in Chromium (Playwright)
pytest -m hardware                      # Verilator lint + 25 RTL testbenches (needs verilator)
```

Other entry points:

* `aardvark simulate --fast --out sim/` writes a simulated survey (summary, Zarr cube, GeoJSON, NetCDF).
* `aardvark sf validate|generate|check|budget` runs the Silica Flux manifest tooling.
* `aardvark decode dump.hex` decodes an SFP1 word dump; `aardvark spool-recover <dir>` repairs torn records after a power loss.
* `aardvark benchmark` reports timings on the current machine.
* The workstation also opens straight from `frontend/index.html` without a server. It then uses the recorded simulated snapshot.

## Layout

| Path | Contents |
|---|---|
| `hardware/silica_flux/` | manifest (single source of truth), architecture spec, register maps, timing-constraint template |
| `hardware/systemverilog/` | RTL (17 required `sf_*` modules plus CDC, FIFO, SPI, I2C, LVDS, ADC, AXI-Lite helpers) |
| `hardware/verification/` | 25 self-checking testbenches, assertions, simulation runner, vectors, Yosys estimate |
| `backend/` (import name `aardvark_imaging`) | acquisition, calibration, spectral, hyperspectral, carbon, mineralogy, nodules, sonar, electromagnetic, sensor fusion, geospatial, mapping, storage, simulation, API |
| `frontend/` | workstation (`index.html`, `css/`, `js/` with a WebGL seabed viewer; `assets/` offline snapshot) |
| `tests/` | unit, integration, scientific constraints, simulated validation, hardware, UI |
| `docs/` | sensor specification, Silica Flux, calibration, carbon measurement, spectral processing, hardware verification, deployment, data-rate budget, benchmarks, repository inspection |
| `deploy/`, `docker-compose.yml` | Dockerfile, compose (API + PostgreSQL), profiles (dev, FPGA board, ROV/AUV, vessel, analysis server) |
| `data/schemas/` | JSON Schemas of every record type |
| `models/` | model cards and acceptance gates (no validated models yet) |

## Rules this code enforces

* **Radar is never used to infer carbon.** Through seawater it is refused outright, at about 325 dB/m at 100 MHz.
* **Raman D/G describes carbon structure, not concentration.** TOC/TIC is reported only through a laboratory-validated model, and none exists yet.
* **No purity from spectra.** Grade, purity, mass and recoverable metal are kept separate; grade needs assays, purity needs XRD.
* **Raw data is retained.** The raw spool is append-only and cube products are write-once, with provenance on every product.
* **Water physics limits the optical sensors.** Unusable bands are masked; SWIR is contact-only; mid-IR is ATR-only.

See `VERIFICATION_LOG.md` for the defects found by testing and how each was fixed.
