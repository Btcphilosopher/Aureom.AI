// AXI4 write-channel checker for the DMA master: handshake stability, INCR
// 32-bit bursts, no 64-byte (and therefore no 4 KiB) boundary crossing, WLAST
// on exactly the AWLEN+1-th beat, and no more than one outstanding burst.
module sf_axi_write_checker (
  input logic        clk,
  input logic        rst_n,
  input logic [31:0] awaddr,
  input logic [7:0]  awlen,
  input logic [2:0]  awsize,
  input logic [1:0]  awburst,
  input logic        awvalid,
  input logic        awready,
  input logic [31:0] wdata,
  input logic        wlast,
  input logic        wvalid,
  input logic        wready,
  input logic        bvalid,
  input logic        bready
);
  a_aw_hold: assert property (@(posedge clk) disable iff (!rst_n)
                              (awvalid && !awready) |=> (awvalid && $stable(awaddr) && $stable(awlen)))
    else $error("AXI: AW not held");
  a_w_hold: assert property (@(posedge clk) disable iff (!rst_n)
                             (wvalid && !wready) |=> (wvalid && $stable(wdata) && $stable(wlast)))
    else $error("AXI: W not held");
  a_size: assert property (@(posedge clk) disable iff (!rst_n) awvalid |-> (awsize == 3'd2 && awburst == 2'b01))
    else $error("AXI: unexpected size/burst");
  a_64b: assert property (@(posedge clk) disable iff (!rst_n)
                          awvalid |-> ((32'(awaddr[5:2]) + 32'(awlen)) < 32'd16))
    else $error("AXI: burst crosses a 64-byte boundary");
  a_align: assert property (@(posedge clk) disable iff (!rst_n) awvalid |-> (awaddr[1:0] == 2'b00))
    else $error("AXI: unaligned address");

  int beats_left;
  int outstanding;
  always_ff @(posedge clk) begin
    if (!rst_n) begin beats_left <= 0; outstanding <= 0; end
    else begin
      if (awvalid && awready) begin
        if (outstanding != 0) $error("AXI: more than one outstanding burst");
        beats_left <= int'(awlen) + 1;
        outstanding <= outstanding + 1;
      end
      if (wvalid && wready) begin
        if (wlast != (beats_left == 1)) $error("AXI: WLAST mismatch (beats_left=%0d)", beats_left);
        beats_left <= beats_left - 1;
      end
      if (bvalid && bready) outstanding <= outstanding - 1;
    end
  end
endmodule
