// Valid/ready stream protocol checker (SVA). Bind or instantiate next to any
// valid/ready interface. Checks: once valid is asserted it is held, with
// stable data/last, until accepted; no X on valid out of reset.
module sf_stream_checker #(
  parameter int DW = 32
) (
  input logic          clk,
  input logic          rst_n,
  input logic          valid,
  input logic          ready,
  input logic [DW-1:0] data,
  input logic          last
);
  a_hold: assert property (@(posedge clk) disable iff (!rst_n)
                           (valid && !ready) |=> (valid && $stable(data) && $stable(last)))
    else $error("stream: valid/data/last not held under backpressure");
  a_known: assert property (@(posedge clk) disable iff (!rst_n) !$isunknown(valid))
    else $error("stream: valid is X");
endmodule
