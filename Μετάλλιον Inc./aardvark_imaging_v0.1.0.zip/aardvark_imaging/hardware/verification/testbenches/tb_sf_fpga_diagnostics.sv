// Diagnostics + housekeeping: error counting, host-link supervision (data
// keep flowing), over-temperature from the housekeeping scan, diagnostic
// packet layout, housekeeping packet codes.
module tb_sf_fpga_diagnostics;
  `include "tb_common.svh"
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic [7:0] errp = 0;
  logic kick = 0;
  logic [63:0] ts = 0;
  always @(posedge clk) ts <= ts + 1;
  logic [31:0] hb, etot;
  logic hlost, otemp, fany;
  logic dv, dr, dl, hv, hr, hl;
  logic [31:0] dd, dfr, dm, hd, hfr, hm;
  logic [7:0] df, hf;
  logic [15:0] drow, hrow;
  logic [63:0] dts, hts;
  // housekeeping ADC path
  logic hstart, hvalid, hbusy, hovr, cnv, sclk, csn, miso, scan;
  logic [1:0] hch, hchin, hmux;
  logic [15:0] hdata;
  logic [63:0] codes;
  sf_adc_interface #(.BITS(16), .LANES(1), .CLKDIV(2), .CNV_CYCLES(10), .MUX_W(2), .MUX_SETTLE(5)) u_adc (.clk(clk),
    .rst_n(rst_n), .start(hstart), .ch(hch), .busy(hbusy), .start_overrun(hovr), .sample_valid(hvalid), .sample_data(hdata),
    .sample_ch(hchin), .mux_sel(hmux), .adc_cnv(cnv), .adc_sclk(sclk), .adc_cs_n(csn), .adc_miso(miso));
  sf_housekeeping u_hk (.clk(clk), .rst_n(rst_n), .enable(1'b1), .pkt_en(1'b1), .period(32'd2000), .ts_now(ts),
    .adc_start(hstart), .adc_ch(hch), .adc_valid(hvalid), .adc_data(hdata), .adc_ch_in(hchin), .codes(codes),
    .src_valid(hv), .src_ready(hr), .src_data(hd), .src_last(hl), .src_flags(hf), .src_frame(hfr), .src_row(hrow),
    .src_meta(hm), .src_ts(hts), .scan_done(scan));
  sf_fpga_diagnostics #(.NERR(8), .NSTATUS(5)) dut (.clk(clk), .rst_n(rst_n), .err_pulse(errp), .host_kick(kick),
    .host_timeout(32'd3000), .temp_code(codes[15:0]), .temp_limit(16'd40000), .pkt_en(1'b1), .period(32'd5000),
    .status_words({32'h55, 32'h44, 32'h33, 32'h22, 32'h11}), .stage_hwm(16'd77), .ts_now(ts), .heartbeat(hb),
    .host_lost(hlost), .overtemp(otemp), .fault_any(fany), .err_total(etot), .src_valid(dv), .src_ready(dr), .src_data(dd),
    .src_last(dl), .src_flags(df), .src_frame(dfr), .src_row(drow), .src_meta(dm), .src_ts(dts));
  tb_src_sink #(.READY_PCT(80), .SEED(31)) dsink (.clk(clk), .rst_n(rst_n), .valid(dv), .ready(dr), .data(dd), .last(dl),
    .flags(df), .frame(dfr), .row(drow), .meta(dm), .ts(dts));
  tb_src_sink #(.READY_PCT(80), .SEED(37)) hsink (.clk(clk), .rst_n(rst_n), .valid(hv), .ready(hr), .data(hd), .last(hl),
    .flags(hf), .frame(hfr), .row(hrow), .meta(hm), .ts(hts));
  // HK ADC model: channel-dependent codes; temperature (ch0) is programmable
  logic [15:0] temp_code = 16'd30000, sh;
  always @(negedge cnv) sh = (hmux == 0) ? temp_code : 16'(1000 * (int'(hmux) + 1) + 7);
  always @(negedge csn) miso = sh[15];
  always @(negedge sclk) if (!csn) begin sh = sh << 1; miso = sh[15]; end
  initial begin
    miso = 0;
    repeat (4) @(posedge clk); rst_n = 1;
    // error pulses: 3 on ch1, 2 on ch6 (one simultaneous)
    for (int i = 0; i < 3; i++) begin @(negedge clk) errp = 8'b0000_0010; @(negedge clk) errp = 0; end
    @(negedge clk) errp = 8'b0100_0010; @(negedge clk) errp = 0;
    @(negedge clk) errp = 8'b0100_0000; @(negedge clk) errp = 0;
    repeat (5) @(negedge clk);
    tb_check(etot == 32'd5, $sformatf("error events total %0d", etot));
    // host link: kick regularly, then stop
    for (int i = 0; i < 5; i++) begin repeat (1000) @(negedge clk); @(negedge clk) kick = 1; @(negedge clk) kick = 0; end
    tb_check(!hlost, "host link healthy while kicked");
    repeat (3500) @(negedge clk);
    tb_check(hlost, "host link lost after timeout");
    begin int n0; n0 = dsink.npk; repeat (12000) @(negedge clk); tb_check(dsink.npk > n0, "diagnostic packets continue while host lost"); end
    // diagnostic packet layout
    begin
      int p;
      p = dsink.npk - 1;
      tb_check(dsink.p_len[p] == 16, "16-word diagnostic snapshot");
      tb_check(dsink.w[dsink.p_start[p] + 3] == 32'd5, "err_total in word 3");
      tb_check(dsink.w[dsink.p_start[p] + 5] == {16'd4, 16'd0}, "ch1 counter in word 5 high half (word = {ch1, ch0})");
      tb_check(dsink.w[dsink.p_start[p] + 8] == {16'd0, 16'd2}, "ch6 counter in word 8 low half");
      tb_check(dsink.w[dsink.p_start[p] + 10] == 32'd77, "stage high-water mark");
      tb_check(dsink.w[dsink.p_start[p] + 11] == 32'h11 && dsink.w[dsink.p_start[p] + 15] == 32'h55, "status words");
      tb_check(dsink.w[dsink.p_start[p] + 4][0] == 1'b1, "host_lost bit");
    end
    // housekeeping codes and packets
    tb_check(codes[31:16] == 16'd2007 && codes[47:32] == 16'd3007 && codes[63:48] == 16'd4007, "HK codes per channel");
    tb_check(hsink.npk > 3 && hsink.p_len[0] == 4, "HK packets");
    tb_check(!otemp, "no overtemp at 30000");
    temp_code = 16'd50000;
    repeat (5000) @(negedge clk);
    tb_check(otemp && fany, "overtemp raised from housekeeping temperature");
    tb_done("tb_sf_fpga_diagnostics");
  end
endmodule
