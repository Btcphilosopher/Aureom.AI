// Hyperspectral controller: trigger-width exposure timing, camera FVAL/LVAL
// readout in the camera clock domain, exposure-start timestamps on every row
// of the line, band(row)/line(frame) indexing, trigger-during-exposure
// overrun counting, and the internal test pattern path.
module tb_sf_hsi_controller;
  `include "tb_common.svh"
  localparam int P = 12, R = 5;
  logic clk = 0, pclk = 0, rst_n = 0, prst_n = 0;
  always #5 clk = ~clk;
  always #6.734 pclk = ~pclk;
  logic fval = 0, lval = 0, expo, en = 0, test = 0, trig = 0, cal_we = 0;
  logic [15:0] cdata = 0;
  logic [63:0] ts = 0;
  logic sv, sr, sl, eevt, errevt;
  logic [31:0] sd, sfr, sm, status, frames, errors;
  logic [7:0] sf;
  logic [15:0] srow;
  logic [63:0] sts;
  always @(posedge clk) ts <= ts + 1;
  sf_hsi_controller #(.FIFO_AW(6), .CAL_AW(8)) dut (.clk(clk), .rst_n(rst_n), .pclk(pclk), .prst_n(prst_n),
    .cam_fval(fval), .cam_lval(lval), .cam_data(cdata), .cam_exposure(expo), .enable(en), .cal_en(1'b0),
    .test_mode(test), .cfg_pixels(16'(P)), .cfg_rows(16'(R)), .exposure_cycles(32'd200), .sat_level(16'h0FFF),
    .trig(trig), .ts_now(ts), .cal_we(cal_we), .cal_waddr(8'd0), .cal_wdata(33'd0),
    .src_valid(sv), .src_ready(sr), .src_data(sd), .src_last(sl), .src_flags(sf), .src_frame(sfr), .src_row(srow),
    .src_meta(sm), .src_ts(sts), .status(status), .frames(frames), .errors(errors), .exposure_evt(eevt), .error_evt(errevt));
  tb_src_sink #(.READY_PCT(80), .SEED(3)) sink (.clk(clk), .rst_n(rst_n), .valid(sv), .ready(sr), .data(sd), .last(sl),
    .flags(sf), .frame(sfr), .row(srow), .meta(sm), .ts(sts));
  // camera model: after exposure ends, read out R rows of P pixels (FVAL/LVAL)
  int expo_len = 0, max_expo = 0, lines = 0;
  logic [63:0] trig_ts [int];
  // Monitors sample at negedge (unambiguous with respect to posedge updates).
  // Timestamp convention: an imager row carries the counter value of the
  // first clk_sys cycle in which the exposure gate is asserted.
  always @(negedge clk) if (rst_n) begin
    if (expo) expo_len++; else begin if (expo_len > max_expo) max_expo = expo_len; expo_len = 0; end
    if (eevt) begin trig_ts[lines] = ts; lines++; end
  end
  logic expo_p = 0, expo_pq = 0;
  always @(posedge pclk) begin expo_p <= expo; expo_pq <= expo_p; end
  int cam_line = 0;
  function automatic logic [15:0] cval(input int ln, input int r, input int c); cval = 16'((ln * 101 + r * 17 + c) & 16'h0FFF); endfunction
  initial forever begin
    @(negedge pclk);
    if (prst_n && expo_pq && !expo_p && !test) begin
      fval = 1;
      for (int r = 0; r < R; r++) begin
        repeat (3) @(negedge pclk);
        for (int c = 0; c < P; c++) begin lval = 1; cdata = cval(cam_line, r, c); @(negedge pclk); end
        lval = 0;
      end
      repeat (2) @(negedge pclk); fval = 0; cam_line++;
    end
  end
  task automatic fire(); @(negedge clk) trig = 1; @(negedge clk) trig = 0; endtask
  initial begin
    repeat (4) @(posedge clk); rst_n = 1; prst_n = 1;
    @(negedge clk) en = 1;
    for (int k = 0; k < 4; k++) begin fire(); repeat (900) @(negedge clk); end
    // trigger during exposure -> overrun counted, no extra line
    fire(); repeat (50) @(negedge clk); fire(); repeat (900) @(negedge clk);
    tb_check(max_expo == 200, $sformatf("exposure width %0d cycles", max_expo));
    tb_check(errors[31:16] == 16'd1, $sformatf("trigger overrun counted (%0d)", errors[31:16]));
    tb_check(frames == 32'd5, $sformatf("lines completed %0d", frames));
    tb_check(sink.npk == 5 * R, $sformatf("packets %0d", sink.npk));
    for (int p = 0; p < sink.npk && p < 5 * R; p++) begin
      int ln, r;
      ln = p / R; r = p % R;
      tb_check(sink.p_frame[p] == ln && sink.p_row[p] == r, "line/band indexing");
      tb_check(sink.p_ts[p] == trig_ts[ln] && sink.p_meta[p][31], $sformatf("exposure-start timestamp on every row: pkt %0d trig %0d meta31 %0b", sink.p_ts[p], trig_ts[ln], sink.p_meta[p][31]));
      for (int c = 0; c < P; c++) tb_check(sink.pix(p, c) == cval(ln, r, c), "camera pixel data");
    end
    // test pattern
    en = 0; @(negedge clk) test = 1; repeat (10) @(negedge clk); en = 1;
    begin
      int p0;
      p0 = sink.npk;
      fire(); repeat (900) @(negedge clk);
      tb_check(sink.npk == p0 + R, "test pattern line");
      for (int r = 0; r < R; r++) for (int c = 0; c < P; c++) begin
        logic [15:0] e;
        // saturated raw codes are sentinel-coded (0xFFFF) even with calibration bypassed
        e = (r == 0 && c == 0) ? 16'hFFFF : 16'((0 * 31 + r * 7 + c * 3) & 16'h0FFF);
        tb_check(sink.pix(p0 + r, c) == e, $sformatf("pattern r%0d c%0d %0h exp %0h", r, c, sink.pix(p0 + r, c), e));
      end
      tb_check(sink.p_flags[p0][0] == 1'b1, "saturated test pixel flagged");
    end
    tb_done("tb_sf_hsi_controller");
  end
endmodule
