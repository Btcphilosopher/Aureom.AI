// SPI master in all four modes, 2 MISO lanes, against behavioural slaves.
module tb_spi_slave #(parameter logic CPOL = 0, parameter logic CPHA = 0, parameter int BITS = 12) (
  input logic sclk, input logic cs_n, input logic mosi, output logic [1:0] miso,
  input logic [BITS-1:0] tx0, input logic [BITS-1:0] tx1, output logic [BITS-1:0] rx
);
  logic [BITS-1:0] s0, s1;
  int n;
  always @(negedge cs_n) begin
    s0 = tx0; s1 = tx1; n = 0; rx = '0;
    if (!CPHA) miso = {s1[BITS-1], s0[BITS-1]};
  end
  always @(sclk) if (!cs_n) begin
    if ((sclk != CPOL) == !CPHA) begin  // sampling edge
      rx = {rx[BITS-2:0], mosi};
    end else begin                      // shifting edge
      if (CPHA) begin miso = {s1[BITS-1], s0[BITS-1]}; s0 = s0 << 1; s1 = s1 << 1; end
      else begin s0 = s0 << 1; s1 = s1 << 1; miso = {s1[BITS-1], s0[BITS-1]}; end
    end
  end
endmodule

module tb_sf_spi_master;
  `include "tb_common.svh"
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  localparam int B = 12;
  logic [3:0] start = 0, busy, done, sclk, cs_n, mosi;
  logic [B-1:0] tx [4];
  logic [2*B-1:0] rx [4];
  logic [1:0] miso [4];
  logic [B-1:0] st0 [4], st1 [4], srx [4];
  genvar m;
  generate for (m = 0; m < 4; m++) begin : g
    sf_spi_master #(.BITS(B), .LANES(2), .CLKDIV(3), .CPOL(m[1]), .CPHA(m[0])) dut (
      .clk(clk), .rst_n(rst_n), .start(start[m]), .tx_data(tx[m]), .busy(busy[m]), .done(done[m]), .rx_data(rx[m]),
      .sclk(sclk[m]), .cs_n(cs_n[m]), .mosi(mosi[m]), .miso(miso[m]));
    tb_spi_slave #(.CPOL(m[1]), .CPHA(m[0]), .BITS(B)) sl (.sclk(sclk[m]), .cs_n(cs_n[m]), .mosi(mosi[m]), .miso(miso[m]),
      .tx0(st0[m]), .tx1(st1[m]), .rx(srx[m]));
  end endgenerate
  int unsigned rs = 5;
  function automatic int rnd(input int mm); rs = rs * 1664525 + 1013904223; rnd = int'((rs >> 8) % mm); endfunction
  initial begin
    for (int i = 0; i < 4; i++) begin tx[i] = 0; st0[i] = 0; st1[i] = 0; end
    repeat (3) @(posedge clk); rst_n = 1;
    for (int t = 0; t < 40; t++) begin
      for (int i = 0; i < 4; i++) begin tx[i] = B'(rnd(4096)); st0[i] = B'(rnd(4096)); st1[i] = B'(rnd(4096)); end
      @(negedge clk) start = 4'hF;
      @(negedge clk) start = 4'h0;
      tb_check(&busy, "busy after start");
      wait (&(~busy));
      @(negedge clk);
      for (int i = 0; i < 4; i++) begin
        tb_check(rx[i][B-1:0] == st0[i], $sformatf("mode %0d lane0 rx %0h exp %0h", i, rx[i][B-1:0], st0[i]));
        tb_check(rx[i][2*B-1:B] == st1[i], $sformatf("mode %0d lane1 rx %0h exp %0h", i, rx[i][2*B-1:B], st1[i]));
        tb_check(srx[i] == tx[i], $sformatf("mode %0d mosi %0h exp %0h", i, srx[i], tx[i]));
        tb_check(sclk[i] == logic'(i >> 1), "SCLK idles at CPOL");
        tb_check(cs_n[i], "CS released");
      end
    end
    tb_done("tb_sf_spi_master");
  end
endmodule
