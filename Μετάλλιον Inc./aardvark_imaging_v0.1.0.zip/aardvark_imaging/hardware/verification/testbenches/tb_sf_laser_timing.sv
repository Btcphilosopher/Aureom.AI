// Laser timing & interlock: key arming, wrong key, delay, CW and pulsed
// waveform, watchdog, interlock drop during emission, overtemp, max-on cap.
module tb_sf_laser_timing;
  `include "tb_common.svh"
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic arm = 0, kick = 0, pulsed = 0, sub = 0, ot = 0, req = 0;
  logic [15:0] key = 0;
  logic [31:0] wd = 5000, dly = 20, pw = 3, pp = 10, maxon = 2000;
  logic en, mod_, emit, armed, ilk, wdok, abort_, start_;
  logic [3:0] fault;
  sf_laser_timing #(.MAX_ON_HW(32'd100000)) dut (.clk(clk), .rst_n(rst_n), .arm_stb(arm), .arm_key(key), .kick_stb(kick),
    .wd_timeout(wd), .pulsed(pulsed), .delay_cycles(dly), .pulse_width(pw), .pulse_period(pp), .max_on_sw(maxon),
    .submerged_async(sub), .overtemp(ot), .gate_req(req), .laser_enable(en), .laser_mod(mod_), .emitting(emit),
    .armed(armed), .interlock_ok(ilk), .wd_ok(wdok), .abort_evt(abort_), .emit_start_evt(start_), .fault_evt(fault));
  int faults [4] = '{0, 0, 0, 0};
  int aborts = 0, sub_low = 0;
  always @(posedge clk) if (rst_n) begin
    for (int i = 0; i < 4; i++) if (fault[i]) faults[i]++;
    if (abort_) aborts++;
    sub_low = sub ? 0 : sub_low + 1;
    // two-flop interlock synchroniser: output must be off by the 3rd edge
    tb_check(!(en && sub_low > 2), "never enabled once interlock low for > sync latency");
  end
  task automatic do_arm(input logic [15:0] k); @(negedge clk) begin arm = 1; key = k; end @(negedge clk) arm = 0; endtask
  initial begin
    repeat (3) @(posedge clk); rst_n = 1;
    do_arm(16'hA55A);
    tb_check(!armed, "cannot arm when not submerged");
    sub = 1; repeat (4) @(negedge clk);
    do_arm(16'h1234); tb_check(!armed, "wrong key does not arm");
    do_arm(16'hA55A); tb_check(armed, "armed with key + interlock");
    // CW gate with delay
    begin
      int t_on;
      @(negedge clk) req = 1;
      t_on = 0;
      while (!emit) begin @(negedge clk); t_on++; end
      tb_check(t_on >= 20 && t_on <= 23, $sformatf("emission delay %0d", t_on));
      repeat (50) @(negedge clk);
      tb_check(en && mod_, "CW emitting");
      @(negedge clk) req = 0;
      repeat (2) @(negedge clk);
      tb_check(!emit && armed, "gate release returns to armed");
    end
    // pulsed waveform: width 3 / period 10
    pulsed = 1; kick = 1; @(negedge clk) kick = 0;
    @(negedge clk) req = 1;
    wait (emit);
    begin
      int hi = 0, tot = 0;
      repeat (5) @(negedge clk);
      for (int i = 0; i < 100; i++) begin @(negedge clk); tot++; if (mod_) hi++; end
      tb_check(hi == 30, $sformatf("pulsed duty %0d/100", hi));
    end
    @(negedge clk) req = 0; pulsed = 0;
    // interlock drop during emission -> immediate cut, fault, disarm
    kick = 1; @(negedge clk) kick = 0;
    @(negedge clk) req = 1;
    wait (emit);
    repeat (10) @(negedge clk);
    sub = 0;
    repeat (3) @(negedge clk);
    tb_check(!en, "laser cut within synchroniser latency of interlock drop");
    repeat (2) @(negedge clk);
    tb_check(!armed && faults[0] == 1, "interlock drop fault + disarm");
    @(negedge clk) req = 0;
    // watchdog
    sub = 1; repeat (4) @(negedge clk);
    do_arm(16'hA55A); tb_check(armed, "re-armed");
    repeat (5100) @(negedge clk);
    tb_check(!armed && faults[1] == 1, "watchdog timeout disarms");
    // max-on
    do_arm(16'hA55A);
    @(negedge clk) req = 1;
    for (int i = 0; i < 2100; i++) begin @(negedge clk); if (i % 1000 == 0) begin kick = 1; @(negedge clk) kick = 0; end end
    tb_check(!en && faults[2] == 1, "max-on cap cuts emission");
    @(negedge clk) req = 0;
    // overtemp
    do_arm(16'hA55A); tb_check(armed, "armed again");
    @(negedge clk) ot = 1; @(negedge clk) ot = 0;
    repeat (2) @(negedge clk);
    tb_check(!armed && faults[3] == 1, "overtemp disarms");
    tb_check(aborts >= 2, $sformatf("abort events %0d", aborts));
    tb_done("tb_sf_laser_timing");
  end
endmodule
