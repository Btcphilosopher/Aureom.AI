// Sonar interface: MBES trigger pulse width, TX-ack timestamping, ack timeout,
// acoustic array capture after RX delay with segmentation and exact sample
// payloads, and drop flagging under back-pressure.
module tb_sf_sonar_interface;
  `include "tb_common.svh"
  localparam int NCH = 8, SEG = 128, NS = 300, TW = 20;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic en = 0, aen = 1, trig = 0, ack = 0, arr_v = 0;
  logic [63:0] ts = 0;
  always @(posedge clk) ts <= ts + 1;
  logic [NCH*16-1:0] arr_d = 0;
  logic mtrig, pv, pr, pl, av, ar, al, pevt, eevt;
  logic [31:0] pd, pfr, pm, ad, afr, am, status, pings, errors;
  logic [7:0] pf, af;
  logic [15:0] prow, arow;
  logic [63:0] pts, ats;
  sf_sonar_interface #(.NCH(NCH), .SEG_SAMPLES(SEG), .TRIG_WIDTH(TW)) dut (.clk(clk), .rst_n(rst_n), .enable(en), .array_en(aen),
    .rx_delay(24'd5), .nsamp(16'(NS)), .ack_timeout(32'd300), .trig(trig), .ts_now(ts), .mbes_trigger(mtrig),
    .tx_ack_async(ack), .arr_aligned(1'b1), .arr_valid(arr_v), .arr_data(arr_d),
    .p_valid(pv), .p_ready(pr), .p_data(pd), .p_last(pl), .p_flags(pf), .p_frame(pfr), .p_row(prow), .p_meta(pm), .p_ts(pts),
    .a_valid(av), .a_ready(ar), .a_data(ad), .a_last(al), .a_flags(af), .a_frame(afr), .a_row(arow), .a_meta(am), .a_ts(ats),
    .status(status), .pings(pings), .errors(errors), .ping_evt(pevt), .error_evt(eevt));
  tb_src_sink #(.READY_PCT(100), .SEED(19)) psink (.clk(clk), .rst_n(rst_n), .valid(pv), .ready(pr), .data(pd), .last(pl),
    .flags(pf), .frame(pfr), .row(prow), .meta(pm), .ts(pts));
  logic block = 0, ar_s;
  tb_src_sink #(.READY_PCT(100), .SEED(23)) asink (.clk(clk), .rst_n(rst_n), .valid(av), .ready(ar_s), .data(ad), .last(al),
    .flags(af), .frame(afr), .row(arow), .meta(am), .ts(ats));
  assign ar = ar_s && !block;
  int tw = 0, twmax = 0, k = 0;
  always @(negedge clk) if (rst_n) begin if (mtrig) tw++; else begin if (tw > twmax) twmax = tw; tw = 0; end end
  // array ADC: one sample every 10 cycles, channel c = k*(c+1)
  initial forever begin
    repeat (9) @(negedge clk);
    @(negedge clk) begin arr_v = 1; for (int c = 0; c < NCH; c++) arr_d[16*c +: 16] = 16'(k * (c + 1)); k++; end
    @(negedge clk) arr_v = 0;
  end
  logic [63:0] ack_time;
  initial begin
    repeat (4) @(posedge clk); rst_n = 1;
    @(negedge clk) en = 1;
    // ping 0 with ack
    @(negedge clk) trig = 1; @(negedge clk) trig = 0;
    repeat (37) @(negedge clk);
    ack_time = ts; ack = 1; repeat (5) @(negedge clk); ack = 0;
    repeat (4000) @(negedge clk);
    tb_check(twmax == TW, $sformatf("MBES trigger width %0d", twmax));
    tb_check(psink.npk == 1 && psink.p_len[0] == 6, "ping event packet");
    tb_check(psink.w[0] == 0 && psink.w[5] == 32'd1, "ping number, ack ok");
    begin
      logic [63:0] at;
      at = {psink.w[3], psink.w[4]};
      tb_check(at >= ack_time + 2 && at <= ack_time + 4, $sformatf("ack timestamp latency %0d", int'(at - ack_time)));
      tb_check({psink.w[1], psink.w[2]} < at, "trigger precedes ack");
    end
    // array: 300 samples -> segments of 128, 128, 44
    tb_check(asink.npk == 3, $sformatf("array segments %0d", asink.npk));
    begin
      int first;
      first = -1;
      for (int p = 0; p < asink.npk && p < 3; p++) begin
        int nsmp;
        nsmp = (p < 2) ? SEG : NS - 2 * SEG;
        tb_check(asink.p_row[p] == p && int'(asink.p_meta[p][15:0]) == nsmp && asink.p_len[p] == nsmp * NCH / 2,
                 $sformatf("segment %0d header", p));
        tb_check(asink.p_flags[p] == 8'h00, "no drops at full rate");
        if (p == 0) first = int'(asink.w[asink.p_start[0]][15:0]);
        for (int i = 0; i < nsmp; i++) for (int c = 0; c < NCH; c++) begin
          logic [31:0] x; logic [15:0] v;
          x = asink.w[asink.p_start[p] + i * (NCH / 2) + c / 2];
          v = (c % 2) ? x[31:16] : x[15:0];
          tb_check(v == 16'((first + p * SEG + i) * (c + 1)), "sample data / channel interleave");
        end
      end
    end
    // ping 1 without ack -> timeout
    @(negedge clk) trig = 1; @(negedge clk) trig = 0;
    repeat (5000) @(negedge clk);
    tb_check(psink.npk == 2 && psink.w[11] == 32'd0, "ack timeout reported in status word");
    tb_check(errors[15:0] == 16'd1, "ack timeout counted");
    // back-pressure: block the array sink -> dropped samples flagged
    block = 1;
    @(negedge clk) trig = 1; @(negedge clk) trig = 0;
    repeat (600) @(negedge clk);
    block = 0;
    repeat (4000) @(negedge clk);
    begin
      bit flagged;
      flagged = 0;
      for (int p = 3; p < asink.npk; p++) flagged |= (asink.p_flags[p] == 8'h84);
      tb_check(flagged && errors[31:16] > 0, $sformatf("drops flagged TRUNCATED|OVERRUN (%0d drops)", errors[31:16]));
    end
    tb_done("tb_sf_sonar_interface");
  end
endmodule
