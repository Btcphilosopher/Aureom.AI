// Behavioural AXI4 write-only slave memory for DMA testbenches.
// Randomised AWREADY/WREADY back-pressure and B-response latency when
// RANDOM=1; always-ready, one-cycle response when RANDOM=0 (efficiency runs).
module tb_axi_mem #(
  parameter int WORDS = 65536,
  parameter bit RANDOM = 1,
  parameter int SEED = 1
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [31:0] awaddr,
  input  logic [7:0]  awlen,
  input  logic        awvalid,
  output logic        awready,
  input  logic [31:0] wdata,
  input  logic        wlast,
  input  logic        wvalid,
  output logic        wready,
  output logic [1:0]  bresp,
  output logic        bvalid,
  input  logic        bready,
  input  logic        force_error
);
  logic [31:0] mem [0:WORDS-1];
  logic [31:0] addr_q;
  int          bdelay;
  logic        in_burst, resp_pending;
  int unsigned rs;
  initial begin
    rs = SEED;
    for (int i = 0; i < WORDS; i++) mem[i] = 32'hDEADBEEF;
  end
  function automatic bit rnd(input int pct);
    rs = rs * 1103515245 + 12345;
    rnd = ((rs >> 16) % 100) < pct;
  endfunction
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      awready <= 1'b0; wready <= 1'b0; bvalid <= 1'b0; bresp <= 2'b00; in_burst <= 1'b0; resp_pending <= 1'b0;
      addr_q <= '0; bdelay <= 0;
    end else begin
      awready <= !in_burst && !resp_pending && (RANDOM ? rnd(70) : 1'b1);
      wready  <= in_burst && (RANDOM ? rnd(75) : 1'b1);
      if (awvalid && awready) begin in_burst <= 1'b1; addr_q <= awaddr; awready <= 1'b0; end
      if (wvalid && wready) begin
        mem[(addr_q >> 2) % WORDS] <= wdata;
        addr_q <= addr_q + 32'd4;
        if (wlast) begin
          in_burst <= 1'b0; wready <= 1'b0; resp_pending <= 1'b1;
          bdelay <= RANDOM ? int'(rs % 5) : 0;
        end
      end
      if (resp_pending && !bvalid) begin
        if (bdelay == 0) begin bvalid <= 1'b1; bresp <= force_error ? 2'b10 : 2'b00; end
        else bdelay <= bdelay - 1;
      end
      if (bvalid && bready) begin bvalid <= 1'b0; resp_pending <= 1'b0; end
    end
  end
  task automatic dump(input string path, input int nwords);
    int fd;
    fd = $fopen(path, "w");
    for (int i = 0; i < nwords; i++) $fdisplay(fd, "%08x", mem[i]);
    $fclose(fd);
  endtask
endmodule
