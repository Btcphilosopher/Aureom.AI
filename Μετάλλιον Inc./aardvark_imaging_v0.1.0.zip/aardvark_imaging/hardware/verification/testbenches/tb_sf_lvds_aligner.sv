// LVDS fabric word aligner: every bit offset 0..W-1, data integrity after
// lock, and re-lock after an injected bit slip.
module tb_sf_lvds_aligner;
  `include "tb_common.svh"
  localparam int W = 14, L = 4;
  localparam logic [W-1:0] FP = 14'h3F80;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic in_valid = 0, out_valid, aligned, realign;
  logic [W-1:0] in_frame = 0;
  logic [L*W-1:0] in_data = 0, out_data;
  logic [3:0] slip;
  sf_lvds_aligner #(.W(W), .LANES(L), .FRAME_PATTERN(FP), .MATCH_N(6), .LOSS_N(3)) dut (
    .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_frame(in_frame), .in_data(in_data), .out_valid(out_valid),
    .out_data(out_data), .aligned(aligned), .slip(slip), .realign_evt(realign));
  // serial bit queues per lane (lane L = frame clock)
  bit fq[$];
  bit dq[L][$];
  function automatic logic [W-1:0] sample(input int n, input int l); sample = W'(n * 13 + l * 101 + 7); endfunction
  int nsent;
  task automatic push_sample(input int n);
    for (int b = W - 1; b >= 0; b--) begin
      fq.push_back(FP[b]);
      for (int l = 0; l < L; l++) begin
        logic [W-1:0] v;
        v = sample(n, l);
        dq[l].push_back(v[b]);
      end
    end
  endtask
  task automatic feed_word();
    @(negedge clk);
    in_valid = 1;
    for (int b = W - 1; b >= 0; b--) begin
      in_frame[b] = fq.pop_front();
      for (int l = 0; l < L; l++) in_data[l*W + b] = dq[l].pop_front();
    end
  endtask
  int good, firstn;
  logic [W-1:0] prev_lane0;
  bit have_prev;
  logic inv_q = 0;
  always @(posedge clk) begin
    if (rst_n && inv_q && !out_valid) have_prev = 0;   // gap in valid output: restart continuity
    inv_q <= in_valid;
  end
  always @(posedge clk) if (rst_n && out_valid) begin
    // data words must be consecutive samples: lane0(n+1) - lane0(n) == 13 mod 2^W, lanes consistent
    logic [W-1:0] l0;
    l0 = out_data[W-1:0];
    for (int l = 1; l < L; l++) tb_check(out_data[l*W +: W] == W'(l0 + W'(l * 101)), "lanes consistent");
    if (have_prev) tb_check(l0 == W'(prev_lane0 + 13), $sformatf("consecutive samples %0h -> %0h", prev_lane0, l0));
    prev_lane0 = l0; have_prev = 1; good++;
  end
  initial begin
    for (int off = 0; off < W; off++) begin
      rst_n = 0; fq.delete(); for (int l = 0; l < L; l++) dq[l].delete(); have_prev = 0; good = 0;
      repeat (2) @(negedge clk); rst_n = 1;
      // leading junk of `off` bits shifts the word boundary
      for (int b = 0; b < off; b++) begin fq.push_back(b[0]); for (int l = 0; l < L; l++) dq[l].push_back(1'b0); end
      for (int n = 0; n < 120; n++) push_sample(n);
      while (fq.size() >= W) feed_word();
      @(negedge clk) in_valid = 0;
      tb_check(aligned, $sformatf("aligned at offset %0d", off));
      tb_check(good > 60, $sformatf("offset %0d: %0d aligned words", off, good));
    end
    // bit slip mid-stream: insert one extra bit, expect loss of lock and relock
    begin
      int realigns = 0;
      rst_n = 0; fq.delete(); for (int l = 0; l < L; l++) dq[l].delete(); have_prev = 0; good = 0;
      repeat (2) @(negedge clk); rst_n = 1;
      for (int n = 0; n < 60; n++) push_sample(n);
      fq.push_back(1'b0); for (int l = 0; l < L; l++) dq[l].push_back(1'b0);
      for (int n = 60; n < 200; n++) push_sample(n);
      while (fq.size() >= W) begin feed_word(); if (realign) realigns++; end
      @(negedge clk) in_valid = 0;
      tb_check(realigns == 1, $sformatf("one realign event (%0d)", realigns));
      tb_check(aligned, "relocked after slip");
    end
    tb_done("tb_sf_lvds_aligner");
  end
endmodule
