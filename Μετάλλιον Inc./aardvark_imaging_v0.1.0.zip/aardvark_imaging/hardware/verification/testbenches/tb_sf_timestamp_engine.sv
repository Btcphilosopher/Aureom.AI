// Timestamp engine: monotonic count, coherent snapshot, 32-bit carry, 64-bit
// rollover flag, PPS latch/count, PPS-lost detection, event capture.
module tb_sf_timestamp_engine;
  `include "tb_common.svh"
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic snap_stb = 0, load_stb = 0, pps = 0, pps_pulse, pps_seen, roll, lost;
  logic [63:0] load_v = 0, ts, snap, pps_ts;
  logic [31:0] pps_count;
  logic [1:0] ev = 0;
  logic [127:0] ev_ts;
  sf_timestamp_engine #(.N_EVENTS(2), .PPS_TIMEOUT(32'd300)) dut (.clk(clk), .rst_n(rst_n), .snapshot_stb(snap_stb),
    .load_stb(load_stb), .load_value(load_v), .pps_async(pps), .event_pulse(ev), .ts_now(ts), .snap(snap), .pps_ts(pps_ts),
    .pps_count(pps_count), .pps_pulse(pps_pulse), .pps_seen(pps_seen), .rollover_evt(roll), .pps_lost_evt(lost), .event_ts(ev_ts));
  int rolls = 0, losts = 0;
  logic [63:0] prev;
  bit chk_mono = 0;
  always @(posedge clk) if (rst_n) begin
    if (roll) rolls++;
    if (lost) losts++;
  end
  always @(negedge clk) if (chk_mono) begin tb_check(ts == prev + 1, $sformatf("ts increments by one per cycle %0d %0d", ts, prev)); prev = ts; end
  initial begin
    repeat (3) @(posedge clk); rst_n = 1;
    @(negedge clk) prev = ts;
    @(posedge clk) #1 chk_mono = 1;
    repeat (50) @(negedge clk);
    chk_mono = 0;
    // snapshot
    @(negedge clk) snap_stb = 1;
    begin logic [63:0] t0; t0 = ts; @(negedge clk) snap_stb = 0; tb_check(snap == t0, "snapshot == counter at strobe"); end
    // event capture
    @(negedge clk) ev = 2'b10;
    begin logic [63:0] t1; t1 = ts; @(negedge clk) ev = 0; tb_check(ev_ts[127:64] == t1, "event ts captured"); end
    // 32-bit carry
    @(negedge clk) begin load_v = 64'h0000_0000_FFFF_FFF0; load_stb = 1; end
    @(negedge clk) load_stb = 0;
    repeat (31) @(negedge clk);
    tb_check(ts == 64'h0000_0001_0000_000F, $sformatf("carry into high word: %016h", ts));
    // 64-bit rollover
    @(negedge clk) begin load_v = 64'hFFFF_FFFF_FFFF_FFF8; load_stb = 1; end
    @(negedge clk) load_stb = 0;
    repeat (20) @(negedge clk);
    tb_check(rolls == 1, $sformatf("rollover flagged once (%0d)", rolls));
    tb_check(ts < 64'd32, "counter wrapped to small value");
    // PPS: asynchronous edges (not aligned to clk)
    for (int k = 0; k < 3; k++) begin
      logic [63:0] at;
      #(1003 + k * 17);
      at = ts; pps = 1;
      #77 pps = 0;
      repeat (8) @(negedge clk);
      tb_check(pps_ts >= at + 2 && pps_ts <= at + 5, $sformatf("pps latch latency %0d", int'(pps_ts - at)));
      tb_check(pps_count == 32'(k + 1), "pps count");
    end
    tb_check(pps_seen, "pps seen");
    repeat (400) @(negedge clk);
    tb_check(losts == 1, $sformatf("PPS lost raised once (%0d)", losts));
    repeat (400) @(negedge clk);
    tb_check(losts == 1, "PPS lost not repeated");
    tb_done("tb_sf_timestamp_engine");
  end
endmodule
