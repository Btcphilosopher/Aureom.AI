// IR ATR lock-in: ADC model returns DC + A_band when the source is on at
// conversion start. Expected demod = A*(H-S)*N, total = (2DC+A)*(H-S)*N
// exactly for every band, with signed (negative DC) samples.
module tb_sf_ir_controller;
  `include "tb_common.svh"
  localparam int H = 12, S = 3, NPER = 5, NB = 3, DC = -5000;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic en = 0, trig = 0;
  logic [63:0] ts = 0;
  always @(posedge clk) ts <= ts + 1;
  logic son, astart, avalid, abusy, aovr, cnv, sclk, csn, miso;
  logic [3:0] band;
  logic [17:0] adata;
  logic [0:0] sch, msel;
  sf_adc_interface #(.BITS(18), .LANES(1), .CLKDIV(2), .CNV_CYCLES(20), .MUX_W(1)) u_adc (.clk(clk), .rst_n(rst_n),
    .start(astart), .ch(1'b0), .busy(abusy), .start_overrun(aovr), .sample_valid(avalid), .sample_data(adata),
    .sample_ch(sch), .mux_sel(msel), .adc_cnv(cnv), .adc_sclk(sclk), .adc_cs_n(csn), .adc_miso(miso));
  logic sv, sr, sl, sevt;
  logic [31:0] sd, sfr, sm, status, sweeps;
  logic [7:0] sf;
  logic [15:0] srow;
  logic [63:0] sts;
  sf_ir_controller #(.SAMPLE_PERIOD(140), .BITS(18)) dut (.clk(clk), .rst_n(rst_n), .enable(en), .nbands(4'(NB)),
    .half_period(24'(H)), .nperiods(16'(NPER)), .settle(16'(S)), .trig(trig), .ts_now(ts), .source_on(son), .band_sel(band),
    .adc_start(astart), .adc_valid(avalid), .adc_data(adata), .src_valid(sv), .src_ready(sr), .src_data(sd), .src_last(sl),
    .src_flags(sf), .src_frame(sfr), .src_row(srow), .src_meta(sm), .src_ts(sts), .status(status), .sweeps(sweeps), .sweep_evt(sevt));
  tb_src_sink #(.READY_PCT(50), .SEED(13)) sink (.clk(clk), .rst_n(rst_n), .valid(sv), .ready(sr), .data(sd), .last(sl),
    .flags(sf), .frame(sfr), .row(srow), .meta(sm), .ts(sts));
  logic [17:0] sh;
  int amp [4] = '{1000, 2000, 3000, 4000};
  always @(posedge cnv) sh = 18'(DC + (son ? amp[band] : 0));
  always @(negedge csn) miso = sh[17];
  always @(negedge sclk) if (!csn) begin sh = sh << 1; miso = sh[17]; end
  initial begin
    miso = 0;
    repeat (4) @(posedge clk); rst_n = 1;
    @(negedge clk) en = 1;
    for (int sw = 0; sw < 2; sw++) begin
      @(negedge clk) trig = 1; @(negedge clk) trig = 0;
      wait (sink.npk == sw + 1); repeat (3) @(negedge clk);
      tb_check(sink.p_len[sw] == 4 * NB, "4 words per band");
      for (int b = 0; b < NB; b++) begin
        longint dm, tt, edm, ett;
        dm = longint'({sink.w[sink.p_start[sw] + 4*b + 1], sink.w[sink.p_start[sw] + 4*b]});
        tt = longint'({sink.w[sink.p_start[sw] + 4*b + 3], sink.w[sink.p_start[sw] + 4*b + 2]});
        edm = longint'(amp[b]) * (H - S) * NPER;
        ett = longint'(2 * DC + amp[b]) * (H - S) * NPER;
        tb_check(dm == edm, $sformatf("band %0d demod %0d exp %0d", b, dm, edm));
        tb_check(tt == ett, $sformatf("band %0d total %0d exp %0d", b, tt, ett));
      end
    end
    tb_check(sweeps == 32'd2 && !son, "sweeps counted, source off");
    tb_done("tb_sf_ir_controller");
  end
endmodule
