// Calibration engine: random raw/index/tag stream with random stalls,
// calibration RAM contents, cal_en and saturation thresholds. Checks order
// and an independent TB reference model; dumps every vector for the Python
// bit-exact model (tests/hardware/test_rtl_crosscheck.py).
module tb_sf_calibration_engine;
  `include "tb_common.svh"
  localparam int AW = 6;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic stall = 0, in_valid = 0, in_oob = 0, cal_en = 0, cal_we = 0;
  logic [15:0] in_raw = 0, sat = 16'h0FFF;
  logic [AW-1:0] in_index = 0, cal_waddr = 0;
  logic [3:0] in_tag = 0;
  logic [32:0] cal_wdata = 0;
  logic ov, os, ob, oc, ocal;
  logic [15:0] op;
  logic [3:0] ot;
  sf_calibration_engine #(.CAL_AW(AW), .TAG_W(4)) dut (.clk(clk), .rst_n(rst_n), .stall(stall), .in_valid(in_valid),
    .in_raw(in_raw), .in_index(in_index), .in_oob(in_oob), .in_tag(in_tag), .cal_en(cal_en), .sat_level(sat),
    .cal_we(cal_we), .cal_waddr(cal_waddr), .cal_wdata(cal_wdata), .out_valid(ov), .out_pix(op), .out_tag(ot),
    .out_sat(os), .out_bad(ob), .out_clip(oc), .out_cal(ocal));
  logic [32:0] calmem [0:(1<<AW)-1];
  typedef struct { int raw; int idx; bit oob; int tag; bit en; int satl; } vin_t;
  vin_t q[$];
  int unsigned rs = 77;
  int fd, nout = 0;
  function automatic int rnd(input int m); rs = rs * 1664525 + 1013904223; rnd = int'((rs >> 8) % m); endfunction
  function automatic int ref_pix(input vin_t v, output bit s, output bit b, output bit c, output bit k);
    int dark, gain, diff, y;
    bit bad;
    dark = v.oob ? 0 : int'(calmem[v.idx][15:0]);
    gain = v.oob ? 16384 : int'(calmem[v.idx][31:16]);
    bad  = v.oob ? 0 : calmem[v.idx][32];
    s = (v.raw >= v.satl); b = bad && v.en; k = v.en && !v.oob; c = 0;
    diff = (v.raw > dark) ? v.raw - dark : 0;
    y = int'((longint'(diff) * gain + 8192) >>> 14);
    if (b) ref_pix = 16'hFFFE;
    else if (s) ref_pix = 16'hFFFF;
    else if (v.en) begin if (y > 16'hFFFD) begin ref_pix = 16'hFFFD; c = 1; end else ref_pix = y; end
    else begin if (v.raw > 16'hFFFD) begin ref_pix = 16'hFFFD; c = 1; end else ref_pix = v.raw; end
  endfunction
  always @(posedge clk) if (rst_n && !stall && ov) begin
    vin_t v; bit s, b, c, k; int e;
    v = q.pop_front();
    e = ref_pix(v, s, b, c, k);
    tb_check(int'(op) == e, $sformatf("pix raw=%0d idx=%0d en=%0d: got %0h exp %0h", v.raw, v.idx, v.en, op, e));
    tb_check(int'(ot) == v.tag, "tag order");
    tb_check(os == s && ob == b && oc == c && ocal == k, "per-pixel flags");
    $fdisplay(fd, "%0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d", v.raw, v.oob ? 0 : int'(calmem[v.idx][15:0]),
              v.oob ? 16384 : int'(calmem[v.idx][31:16]), v.oob ? 0 : int'(calmem[v.idx][32]), v.oob, v.en, v.satl,
              op, os, ob, oc, ocal, v.idx);
    nout++;
  end
  initial begin
    fd = $fopen({`SF_VEC_DIR, "/calibration_engine_vectors.txt"}, "w");
    $fdisplay(fd, "# raw dark gain bad oob cal_en sat_level | out_pix sat bad clip cal | index");
    repeat (3) @(posedge clk); rst_n = 1;
    for (int i = 0; i < (1 << AW); i++) begin
      @(negedge clk);
      cal_we = 1; cal_waddr = AW'(i);
      cal_wdata = {(rnd(100) < 6), 16'(6000 + rnd(26000)), 16'(rnd(900))};
      if (i == 3) cal_wdata = {1'b0, 16'hFFFF, 16'd0};      // maximum gain: exercises clipping
      calmem[i] = cal_wdata;
    end
    @(negedge clk) cal_we = 0;
    for (int blk = 0; blk < 8; blk++) begin
      cal_en = blk[0]; sat = (blk < 4) ? 16'h0FFF : 16'hFFF0;
      for (int n = 0; n < 700; n++) begin
        @(negedge clk);
        stall = (rnd(100) < 30);
        if (!stall) begin
          vin_t v;
          in_valid = (rnd(100) < 85);
          begin
            int r;
            r = rnd(100);
            // mostly detector-range codes; some high codes reach the clip branch via the max-gain entry
            v.raw = (r < 3) ? 65535 - rnd(3) : (r < 12) ? 16000 + rnd(40000) : rnd(4500);
          end
          v.idx = (rnd(100) < 10) ? 3 : rnd(70); v.oob = (v.idx >= (1 << AW)); v.tag = rnd(16); v.en = cal_en; v.satl = int'(sat);
          if (v.oob) v.idx = v.idx - (1 << AW);
          in_raw = 16'(v.raw); in_index = AW'(v.idx); in_oob = v.oob; in_tag = 4'(v.tag);
          if (in_valid) q.push_back(v);
        end
      end
      @(negedge clk) begin in_valid = 0; stall = 0; end
      repeat (8) @(negedge clk);       // drain before changing quasi-static controls
    end
    tb_check(q.size() == 0, $sformatf("all inputs produced outputs (%0d left)", q.size()));
    tb_check(nout > 3000, $sformatf("vector count %0d", nout));
    $fclose(fd);
    tb_done("tb_sf_calibration_engine");
  end
endmodule
