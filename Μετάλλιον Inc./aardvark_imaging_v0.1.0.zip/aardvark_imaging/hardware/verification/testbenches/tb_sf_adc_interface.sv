// SAR ADC interface: CNV timing contract, quiet bus during conversion, mux
// latching, 2-lane read-back, start-while-busy rejection.
module tb_sf_adc_interface;
  `include "tb_common.svh"
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  localparam int CNV = 20;
  logic start = 0, busy, ovr, sv, cnv, sclk, cs_n;
  logic [1:0] ch = 0, sch, mux;
  logic [31:0] sd;
  logic [1:0] miso;
  sf_adc_interface #(.BITS(16), .LANES(2), .CLKDIV(2), .CNV_CYCLES(CNV), .MUX_W(2), .MUX_SETTLE(3)) dut (
    .clk(clk), .rst_n(rst_n), .start(start), .ch(ch), .busy(busy), .start_overrun(ovr), .sample_valid(sv),
    .sample_data(sd), .sample_ch(sch), .mux_sel(mux), .adc_cnv(cnv), .adc_sclk(sclk), .adc_cs_n(cs_n), .adc_miso(miso));
  // ADC model: conversion result latched on CNV falling edge; MSB valid at CS low; shift on SCLK falling.
  logic [15:0] v0, v1, s0, s1;
  int cnv_hi = 0, conv_n = 0;
  bit sclk_during_cnv = 0;
  always @(posedge clk) begin
    if (cnv) cnv_hi++;
    if (cnv && !cs_n) sclk_during_cnv = 1;
  end
  always @(negedge cnv) begin
    tb_check(cnv_hi >= CNV, $sformatf("CNV high %0d cycles", cnv_hi));
    cnv_hi = 0;
    v0 = 16'(16'h1000 * mux + 16'(conv_n * 7));
    v1 = 16'(16'hF000 - 16'(conv_n * 13));
    s0 = v0; s1 = v1; conv_n++;
  end
  always @(negedge cs_n) miso = {s1[15], s0[15]};
  always @(negedge sclk) if (!cs_n) begin s0 = s0 << 1; s1 = s1 << 1; miso = {s1[15], s0[15]}; end
  initial begin
    miso = 0;
    repeat (3) @(posedge clk); rst_n = 1;
    for (int i = 0; i < 24; i++) begin
      @(negedge clk) begin start = 1; ch = 2'(i % 4); end
      @(negedge clk) start = 0;
      // a second start while busy must be rejected
      if (i == 5) begin @(negedge clk) start = 1; #1 tb_check(ovr, "start_overrun while busy"); @(negedge clk) start = 0; end
      wait (sv);
      @(negedge clk);
      tb_check(sd[15:0] == v0, $sformatf("lane0 %0h exp %0h", sd[15:0], v0));
      tb_check(sd[31:16] == v1, $sformatf("lane1 %0h exp %0h", sd[31:16], v1));
      tb_check(sch == 2'(i % 4) && mux == 2'(i % 4), "channel latched");
    end
    tb_check(!sclk_during_cnv, "no CS/SCLK activity during conversion");
    tb_check(conv_n == 24, $sformatf("%0d conversions", conv_n));
    tb_done("tb_sf_adc_interface");
  end
endmodule
