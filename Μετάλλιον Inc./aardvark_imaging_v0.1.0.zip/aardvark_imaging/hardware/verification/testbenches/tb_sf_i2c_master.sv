// I2C master against a cycle-sampled slave model (address 0x48, register
// pointer + auto-increment, clock stretching after the address ACK).
module tb_sf_i2c_master;
  `include "tb_common.svh"
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic cmd_stb = 0, busy, done, ack_err, scl_oe, sda_oe;
  logic [2:0] cmd = 0;
  logic [7:0] cmd_data = 0, rx;
  logic s_sda_drv = 0, s_scl_hold = 0;
  wire scl = !(scl_oe || s_scl_hold);
  wire sda = !(sda_oe || s_sda_drv);
  sf_i2c_master dut (.clk(clk), .rst_n(rst_n), .prescale(16'd8), .cmd_stb(cmd_stb), .cmd(cmd), .cmd_data(cmd_data),
    .busy(busy), .done(done), .ack_err(ack_err), .rx_data(rx), .scl_i(scl), .sda_i(sda), .scl_oe(scl_oe), .sda_oe(sda_oe));

  // ---------------- slave model
  typedef enum {S_IDLE, S_RX, S_RX_ACK, S_TX, S_TX_ACK} st_e;
  st_e st = S_IDLE;
  logic scl_q = 1, sda_q = 1;
  logic [7:0] sh, regs [0:15];
  int bitn = 0, txbits = 0, stretch = 0;
  bit is_addr = 0, rw = 0, addr_ok = 0, ptr_set = 0, mack = 0;
  int ptr = 0, starts = 0, stops = 0, stretched = 0;
  always @(posedge clk) begin
    scl_q <= scl; sda_q <= sda;
    if (stretch > 0) begin stretch <= stretch - 1; if (stretch == 1) s_scl_hold <= 0; end
    if (scl && scl_q && sda_q && !sda) begin
      st <= S_RX; bitn <= 0; is_addr <= 1; s_sda_drv <= 0; starts <= starts + 1;
    end else if (scl && scl_q && !sda_q && sda) begin
      st <= S_IDLE; s_sda_drv <= 0; stops <= stops + 1; ptr_set <= 0;
    end else if (scl && !scl_q) begin
      if (st == S_RX) begin sh <= {sh[6:0], sda}; bitn <= bitn + 1; end
      if (st == S_TX) txbits <= txbits + 1;
      if (st == S_TX_ACK) mack <= !sda;
    end else if (!scl && scl_q) begin
      case (st)
        S_RX: if (bitn == 8) begin
          bit accept;
          accept = 1;
          if (is_addr) begin
            addr_ok <= (sh[7:1] == 7'h48); rw <= sh[0];
            accept = (sh[7:1] == 7'h48);
          end else if (!ptr_set) begin ptr <= int'(sh); ptr_set <= 1; end
          else begin regs[ptr[3:0]] <= sh; ptr <= ptr + 1; end
          s_sda_drv <= accept;
          st <= accept ? S_RX_ACK : S_IDLE;
        end
        S_RX_ACK: begin
          s_sda_drv <= 0;
          if (is_addr && addr_ok && rw) begin
            st <= S_TX; sh <= regs[ptr[3:0]]; s_sda_drv <= !regs[ptr[3:0]][7]; txbits <= 0; ptr <= ptr + 1;
          end else begin st <= S_RX; bitn <= 0; end
          if (is_addr) begin s_scl_hold <= 1; stretch <= 60; stretched <= stretched + 1; end
          is_addr <= 0;
        end
        S_TX: begin
          if (txbits == 8) begin s_sda_drv <= 0; st <= S_TX_ACK; end
          else s_sda_drv <= !sh[7 - txbits];
        end
        S_TX_ACK: begin
          if (mack) begin
            st <= S_TX; sh <= regs[ptr[3:0]]; s_sda_drv <= !regs[ptr[3:0]][7]; txbits <= 0; ptr <= ptr + 1;
          end else begin st <= S_IDLE; s_sda_drv <= 0; end
        end
        default: ;
      endcase
    end
  end

  task automatic do_cmd(input logic [2:0] c, input logic [7:0] d);
    @(negedge clk) begin cmd_stb = 1; cmd = c; cmd_data = d; end
    @(negedge clk) cmd_stb = 0;
    wait (done);
    @(negedge clk);
  endtask

  initial begin
    for (int i = 0; i < 16; i++) regs[i] = 8'h00;
    repeat (3) @(posedge clk); rst_n = 1;
    repeat (5) @(posedge clk);
    tb_check(scl && sda, "bus idle high");
    // write two bytes at register 5
    do_cmd(3'd1, 0); do_cmd(3'd2, 8'h90); tb_check(!ack_err, "addr W ACK");
    do_cmd(3'd2, 8'h05); tb_check(!ack_err, "ptr ACK");
    do_cmd(3'd2, 8'hA7); tb_check(!ack_err, "data0 ACK");
    do_cmd(3'd2, 8'h3C); tb_check(!ack_err, "data1 ACK");
    do_cmd(3'd5, 0);
    repeat (20) @(posedge clk);
    tb_check(regs[5] == 8'hA7 && regs[6] == 8'h3C, $sformatf("slave regs %0h %0h", regs[5], regs[6]));
    // set pointer, repeated start, read two bytes
    do_cmd(3'd1, 0); do_cmd(3'd2, 8'h90); do_cmd(3'd2, 8'h05);
    do_cmd(3'd1, 0); do_cmd(3'd2, 8'h91); tb_check(!ack_err, "addr R ACK");
    do_cmd(3'd3, 0); tb_check(rx == 8'hA7, $sformatf("read0 %0h", rx));
    do_cmd(3'd4, 0); tb_check(rx == 8'h3C, $sformatf("read1 %0h", rx));
    do_cmd(3'd5, 0);
    // wrong address is NACKed
    do_cmd(3'd1, 0); do_cmd(3'd2, 8'hA0); tb_check(ack_err, "NACK on wrong address");
    do_cmd(3'd5, 0);
    repeat (40) @(posedge clk);
    tb_check(starts == 4 && stops == 3, $sformatf("START/STOP counts %0d/%0d", starts, stops));
    tb_check(stretched >= 3, "clock stretching exercised");
    tb_check(scl && sda, "bus released after STOP");
    tb_done("tb_sf_i2c_master");
  end
endmodule
