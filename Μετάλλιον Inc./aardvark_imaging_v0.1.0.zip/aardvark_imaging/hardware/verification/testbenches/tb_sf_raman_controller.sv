// Raman acquisition with the real laser-timing and ADC-interface blocks and a
// CCD/ADC model: dark co-adds, light co-adds (laser only during integration,
// off during readout), saturation flag, interlock abort mid-integration and
// laser-not-armed timeout. All sums are checked exactly.
module tb_sf_raman_controller;
  `include "tb_common.svh"
  localparam int NP = 48, INTEG = 600;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic en = 0, dark = 0, trig = 0, sub = 1, arm = 0;
  logic [7:0] coadd = 1;
  logic [15:0] key = 0, satl = 16'hFFF0;
  logic [63:0] ts = 0;
  always @(posedge clk) ts <= ts + 1;
  logic lreq, lemit, labort, len, lmod, larmed, lilk, lwd, lstart;
  logic [3:0] lfault;
  sf_laser_timing u_l (.clk(clk), .rst_n(rst_n), .arm_stb(arm), .arm_key(key), .kick_stb(1'b0), .wd_timeout(32'd100000000),
    .pulsed(1'b0), .delay_cycles(32'd10), .pulse_width(32'd1), .pulse_period(32'd2), .max_on_sw(32'hFFFFFFFF),
    .submerged_async(sub), .overtemp(1'b0), .gate_req(lreq), .laser_enable(len), .laser_mod(lmod), .emitting(lemit),
    .armed(larmed), .interlock_ok(lilk), .wd_ok(lwd), .abort_evt(labort), .emit_start_evt(lstart), .fault_evt(lfault));
  logic astart, avalid, abusy, aovr, cnv, sclk, csn, miso, integ, cpix;
  logic [15:0] adata;
  logic [0:0] sch, msel;
  sf_adc_interface #(.BITS(16), .LANES(1), .CLKDIV(2), .CNV_CYCLES(20), .MUX_W(1)) u_adc (.clk(clk), .rst_n(rst_n),
    .start(astart), .ch(1'b0), .busy(abusy), .start_overrun(aovr), .sample_valid(avalid), .sample_data(adata),
    .sample_ch(sch), .mux_sel(msel), .adc_cnv(cnv), .adc_sclk(sclk), .adc_cs_n(csn), .adc_miso(miso));
  logic sv, sr, sl, ievt, eevt;
  logic [31:0] sd, sfr, sm, status, spectra, errors;
  logic [7:0] sf;
  logic [15:0] srow;
  logic [63:0] sts;
  sf_raman_controller #(.NPIX_MAX(64), .PIX_PERIOD(80), .LASER_WAIT(3000)) dut (.clk(clk), .rst_n(rst_n), .enable(en),
    .dark_mode(dark), .coadd(coadd), .npix(12'(NP)), .integ_cycles(32'(INTEG)), .sat_level(satl), .trig(trig), .ts_now(ts),
    .laser_gate_req(lreq), .laser_emitting(lemit), .laser_abort(labort), .ccd_integrate(integ), .ccd_pixel(cpix),
    .adc_start(astart), .adc_valid(avalid), .adc_data(adata), .src_valid(sv), .src_ready(sr), .src_data(sd), .src_last(sl),
    .src_flags(sf), .src_frame(sfr), .src_row(srow), .src_meta(sm), .src_ts(sts), .status(status), .spectra(spectra),
    .errors(errors), .integ_evt(ievt), .error_evt(eevt));
  tb_src_sink #(.READY_PCT(60), .SEED(11)) sink (.clk(clk), .rst_n(rst_n), .valid(sv), .ready(sr), .data(sd), .last(sl),
    .flags(sf), .frame(sfr), .row(srow), .meta(sm), .ts(sts));
  // CCD + ADC model: exposure k accumulates laser photons only while the laser emits during integration
  int lit_cycles = 0, pix_i = 0, laser_during_read = 0, gain_sig = 1;
  logic integ_q = 0;
  logic [15:0] sh;
  function automatic int ccd(input int i, input int lit);
    int sig;
    sig = (i == 20) ? 900 : (i == 33) ? 400 : (i > 25 && i < 30) ? 120 : 15;
    ccd = 100 + i + ((lit > 0) ? sig * gain_sig : 0);
    if (ccd > 65535) ccd = 65535;
  endfunction
  int cur_lit = 0;
  always @(negedge clk) if (rst_n) begin
    if (integ && len) lit_cycles++;
    if (integ_q && !integ) begin cur_lit = lit_cycles; lit_cycles = 0; pix_i = 0; end
    if (!integ && cpix && len) laser_during_read++;
    integ_q = integ;
  end
  always @(negedge cnv) begin sh = 16'(ccd(pix_i, cur_lit)); pix_i++; end
  always @(negedge csn) miso = sh[15];
  always @(negedge sclk) if (!csn) begin sh = sh << 1; miso = sh[15]; end

  task automatic acquire(input bit d, input int n);
    @(negedge clk) begin dark = d; coadd = 8'(n); trig = 1; end
    @(negedge clk) trig = 0;
  endtask
  task automatic check_spectrum(input int p, input int n, input bit lit, input string tag);
    for (int i = 0; i < NP; i++) begin
      int e;
      e = n * ccd(i, lit ? 1 : 0);
      tb_check(int'(sink.w[sink.p_start[p] + i]) == e, $sformatf("%s pix %0d = %0d exp %0d", tag, i, sink.w[sink.p_start[p] + i], e));
    end
    tb_check(sink.p_len[p] == NP, $sformatf("%s length %0d", tag, sink.p_len[p]));
    tb_check(int'(sink.p_meta[p][31:24]) == n && int'(sink.p_meta[p][11:0]) == NP, "meta coadd/npix");
    tb_check(sink.p_flags[p][5] == !lit && sink.p_flags[p][4] == lit, $sformatf("%s DARK/LASER_ON flags %0h", tag, sink.p_flags[p]));
  endtask
  initial begin
    miso = 0;
    repeat (4) @(posedge clk); rst_n = 1;
    @(negedge clk) en = 1;
    // 1. dark, 3 co-adds
    acquire(1, 3); wait (sink.npk == 1); repeat (5) @(negedge clk);
    check_spectrum(0, 3, 0, "dark");
    // 2. light without arming -> laser wait timeout abort
    acquire(0, 1); repeat (5000) @(negedge clk);
    tb_check(errors[15:0] == 16'd1 && sink.npk == 1, $sformatf("unarmed light acquisition aborts (%0d)", errors[15:0]));
    // arm
    @(negedge clk) begin arm = 1; key = 16'hA55A; end @(negedge clk) arm = 0;
    tb_check(larmed, "laser armed");
    // 3. light, 2 co-adds
    acquire(0, 2); wait (sink.npk == 2); repeat (5) @(negedge clk);
    check_spectrum(1, 2, 1, "light");
    tb_check(laser_during_read == 0, "laser off during CCD readout");
    tb_check(!len, "laser off after acquisition");
    // 4. saturation flag
    satl = 16'd1000; acquire(0, 1); wait (sink.npk == 3); repeat (5) @(negedge clk);
    tb_check(sink.p_flags[2][0], "SATURATED flagged");
    satl = 16'hFFF0;
    // 5. interlock drop mid-integration -> abort, no spectrum
    acquire(0, 1);
    wait (integ); repeat (100) @(negedge clk);
    sub = 0; repeat (20) @(negedge clk);
    tb_check(!len && !integ, "emission and integration stopped");
    repeat (6000) @(negedge clk);
    tb_check(sink.npk == 3, "aborted acquisition emitted nothing");
    tb_check(errors[15:0] == 16'd2, $sformatf("laser abort counted (%0d)", errors[15:0]));
    tb_check(spectra == 32'd3, "spectrum counter");
    tb_done("tb_sf_raman_controller");
  end
endmodule
