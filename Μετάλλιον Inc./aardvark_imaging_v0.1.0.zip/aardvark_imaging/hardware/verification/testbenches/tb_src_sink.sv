// Testbench packet sink for sensor-controller source ports. Accepts words
// with programmable random back-pressure and records packets (descriptor +
// payload) for the checking process.
module tb_src_sink #(parameter int READY_PCT = 100, parameter int SEED = 1) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        valid,
  output logic        ready,
  input  logic [31:0] data,
  input  logic        last,
  input  logic [7:0]  flags,
  input  logic [31:0] frame,
  input  logic [15:0] row,
  input  logic [31:0] meta,
  input  logic [63:0] ts
);
  int unsigned rs = SEED;
  int npk = 0, nw = 0, cur = 0;
  logic [31:0] w [int];
  int          p_start [int], p_len [int], p_frame [int], p_row [int];
  logic [7:0]  p_flags [int];
  logic [31:0] p_meta [int];
  logic [63:0] p_ts [int];
  always @(negedge clk) begin rs = rs * 1103515245 + 12345; ready = ((rs >> 16) % 100) < READY_PCT; end
  always @(posedge clk) if (rst_n && valid && ready) begin
    w[nw] = data; nw++; cur++;
    if (last) begin
      p_start[npk] = nw - cur; p_len[npk] = cur; p_frame[npk] = int'(frame); p_row[npk] = int'(row);
      p_flags[npk] = flags; p_meta[npk] = meta; p_ts[npk] = ts; npk++; cur = 0;
    end
  end
  function automatic logic [15:0] pix(input int p, input int i);
    logic [31:0] x; x = w[p_start[p] + i / 2]; pix = (i % 2) ? x[31:16] : x[15:0];
  endfunction
endmodule
