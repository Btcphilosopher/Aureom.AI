// Fluorometer: 3-lane ADC model with per-(excitation, emission) response and
// ambient offsets; masked excitation reports zeros; exact on-off sums.
module tb_sf_fluorescence_controller;
  `include "tb_common.svh"
  localparam int ON = 10, BL = 2, NP = 4;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic en = 0, trig = 0;
  logic [63:0] ts = 0;
  always @(posedge clk) ts <= ts + 1;
  logic [2:0] led, miso;
  logic astart, avalid, abusy, aovr, cnv, sclk, csn;
  logic [47:0] adata;
  logic [0:0] sch, msel;
  sf_adc_interface #(.BITS(16), .LANES(3), .CLKDIV(2), .CNV_CYCLES(20), .MUX_W(1)) u_adc (.clk(clk), .rst_n(rst_n),
    .start(astart), .ch(1'b0), .busy(abusy), .start_overrun(aovr), .sample_valid(avalid), .sample_data(adata),
    .sample_ch(sch), .mux_sel(msel), .adc_cnv(cnv), .adc_sclk(sclk), .adc_cs_n(csn), .adc_miso(miso));
  logic sv, sr, sl, bevt;
  logic [31:0] sd, sfr, sm, status, blocks;
  logic [7:0] sf;
  logic [15:0] srow;
  logic [63:0] sts;
  sf_fluorescence_controller #(.SAMPLE_PERIOD(130)) dut (.clk(clk), .rst_n(rst_n), .enable(en), .exc_mask(3'b101),
    .on_samples(16'(ON)), .blank_samples(16'(BL)), .npulses(16'(NP)), .trig(trig), .ts_now(ts), .led(led),
    .adc_start(astart), .adc_valid(avalid), .adc_data(adata), .src_valid(sv), .src_ready(sr), .src_data(sd), .src_last(sl),
    .src_flags(sf), .src_frame(sfr), .src_row(srow), .src_meta(sm), .src_ts(sts), .status(status), .blocks(blocks), .block_evt(bevt));
  tb_src_sink #(.READY_PCT(70), .SEED(17)) sink (.clk(clk), .rst_n(rst_n), .valid(sv), .ready(sr), .data(sd), .last(sl),
    .flags(sf), .frame(sfr), .row(srow), .meta(sm), .ts(sts));
  int M [3][3] = '{'{300, 50, 5}, '{20, 800, 40}, '{2, 30, 1200}};
  int AMB [3] = '{1000, 2000, 3000};
  logic [15:0] s [3];
  int multi_led = 0;
  always @(posedge clk) if (rst_n && led != 0 && (led & (led - 1)) != 0) multi_led++;
  always @(posedge cnv) for (int c = 0; c < 3; c++) begin
    int v; v = AMB[c];
    for (int e = 0; e < 3; e++) if (led[e]) v += M[e][c];
    s[c] = 16'(v);
  end
  always @(negedge csn) for (int c = 0; c < 3; c++) miso[c] = s[c][15];
  always @(negedge sclk) if (!csn) for (int c = 0; c < 3; c++) begin s[c] = s[c] << 1; miso[c] = s[c][15]; end
  initial begin
    miso = 0;
    repeat (4) @(posedge clk); rst_n = 1;
    @(negedge clk) en = 1;
    @(negedge clk) trig = 1; @(negedge clk) trig = 0;
    wait (sink.npk == 1); repeat (3) @(negedge clk);
    tb_check(sink.p_len[0] == 18, "18-word block");
    for (int e = 0; e < 3; e++) for (int c = 0; c < 3; c++) begin
      int d, o, ed, eo;
      d = int'(sink.w[sink.p_start[0] + 6*e + 2*c]); o = int'(sink.w[sink.p_start[0] + 6*e + 2*c + 1]);
      ed = (e == 1) ? 0 : M[e][c] * (ON - BL) * NP;
      eo = (e == 1) ? 0 : AMB[c] * (ON - BL) * NP;
      tb_check(d == ed && o == eo, $sformatf("exc %0d em %0d: diff %0d exp %0d, off %0d exp %0d", e, c, d, ed, o, eo));
    end
    tb_check(multi_led == 0 && led == 0, "one LED at a time, all off at end");
    tb_done("tb_sf_fluorescence_controller");
  end
endmodule
