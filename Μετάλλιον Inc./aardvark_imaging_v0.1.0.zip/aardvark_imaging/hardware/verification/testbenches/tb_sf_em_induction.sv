// EM induction: DDS + quarter-wave ROM + 2-lane ADC + I/Q accumulation.
// The ADC model synthesises receiver and reference signals with known
// amplitude and phase at each conversion's DDS phase. Checks amplitude and
// phase recovery and dumps every integrated sample with the DUT accumulators
// for the Python bit-exact model.
module tb_sf_em_induction;
  `include "tb_common.svh"
  localparam logic [31:0] FTW = 32'd134217728;   // f_s / 32
  localparam int NS = 1600;
  localparam real A_RX = 9000.0, A_RF = 20000.0, TH_RX = 37.0, TH_RF = -12.0;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic en = 0, trig = 0;
  logic [63:0] ts = 0;
  always @(posedge clk) ts <= ts + 1;
  logic signed [15:0] dac;
  logic dload, astart, avalid, abusy, aovr, cnv, sclk, csn;
  logic [1:0] miso;
  logic [31:0] adata;
  logic [0:0] sch, msel;
  sf_adc_interface #(.BITS(16), .LANES(2), .CLKDIV(2), .CNV_CYCLES(10), .MUX_W(1)) u_adc (.clk(clk), .rst_n(rst_n),
    .start(astart), .ch(1'b0), .busy(abusy), .start_overrun(aovr), .sample_valid(avalid), .sample_data(adata),
    .sample_ch(sch), .mux_sel(msel), .adc_cnv(cnv), .adc_sclk(sclk), .adc_cs_n(csn), .adc_miso(miso));
  logic sv, sr, sl, ievt;
  logic [31:0] sd, sfr, sm, status, recs;
  logic [7:0] sf;
  logic [15:0] srow;
  logic [63:0] sts;
  sf_em_induction #(.SAMPLE_DIV(100), .ROM_FILE(`SF_ROM_FILE)) dut (.clk(clk), .rst_n(rst_n), .enable(en), .tx_en(1'b1),
    .ftw(FTW), .amplitude(16'h8000), .nsamp(24'(NS)), .trig(trig), .ts_now(ts), .dac_data(dac), .dac_load(dload),
    .adc_start(astart), .adc_valid(avalid), .adc_data(adata), .src_valid(sv), .src_ready(sr), .src_data(sd),
    .src_last(sl), .src_flags(sf), .src_frame(sfr), .src_row(srow), .src_meta(sm), .src_ts(sts), .status(status),
    .records(recs), .integ_evt(ievt));
  tb_src_sink #(.READY_PCT(100), .SEED(29)) sink (.clk(clk), .rst_n(rst_n), .valid(sv), .ready(sr), .data(sd), .last(sl),
    .flags(sf), .frame(sfr), .row(srow), .meta(sm), .ts(sts));
  int kconv = -1, fd, nint = 0;
  logic [15:0] s0, s1;
  real pi = 3.14159265358979;
  always @(posedge cnv) begin
    real ph;
    kconv++;
    ph = 2.0 * pi * real'((longint'(kconv) * longint'(FTW)) % 64'd4294967296) / 4294967296.0;
    s0 = 16'($rtoi(A_RX * $sin(ph + TH_RX * pi / 180.0) + (A_RX * $sin(ph + TH_RX * pi / 180.0) >= 0 ? 0.5 : -0.5)));
    s1 = 16'($rtoi(A_RF * $sin(ph + TH_RF * pi / 180.0) + (A_RF * $sin(ph + TH_RF * pi / 180.0) >= 0 ? 0.5 : -0.5)));
  end
  always @(negedge csn) miso = {s1[15], s0[15]};
  always @(negedge sclk) if (!csn) begin s0 = s0 << 1; s1 = s1 << 1; miso = {s1[15], s0[15]}; end
  // record samples that the DUT will integrate (state checked at negedge)
  always @(negedge clk) if (rst_n && avalid && dut.st == 2'd1 && dut.ref_ready) begin
    $fdisplay(fd, "S %0d %0d %0d", kconv, $signed(adata[15:0]), $signed(adata[31:16])); nint++;
  end
  initial begin
    miso = 0;
    fd = $fopen({`SF_VEC_DIR, "/em_iq_vectors.txt"}, "w");
    $fdisplay(fd, "# FTW %0d NSAMP %0d  lines: S k rx ref ; R rx_i rx_q ref_i ref_q n", FTW, NS);
    repeat (4) @(posedge clk); rst_n = 1;
    @(negedge clk) en = 1;
    repeat (3000) @(negedge clk);
    @(negedge clk) trig = 1; @(negedge clk) trig = 0;
    wait (sink.npk == 1); repeat (3) @(negedge clk);
    begin
      longint ri, rq, fi, fq, n;
      real arx, arf, prx, prf, scale;
      ri = longint'({sink.w[1], sink.w[0]}); rq = longint'({sink.w[3], sink.w[2]});
      fi = longint'({sink.w[5], sink.w[4]}); fq = longint'({sink.w[7], sink.w[6]});
      n = longint'(sink.w[8]);
      $fdisplay(fd, "R %0d %0d %0d %0d %0d", ri, rq, fi, fq, n);
      scale = real'(n) * 32767.0 / 2.0;
      arx = $sqrt(real'(ri) * real'(ri) + real'(rq) * real'(rq)) / scale;
      arf = $sqrt(real'(fi) * real'(fi) + real'(fq) * real'(fq)) / scale;
      prx = $atan2(real'(rq), real'(ri)) * 180.0 / pi;
      prf = $atan2(real'(fq), real'(fi)) * 180.0 / pi;
      $display("EM: |rx| %0.2f (%0.0f)  |ref| %0.2f (%0.0f)  ph_rx %0.3f (%0.1f)  ph_ref %0.3f (%0.1f)", arx, A_RX, arf, A_RF, prx, TH_RX, prf, TH_RF);
      tb_check(n == NS && nint == NS, $sformatf("integration length %0d / %0d", n, nint));
      tb_check(arx > A_RX * 0.995 && arx < A_RX * 1.005, "receiver amplitude within 0.5%");
      tb_check(arf > A_RF * 0.995 && arf < A_RF * 1.005, "reference amplitude within 0.5%");
      tb_check(prx > TH_RX - 0.5 && prx < TH_RX + 0.5, "receiver phase within 0.5 deg");
      tb_check(prf > TH_RF - 0.5 && prf < TH_RF + 0.5, "reference phase within 0.5 deg");
      tb_check((prx - prf) > 48.5 && (prx - prf) < 49.5, "secondary/primary phase difference");
      tb_check(sink.p_meta[0] == FTW, "record carries FTW");
    end
    $fclose(fd);
    tb_done("tb_sf_em_induction");
  end
endmodule
