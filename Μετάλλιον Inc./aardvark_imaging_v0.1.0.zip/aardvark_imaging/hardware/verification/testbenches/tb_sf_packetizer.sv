// Packetiser: 3 sources, random lengths/descriptors, random output
// back-pressure, test_mode. Checks framing, per-source ordering, global
// sequence, header fields and CRC (byte-wise reference, independent of the
// RTL bit-serial implementation). Dumps the stream for zlib verification.
module tb_sf_packetizer;
  `include "tb_common.svh"
  localparam int N = 3, SAW = 6;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic test_mode = 0;
  // Per-source driver signals are separate variables combined by continuous
  // assignment (no shared vector written from several processes).
  logic [N-1:0] sv, sr, sl;
  logic [32*N-1:0] sd, sfr, sm;
  logic [8*N-1:0] sf;
  logic [16*N-1:0] srow;
  logic [64*N-1:0] sts;
  logic mv, mr = 0, ml, msop;
  logic [31:0] md, seq;
  logic [15:0] mlen, hwm;
  sf_packetizer #(.N(N), .SRC_UID({8'h33, 8'h22, 8'h11}), .SRC_PTYPE({8'h0C, 8'h04, 8'h01}), .STAGE_AW(SAW)) dut (
    .clk(clk), .rst_n(rst_n), .test_mode(test_mode), .s_valid(sv), .s_ready(sr), .s_data(sd), .s_last(sl), .s_flags(sf),
    .s_frame(sfr), .s_row(srow), .s_meta(sm), .s_ts(sts), .m_valid(mv), .m_ready(mr), .m_data(md), .m_last(ml),
    .m_sop(msop), .m_len(mlen), .seq(seq), .stage_hwm(hwm));
  sf_stream_checker #(.DW(32)) chk (.clk(clk), .rst_n(rst_n), .valid(mv), .ready(mr), .data(md), .last(ml));
  typedef struct { int src; int len; logic [7:0] flags; logic [31:0] frame; logic [15:0] row; logic [31:0] meta; logic [63:0] ts; } pkt_t;
  // expectation store keyed by (source, packet number); associative arrays
  // avoid per-source queue arrays shared across generate blocks
  pkt_t exp_d [int];
  logic [31:0] exp_w [int];
  logic [31:0] wbuf [N][0:63];
  int rx_n [N] = '{0, 0, 0};
  int unsigned rs = 3;
  function automatic int rnd(input int m); rs = rs * 1664525 + 1013904223; rnd = int'((rs >> 8) % m); endfunction
  function automatic logic [31:0] crc_bytes(input logic [31:0] c, input logic [31:0] w);
    logic [31:0] x;
    x = c;
    for (int by = 0; by < 4; by++) begin
      x = x ^ {24'd0, w[8*by +: 8]};
      for (int k = 0; k < 8; k++) x = x[0] ? ((x >> 1) ^ 32'hEDB88320) : (x >> 1);
    end
    crc_bytes = x;
  endfunction
  // source drivers
  int sent [N] = '{0, 0, 0};
  localparam int NPK = 60;
  genvar g;
  generate for (g = 0; g < N; g++) begin : gs
    logic v_l = 0, l_l = 0;
    logic [31:0] d_l = 0, fr_l = 0, m_l = 0;
    logic [7:0] f_l = 0;
    logic [15:0] r_l = 0;
    logic [63:0] t_l = 0;
    assign sv[g] = v_l; assign sl[g] = l_l; assign sd[32*g +: 32] = d_l; assign sfr[32*g +: 32] = fr_l;
    assign sm[32*g +: 32] = m_l; assign sf[8*g +: 8] = f_l; assign srow[16*g +: 16] = r_l; assign sts[64*g +: 64] = t_l;
    initial begin
      @(posedge rst_n);
      for (int p = 0; p < NPK; p++) begin
        pkt_t k;
        k.src = g; k.len = 1 + rnd(1 << SAW); k.flags = 8'(rnd(64)); k.frame = 32'(rnd(1 << 30)); k.row = 16'(rnd(65536));
        k.meta = 32'(rnd(1 << 30)); k.ts = {32'(rnd(1 << 30)), 32'(rnd(1 << 30))};
        for (int i = 0; i < k.len; i++) wbuf[g][i] = 32'(rnd(1 << 30)) ^ 32'(i << 30);
        for (int i = 0; i < k.len; i++) exp_w[g * 1000000 + p * 100 + i] = wbuf[g][i];
        for (int i = 0; i < k.len; i++) begin
          @(negedge clk);
          while (rnd(100) < 20) @(negedge clk);
          v_l = 1; d_l = wbuf[g][i]; l_l = (i == k.len - 1);
          if (i == k.len - 1) begin
            k.flags = (k.flags & 8'hBF) | (test_mode ? 8'h40 : 8'h00); exp_d[g * 1000 + p] = k;
            f_l = k.flags & 8'hBF; fr_l = k.frame; r_l = k.row; m_l = k.meta; t_l = k.ts;
          end
          // ready is registered-derived and stable at negedge: if high now, the next edge accepts
          while (!sr[g]) @(negedge clk);
          @(posedge clk);
          @(negedge clk) v_l = 0;
        end
        sent[g]++;
      end
    end
  end endgenerate
  // sink
  int fd, got = 0, widx = 0;
  logic [31:0] cur [$];
  logic [31:0] exp_seq = 0;
  always @(negedge clk) mr = (rnd(100) < 70);
  always @(posedge clk) if (rst_n && mv && mr) begin
    $fdisplay(fd, "%08x", md);
    cur.push_back(md);
    if (widx == 0) tb_check(msop && md == 32'h53465031, "SOP carries SYNC");
    widx++;
    if (ml) begin
      int s, len; pkt_t e; logic [31:0] c;
      len = int'(cur[6] >> 16);
      tb_check(cur.size() == 9 + len, $sformatf("length %0d words for payload %0d", cur.size(), len));
      s = (cur[1][23:16] == 8'h11) ? 0 : (cur[1][23:16] == 8'h22) ? 1 : 2;
      tb_check(exp_d.exists(s * 1000 + rx_n[s]), "expected descriptor present");
      e = exp_d[s * 1000 + rx_n[s]];
      tb_check(cur[1][31:24] == 8'd1, "version");
      tb_check(cur[1][15:8] == ((s == 0) ? 8'h01 : (s == 1) ? 8'h04 : 8'h0C), "packet type per source");
      tb_check(cur[1][7:0] == e.flags, $sformatf("flags %0h exp %0h", cur[1][7:0], e.flags));
      tb_check(cur[2] == exp_seq, "global sequence");
      tb_check(cur[3] == e.frame && {cur[4], cur[5]} == e.ts && cur[6][15:0] == e.row && cur[7] == e.meta, "descriptor fields");
      tb_check(len == e.len, "payload length");
      for (int i = 0; i < e.len && i < len; i++) tb_check(cur[8 + i] == exp_w[s * 1000000 + rx_n[s] * 100 + i], "payload word");
      rx_n[s]++;
      c = 32'hFFFFFFFF;
      for (int i = 0; i < cur.size() - 1; i++) c = crc_bytes(c, cur[i]);
      tb_check(cur[cur.size() - 1] == ~c, "CRC-32");
      exp_seq++; got++; widx = 0; cur.delete();
    end
  end
  initial begin
    fd = $fopen({`SF_VEC_DIR, "/packetizer_stream.hex"}, "w");
    repeat (3) @(posedge clk); rst_n = 1;
    #20000 test_mode = 1;
    #40000 test_mode = 0;
    wait (sent[0] == NPK && sent[1] == NPK && sent[2] == NPK);
    repeat (3000) @(posedge clk);
    tb_check(got == N * NPK, $sformatf("received %0d packets", got));
    tb_check(hwm > 16'd8, "staging high-water mark tracked");
    $fclose(fd);
    tb_done("tb_sf_packetizer");
  end
endmodule
