// Async FIFO: two instances (fast->slow, slow->fast) with independent
// randomised traffic, scoreboards, and drain checks.
module tb_sf_async_fifo;
  `include "tb_common.svh"
  logic ca = 0, cb = 0, rst_n = 0;
  always #3.5 ca = ~ca;     // ~143 MHz
  always #6.1 cb = ~cb;     // ~82 MHz
  int unsigned rs = 99;
  function automatic int rnd(input int m); rs = rs * 1664525 + 1013904223; rnd = int'((rs >> 8) % m); endfunction

  // instance 0: write ca, read cb ; instance 1: write cb, read ca
  logic w_en [2], r_en [2], wf [2], ov [2], rv [2];
  logic [17:0] wd [2], rd [2];
  logic [4:0] wl [2], rl [2];
  sf_async_fifo #(.DW(18), .AW(4)) f0 (.wclk(ca), .wrst_n(rst_n), .wr_en(w_en[0]), .wr_data(wd[0]), .wfull(wf[0]),
    .overflow(ov[0]), .wlevel(wl[0]), .rclk(cb), .rrst_n(rst_n), .rd_en(r_en[0]), .rd_data(rd[0]), .rd_valid(rv[0]), .rlevel(rl[0]));
  sf_async_fifo #(.DW(18), .AW(4)) f1 (.wclk(cb), .wrst_n(rst_n), .wr_en(w_en[1]), .wr_data(wd[1]), .wfull(wf[1]),
    .overflow(ov[1]), .wlevel(wl[1]), .rclk(ca), .rrst_n(rst_n), .rd_en(r_en[1]), .rd_data(rd[1]), .rd_valid(rv[1]), .rlevel(rl[1]));
  int q0[$], q1[$];
  int wr_cnt [2] = '{0, 0};
  int rd_cnt [2] = '{0, 0};
  bit stop_w = 0;

  always @(posedge ca) if (rst_n) begin
    if (w_en[0] && !wf[0]) begin q0.push_back(int'(wd[0])); wr_cnt[0]++; end
    if (r_en[1] && rv[1]) begin int e; e = q1.pop_front(); rd_cnt[1]++; tb_check(int'(rd[1]) == e, "f1 order"); end
  end
  always @(posedge cb) if (rst_n) begin
    if (w_en[1] && !wf[1]) begin q1.push_back(int'(wd[1])); wr_cnt[1]++; end
    if (r_en[0] && rv[0]) begin int e; e = q0.pop_front(); rd_cnt[0]++; tb_check(int'(rd[0]) == e, "f0 order"); end
  end
  always @(negedge ca) begin
    w_en[0] = rst_n && !stop_w && (rnd(100) < 60); wd[0] = 18'(rnd(262144));
    r_en[1] = rst_n && rv[1] && (stop_w || rnd(100) < 70);
  end
  always @(negedge cb) begin
    w_en[1] = rst_n && !stop_w && (rnd(100) < 60); wd[1] = 18'(rnd(262144));
    r_en[0] = rst_n && rv[0] && (stop_w || rnd(100) < 70);
  end
  initial begin
    w_en = '{0, 0}; r_en = '{0, 0}; wd = '{0, 0};
    #50 rst_n = 1;
    #200000;
    stop_w = 1;
    #5000;
    tb_check(q0.size() == 0 && q1.size() == 0, $sformatf("drained (%0d,%0d)", q0.size(), q1.size()));
    tb_check(wr_cnt[0] == rd_cnt[0] && wr_cnt[1] == rd_cnt[1], "no loss / duplication");
    tb_check(wr_cnt[0] > 5000 && wr_cnt[1] > 5000, $sformatf("traffic volume %0d %0d", wr_cnt[0], wr_cnt[1]));
    tb_done("tb_sf_async_fifo");
  end
endmodule
