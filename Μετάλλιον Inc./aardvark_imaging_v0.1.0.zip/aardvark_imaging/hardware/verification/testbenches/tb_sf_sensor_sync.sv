// Sensor synchronisation: frame period, divisors, offsets (fixed latency
// OFFSET+2), widths, overrun when offset exceeds the period, PPS alignment
// and external sync.
module tb_sf_sensor_sync;
  `include "tb_common.svh"
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic en = 0, ext_en = 0, pps_al = 0, ext = 0, pps_p = 0, tick, ovr;
  logic [31:0] period = 100, fidx;
  logic [7:0] mask = 0, tp, to;
  logic [255:0] div = 0, off = 0;
  sf_sensor_sync dut (.clk(clk), .rst_n(rst_n), .enable(en), .ext_sync_en(ext_en), .pps_align(pps_al), .frame_period(period),
    .trig_mask(mask), .trig_div(div), .trig_offset(off), .ext_sync_async(ext), .pps_pulse(pps_p), .frame_tick(tick),
    .frame_index(fidx), .trig_pulse(tp), .trig_out(to), .overrun_evt(ovr));
  longint cyc = 0, last_tick = -1, last_t0 = -1, last_t1 = -1, last_tick_for1 = -1;
  int nt = 0, n0 = 0, n1 = 0, novr = 0, w0 = 0, wmax = 0, bad_period = 0, bad_lat = 0, ticks_since = 0;
  always @(posedge clk) begin
    cyc++;
    if (rst_n) begin
      if (tick) begin
        if (last_tick >= 0 && !ext_en && (cyc - last_tick) != longint'(period)) bad_period++;
        last_tick = cyc; nt++;
      end
      if (tp[0]) begin
        if ((cyc - last_tick) != 12) bad_lat++;
        n0++;
      end
      if (tp[1]) n1++;
      if (ovr) novr++;
      if (to[0]) w0++; else begin if (w0 > wmax) wmax = w0; w0 = 0; end
    end
  end
  initial begin
    repeat (3) @(posedge clk); rst_n = 1;
    div[15:0] = 16'd1; div[31:16] = 16'd5; off[31:0] = 32'd10;           // ch0: every frame, +10, 5 wide
    div[47:32] = 16'd3; div[63:48] = 16'd2; off[63:32] = 32'd0;          // ch1: every 3rd frame
    div[79:64] = 16'd1; div[95:80] = 16'd1; off[95:64] = 32'd150;        // ch2: offset > period -> overrun
    mask = 8'b0000_0011;
    @(negedge clk) en = 1;
    repeat (3000) @(negedge clk);
    tb_check(bad_period == 0, $sformatf("frame period exact (%0d bad)", bad_period));
    tb_check(nt >= 29 && nt <= 31, $sformatf("tick count %0d", nt));
    tb_check(bad_lat == 0, "ch0 latency OFFSET+2");
    tb_check(n0 == nt || n0 == nt - 1, $sformatf("ch0 fires every frame %0d/%0d", n0, nt));
    tb_check(n1 >= nt / 3 - 1 && n1 <= nt / 3 + 1, $sformatf("ch1 every 3rd frame %0d", n1));
    tb_check(wmax == 5, $sformatf("ch0 width %0d", wmax));
    tb_check(novr == 0, "no overrun yet");
    mask = 8'b0000_0100;
    repeat (1000) @(negedge clk);
    tb_check(novr > 5, $sformatf("overrun detected when offset > period (%0d)", novr));
    // PPS alignment
    en = 0; mask = 0; @(negedge clk); pps_al = 1; nt = 0; last_tick = -1;
    @(negedge clk) en = 1;
    repeat (500) @(negedge clk);
    tb_check(nt == 0, "no tick before PPS");
    @(negedge clk) pps_p = 1; @(negedge clk) pps_p = 0;
    repeat (2) @(negedge clk);
    tb_check(nt == 1, "first tick on PPS");
    // external sync
    en = 0; pps_al = 0; @(negedge clk); ext_en = 1; nt = 0;
    @(negedge clk) en = 1;
    for (int k = 0; k < 7; k++) begin #(370 + 13 * k) ext = 1; #200 ext = 0; end
    repeat (10) @(negedge clk);
    tb_check(nt == 7, $sformatf("external sync ticks %0d", nt));
    tb_check(fidx > 0, "frame index advances");
    tb_done("tb_sf_sensor_sync");
  end
endmodule
