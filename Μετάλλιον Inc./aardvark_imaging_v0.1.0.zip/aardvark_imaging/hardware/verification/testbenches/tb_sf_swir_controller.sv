// SWIR controller: TEC-lock inhibit, integration width, readout pulse,
// ROIC FVAL/LVAL capture at 40 MHz.
module tb_sf_swir_controller;
  `include "tb_common.svh"
  localparam int W = 6, H = 4;
  logic clk = 0, pclk = 0, rst_n = 0, prst_n = 0;
  always #5 clk = ~clk;
  always #12.5 pclk = ~pclk;
  logic fval = 0, lval = 0, rint, rread, tec = 0, en = 0, trig = 0;
  logic [15:0] rdata = 0;
  logic [63:0] ts = 0;
  logic sv, sr, sl, eevt, errevt;
  logic [31:0] sd, sfr, sm, status, frames, errors;
  logic [7:0] sf;
  logic [15:0] srow;
  logic [63:0] sts;
  always @(posedge clk) ts <= ts + 1;
  sf_swir_controller #(.FIFO_AW(5), .CAL_AW(6)) dut (.clk(clk), .rst_n(rst_n), .pclk(pclk), .prst_n(prst_n),
    .roic_fval(fval), .roic_lval(lval), .roic_data(rdata), .roic_int(rint), .roic_read(rread), .tec_lock_async(tec),
    .enable(en), .cal_en(1'b0), .require_tec(1'b1), .test_mode(1'b0), .cfg_width(16'(W)), .cfg_height(16'(H)),
    .integration_cycles(32'd333), .sat_level(16'h3FFF), .trig(trig), .ts_now(ts), .cal_we(1'b0), .cal_waddr(6'd0),
    .cal_wdata(33'd0), .src_valid(sv), .src_ready(sr), .src_data(sd), .src_last(sl), .src_flags(sf), .src_frame(sfr),
    .src_row(srow), .src_meta(sm), .src_ts(sts), .status(status), .frames(frames), .errors(errors), .exposure_evt(eevt),
    .error_evt(errevt));
  tb_src_sink #(.READY_PCT(100), .SEED(7)) sink (.clk(clk), .rst_n(rst_n), .valid(sv), .ready(sr), .data(sd), .last(sl),
    .flags(sf), .frame(sfr), .row(srow), .meta(sm), .ts(sts));
  int ilen = 0, imax = 0, nread = 0;
  logic rread_q = 0;
  always @(posedge clk) if (rst_n) begin
    if (rint) ilen++; else begin if (ilen > imax) imax = ilen; ilen = 0; end
    rread_q <= rread; if (rread && !rread_q) nread++;
  end
  logic rr_p = 0, rr_pq = 0;
  always @(posedge pclk) begin rr_p <= rread; rr_pq <= rr_p; end
  initial forever begin
    @(negedge pclk);
    if (prst_n && rr_p && !rr_pq) begin
      fval = 1;
      for (int r = 0; r < H; r++) begin repeat (2) @(negedge pclk); for (int c = 0; c < W; c++) begin lval = 1; rdata = 16'(14000 + r * 10 + c); @(negedge pclk); end lval = 0; end
      @(negedge pclk) fval = 0;
    end
  end
  initial begin
    repeat (4) @(posedge clk); rst_n = 1; prst_n = 1;
    @(negedge clk) en = 1;
    // no TEC lock: inhibited
    for (int k = 0; k < 3; k++) begin @(negedge clk) trig = 1; @(negedge clk) trig = 0; repeat (200) @(negedge clk); end
    tb_check(errors[31:24] == 8'd3 && imax == 0, $sformatf("TEC inhibit count %0d", errors[31:24]));
    tec = 1; repeat (5) @(negedge clk);
    tb_check(status[8], "TEC lock visible in status");
    for (int k = 0; k < 3; k++) begin @(negedge clk) trig = 1; @(negedge clk) trig = 0; repeat (1500) @(negedge clk); end
    tb_check(imax == 333, $sformatf("integration %0d cycles", imax));
    tb_check(nread == 3, $sformatf("readout pulses %0d", nread));
    tb_check(frames == 3 && sink.npk == 3 * H, $sformatf("frames %0d packets %0d", frames, sink.npk));
    for (int p = 0; p < sink.npk; p++) for (int c = 0; c < W; c++)
      tb_check(sink.pix(p, c) == 16'(14000 + (p % H) * 10 + c), "ROIC pixel data");
    tb_done("tb_sf_swir_controller");
  end
endmodule
