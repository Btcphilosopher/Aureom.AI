// CDC primitives: pulse synchroniser event conservation in both directions
// at contract spacing; level synchroniser latency; reset synchroniser.
module tb_sf_cdc;
  `include "tb_common.svh"
  logic cf = 0, cs = 0, arst_n = 1;  // falling edge at t=1 asserts the asynchronous reset
  always #2.5 cf = ~cf;   // 200 MHz
  always #11.5 cs = ~cs;  // ~43 MHz
  logic rf, rs_;
  sf_reset_sync u_rf (.clk(cf), .arst_n(arst_n), .rst_n(rf));
  sf_reset_sync u_rs (.clk(cs), .arst_n(arst_n), .rst_n(rs_));
  logic p_fs, p_fs_out, busy_fs, p_sf, p_sf_out, busy_sf;
  sf_cdc_pulse u_fs (.src_clk(cf), .src_rst_n(rf), .src_pulse(p_fs), .src_busy(busy_fs), .dst_clk(cs), .dst_rst_n(rs_), .dst_pulse(p_fs_out));
  sf_cdc_pulse u_sf (.src_clk(cs), .src_rst_n(rs_), .src_pulse(p_sf), .src_busy(busy_sf), .dst_clk(cf), .dst_rst_n(rf), .dst_pulse(p_sf_out));
  logic lvl = 0, lvl_s;
  sf_cdc_bit u_lvl (.clk(cs), .rst_n(rs_), .d(lvl), .q(lvl_s));
  int n_fs_in = 0, n_fs_out = 0, n_sf_in = 0, n_sf_out = 0;
  always @(posedge cs) if (rs_ && p_fs_out) n_fs_out++;
  always @(posedge cf) if (rf && p_sf_out) n_sf_out++;
  initial begin
    p_fs = 0; p_sf = 0;
    #1 arst_n = 0;
    #40;
    tb_check(!rf && !rs_, "resets held");
    arst_n = 1;
    #200;
    tb_check(rf && rs_, "resets released");
    // fast -> slow: pulses only when not busy (busy covers the contract)
    for (int i = 0; i < 300; i++) begin
      @(negedge cf);
      while (busy_fs) @(negedge cf);
      p_fs = 1; n_fs_in++;
      @(negedge cf) p_fs = 0;
    end
    // slow -> fast at maximum rate allowed by busy
    for (int i = 0; i < 300; i++) begin
      @(negedge cs);
      while (busy_sf) @(negedge cs);
      p_sf = 1; n_sf_in++;
      @(negedge cs) p_sf = 0;
    end
    #2000;
    tb_check(n_fs_in == n_fs_out, $sformatf("fast->slow events %0d/%0d", n_fs_out, n_fs_in));
    tb_check(n_sf_in == n_sf_out, $sformatf("slow->fast events %0d/%0d", n_sf_out, n_sf_in));
    // level latency <= 3 destination edges
    @(negedge cs) lvl = 1;
    repeat (3) @(posedge cs);
    #1 tb_check(lvl_s == 1, "level propagated within 2-3 cycles");
    // asynchronous reset assertion is immediate
    arst_n = 0; #1;
    tb_check(!rf && !rs_, "async reset assertion");
    tb_done("tb_sf_cdc");
  end
endmodule
