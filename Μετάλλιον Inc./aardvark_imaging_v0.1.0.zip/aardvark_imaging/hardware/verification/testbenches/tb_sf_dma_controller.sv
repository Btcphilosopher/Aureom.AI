// DMA: (A) randomised AXI back-pressure with a host consumer — byte-exact
// ring contents, packet-granular WR_PTR, no drops with a large ring;
// (B) small ring + stalled host -> packet-atomic drops, accepted packets
// intact and in order; (C) AXI error flag; (D) ideal slave efficiency run.
module tb_sf_dma_controller;
  `include "tb_common.svh"
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  // ---------------- DUT A (random slave)
  logic en = 0, sv = 0, sr, sl = 0, ssop = 0, ferr = 0;
  logic [31:0] base = 32'h0000_0000, rdp = 0, thr = 0, sd = 0;
  logic [4:0] lg = 5'd12;
  logic [15:0] slen = 0;
  logic [31:0] awaddr, wdata, wrp, fill, pkts, drops;
  logic [7:0] awlen; logic [2:0] awsize; logic [1:0] awburst, bresp;
  logic awvalid, awready, wlast, wvalid, wready, bvalid, bready, busy, aerr, dropping, thr_evt, drop_evt;
  logic [3:0] wstrb;
  sf_dma_controller dut (.clk(clk), .rst_n(rst_n), .enable(en), .ring_base(base), .ring_log2(lg), .rd_ptr(rdp),
    .irq_threshold(thr), .s_valid(sv), .s_ready(sr), .s_data(sd), .s_last(sl), .s_sop(ssop), .s_len(slen),
    .m_axi_awaddr(awaddr), .m_axi_awlen(awlen), .m_axi_awsize(awsize), .m_axi_awburst(awburst), .m_axi_awvalid(awvalid),
    .m_axi_awready(awready), .m_axi_wdata(wdata), .m_axi_wstrb(wstrb), .m_axi_wlast(wlast), .m_axi_wvalid(wvalid),
    .m_axi_wready(wready), .m_axi_bresp(bresp), .m_axi_bvalid(bvalid), .m_axi_bready(bready), .wr_ptr(wrp),
    .fill_level(fill), .pkt_count(pkts), .drop_count(drops), .busy(busy), .axi_error(aerr), .dropping(dropping),
    .thresh_evt(thr_evt), .drop_evt(drop_evt));
  tb_axi_mem #(.WORDS(4096), .RANDOM(1), .SEED(9)) mem (.clk(clk), .rst_n(rst_n), .awaddr(awaddr), .awlen(awlen),
    .awvalid(awvalid), .awready(awready), .wdata(wdata), .wlast(wlast), .wvalid(wvalid), .wready(wready), .bresp(bresp),
    .bvalid(bvalid), .bready(bready), .force_error(ferr));
  sf_axi_write_checker axchk (.clk(clk), .rst_n(rst_n), .awaddr(awaddr), .awlen(awlen), .awsize(awsize), .awburst(awburst),
    .awvalid(awvalid), .awready(awready), .wdata(wdata), .wlast(wlast), .wvalid(wvalid), .wready(wready), .bvalid(bvalid), .bready(bready));

  int unsigned rs = 21;
  function automatic int rnd(input int m); rs = rs * 1664525 + 1013904223; rnd = int'((rs >> 8) % m); endfunction
  function automatic logic [31:0] pw(input int p, input int i); pw = (i == 0) ? 32'h53465031 : (i == 1) ? 32'(p) : 32'(p * 7919 + i * 104729); endfunction
  int plen [int];
  int next_pkt = 0;
  task automatic send_pkt(input int p, input int len);
    plen[p] = len;
    for (int i = 0; i < len; i++) begin
      @(negedge clk);
      while (rnd(100) < 10) @(negedge clk);
      sv = 1; sd = pw(p, i); sl = (i == len - 1); ssop = (i == 0); slen = 16'(len);
      while (!sr) @(negedge clk);
      @(posedge clk);
      @(negedge clk) begin sv = 0; ssop = 0; sl = 0; end
    end
  endtask
  // host consumer: parses committed packets between rdp and wrp
  bit host_run = 1;
  int consumed = 0, last_idx = -1, gaps = 0, bad_ptr = 0;
  int ends [int];   // byte offsets where packets end (commit points)
  int expect_off = 0;
  always @(posedge clk) if (rst_n && en && host_run && rdp != wrp && rnd(100) < 30) begin
    int off, idx, len, sz;
    sz = 1 << lg;
    off = int'(rdp);
    tb_check(mem.mem[off >> 2] == 32'h53465031, $sformatf("packet starts with SYNC at %0d", off));
    idx = int'(mem.mem[((off >> 2) + 1) % (sz >> 2)]);
    len = plen.exists(idx) ? plen[idx] : 1;
    if (idx != last_idx + 1) gaps += idx - last_idx - 1;
    tb_check(idx > last_idx, "packets in order");
    last_idx = idx;
    for (int i = 0; i < len; i++) tb_check(mem.mem[((off >> 2) + i) % (sz >> 2)] == pw(idx, i), "ring payload");
    rdp <= 32'((off + 4 * len) % sz);
    consumed++;
  end
  // WR_PTR must only move to packet boundaries: check SYNC at every committed position
  logic [31:0] wrp_q = 0;
  always @(posedge clk) if (rst_n && en) begin
    if (wrp != wrp_q && wrp != rdp) ; // a new commit; next packet (if any) will start here
    wrp_q <= wrp;
  end
  // ---------------- DUT D (ideal slave, efficiency)
  logic e_sv = 0, e_sr, e_sl = 0, e_sop = 0;
  logic [31:0] e_awaddr, e_wdata, e_wrp, e_fill, e_pk, e_dr, e_rdp = 0;
  logic [7:0] e_awlen; logic [2:0] e_awsize; logic [1:0] e_awburst, e_bresp;
  logic e_awvalid, e_awready, e_wlast, e_wvalid, e_wready, e_bvalid, e_bready, e_busy, e_aerr, e_drp, e_thr, e_dev;
  logic [3:0] e_wstrb;
  sf_dma_controller dut_e (.clk(clk), .rst_n(rst_n), .enable(en), .ring_base(32'h0), .ring_log2(5'd16), .rd_ptr(e_rdp),
    .irq_threshold(32'd0), .s_valid(e_sv), .s_ready(e_sr), .s_data(32'h1234), .s_last(e_sl), .s_sop(e_sop), .s_len(16'd1033),
    .m_axi_awaddr(e_awaddr), .m_axi_awlen(e_awlen), .m_axi_awsize(e_awsize), .m_axi_awburst(e_awburst),
    .m_axi_awvalid(e_awvalid), .m_axi_awready(e_awready), .m_axi_wdata(e_wdata), .m_axi_wstrb(e_wstrb),
    .m_axi_wlast(e_wlast), .m_axi_wvalid(e_wvalid), .m_axi_wready(e_wready), .m_axi_bresp(e_bresp),
    .m_axi_bvalid(e_bvalid), .m_axi_bready(e_bready), .wr_ptr(e_wrp), .fill_level(e_fill), .pkt_count(e_pk),
    .drop_count(e_dr), .busy(e_busy), .axi_error(e_aerr), .dropping(e_drp), .thresh_evt(e_thr), .drop_evt(e_dev));
  tb_axi_mem #(.WORDS(16384), .RANDOM(0)) mem_e (.clk(clk), .rst_n(rst_n), .awaddr(e_awaddr), .awlen(e_awlen),
    .awvalid(e_awvalid), .awready(e_awready), .wdata(e_wdata), .wlast(e_wlast), .wvalid(e_wvalid), .wready(e_wready),
    .bresp(e_bresp), .bvalid(e_bvalid), .bready(e_bready), .force_error(1'b0));
  // continuous source of 1033-word packets (an HSI-row-sized packet incl. header/CRC)
  int e_i = 0;
  always @(negedge clk) begin
    if (rst_n && en) begin
      e_sv = 1; e_sop = (e_i == 0); e_sl = (e_i == 1032);
    end else e_sv = 0;
  end
  always @(posedge clk) if (e_sv && e_sr) e_i = (e_i == 1032) ? 0 : e_i + 1;
  always @(posedge clk) e_rdp <= e_wrp;     // instant consumer
  longint e_words = 0, e_cycles = 0;
  bit e_meas = 0;
  always @(posedge clk) if (e_meas) begin e_cycles++; if (e_wvalid && e_wready) e_words++; end

  initial begin
    repeat (3) @(posedge clk); rst_n = 1;
    @(negedge clk) en = 1;
    // (A) 300 packets, large ring, active host
    #5000 e_meas = 1;
    for (int p = 0; p < 300; p++) send_pkt(next_pkt++, 9 + rnd(120));
    #200000 e_meas = 0;
    repeat (2000) @(posedge clk);
    tb_check(consumed == 300 && drops == 0, $sformatf("A: consumed %0d drops %0d", consumed, drops));
    tb_check(pkts == 300, $sformatf("A: committed %0d", pkts));
    tb_check(!aerr, "A: no AXI error");
    // (B) small ring, host stalled -> drops
    host_run = 0;
    @(negedge clk) en = 0; lg = 5'd8; rdp = 0; consumed = 0; last_idx = next_pkt - 1; gaps = 0;
    @(negedge clk) en = 1;
    for (int p = 0; p < 40; p++) send_pkt(next_pkt++, 9 + rnd(20));
    repeat (500) @(posedge clk);
    tb_check(drops > 0, $sformatf("B: drops reported (%0d)", drops));
    tb_check(fill <= 32'd252, "B: ring never over-filled");
    host_run = 1;
    repeat (20000) @(posedge clk);
    tb_check(consumed + int'(drops) == 40, $sformatf("B: consumed %0d + dropped %0d == 40", consumed, drops));
    // (C) AXI error response; this packet also reveals the trailing drops as a sequence gap
    ferr = 1; send_pkt(next_pkt++, 12); repeat (400) @(posedge clk); ferr = 0;
    tb_check(aerr, "C: AXI SLVERR flagged");
    repeat (2000) @(posedge clk);
    tb_check(gaps == int'(drops), $sformatf("B/C: host-visible sequence gaps %0d == drops %0d", gaps, drops));
    // (D) efficiency
    begin
      int fde;
      real eff;
      eff = real'(e_words) / real'(e_cycles);
      fde = $fopen({`SF_VEC_DIR, "/dma_efficiency.json"}, "w");
      $fdisplay(fde, "{\"words\": %0d, \"cycles\": %0d, \"efficiency\": %0.4f, \"packet_words\": 1033, \"slave\": \"ideal, 1-cycle B response\"}", e_words, e_cycles, eff);
      $fclose(fde);
      $display("DMA sustained efficiency %0.4f words/cycle", eff);
      tb_check(eff > 0.70, $sformatf("D: efficiency %0.3f", eff));
    end
    tb_done("tb_sf_dma_controller");
  end
endmodule
