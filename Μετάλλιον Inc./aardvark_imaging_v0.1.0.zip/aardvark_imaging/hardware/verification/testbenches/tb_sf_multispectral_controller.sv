// Multispectral controller: AXI4-Stream video ingest at 150 MHz, LED band
// round-robin with mask skipping, LED strobe confined to exposure, band index
// in packet meta, and frame/row accounting.
module tb_sf_multispectral_controller;
  `include "tb_common.svh"
  localparam int W = 8, H = 3;
  logic clk = 0, vclk = 0, rst_n = 0, vrst_n = 0;
  always #5 clk = ~clk;
  always #3.333 vclk = ~vclk;
  logic tv = 0, tr, tu = 0, tl = 0, camtrig, en = 0, trig = 0;
  logic [15:0] td = 0;
  logic [7:0] led;
  logic [63:0] ts = 0;
  logic sv, sr, sl, eevt, errevt;
  logic [31:0] sd, sfr, sm, status, frames, errors;
  logic [7:0] sf;
  logic [15:0] srow;
  logic [63:0] sts;
  always @(posedge clk) ts <= ts + 1;
  sf_multispectral_controller #(.FIFO_AW(5), .CAL_AW(6)) dut (.clk(clk), .rst_n(rst_n), .vclk(vclk), .vrst_n(vrst_n),
    .s_axis_tvalid(tv), .s_axis_tready(tr), .s_axis_tdata(td), .s_axis_tuser(tu), .s_axis_tlast(tl), .cam_trigger(camtrig),
    .led(led), .enable(en), .cal_en(1'b0), .test_mode(1'b0), .nbands(4'd8), .led_mask(8'b1011_0101), .cfg_width(16'(W)),
    .cfg_height(16'(H)), .exposure_cycles(32'd120), .sat_level(16'h0FFF), .trig(trig), .ts_now(ts), .cal_we(1'b0),
    .cal_waddr(6'd0), .cal_wdata(33'd0), .src_valid(sv), .src_ready(sr), .src_data(sd), .src_last(sl), .src_flags(sf),
    .src_frame(sfr), .src_row(srow), .src_meta(sm), .src_ts(sts), .status(status), .frames(frames), .errors(errors),
    .exposure_evt(eevt), .error_evt(errevt));
  tb_src_sink #(.READY_PCT(90), .SEED(5)) sink (.clk(clk), .rst_n(rst_n), .valid(sv), .ready(sr), .data(sd), .last(sl),
    .flags(sf), .frame(sfr), .row(srow), .meta(sm), .ts(sts));
  int led_outside = 0, bad_onehot = 0;
  always @(posedge clk) if (rst_n) begin
    if (led != 0 && !camtrig) led_outside++;
    if (led != 0 && (led & (led - 1)) != 0) bad_onehot++;
  end
  // camera: after each trigger pulse ends, stream one frame over AXIS
  logic ct_v = 0, ct_vq = 0;
  int fno = 0;
  always @(posedge vclk) begin ct_v <= camtrig; ct_vq <= ct_v; end
  initial forever begin
    @(negedge vclk);
    if (vrst_n && ct_vq && !ct_v) begin
      for (int r = 0; r < H; r++) begin
        for (int c = 0; c < W; c++) begin tv = 1; td = 16'(fno * 64 + r * 8 + c); tu = (r == 0 && c == 0); tl = (c == W - 1); @(negedge vclk); end
        tv = 0; tu = 0; tl = 0; repeat (4) @(negedge vclk);
      end
      fno++;
    end
  end
  initial begin
    int exp_band [10] = '{0, 2, 4, 5, 7, 0, 2, 4, 5, 7};
    repeat (4) @(posedge clk); rst_n = 1; vrst_n = 1;
    @(negedge clk) en = 1;
    for (int k = 0; k < 10; k++) begin @(negedge clk) trig = 1; @(negedge clk) trig = 0; repeat (500) @(negedge clk); end
    tb_check(led_outside == 0, "LED only lit during exposure");
    tb_check(bad_onehot == 0, "one LED at a time");
    tb_check(frames == 32'd10 && sink.npk == 10 * H, $sformatf("frames %0d packets %0d", frames, sink.npk));
    for (int p = 0; p < sink.npk; p++) begin
      int f, r;
      f = p / H; r = p % H;
      tb_check(int'(sink.p_meta[p][23:16]) == exp_band[f], $sformatf("frame %0d band %0d exp %0d", f, sink.p_meta[p][23:16], exp_band[f]));
      tb_check(sink.p_frame[p] == f && sink.p_row[p] == r, "frame/row");
      for (int c = 0; c < W; c++) tb_check(sink.pix(p, c) == 16'(f * 64 + r * 8 + c), "AXIS pixel data");
    end
    tb_done("tb_sf_multispectral_controller");
  end
endmodule
