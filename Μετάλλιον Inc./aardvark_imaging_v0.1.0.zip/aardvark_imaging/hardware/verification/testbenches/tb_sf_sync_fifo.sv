// Sync FIFO: randomised push/pop scoreboard, level, full/overflow, capacity.
module tb_sf_sync_fifo;
  `include "tb_common.svh"
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic wr_en = 0, rd_en = 0, full, overflow, rd_valid;
  logic [15:0] wr_data = 0, rd_data;
  logic [5:0] level;
  sf_sync_fifo #(.DW(16), .AW(4)) dut (.clk(clk), .rst_n(rst_n), .wr_en(wr_en), .wr_data(wr_data), .full(full),
    .overflow(overflow), .rd_en(rd_en), .rd_data(rd_data), .rd_valid(rd_valid), .level(level));
  int q[$];
  int unsigned rs = 12345;
  int ovf_seen = 0, accepted = 0;
  function automatic int rnd(input int m); rs = rs * 1664525 + 1013904223; rnd = int'((rs >> 8) % m); endfunction
  always @(posedge clk) if (rst_n) begin
    if (wr_en && !full) begin q.push_back(int'(wr_data)); accepted++; end
    if (wr_en && full) begin ovf_seen++; tb_check(overflow, "overflow flag on write-when-full"); end
    if (rd_en && rd_valid) begin
      int e;
      e = q.pop_front();
      tb_check(int'(rd_data) == e, $sformatf("data order: got %0h exp %0h", rd_data, e));
    end
  end
  always @(negedge clk) if (rst_n) tb_check(int'(level) == q.size(), $sformatf("level %0d vs model %0d", level, q.size()));
  initial begin
    repeat (3) @(posedge clk);
    @(negedge clk) rst_n = 1;
    // capacity: 2**AW memory words + 1 output register
    for (int i = 0; i < 20; i++) begin @(negedge clk); wr_en = 1; wr_data = 16'(i); end
    @(negedge clk) wr_en = 0;
    repeat (2) @(negedge clk);
    tb_check(accepted == 17, $sformatf("capacity %0d", accepted));
    tb_check(full, "full asserted at capacity");
    tb_check(ovf_seen == 3, "three overflows reported");
    // drain
    while (q.size() > 0) begin @(negedge clk); rd_en = rd_valid; end
    @(negedge clk) rd_en = 0;
    // random traffic
    for (int c = 0; c < 6000; c++) begin
      @(negedge clk);
      wr_en = (rnd(100) < 55); wr_data = 16'(rnd(65536));
      rd_en = rd_valid && (rnd(100) < 50);
    end
    @(negedge clk) begin wr_en = 0; end
    while (q.size() > 0) begin @(negedge clk); rd_en = rd_valid; end
    @(negedge clk) rd_en = 0;
    repeat (3) @(negedge clk);
    tb_check(!rd_valid && level == 0, "empty after drain");
    tb_done("tb_sf_sync_fifo");
  end
endmodule
