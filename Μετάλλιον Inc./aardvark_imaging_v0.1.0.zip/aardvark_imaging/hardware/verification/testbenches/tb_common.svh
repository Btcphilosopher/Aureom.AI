// Shared self-checking testbench helpers (include inside a TB module).
int tb_errors = 0;
int tb_checks = 0;

task automatic tb_check(input bit cond, input string msg);
  tb_checks++;
  if (!cond) begin
    tb_errors++;
    if (tb_errors <= 40) $display("TB_ERROR t=%0t %s", $time, msg);
  end
endtask

task automatic tb_done(input string name);
  if (tb_errors == 0) $display("TB_RESULT %s PASS checks=%0d", name, tb_checks);
  else $display("TB_RESULT %s FAIL errors=%0d checks=%0d", name, tb_errors, tb_checks);
  $finish;
endtask

`ifndef SF_VEC_DIR
`define SF_VEC_DIR "."
`endif
`ifndef SF_ROM_FILE
`define SF_ROM_FILE "sf_sine_q15_quarter.hex"
`endif
