// Row capture across clock domains (74.25 MHz pixel -> 100 MHz system):
// calibrated pixel values vs an independent reference, even/odd widths,
// frame/row counters, context timestamps, length errors, missing EOL,
// FIFO overflow with recovery.
module tb_sf_row_capture;
  `include "tb_common.svh"
  localparam int CAW = 6;
  logic pclk = 0, clk = 0, prst_n = 0, rst_n = 0;
  always #6.734 pclk = ~pclk;
  always #5 clk = ~clk;
  logic px_v = 0, px_sof = 0, px_eol = 0;
  logic [15:0] px_d = 0;
  logic en = 0, cal_en = 1, cal_we = 0, ctx_push = 0, src_ready = 1;
  logic [15:0] sat = 16'd4000, cfg_p = 16'd10, cfg_r = 16'd4;
  logic [CAW-1:0] cal_waddr = 0;
  logic [32:0] cal_wdata = 0;
  logic [63:0] ctx_ts = 0, ts_now = 0;
  logic [7:0] ctx_band = 0;
  logic src_valid, src_last, frame_done, len_evt, ovr_evt;
  logic [31:0] src_data, src_frame, src_meta;
  logic [7:0] src_flags;
  logic [15:0] src_row, fifo_level;
  logic [63:0] src_ts;
  sf_row_capture #(.FIFO_AW(4), .CAL_AW(CAW)) dut (.pclk(pclk), .prst_n(prst_n), .px_valid(px_v), .px_data(px_d),
    .px_sof(px_sof), .px_eol(px_eol), .clk(clk), .rst_n(rst_n), .enable(en), .cal_en(cal_en), .sat_level(sat),
    .cfg_pixels(cfg_p), .cfg_rows(cfg_r), .cal_we(cal_we), .cal_waddr(cal_waddr), .cal_wdata(cal_wdata),
    .ctx_push(ctx_push), .ctx_ts(ctx_ts), .ctx_band(ctx_band), .ts_now(ts_now), .src_valid(src_valid),
    .src_ready(src_ready), .src_data(src_data), .src_last(src_last), .src_flags(src_flags), .src_frame(src_frame),
    .src_row(src_row), .src_meta(src_meta), .src_ts(src_ts), .fifo_level(fifo_level), .frame_done(frame_done),
    .length_err_evt(len_evt), .overrun_evt(ovr_evt));
  sf_stream_checker #(.DW(32)) chk (.clk(clk), .rst_n(rst_n), .valid(src_valid), .ready(src_ready), .data(src_data), .last(src_last));
  always @(posedge clk) ts_now <= ts_now + 1;

  logic [32:0] calm [0:(1<<CAW)-1];
  function automatic logic [15:0] calref(input int idx, input int raw, output bit s, output bit b, output bit oob);
    int dark, gain, y;
    oob = (idx >= (1 << CAW));
    dark = oob ? 0 : int'(calm[idx][15:0]); gain = oob ? 16384 : int'(calm[idx][31:16]); b = oob ? 0 : calm[idx][32];
    s = (raw >= int'(sat));
    y = (raw > dark) ? int'((longint'(raw - dark) * gain + 8192) >>> 14) : 0;
    if (b) calref = 16'hFFFE; else if (s) calref = 16'hFFFF; else calref = (y > 16'hFFFD) ? 16'hFFFD : 16'(y);
  endfunction
  function automatic int pval(input int f, input int r, input int c);
    pval = (f == 1 && r == 2 && c == 3) ? 4095 : ((f * 37 + r * 11 + c * 5 + 100) & 16'h0FFF);
  endfunction

  // ---------------- pixel driver (pclk)
  task automatic send_row(input int f, input int r, input int npx, input bit sof, input bit with_eol);
    for (int c = 0; c < npx; c++) begin
      @(negedge pclk);
      px_v = 1; px_d = 16'(pval(f, r, c)); px_sof = sof && (c == 0); px_eol = with_eol && (c == npx - 1);
    end
    @(negedge pclk) begin px_v = 0; px_sof = 0; px_eol = 0; end
    repeat (6) @(negedge pclk);
  endtask

  // ---------------- sink (clk)
  typedef struct { int frame; int row; int nw; logic [7:0] flags; logic [31:0] meta; logic [63:0] ts; } rpk_t;
  rpk_t pk [$];
  logic [31:0] words [int];
  int nwords = 0, cur_w = 0, n_len = 0, n_ovr = 0;
  always @(posedge clk) if (rst_n) begin
    if (len_evt) n_len++;
    if (ovr_evt) n_ovr++;
    if (src_valid && src_ready) begin
      words[nwords] = src_data; nwords++; cur_w++;
      if (src_last) begin
        rpk_t k;
        k.frame = int'(src_frame); k.row = int'(src_row); k.nw = cur_w; k.flags = src_flags; k.meta = src_meta; k.ts = src_ts;
        pk.push_back(k); cur_w = 0;
      end
    end
  end
  // Check one received row packet against the reference.
  int wptr = 0;
  task automatic expect_row(input int f, input int r, input int frame_no, input int npx, input int base_idx,
                            input bit exp_trunc, input logic [63:0] exp_ts, input bit ts_check);
    rpk_t k; bit any_s, any_b, any_oob;
    any_s = 0; any_b = 0; any_oob = 0;
    if (pk.size() == 0) begin tb_check(0, $sformatf("missing packet f%0d r%0d", f, r)); return; end
    k = pk.pop_front();
    tb_check(k.frame == frame_no && k.row == r, $sformatf("frame/row %0d/%0d exp %0d/%0d", k.frame, k.row, frame_no, r));
    tb_check(k.nw == (npx + 1) / 2, $sformatf("words %0d for %0d px", k.nw, npx));
    tb_check(int'(k.meta[15:0]) == npx, "meta pixel count");
    for (int c = 0; c < npx; c++) begin
      bit s, b, o; logic [15:0] e, g;
      e = calref(base_idx + c, pval(f, r, c), s, b, o);
      any_s |= s; any_b |= b; any_oob |= o;
      g = (c % 2 == 0) ? words[wptr + c / 2][15:0] : words[wptr + c / 2][31:16];
      tb_check(g == e, $sformatf("f%0d r%0d c%0d pix %0h exp %0h", f, r, c, g, e));
    end
    if (npx % 2) tb_check(words[wptr + npx / 2][31:16] == 16'hFFFE, "odd row padded with BAD code");
    tb_check(k.flags[0] == any_s && k.flags[1] == any_b, $sformatf("sat/bad flags %0b", k.flags));
    tb_check(k.flags[3] == !any_oob, "CALIBRATED flag cleared for out-of-RAM pixels");
    tb_check(k.flags[7] == exp_trunc, $sformatf("truncated flag %0b exp %0b", k.flags[7], exp_trunc));
    if (ts_check) tb_check(k.ts == exp_ts && k.meta[31], "exposure timestamp from context");
    wptr += k.nw;
  endtask

  task automatic push_ctx(input logic [63:0] t);
    @(negedge clk) begin ctx_push = 1; ctx_ts = t; ctx_band = 8'd2; end
    @(negedge clk) ctx_push = 0;
  endtask

  initial begin
    repeat (4) @(posedge clk); prst_n = 1; rst_n = 1;
    for (int i = 0; i < (1 << CAW); i++) begin
      @(negedge clk) begin cal_we = 1; cal_waddr = CAW'(i);
        cal_wdata = {(i == 13), 16'(16384 + i * 150), 16'(i * 3)}; calm[i] = cal_wdata; end
    end
    @(negedge clk) cal_we = 0;
    @(negedge clk) en = 1;
    repeat (5) @(negedge clk);
    // S1: three full frames
    for (int f = 0; f < 3; f++) begin
      push_ctx(64'd1000 + 64'(f));
      for (int r = 0; r < 4; r++) send_row(f, r, 10, r == 0, 1);
    end
    repeat (100) @(negedge clk);
    for (int f = 0; f < 3; f++) for (int r = 0; r < 4; r++) expect_row(f, r, f, 10, r * 10, 0, 64'd1000 + 64'(f), 1);
    // S2: odd width (quasi-static change while idle)
    cfg_p = 16'd9;
    push_ctx(64'd2000);
    for (int r = 0; r < 4; r++) send_row(3, r, 9, r == 0, 1);
    repeat (100) @(negedge clk);
    for (int r = 0; r < 4; r++) expect_row(3, r, 3, 9, r * 9, 0, 64'd2000, 1);
    // S3: one short row -> length error, TRUNCATED
    cfg_p = 16'd10;
    push_ctx(64'd3000);
    for (int r = 0; r < 4; r++) send_row(4, r, (r == 2) ? 7 : 10, r == 0, 1);
    repeat (100) @(negedge clk);
    begin
      int base;
      base = 0;
      for (int r = 0; r < 4; r++) begin expect_row(4, r, 4, (r == 2) ? 7 : 10, base, r == 2, 64'd3000, 1); base += (r == 2) ? 7 : 10; end
    end
    tb_check(n_len == 1, $sformatf("one length error event (%0d)", n_len));
    // S4: missing EOL on row 1, next frame starts -> injected terminator
    push_ctx(64'd4000);
    send_row(5, 0, 10, 1, 1);
    send_row(5, 1, 10, 0, 0);
    push_ctx(64'd5000);
    for (int r = 0; r < 4; r++) send_row(6, r, 10, r == 0, 1);
    repeat (100) @(negedge clk);
    expect_row(5, 0, 5, 10, 0, 0, 64'd4000, 1);
    begin
      rpk_t k;
      k = pk.pop_front();
      tb_check(k.row == 1 && k.flags[7] && k.nw == 6, $sformatf("missing-EOL row terminated (row %0d nw %0d flags %0h)", k.row, k.nw, k.flags));
      tb_check(words[wptr + 5] == 32'hFFFEFFFE, "terminator word is BAD|BAD");
      wptr += k.nw;
    end
    for (int r = 0; r < 4; r++) expect_row(6, r, 6, 10, r * 10, 0, 64'd5000, 1);
    // S5: overflow with stalled consumer, then recovery
    @(negedge clk) src_ready = 0;
    push_ctx(64'd6000);
    for (int r = 0; r < 4; r++) send_row(7, r, 10, r == 0, 1);
    repeat (50) @(negedge clk);
    @(negedge clk) src_ready = 1;
    repeat (200) @(negedge clk);
    tb_check(n_ovr >= 1, $sformatf("overflow reported (%0d)", n_ovr));
    begin
      bit any_ovr, any_tr; int nrow;
      any_ovr = 0; any_tr = 0; nrow = pk.size();
      foreach (pk[i]) begin any_ovr |= pk[i].flags[2]; any_tr |= pk[i].flags[7]; end
      tb_check(any_ovr && any_tr, "overflow frame flagged OVERRUN_PRECEDED and TRUNCATED");
      tb_check(nrow >= 1 && nrow <= 4, $sformatf("overflow frame rows %0d", nrow));
      foreach (pk[i]) wptr += pk[i].nw;
      pk.delete();
    end
    push_ctx(64'd7000);
    for (int r = 0; r < 4; r++) send_row(8, r, 10, r == 0, 1);
    repeat (100) @(negedge clk);
    for (int r = 0; r < 4; r++) expect_row(8, r, 8, 10, r * 10, 0, 64'd7000, 1);
    tb_check(pk.size() == 0, "no stray packets");
    tb_done("tb_sf_row_capture");
  end
endmodule
