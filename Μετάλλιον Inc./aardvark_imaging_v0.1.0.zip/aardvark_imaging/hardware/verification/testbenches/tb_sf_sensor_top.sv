// =============================================================================
// Full-system integration: sf_sensor_top with every sensor enabled in
// TEST_PATTERN mode, configured purely through the AXI4-Lite register map
// (addresses from the generated sf_regs_pkg). The DMA writes into a
// randomised-back-pressure AXI memory model. At the end the TB dumps the ring
// and a register snapshot; tests/hardware/test_rtl_crosscheck.py decodes the
// ring with the Python acquisition stack and checks CRC, sequence, flags,
// timestamps and bit-exact payloads.
// =============================================================================
module tb_sf_sensor_top;
  `include "tb_common.svh"
  logic clk = 0, hclk = 0, vclk = 0, sclk_sw = 0, arst_n = 1;
  always #5 clk = ~clk;
  always #6.734 hclk = ~hclk;
  always #3.333 vclk = ~vclk;
  always #12.5 sclk_sw = ~sclk_sw;

  // AXI-Lite
  logic [15:0] awaddr = 0, araddr = 0;
  logic awvalid = 0, wvalid = 0, bready = 0, arvalid = 0, rready = 0;
  logic awready, wready, bvalid, arready, rvalid;
  logic [31:0] wdata = 0, rdata;
  logic [3:0] wstrb = 4'hF;
  logic [1:0] bresp, rresp;
  // AXI4 DMA
  logic [31:0] m_awaddr, m_wdata;
  logic [7:0] m_awlen; logic [2:0] m_awsize; logic [1:0] m_awburst, m_bresp;
  logic m_awvalid, m_awready, m_wlast, m_wvalid, m_wready, m_bvalid, m_bready;
  logic [3:0] m_wstrb;
  logic irq;
  logic pps = 0;
  // sensor IO (idle; TEST_PATTERN supplies data)
  logic hsi_exp, ms_tready, ms_trig, swir_int, swir_read, r_int, r_pix, r_cnv, r_sclk, r_csn, l_en, l_mod;
  logic [7:0] ms_led;
  logic ir_on, ir_cnv, ir_sclk, ir_csn, fl_cnv, fl_sclk, fl_csn, mbes, em_load, em_cnv, em_sclk, em_csn;
  logic hk_cnv, hk_sclk, hk_csn, scl_oe, sda_oe;
  logic [3:0] ir_band; logic [2:0] fl_led; logic [15:0] em_dac; logic [1:0] hk_mux;

  sf_sensor_top #(.CAL_AW(8), .ROW_FIFO_AW(6), .STAGE_AW(10), .RAMAN_NPIX(128), .RAMAN_PIX_PERIOD(140),
                  .ADC_SAMPLE_PERIOD(200), .ARR_SEG(32), .PPS_TIMEOUT(32'd300000), .SONAR_TRIG_WIDTH(20),
                  .ROM_FILE(`SF_ROM_FILE)) dut (
    .clk(clk), .arst_n(arst_n), .hsi_pclk(hclk), .vid_clk(vclk), .swir_pclk(sclk_sw),
    .s_axil_awaddr(awaddr), .s_axil_awvalid(awvalid), .s_axil_awready(awready), .s_axil_wdata(wdata), .s_axil_wstrb(wstrb),
    .s_axil_wvalid(wvalid), .s_axil_wready(wready), .s_axil_bresp(bresp), .s_axil_bvalid(bvalid), .s_axil_bready(bready),
    .s_axil_araddr(araddr), .s_axil_arvalid(arvalid), .s_axil_arready(arready), .s_axil_rdata(rdata), .s_axil_rresp(rresp),
    .s_axil_rvalid(rvalid), .s_axil_rready(rready),
    .m_axi_awaddr(m_awaddr), .m_axi_awlen(m_awlen), .m_axi_awsize(m_awsize), .m_axi_awburst(m_awburst),
    .m_axi_awvalid(m_awvalid), .m_axi_awready(m_awready), .m_axi_wdata(m_wdata), .m_axi_wstrb(m_wstrb), .m_axi_wlast(m_wlast),
    .m_axi_wvalid(m_wvalid), .m_axi_wready(m_wready), .m_axi_bresp(m_bresp), .m_axi_bvalid(m_bvalid), .m_axi_bready(m_bready),
    .irq(irq), .pps_in(pps), .ext_sync_in(1'b0),
    .hsi_fval(1'b0), .hsi_lval(1'b0), .hsi_data(16'd0), .hsi_exposure(hsi_exp),
    .ms_tvalid(1'b0), .ms_tready(ms_tready), .ms_tdata(16'd0), .ms_tuser(1'b0), .ms_tlast(1'b0), .ms_trigger(ms_trig), .ms_led(ms_led),
    .swir_fval(1'b0), .swir_lval(1'b0), .swir_data(16'd0), .swir_int(swir_int), .swir_read(swir_read), .swir_tec_lock(1'b1),
    .raman_ccd_integrate(r_int), .raman_ccd_pixel(r_pix), .raman_adc_cnv(r_cnv), .raman_adc_sclk(r_sclk),
    .raman_adc_cs_n(r_csn), .raman_adc_miso(1'b0), .laser_enable(l_en), .laser_mod(l_mod), .laser_submerged(1'b1),
    .ir_source_on(ir_on), .ir_band(ir_band), .ir_adc_cnv(ir_cnv), .ir_adc_sclk(ir_sclk), .ir_adc_cs_n(ir_csn), .ir_adc_miso(1'b0),
    .fl_led(fl_led), .fl_adc_cnv(fl_cnv), .fl_adc_sclk(fl_sclk), .fl_adc_cs_n(fl_csn), .fl_adc_miso(3'b0),
    .mbes_trigger(mbes), .mbes_tx_ack(1'b0), .arr_raw_valid(1'b0), .arr_raw_frame(14'd0), .arr_raw_data(112'd0),
    .em_dac_data(em_dac), .em_dac_load(em_load), .em_adc_cnv(em_cnv), .em_adc_sclk(em_sclk), .em_adc_cs_n(em_csn), .em_adc_miso(2'b0),
    .hk_adc_cnv(hk_cnv), .hk_adc_sclk(hk_sclk), .hk_adc_cs_n(hk_csn), .hk_adc_miso(1'b0), .hk_mux(hk_mux),
    .i2c_scl_i(!scl_oe), .i2c_sda_i(!sda_oe), .i2c_scl_oe(scl_oe), .i2c_sda_oe(sda_oe)
  );
  tb_axi_mem #(.WORDS(65536), .RANDOM(1), .SEED(41)) mem (.clk(clk), .rst_n(arst_n), .awaddr(m_awaddr), .awlen(m_awlen),
    .awvalid(m_awvalid), .awready(m_awready), .wdata(m_wdata), .wlast(m_wlast), .wvalid(m_wvalid), .wready(m_wready),
    .bresp(m_bresp), .bvalid(m_bvalid), .bready(m_bready), .force_error(1'b0));
  sf_axi_write_checker axchk (.clk(clk), .rst_n(arst_n), .awaddr(m_awaddr), .awlen(m_awlen), .awsize(m_awsize),
    .awburst(m_awburst), .awvalid(m_awvalid), .awready(m_awready), .wdata(m_wdata), .wlast(m_wlast), .wvalid(m_wvalid),
    .wready(m_wready), .bvalid(m_bvalid), .bready(m_bready));
  sf_stream_checker #(.DW(32)) pchk (.clk(clk), .rst_n(arst_n), .valid(dut.p_valid), .ready(dut.p_ready), .data(dut.p_data), .last(dut.p_last));

  // ---------------- AXI-Lite BFM (negedge-decided handshakes)
  task automatic wr(input logic [15:0] a, input logic [31:0] d);
    bit aw_hs, w_hs;
    aw_hs = 0; w_hs = 0;
    @(negedge clk) begin awaddr = a; awvalid = 1; wdata = d; wstrb = 4'hF; wvalid = 1; bready = 1; end
    while (!(aw_hs && w_hs)) begin
      bit an, wn;
      an = awvalid && awready; wn = wvalid && wready;
      @(posedge clk); @(negedge clk);
      if (an) begin aw_hs = 1; awvalid = 0; end
      if (wn) begin w_hs = 1; wvalid = 0; end
    end
    while (!bvalid) @(negedge clk);
    tb_check(bresp == 2'b00, $sformatf("write 0x%04h OKAY", a));
    @(posedge clk); @(negedge clk) bready = 0;
  endtask
  task automatic rd(input logic [15:0] a, output logic [31:0] d);
    bit hs;
    hs = 0;
    @(negedge clk) begin araddr = a; arvalid = 1; rready = 1; end
    while (!hs) begin bit n; n = arvalid && arready; @(posedge clk); @(negedge clk); if (n) begin hs = 1; arvalid = 0; end end
    while (!rvalid) @(negedge clk);
    d = rdata;
    @(posedge clk); @(negedge clk) rready = 0;
  endtask

  // PPS every 1 ms of simulated time
  initial forever begin #1000000 pps = 1; #2000 pps = 0; end
  int irq_seen = 0;
  always @(posedge clk) if (irq) irq_seen++;

  logic [31:0] v, wrp, pkts, drops;
  int fd;
  initial begin
    #1 arst_n = 0;
    #100 arst_n = 1;
    repeat (10) @(posedge clk);
    rd(sf_regs_pkg::ADDR_ID, v); tb_check(v == 32'h41415244, "ID register");
    rd(sf_regs_pkg::ADDR_VERSION, v); tb_check(v == 32'h00010000, "VERSION register");
    // ---- DMA ring
    wr(sf_regs_pkg::ADDR_RING_BASE, 32'h0);
    wr(sf_regs_pkg::ADDR_RING_SIZE_LOG2, 32'd18);
    wr(sf_regs_pkg::ADDR_RD_PTR, 32'h0);
    wr(sf_regs_pkg::ADDR_IRQ_THRESHOLD, 32'd4096);
    wr(sf_regs_pkg::ADDR_IRQ_ENABLE, 32'h1);
    wr(sf_regs_pkg::ADDR_DMA_CONTROL, 32'h1);
    // ---- calibration: HSI entries 0..23, MS entries 0..11
    wr(sf_regs_pkg::ADDR_CAL_SEL, 32'd0);
    for (int i = 0; i < 24; i++) begin
      wr(sf_regs_pkg::ADDR_CAL_ADDR, 32'(i));
      wr(sf_regs_pkg::ADDR_CAL_DATA, {16'(16384 + i * 256), 16'(i)});
      wr(sf_regs_pkg::ADDR_CAL_FLAGS, (i == 5) ? 32'h1 : 32'h0);
      wr(sf_regs_pkg::ADDR_CAL_CMD, 32'h1);
    end
    wr(sf_regs_pkg::ADDR_CAL_SEL, 32'd1);
    for (int i = 0; i < 12; i++) begin
      wr(sf_regs_pkg::ADDR_CAL_ADDR, 32'(i));
      wr(sf_regs_pkg::ADDR_CAL_DATA, {16'd16384, 16'd10});
      wr(sf_regs_pkg::ADDR_CAL_FLAGS, 32'h0);
      wr(sf_regs_pkg::ADDR_CAL_CMD, 32'h1);
    end
    // ---- sensors
    wr(sf_regs_pkg::ADDR_HSI_GEOMETRY, {16'd3, 16'd8});
    wr(sf_regs_pkg::ADDR_HSI_EXPOSURE, 32'd50);
    wr(sf_regs_pkg::ADDR_HSI_SAT, 32'h0FFF);
    wr(sf_regs_pkg::ADDR_HSI_CONTROL, 32'h3);
    wr(sf_regs_pkg::ADDR_MS_GEOMETRY, {16'd2, 16'd6});
    wr(sf_regs_pkg::ADDR_MS_EXPOSURE, 32'd40);
    wr(sf_regs_pkg::ADDR_MS_SAT, 32'h0FFF);
    wr(sf_regs_pkg::ADDR_MS_LED_MASK, 32'h7);
    wr(sf_regs_pkg::ADDR_MS_CONTROL, 32'h0303);
    wr(sf_regs_pkg::ADDR_SWIR_GEOMETRY, {16'd2, 16'd4});
    wr(sf_regs_pkg::ADDR_SWIR_INTEGRATION, 32'd30);
    wr(sf_regs_pkg::ADDR_SWIR_SAT, 32'h3FFF);
    wr(sf_regs_pkg::ADDR_SWIR_CONTROL, 32'h1);
    wr(sf_regs_pkg::ADDR_RAMAN_NPIX, 32'd32);
    wr(sf_regs_pkg::ADDR_RAMAN_INTEG, 32'd2000);
    wr(sf_regs_pkg::ADDR_RAMAN_SAT, 32'hFFF0);
    wr(sf_regs_pkg::ADDR_RAMAN_CONTROL, 32'h0201);       // light, 2 co-adds
    wr(sf_regs_pkg::ADDR_LASER_DELAY, 32'd20);
    wr(sf_regs_pkg::ADDR_LASER_WD_TIMEOUT, 32'd50000000);
    wr(sf_regs_pkg::ADDR_LASER_ARM, 32'hA55A);
    wr(sf_regs_pkg::ADDR_IR_HALF_PERIOD, 32'd4);
    wr(sf_regs_pkg::ADDR_IR_NPERIODS, 32'd2);
    wr(sf_regs_pkg::ADDR_IR_SETTLE, 32'd1);
    wr(sf_regs_pkg::ADDR_IR_CONTROL, 32'h0201);
    wr(sf_regs_pkg::ADDR_FL_ON_SAMPLES, 32'd4);
    wr(sf_regs_pkg::ADDR_FL_BLANK_SAMPLES, 32'd1);
    wr(sf_regs_pkg::ADDR_FL_NPULSES, 32'd2);
    wr(sf_regs_pkg::ADDR_FL_CONTROL, 32'h0701);
    wr(sf_regs_pkg::ADDR_SONAR_RX_DELAY, 32'd2);
    wr(sf_regs_pkg::ADDR_SONAR_NSAMP, 32'd64);
    wr(sf_regs_pkg::ADDR_SONAR_ACK_TIMEOUT, 32'd5000);
    wr(sf_regs_pkg::ADDR_SONAR_CONTROL, 32'h3);
    wr(sf_regs_pkg::ADDR_EM_FTW, 32'd134217728);
    wr(sf_regs_pkg::ADDR_EM_NSAMP, 32'd64);
    wr(sf_regs_pkg::ADDR_EM_CONTROL, 32'h3);
    wr(sf_regs_pkg::ADDR_HK_PERIOD, 32'd40000);
    wr(sf_regs_pkg::ADDR_HK_CONTROL, 32'h3);
    wr(sf_regs_pkg::ADDR_DIAG_PERIOD, 32'd60000);
    wr(sf_regs_pkg::ADDR_HOST_TIMEOUT, 32'd0);
    wr(sf_regs_pkg::ADDR_DIAG_CONTROL, 32'h1);
    // ---- timing: 200 us frames; channel n offset n*100 cycles
    wr(sf_regs_pkg::ADDR_FRAME_PERIOD, 32'd20000);
    for (int c = 0; c < 8; c++) begin
      int div;
      div = (c == 3) ? 6 : (c == 4) ? 3 : (c == 7) ? 2 : 1;
      wr(sf_regs_pkg::ADDR_TRIG_DIV + 16'(4 * c), {16'd5, 16'(div)});
      wr(sf_regs_pkg::ADDR_TRIG_OFFSET + 16'(4 * c), 32'(c * 100));
    end
    wr(sf_regs_pkg::ADDR_TRIG_MASK, 32'hFF);
    wr(sf_regs_pkg::ADDR_SYNC_CONTROL, 32'h1);
    // ---- start: TEST_PATTERN latched while idle, then ACQ_EN
    wr(sf_regs_pkg::ADDR_CONTROL, 32'h6);
    wr(sf_regs_pkg::ADDR_CONTROL, 32'h7);
    rd(sf_regs_pkg::ADDR_STATUS, v);
    tb_check(v[0] && v[7], "STATUS: acquiring with TEST_PATTERN");
    rd(sf_regs_pkg::ADDR_LASER_STATUS, v);
    tb_check(v[0], "laser armed");
    // run ~2.5 ms
    for (int t = 0; t < 25; t++) begin
      #100000;
      wr(sf_regs_pkg::ADDR_LASER_KICK, 32'h1);
      if (t == 10) begin
        logic [31:0] lo, hi, lo2, hi2;
        wr(sf_regs_pkg::ADDR_TS_CONTROL, 32'h1);
        rd(sf_regs_pkg::ADDR_TS_SNAP_LO, lo); rd(sf_regs_pkg::ADDR_TS_SNAP_HI, hi);
        rd(sf_regs_pkg::ADDR_TS_SNAP_LO, lo2); rd(sf_regs_pkg::ADDR_TS_SNAP_HI, hi2);
        tb_check(lo == lo2 && hi == hi2, "timestamp snapshot stable between reads");
        tb_check(lo > 32'd50000, "timestamp advancing");
      end
    end
    // stop and drain
    wr(sf_regs_pkg::ADDR_CONTROL, 32'h4);
    #400000;
    rd(sf_regs_pkg::ADDR_WR_PTR, wrp);
    rd(sf_regs_pkg::ADDR_PKT_COUNT, pkts);
    rd(sf_regs_pkg::ADDR_DROP_COUNT, drops);
    tb_check(drops == 0, $sformatf("no DMA drops (%0d)", drops));
    // expected from the configured rates over ~2.5 ms: ~39 HSI + 26 MS + 26 SWIR + 26 acoustic + 13 ping +
    // 12 fluor + 6 EM + 5 IR + 2 Raman + HK + diag + laser events ~= 165-175
    tb_check(pkts >= 150 && pkts <= 200, $sformatf("packets committed %0d", pkts));
    tb_check(irq_seen > 0, "DMA threshold interrupt asserted");
    rd(sf_regs_pkg::ADDR_IRQ_STATUS, v); tb_check(v[0], "IRQ_STATUS.DMA_THRESH set");
    wr(sf_regs_pkg::ADDR_IRQ_STATUS, 32'h1);
    rd(sf_regs_pkg::ADDR_IRQ_STATUS, v); tb_check(!v[0], "IRQ_STATUS cleared (W1C)");
    rd(sf_regs_pkg::ADDR_DMA_STATUS, v); tb_check(!v[0] && !v[1], "DMA idle, no AXI error");
    fd = $fopen({`SF_VEC_DIR, "/top_registers.txt"}, "w");
    $fdisplay(fd, "WR_PTR %0d", wrp);
    $fdisplay(fd, "PKT_COUNT %0d", pkts);
    $fdisplay(fd, "DROP_COUNT %0d", drops);
    begin
      string names [12] = '{"HSI_FRAMES", "MS_FRAMES", "SWIR_FRAMES", "RAMAN_SPECTRA", "IR_SWEEPS", "FL_COUNT",
                            "SONAR_PINGS", "EM_COUNT", "PPS_COUNT", "ERR_TOTAL", "RAMAN_ERRORS", "FIFO_HWM"};
      logic [15:0] addrs [12] = '{sf_regs_pkg::ADDR_HSI_FRAMES, sf_regs_pkg::ADDR_MS_FRAMES, sf_regs_pkg::ADDR_SWIR_FRAMES,
                                  sf_regs_pkg::ADDR_RAMAN_SPECTRA, sf_regs_pkg::ADDR_IR_SWEEPS, sf_regs_pkg::ADDR_FL_COUNT,
                                  sf_regs_pkg::ADDR_SONAR_PINGS, sf_regs_pkg::ADDR_EM_COUNT, sf_regs_pkg::ADDR_PPS_COUNT,
                                  sf_regs_pkg::ADDR_ERR_TOTAL, sf_regs_pkg::ADDR_RAMAN_ERRORS, sf_regs_pkg::ADDR_FIFO_HWM};
      for (int i = 0; i < 12; i++) begin rd(addrs[i], v); $fdisplay(fd, "%s %0d", names[i], v); end
    end
    $fclose(fd);
    mem.dump({`SF_VEC_DIR, "/top_ring.hex"}, int'(wrp) / 4);
    rd(sf_regs_pkg::ADDR_HSI_FRAMES, v); tb_check(v >= 10, $sformatf("HSI lines %0d", v));
    rd(sf_regs_pkg::ADDR_RAMAN_SPECTRA, v); tb_check(v >= 1, $sformatf("Raman spectra %0d", v));
    rd(sf_regs_pkg::ADDR_PPS_COUNT, v); tb_check(v >= 2, $sformatf("PPS count %0d", v));
    tb_done("tb_sf_sensor_top");
  end
endmodule
