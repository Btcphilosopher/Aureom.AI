#!/usr/bin/env python3
"""Build and run the Aardvark Imaging SystemVerilog testbenches with Verilator.

Every testbench is self-checking and prints a single line
``TB_RESULT <name> PASS|FAIL ...``. This runner compiles each one (Verilator
``--binary --timing --assert``), runs it with randomised initial register
state (to expose missing resets), and writes ``results.json``.

Usage::

    python run_sims.py                 # all testbenches
    python run_sims.py tb_sf_sync_fifo tb_sf_dma_controller
    python run_sims.py --lint          # Verilator -Wall lint of the RTL only
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
VERIF = HERE.parent
HW = VERIF.parent
RTL = HW / "systemverilog"
TB_DIR = VERIF / "testbenches"
ASSERT_DIR = VERIF / "assertions"
VEC_DIR = VERIF / "vectors"
BUILD = HERE / "build"
ROM = RTL / "dsp" / "sf_sine_q15_quarter.hex"
RESULT_RE = re.compile(r"TB_RESULT (\S+) (PASS|FAIL)(.*)")


def rtl_files() -> list[Path]:
    out = []
    for line in (VERIF / "rtl_files.f").read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("//"):
            out.append(RTL / line)
    return out


def discover() -> list[str]:
    return sorted(p.stem for p in TB_DIR.glob("tb_sf_*.sv"))


def verilator() -> str | None:
    return shutil.which("verilator")


def build(name: str, seed: int = 7) -> tuple[bool, str, float]:
    bdir = BUILD / name
    bdir.mkdir(parents=True, exist_ok=True)
    VEC_DIR.mkdir(parents=True, exist_ok=True)
    srcs = [str(p) for p in rtl_files()]
    srcs += [str(p) for p in sorted(ASSERT_DIR.glob("*.sv"))]
    srcs += [str(TB_DIR / "tb_axi_mem.sv"), str(TB_DIR / "tb_src_sink.sv"), str(TB_DIR / f"{name}.sv")]
    cmd = [
        "verilator", "--binary", "--timing", "--assert", "-j", "2",
        "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTITOP", "-Wno-TIMESCALEMOD",
        "--x-assign", "unique", "--x-initial", "unique",
        f"+incdir+{TB_DIR}",
        f'+define+SF_VEC_DIR="{VEC_DIR}"',
        f'+define+SF_ROM_FILE="{ROM}"',
        "--top-module", name, "-Mdir", str(bdir), "-o", "Vtb",
        *srcs,
    ]
    t0 = time.time()
    proc = subprocess.run(cmd, capture_output=True, text=True)
    (bdir / "build.log").write_text(proc.stdout + proc.stderr)
    return proc.returncode == 0, proc.stdout + proc.stderr, time.time() - t0


def run(name: str, seed: int = 7, timeout: int = 180) -> dict:
    ok, log, bt = build(name, seed)
    res = {"name": name, "build_s": round(bt, 1), "status": "BUILD_FAIL", "checks": 0, "errors": None}
    if not ok:
        res["log_tail"] = log[-3000:]
        return res
    exe = BUILD / name / "Vtb"
    t0 = time.time()
    try:
        proc = subprocess.run(
            [str(exe), f"+verilator+seed+{seed}", "+verilator+rand+reset+2"],
            capture_output=True, text=True, timeout=timeout, cwd=str(BUILD / name),
        )
        out = proc.stdout + proc.stderr
    except subprocess.TimeoutExpired as exc:
        out = (exc.stdout or b"").decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        res.update(status="TIMEOUT", run_s=timeout)
        (BUILD / name / "run.log").write_text(out)
        return res
    (BUILD / name / "run.log").write_text(out)
    res["run_s"] = round(time.time() - t0, 2)
    m = RESULT_RE.search(out)
    if not m:
        res["status"] = "NO_RESULT"
        res["log_tail"] = out[-3000:]
        return res
    res["status"] = m.group(2)
    tail = m.group(3)
    c = re.search(r"checks=(\d+)", tail)
    e = re.search(r"errors=(\d+)", tail)
    res["checks"] = int(c.group(1)) if c else 0
    res["errors"] = int(e.group(1)) if e else 0
    if "%Error" in out or "Assertion failed" in out:
        res["status"] = "FAIL"
        res["log_tail"] = out[-3000:]
    if res["status"] != "PASS":
        res["log_tail"] = out[-3000:]
    return res


def lint() -> tuple[bool, str]:
    files = [str(p) for p in rtl_files()]
    cmd = ["verilator", "--lint-only", "-Wall", str(VERIF / "lint.vlt"), *files, "--top-module", "sf_sensor_top"]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    return proc.returncode == 0, proc.stdout + proc.stderr


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("names", nargs="*")
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) // 2))
    ap.add_argument("--lint", action="store_true")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--json", default=str(HERE / "results.json"))
    a = ap.parse_args(argv)
    if not verilator():
        print("verilator not found", file=sys.stderr)
        return 2
    if a.lint:
        ok, log = lint()
        print(log or "lint clean")
        return 0 if ok else 1
    names = a.names or discover()
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        results = list(ex.map(lambda n: run(n, a.seed), names))
    summary = {
        "simulator": subprocess.run(["verilator", "--version"], capture_output=True, text=True).stdout.strip(),
        "seed": a.seed,
        "results": results,
        "passed": sum(r["status"] == "PASS" for r in results),
        "total": len(results),
    }
    if not a.names:
        Path(a.json).write_text(json.dumps(summary, indent=2))
    for r in results:
        print(f"{r['status']:<10} {r['name']:<40} checks={r.get('checks')} build={r['build_s']}s run={r.get('run_s')}s")
        if r["status"] != "PASS":
            print(r.get("log_tail", "")[-1500:])
    print(f"{summary['passed']}/{summary['total']} testbenches passed")
    return 0 if summary["passed"] == summary["total"] else 1


if __name__ == "__main__":
    sys.exit(main())
