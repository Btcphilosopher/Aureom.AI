# Silica Flux architecture specification — AAI-SSA-1

Silica Flux version 0.1 · instrument AAI-SSA-1 · status: **reference design, simulated only**

## 1. Scope and definitions

Silica Flux is the hardware architecture and design methodology for the Aardvark Imaging sensor electronics.

* It is **not** a hardware description language.
* The digital hardware is implemented in synthesizable SystemVerilog.
* Silica Flux contributes three things:
  1. **The manifest** (`manifests/aardvark_ssa.sf.toml`). This is the single, machine-readable source of truth for the hardware contract: clock domains, bus, DMA, the packet format and flags, pixel sentinel codes, fixed-point formats, sensor channels and the register map.
  2. **The tool** (`aardvark sf validate|generate|check|budget`). It validates the manifest's cross-references and generates every artefact that must agree with it.
  3. **The rules** in this document. Every Silica Flux module follows them, so the RTL, the host software and the documentation cannot drift apart.

No Silica Flux language definition existed to reuse (see `docs/repository_inspection.md`), so none is invented here.

## 2. Generated artefacts (never hand-edited)

| Artefact | Path | Consumer |
|---|---|---|
| Register package | `hardware/systemverilog/pkg/sf_regs_pkg.sv` | RTL |
| AXI4-Lite register file | `hardware/systemverilog/common/sf_axil_regfile.sv` | RTL |
| Exhaustive register-file testbench | `hardware/verification/testbenches/tb_sf_axil_regfile.sv` | Verilator |
| Python register map | `backend/acquisition/generated_regmap.py` | host software |
| C header | `register_maps/aardvark_ssa_regs.h` | embedded host / drivers |
| Markdown + JSON register map | `register_maps/register_map.{md,json}` | engineers, UI |
| Q15 quarter-wave sine ROM | `hardware/systemverilog/dsp/sf_sine_q15_quarter.hex` | EM transmitter DDS |
| Data-rate budget | `docs/data_rate_budget.md` | system engineering |

* `aardvark sf check` exits non-zero if any generated file is stale. The unit suite runs this check (`test_manifest_valid_and_generated_files_current`).
* Each generated file carries the SHA-256 of the manifest it came from.

## 3. Manifest validation rules

The validator rejects a manifest that has any of the following:

* duplicate sensor keys or UIDs;
* unknown clock domains or packet types;
* duplicate packet-type codes;
* packet flags that are not unique bit positions 0–7;
* a sensor record larger than `max_payload_words`;
* overlapping registers or reused block bases;
* a register map that exceeds the bus address width;
* sensor status registers that do not exist.

## 4. System architecture

```
 sensors ──► acquisition ──► calibration ──► packetiser ──► DMA ──► ring buffer in host DDR ──► host (UIO)
 (CDC per      (row capture,   (dark/flat,     (SFP1, CRC,     (AXI4 INCR,     packet-atomic,       RingReader
  domain)       LVDS align,     sentinels)      12 sources,     64 B aligned)   WR_PTR committed     → raw spool
                ADC/SPI)                         round-robin)                    after B responses)   → processing
        ▲                                ▲
        │ trigger / exposure gate        │ 64-bit timestamp (PPS-disciplined)
   sf_sensor_sync ◄── sf_timestamp_engine ◄── PPS / external sync
   sf_laser_timing (key-armed, interlocked, watchdog)
```

### 4.1 Clock domains

| Domain | Frequency | Source | Crossing into `clk_sys` |
|---|---:|---|---|
| clk_sys | 100 MHz | PS pl_clk0 | — |
| clk_hsi | 74.25 MHz | HSI pixel clock | `sf_row_capture` → `sf_async_fifo` (Gray pointers) |
| clk_vid | 150 MHz | CSI-2 RX IP video clock | `sf_axis_video_ingest` → async FIFO |
| clk_swir | 40 MHz | ROIC pixel clock | `sf_row_capture` → async FIFO |
| clk_lvds | 50 MHz | acoustic ADC frame clock | synchronous to clk_sys in the reference RTL (ISERDES wrapper is vendor-specific) |

**CDC rules:**

* Single bits cross through `sf_cdc_bit` (2–3 flops, `ASYNC_REG`).
* Events cross through `sf_cdc_pulse`, a toggle handshake with a busy signal back to the source.
* Data crosses only through `sf_async_fifo`.
* Every domain resets through `sf_reset_sync`: asynchronous assert, synchronous de-assert.
* No other construct may cross a clock domain.
* `timing/sf_sensor_top.xdc` declares the asynchronous groups and bounds the Gray-pointer bus skew.

### 4.2 Timestamping and synchronisation

* `sf_timestamp_engine` is a 64-bit counter at `clk_sys`.
  * A PPS edge, after a 3-flop synchroniser, latches the counter value into `TS_PPS_LO/HI` and counts PPS events.
  * A missing PPS edge (timeout `PPS_TIMEOUT`) raises `PPS_LOST`.
  * Discipline happens on the host: `acquisition/timebase.py` fits counter frequency and offset to UTC from the latched PPS values, so no clock steering is done in hardware.
* **Convention:** an imager row carries the counter value of the first cycle of its exposure gate. Other records carry the time of their sample start.
* `sf_sensor_sync` generates per-sensor triggers from a programmable period and offset, fired at `OFFSET + 2` cycles after the period start. It can also follow an external sync input.

### 4.3 Laser safety (`sf_laser_timing`)

* Emission requires all of the following:
  * a key write of `0xA55A`;
  * the arm bit;
  * the hardware interlock closed;
  * the submerged input asserted (3-flop synchronised);
  * a host heartbeat inside the watchdog window.
* The on-time is capped by a register and by the hard limit `MAX_ON_HW`, which software cannot raise.
* Any fault drops emission within one clock and is latched until cleared.
* Every on/off transition emits a `LASER_EVENT` packet, so the emission history is part of the raw record.

### 4.4 Calibration engine (`sf_calibration_engine`)

* **Per-pixel formula:** `out = sat(round_half_up(max(raw − dark, 0) × gain_u2.14 / 2^14))`, clipped to `MAX_VALID` (0xFFFD).
* **Sentinels:**
  * Saturated raw input (≥ the saturation level) becomes 0xFFFF, even when calibration is bypassed.
  * Bad pixels become 0xFFFE.
* **Pipeline:** four stages with full back-pressure.
* **Tables:** dark and gain sit in per-imager RAMs written over the register bus.
* **Bit-exact reference:** `acquisition/fixedpoint.calibrate_pixels`. Agreement is checked on more than 3000 vectors in `tests/hardware/test_rtl_crosscheck.py`.

### 4.5 Packet format SFP1

| Word | Content |
|---|---|
| 0 | SYNC `0x53465031` ("SFP1") |
| 1 | `{version[31:24], sensor_uid[23:16], packet_type[15:8], flags[7:0]}` |
| 2 | sequence number (per packetiser, increments for every packet *offered*, so drops are visible) |
| 3 | frame number |
| 4 / 5 | timestamp high / low |
| 6 | `{payload_words[31:16], row[15:0]}` |
| 7 | meta (type-specific; imagers: `{ts_from_trigger[31], band[23:16], pixel_count[15:0]}`) |
| 8 … | payload |
| last | CRC-32/ISO-HDLC (zlib) over header + payload, little-endian bytes per word |

* **Flags:**
  * bit 0: SATURATED
  * bit 1: BAD_PIXEL
  * bit 2: OVERRUN_PRECEDED
  * bit 3: CALIBRATED
  * bit 4: LASER_ON
  * bit 5: DARK
  * bit 6: SIMULATED
  * bit 7: TRUNCATED
* **Test sources:** every test-pattern source sets SIMULATED. Real samples can never be mistaken for synthetic ones, or the reverse.

### 4.6 DMA and ring buffer

* **Write path:** `sf_dma_controller` writes whole packets into a power-of-two ring in host DDR, using AXI4 INCR bursts that are 64-byte aligned, with one burst outstanding.
* **Admission:** a packet is written only if it fits entirely. Otherwise it is dropped, `DMA_DROPS` increments, and the sequence gap tells the host exactly how many packets were lost.
* **Commit:** `WR_PTR` is committed only after every B response of the packet has returned. The host can never read a partial packet.
* **Efficiency:** 0.7619 words per cycle, measured in RTL simulation against a zero-wait AXI slave model. Real DDR latency will lower it.

### 4.7 Sensor channel modules

| Module | Function |
|---|---|
| `sf_hsi_controller` | push-broom row capture, exposure gate, test pattern, calibration, one packet per spectral row |
| `sf_multispectral_controller` | LED-sequenced bands (one LED on during each exposure), band tag in meta |
| `sf_swir_controller` | ROIC row capture, TEC-lock gating, calibration |
| `sf_raman_controller` | laser-gated CCD readout through `sf_adc_interface`, per-pixel co-adding, dark frames flagged DARK |
| `sf_ir_controller` | multi-line source sequencing, square-wave lock-in (`Σon − Σoff`), source switching aligned to the sample start |
| `sf_fluorescence_controller` | three-LED pulsed excitation with background (LED-off) windows |
| `sf_sonar_interface` | multibeam trigger, TX-ack timestamping; acoustic array sample segments |
| `sf_em_induction` | DDS transmitter (Q15 quarter-wave ROM), I/Q demodulation of receiver and Tx-current reference |
| `sf_fpga_diagnostics` / `sf_housekeeping` | error counters, FIFO high-water marks, uptime; SPI housekeeping ADC |

### 4.8 Vendor boundaries (not in the portable RTL)

* MIPI CSI-2 D-PHY and the CSI-2 RX subsystem. The RTL starts at its AXI4-Stream video output (`sf_axis_video_ingest`).
* ISERDES primitives for LVDS. The RTL starts at parallel words; `sf_lvds_aligner` does the bit-slip and frame alignment in fabric.
* The PS block design, the AXI HP port and the UIO device-tree node.
* The RGB0 context camera is declared in the manifest but not instantiated in `sf_sensor_top`. A second `sf_multispectral_controller` with a single band would serve it.

## 5. Coding rules (enforced by lint and review)

1. Synchronous active-low reset in each domain, released through `sf_reset_sync`. Every flop that controls a handshake or a counter is reset.
2. Every testbench runs with `--x-initial unique` and random initial state, so a missing reset fails.
3. The SystemVerilog subset is the one that Verilator 5 and Yosys 0.33 both accept:
   * no `import pkg::*` (use `pkg::NAME`);
   * functions assign to their own name instead of using `return`;
   * no packed 2-D or unpacked-array ports (use flattened vectors);
   * no `int'()` casts.
4. Every stream interface uses valid/ready, and data is held stable while `valid && !ready`. `assertions/sf_stream_checker.sv` and `sf_axi_write_checker.sv` check this in simulation.
5. No vendor primitives inside the portable RTL.
6. Every sensor packet path has a bit-exact Python model and a cross-check test.

## 6. Resource estimate (Yosys, not Vivado)

`hardware/verification/synthesis/utilisation_xcup.txt` has the details. A Yosys `synth_xilinx` estimate for UltraScale+ gives about 81 k LUTs, 16 k flip-flops, 31 DSP48E2 and 83 BRAM tiles:

* the per-pixel calibration RAMs set the block-RAM figure;
* the generated register file's read multiplexer accounts for most of the MUXF7/F8 count.

This is a mapping estimate only. **No place-and-route or timing closure has been performed.**
