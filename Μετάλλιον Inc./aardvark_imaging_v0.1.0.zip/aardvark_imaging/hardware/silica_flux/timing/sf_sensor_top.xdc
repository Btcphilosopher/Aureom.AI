# =============================================================================
# Aardvark Imaging AAI-SSA-1 — timing constraints TEMPLATE for sf_sensor_top
# Target (assumed): AMD Zynq UltraScale+ XCZU7EV.  NOT timing-closed.
#
# Status: written from the clock plan in manifests/aardvark_ssa.sf.toml and the
# CDC structures in the RTL. It has NOT been run through Vivado: pin
# locations, I/O standards and I/O delays depend on the carrier board and the
# camera/ADC parts, which are not selected. Treat every number below as a
# placeholder to be replaced from datasheets and the board timing model.
# =============================================================================

# ---------------------------------------------------------------- clocks
# clk_sys: PS pl_clk0. When the PS block design drives it, Vivado creates this
# clock automatically — delete this line in that flow.
create_clock -name clk_sys   -period 10.000 [get_ports clk]

# Forwarded / recovered sensor clocks (frequencies from the manifest).
create_clock -name clk_hsi   -period 13.468 [get_ports hsi_pclk]     ;# 74.25 MHz
create_clock -name clk_vid   -period  6.667 [get_ports vid_clk]      ;# 150 MHz (CSI-2 RX IP video clock)
create_clock -name clk_swir  -period 25.000 [get_ports swir_pclk]    ;# 40 MHz

# All sensor clocks are asynchronous to clk_sys and to each other. Every
# crossing in the RTL goes through sf_cdc_bit / sf_cdc_pulse / sf_async_fifo /
# sf_reset_sync, so the groups are declared asynchronous; the bus-skew and
# max-delay constraints below then bound the multi-bit Gray-code crossings.
set_clock_groups -asynchronous \
    -group [get_clocks clk_sys] \
    -group [get_clocks clk_hsi] \
    -group [get_clocks clk_vid] \
    -group [get_clocks clk_swir]

# ---------------------------------------------------------------- CDC
# Gray-coded FIFO pointers: limit skew between bits to less than one
# destination period so a synchroniser never samples a mixed code.
foreach fifo [get_cells -hier -filter {REF_NAME =~ sf_async_fifo*}] {
    set_max_delay -datapath_only -from [get_cells $fifo/wgray_reg[*]] -to [get_cells $fifo/rq1_wgray_reg[*]] 6.0
    set_max_delay -datapath_only -from [get_cells $fifo/rgray_reg[*]] -to [get_cells $fifo/wq1_rgray_reg[*]] 6.0
    set_bus_skew -from [get_cells $fifo/wgray_reg[*]] -to [get_cells $fifo/rq1_wgray_reg[*]] 5.0
    set_bus_skew -from [get_cells $fifo/rgray_reg[*]] -to [get_cells $fifo/wq1_rgray_reg[*]] 5.0
}

# Single-bit synchronisers: first stage carries ASYNC_REG in the RTL; give the
# path into it a generous datapath-only bound (it is a level or toggle).
set_max_delay -datapath_only -to [get_cells -hier -filter {NAME =~ */u_*/sync_reg[0]}] 8.0
set_max_delay -datapath_only -to [get_cells -hier -filter {NAME =~ */dst_tog_s_reg}] 8.0
set_max_delay -datapath_only -to [get_cells -hier -filter {NAME =~ */ack_s_reg}] 8.0

# Asynchronous reset input: reset assertion is asynchronous, de-assertion is
# synchronised per domain by sf_reset_sync.
set_false_path -from [get_ports arst_n]

# Truly asynchronous external inputs (synchronised inside the RTL).
set_false_path -from [get_ports {pps_in ext_sync_in}]
set_false_path -from [get_ports -quiet {sonar_tx_ack laser_submerged laser_interlock_n swir_tec_lock}]

# ---------------------------------------------------------------- I/O (PLACEHOLDERS)
# Hyperspectral parallel interface, source-synchronous to hsi_pclk.
# Replace with the camera datasheet tCO min/max and board trace delays.
set_input_delay -clock clk_hsi -max 4.0 [get_ports {hsi_data[*] hsi_fval hsi_lval}]
set_input_delay -clock clk_hsi -min 1.0 [get_ports {hsi_data[*] hsi_fval hsi_lval}]
set_input_delay -clock clk_swir -max 8.0 [get_ports -quiet {swir_data[*] swir_fval swir_lval}]
set_input_delay -clock clk_swir -min 1.0 [get_ports -quiet {swir_data[*] swir_fval swir_lval}]

# Exposure / trigger / laser outputs are timed by the RTL counters, not by
# the I/O path; jitter budget is set by the output buffer, not STA.
set_false_path -to [get_ports -quiet {hsi_exposure ms_led[*] swir_exposure laser_* sonar_trigger}]

# SPI / I2C: low-speed, sampled with the RTL's own clock-enable timing.
set_false_path -to   [get_ports -quiet {*_sclk *_cs_n *_mosi i2c_scl i2c_sda}]
set_false_path -from [get_ports -quiet {*_miso i2c_scl i2c_sda}]

# ---------------------------------------------------------------- acoustic LVDS
# The acoustic ADC (clk_lvds, 50 MHz frame clock) is deserialised by vendor
# ISERDES primitives that are not part of the portable RTL. Constrain the
# ISERDES clocking in the board-specific wrapper that instantiates them.
