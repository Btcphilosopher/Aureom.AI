// Packet ring-buffer DMA: SFP1 stream -> host memory over AXI4 (write only).
//
// Ring: RING_BASE (64-byte aligned), size 2**RING_SIZE_LOG2 bytes (>= 256).
// The host owns RD_PTR; the FPGA owns WR_PTR. Both are byte offsets.
//  * Admission is packet-atomic: at start of packet the whole packet length
//    (m_len words from the packetiser) is reserved if it fits in the free
//    space (one word is always kept free so full != empty); otherwise the
//    packet is consumed and dropped, DROP_COUNT increments and DROP raises an
//    interrupt event. Host software detects the gap from the sequence number.
//  * WR_PTR advances only after every beat of a packet has received an OKAY
//    or error write response, so the host never parses a partially written
//    packet.
//  * Bursts are INCR, 32-bit beats, at most 16 beats, and never cross a
//    64-byte boundary (hence never a 4 KiB boundary or the ring end).
//  * One burst outstanding at a time; sustained efficiency is measured in
//    simulation (tb_sf_dma_controller) and recorded in the manifest.
//  * Rising edge of `enable` resets WR_PTR/internal offsets to 0; the host
//    must set RD_PTR = 0 before enabling.
module sf_dma_controller #(
  parameter int FIFO_AW = 5,
  parameter int CFIFO_AW = 4
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        enable,
  input  logic [31:0] ring_base,
  input  logic [4:0]  ring_log2,
  input  logic [31:0] rd_ptr,
  input  logic [31:0] irq_threshold,
  input  logic        s_valid,
  output logic        s_ready,
  input  logic [31:0] s_data,
  input  logic        s_last,
  input  logic        s_sop,
  input  logic [15:0] s_len,
  output logic [31:0] m_axi_awaddr,
  output logic [7:0]  m_axi_awlen,
  output logic [2:0]  m_axi_awsize,
  output logic [1:0]  m_axi_awburst,
  output logic        m_axi_awvalid,
  input  logic        m_axi_awready,
  output logic [31:0] m_axi_wdata,
  output logic [3:0]  m_axi_wstrb,
  output logic        m_axi_wlast,
  output logic        m_axi_wvalid,
  input  logic        m_axi_wready,
  input  logic [1:0]  m_axi_bresp,
  input  logic        m_axi_bvalid,
  output logic        m_axi_bready,
  output logic [31:0] wr_ptr,
  output logic [31:0] fill_level,
  output logic [31:0] pkt_count,
  output logic [31:0] drop_count,
  output logic        busy,
  output logic        axi_error,
  output logic        dropping,
  output logic        thresh_evt,
  output logic        drop_evt
);
  logic [4:0]  lg;
  logic [31:0] size, mask;
  assign lg   = (ring_log2 < 5'd8) ? 5'd8 : ((ring_log2 > 5'd28) ? 5'd28 : ring_log2);
  assign size = 32'd1 << lg;
  assign mask = size - 32'd1;

  logic en_q, en_rise;
  assign en_rise = enable && !en_q;

  // ---------------------------------------------------------------- ingest
  typedef enum logic [1:0] {I_IDLE, I_PASS, I_DROP} ist_t;
  ist_t ist;
  logic [31:0] wr_spec, used_spec, free_b, need_b;
  logic [31:0] words_in;            // cumulative words admitted
  logic        bf_full, bf_valid, bf_rd, bf_ovf_u;
  logic [31:0] bf_data;
  logic [FIFO_AW+1:0] bf_level;
  logic        cf_full, cf_valid, cf_pop, cf_ovf_u;
  logic [63:0] cf_q;                // {end_word_count, end_offset}
  logic [CFIFO_AW+1:0] cf_level_u;
  logic        cf_push;
  logic [63:0] cf_wdata;

  assign used_spec = (wr_spec - rd_ptr) & mask;
  assign free_b    = size - used_spec - 32'd4;
  assign need_b    = {14'd0, s_len, 2'b00};

  always_comb begin
    s_ready = 1'b0;
    case (ist)
      I_PASS: s_ready = !bf_full;
      I_DROP: s_ready = 1'b1;
      default: s_ready = 1'b0;
    endcase
  end
  assign dropping = (ist == I_DROP);

  sf_sync_fifo #(.DW(32), .AW(FIFO_AW)) u_bf (
    .clk(clk), .rst_n(rst_n), .wr_en(ist == I_PASS && s_valid && s_ready), .wr_data(s_data), .full(bf_full),
    .overflow(bf_ovf_u), .rd_en(bf_rd), .rd_data(bf_data), .rd_valid(bf_valid), .level(bf_level)
  );
  sf_sync_fifo #(.DW(64), .AW(CFIFO_AW)) u_cf (
    .clk(clk), .rst_n(rst_n), .wr_en(cf_push), .wr_data(cf_wdata), .full(cf_full),
    .overflow(cf_ovf_u), .rd_en(cf_pop), .rd_data(cf_q), .rd_valid(cf_valid), .level(cf_level_u)
  );

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      ist <= I_IDLE; wr_spec <= '0; words_in <= '0; drop_count <= '0; drop_evt <= 1'b0; en_q <= 1'b0;
      cf_push <= 1'b0; cf_wdata <= '0;
    end else begin
      en_q <= enable;
      drop_evt <= 1'b0;
      cf_push <= 1'b0;
      if (en_rise) begin wr_spec <= '0; words_in <= '0; end
      case (ist)
        I_IDLE: if (enable && s_valid && s_sop && !cf_full) begin
          if (need_b <= free_b) begin
            ist <= I_PASS;
            wr_spec <= (wr_spec + need_b) & mask;
            cf_wdata <= {words_in + {16'd0, s_len}, (wr_spec + need_b) & mask};
          end else begin
            ist <= I_DROP;
            drop_count <= drop_count + 32'd1;
            drop_evt <= 1'b1;
          end
        end
        I_PASS: if (s_valid && s_ready) begin
          words_in <= words_in + 32'd1;
          if (s_last) begin ist <= I_IDLE; cf_push <= 1'b1; end
        end
        I_DROP: if (s_valid && s_last) ist <= I_IDLE;
        default: ist <= I_IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------- AXI write engine
  typedef enum logic [1:0] {W_IDLE, W_AW, W_DATA, W_RESP} wst_t;
  wst_t wst;
  logic [31:0] dma_off, words_done;
  logic [4:0]  blen, beats, room;
  logic [FIFO_AW+1:0] avail;

  assign room  = 5'd16 - {1'b0, dma_off[5:2]};
  assign avail = bf_level;
  assign m_axi_awsize  = 3'd2;
  assign m_axi_awburst = 2'b01;
  assign m_axi_wstrb   = 4'hF;
  assign m_axi_wdata   = bf_data;
  assign m_axi_bready  = (wst == W_RESP);
  assign m_axi_wvalid  = (wst == W_DATA) && bf_valid;
  assign m_axi_wlast   = (beats == 5'd1);
  assign bf_rd         = m_axi_wvalid && m_axi_wready;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      wst <= W_IDLE; dma_off <= '0; words_done <= '0; blen <= '0; beats <= '0; m_axi_awaddr <= '0; m_axi_awlen <= '0;
      m_axi_awvalid <= 1'b0; axi_error <= 1'b0;
    end else begin
      if (en_rise) begin dma_off <= '0; words_done <= '0; axi_error <= 1'b0; end
      case (wst)
        W_IDLE: begin
          if (avail != 0 && (avail >= {{(FIFO_AW-3){1'b0}}, room} || ist != I_PASS)) begin
            logic [4:0] l;
            l = (avail >= {{(FIFO_AW-3){1'b0}}, room}) ? room : avail[4:0];
            blen <= l; beats <= l;
            m_axi_awaddr <= ring_base + dma_off;
            m_axi_awlen <= {3'd0, l - 5'd1};
            m_axi_awvalid <= 1'b1;
            wst <= W_AW;
          end
        end
        W_AW: if (m_axi_awready) begin m_axi_awvalid <= 1'b0; wst <= W_DATA; end
        W_DATA: if (m_axi_wvalid && m_axi_wready) begin
          beats <= beats - 5'd1;
          if (beats == 5'd1) wst <= W_RESP;
        end
        W_RESP: if (m_axi_bvalid) begin
          if (m_axi_bresp != 2'b00) axi_error <= 1'b1;
          words_done <= words_done + {27'd0, blen};
          dma_off <= (dma_off + {25'd0, blen, 2'b00}) & mask;
          wst <= W_IDLE;
        end
        default: wst <= W_IDLE;
      endcase
    end
  end

  // ---------------------------------------------------------------- commit
  // Wrap-safe comparison of cumulative word counters.
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] cdiff;
  /* verilator lint_on UNUSEDSIGNAL */
  assign cdiff = words_done - cf_q[63:32];
  assign cf_pop = cf_valid && !cdiff[31];
  logic thr_q;
  always_ff @(posedge clk) begin
    if (!rst_n) begin wr_ptr <= '0; pkt_count <= '0; thr_q <= 1'b0; thresh_evt <= 1'b0; end
    else begin
      thresh_evt <= 1'b0;
      if (en_rise) wr_ptr <= '0;
      else if (cf_pop) begin wr_ptr <= cf_q[31:0]; pkt_count <= pkt_count + 32'd1; end
      thr_q <= (irq_threshold != 0) && (fill_level >= irq_threshold);
      if ((irq_threshold != 0) && (fill_level >= irq_threshold) && !thr_q) thresh_evt <= 1'b1;
    end
  end
  assign fill_level = (wr_ptr - rd_ptr) & mask;
  assign busy = (ist != I_IDLE) || (wst != W_IDLE) || bf_valid || cf_valid;

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_d;
  assign unused_d = bf_ovf_u ^ cf_ovf_u ^ (^cf_level_u) ^ (^avail[FIFO_AW+1:5]);
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
