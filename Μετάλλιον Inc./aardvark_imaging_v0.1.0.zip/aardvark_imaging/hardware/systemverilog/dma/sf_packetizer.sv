// SFP1 packetiser: N store-and-forward source ports -> one framed stream.
//
// Source contract (per port): payload words on s_valid/s_ready/s_data, the
// final word marked s_last, with the packet descriptor (flags, frame, row,
// meta, ts) valid on that final beat. Payload length 1..2**STAGE_AW words.
//
// Packet format (all 32-bit words, little-endian on the host):
//   W0 SYNC 0x53465031 ("SFP1")
//   W1 {version[31:24], sensor_uid[23:16], packet_type[15:8], flags[7:0]}
//   W2 global sequence number (increments per emitted packet, wraps)
//   W3 frame counter            W4 timestamp[63:32]    W5 timestamp[31:0]
//   W6 {payload_words[31:16], row[15:0]}               W7 meta
//   payload...                  CRC-32/ISO-HDLC over W0..last payload word
// The SIMULATED flag is OR-ed into every packet staged while test_mode=1.
// Arbitration: round robin between sources with a complete staged packet;
// packets are atomic on the output.
module sf_packetizer #(
  parameter int              N         = 4,
  parameter logic [8*N-1:0]  SRC_UID   = '0,
  parameter logic [8*N-1:0]  SRC_PTYPE = '0,
  parameter int              STAGE_AW  = 11
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic              test_mode,
  input  logic [N-1:0]      s_valid,
  output logic [N-1:0]      s_ready,
  input  logic [32*N-1:0]   s_data,
  input  logic [N-1:0]      s_last,
  input  logic [8*N-1:0]    s_flags,
  input  logic [32*N-1:0]   s_frame,
  input  logic [16*N-1:0]   s_row,
  input  logic [32*N-1:0]   s_meta,
  input  logic [64*N-1:0]   s_ts,
  output logic              m_valid,
  input  logic              m_ready,
  output logic [31:0]       m_data,
  output logic              m_last,
  output logic              m_sop,
  output logic [15:0]       m_len,
  output logic [31:0]       seq,
  output logic [15:0]       stage_hwm
);
  localparam int DW = 8 + 32 + 16 + 32 + 64 + 16;   // descriptor width
  localparam int SW = (N > 1) ? $clog2(N) : 1;

  logic [N-1:0]        pay_full, pay_rd_valid, pay_rd_en, desc_full, desc_valid, desc_pop;
  logic [32*N-1:0]     pay_rd_data;
  logic [DW*N-1:0]     desc_q;
  logic [16*N-1:0]     wc;
  logic [(STAGE_AW+2)*N-1:0] pay_level;

  genvar g;
  generate
    for (g = 0; g < N; g++) begin : g_src
      logic wr, dw, pov_u, dov_u;
      logic [DW-1:0] dd;
      logic [2:0] dlev_u;
      assign s_ready[g] = !pay_full[g] && !desc_full[g];
      assign wr = s_valid[g] && s_ready[g];
      assign dw = wr && s_last[g];
      assign dd = {s_flags[8*g +: 8] | {1'b0, test_mode, 6'b0}, s_frame[32*g +: 32], s_row[16*g +: 16],
                   s_meta[32*g +: 32], s_ts[64*g +: 64], wc[16*g +: 16] + 16'd1};
      always_ff @(posedge clk) begin
        if (!rst_n) wc[16*g +: 16] <= '0;
        else if (wr) wc[16*g +: 16] <= s_last[g] ? 16'd0 : wc[16*g +: 16] + 16'd1;
      end
      sf_sync_fifo #(.DW(32), .AW(STAGE_AW)) u_pay (
        .clk(clk), .rst_n(rst_n), .wr_en(wr), .wr_data(s_data[32*g +: 32]), .full(pay_full[g]), .overflow(pov_u),
        .rd_en(pay_rd_en[g]), .rd_data(pay_rd_data[32*g +: 32]), .rd_valid(pay_rd_valid[g]),
        .level(pay_level[(STAGE_AW+2)*g +: STAGE_AW+2])
      );
      sf_sync_fifo #(.DW(DW), .AW(1)) u_desc (
        .clk(clk), .rst_n(rst_n), .wr_en(dw), .wr_data(dd), .full(desc_full[g]), .overflow(dov_u),
        .rd_en(desc_pop[g]), .rd_data(desc_q[DW*g +: DW]), .rd_valid(desc_valid[g]), .level(dlev_u)
      );
      /* verilator lint_off UNUSEDSIGNAL */
      logic unused_g;
      assign unused_g = pov_u ^ dov_u ^ (^dlev_u);
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate

  // ---------------------------------------------------- output framing
  typedef enum logic [1:0] {O_IDLE, O_HDR, O_PAY, O_CRC} st_t;
  st_t st;
  logic [SW-1:0] sel, last_sel;
  logic [2:0]    hidx;
  logic [15:0]   rem;
  logic [31:0]   crc;
  logic [DW-1:0] cur;
  logic [7:0]    c_flags;
  logic [31:0]   c_frame, c_meta;
  logic [15:0]   c_row, c_len;
  logic [63:0]   c_ts;
  logic          found;
  logic [SW-1:0] pick;

  assign {c_flags, c_frame, c_row, c_meta, c_ts, c_len} = cur;

  always_comb begin
    found = 1'b0;
    pick = last_sel;
    for (int k = 1; k <= N; k++) begin
      /* verilator lint_off UNUSEDSIGNAL */
      int idx;
      /* verilator lint_on UNUSEDSIGNAL */
      idx = (32'(last_sel) + k) % N;
      if (!found && desc_valid[idx]) begin found = 1'b1; pick = SW'(idx); end
    end
  end

  logic [31:0] hdr_word;
  always_comb begin
    case (hidx)
      3'd0: hdr_word = sf_pkg::SFP_SYNC;
      3'd1: hdr_word = {sf_pkg::SFP_VERSION, SRC_UID[8*sel +: 8], SRC_PTYPE[8*sel +: 8], c_flags};
      3'd2: hdr_word = seq;
      3'd3: hdr_word = c_frame;
      3'd4: hdr_word = c_ts[63:32];
      3'd5: hdr_word = c_ts[31:0];
      3'd6: hdr_word = {c_len, c_row};
      default: hdr_word = c_meta;
    endcase
  end

  always_comb begin
    m_valid = 1'b0; m_data = 32'h0; m_last = 1'b0; m_sop = 1'b0;
    pay_rd_en = '0; desc_pop = '0;
    case (st)
      O_HDR: begin m_valid = 1'b1; m_data = hdr_word; m_sop = (hidx == 3'd0); end
      O_PAY: begin
        m_valid = pay_rd_valid[sel];
        m_data = pay_rd_data[32*sel +: 32];
        pay_rd_en[sel] = m_ready && pay_rd_valid[sel];
      end
      O_CRC: begin
        m_valid = 1'b1; m_data = ~crc; m_last = 1'b1;
        desc_pop[sel] = m_ready;
      end
      default: ;
    endcase
  end
  assign m_len = c_len + 16'd9;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= O_IDLE; sel <= '0; last_sel <= SW'(N - 1); hidx <= '0; rem <= '0; crc <= 32'hFFFFFFFF; cur <= '0; seq <= '0;
    end else begin
      case (st)
        O_IDLE: if (found) begin
          sel <= pick; cur <= desc_q[DW*pick +: DW]; hidx <= '0; crc <= 32'hFFFFFFFF; st <= O_HDR;
        end
        O_HDR: if (m_ready) begin
          crc <= sf_util_pkg::crc32_word(crc, hdr_word);
          if (hidx == 3'd7) begin st <= O_PAY; rem <= c_len; end
          hidx <= hidx + 3'd1;
        end
        O_PAY: if (m_valid && m_ready) begin
          crc <= sf_util_pkg::crc32_word(crc, m_data);
          if (rem == 16'd1) st <= O_CRC;
          rem <= rem - 16'd1;
        end
        O_CRC: if (m_ready) begin
          st <= O_IDLE; seq <= seq + 32'd1; last_sel <= sel;
        end
        default: st <= O_IDLE;
      endcase
    end
  end

  // staging high-water mark (diagnostics)
  always_ff @(posedge clk) begin
    if (!rst_n) stage_hwm <= '0;
    else begin
      for (int i = 0; i < N; i++) begin
        if (16'(pay_level[(STAGE_AW+2)*i +: STAGE_AW+2]) > stage_hwm) stage_hwm <= 16'(pay_level[(STAGE_AW+2)*i +: STAGE_AW+2]);
      end
    end
  end
endmodule
