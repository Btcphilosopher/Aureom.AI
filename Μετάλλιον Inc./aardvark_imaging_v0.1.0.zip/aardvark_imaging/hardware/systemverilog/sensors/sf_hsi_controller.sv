// Hyperspectral push-broom imager controller.
// A push-broom "line" is one detector frame: ROWS spectral rows (bands) of
// PIXELS spatial pixels. Each spectral row becomes one HSI_ROW packet
// (row = band index, frame = push-broom line number).
//  * Exposure: trigger-width mode. On a synchronised trigger the controller
//    drives cam_exposure for EXPOSURE cycles and records the exposure-start
//    timestamp in the row-capture context FIFO.
//  * Camera interface: FVAL/LVAL/16-bit data from the vendor LVDS deserialiser
//    in the camera pixel clock domain (clk_hsi).
//  * test_mode replaces the camera with sf_test_pattern (SIMULATED packets).
module sf_hsi_controller #(
  parameter int FIFO_AW = 11,
  parameter int CAL_AW  = 10
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic              pclk,
  input  logic              prst_n,
  input  logic              cam_fval,
  input  logic              cam_lval,
  input  logic [15:0]       cam_data,
  output logic              cam_exposure,
  input  logic              enable,
  input  logic              cal_en,
  input  logic              test_mode,
  input  logic [15:0]       cfg_pixels,
  input  logic [15:0]       cfg_rows,
  input  logic [31:0]       exposure_cycles,
  input  logic [15:0]       sat_level,
  input  logic              trig,
  input  logic [63:0]       ts_now,
  input  logic              cal_we,
  input  logic [CAL_AW-1:0] cal_waddr,
  input  logic [32:0]       cal_wdata,
  output logic              src_valid,
  input  logic              src_ready,
  output logic [31:0]       src_data,
  output logic              src_last,
  output logic [7:0]        src_flags,
  output logic [31:0]       src_frame,
  output logic [15:0]       src_row,
  output logic [31:0]       src_meta,
  output logic [63:0]       src_ts,
  output logic [31:0]       status,
  output logic [31:0]       frames,
  output logic [31:0]       errors,
  output logic              exposure_evt,
  output logic              error_evt
);
  // ---------------- exposure timing (clk_sys)
  logic        exposing, ctx_push, pat_start_sys;
  logic [31:0] ecnt;
  logic [15:0] len_errs, ovr_errs;
  logic        frame_done, len_evt, ovr_evt;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      exposing <= 1'b0; ecnt <= '0; ctx_push <= 1'b0; pat_start_sys <= 1'b0; exposure_evt <= 1'b0;
      frames <= '0; len_errs <= '0; ovr_errs <= '0; error_evt <= 1'b0;
    end else begin
      ctx_push <= 1'b0; pat_start_sys <= 1'b0; exposure_evt <= 1'b0; error_evt <= 1'b0;
      // Exposure countdown runs independently of trigger handling so a trigger
      // arriving mid-exposure can never stretch the exposure.
      if (exposing) begin
        if (ecnt <= 32'd1) begin
          exposing <= 1'b0;
          pat_start_sys <= test_mode;
        end else ecnt <= ecnt - 32'd1;
      end
      if (trig && enable) begin
        if (exposing) begin
          if (ovr_errs != 16'hFFFF) ovr_errs <= ovr_errs + 16'd1;
          error_evt <= 1'b1;
        end else begin
          exposing <= 1'b1; ecnt <= (exposure_cycles == 0) ? 32'd1 : exposure_cycles;
          ctx_push <= 1'b1; exposure_evt <= 1'b1;
        end
      end
      if (!enable) exposing <= 1'b0;
      if (frame_done && frames != 32'hFFFFFFFF) frames <= frames + 32'd1;
      if (len_evt) begin
        if (len_errs != 16'hFFFF) len_errs <= len_errs + 16'd1;
        error_evt <= 1'b1;
      end
      if (ovr_evt) begin
        if (ovr_errs != 16'hFFFF) ovr_errs <= ovr_errs + 16'd1;
        error_evt <= 1'b1;
      end
    end
  end
  assign cam_exposure = exposing;
  assign errors = {ovr_errs, len_errs};

  // ---------------- pixel domain: adapter / test pattern mux
  logic pat_start_p, pat_busy, test_p, pbusy_unused;
  sf_cdc_pulse u_pat (.src_clk(clk), .src_rst_n(rst_n), .src_pulse(pat_start_sys), .src_busy(pbusy_unused),
                      .dst_clk(pclk), .dst_rst_n(prst_n), .dst_pulse(pat_start_p));
  sf_cdc_bit u_test (.clk(pclk), .rst_n(prst_n), .d(test_mode), .q(test_p));

  logic        a_v, a_sof, a_eol, t_v, t_sof, t_eol;
  logic [15:0] a_d, t_d;
  sf_lvfv_adapter u_lvfv (.clk(pclk), .rst_n(prst_n), .fval(cam_fval), .lval(cam_lval), .data(cam_data),
                          .px_valid(a_v), .px_data(a_d), .px_sof(a_sof), .px_eol(a_eol));
  // Geometry registers are quasi-static (only changed while ENABLE=0) and are
  // treated as false paths into the pixel domain (see timing constraints).
  sf_test_pattern u_pat_gen (.clk(pclk), .rst_n(prst_n), .start(pat_start_p), .pixels(cfg_pixels), .rows(cfg_rows),
                             .busy(pat_busy), .px_valid(t_v), .px_data(t_d), .px_sof(t_sof), .px_eol(t_eol));

  logic        m_v, m_sof, m_eol;
  logic [15:0] m_d;
  assign m_v   = test_p ? t_v   : a_v;
  assign m_d   = test_p ? t_d   : a_d;
  assign m_sof = test_p ? t_sof : a_sof;
  assign m_eol = test_p ? t_eol : a_eol;

  logic [15:0] fifo_level;
  sf_row_capture #(.FIFO_AW(FIFO_AW), .CAL_AW(CAL_AW)) u_rows (
    .pclk(pclk), .prst_n(prst_n), .px_valid(m_v), .px_data(m_d), .px_sof(m_sof), .px_eol(m_eol),
    .clk(clk), .rst_n(rst_n), .enable(enable), .cal_en(cal_en), .sat_level(sat_level),
    .cfg_pixels(cfg_pixels), .cfg_rows(cfg_rows),
    .cal_we(cal_we), .cal_waddr(cal_waddr), .cal_wdata(cal_wdata),
    .ctx_push(ctx_push), .ctx_ts(ts_now), .ctx_band(8'd0), .ts_now(ts_now),
    .src_valid(src_valid), .src_ready(src_ready), .src_data(src_data), .src_last(src_last), .src_flags(src_flags),
    .src_frame(src_frame), .src_row(src_row), .src_meta(src_meta), .src_ts(src_ts),
    .fifo_level(fifo_level), .frame_done(frame_done), .length_err_evt(len_evt), .overrun_evt(ovr_evt)
  );

  logic [3:0] state;
  assign state = !enable ? 4'd0 : (exposing ? 4'd1 : ((fifo_level != 0 || src_valid) ? 4'd2 : 4'd3));
  assign status = {fifo_level, 11'd0, exposing, state};

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_h;
  assign unused_h = pat_busy ^ pbusy_unused;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
