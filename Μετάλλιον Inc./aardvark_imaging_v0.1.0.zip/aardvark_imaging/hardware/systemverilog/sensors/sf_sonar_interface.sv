// Acoustic sensor interface.
// (1) Multibeam echosounder (MBES): the FPGA issues the ping trigger and
//     timestamps both the trigger and the sonar's TX-acknowledge line. The
//     MBES bathymetry datagrams travel over Ethernet to the host, which joins
//     them to SONAR_PING events by ping number / timestamp. Payload (6 words):
//     ping, trig_ts_hi, trig_ts_lo, ack_ts_hi, ack_ts_lo, status{ack_ok}.
// (2) High-frequency imaging array: after RX_DELAY array samples, captures
//     NSAMP samples of NCH channels (aligned LVDS ADC words, sign-extended to
//     16 bits) and streams them in ACOUSTIC_SAMPLES segments of SEG_SAMPLES
//     samples (channel-interleaved, 2 channels per word). frame = ping number,
//     row = segment index, meta = {NCH, 8'd0, samples_in_segment}.
//     A sample arriving before the previous one has drained is dropped and
//     the segment is flagged TRUNCATED | OVERRUN_PRECEDED.
module sf_sonar_interface #(
  parameter int NCH         = 8,
  parameter int SEG_SAMPLES = 128,
  parameter int TRIG_WIDTH  = 1000
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic              enable,
  input  logic              array_en,
  input  logic [23:0]       rx_delay,
  input  logic [15:0]       nsamp,
  input  logic [31:0]       ack_timeout,
  input  logic              trig,
  input  logic [63:0]       ts_now,
  output logic              mbes_trigger,
  input  logic              tx_ack_async,
  input  logic              arr_aligned,
  input  logic              arr_valid,
  input  logic [NCH*16-1:0] arr_data,
  // ping events
  output logic              p_valid,
  input  logic              p_ready,
  output logic [31:0]       p_data,
  output logic              p_last,
  output logic [7:0]        p_flags,
  output logic [31:0]       p_frame,
  output logic [15:0]       p_row,
  output logic [31:0]       p_meta,
  output logic [63:0]       p_ts,
  // array samples
  output logic              a_valid,
  input  logic              a_ready,
  output logic [31:0]       a_data,
  output logic              a_last,
  output logic [7:0]        a_flags,
  output logic [31:0]       a_frame,
  output logic [15:0]       a_row,
  output logic [31:0]       a_meta,
  output logic [63:0]       a_ts,
  output logic [31:0]       status,
  output logic [31:0]       pings,
  output logic [31:0]       errors,
  output logic              ping_evt,
  output logic              error_evt
);
  localparam int WPS = NCH / 2;   // words per sample
  // ------------------------------------------------ ping / MBES
  typedef enum logic [1:0] {P_IDLE, P_WAIT, P_EMIT} pst_t;
  pst_t pst;
  logic ack_s, ack_q, ack_ok;
  logic [31:0] tw, tmo;
  logic [63:0] trig_ts, ack_ts;
  logic [2:0]  pidx;
  logic [15:0] ack_errs, ovr_errs;
  sf_cdc_bit u_ack (.clk(clk), .rst_n(rst_n), .d(tx_ack_async), .q(ack_s));

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      pst <= P_IDLE; ack_q <= 1'b0; ack_ok <= 1'b0; tw <= '0; tmo <= '0; trig_ts <= '0; ack_ts <= '0; pidx <= '0;
      pings <= '0; ack_errs <= '0; mbes_trigger <= 1'b0; ping_evt <= 1'b0;
      p_valid <= 1'b0; p_data <= '0; p_last <= 1'b0; p_flags <= '0; p_frame <= '0; p_row <= '0; p_meta <= '0; p_ts <= '0;
    end else begin
      ack_q <= ack_s;
      ping_evt <= 1'b0;
      if (tw != 0) tw <= tw - 32'd1;
      mbes_trigger <= (tw > 32'd1);
      case (pst)
        P_IDLE: if (trig && enable) begin
          pst <= P_WAIT; trig_ts <= ts_now; tw <= 32'(TRIG_WIDTH) + 32'd1; tmo <= ack_timeout; ack_ok <= 1'b0;
          ack_ts <= '0; ping_evt <= 1'b1;
        end
        P_WAIT: begin
          if (ack_s && !ack_q) begin ack_ts <= ts_now; ack_ok <= 1'b1; pst <= P_EMIT; pidx <= '0; end
          else if (tmo == 0) begin
            pst <= P_EMIT; pidx <= '0;
            if (ack_errs != 16'hFFFF) ack_errs <= ack_errs + 16'd1;
          end else tmo <= tmo - 32'd1;
        end
        P_EMIT: begin
          if (!p_valid || p_ready) begin
            if (p_valid && p_last) begin p_valid <= 1'b0; pst <= P_IDLE; pings <= pings + 32'd1; end
            else begin
              p_valid <= 1'b1;
              case (pidx)
                3'd0: p_data <= pings;
                3'd1: p_data <= trig_ts[63:32];
                3'd2: p_data <= trig_ts[31:0];
                3'd3: p_data <= ack_ts[63:32];
                3'd4: p_data <= ack_ts[31:0];
                default: p_data <= {31'd0, ack_ok};
              endcase
              p_last <= (pidx == 3'd5);
              p_flags <= 8'd0; p_frame <= pings; p_row <= 16'd0; p_meta <= 32'd0; p_ts <= trig_ts;
              pidx <= pidx + 3'd1;
            end
          end
        end
        default: pst <= P_IDLE;
      endcase
      if (!enable && pst != P_EMIT) pst <= P_IDLE;
    end
  end

  // ------------------------------------------------ array capture
  typedef enum logic [1:0] {A_IDLE, A_DELAY, A_CAP} ast_t;
  ast_t ast;
  logic [23:0] dcnt;
  logic [15:0] scnt, seg_cnt, seg_acc, seg, ns;
  logic [NCH*16-1:0] hold;
  logic [7:0]  hw;            // words of the held sample still to emit
  logic        hold_last_seg, seg_trunc, drain_now;
  logic [31:0] cap_ping;
  logic [63:0] seg_ts;
  logic [7:0]  d_flags;
  logic [31:0] d_frame, d_meta;
  logic [15:0] d_row;
  logic [63:0] d_ts;

  assign ns = (nsamp == 0) ? 16'd1 : nsamp;
  assign drain_now = (hw != 0) && (!a_valid || a_ready);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      ast <= A_IDLE; dcnt <= '0; scnt <= '0; seg_cnt <= '0; seg_acc <= '0; seg <= '0; hold <= '0; hw <= '0;
      hold_last_seg <= 1'b0; seg_trunc <= 1'b0; cap_ping <= '0; seg_ts <= '0; ovr_errs <= '0; error_evt <= 1'b0;
      d_flags <= '0; d_frame <= '0; d_meta <= '0; d_row <= '0; d_ts <= '0;
      a_valid <= 1'b0; a_data <= '0; a_last <= 1'b0; a_flags <= '0; a_frame <= '0; a_row <= '0; a_meta <= '0; a_ts <= '0;
    end else begin
      error_evt <= 1'b0;
      if (a_valid && a_ready) a_valid <= 1'b0;
      if (drain_now) begin
        logic [7:0] widx;
        widx = 8'(WPS) - hw;
        a_valid <= 1'b1;
        a_data  <= hold[32*widx +: 32];
        a_last  <= (hw == 8'd1) && hold_last_seg;
        if (hw == 8'd1 && hold_last_seg) begin
          a_flags <= d_flags; a_frame <= d_frame; a_row <= d_row; a_meta <= d_meta; a_ts <= d_ts;
        end
        hw <= hw - 8'd1;
      end
      case (ast)
        A_IDLE: if (trig && enable && array_en) begin
          ast <= (rx_delay == 0) ? A_CAP : A_DELAY; dcnt <= rx_delay; scnt <= '0; seg_cnt <= '0; seg_acc <= '0;
          seg <= '0; cap_ping <= pings; seg_trunc <= 1'b0;
        end
        A_DELAY: if (arr_valid) begin
          if (dcnt <= 24'd1) ast <= A_CAP;
          dcnt <= dcnt - 24'd1;
        end
        A_CAP: if (arr_valid) begin
          logic is_seg_end, is_end, accepted;
          logic [15:0] acc_n;
          is_end     = (scnt == ns - 16'd1);
          is_seg_end = is_end || (seg_cnt == 16'(SEG_SAMPLES - 1));
          accepted   = (hw == 0) || (hw == 8'd1 && drain_now);
          acc_n      = seg_acc + (accepted ? 16'd1 : 16'd0);
          if (seg_cnt == 0) seg_ts <= ts_now;
          if (accepted) begin
            hold <= arr_data; hw <= 8'(WPS); hold_last_seg <= is_seg_end;
          end else begin
            seg_trunc <= 1'b1;
            if (ovr_errs != 16'hFFFF) ovr_errs <= ovr_errs + 16'd1;
            error_evt <= 1'b1;
            // Segment ends on a dropped sample: terminate it on the held sample
            // if that sample belongs to this segment.
            if (is_seg_end && seg_acc != 0) hold_last_seg <= 1'b1;
          end
          if (is_seg_end) begin
            if (acc_n != 0) begin
              d_flags <= (seg_trunc || !accepted || !arr_aligned) ? 8'h84 : 8'h00;
              d_frame <= cap_ping; d_row <= seg;
              d_meta  <= {8'(NCH), 8'd0, acc_n};
              d_ts    <= (seg_cnt == 0) ? ts_now : seg_ts;
            end
            seg <= seg + 16'd1; seg_cnt <= '0; seg_acc <= '0; seg_trunc <= 1'b0;
          end else begin
            seg_cnt <= seg_cnt + 16'd1; seg_acc <= acc_n;
          end
          scnt <= scnt + 16'd1;
          if (is_end) ast <= A_IDLE;
        end
        default: ast <= A_IDLE;
      endcase
      if (!enable) ast <= A_IDLE;
    end
  end
  assign status = {26'd0, arr_aligned, 1'b0, ast, pst};
  assign errors = {ovr_errs, ack_errs};
endmodule
