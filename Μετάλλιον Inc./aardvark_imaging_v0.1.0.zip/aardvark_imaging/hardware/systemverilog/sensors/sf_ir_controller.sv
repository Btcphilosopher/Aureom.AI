// Mid-IR ATR acquisition with square-wave lock-in demodulation.
// For each of NBANDS source lines (QCL/ICL selected by band_sel), the source
// is modulated on/off with HALF_PERIOD ADC samples per half cycle for
// NPERIODS cycles. The first SETTLE samples after every edge are discarded.
//   demod = sum(on) - sum(off)    total = sum(on) + sum(off)    (s64 each)
// Payload per band: demod_lo, demod_hi, total_lo, total_hi (4 words).
// The sample phase is latched at conversion start, so ADC latency does not
// mix phases.
module sf_ir_controller #(
  parameter int SAMPLE_PERIOD = 200,
  parameter int BITS = 18
) (
  input  logic            clk,
  input  logic            rst_n,
  input  logic            enable,
  input  logic [3:0]      nbands,
  input  logic [23:0]     half_period,
  input  logic [15:0]     nperiods,
  input  logic [15:0]     settle,
  input  logic            trig,
  input  logic [63:0]     ts_now,
  output logic            source_on,
  output logic [3:0]      band_sel,
  output logic            adc_start,
  input  logic            adc_valid,
  input  logic [BITS-1:0] adc_data,
  output logic            src_valid,
  input  logic            src_ready,
  output logic [31:0]     src_data,
  output logic            src_last,
  output logic [7:0]      src_flags,
  output logic [31:0]     src_frame,
  output logic [15:0]     src_row,
  output logic [31:0]     src_meta,
  output logic [63:0]     src_ts,
  output logic [31:0]     status,
  output logic [31:0]     sweeps,
  output logic            sweep_evt
);
  typedef enum logic [1:0] {I_IDLE, I_RUN, I_DRAIN, I_EMIT} st_t;
  st_t st;
  logic [3:0]  nb;
  logic [15:0] tcnt;
  logic [23:0] si, hp;
  logic [15:0] pcnt;
  logic        ph, done_starts;
  logic        l_ph, l_keep, l_last;
  logic signed [63:0] acc_on, acc_off;
  logic [63:0] res [0:15];
  logic [5:0]  eidx;
  logic [63:0] ts_l;
  logic signed [63:0] xs;

  assign nb = (nbands == 0) ? 4'd1 : ((nbands > 4'd8) ? 4'd8 : nbands);
  assign hp = (half_period == 0) ? 24'd1 : half_period;
  assign xs = {{(64-BITS){adc_data[BITS-1]}}, adc_data};

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= I_IDLE; tcnt <= '0; si <= '0; pcnt <= '0; ph <= 1'b1; done_starts <= 1'b0; band_sel <= '0;
      l_ph <= 1'b0; l_keep <= 1'b0; l_last <= 1'b0; acc_on <= '0; acc_off <= '0; eidx <= '0; ts_l <= '0;
      adc_start <= 1'b0; source_on <= 1'b0; sweeps <= '0; sweep_evt <= 1'b0;
      src_valid <= 1'b0; src_data <= '0; src_last <= 1'b0; src_flags <= '0; src_frame <= '0; src_row <= '0;
      src_meta <= '0; src_ts <= '0;
      for (int i = 0; i < 16; i++) res[i] <= '0;
    end else begin
      adc_start <= 1'b0; sweep_evt <= 1'b0;
      case (st)
        I_IDLE: begin
          source_on <= 1'b0;
          if (trig && enable) begin
            st <= I_RUN; band_sel <= '0; si <= '0; pcnt <= '0; ph <= 1'b1; tcnt <= '0; done_starts <= 1'b0;
            acc_on <= '0; acc_off <= '0; ts_l <= ts_now; sweep_evt <= 1'b1;
          end
        end
        I_RUN, I_DRAIN: begin
          if (st == I_RUN && !done_starts) begin
            if (tcnt == 16'(SAMPLE_PERIOD - 1)) begin
              tcnt <= '0;
              adc_start <= 1'b1;
              // The source follows the phase of the sample being started, so a
              // modulation edge coincides with the first (settling) sample of
              // a half period, never with the last sample of the previous one.
              source_on <= ph;
              l_ph <= ph; l_keep <= (si >= {8'd0, settle});
              l_last <= 1'b0;
              if (si == hp - 24'd1) begin
                si <= '0;
                ph <= ~ph;
                if (!ph) begin
                  if (pcnt == ((nperiods == 0) ? 16'd0 : nperiods - 16'd1)) begin
                    l_last <= 1'b1; done_starts <= 1'b1; st <= I_DRAIN;
                  end
                  pcnt <= pcnt + 16'd1;
                end
              end else si <= si + 24'd1;
            end else tcnt <= tcnt + 16'd1;
          end
          if (adc_valid) begin
            logic signed [63:0] on_n, off_n;
            on_n = acc_on; off_n = acc_off;
            if (l_keep) begin
              if (l_ph) on_n = acc_on + xs; else off_n = acc_off + xs;
            end
            acc_on <= on_n; acc_off <= off_n;
            if (l_last) begin
              res[{band_sel[2:0], 1'b0}] <= on_n - off_n;
              res[{band_sel[2:0], 1'b1}] <= on_n + off_n;
              acc_on <= '0; acc_off <= '0;
              if (band_sel + 4'd1 >= nb) begin st <= I_EMIT; eidx <= '0; source_on <= 1'b0; end
              else begin
                band_sel <= band_sel + 4'd1; st <= I_RUN; si <= '0; pcnt <= '0; ph <= 1'b1; tcnt <= '0; done_starts <= 1'b0;
              end
            end
          end
        end
        I_EMIT: begin
          if (!src_valid || src_ready) begin
            if (src_valid && src_last) begin
              src_valid <= 1'b0; st <= I_IDLE; sweeps <= sweeps + 32'd1;
            end else begin
              logic [63:0] w;
              w = res[eidx[4:1]];
              src_valid <= 1'b1;
              src_data <= eidx[0] ? w[63:32] : w[31:0];
              src_last <= (eidx == {nb, 2'b00} - 6'd1);
              src_flags <= 8'd0; src_frame <= sweeps; src_row <= 16'd0;
              src_meta <= {4'd0, nb, half_period}; src_ts <= ts_l;
              eidx <= eidx + 6'd1;
            end
          end
        end
        default: st <= I_IDLE;
      endcase
      if (!enable && st != I_EMIT) begin st <= I_IDLE; source_on <= 1'b0; end
    end
  end
  // res index: word eidx -> band = eidx[5:2], which = eidx[1] (0 demod,1 total), half = eidx[0]
  assign status = {23'd0, source_on, band_sel, 2'd0, st};
endmodule
