// Pulsed-LED fluorometer acquisition (3 excitation LEDs x 3 emission
// channels sampled simultaneously by a 3-lane SAR ADC).
// For every excitation e enabled in EXC_MASK, NPULSES on/off pulse pairs are
// acquired. Each window is ON_SAMPLES ADC samples; the first BLANK samples
// after every LED transition are discarded (LED/TIA settling). Ambient and
// detector offset cancel in the on-minus-off difference.
// Payload: for e = 0..2, c = 0..2: diff[e][c] (s32, saturated), off[e][c]
// (u32, saturated) -> 18 words. Disabled excitations report zeros.
module sf_fluorescence_controller #(
  parameter int SAMPLE_PERIOD = 200
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        enable,
  input  logic [2:0]  exc_mask,
  input  logic [15:0] on_samples,
  input  logic [15:0] blank_samples,
  input  logic [15:0] npulses,
  input  logic        trig,
  input  logic [63:0] ts_now,
  output logic [2:0]  led,
  output logic        adc_start,
  input  logic        adc_valid,
  input  logic [47:0] adc_data,        // lane c at [16c +: 16], unsigned
  output logic        src_valid,
  input  logic        src_ready,
  output logic [31:0] src_data,
  output logic        src_last,
  output logic [7:0]  src_flags,
  output logic [31:0] src_frame,
  output logic [15:0] src_row,
  output logic [31:0] src_meta,
  output logic [63:0] src_ts,
  output logic [31:0] status,
  output logic [31:0] blocks,
  output logic        block_evt
);
  typedef enum logic [2:0] {F_IDLE, F_NEXT, F_RUN, F_DRAIN, F_EMIT} st_t;
  st_t st;
  logic [1:0]  exc;
  logic [15:0] tcnt, si, pcnt, ons;
  logic        ph, l_ph, l_keep, l_last, done_starts;
  logic [47:0] acc_on [0:2];
  logic [47:0] acc_off [0:2];
  logic [31:0] res [0:17];
  logic [4:0]  eidx;
  logic [63:0] ts_l;

  assign ons = (on_samples == 0) ? 16'd1 : on_samples;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= F_IDLE; exc <= '0; tcnt <= '0; si <= '0; pcnt <= '0; ph <= 1'b1; l_ph <= 1'b0; l_keep <= 1'b0;
      l_last <= 1'b0; done_starts <= 1'b0; eidx <= '0; ts_l <= '0; led <= '0; adc_start <= 1'b0;
      blocks <= '0; block_evt <= 1'b0;
      src_valid <= 1'b0; src_data <= '0; src_last <= 1'b0; src_flags <= '0; src_frame <= '0; src_row <= '0;
      src_meta <= '0; src_ts <= '0;
      for (int c = 0; c < 3; c++) begin acc_on[c] <= '0; acc_off[c] <= '0; end
      for (int i = 0; i < 18; i++) res[i] <= '0;
    end else begin
      adc_start <= 1'b0; block_evt <= 1'b0;
      case (st)
        F_IDLE: begin
          led <= '0;
          if (trig && enable) begin
            st <= F_NEXT; exc <= 2'd0; ts_l <= ts_now; block_evt <= 1'b1;
            for (int i = 0; i < 18; i++) res[i] <= '0;
          end
        end
        F_NEXT: begin
          if (exc == 2'd3) begin st <= F_EMIT; eidx <= '0; led <= '0; end
          else if (!exc_mask[exc]) exc <= exc + 2'd1;
          else begin
            st <= F_RUN; si <= '0; pcnt <= '0; ph <= 1'b1; tcnt <= '0; done_starts <= 1'b0;
            for (int c = 0; c < 3; c++) begin acc_on[c] <= '0; acc_off[c] <= '0; end
          end
        end
        F_RUN, F_DRAIN: begin
          if (st == F_RUN && !done_starts) begin
            if (tcnt == 16'(SAMPLE_PERIOD - 1)) begin
              tcnt <= '0; adc_start <= 1'b1;
              // LED follows the phase of the sample being started (see IR controller).
              led <= ph ? (3'd1 << exc) : 3'd0;
              l_ph <= ph; l_keep <= (si >= blank_samples); l_last <= 1'b0;
              if (si == ons - 16'd1) begin
                si <= '0; ph <= ~ph;
                if (!ph) begin
                  if (pcnt == ((npulses == 0) ? 16'd0 : npulses - 16'd1)) begin
                    l_last <= 1'b1; done_starts <= 1'b1; st <= F_DRAIN;
                  end
                  pcnt <= pcnt + 16'd1;
                end
              end else si <= si + 16'd1;
            end else tcnt <= tcnt + 16'd1;
          end
          if (adc_valid) begin
            logic [47:0] on_n [0:2];
            logic [47:0] off_n [0:2];
            for (int c = 0; c < 3; c++) begin
              on_n[c] = acc_on[c]; off_n[c] = acc_off[c];
              if (l_keep) begin
                if (l_ph) on_n[c] = acc_on[c] + {32'd0, adc_data[16*c +: 16]};
                else off_n[c] = acc_off[c] + {32'd0, adc_data[16*c +: 16]};
              end
              acc_on[c] <= on_n[c]; acc_off[c] <= off_n[c];
            end
            if (l_last) begin
              for (int c = 0; c < 3; c++) begin
                res[6*exc + 2*c]     <= sf_util_pkg::sat_s64_to_s32($signed({16'd0, on_n[c]}) - $signed({16'd0, off_n[c]}));
                res[6*exc + 2*c + 1] <= sf_util_pkg::sat_u64_to_u32({16'd0, off_n[c]});
              end
              exc <= exc + 2'd1;
              st <= F_NEXT;
              led <= '0;
            end
          end
        end
        F_EMIT: begin
          if (!src_valid || src_ready) begin
            if (src_valid && src_last) begin
              src_valid <= 1'b0; st <= F_IDLE; blocks <= blocks + 32'd1;
            end else begin
              src_valid <= 1'b1;
              src_data <= res[eidx];
              src_last <= (eidx == 5'd17);
              src_flags <= 8'd0; src_frame <= blocks; src_row <= 16'd0;
              src_meta <= {5'd0, exc_mask, 8'd0, npulses}; src_ts <= ts_l;
              eidx <= eidx + 5'd1;
            end
          end
        end
        default: st <= F_IDLE;
      endcase
      if (!enable && st != F_EMIT) begin st <= F_IDLE; led <= '0; end
    end
  end
  assign status = {25'd0, (st == F_RUN) ? 3'(1 << exc) : 3'd0, 1'b0, st};
endmodule
