// Raman spectrometer acquisition controller (TE-cooled CCD read through a
// SAR ADC). One trigger acquires COADD exposures and emits their per-pixel
// sum as one RAMAN_SPECTRUM packet (u32 per pixel).
//  * Light exposures request the excitation laser via sf_laser_timing and
//    integrate only while it is emitting. DARK mode integrates with the laser
//    held off (same integration time) for dark/background subtraction.
//  * The laser is released before CCD readout.
//  * Laser abort or loss of emission during integration discards the
//    accumulation (no partial spectrum is emitted) and counts LASER_ABORT.
//  * Co-adding is a read-modify-write into a dual-port accumulator RAM.
//  * CCD pixels are paced by both PIX_PERIOD and ADC completion (one
//    conversion outstanding), so no pixel can be lost to an ADC overrun.
//  * Cosmic-ray rejection is NOT done here; it needs individual exposures and
//    runs on the host (set COADD=1 and acquire repeats when it is required).
module sf_raman_controller #(
  parameter int NPIX_MAX   = 2048,
  parameter int PIX_PERIOD = 64,
  parameter int LASER_WAIT = 1 << 20
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        enable,
  input  logic        dark_mode,
  input  logic [7:0]  coadd,
  input  logic [11:0] npix,
  input  logic [31:0] integ_cycles,
  input  logic [15:0] sat_level,
  input  logic        trig,
  input  logic [63:0] ts_now,
  output logic        laser_gate_req,
  input  logic        laser_emitting,
  input  logic        laser_abort,
  output logic        ccd_integrate,
  output logic        ccd_pixel,
  output logic        adc_start,
  input  logic        adc_valid,
  input  logic [15:0] adc_data,
  output logic        src_valid,
  input  logic        src_ready,
  output logic [31:0] src_data,
  output logic        src_last,
  output logic [7:0]  src_flags,
  output logic [31:0] src_frame,
  output logic [15:0] src_row,
  output logic [31:0] src_meta,
  output logic [63:0] src_ts,
  output logic [31:0] status,
  output logic [31:0] spectra,
  output logic [31:0] errors,
  output logic        integ_evt,
  output logic        error_evt
);
  localparam int AW = $clog2(NPIX_MAX);
  typedef enum logic [2:0] {R_IDLE, R_PREP, R_WAIT_LASER, R_INTEG, R_READ, R_EMIT, R_EMIT_WAIT} st_t;
  st_t st;
  logic [31:0] acc [0:NPIX_MAX-1];
  logic [31:0] acc_q, cnt;
  logic [7:0]  k, coadd_l;
  logic [11:0] np, pix_req, pix_got, eidx;
  logic        dark_l, sat_any;
  logic [15:0] aborts, overruns;
  logic [63:0] ts_l;
  logic [7:0]  pp;
  // RMW pipeline
  logic        a_v, a_first;
  logic [AW-1:0] a_idx, rd_addr;
  logic [15:0] a_pix;
  logic        rd_en;

  assign np = (npix == 0) ? 12'd1 : ((npix > 12'(NPIX_MAX)) ? 12'(NPIX_MAX) : npix);

  always_ff @(posedge clk) begin
    if (rd_en) acc_q <= acc[rd_addr];
  end
  always_ff @(posedge clk) begin
    if (a_v) acc[a_idx] <= (a_first ? 32'd0 : acc_q) + {16'd0, a_pix};
  end

  always_comb begin
    rd_en = 1'b0;
    rd_addr = '0;
    if (st == R_READ && adc_valid) begin rd_en = 1'b1; rd_addr = pix_got[AW-1:0]; end
    else if (st == R_EMIT) begin rd_en = 1'b1; rd_addr = eidx[AW-1:0]; end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= R_IDLE; cnt <= '0; k <= '0; coadd_l <= 8'd1; pix_req <= '0; pix_got <= '0; eidx <= '0; dark_l <= 1'b0;
      sat_any <= 1'b0; aborts <= '0; overruns <= '0; ts_l <= '0; pp <= '0; spectra <= '0;
      laser_gate_req <= 1'b0; ccd_integrate <= 1'b0; ccd_pixel <= 1'b0; adc_start <= 1'b0;
      a_v <= 1'b0; a_first <= 1'b0; a_idx <= '0; a_pix <= '0;
      src_valid <= 1'b0; src_data <= '0; src_last <= 1'b0; src_flags <= '0; src_frame <= '0; src_row <= '0;
      src_meta <= '0; src_ts <= '0; integ_evt <= 1'b0; error_evt <= 1'b0;
    end else begin
      adc_start <= 1'b0; ccd_pixel <= 1'b0; a_v <= 1'b0; integ_evt <= 1'b0; error_evt <= 1'b0;
      if (trig && enable && st != R_IDLE) begin
        if (overruns != 16'hFFFF) overruns <= overruns + 16'd1;
        error_evt <= 1'b1;
      end
      case (st)
        R_IDLE: begin
          laser_gate_req <= 1'b0; ccd_integrate <= 1'b0;
          if (trig && enable) begin
            k <= '0; coadd_l <= (coadd == 0) ? 8'd1 : coadd; dark_l <= dark_mode; sat_any <= 1'b0; ts_l <= ts_now;
            st <= R_PREP;
          end
        end
        R_PREP: begin
          if (dark_l) begin st <= R_INTEG; cnt <= (integ_cycles == 0) ? 32'd1 : integ_cycles; ccd_integrate <= 1'b1; integ_evt <= 1'b1; end
          else begin laser_gate_req <= 1'b1; cnt <= 32'(LASER_WAIT); st <= R_WAIT_LASER; end
        end
        R_WAIT_LASER: begin
          if (laser_emitting) begin
            st <= R_INTEG; cnt <= (integ_cycles == 0) ? 32'd1 : integ_cycles; ccd_integrate <= 1'b1; integ_evt <= 1'b1;
          end else if (laser_abort || cnt == 0) begin
            st <= R_IDLE; laser_gate_req <= 1'b0;
            if (aborts != 16'hFFFF) aborts <= aborts + 16'd1;
            error_evt <= 1'b1;
          end else cnt <= cnt - 32'd1;
        end
        R_INTEG: begin
          if (!dark_l && (laser_abort || !laser_emitting)) begin
            st <= R_IDLE; laser_gate_req <= 1'b0; ccd_integrate <= 1'b0;
            if (aborts != 16'hFFFF) aborts <= aborts + 16'd1;
            error_evt <= 1'b1;
          end else if (cnt <= 32'd1) begin
            ccd_integrate <= 1'b0; laser_gate_req <= 1'b0;
            pix_req <= '0; pix_got <= '0; pp <= '0; st <= R_READ;
          end else cnt <= cnt - 32'd1;
        end
        R_READ: begin
          // Pixel pacing: at most one conversion outstanding, and at least
          // PIX_PERIOD cycles between pixels. The readout therefore never
          // outruns the ADC, whatever PIX_PERIOD is set to.
          if (pix_req != np) begin
            if (pp >= 8'(PIX_PERIOD - 1) && pix_req == pix_got && !adc_start) begin
              pp <= '0; adc_start <= 1'b1; ccd_pixel <= 1'b1; pix_req <= pix_req + 12'd1;
            end else if (pp != 8'hFF) pp <= pp + 8'd1;
          end
          if (adc_valid) begin
            a_v <= 1'b1; a_first <= (k == 0); a_idx <= pix_got[AW-1:0]; a_pix <= adc_data;
            if (adc_data >= sat_level) sat_any <= 1'b1;
            pix_got <= pix_got + 12'd1;
            if (pix_got == np - 12'd1) begin
              k <= k + 8'd1;
              if (k + 8'd1 >= coadd_l) begin st <= R_EMIT; eidx <= '0; end
              else st <= R_PREP;
            end
          end
        end
        R_EMIT: begin
          // read issued this cycle for eidx; data valid next cycle
          st <= R_EMIT_WAIT;
        end
        R_EMIT_WAIT: begin
          if (!src_valid) begin
            src_valid <= 1'b1;
            src_data  <= acc_q;
            src_last  <= (eidx == np - 12'd1);
            if (eidx == np - 12'd1) begin
              src_flags <= {2'b00, dark_l, ~dark_l, 3'b000, sat_any};
              src_frame <= spectra;
              src_row   <= 16'd0;
              src_meta  <= {coadd_l, 12'd0, np};
              src_ts    <= ts_l;
            end
          end else if (src_ready) begin
            src_valid <= 1'b0;
            if (src_last) begin st <= R_IDLE; spectra <= spectra + 32'd1; end
            else begin eidx <= eidx + 12'd1; st <= R_EMIT; end
          end
        end
        default: st <= R_IDLE;
      endcase
      if (!enable && st != R_EMIT && st != R_EMIT_WAIT) begin
        st <= R_IDLE; laser_gate_req <= 1'b0; ccd_integrate <= 1'b0;
      end
    end
  end
  assign status = {16'd0, k, 3'd0, laser_gate_req, 1'b0, st};
  assign errors = {overruns, aborts};
endmodule
