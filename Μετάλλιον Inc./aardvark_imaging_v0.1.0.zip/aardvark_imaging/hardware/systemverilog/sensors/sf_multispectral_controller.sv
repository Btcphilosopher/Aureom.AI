// Multispectral controller: global-shutter camera behind a vendor MIPI CSI-2
// receiver (AXI4-Stream video, clk_vid) with sequential narrowband LED
// illumination. Each trigger selects the next enabled LED band (round robin
// over NBANDS, skipping bands masked off in LED_MASK), strobes that LED for
// the exposure window, and tags all rows of the resulting frame with the band
// index in meta[23:16]. One MS_ROW packet per image row.
module sf_multispectral_controller #(
  parameter int FIFO_AW = 11,
  parameter int CAL_AW  = 10
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic              vclk,
  input  logic              vrst_n,
  input  logic              s_axis_tvalid,
  output logic              s_axis_tready,
  input  logic [15:0]       s_axis_tdata,
  input  logic              s_axis_tuser,
  input  logic              s_axis_tlast,
  output logic              cam_trigger,
  output logic [7:0]        led,
  input  logic              enable,
  input  logic              cal_en,
  input  logic              test_mode,
  input  logic [3:0]        nbands,
  input  logic [7:0]        led_mask,
  input  logic [15:0]       cfg_width,
  input  logic [15:0]       cfg_height,
  input  logic [31:0]       exposure_cycles,
  input  logic [15:0]       sat_level,
  input  logic              trig,
  input  logic [63:0]       ts_now,
  input  logic              cal_we,
  input  logic [CAL_AW-1:0] cal_waddr,
  input  logic [32:0]       cal_wdata,
  output logic              src_valid,
  input  logic              src_ready,
  output logic [31:0]       src_data,
  output logic              src_last,
  output logic [7:0]        src_flags,
  output logic [31:0]       src_frame,
  output logic [15:0]       src_row,
  output logic [31:0]       src_meta,
  output logic [63:0]       src_ts,
  output logic [31:0]       status,
  output logic [31:0]       frames,
  output logic [31:0]       errors,
  output logic              exposure_evt,
  output logic              error_evt
);
  logic        exposing, ctx_push, pat_start_sys, have_band;
  logic [31:0] ecnt;
  logic [2:0]  band, next_band;
  logic [15:0] len_errs, ovr_errs;
  logic        frame_done, len_evt, ovr_evt;
  logic [3:0]  nb;

  assign nb = (nbands == 0) ? 4'd1 : ((nbands > 4'd8) ? 4'd8 : nbands);

  // Next enabled band after `band` (round robin), combinational search. A
  // band register outside 0..NBANDS-1 (reset value, or NBANDS reduced) is
  // treated as "before band 0" so the sequence always restarts at band 0.
  logic [2:0] base;
  assign base = (32'(band) >= 32'(nb)) ? 3'(nb - 4'd1) : band;
  always_comb begin
    next_band = band;
    have_band = 1'b0;
    for (int k = 1; k <= 8; k++) begin
      logic [2:0] cand;
      cand = 3'((32'(base) + k) % 32'(nb));
      if (!have_band && (32'(k) <= 32'(nb)) && led_mask[cand]) begin
        next_band = cand;
        have_band = 1'b1;
      end
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      exposing <= 1'b0; ecnt <= '0; ctx_push <= 1'b0; pat_start_sys <= 1'b0; exposure_evt <= 1'b0;
      band <= 3'd7; led <= '0; frames <= '0; len_errs <= '0; ovr_errs <= '0; error_evt <= 1'b0;
    end else begin
      ctx_push <= 1'b0; pat_start_sys <= 1'b0; exposure_evt <= 1'b0; error_evt <= 1'b0;
      if (exposing) begin
        if (ecnt <= 32'd1) begin
          exposing <= 1'b0; led <= '0;
          pat_start_sys <= test_mode;
        end else ecnt <= ecnt - 32'd1;
      end
      if (trig && enable) begin
        if (exposing || !have_band) begin
          if (ovr_errs != 16'hFFFF) ovr_errs <= ovr_errs + 16'd1;
          error_evt <= 1'b1;
        end else begin
          exposing <= 1'b1; ecnt <= (exposure_cycles == 0) ? 32'd1 : exposure_cycles;
          band <= next_band;
          led <= 8'd1 << next_band;
          ctx_push <= 1'b1; exposure_evt <= 1'b1;
        end
      end
      if (!enable) begin exposing <= 1'b0; led <= '0; end
      if (frame_done && frames != 32'hFFFFFFFF) frames <= frames + 32'd1;
      if (len_evt) begin if (len_errs != 16'hFFFF) len_errs <= len_errs + 16'd1; error_evt <= 1'b1; end
      if (ovr_evt) begin if (ovr_errs != 16'hFFFF) ovr_errs <= ovr_errs + 16'd1; error_evt <= 1'b1; end
    end
  end
  assign cam_trigger = exposing;
  assign errors = {ovr_errs, len_errs};

  logic pat_start_v, pat_busy, test_v, pbusy_unused;
  sf_cdc_pulse u_pat (.src_clk(clk), .src_rst_n(rst_n), .src_pulse(pat_start_sys), .src_busy(pbusy_unused),
                      .dst_clk(vclk), .dst_rst_n(vrst_n), .dst_pulse(pat_start_v));
  sf_cdc_bit u_test (.clk(vclk), .rst_n(vrst_n), .d(test_mode), .q(test_v));

  logic        a_v, a_sof, a_eol, t_v, t_sof, t_eol;
  logic [15:0] a_d, t_d;
  sf_axis_video_ingest u_axis (.clk(vclk), .rst_n(vrst_n), .s_axis_tvalid(s_axis_tvalid), .s_axis_tready(s_axis_tready),
                               .s_axis_tdata(s_axis_tdata), .s_axis_tuser(s_axis_tuser), .s_axis_tlast(s_axis_tlast),
                               .px_valid(a_v), .px_data(a_d), .px_sof(a_sof), .px_eol(a_eol));
  sf_test_pattern u_pat_gen (.clk(vclk), .rst_n(vrst_n), .start(pat_start_v), .pixels(cfg_width), .rows(cfg_height),
                             .busy(pat_busy), .px_valid(t_v), .px_data(t_d), .px_sof(t_sof), .px_eol(t_eol));

  logic        m_v, m_sof, m_eol;
  logic [15:0] m_d;
  assign m_v   = test_v ? t_v   : a_v;
  assign m_d   = test_v ? t_d   : a_d;
  assign m_sof = test_v ? t_sof : a_sof;
  assign m_eol = test_v ? t_eol : a_eol;

  logic [15:0] fifo_level;
  sf_row_capture #(.FIFO_AW(FIFO_AW), .CAL_AW(CAL_AW)) u_rows (
    .pclk(vclk), .prst_n(vrst_n), .px_valid(m_v), .px_data(m_d), .px_sof(m_sof), .px_eol(m_eol),
    .clk(clk), .rst_n(rst_n), .enable(enable), .cal_en(cal_en), .sat_level(sat_level),
    .cfg_pixels(cfg_width), .cfg_rows(cfg_height),
    .cal_we(cal_we), .cal_waddr(cal_waddr), .cal_wdata(cal_wdata),
    .ctx_push(ctx_push), .ctx_ts(ts_now), .ctx_band({5'd0, band}), .ts_now(ts_now),   // ctx_push is registered: `band` already holds the selected band
    .src_valid(src_valid), .src_ready(src_ready), .src_data(src_data), .src_last(src_last), .src_flags(src_flags),
    .src_frame(src_frame), .src_row(src_row), .src_meta(src_meta), .src_ts(src_ts),
    .fifo_level(fifo_level), .frame_done(frame_done), .length_err_evt(len_evt), .overrun_evt(ovr_evt)
  );

  logic [3:0] state;
  assign state = !enable ? 4'd0 : (exposing ? 4'd1 : ((fifo_level != 0 || src_valid) ? 4'd2 : 4'd3));
  assign status = {fifo_level, 7'd0, exposing, 1'b0, band, state};

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_m;
  assign unused_m = pat_busy ^ pbusy_unused;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
