// =============================================================================
// sf_sensor_top — Aardvark Imaging Subsea Sensor Array (AAI-SSA-1) FPGA top.
// =============================================================================
// Integrates the Silica Flux register file, timing/synchronisation, all sensor
// controllers, the SFP1 packetiser and the ring-buffer DMA.
//
// Clock domains: clk (clk_sys, 100 MHz) for control/data movement and all
// low-rate sensors; hsi_pclk, vid_clk, swir_pclk for the imager pixel
// domains (async FIFOs inside sf_row_capture). Resets are synchronised per
// domain from the single asynchronous arst_n.
//
// Vendor primitives are NOT instantiated here: LVDS ISERDES, MIPI D-PHY/CSI-2
// RX, PS AXI interconnect and clocking are wrapped in the board-specific shell
// (see docs/silica_flux.md, "Board shell boundary").
// =============================================================================
module sf_sensor_top #(
  parameter int CAL_AW     = 18,       // per-imager calibration RAM entries = 2**CAL_AW
  parameter int ROW_FIFO_AW = 11,
  parameter int STAGE_AW   = 11,
  parameter int RAMAN_NPIX = 2048,
  parameter int RAMAN_PIX_PERIOD = 160,
  parameter int ADC_SAMPLE_PERIOD = 200,
  parameter int ARR_NCH    = 8,
  parameter int ARR_W      = 14,
  parameter int ARR_SEG    = 128,
  parameter int TEST_ARR_DIV = 20,
  parameter logic [31:0] PPS_TIMEOUT = 32'd150_000_000,
  parameter int SONAR_TRIG_WIDTH = 1000,
  parameter ROM_FILE = "sf_sine_q15_quarter.hex"
) (
  input  logic        clk,
  input  logic        arst_n,
  input  logic        hsi_pclk,
  input  logic        vid_clk,
  input  logic        swir_pclk,
  // ---------------- AXI4-Lite control
  input  logic [15:0] s_axil_awaddr,
  input  logic        s_axil_awvalid,
  output logic        s_axil_awready,
  input  logic [31:0] s_axil_wdata,
  input  logic [3:0]  s_axil_wstrb,
  input  logic        s_axil_wvalid,
  output logic        s_axil_wready,
  output logic [1:0]  s_axil_bresp,
  output logic        s_axil_bvalid,
  input  logic        s_axil_bready,
  input  logic [15:0] s_axil_araddr,
  input  logic        s_axil_arvalid,
  output logic        s_axil_arready,
  output logic [31:0] s_axil_rdata,
  output logic [1:0]  s_axil_rresp,
  output logic        s_axil_rvalid,
  input  logic        s_axil_rready,
  // ---------------- AXI4 DMA master (write only)
  output logic [31:0] m_axi_awaddr,
  output logic [7:0]  m_axi_awlen,
  output logic [2:0]  m_axi_awsize,
  output logic [1:0]  m_axi_awburst,
  output logic        m_axi_awvalid,
  input  logic        m_axi_awready,
  output logic [31:0] m_axi_wdata,
  output logic [3:0]  m_axi_wstrb,
  output logic        m_axi_wlast,
  output logic        m_axi_wvalid,
  input  logic        m_axi_wready,
  input  logic [1:0]  m_axi_bresp,
  input  logic        m_axi_bvalid,
  output logic        m_axi_bready,
  output logic        irq,
  // ---------------- timing
  input  logic        pps_in,
  input  logic        ext_sync_in,
  // ---------------- hyperspectral camera (hsi_pclk)
  input  logic        hsi_fval,
  input  logic        hsi_lval,
  input  logic [15:0] hsi_data,
  output logic        hsi_exposure,
  // ---------------- multispectral camera (vid_clk AXI4-Stream video)
  input  logic        ms_tvalid,
  output logic        ms_tready,
  input  logic [15:0] ms_tdata,
  input  logic        ms_tuser,
  input  logic        ms_tlast,
  output logic        ms_trigger,
  output logic [7:0]  ms_led,
  // ---------------- SWIR ROIC (swir_pclk)
  input  logic        swir_fval,
  input  logic        swir_lval,
  input  logic [15:0] swir_data,
  output logic        swir_int,
  output logic        swir_read,
  input  logic        swir_tec_lock,
  // ---------------- Raman CCD + laser
  output logic        raman_ccd_integrate,
  output logic        raman_ccd_pixel,
  output logic        raman_adc_cnv,
  output logic        raman_adc_sclk,
  output logic        raman_adc_cs_n,
  input  logic        raman_adc_miso,
  output logic        laser_enable,
  output logic        laser_mod,
  input  logic        laser_submerged,
  // ---------------- IR ATR
  output logic        ir_source_on,
  output logic [3:0]  ir_band,
  output logic        ir_adc_cnv,
  output logic        ir_adc_sclk,
  output logic        ir_adc_cs_n,
  input  logic        ir_adc_miso,
  // ---------------- fluorometer
  output logic [2:0]  fl_led,
  output logic        fl_adc_cnv,
  output logic        fl_adc_sclk,
  output logic        fl_adc_cs_n,
  input  logic [2:0]  fl_adc_miso,
  // ---------------- sonar
  output logic        mbes_trigger,
  input  logic        mbes_tx_ack,
  input  logic        arr_raw_valid,
  input  logic [ARR_W-1:0] arr_raw_frame,
  input  logic [ARR_NCH*ARR_W-1:0] arr_raw_data,
  // ---------------- EM induction
  output logic [15:0] em_dac_data,
  output logic        em_dac_load,
  output logic        em_adc_cnv,
  output logic        em_adc_sclk,
  output logic        em_adc_cs_n,
  input  logic [1:0]  em_adc_miso,
  // ---------------- housekeeping ADC
  output logic        hk_adc_cnv,
  output logic        hk_adc_sclk,
  output logic        hk_adc_cs_n,
  input  logic        hk_adc_miso,
  output logic [1:0]  hk_mux,
  // ---------------- I2C (open drain: *_oe = 1 drives low)
  input  logic        i2c_scl_i,
  input  logic        i2c_sda_i,
  output logic        i2c_scl_oe,
  output logic        i2c_sda_oe
);
  // ===========================================================================
  // Resets
  // ===========================================================================
  logic rst_n, hsi_rst_n, vid_rst_n, swir_rst_n;
  sf_reset_sync u_rs_sys  (.clk(clk),       .arst_n(arst_n), .rst_n(rst_n));
  sf_reset_sync u_rs_hsi  (.clk(hsi_pclk),  .arst_n(arst_n), .rst_n(hsi_rst_n));
  sf_reset_sync u_rs_vid  (.clk(vid_clk),   .arst_n(arst_n), .rst_n(vid_rst_n));
  sf_reset_sync u_rs_swir (.clk(swir_pclk), .arst_n(arst_n), .rst_n(swir_rst_n));

  // ===========================================================================
  // Register file
  // ===========================================================================
  logic [31:0] control_q, status_i, scratch_q, irq_status_q, irq_status_set_i, irq_enable_q;
  logic [0:0]  ts_control_wstb; logic [31:0] ts_control_wdata;
  logic [31:0] ts_snap_lo_i, ts_snap_hi_i, ts_load_lo_q, ts_load_hi_q, pps_ts_lo_i, pps_ts_hi_i, pps_count_i;
  logic [31:0] ts_flags_q, ts_flags_set_i, sync_control_q, frame_period_q, trig_mask_q, frame_index_i;
  logic [255:0] trig_div_q, trig_offset_q;
  logic [31:0] dma_control_q, ring_base_q, ring_size_log2_q, wr_ptr_i, rd_ptr_q, irq_threshold_q;
  logic [31:0] dma_status_i, pkt_count_i, drop_count_i, fill_level_i;
  logic [31:0] cal_sel_q, cal_addr_q, cal_data_q, cal_flags_q; logic [0:0] cal_cmd_wstb; logic [31:0] cal_cmd_wdata;
  logic [31:0] hsi_control_q, hsi_geometry_q, hsi_exposure_q, hsi_sat_q, hsi_status_i, hsi_frames_i, hsi_errors_i;
  logic [31:0] ms_control_q, ms_geometry_q, ms_exposure_q, ms_sat_q, ms_status_i, ms_frames_i, ms_errors_i, ms_led_mask_q;
  logic [31:0] swir_control_q, swir_geometry_q, swir_integration_q, swir_sat_q, swir_status_i, swir_frames_i, swir_errors_i;
  logic [31:0] raman_control_q, raman_npix_q, raman_integ_q, raman_sat_q, raman_status_i, raman_spectra_i, raman_errors_i;
  logic [0:0]  laser_arm_wstb; logic [31:0] laser_arm_wdata;
  logic [31:0] laser_control_q, laser_delay_q, laser_pulse_width_q, laser_pulse_period_q, laser_max_on_q, laser_wd_timeout_q;
  logic [0:0]  laser_kick_wstb; logic [31:0] laser_kick_wdata;
  logic [31:0] laser_status_i, laser_faults_q, laser_faults_set_i;
  logic [31:0] ir_control_q, ir_half_period_q, ir_nperiods_q, ir_settle_q, ir_status_i, ir_sweeps_i;
  logic [31:0] fl_control_q, fl_on_samples_q, fl_blank_samples_q, fl_npulses_q, fl_status_i, fl_count_i;
  logic [31:0] sonar_control_q, sonar_rx_delay_q, sonar_nsamp_q, sonar_ack_timeout_q, sonar_status_i, sonar_pings_i, sonar_errors_i;
  logic [31:0] em_control_q, em_ftw_q, em_amplitude_q, em_nsamp_q, em_status_i, em_count_i;
  logic [31:0] hk_control_q, hk_period_q; logic [127:0] hk_ch_i;
  logic [31:0] i2c_prescale_q; logic [0:0] i2c_cmd_wstb; logic [31:0] i2c_cmd_wdata; logic [31:0] i2c_status_i;
  logic [31:0] diag_control_q, diag_period_q, diag_heartbeat_i; logic [0:0] host_kick_wstb; logic [31:0] host_kick_wdata;
  logic [31:0] host_timeout_q, temp_limit_q, diag_status_i, err_total_i, fifo_hwm_i;

  sf_axil_regfile u_regs (
    .clk(clk), .rst_n(rst_n),
    .s_axil_awaddr(s_axil_awaddr), .s_axil_awvalid(s_axil_awvalid), .s_axil_awready(s_axil_awready),
    .s_axil_wdata(s_axil_wdata), .s_axil_wstrb(s_axil_wstrb), .s_axil_wvalid(s_axil_wvalid), .s_axil_wready(s_axil_wready),
    .s_axil_bresp(s_axil_bresp), .s_axil_bvalid(s_axil_bvalid), .s_axil_bready(s_axil_bready),
    .s_axil_araddr(s_axil_araddr), .s_axil_arvalid(s_axil_arvalid), .s_axil_arready(s_axil_arready),
    .s_axil_rdata(s_axil_rdata), .s_axil_rresp(s_axil_rresp), .s_axil_rvalid(s_axil_rvalid), .s_axil_rready(s_axil_rready),
    .control_q(control_q), .status_i(status_i), .scratch_q(scratch_q), .irq_status_q(irq_status_q),
    .irq_status_set_i(irq_status_set_i), .irq_enable_q(irq_enable_q),
    .ts_control_wstb(ts_control_wstb), .ts_control_wdata(ts_control_wdata), .ts_snap_lo_i(ts_snap_lo_i), .ts_snap_hi_i(ts_snap_hi_i),
    .ts_load_lo_q(ts_load_lo_q), .ts_load_hi_q(ts_load_hi_q), .pps_ts_lo_i(pps_ts_lo_i), .pps_ts_hi_i(pps_ts_hi_i),
    .pps_count_i(pps_count_i), .ts_flags_q(ts_flags_q), .ts_flags_set_i(ts_flags_set_i), .sync_control_q(sync_control_q),
    .frame_period_q(frame_period_q), .trig_mask_q(trig_mask_q), .frame_index_i(frame_index_i),
    .trig_div_q(trig_div_q), .trig_offset_q(trig_offset_q),
    .dma_control_q(dma_control_q), .ring_base_q(ring_base_q), .ring_size_log2_q(ring_size_log2_q), .wr_ptr_i(wr_ptr_i),
    .rd_ptr_q(rd_ptr_q), .irq_threshold_q(irq_threshold_q), .dma_status_i(dma_status_i), .pkt_count_i(pkt_count_i),
    .drop_count_i(drop_count_i), .fill_level_i(fill_level_i),
    .cal_sel_q(cal_sel_q), .cal_addr_q(cal_addr_q), .cal_data_q(cal_data_q), .cal_flags_q(cal_flags_q),
    .cal_cmd_wstb(cal_cmd_wstb), .cal_cmd_wdata(cal_cmd_wdata),
    .hsi_control_q(hsi_control_q), .hsi_geometry_q(hsi_geometry_q), .hsi_exposure_q(hsi_exposure_q), .hsi_sat_q(hsi_sat_q),
    .hsi_status_i(hsi_status_i), .hsi_frames_i(hsi_frames_i), .hsi_errors_i(hsi_errors_i),
    .ms_control_q(ms_control_q), .ms_geometry_q(ms_geometry_q), .ms_exposure_q(ms_exposure_q), .ms_sat_q(ms_sat_q),
    .ms_status_i(ms_status_i), .ms_frames_i(ms_frames_i), .ms_errors_i(ms_errors_i), .ms_led_mask_q(ms_led_mask_q),
    .swir_control_q(swir_control_q), .swir_geometry_q(swir_geometry_q), .swir_integration_q(swir_integration_q),
    .swir_sat_q(swir_sat_q), .swir_status_i(swir_status_i), .swir_frames_i(swir_frames_i), .swir_errors_i(swir_errors_i),
    .raman_control_q(raman_control_q), .raman_npix_q(raman_npix_q), .raman_integ_q(raman_integ_q), .raman_sat_q(raman_sat_q),
    .raman_status_i(raman_status_i), .raman_spectra_i(raman_spectra_i), .raman_errors_i(raman_errors_i),
    .laser_arm_wstb(laser_arm_wstb), .laser_arm_wdata(laser_arm_wdata), .laser_control_q(laser_control_q),
    .laser_delay_q(laser_delay_q), .laser_pulse_width_q(laser_pulse_width_q), .laser_pulse_period_q(laser_pulse_period_q),
    .laser_max_on_q(laser_max_on_q), .laser_wd_timeout_q(laser_wd_timeout_q), .laser_kick_wstb(laser_kick_wstb),
    .laser_kick_wdata(laser_kick_wdata), .laser_status_i(laser_status_i), .laser_faults_q(laser_faults_q),
    .laser_faults_set_i(laser_faults_set_i),
    .ir_control_q(ir_control_q), .ir_half_period_q(ir_half_period_q), .ir_nperiods_q(ir_nperiods_q), .ir_settle_q(ir_settle_q),
    .ir_status_i(ir_status_i), .ir_sweeps_i(ir_sweeps_i),
    .fl_control_q(fl_control_q), .fl_on_samples_q(fl_on_samples_q), .fl_blank_samples_q(fl_blank_samples_q),
    .fl_npulses_q(fl_npulses_q), .fl_status_i(fl_status_i), .fl_count_i(fl_count_i),
    .sonar_control_q(sonar_control_q), .sonar_rx_delay_q(sonar_rx_delay_q), .sonar_nsamp_q(sonar_nsamp_q),
    .sonar_ack_timeout_q(sonar_ack_timeout_q), .sonar_status_i(sonar_status_i), .sonar_pings_i(sonar_pings_i),
    .sonar_errors_i(sonar_errors_i),
    .em_control_q(em_control_q), .em_ftw_q(em_ftw_q), .em_amplitude_q(em_amplitude_q), .em_nsamp_q(em_nsamp_q),
    .em_status_i(em_status_i), .em_count_i(em_count_i),
    .hk_control_q(hk_control_q), .hk_period_q(hk_period_q), .hk_ch_i(hk_ch_i),
    .i2c_prescale_q(i2c_prescale_q), .i2c_cmd_wstb(i2c_cmd_wstb), .i2c_cmd_wdata(i2c_cmd_wdata), .i2c_status_i(i2c_status_i),
    .diag_control_q(diag_control_q), .diag_period_q(diag_period_q), .diag_heartbeat_i(diag_heartbeat_i),
    .host_kick_wstb(host_kick_wstb), .host_kick_wdata(host_kick_wdata), .host_timeout_q(host_timeout_q),
    .temp_limit_q(temp_limit_q), .diag_status_i(diag_status_i), .err_total_i(err_total_i), .fifo_hwm_i(fifo_hwm_i)
  );

  // ===========================================================================
  // Global control. TEST_PATTERN is latched while acquisition is idle so the
  // data source cannot change in the middle of an acquisition.
  // ===========================================================================
  logic acq_en, test_mode;
  assign acq_en = control_q[0];
  always_ff @(posedge clk) begin
    if (!rst_n) test_mode <= 1'b0;
    else if (!acq_en) test_mode <= control_q[1];
  end

  // ===========================================================================
  // Timestamp engine and synchronisation
  // ===========================================================================
  logic [63:0] ts_now, ts_snap, pps_ts;
  logic [31:0] pps_count;
  logic        pps_pulse, pps_seen, rollover_evt, pps_lost_evt;
  logic [7:0]  ev_pulse;
  logic [511:0] event_ts_u;

  sf_timestamp_engine #(.N_EVENTS(8), .PPS_TIMEOUT(PPS_TIMEOUT)) u_ts (
    .clk(clk), .rst_n(rst_n), .snapshot_stb(ts_control_wstb[0] & ts_control_wdata[0]),
    .load_stb(ts_control_wstb[0] & ts_control_wdata[1]), .load_value({ts_load_hi_q, ts_load_lo_q}),
    .pps_async(pps_in), .event_pulse(ev_pulse), .ts_now(ts_now), .snap(ts_snap), .pps_ts(pps_ts), .pps_count(pps_count),
    .pps_pulse(pps_pulse), .pps_seen(pps_seen), .rollover_evt(rollover_evt), .pps_lost_evt(pps_lost_evt), .event_ts(event_ts_u)
  );
  assign ts_snap_lo_i = ts_snap[31:0];
  assign ts_snap_hi_i = ts_snap[63:32];
  assign pps_ts_lo_i  = pps_ts[31:0];
  assign pps_ts_hi_i  = pps_ts[63:32];
  assign pps_count_i  = pps_count;
  assign ts_flags_set_i = {30'd0, pps_lost_evt, rollover_evt};

  logic        frame_tick, sync_ovr;
  logic [7:0]  trig_pulse, trig_level;
  logic [31:0] frame_index;
  sf_sensor_sync #(.N_CH(8)) u_sync (
    .clk(clk), .rst_n(rst_n), .enable(acq_en & sync_control_q[0]), .ext_sync_en(sync_control_q[1]),
    .pps_align(sync_control_q[2]), .frame_period(frame_period_q), .trig_mask(trig_mask_q[7:0]),
    .trig_div(trig_div_q), .trig_offset(trig_offset_q), .ext_sync_async(ext_sync_in), .pps_pulse(pps_pulse),
    .frame_tick(frame_tick), .frame_index(frame_index), .trig_pulse(trig_pulse), .trig_out(trig_level), .overrun_evt(sync_ovr)
  );
  assign frame_index_i = frame_index;

  // ===========================================================================
  // Calibration memory write routing
  // ===========================================================================
  logic [2:0]        cal_we;
  logic [32:0]       cal_wdata;
  logic [CAL_AW-1:0] cal_waddr;
  assign cal_wdata = {cal_flags_q[0], cal_data_q};
  assign cal_waddr = cal_addr_q[CAL_AW-1:0];
  always_comb begin
    cal_we = 3'b000;
    if (cal_cmd_wstb[0] && cal_cmd_wdata[0] && cal_sel_q[1:0] != 2'd3) cal_we[cal_sel_q[1:0]] = 1'b1;
  end

  // ===========================================================================
  // Packetiser source bus (index = source)
  //  0 HSI  1 MS  2 SWIR  3 RAMAN  4 IR  5 FLUOR  6 SONAR_PING  7 ACOUSTIC
  //  8 EM   9 HK  10 DIAG 11 LASER_EVENT
  // ===========================================================================
  localparam int NSRC = 12;
  localparam logic [8*NSRC-1:0] UIDS = {
    sf_pkg::UID_RAM0, sf_pkg::UID_DIAG, sf_pkg::UID_HK0, sf_pkg::UID_EMI0, sf_pkg::UID_ACA0, sf_pkg::UID_MBES0,
    sf_pkg::UID_FL0, sf_pkg::UID_IR0, sf_pkg::UID_RAM0, sf_pkg::UID_SWIR0, sf_pkg::UID_MS0, sf_pkg::UID_HSI0};
  localparam logic [8*NSRC-1:0] PTYPES = {
    sf_pkg::PT_LASER_EVENT, sf_pkg::PT_DIAGNOSTIC, sf_pkg::PT_HOUSEKEEPING, sf_pkg::PT_EM_IQ, sf_pkg::PT_ACOUSTIC_SAMPLES,
    sf_pkg::PT_SONAR_PING, sf_pkg::PT_FLUOR_BLOCK, sf_pkg::PT_IR_SWEEP, sf_pkg::PT_RAMAN_SPECTRUM, sf_pkg::PT_SWIR_ROW,
    sf_pkg::PT_MS_ROW, sf_pkg::PT_HSI_ROW};

  logic [NSRC-1:0]    s_valid, s_ready, s_last;
  logic [32*NSRC-1:0] s_data, s_frame, s_meta;
  logic [8*NSRC-1:0]  s_flags;
  logic [16*NSRC-1:0] s_row;
  logic [64*NSRC-1:0] s_ts;

  // ===========================================================================
  // Imagers
  // ===========================================================================
  logic hsi_exp_evt, hsi_err_evt, ms_exp_evt, ms_err_evt, swir_exp_evt, swir_err_evt;

  sf_hsi_controller #(.FIFO_AW(ROW_FIFO_AW), .CAL_AW(CAL_AW)) u_hsi (
    .clk(clk), .rst_n(rst_n), .pclk(hsi_pclk), .prst_n(hsi_rst_n),
    .cam_fval(hsi_fval), .cam_lval(hsi_lval), .cam_data(hsi_data), .cam_exposure(hsi_exposure),
    .enable(acq_en & hsi_control_q[0]), .cal_en(hsi_control_q[1]), .test_mode(test_mode),
    .cfg_pixels(hsi_geometry_q[15:0]), .cfg_rows(hsi_geometry_q[31:16]), .exposure_cycles(hsi_exposure_q),
    .sat_level(hsi_sat_q[15:0]), .trig(trig_pulse[0]), .ts_now(ts_now),
    .cal_we(cal_we[0]), .cal_waddr(cal_waddr), .cal_wdata(cal_wdata),
    .src_valid(s_valid[0]), .src_ready(s_ready[0]), .src_data(s_data[0 +: 32]), .src_last(s_last[0]),
    .src_flags(s_flags[0 +: 8]), .src_frame(s_frame[0 +: 32]), .src_row(s_row[0 +: 16]), .src_meta(s_meta[0 +: 32]),
    .src_ts(s_ts[0 +: 64]), .status(hsi_status_i), .frames(hsi_frames_i), .errors(hsi_errors_i),
    .exposure_evt(hsi_exp_evt), .error_evt(hsi_err_evt)
  );

  sf_multispectral_controller #(.FIFO_AW(ROW_FIFO_AW), .CAL_AW(CAL_AW)) u_ms (
    .clk(clk), .rst_n(rst_n), .vclk(vid_clk), .vrst_n(vid_rst_n),
    .s_axis_tvalid(ms_tvalid), .s_axis_tready(ms_tready), .s_axis_tdata(ms_tdata), .s_axis_tuser(ms_tuser),
    .s_axis_tlast(ms_tlast), .cam_trigger(ms_trigger), .led(ms_led),
    .enable(acq_en & ms_control_q[0]), .cal_en(ms_control_q[1]), .test_mode(test_mode), .nbands(ms_control_q[11:8]),
    .led_mask(ms_led_mask_q[7:0]), .cfg_width(ms_geometry_q[15:0]), .cfg_height(ms_geometry_q[31:16]),
    .exposure_cycles(ms_exposure_q), .sat_level(ms_sat_q[15:0]), .trig(trig_pulse[1]), .ts_now(ts_now),
    .cal_we(cal_we[1]), .cal_waddr(cal_waddr), .cal_wdata(cal_wdata),
    .src_valid(s_valid[1]), .src_ready(s_ready[1]), .src_data(s_data[32 +: 32]), .src_last(s_last[1]),
    .src_flags(s_flags[8 +: 8]), .src_frame(s_frame[32 +: 32]), .src_row(s_row[16 +: 16]), .src_meta(s_meta[32 +: 32]),
    .src_ts(s_ts[64 +: 64]), .status(ms_status_i), .frames(ms_frames_i), .errors(ms_errors_i),
    .exposure_evt(ms_exp_evt), .error_evt(ms_err_evt)
  );

  sf_swir_controller #(.FIFO_AW(ROW_FIFO_AW), .CAL_AW(CAL_AW)) u_swir (
    .clk(clk), .rst_n(rst_n), .pclk(swir_pclk), .prst_n(swir_rst_n),
    .roic_fval(swir_fval), .roic_lval(swir_lval), .roic_data(swir_data), .roic_int(swir_int), .roic_read(swir_read),
    .tec_lock_async(swir_tec_lock), .enable(acq_en & swir_control_q[0]), .cal_en(swir_control_q[1]),
    .require_tec(swir_control_q[2]), .test_mode(test_mode),
    .cfg_width(swir_geometry_q[15:0]), .cfg_height(swir_geometry_q[31:16]), .integration_cycles(swir_integration_q),
    .sat_level(swir_sat_q[15:0]), .trig(trig_pulse[2]), .ts_now(ts_now),
    .cal_we(cal_we[2]), .cal_waddr(cal_waddr), .cal_wdata(cal_wdata),
    .src_valid(s_valid[2]), .src_ready(s_ready[2]), .src_data(s_data[64 +: 32]), .src_last(s_last[2]),
    .src_flags(s_flags[16 +: 8]), .src_frame(s_frame[64 +: 32]), .src_row(s_row[32 +: 16]), .src_meta(s_meta[64 +: 32]),
    .src_ts(s_ts[128 +: 64]), .status(swir_status_i), .frames(swir_frames_i), .errors(swir_errors_i),
    .exposure_evt(swir_exp_evt), .error_evt(swir_err_evt)
  );

  // ===========================================================================
  // Raman + laser
  // ===========================================================================
  logic overtemp, laser_emitting, laser_abort, laser_armed, laser_ilk_ok, laser_wd_ok, laser_req;
  logic laser_start_evt;
  logic [3:0] laser_fault_evt;
  sf_laser_timing u_laser (
    .clk(clk), .rst_n(rst_n), .arm_stb(laser_arm_wstb[0]), .arm_key(laser_arm_wdata[15:0]), .kick_stb(laser_kick_wstb[0]),
    .wd_timeout(laser_wd_timeout_q), .pulsed(laser_control_q[0]), .delay_cycles(laser_delay_q),
    .pulse_width(laser_pulse_width_q), .pulse_period(laser_pulse_period_q), .max_on_sw(laser_max_on_q),
    .submerged_async(laser_submerged), .overtemp(overtemp), .gate_req(laser_req),
    .laser_enable(laser_enable), .laser_mod(laser_mod), .emitting(laser_emitting), .armed(laser_armed),
    .interlock_ok(laser_ilk_ok), .wd_ok(laser_wd_ok), .abort_evt(laser_abort), .emit_start_evt(laser_start_evt),
    .fault_evt(laser_fault_evt)
  );
  assign laser_status_i = {28'd0, laser_wd_ok, laser_ilk_ok, laser_emitting, laser_armed};
  assign laser_faults_set_i = {28'd0, laser_fault_evt};

  logic raman_adc_start, raman_adc_valid, raman_integ_evt, raman_err_evt, raman_busy_u, raman_ovr_u, raman_miso_eff;
  logic [15:0] raman_adc_data;
  logic [0:0]  raman_mux_u, raman_ch_u;
  logic        raman_ts_miso;
  sf_adc_test_source #(.BITS(16), .LANES(1), .OFFSET(500)) u_raman_tsrc (
    .clk(clk), .rst_n(rst_n), .sclk(raman_adc_sclk), .cs_n(raman_adc_cs_n), .miso(raman_ts_miso));
  assign raman_miso_eff = test_mode ? raman_ts_miso : raman_adc_miso;
  sf_adc_interface #(.BITS(16), .LANES(1), .CLKDIV(2), .CNV_CYCLES(50), .MUX_W(1)) u_raman_adc (
    .clk(clk), .rst_n(rst_n), .start(raman_adc_start), .ch(1'b0), .busy(raman_busy_u), .start_overrun(raman_ovr_u),
    .sample_valid(raman_adc_valid), .sample_data(raman_adc_data), .sample_ch(raman_ch_u), .mux_sel(raman_mux_u),
    .adc_cnv(raman_adc_cnv), .adc_sclk(raman_adc_sclk), .adc_cs_n(raman_adc_cs_n), .adc_miso(raman_miso_eff)
  );
  sf_raman_controller #(.NPIX_MAX(RAMAN_NPIX), .PIX_PERIOD(RAMAN_PIX_PERIOD)) u_raman (
    .clk(clk), .rst_n(rst_n), .enable(acq_en & raman_control_q[0]), .dark_mode(raman_control_q[1]),
    .coadd(raman_control_q[15:8]), .npix(raman_npix_q[11:0]), .integ_cycles(raman_integ_q), .sat_level(raman_sat_q[15:0]),
    .trig(trig_pulse[3]), .ts_now(ts_now), .laser_gate_req(laser_req), .laser_emitting(laser_emitting),
    .laser_abort(laser_abort), .ccd_integrate(raman_ccd_integrate), .ccd_pixel(raman_ccd_pixel),
    .adc_start(raman_adc_start), .adc_valid(raman_adc_valid), .adc_data(raman_adc_data),
    .src_valid(s_valid[3]), .src_ready(s_ready[3]), .src_data(s_data[96 +: 32]), .src_last(s_last[3]),
    .src_flags(s_flags[24 +: 8]), .src_frame(s_frame[96 +: 32]), .src_row(s_row[48 +: 16]), .src_meta(s_meta[96 +: 32]),
    .src_ts(s_ts[192 +: 64]), .status(raman_status_i), .spectra(raman_spectra_i), .errors(raman_errors_i),
    .integ_evt(raman_integ_evt), .error_evt(raman_err_evt)
  );

  // Laser event packets: emission start, abort and faults, for provenance.
  logic [31:0] laser_evt_cnt;
  logic        lev_pending, lev_valid, lev_last;
  logic [1:0]  lev_idx;
  logic [31:0] lev_code, lev_data;
  logic [63:0] lev_ts;
  logic [7:0]  lev_flags;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      lev_pending <= 1'b0; lev_idx <= '0; lev_code <= '0; lev_ts <= '0; laser_evt_cnt <= '0;
      lev_valid <= 1'b0; lev_data <= '0; lev_last <= 1'b0; lev_flags <= '0;
    end else begin
      if (!lev_pending && (laser_start_evt || laser_abort || laser_fault_evt != 0)) begin
        lev_pending <= 1'b1; lev_idx <= '0; lev_ts <= ts_now;
        lev_code <= {20'd0, laser_fault_evt, 2'd0, laser_abort, laser_start_evt, 2'd0, laser_armed, laser_emitting};
      end
      if (lev_pending && (!lev_valid || s_ready[11])) begin
        if (lev_valid && lev_last) begin
          lev_valid <= 1'b0; lev_pending <= 1'b0; laser_evt_cnt <= laser_evt_cnt + 32'd1;
        end else begin
          lev_valid <= 1'b1;
          lev_data  <= (lev_idx == 2'd0) ? lev_code : {28'd0, laser_faults_q[3:0]};
          lev_last  <= (lev_idx == 2'd1);
          lev_flags <= {3'd0, laser_emitting, 4'd0};
          lev_idx <= lev_idx + 2'd1;
        end
      end
    end
  end
  assign s_valid[11] = lev_valid;
  assign s_data[352 +: 32] = lev_data;
  assign s_last[11] = lev_last;
  assign s_flags[88 +: 8] = lev_flags;
  assign s_frame[352 +: 32] = laser_evt_cnt;
  assign s_row[176 +: 16] = 16'd0;
  assign s_meta[352 +: 32] = 32'd2;
  assign s_ts[704 +: 64] = lev_ts;

  // ===========================================================================
  // IR ATR
  // ===========================================================================
  logic ir_adc_start, ir_adc_valid, ir_sweep_evt, ir_busy_u, ir_ovr_u, ir_miso_eff, ir_ts_miso;
  logic [17:0] ir_adc_data;
  logic [0:0]  ir_mux_u, ir_ch_u;
  sf_adc_test_source #(.BITS(18), .LANES(1), .OFFSET(7)) u_ir_tsrc (
    .clk(clk), .rst_n(rst_n), .sclk(ir_adc_sclk), .cs_n(ir_adc_cs_n), .miso(ir_ts_miso));
  assign ir_miso_eff = test_mode ? ir_ts_miso : ir_adc_miso;
  sf_adc_interface #(.BITS(18), .LANES(1), .CLKDIV(2), .CNV_CYCLES(50), .MUX_W(1)) u_ir_adc (
    .clk(clk), .rst_n(rst_n), .start(ir_adc_start), .ch(1'b0), .busy(ir_busy_u), .start_overrun(ir_ovr_u),
    .sample_valid(ir_adc_valid), .sample_data(ir_adc_data), .sample_ch(ir_ch_u), .mux_sel(ir_mux_u),
    .adc_cnv(ir_adc_cnv), .adc_sclk(ir_adc_sclk), .adc_cs_n(ir_adc_cs_n), .adc_miso(ir_miso_eff)
  );
  sf_ir_controller #(.SAMPLE_PERIOD(ADC_SAMPLE_PERIOD), .BITS(18)) u_ir (
    .clk(clk), .rst_n(rst_n), .enable(acq_en & ir_control_q[0]), .nbands(ir_control_q[11:8]),
    .half_period(ir_half_period_q[23:0]), .nperiods(ir_nperiods_q[15:0]), .settle(ir_settle_q[15:0]),
    .trig(trig_pulse[4]), .ts_now(ts_now), .source_on(ir_source_on), .band_sel(ir_band), .adc_start(ir_adc_start),
    .adc_valid(ir_adc_valid), .adc_data(ir_adc_data),
    .src_valid(s_valid[4]), .src_ready(s_ready[4]), .src_data(s_data[128 +: 32]), .src_last(s_last[4]),
    .src_flags(s_flags[32 +: 8]), .src_frame(s_frame[128 +: 32]), .src_row(s_row[64 +: 16]), .src_meta(s_meta[128 +: 32]),
    .src_ts(s_ts[256 +: 64]), .status(ir_status_i), .sweeps(ir_sweeps_i), .sweep_evt(ir_sweep_evt)
  );

  // ===========================================================================
  // Fluorometer
  // ===========================================================================
  logic fl_adc_start, fl_adc_valid, fl_block_evt, fl_busy_u, fl_ovr_u;
  logic [47:0] fl_adc_data;
  logic [2:0]  fl_miso_eff, fl_ts_miso;
  logic [0:0]  fl_mux_u, fl_ch_u;
  sf_adc_test_source #(.BITS(16), .LANES(3), .OFFSET(64)) u_fl_tsrc (
    .clk(clk), .rst_n(rst_n), .sclk(fl_adc_sclk), .cs_n(fl_adc_cs_n), .miso(fl_ts_miso));
  assign fl_miso_eff = test_mode ? fl_ts_miso : fl_adc_miso;
  sf_adc_interface #(.BITS(16), .LANES(3), .CLKDIV(2), .CNV_CYCLES(50), .MUX_W(1)) u_fl_adc (
    .clk(clk), .rst_n(rst_n), .start(fl_adc_start), .ch(1'b0), .busy(fl_busy_u), .start_overrun(fl_ovr_u),
    .sample_valid(fl_adc_valid), .sample_data(fl_adc_data), .sample_ch(fl_ch_u), .mux_sel(fl_mux_u),
    .adc_cnv(fl_adc_cnv), .adc_sclk(fl_adc_sclk), .adc_cs_n(fl_adc_cs_n), .adc_miso(fl_miso_eff)
  );
  sf_fluorescence_controller #(.SAMPLE_PERIOD(ADC_SAMPLE_PERIOD)) u_fl (
    .clk(clk), .rst_n(rst_n), .enable(acq_en & fl_control_q[0]), .exc_mask(fl_control_q[10:8]),
    .on_samples(fl_on_samples_q[15:0]), .blank_samples(fl_blank_samples_q[15:0]), .npulses(fl_npulses_q[15:0]),
    .trig(trig_pulse[5]), .ts_now(ts_now), .led(fl_led), .adc_start(fl_adc_start), .adc_valid(fl_adc_valid),
    .adc_data(fl_adc_data),
    .src_valid(s_valid[5]), .src_ready(s_ready[5]), .src_data(s_data[160 +: 32]), .src_last(s_last[5]),
    .src_flags(s_flags[40 +: 8]), .src_frame(s_frame[160 +: 32]), .src_row(s_row[80 +: 16]), .src_meta(s_meta[160 +: 32]),
    .src_ts(s_ts[320 +: 64]), .status(fl_status_i), .blocks(fl_count_i), .block_evt(fl_block_evt)
  );

  // ===========================================================================
  // Sonar: MBES trigger/timestamp + acoustic array (LVDS aligner)
  // ===========================================================================
  logic arr_al_valid, arr_aligned, arr_realign_u;
  logic [ARR_NCH*ARR_W-1:0] arr_al_data;
  logic [$clog2(ARR_W)-1:0] arr_slip_u;
  sf_lvds_aligner #(.W(ARR_W), .LANES(ARR_NCH)) u_align (
    .clk(clk), .rst_n(rst_n), .in_valid(arr_raw_valid), .in_frame(arr_raw_frame), .in_data(arr_raw_data),
    .out_valid(arr_al_valid), .out_data(arr_al_data), .aligned(arr_aligned), .slip(arr_slip_u), .realign_evt(arr_realign_u)
  );
  // Test-mode array source: one sample every TEST_ARR_DIV cycles, channel c
  // carries (sample_index * (c + 1)) mod 2^14 sign-extended.
  logic [7:0]  tarr_div;
  logic [15:0] tarr_k;
  logic        tarr_valid;
  always_ff @(posedge clk) begin
    if (!rst_n) begin tarr_div <= '0; tarr_k <= '0; tarr_valid <= 1'b0; end
    else begin
      tarr_valid <= 1'b0;
      if (tarr_div == 8'(TEST_ARR_DIV - 1)) begin tarr_div <= '0; tarr_valid <= test_mode; if (test_mode) tarr_k <= tarr_k + 16'd1; end
      else tarr_div <= tarr_div + 8'd1;
    end
  end
  logic [ARR_NCH*16-1:0] arr16;
  logic                  arr16_valid, arr16_aligned;
  always_comb begin
    for (int c = 0; c < ARR_NCH; c++) begin
      logic [ARR_W-1:0] v;
      v = test_mode ? ARR_W'(32'(tarr_k) * 32'(c + 1)) : arr_al_data[c*ARR_W +: ARR_W];
      arr16[c*16 +: 16] = {{(16-ARR_W){v[ARR_W-1]}}, v};
    end
  end
  assign arr16_valid   = test_mode ? tarr_valid : arr_al_valid;
  assign arr16_aligned = test_mode ? 1'b1 : arr_aligned;

  // TX-ack loopback in test mode (acknowledge 100 cycles after the trigger).
  logic [7:0] ack_dly;
  logic       test_ack;
  always_ff @(posedge clk) begin
    if (!rst_n) begin ack_dly <= '0; test_ack <= 1'b0; end
    else begin
      if (mbes_trigger && ack_dly == 0) ack_dly <= 8'd100;
      else if (ack_dly > 8'd1) ack_dly <= ack_dly - 8'd1;
      else if (ack_dly == 8'd1) begin ack_dly <= 8'd0; end
      test_ack <= (ack_dly == 8'd1) ? 1'b1 : (mbes_trigger ? test_ack : 1'b0);
    end
  end

  logic sonar_ping_evt, sonar_err_evt;
  sf_sonar_interface #(.NCH(ARR_NCH), .SEG_SAMPLES(ARR_SEG), .TRIG_WIDTH(SONAR_TRIG_WIDTH)) u_sonar (
    .clk(clk), .rst_n(rst_n), .enable(acq_en & sonar_control_q[0]), .array_en(sonar_control_q[1]),
    .rx_delay(sonar_rx_delay_q[23:0]), .nsamp(sonar_nsamp_q[15:0]), .ack_timeout(sonar_ack_timeout_q),
    .trig(trig_pulse[6]), .ts_now(ts_now), .mbes_trigger(mbes_trigger),
    .tx_ack_async(test_mode ? test_ack : mbes_tx_ack), .arr_aligned(arr16_aligned), .arr_valid(arr16_valid), .arr_data(arr16),
    .p_valid(s_valid[6]), .p_ready(s_ready[6]), .p_data(s_data[192 +: 32]), .p_last(s_last[6]),
    .p_flags(s_flags[48 +: 8]), .p_frame(s_frame[192 +: 32]), .p_row(s_row[96 +: 16]), .p_meta(s_meta[192 +: 32]),
    .p_ts(s_ts[384 +: 64]),
    .a_valid(s_valid[7]), .a_ready(s_ready[7]), .a_data(s_data[224 +: 32]), .a_last(s_last[7]),
    .a_flags(s_flags[56 +: 8]), .a_frame(s_frame[224 +: 32]), .a_row(s_row[112 +: 16]), .a_meta(s_meta[224 +: 32]),
    .a_ts(s_ts[448 +: 64]),
    .status(sonar_status_i), .pings(sonar_pings_i), .errors(sonar_errors_i), .ping_evt(sonar_ping_evt), .error_evt(sonar_err_evt)
  );

  // ===========================================================================
  // EM induction
  // ===========================================================================
  logic em_adc_start, em_adc_valid, em_integ_evt, em_busy_u, em_ovr_u;
  logic [31:0] em_adc_data;
  logic [1:0]  em_miso_eff, em_ts_miso;
  logic [0:0]  em_mux_u, em_ch_u;
  logic signed [15:0] em_dac_s;
  sf_adc_test_source #(.BITS(16), .LANES(2), .OFFSET(3)) u_em_tsrc (
    .clk(clk), .rst_n(rst_n), .sclk(em_adc_sclk), .cs_n(em_adc_cs_n), .miso(em_ts_miso));
  assign em_miso_eff = test_mode ? em_ts_miso : em_adc_miso;
  sf_adc_interface #(.BITS(16), .LANES(2), .CLKDIV(2), .CNV_CYCLES(50), .MUX_W(1)) u_em_adc (
    .clk(clk), .rst_n(rst_n), .start(em_adc_start), .ch(1'b0), .busy(em_busy_u), .start_overrun(em_ovr_u),
    .sample_valid(em_adc_valid), .sample_data(em_adc_data), .sample_ch(em_ch_u), .mux_sel(em_mux_u),
    .adc_cnv(em_adc_cnv), .adc_sclk(em_adc_sclk), .adc_cs_n(em_adc_cs_n), .adc_miso(em_miso_eff)
  );
  sf_em_induction #(.SAMPLE_DIV(ADC_SAMPLE_PERIOD), .ROM_FILE(ROM_FILE)) u_em (
    .clk(clk), .rst_n(rst_n), .enable(acq_en & em_control_q[0]), .tx_en(em_control_q[1]), .ftw(em_ftw_q),
    .amplitude(em_amplitude_q[15:0]), .nsamp(em_nsamp_q[23:0]), .trig(trig_pulse[7]), .ts_now(ts_now),
    .dac_data(em_dac_s), .dac_load(em_dac_load), .adc_start(em_adc_start), .adc_valid(em_adc_valid), .adc_data(em_adc_data),
    .src_valid(s_valid[8]), .src_ready(s_ready[8]), .src_data(s_data[256 +: 32]), .src_last(s_last[8]),
    .src_flags(s_flags[64 +: 8]), .src_frame(s_frame[256 +: 32]), .src_row(s_row[128 +: 16]), .src_meta(s_meta[256 +: 32]),
    .src_ts(s_ts[512 +: 64]), .status(em_status_i), .records(em_count_i), .integ_evt(em_integ_evt)
  );
  assign em_dac_data = em_dac_s;

  // ===========================================================================
  // Housekeeping + diagnostics
  // ===========================================================================
  logic hk_adc_start, hk_adc_valid, hk_scan_u, hk_busy_u, hk_ovr_u, hk_miso_eff, hk_ts_miso;
  logic [1:0]  hk_ch, hk_ch_in;
  logic [15:0] hk_adc_data;
  logic [63:0] hk_codes;
  sf_adc_test_source #(.BITS(16), .LANES(1), .OFFSET(20000)) u_hk_tsrc (
    .clk(clk), .rst_n(rst_n), .sclk(hk_adc_sclk), .cs_n(hk_adc_cs_n), .miso(hk_ts_miso));
  assign hk_miso_eff = test_mode ? hk_ts_miso : hk_adc_miso;
  sf_adc_interface #(.BITS(16), .LANES(1), .CLKDIV(4), .CNV_CYCLES(100), .MUX_W(2), .MUX_SETTLE(50)) u_hk_adc (
    .clk(clk), .rst_n(rst_n), .start(hk_adc_start), .ch(hk_ch), .busy(hk_busy_u), .start_overrun(hk_ovr_u),
    .sample_valid(hk_adc_valid), .sample_data(hk_adc_data), .sample_ch(hk_ch_in), .mux_sel(hk_mux),
    .adc_cnv(hk_adc_cnv), .adc_sclk(hk_adc_sclk), .adc_cs_n(hk_adc_cs_n), .adc_miso(hk_miso_eff)
  );
  sf_housekeeping u_hk (
    .clk(clk), .rst_n(rst_n), .enable(hk_control_q[0]), .pkt_en(hk_control_q[1] & acq_en), .period(hk_period_q),
    .ts_now(ts_now), .adc_start(hk_adc_start), .adc_ch(hk_ch), .adc_valid(hk_adc_valid), .adc_data(hk_adc_data),
    .adc_ch_in(hk_ch_in), .codes(hk_codes),
    .src_valid(s_valid[9]), .src_ready(s_ready[9]), .src_data(s_data[288 +: 32]), .src_last(s_last[9]),
    .src_flags(s_flags[72 +: 8]), .src_frame(s_frame[288 +: 32]), .src_row(s_row[144 +: 16]), .src_meta(s_meta[288 +: 32]),
    .src_ts(s_ts[576 +: 64]), .scan_done(hk_scan_u)
  );
  always_comb for (int i = 0; i < 4; i++) hk_ch_i[32*i +: 32] = {16'd0, hk_codes[16*i +: 16]};

  logic [31:0] pkt_count, drop_count, seq_u;
  logic [15:0] stage_hwm;
  logic host_lost, fault_any, drop_evt, thresh_evt;
  logic [31:0] err_total;
  sf_fpga_diagnostics #(.NERR(8), .NSTATUS(5)) u_diag (
    .clk(clk), .rst_n(rst_n),
    .err_pulse({|laser_fault_evt, drop_evt, sync_ovr, sonar_err_evt, raman_err_evt, swir_err_evt, ms_err_evt, hsi_err_evt}),
    .host_kick(host_kick_wstb[0]), .host_timeout(host_timeout_q), .temp_code(hk_codes[15:0]), .temp_limit(temp_limit_q[15:0]),
    .pkt_en(diag_control_q[0] & acq_en), .period(diag_period_q),
    .status_words({raman_spectra_i, ms_frames_i, hsi_frames_i, drop_count, pkt_count}),
    .stage_hwm(stage_hwm), .ts_now(ts_now), .heartbeat(diag_heartbeat_i), .host_lost(host_lost), .overtemp(overtemp),
    .fault_any(fault_any), .err_total(err_total),
    .src_valid(s_valid[10]), .src_ready(s_ready[10]), .src_data(s_data[320 +: 32]), .src_last(s_last[10]),
    .src_flags(s_flags[80 +: 8]), .src_frame(s_frame[320 +: 32]), .src_row(s_row[160 +: 16]), .src_meta(s_meta[320 +: 32]),
    .src_ts(s_ts[640 +: 64])
  );
  assign diag_status_i = {29'd0, fault_any, overtemp, host_lost};
  assign err_total_i = err_total;
  assign fifo_hwm_i = {16'd0, stage_hwm};

  // ===========================================================================
  // Packetiser + DMA
  // ===========================================================================
  logic        p_valid, p_ready, p_last, p_sop;
  logic [31:0] p_data;
  logic [15:0] p_len;
  sf_packetizer #(.N(NSRC), .SRC_UID(UIDS), .SRC_PTYPE(PTYPES), .STAGE_AW(STAGE_AW)) u_pkt (
    .clk(clk), .rst_n(rst_n), .test_mode(test_mode),
    .s_valid(s_valid), .s_ready(s_ready), .s_data(s_data), .s_last(s_last), .s_flags(s_flags), .s_frame(s_frame),
    .s_row(s_row), .s_meta(s_meta), .s_ts(s_ts),
    .m_valid(p_valid), .m_ready(p_ready), .m_data(p_data), .m_last(p_last), .m_sop(p_sop), .m_len(p_len),
    .seq(seq_u), .stage_hwm(stage_hwm)
  );

  logic dma_busy, dma_axi_err, dma_dropping;
  logic [31:0] wr_ptr, fill_level;
  sf_dma_controller u_dma (
    .clk(clk), .rst_n(rst_n), .enable(dma_control_q[0]), .ring_base(ring_base_q), .ring_log2(ring_size_log2_q[4:0]),
    .rd_ptr(rd_ptr_q), .irq_threshold(irq_threshold_q),
    .s_valid(p_valid), .s_ready(p_ready), .s_data(p_data), .s_last(p_last), .s_sop(p_sop), .s_len(p_len),
    .m_axi_awaddr(m_axi_awaddr), .m_axi_awlen(m_axi_awlen), .m_axi_awsize(m_axi_awsize), .m_axi_awburst(m_axi_awburst),
    .m_axi_awvalid(m_axi_awvalid), .m_axi_awready(m_axi_awready), .m_axi_wdata(m_axi_wdata), .m_axi_wstrb(m_axi_wstrb),
    .m_axi_wlast(m_axi_wlast), .m_axi_wvalid(m_axi_wvalid), .m_axi_wready(m_axi_wready), .m_axi_bresp(m_axi_bresp),
    .m_axi_bvalid(m_axi_bvalid), .m_axi_bready(m_axi_bready),
    .wr_ptr(wr_ptr), .fill_level(fill_level), .pkt_count(pkt_count), .drop_count(drop_count), .busy(dma_busy),
    .axi_error(dma_axi_err), .dropping(dma_dropping), .thresh_evt(thresh_evt), .drop_evt(drop_evt)
  );
  assign wr_ptr_i = wr_ptr;
  assign fill_level_i = fill_level;
  assign pkt_count_i = pkt_count;
  assign drop_count_i = drop_count;
  assign dma_status_i = {29'd0, dma_dropping, dma_axi_err, dma_busy};

  // ===========================================================================
  // I2C control master
  // ===========================================================================
  logic i2c_busy, i2c_done_u, i2c_ack_err;
  logic [7:0] i2c_rx;
  sf_i2c_master u_i2c (
    .clk(clk), .rst_n(rst_n), .prescale(i2c_prescale_q[15:0]), .cmd_stb(i2c_cmd_wstb[0]), .cmd(i2c_cmd_wdata[10:8]),
    .cmd_data(i2c_cmd_wdata[7:0]), .busy(i2c_busy), .done(i2c_done_u), .ack_err(i2c_ack_err), .rx_data(i2c_rx),
    .scl_i(i2c_scl_i), .sda_i(i2c_sda_i), .scl_oe(i2c_scl_oe), .sda_oe(i2c_sda_oe)
  );
  assign i2c_status_i = {16'd0, i2c_rx, 6'd0, i2c_ack_err, i2c_busy};

  // ===========================================================================
  // Status / interrupts
  // ===========================================================================
  assign ev_pulse = {em_integ_evt, sonar_ping_evt, fl_block_evt, ir_sweep_evt, raman_integ_evt, swir_exp_evt, ms_exp_evt, hsi_exp_evt};
  assign status_i = {24'd0, test_mode, overtemp, laser_emitting, host_lost, pps_seen, (drop_count != 0), fault_any, acq_en};
  assign irq_status_set_i = {28'd0, pps_pulse, (|laser_fault_evt) | (hsi_err_evt | ms_err_evt | swir_err_evt | raman_err_evt),
                             drop_evt, thresh_evt};
  assign irq = control_q[2] & |(irq_status_q[3:0] & irq_enable_q[3:0]);

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_top;
  assign unused_top = ^{scratch_q, ts_flags_q, event_ts_u, frame_tick, trig_level, raman_busy_u, raman_ovr_u, raman_mux_u,
                        raman_ch_u, ir_busy_u, ir_ovr_u, ir_mux_u, ir_ch_u, fl_busy_u, fl_ovr_u, fl_mux_u, fl_ch_u,
                        arr_realign_u, arr_slip_u, em_busy_u, em_ovr_u, em_mux_u, em_ch_u, hk_scan_u, hk_busy_u, hk_ovr_u,
                        seq_u, i2c_done_u, laser_kick_wdata, host_kick_wdata, ts_control_wdata[31:2], cal_cmd_wdata[31:1],
                        laser_arm_wdata[31:16], i2c_cmd_wdata[31:11], control_q[31:3], irq_status_q[31:4],
                        irq_enable_q[31:4], cal_sel_q[31:2], cal_addr_q[31:CAL_AW], cal_flags_q[31:1], sync_control_q[31:3],
                        trig_mask_q[31:8], ring_size_log2_q[31:5], hsi_control_q[31:2], hsi_sat_q[31:16],
                        ms_control_q[31:12], ms_control_q[7:2], ms_sat_q[31:16], ms_led_mask_q[31:8], swir_control_q[31:3],
                        swir_sat_q[31:16], raman_control_q[31:16], raman_control_q[7:2], raman_npix_q[31:12],
                        raman_sat_q[31:16], laser_control_q[31:1], ir_control_q[31:12], ir_control_q[7:1],
                        ir_half_period_q[31:24], ir_nperiods_q[31:16], ir_settle_q[31:16], fl_control_q[31:11],
                        fl_control_q[7:1], fl_on_samples_q[31:16], fl_blank_samples_q[31:16], fl_npulses_q[31:16],
                        sonar_control_q[31:2], sonar_rx_delay_q[31:24], sonar_nsamp_q[31:16], em_control_q[31:2],
                        em_amplitude_q[31:16], em_nsamp_q[31:24], hk_control_q[31:2], i2c_prescale_q[31:16],
                        diag_control_q[31:1], temp_limit_q[31:16], frame_index, dma_control_q[31:1], laser_faults_q[31:4]};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
