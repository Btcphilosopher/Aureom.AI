// Silica Flux utility package: CRC-32 and saturating arithmetic helpers.
// Functions assign to the function name (no `return`) for Yosys 0.33 compatibility.
package sf_util_pkg;
  // CRC-32/ISO-HDLC (zlib) register update for one 32-bit word.
  // The word is consumed as four little-endian bytes, each LSB first, which is
  // exactly bit order data[0], data[1], ..., data[31] for the reflected CRC.
  // Init 0xFFFFFFFF, final XOR 0xFFFFFFFF (applied by the caller).
  function automatic logic [31:0] crc32_word(input logic [31:0] crc, input logic [31:0] data);
    logic [31:0] c;
    c = crc;
    for (int i = 0; i < 32; i++) begin
      if ((c[0] ^ data[i]) == 1'b1) c = (c >> 1) ^ 32'hEDB88320;
      else c = c >> 1;
    end
    crc32_word = c;
  endfunction

  // Saturate a signed 64-bit value to signed 32-bit.
  function automatic logic [31:0] sat_s64_to_s32(input logic signed [63:0] v);
    if (v > 64'sh000000007FFFFFFF) sat_s64_to_s32 = 32'h7FFFFFFF;
    else if (v < -64'sh0000000080000000) sat_s64_to_s32 = 32'h80000000;
    else sat_s64_to_s32 = v[31:0];
  endfunction

  // Saturate an unsigned 64-bit value to unsigned 32-bit.
  function automatic logic [31:0] sat_u64_to_u32(input logic [63:0] v);
    if (v > 64'h00000000FFFFFFFF) sat_u64_to_u32 = 32'hFFFFFFFF;
    else sat_u64_to_u32 = v[31:0];
  endfunction
endpackage
