// Hardware timestamp engine.
//  * 64-bit free-running counter in clk_sys (10 ns resolution at 100 MHz).
//    64 bits roll over after ~5,800 years; rollover is still detected and
//    flagged so the host never silently mis-orders data after a LOAD.
//  * SNAPSHOT copies the live counter atomically into snap (coherent 64-bit
//    read through two 32-bit registers).
//  * LOAD presets the counter (used by verification to exercise carries and
//    rollover, and by hosts that discipline the counter to GNSS time).
//  * PPS input (asynchronous) is synchronised; the counter value at each PPS
//    rising edge is latched with the PPS count. The host fits ticks -> UTC
//    from these latches (aardvark_imaging.acquisition.timebase).
//  * PPS_LOST is raised once if no edge arrives within PPS_TIMEOUT cycles of
//    the previous edge.
//  * N event inputs (single-cycle pulses) latch the counter into event_ts.
module sf_timestamp_engine #(
  parameter int          N_EVENTS    = 8,
  parameter logic [31:0] PPS_TIMEOUT = 32'd150_000_000
) (
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    snapshot_stb,
  input  logic                    load_stb,
  input  logic [63:0]             load_value,
  input  logic                    pps_async,
  input  logic [N_EVENTS-1:0]     event_pulse,
  output logic [63:0]             ts_now,
  output logic [63:0]             snap,
  output logic [63:0]             pps_ts,
  output logic [31:0]             pps_count,
  output logic                    pps_pulse,
  output logic                    pps_seen,
  output logic                    rollover_evt,
  output logic                    pps_lost_evt,
  output logic [N_EVENTS*64-1:0]  event_ts
);
  logic pps_s, pps_q, pps_lost_flag;
  logic [31:0] since_pps;
  sf_cdc_bit #(.STAGES(3)) u_pps (.clk(clk), .rst_n(rst_n), .d(pps_async), .q(pps_s));

  assign pps_pulse = pps_s & ~pps_q;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      ts_now <= '0; snap <= '0; pps_ts <= '0; pps_count <= '0; pps_q <= 1'b0; pps_seen <= 1'b0;
      rollover_evt <= 1'b0; pps_lost_evt <= 1'b0; pps_lost_flag <= 1'b0; since_pps <= '0; event_ts <= '0;
    end else begin
      rollover_evt <= 1'b0;
      pps_lost_evt <= 1'b0;
      pps_q <= pps_s;
      if (load_stb) ts_now <= load_value;
      else begin
        ts_now <= ts_now + 64'd1;
        if (ts_now == 64'hFFFF_FFFF_FFFF_FFFF) rollover_evt <= 1'b1;
      end
      if (snapshot_stb) snap <= ts_now;
      if (pps_pulse) begin
        pps_ts <= ts_now;
        pps_count <= pps_count + 32'd1;
        pps_seen <= 1'b1;
        since_pps <= '0;
        pps_lost_flag <= 1'b0;
      end else if (pps_seen) begin
        if (since_pps != 32'hFFFF_FFFF) since_pps <= since_pps + 32'd1;
        if (since_pps == PPS_TIMEOUT && !pps_lost_flag) begin
          pps_lost_evt <= 1'b1;
          pps_lost_flag <= 1'b1;
        end
      end
      for (int i = 0; i < N_EVENTS; i++) begin
        if (event_pulse[i]) event_ts[i*64 +: 64] <= ts_now;
      end
    end
  end
endmodule
