// Cross-sensor synchronisation: master frame timing and trigger distribution.
//  * Internal mode: a frame tick every FRAME_PERIOD cycles.
//  * EXT_SYNC: frame ticks follow rising edges of an external sync input
//    (e.g. a vehicle or sonar master), synchronised into clk_sys.
//  * PPS_ALIGN: after ENABLE, the first frame tick is the next PPS edge, so
//    frame boundaries are phase-locked to GNSS seconds.
//  * Each of 8 trigger channels fires on every DIV-th frame tick, OFFSET
//    cycles after the tick, as a WIDTH-cycle level (trig_out) and a
//    single-cycle pulse (trig_pulse). A tick arriving while a channel's offset
//    delay is still pending is counted as a trigger overrun.
module sf_sensor_sync #(
  parameter int N_CH = 8
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic              enable,
  input  logic              ext_sync_en,
  input  logic              pps_align,
  input  logic [31:0]       frame_period,
  input  logic [N_CH-1:0]   trig_mask,
  input  logic [N_CH*32-1:0] trig_div,     // per channel {WIDTH[31:16], DIV[15:0]}
  input  logic [N_CH*32-1:0] trig_offset,
  input  logic              ext_sync_async,
  input  logic              pps_pulse,
  output logic              frame_tick,
  output logic [31:0]       frame_index,
  output logic [N_CH-1:0]   trig_pulse,
  output logic [N_CH-1:0]   trig_out,
  output logic              overrun_evt
);
  logic ext_s, ext_q, waiting_pps, running;
  logic [31:0] pcnt;
  sf_cdc_bit #(.STAGES(3)) u_ext (.clk(clk), .rst_n(rst_n), .d(ext_sync_async), .q(ext_s));

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      ext_q <= 1'b0; waiting_pps <= 1'b0; running <= 1'b0; pcnt <= '0; frame_tick <= 1'b0; frame_index <= '0;
    end else begin
      ext_q <= ext_s;
      frame_tick <= 1'b0;
      if (!enable) begin
        running <= 1'b0; waiting_pps <= 1'b0; pcnt <= '0;
      end else if (!running && !waiting_pps) begin
        if (pps_align && !ext_sync_en) waiting_pps <= 1'b1;
        else begin running <= 1'b1; pcnt <= '0; if (!ext_sync_en) frame_tick <= 1'b1; end
      end else if (waiting_pps) begin
        if (pps_pulse) begin waiting_pps <= 1'b0; running <= 1'b1; pcnt <= '0; frame_tick <= 1'b1; end
      end else if (ext_sync_en) begin
        if (ext_s && !ext_q) frame_tick <= 1'b1;
      end else begin
        if (pcnt >= ((frame_period < 32'd16) ? 32'd15 : frame_period - 32'd1)) begin
          pcnt <= '0; frame_tick <= 1'b1;
        end else pcnt <= pcnt + 32'd1;
      end
      if (frame_tick) frame_index <= frame_index + 32'd1;
    end
  end

  logic [N_CH*16-1:0] divc, widc;
  logic [N_CH*32-1:0] offc;
  logic [N_CH-1:0]    pend;
  logic [N_CH-1:0]    ovr;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      divc <= '0; widc <= '0; offc <= '0; pend <= '0; trig_pulse <= '0; trig_out <= '0; ovr <= '0;
    end else begin
      trig_pulse <= '0;
      ovr <= '0;
      for (int c = 0; c < N_CH; c++) begin
        logic [15:0] div, wid;
        div = trig_div[c*32 +: 16];
        wid = trig_div[c*32 + 16 +: 16];
        if (widc[c*16 +: 16] != 0) widc[c*16 +: 16] <= widc[c*16 +: 16] - 16'd1;
        else trig_out[c] <= 1'b0;
        if (!enable || !trig_mask[c]) begin
          divc[c*16 +: 16] <= '0; pend[c] <= 1'b0; trig_out[c] <= 1'b0; widc[c*16 +: 16] <= '0;
        end else begin
          if (frame_tick) begin
            if (divc[c*16 +: 16] == 0) begin
              if (pend[c]) ovr[c] <= 1'b1;
              pend[c] <= 1'b1;
              offc[c*32 +: 32] <= trig_offset[c*32 +: 32];
            end
            divc[c*16 +: 16] <= (divc[c*16 +: 16] + 16'd1 >= ((div == 0) ? 16'd1 : div)) ? 16'd0 : divc[c*16 +: 16] + 16'd1;
          end else if (pend[c]) begin
            if (offc[c*32 +: 32] == 0) begin
              pend[c] <= 1'b0;
              trig_pulse[c] <= 1'b1;
              trig_out[c] <= 1'b1;
              widc[c*16 +: 16] <= (wid == 0) ? 16'd0 : wid - 16'd1;
            end else offc[c*32 +: 32] <= offc[c*32 +: 32] - 32'd1;
          end
        end
      end
    end
  end
  assign overrun_evt = |ovr;
endmodule
