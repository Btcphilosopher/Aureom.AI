// Raman excitation laser timing and interlock (secondary, FPGA-level layer).
// The PRIMARY laser interlock must be hard-wired in the laser driver (housing
// pressure switch / water-contact sensor in series with the driver enable);
// this block never replaces it. It adds:
//  * ARM key: writing 0xA55A arms; any other value disarms immediately.
//  * Host watchdog: when armed, LASER_KICK must arrive within WD_TIMEOUT
//    cycles; otherwise the laser disarms and WATCHDOG is flagged.
//  * Interlock: `submerged` (synchronised) and `!overtemp` must hold to arm
//    and to keep emitting; a drop during emission cuts output immediately
//    (the output gate is combinational on the synchronised interlock).
//  * Max-on: continuous emission is capped by min(MAX_ON_SW, MAX_ON_HW).
//  * Gate: a controller holds gate_req; after DELAY cycles the laser emits
//    (CW, or pulsed with PULSE_WIDTH/PULSE_PERIOD) until gate_req falls.
module sf_laser_timing #(
  parameter logic [31:0] MAX_ON_HW = 32'd3_000_000_000,   // 30 s at 100 MHz hard cap
  parameter logic [15:0] ARM_KEY   = 16'hA55A
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        arm_stb,
  input  logic [15:0] arm_key,
  input  logic        kick_stb,
  input  logic [31:0] wd_timeout,
  input  logic        pulsed,
  input  logic [31:0] delay_cycles,
  input  logic [31:0] pulse_width,
  input  logic [31:0] pulse_period,
  input  logic [31:0] max_on_sw,
  input  logic        submerged_async,
  input  logic        overtemp,
  input  logic        gate_req,
  output logic        laser_enable,
  output logic        laser_mod,
  output logic        emitting,
  output logic        armed,
  output logic        interlock_ok,
  output logic        wd_ok,
  output logic        abort_evt,
  output logic        emit_start_evt,
  output logic [3:0]  fault_evt        // {OVERTEMP, MAX_ON, WATCHDOG, INTERLOCK_DROP}
);
  typedef enum logic [1:0] {L_DISARMED, L_ARMED, L_DELAY, L_EMIT} st_t;
  st_t st;
  logic submerged;
  logic [31:0] wd, dcnt, oncnt, pcnt, max_on;
  sf_cdc_bit #(.STAGES(2)) u_sub (.clk(clk), .rst_n(rst_n), .d(submerged_async), .q(submerged));

  assign interlock_ok = submerged && !overtemp;
  assign max_on = (max_on_sw < MAX_ON_HW) ? max_on_sw : MAX_ON_HW;
  assign armed = (st != L_DISARMED);
  assign wd_ok = armed;
  assign emitting = (st == L_EMIT) && interlock_ok;
  assign laser_enable = emitting;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= L_DISARMED; wd <= '0; dcnt <= '0; oncnt <= '0; pcnt <= '0; laser_mod <= 1'b0;
      abort_evt <= 1'b0; emit_start_evt <= 1'b0; fault_evt <= '0;
    end else begin
      abort_evt <= 1'b0; emit_start_evt <= 1'b0; fault_evt <= '0;
      if (st != L_DISARMED) begin
        if (kick_stb) wd <= '0;
        else if (wd != 32'hFFFFFFFF) wd <= wd + 32'd1;
      end
      case (st)
        L_DISARMED: begin
          laser_mod <= 1'b0;
          if (arm_stb && arm_key == ARM_KEY && interlock_ok && wd_timeout != 0) begin
            st <= L_ARMED; wd <= '0;
          end
        end
        L_ARMED: begin
          laser_mod <= 1'b0;
          if (gate_req) begin st <= L_DELAY; dcnt <= delay_cycles; end
        end
        L_DELAY: begin
          if (!gate_req) st <= L_ARMED;
          else if (dcnt == 0) begin
            st <= L_EMIT; oncnt <= '0; pcnt <= '0; emit_start_evt <= 1'b1; laser_mod <= 1'b1;
          end else dcnt <= dcnt - 32'd1;
        end
        L_EMIT: begin
          oncnt <= oncnt + 32'd1;
          if (pulsed) begin
            pcnt <= (pcnt + 32'd1 >= ((pulse_period == 0) ? 32'd1 : pulse_period)) ? 32'd0 : pcnt + 32'd1;
            laser_mod <= ((pcnt + 32'd1 >= ((pulse_period == 0) ? 32'd1 : pulse_period)) ? 32'd0 : pcnt + 32'd1) < pulse_width;
          end else laser_mod <= 1'b1;
          if (!gate_req) begin st <= L_ARMED; laser_mod <= 1'b0; end
          else if (oncnt + 32'd1 >= max_on) begin
            st <= L_DISARMED; laser_mod <= 1'b0; abort_evt <= 1'b1; fault_evt[2] <= 1'b1;
          end
        end
        default: st <= L_DISARMED;
      endcase
      // Faults and disarm conditions override the state machine.
      if (st != L_DISARMED) begin
        if (arm_stb && arm_key != ARM_KEY) begin
          st <= L_DISARMED; laser_mod <= 1'b0; if (st == L_EMIT) abort_evt <= 1'b1;
        end
        if (!submerged) begin
          st <= L_DISARMED; laser_mod <= 1'b0; fault_evt[0] <= 1'b1; if (st == L_EMIT || st == L_DELAY) abort_evt <= 1'b1;
        end
        if (overtemp) begin
          st <= L_DISARMED; laser_mod <= 1'b0; fault_evt[3] <= 1'b1; if (st == L_EMIT || st == L_DELAY) abort_evt <= 1'b1;
        end
        if (!kick_stb && wd >= wd_timeout) begin
          st <= L_DISARMED; laser_mod <= 1'b0; fault_evt[1] <= 1'b1; if (st == L_EMIT || st == L_DELAY) abort_evt <= 1'b1;
        end
      end
    end
  end
endmodule
