// FPGA diagnostics and host-link supervision.
//  * Counts error events from every subsystem (8 saturating 16-bit
//    counters + a 32-bit total), heartbeat (every 2^20 cycles) and uptime.
//  * Host supervision: HOST_KICK must arrive within HOST_TIMEOUT cycles or
//    HOST_LOST is raised. Acquisition and DMA deliberately CONTINUE when the
//    host link is lost: the onboard recorder keeps writing the ring buffer and
//    data are never discarded because a workstation disconnected.
//  * Over-temperature: housekeeping channel 0 code >= TEMP_LIMIT raises
//    OVERTEMP, which the top level feeds to the laser interlock.
//  * When PKT_EN is set, emits a DIAGNOSTIC packet every PERIOD cycles with a
//    16-word snapshot (layout in docs/hardware_verification.md).
module sf_fpga_diagnostics #(
  parameter int NERR = 8,
  parameter int NSTATUS = 5
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic [NERR-1:0]      err_pulse,
  input  logic                 host_kick,
  input  logic [31:0]          host_timeout,
  input  logic [15:0]          temp_code,
  input  logic [15:0]          temp_limit,
  input  logic                 pkt_en,
  input  logic [31:0]          period,
  input  logic [NSTATUS*32-1:0] status_words,
  input  logic [15:0]          stage_hwm,
  input  logic [63:0]          ts_now,
  output logic [31:0]          heartbeat,
  output logic                 host_lost,
  output logic                 overtemp,
  output logic                 fault_any,
  output logic [31:0]          err_total,
  output logic                 src_valid,
  input  logic                 src_ready,
  output logic [31:0]          src_data,
  output logic                 src_last,
  output logic [7:0]           src_flags,
  output logic [31:0]          src_frame,
  output logic [15:0]          src_row,
  output logic [31:0]          src_meta,
  output logic [63:0]          src_ts
);
  logic [63:0] uptime;
  logic [19:0] hb_div;
  logic [31:0] since_kick, pc, snaps;
  logic [NERR*16-1:0] errc;
  logic        emitting;
  logic [3:0]  eidx;
  logic [31:0] snap [0:15];

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      uptime <= '0; hb_div <= '0; heartbeat <= '0; since_kick <= '0; host_lost <= 1'b0; overtemp <= 1'b0;
      errc <= '0; err_total <= '0; pc <= '0; snaps <= '0; emitting <= 1'b0; eidx <= '0;
      src_valid <= 1'b0; src_data <= '0; src_last <= 1'b0; src_flags <= '0; src_frame <= '0; src_row <= '0;
      src_meta <= '0; src_ts <= '0;
      for (int i = 0; i < 16; i++) snap[i] <= '0;
    end else begin
      uptime <= uptime + 64'd1;
      hb_div <= hb_div + 20'd1;
      if (hb_div == 20'hFFFFF) heartbeat <= heartbeat + 32'd1;
      if (host_kick) begin since_kick <= '0; host_lost <= 1'b0; end
      else begin
        if (since_kick != 32'hFFFFFFFF) since_kick <= since_kick + 32'd1;
        if (host_timeout != 0 && since_kick >= host_timeout) host_lost <= 1'b1;
      end
      overtemp <= (temp_code >= temp_limit);
      for (int i = 0; i < NERR; i++) begin
        if (err_pulse[i] && errc[16*i +: 16] != 16'hFFFF) errc[16*i +: 16] <= errc[16*i +: 16] + 16'd1;
      end
      if (|err_pulse && err_total != 32'hFFFFFFFF) err_total <= err_total + 32'd1;

      if (!emitting) begin
        if (pkt_en) begin
          if (pc >= ((period < 32'd1024) ? 32'd1023 : period - 32'd1)) begin
            pc <= '0; emitting <= 1'b1; eidx <= '0;
            snap[0] <= uptime[63:32]; snap[1] <= uptime[31:0]; snap[2] <= heartbeat; snap[3] <= err_total;
            snap[4] <= {29'd0, fault_any, overtemp, host_lost};
            for (int i = 0; i < 4; i++) snap[5 + i] <= {errc[16*(2*i+1) +: 16], errc[16*(2*i) +: 16]};
            snap[9] <= {16'd0, temp_code}; snap[10] <= {16'd0, stage_hwm};
            for (int i = 0; i < NSTATUS; i++) snap[11 + i] <= status_words[32*i +: 32];
            src_ts <= ts_now;
          end else pc <= pc + 32'd1;
        end else pc <= '0;
      end else if (!src_valid || src_ready) begin
        if (src_valid && src_last) begin src_valid <= 1'b0; emitting <= 1'b0; snaps <= snaps + 32'd1; end
        else begin
          src_valid <= 1'b1; src_data <= snap[eidx]; src_last <= (eidx == 4'd15);
          src_flags <= 8'd0; src_frame <= snaps; src_row <= 16'd0; src_meta <= 32'd16;
          eidx <= eidx + 4'd1;
        end
      end
    end
  end
  assign fault_any = host_lost | overtemp | (err_total != 0);
endmodule
