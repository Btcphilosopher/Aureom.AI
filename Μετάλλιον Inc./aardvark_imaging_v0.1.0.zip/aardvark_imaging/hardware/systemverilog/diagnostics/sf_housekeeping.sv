// Housekeeping scanner: every PERIOD cycles converts the four multiplexed
// housekeeping channels (0 temperature, 1 rail voltage, 2 current,
// 3 housing pressure), keeps the latest codes for the register file and,
// when PKT_EN is set, emits a HOUSEKEEPING packet (4 words, one code each).
module sf_housekeeping (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        enable,
  input  logic        pkt_en,
  input  logic [31:0] period,
  input  logic [63:0] ts_now,
  output logic        adc_start,
  output logic [1:0]  adc_ch,
  input  logic        adc_valid,
  input  logic [15:0] adc_data,
  input  logic [1:0]  adc_ch_in,
  output logic [63:0] codes,
  output logic        src_valid,
  input  logic        src_ready,
  output logic [31:0] src_data,
  output logic        src_last,
  output logic [7:0]  src_flags,
  output logic [31:0] src_frame,
  output logic [15:0] src_row,
  output logic [31:0] src_meta,
  output logic [63:0] src_ts,
  output logic        scan_done
);
  typedef enum logic [1:0] {H_WAIT, H_CONV, H_EMIT} st_t;
  st_t st;
  logic [31:0] pc, scans;
  logic [2:0]  ch, eidx;
  logic        pending;
  logic [63:0] ts_l;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= H_WAIT; pc <= '0; scans <= '0; ch <= '0; eidx <= '0; pending <= 1'b0; ts_l <= '0; codes <= '0;
      adc_start <= 1'b0; adc_ch <= '0; scan_done <= 1'b0;
      src_valid <= 1'b0; src_data <= '0; src_last <= 1'b0; src_flags <= '0; src_frame <= '0; src_row <= '0;
      src_meta <= '0; src_ts <= '0;
    end else begin
      adc_start <= 1'b0; scan_done <= 1'b0;
      case (st)
        H_WAIT: begin
          if (enable) begin
            if (pc >= ((period < 32'd256) ? 32'd255 : period - 32'd1)) begin
              pc <= '0; st <= H_CONV; ch <= '0; pending <= 1'b0; ts_l <= ts_now;
            end else pc <= pc + 32'd1;
          end else pc <= '0;
        end
        H_CONV: begin
          if (!pending) begin
            adc_start <= 1'b1; adc_ch <= ch[1:0]; pending <= 1'b1;
          end else if (adc_valid) begin
            codes[16*adc_ch_in +: 16] <= adc_data;
            pending <= 1'b0;
            if (ch == 3'd3) begin
              scan_done <= 1'b1; scans <= scans + 32'd1;
              if (pkt_en) begin st <= H_EMIT; eidx <= '0; end else st <= H_WAIT;
            end
            ch <= ch + 3'd1;
          end
        end
        H_EMIT: begin
          if (!src_valid || src_ready) begin
            if (src_valid && src_last) begin src_valid <= 1'b0; st <= H_WAIT; end
            else begin
              src_valid <= 1'b1;
              src_data <= {16'd0, codes[16*eidx[1:0] +: 16]};
              src_last <= (eidx == 3'd3);
              src_flags <= 8'd0; src_frame <= scans - 32'd1; src_row <= 16'd0; src_meta <= 32'd4; src_ts <= ts_l;
              eidx <= eidx + 3'd1;
            end
          end
        end
        default: st <= H_WAIT;
      endcase
    end
  end
endmodule
