// Toggle-based single-cycle pulse synchroniser.
// Contract: source pulses must be separated by at least (STAGES + 2)
// destination clock cycles; closer pulses may merge. Merged pulses are not
// silently lost: `src_busy` is high while a toggle is in flight so the
// source can count or hold events.
module sf_cdc_pulse #(
  parameter int STAGES = 2
) (
  input  logic src_clk,
  input  logic src_rst_n,
  input  logic src_pulse,
  output logic src_busy,
  input  logic dst_clk,
  input  logic dst_rst_n,
  output logic dst_pulse
);
  logic src_tog;
  always_ff @(posedge src_clk) begin
    if (!src_rst_n) src_tog <= 1'b0;
    else if (src_pulse) src_tog <= ~src_tog;
  end

  logic dst_tog_s, dst_tog_q;
  sf_cdc_bit #(.STAGES(STAGES)) u_fwd (.clk(dst_clk), .rst_n(dst_rst_n), .d(src_tog), .q(dst_tog_s));
  always_ff @(posedge dst_clk) begin
    if (!dst_rst_n) dst_tog_q <= 1'b0;
    else dst_tog_q <= dst_tog_s;
  end
  assign dst_pulse = dst_tog_s ^ dst_tog_q;

  // Acknowledge path back to the source domain for the busy indication.
  logic ack_s;
  sf_cdc_bit #(.STAGES(STAGES)) u_ack (.clk(src_clk), .rst_n(src_rst_n), .d(dst_tog_q), .q(ack_s));
  assign src_busy = src_tog ^ ack_s;
endmodule
