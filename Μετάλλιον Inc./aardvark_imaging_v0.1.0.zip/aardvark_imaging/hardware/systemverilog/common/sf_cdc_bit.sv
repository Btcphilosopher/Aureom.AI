// Multi-flop synchroniser for a single quasi-static or level signal.
// The destination flops carry ASYNC_REG so placement keeps them adjacent and
// timing tools treat the first stage as a metastability capture register.
module sf_cdc_bit #(
  parameter int   STAGES = 2,
  parameter logic RESET_VAL = 1'b0
) (
  input  logic clk,
  input  logic rst_n,
  input  logic d,
  output logic q
);
  (* ASYNC_REG = "TRUE" *) logic [STAGES-1:0] sync;
  always_ff @(posedge clk) begin
    if (!rst_n) sync <= {STAGES{RESET_VAL}};
    else sync <= {sync[STAGES-2:0], d};
  end
  assign q = sync[STAGES-1];
endmodule
