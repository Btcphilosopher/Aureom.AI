// Generic SPI master: one chip select, shared SCLK/MOSI, LANES parallel MISO
// inputs (simultaneous-sampling ADCs). Modes selectable by CPOL/CPHA.
// MSB first. SCLK half period = CLKDIV clk cycles.
module sf_spi_master #(
  parameter int   BITS   = 16,
  parameter int   LANES  = 1,
  parameter int   CLKDIV = 2,
  parameter logic CPOL   = 1'b0,
  parameter logic CPHA   = 1'b0
) (
  input  logic                  clk,
  input  logic                  rst_n,
  input  logic                  start,
  input  logic [BITS-1:0]       tx_data,
  output logic                  busy,
  output logic                  done,
  output logic [LANES*BITS-1:0] rx_data,
  output logic                  sclk,
  output logic                  cs_n,
  output logic                  mosi,
  input  logic [LANES-1:0]      miso
);
  localparam int CW = (CLKDIV > 1) ? $clog2(CLKDIV) : 1;
  localparam int BW = $clog2(BITS + 1);
  typedef enum logic [1:0] {S_IDLE, S_SETUP, S_RUN, S_HOLD} st_t;
  st_t st;
  logic [CW-1:0]   cnt;
  logic [BW-1:0]   bitc;
  logic            half;
  logic [BITS-1:0] sh;
  logic            tick;

  assign tick = (cnt == CW'(CLKDIV - 1));
  assign busy = (st != S_IDLE);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= S_IDLE; cnt <= '0; bitc <= '0; half <= 1'b0; sh <= '0;
      sclk <= CPOL; cs_n <= 1'b1; mosi <= 1'b0; done <= 1'b0; rx_data <= '0;
    end else begin
      done <= 1'b0;
      case (st)
        S_IDLE: begin
          sclk <= CPOL;
          cs_n <= 1'b1;
          if (start) begin
            sh <= tx_data; cs_n <= 1'b0; st <= S_SETUP; cnt <= '0; bitc <= '0; half <= 1'b0;
            if (!CPHA) mosi <= tx_data[BITS-1];
          end
        end
        S_SETUP: begin
          if (tick) begin cnt <= '0; st <= S_RUN; end
          else cnt <= cnt + 1'b1;
        end
        S_RUN: begin
          if (tick) begin
            cnt <= '0;
            if (!half) begin
              // leading edge
              sclk <= ~CPOL; half <= 1'b1;
              if (!CPHA) begin
                for (int l = 0; l < LANES; l++) rx_data[l*BITS +: BITS] <= {rx_data[l*BITS +: BITS-1], miso[l]};
              end else begin
                mosi <= sh[BITS-1]; sh <= sh << 1;
              end
            end else begin
              // trailing edge
              sclk <= CPOL; half <= 1'b0;
              if (!CPHA) begin
                sh <= sh << 1; mosi <= sh[BITS-2];
              end else begin
                for (int l = 0; l < LANES; l++) rx_data[l*BITS +: BITS] <= {rx_data[l*BITS +: BITS-1], miso[l]};
              end
              if (bitc == BW'(BITS - 1)) st <= S_HOLD;
              bitc <= bitc + 1'b1;
            end
          end else cnt <= cnt + 1'b1;
        end
        S_HOLD: begin
          if (tick) begin cnt <= '0; cs_n <= 1'b1; done <= 1'b1; st <= S_IDLE; end
          else cnt <= cnt + 1'b1;
        end
        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
