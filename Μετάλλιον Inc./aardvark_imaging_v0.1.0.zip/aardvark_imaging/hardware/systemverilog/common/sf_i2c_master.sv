// Byte-level I2C master with clock-stretching support.
// Open-drain outputs: *_oe = 1 pulls the line low; 0 releases it.
// Commands (cmd_stb pulse with cmd):
//   1 START (also repeated START)   2 WRITE cmd_data, ACK sampled into ack_err
//   3 READ, master ACKs             4 READ, master NACKs   5 STOP
// Each bit is four quarter periods of PRESCALE clk cycles. In quarter 1 the
// master releases SCL and waits while a slave stretches the clock.
module sf_i2c_master (
  input  logic        clk,
  input  logic        rst_n,
  input  logic [15:0] prescale,
  input  logic        cmd_stb,
  input  logic [2:0]  cmd,
  input  logic [7:0]  cmd_data,
  output logic        busy,
  output logic        done,
  output logic        ack_err,
  output logic [7:0]  rx_data,
  input  logic        scl_i,
  input  logic        sda_i,
  output logic        scl_oe,
  output logic        sda_oe
);
  localparam logic [2:0] C_START = 3'd1, C_WRITE = 3'd2, C_READ_ACK = 3'd3, C_READ_NACK = 3'd4, C_STOP = 3'd5;
  logic [2:0]  op;
  logic [15:0] qcnt;
  logic [1:0]  q;
  logic [3:0]  bitn;
  logic [7:0]  sh;
  logic        tick, stretch_wait;

  assign tick = (qcnt >= ((prescale == 16'd0) ? 16'd0 : prescale - 16'd1));
  // Quarter 1 -> 2 transition requires SCL to have actually risen.
  assign stretch_wait = (q == 2'd1) && !scl_i;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      busy <= 1'b0; done <= 1'b0; ack_err <= 1'b0; rx_data <= '0;
      scl_oe <= 1'b0; sda_oe <= 1'b0; op <= '0; qcnt <= '0; q <= '0; bitn <= '0; sh <= '0;
    end else begin
      done <= 1'b0;
      if (!busy) begin
        if (cmd_stb && cmd >= C_START && cmd <= C_STOP) begin
          busy <= 1'b1; op <= cmd; sh <= cmd_data; q <= 2'd0; qcnt <= '0; bitn <= '0;
          if (cmd == C_WRITE) ack_err <= 1'b0;
          // quarter 0 action
          case (cmd)
            C_START: sda_oe <= 1'b0;                 // release SDA (repeated start support)
            C_STOP:  sda_oe <= 1'b1;                 // hold SDA low while SCL rises
            C_WRITE: sda_oe <= ~cmd_data[7];
            default: sda_oe <= 1'b0;                 // reads release SDA
          endcase
        end
      end else if (tick && !stretch_wait) begin
        qcnt <= '0;
        q <= q + 2'd1;
        case (q)
          2'd0: scl_oe <= 1'b0;                      // enter Q1: release SCL
          2'd1: begin                                // enter Q2: SCL is high
            if (op == C_START) sda_oe <= 1'b1;       // START: SDA falls while SCL high
            else if (op == C_WRITE || op == C_READ_ACK || op == C_READ_NACK) begin
              if (bitn == 4'd8) begin
                if (op == C_WRITE) ack_err <= sda_i;
              end else if (op != C_WRITE) begin
                rx_data <= {rx_data[6:0], sda_i};
              end
            end
          end
          2'd2: begin                                // enter Q3
            if (op == C_STOP) sda_oe <= 1'b0;        // STOP: SDA rises while SCL high
            else scl_oe <= 1'b1;                     // pull SCL low
          end
          2'd3: begin                                // end of bit
            if (op == C_START || op == C_STOP || bitn == 4'd8) begin
              busy <= 1'b0; done <= 1'b1;
              if (op == C_WRITE || op == C_READ_ACK || op == C_READ_NACK) sda_oe <= (op == C_READ_ACK) ? 1'b0 : 1'b0;
            end else begin
              bitn <= bitn + 4'd1;
              // quarter 0 of next bit: present data while SCL low
              if (bitn == 4'd7) begin
                if (op == C_WRITE) sda_oe <= 1'b0;   // release for slave ACK
                else sda_oe <= (op == C_READ_ACK);   // master ACK drives low
              end else if (op == C_WRITE) begin
                sda_oe <= ~sh[6 - bitn[2:0]];
              end else begin
                sda_oe <= 1'b0;
              end
            end
          end
          default: ;
        endcase
      end else if (!tick) begin
        qcnt <= qcnt + 16'd1;
      end
    end
  end
endmodule
