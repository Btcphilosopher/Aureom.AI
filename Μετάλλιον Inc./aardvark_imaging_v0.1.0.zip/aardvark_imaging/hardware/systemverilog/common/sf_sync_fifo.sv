// Single-clock first-word-fall-through FIFO with registered (BRAM-friendly)
// memory read. Capacity is 2**AW words in memory plus one output register.
//  * rd_valid/rd_data present the head word; rd_en consumes it.
//  * Writes when full are dropped and reported on `overflow` (single cycle).
module sf_sync_fifo #(
  parameter int DW = 32,
  parameter int AW = 4
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          wr_en,
  input  logic [DW-1:0] wr_data,
  output logic          full,
  output logic          overflow,
  input  logic          rd_en,
  output logic [DW-1:0] rd_data,
  output logic          rd_valid,
  output logic [AW+1:0] level
);
  localparam int DEPTH = 1 << AW;
  logic [DW-1:0] mem [0:DEPTH-1];
  logic [AW:0]   wptr, rptr, mem_count;
  logic          do_wr, do_rd_mem;

  assign mem_count = wptr - rptr;
  assign full      = (mem_count == DEPTH[AW:0]);
  assign do_wr     = wr_en && !full;
  assign do_rd_mem = (mem_count != '0) && (!rd_valid || rd_en);
  assign overflow  = wr_en && full;
  assign level     = {1'b0, mem_count} + {{(AW+1){1'b0}}, rd_valid};

  always_ff @(posedge clk) begin
    if (do_wr) mem[wptr[AW-1:0]] <= wr_data;
  end

  always_ff @(posedge clk) begin
    if (do_rd_mem) rd_data <= mem[rptr[AW-1:0]];
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      wptr     <= '0;
      rptr     <= '0;
      rd_valid <= 1'b0;
    end else begin
      if (do_wr) wptr <= wptr + 1'b1;
      if (do_rd_mem) begin
        rptr     <= rptr + 1'b1;
        rd_valid <= 1'b1;
      end else if (rd_en) begin
        rd_valid <= 1'b0;
      end
    end
  end
endmodule
