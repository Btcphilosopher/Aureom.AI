// Dual-clock FIFO (gray-coded pointers, two-flop pointer synchronisers,
// registered full/empty) with first-word-fall-through read side.
// Memory capacity 2**AW words (+1 read output register). AW >= 2.
// Levels are conservative (computed against synchronised remote pointers).
module sf_async_fifo #(
  parameter int DW = 18,
  parameter int AW = 4
) (
  input  logic          wclk,
  input  logic          wrst_n,
  input  logic          wr_en,
  input  logic [DW-1:0] wr_data,
  output logic          wfull,
  output logic          overflow,
  output logic [AW:0]   wlevel,
  input  logic          rclk,
  input  logic          rrst_n,
  input  logic          rd_en,
  output logic [DW-1:0] rd_data,
  output logic          rd_valid,
  output logic [AW:0]   rlevel
);
  localparam int DEPTH = 1 << AW;
  logic [DW-1:0] mem [0:DEPTH-1];

  function automatic logic [AW:0] gray2bin(input logic [AW:0] g);
    logic [AW:0] b;
    b[AW] = g[AW];
    for (int i = AW - 1; i >= 0; i--) b[i] = b[i+1] ^ g[i];
    gray2bin = b;
  endfunction

  // ---------------- write domain
  logic [AW:0] wbin, wgray, wbin_next, wgray_next;
  (* ASYNC_REG = "TRUE" *) logic [AW:0] wq1_rgray, wq2_rgray;
  logic do_wr;
  logic [AW:0] rgray;

  assign do_wr      = wr_en && !wfull;
  assign overflow   = wr_en && wfull;
  assign wbin_next  = wbin + {{AW{1'b0}}, do_wr};
  assign wgray_next = (wbin_next >> 1) ^ wbin_next;

  always_ff @(posedge wclk) begin
    if (do_wr) mem[wbin[AW-1:0]] <= wr_data;
  end

  always_ff @(posedge wclk) begin
    if (!wrst_n) begin
      wbin <= '0;
      wgray <= '0;
      wfull <= 1'b0;
      wq1_rgray <= '0;
      wq2_rgray <= '0;
    end else begin
      wbin  <= wbin_next;
      wgray <= wgray_next;
      wfull <= (wgray_next == {~wq2_rgray[AW:AW-1], wq2_rgray[AW-2:0]});
      wq1_rgray <= rgray;
      wq2_rgray <= wq1_rgray;
    end
  end
  assign wlevel = wbin - gray2bin(wq2_rgray);

  // ---------------- read domain
  logic [AW:0] rbin, rbin_next, rgray_next;
  (* ASYNC_REG = "TRUE" *) logic [AW:0] rq1_wgray, rq2_wgray;
  logic rempty, do_rd_mem;

  assign do_rd_mem  = !rempty && (!rd_valid || rd_en);
  assign rbin_next  = rbin + {{AW{1'b0}}, do_rd_mem};
  assign rgray_next = (rbin_next >> 1) ^ rbin_next;

  always_ff @(posedge rclk) begin
    if (do_rd_mem) rd_data <= mem[rbin[AW-1:0]];
  end

  always_ff @(posedge rclk) begin
    if (!rrst_n) begin
      rbin <= '0;
      rgray <= '0;
      rempty <= 1'b1;
      rd_valid <= 1'b0;
      rq1_wgray <= '0;
      rq2_wgray <= '0;
    end else begin
      rbin   <= rbin_next;
      rgray  <= rgray_next;
      rempty <= (rgray_next == rq2_wgray);
      rq1_wgray <= wgray;
      rq2_wgray <= rq1_wgray;
      if (do_rd_mem) rd_valid <= 1'b1;
      else if (rd_en) rd_valid <= 1'b0;
    end
  end
  assign rlevel = gray2bin(rq2_wgray) - rbin + {{AW{1'b0}}, rd_valid};
endmodule
