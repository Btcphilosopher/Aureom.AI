// Streaming per-pixel radiometric calibration (dark offset, flat-field gain,
// bad-pixel map, saturation detection) with a stallable 4-stage pipeline.
//
// Fixed-point contract (bit-exact model: aardvark_imaging.acquisition.fixedpoint):
//   raw   : u16 detector code
//   dark  : u16
//   gain  : u2.14 unsigned (16384 = 1.0)
//   diff  = max(raw - dark, 0)                         (u16)
//   prod  = diff * gain                                (u32)
//   y     = (prod + 2^13) >> 14   (round half up)      (u18)
//   out   = BAD (0xFFFE)       if bad and cal_en
//           SAT (0xFFFF)       if raw >= sat_level
//           min(y, 0xFFFD)     if cal_en             (clip flagged)
//           min(raw, 0xFFFD)   otherwise (bypass)    (clip flagged)
//   Entries with in_oob (index beyond the calibration RAM) use dark=0,
//   gain=1.0, bad=0 and report out_cal=0.
// Calibration RAM entry: {bad[32], gain[31:16], dark[15:0]}, written from the
// register file while acquisition continues (dual-port RAM).
module sf_calibration_engine #(
  parameter int CAL_AW = 10,
  parameter int TAG_W  = 4
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic              stall,
  input  logic              in_valid,
  input  logic [15:0]       in_raw,
  input  logic [CAL_AW-1:0] in_index,
  input  logic              in_oob,
  input  logic [TAG_W-1:0]  in_tag,
  input  logic              cal_en,
  input  logic [15:0]       sat_level,
  input  logic              cal_we,
  input  logic [CAL_AW-1:0] cal_waddr,
  input  logic [32:0]       cal_wdata,
  output logic              out_valid,
  output logic [15:0]       out_pix,
  output logic [TAG_W-1:0]  out_tag,
  output logic              out_sat,
  output logic              out_bad,
  output logic              out_clip,
  output logic              out_cal
);
  localparam logic [15:0] PIX_SAT = 16'hFFFF, PIX_BAD = 16'hFFFE, PIX_MAX = 16'hFFFD;
  localparam int DEPTH = 1 << CAL_AW;
  logic [32:0] cal_mem [0:DEPTH-1];
  logic [32:0] cal_q;

  initial begin
    for (int i = 0; i < DEPTH; i++) cal_mem[i] = {1'b0, 16'h4000, 16'h0000};
  end

  always_ff @(posedge clk) begin
    if (cal_we) cal_mem[cal_waddr] <= cal_wdata;
  end

  // S1: RAM read, pipeline raw/tag
  logic              v1, oob1;
  logic [15:0]       raw1;
  logic [TAG_W-1:0]  tag1;
  always_ff @(posedge clk) begin
    if (!stall) cal_q <= cal_mem[in_index];
  end
  always_ff @(posedge clk) begin
    if (!rst_n) begin v1 <= 1'b0; raw1 <= '0; tag1 <= '0; oob1 <= 1'b0; end
    else if (!stall) begin v1 <= in_valid; raw1 <= in_raw; tag1 <= in_tag; oob1 <= in_oob; end
  end

  // S2: dark subtraction, saturation compare
  logic              v2, sat2, bad2, cal2;
  logic [15:0]       diff2, gain2, raw2;
  logic [TAG_W-1:0]  tag2;
  logic [15:0]       dark_e, gain_e;
  logic              bad_e;
  assign dark_e = oob1 ? 16'h0000 : cal_q[15:0];
  assign gain_e = oob1 ? 16'h4000 : cal_q[31:16];
  assign bad_e  = oob1 ? 1'b0 : cal_q[32];
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      v2 <= 1'b0; sat2 <= 1'b0; bad2 <= 1'b0; cal2 <= 1'b0; diff2 <= '0; gain2 <= '0; raw2 <= '0; tag2 <= '0;
    end else if (!stall) begin
      v2    <= v1;
      tag2  <= tag1;
      raw2  <= raw1;
      sat2  <= (raw1 >= sat_level);
      bad2  <= bad_e & cal_en;
      cal2  <= cal_en & ~oob1;
      diff2 <= (raw1 > dark_e) ? (raw1 - dark_e) : 16'h0000;
      gain2 <= gain_e;
    end
  end

  // S3: gain multiply
  logic              v3, sat3, bad3, cal3, calen3;
  logic [31:0]       prod3;
  logic [15:0]       raw3;
  logic [TAG_W-1:0]  tag3;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      v3 <= 1'b0; sat3 <= 1'b0; bad3 <= 1'b0; cal3 <= 1'b0; calen3 <= 1'b0; prod3 <= '0; raw3 <= '0; tag3 <= '0;
    end else if (!stall) begin
      v3 <= v2; sat3 <= sat2; bad3 <= bad2; cal3 <= cal2; tag3 <= tag2; raw3 <= raw2;
      calen3 <= cal_en;
      prod3 <= diff2 * gain2;
    end
  end

  // S4: rounding, clipping and sentinel selection
  logic [17:0] y4;
  assign y4 = 18'((prod3 + 32'd8192) >> 14);
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      out_valid <= 1'b0; out_pix <= '0; out_tag <= '0; out_sat <= 1'b0; out_bad <= 1'b0; out_clip <= 1'b0; out_cal <= 1'b0;
    end else if (!stall) begin
      out_valid <= v3;
      out_tag   <= tag3;
      out_sat   <= sat3;
      out_bad   <= bad3;
      out_cal   <= cal3;
      out_clip  <= 1'b0;
      if (bad3) out_pix <= PIX_BAD;
      else if (sat3) out_pix <= PIX_SAT;
      else if (calen3) begin
        if (y4 > {2'b00, PIX_MAX}) begin out_pix <= PIX_MAX; out_clip <= 1'b1; end
        else out_pix <= y4[15:0];
      end else begin
        if (raw3 > PIX_MAX) begin out_pix <= PIX_MAX; out_clip <= 1'b1; end
        else out_pix <= raw3;
      end
    end
  end
endmodule
