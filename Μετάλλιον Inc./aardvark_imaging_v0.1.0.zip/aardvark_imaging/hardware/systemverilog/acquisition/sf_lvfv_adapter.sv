// Frame-valid / line-valid pixel bus adapter (LVDS-deserialised camera or
// ROIC output). Converts to the normalised pixel stream used by
// sf_row_capture: px_valid, px_data, px_sof (first pixel of frame) and
// px_eol (last pixel of row). One pixel of latency is needed to detect EOL.
module sf_lvfv_adapter (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        fval,
  input  logic        lval,
  input  logic [15:0] data,
  output logic        px_valid,
  output logic [15:0] px_data,
  output logic        px_sof,
  output logic        px_eol
);
  logic        hold_v, hold_sof, first_in_frame, fval_q;
  logic [15:0] hold_d;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      hold_v <= 1'b0; hold_sof <= 1'b0; hold_d <= '0; first_in_frame <= 1'b0; fval_q <= 1'b0;
      px_valid <= 1'b0; px_data <= '0; px_sof <= 1'b0; px_eol <= 1'b0;
    end else begin
      fval_q <= fval;
      if (fval && !fval_q) first_in_frame <= 1'b1;
      px_valid <= 1'b0; px_sof <= 1'b0; px_eol <= 1'b0;
      if (lval && fval) begin
        if (hold_v) begin
          px_valid <= 1'b1; px_data <= hold_d; px_sof <= hold_sof; px_eol <= 1'b0;
        end
        hold_v <= 1'b1; hold_d <= data;
        hold_sof <= first_in_frame || (fval && !fval_q);
        first_in_frame <= 1'b0;
      end else if (hold_v) begin
        px_valid <= 1'b1; px_data <= hold_d; px_sof <= hold_sof; px_eol <= 1'b1;
        hold_v <= 1'b0; hold_sof <= 1'b0;
      end
    end
  end
endmodule
