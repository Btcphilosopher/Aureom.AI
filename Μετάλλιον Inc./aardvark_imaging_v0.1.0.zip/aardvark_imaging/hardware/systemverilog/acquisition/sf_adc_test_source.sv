// Synthesizable SPI ADC test source used when GLOBAL.CONTROL.TEST_PATTERN is
// set. It answers the ADC interface's mode-0 read with deterministic codes
// so the downstream acquisition, packetisation and DMA can be verified
// without detectors. Lane l of conversion k returns
//   code = (37*(l+1)*k + 1000*l + OFFSET) mod 2**BITS.
// Every packet derived from these codes carries the SIMULATED flag.
module sf_adc_test_source #(
  parameter int BITS = 16,
  parameter int LANES = 1,
  parameter int OFFSET = 0
) (
  input  logic             clk,
  input  logic             rst_n,
  input  logic             sclk,
  input  logic             cs_n,
  output logic [LANES-1:0] miso
);
  logic sclk_q, cs_q;
  logic [31:0] k;
  logic [LANES*BITS-1:0] sh;
  always_ff @(posedge clk) begin
    if (!rst_n) begin sclk_q <= 1'b0; cs_q <= 1'b1; k <= '0; sh <= '0; end
    else begin
      sclk_q <= sclk; cs_q <= cs_n;
      if (!cs_n && cs_q) begin
        for (int l = 0; l < LANES; l++) sh[l*BITS +: BITS] <= BITS'(32'd37 * 32'(l + 1) * k + 32'd1000 * 32'(l) + 32'(OFFSET));
        k <= k + 32'd1;
      end else if (!sclk && sclk_q) begin
        for (int l = 0; l < LANES; l++) sh[l*BITS +: BITS] <= sh[l*BITS +: BITS] << 1;
      end
    end
  end
  always_comb for (int l = 0; l < LANES; l++) miso[l] = sh[l*BITS + BITS - 1];
endmodule
