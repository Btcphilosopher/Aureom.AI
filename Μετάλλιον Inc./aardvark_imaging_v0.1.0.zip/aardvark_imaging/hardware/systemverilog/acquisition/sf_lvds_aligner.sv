// Fabric word aligner for source-synchronous LVDS ADCs.
// The vendor deserialiser (ISERDES) delivers W-bit words with an arbitrary
// bit offset. This block selects the W-bit window of two consecutive raw
// words ({prev, cur}, MSB = earliest bit) whose frame-clock lane equals
// FRAME_PATTERN, and applies the same offset to every data lane. No vendor
// BITSLIP primitive is required. Output latency: one word.
module sf_lvds_aligner #(
  parameter int           W             = 14,
  parameter int           LANES         = 8,
  parameter logic [W-1:0] FRAME_PATTERN = 14'h3F80,
  parameter int           MATCH_N       = 8,
  parameter int           LOSS_N        = 4
) (
  input  logic                clk,
  input  logic                rst_n,
  input  logic                in_valid,
  input  logic [W-1:0]        in_frame,
  input  logic [LANES*W-1:0]  in_data,
  output logic                out_valid,
  output logic [LANES*W-1:0]  out_data,
  output logic                aligned,
  output logic [$clog2(W)-1:0] slip,
  output logic                realign_evt
);
  localparam int SW = $clog2(W);
  logic [W-1:0]       prev_frame;
  logic [LANES*W-1:0] prev_data;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [2*W-1:0]     comb_f, sh_f;  // only the upper W bits of the shifted window are used
  /* verilator lint_on UNUSEDSIGNAL */
  logic [W-1:0]       win_f;
  logic [7:0]         good, bad;

  assign comb_f = {prev_frame, in_frame};
  assign sh_f   = comb_f << slip;
  assign win_f  = sh_f[2*W-1 -: W];

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      prev_frame <= '0; prev_data <= '0; slip <= '0; aligned <= 1'b0; good <= '0; bad <= '0;
      out_valid <= 1'b0; out_data <= '0; realign_evt <= 1'b0;
    end else begin
      out_valid <= 1'b0;
      realign_evt <= 1'b0;
      if (in_valid) begin
        prev_frame <= in_frame;
        prev_data  <= in_data;
        for (int l = 0; l < LANES; l++) begin
          /* verilator lint_off UNUSEDSIGNAL */
          logic [2*W-1:0] cd;
          /* verilator lint_on UNUSEDSIGNAL */
          cd = {prev_data[l*W +: W], in_data[l*W +: W]} << slip;
          out_data[l*W +: W] <= cd[2*W-1 -: W];
        end
        // A word is only forwarded when its own frame-lane window matches, so a
        // bit slip never produces corrupted samples while loss is being confirmed.
        out_valid <= aligned && (win_f == FRAME_PATTERN);
        if (!aligned) begin
          if (win_f == FRAME_PATTERN) begin
            if (good == 8'(MATCH_N - 1)) begin aligned <= 1'b1; good <= '0; end
            else good <= good + 8'd1;
          end else begin
            good <= '0;
            slip <= (slip == SW'(W - 1)) ? '0 : slip + 1'b1;
          end
        end else begin
          if (win_f != FRAME_PATTERN) begin
            if (bad == 8'(LOSS_N - 1)) begin aligned <= 1'b0; bad <= '0; realign_evt <= 1'b1; end
            else bad <= bad + 8'd1;
          end else bad <= '0;
        end
      end
    end
  end
endmodule
