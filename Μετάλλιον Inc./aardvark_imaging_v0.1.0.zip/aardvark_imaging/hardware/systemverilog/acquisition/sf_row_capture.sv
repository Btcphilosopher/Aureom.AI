// Imager row capture: pixel-clock-domain ingest -> dual-clock FIFO ->
// clk_sys calibration -> 2-pixel/word packing -> packetiser source port.
//
// FIFO entry (20 bits): [19] eol, [18] sof, [17] truncated (pixels of this
// row were dropped in the pixel domain), [16] marker (synthetic EOL inserted
// after an overflow; carries no detector data), [15:0] raw pixel.
//
// Packet descriptor produced with the last word of each row:
//   frame = frame counter (incremented on SOF), row = row index in frame,
//   ts    = exposure-start timestamp popped from the context FIFO at SOF
//           (falls back to arrival time, meta[31]=0, when no context exists),
//   meta  = {ts_from_trigger[31], 7'b0, band[23:16], pixel_count[15:0]},
//   flags = SATURATED | BAD_PIXEL | OVERRUN_PRECEDED | CALIBRATED | TRUNCATED.
module sf_row_capture #(
  parameter int FIFO_AW = 11,
  parameter int CAL_AW  = 10
) (
  // pixel domain
  input  logic              pclk,
  input  logic              prst_n,
  input  logic              px_valid,
  input  logic [15:0]       px_data,
  input  logic              px_sof,
  input  logic              px_eol,
  // system domain
  input  logic              clk,
  input  logic              rst_n,
  input  logic              enable,
  input  logic              cal_en,
  input  logic [15:0]       sat_level,
  input  logic [15:0]       cfg_pixels,
  input  logic [15:0]       cfg_rows,
  input  logic              cal_we,
  input  logic [CAL_AW-1:0] cal_waddr,
  input  logic [32:0]       cal_wdata,
  input  logic              ctx_push,
  input  logic [63:0]       ctx_ts,
  input  logic [7:0]        ctx_band,
  input  logic [63:0]       ts_now,
  output logic              src_valid,
  input  logic              src_ready,
  output logic [31:0]       src_data,
  output logic              src_last,
  output logic [7:0]        src_flags,
  output logic [31:0]       src_frame,
  output logic [15:0]       src_row,
  output logic [31:0]       src_meta,
  output logic [63:0]       src_ts,
  output logic [15:0]       fifo_level,
  output logic              frame_done,
  output logic              length_err_evt,
  output logic              overrun_evt
);
  localparam logic [15:0] PIX_BAD = 16'hFFFE;

  // ------------------------------------------------------------ pixel domain
  logic        wfull, w_ovf_unused, fifo_wr;
  logic [19:0] fifo_wdata;
  logic [FIFO_AW:0] wlevel_unused;
  logic        dropping, eol_pending, p_ovr_pulse, p_en;

  sf_cdc_bit u_en_p (.clk(pclk), .rst_n(prst_n), .d(enable), .q(p_en));

  always_comb begin
    fifo_wr = 1'b0;
    fifo_wdata = '0;
    if (eol_pending && !wfull) begin
      fifo_wr = 1'b1;
      fifo_wdata = {1'b1, 1'b0, 1'b1, 1'b1, PIX_BAD};
    end else if (px_valid && p_en && !eol_pending && !dropping && !wfull) begin
      fifo_wr = 1'b1;
      fifo_wdata = {px_eol, px_sof, 1'b0, 1'b0, px_data};
    end
  end

  always_ff @(posedge pclk) begin
    if (!prst_n) begin
      dropping <= 1'b0; eol_pending <= 1'b0; p_ovr_pulse <= 1'b0;
    end else begin
      p_ovr_pulse <= 1'b0;
      if (eol_pending && !wfull) eol_pending <= 1'b0;
      if (px_valid && p_en) begin
        if (eol_pending || dropping || wfull) begin
          // pixel lost
          if (!dropping) p_ovr_pulse <= 1'b1;
          dropping <= 1'b1;
          if (px_eol) begin
            dropping <= 1'b0;
            eol_pending <= 1'b1;
          end
        end
      end
    end
  end

  logic        rd_en, rd_valid;
  logic [19:0] rd_data;
  logic [FIFO_AW:0] rlevel;
  sf_async_fifo #(.DW(20), .AW(FIFO_AW)) u_fifo (
    .wclk(pclk), .wrst_n(prst_n), .wr_en(fifo_wr), .wr_data(fifo_wdata), .wfull(wfull),
    .overflow(w_ovf_unused), .wlevel(wlevel_unused),
    .rclk(clk), .rrst_n(rst_n), .rd_en(rd_en), .rd_data(rd_data), .rd_valid(rd_valid), .rlevel(rlevel)
  );
  assign fifo_level = 16'(rlevel);

  logic ovr_sys, ovr_busy_unused;
  sf_cdc_pulse u_ovr (.src_clk(pclk), .src_rst_n(prst_n), .src_pulse(p_ovr_pulse), .src_busy(ovr_busy_unused),
                      .dst_clk(clk), .dst_rst_n(rst_n), .dst_pulse(ovr_sys));
  assign overrun_evt = ovr_sys;

  // ------------------------------------------------------------ context FIFO
  logic        ctx_valid, ctx_pop, ctx_full_unused, ctx_ovf_unused;
  logic [71:0] ctx_q;
  logic [2:0]  ctx_level_unused;
  sf_sync_fifo #(.DW(72), .AW(1)) u_ctx (
    .clk(clk), .rst_n(rst_n), .wr_en(ctx_push), .wr_data({ctx_band, ctx_ts}), .full(ctx_full_unused),
    .overflow(ctx_ovf_unused), .rd_en(ctx_pop), .rd_data(ctx_q), .rd_valid(ctx_valid), .level(ctx_level_unused)
  );

  // ------------------------------------------------------------ calibration
  logic        eng_stall, eng_in_valid, inject_now;
  logic [19:0] pidx, pidx_next;
  logic        oob;
  logic        e_valid, e_sat, e_bad, e_clip, e_cal;
  logic [15:0] e_pix;
  logic [3:0]  e_tag;

  assign eng_in_valid = rd_valid;
  assign rd_en = rd_valid && !eng_stall;
  assign pidx = rd_data[18] ? 20'd0 : pidx_next;
  assign oob = (pidx >= 20'(1 << CAL_AW));

  always_ff @(posedge clk) begin
    if (!rst_n) pidx_next <= '0;
    else if (rd_en) pidx_next <= pidx + 20'd1;
  end

  sf_calibration_engine #(.CAL_AW(CAL_AW), .TAG_W(4)) u_cal (
    .clk(clk), .rst_n(rst_n), .stall(eng_stall),
    .in_valid(eng_in_valid && !eng_stall), .in_raw(rd_data[15:0]), .in_index(pidx[CAL_AW-1:0]), .in_oob(oob),
    .in_tag(rd_data[19:16]), .cal_en(cal_en), .sat_level(sat_level),
    .cal_we(cal_we), .cal_waddr(cal_waddr), .cal_wdata(cal_wdata),
    .out_valid(e_valid), .out_pix(e_pix), .out_tag(e_tag), .out_sat(e_sat), .out_bad(e_bad), .out_clip(e_clip), .out_cal(e_cal)
  );

  // ------------------------------------------------------------ packer
  logic        e_eol, e_sof, e_trunc, e_marker;
  assign {e_eol, e_sof, e_trunc, e_marker} = e_tag;

  logic        out_busy;
  logic        row_open, half;
  logic [15:0] lo_pix, row_idx, row_pix;
  logic [31:0] frame_cnt, frame_cur;
  logic        r_sat, r_bad, r_trunc, r_cal_ok, ovr_sticky;
  logic [63:0] frame_ts;
  logic [7:0]  frame_band;
  logic        frame_ts_valid;
  logic [15:0] pv;

  assign out_busy   = src_valid && !src_ready;
  assign inject_now = e_valid && e_sof && row_open && !out_busy;
  assign eng_stall  = out_busy || inject_now;
  assign pv = e_marker ? PIX_BAD : e_pix;
  assign ctx_pop = e_valid && e_sof && !eng_stall && ctx_valid;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      src_valid <= 1'b0; src_data <= '0; src_last <= 1'b0; src_flags <= '0; src_frame <= '0; src_row <= '0;
      src_meta <= '0; src_ts <= '0;
      row_open <= 1'b0; half <= 1'b0; lo_pix <= '0; row_idx <= '0; row_pix <= '0; frame_cnt <= '0; frame_cur <= '0;
      r_sat <= 1'b0; r_bad <= 1'b0; r_trunc <= 1'b0; r_cal_ok <= 1'b1; ovr_sticky <= 1'b0;
      frame_ts <= '0; frame_band <= '0; frame_ts_valid <= 1'b0;
      frame_done <= 1'b0; length_err_evt <= 1'b0;
    end else begin
      frame_done <= 1'b0;
      length_err_evt <= 1'b0;
      if (ovr_sys) ovr_sticky <= 1'b1;
      if (src_valid && src_ready) src_valid <= 1'b0;

      if (inject_now) begin
        // SOF arrived while a row was open (missing EOL): terminate the row.
        src_valid <= 1'b1;
        src_data  <= half ? {PIX_BAD, lo_pix} : {PIX_BAD, PIX_BAD};
        src_last  <= 1'b1;
        src_flags <= {1'b1, 3'b000, r_cal_ok, ovr_sticky | ovr_sys, r_bad, r_sat};
        src_frame <= frame_cur; src_row <= row_idx;
        src_meta  <= {frame_ts_valid, 7'b0, frame_band, row_pix};
        src_ts    <= frame_ts;
        ovr_sticky <= 1'b0;
        row_open <= 1'b0; half <= 1'b0;
        length_err_evt <= 1'b1;
      end else if (e_valid && !out_busy) begin
        logic        n_sat, n_bad, n_trunc, n_cal;
        logic [15:0] n_pix, n_row;
        n_sat   = (e_sof ? 1'b0 : (row_open ? r_sat : 1'b0)) | (e_sat & ~e_marker);
        n_bad   = (e_sof ? 1'b0 : (row_open ? r_bad : 1'b0)) | (e_bad & ~e_marker);
        n_trunc = (e_sof ? 1'b0 : (row_open ? r_trunc : 1'b0)) | e_trunc | e_marker;
        n_cal   = (e_sof ? 1'b1 : (row_open ? r_cal_ok : 1'b1)) & e_cal;
        n_pix   = (row_open && !e_sof) ? row_pix + 16'd1 : 16'd1;
        n_row   = e_sof ? 16'd0 : row_idx;
        if (e_sof) begin
          frame_cur <= frame_cnt;
          frame_cnt <= frame_cnt + 32'd1;
          if (ctx_valid) begin frame_ts <= ctx_q[63:0]; frame_band <= ctx_q[71:64]; frame_ts_valid <= 1'b1; end
          else begin frame_ts <= ts_now; frame_band <= 8'd0; frame_ts_valid <= 1'b0; end
          row_idx <= 16'd0;
        end
        r_sat <= n_sat; r_bad <= n_bad; r_trunc <= n_trunc; r_cal_ok <= n_cal; row_pix <= n_pix;
        row_open <= 1'b1;
        if (!half) begin
          lo_pix <= pv;
          half <= 1'b1;
        end else begin
          half <= 1'b0;
          src_valid <= 1'b1;
          src_data <= {pv, lo_pix};
          src_last <= e_eol;
        end
        if (e_eol) begin
          logic len_bad;
          len_bad = (n_pix != cfg_pixels);
          if (!half) begin
            src_valid <= 1'b1;
            src_data <= {PIX_BAD, pv};
            src_last <= 1'b1;
          end
          src_flags <= {n_trunc | len_bad, 3'b000, n_cal, ovr_sticky | ovr_sys, n_bad, n_sat};
          src_frame <= e_sof ? frame_cnt : frame_cur;
          src_row   <= n_row;
          src_meta  <= e_sof ? {ctx_valid, 7'b0, (ctx_valid ? ctx_q[71:64] : 8'd0), n_pix}
                             : {frame_ts_valid, 7'b0, frame_band, n_pix};
          src_ts    <= e_sof ? (ctx_valid ? ctx_q[63:0] : ts_now) : frame_ts;
          ovr_sticky <= 1'b0;
          row_open <= 1'b0;
          half <= 1'b0;
          row_idx <= n_row + 16'd1;
          if (len_bad) length_err_evt <= 1'b1;
          if (n_row == cfg_rows - 16'd1) frame_done <= 1'b1;
        end
      end
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_rc;
  assign unused_rc = ^{w_ovf_unused, wlevel_unused, ovr_busy_unused, ctx_full_unused, ctx_ovf_unused, ctx_level_unused, e_clip};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
