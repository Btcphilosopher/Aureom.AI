// AXI4-Stream video ingest (Xilinx/AMD video convention: tuser[0] = start of
// frame, tlast = end of line), one pixel per beat. This is the boundary to a
// vendor MIPI CSI-2 RX subsystem: D-PHY and CSI-2 packet decoding are vendor
// hard/soft IP and are NOT implemented here. tready is held high (the CSI-2
// receiver has no meaningful backpressure); overflow is handled downstream.
module sf_axis_video_ingest (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        s_axis_tvalid,
  output logic        s_axis_tready,
  input  logic [15:0] s_axis_tdata,
  input  logic        s_axis_tuser,
  input  logic        s_axis_tlast,
  output logic        px_valid,
  output logic [15:0] px_data,
  output logic        px_sof,
  output logic        px_eol
);
  assign s_axis_tready = rst_n;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      px_valid <= 1'b0; px_data <= '0; px_sof <= 1'b0; px_eol <= 1'b0;
    end else begin
      px_valid <= s_axis_tvalid;
      px_data  <= s_axis_tdata;
      px_sof   <= s_axis_tvalid & s_axis_tuser;
      px_eol   <= s_axis_tvalid & s_axis_tlast;
    end
  end
endmodule
