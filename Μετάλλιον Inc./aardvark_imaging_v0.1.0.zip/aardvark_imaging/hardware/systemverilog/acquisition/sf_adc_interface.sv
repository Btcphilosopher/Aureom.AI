// SAR ADC acquisition interface (CNV-initiated conversion, SPI read-back).
// One `start` pulse = one conversion on all LANES simultaneously:
//   1. latch channel to the analog multiplexer, wait MUX_SETTLE cycles
//   2. CNV high for CNV_CYCLES (conversion time), then low
//   3. SPI mode-0 read of BITS bits per lane (MSB first)
//   4. sample_valid pulse with sample_data / sample_ch
// A start while busy is rejected and reported on `start_overrun`.
module sf_adc_interface #(
  parameter int BITS       = 16,
  parameter int LANES      = 1,
  parameter int CLKDIV     = 2,
  parameter int CNV_CYCLES = 70,
  parameter int MUX_W      = 2,
  parameter int MUX_SETTLE = 4
) (
  input  logic                  clk,
  input  logic                  rst_n,
  input  logic                  start,
  input  logic [MUX_W-1:0]      ch,
  output logic                  busy,
  output logic                  start_overrun,
  output logic                  sample_valid,
  output logic [LANES*BITS-1:0] sample_data,
  output logic [MUX_W-1:0]      sample_ch,
  output logic [MUX_W-1:0]      mux_sel,
  output logic                  adc_cnv,
  output logic                  adc_sclk,
  output logic                  adc_cs_n,
  input  logic [LANES-1:0]      adc_miso
);
  localparam int TW = $clog2((CNV_CYCLES > MUX_SETTLE ? CNV_CYCLES : MUX_SETTLE) + 2);
  typedef enum logic [1:0] {A_IDLE, A_SETTLE, A_CONV, A_READ} st_t;
  st_t st;
  logic [TW-1:0] t;
  logic spi_start, spi_busy, spi_done, spi_mosi_unused;
  logic [LANES*BITS-1:0] spi_rx;

  sf_spi_master #(.BITS(BITS), .LANES(LANES), .CLKDIV(CLKDIV), .CPOL(1'b0), .CPHA(1'b0)) u_spi (
    .clk(clk), .rst_n(rst_n), .start(spi_start), .tx_data('0), .busy(spi_busy), .done(spi_done),
    .rx_data(spi_rx), .sclk(adc_sclk), .cs_n(adc_cs_n), .mosi(spi_mosi_unused), .miso(adc_miso)
  );

  assign busy = (st != A_IDLE);
  assign start_overrun = start && busy;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= A_IDLE; t <= '0; adc_cnv <= 1'b0; spi_start <= 1'b0;
      sample_valid <= 1'b0; sample_data <= '0; sample_ch <= '0; mux_sel <= '0;
    end else begin
      spi_start <= 1'b0;
      sample_valid <= 1'b0;
      case (st)
        A_IDLE: if (start) begin mux_sel <= ch; t <= '0; st <= A_SETTLE; end
        A_SETTLE: begin
          if (t == TW'(MUX_SETTLE)) begin t <= '0; adc_cnv <= 1'b1; st <= A_CONV; end
          else t <= t + 1'b1;
        end
        A_CONV: begin
          if (t == TW'(CNV_CYCLES - 1)) begin adc_cnv <= 1'b0; spi_start <= 1'b1; st <= A_READ; end
          else t <= t + 1'b1;
        end
        A_READ: begin
          if (spi_done) begin
            sample_valid <= 1'b1; sample_data <= spi_rx; sample_ch <= mux_sel; st <= A_IDLE;
          end
        end
        default: st <= A_IDLE;
      endcase
    end
  end
  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_spi;
  assign unused_spi = spi_busy ^ spi_mosi_unused;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
