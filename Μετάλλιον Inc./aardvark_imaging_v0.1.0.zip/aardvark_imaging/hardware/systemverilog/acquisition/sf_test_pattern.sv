// Deterministic detector test-pattern source (pixel clock domain).
// On `start`, emits one frame of `rows` x `pixels` on the normalised pixel
// stream with HBLANK idle cycles between rows. Pixel value:
//   p = (31*frame + 7*row + 3*col) mod 4096, except pixel (0,0) = 0x0FFF
// (a deliberately saturated 12-bit code). The host regenerates the same
// pattern to verify the full acquisition/calibration/DMA path bit-exactly.
// Packets produced while the test pattern is active carry the SIMULATED flag.
module sf_test_pattern #(
  parameter int HBLANK = 4
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        start,
  input  logic [15:0] pixels,
  input  logic [15:0] rows,
  output logic        busy,
  output logic        px_valid,
  output logic [15:0] px_data,
  output logic        px_sof,
  output logic        px_eol
);
  logic [15:0] col, row, frame;
  logic [7:0]  blank;
  logic        active;
  logic [15:0] val;

  assign busy = active;
  assign val = 16'((frame * 16'd31 + row * 16'd7 + col * 16'd3) & 16'h0FFF);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      col <= '0; row <= '0; frame <= '0; blank <= '0; active <= 1'b0;
      px_valid <= 1'b0; px_data <= '0; px_sof <= 1'b0; px_eol <= 1'b0;
    end else begin
      px_valid <= 1'b0; px_sof <= 1'b0; px_eol <= 1'b0;
      if (!active) begin
        if (start && pixels != 0 && rows != 0) begin active <= 1'b1; col <= '0; row <= '0; blank <= '0; end
      end else if (blank != 0) begin
        blank <= blank - 8'd1;
      end else begin
        px_valid <= 1'b1;
        px_data  <= (row == 0 && col == 0) ? 16'h0FFF : val;
        px_sof   <= (row == 0 && col == 0);
        px_eol   <= (col == pixels - 16'd1);
        if (col == pixels - 16'd1) begin
          col <= '0;
          blank <= 8'(HBLANK);
          if (row == rows - 16'd1) begin row <= '0; active <= 1'b0; frame <= frame + 16'd1; end
          else row <= row + 16'd1;
        end else col <= col + 16'd1;
      end
    end
  end
endmodule
