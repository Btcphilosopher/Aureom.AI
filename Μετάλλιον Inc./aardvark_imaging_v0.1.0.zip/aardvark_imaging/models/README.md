# Models

**No trained, laboratory-validated model ships with this repository**, because no laboratory or field data exists yet. Each subdirectory documents the model, its acceptance gate, and what training data it needs. The software refuses to apply a model that has not passed its gate.

| Directory | Model | Code | Acceptance gate | Training data needed |
|---|---|---|---|---|
| `carbon_classification/` | evidence weights (log-likelihood ratios) for 7 carbon-related classes | `carbon/engine.py` (`WEIGHTS`, `CONTEXT_WEIGHTS`, `CONTEXT_PRIOR`) | currently **expert priors**; re-estimate by logistic regression on labelled lab samples; ECE ≤ 0.1 on held-out groups | ≥ 20 physical samples per class with Raman/IR/fluorescence + lab identification |
| `carbon_classification/` (quantitative) | PLS TOC/TIC/carbonate model | `carbon/calibration_model.py` | ≥ 20 independent samples, grouped-CV R² ≥ 0.7, applicability domain | coulometric/EA TOC/TIC on the same samples |
| `mineral_classification/` | SAM library classifier + phase probabilities | `hyperspectral/classification.py`, `mineralogy/classifier.py` | measured library replacing the SIMULATED parametric one; confusion matrix on XRD-verified samples | VNIR/SWIR/Raman spectra of XRD-characterised samples |
| `spectral_unmixing/` | FCLS endmember set | `hyperspectral/analysis.unmix` | endmembers from measured spectra; abundance RMSE vs point counts / XRD | as above |
| `model_validation/` | reports | `analytics/` (regression, classification, ECE) | — | — |

The grade model (`mineralogy/grade.GradeCalibrationModel`) follows the same pattern. It needs at least 25–30 assay-linked nodules and a grouped-CV R² of at least 0.6, and it reports "not reported: …" otherwise. In the simulated surveys, its status depends on the scene: it was refused for seed 21 (CV R² 0.22) and seed 7 (0.58).
