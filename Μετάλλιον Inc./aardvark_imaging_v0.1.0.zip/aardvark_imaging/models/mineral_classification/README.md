# mineral_classification

See ../README.md. No validated model artefact is stored here yet; when one is trained, store the serialised model, its training-set manifest (sample IDs, laboratories, dates), the cross-validation report and the applicability-domain statistics together, with a version and the data origin `lab_validated`.
