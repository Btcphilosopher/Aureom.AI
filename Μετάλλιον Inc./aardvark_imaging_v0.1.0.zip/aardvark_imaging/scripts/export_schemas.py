"""Export JSON Schemas of the platform's record types to data/schemas/.

    python scripts/export_schemas.py
"""
from __future__ import annotations

import json
from pathlib import Path

from aardvark_imaging.calibration.models import CalibrationRecord
from aardvark_imaging.carbon.engine import CarbonCharacterisation
from aardvark_imaging.core.provenance import Estimate, Provenance
from aardvark_imaging.mineralogy.grade import AssayRecord, GradeReport, XrdRecord
from aardvark_imaging.nodules.registry import NoduleObservation, NoduleRecord

OUT = Path(__file__).resolve().parents[1] / "data" / "schemas"
MODELS = {"calibration_record": CalibrationRecord, "carbon_characterisation": CarbonCharacterisation,
          "estimate": Estimate, "provenance": Provenance, "assay_record": AssayRecord, "xrd_record": XrdRecord,
          "grade_report": GradeReport, "nodule_observation": NoduleObservation, "nodule_record": NoduleRecord}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for name, model in MODELS.items():
        schema = model.model_json_schema()
        schema["$id"] = f"https://metallion.example/aardvark/schemas/{name}.schema.json"
        (OUT / f"{name}.schema.json").write_text(json.dumps(schema, indent=2, ensure_ascii=False) + "\n")
        print(OUT / f"{name}.schema.json")


if __name__ == "__main__":
    main()
