"""Ray tracing through a layered sound-velocity profile.

Within each layer the speed varies linearly with depth, so rays are circular
arcs; Snell's invariant p = sin(theta)/c holds across layers (theta from
vertical). Used to convert multibeam beam angles and two-way travel times
into depth and across-track distance.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class SoundVelocityProfile:
    depth_m: np.ndarray
    speed_mps: np.ndarray

    def __post_init__(self):
        self.depth_m = np.asarray(self.depth_m, dtype=float)
        self.speed_mps = np.asarray(self.speed_mps, dtype=float)
        if np.any(np.diff(self.depth_m) <= 0):
            raise ValueError("SVP depths must increase")

    def at(self, z):
        return np.interp(z, self.depth_m, self.speed_mps)


def trace_ray(svp: SoundVelocityProfile, z0: float, theta0_rad: float, one_way_time_s: float,
              dz: float = 0.5) -> tuple[float, float]:
    """Follow a downward ray from depth z0 at angle theta0 (from vertical) for
    ``one_way_time_s``; returns (depth, horizontal distance). Integrates over
    thin layers (``dz``) using the exact constant-gradient arc formulas."""
    c0 = svp.at(z0)
    p = np.sin(theta0_rad) / c0
    t_left = one_way_time_s
    z, x = z0, 0.0
    while t_left > 0:
        z1 = z + dz
        ca, cb = svp.at(z), svp.at(z1)
        sa, sb = p * ca, p * cb
        if sb >= 1.0:          # turning point: treat as horizontal in this layer
            raise ValueError("ray turns before reaching the requested travel time")
        cos_a, cos_b = np.sqrt(1 - sa ** 2), np.sqrt(1 - sb ** 2)
        g = (cb - ca) / dz
        if abs(g) < 1e-9:
            dt = dz / (ca * cos_a)
            dx = dz * sa / cos_a
        else:
            dt = (1 / g) * np.log((cb / ca) * (1 + cos_a) / (1 + cos_b))
            dx = (cos_a - cos_b) / (p * g) if p > 0 else 0.0
        if dt >= t_left:
            frac = t_left / dt
            return z + frac * dz, x + frac * dx
        t_left -= dt
        z, x = z1, x + dx
    return z, x


def beam_to_seabed(svp, z_transducer, angles_rad, twtt_s, **kw):
    """Depth and across-track offset for each beam (two-way travel times)."""
    out = np.array([trace_ray(svp, z_transducer, abs(a), t / 2.0, **kw) for a, t in zip(angles_rad, twtt_s)])
    depth = out[:, 0]
    across = out[:, 1] * np.sign(angles_rad)
    return depth, across
