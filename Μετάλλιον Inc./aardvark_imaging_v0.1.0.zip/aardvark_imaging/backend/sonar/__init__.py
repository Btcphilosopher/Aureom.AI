"""Acoustic sensing: sound speed/absorption, ray tracing, multibeam, imaging array, sub-bottom."""
