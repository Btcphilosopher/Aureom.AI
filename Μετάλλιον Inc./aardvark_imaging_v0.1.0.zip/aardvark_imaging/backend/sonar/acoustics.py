"""Seawater acoustics: sound speed, absorption, transmission loss."""
from __future__ import annotations

import numpy as np


def sound_speed_mackenzie(T, S, D):
    """Mackenzie (1981) nine-term equation; T in C (2-30), S in psu (25-40),
    D depth in m (0-8000). Check value: c(25, 35, 1000) = 1550.744 m/s."""
    T = np.asarray(T, dtype=float)
    S = np.asarray(S, dtype=float)
    D = np.asarray(D, dtype=float)
    return (1448.96 + 4.591 * T - 5.304e-2 * T ** 2 + 2.374e-4 * T ** 3 + 1.340 * (S - 35) + 1.630e-2 * D
            + 1.675e-7 * D ** 2 - 1.025e-2 * T * (S - 35) - 7.139e-13 * T * D ** 3)


def absorption_db_per_km(f_khz, T: float = 2.0, S: float = 35.0, z_km: float = 0.0, pH: float = 8.0):
    """Ainslie & McColm (1998) simplified seawater absorption (dB/km):
    boric acid + magnesium sulfate relaxations + pure water viscosity."""
    f = np.asarray(f_khz, dtype=float)
    f1 = 0.78 * np.sqrt(S / 35.0) * np.exp(T / 26.0)
    f2 = 42.0 * np.exp(T / 17.0)
    boric = 0.106 * f1 * f ** 2 / (f1 ** 2 + f ** 2) * np.exp((pH - 8.0) / 0.56)
    mgso4 = 0.52 * (1 + T / 43.0) * (S / 35.0) * f2 * f ** 2 / (f2 ** 2 + f ** 2) * np.exp(-z_km / 6.0)
    water = 0.00049 * f ** 2 * np.exp(-(T / 27.0 + z_km / 17.0))
    return boric + mgso4 + water


def transmission_loss_db(range_m, f_khz, **kw):
    """One-way spherical spreading + absorption."""
    r = np.maximum(np.asarray(range_m, dtype=float), 1e-3)
    return 20 * np.log10(r) + absorption_db_per_km(f_khz, **kw) * r / 1000.0


def reflection_coefficient(rho1, c1, rho2, c2):
    """Normal-incidence pressure reflection coefficient between media."""
    z1, z2 = rho1 * c1, rho2 * c2
    return (z2 - z1) / (z2 + z1)
