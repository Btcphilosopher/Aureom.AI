"""Chirp sub-bottom profiling: sediment penetration and layer picking.

Acoustic waves, unlike EM waves, penetrate water-saturated sediment; this is
the subsurface imaging path for the seabed (metres to tens of metres at
2-16 kHz)."""
from __future__ import annotations

import numpy as np
from scipy.signal import find_peaks

from .acoustics import reflection_coefficient


def sediment_attenuation_db_per_m(f_khz, k_db_m_khz: float = 0.2):
    """Hamilton's linear law alpha = k f (k ~ 0.05-0.5 dB/m/kHz for clays-sands)."""
    return k_db_m_khz * np.asarray(f_khz, dtype=float)


def penetration_depth_m(f_khz, *, available_db: float, k_db_m_khz: float = 0.2) -> np.ndarray:
    """Depth at which two-way sediment loss consumes the available dynamic range."""
    return available_db / (2 * sediment_attenuation_db_per_m(f_khz, k_db_m_khz))


def synthetic_trace(layers, *, fs: float, duration_s: float, f_khz: float, c_water: float = 1500.0,
                    rho_water: float = 1025.0, water_depth_m: float = 10.0, k_db_m_khz: float = 0.2,
                    replica=None) -> np.ndarray:
    """Normal-incidence reflectivity series for (thickness_m, c, rho) layers."""
    n = int(duration_s * fs)
    trace = np.zeros(n)
    t = 2 * water_depth_m / c_water
    c_prev, rho_prev = c_water, rho_water
    loss_db, trans = 0.0, 1.0
    for thick, c, rho in layers:
        R = reflection_coefficient(rho_prev, c_prev, rho, c)
        i = int(t * fs)
        if i < n:
            trace[i] += trans * R * 10 ** (-loss_db / 20)
        trans *= (1 - R ** 2)
        loss_db += 2 * sediment_attenuation_db_per_m(f_khz, k_db_m_khz) * thick
        t += 2 * thick / c
        c_prev, rho_prev = c, rho
    if replica is not None:
        trace = np.convolve(trace, replica, mode="same")
    return trace


def pick_layers(envelope, fs: float, c_sediment: float, *, rel_threshold: float = 0.05, min_sep_s: float = 1e-4):
    e = np.asarray(envelope, dtype=float)
    idx, _ = find_peaks(e, height=rel_threshold * e.max(), distance=max(1, int(min_sep_s * fs)))
    t = idx / fs
    if t.size == 0:
        return np.array([]), np.array([])
    depth_below_seabed = (t - t[0]) * c_sediment / 2
    return t, depth_below_seabed
