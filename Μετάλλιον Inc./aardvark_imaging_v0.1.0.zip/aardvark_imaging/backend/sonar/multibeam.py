"""Multibeam bathymetry and backscatter processing."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import xarray as xr

from .acoustics import transmission_loss_db
from .raytrace import SoundVelocityProfile, beam_to_seabed


@dataclass
class Ping:
    time_s: float
    east_m: float
    north_m: float
    depth_m: float               # transducer depth
    heading_rad: float
    angles_rad: np.ndarray       # beam angles (+ starboard)
    twtt_s: np.ndarray
    level_db: np.ndarray         # received echo level (dB re arbitrary)


def georeference(pings: list[Ping], svp: SoundVelocityProfile):
    """Soundings (east, north, depth, beam angle, slant range)."""
    rows = []
    for p in pings:
        z, ac = beam_to_seabed(svp, p.depth_m, p.angles_rad, p.twtt_s)
        e = p.east_m + ac * np.cos(p.heading_rad)
        n = p.north_m - ac * np.sin(p.heading_rad)
        R = np.hypot(z - p.depth_m, ac)
        rows.append(np.column_stack([e, n, z, p.angles_rad, R]))
    return np.vstack(rows)


def grid_soundings(soundings: np.ndarray, *, resolution_m: float, bounds=None, stat: str = "median") -> xr.Dataset:
    """Bin soundings into a DEM with per-cell count and standard deviation."""
    e, n, z = soundings[:, 0], soundings[:, 1], soundings[:, 2]
    if bounds is None:
        bounds = (e.min(), e.max(), n.min(), n.max())
    x0, x1, y0, y1 = bounds
    nx = int(np.ceil((x1 - x0) / resolution_m)) + 1
    ny = int(np.ceil((y1 - y0) / resolution_m)) + 1
    ix = np.clip(((e - x0) / resolution_m).astype(int), 0, nx - 1)
    iy = np.clip(((n - y0) / resolution_m).astype(int), 0, ny - 1)
    flat = iy * nx + ix
    order = np.argsort(flat)
    flat_s, z_s = flat[order], z[order]
    cells, start, counts = np.unique(flat_s, return_index=True, return_counts=True)
    dem = np.full(ny * nx, np.nan)
    sd = np.full(ny * nx, np.nan)
    cnt = np.zeros(ny * nx, dtype=int)
    for c, s, k in zip(cells, start, counts):
        v = z_s[s:s + k]
        dem[c] = np.median(v) if stat == "median" else v.mean()
        sd[c] = v.std(ddof=1) if k > 1 else np.nan
        cnt[c] = k
    coords = {"north": y0 + resolution_m * np.arange(ny), "east": x0 + resolution_m * np.arange(nx)}
    return xr.Dataset({"depth": (("north", "east"), dem.reshape(ny, nx)),
                       "depth_std": (("north", "east"), sd.reshape(ny, nx)),
                       "count": (("north", "east"), cnt.reshape(ny, nx))}, coords=coords,
                      attrs={"resolution_m": resolution_m, "statistic": stat})


def backscatter_strength(level_db, slant_range_m, incidence_rad, *, f_khz: float, source_level_db: float,
                         beamwidth_along_rad: float, beamwidth_across_rad: float, pulse_s: float, c: float = 1500.0,
                         **absorption_kw) -> np.ndarray:
    """Seabed backscatter strength BS = EL - SL + 2 TL - 10 log10(A).

    Insonified area A is the smaller of the beam-limited footprint
    (R^2 * bw_along * bw_across / cos(theta)) and the pulse-limited footprint
    (R * bw_along * c * tau / (2 sin theta)).
    """
    R = np.asarray(slant_range_m, dtype=float)
    th = np.clip(np.abs(np.asarray(incidence_rad, dtype=float)), 1e-3, np.pi / 2 - 1e-3)
    tl = transmission_loss_db(R, f_khz, **absorption_kw)
    A_beam = R ** 2 * beamwidth_along_rad * beamwidth_across_rad / np.cos(th)
    A_pulse = R * beamwidth_along_rad * c * pulse_s / (2 * np.sin(th))
    A = np.minimum(A_beam, A_pulse)
    return np.asarray(level_db, dtype=float) - source_level_db + 2 * tl - 10 * np.log10(A)


def angular_response_correction(bs_db, incidence_rad, *, bin_deg: float = 2.0, ref_deg: float = 45.0):
    """Normalise BS to a reference angle using the mean angular response."""
    ang = np.degrees(np.abs(np.asarray(incidence_rad, dtype=float)))
    bs = np.asarray(bs_db, dtype=float)
    bins = np.floor(ang / bin_deg).astype(int)
    means = {b: np.nanmean(bs[bins == b]) for b in np.unique(bins)}
    ref = means.get(int(ref_deg // bin_deg), np.nanmean(bs))
    return bs - np.array([means[b] for b in bins]) + ref


def nodule_backscatter_index(bs_corrected_db, background_db: float):
    """Relative backscatter excess over a nodule-free reference area.

    Nodule-covered seabed scatters more strongly at high frequency; turning
    this into abundance (kg/m2) requires a site calibration against optical
    or box-core abundance — see :func:`calibrate_abundance`.
    """
    return np.asarray(bs_corrected_db, dtype=float) - background_db


def calibrate_abundance(bs_excess_db, abundance_kg_m2):
    """Linear calibration abundance ~ a + b * BS_excess with residual std."""
    x = np.asarray(bs_excess_db, dtype=float)
    y = np.asarray(abundance_kg_m2, dtype=float)
    A = np.column_stack([np.ones_like(x), x])
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    resid = y - A @ coef
    return {"intercept": float(coef[0]), "slope": float(coef[1]), "residual_std": float(resid.std(ddof=2)),
            "r2": 1 - float(np.sum(resid ** 2)) / (float(np.sum((y - y.mean()) ** 2)) or 1e-12), "n": int(x.size)}
