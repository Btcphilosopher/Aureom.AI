"""High-frequency acoustic imaging: LFM pulse compression, time of flight
and near-field delay-and-sum beamforming for a linear receive array."""
from __future__ import annotations

import numpy as np
from scipy.signal import hilbert


def lfm_chirp(f0: float, f1: float, duration_s: float, fs: float) -> np.ndarray:
    t = np.arange(int(round(duration_s * fs))) / fs
    k = (f1 - f0) / duration_s
    return np.sin(2 * np.pi * (f0 * t + 0.5 * k * t ** 2)) * np.hanning(t.size)


def matched_filter(signal, replica) -> np.ndarray:
    """Pulse compression; returns the analytic-signal envelope aligned so that
    index i corresponds to an echo starting at sample i."""
    n = signal.shape[-1] + replica.size - 1
    nfft = 1 << int(np.ceil(np.log2(n)))
    S = np.fft.rfft(signal, nfft, axis=-1)
    R = np.fft.rfft(replica, nfft)
    y = np.fft.irfft(S * np.conj(R), nfft, axis=-1)[..., : signal.shape[-1]]
    return np.abs(hilbert(y, axis=-1))


def range_resolution_m(bandwidth_hz: float, c: float = 1500.0) -> float:
    return c / (2 * bandwidth_hz)


def time_of_flight_range(envelope, fs: float, c: float, *, threshold: float = 0.5) -> float:
    """Range of the strongest echo from the compressed envelope (parabolic
    sub-sample peak refinement)."""
    e = np.asarray(envelope, dtype=float)
    i = int(np.argmax(e))
    if 0 < i < e.size - 1:
        den = e[i - 1] - 2 * e[i] + e[i + 1]
        frac = 0.5 * (e[i - 1] - e[i + 1]) / den if den != 0 else 0.0
    else:
        frac = 0.0
    return c * (i + frac) / fs / 2.0


def delay_and_sum(env, element_x_m, fs: float, c: float, grid_x_m, grid_z_m, *, tx_pos=(0.0, 0.0)) -> np.ndarray:
    """Near-field focused image: for each pixel (x, z) sum each element's
    compressed envelope at the two-way delay transmitter -> pixel -> element.
    ``env``: elements x samples (aligned to transmit time)."""
    env = np.asarray(env, dtype=float)
    ex = np.asarray(element_x_m, dtype=float)
    X, Z = np.meshgrid(grid_x_m, grid_z_m)
    d_tx = np.hypot(X - tx_pos[0], Z - tx_pos[1])
    img = np.zeros_like(X)
    ns = env.shape[1]
    for k, x_e in enumerate(ex):
        d_rx = np.hypot(X - x_e, Z)
        idx = (d_tx + d_rx) / c * fs
        i0 = np.clip(idx.astype(int), 0, ns - 2)
        w = idx - i0
        val = (1 - w) * env[k, i0] + w * env[k, i0 + 1]
        val[(idx < 0) | (idx >= ns - 1)] = 0
        img += val
    return img / len(ex)
