"""Instrument diagnostics and health assessment."""
