"""Instrument health assessment from FPGA diagnostics, housekeeping and
calibration status."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class HealthLimits:
    temperature_c_warn: float = 45.0
    temperature_c_fault: float = 60.0
    rail_v_range: tuple[float, float] = (11.4, 12.6)
    max_drop_rate: float = 0.0
    housing_pressure_dbar_max: float = 6500.0


@dataclass
class HealthReport:
    status: str                      # ok | warning | fault
    items: list[dict] = field(default_factory=list)

    def add(self, name: str, level: str, detail: str):
        self.items.append({"name": name, "level": level, "detail": detail})
        order = {"ok": 0, "warning": 1, "fault": 2}
        if order[level] > order[self.status]:
            self.status = level


def hk_to_engineering(codes: dict, *, adc_vref: float = 4.096, bits: int = 16) -> dict:
    """Convert housekeeping ADC codes with the (assumed) front-end transfer
    functions: 10 mV/C sensor with 0.5 V offset, 1:4 rail divider, 0.1 V/A
    current monitor, 0-5 V = 0-10000 dbar housing pressure transducer
    through a 1:1.25 divider. Replace with the calibration record values."""
    v = {k: codes[k] * adc_vref / (1 << bits) for k in codes}
    return {"temperature_c": (v["temperature_code"] - 0.5) / 0.010, "rail_v": v["rail_code"] * 4.0,
            "current_a": v["current_code"] / 0.1, "pressure_dbar": v["pressure_code"] * 1.25 / 5.0 * 10000.0}


def assess(diag: dict | None, hk_eng: dict | None, calibration_summary: dict | None, *, dma_drops: int = 0,
           sequence_gaps: int = 0, limits: HealthLimits = HealthLimits()) -> HealthReport:
    r = HealthReport("ok")
    if diag:
        r.add("host_link", "warning" if diag.get("host_lost") else "ok",
              "host heartbeat lost: FPGA continues recording to ring" if diag.get("host_lost") else "heartbeat present")
        r.add("fpga_errors", "warning" if diag.get("err_total", 0) else "ok", f"{diag.get('err_total', 0)} error events")
        if diag.get("overtemp"):
            r.add("overtemp", "fault", "FPGA over-temperature: laser interlocked")
    if hk_eng:
        t = hk_eng["temperature_c"]
        lvl = "fault" if t >= limits.temperature_c_fault else "warning" if t >= limits.temperature_c_warn else "ok"
        r.add("electronics_temperature", lvl, f"{t:.1f} C")
        lo, hi = limits.rail_v_range
        r.add("rail_voltage", "ok" if lo <= hk_eng["rail_v"] <= hi else "warning", f"{hk_eng['rail_v']:.2f} V")
    if dma_drops > limits.max_drop_rate or sequence_gaps:
        r.add("data_loss", "warning", f"{dma_drops} DMA drops, {sequence_gaps} sequence gaps")
    if calibration_summary:
        for sensor, kinds in calibration_summary.items():
            bad = [k for k, s in kinds.items() if s in ("expired", "missing")]
            sim = [k for k, s in kinds.items() if s == "simulated"]
            if bad:
                r.add(f"calibration_{sensor}", "warning", "expired/missing: " + ", ".join(bad))
            elif sim:
                r.add(f"calibration_{sensor}", "warning", "simulated calibration (not traceable): " + ", ".join(sim))
            else:
                r.add(f"calibration_{sensor}", "ok", "valid")
    return r
