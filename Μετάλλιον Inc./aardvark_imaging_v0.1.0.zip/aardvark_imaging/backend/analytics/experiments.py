"""Reproducible experiment records and model versioning."""
from __future__ import annotations

import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

from .. import __version__


def dataset_hash(*arrays) -> str:
    h = hashlib.sha256()
    for a in arrays:
        a = np.ascontiguousarray(np.asarray(a))
        h.update(str(a.dtype).encode())
        h.update(str(a.shape).encode())
        h.update(a.tobytes())
    return h.hexdigest()[:16]


def config_hash(config: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(config, sort_keys=True, default=str).encode()).hexdigest()[:16]


def record_experiment(directory: str | Path, *, name: str, config: dict, metrics: dict, data_hash: str,
                      seed: int, model_version: str, data_origin: str) -> Path:
    """Write an immutable experiment record (JSON); returns its path."""
    d = Path(directory)
    d.mkdir(parents=True, exist_ok=True)
    rec = {
        "name": name, "created_utc": datetime.now(timezone.utc).isoformat(), "software": __version__,
        "python": platform.python_version(), "numpy": np.__version__, "config": config,
        "config_hash": config_hash(config), "data_hash": data_hash, "seed": seed, "model_version": model_version,
        "data_origin": data_origin, "metrics": metrics,
    }
    path = d / f"{name}_{rec['config_hash']}_{data_hash}.json"
    if path.exists():
        prev = json.loads(path.read_text())
        if prev["metrics"] != json.loads(json.dumps(metrics, default=float)):
            raise RuntimeError(f"{path.name}: same config and data produced different metrics (non-determinism)")
        return path
    path.write_text(json.dumps(rec, indent=2, default=float))
    return path
