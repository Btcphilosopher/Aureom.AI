"""Validation metrics: classification, confidence calibration, regression,
spectral reconstruction and calibration drift."""
from __future__ import annotations

import numpy as np
from scipy import stats


def confusion_matrix(y_true, y_pred, labels) -> np.ndarray:
    idx = {l: i for i, l in enumerate(labels)}
    m = np.zeros((len(labels), len(labels)), dtype=int)
    for t, p in zip(y_true, y_pred):
        m[idx[t], idx[p]] += 1
    return m


def classification_report(y_true, y_pred, labels) -> dict:
    cm = confusion_matrix(y_true, y_pred, labels)
    tp = np.diag(cm).astype(float)
    fp = cm.sum(0) - tp
    fn = cm.sum(1) - tp
    tn = cm.sum() - tp - fp - fn
    prec = np.divide(tp, tp + fp, out=np.full_like(tp, np.nan), where=(tp + fp) > 0)
    rec = np.divide(tp, tp + fn, out=np.full_like(tp, np.nan), where=(tp + fn) > 0)
    f1 = np.divide(2 * prec * rec, prec + rec, out=np.full_like(tp, np.nan), where=(prec + rec) > 0)
    fpr = np.divide(fp, fp + tn, out=np.full_like(tp, np.nan), where=(fp + tn) > 0)
    fnr = np.divide(fn, fn + tp, out=np.full_like(tp, np.nan), where=(fn + tp) > 0)
    per = {l: {"precision": float(prec[i]), "recall": float(rec[i]), "f1": float(f1[i]), "fpr": float(fpr[i]),
               "fnr": float(fnr[i]), "support": int(cm[i].sum())} for i, l in enumerate(labels)}
    return {"accuracy": float(tp.sum() / max(cm.sum(), 1)), "balanced_accuracy": float(np.nanmean(rec)),
            "macro_f1": float(np.nanmean(f1)), "per_class": per, "confusion": cm.tolist(), "labels": list(labels)}


def expected_calibration_error(prob_max, correct, n_bins: int = 10) -> dict:
    """ECE / MCE and reliability-diagram bins for top-class confidence."""
    p = np.asarray(prob_max, dtype=float)
    c = np.asarray(correct, dtype=float)
    edges = np.linspace(0, 1, n_bins + 1)
    ece, mce, bins = 0.0, 0.0, []
    for a, b in zip(edges[:-1], edges[1:]):
        sel = (p > a) & (p <= b) if a > 0 else (p >= a) & (p <= b)
        if sel.sum() == 0:
            bins.append({"lo": a, "hi": b, "n": 0})
            continue
        acc, conf = c[sel].mean(), p[sel].mean()
        gap = abs(acc - conf)
        ece += sel.mean() * gap
        mce = max(mce, gap)
        bins.append({"lo": float(a), "hi": float(b), "n": int(sel.sum()), "accuracy": float(acc), "confidence": float(conf)})
    return {"ece": float(ece), "mce": float(mce), "bins": bins}


def brier_score(probs, y_true_index) -> float:
    P = np.asarray(probs, dtype=float)
    Y = np.zeros_like(P)
    Y[np.arange(P.shape[0]), np.asarray(y_true_index)] = 1.0
    return float(np.mean(np.sum((P - Y) ** 2, axis=1)))


def regression_report(y_true, y_pred) -> dict:
    t = np.asarray(y_true, dtype=float)
    p = np.asarray(y_pred, dtype=float)
    r = p - t
    ss = float(np.sum((t - t.mean()) ** 2)) or 1e-12
    return {"rmse": float(np.sqrt(np.mean(r ** 2))), "bias": float(r.mean()), "mae": float(np.mean(np.abs(r))),
            "r2": 1 - float(np.sum(r ** 2)) / ss, "n": int(t.size)}


def reconstruction_error(X, X_hat) -> dict:
    X = np.asarray(X, dtype=float)
    Y = np.asarray(X_hat, dtype=float)
    rmse = np.sqrt(np.mean((X - Y) ** 2, axis=1))
    cos = np.sum(X * Y, 1) / np.maximum(np.linalg.norm(X, axis=1) * np.linalg.norm(Y, axis=1), 1e-12)
    sam = np.arccos(np.clip(cos, -1, 1))
    return {"rmse_mean": float(rmse.mean()), "rmse_p95": float(np.quantile(rmse, 0.95)),
            "sam_mean_rad": float(sam.mean()), "sam_p95_rad": float(np.quantile(sam, 0.95))}


def calibration_drift(times_days, values) -> dict:
    """Theil-Sen trend with Kendall-tau significance for a calibration
    parameter series (e.g. dark level, responsivity, Raman shift offset)."""
    t = np.asarray(times_days, dtype=float)
    v = np.asarray(values, dtype=float)
    slope, icpt, lo, hi = stats.theilslopes(v, t)
    tau, pval = stats.kendalltau(t, v)
    return {"slope_per_day": float(slope), "slope_ci": (float(lo), float(hi)), "intercept": float(icpt),
            "kendall_tau": float(tau), "p_value": float(pval), "significant": bool(pval < 0.05)}


def bootstrap_ci(fn, *arrays, n: int = 1000, seed: int = 0, alpha: float = 0.05, groups=None):
    """Percentile bootstrap CI of ``fn(*arrays)``; resamples groups if given."""
    rng = np.random.default_rng(seed)
    arrays = [np.asarray(a) for a in arrays]
    m = len(arrays[0])
    vals = []
    if groups is not None:
        g = np.asarray(groups)
        uniq = np.unique(g)
        members = {u: np.nonzero(g == u)[0] for u in uniq}
    for _ in range(n):
        if groups is None:
            idx = rng.integers(0, m, m)
        else:
            idx = np.concatenate([members[u] for u in rng.choice(uniq, len(uniq))])
        vals.append(fn(*[a[idx] for a in arrays]))
    lo, hi = np.quantile(vals, [alpha / 2, 1 - alpha / 2])
    return float(fn(*arrays)), (float(lo), float(hi))
