"""Analytics and scientific validation: metrics, leakage-safe splits, experiment records."""
