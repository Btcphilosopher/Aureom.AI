"""Leakage-safe data splitting.

Measurements of the same physical sample (repeat spectra, adjacent pixels of
one nodule, sub-samples of one core) are never split between training and
evaluation sets.
"""
from __future__ import annotations

import numpy as np


class LeakageError(AssertionError):
    pass


def group_kfold(groups, k: int = 5, seed: int = 0):
    """Yield (train_idx, test_idx) with every group entirely in one fold."""
    g = np.asarray(groups)
    uniq = np.unique(g)
    if len(uniq) < k:
        raise ValueError(f"{len(uniq)} groups cannot form {k} folds")
    rng = np.random.default_rng(seed)
    perm = rng.permutation(uniq)
    folds = np.array_split(perm, k)
    for f in folds:
        te = np.isin(g, f)
        yield np.nonzero(~te)[0], np.nonzero(te)[0]


def grouped_split(groups, fractions=(0.6, 0.2, 0.2), seed: int = 0) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Train/validation/test indices split by group."""
    if abs(sum(fractions) - 1.0) > 1e-9:
        raise ValueError("fractions must sum to 1")
    g = np.asarray(groups)
    uniq = np.random.default_rng(seed).permutation(np.unique(g))
    n = len(uniq)
    a = int(round(fractions[0] * n))
    b = a + int(round(fractions[1] * n))
    sets = [uniq[:a], uniq[a:b], uniq[b:]]
    out = tuple(np.nonzero(np.isin(g, s))[0] for s in sets)
    assert_no_leakage(g, *out)
    return out


def assert_no_leakage(groups, *index_sets) -> None:
    g = np.asarray(groups)
    seen: dict = {}
    for k, idx in enumerate(index_sets):
        for grp in np.unique(g[idx]):
            if grp in seen and seen[grp] != k:
                raise LeakageError(f"group {grp!r} appears in split {seen[grp]} and split {k}")
            seen[grp] = k
