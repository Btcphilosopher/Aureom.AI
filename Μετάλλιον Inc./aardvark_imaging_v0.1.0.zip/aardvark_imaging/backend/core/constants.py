"""Physical constants and reference seawater properties (SI units)."""
import math

C0 = 299_792_458.0                 # speed of light in vacuum, m/s
MU0 = 4e-7 * math.pi               # vacuum permeability, H/m (classical definition; CODATA 2018 differs by ~1e-10)
EPS0 = 8.8541878128e-12            # vacuum permittivity, F/m
H_PLANCK = 6.62607015e-34          # J s
K_BOLTZMANN = 1.380649e-23         # J/K
G0 = 9.80665                       # m/s^2

# Reference deep-ocean conditions for the Clarion-Clipperton Zone (typical
# abyssal plain values; used only as documented defaults).
CCZ_DEPTH_M = 4500.0
CCZ_TEMPERATURE_C = 1.5
CCZ_SALINITY_PSU = 34.7

# Polymetallic nodule physical properties (literature ranges; defaults are
# central values with the uncertainty carried as a standard deviation).
NODULE_WET_BULK_DENSITY_G_CM3 = (1.95, 0.10)
NODULE_DRY_BULK_DENSITY_G_CM3 = (1.35, 0.10)
