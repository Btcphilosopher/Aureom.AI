"""Identifier helpers."""
from __future__ import annotations

import hashlib
import uuid


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"


def content_hash(*parts: object, n: int = 16) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update(repr(p).encode())
        h.update(b"\x1f")
    return h.hexdigest()[:n]


def nodule_id(survey_id: str, east_m: float, north_m: float, cell_m: float = 0.05) -> str:
    """Persistent nodule identifier from survey and georeferenced position.

    Positions are quantised to ``cell_m`` so repeat observations of the same
    nodule (within re-identification tolerance, resolved by the registry)
    produce a stable key. Collisions are resolved by the registry.
    """
    ix = int(round(east_m / cell_m))
    iy = int(round(north_m / cell_m))
    return f"NOD-{survey_id}-{content_hash(survey_id, ix, iy, n=10)}"
