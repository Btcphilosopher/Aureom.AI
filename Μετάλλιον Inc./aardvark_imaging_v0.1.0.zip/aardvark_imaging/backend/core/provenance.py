"""Data origin, quantitation level and provenance records.

Every data product in Aardvark Imaging carries a :class:`Provenance`. The
:class:`DataOrigin` makes the distinction the instrument specification insists
on explicit and machine-checkable:

* ``SIMULATED``      produced by a simulator or an FPGA test pattern
* ``MEASURED``       derived from real detector data with no model inference
* ``ESTIMATED``      model-derived from measurements (classification, unmixing,
                     mass from volume, interpolation, ...)
* ``LAB_VALIDATED``  laboratory analyses (assay, XRD, TOC/TIC) or estimates
                     whose model has passed validation against them

Origins combine conservatively: anything touched by simulation stays
SIMULATED; anything touched by a model is at best ESTIMATED.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Iterable

from pydantic import BaseModel, ConfigDict, Field

from .. import __version__


class DataOrigin(str, Enum):
    SIMULATED = "simulated"
    MEASURED = "measured"
    ESTIMATED = "estimated"
    LAB_VALIDATED = "lab_validated"


_RANK = {DataOrigin.LAB_VALIDATED: 0, DataOrigin.MEASURED: 1, DataOrigin.ESTIMATED: 2, DataOrigin.SIMULATED: 3}


def combine_origins(origins: Iterable[DataOrigin], *, model_applied: bool = False) -> DataOrigin:
    """Conservative origin of a product derived from inputs with ``origins``.

    The weakest input wins (SIMULATED > ESTIMATED > MEASURED > LAB_VALIDATED);
    applying a model to measured data yields ESTIMATED.
    """
    origins = list(origins)
    if not origins:
        raise ValueError("at least one input origin required")
    worst = max(origins, key=lambda o: _RANK[o])
    if model_applied and worst in (DataOrigin.MEASURED, DataOrigin.LAB_VALIDATED):
        return DataOrigin.ESTIMATED
    return worst


class QuantitationLevel(str, Enum):
    """How far a reported quantity may be interpreted numerically."""

    NOT_DETECTED = "not_detected"
    QUALITATIVE = "qualitative"              # presence / class only
    SEMI_QUANTITATIVE = "semi_quantitative"  # relative index, uncalibrated scale
    QUANTITATIVE = "quantitative"            # calibrated against validated lab data


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Provenance(BaseModel):
    model_config = ConfigDict(extra="forbid")
    origin: DataOrigin
    source: str = Field(description="Sensor key, generator or processing step")
    created_utc: datetime = Field(default_factory=utcnow)
    software: str = f"aardvark-imaging {__version__}"
    calibration_ids: list[str] = Field(default_factory=list)
    parents: list[str] = Field(default_factory=list, description="Identifiers of input products")
    parameters: dict[str, Any] = Field(default_factory=dict)
    notes: list[str] = Field(default_factory=list)

    def derive(self, source: str, *, model_applied: bool = True, parents: list[str] | None = None,
               parameters: dict[str, Any] | None = None, calibration_ids: list[str] | None = None,
               notes: list[str] | None = None) -> "Provenance":
        """Provenance for a product derived from this one."""
        return Provenance(
            origin=combine_origins([self.origin], model_applied=model_applied),
            source=source,
            calibration_ids=sorted(set(self.calibration_ids) | set(calibration_ids or [])),
            parents=list(parents or []),
            parameters=dict(parameters or {}),
            notes=list(self.notes) + list(notes or []),
        )

    def to_json(self) -> str:
        return self.model_dump_json()

    @classmethod
    def from_json(cls, s: str) -> "Provenance":
        return cls.model_validate(json.loads(s))


class Estimate(BaseModel):
    """A numeric value with uncertainty, units, interval and origin."""

    model_config = ConfigDict(extra="forbid")
    value: float
    std: float | None = Field(default=None, ge=0)
    units: str = ""
    interval: tuple[float, float] | None = None
    confidence: float = Field(default=0.95, gt=0, lt=1)
    origin: DataOrigin = DataOrigin.ESTIMATED
    method: str = ""

    @classmethod
    def from_samples(cls, samples, *, units: str = "", origin: DataOrigin = DataOrigin.ESTIMATED,
                     method: str = "monte_carlo", confidence: float = 0.95) -> "Estimate":
        import numpy as np

        s = np.asarray(samples, dtype=float)
        s = s[np.isfinite(s)]
        if s.size == 0:
            raise ValueError("no finite samples")
        a = (1 - confidence) / 2
        lo, hi = np.quantile(s, [a, 1 - a])
        return cls(value=float(np.mean(s)), std=float(np.std(s, ddof=1)) if s.size > 1 else 0.0, units=units,
                   interval=(float(lo), float(hi)), confidence=confidence, origin=origin, method=method)
