"""Hyperspectral cube persistence (Zarr / HDF5) with raw retention.

Raw detector codes are written once and are never overwritten; processed
products are written alongside under new names. Provenance is stored as a
JSON attribute on every dataset.
"""
from __future__ import annotations

import json
from pathlib import Path

import h5py
import numpy as np
import xarray as xr

from ..hyperspectral.cube import HyperspectralCube


class RawOverwriteError(FileExistsError):
    pass


def save_zarr(cube: HyperspectralCube, path: str | Path, *, product: str = "processed") -> Path:
    """Write ``raw`` (once) and ``<product>`` groups into a Zarr store."""
    p = Path(path)
    ds = cube.to_dataset()
    raw_group = p / "raw"
    if not raw_group.exists():
        xr.Dataset({"raw": ds["raw"], "saturated": ds["saturated"], "bad": ds["bad"], "missing": ds["missing"]},
                   attrs={"provenance": ds.attrs["provenance"], "data_origin": ds.attrs["data_origin"]}
                   ).to_zarr(p, group="raw", mode="w-")
    prod = p / product
    if prod.exists():
        raise RawOverwriteError(f"product '{product}' already exists in {p}; write a new product name")
    ds.drop_vars(["raw"]).to_zarr(p, group=product, mode="w-")
    return p


def load_zarr(path: str | Path, product: str = "processed") -> HyperspectralCube:
    p = Path(path)
    raw = xr.open_zarr(p, group="raw")
    prod = xr.open_zarr(p, group=product)
    ds = prod.assign(raw=raw["raw"]).load()
    ds.attrs.update(prod.attrs)
    return HyperspectralCube.from_dataset(ds)


def save_hdf5(cube: HyperspectralCube, path: str | Path, *, product: str = "processed", compression: str = "gzip") -> Path:
    p = Path(path)
    with h5py.File(p, "a") as f:
        if "raw" not in f:
            g = f.create_group("raw")
            g.create_dataset("codes", data=cube.raw.values, compression=compression)
            for name in ("saturated", "bad", "missing"):
                g.create_dataset(name, data=getattr(cube, name), compression=compression)
            g.attrs["provenance"] = cube.provenance.to_json()
            g.attrs["data_origin"] = cube.provenance.origin.value
            g.create_dataset("wavelength_nm", data=cube.wavelength_nm)
        if product in f:
            raise RawOverwriteError(f"product '{product}' already exists in {p}")
        g = f.create_group(product)
        g.create_dataset("data", data=cube.data.values.astype(np.float32), compression=compression)
        g.attrs["provenance"] = cube.provenance.to_json()
        g.attrs["units"] = cube.units
        g.attrs["history"] = json.dumps(cube.history)
    return p


def load_hdf5(path: str | Path, product: str = "processed") -> HyperspectralCube:
    from ..core.provenance import Provenance
    with h5py.File(path, "r") as f:
        raw = f["raw/codes"][...]
        wl = f["raw/wavelength_nm"][...]
        g = f[product]
        data = g["data"][...]
        prov = Provenance.from_json(g.attrs["provenance"])
        masks = {n: f[f"raw/{n}"][...] for n in ("saturated", "bad", "missing")}
        units = g.attrs["units"]
        hist = json.loads(g.attrs["history"])
    coords = {"line": np.arange(raw.shape[0]), "sample": np.arange(raw.shape[1]), "band": np.arange(raw.shape[2]),
              "wavelength_nm": ("band", wl)}
    da = xr.DataArray(data, dims=("line", "sample", "band"), coords=coords, attrs={"provenance": prov.to_json()})
    ra = xr.DataArray(raw, dims=("line", "sample", "band"), coords=coords)
    return HyperspectralCube(da, ra, masks["saturated"], masks["bad"], masks["missing"], prov, units, hist)
