"""Relational persistence (SQLAlchemy Core): surveys, calibrations, nodules,
observations, assays and carbon results.

SQLite for development and tests; PostgreSQL in deployment
(``AARDVARK_DB_URL=postgresql+psycopg://...``). JSON payloads are stored in
JSON columns; every row carries its data origin.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any, Iterable

from sqlalchemy import (JSON, Column, DateTime, Float, ForeignKey, MetaData, String, Table, Text, create_engine,
                        insert, select)
from sqlalchemy.engine import Engine

metadata = MetaData()

surveys = Table("surveys", metadata,
                Column("survey_id", String(64), primary_key=True),
                Column("created", DateTime(timezone=True)),
                Column("data_origin", String(32), nullable=False),
                Column("summary", JSON))

calibrations = Table("calibrations", metadata,
                     Column("calibration_id", String(96), primary_key=True),
                     Column("sensor_key", String(32), index=True),
                     Column("kind", String(48)),
                     Column("version", String(16)),
                     Column("origin", String(32), nullable=False),
                     Column("record", JSON))

nodules = Table("nodules", metadata,
                Column("nodule_id", String(96), primary_key=True),
                Column("survey_id", String(64), ForeignKey("surveys.survey_id"), index=True),
                Column("east_m", Float), Column("north_m", Float),
                Column("data_origin", String(32), nullable=False),
                Column("record", JSON))

observations = Table("observations", metadata,
                     Column("observation_id", String(64), primary_key=True),
                     Column("nodule_id", String(96), ForeignKey("nodules.nodule_id"), index=True),
                     Column("time_utc", DateTime(timezone=True)),
                     Column("sensor", String(64)),
                     Column("data_origin", String(32), nullable=False),
                     Column("payload", JSON))

assays = Table("assays", metadata,
               Column("sample_id", String(64), primary_key=True),
               Column("nodule_id", String(96), index=True, nullable=True),
               Column("laboratory", String(128)),
               Column("method", String(64)),
               Column("payload", JSON))

carbon_results = Table("carbon_results", metadata,
                       Column("target_id", String(64), primary_key=True),
                       Column("survey_id", String(64), ForeignKey("surveys.survey_id")),
                       Column("east_m", Float), Column("north_m", Float),
                       Column("top_class", String(48)),
                       Column("quantitation_level", String(32)),
                       Column("data_origin", String(32), nullable=False),
                       Column("payload", JSON))

audit = Table("audit", metadata,
              Column("ts", DateTime(timezone=True)), Column("actor", String(64)), Column("action", String(64)),
              Column("detail", Text))


def make_engine(url: str | None = None) -> Engine:
    url = url or os.environ.get("AARDVARK_DB_URL", "sqlite:///aardvark.db")
    eng = create_engine(url, future=True)
    metadata.create_all(eng)
    return eng


def _j(obj: Any):
    return json.loads(json.dumps(obj, default=str))


class Repository:
    def __init__(self, engine: Engine):
        self.engine = engine

    def has_survey(self, survey_id: str) -> bool:
        with self.engine.connect() as c:
            return c.execute(select(surveys.c.survey_id).where(surveys.c.survey_id == survey_id)).first() is not None

    def save_survey(self, products) -> bool:
        """Persist a survey's records. Idempotent: an already-stored survey is
        left untouched (records are immutable) and False is returned."""
        if self.has_survey(products.survey_id):
            return False
        with self.engine.begin() as c:
            c.execute(insert(surveys).values(survey_id=products.survey_id, created=datetime.now(timezone.utc),
                                             data_origin="simulated", summary=_j(products.summary())))
            for rec in products.calibrations._records.values():
                c.execute(insert(calibrations).values(calibration_id=rec.calibration_id, sensor_key=rec.sensor_key,
                                                      kind=rec.kind.value, version=str(rec.version),
                                                      origin=rec.origin.value, record=_j(rec.model_dump())))
            for nid, rec in products.registry.records.items():
                c.execute(insert(nodules).values(nodule_id=nid, survey_id=products.survey_id, east_m=rec.east_m,
                                                 north_m=rec.north_m, data_origin=rec.data_origin.value,
                                                 record=_j({"assays": rec.assay_sample_ids, "notes": rec.notes})))
                for ob in rec.observations:
                    c.execute(insert(observations).values(observation_id=ob.observation_id, nodule_id=nid,
                                                          time_utc=ob.time_utc, sensor=ob.sensor,
                                                          data_origin=ob.data_origin.value, payload=_j(ob.model_dump())))
            for r, (e, n) in zip(products.carbon_results, products.carbon_positions):
                c.execute(insert(carbon_results).values(target_id=f"{products.survey_id}-{r.target_id}",
                                                        survey_id=products.survey_id, east_m=float(e), north_m=float(n),
                                                        top_class=r.top_class, quantitation_level=r.quantitation_level.value,
                                                        data_origin=r.data_origin.value, payload=_j(r.model_dump())))
        return True

    def save_assays(self, records: Iterable) -> None:
        with self.engine.begin() as c:
            for a in records:
                c.execute(insert(assays).values(sample_id=a.sample_id, nodule_id=a.nodule_id, laboratory=a.laboratory,
                                                method=a.method, payload=_j(a.model_dump())))

    def nodule(self, nodule_id: str) -> dict | None:
        with self.engine.connect() as c:
            row = c.execute(select(nodules).where(nodules.c.nodule_id == nodule_id)).mappings().first()
            if row is None:
                return None
            obs = c.execute(select(observations).where(observations.c.nodule_id == nodule_id)).mappings().all()
            return {**dict(row), "observations": [dict(o) for o in obs]}

    def count(self, table: Table) -> int:
        with self.engine.connect() as c:
            return len(c.execute(select(table.c[list(table.c.keys())[0]])).all())

    def log(self, actor: str, action: str, detail: str = "") -> None:
        with self.engine.begin() as c:
            c.execute(insert(audit).values(ts=datetime.now(timezone.utc), actor=actor, action=action, detail=detail))
