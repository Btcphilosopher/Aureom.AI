"""Storage: hyperspectral cubes (Zarr/HDF5, raw retained) and relational records."""
