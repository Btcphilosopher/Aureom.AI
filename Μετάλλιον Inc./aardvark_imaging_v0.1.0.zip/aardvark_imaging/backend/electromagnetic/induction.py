"""Frequency-domain electromagnetic induction (EMI) processing.

What this channel measures: the secondary magnetic field induced in
electrically conductive (and magnetically susceptible) material near the
coils, as a complex ratio to the primary field. In seawater the background
is large (sigma_sw ~ 3-5 S/m) and the seabed contrast is small, so the
product is a *material-contrast* layer relative to local background. It is
not a carbon measurement and not a direct metal-grade measurement; a site
calibration against physical samples is required before any geological
interpretation.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.constants import MU0


def seawater_conductivity(temperature_c: float, salinity_psu: float = 35.0) -> float:
    """Approximate conductivity (S/m): sigma ~ (S/35)(2.90 + 0.088 T + 0.0006 T^2).
    Within ~3 % of PSS-78 derived values for 0-25 C at oceanic salinity;
    use measured CTD conductivity in operations."""
    T = temperature_c
    return (salinity_psu / 35.0) * (2.90 + 0.088 * T + 0.0006 * T * T)


def skin_depth_m(frequency_hz, sigma_s_m) -> np.ndarray:
    """delta = sqrt(2 / (omega mu0 sigma)) (good-conductor limit)."""
    w = 2 * np.pi * np.asarray(frequency_hz, dtype=float)
    return np.sqrt(2.0 / (w * MU0 * np.asarray(sigma_s_m, dtype=float)))


def induction_number(spacing_m: float, frequency_hz, sigma_s_m) -> np.ndarray:
    return spacing_m / skin_depth_m(frequency_hz, sigma_s_m)


def complex_response(rx_i, rx_q, ref_i, ref_q) -> np.ndarray:
    """Receiver / reference complex ratio from the FPGA I/Q accumulators.

    With I = sum x sin(phi) and Q = sum x cos(phi), a signal A sin(phi + th)
    gives I + jQ ~ (N A/2) e^{j th}; the ratio cancels transmitter drift."""
    return (np.asarray(rx_i) + 1j * np.asarray(rx_q)) / (np.asarray(ref_i) + 1j * np.asarray(ref_q))


@dataclass
class EmiCalibration:
    null_response: complex          # response measured in the reference condition (free field / water column)
    scale: complex                  # coil-geometry scaling: Hs/Hp = scale * (Z - null)
    frequency_hz: float
    spacing_m: float
    reference: str


def secondary_primary_ratio(Z, cal: EmiCalibration) -> np.ndarray:
    return cal.scale * (np.asarray(Z) - cal.null_response)


def apparent_conductivity(hs_hp, frequency_hz: float, spacing_m: float) -> np.ndarray:
    """McNeill (1980) low-induction-number approximation:
        sigma_a = 4 / (omega mu0 s^2) * Im(Hs/Hp)
    Valid only for induction number << 1; callers must check."""
    w = 2 * np.pi * frequency_hz
    return 4.0 / (w * MU0 * spacing_m ** 2) * np.imag(np.asarray(hs_hp))


def lin_valid(frequency_hz: float, spacing_m: float, sigma_s_m: float, limit: float = 0.3) -> bool:
    return bool(induction_number(spacing_m, frequency_hz, sigma_s_m) < limit)


@dataclass
class PlatformCompensation:
    """Linear regression of the complex response on vehicle-state regressors
    (thruster currents, heading sin/cos, pitch, roll, ...) recorded during a
    calibration manoeuvre in the water column, away from the seabed."""
    coef: np.ndarray            # complex, (n_regressors + 1)
    regressor_names: list[str]
    residual_std: float

    def apply(self, Z, regressors) -> np.ndarray:
        R = np.column_stack([np.ones(len(Z)), np.asarray(regressors, dtype=float)])
        return np.asarray(Z) - R @ self.coef + self.coef[0]


def fit_platform_compensation(Z_cal, regressors, names) -> PlatformCompensation:
    R = np.column_stack([np.ones(len(Z_cal)), np.asarray(regressors, dtype=float)])
    Zc = np.asarray(Z_cal)
    coef_r, *_ = np.linalg.lstsq(R, Zc.real, rcond=None)
    coef_i, *_ = np.linalg.lstsq(R, Zc.imag, rcond=None)
    coef = coef_r + 1j * coef_i
    resid = Zc - R @ coef
    return PlatformCompensation(coef, list(names), float(np.std(np.abs(resid))))


def material_contrast(values, window: int = 51) -> np.ndarray:
    """Robust z-score of a response series relative to a running median
    background (MAD scale)."""
    v = np.asarray(values, dtype=float)
    n = v.size
    out = np.zeros(n)
    h = window // 2
    for i in range(n):
        seg = v[max(0, i - h):min(n, i + h + 1)]
        med = np.median(seg)
        mad = np.median(np.abs(seg - med)) * 1.4826
        out[i] = (v[i] - med) / (mad if mad > 0 else 1.0)
    return out
