"""Radar subsystem and its physical limits in seawater.

Seawater is a good conductor at radar frequencies: at 100 MHz with
sigma = 4 S/m the loss tangent sigma/(omega eps) is ~8 and the attenuation is
~37 Np/m (~325 dB/m). Conventional ground-penetrating radar therefore cannot
image through a water column. This module provides:

* :func:`seawater_attenuation` — exact plane-wave attenuation for a lossy
  dielectric (Debye water permittivity + conductivity);
* :func:`assess_path` — a feasibility gate used by every radar workflow;
* :class:`FmcwRadar` — FMCW range processing for topside, laboratory or
  in-air (core-scanning) use, which refuses submerged paths that the
  feasibility gate rejects.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.constants import C0, EPS0, MU0


def water_permittivity(frequency_hz, temperature_c: float = 2.0) -> np.ndarray:
    """Single-Debye relative permittivity of water (eps_s ~ 87.7 at 0 C,
    eps_inf ~ 5.7, tau ~ 17.7 ps at 0 C, decreasing with temperature)."""
    f = np.asarray(frequency_hz, dtype=float)
    T = temperature_c
    eps_s = 87.74 - 0.40008 * T + 9.398e-4 * T ** 2
    eps_inf = 5.7
    tau = (1.1109e-10 - 3.824e-12 * T + 6.938e-14 * T ** 2) / (2 * np.pi)
    return eps_inf + (eps_s - eps_inf) / (1 + 1j * 2 * np.pi * f * tau)


def seawater_attenuation(frequency_hz, sigma_s_m: float = 4.0, temperature_c: float = 2.0) -> dict:
    """Plane-wave attenuation (Np/m and dB/m) and phase speed."""
    f = np.asarray(frequency_hz, dtype=float)
    w = 2 * np.pi * f
    eps = water_permittivity(f, temperature_c) * EPS0 - 1j * sigma_s_m / w
    k = w * np.sqrt(MU0 * eps)          # complex wavenumber, Im<0 by convention of e^{j(wt-kz)}
    alpha = np.abs(np.imag(k))
    beta = np.abs(np.real(k))
    return {"alpha_np_m": alpha, "alpha_db_m": 8.686 * alpha, "phase_speed_m_s": w / beta,
            "loss_tangent": sigma_s_m / (w * np.real(water_permittivity(f, temperature_c)) * EPS0)}


@dataclass
class PathAssessment:
    feasible: bool
    medium: str
    frequency_hz: float
    path_m: float
    two_way_loss_db: float
    reason: str


def assess_path(frequency_hz: float, path_m: float, *, medium: str = "seawater", sigma_s_m: float = 4.0,
                max_two_way_loss_db: float = 120.0) -> PathAssessment:
    """Gate radar operation on the two-way propagation loss of the medium."""
    if medium == "air":
        loss = 2 * 20 * np.log10(max(path_m, 1e-3))
        return PathAssessment(loss <= max_two_way_loss_db + 60, medium, frequency_hz, path_m, float(loss),
                              "free-space spreading only")
    att = float(seawater_attenuation(frequency_hz, sigma_s_m)["alpha_db_m"]) if medium == "seawater" else 0.0
    if medium == "saturated_sediment":
        att = float(seawater_attenuation(frequency_hz, sigma_s_m * 0.3)["alpha_db_m"])
    loss = 2 * att * path_m
    ok = loss <= max_two_way_loss_db
    reason = ("within loss budget" if ok else
              f"two-way {medium} attenuation {loss:,.0f} dB exceeds {max_two_way_loss_db:.0f} dB: radar is not a viable "
              f"imaging method on this path; use acoustic sub-bottom profiling (subsurface) or EMI (near-field contrast)")
    return PathAssessment(bool(ok), medium, frequency_hz, path_m, float(loss), reason)


class RadarNotFeasible(RuntimeError):
    pass


@dataclass
class FmcwRadar:
    f_start_hz: float
    bandwidth_hz: float
    sweep_s: float
    fs_hz: float

    @property
    def range_resolution_m(self) -> float:
        return C0 / (2 * self.bandwidth_hz)

    def beat_to_range(self, f_beat_hz, velocity_factor: float = 1.0):
        return np.asarray(f_beat_hz) * C0 * velocity_factor * self.sweep_s / (2 * self.bandwidth_hz)

    def process(self, beat_signal, *, medium: str = "air", path_m: float = 1.0, velocity_factor: float = 1.0):
        """Range profile (magnitude per range bin). Refuses media/paths that
        fail :func:`assess_path`."""
        a = assess_path(self.f_start_hz + self.bandwidth_hz / 2, path_m, medium=medium)
        if not a.feasible:
            raise RadarNotFeasible(a.reason)
        x = np.asarray(beat_signal, dtype=float)
        n = x.size
        spec = np.abs(np.fft.rfft(x * np.hanning(n)))
        f = np.fft.rfftfreq(n, 1 / self.fs_hz)
        return self.beat_to_range(f, velocity_factor), spec, a
