"""Data-rate and storage budget derived from the Silica Flux manifest.

All rates are *arithmetic consequences* of the assumed sensor configuration in
the manifest (rows, pixels, sample rates, packet overhead). They are not
measured throughput. DMA capacity uses the efficiency measured in RTL
simulation (``dma.simulated_efficiency``), which is itself not a hardware
measurement.
"""
from __future__ import annotations

from dataclasses import dataclass

from .manifest import Manifest


@dataclass(frozen=True)
class SensorRate:
    key: str
    name: str
    packets_per_s: float
    payload_bytes_per_s: float
    wire_bytes_per_s: float
    overhead_fraction: float
    in_reference_rtl: bool


@dataclass(frozen=True)
class Budget:
    sensors: tuple[SensorRate, ...]
    total_wire_bytes_per_s: float
    dma_capacity_bytes_per_s: float
    utilisation: float
    storage_bytes_per_hour: float
    verdict: str

    def as_dict(self) -> dict:
        return {
            "sensors": [s.__dict__ for s in self.sensors],
            "total_wire_bytes_per_s": self.total_wire_bytes_per_s,
            "dma_capacity_bytes_per_s": self.dma_capacity_bytes_per_s,
            "utilisation": self.utilisation,
            "storage_bytes_per_hour": self.storage_bytes_per_hour,
            "verdict": self.verdict,
            "basis": "Arithmetic from assumed manifest configuration; not measured hardware throughput.",
        }


def compute_budget(m: Manifest, *, warn_at: float = 0.7, fail_at: float = 0.95) -> Budget:
    hdr = int(m.packet["header_words"]) + int(m.packet["trailer_words"])
    rows: list[SensorRate] = []
    for s in m.sensors:
        pkts = s.sampling_hz * s.records_per_sample
        payload = pkts * s.words_per_record * 4.0
        wire = pkts * (s.words_per_record + hdr) * 4.0
        rows.append(
            SensorRate(
                key=s.key,
                name=s.name,
                packets_per_s=pkts,
                payload_bytes_per_s=payload,
                wire_bytes_per_s=wire,
                overhead_fraction=(wire - payload) / wire if wire else 0.0,
                in_reference_rtl=s.instantiated_in_reference_rtl,
            )
        )
    total = sum(r.wire_bytes_per_s for r in rows)
    clk = m.clock("clk_sys").frequency_hz
    cap = clk * (int(m.dma["data_width"]) / 8) * float(m.dma["simulated_efficiency"])
    util = total / cap
    if util >= fail_at:
        verdict = "FAIL: aggregate sensor rate exceeds DMA capacity margin"
    elif util >= warn_at:
        verdict = "WARN: aggregate rate above comfortable DMA margin"
    else:
        verdict = "OK"
    return Budget(tuple(rows), total, cap, util, total * 3600.0, verdict)


def budget_markdown(b: Budget) -> str:
    lines = [
        "# Data-rate budget (derived)",
        "",
        "Computed by `aardvark sf budget` from the assumed sensor configuration in the Silica Flux",
        "manifest. These figures are arithmetic, not benchmarks. DMA capacity uses the efficiency",
        "measured in RTL simulation of `sf_dma_controller`, not on hardware.",
        "",
        "| Sensor | Packets/s | Payload MB/s | On-wire MB/s | Header overhead | In reference RTL |",
        "|---|---:|---:|---:|---:|:---:|",
    ]
    for r in b.sensors:
        lines.append(
            f"| {r.key} — {r.name} | {r.packets_per_s:,.1f} | {r.payload_bytes_per_s / 1e6:,.3f} | "
            f"{r.wire_bytes_per_s / 1e6:,.3f} | {100 * r.overhead_fraction:.2f}% | {'yes' if r.in_reference_rtl else 'no'} |"
        )
    lines += [
        "",
        f"* Aggregate on-wire rate: **{b.total_wire_bytes_per_s / 1e6:,.1f} MB/s**",
        f"* DMA capacity (clk_sys × 4 B × simulated efficiency): **{b.dma_capacity_bytes_per_s / 1e6:,.1f} MB/s**",
        f"* Utilisation: **{100 * b.utilisation:.1f}%** — {b.verdict}",
        f"* Raw storage at full duty: **{b.storage_bytes_per_hour / 1e9:,.1f} GB/hour** "
        f"({b.storage_bytes_per_hour * 24 / 1e12:,.1f} TB/day)",
        "",
        "Storage at full duty cycle exceeds what is practical for multi-day AUV missions; survey",
        "plans must duty-cycle the area cameras (MS0/RGB0) or decimate them on the vehicle.",
        "",
    ]
    return "\n".join(lines)
