"""Silica Flux hardware manifest model and validation.

The manifest (TOML) is the single source of truth for the instrument's
digital hardware contract: clock domains, packet format, sensor channels and
the AXI4-Lite register map. This module parses it into typed objects and runs
structural checks that would otherwise surface as silent hardware/software
mismatches (overlapping registers, fields outside 32 bits, dangling clock
domain references, duplicate sensor identifiers, ...).
"""
from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Access = Literal["RW", "RO", "RO_CONST", "W1C", "W1P"]

BLOCK_SPAN = 0x100  # bytes reserved per register block


class ManifestError(ValueError):
    """Raised when a Silica Flux manifest is structurally invalid."""


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class RegField(_Strict):
    name: str
    lsb: int = Field(ge=0, le=31)
    width: int = Field(ge=1, le=32)
    description: str = ""

    @property
    def msb(self) -> int:
        return self.lsb + self.width - 1

    @property
    def mask(self) -> int:
        return ((1 << self.width) - 1) << self.lsb

    @model_validator(mode="after")
    def _fits(self) -> "RegField":
        if self.msb > 31:
            raise ValueError(f"field {self.name} [{self.msb}:{self.lsb}] exceeds 32 bits")
        return self


class Register(_Strict):
    name: str
    offset: int = Field(ge=0, lt=BLOCK_SPAN)
    access: Access
    description: str = ""
    reset: int = 0
    value: int | None = None
    count: int = Field(default=1, ge=1, le=64)
    stride: int = 4
    fields: tuple[RegField, ...]

    @property
    def mask(self) -> int:
        m = 0
        for f in self.fields:
            m |= f.mask
        return m

    @property
    def is_array(self) -> bool:
        return self.count > 1

    def field(self, name: str) -> RegField:
        for f in self.fields:
            if f.name == name:
                return f
        raise KeyError(f"{self.name} has no field {name}")

    @model_validator(mode="after")
    def _check(self) -> "Register":
        if self.offset % 4:
            raise ValueError(f"register {self.name} offset 0x{self.offset:X} not word aligned")
        if self.stride % 4 or self.stride < 4:
            raise ValueError(f"register {self.name} stride must be a multiple of 4")
        if not self.fields:
            raise ValueError(f"register {self.name} has no fields")
        used = 0
        names = set()
        for f in self.fields:
            if f.name in names:
                raise ValueError(f"register {self.name}: duplicate field {f.name}")
            names.add(f.name)
            if used & f.mask:
                raise ValueError(f"register {self.name}: field {f.name} overlaps another field")
            used |= f.mask
        if self.access == "RO_CONST" and self.value is None:
            raise ValueError(f"RO_CONST register {self.name} needs a value")
        if self.access != "RO_CONST" and self.value is not None:
            raise ValueError(f"register {self.name}: `value` is only valid for RO_CONST")
        if self.reset & ~used & 0xFFFFFFFF:
            raise ValueError(
                f"register {self.name}: reset 0x{self.reset:08X} sets reserved bits (mask 0x{used:08X})"
            )
        if self.reset and self.access not in ("RW",):
            raise ValueError(f"register {self.name}: reset value only meaningful for RW")
        last = self.offset + (self.count - 1) * self.stride
        if last >= BLOCK_SPAN:
            raise ValueError(f"register array {self.name} overflows its block")
        return self


class RegisterBlock(_Strict):
    name: str
    base: int = Field(ge=0)
    description: str = ""
    registers: tuple[Register, ...]

    @field_validator("base")
    @classmethod
    def _aligned(cls, v: int) -> int:
        if v % BLOCK_SPAN:
            raise ValueError(f"block base 0x{v:X} must be {BLOCK_SPAN}-byte aligned")
        return v


class ClockDomain(_Strict):
    name: str
    frequency_hz: float = Field(gt=0)
    source: str
    role: str
    async_to: tuple[str, ...] = ()


class Sensor(BaseModel):
    model_config = ConfigDict(extra="allow", frozen=True)
    key: str
    uid: int = Field(ge=0, le=255)
    name: str
    type: str
    module: str
    interface: str
    clock_domain: str
    trigger_channel: int = Field(ge=-1, le=7)
    packet_type: str
    sampling_hz: float = Field(ge=0)
    resolution_bits: int = Field(ge=0, le=64)
    channel_count: int = Field(ge=1)
    data_format: str
    words_per_record: int = Field(ge=0)
    records_per_sample: int = Field(ge=1)
    calibration: tuple[str, ...]
    timing: dict[str, Any]
    status_registers: tuple[str, ...]
    assumed: bool
    instantiated_in_reference_rtl: bool = True


@dataclass(frozen=True)
class ExpandedRegister:
    """A single addressable 32-bit register (array elements expanded)."""

    block: str
    name: str
    base_name: str
    index: int | None
    address: int
    reg: Register


class Manifest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    instrument: dict[str, Any]
    clock_domains: tuple[ClockDomain, ...]
    bus: dict[str, Any]
    dma: dict[str, Any]
    packet: dict[str, Any]
    pixel_codes: dict[str, int]
    fixed_point: dict[str, str]
    sensors: tuple[Sensor, ...]
    register_blocks: tuple[RegisterBlock, ...]

    # ------------------------------------------------------------------ access
    @property
    def packet_types(self) -> dict[str, int]:
        return dict(self.packet["types"])

    @property
    def packet_flags(self) -> dict[str, int]:
        return dict(self.packet["flags"])

    def clock(self, name: str) -> ClockDomain:
        for c in self.clock_domains:
            if c.name == name:
                return c
        raise KeyError(name)

    def sensor(self, key: str) -> Sensor:
        for s in self.sensors:
            if s.key == key:
                return s
        raise KeyError(key)

    def register(self, name: str) -> Register:
        for b in self.register_blocks:
            for r in b.registers:
                if r.name == name:
                    return r
        raise KeyError(name)

    def address(self, name: str, index: int = 0) -> int:
        for b in self.register_blocks:
            for r in b.registers:
                if r.name == name:
                    if not 0 <= index < r.count:
                        raise IndexError(f"{name}[{index}] out of range")
                    return b.base + r.offset + index * r.stride
        raise KeyError(name)

    def expanded(self) -> list[ExpandedRegister]:
        out: list[ExpandedRegister] = []
        for b in self.register_blocks:
            for r in b.registers:
                for k in range(r.count):
                    nm = f"{r.name}{k}" if r.is_array else r.name
                    out.append(
                        ExpandedRegister(b.name, nm, r.name, k if r.is_array else None,
                                         b.base + r.offset + k * r.stride, r)
                    )
        return sorted(out, key=lambda e: e.address)

    # -------------------------------------------------------------- validation
    @model_validator(mode="after")
    def _cross_checks(self) -> "Manifest":
        clocks = {c.name for c in self.clock_domains}
        for c in self.clock_domains:
            for a in c.async_to:
                if a not in clocks:
                    raise ValueError(f"clock {c.name}: async_to references unknown domain {a}")
        ptypes = self.packet.get("types", {})
        if len(set(ptypes.values())) != len(ptypes):
            raise ValueError("duplicate packet type codes")
        flags = self.packet.get("flags", {})
        if any(not 0 <= v <= 7 for v in flags.values()) or len(set(flags.values())) != len(flags):
            raise ValueError("packet flags must be unique bit positions 0..7")
        keys, uids = set(), set()
        for s in self.sensors:
            if s.key in keys:
                raise ValueError(f"duplicate sensor key {s.key}")
            if s.uid in uids:
                raise ValueError(f"duplicate sensor uid 0x{s.uid:02X}")
            keys.add(s.key)
            uids.add(s.uid)
            if s.clock_domain not in clocks:
                raise ValueError(f"sensor {s.key}: unknown clock domain {s.clock_domain}")
            if s.packet_type not in ptypes:
                raise ValueError(f"sensor {s.key}: unknown packet type {s.packet_type}")
            if s.words_per_record > int(self.packet["max_payload_words"]):
                raise ValueError(f"sensor {s.key}: record exceeds max payload")
        names: set[str] = set()
        blocks_seen: set[int] = set()
        for b in self.register_blocks:
            if b.base in blocks_seen:
                raise ValueError(f"block {b.name}: base 0x{b.base:04X} reused")
            blocks_seen.add(b.base)
            occupied: dict[int, str] = {}
            for r in b.registers:
                if r.name in names:
                    raise ValueError(f"duplicate register name {r.name}")
                names.add(r.name)
                for k in range(r.count):
                    off = r.offset + k * r.stride
                    if off in occupied:
                        raise ValueError(f"{b.name}: {r.name} overlaps {occupied[off]} at +0x{off:02X}")
                    occupied[off] = r.name
        addr_bits = int(self.bus["addr_width"])
        top = max(b.base for b in self.register_blocks) + BLOCK_SPAN
        if top > (1 << addr_bits):
            raise ValueError("register map exceeds bus address width")
        for s in self.sensors:
            for sr in s.status_registers:
                if sr not in names:
                    raise ValueError(f"sensor {s.key}: status register {sr} not in register map")
        return self


def default_manifest_path() -> Path:
    here = Path(__file__).resolve()
    for parent in here.parents:
        cand = parent / "hardware" / "silica_flux" / "manifests" / "aardvark_ssa.sf.toml"
        if cand.exists():
            return cand
    packaged = here.parent / "aardvark_ssa.sf.toml"
    if packaged.exists():
        return packaged
    raise FileNotFoundError("Silica Flux manifest not found")


def load_manifest(path: str | Path | None = None) -> Manifest:
    p = Path(path) if path else default_manifest_path()
    with p.open("rb") as fh:
        raw = tomllib.load(fh)
    try:
        return Manifest.model_validate(raw)
    except Exception as exc:  # pydantic.ValidationError or ValueError
        raise ManifestError(f"{p}: {exc}") from exc
