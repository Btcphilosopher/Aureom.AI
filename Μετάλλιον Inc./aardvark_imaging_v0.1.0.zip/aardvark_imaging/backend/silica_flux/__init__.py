"""Silica Flux — hardware architecture specification tooling.

Silica Flux is the architecture and specification layer for the Aardvark
Imaging sensor electronics: a machine-readable manifest describing clock
domains, sensors, the packet format and the register map, plus generators
that emit SystemVerilog, Python, C and documentation from that manifest.
The synthesizable hardware itself is standard SystemVerilog.
"""
from .manifest import Manifest, ManifestError, load_manifest, default_manifest_path
from .budget import compute_budget, budget_markdown
from .codegen import generate, check_up_to_date, artefacts, sine_quarter_rom

__all__ = [
    "Manifest",
    "ManifestError",
    "load_manifest",
    "default_manifest_path",
    "compute_budget",
    "budget_markdown",
    "generate",
    "check_up_to_date",
    "artefacts",
    "sine_quarter_rom",
]
