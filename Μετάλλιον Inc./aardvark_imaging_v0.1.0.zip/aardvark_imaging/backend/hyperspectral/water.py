"""Optical properties of seawater along the instrument path.

The dominant physical constraint on subsea spectral imaging: pure water
absorbs strongly above ~600 nm and catastrophically in the NIR/SWIR. With
active illumination at standoff h the light path is ~2h, so

    T(lambda) = exp(-c(lambda) * path),   c = a_w + b_w + c_particulate.

Table provenance (approximate, see ``WATER_TABLE_NOTE``): 380-720 nm from
Pope & Fry (1997); 730-1700 nm compiled and rounded from Kou, Labrie &
Chylek (1993) and Hale & Querry (1973). NIR/SWIR values are good to roughly
+-20-30 %, which does not change any usable-band conclusion (transmission
across 1 cm of water at 1450 nm is ~1e-13 whether a_w is 2400 or 3200 m^-1).
Replace with a verified table before using it for radiometric correction.
"""
from __future__ import annotations

import numpy as np

WATER_TABLE_NOTE = ("Approximate pure-water absorption: Pope & Fry 1997 (380-720 nm); NIR/SWIR rounded from "
                    "Kou et al. 1993 and Hale & Querry 1973 (+-20-30 %). Not a certified reference table.")

_WL = np.array([380, 400, 420, 440, 460, 480, 500, 520, 540, 560, 580, 600, 620, 640, 660, 680, 700, 720,
                740, 760, 780, 800, 820, 850, 880, 900, 920, 940, 960, 980, 1000, 1050, 1100, 1150, 1200,
                1250, 1300, 1350, 1400, 1450, 1500, 1550, 1600, 1650, 1700], dtype=float)
_AW = np.array([0.0114, 0.0066, 0.0045, 0.0064, 0.0098, 0.0127, 0.0204, 0.0409, 0.0474, 0.0619, 0.0896, 0.2224,
                0.2755, 0.3108, 0.410, 0.465, 0.624, 1.231, 2.47, 2.55, 2.36, 2.07, 2.6, 4.3, 5.6, 6.8, 15.0,
                27.0, 43.0, 44.0, 36.0, 15.0, 18.0, 87.0, 104.0, 85.0, 116.0, 270.0, 1900.0, 2900.0, 1800.0,
                980.0, 650.0, 550.0, 600.0])


def water_absorption(wavelength_nm) -> np.ndarray:
    """Pure-water absorption coefficient a_w (1/m), log-interpolated."""
    wl = np.asarray(wavelength_nm, dtype=float)
    if np.any(wl < _WL[0]) or np.any(wl > _WL[-1]):
        raise ValueError(f"wavelength outside table range {_WL[0]:.0f}-{_WL[-1]:.0f} nm")
    return np.exp(np.interp(wl, _WL, np.log(_AW)))


def water_scattering(wavelength_nm) -> np.ndarray:
    """Pure seawater scattering coefficient b_w (1/m), Morel (1974) power law."""
    return 0.00288 * (np.asarray(wavelength_nm, dtype=float) / 500.0) ** -4.32


def attenuation(wavelength_nm, *, c_particulate: float = 0.03) -> np.ndarray:
    """Beam attenuation c (1/m). ``c_particulate`` represents suspended
    particles; ~0.02-0.05 1/m in clear abyssal water, much higher in the
    benthic boundary layer or in plumes raised by the vehicle itself."""
    return water_absorption(wavelength_nm) + water_scattering(wavelength_nm) + c_particulate


def transmission(wavelength_nm, path_m: float, **kw) -> np.ndarray:
    return np.exp(-attenuation(wavelength_nm, **kw) * path_m)


def usable_bands(wavelength_nm, path_m: float, *, t_min: float = 0.02, **kw) -> np.ndarray:
    """Boolean mask of bands whose two-way transmission exceeds ``t_min``."""
    return transmission(wavelength_nm, path_m, **kw) >= t_min


def max_standoff_m(wavelength_nm, *, t_min: float = 0.02, two_way: bool = True, **kw) -> np.ndarray:
    """Largest standoff (m) at which a band still meets ``t_min``."""
    c = attenuation(wavelength_nm, **kw)
    path = -np.log(t_min) / c
    return path / (2.0 if two_way else 1.0)


def correct_water_path(radiance, wavelength_nm, path_m, *, backscatter=None, **kw):
    """Seabed-leaving radiance: (L_measured - L_backscatter) / T(path).

    ``backscatter`` is the water-column path radiance measured with the
    seabed out of range (or modelled); ``path_m`` may be per pixel.
    """
    L = np.asarray(radiance, dtype=float)
    T = np.exp(-attenuation(wavelength_nm, **kw) * np.asarray(path_m, dtype=float)[..., None])
    if backscatter is not None:
        L = L - np.asarray(backscatter, dtype=float)
    return L / T
