"""Hyperspectral radiometric processing chain.

raw -> dark -> flat -> bad-pixel repair -> radiance -> water-path correction
-> reflectance (only with a valid reference) -> optional MNF denoising.
Each stage records itself in the cube provenance; nothing touches ``raw``.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import ndimage

from ..calibration.radiometric import DarkReference, RadianceCalibration
from . import water
from .cube import HyperspectralCube


def subtract_dark(cube: HyperspectralCube, dark: DarkReference, calibration_id: str) -> HyperspectralCube:
    d = np.asarray(dark.mean, dtype=np.float32)        # (sample, band) for a push-broom detector
    return cube.with_data(cube.data.values - d[None], step="dark_subtraction", calibration_ids=[calibration_id],
                          parameters={"n_dark_frames": dark.n_frames})


def apply_flat(cube: HyperspectralCube, gain: np.ndarray, calibration_id: str) -> HyperspectralCube:
    return cube.with_data(cube.data.values * np.asarray(gain, dtype=np.float32)[None], step="flat_field",
                          calibration_ids=[calibration_id])


def repair_bad_pixels(cube: HyperspectralCube, extra_bad: np.ndarray | None = None) -> HyperspectralCube:
    """Replace invalid samples by the mean of valid spatial neighbours in the
    same band (3x3). Repaired samples remain flagged in ``bad``."""
    v = cube.data.values.astype(np.float64)
    invalid = cube.saturated | cube.bad | cube.missing
    if extra_bad is not None:
        invalid = invalid | np.broadcast_to(extra_bad[None], invalid.shape)
    ok = (~invalid).astype(float)
    k = np.ones((3, 3, 1))
    num = ndimage.convolve(np.where(invalid, 0, v), k, mode="nearest")
    den = ndimage.convolve(ok, k, mode="nearest")
    fill = np.where(den > 0, num / np.maximum(den, 1), np.nan)
    out = np.where(invalid & ~cube.saturated, fill, v)   # saturated stays saturated (no information)
    return cube.with_data(out, step="bad_pixel_repair", extra_invalid=extra_bad if extra_bad is None else
                          np.broadcast_to(extra_bad[None], invalid.shape), model_applied=True,
                          parameters={"repaired": int((invalid & ~cube.saturated).sum())})


def to_radiance(cube: HyperspectralCube, cal: RadianceCalibration, exposure_s: float, calibration_id: str) -> HyperspectralCube:
    rad = cal.to_radiance(cube.data.values / exposure_s)
    return cube.with_data(rad, step="radiance", units="W m-2 sr-1 nm-1", calibration_ids=[calibration_id],
                          parameters={"exposure_s": exposure_s, "certificate": cal.sphere_certificate})


def correct_water(cube: HyperspectralCube, path_m, *, backscatter=None, c_particulate: float = 0.03,
                  t_min: float = 0.02) -> HyperspectralCube:
    """Remove two-way water attenuation; bands below ``t_min`` transmission
    are marked invalid rather than amplified into noise."""
    wl = cube.wavelength_nm
    path = np.broadcast_to(np.asarray(path_m, dtype=float), cube.shape[:2])
    out = water.correct_water_path(cube.data.values, wl, path, backscatter=backscatter, c_particulate=c_particulate)
    T = np.exp(-water.attenuation(wl, c_particulate=c_particulate) * path[..., None])
    unusable = T < t_min
    return cube.with_data(np.where(unusable, np.nan, out), step="water_path_correction", model_applied=True,
                          extra_invalid=unusable,
                          parameters={"mean_path_m": float(path.mean()), "c_particulate": c_particulate,
                                      "t_min": t_min, "table": water.WATER_TABLE_NOTE,
                                      "bands_unusable": int(unusable.reshape(-1, unusable.shape[-1]).all(0).sum())})


@dataclass
class ReflectanceReference:
    panel_signal: np.ndarray        # same units/stage as the cube, per band (or per sample x band)
    panel_reflectance: np.ndarray   # certified reflectance per band
    reference_id: str
    certificate: str


def to_reflectance(cube: HyperspectralCube, ref: ReflectanceReference | None) -> HyperspectralCube:
    if ref is None:
        raise ValueError("reflectance requires a valid reference measurement (panel/target); none supplied")
    sig = np.asarray(ref.panel_signal, dtype=float)
    refl = cube.data.values / np.where(sig > 0, sig, np.nan) * np.asarray(ref.panel_reflectance, dtype=float)
    return cube.with_data(refl, step="reflectance", units="reflectance factor", calibration_ids=[ref.reference_id],
                          parameters={"certificate": ref.certificate})


def mnf_denoise(cube: HyperspectralCube, n_components: int) -> HyperspectralCube:
    from .analysis import mnf
    X = cube.data.values.reshape(-1, cube.shape[-1]).astype(np.float64)
    good = np.all(np.isfinite(X), axis=1)
    res = mnf(X[good].reshape(-1, 1, cube.shape[-1]), n_components=n_components)
    out = X.copy()
    out[good] = res["reconstruction"].reshape(-1, cube.shape[-1])
    return cube.with_data(out.reshape(cube.shape), step="mnf_denoise", model_applied=True,
                          parameters={"n_components": n_components})
