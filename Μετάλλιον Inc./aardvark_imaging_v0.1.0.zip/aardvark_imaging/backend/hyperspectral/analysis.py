"""Hyperspectral analysis: PCA, MNF, endmember extraction (VCA, ATGP),
linear unmixing (NNLS / FCLS) with abundance uncertainty."""
from __future__ import annotations

import numpy as np
from scipy.optimize import nnls


def pca(X: np.ndarray, n_components: int | None = None) -> dict:
    X = np.asarray(X, dtype=float)
    mu = X.mean(0)
    U, s, Vt = np.linalg.svd(X - mu, full_matrices=False)
    var = s ** 2 / max(1, X.shape[0] - 1)
    k = n_components or Vt.shape[0]
    return {"mean": mu, "components": Vt[:k], "explained_variance": var[:k],
            "explained_ratio": var[:k] / var.sum(), "scores": (X - mu) @ Vt[:k].T}


def shift_difference_noise(cube_xy: np.ndarray) -> np.ndarray:
    """Noise covariance from horizontal shift differences (Green et al. 1988)."""
    d = (cube_xy[:, 1:, :] - cube_xy[:, :-1, :]).reshape(-1, cube_xy.shape[-1]) / np.sqrt(2.0)
    if d.shape[0] < 2:
        d = np.diff(cube_xy.reshape(-1, cube_xy.shape[-1]), axis=0) / np.sqrt(2.0)
    return np.cov(d, rowvar=False)


def mnf(cube_xy: np.ndarray, n_components: int) -> dict:
    """Minimum Noise Fraction: noise-whitened PCA; reconstructs from the
    ``n_components`` highest-SNR components."""
    nb = cube_xy.shape[-1]
    X = cube_xy.reshape(-1, nb).astype(float)
    Cn = shift_difference_noise(cube_xy) + 1e-9 * np.eye(nb)
    ev, evec = np.linalg.eigh(Cn)
    W = evec @ np.diag(1.0 / np.sqrt(np.clip(ev, 1e-12, None))) @ evec.T
    mu = X.mean(0)
    Xw = (X - mu) @ W
    U, s, Vt = np.linalg.svd(Xw, full_matrices=False)
    k = min(n_components, Vt.shape[0])
    Winv = np.linalg.inv(W)
    rec = (Xw @ Vt[:k].T @ Vt[:k]) @ Winv + mu
    return {"snr_eigenvalues": s ** 2 / max(1, X.shape[0] - 1), "transform": W @ Vt.T, "reconstruction": rec}


def atgp(X: np.ndarray, p: int) -> np.ndarray:
    """Automatic Target Generation Process: indices of ``p`` endmembers by
    successive orthogonal-subspace maximisation."""
    X = np.asarray(X, dtype=float)
    idx = [int(np.argmax(np.sum(X ** 2, axis=1)))]
    for _ in range(1, p):
        U = X[idx].T
        P = np.eye(X.shape[1]) - U @ np.linalg.pinv(U)
        idx.append(int(np.argmax(np.sum((X @ P) ** 2, axis=1))))
    return np.array(idx)


def vca(X: np.ndarray, p: int, *, seed: int = 0) -> np.ndarray:
    """Vertex Component Analysis (Nascimento & Bioucas-Dias, 2005), SNR-high
    branch: project onto the p-dim signal subspace and iteratively find the
    extreme projections. Returns pixel indices of the endmembers."""
    rng = np.random.default_rng(seed)
    X = np.asarray(X, dtype=float)
    N, B = X.shape
    R = X.T                                       # B x N
    Ud, _, _ = np.linalg.svd(R @ R.T / N)
    Ud = Ud[:, :p]
    Xp = Ud.T @ R                                 # p x N
    u = Xp.mean(1, keepdims=True)
    Y = Xp / np.maximum(np.sum(Xp * u, axis=0, keepdims=True), 1e-12)
    A = np.zeros((p, p))
    A[-1, 0] = 1.0
    idx = np.zeros(p, dtype=int)
    for i in range(p):
        w = rng.standard_normal((p, 1))
        f = w - A @ np.linalg.pinv(A) @ w
        f /= np.linalg.norm(f) or 1.0
        v = f.T @ Y
        idx[i] = int(np.argmax(np.abs(v)))
        A[:, i] = Y[:, idx[i]]
    return idx


def unmix(X: np.ndarray, E: np.ndarray, *, sum_to_one: bool = True, delta: float = 1e3) -> dict:
    """Non-negative (and optionally fully constrained) least-squares unmixing.

    X: N x B pixels; E: M x B endmember spectra. FCLS enforces sum-to-one by
    augmenting the system with a heavily weighted row (Heinz & Chang, 2001).
    Abundance standard deviations are first-order estimates from the
    residual variance and the unconstrained normal matrix.
    """
    X = np.asarray(X, dtype=float)
    E = np.asarray(E, dtype=float)
    M, B = E.shape
    A = E.T
    if sum_to_one:
        A = np.vstack([A, delta * np.ones((1, M))])
    ab = np.empty((X.shape[0], M))
    resid = np.empty(X.shape[0])
    for i, x in enumerate(X):
        rhs = np.concatenate([x, [delta]]) if sum_to_one else x
        a, _ = nnls(A, rhs, maxiter=50 * M)
        ab[i] = a
        resid[i] = np.linalg.norm(E.T @ a - x)
    sigma2 = resid ** 2 / max(1, B - M)
    G = np.linalg.pinv(E @ E.T)
    std = np.sqrt(np.outer(sigma2, np.clip(np.diag(G), 0, None)))
    rmse = resid / np.sqrt(B)
    return {"abundances": ab, "std": std, "rmse": rmse, "residual_norm": resid}
