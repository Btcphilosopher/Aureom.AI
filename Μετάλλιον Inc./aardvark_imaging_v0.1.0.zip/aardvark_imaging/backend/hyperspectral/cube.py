"""Labelled hyperspectral cubes (xarray) with raw retention and provenance.

A :class:`HyperspectralCube` always carries:
* ``data``     processed values (dims: line, sample, band) as float32
* ``raw``      the original detector codes (uint16), never modified
* ``saturated`` / ``bad`` / ``missing`` boolean masks
* ``wavelength_nm`` band centres, ``line_time`` per-line timestamps
* ``provenance`` (JSON in attrs so it survives NetCDF/Zarr/HDF5)
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import xarray as xr

from ..acquisition import sfp
from ..core.provenance import DataOrigin, Provenance


@dataclass
class HyperspectralCube:
    data: xr.DataArray
    raw: xr.DataArray
    saturated: np.ndarray
    bad: np.ndarray
    missing: np.ndarray
    provenance: Provenance
    units: str = "counts"
    history: list[str] = field(default_factory=list)

    @property
    def wavelength_nm(self) -> np.ndarray:
        return self.data.coords["wavelength_nm"].values

    @property
    def shape(self):
        return self.data.shape

    @property
    def valid(self) -> np.ndarray:
        return ~(self.saturated | self.bad | self.missing)

    def with_data(self, values: np.ndarray, *, step: str, units: str | None = None, parameters: dict | None = None,
                  calibration_ids: list[str] | None = None, extra_invalid: np.ndarray | None = None,
                  model_applied: bool = False) -> "HyperspectralCube":
        prov = self.provenance.derive(step, model_applied=model_applied, parameters=parameters,
                                      calibration_ids=calibration_ids)
        da = self.data.copy(data=np.asarray(values, dtype=np.float32))
        da.attrs["provenance"] = prov.to_json()
        da.attrs["units"] = units or self.units
        bad = self.bad if extra_invalid is None else (self.bad | extra_invalid)
        return HyperspectralCube(da, self.raw, self.saturated, bad, self.missing, prov, units or self.units,
                                 self.history + [step])

    def to_dataset(self) -> xr.Dataset:
        ds = xr.Dataset({
            "data": self.data, "raw": self.raw,
            "saturated": (self.data.dims, self.saturated), "bad": (self.data.dims, self.bad),
            "missing": (self.data.dims, self.missing),
        })
        ds.attrs["provenance"] = self.provenance.to_json()
        ds.attrs["units"] = self.units
        ds.attrs["history"] = "; ".join(self.history)
        ds.attrs["data_origin"] = self.provenance.origin.value
        return ds

    @classmethod
    def from_dataset(cls, ds: xr.Dataset) -> "HyperspectralCube":
        prov = Provenance.from_json(ds.attrs["provenance"])
        return cls(ds["data"], ds["raw"], ds["saturated"].values.astype(bool), ds["bad"].values.astype(bool),
                   ds["missing"].values.astype(bool), prov, ds.attrs.get("units", "counts"),
                   [h for h in ds.attrs.get("history", "").split("; ") if h])

    def pixels(self, mask: np.ndarray | None = None) -> np.ndarray:
        """Spectra of valid pixels (N x bands); a pixel is valid if all its bands are valid."""
        v = self.data.values.reshape(-1, self.shape[-1])
        ok = self.valid.reshape(-1, self.shape[-1]).all(1)
        if mask is not None:
            ok &= np.asarray(mask, dtype=bool).ravel()
        return v[ok]


def make_cube(raw_codes: np.ndarray, wavelength_nm: np.ndarray, *, origin: DataOrigin, source: str,
              line_time=None, saturated=None, bad=None, missing=None, calibration_ids=None,
              notes=None) -> HyperspectralCube:
    raw_codes = np.asarray(raw_codes)
    nl, ns, nb = raw_codes.shape
    coords = {"line": np.arange(nl), "sample": np.arange(ns), "wavelength_nm": ("band", np.asarray(wavelength_nm, float)),
              "band": np.arange(nb)}
    if line_time is not None:
        coords["line_time"] = ("line", np.asarray(line_time))
    prov = Provenance(origin=origin, source=source, calibration_ids=list(calibration_ids or []), notes=list(notes or []))
    raw = xr.DataArray(raw_codes.astype(np.uint16), dims=("line", "sample", "band"), coords=coords, name="raw")
    data = xr.DataArray(raw_codes.astype(np.float32), dims=("line", "sample", "band"), coords=coords, name="data",
                        attrs={"provenance": prov.to_json(), "units": "counts"})
    z = np.zeros(raw_codes.shape, dtype=bool)
    return HyperspectralCube(data, raw, z if saturated is None else saturated, z.copy() if bad is None else bad,
                             z.copy() if missing is None else missing, prov, "counts", ["assembled"])


def assemble_pushbroom(packets: list[sfp.SfpPacket], *, n_samples: int, n_bands: int, wavelength_nm,
                       source: str = "HSI0") -> HyperspectralCube:
    """Assemble HSI_ROW packets into a (line, sample, band) cube.

    Missing spectral rows (dropped/lost packets) are masked, not invented.
    Packet SIMULATED flags propagate to the cube's data origin.
    """
    rows = [p for p in packets if p.type_name == "HSI_ROW"]
    if not rows:
        raise ValueError("no HSI_ROW packets")
    lines = sorted({p.frame for p in rows})
    lidx = {f: i for i, f in enumerate(lines)}
    raw = np.zeros((len(lines), n_samples, n_bands), dtype=np.uint16)
    sat = np.zeros(raw.shape, dtype=bool)
    bad = np.zeros(raw.shape, dtype=bool)
    missing = np.ones(raw.shape, dtype=bool)
    t = np.zeros(len(lines), dtype=np.int64)
    simulated = False
    calibrated = set()
    for p in rows:
        if p.row >= n_bands:
            continue
        li = lidx[p.frame]
        meta = sfp.imager_meta(p.meta)
        n = min(meta["pixel_count"], n_samples)
        px, s, b = sfp.unpack_pixels(p.payload, n)
        raw[li, :n, p.row] = px.data
        sat[li, :n, p.row] = s
        bad[li, :n, p.row] = b
        missing[li, :n, p.row] = False
        t[li] = p.timestamp
        simulated |= p.simulated
        calibrated.add(p.has("CALIBRATED"))
    notes = []
    if True in calibrated:
        notes.append("FPGA dark/flat calibration applied (CAL_EN=1); raw reconstructable from archived tables")
    return make_cube(raw, wavelength_nm, origin=DataOrigin.SIMULATED if simulated else DataOrigin.MEASURED,
                     source=source, line_time=t, saturated=sat, bad=bad, missing=missing, notes=notes)
