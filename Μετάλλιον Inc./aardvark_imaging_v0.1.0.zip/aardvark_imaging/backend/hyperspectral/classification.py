"""Probabilistic spectral classification against a reference library.

Probabilities come from spectral angles to library members:
    p_k ~ exp(-theta_k^2 / (2 sigma_theta^2))
where sigma_theta is the angular noise implied by the measurement SNR
(sigma_theta ~ 1/SNR for small angles). Pixels whose best angle exceeds
``max_angle`` are UNCLASSIFIED; the second-best margin is reported. Only
bands flagged usable (e.g. by water-path transmission) are used.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..spectral.similarity import sam_matrix

UNCLASSIFIED = "unclassified"


@dataclass
class ClassificationResult:
    classes: list[str]
    probabilities: np.ndarray     # N x K
    label: np.ndarray             # N (index into classes, -1 = unclassified)
    best_angle: np.ndarray        # radians
    margin: np.ndarray            # second-best minus best angle
    confidence: np.ndarray        # max probability (0 for unclassified)
    bands_used: np.ndarray

    def label_names(self) -> list[str]:
        return [self.classes[i] if i >= 0 else UNCLASSIFIED for i in self.label]


def classify_sam(pixels: np.ndarray, library: np.ndarray, classes: list[str], *, snr: float | np.ndarray,
                 usable: np.ndarray | None = None, max_angle: float = 0.15, min_prob: float = 0.5) -> ClassificationResult:
    X = np.asarray(pixels, dtype=float)
    L = np.asarray(library, dtype=float)
    use = np.ones(X.shape[1], dtype=bool) if usable is None else np.asarray(usable, dtype=bool)
    if use.sum() < 3:
        raise ValueError("fewer than 3 usable bands: spectral classification is not possible at this standoff")
    ang = sam_matrix(X[:, use], L[:, use])
    sig = 1.0 / np.maximum(np.atleast_1d(np.asarray(snr, dtype=float)), 1e-3)
    sig = np.broadcast_to(sig.reshape(-1, 1) if sig.size > 1 else sig, (X.shape[0], 1))
    logp = -0.5 * (ang / np.maximum(sig, 1e-6)) ** 2
    logp -= logp.max(1, keepdims=True)
    P = np.exp(logp)
    P /= P.sum(1, keepdims=True)
    order = np.sort(ang, axis=1)
    best = order[:, 0]
    margin = order[:, 1] - order[:, 0] if ang.shape[1] > 1 else np.full(best.shape, np.inf)
    lab = np.argmax(P, axis=1)
    conf = P[np.arange(P.shape[0]), lab]
    uncl = (best > max_angle) | (conf < min_prob)
    lab = np.where(uncl, -1, lab)
    conf = np.where(uncl, 0.0, conf)
    return ClassificationResult(list(classes), P, lab, best, margin, conf, use)
