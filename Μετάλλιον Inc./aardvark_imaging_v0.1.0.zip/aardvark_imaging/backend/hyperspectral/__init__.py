"""Hyperspectral cubes, radiometric pipeline, water-path physics, analysis and classification."""
