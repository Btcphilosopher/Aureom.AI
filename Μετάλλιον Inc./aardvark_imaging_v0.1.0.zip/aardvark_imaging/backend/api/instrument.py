"""Simulated FPGA instrument for the API's simulation mode.

Generates genuine SFP1 packets (bit-exact with the RTL packetiser format,
every one flagged SIMULATED) from the simulated survey, writes them into a
ring buffer exactly as the DMA would, and runs the same host path used with
hardware: RingReader -> RawSpool (durable) -> telemetry fan-out. Recording
never depends on WebSocket subscribers.
"""
from __future__ import annotations

import asyncio
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from ..acquisition import generated_regmap as rm
from ..acquisition import sfp
from ..acquisition.ring import ArrayRing, RingReader
from ..acquisition.spool import RawSpool

SIM_FLAGS = sfp.flags_value("SIMULATED")


class SimulatedInstrument:
    def __init__(self, products_getter, spool_dir: Path, *, ring_bytes: int = 1 << 22):
        self._products = products_getter
        self.spool_dir = Path(spool_dir)
        self.ring = ArrayRing(ring_bytes)
        self.reader = RingReader(self.ring)
        self.spool: RawSpool | None = None
        self.seq = 0
        self.ticks = 0
        self.acquiring = False
        self.started: datetime | None = None
        self.per_sensor: Counter = Counter()
        self.packets = 0
        self.subscribers: set[asyncio.Queue] = set()
        self._task: asyncio.Task | None = None
        self.sensors: list[str] = []
        self.line_rate = 20.0
        self.duration: float | None = None
        self._line = 0
        self.last_telemetry: dict = {}

    # ---------------------------------------------------------- packet sources
    def _emit(self, key: str, ptype: str, frame: int, row: int, meta: int, payload, flags: int = 0) -> None:
        words = sfp.encode_packet(sensor_uid=rm.SENSORS[key]["uid"], packet_type=rm.PACKET_TYPES[ptype],
                                  flags=flags | SIM_FLAGS, seq=self.seq, frame=frame, timestamp=self.ticks, row=row,
                                  meta=meta, payload=payload)
        self.seq = (self.seq + 1) & 0xFFFFFFFF
        if not self.ring.write_packet(words, self.reader.rd_ptr):
            self.per_sensor["DMA_DROP"] += 1

    def _hsi_line(self) -> None:
        cube = self._products().hsi_cube
        raw = cube.raw.values
        li = self._line % raw.shape[0]
        for band in range(0, raw.shape[2], 4):              # decimated band set keeps the demo light
            px = raw[li, :, band].astype(np.uint32)
            self._emit("HSI0", "HSI_ROW", self._line, band, (1 << 31) | px.size, sfp.pack_pixels(px))
        self._line += 1

    def _housekeeping(self) -> None:
        t = 20000 + int(200 * np.sin(time.time() / 30))
        self._emit("HK0", "HOUSEKEEPING", self._line, 0, 4, [t, 47000, 9000, 29500])

    def _diag(self) -> None:
        p = np.zeros(16, dtype=np.uint32)
        p[0], p[1] = self.ticks >> 32, self.ticks & 0xFFFFFFFF
        p[2] = self._line
        self._emit("DIAG", "DIAGNOSTIC", self._line, 0, 16, p)

    def _ping(self) -> None:
        self._emit("MBES0", "SONAR_PING", self._line, 0, 0,
                   [self._line, self.ticks >> 32, self.ticks & 0xFFFFFFFF, (self.ticks + 140) >> 32,
                    (self.ticks + 140) & 0xFFFFFFFF, 1])

    def _raman(self) -> None:
        ex = self._products().raman_examples
        k = list(ex)[self._line // 40 % len(ex)]
        counts = np.clip(np.asarray(ex[k]["signal"]) + np.asarray(ex[k]["baseline"]) + 1000, 0, 2 ** 32 - 1)
        self._emit("RAM0", "RAMAN_SPECTRUM", self._line // 40, 0, (1 << 24) | counts.size, counts.astype(np.uint32),
                   flags=sfp.flags_value("LASER_ON"))

    # ---------------------------------------------------------- loop
    async def _run(self) -> None:
        period = 1.0 / self.line_rate
        t_end = time.monotonic() + self.duration if self.duration else None
        while self.acquiring:
            self.ticks += int(period * 1e8)
            if "HSI0" in self.sensors:
                self._hsi_line()
            if "MBES0" in self.sensors and self._line % 2 == 0:
                self._ping()
            if "HK0" in self.sensors and self._line % 20 == 0:
                self._housekeeping()
            if "DIAG" in self.sensors and self._line % 20 == 0:
                self._diag()
            if "RAM0" in self.sensors and self._line % 40 == 0:
                self._raman()
            # host side: identical to hardware operation
            for p in self.reader.poll(self.ring.wr_ptr):
                self.spool.write(self._repack(p))
                self.per_sensor[p.sensor_key] += 1
                self.packets += 1
            self.last_telemetry = self.telemetry()
            for q in list(self.subscribers):
                if q.full():
                    try:
                        q.get_nowait()          # drop oldest for slow viewers; recording is unaffected
                    except asyncio.QueueEmpty:
                        pass
                q.put_nowait(self.last_telemetry)
            if t_end and time.monotonic() >= t_end:
                break
            await asyncio.sleep(period)
        self.acquiring = False
        if self.spool:
            self.spool.flush()

    @staticmethod
    def _repack(p: sfp.SfpPacket) -> np.ndarray:
        return sfp.encode_packet(sensor_uid=p.sensor_uid, packet_type=p.packet_type, flags=p.flags, seq=p.seq,
                                 frame=p.frame, timestamp=p.timestamp, row=p.row, meta=p.meta, payload=p.payload)

    async def start(self, sensors: list[str], line_rate_hz: float, duration_s: float | None) -> None:
        unknown = [s for s in sensors if s not in rm.SENSORS]
        if unknown:
            raise ValueError(f"unknown sensors: {unknown}")
        if self.acquiring:
            raise RuntimeError("acquisition already running")
        # The simulated scene is built lazily (seconds of CPU). Build it off the
        # event loop *before* the acquisition clock starts, so neither the
        # requested duration nor other requests are consumed by the warm-up.
        await asyncio.to_thread(self._products)
        if self.acquiring:
            raise RuntimeError("acquisition already running")
        self.sensors, self.line_rate, self.duration = sensors, line_rate_hz, duration_s
        self.spool = RawSpool(self.spool_dir, metadata={"mode": "simulation", "data_origin": "simulated",
                                                        "sensors": sensors})
        self.acquiring = True
        self.started = datetime.now(timezone.utc)
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self.acquiring = False
        if self._task:
            await self._task
            self._task = None
        if self.spool:
            self.spool.close()

    def telemetry(self) -> dict:
        return {"type": "telemetry", "data_origin": "simulated", "acquiring": self.acquiring, "packets": self.packets,
                "line": self._line, "ticks": self.ticks, "per_sensor": dict(self.per_sensor),
                "ring_fill_bytes": (self.ring.wr_ptr - self.reader.rd_ptr) % self.ring.size_bytes,
                "bytes_recorded": self.spool.stats.bytes if self.spool else 0,
                "time_utc": datetime.now(timezone.utc).isoformat()}

    def status(self) -> dict:
        return {"acquiring": self.acquiring, "mode": "simulation", "packets": self.packets,
                "bytes_recorded": self.spool.stats.bytes if self.spool else 0,
                "spool_segments": self.spool.stats.segments if self.spool else 0, "spool_dir": str(self.spool_dir),
                "sequence_gaps": len(self.reader.gaps), "corrupt_packets": self.reader.corrupt,
                "per_sensor": dict(self.per_sensor), "started_utc": self.started.isoformat() if self.started else None,
                "subscribers": len(self.subscribers), "data_origin": "simulated"}
