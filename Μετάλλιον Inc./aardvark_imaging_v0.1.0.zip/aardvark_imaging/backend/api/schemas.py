"""Versioned API contracts (v1). Requests are strict: unknown fields are rejected."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

API_VERSION = "1.0.0"


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SystemStatus(BaseModel):
    api_version: str = API_VERSION
    instrument: str
    mode: Literal["simulation", "hardware"]
    data_origin: str
    acquiring: bool
    survey_id: str | None
    depth_m: float | None
    position: dict[str, float] | None
    nodule_count: int
    carbon_targets: int
    calibration: dict[str, dict[str, str]]
    health: str
    uptime_s: float
    notices: list[str]


class SensorInfo(BaseModel):
    key: str
    uid: int
    name: str
    type: str
    interface: str
    clock_domain: str
    sampling_hz: float
    channel_count: int
    resolution_bits: int
    assumed_specification: bool
    in_reference_rtl: bool
    calibration_kinds: list[str]


class AcquisitionStartRequest(Strict):
    sensors: list[str] = Field(default_factory=lambda: ["HSI0", "HK0", "DIAG", "MBES0", "RAM0"])
    duration_s: float | None = Field(default=None, gt=0, le=86400)
    line_rate_hz: float = Field(default=20.0, gt=0, le=200)


class AcquisitionStatus(BaseModel):
    acquiring: bool
    mode: str
    packets: int
    bytes_recorded: int
    spool_segments: int
    spool_dir: str
    sequence_gaps: int
    corrupt_packets: int
    per_sensor: dict[str, int]
    started_utc: str | None
    subscribers: int
    data_origin: str


class SpectrumRequest(Strict):
    wavelength_nm: list[float] = Field(min_length=3)
    reflectance: list[float] = Field(min_length=3)
    snr: float = Field(default=50.0, gt=0)
    altitude_m: float = Field(default=2.0, ge=0, le=50)


class CarbonAnalyseRequest(Strict):
    target_id: str | None = None
    context: Literal["nodule_surface", "sediment", "unknown"] = "unknown"
    raman_shift_cm1: list[float] | None = None
    raman_light: list[list[float]] | None = None
    raman_dark: list[list[float]] | None = None


class NoduleDetectRequest(Strict):
    min_area_px: int = Field(default=12, ge=1, le=100000)
    max_relative_darkness: float = Field(default=0.55, gt=0, lt=1)
    min_seed_distance_px: float = Field(default=5.0, gt=0, le=200)


class FusionOpinion(Strict):
    channel: str
    probabilities: dict[str, float]
    quality: float = Field(ge=0, le=1)
    provenance_id: str


class FusionRequest(Strict):
    classes: list[str] = Field(min_length=2)
    opinions: list[FusionOpinion] = Field(min_length=1)
    expected_channels: list[str] | None = None


class ExportRequest(Strict):
    format: Literal["geojson_nodules", "geojson_track", "esri_ascii", "ply", "csv_nodules", "netcdf", "json_map"]
    layer: str = "nodule_abundance_kg_m2"


class ErrorResponse(BaseModel):
    detail: str
    data: dict[str, Any] | None = None
