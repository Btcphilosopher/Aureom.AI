"""FastAPI service exposing the Aardvark Imaging scientific engine (API v1).

Run: ``aardvark serve`` or ``uvicorn aardvark_imaging.api.app:create_app --factory``.
Set ``AARDVARK_API_KEY`` to require an ``X-API-Key`` header (and
``?api_key=`` on the WebSocket). TLS is terminated by the reverse proxy
(see deploy/). In simulation mode every response carries
``data_origin = "simulated"``.
"""
from __future__ import annotations

import asyncio
import dataclasses
import json
import os
import tempfile
import threading
import time
from pathlib import Path

import numpy as np
from fastapi import APIRouter, Depends, FastAPI, Header, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from .. import __version__
from ..acquisition import generated_regmap as rm
from ..carbon.engine import CarbonCharacterisationEngine, CarbonTarget
from ..diagnostics.health import assess
from ..geological_mapping.seabed_map import frontend_payload, survey_statistics
from ..geospatial import export as gx
from ..hyperspectral import water
from ..hyperspectral.classification import classify_sam
from ..mineralogy.library import parametric_vnir_library
from ..nodules.detection import detect_nodules
from ..sensor_fusion.fusion import ChannelOpinion, fuse
from ..silica_flux import load_manifest
from ..simulation.survey import SurveyProducts, fast_config, run_survey
from ..spectral.raman import assign_bands, process_raman
from .instrument import SimulatedInstrument
from .schemas import (AcquisitionStartRequest, AcquisitionStatus, CarbonAnalyseRequest, ExportRequest, FusionRequest,
                      NoduleDetectRequest, SensorInfo, SpectrumRequest, SystemStatus)

FRONTEND = Path(os.environ.get("AARDVARK_FRONTEND_DIR", Path(__file__).resolve().parents[2] / "frontend"))


class AppState:
    def __init__(self, seed: int, data_dir: Path):
        self.seed = seed
        self.data_dir = data_dir
        self._products: SurveyProducts | None = None
        self._lock = threading.Lock()
        self.db_status: dict = {"enabled": bool(os.environ.get("AARDVARK_DB_URL")), "state": "not yet loaded"}
        self.manifest = load_manifest()
        self.instrument = SimulatedInstrument(self.products, data_dir / "spool")
        self.t0 = time.time()

    def products(self) -> SurveyProducts:
        with self._lock:
            if self._products is None:
                self._products = run_survey(fast_config(self.seed))
                self._persist(self._products)
            return self._products

    def _persist(self, p: SurveyProducts) -> None:
        """Store survey records in SQL when AARDVARK_DB_URL is configured
        (SQLite or PostgreSQL). Failure is reported, never fatal: the raw
        spool and the in-memory products are unaffected."""
        url = os.environ.get("AARDVARK_DB_URL")
        if not url:
            self.db_status = {"enabled": False}
            return
        try:
            from ..storage.database import Repository, make_engine, nodules
            repo = Repository(make_engine(url))
            stored = repo.save_survey(p)
            repo.log("api", "survey_loaded", p.survey_id)
            self.db_status = {"enabled": True, "backend": url.split(":", 1)[0], "survey_stored_now": stored,
                              "nodule_rows": repo.count(nodules)}
        except Exception as exc:  # noqa: BLE001 - report, do not crash acquisition
            self.db_status = {"enabled": True, "error": f"{type(exc).__name__}: {exc}"}


def _np(o):
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if hasattr(o, "model_dump"):
        return o.model_dump()
    if hasattr(o, "__dict__"):
        return {k: v for k, v in o.__dict__.items() if not k.startswith("_")}
    return str(o)


def js(obj, status: int = 200) -> JSONResponse:
    return JSONResponse(json.loads(json.dumps(_clean(obj), default=_np)), status_code=status)


def _clean(o):
    """Replace NaN/inf by None so responses are valid JSON."""
    if isinstance(o, float):
        return o if np.isfinite(o) else None
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, np.ndarray):
        return _clean(o.tolist())
    if isinstance(o, (np.floating,)):
        return _clean(float(o))
    if isinstance(o, np.integer):
        return int(o)
    if hasattr(o, "model_dump"):
        return _clean(o.model_dump(mode="json"))
    if dataclasses.is_dataclass(o) and not isinstance(o, type):
        return _clean({f.name: getattr(o, f.name) for f in dataclasses.fields(o)})
    if hasattr(o, "value") and hasattr(o, "name") and not isinstance(o, (str, bytes)):
        return o.value
    return o


def create_app(*, seed: int | None = None, data_dir: str | None = None, api_key: str | None = None) -> FastAPI:
    seed = int(os.environ.get("AARDVARK_SIM_SEED", seed if seed is not None else 21))
    ddir = Path(data_dir or os.environ.get("AARDVARK_DATA_DIR", tempfile.mkdtemp(prefix="aardvark_")))
    ddir.mkdir(parents=True, exist_ok=True)
    key = api_key if api_key is not None else os.environ.get("AARDVARK_API_KEY")
    state = AppState(seed, ddir)
    app = FastAPI(title="Aardvark Imaging API", version=__version__,
                  description="Subsea spectral, carbon-characterisation and mineral-intelligence instrument (Μετάλλιον Inc.)")
    app.state.aardvark = state
    app.add_middleware(CORSMiddleware, allow_origins=os.environ.get("AARDVARK_CORS", "*").split(","),
                       allow_methods=["*"], allow_headers=["*"])

    def auth(x_api_key: str | None = Header(default=None)):
        if key and x_api_key != key:
            raise HTTPException(401, "invalid or missing X-API-Key")

    r = APIRouter(prefix="/api/v1", dependencies=[Depends(auth)])

    # ------------------------------------------------------------------ system
    @r.get("/system/status", response_model=SystemStatus)
    def system_status():
        p = state.products()
        cal = p.calibrations.summary({s.key: list(s.calibration) for s in state.manifest.sensors})
        h = assess(None, None, cal, sequence_gaps=len(state.instrument.reader.gaps))
        return SystemStatus(instrument=state.manifest.instrument["id"], mode="simulation", data_origin="simulated",
                            acquiring=state.instrument.acquiring, survey_id=p.survey_id,
                            depth_m=float(p.scene.cfg.mean_depth_m),
                            position={"lat": p.scene.cfg.origin_lat, "lon": p.scene.cfg.origin_lon},
                            nodule_count=len(p.registry), carbon_targets=len(p.carbon_results), calibration=cal,
                            health=h.status, uptime_s=time.time() - state.t0,
                            notices=["SIMULATION MODE: all data are synthetic and labelled SIMULATED",
                                     "sensor specifications are engineering assumptions (Silica Flux manifest)"])

    @r.get("/sensors", response_model=list[SensorInfo])
    def sensors():
        return [SensorInfo(key=s.key, uid=s.uid, name=s.name, type=s.type, interface=s.interface,
                           clock_domain=s.clock_domain, sampling_hz=s.sampling_hz, channel_count=s.channel_count,
                           resolution_bits=s.resolution_bits, assumed_specification=s.assumed,
                           in_reference_rtl=s.instantiated_in_reference_rtl, calibration_kinds=list(s.calibration))
                for s in state.manifest.sensors]

    @r.get("/sensors/health")
    def sensors_health():
        p = state.products()
        cal = p.calibrations.summary({s.key: list(s.calibration) for s in state.manifest.sensors})
        tel = state.instrument.last_telemetry
        h = assess({"host_lost": False, "err_total": 0}, None, cal, sequence_gaps=len(state.instrument.reader.gaps),
                   dma_drops=int(state.instrument.per_sensor.get("DMA_DROP", 0)))
        return js({"status": h.status, "items": h.items, "telemetry": tel, "data_origin": "simulated"})

    # ------------------------------------------------------------------ acquisition
    @r.post("/acquisition/start", response_model=AcquisitionStatus)
    async def acq_start(req: AcquisitionStartRequest):
        try:
            await state.instrument.start(req.sensors, req.line_rate_hz, req.duration_s)
        except ValueError as e:
            raise HTTPException(422, str(e))
        except RuntimeError as e:
            raise HTTPException(409, str(e))
        return AcquisitionStatus(**state.instrument.status())

    @r.post("/acquisition/stop", response_model=AcquisitionStatus)
    async def acq_stop():
        await state.instrument.stop()
        return AcquisitionStatus(**state.instrument.status())

    @r.get("/acquisition/status", response_model=AcquisitionStatus)
    def acq_status():
        return AcquisitionStatus(**state.instrument.status())

    # ------------------------------------------------------------------ spectral
    @r.get("/spectral/cube")
    def spectral_cube(band: int | None = Query(default=None, ge=0), wavelength_nm: float | None = None):
        p = state.products()
        c = p.hsi_cube
        wl = c.wavelength_nm
        b = int(np.argmin(np.abs(wl - wavelength_nm))) if wavelength_nm is not None else (band if band is not None else len(wl) // 2)
        if b >= len(wl):
            raise HTTPException(422, "band out of range")
        img = c.data.values[..., b]
        usable = water.usable_bands(wl, 2 * p.config.altitude_m, t_min=0.05)
        return js({"shape": list(c.shape), "wavelength_nm": wl, "band": b, "band_wavelength_nm": float(wl[b]),
                   "image": np.round(img, 4), "units": c.units, "usable_bands": usable,
                   "history": c.history, "provenance": json.loads(c.provenance.to_json()),
                   "data_origin": c.provenance.origin.value,
                   "label_map": p.hsi_labels, "label_names": p.hsi_label_names})

    @r.get("/spectral/scan")
    def spectral_scan(line: int = Query(ge=0), sample: int = Query(ge=0)):
        p = state.products()
        c = p.hsi_cube
        if line >= c.shape[0] or sample >= c.shape[1]:
            raise HTTPException(422, "pixel out of range")
        spec = c.data.values[line, sample]
        lib = parametric_vnir_library().resample(c.wavelength_nm)
        usable = water.usable_bands(c.wavelength_nm, 2 * p.config.altitude_m, t_min=0.05)
        ok = np.isfinite(spec)
        res = None
        if (ok & usable).sum() >= 3:
            res = classify_sam(np.nan_to_num(spec)[None], lib.spectra, lib.names, snr=60.0, usable=usable & ok,
                               max_angle=0.25, min_prob=0.3)
        return js({"line": line, "sample": sample, "wavelength_nm": c.wavelength_nm, "spectrum": spec,
                   "raw_codes": c.raw.values[line, sample], "valid": c.valid[line, sample], "usable_bands": usable,
                   "classification": None if res is None else
                   {"label": res.label_names()[0], "probabilities": dict(zip(res.classes, res.probabilities[0])),
                    "best_angle_rad": res.best_angle[0], "margin_rad": res.margin[0]},
                   "label_at_pixel": p.hsi_label_names[int(p.hsi_labels[line, sample])] if p.hsi_labels[line, sample] >= 0 else "unclassified",
                   "data_origin": "simulated"})

    @r.get("/spectral/raman/examples")
    def raman_examples():
        return js({"examples": state.products().raman_examples, "data_origin": "simulated"})

    @r.post("/minerals/classify")
    def minerals_classify(req: SpectrumRequest):
        if len(req.wavelength_nm) != len(req.reflectance):
            raise HTTPException(422, "wavelength and reflectance lengths differ")
        wl = np.asarray(req.wavelength_nm)
        try:
            usable = water.usable_bands(wl, 2 * req.altitude_m, t_min=0.05)
        except ValueError as e:
            raise HTTPException(422, str(e))
        lib = parametric_vnir_library().resample(wl)
        try:
            res = classify_sam(np.asarray(req.reflectance)[None], lib.spectra, lib.names, snr=req.snr, usable=usable)
        except ValueError as e:
            return js({"label": "unclassified", "reason": str(e), "usable_bands": usable})
        return js({"label": res.label_names()[0], "probabilities": dict(zip(res.classes, res.probabilities[0])),
                   "confidence": res.confidence[0], "usable_bands": usable, "library": lib.source,
                   "library_origin": lib.origin.value,
                   "note": "phase classification only; elemental grade requires XRF/ICP-MS assay"})

    # ------------------------------------------------------------------ carbon
    @r.post("/carbon/analyse")
    def carbon_analyse(req: CarbonAnalyseRequest):
        p = state.products()
        if req.target_id:
            for res in p.carbon_results:
                if res.target_id == req.target_id:
                    return js(res)
            raise HTTPException(404, f"no carbon target {req.target_id}")
        if not (req.raman_shift_cm1 and req.raman_light and req.raman_dark):
            raise HTTPException(422, "give target_id, or raman_shift_cm1 + raman_light + raman_dark")
        pr = process_raman(np.array(req.raman_light), np.array(req.raman_dark), np.array(req.raman_shift_cm1))
        res = CarbonCharacterisationEngine(n_mc=200).analyse(CarbonTarget("request", req.context, raman=pr))
        return js(res)

    @r.get("/carbon/map")
    def carbon_map():
        p = state.products()
        ds = p.seabed_map.layers
        layers = {k: ds[k].values for k in ds.data_vars if k.startswith("carbon_")}
        return js({"east": ds.east.values, "north": ds.north.values, "layers": layers,
                   "points": [{"target_id": r.target_id, "east_m": e, "north_m": n, "top_class": r.top_class,
                               "top_probability": r.top_probability, "organic_probability": r.organic_probability,
                               "quantitation_level": r.quantitation_level.value,
                               "class_probabilities": r.class_probabilities}
                              for r, (e, n) in zip(p.carbon_results, p.carbon_positions)],
                   "data_origin": "simulated"})

    # ------------------------------------------------------------------ nodules
    @r.get("/nodules")
    def nodules(limit: int = Query(default=500, ge=1, le=10000)):
        p = state.products()
        out = []
        for nid, rec in list(p.registry.records.items())[:limit]:
            ob = rec.observations[-1]
            ma = p.mineral_assessments[nid]
            out.append({"nodule_id": nid, "east_m": rec.east_m, "north_m": rec.north_m,
                        "diameter_m": ob.measurements["equivalent_diameter_m"]["value"],
                        "mass_g": ob.measurements["mass_g"]["value"], "top_class": ma.top_class,
                        "confidence": ma.confidence, "assays": rec.assay_sample_ids})
        return js({"count": len(p.registry), "nodules": out, "data_origin": "simulated"})

    @r.post("/nodules/detect")
    def nodules_detect(req: NoduleDetectRequest):
        p = state.products()
        d = detect_nodules(p.image, min_area_px=req.min_area_px, max_relative_darkness=req.max_relative_darkness,
                           min_seed_distance_px=req.min_seed_distance_px)
        v = p.validation["nodule_detection"]
        return js({"detected": d.n, "threshold": d.threshold, "image_shape": list(p.image.shape),
                   "survey_validation": v, "data_origin": "simulated"})

    @r.get("/nodules/{nodule_id}")
    def nodule(nodule_id: str):
        p = state.products()
        rec = p.registry.records.get(nodule_id)
        if rec is None:
            raise HTTPException(404, f"unknown nodule {nodule_id}")
        ma = p.mineral_assessments[nodule_id]
        return js({"record": rec.model_dump(mode="json"), "mineral_assessment": ma,
                   "grade_report": p.grade_reports[nodule_id].model_dump(mode="json"), "data_origin": "simulated"})

    # ------------------------------------------------------------------ sonar / EM / fusion / geology
    @r.get("/sonar/reconstruct")
    def sonar():
        ds = state.products().seabed_map.layers
        if "depth" not in ds:
            raise HTTPException(404, "no multibeam data in this survey")
        return js({"east": ds.east.values, "north": ds.north.values, "depth": ds["depth"].values,
                   "depth_std": ds["depth_std"].values if "depth_std" in ds else None,
                   "validation": state.products().validation.get("bathymetry"), "data_origin": "simulated"})

    @r.get("/electromagnetic/analyse")
    def em():
        e = state.products().emi
        return js({**e, "interpretation": "relative material contrast; not a carbon or grade measurement",
                   "data_origin": "simulated"})

    @r.post("/fusion/process")
    def fusion(req: FusionRequest):
        try:
            res = fuse([ChannelOpinion(o.channel, o.probabilities, o.quality, o.provenance_id) for o in req.opinions],
                       req.classes, expected_channels=req.expected_channels)
        except ValueError as e:
            raise HTTPException(422, str(e))
        return js(res)

    @r.get("/geology/map")
    def geology():
        p = state.products()
        return js({"map": frontend_payload(p.seabed_map), "statistics": survey_statistics(p.seabed_map),
                   "nodules": [{"id": nid, "e": rec.east_m, "n": rec.north_m,
                                "d": rec.observations[-1].measurements["equivalent_diameter_m"]["value"],
                                "c": p.mineral_assessments[nid].top_class} for nid, rec in p.registry.records.items()],
                   "carbon_points": [{"id": r.target_id, "e": e, "n": n, "c": r.top_class}
                                     for r, (e, n) in zip(p.carbon_results, p.carbon_positions)],
                   "data_origin": "simulated"})

    @r.get("/calibration")
    def calibration():
        p = state.products()
        recs = [rec.model_dump(mode="json") for rec in p.calibrations._records.values()]
        return js({"summary": p.calibrations.summary({s.key: list(s.calibration) for s in state.manifest.sensors}),
                   "records": recs})

    @r.get("/storage/status")
    def storage_status():
        state.products()
        return js({"database": state.db_status, "spool_dir": str(state.instrument.spool_dir),
                   "data_dir": str(state.data_dir)})

    @r.get("/validation")
    def validation():
        return js({"validation": state.products().validation, "timings_s": state.products().timings_s})

    @r.post("/export")
    def export(req: ExportRequest):
        p = state.products()
        m = p.seabed_map
        origin = (m.grid.origin_lat, m.grid.origin_lon, m.grid.origin_h)
        out = state.data_dir / "exports"
        out.mkdir(exist_ok=True)
        stamp = f"{p.survey_id}_{int(time.time() * 1000)}"
        if req.format == "geojson_nodules":
            rows = [{"nodule_id": nid, "east_m": rec.east_m, "north_m": rec.north_m,
                     "top_class": p.mineral_assessments[nid].top_class} for nid, rec in p.registry.records.items()]
            f = gx.nodules_geojson(rows, origin, out / f"{stamp}_nodules.geojson", data_origin="simulated")
        elif req.format == "geojson_track":
            if not m.tracks:
                raise HTTPException(404, "no survey track")
            t = m.tracks[0]
            f = gx.track_geojson(t[:, 0], t[:, 1], origin, out / f"{stamp}_track.geojson", data_origin="simulated")
        elif req.format == "esri_ascii":
            if req.layer not in m.layers:
                raise HTTPException(422, f"unknown layer {req.layer}")
            f = gx.esri_ascii(m.grid, m.layers[req.layer].values, out / f"{stamp}_{req.layer}.asc", data_origin="simulated")
        elif req.format == "ply":
            if "depth" not in m.layers:
                raise HTTPException(404, "no DEM")
            f = gx.ply_mesh(m.layers.east.values, m.layers.north.values, m.layers["depth"].values,
                            out / f"{stamp}_seabed.ply", comment="SIMULATED Aardvark Imaging seabed")
        elif req.format == "csv_nodules":
            rows = [{"nodule_id": nid, "east_m": rec.east_m, "north_m": rec.north_m, "data_origin": "simulated",
                     "diameter_m": rec.observations[-1].measurements["equivalent_diameter_m"]["value"],
                     "mass_g": rec.observations[-1].measurements["mass_g"]["value"]}
                    for nid, rec in p.registry.records.items()]
            f = gx.table_csv(rows, out / f"{stamp}_nodules.csv")
        elif req.format == "netcdf":
            f = gx.dataset_netcdf(m.layers, out / f"{stamp}_seabed.nc")
        else:
            f = out / f"{stamp}_map.json"
            f.write_text(json.dumps(_clean(frontend_payload(m))))
        return FileResponse(f, filename=f.name)

    app.include_router(r)

    # ------------------------------------------------------------------ websocket
    @app.websocket("/api/v1/stream/telemetry")
    async def telemetry(ws: WebSocket, api_key: str | None = None):
        if key and api_key != key:
            await ws.close(code=4401)
            return
        await ws.accept()
        q: asyncio.Queue = asyncio.Queue(maxsize=50)
        state.instrument.subscribers.add(q)
        try:
            await ws.send_json({"type": "hello", "api_version": "1.0.0", "data_origin": "simulated",
                                "status": state.instrument.status()})
            while True:
                try:
                    msg = await asyncio.wait_for(q.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    msg = {"type": "keepalive", **state.instrument.status()}
                await ws.send_json(_clean(msg))
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            state.instrument.subscribers.discard(q)

    @app.get("/healthz", include_in_schema=False)
    def healthz():
        return {"ok": True, "version": __version__}

    if FRONTEND.exists():
        app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
    return app
