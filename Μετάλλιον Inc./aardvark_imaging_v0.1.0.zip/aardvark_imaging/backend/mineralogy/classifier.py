"""Mineral intelligence: phase classification and host-phase associations.

Optical spectroscopy identifies *mineral phases* (with uncertainty). It does
not measure Ni, Cu, Co or Mn concentrations. The classifier therefore
reports, separately:

* phase-class probabilities (Mn oxide, Fe oxyhydroxide, silicate, carbonate,
  phosphate, sediment, biological, unclassified);
* the Mn-phase breakdown and a genetic indicator (diagenetic, todorokite /
  10-A manganate dominated vs hydrogenetic, vernadite dominated);
* *inferred host-phase associations*: in CCZ-type nodules Ni and Cu are
  hosted mainly by diagenetic 10-A manganates (todorokite/buserite) and Co by
  hydrogenetic vernadite/Fe-vernadite. These associations are qualitative
  and always flagged ``requires = [XRF, ICP-MS]``.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..spectral.raman import BandMatch
from .library import MN_PHASES, PHASE_TO_CLASS

PHASE_CLASSES = ["manganese_rich", "iron_oxyhydroxide", "silicate", "carbonate", "phosphate", "sediment",
                 "biological"]
RAMAN_PHASE_CLASS = {"calcite": "carbonate", "aragonite": "carbonate", "dolomite": "carbonate",
                     "rhodochrosite": "carbonate", "siderite": "carbonate", "apatite_cfa": "phosphate",
                     "quartz": "silicate", "goethite": "iron_oxyhydroxide", "hematite": "iron_oxyhydroxide",
                     "vernadite": "manganese_rich", "todorokite": "manganese_rich", "birnessite": "manganese_rich",
                     "barite": "sediment"}


@dataclass
class HostAssociation:
    element: str
    associated_phase: str
    likelihood: float
    basis: str
    quantitative: bool = False
    requires: tuple[str, ...] = ("XRF", "ICP-MS")


@dataclass
class MineralAssessment:
    class_probabilities: dict[str, float]
    top_class: str
    confidence: float
    mn_phase_probabilities: dict[str, float]
    genesis: dict[str, float]
    associations: list[HostAssociation]
    evidence: list[str] = field(default_factory=list)
    disagreements: list[str] = field(default_factory=list)


def _norm(d):
    s = sum(d.values()) or 1.0
    return {k: v / s for k, v in d.items()}


class MineralClassifier:
    def __init__(self, *, min_confidence: float = 0.5, raman_weight: float = 2.0):
        self.min_confidence = min_confidence
        self.raman_weight = raman_weight

    def assess(self, vnir_phase_probs: dict[str, float] | None = None, raman: list[BandMatch] | None = None,
               ir_carbonate_snr: float | None = None) -> MineralAssessment:
        evidence, disagreements = [], []
        logp = {c: 0.0 for c in PHASE_CLASSES}
        mn = {p: 1.0 for p in MN_PHASES}
        if vnir_phase_probs:
            agg = {c: 1e-3 for c in PHASE_CLASSES}
            for ph, p in vnir_phase_probs.items():
                c = PHASE_TO_CLASS.get(ph)
                if c in agg:
                    agg[c] += p
                if ph in mn:
                    mn[ph] += 2.0 * p
            agg = _norm(agg)
            for c in PHASE_CLASSES:
                logp[c] += np.log(agg[c])
            evidence.append("VNIR spectral angle classification")
        raman_cls = {}
        for m in raman or []:
            c = RAMAN_PHASE_CLASS.get(m.phase)
            if c is None:
                continue
            s = min(m.snr / 10.0, 1.0)
            raman_cls[c] = max(raman_cls.get(c, 0.0), s)
            if m.phase in mn:
                mn[m.phase] += 3.0 * s
        for c, s in raman_cls.items():
            logp[c] += self.raman_weight * s
            evidence.append(f"Raman band evidence for {c} (strength {s:.2f})")
        if ir_carbonate_snr is not None and ir_carbonate_snr > 3:
            logp["carbonate"] += min(ir_carbonate_snr / 10.0, 1.0)
            evidence.append("ATR-IR carbonate absorption")
        m = max(logp.values())
        probs = _norm({c: float(np.exp(v - m)) for c, v in logp.items()})
        if vnir_phase_probs and raman_cls:
            v_top = max((c for c in PHASE_CLASSES), key=lambda c: sum(p for ph, p in vnir_phase_probs.items()
                                                                      if PHASE_TO_CLASS.get(ph) == c))
            r_top = max(raman_cls, key=raman_cls.get)
            if v_top != r_top and raman_cls[r_top] > 0.5:
                disagreements.append(f"VNIR favours {v_top}, Raman favours {r_top}")
        top = max(probs, key=probs.get)
        conf = probs[top]
        if conf < self.min_confidence:
            top = "unclassified"
        mnp = _norm(mn)
        diag = mnp["todorokite"] + 0.5 * mnp["birnessite"]
        hydro = mnp["vernadite"] + 0.5 * mnp["birnessite"]
        genesis = _norm({"diagenetic": diag, "hydrogenetic": hydro})
        mn_presence = probs["manganese_rich"]
        assoc = [
            HostAssociation("Ni", "todorokite/10-A manganate", mn_presence * genesis["diagenetic"],
                            "Ni2+ substitution in diagenetic 10-A manganates (literature association)"),
            HostAssociation("Cu", "todorokite/10-A manganate", mn_presence * genesis["diagenetic"],
                            "Cu2+ in diagenetic 10-A manganates (literature association)"),
            HostAssociation("Co", "vernadite / Fe-vernadite", mn_presence * genesis["hydrogenetic"],
                            "oxidative Co3+ scavenging by hydrogenetic vernadite (literature association)"),
        ]
        return MineralAssessment(probs, top, float(conf), mnp, genesis, assoc, evidence, disagreements)
