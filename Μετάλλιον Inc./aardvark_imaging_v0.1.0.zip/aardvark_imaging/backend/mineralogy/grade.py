"""Assay-linked grade estimation, keeping every quantity separate.

=========================  ==============================================  ============
quantity                   source                                          origin
=========================  ==============================================  ============
spectral classification    VNIR/Raman/IR classifiers                       ESTIMATED
phase abundance            linear unmixing (areal, surface only)           ESTIMATED
elemental grade            linked laboratory assay, or a validated         LAB_VALIDATED /
                           assay-trained model inside its domain           ESTIMATED
mineralogical purity       XRD / quantitative mineralogy only              LAB_VALIDATED
physical nodule mass       volume model x bulk density                     ESTIMATED
recoverable metal content  mass x grade x recovery (if grade available)    ESTIMATED
=========================  ==============================================  ============

A spectral classification probability is never converted into a grade or a
purity.
"""
from __future__ import annotations

import csv
import zlib
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from ..analytics.splits import group_kfold
from ..core.provenance import DataOrigin, Estimate

ELEMENTS = ("Mn", "Ni", "Cu", "Co", "Fe")


class AssayRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")
    sample_id: str
    nodule_id: str | None = None
    laboratory: str
    method: str = Field(description="ICP-MS, ICP-OES, XRF (lab), ...")
    analysed: date
    wt_pct: dict[str, float]
    uncertainty_wt_pct: dict[str, float] = Field(default_factory=dict)
    moisture_basis: str = "dry"
    qa_flags: list[str] = Field(default_factory=list)


class XrdRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")
    sample_id: str
    nodule_id: str | None = None
    laboratory: str
    method: str = "XRD Rietveld"
    phase_wt_pct: dict[str, float]
    amorphous_wt_pct: float | None = None


def load_assays_csv(path: str | Path) -> list[AssayRecord]:
    """CSV columns: sample_id, nodule_id, laboratory, method, analysed (ISO date),
    then <El>_wt_pct and optional <El>_unc columns."""
    out = []
    with open(path, newline="") as fh:
        for row in csv.DictReader(fh):
            wt = {e: float(row[f"{e}_wt_pct"]) for e in ELEMENTS if row.get(f"{e}_wt_pct") not in (None, "")}
            unc = {e: float(row[f"{e}_unc"]) for e in ELEMENTS if row.get(f"{e}_unc") not in (None, "")}
            out.append(AssayRecord(sample_id=row["sample_id"], nodule_id=row.get("nodule_id") or None,
                                   laboratory=row["laboratory"], method=row["method"],
                                   analysed=date.fromisoformat(row["analysed"]), wt_pct=wt, uncertainty_wt_pct=unc))
    return out


@dataclass
class GradeCalibrationModel:
    """Linear model element grade ~ features (e.g. unmixed phase abundances,
    Raman Mn-phase indices) trained on assay-linked nodules with grouped CV."""
    element: str
    feature_names: list[str]
    min_samples: int = 30
    min_r2_cv: float = 0.6
    coef: np.ndarray | None = None
    rmsecv: float | None = None
    r2_cv: float | None = None
    domain_lo: np.ndarray | None = None
    domain_hi: np.ndarray | None = None
    validated: bool = False
    reasons: list[str] = field(default_factory=list)

    def fit(self, X, y, groups, k: int = 5) -> "GradeCalibrationModel":
        X = np.column_stack([np.asarray(X, dtype=float), np.ones(len(y))])
        y = np.asarray(y, dtype=float)
        g = np.asarray(groups)
        self.reasons = []
        if len(np.unique(g)) < self.min_samples:
            self.reasons.append(f"{len(np.unique(g))} assay-linked nodules < {self.min_samples}")
        pred = np.full(len(y), np.nan)
        for tr, te in group_kfold(g, k=min(k, max(2, len(np.unique(g)))), seed=1):
            c, *_ = np.linalg.lstsq(X[tr], y[tr], rcond=None)
            pred[te] = X[te] @ c
        r = pred - y
        self.rmsecv = float(np.sqrt(np.nanmean(r ** 2)))
        self.r2_cv = 1 - float(np.nansum(r ** 2)) / (float(np.sum((y - y.mean()) ** 2)) or 1e-12)
        if self.r2_cv < self.min_r2_cv:
            self.reasons.append(f"CV R2 {self.r2_cv:.2f} < {self.min_r2_cv}")
        self.coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        self.domain_lo, self.domain_hi = X[:, :-1].min(0), X[:, :-1].max(0)
        self.validated = not self.reasons
        return self

    def predict(self, x) -> tuple[Estimate | None, str]:
        if self.coef is None:
            return None, "not trained"
        if not self.validated:
            return None, "not validated: " + "; ".join(self.reasons)
        x = np.asarray(x, dtype=float)
        if np.any(x < self.domain_lo) or np.any(x > self.domain_hi):
            return None, "features outside the training range (extrapolation refused)"
        v = float(np.append(x, 1.0) @ self.coef)
        return Estimate(value=v, std=self.rmsecv, units="wt%", interval=(v - 1.96 * self.rmsecv, v + 1.96 * self.rmsecv),
                        origin=DataOrigin.ESTIMATED, method=f"assay-calibrated linear model (R2cv={self.r2_cv:.2f})"), "ok"


class GradeReport(BaseModel):
    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)
    nodule_id: str
    spectral_classification: dict[str, float]
    phase_abundance: dict[str, Estimate]
    elemental_grade: dict[str, Estimate | None]
    elemental_grade_basis: dict[str, str]
    mineralogical_purity: dict[str, float] | None
    purity_basis: str
    physical_mass_g: Estimate | None
    recoverable_metal_g: dict[str, Estimate | None]
    notes: list[str]


class GradeEngine:
    def __init__(self, *, recovery: dict[str, float] | None = None, models: dict[str, GradeCalibrationModel] | None = None):
        self.recovery = recovery or {}
        self.models = models or {}

    def report(self, *, nodule_id: str, classification: dict[str, float], abundances: dict[str, tuple[float, float]],
               mass_g: Estimate | None, assays: list[AssayRecord] = (), xrd: list[XrdRecord] = (),
               model_features: Any = None) -> GradeReport:
        notes = ["phase abundances are areal surface fractions from unmixing, not volumetric or mass fractions"]
        ab = {k: Estimate(value=v, std=s, units="areal fraction", origin=DataOrigin.ESTIMATED, method="FCLS unmixing")
              for k, (v, s) in abundances.items()}
        grade: dict[str, Estimate | None] = {}
        basis: dict[str, str] = {}
        linked = [a for a in assays if a.nodule_id == nodule_id]
        for el in ELEMENTS:
            vals = [a for a in linked if el in a.wt_pct]
            if vals:
                v = float(np.mean([a.wt_pct[el] for a in vals]))
                u = float(np.sqrt(np.mean([a.uncertainty_wt_pct.get(el, 0.0) ** 2 for a in vals])))
                grade[el] = Estimate(value=v, std=u or None, units="wt% (dry)", origin=DataOrigin.LAB_VALIDATED,
                                     method=", ".join(sorted({f"{a.method} @ {a.laboratory}" for a in vals})))
                basis[el] = f"linked assay ({len(vals)} analyses)"
            elif el in self.models and model_features is not None:
                est, why = self.models[el].predict(model_features)
                grade[el] = est
                basis[el] = "assay-calibrated model" if est else f"not reported: {why}"
            else:
                grade[el] = None
                basis[el] = "not reported: no linked assay and no validated assay-calibrated model"
        x = [r for r in xrd if r.nodule_id == nodule_id]
        purity = x[0].phase_wt_pct if x else None
        pbasis = f"XRD ({x[0].laboratory})" if x else "not reported: requires XRD / quantitative mineralogy"
        recov: dict[str, Estimate | None] = {}
        for el in ELEMENTS:
            g = grade.get(el)
            r = self.recovery.get(el)
            if g is None or mass_g is None or r is None:
                recov[el] = None
                continue
            rng = np.random.default_rng(zlib.crc32(f"{nodule_id}:{el}".encode()))
            m = rng.normal(mass_g.value, mass_g.std or 0.0, 4000)
            gg = rng.normal(g.value, g.std or 0.0, 4000)
            recov[el] = Estimate.from_samples(m * gg / 100.0 * r, units="g", method="Monte Carlo mass x grade x recovery")
        if mass_g is not None:
            notes.append("mass from ellipsoid volume model x literature wet bulk density; validate with weighed samples")
        return GradeReport(nodule_id=nodule_id, spectral_classification=dict(classification), phase_abundance=ab,
                           elemental_grade=grade, elemental_grade_basis=basis, mineralogical_purity=purity,
                           purity_basis=pbasis, physical_mass_g=mass_g, recoverable_metal_g=recov, notes=notes)
