"""Reference spectral libraries.

* :func:`parametric_vnir_library` — SIMULATED parametric reflectance spectra
  that reproduce the qualitative VNIR behaviour of nodule-related phases
  (dark, near-featureless Mn oxides; Fe3+ charge-transfer edge and ~900 nm
  crystal-field band of goethite; bright carbonate/clay; chlorophyll
  absorption of biological material). They are for simulation and software
  testing only and MUST be replaced by measured spectra (USGS splib07,
  RELAB, or Metallion's own laboratory measurements of CCZ samples).
* Importers for the USGS splib07 ASCII format and RRUFF Raman files.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from ..core.provenance import DataOrigin

MN_PHASES = ("vernadite", "todorokite", "birnessite")
PHASE_TO_CLASS = {
    "vernadite": "manganese_rich", "todorokite": "manganese_rich", "birnessite": "manganese_rich",
    "goethite": "iron_oxyhydroxide", "smectite": "silicate", "calcite": "carbonate", "cfa": "phosphate",
    "sediment": "sediment", "biological": "biological",
}
TARGET_CLASSES = ["manganese_rich", "nickel_bearing", "copper_bearing", "cobalt_bearing", "iron_oxyhydroxide",
                  "silicate", "carbonate", "phosphate", "sediment", "biological", "unclassified"]


@dataclass
class SpectralLibrary:
    wavelength_nm: np.ndarray
    names: list[str]
    spectra: np.ndarray                     # members x bands
    origin: DataOrigin
    source: str
    notes: list[str] = field(default_factory=list)

    def resample(self, wavelength_nm) -> "SpectralLibrary":
        wl = np.asarray(wavelength_nm, dtype=float)
        sp = np.array([np.interp(wl, self.wavelength_nm, s) for s in self.spectra])
        return SpectralLibrary(wl, list(self.names), sp, self.origin, self.source, self.notes + ["linear resample"])

    def get(self, name: str) -> np.ndarray:
        return self.spectra[self.names.index(name)]

    def classes(self) -> list[str]:
        return [PHASE_TO_CLASS.get(n, n) for n in self.names]


def _g(wl, c, w, d):
    return d * np.exp(-0.5 * ((wl - c) / w) ** 2)


def parametric_vnir_library(wavelength_nm=None) -> SpectralLibrary:
    wl = np.arange(400.0, 1701.0, 5.0) if wavelength_nm is None else np.asarray(wavelength_nm, dtype=float)
    x = (wl - 400.0) / 1300.0
    S = {}
    S["vernadite"] = 0.045 + 0.012 * x
    S["todorokite"] = 0.050 + 0.030 * x - _g(wl, 520, 60, 0.006)
    S["birnessite"] = 0.060 + 0.020 * x - _g(wl, 480, 50, 0.008)
    edge = 1 / (1 + np.exp(-(wl - 560) / 30))
    S["goethite"] = 0.07 + 0.25 * edge - _g(wl, 650, 40, 0.03) - _g(wl, 920, 90, 0.09)
    S["smectite"] = 0.42 + 0.10 * x - _g(wl, 1410, 40, 0.12) - _g(wl, 950, 120, 0.02)
    S["calcite"] = 0.78 + 0.04 * x - _g(wl, 1440, 60, 0.05)
    S["cfa"] = 0.55 + 0.05 * x - _g(wl, 1420, 50, 0.05)
    S["sediment"] = 0.12 + 0.18 * edge * (0.6 + 0.4 * x) - _g(wl, 900, 100, 0.03) - _g(wl, 1410, 40, 0.05)
    S["biological"] = 0.08 + 0.35 / (1 + np.exp(-(wl - 705) / 12)) - _g(wl, 675, 15, 0.05) - _g(wl, 480, 35, 0.04)
    names = list(S)
    sp = np.clip(np.array([S[n] for n in names]), 0.005, 1.0)
    return SpectralLibrary(wl, names, sp, DataOrigin.SIMULATED, "aardvark parametric VNIR library v1",
                           ["parametric approximation for simulation; not a measured library"])


def load_usgs_splib07_ascii(spectrum_path: str | Path, wavelength_path: str | Path, name: str | None = None):
    """USGS splib07a ASCII: one header line, then one value per line;
    wavelengths (micrometres) are in a separate file of the same layout.
    Deleted channels (-1.23e34) become NaN."""
    def read(p):
        lines = Path(p).read_text().splitlines()[1:]
        v = np.array([float(l.split()[0]) for l in lines if l.strip()])
        return np.where(v < -1e30, np.nan, v)
    wl = read(wavelength_path) * 1000.0
    refl = read(spectrum_path)
    if wl.size != refl.size:
        raise ValueError("spectrum and wavelength files differ in length")
    nm = name or Path(spectrum_path).stem
    return wl, refl, nm


def load_rruff_raman(path: str | Path) -> dict:
    """RRUFF processed Raman file: '##KEY=value' header lines then 'x, y' pairs."""
    meta, xs, ys = {}, [], []
    for ln in Path(path).read_text().splitlines():
        ln = ln.strip()
        if not ln:
            continue
        if ln.startswith("##"):
            if "=" in ln:
                k, v = ln[2:].split("=", 1)
                meta[k.strip()] = v.strip()
            continue
        parts = [p for p in ln.replace(",", " ").split() if p]
        if len(parts) >= 2:
            xs.append(float(parts[0]))
            ys.append(float(parts[1]))
    if not xs:
        raise ValueError(f"{path}: no data points")
    return {"shift_cm1": np.array(xs), "intensity": np.array(ys), "meta": meta,
            "name": meta.get("NAMES", Path(path).stem)}
