"""Command-line interface: ``aardvark <command>``.

    aardvark sf validate|generate|check|budget   Silica Flux manifest tooling
    aardvark simulate --seed N --out DIR         run a simulated survey, write products
    aardvark decode RING.hex                     decode an SFP1 word dump
    aardvark spool-recover DIR                   repair torn records after power loss
    aardvark serve [--host --port]               run the API + workstation
    aardvark snapshot --out FILE                 offline workstation snapshot (JSON)
    aardvark benchmark                           measured timings on this machine
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _sf(args) -> int:
    from .silica_flux import budget_markdown, check_up_to_date, compute_budget, generate, load_manifest
    m = load_manifest(args.manifest)
    if args.action == "validate":
        print(f"OK: {m.instrument['id']} — {len(m.expanded())} registers, {len(m.sensors)} sensors, "
              f"{len(m.clock_domains)} clock domains")
    elif args.action == "generate":
        for p in generate(args.manifest):
            print(p)
    elif args.action == "check":
        stale = check_up_to_date(args.manifest)
        for p in stale:
            print(f"STALE {p}")
        return 1 if stale else 0
    elif args.action == "budget":
        print(budget_markdown(compute_budget(m)))
    return 0


def _simulate(args) -> int:
    from .geospatial import export as gx
    from .simulation.survey import SurveyConfig, fast_config, run_survey
    from .storage.cube_store import save_zarr
    cfg = fast_config(args.seed) if args.fast else SurveyConfig(seed=args.seed)
    p = run_survey(cfg)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "summary.json").write_text(json.dumps(p.summary(), indent=2, default=float))
    save_zarr(p.hsi_cube, out / "hsi_cube.zarr")
    m = p.seabed_map
    origin = (m.grid.origin_lat, m.grid.origin_lon, m.grid.origin_h)
    rows = [{"nodule_id": nid, "east_m": r.east_m, "north_m": r.north_m} for nid, r in p.registry.records.items()]
    gx.nodules_geojson(rows, origin, out / "nodules.geojson", data_origin="simulated")
    gx.dataset_netcdf(m.layers, out / "seabed_layers.nc")
    print(json.dumps(p.summary()["validation"]["nodule_detection"], indent=1))
    print(f"products written to {out} (all SIMULATED)")
    return 0


def _decode(args) -> int:
    import numpy as np
    from .acquisition import sfp
    words = np.array([int(x, 16) for x in Path(args.file).read_text().split()], dtype=np.uint32)
    res = sfp.decode_words(words)
    from collections import Counter
    c = Counter(p.type_name for p in res.packets)
    print(json.dumps({"packets": len(res.packets), "errors": [e.__dict__ for e in res.errors],
                      "sequence_gaps": res.sequence_gaps(), "by_type": c,
                      "simulated": sum(p.simulated for p in res.packets)}, indent=1))
    return 0 if not res.errors else 1


def _recover(args) -> int:
    from .acquisition.spool import recover_segment
    for seg in sorted(Path(args.dir).glob("raw_*.sfp")):
        print(f"{seg.name}: {recover_segment(seg)} intact records")
    return 0


def _serve(args) -> int:
    import uvicorn
    from .api.app import create_app
    uvicorn.run(create_app(seed=args.seed), host=args.host, port=args.port, log_level="info")
    return 0


def _snapshot(args) -> int:
    from .api.app import create_app
    from fastapi.testclient import TestClient
    app = create_app(seed=args.seed)
    snap = {}
    with TestClient(app) as c:
        for k, path in {"status": "/api/v1/system/status", "sensors": "/api/v1/sensors", "health": "/api/v1/sensors/health",
                        "acquisition": "/api/v1/acquisition/status", "cube": "/api/v1/spectral/cube",
                        "carbon": "/api/v1/carbon/map", "nodules": "/api/v1/nodules", "geology": "/api/v1/geology/map",
                        "calibration": "/api/v1/calibration", "validation": "/api/v1/validation",
                        "raman": "/api/v1/spectral/raman/examples", "em": "/api/v1/electromagnetic/analyse"}.items():
            snap[k] = c.get(path).json()
        nodes = snap["nodules"]["nodules"][: args.nodule_details]
        snap["nodule_details"] = {n["nodule_id"]: c.get(f"/api/v1/nodules/{n['nodule_id']}").json() for n in nodes}
        scans = {}
        shape = snap["cube"]["shape"]
        for (li, si) in [(shape[0] // 3, shape[1] // 3), (shape[0] // 2, shape[1] // 2), (2 * shape[0] // 3, shape[1] // 4)]:
            scans[f"{li},{si}"] = c.get(f"/api/v1/spectral/scan?line={li}&sample={si}").json()
        snap["scans"] = scans
        snap["carbon_details"] = {pt["target_id"]: c.post("/api/v1/carbon/analyse", json={"target_id": pt["target_id"]}).json()
                                  for pt in snap["carbon"]["points"]}
        # whole cube, 8-bit display quantisation per band (band-interleaved-by-pixel)
        import base64
        import numpy as np
        cube = app.state.aardvark.products().hsi_cube.data.values
        lo = np.nanmin(cube, axis=(0, 1)); hi = np.nanmax(cube, axis=(0, 1))
        q = np.where(np.isfinite(cube), np.round((cube - lo) / np.maximum(hi - lo, 1e-12) * 254), 255).astype(np.uint8)
        snap["cube_q"] = {"shape": list(cube.shape), "lo": lo.tolist(), "hi": hi.tolist(), "nan_code": 255,
                          "layout": "line,sample,band uint8; value = lo + q/254*(hi-lo)",
                          "note": "8-bit display quantisation of the SIMULATED reflectance cube; use the live API for full precision",
                          "b64": base64.b64encode(q.tobytes()).decode()}
    snap["snapshot_note"] = "Offline snapshot of a SIMULATED survey for the workstation demo mode."
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(snap, separators=(",", ":"))
    out.write_text(text)
    # same data as a classic script so the workstation also opens from file:// (no fetch of local files there)
    out.with_suffix(".js").write_text("window.AARDVARK_SNAPSHOT=" + text + ";\n")
    print(f"wrote {out} and {out.with_suffix('.js')} ({out.stat().st_size / 1e6:.1f} MB each)")
    return 0


def _benchmark(args) -> int:
    import platform
    import time
    import numpy as np
    from .acquisition import sfp
    from .simulation.survey import fast_config, run_survey
    t = time.perf_counter()
    p = run_survey(fast_config(args.seed))
    total = time.perf_counter() - t
    pk = [sfp.encode_packet(sensor_uid=0x10, packet_type=1, flags=0x40, seq=i, frame=i, timestamp=i, row=0, meta=0,
                            payload=np.arange(480, dtype=np.uint32)) for i in range(2000)]
    words = np.concatenate(pk)
    t = time.perf_counter()
    res = sfp.decode_words(words)
    dt = time.perf_counter() - t
    print(json.dumps({"machine": platform.platform(), "python": platform.python_version(),
                      "survey_total_s": total, "survey_stages_s": p.timings_s,
                      "sfp_decode_MB_per_s": words.nbytes / dt / 1e6, "sfp_packets": len(res.packets),
                      "note": "measured on this machine; not representative of instrument hardware"}, indent=1, default=float))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="aardvark", description="Aardvark Imaging instrument software")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("sf")
    s.add_argument("action", choices=["validate", "generate", "check", "budget"])
    s.add_argument("--manifest", default=None)
    s.set_defaults(fn=_sf)
    s = sub.add_parser("simulate")
    s.add_argument("--seed", type=int, default=21)
    s.add_argument("--out", default="sim_output")
    s.add_argument("--fast", action="store_true")
    s.set_defaults(fn=_simulate)
    s = sub.add_parser("decode")
    s.add_argument("file")
    s.set_defaults(fn=_decode)
    s = sub.add_parser("spool-recover")
    s.add_argument("dir")
    s.set_defaults(fn=_recover)
    s = sub.add_parser("serve")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8000)
    s.add_argument("--seed", type=int, default=21)
    s.set_defaults(fn=_serve)
    s = sub.add_parser("snapshot")
    s.add_argument("--out", default="frontend/assets/snapshot.json")
    s.add_argument("--seed", type=int, default=21)
    s.add_argument("--nodule-details", type=int, default=40)
    s.set_defaults(fn=_snapshot)
    s = sub.add_parser("benchmark")
    s.add_argument("--seed", type=int, default=21)
    s.set_defaults(fn=_benchmark)
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
