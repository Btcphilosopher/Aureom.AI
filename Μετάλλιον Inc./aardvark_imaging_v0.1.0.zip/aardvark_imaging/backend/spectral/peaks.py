"""Peak detection and multi-peak fitting with parameter uncertainties."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import least_squares
from scipy.signal import find_peaks

from .noise import noise_sigma


def gaussian(x, a, x0, fwhm):
    s = fwhm / 2.354820045
    return a * np.exp(-0.5 * ((x - x0) / s) ** 2)


def lorentzian(x, a, x0, fwhm):
    g = fwhm / 2.0
    return a * g ** 2 / ((x - x0) ** 2 + g ** 2)


def pseudo_voigt(x, a, x0, fwhm, eta):
    return eta * lorentzian(x, a, x0, fwhm) + (1 - eta) * gaussian(x, a, x0, fwhm)


SHAPES = {"gaussian": (gaussian, 3), "lorentzian": (lorentzian, 3), "pseudo_voigt": (pseudo_voigt, 4)}


@dataclass
class PeakFit:
    shape: str
    params: np.ndarray          # (n_peaks, n_par)
    stderr: np.ndarray          # (n_peaks, n_par)
    offset: float
    residual_rms: float
    success: bool
    message: str = ""
    areas: np.ndarray = field(default_factory=lambda: np.empty(0))

    @property
    def centers(self):
        return self.params[:, 1]

    @property
    def heights(self):
        return self.params[:, 0]

    @property
    def fwhms(self):
        return self.params[:, 2]


def detect_peaks(x, y, *, snr: float = 5.0, min_distance: float | None = None, sigma: float | None = None):
    """Peak indices whose prominence exceeds ``snr`` times the noise sigma."""
    y = np.asarray(y, dtype=float)
    sigma = noise_sigma(y) if sigma is None else sigma
    dist = None
    if min_distance is not None and len(x) > 1:
        dist = max(1, int(round(min_distance / abs(x[1] - x[0]))))
    idx, props = find_peaks(y, prominence=max(snr * sigma, 1e-12), distance=dist)
    return idx, props, sigma


def _area(shape, p):
    a, fwhm = p[0], p[2]
    if shape == "gaussian":
        return a * fwhm * np.sqrt(np.pi / (4 * np.log(2)))
    if shape == "lorentzian":
        return a * np.pi * fwhm / 2
    eta = p[3]
    return eta * a * np.pi * fwhm / 2 + (1 - eta) * a * fwhm * np.sqrt(np.pi / (4 * np.log(2)))


def fit_peaks(x, y, initial, *, shape: str = "lorentzian", fit_offset: bool = True, bounds_x0: float = 30.0,
              fwhm_range: tuple[float, float] = (2.0, 400.0), sigma: np.ndarray | float | None = None) -> PeakFit:
    """Least-squares fit of a sum of peaks.

    ``initial`` is a list of (height, center, fwhm[, eta]) guesses. Standard
    errors come from the Jacobian covariance scaled by the reduced chi-square.
    """
    f, npar = SHAPES[shape]
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    init = []
    lo, hi = [], []
    for g in initial:
        g = list(g) + ([0.5] if shape == "pseudo_voigt" and len(g) == 3 else [])
        init += g[:npar]
        lo += [0.0, g[1] - bounds_x0, fwhm_range[0]] + ([0.0] if npar == 4 else [])
        hi += [np.inf, g[1] + bounds_x0, fwhm_range[1]] + ([1.0] if npar == 4 else [])
    if fit_offset:
        init.append(float(np.percentile(y, 5)))
        lo.append(-np.inf)
        hi.append(np.inf)
    w = 1.0 / np.asarray(sigma if sigma is not None else 1.0, dtype=float)
    n = len(initial)

    def model(p):
        m = np.full_like(x, p[-1] if fit_offset else 0.0)
        for k in range(n):
            m += f(x, *p[k * npar:(k + 1) * npar])
        return m

    init_a = np.clip(np.array(init, dtype=float), np.array(lo) + 1e-9, np.array(hi) - 1e-9)
    r = least_squares(lambda p: (model(p) - y) * w, init_a, bounds=(lo, hi), x_scale="jac", max_nfev=5000)
    dof = max(1, x.size - r.x.size)
    chi2 = float(np.sum(r.fun ** 2)) / dof
    try:
        cov = np.linalg.pinv(r.jac.T @ r.jac) * chi2
        se = np.sqrt(np.clip(np.diag(cov), 0, None))
    except np.linalg.LinAlgError:
        se = np.full(r.x.size, np.nan)
    pk = r.x[: n * npar].reshape(n, npar)
    pse = se[: n * npar].reshape(n, npar)
    resid = model(r.x) - y
    areas = np.array([_area(shape, p) for p in pk])
    return PeakFit(shape, pk, pse, float(r.x[-1]) if fit_offset else 0.0, float(np.sqrt(np.mean(resid ** 2))),
                   bool(r.success), r.message, areas)
