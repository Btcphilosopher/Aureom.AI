"""Raman spectrum processing and band assignment.

Pipeline: dark subtraction -> cosmic-ray removal -> intensity-response
correction -> baseline (fluorescence) removal -> noise propagation -> band
detection / Lorentzian fitting -> assignment to reference bands.

Reference band positions (cm^-1) are literature values for the phases
relevant to polymetallic nodules and their sediments; widths are typical
for ~5 cm^-1 instrument resolution. Mn-oxide Raman bands are weak and
broad and easily damaged by laser heating — assignments to Mn phases are
therefore reported with lower prior confidence.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .baseline import als_baseline
from .cosmic import remove_spikes_multi, remove_spikes_single
from .peaks import detect_peaks, fit_peaks

# phase -> list of (shift_cm1, relative_intensity, typical_fwhm_cm1)
RAMAN_REFERENCE: dict[str, list[tuple[float, float, float]]] = {
    "calcite": [(1086.0, 1.0, 4.0), (712.0, 0.15, 4.0), (282.0, 0.25, 8.0), (156.0, 0.2, 6.0)],
    "aragonite": [(1085.0, 1.0, 4.0), (705.0, 0.08, 3.0), (701.0, 0.06, 3.0), (206.0, 0.2, 6.0), (153.0, 0.25, 6.0)],
    "dolomite": [(1097.0, 1.0, 5.0), (725.0, 0.12, 5.0), (300.0, 0.2, 8.0), (176.0, 0.2, 8.0)],
    "rhodochrosite": [(1085.0, 1.0, 6.0), (718.0, 0.12, 6.0), (289.0, 0.2, 10.0)],
    "siderite": [(1088.0, 1.0, 6.0), (731.0, 0.1, 6.0), (287.0, 0.2, 10.0)],
    "apatite_cfa": [(965.0, 1.0, 8.0), (1075.0, 0.1, 10.0), (590.0, 0.1, 10.0), (430.0, 0.1, 10.0)],
    "quartz": [(464.0, 1.0, 8.0), (206.0, 0.3, 10.0), (128.0, 0.3, 8.0)],
    "goethite": [(385.0, 1.0, 15.0), (299.0, 0.4, 15.0), (243.0, 0.3, 12.0), (481.0, 0.25, 20.0), (550.0, 0.2, 25.0)],
    "hematite": [(226.0, 0.8, 8.0), (292.0, 1.0, 10.0), (411.0, 0.4, 12.0), (498.0, 0.15, 15.0), (612.0, 0.2, 20.0),
                 (1320.0, 0.5, 60.0)],
    "vernadite": [(580.0, 0.6, 45.0), (640.0, 1.0, 45.0)],
    "todorokite": [(635.0, 1.0, 35.0), (575.0, 0.5, 35.0), (350.0, 0.2, 30.0)],
    "birnessite": [(575.0, 1.0, 35.0), (500.0, 0.4, 35.0), (640.0, 0.6, 35.0)],
    "barite": [(988.0, 1.0, 5.0), (462.0, 0.2, 6.0), (453.0, 0.2, 6.0)],
    "seawater_sulfate": [(981.0, 1.0, 10.0)],
    "water": [(1640.0, 1.0, 100.0), (3250.0, 0.7, 250.0), (3420.0, 1.0, 200.0)],
    "carbonaceous_D1": [(1350.0, 1.0, 60.0)],
    "carbonaceous_G": [(1585.0, 1.0, 40.0)],
}
LOW_CONFIDENCE_PHASES = {"vernadite", "todorokite", "birnessite"}


@dataclass
class ProcessedRaman:
    shift_cm1: np.ndarray
    signal: np.ndarray            # baseline-removed, response-corrected counts
    baseline: np.ndarray          # fluorescence + broad background
    sigma: np.ndarray             # per-pixel 1-sigma noise of ``signal``
    spikes: np.ndarray            # mask of replaced cosmic-ray pixels
    fluorescence_ratio: float     # baseline area / band area (0 = no background)
    sulfate_area: float | None    # in-situ internal standard
    notes: list[str] = field(default_factory=list)

    @property
    def snr(self) -> np.ndarray:
        return self.signal / np.maximum(self.sigma, 1e-9)


def process_raman(light, dark, shift_cm1, *, read_noise: float = 4.0, gain_e_per_count: float = 1.0,
                  response=None, als_lam: float = 1e5, als_p: float = 0.005) -> ProcessedRaman:
    """``light``/``dark``: 1-D co-added spectra or 2-D stacks (frames x pixels)."""
    shift = np.asarray(shift_cm1, dtype=float)
    L = np.atleast_2d(np.asarray(light, dtype=float))
    D = np.atleast_2d(np.asarray(dark, dtype=float))
    notes: list[str] = []
    if L.shape[0] >= 3:
        Lc, spk = remove_spikes_multi(L, read_noise=read_noise)
        spikes = spk.any(0)
        notes.append(f"multi-frame cosmic-ray removal over {L.shape[0]} frames")
    else:
        Lc = L.copy()
        spikes = np.zeros(L.shape[1], dtype=bool)
        for i in range(L.shape[0]):
            Lc[i], s = remove_spikes_single(L[i])
            spikes |= s
        notes.append("single-spectrum cosmic-ray removal (no repeats available)")
    light_sum = Lc.sum(0)
    dark_sum = D.mean(0) * L.shape[0]
    net = light_sum - dark_sum
    var = (np.maximum(light_sum, 0) + np.maximum(dark_sum, 0) / max(D.shape[0], 1) * L.shape[0]) / gain_e_per_count \
        + (L.shape[0] + L.shape[0] ** 2 / max(D.shape[0], 1)) * read_noise ** 2
    sigma = np.sqrt(np.maximum(var, 0))
    if response is not None:
        r = np.interp(shift, response.shift_cm1, response.response)
        net = net / r
        sigma = sigma / r
        notes.append(f"intensity response corrected ({response.certificate})")
    base = als_baseline(net, lam=als_lam, p=als_p)
    sig = net - base
    band_area = float(np.trapezoid(np.clip(sig, 0, None), shift)) or 1e-9
    fl_ratio = float(np.trapezoid(np.clip(base, 0, None), shift)) / band_area
    sulf = None
    sel = (shift > 960) & (shift < 1000)
    if sel.sum() >= 3:
        a = float(np.trapezoid(np.clip(sig[sel], 0, None), shift[sel]))
        if a > 3 * float(np.sqrt(np.sum(sigma[sel] ** 2))) * abs(shift[1] - shift[0]):
            sulf = a
    return ProcessedRaman(shift, sig, base, sigma, spikes, fl_ratio, sulf, notes)


@dataclass
class BandMatch:
    phase: str
    reference_cm1: float
    observed_cm1: float
    delta_cm1: float
    height: float
    height_se: float
    fwhm: float
    area: float
    snr: float


def _half_max_width(x, y, i) -> float:
    h = y[i] / 2.0
    l = i
    while l > 0 and y[l] > h:
        l -= 1
    r = i
    while r < y.size - 1 and y[r] > h:
        r += 1
    xl = np.interp(h, [y[l], y[l + 1]], [x[l], x[l + 1]]) if y[l + 1] != y[l] else x[l]
    xr = np.interp(h, [y[r], y[r - 1]], [x[r], x[r - 1]]) if y[r - 1] != y[r] else x[r]
    return float(abs(xr - xl))


def assign_bands(pr: ProcessedRaman, *, snr: float = 5.0, tolerance_cm1: float = 8.0,
                 window: tuple[float, float] = (120.0, 1800.0), fit: bool = False) -> list[BandMatch]:
    """Detect bands and assign each to the closest reference band within
    ``tolerance_cm1`` (2x for the broad Mn-oxide bands).

    Band parameters come from a parabolic centre, the peak height and the
    half-maximum width (fast, robust); ``fit=True`` refines them with a
    Lorentzian least-squares fit and Jacobian uncertainties.
    """
    x, y = pr.shift_cm1, pr.signal
    sel = (x >= window[0]) & (x <= window[1])
    xs, ys = x[sel], y[sel]
    idx, props, sig = detect_peaks(xs, ys, snr=snr, sigma=float(np.median(pr.sigma[sel])))
    out: list[BandMatch] = []
    for i in idx:
        if 0 < i < xs.size - 1:
            den = ys[i - 1] - 2 * ys[i] + ys[i + 1]
            frac = 0.5 * (ys[i - 1] - ys[i + 1]) / den if den != 0 else 0.0
        else:
            frac = 0.0
        xc = float(np.interp(i + frac, np.arange(xs.size), xs))
        h, fw, hse = float(ys[i]), _half_max_width(xs, ys, i), float(sig)
        area = np.pi * h * fw / 2
        if fit:
            w = (xs > xc - 60) & (xs < xc + 60)
            try:
                f = fit_peaks(xs[w], ys[w], [(max(h, 1e-6), xc, max(fw, 4.0))], shape="lorentzian", bounds_x0=15.0)
                h, xc, fw = (float(v) for v in f.params[0])
                hse, area = float(f.stderr[0, 0]), float(f.areas[0])
            except Exception:
                pass
        best = None
        for phase, bands in RAMAN_REFERENCE.items():
            for ref, _, _ in bands:
                tol = tolerance_cm1 * (2 if phase in LOW_CONFIDENCE_PHASES else 1)
                d = xc - ref
                if abs(d) <= tol and (best is None or abs(d) < abs(best[2])):
                    best = (phase, ref, d)
        if best:
            out.append(BandMatch(best[0], best[1], xc, float(best[2]), h, hse, fw, float(area), float(h / max(sig, 1e-9))))
    return out
