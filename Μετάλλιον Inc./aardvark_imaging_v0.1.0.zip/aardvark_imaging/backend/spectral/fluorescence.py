"""Pulsed-LED fluorometer processing and biological-interference classification.

Three excitation x three emission channels:
    ex 280 / em 340  protein-like (tryptophan) — fresh biomass, microbial films
    ex 365 / em 450  humic-like (CDOM)        — degraded / refractory organics
    ex 450 / em 685  chlorophyll a            — fresh phytodetritus
The on-minus-off difference removes ambient light and detector offset.
Values are relative fluorescence units normalised to the LED power monitor and
a reference target unless an equivalent-unit calibration (QSE, chl-a) exists.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

EXCITATION_NM = (280, 365, 450)
EMISSION_NM = (340, 450, 685)
PAIRS = {"protein_like": (0, 0), "humic_like": (1, 1), "chlorophyll": (2, 2)}


@dataclass
class FluorescenceResult:
    net_per_sample: np.ndarray   # 3x3 mean (on - off) per kept sample
    se: np.ndarray               # 3x3 standard error
    snr: np.ndarray
    indices: dict[str, float]    # normalised channel values
    index_snr: dict[str, float]
    interference: dict[str, float]   # class probabilities
    raman_background_risk: bool
    units: str


def net_fluorescence(diff, off, *, npulses: int, kept_per_window: int, adc_noise_codes: float = 2.0,
                     gain_e_per_code: float = 1.0, led_power=None, cal_factors=None,
                     background_stability: float = 0.02) -> FluorescenceResult:
    """Net on-off fluorescence per sample with statistical *and* systematic
    uncertainty. ``background_stability`` is the relative stability of the
    off-level (ambient, detector offset, LED leakage) between on and off
    windows; it sets a detection floor that averaging cannot beat, so long
    integrations do not turn tiny systematic offsets into "detections"."""
    d = np.asarray(diff, dtype=float)
    o = np.asarray(off, dtype=float)
    n = npulses * kept_per_window
    net = d / n
    on_mean = (d + o) / n
    off_mean = o / n
    var = (np.maximum(on_mean, 0) + np.maximum(off_mean, 0)) / gain_e_per_code + 2 * adc_noise_codes ** 2
    se = np.sqrt(var / n + (background_stability * off_mean) ** 2)
    units = "ADC codes per sample"
    if led_power is not None:
        lp = np.asarray(led_power, dtype=float).reshape(3, 1)
        net, se = net / lp, se / lp
        units = "relative fluorescence (per unit LED power)"
    if cal_factors is not None:
        cf = np.asarray(cal_factors, dtype=float)
        net, se = net * cf, se * cf
        units = "calibrated equivalent units (see calibration record)"
    snr = net / np.maximum(se, 1e-12)
    idx = {k: float(net[e, c]) for k, (e, c) in PAIRS.items()}
    isnr = {k: float(snr[e, c]) for k, (e, c) in PAIRS.items()}
    return FluorescenceResult(net, se, snr, idx, isnr, classify_interference(isnr), isnr["chlorophyll"] > 10, units)


def _sig(x):
    return 1.0 / (1.0 + np.exp(-x))


def classify_interference(snr: dict[str, float], *, detect_snr: float = 5.0) -> dict[str, float]:
    """Soft classification of biological / organic interference from channel SNRs.

    Each channel's detection probability is a logistic in SNR centred at
    ``detect_snr``; class probabilities are products of detections and
    non-detections, normalised. These are interference indicators, not
    taxonomic identifications.
    """
    pc = _sig((snr["chlorophyll"] - detect_snr) / 1.5)
    pp = _sig((snr["protein_like"] - detect_snr) / 1.5)
    ph = _sig((snr["humic_like"] - detect_snr) / 1.5)
    raw = {
        "none": (1 - pc) * (1 - pp) * (1 - ph),
        "fresh_phytodetritus": pc * (1 - 0.5 * ph),
        "microbial_or_protein": pp * (1 - pc),
        "refractory_organic": ph * (1 - pc) * (1 - pp),
    }
    s = sum(raw.values())
    return {k: float(v / s) for k, v in raw.items()}


def fluorescence_map(on_img, off_img, *, read_noise: float = 3.0, snr_min: float = 3.0):
    """Spatial fluorescence (on - off) with an SNR mask, e.g. from the
    multispectral camera under 450 nm excitation with a 685 nm emission filter."""
    on = np.asarray(on_img, dtype=float)
    off = np.asarray(off_img, dtype=float)
    net = on - off
    sigma = np.sqrt(np.maximum(on, 0) + np.maximum(off, 0) + 2 * read_noise ** 2)
    snr = net / sigma
    return np.ma.masked_array(net, mask=snr < snr_min), snr
