"""Spectral similarity measures."""
from __future__ import annotations

import numpy as np


def spectral_angle(a, b, axis: int = -1) -> np.ndarray:
    """Spectral angle (radians); invariant to illumination scaling."""
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    num = np.sum(a * b, axis=axis)
    den = np.linalg.norm(a, axis=axis) * np.linalg.norm(b, axis=axis)
    return np.arccos(np.clip(num / np.where(den > 0, den, np.nan), -1.0, 1.0))


def sam_matrix(pixels, refs) -> np.ndarray:
    """Angles between every pixel (N x B) and reference (M x B) -> N x M."""
    p = np.asarray(pixels, dtype=float)
    r = np.asarray(refs, dtype=float)
    pn = p / np.linalg.norm(p, axis=1, keepdims=True).clip(1e-12)
    rn = r / np.linalg.norm(r, axis=1, keepdims=True).clip(1e-12)
    return np.arccos(np.clip(pn @ rn.T, -1.0, 1.0))


def spectral_information_divergence(a, b, eps: float = 1e-12) -> float:
    p = np.clip(np.asarray(a, dtype=float), eps, None)
    q = np.clip(np.asarray(b, dtype=float), eps, None)
    p /= p.sum()
    q /= q.sum()
    return float(np.sum(p * np.log(p / q)) + np.sum(q * np.log(q / p)))


def resample_gaussian(src_wl, src_val, dst_wl, fwhm) -> np.ndarray:
    """Resample a high-resolution spectrum to bands with Gaussian SRFs."""
    sw = np.asarray(src_wl, dtype=float)
    sv = np.asarray(src_val, dtype=float)
    out = []
    for c, w in zip(np.atleast_1d(dst_wl), np.broadcast_to(fwhm, np.shape(np.atleast_1d(dst_wl)))):
        s = w / 2.354820045
        k = np.exp(-0.5 * ((sw - c) / s) ** 2)
        out.append(np.sum(k * sv) / np.sum(k) if k.sum() > 0 else np.nan)
    return np.array(out)
