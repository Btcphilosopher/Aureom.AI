"""Baseline estimation for Raman / IR / fluorescence-contaminated spectra."""
from __future__ import annotations

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve


def als_baseline(y, *, lam: float = 1e5, p: float = 0.01, n_iter: int = 15) -> np.ndarray:
    """Asymmetric least squares baseline (Eilers & Boelens, 2005).

    Minimises sum w_i (y_i - z_i)^2 + lam * sum (D^2 z)^2 with weights p for
    points above the baseline and 1-p below; robust to positive peaks.
    """
    y = np.asarray(y, dtype=float)
    n = y.size
    if n < 3:
        return y.copy()
    D = sparse.diags([1.0, -2.0, 1.0], [0, -1, -2], shape=(n, n - 2))
    H = lam * (D @ D.T)
    w = np.ones(n)
    z = y
    for _ in range(n_iter):
        W = sparse.spdiags(w, 0, n, n)
        z = spsolve((W + H).tocsc(), w * y)
        w_new = p * (y > z) + (1 - p) * (y <= z)
        if np.array_equal(w_new, w):
            break
        w = w_new
    return np.asarray(z)


def modpoly_baseline(x, y, *, degree: int = 5, n_iter: int = 100, tol: float = 1e-4) -> np.ndarray:
    """Modified polynomial fit (Lieber & Mahadevan-Jansen, 2003)."""
    x = np.asarray(x, dtype=float)
    yb = np.asarray(y, dtype=float).copy()
    xs = (x - x.mean()) / (x.std() or 1.0)
    prev = None
    for _ in range(n_iter):
        c = np.polyfit(xs, yb, degree)
        fit = np.polyval(c, xs)
        yb = np.minimum(yb, fit)
        if prev is not None and np.linalg.norm(fit - prev) / (np.linalg.norm(prev) or 1.0) < tol:
            break
        prev = fit
    return fit
