"""Cosmic-ray (spike) removal for CCD spectra."""
from __future__ import annotations

import numpy as np


def remove_spikes_multi(frames, *, k: float = 6.0, read_noise: float = 3.0):
    """Replace spikes using repeated acquisitions of the same target.

    A pixel in frame j is a spike when it exceeds the per-pixel median of all
    frames by more than ``k`` times the expected noise (shot + read). Returns
    (cleaned_frames, spike_mask).
    """
    f = np.asarray(frames, dtype=float)
    if f.ndim != 2 or f.shape[0] < 3:
        raise ValueError("need >= 3 frames (frames x pixels)")
    med = np.median(f, axis=0)
    sigma = np.sqrt(np.maximum(med, 0) + read_noise ** 2)
    mask = (f - med) > k * sigma
    out = np.where(mask, med, f)
    return out, mask


def remove_spikes_single(y, *, threshold: float = 7.0, window: int = 3):
    """Single-spectrum spike removal (Whitaker & Hayes 2018): modified
    z-score of the first difference; flagged points are replaced by the mean
    of non-spike neighbours within ``window``."""
    y = np.asarray(y, dtype=float)
    d = np.diff(y)
    med = np.median(d)
    mad = np.median(np.abs(d - med)) or 1e-12
    z = 0.6745 * (d - med) / mad
    spikes = np.zeros(y.size, dtype=bool)
    spikes[1:] |= np.abs(z) > threshold
    # a single-point spike produces one large positive and one large negative
    # difference; keep only points that are local maxima of |y - local median|
    out = y.copy()
    for i in np.nonzero(spikes)[0]:
        lo, hi = max(0, i - window), min(y.size, i + window + 1)
        nb = [j for j in range(lo, hi) if not spikes[j]]
        if nb:
            out[i] = np.mean(y[nb])
    return out, spikes
