"""Continuum removal and absorption-band parameters (reflectance spectra)."""
from __future__ import annotations

import numpy as np


def upper_hull(x, y) -> np.ndarray:
    """Upper convex hull of (x, y), linearly interpolated onto x."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    hull: list[int] = []
    for i in range(x.size):
        while len(hull) >= 2:
            x1, y1 = x[hull[-2]], y[hull[-2]]
            x2, y2 = x[hull[-1]], y[hull[-1]]
            if (x2 - x1) * (y[i] - y1) - (y2 - y1) * (x[i] - x1) >= 0:
                hull.pop()
            else:
                break
        hull.append(i)
    return np.interp(x, x[hull], y[hull])


def continuum_removed(x, y) -> np.ndarray:
    c = upper_hull(x, y)
    return np.asarray(y, dtype=float) / np.where(c > 0, c, np.nan)


def band_parameters(x, y, lo: float, hi: float) -> dict:
    """Depth, centre and area of the absorption between ``lo`` and ``hi``."""
    x = np.asarray(x, dtype=float)
    sel = (x >= lo) & (x <= hi)
    if sel.sum() < 3:
        raise ValueError("band window has fewer than 3 samples")
    cr = continuum_removed(x[sel], np.asarray(y, dtype=float)[sel])
    j = int(np.nanargmin(cr))
    return {"depth": float(1 - cr[j]), "center": float(x[sel][j]),
            "area": float(np.trapezoid(1 - cr, x[sel])), "window": (lo, hi)}
