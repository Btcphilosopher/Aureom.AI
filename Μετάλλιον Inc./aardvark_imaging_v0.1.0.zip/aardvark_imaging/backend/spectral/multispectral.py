"""Multispectral / RGB camera processing: band registration, motion
compensation, lens distortion correction, colour calibration and HDR merge."""
from __future__ import annotations

import numpy as np
from scipy import ndimage


def phase_correlation(ref, img, *, upsample: int = 20) -> tuple[float, float]:
    """Sub-pixel translation (dy, dx) such that img(x) ~ ref(x - shift).

    Normalised cross-power spectrum peak, refined by a local upsampled DFT
    (Guizar-Sicairos et al., 2008) around the integer peak.
    """
    a = np.asarray(ref, dtype=float)
    b = np.asarray(img, dtype=float)
    win = np.outer(np.hanning(a.shape[0]), np.hanning(a.shape[1]))
    A = np.fft.fft2((a - a.mean()) * win)
    B = np.fft.fft2((b - b.mean()) * win)
    R = B * np.conj(A)
    R /= np.maximum(np.abs(R), 1e-12)
    r = np.fft.ifft2(R).real
    py, px = np.unravel_index(np.argmax(r), r.shape)
    sh = np.array([py, px], dtype=float)
    for k, n in enumerate(r.shape):
        if sh[k] > n // 2:
            sh[k] -= n
    # local upsampled DFT refinement over +-1.5 px
    ny, nx = R.shape
    fy = np.fft.fftfreq(ny)[:, None]
    fx = np.fft.fftfreq(nx)[None, :]
    best, best_v = sh.copy(), -np.inf
    offs = np.arange(-1.5, 1.5 + 1e-9, 1.0 / upsample)
    for dy in offs:
        ey = np.exp(2j * np.pi * fy * (sh[0] + dy))
        row = (R * ey).sum(0)
        vals = np.array([(row * np.exp(2j * np.pi * fx[0] * (sh[1] + dx))).sum().real for dx in offs])
        j = int(np.argmax(vals))
        if vals[j] > best_v:
            best_v, best = vals[j], np.array([sh[0] + dy, sh[1] + offs[j]])
    return float(best[0]), float(best[1])


def register_bands(stack, *, reference: int = 0, upsample: int = 20):
    """Register every band of (band, y, x) to ``reference`` by translation."""
    s = np.asarray(stack, dtype=float)
    shifts = np.zeros((s.shape[0], 2))
    out = np.empty_like(s)
    for i in range(s.shape[0]):
        if i == reference:
            out[i] = s[i]
            continue
        dy, dx = phase_correlation(s[reference], s[i], upsample=upsample)
        shifts[i] = (dy, dx)
        out[i] = ndimage.shift(s[i], (-dy, -dx), order=3, mode="nearest")
    return out, shifts


def motion_shift_px(dt_s: float, velocity_mps, gsd_m: float, yaw_rate_rad_s: float = 0.0, half_width_px: float = 0.0):
    """Predicted image translation between two exposures from platform motion
    (IMU/DVL velocity in camera axes), used to seed or check registration.
    Returns (dy, dx, rotation_rad)."""
    vx, vy = velocity_mps
    return vy * dt_s / gsd_m, vx * dt_s / gsd_m, yaw_rate_rad_s * dt_s


def undistort(image, fx, fy, cx, cy, k1=0.0, k2=0.0, p1=0.0, p2=0.0, k3=0.0):
    """Remove Brown-Conrady lens distortion by inverse mapping."""
    img = np.asarray(image, dtype=float)
    yy, xx = np.mgrid[0:img.shape[0], 0:img.shape[1]].astype(float)
    x = (xx - cx) / fx
    y = (yy - cy) / fy
    r2 = x * x + y * y
    rad = 1 + k1 * r2 + k2 * r2 ** 2 + k3 * r2 ** 3
    xd = x * rad + 2 * p1 * x * y + p2 * (r2 + 2 * x * x)
    yd = y * rad + p1 * (r2 + 2 * y * y) + 2 * p2 * x * y
    return ndimage.map_coordinates(img, [yd * fy + cy, xd * fx + cx], order=3, mode="nearest")


def fit_colour_matrix(measured, reference, *, offset: bool = True) -> np.ndarray:
    """Least-squares colour correction (N x 3 linear RGB -> reference)."""
    M = np.asarray(measured, dtype=float)
    if offset:
        M = np.hstack([M, np.ones((M.shape[0], 1))])
    X, *_ = np.linalg.lstsq(M, np.asarray(reference, dtype=float), rcond=None)
    return X


def apply_colour_matrix(rgb, X) -> np.ndarray:
    a = np.asarray(rgb, dtype=float)
    flat = a.reshape(-1, 3)
    if X.shape[0] == 4:
        flat = np.hstack([flat, np.ones((flat.shape[0], 1))])
    return (flat @ X).reshape(a.shape)


def linear_rgb_to_lab(rgb) -> np.ndarray:
    """Linear sRGB (D65) -> CIE L*a*b*."""
    M = np.array([[0.4124564, 0.3575761, 0.1804375], [0.2126729, 0.7151522, 0.0721750],
                  [0.0193339, 0.1191920, 0.9503041]])
    xyz = np.asarray(rgb, dtype=float) @ M.T / np.array([0.95047, 1.0, 1.08883])
    f = np.where(xyz > (6 / 29) ** 3, np.cbrt(xyz), xyz / (3 * (6 / 29) ** 2) + 4 / 29)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], axis=-1)


def delta_e76(lab1, lab2) -> np.ndarray:
    return np.linalg.norm(np.asarray(lab1) - np.asarray(lab2), axis=-1)


def hdr_merge(frames, exposures_s, *, sat_level: float, dark: float = 0.0):
    """Radiance (counts/s) from an exposure bracket, excluding saturated
    samples; weights favour longer (higher-SNR) exposures."""
    F = np.asarray(frames, dtype=float) - dark
    t = np.asarray(exposures_s, dtype=float).reshape(-1, *([1] * (F.ndim - 1)))
    ok = (np.asarray(frames) < sat_level) & (F > 0)
    w = np.where(ok, t, 0.0)
    num = np.sum(w * F / t, axis=0)
    den = np.sum(w, axis=0)
    return np.where(den > 0, num / np.maximum(den, 1e-12), np.nan)
