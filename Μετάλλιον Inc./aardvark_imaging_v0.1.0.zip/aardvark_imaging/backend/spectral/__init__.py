"""Spectral processing: baselines, noise, peaks, cosmic rays, continuum, similarity,
plus instrument-specific Raman, infrared, fluorescence and multispectral processing."""
