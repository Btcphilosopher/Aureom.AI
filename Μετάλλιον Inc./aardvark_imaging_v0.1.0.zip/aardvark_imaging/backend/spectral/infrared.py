"""Diamond-ATR mid-infrared line measurements (contact probe).

Water makes open-path mid-IR impossible underwater (absorption ~1e5 1/m
around 3 um and ~1e4-1e5 1/m across 5-12 um): the instrument therefore
measures by attenuated total reflectance, where the evanescent wave probes
only ~1 um into whatever is in contact with the crystal. Results describe
the contact surface, not the bulk nodule.

Lines (cm^-1) and roles match the SSA-1 IR source set.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

IR_LINES = [
    (2920.0, "organic_ch2_asym"), (2850.0, "organic_ch2_sym"), (2500.0, "baseline_hi"),
    (1640.0, "water_bend"), (1430.0, "carbonate_nu3"), (1250.0, "baseline_mid"),
    (875.0, "carbonate_nu2"), (800.0, "baseline_lo"),
]
LINE_CM1 = np.array([l for l, _ in IR_LINES])
ROLE = {r: i for i, (_, r) in enumerate(IR_LINES)}


def atr_penetration_depth_um(wavenumber_cm1, *, n_crystal: float = 2.4, n_sample: float = 1.33,
                             angle_deg: float = 45.0) -> np.ndarray:
    """Evanescent-wave penetration depth d_p = lambda / (2 pi n1 sqrt(sin^2 theta - (n2/n1)^2))."""
    lam_um = 1e4 / np.asarray(wavenumber_cm1, dtype=float)
    s = np.sin(np.radians(angle_deg)) ** 2 - (n_sample / n_crystal) ** 2
    if s <= 0:
        raise ValueError("no total internal reflection for these indices/angle")
    return lam_um / (2 * np.pi * n_crystal * np.sqrt(s))


@dataclass
class IrResult:
    absorbance: np.ndarray        # per line, relative to the water-covered crystal
    absorbance_se: np.ndarray
    corrected: np.ndarray         # water-displacement corrected, baseline removed
    contact_fraction: float
    carbonate_index: float
    carbonate_se: float
    organic_index: float
    organic_se: float
    notes: list[str]


def ir_absorbance(sample_demod, background_demod, *, demod_noise) -> tuple[np.ndarray, np.ndarray]:
    """A = -log10(I / I0) per line with first-order uncertainty."""
    I = np.asarray(sample_demod, dtype=float)
    I0 = np.asarray(background_demod, dtype=float)
    if np.any(I <= 0) or np.any(I0 <= 0):
        raise ValueError("demodulated intensities must be positive (check source and lock-in phase)")
    A = -np.log10(I / I0)
    se = np.sqrt((demod_noise / I) ** 2 + (demod_noise / I0) ** 2) / np.log(10)
    return A, se


def analyse_ir(A, se, water_reference_A_1640: float) -> IrResult:
    """Water-displacement correction and band indices.

    ``A`` is relative to the crystal under seawater, so a sample that
    displaces water from the evanescent field gives *negative* absorbance at
    the water bending band. The displaced fraction f is estimated from the
    1640 cm^-1 line, ``f = -A_1640 / A_water_1640`` (A_water_1640 from a
    reference measurement of water vs a clean crystal), and the sample
    absorbance is A_sample = (A + f * A_water) / f at each line, assuming the
    water absorbance scales the same way at every line. Organic amide I
    (~1650 cm^-1) overlaps the water band and biases f; this is reported.
    """
    A = np.asarray(A, dtype=float)
    se = np.asarray(se, dtype=float)
    notes = []
    f = float(np.clip(-A[ROLE["water_bend"]] / water_reference_A_1640, 0.05, 1.0))
    if f <= 0.05:
        notes.append("negligible water displacement: poor probe contact, indices unreliable")
    Aw = water_reference_A_1640 * _water_shape()
    As = (A + f * Aw) / f
    ses = se / f
    base = np.interp(LINE_CM1, LINE_CM1[[ROLE["baseline_lo"], ROLE["baseline_mid"], ROLE["baseline_hi"]]][::-1],
                     As[[ROLE["baseline_lo"], ROLE["baseline_mid"], ROLE["baseline_hi"]]][::-1])
    corr = As - base
    carb = 0.5 * (corr[ROLE["carbonate_nu3"]] + corr[ROLE["carbonate_nu2"]])
    carb_se = 0.5 * float(np.hypot(ses[ROLE["carbonate_nu3"]], ses[ROLE["carbonate_nu2"]]))
    org = corr[ROLE["organic_ch2_asym"]] + corr[ROLE["organic_ch2_sym"]]
    org_se = float(np.hypot(ses[ROLE["organic_ch2_asym"]], ses[ROLE["organic_ch2_sym"]]))
    notes.append("ATR probes ~1 um of the contact surface (see atr_penetration_depth_um)")
    notes.append("amide I (~1650 cm-1) overlaps the water band used for contact estimation")
    return IrResult(A, se, corr, f, float(carb), carb_se, float(org), org_se, notes)


def _water_shape() -> np.ndarray:
    """Relative liquid-water absorbance at each line, normalised to 1640 cm^-1
    (approximate shape from published liquid-water optical constants)."""
    rel = {2920: 0.35, 2850: 0.25, 2500: 0.08, 1640: 1.0, 1430: 0.12, 1250: 0.10, 875: 0.35, 800: 0.45}
    return np.array([rel[int(l)] for l in LINE_CM1])
