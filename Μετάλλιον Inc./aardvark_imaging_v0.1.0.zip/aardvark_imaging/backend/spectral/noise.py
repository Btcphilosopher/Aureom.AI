"""Noise estimation and smoothing."""
from __future__ import annotations

import numpy as np
from scipy.signal import savgol_filter


def noise_sigma(y) -> float:
    """Robust white-noise sigma from the MAD of second differences
    (insensitive to smooth signal and baseline): sigma = MAD(d2) * 1.4826 / sqrt(6)."""
    d2 = np.diff(np.asarray(y, dtype=float), 2)
    if d2.size == 0:
        return 0.0
    return float(np.median(np.abs(d2 - np.median(d2))) * 1.4826 / np.sqrt(6.0))


def savgol(y, window: int = 9, order: int = 3):
    window = max(order + 2 + (order % 2 == 0), window | 1)
    return savgol_filter(np.asarray(y, dtype=float), window, order, mode="interp")


def shot_read_noise(signal_e, read_noise_e: float, dark_e=0.0):
    """Per-pixel noise (electrons) for Poisson shot + dark + Gaussian read noise."""
    return np.sqrt(np.maximum(np.asarray(signal_e, dtype=float), 0) + np.asarray(dark_e) + read_noise_e ** 2)
