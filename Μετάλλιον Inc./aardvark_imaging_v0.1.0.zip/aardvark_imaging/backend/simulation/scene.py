"""Synthetic seabed scenes with ground truth (all outputs SIMULATED).

A scene is a rectangular patch of abyssal plain with fractal micro-relief,
a nodule field (lognormal sizes, Poisson positions with clustering), two
sediment facies, scattered phytodetritus patches and per-nodule "truth":
genesis, surface phase fractions, coatings, elemental grade and mass.
The elemental grade truth follows literature-typical contrasts between
diagenetic and hydrogenetic end-members; it exists only to exercise the
validation machinery and has no geological authority.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..core.constants import NODULE_WET_BULK_DENSITY_G_CM3

GRADE_ENDMEMBERS = {  # wt% dry, illustrative
    "diagenetic": {"Mn": 31.0, "Ni": 1.45, "Cu": 1.25, "Co": 0.15, "Fe": 5.0},
    "hydrogenetic": {"Mn": 22.0, "Ni": 0.55, "Cu": 0.35, "Co": 0.55, "Fe": 16.0},
}


@dataclass
class SceneConfig:
    seed: int = 7
    width_m: float = 6.0
    height_m: float = 4.0
    dem_resolution_m: float = 0.05
    origin_lat: float = 13.0
    origin_lon: float = -117.0
    mean_depth_m: float = 4500.0
    relief_m: float = 0.15
    density_per_m2: float = 45.0
    diameter_median_m: float = 0.055
    diameter_sigma: float = 0.35
    diagenetic_fraction: float = 0.6
    calcareous_fraction: float = 0.25
    n_biopatches: int = 6


@dataclass
class TrueNodule:
    idx: int
    east: float
    north: float
    a_m: float
    b_m: float
    c_m: float
    angle_rad: float
    genesis_diag: float
    phases: dict[str, float]
    carbonaceous_coating: float
    carbonate_encrustation: float
    grade: dict[str, float]
    mass_g: float

    @property
    def diameter_m(self) -> float:
        return 2 * np.sqrt(self.a_m * self.b_m)

    @property
    def dominant_class(self) -> str:
        return "manganese_rich"


@dataclass
class Scene:
    cfg: SceneConfig
    east: np.ndarray
    north: np.ndarray
    dem: np.ndarray                       # depth (m, positive down) on (north, east)
    sediment_calcareous: np.ndarray       # bool facies map on DEM grid
    biomass: np.ndarray                   # 0..1 phytodetritus cover on DEM grid
    nodules: list[TrueNodule] = field(default_factory=list)

    def depth_at(self, e, n):
        from scipy.ndimage import map_coordinates
        r = self.cfg.dem_resolution_m
        return map_coordinates(self.dem, [np.atleast_1d((np.asarray(n) - self.north[0]) / r),
                                          np.atleast_1d((np.asarray(e) - self.east[0]) / r)], order=1, mode="nearest")


def _fractal(shape, rng, beta=2.2):
    ky = np.fft.fftfreq(shape[0])[:, None]
    kx = np.fft.fftfreq(shape[1])[None, :]
    k = np.hypot(kx, ky)
    k[0, 0] = 1
    spec = (rng.standard_normal(shape) + 1j * rng.standard_normal(shape)) / k ** (beta / 2)
    spec[0, 0] = 0
    f = np.fft.ifft2(spec).real
    return f / (np.abs(f).max() or 1)


def generate_scene(cfg: SceneConfig = SceneConfig()) -> Scene:
    rng = np.random.default_rng(cfg.seed)
    r = cfg.dem_resolution_m
    east = np.arange(0, cfg.width_m + 1e-9, r)
    north = np.arange(0, cfg.height_m + 1e-9, r)
    dem = cfg.mean_depth_m + cfg.relief_m * _fractal((north.size, east.size), rng)
    facies = _fractal((north.size, east.size), rng, beta=3.0) > np.quantile(_fractal((north.size, east.size), np.random.default_rng(cfg.seed + 1), 3.0), 1 - cfg.calcareous_fraction)
    bio = np.zeros_like(dem)
    E, N = np.meshgrid(east, north)
    for _ in range(cfg.n_biopatches):
        ce, cn, s = rng.uniform(0, cfg.width_m), rng.uniform(0, cfg.height_m), rng.uniform(0.08, 0.25)
        bio = np.maximum(bio, np.exp(-((E - ce) ** 2 + (N - cn) ** 2) / (2 * s ** 2)))
    n_nod = rng.poisson(cfg.density_per_m2 * cfg.width_m * cfg.height_m)
    nodules: list[TrueNodule] = []
    placed = np.zeros((0, 3))
    tries = 0
    while len(nodules) < n_nod and tries < n_nod * 20:
        tries += 1
        d = cfg.diameter_median_m * np.exp(cfg.diameter_sigma * rng.standard_normal())
        d = float(np.clip(d, 0.015, 0.16))
        e, n = rng.uniform(0.05, cfg.width_m - 0.05), rng.uniform(0.05, cfg.height_m - 0.05)
        if placed.size and np.any(np.hypot(placed[:, 0] - e, placed[:, 1] - n) < 0.55 * (placed[:, 2] + d)):
            continue
        elong = rng.uniform(1.0, 1.4)
        a, b = d / 2 * np.sqrt(elong), d / 2 / np.sqrt(elong)
        c = b * rng.uniform(0.6, 1.0)
        g = float(np.clip(cfg.diagenetic_fraction + 0.25 * rng.standard_normal(), 0, 1))
        coat = float(rng.uniform(0, 0.25) if rng.random() < 0.3 else 0.0)
        carb = float(rng.uniform(0.1, 0.4) if facies[int(n / r), int(e / r)] and rng.random() < 0.4 else 0.0)
        mn_total = 1 - coat - carb - 0.08
        phases = {"todorokite": mn_total * (0.15 + 0.6 * g), "vernadite": mn_total * (0.15 + 0.6 * (1 - g)),
                  "birnessite": mn_total * 0.1, "goethite": 0.08 * (1.5 - g), "sediment": 0.0, "calcite": carb}
        s = sum(phases.values())
        phases = {k: v / s * (1 - coat) for k, v in phases.items()}
        grade = {el: g * GRADE_ENDMEMBERS["diagenetic"][el] + (1 - g) * GRADE_ENDMEMBERS["hydrogenetic"][el] for el in
                 GRADE_ENDMEMBERS["diagenetic"]}
        grade = {k: float(v * np.exp(0.06 * rng.standard_normal())) for k, v in grade.items()}
        vol = 4 / 3 * np.pi * a * b * c * 1e6
        rho = NODULE_WET_BULK_DENSITY_G_CM3[0] + NODULE_WET_BULK_DENSITY_G_CM3[1] * rng.standard_normal()
        nodules.append(TrueNodule(len(nodules), float(e), float(n), float(a), float(b), float(c),
                                  float(rng.uniform(0, np.pi)), g, phases, coat, carb, grade, float(vol * rho)))
        placed = np.vstack([placed, [e, n, d]])
    return Scene(cfg, east, north, dem, facies, bio, nodules)
