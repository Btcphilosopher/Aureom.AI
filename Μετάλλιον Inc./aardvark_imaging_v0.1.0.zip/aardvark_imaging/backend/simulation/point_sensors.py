"""Synthetic point-sensor measurements (Raman, ATR-IR, fluorescence, EMI)
for targets with known surface composition. All outputs SIMULATED."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..calibration.raman_shift import shift_to_nm
from ..spectral.infrared import IR_LINES, ROLE, _water_shape
from ..spectral.peaks import lorentzian
from ..spectral.raman import RAMAN_REFERENCE

RAMAN_CROSS_SECTION = {"calcite": 1.0, "aragonite": 1.0, "dolomite": 0.9, "rhodochrosite": 0.8, "siderite": 0.7,
                       "apatite_cfa": 0.6, "quartz": 0.6, "goethite": 0.25, "hematite": 0.4, "vernadite": 0.06,
                       "todorokite": 0.07, "birnessite": 0.06, "barite": 0.8}


@dataclass
class TargetTruth:
    target_id: str
    context: str                         # nodule_surface | sediment
    phases: dict[str, float]             # surface fractions (Raman phase names)
    carbonaceous: float                  # 0..1 carbonaceous coating
    organic: float                       # 0..1 organic matter (non-graphitic)
    chlorophyll: float                   # 0..1 fresh phytodetritus
    protein: float                       # 0..1 microbial/protein-like
    humic: float                         # 0..1 refractory organic
    toc_wt_pct: float
    tic_wt_pct: float
    true_class: str


def raman_axis(npix: int = 1024, laser_nm: float = 532.0, lo: float = 100.0, hi: float = 3600.0):
    shift = np.linspace(lo, hi, npix)
    return shift, shift_to_nm(shift, laser_nm)


def simulate_raman(t: TargetTruth, shift, *, n_frames: int = 3, integration_s: float = 5.0, rng=None,
                   signal_scale: float = 400.0, read_noise: float = 4.0, dark_e_s: float = 2.0, cosmic_rate: float = 0.8):
    """Returns (light_frames, dark_frames) in counts."""
    rng = rng or np.random.default_rng(0)
    spec = np.zeros_like(shift)
    for ph, f in t.phases.items():
        for c, rel, w in RAMAN_REFERENCE.get(ph, []):
            spec += signal_scale * f * RAMAN_CROSS_SECTION.get(ph, 0.3) * rel * lorentzian(shift, 1.0, c, w)
    for c, rel, w in RAMAN_REFERENCE["water"]:
        spec += signal_scale * 0.25 * rel * lorentzian(shift, 1.0, c, w)
    spec += signal_scale * 0.08 * lorentzian(shift, 1.0, 981.0, 10.0)                    # seawater sulfate
    if t.carbonaceous > 0:
        spec += signal_scale * 3.0 * t.carbonaceous * (lorentzian(shift, 1.0, 1350, 70) + 0.9 * lorentzian(shift, 1.0, 1590, 45)
                                                     + 0.25 * lorentzian(shift, 1.0, 1620, 30))
    fl = signal_scale * (0.5 * t.chlorophyll + 0.25 * t.organic + 0.1 * t.humic) * 6
    background = fl * np.exp(-((shift - 1800) / 2200) ** 2) + 5.0
    mean_e = (spec + background) * integration_s
    lights, darks = [], []
    for _ in range(n_frames):
        e = rng.poisson(np.maximum(mean_e + dark_e_s * integration_s, 0)) + read_noise * rng.standard_normal(shift.size)
        for _ in range(rng.poisson(cosmic_rate)):
            i = rng.integers(0, shift.size)
            e[i:i + rng.integers(1, 3)] += rng.uniform(300, 3000)
        lights.append(e)
        darks.append(rng.poisson(dark_e_s * integration_s, shift.size) + read_noise * rng.standard_normal(shift.size))
    return np.array(lights), np.array(darks)


def simulate_ir(t: TargetTruth, *, rng=None, I0: float = 2.0e6, demod_noise: float = 300.0, water_A_1640: float = 0.5):
    """Demodulated intensities for the 8 ATR lines: background (water-covered
    crystal) and sample, plus the water reference absorbance at 1640 cm^-1."""
    rng = rng or np.random.default_rng(0)
    contact = rng.uniform(0.6, 0.95)
    carb = t.phases.get("calcite", 0) + t.phases.get("aragonite", 0)
    A_min = np.zeros(len(IR_LINES))
    A_min[ROLE["carbonate_nu3"]] += 0.9 * carb
    A_min[ROLE["carbonate_nu2"]] += 0.5 * carb
    A_min[ROLE["organic_ch2_asym"]] += 0.6 * (t.organic + t.protein + 0.5 * t.carbonaceous)
    A_min[ROLE["organic_ch2_sym"]] += 0.4 * (t.organic + t.protein + 0.5 * t.carbonaceous)
    A_min += 0.03                                                                       # generic scattering/baseline
    Aw = water_A_1640 * _water_shape()
    A_rel = contact * A_min + (1 - contact) * Aw - Aw                                  # relative to water-covered crystal
    bg = I0 * (1 + 0.002 * rng.standard_normal(len(IR_LINES)))
    sample = I0 * 10 ** (-A_rel) + demod_noise * rng.standard_normal(len(IR_LINES))
    return sample, bg + demod_noise * rng.standard_normal(len(IR_LINES)), water_A_1640, demod_noise


def simulate_fluorescence(t: TargetTruth, *, rng=None, npulses: int = 100, kept: int = 60, scale: float = 600.0):
    """diff (3x3) and off (3x3) sums as produced by sf_fluorescence_controller."""
    rng = rng or np.random.default_rng(0)
    eem = np.zeros((3, 3))
    eem[0, 0] = 1.0 * t.protein + 0.2 * t.organic
    eem[1, 1] = 1.0 * t.humic + 0.3 * t.organic
    eem[2, 2] = 1.2 * t.chlorophyll
    eem[0, 1] = 0.2 * t.humic
    eem[1, 2] = 0.05 * t.chlorophyll
    n = npulses * kept
    ambient = np.array([500.0, 800.0, 1200.0])
    on = (ambient[None, :] + scale * eem) * n
    off = np.tile(ambient * n, (3, 1))
    on_s = rng.poisson(on).astype(float)
    off_s = rng.poisson(off).astype(float)
    return (on_s - off_s).astype(np.int64), off_s.astype(np.int64), npulses, kept


def simulate_emi_profile(n: int, coverage, sediment_sigma, *, rng=None, sigma_sw: float = 3.2, f_hz: float = 10e3,
                         spacing_m: float = 1.0, noise: float = 2e-5):
    """Complex secondary/primary responses along a track, with platform
    interference driven by synthetic thruster currents and heading."""
    from ..core.constants import MU0
    rng = rng or np.random.default_rng(0)
    w = 2 * np.pi * f_hz
    sig_eff = 0.7 * sigma_sw + 0.3 * np.asarray(sediment_sigma) + 0.5 * np.asarray(coverage)
    hs_hp_true = 1j * sig_eff * w * MU0 * spacing_m ** 2 / 4.0
    thr = np.column_stack([np.sin(np.linspace(0, 12, n)) + 0.1 * rng.standard_normal(n),
                           np.cos(np.linspace(0, 7, n))])
    heading = np.linspace(0, 2 * np.pi, n)
    regs = np.column_stack([thr, np.sin(heading), np.cos(heading)])
    interference = regs @ np.array([3e-4 + 1e-4j, -2e-4 + 2e-4j, 1e-4 - 1e-4j, 5e-5 + 0j])
    z = hs_hp_true + interference + noise * (rng.standard_normal(n) + 1j * rng.standard_normal(n))
    return z, hs_hp_true, regs, ["thruster_1", "thruster_2", "sin_heading", "cos_heading"]
