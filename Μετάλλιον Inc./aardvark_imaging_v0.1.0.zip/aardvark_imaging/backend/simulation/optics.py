"""Optical rendering and detector simulation for synthetic scenes."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import ndimage

from ..hyperspectral import water
from ..mineralogy.library import SpectralLibrary, parametric_vnir_library
from .scene import Scene


def nodule_fraction_map(scene: Scene, gsd_m: float, supersample: int = 3):
    """Per-pixel fractional nodule cover and owning-nodule index (largest share)."""
    W = int(round(scene.cfg.width_m / gsd_m))
    H = int(round(scene.cfg.height_m / gsd_m))
    s = supersample
    fine = np.full((H * s, W * s), -1, dtype=np.int32)
    g = gsd_m / s
    for nd in scene.nodules:
        r = max(nd.a_m, nd.b_m)
        i0, i1 = int((nd.north - r) / g), int((nd.north + r) / g) + 2
        j0, j1 = int((nd.east - r) / g), int((nd.east + r) / g) + 2
        i0, j0 = max(i0, 0), max(j0, 0)
        i1, j1 = min(i1, H * s), min(j1, W * s)
        if i1 <= i0 or j1 <= j0:
            continue
        yy, xx = np.mgrid[i0:i1, j0:j1]
        y = (yy + 0.5) * g - nd.north
        x = (xx + 0.5) * g - nd.east
        ca, sa = np.cos(nd.angle_rad), np.sin(nd.angle_rad)
        u, v = x * ca + y * sa, -x * sa + y * ca
        inside = (u / nd.a_m) ** 2 + (v / nd.b_m) ** 2 <= 1.0
        sub = fine[i0:i1, j0:j1]
        sub[inside] = nd.idx
    frac = (fine >= 0).reshape(H, s, W, s).mean(axis=(1, 3))
    owner = fine.reshape(H, s, W, s).transpose(0, 2, 1, 3).reshape(H, W, s * s).max(-1)
    return frac, owner


def render_reflectance(scene: Scene, wavelength_nm, gsd_m: float, lib: SpectralLibrary | None = None):
    """Reflectance cube (H, W, B) with per-pixel truth (nodule fraction, owner, facies, biomass)."""
    lib = (lib or parametric_vnir_library()).resample(wavelength_nm)
    frac, owner = nodule_fraction_map(scene, gsd_m)
    H, W = frac.shape
    r = scene.cfg.dem_resolution_m
    # Bilinear resampling of the DEM-grid fields onto the image grid. Nearest
    # neighbour would turn 5 cm grid cells into hard-edged, nodule-sized dark
    # squares — an artefact no real seabed has.
    yy = (np.arange(H) + 0.5) * gsd_m / r
    xx = (np.arange(W) + 0.5) * gsd_m / r
    Y, X = np.meshgrid(yy, xx, indexing="ij")
    calc = ndimage.map_coordinates(scene.sediment_calcareous.astype(float), [Y, X], order=1, mode="nearest") > 0.5
    bio = np.clip(ndimage.map_coordinates(scene.biomass, [Y, X], order=1, mode="nearest"), 0.0, 1.0)
    sed = lib.get("sediment")
    calc_spec = 0.55 * lib.get("calcite") + 0.45 * lib.get("sediment")
    bg = np.where(calc[..., None], calc_spec, sed)
    bg = (1 - 0.6 * bio[..., None]) * bg + 0.6 * bio[..., None] * lib.get("biological")
    nod_spec = np.zeros((len(scene.nodules), len(lib.wavelength_nm)))
    for nd in scene.nodules:
        s = sum(f * lib.get(p) for p, f in nd.phases.items() if f > 0 and p in lib.names)
        coat = nd.carbonaceous_coating
        nod_spec[nd.idx] = (1 - coat) * s + coat * 0.03 * np.ones_like(s)
    ns = np.where(owner[..., None] >= 0, nod_spec[np.maximum(owner, 0)], 0.0)
    refl = (1 - frac[..., None]) * bg + frac[..., None] * ns
    truth = {"nodule_fraction": frac, "owner": owner, "calcareous": calc, "biomass": bio}
    return refl, truth, lib


@dataclass
class DetectorModel:
    full_well_e: float = 20000.0
    gain_e_per_code: float = 5.0
    read_noise_e: float = 12.0
    dark_e_per_s: float = 40.0
    bias_codes: float = 100.0
    bits: int = 12
    prnu_rel: float = 0.01
    bad_fraction: float = 0.001
    seed: int = 3

    def fixed_patterns(self, shape):
        rng = np.random.default_rng(self.seed)
        prnu = 1 + self.prnu_rel * rng.standard_normal(shape)
        bad = rng.random(shape) < self.bad_fraction
        hot = rng.random(shape) < self.bad_fraction / 2
        return prnu, bad, hot


def expose(radiance_e_per_s: np.ndarray, exposure_s: float, det: DetectorModel, rng, *, fixed=None, dark: bool = False):
    """Photo-electrons -> 12-bit codes with shot, dark, read noise, PRNU, hot pixels and saturation."""
    prnu, bad, hot = fixed if fixed is not None else det.fixed_patterns(radiance_e_per_s.shape)
    sig = 0.0 if dark else radiance_e_per_s * exposure_s * prnu
    dk = det.dark_e_per_s * exposure_s * np.where(hot, 50.0, 1.0)
    e = rng.poisson(np.maximum(sig + dk, 0)).astype(float) + det.read_noise_e * rng.standard_normal(radiance_e_per_s.shape)
    e = np.minimum(e, det.full_well_e)
    codes = np.clip(np.rint(e / det.gain_e_per_code + det.bias_codes), 0, 2 ** det.bits - 1)
    codes = np.where(bad, 2 ** det.bits - 1, codes)
    return codes.astype(np.uint16)


def at_sensor_signal(refl: np.ndarray, wavelength_nm, *, altitude_m: float, peak_e_per_s: float = 4.0e5,
                     c_particulate: float = 0.03, backscatter_frac: float = 0.01):
    """Active illumination model: L = E0(lambda) * vignetting * (R * T_2way + backscatter)."""
    H, W, B = refl.shape
    wl = np.asarray(wavelength_nm, dtype=float)
    lamp = 0.4 + 0.6 * np.exp(-0.5 * ((wl - 560) / 160) ** 2)        # broadband white LED shape
    yy, xx = np.mgrid[0:H, 0:W]
    r2 = ((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2
    vign = 1.0 / (1 + 0.35 * r2)
    T = water.transmission(wl, 2 * altitude_m, c_particulate=c_particulate)
    bs = backscatter_frac * (1 - np.exp(-2 * water.attenuation(wl, c_particulate=c_particulate) * altitude_m))
    return peak_e_per_s * lamp * vign[..., None] * (refl * T + bs), T, bs


def luminance(refl: np.ndarray, wavelength_nm) -> np.ndarray:
    wl = np.asarray(wavelength_nm, dtype=float)
    w = np.exp(-0.5 * ((wl - 555) / 60) ** 2)
    return np.tensordot(refl, w / w.sum(), axes=([-1], [0]))


def blur(img, sigma_px: float):
    return ndimage.gaussian_filter(img, sigma_px) if sigma_px > 0 else img
