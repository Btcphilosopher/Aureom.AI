"""Deterministic simulation environment. Every product is labelled SIMULATED."""
