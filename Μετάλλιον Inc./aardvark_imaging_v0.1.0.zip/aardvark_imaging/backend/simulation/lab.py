"""Synthetic laboratory datasets (assays, TOC/TIC) for exercising the
validation and calibration machinery. Every record is SIMULATED and carries
a 'SIMULATED' QA flag so it can never be mistaken for real laboratory data."""
from __future__ import annotations

from datetime import date

import numpy as np

from ..mineralogy.grade import AssayRecord
from .scene import TrueNodule


def simulate_assays(nodules: list[TrueNodule], nodule_ids: dict[int, str], *, n: int = 60, seed: int = 5,
                    rel_unc: float = 0.03) -> list[AssayRecord]:
    rng = np.random.default_rng(seed)
    pick = rng.choice(len(nodules), size=min(n, len(nodules)), replace=False)
    out = []
    for k, i in enumerate(sorted(pick)):
        nd = nodules[i]
        wt = {el: float(v * (1 + rel_unc * rng.standard_normal())) for el, v in nd.grade.items()}
        out.append(AssayRecord(sample_id=f"SIM-BC-{k:03d}", nodule_id=nodule_ids.get(nd.idx), laboratory="SIMULATED-LAB",
                               method="ICP-OES (simulated)", analysed=date(2026, 10, 1), wt_pct=wt,
                               uncertainty_wt_pct={el: abs(v) * rel_unc for el, v in wt.items()},
                               qa_flags=["SIMULATED"]))
    return out
