"""End-to-end simulated survey: synthetic scene -> sensor data -> every
processing engine -> products + validation against ground truth.

Everything produced here is SIMULATED (data origin propagated through every
product). It is the integration test of the scientific stack, the demo data
source for the API/workstation, and the template for processing real data.
"""
from __future__ import annotations

import dataclasses

import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

import numpy as np
from scipy import ndimage

from ..analytics.metrics import classification_report, expected_calibration_error, regression_report
from ..calibration.models import CalibrationKind, CalibrationLevel, CalibrationRecord
from ..calibration.radiometric import dark_reference, detect_bad_pixels, flat_field_gain
from ..calibration.registry import CalibrationRegistry
from ..carbon.engine import CarbonCharacterisationEngine, CarbonTarget
from ..core.ids import new_id
from ..core.provenance import DataOrigin, Estimate
from ..electromagnetic import induction
from ..geological_mapping.seabed_map import build_seabed_map, frontend_payload, survey_statistics
from ..geospatial.grid import GridSpec
from ..hyperspectral import water
from ..hyperspectral.analysis import pca, unmix
from ..hyperspectral.classification import classify_sam
from ..hyperspectral.cube import make_cube
from ..mineralogy.classifier import MineralClassifier
from ..mineralogy.grade import GradeCalibrationModel, GradeEngine
from ..mineralogy.library import parametric_vnir_library
from ..nodules.detection import detect_nodules, reject_by_chromaticity
from ..nodules.measurement import measure_nodules
from ..nodules.registry import NoduleObservation, NoduleRegistry
from ..sensor_fusion.fusion import ChannelOpinion, fuse
from ..sonar.multibeam import georeference, grid_soundings
from ..sonar.raytrace import SoundVelocityProfile
from ..spectral.fluorescence import net_fluorescence
from ..spectral.infrared import analyse_ir, ir_absorbance
from ..spectral.raman import assign_bands, process_raman
from . import optics
from .acoustic_sim import simulate_pings
from .lab import simulate_assays
from .point_sensors import TargetTruth, raman_axis, simulate_emi_profile, simulate_fluorescence, simulate_ir, simulate_raman
from .scene import Scene, SceneConfig, generate_scene

ORIGIN = DataOrigin.SIMULATED
CARBON_CLASS_TRUTH = ["carbonaceous_coating", "carbonate", "carbon_bearing_sediment", "biological", "background_matrix",
                      "organic_carbon"]


@dataclass
class SurveyConfig:
    scene: SceneConfig = field(default_factory=SceneConfig)
    image_gsd_m: float = 0.005
    hsi_gsd_m: float = 0.02
    hsi_wavelengths_nm: tuple[float, float, float] = (400.0, 800.0, 5.0)
    altitude_m: float = 2.0
    n_point_targets: int = 36
    n_assays: int = 60
    mbes: bool = True
    seed: int = 21


@dataclass
class SurveyProducts:
    survey_id: str
    config: SurveyConfig
    scene: Scene
    registry: NoduleRegistry
    calibrations: CalibrationRegistry
    hsi_cube: Any
    hsi_classification: Any
    carbon_results: list
    carbon_positions: list
    mineral_assessments: dict
    grade_reports: dict
    seabed_map: Any
    emi: dict
    validation: dict
    timings_s: dict
    raman_examples: dict
    image: np.ndarray
    labels: np.ndarray
    hsi_labels: np.ndarray
    hsi_label_names: list

    def summary(self) -> dict:
        return {"survey_id": self.survey_id, "data_origin": ORIGIN.value, "nodules": len(self.registry),
                "carbon_targets": len(self.carbon_results), "map": survey_statistics(self.seabed_map),
                "validation": self.validation, "timings_s": self.timings_s}


def _sim_calibrations(reg: CalibrationRegistry, sensors: dict[str, list[str]]) -> None:
    now = datetime.now(timezone.utc)
    for s, kinds in sensors.items():
        for k in kinds:
            try:
                kind = CalibrationKind(k)
            except ValueError:
                continue
            reg.add(CalibrationRecord(calibration_id=new_id(f"CAL-{s}-{k}"), sensor_key=s, kind=kind,
                                      level=CalibrationLevel.FIELD, version=1, valid_from=now - timedelta(days=1),
                                      expires=now + timedelta(days=90), method="derived from simulated frames",
                                      origin=DataOrigin.SIMULATED, notes="simulation calibration; not traceable"))


def run_survey(cfg: SurveyConfig = SurveyConfig(), *, progress=None) -> SurveyProducts:
    T: dict[str, float] = {}
    tic = time.perf_counter
    rng = np.random.default_rng(cfg.seed)
    t0 = tic()
    scene = generate_scene(cfg.scene)
    survey_id = f"SIM{cfg.seed:03d}"
    T["scene"] = tic() - t0

    # ------------------------------------------------------------ calibrations
    calreg = CalibrationRegistry()
    _sim_calibrations(calreg, {"HSI0": ["dark", "flat_field", "wavelength", "radiometric", "bad_pixel"],
                               "MS0": ["dark", "flat_field", "colour", "distortion", "band_registration"],
                               "RAM0": ["dark", "raman_shift", "intensity_response"],
                               "IR0": ["ir_background"], "FL0": ["fluorescence"],
                               "EMI0": ["em_free_field_null", "em_platform_compensation"],
                               "MBES0": ["sound_velocity"]})

    # ------------------------------------------------------------ imaging: high-res mosaic -> nodules
    t0 = tic()
    wl_img = np.array([450.0, 530.0, 610.0])
    refl_img, truth_img, lib_full = optics.render_reflectance(scene, wl_img, cfg.image_gsd_m)
    sig, T_img, _ = optics.at_sensor_signal(refl_img, wl_img, altitude_m=cfg.altitude_m)
    det = optics.DetectorModel(seed=cfg.seed)
    fixed = det.fixed_patterns(sig.shape[:2] + (3,))
    codes = optics.expose(sig, 0.03, det, rng, fixed=fixed)
    lum = codes.astype(float).mean(-1) - det.bias_codes
    gsd = cfg.image_gsd_m
    seed_px = max(3.0, 0.5 * cfg.scene.diameter_median_m / gsd)
    det_res = detect_nodules(lum, min_area_px=12, max_area_px=int(np.pi * (0.1 / gsd) ** 2), min_seed_distance_px=seed_px)
    # colour test: Mn-oxide nodules are spectrally flat, dark biogenic cover is green-brown
    cb = np.maximum(ndimage.median_filter(codes[..., 0].astype(float) - det.bias_codes, 3), 1.0)
    cg = np.maximum(ndimage.median_filter(codes[..., 1].astype(float) - det.bias_codes, 3), 1.0)
    labels_c, _ = reject_by_chromaticity(det_res.labels, np.log(cg / cb), max_delta=0.0)
    det_res = dataclasses.replace(det_res, labels=labels_c, n=int(labels_c.max()))
    meas = measure_nodules(det_res.labels, gsd_m=gsd, image=lum, coverage=det_res.coverage, n_mc=150, seed=cfg.seed,
                           pixel_to_world=lambda r, c: ((c + 0.5) * gsd, (r + 0.5) * gsd), origin=ORIGIN)
    T["imaging_detection"] = tic() - t0

    # ------------------------------------------------------------ HSI cube -> calibrated -> classification
    t0 = tic()
    a, b, s = cfg.hsi_wavelengths_nm
    wl = np.arange(a, b + 1e-9, s)
    lib = parametric_vnir_library().resample(wl)
    refl, truth, _ = optics.render_reflectance(scene, wl, cfg.hsi_gsd_m, lib)
    sig_h, T_h, bs_h = optics.at_sensor_signal(refl, wl, altitude_m=cfg.altitude_m, peak_e_per_s=2.5e6)
    det_h = optics.DetectorModel(seed=cfg.seed + 1, full_well_e=60000, gain_e_per_code=15)
    fixed_h = det_h.fixed_patterns(sig_h.shape)
    exp_s = 0.008
    raw = optics.expose(sig_h, exp_s, det_h, rng, fixed=fixed_h)
    darks = np.stack([optics.expose(sig_h[0:1], exp_s, det_h, rng, fixed=tuple(f[0:1] for f in fixed_h), dark=True)[0]
                      for _ in range(16)])
    dref = dark_reference(darks, temperature_c=4.0, exposure_s=exp_s)
    flat_sig = np.full(sig_h.shape[1:], 2.0e6)
    flats = np.stack([optics.expose(flat_sig[None], exp_s, det_h, rng, fixed=tuple(f[0:1] for f in fixed_h))[0] for _ in range(8)])
    gain = flat_field_gain(np.maximum(flats.astype(float), dref.mean + 1), dref)
    badpix = detect_bad_pixels(dref, gain, gain_range=(0.7, 1.4))
    cube = make_cube(raw, wl, origin=ORIGIN, source="HSI0 (simulated)",
                     saturated=raw >= 4095, calibration_ids=[calreg.applicable("HSI0", CalibrationKind.DARK).calibration_id])
    corr = (raw.astype(float) - dref.mean[None]) * gain[None]
    # radiometric conversion with known simulated responsivity, then water path, then reflectance
    lamp = sig_h / np.maximum(refl * T_h + bs_h, 1e-12)        # illumination field (known to the simulator; in the
    # field this comes from a reference-panel measurement at the same altitude)
    est_refl = (corr / (exp_s / det_h.gain_e_per_code) / lamp - bs_h) / T_h
    usable = water.usable_bands(wl, 2 * cfg.altitude_m, t_min=0.05)
    invalid = badpix[None] | (raw >= 4095)
    est_refl = np.where(invalid, np.nan, est_refl)
    cube = cube.with_data(est_refl, step="dark+flat+radiance+water+reflectance (simulated reference panel)",
                          units="reflectance factor", extra_invalid=invalid)
    H, W, B = est_refl.shape
    X = est_refl.reshape(-1, B)
    # Pixels with a few flagged (bad / saturated) usable bands are classified
    # after linear interpolation along wavelength over the flagged bands; the
    # cube itself keeps them as NaN with the invalid mask (raw is untouched).
    fin = np.isfinite(X[:, usable])
    good = fin.mean(axis=1) >= 0.9
    Xc = X.copy()
    ub = np.nonzero(usable)[0]
    for i in np.nonzero(good & ~fin.all(axis=1))[0]:
        ok = fin[i]
        Xc[i, ub[~ok]] = np.interp(wl[ub[~ok]], wl[ub[ok]], X[i, ub[ok]])
    n_interp = int((good & ~fin.all(axis=1)).sum())
    snr_est = 60.0
    cls = classify_sam(np.nan_to_num(Xc[good]), lib.spectra, lib.names, snr=snr_est, usable=usable, max_angle=0.25,
                       min_prob=0.3)
    pc = pca(np.nan_to_num(Xc[good][:, usable]), 5)
    T["hsi"] = tic() - t0

    # ------------------------------------------------------------ registry + per-nodule HSI unmixing
    t0 = tic()
    reg = NoduleRegistry(survey_id)
    mn_lib_names = ["vernadite", "todorokite", "birnessite", "goethite", "calcite", "sediment"]
    E = np.array([lib.get(n)[usable] for n in mn_lib_names])
    label_hsi = np.full(H * W, -1)
    label_hsi[np.nonzero(good)[0]] = cls.label
    mineral_assessments, nodule_idx_map, grade_reports = {}, {}, {}
    mc = MineralClassifier()
    # map image-detected nodules onto HSI pixels
    true_pos = np.array([[nd.east, nd.north] for nd in scene.nodules])
    detected_truth = []
    feats_for_grade, assay_targets = [], {}
    for m in meas:
        e, n = m.position_m
        ih, jh = int(n / cfg.hsi_gsd_m), int(e / cfg.hsi_gsd_m)
        win = est_refl[max(0, ih - 1):ih + 2, max(0, jh - 1):jh + 2].reshape(-1, B)
        win = win[np.all(np.isfinite(win[:, usable]), axis=1)] if win.size else win
        ab, ab_std = {}, {}
        if len(win):
            # image-derived pixel choice only (no ground truth): Mn-oxide nodules are the darkest
            # material in the scene, so the darkest valid pixel in the 3x3 window is the one most
            # likely dominated by the nodule surface.
            spec = win[int(np.argmin(win[:, usable].mean(axis=1)))]
            u = unmix(spec[usable][None], E)
            ab = {nme: float(u["abundances"][0, k]) for k, nme in enumerate(mn_lib_names)}
            ab_std = {nme: float(u["std"][0, k]) for k, nme in enumerate(mn_lib_names)}
            ph = {k: v for k, v in ab.items()}
        else:
            ph = {}
        assess = mc.assess(vnir_phase_probs=ph or None)
        d = np.hypot(true_pos[:, 0] - e, true_pos[:, 1] - n)
        j = int(np.argmin(d))
        tn = scene.nodules[j] if d[j] < 0.6 * scene.nodules[j].diameter_m + 0.01 else None
        detected_truth.append((m, tn))
        obs = NoduleObservation(observation_id=new_id("OBS"), sensor="MS0+HSI0", east_m=e, north_m=n,
                                position_std_m=0.01,
                                measurements={"equivalent_diameter_m": m.equivalent_diameter_m.model_dump(),
                                              "volume_cm3": m.volume_cm3.model_dump(), "mass_g": m.mass_g.model_dump(),
                                              "area_m2": m.area_m2.model_dump(), "circularity": m.circularity,
                                              "elongation": m.elongation, "orientation_deg": m.orientation_deg},
                                classification=assess.class_probabilities, quality=m.quality, data_origin=ORIGIN)
        nid, _ = reg.add(obs)
        mineral_assessments[nid] = assess
        if tn is not None:
            nodule_idx_map[tn.idx] = nid
            feats_for_grade.append((nid, tn, [ab.get("todorokite", 0), ab.get("vernadite", 0), ab.get("goethite", 0)]))
        grade_reports[nid] = {"classification": assess.class_probabilities,
                              "abundances": {k: (ab[k], ab_std[k]) for k in ab}, "mass": m.mass_g}
    T["registry_unmixing"] = tic() - t0

    # ------------------------------------------------------------ grade (assay-linked, simulated lab)
    t0 = tic()
    assays = simulate_assays(scene.nodules, nodule_idx_map, n=cfg.n_assays, seed=cfg.seed)
    by_nod = {a.nodule_id: a for a in assays if a.nodule_id}
    Xg, yg, gg = [], [], []
    for nid, tn, f in feats_for_grade:
        if nid in by_nod:
            Xg.append(f); yg.append(by_nod[nid].wt_pct["Ni"]); gg.append(nid)
    ni_model = GradeCalibrationModel("Ni", ["todorokite", "vernadite", "goethite"], min_samples=25)
    if len(Xg) >= 6:
        ni_model.fit(np.array(Xg), np.array(yg), np.array(gg), k=5)
    ge = GradeEngine(recovery={"Ni": 0.9, "Cu": 0.85, "Co": 0.8, "Mn": 0.9}, models={"Ni": ni_model})
    feat_by_nid = {nid: f for nid, _, f in feats_for_grade}
    reports = {}
    for nid, g in grade_reports.items():
        reports[nid] = ge.report(nodule_id=nid, classification=g["classification"], abundances=g["abundances"],
                                 mass_g=g["mass"], assays=assays, model_features=feat_by_nid.get(nid))
    for a in assays:
        if a.nodule_id:
            reg.link_assay(a.nodule_id, a.sample_id)
    T["grade"] = tic() - t0

    # ------------------------------------------------------------ point sensors -> carbon engine
    t0 = tic()
    shift, _ = raman_axis(1024)
    engine = CarbonCharacterisationEngine(n_mc=200, seed=cfg.seed)
    carbon_results, carbon_pos, carbon_truth, raman_examples = [], [], [], {}
    for k in range(cfg.n_point_targets):
        kind = k % 6
        if kind in (0, 1, 2) and scene.nodules:
            nd = scene.nodules[rng.integers(0, len(scene.nodules))]
            pos = (nd.east, nd.north)
            if kind == 0:
                tt = TargetTruth(f"PT{k:03d}", "nodule_surface", {"todorokite": 0.5, "vernadite": 0.4, "goethite": 0.1},
                                 0.6, 0.1, 0.0, 0.0, 0.05, 0.8, 0.0, "carbonaceous_coating")
            elif kind == 1:
                tt = TargetTruth(f"PT{k:03d}", "nodule_surface", {"calcite": 0.6, "vernadite": 0.4}, 0.0, 0.0, 0.0, 0.0,
                                 0.0, 0.05, 6.0, "carbonate")
            else:
                tt = TargetTruth(f"PT{k:03d}", "nodule_surface", {"vernadite": 0.6, "todorokite": 0.3, "goethite": 0.1},
                                 0.0, 0.0, 0.0, 0.0, 0.0, 0.02, 0.0, "background_matrix")
        else:
            pos = (rng.uniform(0, scene.cfg.width_m), rng.uniform(0, scene.cfg.height_m))
            if kind == 3:
                tt = TargetTruth(f"PT{k:03d}", "sediment", {"quartz": 0.3, "calcite": 0.5}, 0.0, 0.15, 0.0, 0.1, 0.4, 0.4, 5.0,
                                 "carbon_bearing_sediment")
            elif kind == 4:
                tt = TargetTruth(f"PT{k:03d}", "sediment", {"quartz": 0.5}, 0.0, 0.3, 0.9, 0.6, 0.2, 0.9, 0.1, "biological")
            else:
                tt = TargetTruth(f"PT{k:03d}", "sediment", {"quartz": 0.6}, 0.0, 0.0, 0.0, 0.0, 0.0, 0.1, 0.05,
                                 "background_matrix")
        L, D = simulate_raman(tt, shift, rng=rng)
        pr = process_raman(L, D, shift)
        Ii, I0, Aw, nz = simulate_ir(tt, rng=rng)
        A, se = ir_absorbance(Ii, I0, demod_noise=nz)
        ir = analyse_ir(A, se, Aw)
        diff, off, npul, kept = simulate_fluorescence(tt, rng=rng)
        fl = net_fluorescence(diff, off, npulses=npul, kept_per_window=kept)
        res = engine.analyse(CarbonTarget(tt.target_id, tt.context, pr, ir, fl,
                                          {"RAM0": "simulated", "IR0": "simulated", "FL0": "simulated"}, ORIGIN))
        carbon_results.append(res)
        carbon_pos.append(pos)
        carbon_truth.append(tt.true_class)
        if tt.true_class not in raman_examples:
            raman_examples[tt.true_class] = {"shift": shift.tolist(), "signal": pr.signal.tolist(),
                                             "baseline": pr.baseline.tolist(), "sigma": pr.sigma.tolist(),
                                             "bands": [b.__dict__ for b in assign_bands(pr)]}
    T["carbon"] = tic() - t0

    # ------------------------------------------------------------ multibeam + EMI
    t0 = tic()
    dem_ds, pings = None, []
    if cfg.mbes:
        cov = {"frac": optics.nodule_fraction_map(scene, 0.05)[0], "res": 0.05}
        pings, c = simulate_pings(scene, coverage_map=cov, altitude_m=6.0, n_beams=48, line_spacing_m=1.0,
                                  ping_spacing_m=0.25, seed=cfg.seed)
        svp = SoundVelocityProfile(np.array([0.0, 11000.0]), np.array([c, c]))
        snd = georeference(pings, svp)
        inside = (snd[:, 0] >= 0) & (snd[:, 0] <= scene.cfg.width_m) & (snd[:, 1] >= 0) & (snd[:, 1] <= scene.cfg.height_m)
        dem_ds = grid_soundings(snd[inside], resolution_m=0.25, bounds=(0, scene.cfg.width_m, 0, scene.cfg.height_m))
    n_emi = 300
    track_e = np.linspace(0, scene.cfg.width_m, n_emi)
    track_n = np.full(n_emi, scene.cfg.height_m / 2)
    frac_line = optics.nodule_fraction_map(scene, 0.05)[0]
    covs = frac_line[np.clip((track_n / 0.05).astype(int), 0, frac_line.shape[0] - 1),
                     np.clip((track_e / 0.05).astype(int), 0, frac_line.shape[1] - 1)]
    z, true_hs, regs, names = simulate_emi_profile(n_emi, covs, np.full(n_emi, 1.2), rng=rng)
    # platform compensation is fitted on a calibration manoeuvre in the water
    # column (uniform background), never on survey data over the seabed
    z_cal, true_cal, regs_cal, _ = simulate_emi_profile(200, np.zeros(200), np.full(200, 3.2), rng=rng)
    comp = induction.fit_platform_compensation(z_cal, regs_cal, names)
    zc = comp.apply(z, regs)
    sig_a = induction.apparent_conductivity(zc, 10e3, 1.0)
    emi = {"east": track_e.tolist(), "north": track_n.tolist(), "apparent_conductivity_s_m": sig_a.tolist(),
           "contrast_z": induction.material_contrast(sig_a).tolist(),
           "lin_valid": induction.lin_valid(10e3, 1.0, induction.seawater_conductivity(1.5)),
           "residual_after_compensation": float(np.sqrt(np.mean(np.abs(zc - true_hs) ** 2))),
           "residual_before_compensation": float(np.sqrt(np.mean(np.abs(z - true_hs) ** 2)))}
    T["acoustic_em"] = tic() - t0

    # ------------------------------------------------------------ seabed map
    t0 = tic()
    grid = GridSpec(0.125, 0.125, 0.25, int(scene.cfg.width_m / 0.25), int(scene.cfg.height_m / 0.25),
                    scene.cfg.origin_lat, scene.cfg.origin_lon, -scene.cfg.mean_depth_m)
    nod_rows = []
    for nid, rec in reg.records.items():
        ob = rec.observations[-1]
        ma = mineral_assessments[nid]
        nod_rows.append({"east_m": rec.east_m, "north_m": rec.north_m, "area_m2": ob.measurements["area_m2"]["value"],
                         "mass_g": ob.measurements["mass_g"]["value"], "mass_std_g": ob.measurements["mass_g"]["std"] or 0.0,
                         "top_class": ma.top_class, "top_prob": ma.confidence})
    from ..carbon.mapping import carbon_layers
    cl = carbon_layers(carbon_results, carbon_pos, grid.east, grid.north)
    tracks = [np.column_stack([[p.east_m for p in pings], [p.north_m for p in pings]])] if pings else []
    smap = build_seabed_map(grid, dem=dem_ds, nodules=nod_rows, carbon_layers=cl, tracks=tracks, data_origin=ORIGIN)
    T["mapping"] = tic() - t0

    # ------------------------------------------------------------ validation against truth
    t0 = tic()
    val: dict[str, Any] = {"data_origin": ORIGIN.value}
    matched = [(m, tn) for m, tn in detected_truth if tn is not None]
    val["nodule_detection"] = {"detected": len(meas), "true": len(scene.nodules), "matched": len(matched),
                               "precision": len(matched) / max(len(meas), 1),
                               "recall": len({tn.idx for _, tn in matched}) / max(len(scene.nodules), 1)}
    if matched:
        d_est = np.array([m.equivalent_diameter_m.value for m, _ in matched])
        d_true = np.array([tn.diameter_m for _, tn in matched])
        val["diameter_m"] = regression_report(d_true, d_est)
        m_est = np.array([m.mass_g.value for m, _ in matched])
        m_true = np.array([tn.mass_g for _, tn in matched])
        val["mass_g"] = regression_report(m_true, m_est)
        val["mass_interval_coverage_95"] = float(np.mean([m.mass_g.interval[0] <= tn.mass_g <= m.mass_g.interval[1]
                                                          for m, tn in matched]))
    area = scene.cfg.width_m * scene.cfg.height_m
    val["abundance_kg_m2"] = {"estimated": float(sum(m.mass_g.value for m in meas) / 1000 / area),
                              "true": float(sum(tn.mass_g for tn in scene.nodules) / 1000 / area)}
    pred = [r.top_class for r in carbon_results]
    val["carbon_classification"] = classification_report(carbon_truth, pred, sorted(set(carbon_truth) | set(pred)))
    val["carbon_confidence_calibration"] = expected_calibration_error([r.top_probability for r in carbon_results],
                                                                      [p == t for p, t in zip(pred, carbon_truth)], 5)
    # per-pixel HSI: nodule-dominated pixels should be Mn-oxide classes
    fr_flat = truth["nodule_fraction"].ravel()[good]
    lab_names = np.array(cls.label_names())
    nod_px = fr_flat > 0.8
    sed_px = fr_flat < 0.05
    mn = np.isin(lab_names, ["vernadite", "todorokite", "birnessite"])
    val["hsi_pixels"] = {"nodule_pixels_classified_mn_oxide": float(mn[nod_px].mean()) if nod_px.any() else None,
                         "sediment_pixels_classified_mn_oxide": float(mn[sed_px].mean()) if sed_px.any() else None,
                         "usable_bands": int(usable.sum()), "total_bands": int(usable.size),
                         "pixels_classified": int(good.sum()), "pixels_total": int(good.size),
                         "pixels_with_interpolated_bands": n_interp,
                         "pca_explained_ratio": [float(x) for x in pc["explained_ratio"]]}
    val["grade_model_Ni"] = {"validated": ni_model.validated, "r2_cv": ni_model.r2_cv, "rmsecv_wt_pct": ni_model.rmsecv,
                             "reasons": ni_model.reasons, "n_assay_linked": len(Xg)}
    if dem_ds is not None:
        tz = scene.depth_at(np.repeat(dem_ds.east.values[None], dem_ds.north.size, 0).ravel(),
                            np.repeat(dem_ds.north.values[:, None], dem_ds.east.size, 1).ravel()).reshape(dem_ds.depth.shape)
        ok = np.isfinite(dem_ds.depth.values)
        val["bathymetry"] = {"rmse_m": float(np.sqrt(np.mean((dem_ds.depth.values[ok] - tz[ok]) ** 2))),
                             "cells": int(ok.sum())}
    val["emi_compensation"] = {"before": emi["residual_before_compensation"], "after": emi["residual_after_compensation"]}
    T["validation"] = tic() - t0

    return SurveyProducts(survey_id, cfg, scene, reg, calreg, cube, cls, carbon_results, carbon_pos, mineral_assessments,
                          reports, smap, emi, val, T, raman_examples, lum, det_res.labels, label_hsi.reshape(H, W),
                          list(cls.classes))


def fast_config(seed: int = 21) -> SurveyConfig:
    """Small, quick configuration for tests and the API's default demo."""
    return SurveyConfig(scene=SceneConfig(seed=seed, width_m=3.0, height_m=2.0, density_per_m2=40.0),
                        n_point_targets=18, n_assays=40, seed=seed)
