"""Synthetic multibeam pings over a scene DEM (straight rays, constant sound
speed; the processing uses the identical constant SVP). SIMULATED."""
from __future__ import annotations

import numpy as np

from ..sonar.acoustics import sound_speed_mackenzie, transmission_loss_db
from ..sonar.multibeam import Ping
from .scene import Scene


def simulate_pings(scene: Scene, *, altitude_m: float = 8.0, n_beams: int = 96, swath_deg: float = 120.0,
                   line_spacing_m: float = 2.0, ping_spacing_m: float = 0.25, f_khz: float = 400.0,
                   source_level_db: float = 210.0, nodule_bs_gain_db: float = 6.0, seed: int = 11,
                   coverage_map=None):
    rng = np.random.default_rng(seed)
    c = float(sound_speed_mackenzie(1.5, 34.7, scene.cfg.mean_depth_m))
    angles = np.radians(np.linspace(-swath_deg / 2, swath_deg / 2, n_beams))
    pings = []
    t = 0.0
    for k, n0 in enumerate(np.arange(0.0, scene.cfg.height_m + 1e-9, line_spacing_m)):
        es = np.arange(0.0, scene.cfg.width_m + 1e-9, ping_spacing_m)
        if k % 2:
            es = es[::-1]
        for e0 in es:
            z0 = float(scene.depth_at(e0, n0)[0]) - altitude_m
            heading = np.pi / 2 if k % 2 == 0 else -np.pi / 2       # east- or west-bound
            # march all beams along their straight rays until they meet the DEM
            s = np.full(angles.size, altitude_m * 0.5)
            hit = np.zeros(angles.size, dtype=bool)
            ds = 0.05
            for _ in range(int(4 * altitude_m / ds)):
                ac = s * np.sin(angles)
                e = e0 + ac * np.cos(heading)
                nn = n0 - ac * np.sin(heading)
                z = z0 + s * np.cos(angles)
                below = z >= scene.depth_at(e, nn)
                newly = below & ~hit
                hit |= below
                if hit.all():
                    break
                s = np.where(hit, s, s + ds)
                del newly
            # refine the crossing linearly within the last step
            R = s - 0.5 * ds
            ac = R * np.sin(angles)
            e = e0 + ac * np.cos(heading)
            nn = n0 - ac * np.sin(heading)
            cov = np.zeros(angles.size)
            if coverage_map is not None:
                g = coverage_map
                ii = np.clip((nn / g["res"]).astype(int), 0, g["frac"].shape[0] - 1)
                jj = np.clip((e / g["res"]).astype(int), 0, g["frac"].shape[1] - 1)
                cov = g["frac"][ii, jj]
            inc = np.abs(angles)
            bs = -30.0 - 5 * np.log10(np.cos(inc) ** 2 + 0.05) + nodule_bs_gain_db * cov / 0.3 + rng.normal(0, 1.0, angles.size)
            A = R ** 2 * np.radians(1.0) ** 2 / np.maximum(np.cos(inc), 0.05)
            lvl = source_level_db - 2 * transmission_loss_db(R, f_khz) + bs + 10 * np.log10(A)
            twtt = 2 * R / c + rng.normal(0, 2e-6, angles.size)
            pings.append(Ping(t, e0, n0, z0, heading, angles, twtt, lvl))
            t += 0.2
    return pings, c
