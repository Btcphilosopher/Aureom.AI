"""Nodule detection in seabed imagery.

Polymetallic nodules are dark (reflectance ~0.04-0.08), rounded objects on
lighter sediment. Detection: impulse-noise median filter -> local-background flattening
(percentile filter) -> darkness threshold (Otsu, capped) -> morphological clean-up -> hole filling -> distance-transform seeded
watershed to split touching nodules -> saddle-based merge of over-split
regions -> dark-core (hysteresis) test -> size filtering. Works on a single
band, an RGB luminance image, or a band-averaged reflectance image.

The optional dark-core test (off by default) rejects regions without a core
much darker than the local background. In simulation with realistic
backscatter, nodule contrast (~0.37 of background at the centre) overlaps
dark biogenic cover, so single-band darkness alone cannot separate them:
colour/NIR (red-edge) or texture features are needed — see docs.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import ndimage


def otsu_threshold(values: np.ndarray, bins: int = 256) -> float:
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    hist, edges = np.histogram(v, bins=bins)
    p = hist / max(hist.sum(), 1)
    omega = np.cumsum(p)
    centers = 0.5 * (edges[:-1] + edges[1:])
    mu = np.cumsum(p * centers)
    mu_t = mu[-1]
    with np.errstate(divide="ignore", invalid="ignore"):
        sigma_b = (mu_t * omega - mu) ** 2 / (omega * (1 - omega))
    sigma_b[~np.isfinite(sigma_b)] = 0
    return float(centers[int(np.argmax(sigma_b))])


def flatten_illumination(img: np.ndarray, window_px: float = 40.0, percentile: float = 75.0) -> np.ndarray:
    """Divide by a local *background* estimate.

    The background is a high percentile of a window much larger than a
    nodule, computed on a 4x decimated image and smoothly upsampled. Using a
    percentile rather than a mean keeps the dark nodules themselves out of
    the background, and removes illumination fall-off *and* sediment-facies
    brightness changes (e.g. calcareous vs siliceous clay patches), which
    would otherwise dominate a global threshold.
    """
    a = np.asarray(img, dtype=float)
    a = np.where(np.isfinite(a), a, np.nanmedian(a))
    f = 4
    small = a[::f, ::f]
    size = max(3, int(window_px / f) | 1)
    bg_small = ndimage.percentile_filter(small, percentile, size=size)
    bg_small = ndimage.uniform_filter(bg_small, size=max(3, size // 2))
    zoom = (a.shape[0] / bg_small.shape[0], a.shape[1] / bg_small.shape[1])
    bg = ndimage.zoom(bg_small, zoom, order=1)[: a.shape[0], : a.shape[1]]
    return a / np.maximum(bg, 1e-9)


@dataclass
class DetectionResult:
    labels: np.ndarray          # 0 background, 1..N nodules
    n: int
    threshold: float
    flattened: np.ndarray
    coverage: np.ndarray        # per-pixel fractional nodule cover estimate (mixed edge pixels)


def _watershed_on_distance(dist: np.ndarray, markers: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Priority-flood (Meyer) watershed of -dist from labelled markers, 8-connected,
    restricted to ``mask``. Pixels are claimed in order of decreasing distance,
    so two touching nodules meet at the neck of the distance map.

    (scipy's ``watershed_ift`` uses a max-arc path cost on a quantised image;
    on plateaus and ties it can let one seed flood a neighbouring nodule.)
    """
    import heapq
    H, W = mask.shape
    lab = np.where(mask, markers, 0).astype(np.int32).ravel()
    d = dist.ravel()
    m = mask.ravel()
    offs = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]
    heap: list[tuple[float, int, int]] = []
    counter = 0
    seeded = np.nonzero(lab > 0)[0]
    queued = np.zeros(lab.size, dtype=bool)
    queued[seeded] = True
    def push_neighbours(i):
        nonlocal counter
        r, c = divmod(int(i), W)
        for dr, dc in offs:
            rr, cc = r + dr, c + dc
            if 0 <= rr < H and 0 <= cc < W:
                j = rr * W + cc
                if m[j] and not queued[j]:
                    queued[j] = True
                    counter += 1
                    heapq.heappush(heap, (-d[j], counter, j))
    for i in seeded:
        push_neighbours(i)
    while heap:
        _, _, j = heapq.heappop(heap)
        r, c = divmod(j, W)
        # take the label of the already-labelled neighbour with the largest distance
        best, bd = 0, -1.0
        for dr, dc in offs:
            rr, cc = r + dr, c + dc
            if 0 <= rr < H and 0 <= cc < W:
                k = rr * W + cc
                if lab[k] > 0 and d[k] > bd:
                    best, bd = lab[k], d[k]
        lab[j] = best
        push_neighbours(j)
    return lab.reshape(H, W)


def _merge_oversplit(lab: np.ndarray, dist: np.ndarray, ratio: float) -> np.ndarray:
    """Merge adjacent watershed regions separated by a shallow saddle.

    Two touching round nodules meet at a narrow neck, where the distance
    transform falls well below both peaks. An elongated or irregular single
    nodule that the seeding over-split has no such neck. Regions a, b are
    merged when saddle(a, b) >= ratio * min(peak_a, peak_b).
    """
    n = int(lab.max())
    if n < 2:
        return lab
    peak = np.zeros(n + 1)
    np.maximum.at(peak, lab.ravel(), dist.ravel())
    saddle: dict[tuple[int, int], float] = {}
    H, W = lab.shape
    L = np.pad(lab, 1)
    Dp = np.pad(dist, 1)
    for dy, dx in ((0, 1), (1, 0), (1, 1), (1, -1)):
        a = L[1:H + 1, 1:W + 1]
        b = L[1 + dy:H + 1 + dy, 1 + dx:W + 1 + dx]
        da = Dp[1:H + 1, 1:W + 1]
        db = Dp[1 + dy:H + 1 + dy, 1 + dx:W + 1 + dx]
        m = (a > 0) & (b > 0) & (a != b)
        if not m.any():
            continue
        lo = np.minimum(a[m], b[m]); hi = np.maximum(a[m], b[m]); v = np.minimum(da[m], db[m])
        for i, j, x in zip(lo.tolist(), hi.tolist(), v.tolist()):
            if x > saddle.get((i, j), -1.0):
                saddle[(i, j)] = x
    parent = list(range(n + 1))
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for (i, j), x in sorted(saddle.items(), key=lambda kv: -kv[1]):
        if x >= ratio * min(peak[i], peak[j]):
            ri, rj = find(i), find(j)
            if ri != rj:
                parent[max(ri, rj)] = min(ri, rj)
    root = np.array([find(i) for i in range(n + 1)])
    return root[lab]


def detect_nodules(img: np.ndarray, *, min_area_px: int = 20, max_area_px: int | None = None,
                   flatten_sigma_px: float = 40.0, open_radius: int = 1, split: bool = True,
                   min_seed_distance_px: float = 3.0, max_relative_darkness: float = 0.55,
                   core_relative_darkness: float | None = None, min_core_px: int = 4,
                   merge_saddle_ratio: float = 0.75) -> DetectionResult:
    # impulse noise (hot / dead pixels) removal before any statistics
    clean = ndimage.median_filter(np.asarray(img, dtype=float), size=3)
    flat = np.clip(flatten_illumination(clean, max(flatten_sigma_px, 8 * min_seed_distance_px)), 0.0, 2.0)
    # Otsu on the flattened histogram; sediment sits near 1.0, nodules well
    # below (reflectance ~0.05 vs ~0.15-0.4). A nodule must be at least
    # (1 - max_relative_darkness) darker than its local background whatever
    # Otsu returns: diffuse dark material (phytodetritus, shadows) is
    # typically only 20-40 % darker and is rejected here and by the area limit.
    thr = min(otsu_threshold(flat[flat < 1.5]), max_relative_darkness)
    mask = flat < thr
    st = ndimage.generate_binary_structure(2, 1)
    if open_radius > 0:
        mask = ndimage.binary_opening(mask, st, iterations=open_radius)
    mask = ndimage.binary_fill_holes(mask)
    if split:
        dist = ndimage.distance_transform_edt(mask)
        # Seeds: local maxima of the distance map separated by at least
        # min_seed_distance_px; every connected component keeps at least one
        # seed, so small nodules are never lost by the splitting step.
        size = int(2 * min_seed_distance_px + 1)
        peaks = (dist == ndimage.maximum_filter(dist, size=size)) & (dist >= 1.0)
        comp, ncomp = ndimage.label(mask)
        has = np.zeros(ncomp + 1, dtype=bool)
        has[np.unique(comp[peaks])] = True
        if ncomp:
            missing = np.nonzero(~has[1:])[0] + 1
            if missing.size:
                pos = ndimage.maximum_position(dist, comp, missing)
                for (r, c) in pos:
                    peaks[r, c] = True
        # merge seeds closer than the separation (plateaus give adjacent maxima)
        peaks = ndimage.binary_dilation(peaks, iterations=1) & mask
        markers, _ = ndimage.label(peaks)
        lab = _watershed_on_distance(dist, markers, mask)
        lab = _merge_oversplit(lab, dist, merge_saddle_ratio)
    else:
        lab, _ = ndimage.label(mask)
    # relabel, filter by size and by the dark-core criterion
    ids, counts = np.unique(lab[lab > 0], return_counts=True)
    ok = (counts >= min_area_px) & ((counts <= max_area_px) if max_area_px else True)
    if core_relative_darkness is not None and ids.size:
        # optional hysteresis test; off by default because under strong
        # backscatter nodule contrast and dark biogenic cover overlap
        core_px = ndimage.sum((flat < core_relative_darkness).astype(float), lab, ids)
        ok &= np.asarray(core_px) >= min_core_px
    keep = ids[ok]
    out = np.zeros_like(lab, dtype=np.int32)
    for k, i in enumerate(keep, start=1):
        out[lab == i] = k
    # Fractional cover from darkness: 0 at the local background level (1.0),
    # 1 at the median level of nodule cores. Lets the measurement step use
    # mixed edge pixels instead of the hard threshold (removes a ~0.5 px
    # radius bias).
    core = ndimage.binary_erosion(out > 0, iterations=1)
    level = float(np.median(flat[core])) if core.any() else 0.35
    coverage = np.clip((1.0 - flat) / max(1.0 - level, 1e-6), 0.0, 1.0)
    return DetectionResult(out, len(keep), thr, flat, coverage)


def reject_by_chromaticity(labels: np.ndarray, chroma: np.ndarray, *, max_delta: float = 0.0,
                           inner: int = 2, outer: int = 6) -> tuple[np.ndarray, dict[int, float]]:
    """Reject candidates whose colour does not look like a Mn-oxide nodule.

    ``chroma`` is a log band-ratio image, e.g. ln(green / blue) from a colour or
    multispectral frame. Ferromanganese nodules are spectrally flat and near
    black; dark biogenic cover (phytodetritus) and sediment are green-brown, so
    a nodule's median chroma is *lower* than its surrounding annulus while a
    dark biogenic patch is equal or higher. Regions with
    ``median(chroma[region]) - median(chroma[annulus]) > max_delta`` are
    removed. Returns the relabelled image and the per-region contrast.

    The threshold is a property of the illumination/camera and must be set
    from imagery of verified nodules; the default 0.0 was chosen on
    SIMULATED scenes only.
    """
    out = np.zeros_like(labels)
    deltas: dict[int, float] = {}
    k_new = 0
    st = ndimage.generate_binary_structure(2, 2)
    objs = ndimage.find_objects(labels)
    for k, sl in enumerate(objs, start=1):
        if sl is None:
            continue
        pad = outer + 1
        r0, r1 = max(0, sl[0].start - pad), min(labels.shape[0], sl[0].stop + pad)
        c0, c1 = max(0, sl[1].start - pad), min(labels.shape[1], sl[1].stop + pad)
        sub = labels[r0:r1, c0:c1]
        own = sub == k
        ring = ndimage.binary_dilation(own, st, iterations=outer) & ~ndimage.binary_dilation(own, st, iterations=inner) & (sub == 0)
        ch = chroma[r0:r1, c0:c1]
        if not ring.any():
            delta = 0.0
        else:
            delta = float(np.median(ch[own]) - np.median(ch[ring]))
        deltas[k] = delta
        if delta <= max_delta:
            k_new += 1
            out[r0:r1, c0:c1][own] = k_new
    return out, deltas
