"""Per-nodule measurements with uncertainty.

Geometry from the label mask (moments), scaled by the ground sample distance
(GSD) from the camera model and altitude. Volume and mass use an ellipsoid
whose vertical semi-axis is unknown from a plan view: c = h * b with the
height ratio h drawn from a prior (default U[0.6, 1.0], typical of CCZ
nodules; refine with stereo/laser profiling). Mass = volume x wet bulk
density. All derived quantities are Monte-Carlo estimates (ESTIMATED).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy import ndimage
from scipy.spatial import ConvexHull

from ..core.constants import NODULE_WET_BULK_DENSITY_G_CM3
from ..core.provenance import DataOrigin, Estimate


@dataclass
class NoduleMeasurement:
    label: int
    centroid_px: tuple[float, float]
    area_px: int
    position_m: tuple[float, float] | None
    major_axis_m: Estimate
    minor_axis_m: Estimate
    area_m2: Estimate
    equivalent_diameter_m: Estimate
    volume_cm3: Estimate
    surface_area_cm2: Estimate
    mass_g: Estimate
    orientation_deg: float
    circularity: float
    solidity: float
    elongation: float
    edge_touching: bool
    mean_spectrum: np.ndarray | None = None
    spectrum_std: np.ndarray | None = None
    quality: dict[str, float] = field(default_factory=dict)


def _perimeter_px(mask: np.ndarray) -> float:
    """Boundary length with the 4-connected crack count corrected by pi/4
    (unbiased for isotropically oriented boundaries)."""
    m = mask.astype(np.int8)
    cracks = np.abs(np.diff(np.pad(m, 1), axis=0)).sum() + np.abs(np.diff(np.pad(m, 1), axis=1)).sum()
    return float(cracks) * np.pi / 4.0


def ellipsoid_surface_area(a, b, c, p: float = 1.6075):
    """Knud Thomsen approximation (relative error < 1.1 %)."""
    return 4 * np.pi * (((a * b) ** p + (a * c) ** p + (b * c) ** p) / 3) ** (1 / p)


def measure_nodules(labels: np.ndarray, *, gsd_m: float, gsd_rel_std: float = 0.02, image=None, cube=None,
                    coverage: np.ndarray | None = None,
                    height_ratio=(0.6, 1.0), density=NODULE_WET_BULK_DENSITY_G_CM3, pixel_to_world=None,
                    n_mc: int = 500, seed: int = 0, origin: DataOrigin = DataOrigin.ESTIMATED) -> list[NoduleMeasurement]:
    rng = np.random.default_rng(seed)
    out = []
    H, W = labels.shape
    objs = ndimage.find_objects(labels)
    for k, sl in enumerate(objs, start=1):
        if sl is None:
            continue
        sub = labels[sl] == k
        yy, xx = np.nonzero(sub)
        yy = yy + sl[0].start
        xx = xx + sl[1].start
        n = yy.size
        cy, cx = yy.mean(), xx.mean()
        cov = np.cov(np.vstack([xx - cx, yy - cy])) if n > 2 else np.eye(2) * 0.25
        ev, evec = np.linalg.eigh(cov + np.eye(2) / 12.0)       # +1/12 px^2: pixel discretisation
        major_px, minor_px = 4 * np.sqrt(ev[1]), 4 * np.sqrt(ev[0])     # full axes of the equivalent ellipse
        theta = float(np.degrees(np.arctan2(evec[1, 1], evec[0, 1])))
        perim = _perimeter_px(sub)
        circ = float(4 * np.pi * n / max(perim, 1e-9) ** 2)
        try:
            pts = np.column_stack([xx, yy]).astype(float)
            hull = ConvexHull(pts + rng.normal(0, 1e-6, pts.shape)) if n >= 3 else None
            solidity = float(n / max(hull.volume, 1.0)) if hull is not None else 1.0
        except Exception:
            solidity = 1.0
        n_eff = float(n)
        if coverage is not None:
            # sub-pixel area: hard-labelled pixels plus fractional cover of the
            # one-pixel ring that no other nodule owns
            own = labels == k
            ring = ndimage.binary_dilation(own) & ~own & (labels == 0)
            n_eff = float(own.sum()) + float(np.asarray(coverage)[ring].sum())
            s = np.sqrt(n_eff / max(n, 1))
            major_px, minor_px = major_px * s, minor_px * s
        g = gsd_m * (1 + gsd_rel_std * rng.standard_normal(n_mc))
        h = rng.uniform(*height_ratio, n_mc)
        rho = rng.normal(density[0], density[1], n_mc)
        a = 0.5 * major_px * g * 100       # semi-axes in cm
        b = 0.5 * minor_px * g * 100
        c = h * b
        vol = 4 / 3 * np.pi * a * b * c
        sa = ellipsoid_surface_area(a, b, c)
        area = n_eff * g ** 2
        mk = lambda s, u, m: Estimate.from_samples(s, units=u, origin=origin, method=m)
        meas = NoduleMeasurement(
            label=k, centroid_px=(float(cy), float(cx)), area_px=int(n),
            position_m=tuple(pixel_to_world(cy, cx)) if pixel_to_world else None,
            major_axis_m=mk(major_px * g, "m", "moments x GSD"), minor_axis_m=mk(minor_px * g, "m", "moments x GSD"),
            area_m2=mk(area, "m2", "pixel count x GSD^2"), equivalent_diameter_m=mk(2 * np.sqrt(area / np.pi), "m", "equal-area circle"),
            volume_cm3=mk(vol, "cm3", "ellipsoid, height-ratio prior"), surface_area_cm2=mk(sa, "cm2", "Knud Thomsen ellipsoid"),
            mass_g=mk(vol * rho, "g", "volume x wet bulk density"), orientation_deg=theta, circularity=min(circ, 1.2),
            solidity=min(solidity, 1.0), elongation=float(major_px / max(minor_px, 1e-9)),
            edge_touching=bool(yy.min() == 0 or xx.min() == 0 or yy.max() == H - 1 or xx.max() == W - 1))
        if cube is not None:
            core = ndimage.binary_erosion(labels == k, iterations=1)
            if core.sum() < 3:
                core = labels == k
            spec = np.asarray(cube)[core]
            spec = spec[np.all(np.isfinite(spec), axis=1)]
            if spec.size:
                meas.mean_spectrum = spec.mean(0)
                meas.spectrum_std = spec.std(0)
        if image is not None:
            meas.quality = acquisition_quality(np.asarray(image, dtype=float)[sl], sub)
        out.append(meas)
    return out


def acquisition_quality(patch: np.ndarray, mask: np.ndarray, sat_level: float | None = None) -> dict[str, float]:
    """Focus (variance of Laplacian), contrast-to-noise and saturation."""
    lap = ndimage.laplace(patch)
    inside = patch[mask]
    outside = patch[~mask] if (~mask).any() else patch.ravel()
    noise = float(np.std(np.diff(outside))) / np.sqrt(2) if outside.size > 2 else 1.0
    q = {"focus_var_laplacian": float(np.var(lap)), "contrast_to_noise": float(abs(outside.mean() - inside.mean()) / max(noise, 1e-9))}
    if sat_level is not None:
        q["saturated_fraction"] = float(np.mean(patch >= sat_level))
    return q


def annulus_mask(labels: np.ndarray, k: int, inner: int = 2, outer: int = 6) -> np.ndarray:
    """Sediment ring around nodule ``k`` (excluding all nodules)."""
    m = labels == k
    ring = ndimage.binary_dilation(m, iterations=outer) & ~ndimage.binary_dilation(m, iterations=inner)
    return ring & (labels == 0)
