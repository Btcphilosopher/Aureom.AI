"""Nodule detection, measurement and persistent registry."""
