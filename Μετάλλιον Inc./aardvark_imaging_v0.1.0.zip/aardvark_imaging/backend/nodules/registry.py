"""Persistent nodule records and re-identification across survey passes."""
from __future__ import annotations

from datetime import datetime
from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict, Field
from scipy.spatial import cKDTree

from ..core.ids import nodule_id
from ..core.provenance import DataOrigin, utcnow


class NoduleObservation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    observation_id: str
    time_utc: datetime = Field(default_factory=utcnow)
    sensor: str
    survey_line: str | None = None
    east_m: float
    north_m: float
    position_std_m: float
    measurements: dict[str, Any]
    classification: dict[str, float] = Field(default_factory=dict)
    carbon: dict[str, Any] | None = None
    quality: dict[str, float] = Field(default_factory=dict)
    data_origin: DataOrigin
    provenance_ids: list[str] = Field(default_factory=list)


class NoduleRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")
    nodule_id: str
    survey_id: str
    east_m: float
    north_m: float
    observations: list[NoduleObservation] = Field(default_factory=list)
    assay_sample_ids: list[str] = Field(default_factory=list)
    xrd_sample_ids: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)

    @property
    def data_origin(self) -> DataOrigin:
        o = {ob.data_origin for ob in self.observations}
        return DataOrigin.SIMULATED if DataOrigin.SIMULATED in o else DataOrigin.ESTIMATED


class NoduleRegistry:
    """Assigns persistent IDs and merges repeat observations by position.

    A new observation joins an existing record when it lies within
    ``max(k_sigma * combined position std, min_radius_m)`` of it and no
    closer record exists; otherwise it creates a new record.
    """

    def __init__(self, survey_id: str, *, k_sigma: float = 3.0, min_radius_m: float = 0.02):
        self.survey_id = survey_id
        self.k_sigma = k_sigma
        self.min_radius_m = min_radius_m
        self.records: dict[str, NoduleRecord] = {}
        self._pos_std: dict[str, float] = {}

    def _tree(self):
        ids = list(self.records)
        if not ids:
            return None, ids
        pts = np.array([[self.records[i].east_m, self.records[i].north_m] for i in ids])
        return cKDTree(pts), ids

    def add(self, obs: NoduleObservation) -> tuple[str, bool]:
        """Returns (nodule_id, is_new)."""
        tree, ids = self._tree()
        if tree is not None:
            d, j = tree.query([obs.east_m, obs.north_m])
            rid = ids[int(j)]
            gate = max(self.k_sigma * float(np.hypot(obs.position_std_m, self._pos_std[rid])), self.min_radius_m)
            if d <= gate:
                rec = self.records[rid]
                rec.observations.append(obs)
                w = 1.0 / np.array([o.position_std_m ** 2 for o in rec.observations])
                rec.east_m = float(np.sum(w * [o.east_m for o in rec.observations]) / w.sum())
                rec.north_m = float(np.sum(w * [o.north_m for o in rec.observations]) / w.sum())
                self._pos_std[rid] = float(1 / np.sqrt(w.sum()))
                return rid, False
        nid = nodule_id(self.survey_id, obs.east_m, obs.north_m)
        base, k = nid, 1
        while nid in self.records:
            nid = f"{base}-{k}"
            k += 1
        self.records[nid] = NoduleRecord(nodule_id=nid, survey_id=self.survey_id, east_m=obs.east_m,
                                         north_m=obs.north_m, observations=[obs])
        self._pos_std[nid] = obs.position_std_m
        return nid, True

    def link_assay(self, nodule: str, sample_id: str) -> None:
        self.records[nodule].assay_sample_ids.append(sample_id)

    def __len__(self) -> int:
        return len(self.records)
