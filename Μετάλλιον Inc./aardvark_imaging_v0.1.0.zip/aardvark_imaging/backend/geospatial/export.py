"""Exports to standard scientific and geospatial formats.

GeoJSON (RFC 7946, WGS-84 lon/lat), ESRI ASCII grid (local metric grid with
a sidecar .json describing the ENU origin), PLY meshes, CSV, NetCDF (via
xarray's SciPy backend) and Zarr. Every file records its data origin.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Iterable

import numpy as np
import xarray as xr

from ..sensor_fusion.frames import enu_to_geodetic
from .grid import GridSpec


def _ll(grid_or_origin, east, north):
    lat0, lon0, h0 = grid_or_origin
    lat, lon, _ = enu_to_geodetic(np.column_stack([np.atleast_1d(east), np.atleast_1d(north),
                                                   np.zeros(np.size(east))]), lat0, lon0, h0)
    return np.atleast_1d(lon), np.atleast_1d(lat)


def nodules_geojson(records: Iterable[dict], origin: tuple[float, float, float], path: str | Path, *, data_origin: str) -> Path:
    feats = []
    for r in records:
        lon, lat = _ll(origin, r["east_m"], r["north_m"])
        props = {k: v for k, v in r.items() if k not in ("east_m", "north_m") and not isinstance(v, (list, dict))}
        props.update(east_m=r["east_m"], north_m=r["north_m"], data_origin=data_origin)
        feats.append({"type": "Feature", "geometry": {"type": "Point", "coordinates": [float(lon[0]), float(lat[0])]},
                      "properties": props})
    fc = {"type": "FeatureCollection", "features": feats, "properties": {"data_origin": data_origin}}
    p = Path(path)
    p.write_text(json.dumps(fc, default=float))
    return p


def track_geojson(east, north, origin, path, *, data_origin: str) -> Path:
    lon, lat = _ll(origin, east, north)
    fc = {"type": "FeatureCollection", "properties": {"data_origin": data_origin},
          "features": [{"type": "Feature", "properties": {"kind": "survey_track", "data_origin": data_origin},
                        "geometry": {"type": "LineString", "coordinates": [[float(a), float(b)] for a, b in zip(lon, lat)]}}]}
    p = Path(path)
    p.write_text(json.dumps(fc))
    return p


def esri_ascii(grid: GridSpec, values: np.ndarray, path: str | Path, *, nodata: float = -9999.0, data_origin: str) -> Path:
    """ESRI ASCII raster (rows north->south) + JSON sidecar with the ENU anchor."""
    p = Path(path)
    v = np.where(np.isfinite(values), values, nodata)[::-1]
    with open(p, "w") as fh:
        fh.write(f"ncols {grid.nx}\nnrows {grid.ny}\nxllcorner {grid.east0 - grid.resolution_m / 2:.6f}\n")
        fh.write(f"yllcorner {grid.north0 - grid.resolution_m / 2:.6f}\ncellsize {grid.resolution_m:.6f}\n")
        fh.write(f"NODATA_value {nodata}\n")
        np.savetxt(fh, v, fmt="%.6g")
    p.with_suffix(".json").write_text(json.dumps({"crs": "local ENU (metres)", "origin_lat": grid.origin_lat,
                                                  "origin_lon": grid.origin_lon, "origin_h": grid.origin_h,
                                                  "data_origin": data_origin}))
    return p


def read_esri_ascii(path) -> tuple[dict, np.ndarray]:
    lines = Path(path).read_text().splitlines()
    hdr = {}
    for ln in lines[:6]:
        k, v = ln.split()
        hdr[k.lower()] = float(v)
    data = np.loadtxt(lines[6:])
    data = np.where(data == hdr["nodata_value"], np.nan, data)[::-1]
    return hdr, data


def ply_mesh(east, north, z, path: str | Path, *, colors=None, comment: str = "") -> Path:
    """ASCII PLY triangulated height field from a regular grid (NaN cells skipped)."""
    E, N = np.meshgrid(east, north)
    Z = np.asarray(z, dtype=float)
    ny, nx = Z.shape
    vid = -np.ones((ny, nx), dtype=int)
    verts = []
    for i in range(ny):
        for j in range(nx):
            if np.isfinite(Z[i, j]):
                vid[i, j] = len(verts)
                verts.append((E[i, j], N[i, j], -Z[i, j]))
    faces = []
    for i in range(ny - 1):
        for j in range(nx - 1):
            a, b, c, d = vid[i, j], vid[i, j + 1], vid[i + 1, j], vid[i + 1, j + 1]
            if min(a, b, c) >= 0:
                faces.append((a, b, c))
            if min(b, d, c) >= 0:
                faces.append((b, d, c))
    p = Path(path)
    with open(p, "w") as fh:
        fh.write("ply\nformat ascii 1.0\n")
        if comment:
            fh.write(f"comment {comment}\n")
        fh.write(f"element vertex {len(verts)}\nproperty float x\nproperty float y\nproperty float z\n")
        if colors is not None:
            fh.write("property uchar red\nproperty uchar green\nproperty uchar blue\n")
        fh.write(f"element face {len(faces)}\nproperty list uchar int vertex_indices\nend_header\n")
        cols = None if colors is None else np.asarray(colors).reshape(-1, 3)
        k = 0
        for i in range(ny):
            for j in range(nx):
                if vid[i, j] >= 0:
                    x, y, zz = verts[vid[i, j]]
                    if cols is not None:
                        r, g, b = cols[i * nx + j]
                        fh.write(f"{x:.4f} {y:.4f} {zz:.4f} {int(r)} {int(g)} {int(b)}\n")
                    else:
                        fh.write(f"{x:.4f} {y:.4f} {zz:.4f}\n")
                    k += 1
        for f in faces:
            fh.write(f"3 {f[0]} {f[1]} {f[2]}\n")
    return p


def table_csv(rows: list[dict], path: str | Path) -> Path:
    p = Path(path)
    keys = sorted({k for r in rows for k in r})
    with open(p, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    return p


def dataset_netcdf(ds: xr.Dataset, path: str | Path) -> Path:
    p = Path(path)
    ds.to_netcdf(p, engine="scipy")
    return p


def dataset_zarr(ds: xr.Dataset, path: str | Path) -> Path:
    p = Path(path)
    ds.to_zarr(p, mode="w-")
    return p
