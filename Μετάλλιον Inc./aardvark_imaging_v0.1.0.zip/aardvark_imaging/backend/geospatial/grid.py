"""Regular grids in a local ENU frame anchored at a geodetic origin."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class GridSpec:
    east0: float
    north0: float
    resolution_m: float
    nx: int
    ny: int
    origin_lat: float
    origin_lon: float
    origin_h: float = 0.0

    @property
    def east(self) -> np.ndarray:
        return self.east0 + self.resolution_m * np.arange(self.nx)

    @property
    def north(self) -> np.ndarray:
        return self.north0 + self.resolution_m * np.arange(self.ny)

    @property
    def cell_area_m2(self) -> float:
        return self.resolution_m ** 2

    def index(self, east, north):
        ix = np.floor((np.asarray(east) - self.east0) / self.resolution_m + 0.5).astype(int)
        iy = np.floor((np.asarray(north) - self.north0) / self.resolution_m + 0.5).astype(int)
        ok = (ix >= 0) & (ix < self.nx) & (iy >= 0) & (iy < self.ny)
        return ix, iy, ok

    @classmethod
    def covering(cls, east, north, resolution_m, origin_lat, origin_lon, pad: float = 0.0):
        e0, e1 = float(np.min(east)) - pad, float(np.max(east)) + pad
        n0, n1 = float(np.min(north)) - pad, float(np.max(north)) + pad
        return cls(e0, n0, resolution_m, int(np.ceil((e1 - e0) / resolution_m)) + 1,
                   int(np.ceil((n1 - n0) / resolution_m)) + 1, origin_lat, origin_lon)


def bin_statistic(grid: GridSpec, east, north, values=None, stat: str = "sum") -> np.ndarray:
    ix, iy, ok = grid.index(east, north)
    out = np.zeros((grid.ny, grid.nx))
    v = np.ones(np.size(east)) if values is None else np.asarray(values, dtype=float)
    np.add.at(out, (iy[ok], ix[ok]), v[ok])
    if stat == "mean":
        cnt = np.zeros_like(out)
        np.add.at(cnt, (iy[ok], ix[ok]), 1)
        out = np.where(cnt > 0, out / np.maximum(cnt, 1), np.nan)
    return out
