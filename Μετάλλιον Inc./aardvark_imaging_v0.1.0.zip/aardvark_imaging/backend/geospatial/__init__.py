"""Geospatial grids and standard-format exports."""
