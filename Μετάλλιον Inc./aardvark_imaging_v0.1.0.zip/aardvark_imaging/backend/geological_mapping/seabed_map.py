"""Three-dimensional seabed geological model.

Combines the multibeam DEM, georeferenced nodule records and per-nodule /
per-point mineral and carbon results into gridded layers:

* bathymetry (+ sounding std and count)       MEASURED (from soundings)
* nodule count density (per m2), coverage (%) ESTIMATED
* nodule abundance (kg/m2 wet) with std       ESTIMATED (mass model)
* dominant mineral class and its probability  ESTIMATED
* carbon layers (carbonate, carbonaceous, organic) + confidence
* sediment class
* survey tracks
* observation density / confidence layers
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import xarray as xr

from ..core.provenance import DataOrigin
from ..geospatial.grid import GridSpec, bin_statistic


@dataclass
class SeabedMap:
    grid: GridSpec
    layers: xr.Dataset
    tracks: list[np.ndarray] = field(default_factory=list)
    data_origin: DataOrigin = DataOrigin.ESTIMATED

    def layer_names(self) -> list[str]:
        return list(self.layers.data_vars)


def build_seabed_map(grid: GridSpec, *, dem: xr.Dataset | None, nodules: list[dict], imaged_mask=None,
                     carbon_layers: dict[str, np.ndarray] | None = None, sediment_class: np.ndarray | None = None,
                     tracks: list[np.ndarray] | None = None, data_origin: DataOrigin = DataOrigin.ESTIMATED) -> SeabedMap:
    """``nodules``: dicts with east_m, north_m, area_m2, mass_g, mass_std_g,
    top_class, top_prob. ``imaged_mask``: grid cells actually imaged (so
    density is computed over observed area only, never extrapolated)."""
    e = np.array([n["east_m"] for n in nodules]) if nodules else np.zeros(0)
    nn = np.array([n["north_m"] for n in nodules]) if nodules else np.zeros(0)
    A = grid.cell_area_m2
    imaged = np.ones((grid.ny, grid.nx), dtype=bool) if imaged_mask is None else np.asarray(imaged_mask, bool)
    count = bin_statistic(grid, e, nn)
    area = bin_statistic(grid, e, nn, [n["area_m2"] for n in nodules])
    mass = bin_statistic(grid, e, nn, [n["mass_g"] for n in nodules])
    mvar = bin_statistic(grid, e, nn, [n.get("mass_std_g", 0.0) ** 2 for n in nodules])
    unobs = ~imaged
    density = np.where(unobs, np.nan, count / A)
    coverage = np.where(unobs, np.nan, 100 * area / A)
    abundance = np.where(unobs, np.nan, mass / 1000 / A)
    abundance_std = np.where(unobs, np.nan, np.sqrt(mvar) / 1000 / A)
    classes = sorted({n["top_class"] for n in nodules}) if nodules else []
    dom = np.full((grid.ny, grid.nx), -1, dtype=int)
    domp = np.full((grid.ny, grid.nx), np.nan)
    if classes:
        votes = np.zeros((len(classes), grid.ny, grid.nx))
        for k, c in enumerate(classes):
            sel = [i for i, n in enumerate(nodules) if n["top_class"] == c]
            votes[k] = bin_statistic(grid, e[sel], nn[sel], [nodules[i]["top_prob"] for i in sel])
        tot = votes.sum(0)
        dom = np.where(tot > 0, np.argmax(votes, 0), -1)
        domp = np.where(tot > 0, votes.max(0) / np.maximum(tot, 1e-12), np.nan)
    ds = xr.Dataset(coords={"north": grid.north, "east": grid.east})
    if dem is not None:
        ds["depth"] = (("north", "east"), dem["depth"].interp(north=grid.north, east=grid.east).values)
        if "depth_std" in dem:
            ds["depth_std"] = (("north", "east"), dem["depth_std"].interp(north=grid.north, east=grid.east).values)
    ds["nodule_density_per_m2"] = (("north", "east"), density)
    ds["nodule_coverage_pct"] = (("north", "east"), coverage)
    ds["nodule_abundance_kg_m2"] = (("north", "east"), abundance)
    ds["nodule_abundance_std_kg_m2"] = (("north", "east"), abundance_std)
    ds["dominant_mineral_class"] = (("north", "east"), dom)
    ds["dominant_mineral_probability"] = (("north", "east"), domp)
    ds["imaged"] = (("north", "east"), imaged.astype(np.int8))
    if carbon_layers:
        for k, v in carbon_layers.items():
            ds[f"carbon_{k}"] = (("north", "east"), np.asarray(v, dtype=float))
    if sediment_class is not None:
        ds["sediment_class"] = (("north", "east"), np.asarray(sediment_class))
    ds.attrs.update(mineral_classes=",".join(classes), data_origin=data_origin.value,
                    resolution_m=grid.resolution_m, origin_lat=grid.origin_lat, origin_lon=grid.origin_lon,
                    abundance_basis="sum of per-nodule mass estimates (ellipsoid x wet bulk density) per imaged cell")
    return SeabedMap(grid, ds, list(tracks or []), data_origin)


def survey_statistics(m: SeabedMap) -> dict:
    ds = m.layers
    imaged = ds["imaged"].values.astype(bool)
    area = imaged.sum() * m.grid.cell_area_m2
    ab = ds["nodule_abundance_kg_m2"].values
    out = {"imaged_area_m2": float(area),
           "mean_abundance_kg_m2": float(np.nanmean(ab[imaged])) if imaged.any() else None,
           "mean_density_per_m2": float(np.nanmean(ds["nodule_density_per_m2"].values[imaged])) if imaged.any() else None,
           "data_origin": m.data_origin.value}
    if "depth" in ds:
        d = ds["depth"].values
        out["depth_range_m"] = (float(np.nanmin(d)), float(np.nanmax(d)))
    return out


def frontend_payload(m: SeabedMap, *, max_cells: int = 128) -> dict:
    """Downsampled mesh + layers for the WebGL workstation."""
    ds = m.layers
    step = max(1, int(np.ceil(max(m.grid.nx, m.grid.ny) / max_cells)))
    sub = ds.isel(north=slice(None, None, step), east=slice(None, None, step))
    def arr(name):
        if name not in sub:
            return None
        v = sub[name].values.astype(float)
        return [[None if not np.isfinite(x) else round(float(x), 5) for x in row] for row in v]
    return {"east": [float(x) for x in sub.east.values], "north": [float(x) for x in sub.north.values],
            "layers": {k: arr(k) for k in sub.data_vars}, "mineral_classes": ds.attrs.get("mineral_classes", "").split(","),
            "tracks": [[[float(a), float(b)] for a, b in t[:: max(1, len(t) // 400)]] for t in m.tracks],
            "data_origin": m.data_origin.value, "resolution_m": m.grid.resolution_m * step}
