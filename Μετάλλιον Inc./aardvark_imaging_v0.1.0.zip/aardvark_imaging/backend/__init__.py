"""Aardvark Imaging — subsea spectral, carbon-characterisation and mineral-intelligence instrument.

Scientific backend for the Μετάλλιον Inc. polymetallic-nodule survey instrument.
Every data product carries a :class:`~aardvark_imaging.core.provenance.DataOrigin`
(SIMULATED, MEASURED, ESTIMATED or LAB_VALIDATED) and calibration provenance.
"""
__version__ = "0.1.0"
