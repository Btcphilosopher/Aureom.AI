"""Durable raw-packet recorder.

Raw SFP1 packets are appended to segment files *before* any processing, so
the original measurements are never discarded and recording continues no
matter what happens to processing or to remote workstation connections.

Segment file layout::

    file header : b"AARDSPOOL1\\n" + JSON metadata line
    record      : magic u32 0x52504653 ("SFPR") | nwords u32 | host_time f64 |
                  words[nwords] u32 | crc32(record body) u32

Records are flushed (``fsync``) every ``fsync_every`` records and on close.
:func:`recover_segment` truncates a partially written trailing record after
a crash or power loss and reports how many complete records survived.
"""
from __future__ import annotations

import json
import os
import struct
import time
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

import numpy as np

MAGIC = 0x52504653
FILE_HEADER = b"AARDSPOOL1\n"
REC_HDR = struct.Struct("<IId")


@dataclass
class SpoolStats:
    records: int = 0
    bytes: int = 0
    segments: int = 0


class RawSpool:
    def __init__(self, directory: str | Path, *, segment_bytes: int = 256 << 20, fsync_every: int = 64,
                 metadata: dict | None = None):
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.segment_bytes = segment_bytes
        self.fsync_every = fsync_every
        self.metadata = metadata or {}
        self.stats = SpoolStats()
        self._fh = None
        self._pending = 0
        self._seg_index = 0
        self._open_segment()

    def _open_segment(self) -> None:
        if self._fh:
            self._close_fh()
        ts = time.strftime("%Y%m%dT%H%M%S", time.gmtime())
        path = self.dir / f"raw_{ts}_{self._seg_index:05d}.sfp"
        while path.exists():
            self._seg_index += 1
            path = self.dir / f"raw_{ts}_{self._seg_index:05d}.sfp"
        self._seg_index += 1
        self._path = path
        self._fh = open(path, "xb")      # never overwrite an existing segment
        meta = dict(self.metadata, created_unix=time.time(), format="SFP1 raw spool v1")
        self._fh.write(FILE_HEADER + json.dumps(meta).encode() + b"\n")
        self._seg_bytes = self._fh.tell()
        self.stats.segments += 1

    def write(self, words, host_time: float | None = None) -> None:
        w = np.ascontiguousarray(np.asarray(words, dtype="<u4"))
        body = REC_HDR.pack(MAGIC, w.size, host_time if host_time is not None else time.time()) + w.tobytes()
        rec = body + struct.pack("<I", zlib.crc32(body) & 0xFFFFFFFF)
        if self._seg_bytes + len(rec) > self.segment_bytes and self._seg_bytes > len(FILE_HEADER) + 2:
            self._open_segment()
        self._fh.write(rec)
        self._seg_bytes += len(rec)
        self.stats.records += 1
        self.stats.bytes += len(rec)
        self._pending += 1
        if self._pending >= self.fsync_every:
            self.flush()

    def flush(self) -> None:
        if self._fh:
            self._fh.flush()
            os.fsync(self._fh.fileno())
            self._pending = 0

    def _close_fh(self) -> None:
        self.flush()
        self._fh.close()
        self._fh = None

    def close(self) -> None:
        if self._fh:
            self._close_fh()

    @property
    def current_segment(self) -> Path:
        return self._path

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def _read_header(fh) -> dict:
    magic = fh.read(len(FILE_HEADER))
    if magic != FILE_HEADER:
        raise ValueError("not an Aardvark raw spool segment")
    return json.loads(fh.readline())


def iter_segment(path: str | Path) -> Iterator[tuple[float, np.ndarray]]:
    with open(path, "rb") as fh:
        _read_header(fh)
        while True:
            hdr = fh.read(REC_HDR.size)
            if len(hdr) < REC_HDR.size:
                return
            magic, n, t = REC_HDR.unpack(hdr)
            if magic != MAGIC:
                raise ValueError(f"{path}: bad record magic at {fh.tell() - REC_HDR.size}")
            data = fh.read(4 * n + 4)
            if len(data) < 4 * n + 4:
                return
            crc = struct.unpack("<I", data[-4:])[0]
            if zlib.crc32(hdr + data[:-4]) & 0xFFFFFFFF != crc:
                raise ValueError(f"{path}: record CRC mismatch")
            yield t, np.frombuffer(data[:-4], dtype="<u4").copy()


def iter_spool(directory: str | Path) -> Iterator[tuple[float, np.ndarray]]:
    for seg in sorted(Path(directory).glob("raw_*.sfp")):
        yield from iter_segment(seg)


def recover_segment(path: str | Path) -> int:
    """Truncate a torn trailing record; return the number of intact records."""
    path = Path(path)
    good_end = None
    count = 0
    with open(path, "rb") as fh:
        _read_header(fh)
        good_end = fh.tell()
        while True:
            pos = fh.tell()
            hdr = fh.read(REC_HDR.size)
            if len(hdr) < REC_HDR.size:
                break
            magic, n, _ = REC_HDR.unpack(hdr)
            data = fh.read(4 * n + 4)
            if magic != MAGIC or len(data) < 4 * n + 4:
                break
            if zlib.crc32(hdr + data[:-4]) & 0xFFFFFFFF != struct.unpack("<I", data[-4:])[0]:
                break
            count += 1
            good_end = fh.tell()
            del pos
    if good_end is not None and good_end < path.stat().st_size:
        with open(path, "r+b") as fh:
            fh.truncate(good_end)
    return count
