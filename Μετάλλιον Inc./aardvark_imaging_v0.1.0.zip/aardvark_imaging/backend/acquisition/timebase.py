"""Hardware timestamp -> UTC mapping from PPS latches.

The FPGA latches its 64-bit clk_sys counter at every GNSS PPS edge. Pairing
those latches with the UTC second each PPS marks (from the GNSS receiver's
time message) gives a linear model ``utc = t0 + (ticks - k0) / f`` whose
fitted frequency also measures the oscillator offset (ppm) and whose
residuals bound the timing uncertainty.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class TimebaseModel:
    nominal_hz: float
    hz: float
    k0: int
    t0: float
    residual_std_s: float
    n_pps: int

    @property
    def drift_ppm(self) -> float:
        return (self.hz / self.nominal_hz - 1.0) * 1e6

    def to_utc(self, ticks) -> np.ndarray | float:
        t = (np.asarray(ticks, dtype=np.float64) - float(self.k0)) / self.hz + self.t0
        return float(t) if np.ndim(t) == 0 else t

    def to_ticks(self, utc) -> np.ndarray | int:
        k = (np.asarray(utc, dtype=np.float64) - self.t0) * self.hz + self.k0
        return int(round(float(k))) if np.ndim(k) == 0 else np.rint(k).astype(np.int64)


def fit_timebase(pps_ticks, utc_seconds, nominal_hz: float = 100e6) -> TimebaseModel:
    k = np.asarray(pps_ticks, dtype=np.int64)
    t = np.asarray(utc_seconds, dtype=np.float64)
    if k.size < 2 or k.size != t.size:
        raise ValueError("need >= 2 matching PPS latches and UTC seconds")
    if np.any(np.diff(k) <= 0):
        raise ValueError("PPS latches must be strictly increasing")
    k0 = int(k[0])
    x = (k - k0).astype(np.float64)
    y = t - t[0]
    slope, intercept = np.polyfit(x, y, 1)     # seconds per tick
    resid = y - (slope * x + intercept)
    return TimebaseModel(nominal_hz=nominal_hz, hz=1.0 / slope, k0=k0, t0=float(t[0] + intercept),
                         residual_std_s=float(np.std(resid)) if k.size > 2 else 0.0, n_pps=int(k.size))
