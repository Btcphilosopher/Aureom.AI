"""Bit-exact Python reference models of the Silica Flux RTL datapaths.

These are executable specifications: the RTL testbenches dump their stimulus
and responses, and ``tests/hardware/test_rtl_crosscheck.py`` requires the
models below to reproduce them exactly. The same models are used by the host
software (e.g. to build FPGA calibration tables and to regenerate expected
test-pattern data).
"""
from __future__ import annotations

import zlib

import numpy as np

from ..silica_flux.codegen import sine_quarter_rom

PIX_SAT = 0xFFFF
PIX_BAD = 0xFFFE
PIX_MAX = 0xFFFD
GAIN_ONE = 1 << 14   # u2.14


# --------------------------------------------------------------------- calibration
def calibrate_pixels(raw, dark, gain, bad, oob, cal_en, sat_level):
    """Model of ``sf_calibration_engine`` (vectorised).

    Returns ``(out, sat, bad_flag, clip, cal)`` as numpy arrays.
    """
    raw = np.asarray(raw, dtype=np.int64)
    oob = np.asarray(oob, dtype=bool)
    dark = np.where(oob, 0, np.asarray(dark, dtype=np.int64))
    gain = np.where(oob, GAIN_ONE, np.asarray(gain, dtype=np.int64))
    badm = np.where(oob, False, np.asarray(bad, dtype=bool))
    cal_en = np.broadcast_to(np.asarray(cal_en, dtype=bool), raw.shape)
    sat_level = np.broadcast_to(np.asarray(sat_level, dtype=np.int64), raw.shape)
    sat = raw >= sat_level
    bad_flag = badm & cal_en
    diff = np.where(raw > dark, raw - dark, 0)
    y = (diff * gain + 8192) >> 14
    cal_val = np.minimum(y, PIX_MAX)
    byp_val = np.minimum(raw, PIX_MAX)
    clip = np.where(cal_en, y > PIX_MAX, raw > PIX_MAX) & ~bad_flag & ~sat
    out = np.where(cal_en, cal_val, byp_val)
    out = np.where(sat, PIX_SAT, out)
    out = np.where(bad_flag, PIX_BAD, out)
    return out.astype(np.uint16), sat, bad_flag, clip, cal_en & ~oob


def gain_to_u2_14(gain) -> np.ndarray:
    """Quantise a floating-point flat-field gain to the FPGA u2.14 format."""
    g = np.rint(np.asarray(gain, dtype=float) * GAIN_ONE)
    if np.any(g < 0) or np.any(g > 0xFFFF):
        raise ValueError("gain outside u2.14 range [0, 3.99994]")
    return g.astype(np.uint16)


# --------------------------------------------------------------------- CRC
def crc32_words(words) -> int:
    """CRC-32/ISO-HDLC of 32-bit words fed as little-endian bytes (zlib)."""
    w = np.ascontiguousarray(np.asarray(words, dtype="<u4"))
    return zlib.crc32(w.tobytes()) & 0xFFFFFFFF


# --------------------------------------------------------------------- DDS / EM I/Q
_ROM = np.array(sine_quarter_rom(), dtype=np.int64)


def dds_lookup(phase32) -> tuple[np.ndarray, np.ndarray]:
    """Q15 (sin, cos) of 32-bit DDS phases exactly as ``sf_em_induction``."""
    p = (np.asarray(phase32, dtype=np.uint64) >> np.uint64(22)).astype(np.int64) & 0x3FF

    def look(p10):
        p9 = p10 & 0x1FF
        idx = np.where(p9 & 0x100, (~p9) & 0xFF, p9 & 0xFF)
        v = _ROM[idx]
        return np.where(p10 & 0x200, -v, v)

    return look(p), look((p + 256) & 0x3FF)


def em_iq_model(k, rx, ref, ftw: int) -> tuple[int, int, int, int]:
    """Accumulators of ``sf_em_induction`` for conversions ``k`` (tick index
    since enable) with signed 16-bit receiver/reference samples."""
    k = np.asarray(k, dtype=np.uint64)
    phase = (k * np.uint64(ftw)) & np.uint64(0xFFFFFFFF)
    s, c = dds_lookup(phase)
    rx = np.asarray(rx, dtype=np.int64)
    ref = np.asarray(ref, dtype=np.int64)
    return int(np.sum(rx * s)), int(np.sum(rx * c)), int(np.sum(ref * s)), int(np.sum(ref * c))


def iq_to_amplitude_phase(i: float, q: float, n: int) -> tuple[float, float]:
    """Amplitude (ADC codes) and phase (degrees) from I/Q accumulators."""
    scale = n * 32767.0 / 2.0
    return float(np.hypot(i, q) / scale), float(np.degrees(np.arctan2(q, i)))


ROM_PHASE_BIAS_DEG = -0.5 * 360.0 / 1024.0   # half-sample table offset seen as a phase lag


# --------------------------------------------------------------------- test sources
def test_pattern_frame(frame: int, rows: int, pixels: int) -> np.ndarray:
    """``sf_test_pattern`` output for one frame (rows x pixels, uint16)."""
    r = np.arange(rows)[:, None]
    c = np.arange(pixels)[None, :]
    v = ((frame * 31 + r * 7 + c * 3) & 0xFFFF) & 0x0FFF
    v = v.astype(np.uint16)
    v[0, 0] = 0x0FFF
    return v


def adc_test_code(k, lane: int, bits: int, offset: int):
    """``sf_adc_test_source`` code for conversion ``k`` on ``lane``."""
    k = np.asarray(k, dtype=np.int64)
    return ((37 * (lane + 1) * k + 1000 * lane + offset) & 0xFFFFFFFF) % (1 << bits)


def to_signed(v, bits: int):
    v = np.asarray(v, dtype=np.int64)
    return np.where(v >= (1 << (bits - 1)), v - (1 << bits), v)
