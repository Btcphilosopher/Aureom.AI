"""Host side of the FPGA ring-buffer DMA.

:class:`RingReader` consumes committed packets between the host read pointer
and the FPGA write pointer, handling wrap-around, and reports sequence gaps
(packets dropped by the FPGA for lack of ring space). The memory source is
abstract so the same reader works on a simulated ring and on a real
UIO/mmap'd buffer (:class:`MmapRing`; tested against a file-backed mapping,
not against a real UIO device).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

import numpy as np

from .sfp import DecodeResult, SfpPacket, decode_words


class RingMemory(Protocol):
    size_bytes: int

    def read_words(self, offset_bytes: int, nwords: int) -> np.ndarray: ...


class ArrayRing:
    """Ring memory backed by a numpy array (simulation, tests, file dumps)."""

    def __init__(self, size_bytes: int):
        if size_bytes & (size_bytes - 1) or size_bytes < 256:
            raise ValueError("ring size must be a power of two >= 256")
        self.size_bytes = size_bytes
        self.mem = np.zeros(size_bytes // 4, dtype=np.uint32)
        self.wr_ptr = 0

    def read_words(self, offset_bytes: int, nwords: int) -> np.ndarray:
        n = self.mem.size
        idx = (offset_bytes // 4 + np.arange(nwords)) % n
        return self.mem[idx]

    def free_bytes(self, rd_ptr: int) -> int:
        return self.size_bytes - ((self.wr_ptr - rd_ptr) % self.size_bytes) - 4

    def write_packet(self, words: np.ndarray, rd_ptr: int) -> bool:
        """Packet-atomic write with the same admission rule as the RTL."""
        need = int(words.size) * 4
        if need > self.free_bytes(rd_ptr):
            return False
        n = self.mem.size
        idx = (self.wr_ptr // 4 + np.arange(words.size)) % n
        self.mem[idx] = words
        self.wr_ptr = (self.wr_ptr + need) % self.size_bytes
        return True


class MmapRing:
    """Ring memory in a physically contiguous buffer exposed through UIO."""

    def __init__(self, device: str, size_bytes: int, offset: int = 0):
        import mmap
        import os

        self.size_bytes = size_bytes
        self._fd = os.open(device, os.O_RDONLY | os.O_SYNC)
        self._mm = mmap.mmap(self._fd, size_bytes, mmap.MAP_SHARED, mmap.PROT_READ, offset=offset)
        self._view = np.frombuffer(self._mm, dtype="<u4")

    def read_words(self, offset_bytes: int, nwords: int) -> np.ndarray:
        idx = (offset_bytes // 4 + np.arange(nwords)) % self._view.size
        return np.array(self._view[idx], dtype=np.uint32)


@dataclass
class RingReader:
    memory: RingMemory
    rd_ptr: int = 0
    last_seq: int | None = None
    gaps: list[tuple[int, int]] = field(default_factory=list)
    corrupt: int = 0

    def poll(self, wr_ptr: int) -> list[SfpPacket]:
        """Consume all committed packets up to ``wr_ptr``; return them."""
        size = self.memory.size_bytes
        avail = (wr_ptr - self.rd_ptr) % size
        if avail == 0:
            return []
        words = self.memory.read_words(self.rd_ptr, avail // 4)
        res: DecodeResult = decode_words(words)
        self.corrupt += len([e for e in res.errors if e.kind in ("crc", "bad_length")])
        for p in res.packets:
            if self.last_seq is not None and (self.last_seq + 1) & 0xFFFFFFFF != p.seq:
                self.gaps.append(((self.last_seq + 1) & 0xFFFFFFFF, p.seq))
            self.last_seq = p.seq
        # WR_PTR is packet-granular, so everything available was decodable.
        self.rd_ptr = wr_ptr
        return res.packets

    @property
    def dropped_packets(self) -> int:
        return sum((b - a) & 0xFFFFFFFF for a, b in self.gaps)
