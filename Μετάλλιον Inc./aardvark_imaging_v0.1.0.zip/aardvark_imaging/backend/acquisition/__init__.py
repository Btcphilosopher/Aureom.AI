"""Acquisition: SFP1 packets, DMA ring reading, raw spooling, timebase, register map."""
