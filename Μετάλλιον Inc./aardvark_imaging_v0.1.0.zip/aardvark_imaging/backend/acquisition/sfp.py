"""SFP1 packet format: decoder, encoder and payload interpreters.

Wire format (32-bit little-endian words), produced by ``sf_packetizer``::

    W0 SYNC "SFP1"          W1 {version, sensor_uid, packet_type, flags}
    W2 global sequence      W3 frame counter
    W4 timestamp[63:32]     W5 timestamp[31:0]
    W6 {payload_words, row} W7 meta
    payload...              CRC-32/ISO-HDLC over W0..last payload word
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import generated_regmap as rm
from .fixedpoint import PIX_BAD, PIX_SAT, crc32_words, to_signed

SYNC = rm.SYNC_WORD
HDR = rm.HEADER_WORDS
FLAG_BITS = rm.PACKET_FLAGS
TYPE_NAMES = rm.PACKET_TYPE_NAMES
SENSOR_BY_UID = rm.SENSOR_BY_UID


@dataclass
class SfpPacket:
    offset: int                 # word offset in the decoded stream
    version: int
    sensor_uid: int
    packet_type: int
    flags: int
    seq: int
    frame: int
    timestamp: int
    payload_words: int
    row: int
    meta: int
    payload: np.ndarray
    crc: int
    crc_ok: bool

    @property
    def sensor_key(self) -> str:
        return SENSOR_BY_UID.get(self.sensor_uid, f"UID_{self.sensor_uid:02X}")

    @property
    def type_name(self) -> str:
        return TYPE_NAMES.get(self.packet_type, f"PT_{self.packet_type:02X}")

    def has(self, flag: str) -> bool:
        return bool(self.flags >> FLAG_BITS[flag] & 1)

    @property
    def flag_names(self) -> list[str]:
        return [k for k, b in FLAG_BITS.items() if self.flags >> b & 1]

    @property
    def simulated(self) -> bool:
        return self.has("SIMULATED")

    @property
    def total_words(self) -> int:
        return HDR + self.payload_words + 1


@dataclass
class DecodeError:
    offset: int
    kind: str
    detail: str = ""


@dataclass
class DecodeResult:
    packets: list[SfpPacket] = field(default_factory=list)
    errors: list[DecodeError] = field(default_factory=list)
    consumed_words: int = 0

    def sequence_gaps(self) -> list[tuple[int, int]]:
        """(expected, got) pairs where the global sequence jumped."""
        gaps = []
        for a, b in zip(self.packets, self.packets[1:]):
            if (a.seq + 1) & 0xFFFFFFFF != b.seq:
                gaps.append(((a.seq + 1) & 0xFFFFFFFF, b.seq))
        return gaps


def decode_words(words, *, max_payload: int = rm.MAX_PAYLOAD_WORDS) -> DecodeResult:
    """Decode a contiguous stream of 32-bit words into SFP1 packets.

    Corrupt packets (bad CRC, impossible length) are reported and skipped;
    the decoder resynchronises on the next SYNC word.
    """
    w = np.asarray(words, dtype=np.uint32)
    n = w.size
    res = DecodeResult()
    i = 0
    while i < n:
        if w[i] != SYNC:
            j = i + 1
            hits = np.nonzero(w[j:] == SYNC)[0]
            if hits.size == 0:
                res.errors.append(DecodeError(i, "trailing_garbage", f"{n - i} words"))
                i = n
                break
            res.errors.append(DecodeError(i, "resync", f"skipped {hits[0] + 1} words"))
            i = j + int(hits[0])
            continue
        if i + HDR > n:
            res.errors.append(DecodeError(i, "truncated_header"))
            break
        h = w[i:i + HDR]
        plen = int(h[6] >> 16)
        if plen == 0 or plen > max_payload:
            res.errors.append(DecodeError(i, "bad_length", str(plen)))
            i += 1
            continue
        end = i + HDR + plen
        if end >= n:
            res.errors.append(DecodeError(i, "truncated_packet"))
            break
        crc = int(w[end])
        ok = crc32_words(w[i:end]) == crc
        if not ok:
            res.errors.append(DecodeError(i, "crc", f"0x{crc:08X}"))
            i += 1
            continue
        res.packets.append(SfpPacket(
            offset=i, version=int(h[1] >> 24), sensor_uid=int(h[1] >> 16 & 0xFF), packet_type=int(h[1] >> 8 & 0xFF),
            flags=int(h[1] & 0xFF), seq=int(h[2]), frame=int(h[3]), timestamp=(int(h[4]) << 32) | int(h[5]),
            payload_words=plen, row=int(h[6] & 0xFFFF), meta=int(h[7]), payload=w[i + HDR:end].copy(), crc=crc,
            crc_ok=ok))
        i = end + 1
    res.consumed_words = i
    return res


def encode_packet(*, sensor_uid: int, packet_type: int, flags: int, seq: int, frame: int, timestamp: int,
                  row: int, meta: int, payload) -> np.ndarray:
    """Bit-exact software model of the packetiser output for one packet."""
    p = np.asarray(payload, dtype=np.uint32)
    if not 1 <= p.size <= 0xFFFF:
        raise ValueError("payload must be 1..65535 words")
    hdr = np.array([
        SYNC, (rm.PACKET_VERSION << 24) | (sensor_uid << 16) | (packet_type << 8) | (flags & 0xFF),
        seq & 0xFFFFFFFF, frame & 0xFFFFFFFF, (timestamp >> 32) & 0xFFFFFFFF, timestamp & 0xFFFFFFFF,
        (p.size << 16) | (row & 0xFFFF), meta & 0xFFFFFFFF], dtype=np.uint32)
    body = np.concatenate([hdr, p])
    return np.concatenate([body, np.array([crc32_words(body)], dtype=np.uint32)])


def flags_value(*names: str) -> int:
    v = 0
    for n in names:
        v |= 1 << FLAG_BITS[n]
    return v


# ===================================================================== payloads
def unpack_pixels(payload, npx: int | None = None) -> tuple[np.ma.MaskedArray, np.ndarray, np.ndarray]:
    """16-bit sentinel-coded pixels -> (masked values, saturated mask, bad mask)."""
    p = np.asarray(payload, dtype=np.uint32)
    px = np.empty(p.size * 2, dtype=np.uint16)
    px[0::2] = (p & 0xFFFF).astype(np.uint16)
    px[1::2] = (p >> 16).astype(np.uint16)
    if npx is not None:
        px = px[:npx]
    sat = px == PIX_SAT
    bad = px == PIX_BAD
    return np.ma.masked_array(px, mask=sat | bad), sat, bad


def pack_pixels(px) -> np.ndarray:
    px = np.asarray(px, dtype=np.uint32)
    if px.size % 2:
        px = np.concatenate([px, np.array([PIX_BAD], dtype=np.uint32)])
    return (px[0::2] | (px[1::2] << 16)).astype(np.uint32)


def imager_meta(meta: int) -> dict:
    return {"ts_from_trigger": bool(meta >> 31 & 1), "band": meta >> 16 & 0xFF, "pixel_count": meta & 0xFFFF}


def raman_payload(pkt: SfpPacket) -> dict:
    return {"counts": pkt.payload.astype(np.int64), "coadd": pkt.meta >> 24 & 0xFF, "npix": pkt.meta & 0xFFF,
            "dark": pkt.has("DARK"), "laser_on": pkt.has("LASER_ON"), "saturated": pkt.has("SATURATED")}


def _s64(lo, hi) -> np.ndarray:
    lo = np.asarray(lo, dtype=np.uint64)
    hi = np.asarray(hi, dtype=np.uint64)
    return (lo | (hi << np.uint64(32))).view(np.int64)


def ir_payload(pkt: SfpPacket) -> dict:
    p = pkt.payload.reshape(-1, 4)
    return {"demod": _s64(p[:, 0], p[:, 1]), "total": _s64(p[:, 2], p[:, 3]), "nbands": p.shape[0],
            "half_period": pkt.meta & 0xFFFFFF}


def fluor_payload(pkt: SfpPacket) -> dict:
    p = pkt.payload.reshape(3, 3, 2)
    return {"diff": p[:, :, 0].view(np.int32).astype(np.int64), "off": p[:, :, 1].astype(np.int64),
            "exc_mask": pkt.meta >> 24 & 0x7, "npulses": pkt.meta & 0xFFFF}


def sonar_ping_payload(pkt: SfpPacket) -> dict:
    p = pkt.payload
    return {"ping": int(p[0]), "trigger_ts": (int(p[1]) << 32) | int(p[2]), "ack_ts": (int(p[3]) << 32) | int(p[4]),
            "ack_ok": bool(p[5] & 1)}


def acoustic_payload(pkt: SfpPacket) -> dict:
    nch = pkt.meta >> 24 & 0xFF
    ns = pkt.meta & 0xFFFF
    p = pkt.payload
    s = np.empty(p.size * 2, dtype=np.int16)
    s[0::2] = (p & 0xFFFF).astype(np.uint16).view(np.int16)
    s[1::2] = (p >> 16).astype(np.uint16).view(np.int16)
    return {"samples": s[: ns * nch].reshape(ns, nch), "nch": nch, "ping": pkt.frame, "segment": pkt.row}


def em_payload(pkt: SfpPacket) -> dict:
    p = pkt.payload
    v = _s64(p[0:8:2], p[1:8:2])
    return {"rx_i": int(v[0]), "rx_q": int(v[1]), "ref_i": int(v[2]), "ref_q": int(v[3]), "n": int(p[8] & 0xFFFFFF),
            "ftw": pkt.meta}


def hk_payload(pkt: SfpPacket) -> dict:
    c = pkt.payload & 0xFFFF
    return {"temperature_code": int(c[0]), "rail_code": int(c[1]), "current_code": int(c[2]), "pressure_code": int(c[3])}


def diag_payload(pkt: SfpPacket) -> dict:
    p = pkt.payload.astype(np.uint64)
    errs = []
    for wv in p[5:9]:
        errs += [int(wv & 0xFFFF), int(wv >> 16)]
    return {"uptime_cycles": int(p[0] << 32 | p[1]), "heartbeat": int(p[2]), "err_total": int(p[3]),
            "host_lost": bool(p[4] & 1), "overtemp": bool(p[4] >> 1 & 1), "fault_any": bool(p[4] >> 2 & 1),
            "error_counters": errs, "temperature_code": int(p[9]), "stage_hwm": int(p[10]),
            "status_words": [int(x) for x in p[11:16]]}


def laser_event_payload(pkt: SfpPacket) -> dict:
    c = int(pkt.payload[0])
    return {"emitting": bool(c & 1), "armed": bool(c >> 1 & 1), "emit_start": bool(c >> 4 & 1),
            "abort": bool(c >> 5 & 1), "fault_bits": c >> 8 & 0xF, "sticky_faults": int(pkt.payload[1]) & 0xF}


PAYLOAD_DECODERS = {
    "RAMAN_SPECTRUM": raman_payload, "IR_SWEEP": ir_payload, "FLUOR_BLOCK": fluor_payload,
    "SONAR_PING": sonar_ping_payload, "ACOUSTIC_SAMPLES": acoustic_payload, "EM_IQ": em_payload,
    "HOUSEKEEPING": hk_payload, "DIAGNOSTIC": diag_payload, "LASER_EVENT": laser_event_payload,
}
_ = to_signed
