"""Spatial carbon-characterisation layers.

Point measurements (Raman/IR spots) are interpolated by inverse-distance
weighting with an uncertainty that grows with distance to the nearest
measurement; pixel-wise fluorescence imaging provides the organic layer.
All interpolated layers are ESTIMATED and carry a confidence layer.
"""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree


def idw_layer(points_xy, values, grid_x, grid_y, *, power: float = 2.0, k: int = 8, length_scale: float = 0.5,
              max_distance: float = 3.0):
    """IDW estimate on a grid plus confidence in [0, 1] (exp(-d/length_scale)
    with d the nearest-point distance); cells farther than ``max_distance``
    from any measurement are left undefined (NaN)."""
    pts = np.asarray(points_xy, dtype=float)
    v = np.asarray(values, dtype=float)
    gx, gy = np.meshgrid(grid_x, grid_y)
    q = np.column_stack([gx.ravel(), gy.ravel()])
    tree = cKDTree(pts)
    kk = min(k, len(pts))
    d, i = tree.query(q, k=kk)
    d = np.atleast_2d(d.T).T if kk > 1 else d[:, None]
    i = np.atleast_2d(i.T).T if kk > 1 else i[:, None]
    w = 1.0 / np.maximum(d, 1e-6) ** power
    est = np.sum(w * v[i], axis=1) / np.sum(w, axis=1)
    near = d[:, 0]
    conf = np.exp(-near / length_scale)
    est[near > max_distance] = np.nan
    conf[near > max_distance] = 0.0
    return est.reshape(gx.shape), conf.reshape(gx.shape)


def carbon_layers(results, positions_xy, grid_x, grid_y, *, fluorescence_organic=None) -> dict[str, np.ndarray]:
    """Layers from a list of CarbonCharacterisation results at positions."""
    pts = np.asarray(positions_xy, dtype=float)
    layers = {}
    for name, key in [("carbonaceous_raman", "carbonaceous_coating"), ("carbonate", "carbonate"),
                      ("organic_probability", None)]:
        if key is None:
            vals = [r.organic_probability for r in results]
        else:
            vals = [r.class_probabilities[key] for r in results]
        est, conf = idw_layer(pts, vals, grid_x, grid_y)
        layers[name] = est
        layers[name + "_confidence"] = conf
    if fluorescence_organic is not None:
        layers["fluorescence_organic"] = np.asarray(fluorescence_organic, dtype=float)
    return layers
