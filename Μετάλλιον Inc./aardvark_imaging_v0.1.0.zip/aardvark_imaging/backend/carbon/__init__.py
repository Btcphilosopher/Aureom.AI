"""Carbon imaging and characterisation: Raman carbon evidence, calibrated quantification,
evidence-fusion engine and spatial layers."""
