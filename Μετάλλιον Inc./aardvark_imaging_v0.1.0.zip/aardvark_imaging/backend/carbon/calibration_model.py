"""Laboratory-calibrated carbon quantification (TOC / TIC) models.

A quantitative carbon concentration may only be reported when a model
trained on laboratory measurements of physical samples (TOC, TIC by
coulometry/combustion, carbonate by gasometry, elemental analysis) has been
validated with grouped cross-validation (samples never split across folds)
and the new measurement lies inside the model's applicability domain.
Otherwise :meth:`predict` returns ``None`` with the reason.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..analytics.splits import group_kfold


def pls_fit(X, y, n_components: int):
    """PLS1 regression by NIPALS. Returns (coef, x_mean, y_mean, x_scale)."""
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    xm, ym = X.mean(0), y.mean()
    xs = X.std(0, ddof=1)
    xs[xs == 0] = 1.0
    E = (X - xm) / xs
    f = y - ym
    W, P, Q = [], [], []
    for _ in range(n_components):
        w = E.T @ f
        nw = np.linalg.norm(w)
        if nw < 1e-12:
            break
        w /= nw
        t = E @ w
        tt = t @ t
        p = E.T @ t / tt
        q = f @ t / tt
        E = E - np.outer(t, p)
        f = f - q * t
        W.append(w); P.append(p); Q.append(q)
    W, P, Q = np.array(W).T, np.array(P).T, np.array(Q)
    coef = W @ np.linalg.pinv(P.T @ W) @ Q
    return coef, xm, ym, xs


@dataclass
class CarbonCalibrationModel:
    analyte: str                       # "TOC_wt_pct" | "TIC_wt_pct" | "carbonate_wt_pct"
    feature_names: list[str]
    n_components: int = 2
    min_samples: int = 20
    min_r2_cv: float = 0.7
    coef: np.ndarray | None = None
    x_mean: np.ndarray | None = None
    y_mean: float = 0.0
    x_scale: np.ndarray | None = None
    rmsecv: float | None = None
    r2_cv: float | None = None
    n_samples: int = 0
    n_groups: int = 0
    leverage_limit: float | None = None
    train_scores_cov_inv: np.ndarray | None = None
    validated: bool = False
    reasons: list[str] = field(default_factory=list)

    def fit(self, X, y, groups, *, k: int = 5, seed: int = 0) -> "CarbonCalibrationModel":
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        groups = np.asarray(groups)
        self.n_samples, self.n_groups = len(y), len(np.unique(groups))
        self.reasons = []
        if self.n_groups < self.min_samples:
            self.reasons.append(f"only {self.n_groups} independent physical samples (< {self.min_samples})")
        pred = np.full(len(y), np.nan)
        for tr, te in group_kfold(groups, k=min(k, max(2, self.n_groups)), seed=seed):
            c, xm, ym, xs = pls_fit(X[tr], y[tr], self.n_components)
            pred[te] = ((X[te] - xm) / xs) @ c + ym
        ok = np.isfinite(pred)
        resid = pred[ok] - y[ok]
        self.rmsecv = float(np.sqrt(np.mean(resid ** 2)))
        ss = float(np.sum((y[ok] - y[ok].mean()) ** 2)) or 1e-12
        self.r2_cv = 1.0 - float(np.sum(resid ** 2)) / ss
        if self.r2_cv < self.min_r2_cv:
            self.reasons.append(f"cross-validated R2 {self.r2_cv:.2f} < {self.min_r2_cv}")
        self.coef, self.x_mean, self.y_mean, self.x_scale = pls_fit(X, y, self.n_components)
        Z = (X - self.x_mean) / self.x_scale
        self.train_scores_cov_inv = np.linalg.pinv(np.cov(Z, rowvar=False) + 1e-9 * np.eye(Z.shape[1]))
        d2 = np.einsum("ij,jk,ik->i", Z, self.train_scores_cov_inv, Z)
        self.leverage_limit = float(np.quantile(d2, 0.99) * 1.2)
        self.validated = not self.reasons
        return self

    def predict(self, x) -> tuple[dict | None, str]:
        if self.coef is None:
            return None, "model not trained"
        if not self.validated:
            return None, "model not validated: " + "; ".join(self.reasons)
        z = (np.asarray(x, dtype=float) - self.x_mean) / self.x_scale
        d2 = float(z @ self.train_scores_cov_inv @ z)
        if d2 > self.leverage_limit:
            return None, f"outside applicability domain (Mahalanobis^2 {d2:.1f} > {self.leverage_limit:.1f})"
        v = float(z @ self.coef + self.y_mean)
        half = 1.96 * self.rmsecv * np.sqrt(1 + d2 / max(self.n_samples, 1))
        return {"analyte": self.analyte, "value": v, "interval": (v - half, v + half), "rmsecv": self.rmsecv,
                "r2_cv": self.r2_cv, "n_samples": self.n_samples}, "ok"
