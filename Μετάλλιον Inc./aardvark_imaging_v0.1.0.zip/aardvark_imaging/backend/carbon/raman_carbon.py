"""Raman evidence for carbon-bearing phases.

Two distinct questions, kept separate on purpose:

1. *Carbonaceous material* (disordered sp2 carbon: kerogen-like organics,
   char, graphitic coatings) shows first-order D (~1350 cm^-1) and G
   (~1585 cm^-1) bands. Their widths and ratios describe structural order.
   They are NOT a measurement of how much carbon is present: Raman cross
   sections, absorption depth, laser heating and fluorescence all scale the
   signal independently of concentration.
2. *Carbonate minerals* show the CO3 symmetric stretch nu1 (1080-1100 cm^-1)
   and the in-plane bend nu4 (700-735 cm^-1); nu4 discriminates the
   polymorphs/cations because nu1 positions overlap.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..spectral.raman import BandMatch, ProcessedRaman


@dataclass
class CarbonaceousResult:
    detected: bool
    g_center: float | None = None
    g_fwhm: float | None = None
    d1_center: float | None = None
    d1_fwhm: float | None = None
    r1_height_ratio: float | None = None     # I(D1)/I(G)
    r2_area_ratio: float | None = None       # A(D1)/(A(G)+A(D1)+A(D2))
    g_snr: float = 0.0
    d1_snr: float = 0.0
    order: str = "n/a"
    note: str = ("D/G bands indicate carbonaceous material and its structural order; "
                 "they do not quantify carbon concentration")


def fit_carbonaceous(pr: ProcessedRaman, *, min_snr_g: float = 5.0, min_snr_d: float = 3.0) -> CarbonaceousResult:
    """Fit D1, G, D2 together with the liquid-water bending band.

    The H-O-H bend of the seawater column (~1640 cm^-1, FWHM ~100 cm^-1) sits
    on top of the G/D2 region in every subsea spectrum; without an explicit
    water component a broad G band would be "detected" in pure seawater. The
    water band is fitted as a constrained component (centre 1625-1655, width
    70-140); carbonaceous detection then requires both D1 and G with
    physically plausible positions and widths.
    """
    x, y = pr.shift_cm1, pr.signal
    sel = (x > 1100) & (x < 1800)
    if sel.sum() < 20:
        return CarbonaceousResult(False)
    xs, ys = x[sel], y[sel]
    sig = float(np.median(pr.sigma[sel]))
    hG = max(float(np.max(ys[(xs > 1560) & (xs < 1610)], initial=0.0)), sig)
    hD = max(float(np.max(ys[(xs > 1320) & (xs < 1390)], initial=0.0)), sig)
    hW = max(float(np.max(ys[(xs > 1630) & (xs < 1660)], initial=0.0)), sig)
    from scipy.optimize import least_squares
    from ..spectral.peaks import lorentzian

    def model(p):
        hd, cd, wd, hg, cg, wg, hd2, hw, cw, ww, off = p
        return (lorentzian(xs, hd, cd, wd) + lorentzian(xs, hg, cg, wg) + lorentzian(xs, hd2, 1620.0, 30.0)
                + lorentzian(xs, hw, cw, ww) + off)

    p0 = [hD, 1350, 80, hG, 1588, 45, 0.2 * hG, hW, 1640, 100, 0.0]
    lo = [0, 1320, 30, 0, 1570, 15, 0, 0, 1625, 70, -np.inf]
    hi = [np.inf, 1385, 250, np.inf, 1605, 100, np.inf, np.inf, 1655, 140, np.inf]
    p0 = np.clip(p0, np.array(lo) + 1e-6, np.array(hi) - 1e-6)
    try:
        r = least_squares(lambda p: model(p) - ys, p0, bounds=(lo, hi), x_scale="jac", max_nfev=4000)
    except Exception:
        return CarbonaceousResult(False)
    hd, cd, wd, hg, cg, wg, hd2 = r.x[:7]
    try:
        cov = np.linalg.pinv(r.jac.T @ r.jac) * (np.sum(r.fun ** 2) / max(1, xs.size - r.x.size))
        se = np.sqrt(np.clip(np.diag(cov), 0, None))
    except np.linalg.LinAlgError:
        se = np.full(r.x.size, np.inf)
    # SNR from the height against both the noise and the fit uncertainty
    snr_g = hg / max(np.hypot(sig, se[3]), 1e-9)
    snr_d = hd / max(np.hypot(sig, se[0]), 1e-9)
    detected = bool(snr_g >= min_snr_g and snr_d >= min_snr_d)
    if not detected:
        return CarbonaceousResult(False, g_snr=float(snr_g), d1_snr=float(snr_d))
    aD, aG, aD2 = np.pi * hd * wd / 2, np.pi * hg * wg / 2, np.pi * hd2 * 30.0 / 2
    r1 = hd / hg
    r2 = aD / (aG + aD + aD2)
    order = "well_ordered" if r1 < 0.5 else ("intermediate" if r1 < 1.0 else "poorly_ordered")
    return CarbonaceousResult(True, float(cg), float(wg), float(cd), float(wd), float(r1), float(r2),
                              float(snr_g), float(snr_d), order)


CARBONATE_NU4 = {"calcite": 712.0, "aragonite": 704.0, "dolomite": 725.0, "rhodochrosite": 718.0, "siderite": 731.0}
CARBONATE_NU1 = {"calcite": 1086.0, "aragonite": 1085.0, "dolomite": 1097.0, "rhodochrosite": 1085.0, "siderite": 1088.0}


@dataclass
class CarbonateResult:
    detected: bool
    nu1_center: float | None
    nu1_snr: float
    nu4_center: float | None
    mineral_probabilities: dict[str, float] | None
    note: str


def identify_carbonate(matches: list[BandMatch], *, resolution_cm1: float = 4.0, min_snr: float = 5.0) -> CarbonateResult:
    nu1 = [m for m in matches if 1078 <= m.observed_cm1 <= 1102 and m.snr >= min_snr]
    if not nu1:
        return CarbonateResult(False, None, 0.0, None, None, "no carbonate nu1 band above detection threshold")
    b1 = max(nu1, key=lambda m: m.snr)
    nu4 = [m for m in matches if 695 <= m.observed_cm1 <= 740 and m.snr >= 3.0]
    logl = {}
    for k in CARBONATE_NU1:
        ll = -0.5 * ((b1.observed_cm1 - CARBONATE_NU1[k]) / resolution_cm1) ** 2
        if nu4:
            b4 = max(nu4, key=lambda m: m.snr)
            ll += -0.5 * ((b4.observed_cm1 - CARBONATE_NU4[k]) / resolution_cm1) ** 2
        logl[k] = ll
    m = max(logl.values())
    p = {k: float(np.exp(v - m)) for k, v in logl.items()}
    s = sum(p.values())
    probs = {k: v / s for k, v in p.items()}
    note = "nu1 and nu4 used" if nu4 else "nu4 not detected: polymorph/cation discrimination weak (nu1 positions overlap)"
    return CarbonateResult(True, b1.observed_cm1, b1.snr, max(nu4, key=lambda m: m.snr).observed_cm1 if nu4 else None,
                           probs, note)
