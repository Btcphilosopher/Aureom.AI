"""Carbon characterisation engine: evidence fusion across Raman, ATR-IR and
fluorescence into carbon-bearing material classes with uncertainty.

The engine never reports a single undifferentiated "carbon" number. It
reports class probabilities for seven carbon-related material classes, the
evidence behind them, Monte-Carlo confidence intervals, the quantitation
level that the available calibration supports, sensor limitations and
calibration status. A concentration is reported only through a validated
:class:`~.calibration_model.CarbonCalibrationModel`.

Evidence weights are explicit, documented log-likelihood ratios (see
``WEIGHTS``) chosen from the physical meaning of each feature; they are
priors for an expert system, to be re-estimated once laboratory-validated
training data exist (``models/carbon_classification``).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict

from ..core.provenance import DataOrigin, QuantitationLevel
from ..spectral.fluorescence import FluorescenceResult
from ..spectral.infrared import IrResult
from ..spectral.raman import ProcessedRaman, assign_bands
from .calibration_model import CarbonCalibrationModel
from .raman_carbon import fit_carbonaceous, identify_carbonate

CLASSES = ["organic_carbon", "carbonate", "carbon_bearing_sediment", "carbonaceous_coating", "biological",
           "carbon_rich_inclusion", "background_matrix"]

# feature -> class -> log-likelihood ratio at full-strength detection
WEIGHTS: dict[str, dict[str, float]] = {
    "raman_carbonaceous": {"carbonaceous_coating": 2.5, "organic_carbon": 1.5, "carbon_rich_inclusion": 1.0,
                           "carbon_bearing_sediment": 0.8, "background_matrix": -2.5},
    "raman_carbonate": {"carbonate": 3.0, "carbon_bearing_sediment": 1.0, "background_matrix": -2.5},
    "ir_carbonate": {"carbonate": 2.0, "carbon_bearing_sediment": 0.7, "background_matrix": -1.5},
    "ir_organic": {"organic_carbon": 1.8, "biological": 1.0, "carbonaceous_coating": 0.5, "background_matrix": -1.5},
    "fl_chlorophyll": {"biological": 2.5, "organic_carbon": 0.8, "background_matrix": -1.5},
    "fl_protein": {"biological": 2.0, "organic_carbon": 0.8, "background_matrix": -1.0},
    "fl_humic": {"organic_carbon": 1.5, "carbon_bearing_sediment": 0.8, "background_matrix": -1.0},
}
# In sediment, carbonate and humic signals describe carbon held *in the
# sediment*; on a nodule surface they describe a discrete carbonate phase or
# organic film. Context-specific weights override the defaults.
CONTEXT_WEIGHTS: dict[str, dict[str, dict[str, float]]] = {
    "sediment": {
        "raman_carbonate": {"carbon_bearing_sediment": 2.6, "carbonate": 1.6, "background_matrix": -2.5},
        "ir_carbonate": {"carbon_bearing_sediment": 1.6, "carbonate": 1.0, "background_matrix": -1.5},
        "fl_humic": {"carbon_bearing_sediment": 1.6, "organic_carbon": 0.8, "background_matrix": -1.0},
        "raman_carbonaceous": {"organic_carbon": 1.5, "carbon_bearing_sediment": 1.5, "carbonaceous_coating": -1.0,
                               "background_matrix": -2.5},
    },
    "nodule_surface": {
        "ir_organic": {"carbonaceous_coating": 1.2, "organic_carbon": 1.0, "biological": 0.6, "background_matrix": -1.5},
    },
}
CONTEXT_PRIOR = {
    "nodule_surface": {"carbonaceous_coating": 0.5, "carbon_rich_inclusion": 0.2, "carbon_bearing_sediment": -1.0},
    "sediment": {"carbon_bearing_sediment": 0.8, "carbonaceous_coating": -1.0, "carbon_rich_inclusion": -1.0},
    "unknown": {},
}


@dataclass
class CarbonTarget:
    target_id: str
    context: str = "unknown"                    # nodule_surface | sediment | unknown
    raman: ProcessedRaman | None = None
    ir: IrResult | None = None
    fluorescence: FluorescenceResult | None = None
    calibration_status: dict[str, str] = field(default_factory=dict)
    origin: DataOrigin = DataOrigin.MEASURED
    lab_features: np.ndarray | None = None      # features for a quantitative model


class EvidenceItem(BaseModel):
    model_config = ConfigDict(extra="forbid")
    channel: str
    feature: str
    value: float
    se: float
    snr: float
    strength: float
    contributions: dict[str, float]
    note: str = ""


class CarbonCharacterisation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target_id: str
    context: str
    class_probabilities: dict[str, float]
    probability_intervals: dict[str, tuple[float, float]]
    top_class: str
    top_probability: float
    organic_probability: float
    evidence: list[EvidenceItem]
    carbonaceous_structure: dict[str, Any] | None
    carbonate_mineralogy: dict[str, float] | None
    quantitation_level: QuantitationLevel
    quantitative: list[dict[str, Any]]
    quantitative_refusals: list[str]
    limitations: list[str]
    calibration_status: dict[str, str]
    data_origin: DataOrigin


# Systematic (measurement-model) uncertainty floors. Statistical noise alone
# understates uncertainty: ATR water-displacement correction and contact
# variability leave ~0.02 absorbance units of systematic error.
IR_SYSTEMATIC_AU = 0.02
# Log-likelihood penalty for a non-detection, as a fraction of the detection
# weight; it only applies to channels that were actually measured.
ABSENCE_FACTOR = 0.5


def _strength(snr: float, centre: float = 5.0, scale: float = 1.5) -> float:
    return float(1.0 / (1.0 + np.exp(-(snr - centre) / scale)))


class CarbonCharacterisationEngine:
    def __init__(self, models: list[CarbonCalibrationModel] | None = None, *, n_mc: int = 400, seed: int = 0):
        self.models = models or []
        self.n_mc = n_mc
        self.rng = np.random.default_rng(seed)

    # ------------------------------------------------------------------ features
    def _features(self, t: CarbonTarget):
        feats: list[tuple[str, str, float, float, str]] = []   # (channel, feature, value, se, note)
        carb_struct = None
        carb_min = None
        limitations: list[str] = []
        if t.raman is not None:
            matches = assign_bands(t.raman)
            cr = fit_carbonaceous(t.raman)
            # carbonaceous material requires BOTH bands: the weaker one limits the evidence
            snr = min(cr.g_snr, 2 * cr.d1_snr)
            feats.append(("raman", "raman_carbonaceous", snr, 1.0, cr.note))
            if cr.detected:
                carb_struct = {k: getattr(cr, k) for k in ("g_center", "g_fwhm", "d1_center", "d1_fwhm",
                                                           "r1_height_ratio", "r2_area_ratio", "order")}
            cb = identify_carbonate(matches)
            feats.append(("raman", "raman_carbonate", cb.nu1_snr, 1.0, cb.note))
            carb_min = cb.mineral_probabilities
            if t.raman.fluorescence_ratio > 20:
                limitations.append("strong fluorescence background: weak Raman bands may be masked")
        else:
            limitations.append("no Raman measurement: carbonaceous material and carbonate mineralogy unconstrained")
        if t.ir is not None:
            feats.append(("ir", "ir_carbonate", t.ir.carbonate_index / float(np.hypot(t.ir.carbonate_se, IR_SYSTEMATIC_AU)),
                          1.0, f"contact fraction {t.ir.contact_fraction:.2f}; {IR_SYSTEMATIC_AU} AU systematic floor"))
            feats.append(("ir", "ir_organic", t.ir.organic_index / float(np.hypot(t.ir.organic_se, IR_SYSTEMATIC_AU)), 1.0,
                          "CH2 stretch; ATR surface (~1 um) only"))
        else:
            limitations.append("no ATR-IR contact measurement")
        if t.fluorescence is not None:
            s = t.fluorescence.index_snr
            feats += [("fluorescence", "fl_chlorophyll", s["chlorophyll"], 1.0, "ex450/em685"),
                      ("fluorescence", "fl_protein", s["protein_like"], 1.0, "ex280/em340"),
                      ("fluorescence", "fl_humic", s["humic_like"], 1.0, "ex365/em450")]
            if t.fluorescence.raman_background_risk:
                limitations.append("chlorophyll fluorescence present: 532 nm Raman background elevated")
        else:
            limitations.append("no fluorescence measurement: biological interference unconstrained")
        limitations += ["electromagnetic and acoustic channels carry no direct carbon information",
                        "surface-sensitive optical methods do not sample nodule interiors"]
        return feats, carb_struct, carb_min, limitations

    @staticmethod
    def _weights(context: str, feat: str) -> dict[str, float]:
        return CONTEXT_WEIGHTS.get(context, {}).get(feat, WEIGHTS[feat])

    def _posterior(self, context: str, strengths: dict[str, float]) -> np.ndarray:
        logp = np.zeros(len(CLASSES))
        for c, v in CONTEXT_PRIOR.get(context, {}).items():
            logp[CLASSES.index(c)] += v
        for feat, s in strengths.items():
            for c, w in self._weights(context, feat).items():
                logp[CLASSES.index(c)] += w * s
                # Absence of evidence from a measured channel is evidence:
                # against the classes the feature supports, and for the classes
                # (background matrix) that the feature argues against.
                logp[CLASSES.index(c)] -= ABSENCE_FACTOR * w * (1.0 - s)
        logp -= logp.max()
        p = np.exp(logp)
        return p / p.sum()

    # ------------------------------------------------------------------ public
    def analyse(self, t: CarbonTarget) -> CarbonCharacterisation:
        feats, carb_struct, carb_min, limitations = self._features(t)
        strengths = {f: _strength(v) for _, f, v, _, _ in feats}
        p = self._posterior(t.context, strengths)
        # Monte Carlo over feature SNR uncertainty (unit SE on each SNR)
        draws = np.empty((self.n_mc, len(CLASSES)))
        for i in range(self.n_mc):
            st = {f: _strength(v + self.rng.normal(0, se)) for _, f, v, se, _ in feats}
            draws[i] = self._posterior(t.context, st)
        lo, hi = np.quantile(draws, [0.025, 0.975], axis=0)
        evidence = []
        for ch, f, v, se, note in feats:
            s = strengths[f]
            evidence.append(EvidenceItem(channel=ch, feature=f, value=float(v), se=float(se), snr=float(v), strength=s,
                                         contributions={c: w * s for c, w in self._weights(t.context, f).items()},
                                         note=note))
        quant, refusals = [], []
        for m in self.models:
            if t.lab_features is None:
                refusals.append(f"{m.analyte}: no features supplied for the quantitative model")
                continue
            r, why = m.predict(t.lab_features)
            (quant.append(r) if r else refusals.append(f"{m.analyte}: {why}"))
        if not self.models:
            refusals.append("no laboratory-validated TOC/TIC model attached: concentrations are not reported")
        detected = any(s > 0.5 for s in strengths.values())
        level = (QuantitationLevel.QUANTITATIVE if quant else
                 QuantitationLevel.QUALITATIVE if detected else QuantitationLevel.NOT_DETECTED)
        k = int(np.argmax(p))
        organic = float(p[CLASSES.index("organic_carbon")] + p[CLASSES.index("biological")]
                        + p[CLASSES.index("carbonaceous_coating")])
        origin = t.origin if t.origin == DataOrigin.SIMULATED else DataOrigin.ESTIMATED
        if quant and origin != DataOrigin.SIMULATED:
            origin = DataOrigin.ESTIMATED
        return CarbonCharacterisation(
            target_id=t.target_id, context=t.context,
            class_probabilities={c: float(v) for c, v in zip(CLASSES, p)},
            probability_intervals={c: (float(a), float(b)) for c, a, b in zip(CLASSES, lo, hi)},
            top_class=CLASSES[k], top_probability=float(p[k]), organic_probability=min(1.0, organic),
            evidence=evidence, carbonaceous_structure=carb_struct, carbonate_mineralogy=carb_min,
            quantitation_level=level, quantitative=quant, quantitative_refusals=refusals, limitations=limitations,
            calibration_status=dict(t.calibration_status), data_origin=origin)
