"""Radiometric calibration of area / push-broom detectors.

Implements dark reference, flat-field (PRNU) gain, bad-pixel detection,
detector linearity correction, dark-current temperature compensation,
counts-to-radiance conversion against an integrating-sphere standard, and
export of the FPGA calibration tables (u16 dark, u2.14 gain, bad flags) with
the quantisation error those tables introduce.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..acquisition.fixedpoint import GAIN_ONE, gain_to_u2_14


@dataclass
class DarkReference:
    mean: np.ndarray           # counts per pixel
    std: np.ndarray            # temporal noise per pixel
    n_frames: int
    temperature_c: float | None
    exposure_s: float


def dark_reference(frames: np.ndarray, *, temperature_c: float | None = None, exposure_s: float = 0.0) -> DarkReference:
    f = np.asarray(frames, dtype=np.float64)
    if f.ndim < 2 or f.shape[0] < 2:
        raise ValueError("need a stack of >= 2 dark frames (frames first)")
    return DarkReference(f.mean(0), f.std(0, ddof=1), f.shape[0], temperature_c, exposure_s)


def flat_field_gain(flat_frames: np.ndarray, dark: DarkReference, *, axis_norm=None) -> np.ndarray:
    """Per-pixel gain that equalises response to a uniform source (PRNU).

    gain = median(response) / response, so applying ``(raw - dark) * gain``
    flattens the field. ``axis_norm`` normalises along an axis (e.g. per
    spectral row for a push-broom HSI, where illumination varies by band).
    """
    resp = np.asarray(flat_frames, dtype=np.float64).mean(0) - dark.mean
    if np.any(resp <= 0):
        raise ValueError("flat response must exceed the dark level everywhere (check exposure / bad pixels)")
    ref = np.median(resp, axis=axis_norm, keepdims=axis_norm is not None)
    return ref / resp


def detect_bad_pixels(dark: DarkReference, gain: np.ndarray, *, k_dark: float = 6.0, k_noise: float = 6.0,
                      gain_range: tuple[float, float] = (0.5, 2.0)) -> np.ndarray:
    """Hot/cold/noisy pixel mask from robust statistics (MAD)."""
    def robust_z(x):
        med = np.median(x)
        mad = np.median(np.abs(x - med)) * 1.4826
        return (x - med) / (mad if mad > 0 else 1.0)

    hot = np.abs(robust_z(dark.mean)) > k_dark
    noisy = robust_z(dark.std) > k_noise
    gain_bad = (gain < gain_range[0]) | (gain > gain_range[1])
    return hot | noisy | gain_bad


def fpga_tables(dark: DarkReference, gain: np.ndarray, bad: np.ndarray) -> dict[str, np.ndarray | float]:
    """Quantise to the sf_calibration_engine table format.

    Returns the u16 dark, u2.14 gain, bad flags and the worst-case relative
    gain quantisation error (half an LSB of u2.14 relative to the gain).
    """
    d = np.clip(np.rint(dark.mean), 0, 0xFFFF).astype(np.uint16)
    g = gain_to_u2_14(np.clip(gain, 0, 0xFFFF / GAIN_ONE))
    rel = 0.5 / (np.asarray(gain, dtype=float) * GAIN_ONE)
    return {"dark_u16": d, "gain_u2_14": g, "bad": np.asarray(bad, dtype=bool),
            "max_gain_quant_rel_error": float(np.max(rel[np.isfinite(rel)]))}


def pack_cal_words(tables: dict) -> tuple[np.ndarray, np.ndarray]:
    """CAL_DATA / CAL_FLAGS register words for each pixel index."""
    data = (tables["gain_u2_14"].astype(np.uint32).ravel() << 16) | tables["dark_u16"].astype(np.uint32).ravel()
    flags = tables["bad"].astype(np.uint32).ravel()
    return data, flags


# ----------------------------------------------------------------- linearity
@dataclass
class LinearityModel:
    coeffs: np.ndarray          # polynomial mapping measured -> linearised counts (highest power first)
    max_valid: float
    residual_rms: float

    def apply(self, counts: np.ndarray) -> np.ndarray:
        c = np.asarray(counts, dtype=np.float64)
        out = np.polyval(self.coeffs, c)
        return np.where(c <= self.max_valid, out, np.nan)


def fit_linearity(exposures_s: np.ndarray, mean_counts: np.ndarray, *, degree: int = 3,
                  linear_fraction: float = 0.3) -> LinearityModel:
    """Fit a correction from an exposure series of a stable source.

    The ideal response is the straight line through the lowest
    ``linear_fraction`` of the series; the polynomial maps measured counts to
    that ideal.
    """
    t = np.asarray(exposures_s, dtype=float)
    m = np.asarray(mean_counts, dtype=float)
    order = np.argsort(t)
    t, m = t[order], m[order]
    n_lin = max(3, int(len(t) * linear_fraction))
    slope, icpt = np.polyfit(t[:n_lin], m[:n_lin], 1)
    ideal = slope * t + icpt
    coeffs = np.polyfit(m, ideal, degree)
    resid = np.polyval(coeffs, m) - ideal
    return LinearityModel(coeffs, float(m.max()), float(np.sqrt(np.mean(resid ** 2))))


# ----------------------------------------------------------------- temperature
def dark_current_scale(t_c: float, t_ref_c: float, doubling_c: float = 7.0) -> float:
    """Empirical dark-current temperature scaling (doubling every ``doubling_c``).

    Typical doubling temperatures: ~6-8 C for silicon CMOS/CCD and InGaAs.
    The value must be measured per detector (calibration kind TEMPERATURE).
    """
    return float(2.0 ** ((t_c - t_ref_c) / doubling_c))


def compensate_dark(dark: DarkReference, offset: np.ndarray, t_c: float, *, doubling_c: float = 7.0) -> np.ndarray:
    """Dark frame predicted at ``t_c``: bias offset + thermally scaled dark signal."""
    if dark.temperature_c is None:
        raise ValueError("dark reference has no temperature; cannot compensate")
    signal = dark.mean - offset
    return offset + signal * dark_current_scale(t_c, dark.temperature_c, doubling_c)


# ----------------------------------------------------------------- radiance
@dataclass
class RadianceCalibration:
    """counts/s -> spectral radiance (W m^-2 sr^-1 nm^-1) per band."""
    responsivity: np.ndarray     # (counts/s) per radiance unit, per band (and optionally per pixel)
    uncertainty_rel: np.ndarray  # relative standard uncertainty per band
    sphere_certificate: str

    def to_radiance(self, counts_per_s: np.ndarray, band_axis: int = -1) -> np.ndarray:
        r = np.moveaxis(np.asarray(counts_per_s, dtype=float), band_axis, -1) / self.responsivity
        return np.moveaxis(r, -1, band_axis)


def fit_radiance(sphere_counts_per_s: np.ndarray, sphere_radiance: np.ndarray, *, cert_uncertainty_rel: np.ndarray,
                 counts_noise_rel: np.ndarray, certificate: str) -> RadianceCalibration:
    """Responsivity from an integrating sphere of certified spectral radiance."""
    c = np.asarray(sphere_counts_per_s, dtype=float)
    L = np.asarray(sphere_radiance, dtype=float)
    resp = c / L
    unc = np.sqrt(np.asarray(cert_uncertainty_rel) ** 2 + np.asarray(counts_noise_rel) ** 2)
    return RadianceCalibration(resp, unc, certificate)


def reflectance_from_panel(radiance: np.ndarray, panel_radiance: np.ndarray, panel_reflectance: np.ndarray) -> np.ndarray:
    """Reflectance factor relative to a reference panel of known reflectance
    imaged under the same illumination and water path."""
    return np.asarray(radiance) / np.asarray(panel_radiance) * np.asarray(panel_reflectance)
