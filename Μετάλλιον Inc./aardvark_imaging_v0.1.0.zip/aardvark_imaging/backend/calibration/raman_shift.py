"""Raman shift axis and intensity-response calibration.

Raman shift (cm^-1) = 1e7/lambda_laser - 1e7/lambda_scattered. The absolute
pixel->wavenumber mapping is fitted from a reference material with
well-established bands, and the laser wavelength is then refined from a
second standard (or the same one) so the shift axis is consistent.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

# Reference Raman bands (cm^-1). Cyclohexane values per ASTM E1840; silicon
# first-order phonon; polystyrene.
CYCLOHEXANE_CM1 = np.array([384.1, 426.3, 801.3, 1028.3, 1157.6, 1266.4, 1444.4, 2664.4, 2852.9, 2923.8, 2938.3])
SILICON_CM1 = np.array([520.7])
POLYSTYRENE_CM1 = np.array([620.9, 795.8, 1001.4, 1031.8, 1155.3, 1450.5, 1583.1, 1602.3, 2852.4, 3054.3])
# Seawater dissolved sulfate symmetric stretch: an in-situ internal standard.
SULFATE_NU1_CM1 = 981.0


def shift_to_nm(shift_cm1, laser_nm: float):
    return 1e7 / (1e7 / laser_nm - np.asarray(shift_cm1, dtype=float))


def nm_to_shift(nm, laser_nm: float):
    return 1e7 / laser_nm - 1e7 / np.asarray(nm, dtype=float)


@dataclass
class RamanAxisCalibration:
    laser_nm: float
    coeffs_nm: np.ndarray        # pixel -> scattered wavelength (nm)
    rms_cm1: float
    standard: str

    def shift_axis(self, n_pixels: int) -> np.ndarray:
        return nm_to_shift(np.polyval(self.coeffs_nm, np.arange(n_pixels, dtype=float)), self.laser_nm)


def calibrate_axis(peak_pixels, reference_shifts_cm1, laser_nm_nominal: float, *, degree: int = 2,
                   standard: str = "cyclohexane (ASTM E1840)") -> RamanAxisCalibration:
    """Fit pixel -> scattered wavelength given identified reference peaks.

    The fit is done in absolute wavelength computed with the nominal laser
    wavelength; :func:`refine_laser_wavelength` then removes laser drift.
    """
    px = np.asarray(peak_pixels, dtype=float)
    nm = shift_to_nm(reference_shifts_cm1, laser_nm_nominal)
    coeffs = np.polyfit(px, nm, degree)
    resid = nm_to_shift(np.polyval(coeffs, px), laser_nm_nominal) - np.asarray(reference_shifts_cm1)
    return RamanAxisCalibration(laser_nm_nominal, coeffs, float(np.sqrt(np.mean(resid ** 2))), standard)


def refine_laser_wavelength(cal: RamanAxisCalibration, observed_pixel: float, known_shift_cm1: float) -> RamanAxisCalibration:
    """Solve for the laser wavelength that places a known band at its shift."""
    lam_s = float(np.polyval(cal.coeffs_nm, observed_pixel))
    laser_nm = 1e7 / (1e7 / lam_s + known_shift_cm1)
    return RamanAxisCalibration(laser_nm, cal.coeffs_nm, cal.rms_cm1, cal.standard + f" + laser refined on {known_shift_cm1} cm-1")


@dataclass
class IntensityResponse:
    """Relative spectral response correction (e.g. from NIST SRM 2242a for
    532 nm excitation): corrected = measured / response."""
    shift_cm1: np.ndarray
    response: np.ndarray
    certificate: str

    def correct(self, shift_cm1: np.ndarray, counts: np.ndarray) -> np.ndarray:
        r = np.interp(shift_cm1, self.shift_cm1, self.response)
        return np.asarray(counts, dtype=float) / r


def fit_intensity_response(shift_cm1, measured, certified, *, degree: int = 5, certificate: str) -> IntensityResponse:
    """Response = measured / certified, smoothed with a polynomial."""
    x = np.asarray(shift_cm1, dtype=float)
    ratio = np.asarray(measured, dtype=float) / np.asarray(certified, dtype=float)
    ratio /= np.nanmax(ratio)
    c = np.polyfit(x, ratio, degree)
    return IntensityResponse(x, np.polyval(c, x), certificate)
