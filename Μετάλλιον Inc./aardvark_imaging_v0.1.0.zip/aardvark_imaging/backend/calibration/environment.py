"""Optical window, pressure and water refractive-index effects.

* Seawater refractive index n(lambda, T, S) from the empirical formula of
  Quan & Fry (1995, Applied Optics 34(18)) at atmospheric pressure, plus a
  pressure term of +1.6e-4 per MPa (Lorentz-Lorenz relation with the
  isothermal compressibility of water, ~4.6e-10 1/Pa). At 4500 m (~45 MPa)
  this raises n by ~7e-3 (~0.5 % change in flat-port magnification).
* Flat-port refraction: a camera behind a flat window sees an underwater
  field of view reduced by ~n_water (paraxial), and is not a single-viewpoint
  system — :mod:`aardvark_imaging.sensor_fusion.camera` ray-traces the port.
* Window transmission (Fresnel reflections at both faces + bulk absorption).
"""
from __future__ import annotations

import numpy as np


def seawater_index(wavelength_nm, temperature_c: float = 2.0, salinity_psu: float = 35.0,
                   pressure_mpa: float = 0.1) -> np.ndarray:
    """Refractive index of seawater (Quan & Fry 1995; valid ~400-700 nm,
    0-30 C, 0-35 psu; extrapolated values are flagged by the caller)."""
    lam = np.asarray(wavelength_nm, dtype=float)
    T, S = temperature_c, salinity_psu
    n0, n1, n2, n3, n4 = 1.31405, 1.779e-4, -1.05e-6, 1.6e-8, -2.02e-6
    n5, n6, n7, n8, n9 = 15.868, 0.01155, -0.00423, -4382.0, 1.1455e6
    n = (n0 + (n1 + n2 * T + n3 * T ** 2) * S + n4 * T ** 2 + (n5 + n6 * S + n7 * T) / lam
         + n8 / lam ** 2 + n9 / lam ** 3)
    return n + 1.6e-4 * (pressure_mpa - 0.1)


def pressure_mpa_from_depth(depth_m: float, density: float = 1035.0) -> float:
    return 0.101325 + density * 9.80665 * depth_m / 1e6


def fresnel_normal_reflectance(n1, n2) -> np.ndarray:
    n1 = np.asarray(n1, dtype=float)
    n2 = np.asarray(n2, dtype=float)
    return ((n1 - n2) / (n1 + n2)) ** 2


def sapphire_index(wavelength_nm) -> np.ndarray:
    """Ordinary-ray index of sapphire (Malitson 1962 Sellmeier)."""
    lam = np.asarray(wavelength_nm, dtype=float) / 1000.0
    l2 = lam ** 2
    n2 = 1 + 1.4313493 * l2 / (l2 - 0.0726631 ** 2) + 0.65054713 * l2 / (l2 - 0.1193242 ** 2) + 5.3414021 * l2 / (l2 - 18.028251 ** 2)
    return np.sqrt(n2)


def window_transmission(wavelength_nm, *, inside_n: float = 1.0, outside_n=None, thickness_mm: float = 25.0,
                        bulk_absorption_per_mm=0.0) -> np.ndarray:
    """Transmission of a flat sapphire port (air inside, seawater outside),
    single pass, incoherent multiple reflections neglected beyond first order."""
    lam = np.asarray(wavelength_nm, dtype=float)
    ns = sapphire_index(lam)
    no = seawater_index(lam) if outside_n is None else np.asarray(outside_n)
    r1 = fresnel_normal_reflectance(inside_n, ns)
    r2 = fresnel_normal_reflectance(ns, no)
    return (1 - r1) * (1 - r2) * np.exp(-np.asarray(bulk_absorption_per_mm) * thickness_mm)


def flat_port_fov_ratio(wavelength_nm=550.0, **kw) -> float:
    """Paraxial ratio of underwater to in-air field of view behind a flat port."""
    return float(1.0 / seawater_index(wavelength_nm, **kw))
