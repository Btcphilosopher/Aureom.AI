"""Spectrometer / hyperspectral wavelength calibration from emission lines.

Fits a polynomial pixel -> wavelength mapping from lamp spectra (e.g. a
Hg-Ar pen lamp), with line identification, residuals and per-row smile for
push-broom imagers.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.signal import find_peaks

# Hg-Ar lamp lines (nm, air). NIST Atomic Spectra Database values, rounded.
HG_AR_LINES_NM = np.array([404.656, 407.783, 435.833, 546.074, 576.960, 579.066, 696.543, 706.722, 714.704,
                           727.294, 738.398, 750.387, 763.511, 772.376, 794.818, 800.616, 811.531, 826.452,
                           842.465, 852.144, 866.794, 912.297, 922.450])


@dataclass
class WavelengthCalibration:
    coeffs: np.ndarray          # pixel -> nm (highest power first)
    rms_nm: float
    n_lines: int
    matched: list[tuple[float, float]]   # (pixel, nm)

    def wavelengths(self, n_pixels: int) -> np.ndarray:
        return np.polyval(self.coeffs, np.arange(n_pixels, dtype=float))


def centroid_peaks(spectrum: np.ndarray, *, prominence: float, half_window: int = 3) -> np.ndarray:
    """Sub-pixel line centres by intensity-weighted centroid around peaks."""
    s = np.asarray(spectrum, dtype=float)
    idx, _ = find_peaks(s, prominence=prominence)
    out = []
    for i in idx:
        lo, hi = max(0, i - half_window), min(s.size, i + half_window + 1)
        w = s[lo:hi] - s[lo:hi].min()
        if w.sum() > 0:
            out.append(np.sum(np.arange(lo, hi) * w) / w.sum())
    return np.array(out)


def calibrate_from_lines(spectrum: np.ndarray, initial_coeffs, *, lines_nm=HG_AR_LINES_NM, prominence: float,
                         tolerance_nm: float = 2.0, degree: int = 3, iterations: int = 4,
                         clip_k: float = 3.5) -> WavelengthCalibration:
    """Iteratively identify lamp lines near their predicted pixels and refit.

    Matching is one-to-one: a detected peak claimed by two lamp lines within
    the tolerance (an unresolved doublet such as Hg 576.96/579.07 nm) is
    dropped rather than assigned, because its centroid lies between the
    lines. Matches with residuals beyond ``clip_k`` robust sigmas are
    rejected before the final fit.
    """
    peaks = centroid_peaks(spectrum, prominence=prominence)
    coeffs = np.asarray(initial_coeffs, dtype=float)
    lines_nm = np.asarray(lines_nm, dtype=float)
    matched: list[tuple[float, float]] = []
    for it in range(iterations):
        pred = np.polyval(coeffs, peaks) if peaks.size else np.zeros(0)
        claims: dict[int, list[float]] = {}
        for ln in lines_nm:
            if not peaks.size:
                break
            j = int(np.argmin(np.abs(pred - ln)))
            if abs(pred[j] - ln) < tolerance_nm:
                claims.setdefault(j, []).append(float(ln))
        matched = [(float(peaks[j]), lns[0]) for j, lns in sorted(claims.items()) if len(lns) == 1]
        if len(matched) < degree + 2:
            raise ValueError(f"only {len(matched)} lines identified; need >= {degree + 2}")
        px, nm = np.array(matched).T
        coeffs = np.polyfit(px, nm, degree)
        if it >= 1 and len(matched) > degree + 3:
            r = np.polyval(coeffs, px) - nm
            mad = 1.4826 * np.median(np.abs(r - np.median(r))) or 1e-9
            keep = np.abs(r - np.median(r)) <= clip_k * mad
            if keep.sum() >= degree + 2 and not keep.all():
                matched = [m for m, k in zip(matched, keep) if k]
                px, nm = np.array(matched).T
                coeffs = np.polyfit(px, nm, degree)
    px, nm = np.array(matched).T
    resid = np.polyval(coeffs, px) - nm
    return WavelengthCalibration(coeffs, float(np.sqrt(np.mean(resid ** 2))), len(matched), matched)


def smile_shift(rows_spectra: np.ndarray, reference_row: int, *, max_shift: int = 5) -> np.ndarray:
    """Per spatial row spectral shift (pixels) relative to ``reference_row`` by
    cross-correlation with parabolic sub-pixel refinement (push-broom smile)."""
    ref = rows_spectra[reference_row] - rows_spectra[reference_row].mean()
    shifts = np.zeros(rows_spectra.shape[0])
    lags = np.arange(-max_shift, max_shift + 1)
    for r, spec in enumerate(rows_spectra):
        s = spec - spec.mean()
        cc = np.array([np.dot(np.roll(s, -k), ref) for k in lags])
        j = int(np.argmax(cc))
        if 0 < j < len(cc) - 1:
            den = cc[j - 1] - 2 * cc[j] + cc[j + 1]
            frac = 0.5 * (cc[j - 1] - cc[j + 1]) / den if den != 0 else 0.0
        else:
            frac = 0.0
        shifts[r] = lags[j] + frac
    return shifts
