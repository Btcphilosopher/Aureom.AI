"""In-memory calibration registry with versioning, expiry and lookup.

Persistence is provided by :mod:`aardvark_imaging.storage.database`; this
class holds the policy: which record applies to a measurement at time *t*,
version monotonicity, and the status summary shown on the workstation.
"""
from __future__ import annotations

from datetime import datetime, timezone

from .models import CalibrationKind, CalibrationRecord, CalibrationStatus


class CalibrationRegistry:
    def __init__(self) -> None:
        self._records: dict[str, CalibrationRecord] = {}

    def add(self, rec: CalibrationRecord) -> None:
        if rec.calibration_id in self._records:
            raise ValueError(f"calibration {rec.calibration_id} already registered (records are immutable)")
        prior = self.history(rec.sensor_key, rec.kind)
        if prior and rec.version <= prior[-1].version:
            raise ValueError(f"version {rec.version} must exceed {prior[-1].version}")
        self._records[rec.calibration_id] = rec

    def get(self, calibration_id: str) -> CalibrationRecord:
        return self._records[calibration_id]

    def history(self, sensor_key: str, kind: CalibrationKind) -> list[CalibrationRecord]:
        return sorted((r for r in self._records.values() if r.sensor_key == sensor_key and r.kind == kind),
                      key=lambda r: r.version)

    def applicable(self, sensor_key: str, kind: CalibrationKind, at: datetime | None = None) -> CalibrationRecord | None:
        """Highest version whose validity window contains ``at``."""
        at = at or datetime.now(timezone.utc)
        cands = [r for r in self.history(sensor_key, kind) if r.valid_from <= at < r.expires]
        return cands[-1] if cands else None

    def status(self, sensor_key: str, kind: CalibrationKind, at: datetime | None = None) -> CalibrationStatus:
        at = at or datetime.now(timezone.utc)
        rec = self.applicable(sensor_key, kind, at)
        if rec is None:
            hist = self.history(sensor_key, kind)
            if not hist:
                return CalibrationStatus.MISSING
            return CalibrationStatus.EXPIRED if hist[-1].expires <= at else CalibrationStatus.NOT_YET_VALID
        return rec.status(at)

    def summary(self, requirements: dict[str, list[str]], at: datetime | None = None) -> dict[str, dict[str, str]]:
        """Status of every required (sensor, kind) pair, e.g. from the manifest."""
        out: dict[str, dict[str, str]] = {}
        for sensor, kinds in requirements.items():
            out[sensor] = {}
            for k in kinds:
                try:
                    kind = CalibrationKind(k)
                except ValueError:
                    out[sensor][k] = "unsupported_kind"
                    continue
                out[sensor][k] = self.status(sensor, kind, at).value
        return out

    def __len__(self) -> int:
        return len(self._records)
