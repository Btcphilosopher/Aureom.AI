"""Calibration records, certificates and status.

Every calibration is a versioned, immutable record with traceability: the
reference standard and certificate used, the environmental conditions at
calibration, validity window, the method and its uncertainty, and the data
origin (a calibration derived from simulated frames is itself SIMULATED and
is reported as such everywhere it is applied).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..core.provenance import DataOrigin, utcnow


class CalibrationKind(str, Enum):
    DARK = "dark"
    FLAT_FIELD = "flat_field"
    BAD_PIXEL = "bad_pixel"
    RADIOMETRIC = "radiometric"
    WAVELENGTH = "wavelength"
    SMILE_KEYSTONE = "smile_keystone"
    LINEARITY = "linearity"
    TEMPERATURE = "temperature"
    RAMAN_SHIFT = "raman_shift"
    INTENSITY_RESPONSE = "intensity_response"
    COLOUR = "colour"
    DISTORTION = "distortion"
    BAND_REGISTRATION = "band_registration"
    WINDOW = "optical_window"
    FLUORESCENCE = "fluorescence"
    IR_BACKGROUND = "ir_background"
    EM_NULL = "em_free_field_null"
    EM_PLATFORM = "em_platform_compensation"
    SOUND_VELOCITY = "sound_velocity"
    MOUNTING = "mounting"


class CalibrationLevel(str, Enum):
    FACTORY = "factory"
    FIELD = "field"
    IN_SITU = "in_situ"


class CalibrationStatus(str, Enum):
    VALID = "valid"
    EXPIRING = "expiring"
    EXPIRED = "expired"
    MISSING = "missing"
    SIMULATED = "simulated"
    NOT_YET_VALID = "not_yet_valid"


class Certificate(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    certificate_id: str
    issuer: str
    standard: str = Field(description="Reference standard, e.g. 'Spectralon SRS-99 #1234', 'NIST SRM 2242a'")
    issued: datetime
    traceable_to: str = Field(description="National metrology institute / chain")
    uncertainty: str = ""


class CalibrationRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    calibration_id: str
    sensor_key: str
    kind: CalibrationKind
    level: CalibrationLevel
    version: int = Field(ge=1)
    created: datetime = Field(default_factory=utcnow)
    valid_from: datetime = Field(default_factory=utcnow)
    expires: datetime
    method: str
    origin: DataOrigin
    certificate: Certificate | None = None
    temperature_c: float | None = None
    pressure_dbar: float | None = None
    parameters: dict[str, Any] = Field(default_factory=dict)
    array_refs: dict[str, str] = Field(default_factory=dict, description="Large arrays stored by reference (path#key)")
    uncertainty: dict[str, float] = Field(default_factory=dict)
    supersedes: str | None = None
    notes: str = ""

    @model_validator(mode="after")
    def _window(self) -> "CalibrationRecord":
        if self.expires <= self.valid_from:
            raise ValueError("expires must be after valid_from")
        if self.origin == DataOrigin.MEASURED and self.level == CalibrationLevel.FACTORY and self.certificate is None:
            raise ValueError("a measured factory calibration requires a traceable certificate")
        return self

    def status(self, at: datetime | None = None, warn: timedelta = timedelta(days=14)) -> CalibrationStatus:
        at = at or datetime.now(timezone.utc)
        if self.origin == DataOrigin.SIMULATED:
            return CalibrationStatus.SIMULATED
        if at < self.valid_from:
            return CalibrationStatus.NOT_YET_VALID
        if at >= self.expires:
            return CalibrationStatus.EXPIRED
        if at >= self.expires - warn:
            return CalibrationStatus.EXPIRING
        return CalibrationStatus.VALID
