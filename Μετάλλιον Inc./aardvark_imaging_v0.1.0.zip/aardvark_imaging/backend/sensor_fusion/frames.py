"""Coordinate frames: WGS-84 geodetic <-> ECEF <-> local ENU, attitude
rotations (ZYX yaw-pitch-roll, NED body convention) and quaternion slerp."""
from __future__ import annotations

import numpy as np

A_WGS84 = 6378137.0
F_WGS84 = 1 / 298.257223563
E2 = F_WGS84 * (2 - F_WGS84)


def geodetic_to_ecef(lat_deg, lon_deg, h_m):
    lat, lon = np.radians(lat_deg), np.radians(lon_deg)
    N = A_WGS84 / np.sqrt(1 - E2 * np.sin(lat) ** 2)
    x = (N + h_m) * np.cos(lat) * np.cos(lon)
    y = (N + h_m) * np.cos(lat) * np.sin(lon)
    z = (N * (1 - E2) + h_m) * np.sin(lat)
    return np.stack([x, y, z], axis=-1)


def ecef_to_geodetic(xyz, iterations: int = 6):
    x, y, z = np.moveaxis(np.asarray(xyz, dtype=float), -1, 0)
    lon = np.arctan2(y, x)
    p = np.hypot(x, y)
    lat = np.arctan2(z, p * (1 - E2))
    for _ in range(iterations):
        N = A_WGS84 / np.sqrt(1 - E2 * np.sin(lat) ** 2)
        h = p / np.cos(lat) - N
        lat = np.arctan2(z, p * (1 - E2 * N / (N + h)))
    N = A_WGS84 / np.sqrt(1 - E2 * np.sin(lat) ** 2)
    h = p / np.cos(lat) - N
    return np.degrees(lat), np.degrees(lon), h


def _enu_rot(lat0, lon0):
    la, lo = np.radians(lat0), np.radians(lon0)
    return np.array([[-np.sin(lo), np.cos(lo), 0],
                     [-np.sin(la) * np.cos(lo), -np.sin(la) * np.sin(lo), np.cos(la)],
                     [np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)]])


def geodetic_to_enu(lat, lon, h, lat0, lon0, h0):
    d = geodetic_to_ecef(lat, lon, h) - geodetic_to_ecef(lat0, lon0, h0)
    return d @ _enu_rot(lat0, lon0).T


def enu_to_geodetic(enu, lat0, lon0, h0):
    xyz = np.asarray(enu) @ _enu_rot(lat0, lon0) + geodetic_to_ecef(lat0, lon0, h0)
    return ecef_to_geodetic(xyz)


def rotation_ypr(yaw, pitch, roll) -> np.ndarray:
    """Body -> navigation (NED) rotation for ZYX Euler angles (radians)."""
    cy, sy, cp, sp, cr, sr = np.cos(yaw), np.sin(yaw), np.cos(pitch), np.sin(pitch), np.cos(roll), np.sin(roll)
    return np.array([[cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
                     [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
                     [-sp, cp * sr, cp * cr]])


def quat_from_ypr(yaw, pitch, roll) -> np.ndarray:
    cy, sy = np.cos(yaw / 2), np.sin(yaw / 2)
    cp, sp = np.cos(pitch / 2), np.sin(pitch / 2)
    cr, sr = np.cos(roll / 2), np.sin(roll / 2)
    return np.array([cr * cp * cy + sr * sp * sy, sr * cp * cy - cr * sp * sy, cr * sp * cy + sr * cp * sy,
                     cr * cp * sy - sr * sp * cy])


def ypr_from_quat(q) -> tuple[float, float, float]:
    w, x, y, z = q
    yaw = np.arctan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
    pitch = np.arcsin(np.clip(2 * (w * y - z * x), -1, 1))
    roll = np.arctan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    return float(yaw), float(pitch), float(roll)


def slerp(q0, q1, t: float) -> np.ndarray:
    q0 = np.asarray(q0, dtype=float)
    q1 = np.asarray(q1, dtype=float)
    d = float(np.dot(q0, q1))
    if d < 0:
        q1, d = -q1, -d
    if d > 0.9995:
        q = q0 + t * (q1 - q0)
        return q / np.linalg.norm(q)
    th = np.arccos(d)
    return (np.sin((1 - t) * th) * q0 + np.sin(t * th) * q1) / np.sin(th)


def ned_to_enu(v) -> np.ndarray:
    v = np.asarray(v, dtype=float)
    return np.stack([v[..., 1], v[..., 0], -v[..., 2]], axis=-1)
