"""Vehicle navigation time series and interpolation to sensor timestamps."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .frames import quat_from_ypr, slerp, ypr_from_quat


@dataclass
class NavSeries:
    t: np.ndarray                 # UTC seconds
    east: np.ndarray              # local ENU (m)
    north: np.ndarray
    depth: np.ndarray             # m, positive down
    yaw: np.ndarray               # rad (heading, from north, clockwise)
    pitch: np.ndarray
    roll: np.ndarray
    altitude: np.ndarray          # m above seabed (DVL)
    pos_std: np.ndarray           # horizontal 1-sigma (m)
    att_std: float = np.radians(0.05)
    alt_std: float = 0.02

    def __post_init__(self):
        if np.any(np.diff(self.t) <= 0):
            raise ValueError("navigation timestamps must increase")

    def interpolate(self, t) -> dict:
        """Position (linear), attitude (quaternion slerp) and uncertainty at ``t``.
        Extrapolation beyond the series raises (no silent invention of pose)."""
        t = float(t)
        if t < self.t[0] or t > self.t[-1]:
            raise ValueError(f"time {t} outside navigation coverage [{self.t[0]}, {self.t[-1]}]")
        i = int(np.clip(np.searchsorted(self.t, t) - 1, 0, self.t.size - 2))
        a = (t - self.t[i]) / (self.t[i + 1] - self.t[i])
        lin = lambda v: float(v[i] + a * (v[i + 1] - v[i]))
        q = slerp(quat_from_ypr(self.yaw[i], self.pitch[i], self.roll[i]),
                  quat_from_ypr(self.yaw[i + 1], self.pitch[i + 1], self.roll[i + 1]), a)
        yaw, pitch, roll = ypr_from_quat(q)
        return {"east": lin(self.east), "north": lin(self.north), "depth": lin(self.depth), "yaw": yaw,
                "pitch": pitch, "roll": roll, "altitude": lin(self.altitude), "pos_std": lin(self.pos_std),
                "att_std": self.att_std, "alt_std": self.alt_std}
