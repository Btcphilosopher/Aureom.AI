"""Underwater camera geometry: pinhole + Brown-Conrady intrinsics behind a
flat port, with explicit refraction (air -> glass -> water), seabed
intersection and georeferencing with uncertainty."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..calibration.environment import seawater_index
from .frames import rotation_ypr


@dataclass
class CameraModel:
    fx: float
    fy: float
    cx: float
    cy: float
    width: int
    height: int
    k1: float = 0.0
    k2: float = 0.0
    p1: float = 0.0
    p2: float = 0.0
    lever_arm_m: tuple[float, float, float] = (0.0, 0.0, 0.0)      # body frame (fwd, stbd, down)
    boresight_ypr: tuple[float, float, float] = (0.0, 0.0, 0.0)    # camera->body misalignment
    n_water: float | None = None

    def ray_in_air(self, u, v, iterations: int = 5) -> np.ndarray:
        """Unit ray (camera frame: x right, y down, z optical axis) after
        removing lens distortion (fixed-point inversion)."""
        xd = (np.asarray(u, dtype=float) - self.cx) / self.fx
        yd = (np.asarray(v, dtype=float) - self.cy) / self.fy
        x, y = xd.copy(), yd.copy()
        for _ in range(iterations):
            r2 = x * x + y * y
            rad = 1 + self.k1 * r2 + self.k2 * r2 * r2
            dx = 2 * self.p1 * x * y + self.p2 * (r2 + 2 * x * x)
            dy = self.p1 * (r2 + 2 * y * y) + 2 * self.p2 * x * y
            x = (xd - dx) / rad
            y = (yd - dy) / rad
        d = np.stack([x, y, np.ones_like(x)], axis=-1)
        return d / np.linalg.norm(d, axis=-1, keepdims=True)

    def ray_in_water(self, u, v, wavelength_nm: float = 550.0, **env) -> np.ndarray:
        """Refract through a flat port normal to the optical axis (Snell;
        a parallel glass slab does not change the final direction)."""
        d = self.ray_in_air(u, v)
        n = self.n_water or float(seawater_index(wavelength_nm, **env))
        sin_a = np.linalg.norm(d[..., :2], axis=-1)
        sin_w = sin_a / n
        cos_w = np.sqrt(1 - sin_w ** 2)
        scale = np.where(sin_a > 0, sin_w / np.maximum(sin_a, 1e-12), 1 / n)
        out = np.concatenate([d[..., :2] * scale[..., None], cos_w[..., None]], axis=-1)
        return out / np.linalg.norm(out, axis=-1, keepdims=True)

    def gsd_m(self, altitude_m: float, wavelength_nm: float = 550.0) -> float:
        """Ground sample distance at nadir for a flat seabed (refraction included)."""
        n = self.n_water or float(seawater_index(wavelength_nm))
        return altitude_m / (self.fx * n)


# camera axes (x right, y down, z forward/down-looking) -> body (fwd, stbd, down) for a down-looking camera
_CAM_TO_BODY_DOWN = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1]], dtype=float)


def georeference_pixels(cam: CameraModel, u, v, pose: dict, *, seabed_depth: float | None = None, n_mc: int = 0,
                        seed: int = 0):
    """Intersect pixel rays with a flat seabed (depth = vehicle depth +
    altitude unless given). Returns east, north (and std if n_mc > 0)."""
    def once(p):
        R = rotation_ypr(p["yaw"], p["pitch"], p["roll"]) @ rotation_ypr(*cam.boresight_ypr)
        d_body = (_CAM_TO_BODY_DOWN @ cam.ray_in_water(u, v)[..., None])[..., 0]
        d_ned = (R @ d_body[..., None])[..., 0]
        lever = R @ np.asarray(cam.lever_arm_m)
        origin_ned = np.array([p["north"], p["east"], p["depth"]]) + lever
        z_bed = seabed_depth if seabed_depth is not None else p["depth"] + p["altitude"]
        s = (z_bed - origin_ned[2]) / np.maximum(d_ned[..., 2], 1e-9)
        pt = origin_ned + s[..., None] * d_ned
        return pt[..., 1], pt[..., 0]

    e, n = once(pose)
    if n_mc <= 0:
        return e, n
    rng = np.random.default_rng(seed)
    es, ns = [], []
    for _ in range(n_mc):
        p = dict(pose)
        p["east"] += rng.normal(0, pose["pos_std"] / np.sqrt(2))
        p["north"] += rng.normal(0, pose["pos_std"] / np.sqrt(2))
        for k in ("yaw", "pitch", "roll"):
            p[k] += rng.normal(0, pose["att_std"])
        p["altitude"] += rng.normal(0, pose["alt_std"])
        a, b = once(p)
        es.append(a)
        ns.append(b)
    return e, n, np.hypot(np.std(es, axis=0), np.std(ns, axis=0))
