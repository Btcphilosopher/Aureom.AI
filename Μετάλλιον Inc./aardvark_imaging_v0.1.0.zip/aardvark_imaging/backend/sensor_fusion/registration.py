"""Sensor-to-sensor spatial registration and timestamp alignment."""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree


def rigid_2d(src, dst):
    """Least-squares rotation + translation mapping src -> dst (Kabsch)."""
    s = np.asarray(src, dtype=float)
    d = np.asarray(dst, dtype=float)
    cs, cd = s.mean(0), d.mean(0)
    H = (s - cs).T @ (d - cd)
    U, _, Vt = np.linalg.svd(H)
    R = Vt.T @ U.T
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = Vt.T @ U.T
    return R, cd - R @ cs


def icp_2d(src, dst, *, iterations: int = 30, max_distance: float = 0.5, tol: float = 1e-6):
    """Iterative closest point between e.g. camera-detected nodule centroids
    (src) and sonar-detected targets (dst). Returns R, t, rms residual and
    the number of matched pairs."""
    s = np.asarray(src, dtype=float)
    tree = cKDTree(np.asarray(dst, dtype=float))
    R, t = np.eye(2), np.zeros(2)
    prev = np.inf
    rms, n = np.inf, 0
    for _ in range(iterations):
        cur = s @ R.T + t
        d, j = tree.query(cur)
        ok = d < max_distance
        n = int(ok.sum())
        if n < 3:
            break
        dR, dt = rigid_2d(cur[ok], tree.data[j[ok]])
        R, t = dR @ R, dR @ t + dt
        rms = float(np.sqrt(np.mean(d[ok] ** 2)))
        if abs(prev - rms) < tol:
            break
        prev = rms
    return R, t, rms, n


def align_times(sensor_ticks, timebase) -> np.ndarray:
    """Hardware ticks -> UTC via the PPS-fitted timebase."""
    return np.asarray(timebase.to_utc(np.asarray(sensor_ticks)))


def nearest_in_time(t_query, t_ref, max_dt: float):
    """Indices of nearest reference times, -1 where farther than ``max_dt``."""
    tq = np.asarray(t_query, dtype=float)
    tr = np.asarray(t_ref, dtype=float)
    j = np.clip(np.searchsorted(tr, tq), 1, tr.size - 1)
    left, right = tr[j - 1], tr[j]
    k = np.where(np.abs(tq - left) <= np.abs(right - tq), j - 1, j)
    return np.where(np.abs(tr[k] - tq) <= max_dt, k, -1)
