"""Confidence-weighted, provenance-preserving sensor fusion.

Each channel contributes a probability vector over a common class taxonomy,
a quality weight in [0, 1] and provenance. Fusion is a weighted log-linear
opinion pool. Disagreement is measured and *recorded* (never silently
resolved): pairwise Jensen-Shannon divergence and explicit conflicts where
two confident channels prefer different classes. Missing channels are simply
absent; repeated measurements are screened for outliers by robust z-score.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class ChannelOpinion:
    channel: str
    probabilities: dict[str, float]
    quality: float
    provenance_id: str
    notes: str = ""


@dataclass
class Conflict:
    channel_a: str
    channel_b: str
    class_a: str
    class_b: str
    js_divergence: float


@dataclass
class FusionResult:
    classes: list[str]
    probabilities: dict[str, float]
    top_class: str
    top_probability: float
    entropy_bits: float
    channels_used: list[str]
    channels_missing: list[str]
    conflicts: list[Conflict]
    max_js_divergence: float
    opinions: list[ChannelOpinion] = field(default_factory=list)


def _vec(p: dict, classes, eps=1e-6):
    v = np.array([p.get(c, 0.0) for c in classes], dtype=float) + eps
    return v / v.sum()


def js_divergence(p, q) -> float:
    m = 0.5 * (p + q)
    kl = lambda a, b: float(np.sum(a * np.log2(a / b)))
    return 0.5 * kl(p, m) + 0.5 * kl(q, m)


def fuse(opinions: list[ChannelOpinion], classes: list[str], *, expected_channels: list[str] | None = None,
         confident: float = 0.6, min_quality: float = 0.05) -> FusionResult:
    used = [o for o in opinions if o.quality >= min_quality]
    if not used:
        raise ValueError("no channel with sufficient quality")
    logp = np.zeros(len(classes))
    vecs = {}
    for o in used:
        v = _vec(o.probabilities, classes)
        vecs[o.channel] = v
        logp += o.quality * np.log(v)
    logp -= logp.max()
    p = np.exp(logp)
    p /= p.sum()
    conflicts, maxjs = [], 0.0
    names = list(vecs)
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = vecs[names[i]], vecs[names[j]]
            js = js_divergence(a, b)
            maxjs = max(maxjs, js)
            ca, cb = int(np.argmax(a)), int(np.argmax(b))
            if ca != cb and a[ca] >= confident and b[cb] >= confident:
                conflicts.append(Conflict(names[i], names[j], classes[ca], classes[cb], js))
    k = int(np.argmax(p))
    missing = sorted(set(expected_channels or []) - {o.channel for o in used})
    return FusionResult(list(classes), {c: float(x) for c, x in zip(classes, p)}, classes[k], float(p[k]),
                        float(-np.sum(p * np.log2(np.maximum(p, 1e-15)))), [o.channel for o in used], missing,
                        conflicts, float(maxjs), list(opinions))


def robust_outliers(values, k: float = 3.5) -> np.ndarray:
    """Modified z-score (Iglewicz & Hoaglin) outlier mask for repeat measurements."""
    v = np.asarray(values, dtype=float)
    med = np.median(v)
    mad = np.median(np.abs(v - med))
    if mad == 0:
        return np.zeros(v.size, dtype=bool)
    return np.abs(0.6745 * (v - med) / mad) > k
