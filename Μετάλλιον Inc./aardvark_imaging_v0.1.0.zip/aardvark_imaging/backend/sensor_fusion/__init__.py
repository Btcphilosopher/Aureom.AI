"""Sensor fusion: frames, navigation, camera geometry, registration, evidence fusion."""
