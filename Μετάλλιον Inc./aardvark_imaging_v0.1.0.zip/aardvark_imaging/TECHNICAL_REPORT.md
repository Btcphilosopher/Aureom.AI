# Aardvark Imaging × Μετάλλιον Inc.: technical report

Instrument AAI-SSA-1 · software 0.1.0 · report date 2026-11-02

## 1. Summary

The complete software and digital-hardware design of the instrument is in place. **None of it has touched real sensor data.**

* **Silica Flux layer:** a manifest-driven hardware contract (133 registers, 12 sensor channels, 5 clock domains) with a code generator that keeps the RTL, host software and documentation consistent.
* **RTL:** 5,450 lines of synthesizable SystemVerilog, verified by 25 self-checking testbenches (91,412 checks) and bit-exact cross-checks against Python.
* **Backend:** a 10,000-line Python backend covering acquisition, calibration, spectral, carbon, mineral/nodule, acoustic, EM, fusion, mapping and storage.
* **Service and workstation:** a FastAPI service with WebSocket telemetry and a browser workstation with a WebGL seabed model.
* **Tests:** 207 automated tests pass, with 91 % line coverage of the backend.

**All sensor data is simulated.** No detector is selected, no calibration is measured, and no FPGA is programmed. The simulated validation shows the algorithms behave as designed on synthetic scenes. **It is not evidence of field accuracy.**

## 2. What is implemented

| Area | Implemented |
|---|---|
| Silica Flux | TOML manifest + validator; generators for SV register package, AXI4-Lite register file, exhaustive register testbench, Python map, C header, Markdown/JSON map, Q15 sine ROM, data-rate budget; staleness check |
| RTL | all 17 required modules (`sf_sensor_top`, HSI/MS/SWIR/Raman/IR/fluorescence controllers, sonar interface, EM induction, laser timing, ADC interface, sensor sync, timestamp engine, calibration engine, DMA, packetiser, FPGA diagnostics) plus CDC, FIFOs, SPI, I2C, LVDS aligner, row capture, housekeeping |
| Acquisition | SFP1 codec (CRC, resync, sentinels), ring reader with gap accounting, `MmapRing` for UIO, append-only crash-recoverable raw spool, PPS timebase fit |
| Calibration | versioned immutable records with certificates, expiry and status; dark/flat/bad-pixel/linearity/radiometric/reflectance; Hg-Ar wavelength; Raman shift and intensity; seawater and sapphire optics |
| Spectral | ALS/modpoly baselines, cosmic-ray removal, peak fitting with SE, continuum removal, SAM/SID, multispectral registration, colour and HDR, Raman processing and band assignment, ATR-IR, fluorescence |
| Hyperspectral | cube with raw + provenance, push-broom assembly, calibration chain, water-path correction with band masking, PCA/MNF/ATGP/VCA/FCLS, SAM classification with refusal |
| Carbon | D/G fit with water band, carbonate identification, 7-class evidence engine with Monte Carlo intervals and quantitation levels, PLS TOC/TIC with grouped CV and applicability domain, IDW mapping with confidence |
| Mineral / nodules | detection (median, percentile flattening, capped Otsu, priority-flood watershed, saddle merge, colour test), sub-pixel measurement, Monte Carlo volume/mass, persistent registry, mineral assessment, assay-linked grade engine keeping grade, purity, mass and recoverable metal separate |
| Acoustics / EM / radar | Mackenzie, Ainslie–McColm, ray tracing, multibeam georeferencing and gridding, backscatter, chirp and matched filter, delay-and-sum, sub-bottom; EMI I/Q, LIN apparent conductivity, platform compensation; radar feasibility gate and FMCW with refusal |
| Fusion / geospatial | frames (geodetic, ECEF, ENU, quaternions), navigation interpolation, flat-port refracting camera model with Monte Carlo georeferencing, ICP, log-linear fusion with recorded conflicts; GeoJSON, ESRI ASCII, PLY, CSV, NetCDF, Zarr |
| Storage | Zarr/HDF5 cube store (raw write-once, named products), SQL repository (SQLite/PostgreSQL), audit log |
| API | 20+ endpoints, API-key auth (HTTP + WebSocket), WebSocket telemetry, live simulated acquisition through the same ring → spool path as hardware, exports, optional SQL persistence |
| Workstation | dashboard, spectral (cube, pixel spectra, pins, class overlay), carbon (layers, evidence, Raman), mineral (register, record), geology (WebGL orbit, layers, nodules, track, picking); live or offline snapshot; desktop and phone layouts |
| Deployment | Dockerfile, compose (API + PostgreSQL 16), env template, five deployment profiles, XDC timing template |

## 3. What is tested

| Suite | Count | Result |
|---|---:|---|
| Unit (`tests/unit`) | 125 | pass |
| Integration: API, WebSocket, spool, pipeline (`tests/integration`) | 40 | pass |
| Scientific constraints (`tests/scientific`) | 11 | pass |
| Simulated validation, two scenes (`tests/validation`) | 14 | pass |
| RTL cross-checks against Python (`tests/hardware/test_rtl_crosscheck.py`) | 13 | pass |
| RTL simulation: Verilator lint + 25 testbenches (`-m hardware`) | 2 (25 TBs, 91,412 checks) | pass |
| Workstation in Chromium: live + snapshot, desktop + 390 px phone, zero console errors, no horizontal scroll (`-m ui`) | 2 | pass |

Other verification:

* **Coverage:** 91 % of backend lines (non-hardware suites).
* **Clean install:** wheel build → clean virtual environment → `aardvark serve` against **PostgreSQL 16**. The survey was persisted, live acquisition spooled 865 packets with no gaps, and recovery verified every record.
* **Defects:** 7 RTL defects, 10 testbench defects and 22 software/science defects were found by tests and fixed. They are listed in `VERIFICATION_LOG.md`.

## 4. What is simulated, estimated or not done

| Item | Status |
|---|---|
| All sensor data | **SIMULATED** (deterministic scene generator with optics, detector noise, acoustics, EM) |
| All calibrations | **SIMULATED** records; several kinds deliberately missing to exercise warnings |
| Spectral library | **SIMULATED** parametric VNIR library; loaders for USGS/RRUFF exist, no measured library is bundled |
| Water optical model | approximate absorption table; must be replaced with measured coefficients |
| Nodule mass | **ESTIMATED**: ellipsoid volume with a height-ratio prior × literature density, not weighed |
| Carbon concentrations | **not reported**: no validated TOC/TIC model exists |
| Elemental grade | reported only from linked (simulated) assays; the assay-calibrated Ni model is refused in both simulated scenes (CV R² 0.22 and 0.58 < 0.6) |
| Mineralogical purity | **not reported**: requires XRD |
| FPGA implementation | not done: no Vivado synthesis, place-and-route or timing closure; Yosys mapping estimate only (~81 k LUT, 31 DSP, 83 BRAM tiles) |
| Vendor IP boundaries | CSI-2 D-PHY/RX, ISERDES, PS block design and UIO driver are outside the portable RTL |
| RGB0 context camera | in the manifest, **not instantiated** in `sf_sensor_top` |
| `MmapRing` | tested on a file-backed mmap, not on a UIO device |
| Docker image | Dockerfile and compose written; **image not built here** (Docker Hub blocked, HTTP 403). The identical install path was tested in a clean venv with PostgreSQL. |
| Formal verification, gate-level simulation | not done |

## 5. Simulated performance (against simulated ground truth)

| Metric | Scene 21 | Scene 7 | Note |
|---|---:|---:|---|
| Nodule detection precision | 1.00 | 1.00 | colour test rejects dark biogenic cover |
| Nodule detection recall | 0.69 | 0.61 | missed nodules are mostly ones partly covered by biogenic material, or merged with it |
| Equivalent diameter MAE / bias | 1.1 / +0.8 mm | 1.7 / +1.4 mm | 5 mm GSD |
| Mass MAE | 32 g | 47 g | median estimate/true ≈ 1.1 (small elongated nodules look rounder after pixelisation) |
| 95 % mass-interval coverage | 0.89 | 0.88 | below nominal 0.95: intervals too narrow |
| Abundance, estimated vs true | 5.2 vs 7.1 kg/m² | 5.0 vs 7.0 kg/m² | **biased low by 15–28 %**, conservative because of missed nodules |
| Carbon classification accuracy / ECE | 1.00 / 0.06 | 1.00 / 0.06 | self-consistency; 5 of 7 classes exercised |
| HSI: nodule pixels → Mn oxide | 0.79 | 0.77 | sediment pixels → Mn oxide 0.15 / 0.16 |
| Bathymetry RMSE | 3.5 cm | 4.1 cm | 0.25 m grid |
| EMI residual after compensation | ×0.09 | ×0.08 | fitted on a separate manoeuvre |

**Trade-off in the colour test.** Before it was added, detection reached recall 0.85 at precision 0.81. Abundance was then overestimated 2.3×, because dark biogenic patches were measured as kilogram-scale nodules. The conservative setting was kept.

## 6. Limitations and risks

1. **IR0 (diamond-ATR mid-IR) is the highest-risk sensor.** It is contact-only and samples about 1 µm of surface; there is no open-water mid-IR path. Feasibility is unproven.
2. **SWIR0 works only at contact or with a water gap of a few millimetres.** The maximum standoff is about 1.9 cm at 1200 nm and about 0.7 mm at 1450 nm.
3. **Imagery-only detection misses partly covered or buried nodules.** Recall is about 0.6–0.7 in simulation, and abundance from imagery is a lower bound. Acoustic sub-bottom data and box-core ground truth are needed to correct it.
4. **Mass depends on an unobserved height.** Calibrate the height-ratio prior against weighed nodules, or add stereo or laser-line height.
5. **Carbon and grade evidence weights are expert priors.** They must be re-estimated from laboratory data.
6. **The carbon validation tests nothing outside the simulator's own physics.** Its 1.0 accuracy is self-consistency.
7. **The data rate exceeds what multi-day missions can store.** The assumed configuration produces about 740 GB/hour at full duty, so the area cameras must be duty-cycled or decimated on the vehicle.
8. **Timing closure is unknown.** The generated register-file read mux is large; pipelining may be needed at 100 MHz.

## 7. Hardware required

* **FPGA:** Zynq UltraScale+ evaluation board (XCZU7EV-class) with FMC/GPIO carriers.
* **Cameras:**
  * VNIR push-broom HSI camera (LVDS or Camera Link);
  * global-shutter CSI-2 monochrome camera with an 8-band LED ring;
  * InGaAs SWIR camera with a displacement window.
* **Point spectrometers:**
  * 532 nm TE-cooled Raman spectrometer and probe;
  * QCL/ICL + TE-MCT ATR module (feasibility unit);
  * three-excitation LED fluorometer.
* **Acoustics and EMI:**
  * multibeam echosounder with trigger and ack I/O;
  * 8-element acoustic array with an LVDS ADC evaluation board;
  * EMI coil pair with DAC and ADC front-end.
* **Timing:** a GNSS/PPS source for timing tests.
* **Facilities:** a water tank with temperature control and a pressure vessel for housing tests.

## 8. Laboratory validation required

1. Detector characterisation (dark, PRNU, linearity, bad pixels, noise) at 2 °C.
2. Traceable radiometric calibration through the sapphire port in water at 1–3 m, plus measured water attenuation for the survey water mass.
3. Measured spectral libraries (VNIR/SWIR/Raman/ATR-IR) of XRD-characterised nodule phases, sediments and organics.
4. Carbon reference set: at least 20 independent wet samples with coulometric/EA TOC and TIC, measured on the probe. This trains and validates the PLS model.
5. Grade reference set: at least 30 nodules with ICP-MS/OES, XRD and weighed wet and dry mass. This covers the grade model and the mass prior.
6. Tank trials with known targets, then sea-trial transects with box-core ground truth per m².

## 9. Next milestones

| # | Milestone | Exit criterion |
|---|---|---|
| M1 | Detector selection | manifest `assumed = false` for chosen parts; budget recomputed |
| M2 | Vivado implementation | timing closed at 100 MHz with the completed XDC; `report_cdc` clean |
| M3 | Board bring-up | register test, PPS timestamping, test-pattern stream decoded with zero CRC errors over 24 h |
| M4 | IR0 feasibility | ATR spectra of wet Fe-Mn crust with SNR ≥ 10 on the carbonate and C–H lines |
| M5 | Laboratory calibration set | measured libraries; carbon and grade models validated through their gates |
| M6 | Tank trial | detection, size and mass against known targets; measured validation reports |
| M7 | Pressure and thermal qualification | electronics housing at 600 bar, 0–40 °C |
| M8 | Sea trial | transect results with box-core ground truth; acceptance criteria agreed with Μετάλλιον |

## 10. Notes on the brief

* **Silica Flux:** no Μετάλλιον repository or Silica Flux definition was available, and the user's earlier SilicaFlux ISA sources could not be reached. Silica Flux was therefore established as a documented manifest-and-generator methodology, not invented syntax (`docs/repository_inspection.md`).
* **Repository location:** the subsystem lives at `metallion/aardvark_imaging/`, ready to be moved into the real repository.
