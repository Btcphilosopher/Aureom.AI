# Spectral processing

All processing keeps the raw cube (`HyperspectralCube.raw`, uint16 counts) next to the processed data. Each processing step adds four things to the cube's record:

* a history entry;
* calibration IDs;
* parameters;
* an origin update (`model_applied=True` turns MEASURED into ESTIMATED).

Products are write-once in Zarr/HDF5 (`storage/cube_store.py`).

## 1. Hyperspectral (HSI0) chain — `hyperspectral/pipeline.py`

1. **Assembly** (`cube.assemble_pushbroom`): HSI_ROW packets go into a (line, sample, band) cube.
   * A dropped packet becomes a *masked* spectral row. It is never interpolated silently.
   * Sentinel codes become saturated and bad masks.
   * The packet SIMULATED flag sets the cube origin.
2. **Dark subtraction:** the per (sample, band) dark comes from a `DarkReference`, scaled by temperature if needed.
3. **Flat field:** per-pixel PRNU gain.
4. **Bad-pixel repair:** spatial 3×3 mean of valid neighbours in the same band. Repaired samples stay flagged. Saturated samples are never "repaired", because they hold no information.
5. **Radiance:** responsivity from a traceable sphere certificate, with its uncertainty.
6. **Water-path correction** (`water.correct_water_path`):
   * Removes two-way attenuation exp(−c(λ)·2h) with c = a_w + b_w + c_p, and subtracts backscatter if a model is provided.
   * **Bands with two-way transmission below t_min are set invalid (NaN), not amplified.**
   * The absorption table is approximate and must be replaced with measurements for the survey water mass (`WATER_TABLE_NOTE` records this in the product).
7. **Reflectance** from an in-water reference panel at survey altitude. With no reference, this step raises an error; it never assumes one.
8. **Optional MNF denoising** (`analysis.mnf`).
   * Noise covariance comes from shift differences.
   * It needs spatially correlated signal and is sensitive to outliers (edges, pure-pixel discontinuities) in the difference statistics.
   * Use with care. It is off in the survey pipeline.

**Survey pipeline differences:** the simulated survey (`simulation/survey.py`) runs the same physics inline. It classifies pixels with a few flagged usable bands (≥ 90 % valid) after linear interpolation along wavelength. The cube keeps those samples as NaN, and the number of pixels so treated is reported (`pixels_with_interpolated_bands`).

## 2. Analysis — `hyperspectral/analysis.py`, `classification.py`

* **PCA:** explained variance and loadings.
* **Endmember extraction:** ATGP and VCA.
* **Unmixing:** FCLS (non-negative, sum-to-one), giving abundances, per-pixel standard deviation and RMSE. Abundances are **areal surface fractions**, not volume or mass fractions, and are reported as such.
* **SAM classification:**
  * Usable bands only.
  * An angle threshold (`max_angle`) and a minimum probability. Below either, a pixel is **unclassified**, never forced into a class.
  * Probabilities use a Gaussian likelihood in angle, with σ derived from SNR.
* **Library:**
  * `mineralogy/library.parametric_vnir_library` is a **SIMULATED** parametric library (Mn oxides, goethite, smectite, calcite, CFA, sediment, biological) for development only.
  * Measured libraries load from USGS splib07 or RRUFF files.

## 3. Multispectral / RGB — `spectral/multispectral.py`

* Band registration by sub-pixel phase correlation, and motion-shift prediction from the vehicle velocity.
* Brown–Conrady undistortion.
* Least-squares colour matrix against a chart, with ΔE76 in CIELAB.
* HDR merge of an exposure bracket, excluding saturated samples.

## 4. Raman — `spectral/raman.py`

* **Dark and noise:** dark subtraction, then a σ per channel from shot, read and dark noise.
* **Cosmic rays:**
  * multi-frame rejection (median and MAD across frames);
  * a single-frame fallback for the case where only one frame exists.
* **Response correction** with an `IntensityResponse` (NIST SRM 2241 or equivalent).
* **Baseline:** ALS, with modified polynomial as an alternative.
* **Band assignment** against `RAMAN_REFERENCE` (Mn oxides, Fe oxides, carbonates, apatite, quartz, barite, water, seawater sulfate):
  * a tolerance window;
  * SNR from the fitted or half-maximum height over σ;
  * the observed shift reported alongside the reference.
* **Shift axis:** the shift↔wavelength conversion uses the calibrated laser wavelength (`calibration/raman_shift.py`).

## 5. ATR mid-IR — `spectral/infrared.py`

* **Absorbance:** A = −log10(I_sample / I_background), from lock-in demodulated signals with propagated SE.
* **Water correction:** subtraction scaled on the 1640 cm⁻¹ bending band.
* **Contact fraction:** estimated from the water band depth.
* **Penetration depth:** d_p ≈ λ / (2π n₁ √(sin²θ − (n₂/n₁)²)); about 0.5–1.7 µm across the lines.
* **Line roles:** C–H (organic), CO₃ (carbonate), Mn–O (lattice).
* **Systematic floor:** 0.02 AU before a band counts as detected.

## 6. Fluorescence — `spectral/fluorescence.py`

* **Net signal:** LED-on minus LED-off per excitation/emission pair.
* **SNR:** from ADC and shot noise, plus a 2 % background-stability systematic.
* **Interference classification:** chlorophyll, protein-like or humic, by excitation/emission pair.

## 7. Nodule imagery — `nodules/detection.py`, `measurement.py`

* **Detection steps:**
  1. Median filter (impulse noise).
  2. Percentile-background flattening (illumination and sediment facies).
  3. Otsu threshold capped at 0.55 relative darkness.
  4. Opening and hole fill.
  5. Distance-transform seeds (every component keeps at least one).
  6. Priority-flood watershed of the distance map.
  7. Saddle-based merge of over-split regions: merged when the saddle is at least 0.75 × the smaller peak.
  8. Size filter.
* **Colour test** (`reject_by_chromaticity`): compares ln(G/B) inside the region with its annulus. Mn-oxide nodules are spectrally flat; dark biogenic cover is green-brown and is rejected.
  * The threshold (0.0) was chosen on SIMULATED scenes and must be re-tuned on real imagery.
* **Measurement:**
  * Area is sub-pixel: pixel count plus fractional edge coverage.
  * Ellipse moments give the axes.
  * Volume comes from an ellipsoid with a height-ratio prior U(0.6, 1.0) × the minor semi-axis. A nadir camera does not observe nodule height.
  * Mass = volume × wet bulk density (1.95 ± 0.10 g cm⁻³, literature).
  * Monte Carlo 95 % intervals.
  * **All of these are ESTIMATED.**
* **Registry:** persistent IDs; re-identification within a k·σ position gate; observation history; linked assays and XRD.

## 8. Fusion — `sensor_fusion/fusion.py`

* **Pooling:** quality-weighted log-linear pooling of channel opinions.
* **Disagreements are recorded:** when two channels confidently disagree, the fusion records a `Conflict` with the Jensen–Shannon divergence, rather than averaging the disagreement away.
* **Missing channels:** expected but missing channels are listed.
