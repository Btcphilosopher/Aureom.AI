# Benchmarks (measured)

`aardvark benchmark` was run on the build machine: 2 vCPU Intel Xeon @ 2.1 GHz, Python 3.13.18, Linux. These are software timings on this machine. **They are not instrument performance.**

| Measurement | Result |
|---|---:|
| Full simulated survey, `fast_config` (3×2 m scene, 226 nodules, 81-band HSI, 18 point targets, MBES, EMI, validation) | 2.8 s |
| — image detection + measurement (600×400 px, Monte Carlo 150) | 1.45 s |
| — HSI reflectance + SAM classification + PCA | 0.37 s |
| — carbon engine, 18 targets (Raman/IR/fluorescence processing, MC 200) | 0.49 s |
| — acoustic + EM simulation and processing | 0.30 s |
| SFP1 decode (CRC-checked, numpy) | **385 MB/s** single core |

**Decoder headroom:** the assumed instrument produces 205.6 MB/s on the wire (`docs/data_rate_budget.md`). The Python decoder therefore keeps up with about 1.9× headroom on one core of this machine. Raw spooling does not decode at all; it writes packet words as received.

**FPGA DMA efficiency** of 0.7619 words/cycle was measured in RTL simulation (`tb_sf_dma_controller`, zero-wait AXI slave), not on hardware.

**Live simulated acquisition** (API, 20 lines/s, HSI + MBES + HK + DIAG + Raman): 865 packets in 2 s, written to the raw spool with 0 sequence gaps and 0 CRC errors. The same stream was then verified intact by `spool-recover`.
