# Data-rate budget (derived)

Computed by `aardvark sf budget` from the assumed sensor configuration in the Silica Flux
manifest. These figures are arithmetic, not benchmarks. DMA capacity uses the efficiency
measured in RTL simulation of `sf_dma_controller`, not on hardware.

| Sensor | Packets/s | Payload MB/s | On-wire MB/s | Header overhead | In reference RTL |
|---|---:|---:|---:|---:|:---:|
| HSI0 — VNIR push-broom hyperspectral imager | 9,600.0 | 18.432 | 18.778 | 1.84% | yes |
| MS0 — Global-shutter multispectral camera with sequential narrowband LED illumination | 16,384.0 | 67.109 | 67.699 | 0.87% | yes |
| RGB0 — Colour context camera (Bayer, global shutter) | 12,000.0 | 98.304 | 98.736 | 0.44% | no |
| SWIR0 — InGaAs SWIR contact-standoff imager | 15,360.0 | 19.661 | 20.214 | 2.74% | yes |
| RAM0 — 532 nm Raman spectrometer, TE-cooled back-thinned CCD | 1.0 | 0.008 | 0.008 | 0.44% | yes |
| IR0 — Diamond-ATR multi-line mid-IR probe (QCL/ICL sources, TE-MCT detector) | 2.0 | 0.000 | 0.000 | 21.95% | yes |
| FL0 — Three-excitation pulsed LED fluorometer | 10.0 | 0.001 | 0.001 | 33.33% | yes |
| MBES0 — External multibeam echosounder (trigger + timestamp interface only) | 10.0 | 0.000 | 0.001 | 60.00% | yes |
| ACA0 — High-frequency acoustic imaging array (8-element receive, LVDS ADC) | 10.0 | 0.164 | 0.164 | 0.22% | yes |
| EMI0 — Frequency-domain electromagnetic induction (coplanar loops) | 20.0 | 0.001 | 0.001 | 50.00% | yes |
| HK0 — Housekeeping ADC (temperature, rail voltage, current, housing pressure) | 1.0 | 0.000 | 0.000 | 69.23% | yes |
| DIAG — FPGA diagnostics stream | 1.0 | 0.000 | 0.000 | 36.00% | yes |

* Aggregate on-wire rate: **205.6 MB/s**
* DMA capacity (clk_sys × 4 B × simulated efficiency): **304.8 MB/s**
* Utilisation: **67.5%** — OK
* Raw storage at full duty: **740.2 GB/hour** (17.8 TB/day)

Storage at full duty cycle exceeds what is practical for multi-day AUV missions; survey
plans must duty-cycle the area cameras (MS0/RGB0) or decimate them on the vehicle.

