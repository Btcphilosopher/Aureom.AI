# Sensor specification — AAI-SSA-1

> **Status of every number here.** The detector parameters are *engineering assumptions* for an initial configuration. They are recorded in the Silica Flux manifest with `assumed = true`. No detector has been selected, purchased or measured. The physical limits come from published seawater optics and acoustics, as implemented in `backend/hyperspectral/water.py`, `backend/sonar/acoustics.py`, `backend/electromagnetic/` and `backend/calibration/environment.py`. Replace the assumptions with datasheet values when parts are chosen; `aardvark sf budget` then recomputes the data rates.

## 1. Mission envelope

* **Platform:** ROV/AUV skid or towed sled over abyssal plains (Clarion–Clipperton-type nodule fields).
* **Water depth:** 4,000–6,000 m.
* **Imaging altitude:** 1–3 m (simulation default 2 m).
* **Point sensors:** Raman, ATR-IR and fluorescence need contact or a few millimetres of standoff, so they are deployed by manipulator or a compliant probe.
* **Pressure housings** are rated for 600 bar. Optical ports are sapphire.
  * Sapphire index, Malitson Sellmeier: n ≈ 1.768 at 589 nm.
  * Seawater index, Quan & Fry plus 1.6×10⁻⁴ per MPa: n ≈ 1.342 at 550 nm, 2 °C, 45 MPa.
* **Flat ports and refraction:** a flat port narrows the field of view by about 1/n. Refraction is modelled explicitly in `sensor_fusion/camera.py`.

## 2. The governing constraint: light in seawater

Two-way optical path length is set by the absorption of pure water. The table gives the maximum standoff at which two-way transmission stays above 2 % (approximate absorption table, clear water plus c_p = 0.03 m⁻¹):

| λ (nm) | a_w (m⁻¹) | max standoff |
|---:|---:|---:|
| 450 | 0.008 | ~46 m (turbidity-limited in practice) |
| 550 | 0.054 | ~23 m |
| 650 | 0.36 | ~5 m |
| 700 | 0.62 | ~3 m |
| 750 | 2.5 | ~0.8 m |
| 900 | 6.8 | ~29 cm |
| 1050 | 15 | ~13 cm |
| 1200 | 104 | ~1.9 cm |
| 1450 | ~2900 | ~0.7 mm |
| 1650 | ~550 | ~3.6 mm |

**Consequences for the design:**

* **VNIR hyperspectral (400–800 nm)** works from 1–3 m altitude. Above ~700 nm it is limited by the altitude. At 2 m altitude, 61 of the 81 simulated bands pass the 5 % two-way transmission gate. Unusable bands are *masked*, never amplified.
* **SWIR (950–1650 nm)** works only at contact or with a water gap of a few millimetres. A SWIR imager on an imaging sled at 1–3 m would record no seabed signal at all. SWIR0 is therefore specified as a contact-standoff imager with a displacement window.
* **Mid-IR** cannot be transmitted through open water. Water absorbs 10³–10⁴ m⁻¹ across most of the mid-IR. IR0 is therefore an **ATR** probe on a diamond crystal, which samples the outer ~0.5–1.7 µm of the contacted surface: the penetration depth is about 0.9 µm at 1640 cm⁻¹ and about 1.1 µm at 1430 cm⁻¹. **This is the highest-risk sensor in the array** and needs a feasibility study (§5).

## 3. Sensor channels

| Key | Sensor | Key parameters (assumed) | Interface → RTL | Notes |
|---|---|---|---|---|
| HSI0 | VNIR push-broom HSI | 400–800 nm, 160 bands, 960 px, 12 bit, 60 lines/s | LVDS → `sf_hsi_controller` | the primary mineral-mapping sensor |
| MS0 | multispectral, LED-sequenced | 8 LED bands 405–740 nm, 2048², 12 bit, 8 band-frames/s | CSI-2 → AXI4-S → `sf_multispectral_controller` | LED on only during exposure; band registration in software |
| RGB0 | colour context | 4096×3000 Bayer, 4 fps | CSI-2 (second instance) | **not instantiated in the reference RTL** |
| SWIR0 | InGaAs imager | 950–1650 nm, 6 filter bands, 640×512, 14 bit | ROIC parallel → `sf_swir_controller` | contact / mm-gap only; TEC-lock gated |
| RAM0 | Raman spectrometer | 532 nm excitation, 100–4000 cm⁻¹, 2048 px CCD, 16 bit | SPI ADC → `sf_raman_controller` | laser gated by `sf_laser_timing`; dark frames flagged |
| IR0 | ATR mid-IR | 8 discrete lines (2920, 2850, 2500, 1640, 1430, 1250, 875, 800 cm⁻¹), lock-in | SPI ADC → `sf_ir_controller` | contact only; feasibility risk |
| FL0 | pulsed fluorometer | excitation 280/365/450 nm, emission 340/450/685 nm | SPI ADC → `sf_fluorescence_controller` | LED-off background windows |
| MBES0 | multibeam echosounder | 256 beams, 10 pings/s (external unit) | TTL trigger + TX-ack → `sf_sonar_interface` | datagrams to the host over Ethernet |
| ACA0 | acoustic imaging array | 8 elements, 5 MS/s, 14 bit, 1024 samples/ping | LVDS ADC → `sf_lvds_aligner` | close-range nodule imaging |
| EMI0 | frequency-domain EMI | 1–100 kHz, coplanar loops | DDS/DAC + SPI ADC → `sf_em_induction` | relative material contrast only |
| HK0 | housekeeping | 4 channels, 16 bit | SPI → `sf_housekeeping` | temperature, rails, current, pressure |
| DIAG | FPGA diagnostics | 16 counters | internal → `sf_fpga_diagnostics` | — |

## 4. Acoustic and electromagnetic limits

* **Sound speed at 4500 m** (Mackenzie, 1.5 °C, S = 34.7): about 1532 m/s.
* **Absorption** (Ainslie & McColm, 2 °C, 4.5 km depth):

  | Frequency | Absorption |
  |---:|---:|
  | 12 kHz | 0.9 dB/km |
  | 100 kHz | 13.5 dB/km |
  | 400 kHz | 68 dB/km |
  | 1 MHz | 361 dB/km |

  High-frequency imaging (ACA0) is therefore a few-metre instrument. Bathymetry uses the external MBES.
* **Sub-bottom penetration** falls linearly with frequency (k ≈ 0.2 dB m⁻¹ kHz⁻¹ in clay). Use 2–12 kHz chirps for burial and layering. Nodules buried deeper than a few decimetres are *not* resolvable by the high-frequency array.
* **EMI skin depth** in 3.2 S/m seawater:

  | Frequency | Skin depth |
  |---:|---:|
  | 1 kHz | 8.9 m |
  | 10 kHz | 2.8 m |
  | 100 kHz | 0.89 m |

  * The low-induction-number (LIN) apparent-conductivity formula holds only for coil spacing / skin depth < ~0.3. That means about 0.8 m spacing at 10 kHz, and the software checks `lin_valid`.
  * **EMI output is relative material contrast.** It responds to conductivity/susceptibility changes, such as metal-rich nodule cover versus sediment. **It does not measure carbon, grade or composition.**
* **Radar:** seawater attenuates by about 237 dB/m at 50 MHz, 325 dB/m at 100 MHz and 554 dB/m at 400 MHz. Ground-penetrating radar is not viable through seawater. `electromagnetic/radar.py` refuses to process such paths (`RadarNotFeasible`) and points to sub-bottom profiling or EMI instead. **Radar is never used to infer carbon.**

## 5. Risks and open items

| Item | Risk | Required action |
|---|---|---|
| IR0 ATR probe | high | Bench feasibility first: diamond-ATR contact on wet Fe-Mn crusts, and the water background at 1640 cm⁻¹. Then pressure testing of the QCL/ICL and TE-MCT detector. |
| SWIR0 standoff | medium | Design the displacement window; verify the mm-gap control loop. |
| Raman fluorescence background | medium | Organic-rich surfaces may swamp Raman at 532 nm; evaluate a 785 nm alternative (loss of CCD QE versus fluorescence). |
| Laser safety | managed in RTL | Interlock and submerged-only emission are implemented in hardware. Requires a hazard review for deck operations. |
| RGB0 | low | Instantiate a second single-band multispectral controller when the camera is chosen. |
| CSI-2 / ISERDES | vendor IP | Integrate in the board wrapper; not part of the portable RTL. |
