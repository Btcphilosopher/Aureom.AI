# Silica Flux

Silica Flux is the hardware architecture and design methodology layer for the Aardvark Imaging sensor electronics.

* The full specification is `hardware/silica_flux/architecture/README.md`.
* This page is the working guide.

## Working with the manifest

```bash
aardvark sf validate     # schema + cross-reference checks
aardvark sf generate     # regenerate RTL register file/package, Python/C maps, docs, TB, sine ROM
aardvark sf check        # non-zero exit if any generated artefact is stale (run in CI)
aardvark sf budget       # data-rate budget from the sensor configuration
```

The manifest is `hardware/silica_flux/manifests/aardvark_ssa.sf.toml`.

## Adding a register

1. Add the register to the right `[[register_blocks]]` entry. Give it an offset, an access type (`RW`, `RO`, `RO_CONST`, `W1C` or `W1P`), a reset value and its fields.
2. Run `aardvark sf generate`.
3. Connect the new port of `sf_axil_regfile` in `sf_sensor_top`.
4. The generated testbench `tb_sf_axil_regfile` covers the new register automatically:
   * reset value;
   * write and read-back masks;
   * W1C set-priority;
   * W1P strobes;
   * SLVERR on unmapped addresses.

## Adding a sensor channel

1. **Manifest.** Add a `[[sensors]]` entry with a unique key and UID, its clock domain, packet type, record size, calibration kinds and status registers. Set `assumed = true` until datasheet values replace it.
2. **RTL.** Write the controller in `hardware/systemverilog/sensors/`, following the coding rules (spec §5). Add it as a new packetiser source in `sf_sensor_top`.
3. **Model.** Add a bit-exact Python model and a payload decoder in `backend/acquisition/sfp.py`.
4. **Tests.** Add a self-checking testbench that writes a vector file, and a cross-check test in `tests/hardware/test_rtl_crosscheck.py`.

## Register access types

| Type | Behaviour |
|---|---|
| RW | read/write, reset value from manifest |
| RO | hardware status, writes ignored |
| RO_CONST | constant (ID, version) |
| W1C | sticky status; hardware set wins over a simultaneous software clear |
| W1P | write-1 strobe for one `clk_sys` cycle; reads 0 |

Unmapped addresses return `SLVERR`. Reserved bits read as 0.
