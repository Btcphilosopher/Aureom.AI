# Calibration and validation framework

## 1. Principles

* **Calibrations are versioned, immutable records.** Each record (`calibration/models.py: CalibrationRecord`) carries:
  * sensor and calibration kind, level (factory/field/in-situ) and version;
  * validity window (`valid_from`, `expires`);
  * method, certificate (reference standard, laboratory, uncertainty);
  * environmental conditions (temperature, pressure);
  * parameters, references to large arrays, and the uncertainty.
* **The registry enforces the policy** (`calibration/registry.py`):
  * versions must increase;
  * records cannot be overwritten;
  * the applicable record is the highest version whose window contains the measurement time;
  * the status is one of VALID, EXPIRING (14 days), EXPIRED, MISSING, NOT_YET_VALID or **SIMULATED**.
* **A measured factory calibration without a certificate is rejected** at construction.
* **Calibrations derived from simulated frames are SIMULATED.** That label propagates to every product they touch. The workstation shows per-sensor calibration status, and the health panel raises a WARNING for every missing or expired kind.
* **Raw data is never altered.**
  * The FPGA can apply dark/flat correction (CAL_EN), but the tables are archived with their calibration ID, so raw counts can be reconstructed.
  * The raw spool stores the packets exactly as received.
  * Processed cube products are write-once (`RawOverwriteError`); reprocessing writes a new product name.

## 2. Calibration methods implemented

| Kind | Implementation | Inputs required (laboratory) |
|---|---|---|
| dark | `radiometric.dark_reference`; temperature scaling with `dark_current_scale` (doubling ≈ 7 °C, to be measured) | ≥ 16 dark frames per exposure/temperature |
| flat_field (PRNU) | `flat_field_gain`; per-band normalisation for push-broom | integrating sphere, uniform to < 1 % |
| bad_pixel | `detect_bad_pixels` (robust MAD on dark mean/σ and gain range) | dark + flat stacks |
| linearity | `fit_linearity` (polynomial to the low-signal line) | exposure series of a stable source |
| radiometric | `fit_radiance` → `RadianceCalibration` with uncertainty | NIST/PTB-traceable sphere radiance certificate |
| reflectance | `pipeline.to_reflectance` with `ReflectanceReference` | in-water reference panel at survey altitude; **refused if absent** |
| wavelength | `wavelength.calibrate_from_lines` (Hg-Ar lines; one-to-one matching, unresolved doublets dropped, robust clipping) | pen-ray lamp spectra |
| smile/keystone | `wavelength.smile_shift` | line-lamp across the slit |
| Raman shift | `raman_shift.calibrate_axis` + `refine_laser_wavelength` | cyclohexane / polystyrene (ASTM E1840) |
| Raman intensity | `fit_intensity_response` | NIST SRM 2241 luminescence standard |
| IR background | water reference at 1640 cm⁻¹ (`analyse_ir`) | clean ATR crystal in seawater |
| fluorescence | quinine-sulfate / chlorophyll equivalents | standard solutions |
| colour / distortion / registration | `multispectral.fit_colour_matrix`, `undistort`, `register_bands` | colour chart, checkerboard (in water) |
| EMI | free-field null, phase reference, `fit_platform_compensation` | calibration manoeuvre in the water column, away from the seabed |
| sound velocity | SVP cast | CTD/SVP probe |
| optical window | `environment.window_transmission`, `flat_port_fov_ratio` | measured port transmission |

## 3. Laboratory programme (required before any measured result is reported)

1. **Detector characterisation** at 2 °C and room temperature: dark, PRNU, linearity, bad pixels and read noise for HSI0, MS0, SWIR0 and the Raman CCD.
2. **Radiometric chain:** a traceable sphere through the sapphire port, in a water tank, at 1, 2 and 3 m. This validates the water model (`hyperspectral/water.py` uses an *approximate* absorption table that needs replacing with measured coefficients for the survey water mass).
3. **Spectral libraries:** measure reference spectra (VNIR, SWIR, Raman, ATR-IR) of characterised samples. The built-in `parametric_vnir_library` is **SIMULATED** and must not be used to report measured classifications. Loaders exist for USGS splib07 and RRUFF.
   * Mn oxides: vernadite, todorokite, birnessite.
   * Fe oxyhydroxides: goethite, ferrihydrite.
   * Clays and carbonates: smectite, calcite, aragonite, CFA.
   * Organic standards.
   * Wet nodule fragments.
4. **Carbon reference set:** at least 20 independent physical samples, wet, from the survey area. Each needs:
   * coulometric or elemental-analyser TOC/TIC;
   * Raman, ATR-IR and fluorescence measured on the probe.

   `CarbonCalibrationModel` then fits PLS with grouped cross-validation. It refuses to validate with fewer than 20 groups or with CV R² < 0.7, and refuses predictions outside the training applicability domain.
5. **Grade reference set:** at least 25–30 nodules with:
   * ICP-MS/OES assays (Mn, Ni, Cu, Co, Fe);
   * XRD (Rietveld) phase quantification;
   * weighed wet and dry mass;
   * HSI and Raman features.

   `GradeCalibrationModel` refuses unless CV R² ≥ 0.6. Mass measurements also validate the ellipsoid height-ratio prior used by `measure_nodules`.

## 4. Validation framework (software)

* **Simulated validation** (`tests/validation`): two independent simulated scenes are scored against ground truth for:
  * detection precision and recall;
  * diameter MAE and bias;
  * mass-interval coverage;
  * abundance bias;
  * carbon classification and calibration error (ECE);
  * HSI pixel classes;
  * bathymetry RMSE;
  * EMI compensation;
  * the grade-model gate.

  These are regression guards and a statement of *simulated* performance only.
* **Measured validation (to do):** the same reports (`analytics`, `regression_report`, `classification_report`, `expected_calibration_error`) applied to:
  * tank-trial data with known targets;
  * sea-trial transects with box-core ground truth (nodule counts, masses and assays per m²).

  Acceptance criteria are to be agreed with Μετάλλιον. Each result must be reported with its `DataOrigin` set to `measured` or `lab_validated`.

## 5. Known calibration gaps

* No calibration in this repository is measured. Every record the simulator creates is SIMULATED, and the workstation says so.
* `smile_keystone` (HSI0), `radiometric` (MS0) and `tec_temperature` (SWIR0) are deliberately left missing in the simulation, so the health panel's warning path is exercised.
* Several manifest calibration kinds have no registry model yet. The workstation reports them as "no registry model":
  * `thermistor_curve` and the other housekeeping conversions;
  * `element_gain_phase` and the other acoustic-array kinds;
  * `patch_test_offsets`.
