# Carbon measurement

## 1. What the instrument can and cannot say about carbon

| Question | Method | Output | Quantitative? |
|---|---|---|---|
| Is disordered sp² carbon (kerogen-like, char, graphitic coating) present, and how ordered is it? | Raman D1 (~1350 cm⁻¹) and G (~1585 cm⁻¹) fit | presence, band centres and widths, R1 = I(D1)/I(G), R2, order class | **No.** D/G describes structure, not concentration. |
| Is a carbonate mineral present, and which one? | Raman ν1 (1080–1100 cm⁻¹) and ν4 (700–735 cm⁻¹); ATR-IR ν3/ν2 (1430, 875 cm⁻¹) | phase probabilities | No; presence and phase |
| Are organic C–H bonds present at the surface? | ATR-IR 2920/2850 cm⁻¹ (outer ~1 µm only) | absorbance with SE and a 0.02 AU systematic floor | Semi-quantitative index |
| Fresh phytodetritus / protein-like / humic material? | three-excitation fluorescence (450→685, 280→340, 365→450 nm) | net signal, SNR, background-stability floor (2 %) | Relative index |
| TOC / TIC concentration (wt %) | **only** a laboratory-validated PLS model on the combined features | value with prediction interval, inside the applicability domain | **Yes, if validated.** Otherwise refused. |
| Total carbon from radar, EMI or acoustics | — | — | **Never.** These channels carry no direct carbon information. |

**The engine never produces a single undifferentiated "carbon" number.**

## 2. Raman processing for carbon

* **Pre-processing:** dark subtraction, multi-frame cosmic-ray rejection, intensity-response correction (when calibrated), ALS baseline, and a per-channel σ from shot and read noise (`spectral/raman.py`).
* **D/G fit** (`carbon/raman_carbon.fit_carbonaceous`):
  * Pseudo-Voigt components: D1, bounded 1320–1385 cm⁻¹, and G, bounded 1570–1605 cm⁻¹.
  * An explicit **water bending band** at 1625–1655 cm⁻¹ (width 70–140 cm⁻¹). In seawater, the water bend near 1640 cm⁻¹ otherwise gets taken for a G band; the previous version of the fit made exactly that mistake on bare Mn-oxide surfaces (see `VERIFICATION_LOG.md`).
  * Detection needs G SNR ≥ 5 *and* D1 SNR ≥ 3.
  * The evidence SNR is min(G SNR, 2 × D1 SNR), so one strong band cannot carry the decision alone.
* **Carbonate** (`identify_carbonate`): ν1 position plus ν4 for the polymorph/cation. Calcite and aragonite cannot be separated by ν1 alone, which the result reflects.

## 3. Evidence engine

`carbon/engine.py` scores seven classes:

* organic carbon
* carbonate
* carbon-bearing sediment
* carbonaceous coating
* biological
* carbon-rich inclusion
* background matrix

How it works:

* **Weights:**
  * Each feature carries an explicit log-likelihood-ratio weight per class (`WEIGHTS`).
  * Context-specific overrides apply on a nodule surface versus in sediment (`CONTEXT_WEIGHTS`).
  * A context prior is added (`CONTEXT_PRIOR`).
* **Feature strength:** each feature's strength s ∈ [0, 1] comes from its SNR. Systematic floors stop a statistically significant but physically meaningless signal from counting:
  * IR: 0.02 AU;
  * fluorescence: 2 % background stability.
* **Absence is evidence:** a measured but undetected feature contributes `−ABSENCE_FACTOR × w × (1 − s)`, with `ABSENCE_FACTOR = 0.5`. This is symmetric with presence. A clean Raman spectrum with no D/G bands therefore argues *against* a carbonaceous coating, instead of being silent.
* **Missing channels contribute nothing.** Fewer channels can only widen the uncertainty, never sharpen it (tested).
* **Uncertainty:** Monte Carlo over the feature SNRs gives probability intervals for every class.
* **Every result also lists:**
  * the evidence table (value, SE, SNR, strength, contribution to each class);
  * calibration status per channel;
  * limitations ("surface-sensitive optical methods do not sample nodule interiors"; "electromagnetic and acoustic channels carry no direct carbon information");
  * quantitative refusals.

**Quantitation levels** (`core/provenance.QuantitationLevel`):

* `not_detected`
* `qualitative` (presence/class)
* `semi_quantitative` (relative index, uncalibrated scale)
* `quantitative` (validated laboratory model only)

## 4. Quantitative TOC/TIC: the only path

* **Model:** `carbon/calibration_model.CarbonCalibrationModel` is PLS regression on standardised features.
* **Validation rules:**
  * Cross-validation is **grouped by physical sample**, so replicate spectra of one sample never sit on both sides of a split.
  * Validation requires at least 20 independent samples and CV R² ≥ 0.7.
* **Prediction rules:**
  * The applicability domain is the training Mahalanobis distance, at the 99th percentile × 1.2. Predictions outside it are refused with the reason.
  * Reported values carry a 95 % interval: 1.96 × RMSECV × √(1 + leverage).
* **Current state:** no such model exists in this repository, because no laboratory data exists. Every carbon result therefore reports `quantitative = []` and the refusal "no laboratory-validated TOC/TIC model attached: concentrations are not reported".

## 5. Mapping

`carbon/mapping.carbon_layers` interpolates point results with inverse-distance weighting into map layers:

* carbonaceous-Raman probability;
* carbonate probability;
* organic-carbon probability.

Each layer comes with a confidence layer, exp(−d / 0.5 m) from the nearest measurement. Cells beyond `max_distance` are undefined. The workstation fades the map by confidence and labels it ESTIMATED.

## 6. Simulated performance and its limits

* **Results:** on the simulated survey, all 18 point targets are classified correctly (accuracy 1.0, ECE ≈ 0.06).
* **This is self-consistency, not accuracy.** The same physics generates and analyses the spectra.
* **Coverage gaps:**
  * Only five of the seven classes appear among the simulated archetypes. `organic_carbon` and `carbon_rich_inclusion` are scored but never exercised.
  * The weights are expert priors, to be re-estimated from the laboratory reference set (`models/carbon_classification/README.md`).
