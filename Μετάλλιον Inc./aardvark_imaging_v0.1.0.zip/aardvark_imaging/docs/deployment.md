# Deployment

## 1. Components

| Component | Where it runs | Notes |
|---|---|---|
| FPGA bitstream (`sf_sensor_top`) | instrument electronics (Zynq US+ reference) | not yet implemented in Vivado; see `deploy/profiles/fpga_board.md` |
| Acquisition + raw spool | vehicle computer or Zynq PS | RingReader → RawSpool; must run continuously |
| API + workstation | vessel / shore server, or the developer machine | FastAPI on port 8000; also serves `frontend/` |
| Database | PostgreSQL (production) or SQLite (dev / vehicle) | records, calibrations, audit log; **not** the raw data |
| Raw spool + exports | `AARDVARK_DATA_DIR` | the primary scientific record: back it up first |

## 2. Configuration (environment)

| Variable | Default | Meaning |
|---|---|---|
| `AARDVARK_DATA_DIR` | temporary directory | raw spool (`spool/raw_*.sfp`), exports |
| `AARDVARK_DB_URL` | unset → no SQL persistence | `sqlite:///path.db` or `postgresql+psycopg://user:pw@host:5432/db` |
| `AARDVARK_API_KEY` | unset → no authentication | required `X-API-Key` header; WebSocket takes `?api_key=` |
| `AARDVARK_CORS` | `*` | comma-separated allowed origins |
| `AARDVARK_SIM_SEED` | 21 | scene seed in simulation mode |
| `AARDVARK_FRONTEND_DIR` | `<repo>/frontend` | workstation files to serve |

## 3. Profiles (`deploy/profiles/`)

* **dev_workstation.env**
  * `pip install -e .[dev]`, then `aardvark serve`, then open http://127.0.0.1:8000.
  * Uses SQLite and no authentication. Bind to localhost only.
* **analysis_server.env**, with `docker-compose.yml`:
  * `cp .env.example .env`, edit the keys, then `docker compose up -d --build`.
  * Runs the API and workstation with PostgreSQL 16. The raw data volume is `rawdata`.
* **vessel.env**
  * The API on the ship LAN, with PostgreSQL.
  * Raw spool on redundant storage (RAID-1). The spool is append-only; a power cut costs at most the last torn record, which `aardvark spool-recover <dir>` truncates.
* **rov_auv_onboard.env**
  * Minimal: acquisition, raw spool and SQLite.
  * Size the storage from `docs/data_rate_budget.md`. At full duty the assumed configuration produces about 740 GB/hour, so area cameras must be duty-cycled.
* **fpga_board.md**
  * The integration and bring-up sequence for the FPGA.

## 4. Offline workstation

* Open `frontend/index.html` directly from disk with no server, or add `?snapshot` to the server URL.
* The workstation then loads `assets/snapshot.json` / `assets/snapshot.js`, a recorded **simulated** survey, and labels itself OFFLINE SNAPSHOT.
* Regenerate the snapshot with `aardvark snapshot --out frontend/assets/snapshot.json`.

## 5. What was actually tested

| Path | Tested? |
|---|---|
| Wheel build → clean venv install → `aardvark serve` with PostgreSQL 16 (survey persisted, audit row written, acquisition spooled 865 packets with 0 gaps, `spool-recover` verified 865 intact records, workstation served) | **yes** (local PostgreSQL 16.x, Python 3.13) |
| SQLite persistence, idempotent restart | yes (`tests/integration/test_api.py`) |
| API-key enforcement (HTTP and WebSocket) | yes |
| Workstation in Chromium, live and snapshot modes, desktop and 390 px phone width | yes (`tests/ui`, Playwright) |
| `docker build` / `docker compose up` | **no**: the build environment could not pull base images from Docker Hub (HTTP 403). The Dockerfile runs exactly the steps tested in the venv path above, but the image itself has not been built. |
| Real FPGA / UIO ring (`MmapRing`) | tested against a file-backed mmap only, not a UIO device |

## 6. Security notes

* Set `AARDVARK_API_KEY` on any shared network and restrict `AARDVARK_CORS`.
* The API key is a shared secret, not user authentication. Put a TLS-terminating reverse proxy with real identity in front of the API for multi-user deployments.
* The container runs as a non-root user (uid 10001). Only `/data` is writable.
* Laser emission is controlled by FPGA interlocks (key, arm, interlock, submerged, watchdog), not by the API. No API endpoint can enable the laser.
