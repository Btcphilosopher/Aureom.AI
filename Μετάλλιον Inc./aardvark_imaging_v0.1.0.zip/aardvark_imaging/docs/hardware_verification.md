# Hardware verification

**Result:** 25 of 25 self-checking testbenches pass under Verilator 5.020, with 91,412 checks executed. `-Wall` lint of the full RTL is clean, and 13 cross-language tests confirm that the RTL outputs match the Python reference models bit for bit.

**Not done yet:**

* vendor-tool (Vivado) synthesis;
* place-and-route and timing closure;
* gate-level simulation;
* FPGA hardware testing;
* formal verification.

## 1. How to run

```bash
python hardware/verification/simulation/run_sims.py           # all testbenches -> results.json
python hardware/verification/simulation/run_sims.py --lint    # verilator -Wall lint, top = sf_sensor_top
pytest -m hardware                                            # both, from pytest
pytest tests/hardware/test_rtl_crosscheck.py                  # RTL vectors vs Python models
```

**Simulation settings:**

* Verilator flags: `--binary --timing --assert`, with `--x-initial unique` and `+verilator+rand+reset+2`. Every flop starts at a random value, so a missing reset shows up as a failure.
* Each testbench prints a single `TB_RESULT <name> PASS|FAIL checks=<n>` line.
* Results are written to `hardware/verification/simulation/results.json`.

## 2. Testbench inventory

| Testbench | Checks | What it proves |
|---|---:|---|
| tb_sf_sync_fifo | 9,483 | randomised push/pop scoreboard, level, full/overflow, capacity |
| tb_sf_async_fifo | 21,770 | fast→slow and slow→fast instances, randomised traffic, scoreboards, drain |
| tb_sf_cdc | 6 | pulse-synchroniser event conservation both ways, level latency, reset sync |
| tb_sf_spi_master | 840 | all four SPI modes, two MISO lanes, behavioural slaves |
| tb_sf_i2c_master | 13 | addressing, auto-increment, clock stretching |
| tb_sf_adc_interface | 99 | CNV timing contract, quiet bus during conversion, mux latching, start-while-busy rejection |
| tb_sf_lvds_aligner | 6,598 | lock at every bit offset, integrity, re-lock after an injected slip |
| tb_sf_timestamp_engine | 63 | monotonic count, coherent snapshot, carry, rollover, PPS latch/count, PPS-lost, event capture |
| tb_sf_sensor_sync | 12 | period, divisors, offsets (latency OFFSET+2), overrun, PPS alignment, external sync |
| tb_sf_laser_timing | 7,488 | key arming, wrong key, delay, CW/pulsed, watchdog, interlock drop mid-emission, overtemp, max-on cap |
| tb_sf_axil_regfile | 473 | **generated from the manifest:** reset values, RW read-back, RO rejection, W1P, W1C set-priority, byte strobes, SLVERR |
| tb_sf_calibration_engine | 9,908 | random stream with stalls against an independent model; vectors dumped for the Python bit-exact check |
| tb_sf_packetizer | 7,982 | 3 sources, random lengths and back-pressure; framing, per-source order, global sequence, CRC (byte-wise reference) |
| tb_sf_dma_controller | 22,553 | randomised AXI back-pressure, byte-exact ring, packet-granular WR_PTR, packet-atomic drops, AXI error, efficiency run |
| tb_sf_row_capture | 498 | 74.25→100 MHz crossing, calibrated values, counters, timestamps, length errors, missing EOL, overflow recovery |
| tb_sf_hsi_controller | 416 | exposure timing, FVAL/LVAL readout, exposure-start timestamps, band/line indexing, overrun, test pattern |
| tb_sf_multispectral_controller | 303 | AXI4-S ingest at 150 MHz, LED round-robin with mask, strobe confined to exposure, band tag |
| tb_sf_swir_controller | 77 | TEC-lock inhibit, integration width, readout, ROIC capture at 40 MHz |
| tb_sf_raman_controller | 111 | real laser-timing and ADC blocks; dark and light co-adds exact, laser only during integration, interlock abort, not-armed timeout |
| tb_sf_ir_controller | 15 | lock-in sums exact per band (signed samples) |
| tb_sf_fluorescence_controller | 11 | exact on−off sums per excitation × emission, masked excitation |
| tb_sf_sonar_interface | 2,415 | trigger width, TX-ack timestamp, ack timeout, acoustic capture, segmentation, drop flagging |
| tb_sf_em_induction | 7 | DDS + ROM + ADC + I/Q: amplitude and phase recovery; vectors dumped |
| tb_sf_fpga_diagnostics | 15 | error counting, host-link supervision, overtemp, diagnostic and housekeeping packet layout |
| tb_sf_sensor_top | 256 | **full system:** every sensor in TEST_PATTERN mode, configured only through the generated register map, DMA into a ring model; the ring is decoded and checked |

The stream assertion modules `assertions/sf_stream_checker.sv` and `sf_axi_write_checker.sv` are bound in the stream and DMA testbenches.

## 3. Cross-language checks (`tests/hardware/test_rtl_crosscheck.py`)

| Check | What must agree |
|---|---|
| Calibration engine | `fixedpoint.calibrate_pixels` reproduces every RTL output word and flag (> 3000 vectors). |
| Packetiser | Every CRC in the dumped stream matches `zlib.crc32`, and the Python decoder parses every packet. |
| EM | `fixedpoint.em_iq_model` reproduces the RTL I/Q accumulators exactly. |
| Full-system ring dump | Decodes with zero CRC errors and zero sequence gaps. |
| HSI, MS and SWIR test patterns | Match `fixedpoint.test_pattern_frame`. |
| Raman co-adds; IR lock-in; fluorescence; sonar/acoustic; housekeeping/diagnostics | Each payload matches its Python model. |

## 4. RTL bugs found by simulation and fixed

| Module | Bug | Found by |
|---|---|---|
| sf_lvds_aligner | output valid not gated per frame word, so misaligned words leaked during re-lock | tb_sf_lvds_aligner slip injection |
| sf_hsi/ms/swir_controller | a trigger arriving mid-exposure stretched the exposure instead of counting an overrun | controller TBs |
| sf_multispectral_controller | wrong band tag (context sampled the next band); band sequence restarted from the wrong base after masking | tb_sf_multispectral_controller |
| sf_raman_controller | pixel readout not paced by ADC completion, so samples were skipped at a high pixel rate | tb_sf_raman_controller |
| sf_ir/fluorescence_controller | source switching not aligned to the sample start, so on/off windows were contaminated | lock-in TBs (exact-sum checks) |
| sf_laser_timing | `MAX_ON_HW` literal overflowed its parameter width | lint |

`VERIFICATION_LOG.md` covers testbench-side and software bugs.

## 5. SystemVerilog subset (Verilator 5.020 ∩ Yosys 0.33)

These rules are enforced because the `sv2v` converter could not be used:

* no `import pkg::*` (use `pkg::NAME`);
* no `return` in functions (assign to the function name);
* no packed 2-D or unpacked-array ports (use flattened vectors);
* no `int'()` casts;
* `parameter ROM_FILE` is untyped.

## 6. Synthesis estimate

`synthesis/yosys_xcup.log` and `utilisation_xcup.txt` come from a Yosys `synth_xilinx` run for UltraScale+:

| Resource | Count |
|---|---:|
| LUTs | ~81 k |
| flip-flops | ~16.5 k |
| DSP48E2 | 31 |
| RAMB36E2 | 74 |
| RAMB18E2 | 9 |
| RAM32M16 | 170 |

* The per-pixel calibration RAMs set the block-RAM figure.
* The generated register-file read multiplexer accounts for most of the MUXF7/F8 count; a pipelined read path would reduce it.
* This is a technology-mapping estimate. It is **not** a Vivado implementation and carries **no timing information**.
* `hardware/silica_flux/timing/sf_sensor_top.xdc` is a constraint template that has not been run through Vivado.

## 7. What remains for hardware sign-off

1. **Vivado:**
   * synthesis and implementation on the selected device;
   * timing closure against the XDC, once I/O delays are filled in from the chosen parts;
   * CDC report (`report_cdc`) review.
2. **Vendor boundaries:**
   * CSI-2 RX integration (MS0, RGB0);
   * ISERDES wrappers (HSI LVDS, acoustic ADC);
   * the PS block design and UIO driver.
3. **Formal and gate-level:**
   * formal proofs (SymbiYosys) for the FIFO, CDC, DMA admission and laser-interlock properties;
   * gate-level simulation of the post-implementation netlist.
4. **Hardware-in-the-loop:**
   * on the evaluation board with camera and ADC evaluation kits;
   * then pressure and thermal testing of the electronics housing.
