# Repository inspection (Phase 1)

The brief asked for the existing Μετάλλιον Inc. repository, and any Silica Flux definitions in it, to be inspected before anything was built. This file records what was found.

## What was available

| Item | Finding |
|---|---|
| Uploaded files | None. The session's uploads directory was empty. |
| Linked repository | None was attached or linked in the session. |
| GitHub access | The GitHub CLI was present, but its token was invalid, so no organisation repositories could be listed or cloned. |
| Local checkout | No Μετάλλιον source tree existed on the build machine. |
| Silica Flux sources | None available. The user's earlier *SilicaFlux* project (a custom 32-bit ISA compute architecture) was not accessible in this session, so none of its syntax or tooling could be reused. |

## Consequences

* **No invented Silica Flux syntax.** The brief says not to invent Silica Flux syntax when no definition is available. Silica Flux is therefore defined here as a hardware *architecture and methodology layer*:
  * a machine-readable TOML manifest is the single source of truth;
  * a validator and code generator produce the SystemVerilog register package and AXI4-Lite register file, the Python and C register maps, the Markdown documentation and the register-file testbench.
* **The hardware is plain SystemVerilog.** See `docs/silica_flux.md` and `hardware/silica_flux/architecture/README.md`.
* **The subsystem is self-contained.** It was created at `metallion/aardvark_imaging/`, following the brief's proposed layout. When the real Μετάλλιον repository becomes available, the directory can be moved into it as a subsystem. Two things need adapting:
  * its `pyproject.toml` package mapping;
  * its CI.
  No path inside the subsystem depends on anything outside it.
* **Integration points to check against the real repository:**
  * naming conventions;
  * an existing hardware abstraction (if one exists, the manifest schema should be mapped onto it rather than kept in parallel);
  * any existing data schemas;
  * the existing CI and licence headers.
* **If the earlier SilicaFlux ISA is meant to run on the instrument's FPGA,** for example as a soft-core sequencer, the manifest has room for it. Add it as a `[[compute]]` section and give it an AXI4-Lite master port on the register bus. This has not been done because its definition was not available.

## Toolchain found or installed

| Tool | Version | Use |
|---|---|---|
| Python | 3.13 | backend (the package targets ≥ 3.12) |
| Verilator | 5.020 | lint and simulation of all RTL and testbenches |
| Yosys | 0.33 | generic and Xilinx-family synthesis estimate (not timing closure) |
| Icarus Verilog | 12.0 | installed but not used: its SystemVerilog support is too limited for the RTL |
| Chromium + Playwright | 1.63 | workstation UI tests |

The `sv2v` converter was not downloaded, because the session's security policy blocked it. The RTL was written in the SystemVerilog subset that both Verilator and Yosys 0.33 accept. `docs/hardware_verification.md` lists the rules.
