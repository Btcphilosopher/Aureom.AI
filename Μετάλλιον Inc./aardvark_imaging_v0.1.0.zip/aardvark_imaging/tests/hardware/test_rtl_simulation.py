"""Runs the SystemVerilog testbenches under Verilator (marker: hardware).

    pytest -m hardware                 # lint + all testbenches (~several minutes)

Skips when Verilator is not installed. The cross-check tests in
test_rtl_crosscheck.py then compare the vectors these simulations write
against the Python reference models.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
RUNNER = ROOT / "hardware" / "verification" / "simulation" / "run_sims.py"

pytestmark = [pytest.mark.hardware, pytest.mark.skipif(shutil.which("verilator") is None, reason="Verilator not installed")]


def test_rtl_lint_clean():
    r = subprocess.run([sys.executable, str(RUNNER), "--lint"], capture_output=True, text=True, timeout=600)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]


def test_all_testbenches_pass(tmp_path):
    out = tmp_path / "results.json"
    r = subprocess.run([sys.executable, str(RUNNER), "--json", str(out)], capture_output=True, text=True, timeout=3600)
    res = json.loads(out.read_text())
    failed = [t["name"] for t in res["results"] if t["status"] != "PASS"]
    assert r.returncode == 0 and not failed and res["total"] >= 25, (failed, r.stdout[-4000:])
