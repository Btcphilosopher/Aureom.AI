"""Cross-language verification: RTL simulation outputs vs Python reference models.

The SystemVerilog testbenches write their stimulus/response to
``hardware/verification/vectors``. These tests require the Python models and
the Python SFP1 decoder to reproduce them exactly. Run the simulations first
(``tests/hardware/test_rtl_simulation.py`` or ``run_sims.py``); tests skip if
the vectors are absent.
"""
from __future__ import annotations

import re
from collections import defaultdict
from pathlib import Path

import numpy as np
import pytest

from aardvark_imaging.acquisition import fixedpoint as fp
from aardvark_imaging.acquisition import sfp

ROOT = Path(__file__).resolve().parents[2]
VEC = ROOT / "hardware" / "verification" / "vectors"


def need(name: str) -> Path:
    p = VEC / name
    if not p.exists():
        pytest.skip(f"{name} not generated (run the RTL simulations)")
    return p


def test_calibration_engine_bit_exact():
    rows = [list(map(int, ln.split())) for ln in need("calibration_engine_vectors.txt").read_text().splitlines()
            if ln and not ln.startswith("#")]
    a = np.array(rows, dtype=np.int64)
    raw, dark, gain, bad, oob, en, sat = (a[:, i] for i in range(7))
    out, s, b, c, k = fp.calibrate_pixels(raw, dark, gain, bad, oob.astype(bool), en.astype(bool), sat)
    assert a.shape[0] > 3000
    np.testing.assert_array_equal(out, a[:, 7])
    np.testing.assert_array_equal(s.astype(int), a[:, 8])
    np.testing.assert_array_equal(b.astype(int), a[:, 9])
    np.testing.assert_array_equal(c.astype(int), a[:, 10])
    np.testing.assert_array_equal(k.astype(int), a[:, 11])
    # the vectors exercise every branch
    assert a[:, 8].any() and a[:, 9].any() and a[:, 10].any() and (a[:, 4] == 1).any()


def test_packetizer_stream_crc_with_zlib():
    words = np.array([int(x, 16) for x in need("packetizer_stream.hex").read_text().split()], dtype=np.uint32)
    res = sfp.decode_words(words)
    assert not res.errors
    assert len(res.packets) == 180
    assert all(p.crc_ok for p in res.packets)
    assert [p.seq for p in res.packets] == list(range(180))
    assert {p.sensor_uid for p in res.packets} == {0x11, 0x22, 0x33}
    assert any(p.simulated for p in res.packets) and not all(p.simulated for p in res.packets)


def test_em_iq_accumulators_bit_exact():
    text = need("em_iq_vectors.txt").read_text().splitlines()
    ftw = int(re.search(r"FTW (\d+)", text[0]).group(1))
    s = np.array([list(map(int, ln.split()[1:])) for ln in text if ln.startswith("S ")], dtype=np.int64)
    r = [int(x) for x in next(ln for ln in text if ln.startswith("R ")).split()[1:]]
    model = fp.em_iq_model(s[:, 0], s[:, 1], s[:, 2], ftw)
    assert tuple(r[:4]) == model
    assert r[4] == len(s)
    amp, ph = fp.iq_to_amplitude_phase(r[0], r[1], r[4])
    assert abs(amp - 9000) / 9000 < 2e-3
    assert abs(ph - (37.0 + fp.ROM_PHASE_BIAS_DEG)) < 0.05


# --------------------------------------------------------------------------- system
@pytest.fixture(scope="module")
def top():
    words = np.array([int(x, 16) for x in need("top_ring.hex").read_text().split()], dtype=np.uint32)
    regs = dict(ln.split() for ln in need("top_registers.txt").read_text().splitlines() if ln.strip())
    regs = {k: int(v) for k, v in regs.items()}
    res = sfp.decode_words(words)
    by = defaultdict(list)
    for p in res.packets:
        by[p.type_name].append(p)
    return res, regs, by


def test_top_ring_integrity(top):
    res, regs, _ = top
    assert not res.errors
    assert len(res.packets) == regs["PKT_COUNT"]
    assert regs["DROP_COUNT"] == 0
    assert [p.seq for p in res.packets] == list(range(len(res.packets)))
    assert all(p.simulated for p in res.packets), "TEST_PATTERN data must be flagged SIMULATED"


def test_top_timestamps_monotonic_per_sensor(top):
    _, _, by = top
    for name, pk in by.items():
        ts = [p.timestamp for p in pk]
        assert ts == sorted(ts), name


def test_top_hsi_rows_calibrated_bit_exact(top):
    _, regs, by = top
    rows = by["HSI_ROW"]
    assert len(rows) == 3 * regs["HSI_FRAMES"]
    idx = np.arange(24)
    dark = idx.copy()
    gain = 16384 + idx * 256
    bad = idx == 5
    for p in rows:
        pat = fp.test_pattern_frame(p.frame, 3, 8)[p.row]
        i = p.row * 8 + np.arange(8)
        exp, *_ = fp.calibrate_pixels(pat, dark[i], gain[i], bad[i], np.zeros(8, bool), True, 0x0FFF)
        got, sat, badm = sfp.unpack_pixels(p.payload, 8)
        np.testing.assert_array_equal(got.data, exp)
        assert p.has("CALIBRATED") and p.has("SIMULATED")
        assert p.has("SATURATED") == bool(sat.any()) and p.has("BAD_PIXEL") == bool(badm.any())
    # all three rows of a push-broom line share the exposure-start timestamp
    by_line = defaultdict(set)
    for p in rows:
        by_line[p.frame].add(p.timestamp)
    assert all(len(v) == 1 for v in by_line.values())


def test_top_multispectral_band_sequence_and_data(top):
    _, regs, by = top
    rows = by["MS_ROW"]
    assert len(rows) == 2 * regs["MS_FRAMES"]
    for p in rows:
        meta = sfp.imager_meta(p.meta)
        assert meta["band"] == p.frame % 3, "LED bands cycle 0,1,2 from the first frame"
        pat = fp.test_pattern_frame(p.frame, 2, 6)[p.row]
        exp, *_ = fp.calibrate_pixels(pat, np.full(6, 10), np.full(6, 16384), np.zeros(6, bool),
                                      np.zeros(6, bool), True, 0x0FFF)
        got, *_ = sfp.unpack_pixels(p.payload, 6)
        np.testing.assert_array_equal(got.data, exp)


def test_top_swir_bypass_raw(top):
    _, _, by = top
    for p in by["SWIR_ROW"]:
        got, *_ = sfp.unpack_pixels(p.payload, 4)
        np.testing.assert_array_equal(got.data, fp.test_pattern_frame(p.frame, 2, 4)[p.row])
        assert not p.has("CALIBRATED")


def test_top_raman_coadd_sums(top):
    _, regs, by = top
    spec = by["RAMAN_SPECTRUM"]
    assert len(spec) == regs["RAMAN_SPECTRA"] >= 1
    npix, coadd = 32, 2
    for j, p in enumerate(spec):
        d = sfp.raman_payload(p)
        assert d["coadd"] == coadd and d["npix"] == npix and d["laser_on"] and not d["dark"]
        k0 = j * coadd * npix
        exp = sum(fp.adc_test_code(k0 + c * npix + np.arange(npix), 0, 16, 500) for c in range(coadd))
        np.testing.assert_array_equal(d["counts"], exp)
    assert any(sfp.laser_event_payload(p)["emit_start"] for p in by["LASER_EVENT"])


def test_top_ir_lockin_model(top):
    _, regs, by = top
    sweeps = by["IR_SWEEP"]
    assert len(sweeps) == regs["IR_SWEEPS"] >= 2
    nb, hp, npp, settle = 2, 4, 2, 1
    per_band = 2 * hp * npp
    for j, p in enumerate(sweeps):
        d = sfp.ir_payload(p)
        for b in range(nb):
            on = off = 0
            for per in range(npp):
                for half in range(2):
                    for si in range(hp):
                        k = j * nb * per_band + b * per_band + per * 2 * hp + half * hp + si
                        v = int(fp.to_signed(fp.adc_test_code(k, 0, 18, 7), 18))
                        if si >= settle:
                            if half == 0:
                                on += v
                            else:
                                off += v
            assert d["demod"][b] == on - off and d["total"][b] == on + off


def test_top_fluorescence_model(top):
    _, regs, by = top
    blocks = by["FLUOR_BLOCK"]
    assert len(blocks) == regs["FL_COUNT"] >= 1
    on_s, blank, npul = 4, 1, 2
    per_exc = npul * 2 * on_s
    for j, p in enumerate(blocks):
        d = sfp.fluor_payload(p)
        for e in range(3):
            for lane in range(3):
                on = off = 0
                for per in range(npul):
                    for half in range(2):
                        for si in range(on_s):
                            k = j * 3 * per_exc + e * per_exc + per * 2 * on_s + half * on_s + si
                            v = int(fp.adc_test_code(k, lane, 16, 64))
                            if si >= blank:
                                on, off = (on + v, off) if half == 0 else (on, off + v)
                assert d["diff"][e, lane] == on - off and d["off"][e, lane] == off


def test_top_sonar_and_acoustic(top):
    _, regs, by = top
    pings = by["SONAR_PING"]
    assert len(pings) == regs["SONAR_PINGS"]
    for p in pings:
        d = sfp.sonar_ping_payload(p)
        assert d["ack_ok"] and 90 <= d["ack_ts"] - d["trigger_ts"] <= 140
    segs = defaultdict(list)
    for p in by["ACOUSTIC_SAMPLES"]:
        segs[p.frame].append(sfp.acoustic_payload(p))
    for ping, ss in segs.items():
        assert [s["segment"] for s in ss] == [0, 1]
        x = np.concatenate([s["samples"] for s in ss])
        assert x.shape == (64, 8)
        ch0 = x[:, 0].astype(np.int64) % (1 << 14)
        assert np.all(np.diff(ch0) % (1 << 14) == 1), "consecutive array samples"
        for c in range(8):
            exp = fp.to_signed((ch0 * (c + 1)) % (1 << 14), 14)
            np.testing.assert_array_equal(x[:, c], exp)


def test_top_housekeeping_and_diagnostics(top):
    _, _, by = top
    for p in by["HOUSEKEEPING"]:
        s = p.frame
        codes = [int(c) for c in sfp.hk_payload(p).values()]
        assert codes == [int(fp.adc_test_code(4 * s + i, 0, 16, 20000)) for i in range(4)]
    diags = [sfp.diag_payload(p) for p in by["DIAGNOSTIC"]]
    assert diags and all(d["err_total"] == 0 for d in diags)
    up = [d["uptime_cycles"] for d in diags]
    assert up == sorted(up)
    for p in by["EM_IQ"]:
        d = sfp.em_payload(p)
        assert d["n"] == 64 and d["ftw"] == 134217728
