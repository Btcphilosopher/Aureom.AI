"""SFP1 packet codec, fixed-point reference models, ring buffer, raw spool, timebase."""
from __future__ import annotations

import os
import zlib

import numpy as np
import pytest

from aardvark_imaging.acquisition import fixedpoint as fp
from aardvark_imaging.acquisition import sfp
from aardvark_imaging.acquisition.ring import ArrayRing, MmapRing, RingReader
from aardvark_imaging.acquisition.spool import RawSpool, iter_segment, iter_spool, recover_segment
from aardvark_imaging.acquisition.timebase import fit_timebase


def pkt(seq, n=16, uid=0x10, ptype=1, flags=0, payload=None):
    p = np.arange(n, dtype=np.uint32) * 7 + seq if payload is None else payload
    return sfp.encode_packet(sensor_uid=uid, packet_type=ptype, flags=flags, seq=seq, frame=seq // 4, timestamp=1000 + seq,
                             row=seq % 4, meta=0, payload=p)


# ------------------------------------------------------------------ fixed point
class TestFixedPoint:
    def test_crc_matches_zlib_little_endian(self, rng):
        w = rng.integers(0, 2**32, 50, dtype=np.uint64).astype(np.uint32)
        assert fp.crc32_words(w) == zlib.crc32(w.astype("<u4").tobytes()) & 0xFFFFFFFF

    def test_gain_quantisation_u2_14(self):
        g = fp.gain_to_u2_14(np.array([0.0, 1.0, 1.5, 3.99993896484375]))
        assert list(g) == [0, 16384, 24576, 65535]
        with pytest.raises(ValueError):
            fp.gain_to_u2_14(np.array([4.5]))      # refused, never silently wrapped

    def test_calibration_formula_and_sentinels(self):
        raw = np.array([100, 50, 4095, 3001, 200])
        dark = np.array([40, 60, 0, 0, 0])
        gain = fp.gain_to_u2_14(np.array([1.0, 1.0, 1.0, 1.25, 1.0]))
        bad = np.array([0, 0, 0, 0, 1], bool)
        oob = np.zeros(5, bool)
        out, sat, isbad, clipped, _ = fp.calibrate_pixels(raw, dark, gain, bad, oob, np.ones(5, bool), 4095)
        assert out[0] == 60                      # (100-40) * 1.0
        assert out[1] == 0                       # negative clamps to zero, never wraps
        assert out[2] == 0xFFFF and sat[2]       # saturated input -> sentinel
        assert out[3] == 3751                    # 3001 * 1.25 = 3751.25, round half up
        assert out[4] == 0xFFFE and isbad[4]     # bad pixel sentinel

    def test_saturation_flagged_even_in_bypass(self):
        out, sat, *_ = fp.calibrate_pixels(np.array([4095, 10]), np.zeros(2), np.full(2, 16384), np.zeros(2, bool),
                                           np.zeros(2, bool), np.zeros(2, bool), 4095)
        assert out[0] == 0xFFFF and sat[0] and out[1] == 10

    def test_iq_amplitude_phase_recovers_tone(self):
        # receiver tone A*sin(theta + phi): I = sum(rx*sin), Q = sum(rx*cos) -> amplitude A, phase phi
        n, ftw, A, phi = 25000, 85899346, 1000.0, 0.4
        ph = (np.arange(n, dtype=np.uint64) * np.uint64(ftw)) & np.uint64(0xFFFFFFFF)
        s, c = (np.asarray(x, float) for x in fp.dds_lookup(ph))
        rx = np.round(A * (s * np.cos(phi) + c * np.sin(phi)) / 32767.0).astype(int)
        i, q, _, _ = fp.em_iq_model(np.arange(n), rx, np.zeros(n, int), ftw)
        amp, phase = fp.iq_to_amplitude_phase(i, q, n)
        assert amp == pytest.approx(A, rel=2e-3)
        assert np.deg2rad(phase) == pytest.approx(phi, abs=2e-3)


# ------------------------------------------------------------------ packet codec
class TestSfp:
    def test_roundtrip(self):
        w = pkt(5, flags=sfp.flags_value("SIMULATED", "CALIBRATED"))
        r = sfp.decode_words(w)
        assert not r.errors and len(r.packets) == 1
        p = r.packets[0]
        assert (p.seq, p.frame, p.row, p.timestamp) == (5, 1, 1, 1005)
        assert p.simulated and p.flags & (1 << 3)
        np.testing.assert_array_equal(p.payload, np.arange(16, dtype=np.uint32) * 7 + 5)

    def test_crc_corruption_detected(self):
        w = pkt(1).copy()
        w[10] ^= 1
        r = sfp.decode_words(w)
        assert not r.packets and any(e.kind == "crc" for e in r.errors)

    def test_resync_after_garbage_and_truncation(self):
        garbage = np.array([0xDEADBEEF, 0x53465031, 0x12345678], dtype=np.uint32)   # includes a false SYNC
        stream = np.concatenate([garbage, pkt(1), pkt(2), pkt(3)[:-3]])
        r = sfp.decode_words(stream)
        assert [p.seq for p in r.packets] == [1, 2]
        assert r.errors   # the false sync and the truncated tail are reported, not silently dropped

    def test_sequence_gaps(self):
        r = sfp.decode_words(np.concatenate([pkt(1), pkt(2), pkt(5)]))
        assert r.sequence_gaps() == [(3, 5)] or r.sequence_gaps() == [(3, 4)] or len(r.sequence_gaps()) == 1

    def test_pixel_pack_sentinels(self):
        px = np.array([0, 1, 0xFFFD, 0xFFFE, 0xFFFF, 123], dtype=np.uint16)
        payload = sfp.pack_pixels(px)
        vals, sat, bad = sfp.unpack_pixels(payload, px.size)
        assert sat.tolist() == [False, False, False, False, True, False]
        assert bad.tolist() == [False, False, False, True, False, False]
        assert vals.mask.tolist() == [False, False, False, True, True, False]
        assert int(vals[2]) == 0xFFFD and int(vals[5]) == 123

    def test_imager_meta(self):
        m = sfp.imager_meta((1 << 31) | (7 << 16) | 160)
        assert m["band"] == 7 and m["pixel_count"] == 160


# ------------------------------------------------------------------ ring buffer
class TestRing:
    def test_wraparound_and_order(self):
        ring = ArrayRing(1024)
        rd = RingReader(ring)
        got = []
        for s in range(40):
            assert ring.write_packet(pkt(s), rd.rd_ptr)
            got += [p.seq for p in rd.poll(ring.wr_ptr)]
        assert got == list(range(40)) and not rd.gaps

    def test_packet_atomic_admission_and_gap_report(self):
        ring = ArrayRing(512)
        rd = RingReader(ring)
        accepted = [s for s in range(10) if ring.write_packet(pkt(s), rd.rd_ptr)]
        assert 0 < len(accepted) < 10          # host not reading: ring fills, whole packets refused
        rd.poll(ring.wr_ptr)
        ring.write_packet(pkt(20), rd.rd_ptr)  # FPGA seq continues after drops
        rd.poll(ring.wr_ptr)
        assert rd.gaps and rd.dropped_packets == 20 - (accepted[-1] + 1)

    def test_rejects_non_power_of_two(self):
        with pytest.raises(ValueError):
            ArrayRing(1000)

    def test_mmap_ring_reads_file_backed_buffer(self, tmp_path):
        ring = ArrayRing(1024)
        rd0 = RingReader(ring)
        for s in range(3):
            ring.write_packet(pkt(s), rd0.rd_ptr)
        f = tmp_path / "ring.bin"
        f.write_bytes(ring.mem.astype("<u4").tobytes())
        mm = MmapRing(str(f), 1024)
        rd = RingReader(mm)
        assert [p.seq for p in rd.poll(ring.wr_ptr)] == [0, 1, 2]


# ------------------------------------------------------------------ raw spool
class TestSpool:
    def test_write_read_and_segment_rollover(self, tmp_path):
        with RawSpool(tmp_path, segment_bytes=4096, metadata={"survey": "T"}) as sp:
            for s in range(60):
                sp.write(pkt(s), host_time=float(s))
        recs = list(iter_spool(tmp_path))
        assert len(recs) == 60 and len(list(tmp_path.glob("raw_*.sfp"))) > 1
        words = np.concatenate([w for _, w in recs])
        assert [p.seq for p in sfp.decode_words(words).packets] == list(range(60))

    def test_torn_record_recovery(self, tmp_path):
        with RawSpool(tmp_path) as sp:
            for s in range(5):
                sp.write(pkt(s))
        seg = sorted(tmp_path.glob("raw_*.sfp"))[0]
        size = seg.stat().st_size
        with open(seg, "r+b") as fh:          # simulate power loss mid-record
            fh.truncate(size - 9)
        assert recover_segment(seg) == 4
        assert len(list(iter_segment(seg))) == 4

    def test_raw_bytes_are_unmodified(self, tmp_path):
        w = pkt(9)
        with RawSpool(tmp_path) as sp:
            sp.write(w)
        (_, back), = list(iter_spool(tmp_path))
        np.testing.assert_array_equal(back, w)


def test_timebase_fit_recovers_clock_error():
    true_hz = 100e6 * (1 + 12e-6)
    utc = np.arange(30) + 1.7e9
    ticks = np.round((utc - utc[0]) * true_hz + 12345).astype(np.int64)
    tb = fit_timebase(ticks, utc)
    assert abs(tb.hz - true_hz) < 1.0
    assert tb.n_pps == 30 and tb.residual_std_s < 1e-7
    assert not os.environ.get("NEVER")
