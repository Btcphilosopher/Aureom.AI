"""Calibration registry policy, radiometric/wavelength/Raman-axis fits, optical environment."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import numpy as np
import pytest

from aardvark_imaging.calibration import environment as env
from aardvark_imaging.calibration import radiometric as rad
from aardvark_imaging.calibration import raman_shift as rs
from aardvark_imaging.calibration import wavelength as wcal
from aardvark_imaging.calibration.models import (CalibrationKind, CalibrationLevel, CalibrationRecord,
                                                 CalibrationStatus)
from aardvark_imaging.calibration.registry import CalibrationRegistry
from aardvark_imaging.core.provenance import DataOrigin

NOW = datetime(2026, 6, 1, tzinfo=timezone.utc)


def rec(cid, version, start, days, origin=DataOrigin.MEASURED, level=CalibrationLevel.FIELD):
    return CalibrationRecord(calibration_id=cid, sensor_key="HSI0", kind=CalibrationKind.DARK, level=level, version=version,
                             valid_from=start, expires=start + timedelta(days=days), method="test", origin=origin)


class TestRegistry:
    def test_applicable_picks_highest_valid_version(self):
        r = CalibrationRegistry()
        r.add(rec("a", 1, NOW - timedelta(days=30), 60))
        r.add(rec("b", 2, NOW - timedelta(days=1), 60))
        assert r.applicable("HSI0", CalibrationKind.DARK, NOW).calibration_id == "b"
        assert r.applicable("HSI0", CalibrationKind.DARK, NOW - timedelta(days=10)).calibration_id == "a"

    def test_status_expired_missing_expiring_simulated(self):
        r = CalibrationRegistry()
        assert r.status("HSI0", CalibrationKind.DARK, NOW) == CalibrationStatus.MISSING
        r.add(rec("a", 1, NOW - timedelta(days=30), 20))
        assert r.status("HSI0", CalibrationKind.DARK, NOW) == CalibrationStatus.EXPIRED
        r.add(rec("b", 2, NOW - timedelta(days=1), 10))
        assert r.status("HSI0", CalibrationKind.DARK, NOW) == CalibrationStatus.EXPIRING
        r.add(rec("c", 3, NOW - timedelta(days=1), 100, origin=DataOrigin.SIMULATED))
        assert r.status("HSI0", CalibrationKind.DARK, NOW) == CalibrationStatus.SIMULATED

    def test_records_are_immutable_and_versions_monotonic(self):
        r = CalibrationRegistry()
        r.add(rec("a", 2, NOW, 10))
        with pytest.raises(ValueError):
            r.add(rec("a", 3, NOW, 10))
        with pytest.raises(ValueError):
            r.add(rec("x", 1, NOW, 10))
        with pytest.raises(Exception):
            r.get("a").version = 9   # frozen model

    def test_measured_factory_calibration_requires_certificate(self):
        with pytest.raises(ValueError):
            rec("f", 1, NOW, 10, level=CalibrationLevel.FACTORY)

    def test_summary_flags_unsupported_kinds(self):
        s = CalibrationRegistry().summary({"HSI0": ["dark", "no_such_kind"]}, NOW)
        assert s == {"HSI0": {"dark": "missing", "no_such_kind": "unsupported_kind"}}


class TestRadiometric:
    def test_dark_flat_and_bad_pixels(self, rng):
        H, W = 20, 30
        offset = 100 + rng.normal(0, 2, (H, W)); offset[3, 4] = 400          # hot pixel
        prnu = 1 + rng.normal(0, 0.03, (H, W)); prnu[10, 10] = 0.2             # dead-ish pixel
        darks = offset + rng.normal(0, 1.5, (16, H, W))
        flats = offset + 2000 * prnu + rng.normal(0, 5, (16, H, W))
        d = rad.dark_reference(darks)
        g = rad.flat_field_gain(flats, d)
        corrected = (flats.mean(0) - d.mean) * g
        good = np.ones((H, W), bool); good[10, 10] = False
        assert corrected[good].std() / corrected[good].mean() < 0.005     # PRNU removed
        bad = rad.detect_bad_pixels(d, g)
        assert bad[3, 4] and bad[10, 10] and bad.sum() <= 4

    def test_dark_needs_a_stack(self):
        with pytest.raises(ValueError):
            rad.dark_reference(np.zeros((1, 4, 4)))

    def test_linearity_correction(self):
        t = np.linspace(0.001, 0.1, 25)
        ideal = 40000 * t + 50
        measured = ideal - 1.2e-5 * (ideal - 50) ** 2 * (ideal > 0)            # compressive non-linearity
        lm = rad.fit_linearity(t, measured)
        assert lm.residual_rms < 0.01 * ideal.max()

    def test_dark_temperature_scaling(self):
        assert rad.dark_current_scale(17.0, 10.0) == pytest.approx(2.0)


class TestWavelength:
    def test_hg_ar_line_calibration(self):
        px = np.arange(1024, dtype=float)
        true = np.array([1.2e-9, -2.0e-5, 0.62, 380.0])            # cubic pixel->nm
        lam = np.polyval(true, px)
        spec = np.zeros_like(px)
        for ln in wcal.HG_AR_LINES_NM:
            if lam[0] < ln < lam[-1]:
                spec += 1000 * np.exp(-0.5 * ((lam - ln) / 0.9) ** 2)
        # design-model starting point: 1 nm offset and no cubic term
        cal = wcal.calibrate_from_lines(spec + 5, [0, -2.0e-5, 0.62, 381.0], prominence=100)
        assert cal.rms_nm < 0.05 and cal.n_lines >= 8
        assert np.max(np.abs(np.polyval(cal.coeffs, px) - lam)) < 0.15


class TestRamanAxis:
    def test_shift_wavelength_roundtrip(self):
        s = np.array([100.0, 1086.0, 1590.0, 3400.0])
        np.testing.assert_allclose(rs.nm_to_shift(rs.shift_to_nm(s, 532.0), 532.0), s, atol=1e-9)
        assert rs.shift_to_nm(1086.0, 532.0) == pytest.approx(564.6, abs=0.1)   # calcite nu1 under 532 nm

    def test_axis_calibration_with_cyclohexane(self):
        cyclohexane = np.array([801.3, 1028.3, 1266.4, 1444.4, 2852.9, 2938.3])
        px_true = np.polyval([-2.0e-5, 0.0, 0.0], 0) + np.array([120.0, 210.0, 300.0, 365.0, 860.0, 888.0])
        cal = rs.calibrate_axis(px_true, cyclohexane, 532.0, degree=2)
        assert cal.rms_cm1 < 15


class TestEnvironment:
    def test_seawater_index_published_value(self):
        # Quan & Fry: n ~ 1.3395 at 589 nm, 20 C, 35 psu (Austin & Halikas 1976 tables 1.3394)
        assert float(env.seawater_index(589.3, 20.0, 35.0)) == pytest.approx(1.3394, abs=4e-4)

    def test_index_rises_with_pressure_at_depth(self):
        n0 = float(env.seawater_index(550.0, 2.0, 35.0, 0.1))
        n_deep = float(env.seawater_index(550.0, 2.0, 35.0, env.pressure_mpa_from_depth(4500)))
        assert 0.006 < n_deep - n0 < 0.009             # ~1.6e-4 per MPa x ~45 MPa

    def test_sapphire_and_window(self):
        assert float(env.sapphire_index(589.3)) == pytest.approx(1.768, abs=0.002)
        t = env.window_transmission(np.array([450.0, 550.0, 650.0]))
        assert np.all((t > 0.88) & (t < 0.95))
        assert env.flat_port_fov_ratio(550.0) == pytest.approx(1 / 1.34, rel=0.01)
