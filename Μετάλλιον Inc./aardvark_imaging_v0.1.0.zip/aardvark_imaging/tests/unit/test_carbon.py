"""Carbon characterisation: Raman D/G fitting, carbonate identification, evidence
engine, refusal to quantify without a validated laboratory model."""
from __future__ import annotations

import numpy as np
import pytest

from aardvark_imaging.carbon.calibration_model import CarbonCalibrationModel
from aardvark_imaging.carbon.engine import CarbonCharacterisationEngine, CarbonTarget
from aardvark_imaging.carbon.mapping import idw_layer
from aardvark_imaging.carbon.raman_carbon import fit_carbonaceous, identify_carbonate
from aardvark_imaging.core.provenance import DataOrigin, QuantitationLevel
from aardvark_imaging.simulation.point_sensors import (TargetTruth, raman_axis, simulate_fluorescence, simulate_ir,
                                                       simulate_raman)
from aardvark_imaging.spectral.fluorescence import net_fluorescence
from aardvark_imaging.spectral.infrared import analyse_ir, ir_absorbance
from aardvark_imaging.spectral.raman import assign_bands, process_raman

SHIFT, _ = raman_axis(1024)

ARCHETYPES = {
    "carbonaceous_coating": TargetTruth("T", "nodule_surface", {"todorokite": 0.5, "vernadite": 0.4, "goethite": 0.1},
                                        0.6, 0.1, 0.0, 0.0, 0.05, 0.8, 0.0, "carbonaceous_coating"),
    "carbonate": TargetTruth("T", "nodule_surface", {"calcite": 0.6, "vernadite": 0.4}, 0, 0, 0, 0, 0, 0.05, 6.0, "carbonate"),
    "background_matrix": TargetTruth("T", "nodule_surface", {"vernadite": 0.6, "todorokite": 0.3, "goethite": 0.1},
                                     0, 0, 0, 0, 0, 0.02, 0, "background_matrix"),
    "biological": TargetTruth("T", "sediment", {"quartz": 0.5}, 0.0, 0.3, 0.9, 0.6, 0.2, 0.9, 0.1, "biological"),
}


def measure(tt, seed=3, channels=("raman", "ir", "fl")):
    rng = np.random.default_rng(seed)
    pr = ir = fl = None
    if "raman" in channels:
        L, D = simulate_raman(tt, SHIFT, rng=rng)
        pr = process_raman(L, D, SHIFT)
    if "ir" in channels:
        Ii, I0, Aw, nz = simulate_ir(tt, rng=rng)
        A, se = ir_absorbance(Ii, I0, demod_noise=nz)
        ir = analyse_ir(A, se, Aw)
    if "fl" in channels:
        d, o, n, k = simulate_fluorescence(tt, rng=rng)
        fl = net_fluorescence(d, o, npulses=n, kept_per_window=k)
    return CarbonTarget("T", tt.context, pr, ir, fl, {"RAM0": "simulated"}, DataOrigin.SIMULATED)


class TestRamanCarbon:
    def test_dg_fit_on_coating(self):
        pr = measure(ARCHETYPES["carbonaceous_coating"], channels=("raman",)).raman
        r = fit_carbonaceous(pr)
        assert r.detected
        assert 1320 <= r.d1_center <= 1385 and 1570 <= r.g_center <= 1605
        assert 0.5 < r.r1_height_ratio < 2.0
        assert "not" in r.note.lower() or "structur" in r.note.lower()   # D/G is structure, not concentration

    def test_water_bend_is_not_taken_as_g_band(self):
        # bare Mn-oxide surface in seawater: the 1640 cm-1 water bend must not become a "G band"
        for seed in range(4):
            pr = measure(ARCHETYPES["background_matrix"], seed=seed, channels=("raman",)).raman
            assert not fit_carbonaceous(pr).detected

    def test_calcite_identified_from_nu1(self):
        pr = measure(ARCHETYPES["carbonate"], channels=("raman",)).raman
        c = identify_carbonate(assign_bands(pr))
        assert c.detected and c.nu1_center == pytest.approx(1086, abs=4)
        top = max(c.mineral_probabilities, key=c.mineral_probabilities.get)
        assert top in ("calcite", "aragonite")    # 1085-1086 cm-1 cannot separate CaCO3 polymorphs alone


class TestEngine:
    @pytest.mark.parametrize("cls", list(ARCHETYPES))
    def test_archetypes_classified(self, cls):
        res = CarbonCharacterisationEngine(n_mc=100).analyse(measure(ARCHETYPES[cls]))
        assert res.top_class == cls
        lo, hi = res.probability_intervals[cls]
        assert lo <= res.class_probabilities[cls] <= hi

    def test_never_quantifies_without_validated_model(self):
        res = CarbonCharacterisationEngine(n_mc=50).analyse(measure(ARCHETYPES["carbonaceous_coating"]))
        assert res.quantitative == []
        assert res.quantitation_level in (QuantitationLevel.QUALITATIVE, QuantitationLevel.SEMI_QUANTITATIVE)
        assert any("not reported" in r for r in res.quantitative_refusals)
        assert any("electromagnetic" in lim for lim in res.limitations)

    def test_missing_channels_reduce_not_inflate_confidence(self):
        full = CarbonCharacterisationEngine(n_mc=50).analyse(measure(ARCHETYPES["carbonate"]))
        raman_only = CarbonCharacterisationEngine(n_mc=50).analyse(measure(ARCHETYPES["carbonate"], channels=("raman",)))
        assert raman_only.top_class == "carbonate"
        assert raman_only.top_probability <= full.top_probability + 0.05

    def test_no_measurements_is_not_detected(self):
        res = CarbonCharacterisationEngine(n_mc=20).analyse(CarbonTarget("empty", "sediment"))
        assert res.quantitation_level == QuantitationLevel.NOT_DETECTED or res.top_probability < 0.5


class TestCalibrationModel:
    def test_refuses_with_too_few_independent_samples(self, rng):
        X = rng.normal(size=(30, 3)); y = X @ [1.0, 0.5, 0.0] + rng.normal(0, 0.05, 30)
        m = CarbonCalibrationModel("TOC_wt_pct", ["a", "b", "c"]).fit(X, y, groups=np.repeat(np.arange(6), 5))
        assert not m.validated and any("independent" in r for r in m.reasons)
        v, why = m.predict(X[0])
        assert v is None and "not validated" in why

    def test_validated_model_predicts_with_interval_and_domain_check(self, rng):
        X = rng.normal(size=(80, 3)); y = 2 + X @ [1.0, 0.5, 0.0] + rng.normal(0, 0.05, 80)
        m = CarbonCalibrationModel("TOC_wt_pct", ["a", "b", "c"]).fit(X, y, groups=np.arange(80))
        assert m.validated and m.r2_cv > 0.95
        v, why = m.predict(np.array([0.2, -0.1, 0.3]))
        assert why == "ok" and v["interval"][0] < v["value"] < v["interval"][1]
        out, why = m.predict(np.array([40.0, 40.0, 40.0]))
        assert out is None and "applicability domain" in why


def test_idw_layer_respects_max_distance():
    pts = np.array([[0.0, 0.0], [1.0, 0.0]])
    gx, gy = np.linspace(0, 5, 11), np.array([0.0])
    v, conf = idw_layer(pts, np.array([1.0, 0.0]), gx, gy, max_distance=1.5)
    assert np.isnan(v[0, -1]) or conf[0, -1] == 0
    assert v[0, 0] == pytest.approx(1.0, abs=0.05)
