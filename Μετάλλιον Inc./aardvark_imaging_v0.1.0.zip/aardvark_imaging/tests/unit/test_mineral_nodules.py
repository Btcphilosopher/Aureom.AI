"""Mineral assessment, grade separation, nodule detection/measurement/registry."""
from __future__ import annotations

from datetime import date

import numpy as np
import pytest

from aardvark_imaging.core.provenance import DataOrigin, Estimate
from aardvark_imaging.mineralogy.classifier import MineralClassifier
from aardvark_imaging.mineralogy.grade import AssayRecord, GradeCalibrationModel, GradeEngine, load_assays_csv
from aardvark_imaging.nodules.detection import detect_nodules
from aardvark_imaging.nodules.measurement import ellipsoid_surface_area, measure_nodules
from aardvark_imaging.nodules.registry import NoduleObservation, NoduleRegistry


def disc_image(shape, discs, bg=0.25, val=0.05, noise=0.004, seed=0, supersample=4):
    """Anti-aliased dark ellipses (cx, cy, a, b, angle) on a lighter background."""
    H, W = shape
    s = supersample
    yy, xx = np.mgrid[0:H * s, 0:W * s] / s
    frac = np.zeros((H * s, W * s))
    for cx, cy, a, b, ang in discs:
        c, sn = np.cos(ang), np.sin(ang)
        u, v = (xx - cx) * c + (yy - cy) * sn, -(xx - cx) * sn + (yy - cy) * c
        frac = np.maximum(frac, ((u / a) ** 2 + (v / b) ** 2 <= 1).astype(float))
    f = frac.reshape(H, s, W, s).mean((1, 3))
    img = bg * (1 - f) + val * f
    return img + np.random.default_rng(seed).normal(0, noise, img.shape)


class TestMineral:
    def test_associations_are_qualitative_and_require_assay(self):
        a = MineralClassifier().assess(vnir_phase_probs={"todorokite": 0.6, "vernadite": 0.2, "goethite": 0.2})
        assert a.top_class == "manganese_rich"
        assert a.associations and all(not h.quantitative for h in a.associations)
        assert all({"XRF", "ICP-MS"} & set(h.requires) for h in a.associations)

    def test_no_evidence_is_unclassified(self):
        a = MineralClassifier().assess()
        assert a.top_class == "unclassified" or a.confidence < 0.5

    def test_grade_purity_mass_kept_separate_and_refused_without_assay(self):
        mass = Estimate(value=120.0, std=15.0, units="g", origin=DataOrigin.ESTIMATED, method="test")
        r = GradeEngine(recovery={"Ni": 0.9}).report(nodule_id="N1", classification={"manganese_rich": 0.9},
                                                     abundances={"todorokite": (0.5, 0.1)}, mass_g=mass)
        assert all(v is None for v in r.elemental_grade.values())
        assert r.mineralogical_purity is None and "XRD" in r.purity_basis
        assert all(v is None for v in r.recoverable_metal_g.values())
        assert r.physical_mass_g.value == 120.0

    def test_linked_assay_gives_lab_validated_grade_and_recoverable_metal(self):
        mass = Estimate(value=200.0, std=10.0, units="g", origin=DataOrigin.ESTIMATED, method="test")
        a = AssayRecord(sample_id="S1", nodule_id="N1", laboratory="LabX", method="ICP-MS", analysed=date(2026, 1, 5),
                        wt_pct={"Ni": 1.3, "Mn": 29.0}, uncertainty_wt_pct={"Ni": 0.05, "Mn": 0.6})
        r = GradeEngine(recovery={"Ni": 0.9}).report(nodule_id="N1", classification={}, abundances={}, mass_g=mass, assays=[a])
        assert r.elemental_grade["Ni"].value == pytest.approx(1.3)
        assert r.elemental_grade["Ni"].origin == DataOrigin.LAB_VALIDATED
        assert r.recoverable_metal_g["Ni"].value == pytest.approx(200 * 0.013 * 0.9, rel=0.03)
        assert r.elemental_grade["Co"] is None

    def test_grade_model_refuses_when_cv_is_poor(self, rng):
        X = rng.random((40, 3)); y = rng.normal(1.2, 0.2, 40)           # no relation to features
        m = GradeCalibrationModel("Ni", ["a", "b", "c"]).fit(X, y, np.arange(40))
        assert not m.validated
        est, why = m.predict(X[0])
        assert est is None and why

    def test_assay_csv_loader(self, tmp_path):
        f = tmp_path / "assays.csv"
        f.write_text("sample_id,nodule_id,laboratory,method,analysed,Ni_wt_pct,Ni_unc,Mn_wt_pct\nS9,N3,Lab,ICP-OES,2026-02-01,1.1,0.04,27.5\n")
        recs = load_assays_csv(f)
        assert recs[0].wt_pct["Ni"] == pytest.approx(1.1) and recs[0].nodule_id == "N3"
        assert recs[0].uncertainty_wt_pct["Ni"] == pytest.approx(0.04)


class TestDetection:
    def test_counts_and_sizes_isolated_nodules(self):
        discs = [(30 + 45 * i, 30 + 45 * j, 9, 9, 0.0) for i in range(4) for j in range(3)]
        img = disc_image((150, 200), discs)
        d = detect_nodules(img, min_area_px=12)
        assert d.n == 12
        m = measure_nodules(d.labels, gsd_m=0.005, coverage=d.coverage, n_mc=50)
        diam = np.array([x.equivalent_diameter_m.value for x in m])
        assert np.all(np.abs(diam - 0.09) < 0.004)          # 18 px x 5 mm, sub-pixel area via coverage

    def test_touching_nodules_are_split(self):
        img = disc_image((80, 120), [(40, 40, 12, 12, 0), (63, 40, 12, 12, 0)])
        assert detect_nodules(img, min_area_px=12, min_seed_distance_px=4).n == 2

    def test_elongated_nodule_is_not_oversplit(self):
        img = disc_image((80, 140), [(70, 40, 30, 10, 0.3)])
        assert detect_nodules(img, min_area_px=12, min_seed_distance_px=3).n == 1

    def test_illumination_gradient_and_hot_pixels(self, rng):
        discs = [(25 + 40 * i, 40, 8, 8, 0) for i in range(5)]
        img = disc_image((80, 220), discs) * np.linspace(0.5, 1.5, 220)[None, :]
        img[rng.integers(0, 80, 30), rng.integers(0, 220, 30)] = 1.0       # impulse noise
        assert detect_nodules(img, min_area_px=12).n == 5

    def test_empty_seabed_has_no_detections(self, rng):
        img = 0.25 + rng.normal(0, 0.004, (100, 100))
        assert detect_nodules(img, min_area_px=12).n == 0


def test_chromaticity_rejects_green_dark_patch():
    from aardvark_imaging.nodules.detection import reject_by_chromaticity
    discs = [(30, 30, 9, 9, 0), (80, 30, 9, 9, 0)]
    img = disc_image((60, 110), discs)
    d = detect_nodules(img, min_area_px=12)
    chroma = np.full(img.shape, 0.30)                  # sediment ln(g/b)
    yy, xx = np.mgrid[0:60, 0:110]
    chroma[(xx - 30) ** 2 + (yy - 30) ** 2 <= 81] = 0.02    # spectrally flat Mn oxide
    chroma[(xx - 80) ** 2 + (yy - 30) ** 2 <= 81] = 0.45    # green-brown biogenic patch
    lab, deltas = reject_by_chromaticity(d.labels, chroma)
    assert d.n == 2 and lab.max() == 1 and lab[30, 30] == 1 and lab[30, 80] == 0


class TestMeasurementRegistry:
    def test_ellipsoid_surface_area_sphere(self):
        assert ellipsoid_surface_area(1.0, 1.0, 1.0) == pytest.approx(4 * np.pi, rel=1e-6)

    def test_mass_interval_contains_value_and_is_estimated(self):
        img = disc_image((60, 60), [(30, 30, 10, 10, 0)])
        d = detect_nodules(img, min_area_px=12)
        m, = measure_nodules(d.labels, gsd_m=0.005, coverage=d.coverage, n_mc=200, seed=1)
        lo, hi = m.mass_g.interval
        assert lo < m.mass_g.value < hi and m.mass_g.origin == DataOrigin.ESTIMATED

    def test_registry_reidentifies_within_gate_and_fuses_position(self):
        reg = NoduleRegistry("S")
        mk = lambda e, n, sd=0.01: NoduleObservation(observation_id=f"o{e}{n}", sensor="MS0", east_m=e, north_m=n,
                                                     position_std_m=sd, measurements={}, data_origin=DataOrigin.SIMULATED)
        a, new_a = reg.add(mk(1.00, 2.00))
        b, new_b = reg.add(mk(1.01, 2.00))
        c, new_c = reg.add(mk(1.50, 2.00))
        assert new_a and not new_b and new_c and a == b != c
        assert reg.records[a].east_m == pytest.approx(1.005) and len(reg.records[a].observations) == 2
