"""Frames, registration, evidence fusion, geospatial export, storage, Silica Flux manifest."""
from __future__ import annotations

import json

import numpy as np
import pytest

from aardvark_imaging.core.provenance import DataOrigin, Estimate, combine_origins
from aardvark_imaging.geospatial import export as gx
from aardvark_imaging.geospatial.grid import GridSpec, bin_statistic
from aardvark_imaging.hyperspectral.cube import make_cube
from aardvark_imaging.sensor_fusion import frames, registration
from aardvark_imaging.sensor_fusion.fusion import ChannelOpinion, fuse, robust_outliers
from aardvark_imaging.storage.cube_store import RawOverwriteError, load_hdf5, load_zarr, save_hdf5, save_zarr


class TestProvenance:
    def test_origin_combination_is_conservative(self):
        assert combine_origins([DataOrigin.MEASURED, DataOrigin.SIMULATED]) == DataOrigin.SIMULATED
        assert combine_origins([DataOrigin.MEASURED, DataOrigin.MEASURED], model_applied=True) == DataOrigin.ESTIMATED

    def test_estimate_from_samples(self, rng):
        e = Estimate.from_samples(rng.normal(10, 2, 20000), units="g", origin=DataOrigin.ESTIMATED, method="mc")
        assert e.value == pytest.approx(10, abs=0.05) and e.std == pytest.approx(2, rel=0.03)
        assert e.interval[0] == pytest.approx(10 - 1.96 * 2, abs=0.1)


class TestFrames:
    def test_geodetic_ecef_roundtrip(self):
        lat, lon, h = 13.25, -116.8, -4500.0
        back = frames.ecef_to_geodetic(frames.geodetic_to_ecef(lat, lon, h))
        assert np.allclose(back, [lat, lon, h], atol=[1e-9, 1e-9, 1e-4])

    def test_enu_offsets(self):
        enu = frames.geodetic_to_enu(13.0 + 1e-4, -117.0, 0.0, 13.0, -117.0, 0.0)
        assert enu[1] == pytest.approx(11.06, abs=0.05) and abs(enu[0]) < 1e-6

    def test_quaternion_roundtrip_and_slerp(self):
        q = frames.quat_from_ypr(0.3, -0.1, 0.05)
        assert np.allclose(frames.ypr_from_quat(q), (0.3, -0.1, 0.05), atol=1e-12)
        q0, q1 = frames.quat_from_ypr(0, 0, 0), frames.quat_from_ypr(1.0, 0, 0)
        assert frames.ypr_from_quat(frames.slerp(q0, q1, 0.5))[0] == pytest.approx(0.5, abs=1e-9)

    def test_icp_recovers_rigid_transform(self, rng):
        src = rng.uniform(0, 3, (80, 2))
        th = 0.05; R = np.array([[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]])
        dst = src @ R.T + [0.12, -0.07]
        R_est, t_est, rms, n = registration.icp_2d(src, dst)
        assert np.allclose(R_est, R, atol=1e-6) and np.allclose(t_est, [0.12, -0.07], atol=1e-6) and rms < 1e-6


class TestFusion:
    CL = ["manganese_rich", "carbonate", "sediment"]

    def test_agreement_sharpens(self):
        r = fuse([ChannelOpinion("vnir", {"manganese_rich": 0.7, "carbonate": 0.1, "sediment": 0.2}, 1.0, "p1"),
                  ChannelOpinion("raman", {"manganese_rich": 0.8, "carbonate": 0.1, "sediment": 0.1}, 1.0, "p2")], self.CL)
        assert r.top_class == "manganese_rich" and r.top_probability > 0.8 and not r.conflicts

    def test_conflict_is_recorded_not_hidden(self):
        r = fuse([ChannelOpinion("vnir", {"manganese_rich": 0.9, "carbonate": 0.05, "sediment": 0.05}, 1.0, "p1"),
                  ChannelOpinion("raman", {"manganese_rich": 0.05, "carbonate": 0.9, "sediment": 0.05}, 1.0, "p2")],
                 self.CL, expected_channels=["vnir", "raman", "ir"])
        assert r.conflicts and r.conflicts[0].js_divergence > 0.3
        assert r.channels_missing == ["ir"]
        assert r.top_probability < 0.6

    def test_low_quality_channel_is_ignored(self):
        with pytest.raises(ValueError):
            fuse([ChannelOpinion("vnir", {"sediment": 1.0}, 0.0, "p")], self.CL)

    def test_robust_outliers(self):
        v = np.r_[np.random.default_rng(0).normal(0, 1, 50), 25.0]
        assert robust_outliers(v)[-1] and robust_outliers(v).sum() == 1


class TestGeospatial:
    def test_bin_statistic(self):
        g = GridSpec(0.0, 0.0, 1.0, 3, 2, 13.0, -117.0, -4500.0)      # east0/north0 are cell *centres*
        out = bin_statistic(g, np.array([0.1, 0.2, 2.2, 3.6]), np.array([0.1, 0.3, 1.3, 0.0]), np.array([1.0, 2.0, 5.0, 9.0]))
        assert out.shape == (2, 3) and out[0, 0] == 3.0 and out[1, 2] == 5.0 and out.sum() == 8.0   # 3.6 E is off-grid

    def test_geojson_esri_ply_csv(self, tmp_path):
        p = gx.nodules_geojson([{"nodule_id": "N1", "east_m": 10.0, "north_m": 20.0}], (13.0, -117.0, -4500.0),
                               tmp_path / "n.geojson", data_origin="simulated")
        fc = json.loads(p.read_text())
        lon, lat = fc["features"][0]["geometry"]["coordinates"][:2]
        assert lat == pytest.approx(13.0 + 20 / 110_574, abs=2e-6) and lon < -117.0 + 1e-3
        assert fc["features"][0]["properties"]["data_origin"] == "simulated"
        g = GridSpec(0.0, 0.0, 0.5, 4, 3, 13.0, -117.0, -4500.0)
        vals = np.arange(12, dtype=float).reshape(3, 4); vals[1, 1] = np.nan
        hdr, back = gx.read_esri_ascii(gx.esri_ascii(g, vals, tmp_path / "g.asc", data_origin="simulated"))
        assert np.allclose(np.nan_to_num(back, nan=-1), np.nan_to_num(vals, nan=-1))
        ply = gx.ply_mesh(np.arange(4.0), np.arange(3.0), vals, tmp_path / "m.ply", comment="SIMULATED")
        assert ply.read_bytes().startswith(b"ply") and b"SIMULATED" in ply.read_bytes()[:400]
        csv = gx.table_csv([{"a": 1, "b": "x"}], tmp_path / "t.csv")
        assert csv.read_text().splitlines()[0] == "a,b"


class TestStorage:
    def cube(self):
        rng = np.random.default_rng(3)
        raw = rng.integers(0, 4000, (6, 8, 5)).astype(np.uint16)
        return make_cube(raw, np.linspace(450, 650, 5), origin=DataOrigin.SIMULATED, source="test")

    @pytest.mark.parametrize("fmt", ["zarr", "hdf5"])
    def test_roundtrip_and_raw_preserved(self, tmp_path, fmt):
        c = self.cube()
        save, load = (save_zarr, load_zarr) if fmt == "zarr" else (save_hdf5, load_hdf5)
        path = tmp_path / f"c.{fmt}"
        save(c, path)
        back = load(path)
        np.testing.assert_array_equal(back.raw.values, c.raw.values)
        assert back.provenance.origin == DataOrigin.SIMULATED
        with pytest.raises(RawOverwriteError):
            save(c, path)                                # products are write-once
        save(c, path, product="reprocessed_v2")          # new product name: allowed, raw untouched
        np.testing.assert_array_equal(load(path, "reprocessed_v2").raw.values, c.raw.values)

    def test_database_repository(self, survey, tmp_path):
        from aardvark_imaging.storage.database import Repository, make_engine, nodules
        repo = Repository(make_engine(f"sqlite:///{tmp_path / 'db.sqlite'}"))
        repo.save_survey(survey)
        assert repo.count(nodules) == len(survey.registry)
        nid = next(iter(survey.registry.records))
        row = repo.nodule(nid)
        assert row["data_origin"] == "simulated" and len(row["observations"]) >= 1
        repo.log("test", "read", nid)


class TestSilicaFlux:
    def test_manifest_valid_and_generated_files_current(self):
        from aardvark_imaging.silica_flux import check_up_to_date, load_manifest
        m = load_manifest()
        regs = m.expanded()
        addrs = [r.address for r in regs]
        assert len(addrs) == len(set(addrs)) and all(a % 4 == 0 for a in addrs)
        assert check_up_to_date() == []             # RTL/C/Python register maps match the manifest

    def test_data_rate_budget_within_dma_capacity(self):
        from aardvark_imaging.silica_flux import compute_budget, load_manifest
        b = compute_budget(load_manifest())
        assert 0 < b.utilisation < 0.95
        assert b.total_wire_bytes_per_s == pytest.approx(sum(s.wire_bytes_per_s for s in b.sensors))
