"""Acoustics (sound speed, absorption, ray tracing, chirps, sub-bottom), EMI and
radar feasibility. Physical checks use published reference values."""
from __future__ import annotations

import numpy as np
import pytest

from aardvark_imaging.electromagnetic import induction as emi
from aardvark_imaging.electromagnetic import radar
from aardvark_imaging.sonar import acoustics, imaging, multibeam, raytrace, subbottom


class TestAcoustics:
    def test_mackenzie_check_value(self):
        # Mackenzie (1981) check value: T=25 C, S=35, D=1000 m -> 1550.744 m/s
        assert acoustics.sound_speed_mackenzie(25.0, 35.0, 1000.0) == pytest.approx(1550.744, abs=0.01)

    def test_absorption_rises_with_frequency(self):
        a = acoustics.absorption_db_per_km(np.array([1.0, 10.0, 100.0, 400.0]), T=4.0)
        assert np.all(np.diff(a) > 0)
        assert 20 < a[2] < 45          # ~30 dB/km at 100 kHz in cold seawater (Ainslie & McColm)

    def test_reflection_coefficient(self):
        assert acoustics.reflection_coefficient(1025, 1500, 1025, 1500) == pytest.approx(0.0)
        r = acoustics.reflection_coefficient(1025, 1500, 1300, 1480)   # soft abyssal clay: weak reflector
        assert 0.0 < r < 0.2

    def test_straight_ray_in_isovelocity_water(self):
        svp = raytrace.SoundVelocityProfile(np.array([0.0, 6000.0]), np.array([1500.0, 1500.0]))
        z, x = raytrace.trace_ray(svp, 10.0, np.deg2rad(30), 0.01)
        assert z - 10 == pytest.approx(15 * np.cos(np.deg2rad(30)), rel=1e-6)
        assert x == pytest.approx(15 * np.sin(np.deg2rad(30)), rel=1e-6)

    def test_refraction_bends_ray_in_gradient(self):
        svp = raytrace.SoundVelocityProfile(np.array([0.0, 200.0]), np.array([1480.0, 1520.0]))
        straight = raytrace.SoundVelocityProfile(np.array([0.0, 200.0]), np.array([1500.0, 1500.0]))
        _, xg = raytrace.trace_ray(svp, 0.0, np.deg2rad(50), 0.08)
        _, xs = raytrace.trace_ray(straight, 0.0, np.deg2rad(50), 0.08)
        assert xg != pytest.approx(xs, rel=1e-3)

    def test_grid_soundings_median(self):
        s = np.array([[0.1, 0.1, 100.0], [0.1, 0.12, 102.0], [0.12, 0.1, 101.0], [0.9, 0.9, 50.0]])
        ds = multibeam.grid_soundings(s, resolution_m=0.5, bounds=(0, 1, 0, 1))
        assert float(ds.depth.values[0, 0]) == pytest.approx(101.0)

    def test_chirp_matched_filter_resolution(self):
        fs, B = 2e6, 100e3
        rep = imaging.lfm_chirp(150e3, 250e3, 1e-3, fs)
        sig = np.zeros(8000); d = 3000; sig[d:d + rep.size] += rep
        env = imaging.matched_filter(sig, rep)
        assert abs(int(np.argmax(env)) - (d + rep.size - 1)) <= 3 or abs(int(np.argmax(env)) - d) <= 3
        assert imaging.range_resolution_m(B) == pytest.approx(0.0075)

    def test_subbottom_penetration_falls_with_frequency(self):
        p = subbottom.penetration_depth_m(np.array([3.5, 12.0, 100.0]), available_db=60)
        assert p[0] > p[1] > p[2] and p[0] > 20 and p[2] < 3


class TestEmi:
    def test_seawater_conductivity_reference(self):
        # PSS-78 conductivity of S=35 seawater at 15 C is 4.2914 S/m
        assert emi.seawater_conductivity(15.0, 35.0) == pytest.approx(4.29, rel=0.03)
        assert 2.9 < emi.seawater_conductivity(2.0) < 3.3

    def test_skin_depth(self):
        # delta = sqrt(2/(w mu sigma)) ~ 2.8 m at 10 kHz in 3.2 S/m seawater
        assert float(emi.skin_depth_m(10e3, 3.2)) == pytest.approx(2.81, rel=0.01)

    def test_lin_apparent_conductivity_inversion(self):
        f, s, sigma = 10e3, 0.5, 3.2          # B = s/delta = 0.18 < 0.3 (at 1 m spacing B = 0.36: LIN fails in seawater)
        w = 2 * np.pi * f
        hs_hp = 1j * w * emi.MU0 * sigma * s ** 2 / 4       # McNeill low-induction-number response
        assert float(emi.apparent_conductivity(hs_hp, f, s)) == pytest.approx(sigma, rel=1e-9)
        assert emi.lin_valid(f, s, sigma)
        assert not emi.lin_valid(100e3, 3.0, sigma)

    def test_platform_compensation_removes_motion_coupling(self, rng):
        n = 400
        pitch, roll = rng.normal(0, 0.05, n), rng.normal(0, 0.05, n)
        Z = 1e-3 * (2.0 + 0.8 * pitch - 0.5 * roll) + 1e-3j * (0.3 * pitch) + rng.normal(0, 1e-6, n)
        R = np.column_stack([pitch, roll])
        comp = emi.fit_platform_compensation(Z, R, ["pitch", "roll"])
        assert np.std(np.abs(comp.apply(Z, R))) < 0.1 * np.std(np.abs(Z))


class TestRadar:
    def test_seawater_attenuation_order_of_magnitude(self):
        a = radar.seawater_attenuation(100e6, 4.0)["alpha_db_m"]
        assert 250 < a < 400             # ~325 dB/m at 100 MHz: GPR is not viable through seawater

    def test_path_gate_refuses_seawater_and_names_alternatives(self):
        a = radar.assess_path(400e6, 1.0, medium="seawater")
        assert not a.feasible and "sub-bottom" in a.reason and "EMI" in a.reason
        assert radar.assess_path(24e9, 3.0, medium="air").feasible

    def test_fmcw_refuses_underwater_processing(self):
        r = radar.FmcwRadar(24e9, 1e9, 1e-3, 1e6)
        with pytest.raises(radar.RadarNotFeasible):
            r.process(np.zeros(1024), medium="seawater", path_m=0.5)
        rng_m, spec, _ = r.process(np.sin(2 * np.pi * 2e4 * np.arange(1000) / 1e6), medium="air", path_m=3.0)
        assert rng_m[np.argmax(spec)] == pytest.approx(3.0, rel=0.05)
