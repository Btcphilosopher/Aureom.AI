"""Generic spectral processing, hyperspectral water model and analysis, SAM classification."""
from __future__ import annotations

import numpy as np
import pytest

from aardvark_imaging.hyperspectral import analysis as ha
from aardvark_imaging.hyperspectral import water
from aardvark_imaging.hyperspectral.classification import classify_sam
from aardvark_imaging.mineralogy.library import parametric_vnir_library
from aardvark_imaging.spectral import baseline, continuum, cosmic, noise, peaks, similarity
from aardvark_imaging.spectral.infrared import atr_penetration_depth_um


class TestGeneric:
    def test_als_baseline_recovers_smooth_background(self, rng):
        x = np.linspace(100, 3000, 1500)
        bg = 200 + 0.05 * x + 80 * np.exp(-((x - 1800) / 900) ** 2)
        pk = peaks.lorentzian(x, 500, 1086, 8) + peaks.lorentzian(x, 300, 1590, 40)
        y = bg + pk + rng.normal(0, 3, x.size)
        b = baseline.als_baseline(y, lam=1e6, p=0.005)
        far = (np.abs(x - 1086) > 60) & (np.abs(x - 1590) > 200)
        assert np.sqrt(np.mean((b - bg)[far] ** 2)) < 10
        assert (y - b)[np.argmin(np.abs(x - 1086))] == pytest.approx(500, rel=0.1)

    def test_noise_sigma_estimator_unbiased(self, rng):
        y = np.sin(np.linspace(0, 6, 4000)) * 100 + rng.normal(0, 2.0, 4000)
        assert noise.noise_sigma(y) == pytest.approx(2.0, rel=0.08)

    def test_peak_fit_recovers_parameters_and_errors(self, rng):
        x = np.linspace(900, 1300, 800)
        y = peaks.lorentzian(x, 120, 1086.4, 9.0) + rng.normal(0, 2, x.size) + 15
        idx, _, sig = peaks.detect_peaks(x, y - 15, snr=8)
        assert len(idx) == 1
        f = peaks.fit_peaks(x, y, [(100, x[idx[0]], 12)], shape="lorentzian")
        assert f.success
        assert f.centers[0] == pytest.approx(1086.4, abs=0.2)
        assert f.fwhms[0] == pytest.approx(9.0, rel=0.05)
        assert 0 < f.stderr[0, 1] < 0.2           # centre uncertainty is reported

    def test_cosmic_spike_removal(self, rng):
        frames = 100 + rng.normal(0, 3, (5, 500))
        frames[2, 250] += 3000
        clean, mask = cosmic.remove_spikes_multi(frames)
        assert mask[2, 250] and mask.sum() <= 2
        assert abs(clean[2, 250] - 100) < 15
        y = 100 + rng.normal(0, 3, 500); y[100] += 2000
        c1, sp = cosmic.remove_spikes_single(y)
        assert sp[100] and abs(c1[100] - 100) < 20

    def test_continuum_removed_band_depth(self):
        x = np.linspace(800, 1200, 401)
        y = (0.3 + 1e-4 * (x - 800)) * (1 - 0.2 * np.exp(-0.5 * ((x - 950) / 30) ** 2))
        bp = continuum.band_parameters(x, y, 850, 1050)
        assert bp["depth"] == pytest.approx(0.2, abs=0.01) and bp["center"] == pytest.approx(950, abs=3)

    def test_spectral_angle_is_brightness_invariant(self):
        a = np.array([0.1, 0.2, 0.3, 0.25])
        assert float(similarity.spectral_angle(a, 3 * a)) == pytest.approx(0.0, abs=1e-7)
        assert float(similarity.spectral_angle(a, a[::-1])) > 0.2


class TestWater:
    def test_attenuation_is_physical(self):
        wl = np.array([450.0, 550.0, 650.0, 750.0, 900.0, 1200.0, 1450.0])
        a = water.water_absorption(wl)
        assert a[0] < a[2] < a[3] < a[4] < a[5] < a[6]        # blue-green window, rising into the NIR
        assert a[6] > 1000                                     # 1450 nm overtone ~ 2600 /m (approx table)

    def test_max_standoff_bounds(self):
        # two-way, 2 % transmission: SWIR is centimetre-range or less — contact/near-contact only
        s = water.max_standoff_m(np.array([550.0, 900.0, 1200.0, 1450.0]), t_min=0.02)
        assert s[0] > 2.0
        assert 0.1 < s[1] < 0.6
        assert 0.005 < s[2] < 0.05
        assert s[3] < 0.002

    def test_usable_bands_shrink_with_altitude(self):
        wl = np.arange(400.0, 1001.0, 10)
        assert water.usable_bands(wl, 1.0).sum() > water.usable_bands(wl, 6.0).sum()

    def test_atr_penetration_depth_micron_scale(self):
        dp = atr_penetration_depth_um(np.array([2920.0, 1430.0, 875.0]))
        assert np.all((dp > 0.3) & (dp < 3.0))     # ATR samples only the outer ~1 um


class TestHyperspectral:
    def test_fcls_unmixing_recovers_abundances(self, rng):
        lib = parametric_vnir_library(np.arange(400.0, 901.0, 5))
        E = np.array([lib.get(n) for n in ["vernadite", "goethite", "sediment"]])
        A = rng.dirichlet([1, 1, 1], 200)
        X = A @ E + rng.normal(0, 0.001, (200, E.shape[1]))
        u = ha.unmix(X, E)
        assert np.allclose(u["abundances"].sum(1), 1, atol=1e-3)
        assert np.all(u["abundances"] >= -1e-9)
        assert np.sqrt(np.mean((u["abundances"] - A) ** 2)) < 0.03

    def test_atgp_finds_pure_pixels(self, rng):
        lib = parametric_vnir_library(np.arange(400.0, 901.0, 5))
        E = np.array([lib.get(n) for n in ["calcite", "vernadite", "biological"]])
        A = rng.dirichlet([0.5] * 3, 300); A[:3] = np.eye(3)
        idx = ha.atgp(A @ E, 3)
        assert set(idx.tolist()) == {0, 1, 2}

    def test_pca_explained_ratio_sums_to_one(self, rng):
        r = ha.pca(rng.normal(size=(500, 12)))
        assert np.isclose(np.sum(r["explained_ratio"]), 1.0)

    def test_sam_classification_and_refusal(self, rng):
        wl = np.arange(400.0, 801.0, 5)
        lib = parametric_vnir_library(wl)
        px = np.array([lib.get("goethite") * 1.3, lib.get("sediment") * 0.8, np.linspace(0.9, 0.1, wl.size)])
        r = classify_sam(px + rng.normal(0, 0.002, px.shape), lib.spectra, lib.names, snr=60, max_angle=0.15)
        names = r.label_names()
        assert names[0] == "goethite" and names[1] == "sediment"
        assert names[2] == "unclassified"          # nothing in the library looks like it: refused, not forced
