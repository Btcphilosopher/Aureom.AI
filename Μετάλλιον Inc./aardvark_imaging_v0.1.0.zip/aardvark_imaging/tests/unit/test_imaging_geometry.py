"""Camera refraction/georeferencing, navigation interpolation, multispectral
registration/colour/HDR, the hyperspectral calibration pipeline, acoustic
imaging and sub-bottom picking, reference-library loaders."""
from __future__ import annotations

import numpy as np
import pytest

from aardvark_imaging.calibration.radiometric import DarkReference
from aardvark_imaging.core.provenance import DataOrigin
from aardvark_imaging.hyperspectral import analysis as ha
from aardvark_imaging.hyperspectral import pipeline as hp
from aardvark_imaging.hyperspectral.cube import make_cube
from aardvark_imaging.mineralogy.library import load_rruff_raman, load_usgs_splib07_ascii
from aardvark_imaging.sensor_fusion.camera import CameraModel, georeference_pixels
from aardvark_imaging.sensor_fusion.navigation import NavSeries
from aardvark_imaging.sonar import imaging, subbottom
from aardvark_imaging.spectral import multispectral as ms
from aardvark_imaging.spectral import similarity


class TestCamera:
    CAM = CameraModel(fx=2000, fy=2000, cx=1000, cy=750, width=2000, height=1500, n_water=1.34)

    def test_flat_port_narrows_field_of_view(self):
        air = self.CAM.ray_in_air(2000, 750)
        water = self.CAM.ray_in_water(2000, 750)
        ang_a = np.arctan2(np.hypot(*air[:2]), air[2]); ang_w = np.arctan2(np.hypot(*water[:2]), water[2])
        assert np.sin(ang_a) / np.sin(ang_w) == pytest.approx(1.34, rel=1e-9)     # Snell's law
        assert self.CAM.gsd_m(2.0) == pytest.approx(2.0 / (2000 * 1.34))

    def test_nadir_georeference_and_uncertainty(self):
        pose = {"east": 10.0, "north": 20.0, "depth": 4498.0, "yaw": 0.0, "pitch": 0.0, "roll": 0.0, "altitude": 2.0,
                "pos_std": 0.5, "att_std": np.radians(0.1), "alt_std": 0.02}
        e, n = georeference_pixels(self.CAM, 1000, 750, pose)
        assert float(e) == pytest.approx(10.0, abs=1e-9) and float(n) == pytest.approx(20.0, abs=1e-9)
        e2, n2, sd = georeference_pixels(self.CAM, 1000, 750, pose, n_mc=400, seed=1)
        assert 0.3 < float(sd) < 0.7                       # dominated by the 0.5 m navigation error

    def test_pixel_offset_scales_with_refracted_gsd(self):
        pose = {"east": 0.0, "north": 0.0, "depth": 100.0, "yaw": 0.0, "pitch": 0.0, "roll": 0.0, "altitude": 2.0}
        e0, n0 = georeference_pixels(self.CAM, 1000, 750, pose)
        e1, n1 = georeference_pixels(self.CAM, 1100, 750, pose)
        assert np.hypot(float(e1 - e0), float(n1 - n0)) == pytest.approx(100 * self.CAM.gsd_m(2.0), rel=0.01)


class TestNavigation:
    def nav(self):
        t = np.arange(0.0, 10.0, 1.0)
        return NavSeries(t, t * 0.5, np.zeros_like(t), np.full_like(t, 4498.0), np.linspace(0, 0.9, t.size),
                         np.zeros_like(t), np.zeros_like(t), np.full_like(t, 2.0), np.full_like(t, 0.3))

    def test_interpolation(self):
        p = self.nav().interpolate(2.5)
        assert p["east"] == pytest.approx(1.25) and p["yaw"] == pytest.approx(0.25, abs=1e-9)

    def test_refuses_extrapolation_and_non_monotonic_time(self):
        with pytest.raises(ValueError):
            self.nav().interpolate(11.0)
        with pytest.raises(ValueError):
            NavSeries(np.array([0.0, 0.0]), *[np.zeros(2)] * 8)


class TestMultispectral:
    def test_phase_correlation_subpixel(self, rng):
        img = np.zeros((64, 64)); img[20:30, 25:40] = 1.0
        from scipy import ndimage
        img = ndimage.gaussian_filter(img + 0.02 * rng.normal(size=img.shape), 1.0)
        moved = ndimage.shift(img, (2.4, -3.6), order=3)
        dy, dx = ms.phase_correlation(img, moved)
        assert dy == pytest.approx(2.4, abs=0.15) and dx == pytest.approx(-3.6, abs=0.15)
        stack = np.stack([img, moved])
        out, shifts = ms.register_bands(stack)
        assert np.abs(out[1] - img)[8:-8, 8:-8].max() < 0.1

    def test_motion_shift_prediction(self):
        dy, dx, rot = ms.motion_shift_px(0.05, (0.5, 0.0), 0.002)
        assert dx == pytest.approx(12.5) and dy == 0 and rot == 0

    def test_colour_matrix_and_delta_e(self, rng):
        ref = rng.uniform(0.05, 0.9, (24, 3))
        M = np.array([[0.9, 0.05, 0.0], [0.1, 0.8, 0.05], [0.0, 0.1, 0.7]])
        measured = ref @ M.T + 0.01
        X = ms.fit_colour_matrix(measured, ref)
        corr = ms.apply_colour_matrix(measured, X)
        de = ms.delta_e76(ms.linear_rgb_to_lab(corr), ms.linear_rgb_to_lab(ref))
        assert de.max() < 0.5

    def test_hdr_merge_excludes_saturation(self):
        radiance = np.array([100.0, 1000.0, 20000.0])
        exps = np.array([0.001, 0.01, 0.1])
        frames = np.minimum(radiance[None] * exps[:, None], 4095)
        out = ms.hdr_merge(frames, exps, sat_level=4095)
        assert np.allclose(out, radiance, rtol=1e-6)

    def test_undistort_identity_without_distortion(self, rng):
        img = rng.random((40, 50))
        assert np.allclose(ms.undistort(img, 100, 100, 25, 20), img, atol=1e-6)


class TestHyperspectralPipeline:
    def test_chain_preserves_raw_and_records_history(self, rng):
        L, S, B = 6, 10, 5
        wl = np.linspace(450, 650, B)
        dark = 100 + rng.normal(0, 1, (S, B))
        gain = 1 + 0.05 * rng.normal(size=(S, B))
        truth = 0.2 + 0.1 * rng.random((L, S, B))
        raw = np.round(dark[None] + 3000 * truth / gain[None]).astype(np.uint16)
        raw[2, 3, 1] = 4095
        cube = make_cube(raw, wl, origin=DataOrigin.SIMULATED, source="t", saturated=raw >= 4095)
        c = hp.subtract_dark(cube, DarkReference(dark, np.ones_like(dark), 16, 5.0, 0.01), "CAL-D")
        c = hp.apply_flat(c, gain, "CAL-F")
        c = hp.repair_bad_pixels(c)
        with pytest.raises(ValueError):
            hp.to_reflectance(c, None)                       # no reference panel: refuse, do not guess
        c = hp.to_reflectance(c, hp.ReflectanceReference(np.full(B, 3000.0), np.ones(B), "PANEL-1", "cert"))
        ok = ~c.saturated
        assert np.allclose(c.data.values[ok], truth[ok], atol=0.002)
        assert np.isnan(c.data.values[2, 3, 1]) or c.saturated[2, 3, 1]
        np.testing.assert_array_equal(c.raw.values, raw)
        assert set(c.provenance.calibration_ids) >= {"CAL-D", "CAL-F", "PANEL-1"}
        assert len(c.history) >= 5

    def test_water_correction_masks_opaque_bands(self):
        wl = np.array([500.0, 750.0, 1000.0])
        cube = make_cube(np.full((2, 2, 3), 1000, np.uint16), wl, origin=DataOrigin.SIMULATED, source="t")
        c = hp.correct_water(cube, 3.0)
        assert np.all(np.isfinite(c.data.values[..., 0])) and np.all(np.isnan(c.data.values[..., 2]))

    def test_mnf_and_vca(self, rng):
        from aardvark_imaging.mineralogy.library import parametric_vnir_library
        lib = parametric_vnir_library(np.arange(400.0, 901.0, 10))
        E = np.array([lib.get(n) for n in ["calcite", "vernadite", "biological"]])
        # MNF estimates noise from neighbour differences, so the abundance field must be spatially smooth
        from scipy import ndimage
        F = np.stack([ndimage.gaussian_filter(rng.random((20, 20)), 3) for _ in range(3)], -1)
        F = np.exp(8 * (F - F.mean())); A = (F / F.sum(-1, keepdims=True)).reshape(400, 3)
        clean = A @ E
        X = clean + rng.normal(0, 0.01, clean.shape)
        Xp = X.copy(); Xp[:3] = E                              # VCA needs pure pixels present
        idx = ha.vca(Xp, 3, seed=0)
        assert len(set(int(i) for i in idx)) == 3
        r = ha.mnf(X.reshape(20, 20, -1), 3)
        err_before = np.sqrt(np.mean((X - clean) ** 2))
        err_after = np.sqrt(np.mean((r["reconstruction"].reshape(400, -1) - clean) ** 2))
        assert err_after < 0.5 * err_before                  # denoising removes most of the white noise


class TestAcousticImaging:
    def test_delay_and_sum_focuses_point_scatterer(self):
        fs, c = 2e6, 1500.0
        ex = np.linspace(-0.1, 0.1, 8)
        target = (0.03, 1.0)
        env = np.zeros((8, 4000))
        for k, x in enumerate(ex):
            d = np.hypot(target[0], target[1]) + np.hypot(target[0] - x, target[1])
            i = int(round(d / c * fs)); env[k, i - 2:i + 3] = 1.0
        gx, gz = np.linspace(-0.2, 0.2, 81), np.linspace(0.8, 1.2, 81)
        img = imaging.delay_and_sum(env, ex, fs, c, gx, gz)
        iz, ix = np.unravel_index(np.argmax(img), img.shape)
        # envelope (incoherent) DAS: lateral resolution ~ c*tau*z/D = 3.75 mm * 1 m / 0.2 m ~ 19 mm
        assert gx[ix] == pytest.approx(0.03, abs=0.02) and gz[iz] == pytest.approx(1.0, abs=0.005)

    def test_subbottom_layer_picking(self):
        fs = 200e3
        layers = [(0.3, 1480.0, 1300.0), (1.0, 1560.0, 1700.0), (5.0, 1700.0, 1900.0)]
        tr = subbottom.synthetic_trace(layers, fs=fs, duration_s=0.03, f_khz=3.5, water_depth_m=10.0)
        t, depth = subbottom.pick_layers(np.abs(tr), fs, 1550.0, rel_threshold=0.05)
        assert len(t) >= 2 and t[0] == pytest.approx(2 * 10 / 1500, abs=2 / fs)


class TestLibraries:
    def test_usgs_and_rruff_loaders(self, tmp_path):
        (tmp_path / "wl.txt").write_text("header\n0.40\n0.50\n0.60\n")
        (tmp_path / "s.txt").write_text("header\n0.10\n-1.23e34\n0.30\n")
        wl, r, name = load_usgs_splib07_ascii(tmp_path / "s.txt", tmp_path / "wl.txt", name="calcite")
        assert np.allclose(wl, [400, 500, 600]) and np.isnan(r[1]) and name == "calcite"
        (tmp_path / "r.txt").write_text("##NAMES=Calcite\n##RRUFFID=R040070\n150, 10\n1086, 900\n")
        d = load_rruff_raman(tmp_path / "r.txt")
        assert d["name"] == "Calcite" and d["shift_cm1"][1] == 1086

    def test_similarity_metrics(self):
        a = np.array([0.1, 0.2, 0.3]); b = np.array([0.1, 0.2, 0.31])
        assert similarity.spectral_information_divergence(a, a) == pytest.approx(0.0, abs=1e-12)
        assert similarity.spectral_information_divergence(a, b) > 0
        src = np.arange(400.0, 701.0, 1.0); val = np.ones_like(src)
        out = similarity.resample_gaussian(src, val, np.array([450.0, 550.0, 650.0]), 10.0)
        assert np.allclose(out, 1.0, atol=1e-6)
