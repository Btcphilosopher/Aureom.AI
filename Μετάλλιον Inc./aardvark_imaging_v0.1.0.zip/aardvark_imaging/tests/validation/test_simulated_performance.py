"""Acceptance thresholds on SIMULATED ground truth (two independent scenes).

These numbers measure the algorithms against the simulator, nothing more:
they are regression guards and a statement of simulated performance, not
field accuracy. Field acceptance requires the laboratory and sea-trial
programme in docs/calibration.md.
"""
from __future__ import annotations

import pytest


@pytest.fixture(params=["survey", "survey_seed7"])
def val(request):
    return request.getfixturevalue(request.param).validation


def test_detection(val):
    d = val["nodule_detection"]
    assert d["precision"] >= 0.9          # colour test rejects dark biogenic cover
    assert d["recall"] >= 0.55            # conservative: partly covered nodules are missed (documented)


def test_size_and_mass(val):
    assert val["diameter_m"]["mae"] <= 0.003
    assert abs(val["diameter_m"]["bias"]) <= 0.003
    assert val["mass_interval_coverage_95"] >= 0.8     # nominal 0.95: intervals are known to be too narrow


def test_abundance_bias_is_low_side(val):
    a = val["abundance_kg_m2"]
    assert 0.6 * a["true"] <= a["estimated"] <= 1.1 * a["true"]


def test_carbon_classification_self_consistency(val):
    c = val["carbon_classification"]
    assert c["accuracy"] >= 0.8 and val["carbon_confidence_calibration"]["ece"] <= 0.15


def test_hsi_pixel_classes(val):
    h = val["hsi_pixels"]
    assert h["nodule_pixels_classified_mn_oxide"] >= 0.7
    assert h["sediment_pixels_classified_mn_oxide"] <= 0.2


def test_grade_model_gate(val):
    g = val["grade_model_Ni"]
    if g["validated"]:
        assert g["r2_cv"] >= 0.6 and g["n_assay_linked"] >= 25
    else:
        assert g["reasons"]


def test_bathymetry_and_emi(val):
    assert val["bathymetry"]["rmse_m"] < 0.06
    assert val["emi_compensation"]["after"] < 0.2 * val["emi_compensation"]["before"]
