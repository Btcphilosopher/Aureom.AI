"""Browser check of the workstation (Playwright/Chromium).

    python tests/ui/ui_check.py --url http://127.0.0.1:8765/ --out docs/screenshots
    python tests/ui/ui_check.py --url file:///.../frontend/index.html --out /tmp/shots

Visits every view, interacts with the main controls, fails on any console
error or uncaught exception, and writes screenshots (desktop + phone width).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright


def run(url: str, out: Path, phone: bool = True) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []
    report: dict = {"url": url, "views": {}}
    with sync_playwright() as pw:
        b = pw.chromium.launch(args=["--use-gl=swiftshader", "--enable-webgl", "--ignore-gpu-blocklist"])
        for label, vp in [("desktop", {"width": 1440, "height": 1000})] + ([("phone", {"width": 390, "height": 844})] if phone else []):
            pg = b.new_page(viewport=vp)
            pg.on("console", lambda m: errors.append(f"{label} console.{m.type}: {m.text}") if m.type == "error" else None)
            pg.on("pageerror", lambda e: errors.append(f"{label} pageerror: {e}"))
            pg.goto(url)
            pg.wait_for_function("document.body.dataset.ready", timeout=30000)
            report["ready"] = pg.evaluate("document.body.dataset.ready")
            report["source"] = pg.inner_text("#source-badge")
            pg.wait_for_timeout(400)
            pg.screenshot(path=str(out / f"{label}_dashboard.png"), full_page=True)
            report["views"]["dashboard"] = {"sensor_rows": pg.locator("#sensor-table tbody tr").count(),
                                            "health_items": pg.locator("#health-list li").count(),
                                            "validation_boxes": pg.locator("#validation .vbox").count()}
            # spectral
            pg.click("button[data-view=spectral]")
            pg.wait_for_function("document.querySelector('#spec-plot').width > 0", timeout=20000)
            pg.wait_for_timeout(500)
            pg.fill("#wl-slider", "70")
            pg.dispatch_event("#wl-slider", "input")
            pg.check("#overlay-class")
            pg.wait_for_timeout(600)
            box = pg.locator("#cube-canvas").bounding_box()
            pg.mouse.click(box["x"] + box["width"] * 0.3, box["y"] + box["height"] * 0.4)
            pg.wait_for_timeout(600)
            pg.click("#pin-spec")
            pg.mouse.click(box["x"] + box["width"] * 0.7, box["y"] + box["height"] * 0.6)
            pg.wait_for_timeout(600)
            report["views"]["spectral"] = {"wl_label": pg.inner_text("#wl-label"), "pixel": pg.inner_text("#pix-label")}
            pg.screenshot(path=str(out / f"{label}_spectral.png"), full_page=True)
            # carbon
            pg.click("button[data-view=carbon]")
            pg.wait_for_function("document.querySelectorAll('#ct-evidence tbody tr').length > 0", timeout=20000)
            pg.wait_for_timeout(400)
            report["views"]["carbon"] = {"target": pg.inner_text("#ct-id"), "evidence_rows": pg.locator("#ct-evidence tbody tr").count(),
                                         "layers": pg.locator("#carbon-layer option").count()}
            pg.select_option("#carbon-layer", index=1)
            pg.wait_for_timeout(300)
            pg.screenshot(path=str(out / f"{label}_carbon.png"), full_page=True)
            # mineral
            pg.click("button[data-view=mineral]")
            pg.wait_for_function("document.querySelectorAll('#nod-table tbody tr').length > 0", timeout=20000)
            pg.wait_for_function("document.querySelector('#nr-body h3') !== null", timeout=20000)
            pg.fill("#nod-filter", "manganese")
            pg.wait_for_timeout(300)
            report["views"]["mineral"] = {"rows_filtered": pg.locator("#nod-table tbody tr").count(), "record": pg.inner_text("#nr-id")}
            pg.screenshot(path=str(out / f"{label}_mineral.png"), full_page=True)
            # geology
            pg.click("button[data-view=geology]")
            pg.wait_for_timeout(1500)
            cv = pg.locator("#geo-canvas").bounding_box()
            pg.mouse.move(cv["x"] + cv["width"] / 2, cv["y"] + cv["height"] / 2)
            pg.mouse.down(); pg.mouse.move(cv["x"] + cv["width"] / 2 + 80, cv["y"] + cv["height"] / 2 + 30, steps=5); pg.mouse.up()
            pg.mouse.move(cv["x"] + cv["width"] * 0.5, cv["y"] + cv["height"] * 0.55)
            pg.wait_for_timeout(400)
            webgl = pg.evaluate("!!document.querySelector('#geo-canvas').getContext('webgl')")
            px = pg.evaluate("""(() => { const c = document.querySelector('#geo-canvas'); const g = c.getContext('webgl');
                 if (!g) return null; const a = new Uint8Array(4 * 64); g.readPixels(Math.floor(c.width/2)-16, Math.floor(c.height/2), 16, 4, g.RGBA, g.UNSIGNED_BYTE, a);
                 let s = 0; for (let i = 0; i < a.length; i += 4) s += a[i] + a[i+1] + a[i+2]; return s / 64; })()""")
            report["views"]["geology"] = {"webgl": webgl, "centre_brightness": px, "tip_visible": pg.is_visible("#geo-tip"),
                                          "layers": pg.locator("#geo-layer option").count()}
            pg.screenshot(path=str(out / f"{label}_geology.png"), full_page=True)
            # overflow check (no horizontal page scroll)
            report[f"{label}_hscroll"] = pg.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth + 1")
            pg.close()
        b.close()
    report["errors"] = errors
    return report


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--out", default="ui_screenshots")
    ap.add_argument("--no-phone", action="store_true")
    a = ap.parse_args()
    r = run(a.url, Path(a.out), phone=not a.no_phone)
    print(json.dumps(r, indent=1))
    sys.exit(1 if r["errors"] or r.get("ready") != "1" else 0)
