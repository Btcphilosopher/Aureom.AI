"""Browser test of the workstation against a live API server (marker: ui).

Starts the API (which also serves the frontend) on a free port, then drives
Chromium through every view in live and offline-snapshot modes, failing on
any console error or page exception.
"""
from __future__ import annotations

import socket
import threading
import time

import pytest

pytestmark = pytest.mark.ui
playwright = pytest.importorskip("playwright.sync_api")


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    import uvicorn
    from aardvark_imaging.api.app import create_app
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    app = create_app(seed=21, data_dir=str(tmp_path_factory.mktemp("ui")), api_key="")
    cfg = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    srv = uvicorn.Server(cfg)
    th = threading.Thread(target=srv.run, daemon=True)
    th.start()
    for _ in range(200):
        if srv.started:
            break
        time.sleep(0.05)
    yield f"http://127.0.0.1:{port}/"
    srv.should_exit = True
    th.join(timeout=10)


@pytest.mark.parametrize("query", ["", "?snapshot"])
def test_all_views_without_errors(server, tmp_path, query):
    from tests.ui.ui_check import run
    r = run(server + query, tmp_path, phone=True)
    assert r["ready"] == "1", r
    assert r["errors"] == [], r["errors"]
    assert r["source"] == ("LIVE API" if not query else "OFFLINE SNAPSHOT")
    v = r["views"]
    assert v["dashboard"]["sensor_rows"] == 12 and v["dashboard"]["validation_boxes"] >= 8
    assert v["carbon"]["evidence_rows"] >= 5 and v["geology"]["webgl"]
    assert not r["desktop_hscroll"] and not r["phone_hscroll"]
