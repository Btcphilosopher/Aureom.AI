"""The engineering rules of the platform, written as executable checks.

Each test encodes a scientific constraint the software must never violate,
independent of how well the algorithms perform.
"""
from __future__ import annotations

import inspect

import numpy as np
import pytest

from aardvark_imaging.carbon import engine as carbon_engine
from aardvark_imaging.electromagnetic import radar
from aardvark_imaging.hyperspectral import water
from aardvark_imaging.sonar.acoustics import absorption_db_per_km, sound_speed_mackenzie


def test_radar_carries_no_carbon_evidence():
    # the carbon engine's evidence channels are optical only; radar/EMI/acoustic are excluded by construction
    src = inspect.getsource(carbon_engine)
    channels = set(carbon_engine.WEIGHTS) if isinstance(carbon_engine.WEIGHTS, dict) else set()
    assert channels and not any(k.startswith(("radar", "emi", "em_", "sonar", "acoustic")) for k in channels)
    assert "carry no direct carbon information" in src


def test_radar_refuses_seawater_at_every_gpr_frequency():
    for f in (50e6, 100e6, 400e6, 1e9, 2.6e9):
        assert not radar.assess_path(f, 0.3, medium="seawater").feasible


def test_raman_dg_is_never_reported_as_concentration(survey):
    for r in survey.carbon_results:
        assert r.quantitative == []                 # no validated TOC/TIC model -> no concentrations
        assert r.quantitation_level.value in ("not_detected", "qualitative", "semi_quantitative")


def test_purity_and_grade_never_from_spectra_alone(survey):
    for rep in survey.grade_reports.values():
        assert rep.mineralogical_purity is None
        for el, g in rep.elemental_grade.items():
            if g is not None:
                assert "spectral" not in rep.elemental_grade_basis[el]


def test_hsi_classification_uses_only_water_transmissive_bands(survey):
    usable = water.usable_bands(survey.hsi_cube.wavelength_nm, 2 * survey.config.altitude_m, t_min=0.05)
    used = np.asarray(survey.hsi_classification.bands_used)
    assert used.dtype == bool and not np.any(used & ~usable)


def test_two_way_water_path_limits_vnir_at_survey_altitude(survey):
    wl = survey.hsi_cube.wavelength_nm
    T = water.transmission(wl, 2 * survey.config.altitude_m)
    assert T[np.argmin(np.abs(wl - 480))] > 0.5
    assert T[np.argmin(np.abs(wl - 760))] < 0.05      # strong O-H overtone absorption region


def test_swir_requires_contact_or_near_contact():
    assert float(water.max_standoff_m(np.array([1450.0]), t_min=0.02)[0]) < 0.002
    assert float(water.max_standoff_m(np.array([1200.0]), t_min=0.02)[0]) < 0.05


def test_abyssal_sound_speed_and_high_frequency_range_limit():
    c = sound_speed_mackenzie(1.5, 34.7, 4500.0)
    assert 1520 < c < 1545
    # Ainslie & McColm at 400 kHz, 2 C, 4.5 km: ~68 dB/km, i.e. >25 dB two-way over 200 m —
    # why the high-frequency imaging array is a short-range (metres) instrument
    a = float(absorption_db_per_km(400.0, T=2.0, z_km=4.5))
    assert 55 < a < 80 and 2 * 0.2 * a > 25


def test_emi_is_material_contrast_only(survey):
    e = survey.emi
    assert "apparent_conductivity_s_m" in e and not any("carbon" in k or "grade" in k for k in e)


def test_mass_and_abundance_are_consistent(survey):
    m = survey.seabed_map
    total_map_kg = np.nansum(m.layers["nodule_abundance_kg_m2"].values) * m.grid.cell_area_m2
    total_nod_kg = sum(rec.observations[-1].measurements["mass_g"]["value"] for rec in survey.registry.records.values()) / 1000
    assert total_map_kg == pytest.approx(total_nod_kg, rel=0.02)


def test_simulated_flag_survives_every_stage(survey):
    from aardvark_imaging.core.provenance import DataOrigin
    origins = {survey.hsi_cube.provenance.origin, survey.seabed_map.data_origin,
               *(r.data_origin for r in survey.carbon_results)}
    assert origins == {DataOrigin.SIMULATED}
