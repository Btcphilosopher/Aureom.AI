"""Shared fixtures. The simulated survey is expensive (~3 s), so it is built
once per session and shared read-only by the tests that need it."""
from __future__ import annotations

import numpy as np
import pytest


@pytest.fixture(scope="session")
def survey():
    from aardvark_imaging.simulation.survey import fast_config, run_survey
    return run_survey(fast_config(21))


@pytest.fixture(scope="session")
def survey_seed7():
    from aardvark_imaging.simulation.survey import fast_config, run_survey
    return run_survey(fast_config(7))


@pytest.fixture(scope="session")
def api_client(tmp_path_factory):
    from fastapi.testclient import TestClient
    from aardvark_imaging.api.app import create_app
    app = create_app(seed=21, data_dir=str(tmp_path_factory.mktemp("api")), api_key="")
    with TestClient(app) as c:
        yield c


@pytest.fixture
def rng():
    return np.random.default_rng(12345)
