"""End-to-end data paths: FPGA packet stream -> ring -> raw spool -> recovery ->
decode -> cube assembly, and the simulated survey's product consistency."""
from __future__ import annotations

import json

import numpy as np
import pytest

from aardvark_imaging.acquisition import sfp
from aardvark_imaging.acquisition.ring import ArrayRing, RingReader
from aardvark_imaging.acquisition.spool import RawSpool, iter_spool, recover_segment
from aardvark_imaging.core.provenance import DataOrigin
from aardvark_imaging.hyperspectral.cube import assemble_pushbroom


def hsi_packets(raw, start_seq=0):
    L, S, B = raw.shape
    out, seq = [], start_seq
    for li in range(L):
        for b in range(B):
            out.append(sfp.encode_packet(sensor_uid=0x10, packet_type={v: k for k, v in sfp.TYPE_NAMES.items()}["HSI_ROW"],
                                         flags=sfp.flags_value("SIMULATED"), seq=seq, frame=li, timestamp=1000 * li + b,
                                         row=b, meta=(1 << 31) | (b << 16) | S, payload=sfp.pack_pixels(raw[li, :, b])))
            seq += 1
    return out


def test_stream_to_cube_with_drop_and_power_loss(tmp_path, rng):
    raw = rng.integers(0, 4000, (12, 32, 6)).astype(np.uint16)
    raw[4, 5, 2] = 0xFFFF                                   # saturated sentinel
    pk = hsi_packets(raw)
    ring = ArrayRing(4096)
    rd = RingReader(ring)
    spool = RawSpool(tmp_path, segment_bytes=1 << 20)
    dropped = {20}                                          # FPGA drops one packet (ring full at that instant)
    for i, w in enumerate(pk):
        if i in dropped:
            continue
        assert ring.write_packet(w, rd.rd_ptr)
        for p in rd.poll(ring.wr_ptr):
            spool.write(RingReaderRepack(p))
    spool.flush()
    seg = spool.current_segment
    spool.close()
    with open(seg, "ab") as fh:                             # torn trailing record after power loss
        fh.write(b"\x00\x01\x02")
    recover_segment(seg)
    words = np.concatenate([w for _, w in iter_spool(tmp_path)])
    res = sfp.decode_words(words)
    assert not res.errors and len(res.packets) == len(pk) - 1
    assert rd.dropped_packets == 1
    cube = assemble_pushbroom(res.packets, n_samples=32, n_bands=6, wavelength_nm=np.linspace(450, 700, 6))
    li, b = divmod(20, 6)
    assert cube.missing[li, :, b].all()                     # dropped row is masked, never invented
    ok = ~cube.missing & ~cube.saturated
    np.testing.assert_array_equal(cube.raw.values[ok], raw[ok])
    assert cube.saturated[4, 5, 2]
    assert cube.provenance.origin == DataOrigin.SIMULATED


def RingReaderRepack(p):
    return sfp.encode_packet(sensor_uid=p.sensor_uid, packet_type=p.packet_type, flags=p.flags, seq=p.seq, frame=p.frame,
                             timestamp=p.timestamp, row=p.row, meta=p.meta, payload=p.payload)


class TestSurveyProducts:
    def test_everything_is_labelled_simulated(self, survey):
        assert survey.hsi_cube.provenance.origin == DataOrigin.SIMULATED
        assert survey.seabed_map.data_origin == DataOrigin.SIMULATED
        assert all(r.data_origin == DataOrigin.SIMULATED for r in survey.carbon_results)
        assert all(rec.data_origin == DataOrigin.SIMULATED for rec in survey.registry.records.values())

    def test_raw_retained_alongside_processed(self, survey):
        c = survey.hsi_cube
        assert c.raw.values.dtype == np.uint16 and c.raw.shape == c.data.shape
        assert len(c.history) >= 2

    def test_summary_is_json_serialisable(self, survey):
        json.dumps(survey.summary(), default=float, allow_nan=True)

    def test_registry_ids_unique_and_map_consistent(self, survey):
        ids = list(survey.registry.records)
        assert len(ids) == len(set(ids))
        m = survey.seabed_map.layers
        dens = np.nansum(m["nodule_density_per_m2"].values) * survey.seabed_map.grid.cell_area_m2
        assert dens == pytest.approx(len(ids), rel=0.02)

    def test_grade_reports_refuse_or_use_assays(self, survey):
        for nid, rep in survey.grade_reports.items():
            assert rep.mineralogical_purity is None
            for el, g in rep.elemental_grade.items():
                if g is not None:
                    assert g.origin in (DataOrigin.LAB_VALIDATED, DataOrigin.SIMULATED, DataOrigin.ESTIMATED)
                    assert rep.elemental_grade_basis[el].startswith(("linked assay", "assay-calibrated"))

    def test_deterministic_for_a_seed(self, survey):
        from aardvark_imaging.simulation.survey import fast_config, run_survey
        again = run_survey(fast_config(21))
        assert again.validation["nodule_detection"] == survey.validation["nodule_detection"]
        assert [r.top_class for r in again.carbon_results] == [r.top_class for r in survey.carbon_results]
