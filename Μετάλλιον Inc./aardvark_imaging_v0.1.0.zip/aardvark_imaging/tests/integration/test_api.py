"""FastAPI service end to end: every endpoint, error handling, auth, WebSocket
telemetry and raw spooling during live (simulated) acquisition."""
from __future__ import annotations

import json
import math
import time

import pytest
from fastapi.testclient import TestClient

from aardvark_imaging.api.app import create_app


def finite_json(obj):
    """No NaN/Infinity may leak into JSON (browsers reject it)."""
    s = json.dumps(obj, allow_nan=False)
    return bool(s)


def test_status_and_labels(api_client):
    s = api_client.get("/api/v1/system/status").json()
    assert s["data_origin"] == "simulated" and s["mode"] == "simulation"
    assert any("SIMULATED" in n for n in s["notices"])
    assert s["nodule_count"] > 50


@pytest.mark.parametrize("path", ["/api/v1/sensors", "/api/v1/sensors/health", "/api/v1/acquisition/status",
                                  "/api/v1/spectral/cube", "/api/v1/spectral/cube?band=3", "/api/v1/spectral/scan?line=5&sample=7",
                                  "/api/v1/spectral/raman/examples", "/api/v1/carbon/map", "/api/v1/nodules",
                                  "/api/v1/sonar/reconstruct", "/api/v1/electromagnetic/analyse", "/api/v1/geology/map",
                                  "/api/v1/calibration", "/api/v1/validation", "/healthz"])
def test_get_endpoints(api_client, path):
    r = api_client.get(path)
    assert r.status_code == 200, r.text
    assert finite_json(r.json())


def test_em_interpretation_is_not_carbon(api_client):
    e = api_client.get("/api/v1/electromagnetic/analyse").json()
    assert "not a carbon" in e["interpretation"]


def test_nodule_detail_keeps_grade_purity_mass_separate(api_client):
    nid = api_client.get("/api/v1/nodules?limit=1").json()["nodules"][0]["nodule_id"]
    d = api_client.get(f"/api/v1/nodules/{nid}").json()
    g = d["grade_report"]
    assert set(g) >= {"elemental_grade", "mineralogical_purity", "physical_mass_g", "recoverable_metal_g"}
    assert g["mineralogical_purity"] is None and "XRD" in g["purity_basis"]


def test_errors(api_client):
    assert api_client.get("/api/v1/nodules/NOPE").status_code == 404
    assert api_client.get("/api/v1/spectral/scan?line=99999&sample=0").status_code == 422
    assert api_client.get("/api/v1/spectral/cube?band=9999").status_code == 422
    assert api_client.post("/api/v1/carbon/analyse", json={}).status_code == 422
    assert api_client.post("/api/v1/carbon/analyse", json={"target_id": "nope"}).status_code == 404
    assert api_client.post("/api/v1/acquisition/start", json={"line_rate_hz": 5000}).status_code == 422
    assert api_client.post("/api/v1/acquisition/start", json={"sensors": ["NOPE"]}).status_code in (409, 422)
    assert api_client.post("/api/v1/minerals/classify", json={"wavelength_nm": [500, 600], "reflectance": [0.1]}).status_code == 422


def test_carbon_analyse_by_target_and_spectrum(api_client):
    tid = api_client.get("/api/v1/carbon/map").json()["points"][0]["target_id"]
    r = api_client.post("/api/v1/carbon/analyse", json={"target_id": tid}).json()
    assert r["target_id"] == tid and r["quantitative"] == []


def test_mineral_classify(api_client):
    wl = list(range(400, 801, 10))
    r = api_client.post("/api/v1/minerals/classify", json={"wavelength_nm": wl, "reflectance": [0.05] * len(wl),
                                                           "altitude_m": 1.5}).json()
    assert "XRF" in r["note"] or "assay" in r["note"]


def test_fusion_endpoint_records_conflict(api_client):
    body = {"classes": ["a", "b"], "opinions": [
        {"channel": "vnir", "probabilities": {"a": 0.9, "b": 0.1}, "quality": 1.0, "provenance_id": "x"},
        {"channel": "raman", "probabilities": {"a": 0.1, "b": 0.9}, "quality": 1.0, "provenance_id": "y"}]}
    r = api_client.post("/api/v1/fusion/process", json=body).json()
    assert r["conflicts"]


@pytest.mark.parametrize("fmt", ["geojson_nodules", "geojson_track", "esri_ascii", "ply", "csv_nodules", "netcdf", "json_map"])
def test_exports(api_client, fmt):
    r = api_client.post("/api/v1/export", json={"format": fmt})
    assert r.status_code == 200 and len(r.content) > 50


def test_live_acquisition_websocket_and_spool(tmp_path):
    app = create_app(seed=21, data_dir=str(tmp_path), api_key="")
    with TestClient(app) as c:
        with c.websocket_connect("/api/v1/stream/telemetry") as ws:
            hello = ws.receive_json()
            assert hello["type"] == "hello" and hello["data_origin"] == "simulated"
            r = c.post("/api/v1/acquisition/start", json={"line_rate_hz": 50, "duration_s": 1.5})
            assert r.status_code == 200 and r.json()["acquiring"]
            assert c.post("/api/v1/acquisition/start", json={}).status_code == 409    # already running
            msgs = [ws.receive_json() for _ in range(6)]
            assert any(m.get("type") == "telemetry" for m in msgs)
        deadline = time.time() + 10
        while c.get("/api/v1/acquisition/status").json()["acquiring"] and time.time() < deadline:
            time.sleep(0.1)
        st = c.post("/api/v1/acquisition/stop").json()
        assert st["packets"] > 20 and st["sequence_gaps"] == 0 and st["corrupt_packets"] == 0
        assert st["bytes_recorded"] > 0
    from aardvark_imaging.acquisition.spool import iter_spool
    from aardvark_imaging.acquisition import sfp
    import numpy as np
    words = np.concatenate([w for _, w in iter_spool(tmp_path / "spool")])
    res = sfp.decode_words(words)
    assert len(res.packets) == st["packets"] and not res.errors
    assert all(p.simulated for p in res.packets)


def test_api_key_enforced(tmp_path):
    app = create_app(seed=21, data_dir=str(tmp_path), api_key="s3cret")
    with TestClient(app) as c:
        assert c.get("/api/v1/sensors").status_code == 401
        assert c.get("/api/v1/sensors", headers={"X-API-Key": "s3cret"}).status_code == 200
        assert c.get("/healthz").status_code == 200
        with pytest.raises(Exception):
            with c.websocket_connect("/api/v1/stream/telemetry") as ws:
                ws.receive_json()
        with c.websocket_connect("/api/v1/stream/telemetry?api_key=s3cret") as ws:
            assert ws.receive_json()["type"] == "hello"


def test_workstation_served(api_client):
    r = api_client.get("/")
    assert r.status_code == 200 and "Aardvark Imaging" in r.text
    assert api_client.get("/js/app.js").status_code == 200
    assert not math.isnan(0.0)


def test_sql_persistence_when_configured(tmp_path, monkeypatch):
    monkeypatch.setenv("AARDVARK_DB_URL", f"sqlite:///{tmp_path / 'a.db'}")
    for _ in range(2):          # second start: idempotent, nothing duplicated
        app = create_app(seed=21, data_dir=str(tmp_path / "d"), api_key="")
        with TestClient(app) as c:
            st = c.get("/api/v1/storage/status").json()["database"]
            assert st["enabled"] and "error" not in st, st
    assert st["survey_stored_now"] is False and st["nodule_rows"] > 50
