# Calibration data

Empty on purpose: no instrument has been calibrated. Measured calibration records (JSON matching `data/schemas/calibration_record.schema.json`) and their array files belong here, referenced by `array_refs`. See docs/calibration.md for the laboratory programme.
