# Data schemas

The schemas fall into two groups.

**Generated JSON Schemas.** `scripts/export_schemas.py` generates these from the pydantic models; do not edit by hand.

| Schema | Record |
|---|---|
| `provenance.schema.json` | data origin, source, software, calibration IDs, parent records, parameters |
| `estimate.schema.json` | value with std, 95 % interval, units, origin, method; used for every derived quantity |
| `calibration_record.schema.json` | versioned, immutable calibration with certificate and validity window |
| `assay_record.schema.json` / `xrd_record.schema.json` | laboratory results that link to nodules |
| `nodule_observation.schema.json` / `nodule_record.schema.json` | persistent nodule identity and observation history |
| `carbon_characterisation.schema.json` | carbon class probabilities, evidence, quantitation level, refusals |
| `grade_report.schema.json` | grade, purity, mass and recoverable metal, kept separate |

**Binary and storage formats.** These are specified elsewhere:

* **SFP1 packet stream:** `hardware/silica_flux/architecture/README.md` §4.5. The header layout and flags are generated into `register_map.json` and `aardvark_ssa_regs.h`.
* **Raw spool (`raw_*.sfp`):**
  * A file header holds the magic, a version and a JSON metadata block.
  * Each record holds a magic, a word count, the host time, the packet words and a CRC-32. See `backend/acquisition/spool.py`.
* **Cube products:**
  * Zarr or HDF5 with a `raw` group (written once) and named product groups.
  * Provenance is stored as attributes. See `backend/storage/cube_store.py`.

`data_origin` takes one of four values: `simulated`, `measured`, `estimated` or `lab_validated`. The value is carried by every record and every map layer. When origins are combined, the least trustworthy one wins (`simulated` > `estimated` > `measured` > `lab_validated`).
