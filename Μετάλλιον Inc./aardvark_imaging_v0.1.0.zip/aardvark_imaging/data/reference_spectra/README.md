# Reference spectra

Empty on purpose. Measured spectral libraries (USGS splib07 ASCII, RRUFF Raman, in-house measurements of XRD-characterised samples) go here and load with `mineralogy/library.py` (`load_usgs_splib07_ascii`, `load_rruff_raman`). The built-in `parametric_vnir_library` is SIMULATED and only for development.
