# FPGA board profile (Zynq UltraScale+ reference target)

Not deployable yet. This profile records the integration steps; none of them have been executed.

1. **Block design.** Create a Vivado block design containing:
   * the PS;
   * an AXI HP slave port, used by the `sf_dma_controller` master;
   * an AXI GP master port, connected to `s_axil_*`;
   * `pl_clk0` = 100 MHz as `clk`.
2. **Vendor IP.** Add the board wrapper:
   * a MIPI CSI-2 RX subsystem → `ms_*` AXI4-Stream (MS0 / RGB0);
   * ISERDES for the HSI LVDS lanes and the acoustic ADC;
   * IOBUF for I2C.
3. **Constraints.** Fill the pin and I/O-standard sections of `hardware/silica_flux/timing/sf_sensor_top.xdc`, plus I/O delays from the part datasheets. Run `report_cdc` and close timing.
4. **Linux.**
   * Reserve a 16 MiB physically contiguous ring (CMA).
   * Expose it and the register window through UIO.
   * Run `aardvark` on the PS (or the vehicle computer) using `acquisition.ring.MmapRing` on the UIO device.
5. **Bring-up order.**
   1. ID/VERSION/SCRATCH register test.
   2. Timestamp + PPS.
   3. Test-pattern mode, decoded by `aardvark decode`.
   4. One sensor at a time.
   5. Laser last, after the interlock review.
