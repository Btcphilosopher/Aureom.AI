import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  OnDestroy,
  signal,
  computed,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';

export interface CodeNode {
  name: string;
  path: string;
  type: 'file' | 'directory';
  size?: number;
  children?: CodeNode[];
}

export interface BenchmarkItem {
  task: string;
  pure_r_ms: number;
  rcpp_armadillo_ms: number;
  speedup_factor: number;
  memory_mb: number;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class App implements OnInit, OnDestroy {
  private http = inject(HttpClient);
  private timer: ReturnType<typeof setInterval> | null = null;

  // Active navigation tab
  activeTab = signal<'overview' | 'hyperspectral' | 'raman' | 'sonar' | 'nodules' | 'geostats' | 'kotlin_bridge' | 'codebase' | 'validation'>('overview');

  // Real-time telemetry signals
  telemetry = signal({
    depth_m: 4218.45,
    altitude_m: 4.25,
    heading_deg: 248.5,
    pitch_deg: -1.2,
    roll_deg: 0.4,
    latitude: 12.483120,
    longitude: -135.291480,
    sound_velocity_mps: 1528.4,
    salinity_psu: 34.68,
    temperature_c: 1.42,
    pressure_bar: 428.1,
    oxygen_umol_kg: 142.6,
    fpga_buffer_pct: 14.8,
    fpga_bandwidth_mbps: 642.0,
    fpga_dropped_packets: 0,
    nodules_counted: 284150,
    survey_km: 48.6,
    estimated_tonnage: 3480.0
  });

  // Hyperspectral interactive state
  selectedWavelength = signal<number>(650);
  samThresholdRad = signal<number>(0.12);
  sgDerivative = signal<number>(1);
  continuumRemoval = signal<boolean>(true);
  hyperspectralRunning = signal<boolean>(false);
  hyperspectralResults = signal<Record<string, unknown> | null>(null);

  // Raman interactive state
  laserPowerMw = signal<number>(45.0);
  integrationTimeMs = signal<number>(1500);
  cosmicFilterActive = signal<boolean>(true);
  ramanRunning = signal<boolean>(false);
  ramanResults = signal<Record<string, unknown> | null>(null);

  // Sonar interactive state
  soundSpeedInput = signal<number>(1528.4);
  swathAngleDeg = signal<number>(140);
  gridResolutionM = signal<number>(0.25);
  sonarRunning = signal<boolean>(false);
  sonarResults = signal<Record<string, unknown> | null>(null);

  // Nodule detection interactive state
  selectedNoduleId = signal<string>('NOD-01');
  minDiameterCutoff = signal<number>(1.5);
  noduleDetectRunning = signal<boolean>(false);
  noduleResults = signal<Record<string, unknown> | null>(null);

  // Geostatistics & Kriging state
  variogramModel = signal<'Sph' | 'Exp' | 'Gau'>('Sph');
  krigingNugget = signal<number>(0.45);
  krigingSill = signal<number>(4.82);
  krigingRange = signal<number>(145.0);
  krigingRunning = signal<boolean>(false);
  krigingResults = signal<Record<string, unknown> | null>(null);

  // Kotlin API Bridge state
  selectedApiEndpoint = signal<string>('telemetry');
  apiCallRunning = signal<boolean>(false);
  apiLatencyMs = signal<number>(18);
  apiResponseJson = signal<string>('');
  apiHttpStatus = signal<number>(200);

  // R Codebase explorer state
  codeTree = signal<CodeNode[]>([]);
  selectedFilePath = signal<string>('R/hyperspectral/analysis_engine.R');
  selectedFileContent = signal<string>('');
  codeLoading = signal<boolean>(false);

  // Benchmarks state
  benchmarks = signal<BenchmarkItem[]>([]);

  // Computed properties
  idIgRatio = computed(() => {
    const p = this.laserPowerMw();
    return +(0.908 + (p - 45) * 0.001).toFixed(3);
  });

  crystalliteSizeLa = computed(() => {
    const ratio = this.idIgRatio();
    return +(19.2 / Math.max(0.1, ratio)).toFixed(1);
  });

  nodulesData = signal([
    {
      id: 'NOD-01',
      x: 180,
      y: 140,
      r: 32,
      feret_max_cm: 7.42,
      feret_min_cm: 5.18,
      area_cm2: 30.19,
      circ: 0.912,
      wet_mass_g: 186.9,
      class: 'todorokite_rich_nodule',
      mn: 29.8,
      ni: 1.38,
      cu: 1.15,
      co: 0.23,
      fe: 5.82
    },
    {
      id: 'NOD-02',
      x: 320,
      y: 190,
      r: 40,
      feret_max_cm: 9.15,
      feret_min_cm: 6.84,
      area_cm2: 49.14,
      circ: 0.898,
      wet_mass_g: 388.0,
      class: 'vernadite_crust_dominant',
      mn: 27.4,
      ni: 1.22,
      cu: 0.98,
      co: 0.28,
      fe: 6.90
    },
    {
      id: 'NOD-03',
      x: 120,
      y: 280,
      r: 24,
      feret_max_cm: 5.20,
      feret_min_cm: 3.95,
      area_cm2: 16.12,
      circ: 0.925,
      wet_mass_g: 68.4,
      class: 'todorokite_rich_nodule',
      mn: 30.2,
      ni: 1.44,
      cu: 1.21,
      co: 0.21,
      fe: 5.40
    },
    {
      id: 'NOD-04',
      x: 440,
      y: 120,
      r: 30,
      feret_max_cm: 6.80,
      feret_min_cm: 4.82,
      area_cm2: 25.75,
      circ: 0.905,
      wet_mass_g: 138.2,
      class: 'vernadite_crust_dominant',
      mn: 28.9,
      ni: 1.34,
      cu: 1.10,
      co: 0.24,
      fe: 6.05
    },
    {
      id: 'NOD-05',
      x: 270,
      y: 310,
      r: 48,
      feret_max_cm: 11.20,
      feret_min_cm: 8.10,
      area_cm2: 71.25,
      circ: 0.880,
      wet_mass_g: 684.5,
      class: 'vernadite_crust_dominant',
      mn: 26.8,
      ni: 1.18,
      cu: 0.92,
      co: 0.30,
      fe: 7.15
    },
    {
      id: 'NOD-06',
      x: 420,
      y: 290,
      r: 22,
      feret_max_cm: 4.50,
      feret_min_cm: 3.40,
      area_cm2: 12.01,
      circ: 0.938,
      wet_mass_g: 44.8,
      class: 'todorokite_rich_nodule',
      mn: 31.0,
      ni: 1.48,
      cu: 1.25,
      co: 0.20,
      fe: 5.10
    }
  ]);

  selectedNodule = computed(() => {
    return this.nodulesData().find(n => n.id === this.selectedNoduleId()) || this.nodulesData()[0];
  });

  ngOnInit() {
    this.startTelemetryStream();
    this.loadCodebaseTree();
    this.loadFileContent(this.selectedFilePath());
    this.loadBenchmarks();
  }

  ngOnDestroy() {
    if (this.timer) clearInterval(this.timer);
  }

  // Typed input handlers
  onWavelengthInput(e: Event) {
    const target = e.target as HTMLInputElement;
    this.selectedWavelength.set(+target.value);
  }

  onSamThresholdInput(e: Event) {
    const target = e.target as HTMLInputElement;
    this.samThresholdRad.set(+target.value);
  }

  onLaserPowerInput(e: Event) {
    const target = e.target as HTMLInputElement;
    this.laserPowerMw.set(+target.value);
  }

  onIntegrationTimeInput(e: Event) {
    const target = e.target as HTMLInputElement;
    this.integrationTimeMs.set(+target.value);
  }

  onSoundSpeedInput(e: Event) {
    const target = e.target as HTMLInputElement;
    this.soundSpeedInput.set(+target.value);
  }

  onSwathAngleInput(e: Event) {
    const target = e.target as HTMLInputElement;
    this.swathAngleDeg.set(+target.value);
  }

  onKrigingNuggetInput(e: Event) {
    const target = e.target as HTMLInputElement;
    this.krigingNugget.set(+target.value);
  }

  onKrigingSillInput(e: Event) {
    const target = e.target as HTMLInputElement;
    this.krigingSill.set(+target.value);
  }

  onKrigingRangeInput(e: Event) {
    const target = e.target as HTMLInputElement;
    this.krigingRange.set(+target.value);
  }

  startTelemetryStream() {
    this.timer = setInterval(() => {
      const now = Date.now();
      const wave = Math.sin(now / 3000);
      this.telemetry.update(curr => ({
        ...curr,
        depth_m: +(4218.45 + wave * 0.12).toFixed(2),
        altitude_m: +(4.25 - wave * 0.08).toFixed(2),
        heading_deg: +(248.5 + Math.sin(now / 6000) * 0.4).toFixed(1),
        nodules_counted: curr.nodules_counted + Math.floor(Math.random() * 2),
        fpga_buffer_pct: +(14.8 + Math.sin(now / 2000) * 0.6).toFixed(1)
      }));
    }, 1500);
  }

  setTab(tab: 'overview' | 'hyperspectral' | 'raman' | 'sonar' | 'nodules' | 'geostats' | 'kotlin_bridge' | 'codebase' | 'validation') {
    this.activeTab.set(tab);
  }

  // --- HYPERSPECTRAL METHODS ---
  runHyperspectralAnalysis() {
    this.hyperspectralRunning.set(true);
    this.http.post<Record<string, unknown>>('/api/v1/spectral/analyse', {
      cube_id: 'CUBE-CCZ-20261103-004',
      classifier: 'sam',
      angle_threshold_rad: this.samThresholdRad()
    }).subscribe({
      next: (res) => {
        this.hyperspectralResults.set(res);
        this.hyperspectralRunning.set(false);
      },
      error: () => this.hyperspectralRunning.set(false)
    });
  }

  // --- RAMAN METHODS ---
  runRamanAnalysis() {
    this.ramanRunning.set(true);
    this.http.post<Record<string, unknown>>('/api/v1/raman/analyse', {
      spectrum_id: 'RAMAN-CCZ-20261103-018',
      laser_power_mw: this.laserPowerMw(),
      integration_time_ms: this.integrationTimeMs()
    }).subscribe({
      next: (res) => {
        this.ramanResults.set(res);
        this.ramanRunning.set(false);
      },
      error: () => this.ramanRunning.set(false)
    });
  }

  // --- SONAR METHODS ---
  runSonarProcessing() {
    this.sonarRunning.set(true);
    this.http.post<Record<string, unknown>>('/api/v1/sonar/process', {
      ping_batch_id: 'PING-BATCH-20261103-512',
      sound_speed_mps: this.soundSpeedInput()
    }).subscribe({
      next: (res) => {
        this.sonarResults.set(res);
        this.sonarRunning.set(false);
      },
      error: () => this.sonarRunning.set(false)
    });
  }

  // --- NODULE METHODS ---
  selectNodule(id: string) {
    this.selectedNoduleId.set(id);
  }

  runNoduleDetection() {
    this.noduleDetectRunning.set(true);
    this.http.post<Record<string, unknown>>('/api/v1/nodules/detect', {
      frame_id: 'FRAME-20261103-08241',
      min_diameter_cm: this.minDiameterCutoff()
    }).subscribe({
      next: (res) => {
        this.noduleResults.set(res);
        this.noduleDetectRunning.set(false);
      },
      error: () => this.noduleDetectRunning.set(false)
    });
  }

  // --- GEOSTATISTICS & KRIGING METHODS ---
  runKriging() {
    this.krigingRunning.set(true);
    this.http.post<Record<string, unknown>>('/api/v1/mapping/generate', {
      mission_id: 'MISSION-CCZ-2026-ALPHA',
      variable: 'abundance_kg_m2',
      variogram_model: this.variogramModel()
    }).subscribe({
      next: (res) => {
        this.krigingResults.set(res);
        this.krigingRunning.set(false);
      },
      error: () => this.krigingRunning.set(false)
    });
  }

  // --- KOTLIN API BRIDGE TESTER ---
  executeApiTest(endpoint: string) {
    this.selectedApiEndpoint.set(endpoint);
    this.apiCallRunning.set(true);
    const start = performance.now();

    let req$;
    switch (endpoint) {
      case 'health':
        req$ = this.http.get('/api/v1/health');
        break;
      case 'sensors':
        req$ = this.http.get('/api/v1/sensors');
        break;
      case 'telemetry':
        req$ = this.http.get('/api/v1/sensors/telemetry/latest');
        break;
      case 'nodules':
        req$ = this.http.post('/api/v1/nodules/detect', { frame_id: 'FRAME-20261103-08241' });
        break;
      case 'raman':
        req$ = this.http.post('/api/v1/raman/analyse', { spectrum_id: 'RAMAN-CCZ-20261103-018' });
        break;
      case 'sonar':
        req$ = this.http.post('/api/v1/sonar/process', { ping_batch_id: 'PING-BATCH-20261103-512' });
        break;
      case 'kriging':
        req$ = this.http.post('/api/v1/mapping/generate', { mission_id: 'MISSION-CCZ-2026-ALPHA' });
        break;
      case 'benchmarks':
        req$ = this.http.get('/api/v1/diagnostics/benchmarks');
        break;
      default:
        req$ = this.http.get('/api/v1/health');
    }

    req$.subscribe({
      next: (data) => {
        this.apiLatencyMs.set(Math.round(performance.now() - start));
        this.apiHttpStatus.set(200);
        this.apiResponseJson.set(JSON.stringify(data, null, 2));
        this.apiCallRunning.set(false);
      },
      error: (err: { status?: number; error?: unknown; message?: string }) => {
        this.apiLatencyMs.set(Math.round(performance.now() - start));
        this.apiHttpStatus.set(err.status || 500);
        this.apiResponseJson.set(JSON.stringify(err.error || { error: err.message }, null, 2));
        this.apiCallRunning.set(false);
      }
    });
  }

  // --- CODEBASE TREE & VIEWER ---
  loadCodebaseTree() {
    this.http.get<{ root: string; tree: CodeNode[] }>('/api/v1/codebase/tree').subscribe({
      next: (data) => {
        if (data && data.tree && data.tree.length > 0) {
          this.codeTree.set(data.tree);
        } else {
          this.setFallbackCodeTree();
        }
      },
      error: () => this.setFallbackCodeTree()
    });
  }

  setFallbackCodeTree() {
    this.codeTree.set([
      {
        name: 'api',
        path: 'api',
        type: 'directory',
        children: [
          { name: 'plumber.R', path: 'api/plumber.R', type: 'file', size: 1850 },
          {
            name: 'routes',
            path: 'api/routes',
            type: 'directory',
            children: [
              { name: 'sensors.R', path: 'api/routes/sensors.R', type: 'file', size: 3120 },
              { name: 'imaging.R', path: 'api/routes/imaging.R', type: 'file', size: 2150 },
              { name: 'spectral.R', path: 'api/routes/spectral.R', type: 'file', size: 2840 },
              { name: 'carbon.R', path: 'api/routes/carbon.R', type: 'file', size: 3290 },
              { name: 'sonar.R', path: 'api/routes/sonar.R', type: 'file', size: 2740 },
              { name: 'nodules.R', path: 'api/routes/nodules.R', type: 'file', size: 4180 },
              { name: 'mapping.R', path: 'api/routes/mapping.R', type: 'file', size: 3410 },
              { name: 'missions.R', path: 'api/routes/missions.R', type: 'file', size: 2950 },
              { name: 'diagnostics.R', path: 'api/routes/diagnostics.R', type: 'file', size: 2480 }
            ]
          },
          {
            name: 'middleware',
            path: 'api/middleware',
            type: 'directory',
            children: [
              { name: 'auth_cors.R', path: 'api/middleware/auth_cors.R', type: 'file', size: 1420 }
            ]
          }
        ]
      },
      {
        name: 'R',
        path: 'R',
        type: 'directory',
        children: [
          {
            name: 'acquisition',
            path: 'R/acquisition',
            type: 'directory',
            children: [
              { name: 'sensor_manager.R', path: 'R/acquisition/sensor_manager.R', type: 'file', size: 1980 },
              { name: 'telemetry_ingest.R', path: 'R/acquisition/telemetry_ingest.R', type: 'file', size: 2410 }
            ]
          },
          {
            name: 'optical',
            path: 'R/optical',
            type: 'directory',
            children: [
              { name: 'underwater_enhancement.R', path: 'R/optical/underwater_enhancement.R', type: 'file', size: 2140 },
              { name: 'feature_extraction.R', path: 'R/optical/feature_extraction.R', type: 'file', size: 1250 }
            ]
          },
          {
            name: 'hyperspectral',
            path: 'R/hyperspectral',
            type: 'directory',
            children: [
              { name: 'calibration.R', path: 'R/hyperspectral/calibration.R', type: 'file', size: 1650 },
              { name: 'preprocessing.R', path: 'R/hyperspectral/preprocessing.R', type: 'file', size: 1820 },
              { name: 'analysis_engine.R', path: 'R/hyperspectral/analysis_engine.R', type: 'file', size: 2640 }
            ]
          },
          {
            name: 'raman',
            path: 'R/raman',
            type: 'directory',
            children: [
              { name: 'peak_fitting.R', path: 'R/raman/peak_fitting.R', type: 'file', size: 2450 }
            ]
          },
          {
            name: 'carbon',
            path: 'R/carbon',
            type: 'directory',
            children: [
              { name: 'characterisation.R', path: 'R/carbon/characterisation.R', type: 'file', size: 2890 }
            ]
          },
          {
            name: 'sonar',
            path: 'R/sonar',
            type: 'directory',
            children: [
              { name: 'bathymetry_engine.R', path: 'R/sonar/bathymetry_engine.R', type: 'file', size: 2280 },
              { name: 'backscatter_processing.R', path: 'R/sonar/backscatter_processing.R', type: 'file', size: 1950 }
            ]
          },
          {
            name: 'fusion',
            path: 'R/fusion',
            type: 'directory',
            children: [
              { name: 'sensor_fusion.R', path: 'R/fusion/sensor_fusion.R', type: 'file', size: 2410 }
            ]
          },
          {
            name: 'nodules',
            path: 'R/nodules',
            type: 'directory',
            children: [
              { name: 'detection_pipeline.R', path: 'R/nodules/detection_pipeline.R', type: 'file', size: 2940 },
              { name: 'grade_estimation.R', path: 'R/nodules/grade_estimation.R', type: 'file', size: 3180 }
            ]
          },
          {
            name: 'geostatistics',
            path: 'R/geostatistics',
            type: 'directory',
            children: [
              { name: 'variogram_kriging.R', path: 'R/geostatistics/variogram_kriging.R', type: 'file', size: 3450 },
              { name: 'density_analysis.R', path: 'R/geostatistics/density_analysis.R', type: 'file', size: 2180 }
            ]
          },
          {
            name: 'reconstruction',
            path: 'R/reconstruction',
            type: 'directory',
            children: [
              { name: 'mesh_generator.R', path: 'R/reconstruction/mesh_generator.R', type: 'file', size: 2100 }
            ]
          },
          {
            name: 'reporting',
            path: 'R/reporting',
            type: 'directory',
            children: [
              { name: 'scientific_report.R', path: 'R/reporting/scientific_report.R', type: 'file', size: 3200 }
            ]
          }
        ]
      },
      {
        name: 'src',
        path: 'src',
        type: 'directory',
        children: [
          { name: 'acquisition.cpp', path: 'src/acquisition.cpp', type: 'file', size: 1840 },
          { name: 'spectral.cpp', path: 'src/spectral.cpp', type: 'file', size: 2190 },
          { name: 'sonar.cpp', path: 'src/sonar.cpp', type: 'file', size: 1720 },
          { name: 'image_processing.cpp', path: 'src/image_processing.cpp', type: 'file', size: 1940 },
          { name: 'sensor_bridge.cpp', path: 'src/sensor_bridge.cpp', type: 'file', size: 1480 }
        ]
      },
      {
        name: 'database',
        path: 'database',
        type: 'directory',
        children: [
          { name: 'schema.sql', path: 'database/schema.sql', type: 'file', size: 5420 }
        ]
      },
      {
        name: 'tests',
        path: 'tests',
        type: 'directory',
        children: [
          { name: 'testthat.R', path: 'tests/testthat.R', type: 'file', size: 840 },
          {
            name: 'testthat',
            path: 'tests/testthat',
            type: 'directory',
            children: [
              { name: 'test_spectral.R', path: 'tests/testthat/test_spectral.R', type: 'file', size: 1420 },
              { name: 'test_raman_carbon.R', path: 'tests/testthat/test_raman_carbon.R', type: 'file', size: 1190 },
              { name: 'test_sonar.R', path: 'tests/testthat/test_sonar.R', type: 'file', size: 980 },
              { name: 'test_nodules.R', path: 'tests/testthat/test_nodules.R', type: 'file', size: 1350 },
              { name: 'test_geostatistics.R', path: 'tests/testthat/test_geostatistics.R', type: 'file', size: 1280 },
              { name: 'test_sensor_fusion.R', path: 'tests/testthat/test_sensor_fusion.R', type: 'file', size: 1150 }
            ]
          }
        ]
      },
      {
        name: 'docs',
        path: 'docs',
        type: 'directory',
        children: [
          { name: 'KOTLIN_ANDROID_CONTRACTS.kt', path: 'docs/KOTLIN_ANDROID_CONTRACTS.kt', type: 'file', size: 5120 },
          { name: 'SCIENTIFIC_VALIDATION_REPORT.md', path: 'docs/SCIENTIFIC_VALIDATION_REPORT.md', type: 'file', size: 6840 },
          { name: 'API_SPECIFICATION.md', path: 'docs/API_SPECIFICATION.md', type: 'file', size: 3410 },
          { name: 'DEPLOYMENT_GUIDE.md', path: 'docs/DEPLOYMENT_GUIDE.md', type: 'file', size: 2450 }
        ]
      },
      { name: 'Dockerfile', path: 'Dockerfile', type: 'file', size: 1250 },
      { name: 'renv.lock', path: 'renv.lock', type: 'file', size: 1680 },
      { name: 'README.md', path: 'README.md', type: 'file', size: 4200 }
    ]);
  }

  loadFileContent(filePath: string) {
    this.selectedFilePath.set(filePath);
    this.codeLoading.set(true);
    this.http.get<{ path: string; content: string; size: number }>(`/api/v1/codebase/file?path=${encodeURIComponent(filePath)}`).subscribe({
      next: (res) => {
        this.selectedFileContent.set(res.content);
        this.codeLoading.set(false);
      },
      error: () => {
        this.selectedFileContent.set(`# Source file: ${filePath}\n# View live in repository aardvark-subsea-r/${filePath}`);
        this.codeLoading.set(false);
      }
    });
  }

  downloadCurrentFile() {
    const content = this.selectedFileContent();
    const filename = this.selectedFilePath().split('/').pop() || 'aardvark_file.txt';
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  loadBenchmarks() {
    this.http.get<{ benchmark_environment: unknown; benchmarks: BenchmarkItem[] }>('/api/v1/diagnostics/benchmarks').subscribe({
      next: (data) => {
        if (data && data.benchmarks) {
          this.benchmarks.set(data.benchmarks);
        }
      }
    });
  }
}
