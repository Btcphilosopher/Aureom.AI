import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import fs from 'node:fs';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ==============================================================================
// AARDVARK SUBSEA R REST API ENDPOINTS (Compatible with Plumber / Kotlin Workstation)
// ==============================================================================

app.get('/api/v1/health', (req, res) => {
  res.json({
    status: 'HEALTHY',
    service: 'aardvark-subsea-r',
    version: '1.4.0',
    r_version: '4.4.1',
    uptime_seconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    components: {
      database_postgresql: 'CONNECTED_POSTGIS_3.4',
      fpga_sensor_bridge: 'STREAMING_NOMINAL',
      rcpp_acceleration: 'LOADED_ARMADILLO_ACTIVE',
      async_worker_pool: 'IDLE_4_READY'
    }
  });
});

app.get('/api/v1/sensors', (req, res) => {
  res.json({
    status: 'success',
    timestamp: new Date().toISOString(),
    count: 6,
    sensors: [
      {
        sensor_id: 'SNSR-OPT-HYPER-01',
        sensor_name: 'Aardvark HyperEye VNIR 400-1000nm',
        sensor_type: 'hyperspectral_imager',
        spectral_bands: 224,
        frame_rate_hz: 30.0,
        status: 'NOMINAL',
        fov_degrees: 42.5,
        calibration_id: 'CAL-VNIR-2026-Q1',
        interface: 'Silica Flux FPGA PCIe Gen3'
      },
      {
        sensor_id: 'SNSR-RAMAN-532',
        sensor_name: 'DeepOcean Raman In-Situ Spectrometer',
        sensor_type: 'raman_spectrometer',
        excitation_wavelength_nm: 532.0,
        spectral_range_cm1: [200, 3400],
        status: 'NOMINAL',
        integration_time_ms: 1200,
        calibration_id: 'CAL-RAM-532-2026',
        interface: 'Isolated High-Pressure Fiber Probe'
      },
      {
        sensor_id: 'SNSR-MBES-400K',
        sensor_name: 'Reson SeaBat T50-P Equivalent Multibeam',
        sensor_type: 'multibeam_sonar',
        frequency_khz: 400.0,
        beams: 512,
        swath_angle_deg: 140.0,
        status: 'ACTIVE',
        calibration_id: 'CAL-MBES-PATCH-2026',
        interface: 'GbE UDP Multicast'
      },
      {
        sensor_id: 'SNSR-SSS-900K',
        sensor_name: 'Dual-Frequency Side-Scan Sonar',
        sensor_type: 'sidescan_sonar',
        frequency_khz: [455.0, 900.0],
        range_per_side_m: 75.0,
        status: 'ACTIVE',
        interface: 'Direct High-Speed Serial / FPGA'
      },
      {
        sensor_id: 'SNSR-NAV-PHINS',
        sensor_name: 'iXblue Phins Subsea FOG IMU + DVL',
        sensor_type: 'inertial_navigation',
        heading_accuracy_deg: 0.01,
        roll_pitch_accuracy_deg: 0.005,
        status: 'LOCKED_DVL_BOTTOM',
        interface: 'RS-422 NMEA / Binary'
      },
      {
        sensor_id: 'SNSR-CTD-SBE49',
        sensor_name: 'Seabird FastCAT SBE49 CTD',
        sensor_type: 'environmental_ctd',
        sampling_rate_hz: 16.0,
        status: 'STREAMING',
        interface: 'RS-232'
      }
    ]
  });
});

app.get('/api/v1/sensors/telemetry/latest', (req, res) => {
  const depthNoise = (Math.sin(Date.now() / 4000) * 0.15);
  res.json({
    timestamp: new Date().toISOString(),
    mission_id: 'MISSION-CCZ-2026-ALPHA',
    vehicle_id: 'AUV-AARDVARK-DEEPEXPLORER-04',
    navigation: {
      latitude: 12.483120 + (Math.sin(Date.now() / 100000) * 0.0001),
      longitude: -135.291480 + (Math.cos(Date.now() / 100000) * 0.0001),
      crs: 'EPSG:4326',
      depth_m: +(4218.45 + depthNoise).toFixed(2),
      altitude_m: +(4.25 - depthNoise * 0.5).toFixed(2),
      heading_deg: +(248.5 + Math.sin(Date.now() / 5000) * 0.8).toFixed(1),
      pitch_deg: -1.2,
      roll_deg: 0.4,
      surge_velocity_ms: 0.85,
      position_uncertainty_sd_m: 0.18
    },
    environment: {
      sound_velocity_mps: 1528.4,
      salinity_psu: 34.68,
      water_temperature_c: 1.42,
      dissolved_oxygen_umol_kg: 142.6,
      turbidity_ntu: 0.12,
      ambient_pressure_bar: 428.1
    },
    fpga_bus: {
      link_state: 'SYNCED',
      buffer_utilization_pct: 14.8,
      dropped_packets: 0,
      bandwidth_mbps: 642.0
    }
  });
});

app.post('/api/v1/imaging/process', (req, res) => {
  const { frame_id = 'FRAME-20261103-08241', method = 'jaffe_mcglamery' } = req.body || {};
  res.json({
    status: 'SUCCESS',
    frame_id,
    processing_method: method,
    parameters: {
      dark_subtraction: true,
      flat_field_applied: true,
      water_attenuation_beta: { r: 0.28, g: 0.065, b: 0.045 },
      clahe_clip_limit: 2.5
    },
    optical_quality_metrics: {
      uiqm: 3.84,
      uciqe: 0.612,
      snr_db: 34.8,
      contrast_gain: 1.68
    },
    output_reference: `data/processed/opt_${frame_id}.tif`,
    algorithm_version: 'Aardvark-OptiSea-v2.1',
    processing_time_ms: 48.2
  });
});

app.post('/api/v1/spectral/analyse', (req, res) => {
  const { cube_id = 'CUBE-CCZ-20261103-004', classifier = 'sam', angle_threshold_rad = 0.12 } = req.body || {};
  res.json({
    status: 'SUCCESS',
    job_id: `JOB-SPEC-${Date.now()}`,
    cube_id,
    bands_processed: 220,
    wavelength_range_nm: [420, 980],
    classifier_used: String(classifier).toUpperCase(),
    preprocessing: {
      dark_subtracted: true,
      white_reference_normalised: true,
      bad_bands_masked: [1, 2, 223, 224],
      savitzky_golay: { window: 11, poly_order: 2, derivative: 1 },
      continuum_removal: true,
      threshold_rad_applied: angle_threshold_rad
    },
    classification_summary: {
      nodule_coverage_pct: 34.8,
      sediment_coverage_pct: 61.2,
      carbonate_coverage_pct: 3.6,
      anomaly_pixels_pct: 0.4
    },
    endmember_correlations: [
      { name: 'Polymetallic Nodule (Vernadite/Todorokite)', min_spectral_angle_rad: 0.048, mean_confidence: 0.942 },
      { name: 'Pelagic Clay / Siliceous Ooze', min_spectral_angle_rad: 0.052, mean_confidence: 0.915 },
      { name: 'Biogenic Carbonate (Foraminifera)', min_spectral_angle_rad: 0.091, mean_confidence: 0.880 }
    ],
    disclaimer: 'Hyperspectral classification identifies surface optical mineral indicators; physical metal assays require calibrated laboratory XRF/ICP-MS validation.',
    processing_duration_s: 0.84
  });
});

app.post('/api/v1/raman/analyse', (req, res) => {
  const { spectrum_id = 'RAMAN-CCZ-20261103-018', laser_power_mw = 45.0, integration_time_ms = 1500 } = req.body || {};
  res.json({
    status: 'SUCCESS',
    spectrum_id,
    acquisition_metadata: {
      excitation_laser_nm: 532.0,
      laser_power_mw,
      integration_time_ms,
      cosmic_ray_filter_applied: true,
      cosmic_spikes_removed: 2,
      snr_db: 28.6
    },
    raman_shift_range_cm1: [200, 3200],
    peak_fits: {
      d_band: {
        peak_center_cm1: 1348.2,
        peak_intensity_counts: 4820,
        fwhm_cm1: 78.4,
        peak_area: 412500,
        fit_r_squared: 0.991
      },
      g_band: {
        peak_center_cm1: 1584.6,
        peak_intensity_counts: 5310,
        fwhm_cm1: 54.2,
        peak_area: 314000,
        fit_r_squared: 0.994
      },
      carbonate_sym_stretch: {
        peak_center_cm1: 1085.4,
        peak_intensity_counts: 1920,
        mineral_match: 'Aragonite / Calcite (Biogenic)'
      }
    },
    carbon_structural_metrics: {
      id_ig_intensity_ratio: 0.908,
      ad_ag_area_ratio: 1.314,
      crystallite_size_la_nm: 18.5,
      structural_order: 'Disordered Microcrystalline Carbonaceous Material'
    },
    carbon_classification: {
      primary_signature: 'Disordered Carbonaceous Matrix within Polymetallic Nodule Nucleus',
      confidence: 0.895,
      secondary_signature: 'Biogenic Carbonate (Foraminiferal Shell Fragments)',
      fluorescence_interference: 'LOW'
    },
    scientific_disclaimer: 'Raman peak ratios characterize structural order of carbonaceous matter and do NOT yield Total Organic Carbon (TOC) or Total Inorganic Carbon (TIC) weight percent without site-specific elemental combustion calibration.',
    processing_time_ms: 24.5
  });
});

app.post('/api/v1/sonar/process', (req, res) => {
  const { ping_batch_id = 'PING-BATCH-20261103-512', sound_speed_mps = 1528.4 } = req.body || {};
  res.json({
    status: 'SUCCESS',
    ping_batch_id,
    pings_processed: 512,
    beams_per_ping: 512,
    valid_soundings_count: 258410,
    rejected_outliers: 3714,
    acoustic_geometry: {
      swath_width_m: 48.6,
      mean_seabed_depth_m: 4218.42,
      depth_std_dev_m: 0.24,
      refraction_correction_applied: true,
      sound_speed_mps_applied: sound_speed_mps,
      sound_speed_profile_ref: 'CTD-CAST-20261103-DEEP'
    },
    backscatter_statistics: {
      mean_backscatter_db: -24.8,
      backscatter_std_db: 4.2,
      high_backscatter_roughness_anomaly_pct: 28.4
    },
    bathymetry_grid: {
      resolution_m: 0.25,
      min_depth_m: 4217.10,
      max_depth_m: 4220.85,
      grid_rows: 240,
      grid_cols: 180,
      crs: 'EPSG:32610'
    },
    data_products: {
      gridded_dem_geotiff: `data/sonar/dem_${ping_batch_id}.tif`,
      backscatter_raster: `data/sonar/backscatter_${ping_batch_id}.tif`,
      point_cloud_ply: `data/sonar/points_${ping_batch_id}.ply`
    },
    processing_time_ms: 115.4
  });
});

app.post('/api/v1/nodules/detect', (req, res) => {
  const { frame_id = 'FRAME-20261103-08241', min_diameter_cm = 1.5 } = req.body || {};
  res.json({
    status: 'SUCCESS',
    frame_id,
    min_diameter_cutoff_cm: min_diameter_cm,
    surveyed_seabed_area_m2: 4.20,
    total_nodules_detected: 84,
    spatial_density_count_per_m2: 20.0,
    seabed_coverage_pct: 22.4,
    estimated_wet_abundance_kg_per_m2: 14.8,
    size_distribution: {
      bin_2_to_4_cm: 22,
      bin_4_to_6_cm: 38,
      bin_6_to_8_cm: 18,
      bin_8_to_10_cm: 6
    },
    sample_nodules: [
      {
        nodule_id: 'NOD-CCZ-008241-01',
        center_x_px: 642,
        center_y_px: 814,
        latitude: 12.483124,
        longitude: -135.291482,
        feret_max_diameter_cm: 7.42,
        feret_min_diameter_cm: 5.18,
        equivalent_diameter_cm: 6.20,
        projected_area_cm2: 30.19,
        circularity: 0.912,
        estimated_volume_cm3: 98.4,
        estimated_wet_mass_g: 186.9,
        confidence_score: 0.968,
        spectral_class: 'todorokite_rich_nodule',
        assay_estimates_pct: {
          manganese_mn: { value: 29.8, ci95_lower: 28.1, ci95_upper: 31.5 },
          nickel_ni: { value: 1.38, ci95_lower: 1.25, ci95_upper: 1.51 },
          copper_cu: { value: 1.15, ci95_lower: 1.02, ci95_upper: 1.28 },
          cobalt_co: { value: 0.23, ci95_lower: 0.19, ci95_upper: 0.27 },
          iron_fe: { value: 5.82, ci95_lower: 5.20, ci95_upper: 6.44 }
        }
      },
      {
        nodule_id: 'NOD-CCZ-008241-02',
        center_x_px: 1120,
        center_y_px: 940,
        latitude: 12.483126,
        longitude: -135.291479,
        feret_max_diameter_cm: 9.15,
        feret_min_diameter_cm: 6.84,
        equivalent_diameter_cm: 7.91,
        projected_area_cm2: 49.14,
        circularity: 0.898,
        estimated_volume_cm3: 204.2,
        estimated_wet_mass_g: 388.0,
        confidence_score: 0.974,
        spectral_class: 'vernadite_crust_dominant',
        assay_estimates_pct: {
          manganese_mn: { value: 27.4, ci95_lower: 25.8, ci95_upper: 29.0 },
          nickel_ni: { value: 1.22, ci95_lower: 1.10, ci95_upper: 1.34 },
          copper_cu: { value: 0.98, ci95_lower: 0.86, ci95_upper: 1.10 },
          cobalt_co: { value: 0.28, ci95_lower: 0.23, ci95_upper: 0.33 },
          iron_fe: { value: 6.90, ci95_lower: 6.20, ci95_upper: 7.60 }
        }
      }
    ],
    compliance_statement: 'Mineral grade predictions are statistical estimates derived from spectral-photometric transfer functions. In accordance with JORC / NI 43-101 standards, these do not constitute certified mineral reserves without laboratory assay verification.',
    processing_time_ms: 68.2
  });
});

app.post('/api/v1/mapping/generate', (req, res) => {
  const { mission_id = 'MISSION-CCZ-2026-ALPHA', variable = 'abundance_kg_m2', variogram_model = 'Sph' } = req.body || {};
  res.json({
    status: 'SUCCESS',
    mission_id,
    target_variable: variable,
    geostatistical_model: {
      model_type: 'Ordinary Kriging (OK)',
      variogram_family: variogram_model,
      nugget_c0: 0.45,
      sill_c: 4.82,
      range_a_meters: 145.0,
      r_squared: 0.962,
      anisotropy_ratio: 1.15,
      anisotropy_angle_deg: 68.0
    },
    spatial_coverage: {
      bounding_box_utm: {
        xmin: 250100, xmax: 252500,
        ymin: 1380200, ymax: 1382800,
        crs: 'EPSG:32610'
      },
      total_surveyed_area_km2: 6.24,
      effective_track_coverage_pct: 78.5
    },
    kriging_summary_stats: {
      min_estimated: 4.12,
      q25_estimated: 11.45,
      median_estimated: 14.80,
      q75_estimated: 17.92,
      max_estimated: 24.30,
      units: 'kg/m2',
      mean_kriging_variance: 0.62,
      high_uncertainty_area_pct: 8.4
    },
    generated_layers: {
      prediction_surface_geotiff: `/api/v1/mapping/layers/${mission_id}_${variable}_kriged.tif`,
      variance_uncertainty_geotiff: `/api/v1/mapping/layers/${mission_id}_${variable}_var.tif`,
      bathymetric_3d_mesh_ply: `/api/v1/mapping/layers/${mission_id}_bathymetry_3d.ply`,
      bathymetric_3d_mesh_glb: `/api/v1/mapping/layers/${mission_id}_bathymetry_3d.glb`,
      contour_vector_geojson: `/api/v1/mapping/layers/${mission_id}_contours_10cm.geojson`
    },
    processing_time_ms: 185.0
  });
});

app.get('/api/v1/missions', (req, res) => {
  res.json({
    status: 'SUCCESS',
    missions: [
      {
        mission_id: 'MISSION-CCZ-2026-ALPHA',
        contractor: 'Μετάλλιον Inc.',
        exploration_area: 'Clarion-Clipperton Zone (Area C, Block 04)',
        water_depth_range_m: [4150, 4290],
        status: 'ACTIVE_ON_STATION',
        operator_in_charge: 'Dr. Elena Rostova / Lead Geophysicist',
        vessel: 'R/V Deep Surveyor VIII',
        vehicle: 'AUV Aardvark DeepExplorer-04',
        start_time: '2026-11-01T04:00:00Z',
        total_survey_distance_km: 48.6,
        total_nodules_identified: 284150,
        estimated_nodule_tonnage: 3480.0
      }
    ]
  });
});

app.get('/api/v1/diagnostics/benchmarks', (req, res) => {
  res.json({
    benchmark_environment: {
      os: 'Linux x86_64',
      r_version: '4.4.1',
      compiler: 'gcc 12.3 with -O3 -march=native',
      threads: 8
    },
    benchmarks: [
      {
        task: 'Hyperspectral 224-Band Cube Savitzky-Golay + SAM Unmixing (512x512)',
        pure_r_ms: 4850.2,
        rcpp_armadillo_ms: 312.4,
        speedup_factor: 15.5,
        memory_mb: 142.0
      },
      {
        task: 'Raman Cosmic-Ray Spike Suppression & ALS Baseline Fitting (10k spectra)',
        pure_r_ms: 2140.0,
        rcpp_armadillo_ms: 184.6,
        speedup_factor: 11.6,
        memory_mb: 48.5
      },
      {
        task: 'Multibeam Sonar SVP Ray-Tracing & Bottom Picking (100k soundings)',
        pure_r_ms: 3890.0,
        rcpp_armadillo_ms: 142.1,
        speedup_factor: 27.4,
        memory_mb: 64.0
      },
      {
        task: 'Polymetallic Nodule Multi-scale Watershed Segmentation (4K Frame)',
        pure_r_ms: 1620.0,
        rcpp_armadillo_ms: 124.0,
        speedup_factor: 13.1,
        memory_mb: 95.0
      },
      {
        task: 'Marine Geostatistical Ordinary Kriging (10,000 grid points)',
        pure_r_ms: 1850.0,
        rcpp_armadillo_ms: 195.0,
        speedup_factor: 9.5,
        memory_mb: 78.0
      }
    ],
    overall_status: 'MEETS_SUBSEA_REALTIME_CRITERIA'
  });
});

app.get('/api/v1/diagnostics/hardware', (req, res) => {
  res.json({
    fpga_module: 'Silica Flux Xilinx UltraScale+ FPGA',
    systemverilog_core_rev: 'SF-REV-4.1.8-DEEPSEA',
    pcie_link: 'Gen3 x8 (64 Gbps physical theoretical)',
    ring_buffer_depth_frames: 2048,
    ring_buffer_head: 18420,
    ring_buffer_tail: 18412,
    packet_loss_rate: 0.0,
    hardware_safety_interlock: {
      laser_532nm_shutter: 'ARMED_AND_SAFETY_LOCKED',
      pressure_sensor_cutoff_depth_m: 5000.0,
      leak_detection_status: 'DRY_ISOLATED',
      battery_voltage_v: 48.4,
      draw_amperes: 12.8
    }
  });
});

interface TreeNode {
  name: string;
  path: string;
  type: 'file' | 'directory';
  size?: number;
  children?: TreeNode[];
}

// File tree and code reading endpoints for the R Codebase Inspector
app.get('/api/v1/codebase/tree', (_req, res) => {
  const baseDir = '/aardvark-subsea-r';
  const getFileTree = (dir: string, relPath = ''): TreeNode[] => {
    try {
      if (!fs.existsSync(dir)) return [];
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      return entries.map(entry => {
        const itemRel = relPath ? `${relPath}/${entry.name}` : entry.name;
        const itemPath = join(dir, entry.name);
        if (entry.isDirectory()) {
          return {
            name: entry.name,
            path: itemRel,
            type: 'directory',
            children: getFileTree(itemPath, itemRel)
          };
        } else {
          const stats = fs.statSync(itemPath);
          return {
            name: entry.name,
            path: itemRel,
            type: 'file',
            size: stats.size
          };
        }
      });
    } catch {
      return [];
    }
  };

  res.json({
    root: 'aardvark-subsea-r',
    tree: getFileTree(baseDir)
  });
});

app.get('/api/v1/codebase/file', (req, res) => {
  const filePath = String(req.query['path'] || '');
  if (!filePath || filePath.includes('..')) {
    res.status(400).json({ error: 'Invalid file path' });
    return;
  }
  const fullPath = join('/aardvark-subsea-r', filePath);
  try {
    if (!fs.existsSync(fullPath)) {
      res.status(404).json({ error: 'File not found' });
      return;
    }
    const content = fs.readFileSync(fullPath, 'utf8');
    res.json({
      path: filePath,
      content,
      size: content.length
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: message });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Aardvark Subsea Scientific Backend listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
