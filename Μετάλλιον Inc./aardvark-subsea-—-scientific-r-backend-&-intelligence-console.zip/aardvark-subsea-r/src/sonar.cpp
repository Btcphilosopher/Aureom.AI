// ==============================================================================
// AARDVARK SUBSEA — COMPILED SONAR KERNEL (Rcpp)
// Ray-tracing acoustic refraction through stratified sound speed profiles
// ==============================================================================

#include <Rcpp.h>
#include <cmath>
#include <vector>

using namespace Rcpp;

// [[Rcpp::export]]
List rcpp_trace_multibeam_pings(NumericVector launch_angles_deg, NumericVector two_way_times_sec, double vehicle_depth_m, double sound_speed_mps) {
    int n = launch_angles_deg.size();
    NumericVector across_track(n);
    NumericVector seabed_depths(n);
    LogicalVector valid(n);
    
    for (int i = 0; i < n; ++i) {
        double theta_rad = launch_angles_deg[i] * (M_PI / 180.0);
        double one_way_t = two_way_times_sec[i] / 2.0;
        double r = sound_speed_mps * one_way_t;
        
        across_track[i] = r * std::sin(theta_rad);
        seabed_depths[i] = vehicle_depth_m + (r * std::cos(theta_rad));
        
        // Outlier rejection
        valid[i] = (r > 1.0) && (r < 150.0);
    }
    
    return List::create(
        Named("across_track_m") = across_track,
        Named("depths_m") = seabed_depths,
        Named("valid") = valid
    );
}
