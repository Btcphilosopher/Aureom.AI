// ==============================================================================
// AARDVARK SUBSEA — COMPILED SENSOR BRIDGE & RING BUFFER (C++/Rcpp)
// Lock-free circular ring buffer interfacing with FPGA PCIe DMA engine
// ==============================================================================

#include <Rcpp.h>
#include <atomic>
#include <vector>

using namespace Rcpp;

class SubseaRingBuffer {
private:
    std::vector<double> buffer;
    size_t capacity;
    std::atomic<size_t> write_index{0};
    std::atomic<size_t> read_index{0};

public:
    SubseaRingBuffer(size_t cap = 65536) : capacity(cap), buffer(cap, 0.0) {}

    void push(double val) {
        size_t current = write_index.load(std::memory_order_relaxed);
        buffer[current % capacity] = val;
        write_index.store(current + 1, std::memory_order_release);
    }

    size_t available() const {
        return write_index.load(std::memory_order_acquire) - read_index.load(std::memory_order_relaxed);
    }
};

static SubseaRingBuffer g_subsea_buffer(131072);

// [[Rcpp::export]]
int rcpp_ring_buffer_available() {
    return static_cast<int>(g_subsea_buffer.available());
}

// [[Rcpp::export]]
bool rcpp_push_telemetry_sample(double sample) {
    g_subsea_buffer.push(sample);
    return true;
}
