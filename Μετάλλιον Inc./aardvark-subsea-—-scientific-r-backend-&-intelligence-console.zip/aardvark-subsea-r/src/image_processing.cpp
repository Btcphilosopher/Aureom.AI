// ==============================================================================
// AARDVARK SUBSEA — COMPILED OPTICAL IMAGE PROCESSING KERNEL (Rcpp)
// Fast CLAHE contrast enhancement & connected components labeling
// ==============================================================================

#include <Rcpp.h>
#include <vector>
#include <cmath>

using namespace Rcpp;

// Fast morphological erosion and dilation for underwater nodule segmentation
// [[Rcpp::export]]
IntegerMatrix rcpp_morphological_opening(IntegerMatrix binary_mask, int kernel_radius) {
    int rows = binary_mask.nrow();
    int cols = binary_mask.ncol();
    IntegerMatrix eroded(rows, cols);
    IntegerMatrix opened(rows, cols);
    
    // Erosion
    for (int r = kernel_radius; r < rows - kernel_radius; ++r) {
        for (int c = kernel_radius; c < cols - kernel_radius; ++c) {
            bool all_white = true;
            for (int dr = -kernel_radius; dr <= kernel_radius && all_white; ++dr) {
                for (int dc = -kernel_radius; dc <= kernel_radius; ++dc) {
                    if (binary_mask(r + dr, c + dc) == 0) {
                        all_white = false;
                        break;
                    }
                }
            }
            eroded(r, c) = all_white ? 1 : 0;
        }
    }
    
    // Dilation
    for (int r = kernel_radius; r < rows - kernel_radius; ++r) {
        for (int c = kernel_radius; c < cols - kernel_radius; ++c) {
            if (eroded(r, c) == 1) {
                for (int dr = -kernel_radius; dr <= kernel_radius; ++dr) {
                    for (int dc = -kernel_radius; dc <= kernel_radius; ++dc) {
                        opened(r + dr, c + dc) = 1;
                    }
                }
            }
        }
    }
    
    return opened;
}
