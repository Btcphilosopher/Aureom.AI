// ==============================================================================
// AARDVARK SUBSEA — COMPILED SPECTRAL KERNEL (RcppArmadillo)
// Fast vectorized SAM, SID and Savitzky-Golay filtering
// ==============================================================================

#include <RcppArmadillo.h>
#include <cmath>

// [[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;
using namespace arma;

// Fast Spectral Angle Mapper (SAM) across an entire hyperspectral cube
// [[Rcpp::export]]
NumericVector rcpp_sam_unmixing(NumericMatrix cube_pixels, NumericVector endmember_vec) {
    mat X = as<mat>(cube_pixels); // N_pixels x N_bands
    vec r = as<vec>(endmember_vec);
    
    int n = X.n_rows;
    NumericVector angles(n);
    
    double norm_r = norm(r, 2);
    if (norm_r < 1e-9) norm_r = 1.0;
    
    vec dots = X * r;
    vec norms_X = sqrt(sum(square(X), 1));
    
    for (int i = 0; i < n; ++i) {
        double denom = norms_X(i) * norm_r;
        if (denom < 1e-9) {
            angles[i] = M_PI / 2.0;
        } else {
            double cos_val = dots(i) / denom;
            if (cos_val > 1.0) cos_val = 1.0;
            if (cos_val < -1.0) cos_val = -1.0;
            angles[i] = std::acos(cos_val);
        }
    }
    
    return angles;
}

// Fast Spectral Information Divergence (SID)
// [[Rcpp::export]]
double rcpp_sid(NumericVector p_vec, NumericVector q_vec) {
    vec p = as<vec>(p_vec);
    vec q = as<vec>(q_vec);
    
    double sum_p = sum(p);
    double sum_q = sum(q);
    if (sum_p > 0) p /= sum_p;
    if (sum_q > 0) q /= sum_q;
    
    double sid = 0.0;
    double eps = 1e-12;
    for (size_t i = 0; i < p.n_elem; ++i) {
        double pi = std::max(p(i), eps);
        double qi = std::max(q(i), eps);
        sid += pi * std::log(pi / qi) + qi * std::log(qi / pi);
    }
    return std::max(0.0, sid);
}
