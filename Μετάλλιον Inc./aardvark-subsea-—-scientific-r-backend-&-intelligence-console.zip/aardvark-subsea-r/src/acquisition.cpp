// ==============================================================================
// AARDVARK SUBSEA — COMPILED ACQUISITION KERNEL (Rcpp)
// Fast binary parser for Silica Flux / SystemVerilog FPGA sensor packet stream
// ==============================================================================

#include <Rcpp.h>
#include <vector>
#include <cstdint>

using namespace Rcpp;

// Silica Flux Packet Header Structure
#pragma pack(push, 1)
struct SilicaFluxHeader {
    uint32_t sync_word;       // 0xAA55F00D
    uint32_t sequence_id;     // Monotonic counter
    uint64_t timestamp_ns;    // High-precision clock from PTP IEEE 1588
    uint16_t sensor_type;     // 0x01: Hyperspectral, 0x02: Raman, 0x03: Sonar
    uint16_t payload_words;   // 16-bit word count
    uint32_t crc32;           // Hardware checksum
};
#pragma pack(pop)

// [[Rcpp::export]]
List parse_silica_flux_packets(RawVector packet_buffer) {
    const uint8_t* data = RAW(packet_buffer);
    size_t total_bytes = packet_buffer.size();
    
    std::vector<uint32_t> seq_ids;
    std::vector<double> timestamps_s;
    std::vector<int> sensor_types;
    
    size_t offset = 0;
    size_t valid_packets = 0;
    
    while (offset + sizeof(SilicaFluxHeader) <= total_bytes) {
        const SilicaFluxHeader* hdr = reinterpret_cast<const SilicaFluxHeader*>(data + offset);
        if (hdr->sync_word == 0xAA55F00D) {
            seq_ids.push_back(hdr->sequence_id);
            timestamps_s.push_back(static_cast<double>(hdr->timestamp_ns) * 1e-9);
            sensor_types.push_back(hdr->sensor_type);
            valid_packets++;
            offset += sizeof(SilicaFluxHeader) + (hdr->payload_words * 2);
        } else {
            offset++; // Scan for next sync magic
        }
    }
    
    return List::create(
        Named("valid_packets") = valid_packets,
        Named("sequence_ids") = wrap(seq_ids),
        Named("timestamps") = wrap(timestamps_s),
        Named("sensor_types") = wrap(sensor_types)
    );
}
