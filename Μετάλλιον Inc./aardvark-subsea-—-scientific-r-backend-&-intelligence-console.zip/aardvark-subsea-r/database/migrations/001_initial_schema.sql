-- Migration 001: Initial schema migration
-- Apply base tables and spatial constraints
\i database/schema.sql;

-- Populate initial sensor calibration standards
INSERT INTO sensors (sensor_id, sensor_name, sensor_type, model_serial, calibration_id, interface_protocol, status)
VALUES 
    ('SNSR-OPT-HYPER-01', 'Aardvark HyperEye VNIR 400-1000nm', 'hyperspectral_imager', 'HE-VNIR-882', 'CAL-VNIR-2026-Q1', 'Silica Flux PCIe', 'NOMINAL'),
    ('SNSR-RAMAN-532', 'DeepOcean Raman In-Situ Spectrometer', 'raman_spectrometer', 'DORS-532-12', 'CAL-RAM-532-2026', 'Isolated Fiber Probe', 'NOMINAL'),
    ('SNSR-MBES-400K', 'Reson SeaBat T50-P Equivalent Multibeam', 'multibeam_sonar', 'MB-400-991', 'CAL-MBES-PATCH-2026', 'GbE UDP', 'ACTIVE')
ON CONFLICT (sensor_id) DO NOTHING;
