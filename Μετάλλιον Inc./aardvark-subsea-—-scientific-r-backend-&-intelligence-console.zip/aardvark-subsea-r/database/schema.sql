-- ==============================================================================
-- AARDVARK SUBSEA R — POSTGRESQL & POSTGIS DATABASE SCHEMA
-- Client: Μετάλλιον Inc. | Polymetallic Nodule Survey Operations
-- Spatial Reference: EPSG:4326 (WGS 84) & EPSG:32610 (UTM Zone 10N)
-- ==============================================================================

-- Enable PostGIS geospatial extension
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Exploration Missions
CREATE TABLE IF NOT EXISTS missions (
    mission_id VARCHAR(64) PRIMARY KEY,
    contractor VARCHAR(128) NOT NULL DEFAULT 'Μετάλλιον Inc.',
    target_area VARCHAR(128) NOT NULL,
    vessel_name VARCHAR(128) NOT NULL,
    vehicle_id VARCHAR(64) NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ,
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    lead_geophysicist VARCHAR(128),
    survey_polygon GEOMETRY(Polygon, 4326),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Sensor Registry
CREATE TABLE IF NOT EXISTS sensors (
    sensor_id VARCHAR(64) PRIMARY KEY,
    sensor_name VARCHAR(128) NOT NULL,
    sensor_type VARCHAR(64) NOT NULL,
    model_serial VARCHAR(64),
    calibration_id VARCHAR(64),
    interface_protocol VARCHAR(64),
    status VARCHAR(32) DEFAULT 'NOMINAL',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Telemetry Stream (High frequency navigation)
CREATE TABLE IF NOT EXISTS telemetry_records (
    record_id BIGSERIAL PRIMARY KEY,
    mission_id VARCHAR(64) REFERENCES missions(mission_id),
    timestamp TIMESTAMPTZ NOT NULL,
    geom GEOMETRY(PointZ, 4326),
    easting_utm NUMERIC(10, 2),
    northing_utm NUMERIC(10, 2),
    depth_m NUMERIC(7, 2) NOT NULL,
    altitude_m NUMERIC(6, 2) NOT NULL,
    heading_deg NUMERIC(5, 2) NOT NULL,
    pitch_deg NUMERIC(5, 2) NOT NULL,
    roll_deg NUMERIC(5, 2) NOT NULL,
    sound_velocity_mps NUMERIC(6, 2) NOT NULL,
    position_uncertainty_m NUMERIC(5, 3)
);
CREATE INDEX IF NOT EXISTS idx_telemetry_geom ON telemetry_records USING GIST(geom);
CREATE INDEX IF NOT EXISTS idx_telemetry_time ON telemetry_records(timestamp);

-- 4. Optical & Hyperspectral Acquisition Metadata
CREATE TABLE IF NOT EXISTS optical_frames (
    frame_id VARCHAR(64) PRIMARY KEY,
    mission_id VARCHAR(64) REFERENCES missions(mission_id),
    sensor_id VARCHAR(64) REFERENCES sensors(sensor_id),
    capture_time TIMESTAMPTZ NOT NULL,
    geom GEOMETRY(PointZ, 4326),
    altitude_m NUMERIC(6, 2),
    exposure_ms NUMERIC(6, 2),
    uiqm_score NUMERIC(5, 3),
    raw_storage_uri TEXT NOT NULL,
    calibrated_storage_uri TEXT
);

-- 5. Hyperspectral Classification Cubes
CREATE TABLE IF NOT EXISTS spectral_results (
    result_id VARCHAR(64) PRIMARY KEY,
    mission_id VARCHAR(64) REFERENCES missions(mission_id),
    cube_id VARCHAR(64) NOT NULL,
    algorithm VARCHAR(64) NOT NULL, -- e.g. 'SAM', 'SID', 'PLS-DA'
    nodule_coverage_pct NUMERIC(5, 2),
    sediment_coverage_pct NUMERIC(5, 2),
    carbonate_coverage_pct NUMERIC(5, 2),
    classification_raster_uri TEXT,
    processed_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. In-Situ Raman Spectroscopy & Carbon Typing
CREATE TABLE IF NOT EXISTS raman_analyses (
    analysis_id VARCHAR(64) PRIMARY KEY,
    mission_id VARCHAR(64) REFERENCES missions(mission_id),
    spectrum_id VARCHAR(64) NOT NULL,
    laser_power_mw NUMERIC(6, 2),
    integration_time_ms INTEGER,
    geom GEOMETRY(PointZ, 4326),
    d_band_center_cm1 NUMERIC(7, 2),
    g_band_center_cm1 NUMERIC(7, 2),
    id_ig_ratio NUMERIC(5, 3),
    crystallite_size_la_nm NUMERIC(6, 2),
    carbonate_stretch_detected BOOLEAN DEFAULT FALSE,
    carbon_classification TEXT,
    snr_db NUMERIC(5, 2),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Sonar Pings & Bathymetric Products
CREATE TABLE IF NOT EXISTS sonar_batches (
    batch_id VARCHAR(64) PRIMARY KEY,
    mission_id VARCHAR(64) REFERENCES missions(mission_id),
    pings_count INTEGER NOT NULL,
    mean_depth_m NUMERIC(7, 2),
    mean_backscatter_db NUMERIC(5, 2),
    dem_geotiff_uri TEXT,
    point_cloud_ply_uri TEXT,
    processed_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Polymetallic Nodule Detections (Individual Segmented Nodules)
CREATE TABLE IF NOT EXISTS polymetallic_nodules (
    nodule_id VARCHAR(64) PRIMARY KEY,
    mission_id VARCHAR(64) REFERENCES missions(mission_id),
    frame_id VARCHAR(64) REFERENCES optical_frames(frame_id),
    geom GEOMETRY(PointZ, 4326),
    feret_max_diameter_cm NUMERIC(5, 2) NOT NULL,
    feret_min_diameter_cm NUMERIC(5, 2) NOT NULL,
    equivalent_diameter_cm NUMERIC(5, 2) NOT NULL,
    projected_area_cm2 NUMERIC(7, 2) NOT NULL,
    estimated_volume_cm3 NUMERIC(8, 2),
    estimated_wet_mass_g NUMERIC(8, 2),
    circularity NUMERIC(4, 3),
    confidence_score NUMERIC(4, 3) NOT NULL,
    spectral_class VARCHAR(64),
    -- Transfer function grade estimates
    est_manganese_mn_pct NUMERIC(5, 2),
    est_nickel_ni_pct NUMERIC(5, 2),
    est_copper_cu_pct NUMERIC(5, 2),
    est_cobalt_co_pct NUMERIC(5, 2),
    est_iron_fe_pct NUMERIC(5, 2),
    detected_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_nodules_geom ON polymetallic_nodules USING GIST(geom);
CREATE INDEX IF NOT EXISTS idx_nodules_diameter ON polymetallic_nodules(feret_max_diameter_cm);

-- 9. Laboratory Certified Chemical Assays (Ground Truth box-core samples)
CREATE TABLE IF NOT EXISTS laboratory_assays (
    assay_id VARCHAR(64) PRIMARY KEY,
    mission_id VARCHAR(64) REFERENCES missions(mission_id),
    core_sample_id VARCHAR(64) NOT NULL,
    geom GEOMETRY(PointZ, 4326),
    analytical_method VARCHAR(64) NOT NULL DEFAULT 'ICP-MS / ICP-OES',
    lab_cert_number VARCHAR(64) NOT NULL,
    manganese_mn_wt_pct NUMERIC(6, 3) NOT NULL,
    nickel_ni_wt_pct NUMERIC(6, 3) NOT NULL,
    copper_cu_wt_pct NUMERIC(6, 3) NOT NULL,
    cobalt_co_wt_pct NUMERIC(6, 3) NOT NULL,
    iron_fe_wt_pct NUMERIC(6, 3) NOT NULL,
    toc_wt_pct NUMERIC(5, 3),
    tic_wt_pct NUMERIC(5, 3),
    moisture_pct NUMERIC(5, 2),
    accredited_laboratory VARCHAR(128) NOT NULL,
    certified_date DATE NOT NULL
);

-- 10. Geostatistical Spatial Interpolations (Ordinary Kriging Runs)
CREATE TABLE IF NOT EXISTS geostatistical_layers (
    layer_id VARCHAR(64) PRIMARY KEY,
    mission_id VARCHAR(64) REFERENCES missions(mission_id),
    variable_name VARCHAR(64) NOT NULL,
    variogram_model VARCHAR(32) NOT NULL,
    nugget NUMERIC(8, 4),
    sill NUMERIC(8, 4),
    range_m NUMERIC(8, 2),
    grid_cell_size_m NUMERIC(5, 2) NOT NULL,
    prediction_raster_uri TEXT NOT NULL,
    variance_raster_uri TEXT NOT NULL,
    generated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. Asynchronous Jobs Queue
CREATE TABLE IF NOT EXISTS processing_jobs (
    job_id VARCHAR(64) PRIMARY KEY,
    job_type VARCHAR(64) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'QUEUED',
    progress_pct NUMERIC(5, 2) DEFAULT 0.0,
    parameters JSONB,
    result JSONB,
    error_message TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);

-- 12. Quality Control & Audit Event Trail (ISA / JORC Compliance)
CREATE TABLE IF NOT EXISTS audit_events (
    event_id BIGSERIAL PRIMARY KEY,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    action VARCHAR(64) NOT NULL,
    entity_id VARCHAR(64),
    operator_id VARCHAR(64) NOT NULL,
    client_ip INET,
    status VARCHAR(32) NOT NULL,
    details JSONB
);
