# ==============================================================================
# AARDVARK SUBSEA R — TEST SUITE RUNNER (testthat)
# ==============================================================================

library(testthat)

# Source all R library code
source("R/utilities/logger.R")
source("R/optical/underwater_enhancement.R")
source("R/hyperspectral/calibration.R")
source("R/hyperspectral/preprocessing.R")
source("R/hyperspectral/analysis_engine.R")
source("R/raman/peak_fitting.R")
source("R/carbon/characterisation.R")
source("R/sonar/bathymetry_engine.R")
source("R/sonar/backscatter_processing.R")
source("R/fusion/sensor_fusion.R")
source("R/nodules/detection_pipeline.R")
source("R/nodules/grade_estimation.R")
source("R/geostatistics/variogram_kriging.R")
source("R/geostatistics/density_analysis.R")

test_dir("tests/testthat")
