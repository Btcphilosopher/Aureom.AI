# ==============================================================================
# TEST: MULTIBEAM SONAR REFRACTION & BACKSCATTER
# ==============================================================================

test_that("Nadir sounding has zero across-track offset", {
  res <- process_multibeam_ping(beam_angles_deg = c(0.0), two_way_times_s = c(0.01), vehicle_depth_m = 4218.0, vehicle_altitude_m = 7.64, sound_speed_mps = 1528.0)
  expect_equal(res$across_track_m[1], 0.0, tolerance = 1e-4)
  expect_gt(res$depths_m[1], 4218.0)
})

test_that("TVG compensation increases gain with range", {
  ranges <- c(5.0, 50.0)
  amps <- c(10.0, 10.0)
  comp <- apply_tvg_compensation(amps, ranges)
  expect_gt(comp[2], comp[1])
})
