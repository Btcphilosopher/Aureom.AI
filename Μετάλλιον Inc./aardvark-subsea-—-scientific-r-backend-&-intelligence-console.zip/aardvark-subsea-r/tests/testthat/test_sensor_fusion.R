# ==============================================================================
# TEST: SENSOR FUSION & 6-DOF COORDINATE TRANSFORMATION
# ==============================================================================

test_that("Identity rotation matrix preserves vectors", {
  R <- build_rotation_matrix(0, 0, 0)
  v <- c(1.0, 2.0, 3.0)
  v_rot <- as.vector(R %*% v)
  expect_equal(v_rot, v, tolerance = 1e-6)
})

test_that("Sensor lever arm offset propagates correctly to world position", {
  veh_pos <- list(utm_easting = 250000, utm_northing = 1380000, depth_m = 4200, position_uncertainty_sd_m = 0.2)
  res <- transform_sensor_point_to_world(
    point_sensor_frame = c(0, 0, 0),
    sensor_id = "stereo_camera_port",
    vehicle_pos = veh_pos,
    roll_deg = 0, pitch_deg = 0, heading_deg = 0
  )
  expect_gt(res$northing_m, veh_pos$utm_northing)
  expect_gt(res$depth_m, veh_pos$depth_m)
})
