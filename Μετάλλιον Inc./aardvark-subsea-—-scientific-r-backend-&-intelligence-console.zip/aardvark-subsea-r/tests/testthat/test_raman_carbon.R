# ==============================================================================
# TEST: RAMAN DECONVOLUTION & CARBON STRUCTURAL TYPING
# ==============================================================================

test_that("Cosmic ray spike suppression cleans artificial spikes", {
  raw_spectrum <- rep(100, 100)
  raw_spectrum[42] <- 5000 # artificial spike
  result <- remove_cosmic_spikes(raw_spectrum)
  expect_equal(result$spikes_detected, 1)
  expect_lt(result$cleaned[42], 500)
})

test_that("Carbon crystallite size calculation follows Tuinstra-Koenig", {
  d_fit <- list(height_counts = 1000, area_counts = 50000)
  g_fit <- list(height_counts = 1000, area_counts = 50000)
  res <- characterise_carbon_spectrum(d_fit, g_fit, laser_nm = 532.0)
  expect_equal(res$id_ig_ratio, 1.0)
  expect_gt(res$crystallite_size_la_nm, 10.0)
  expect_true(grepl("Disordered", res$structural_order))
})
