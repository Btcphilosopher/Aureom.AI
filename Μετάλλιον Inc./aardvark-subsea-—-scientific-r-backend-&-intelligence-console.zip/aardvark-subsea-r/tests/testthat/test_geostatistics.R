# ==============================================================================
# TEST: GEOSTATISTICS, VARIOGRAM & ORDINARY KRIGING
# ==============================================================================

test_that("Spherical variogram reaches sill at range a", {
  nugget <- 0.5
  sill <- 4.0
  range_a <- 100.0
  
  gamma_range <- spherical_variogram_fn(100.0, nugget, sill, range_a)
  gamma_beyond <- spherical_variogram_fn(150.0, nugget, sill, range_a)
  
  expect_equal(gamma_range, nugget + sill, tolerance = 1e-6)
  expect_equal(gamma_beyond, nugget + sill, tolerance = 1e-6)
  expect_equal(spherical_variogram_fn(0, nugget, sill, range_a), 0)
})

test_that("Ordinary Kriging handles spatial interpolation without error", {
  sample_coords <- matrix(c(0, 0, 10, 0, 0, 10, 10, 10), ncol = 2, byrow = TRUE)
  sample_vals <- c(12.0, 14.5, 11.8, 15.2)
  grid_coords <- matrix(c(5, 5), ncol = 2)
  
  ok_res <- ordinary_kriging_interpolate(sample_coords, sample_vals, grid_coords, nugget = 0.2, sill = 2.0, range_a = 20.0)
  expect_gt(ok_res$mean_prediction, 10.0)
  expect_lt(ok_res$mean_prediction, 16.0)
})
