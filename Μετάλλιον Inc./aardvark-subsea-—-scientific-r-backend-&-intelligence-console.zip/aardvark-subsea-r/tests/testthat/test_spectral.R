# ==============================================================================
# TEST: HYPERSPECTRAL PREPROCESSING, SAM AND SID
# ==============================================================================

test_that("SAM returns zero radians for identical spectra", {
  spec <- c(0.1, 0.2, 0.3, 0.4, 0.5)
  angle <- calculate_sam_angle_rad(spec, spec)
  expect_equal(angle, 0.0, tolerance = 1e-6)
})

test_that("SAM returns pi/2 for orthogonal spectra", {
  spec_a <- c(1, 0, 0)
  spec_b <- c(0, 1, 0)
  angle <- calculate_sam_angle_rad(spec_a, spec_b)
  expect_equal(angle, pi / 2, tolerance = 1e-6)
})

test_that("SID returns non-negative divergence", {
  spec_a <- c(0.2, 0.5, 0.3)
  spec_b <- c(0.3, 0.4, 0.3)
  sid <- calculate_sid_divergence(spec_a, spec_b)
  expect_gte(sid, 0.0)
})

test_that("Savitzky-Golay and SNV retain vector length", {
  spec <- runif(50, 0.1, 0.8)
  res <- preprocess_spectral_vector(spec, window_size = 7, deriv = 1)
  expect_equal(length(res$smoothed), 50)
  expect_equal(length(res$snv), 50)
  expect_equal(mean(res$snv), 0.0, tolerance = 1e-5)
})
