# ==============================================================================
# TEST: POLYMETALLIC NODULE MORPHOMETRICS & GRADE ESTIMATION
# ==============================================================================

test_that("Circular contour morphometrics yield expected geometry", {
  # Synthetic circular contour of radius 20 pixels
  theta <- seq(0, 2 * pi, length.out = 32)[-32]
  pts <- cbind(50 + 20 * cos(theta), 50 + 20 * sin(theta))
  morpho <- calculate_nodule_morphometrics(pts, mm_per_pixel = 1.0)
  
  expect_gt(morpho$circularity, 0.85)
  expect_gt(morpho$projected_area_cm2, 10.0)
  expect_gt(morpho$estimated_wet_mass_g, 10.0)
})

test_that("Grade estimation produces valid JORC bounds", {
  morpho <- list(equivalent_diameter_cm = 6.2)
  spec <- list()
  grades <- estimate_nodule_grade(morpho, spec)
  
  expect_gt(grades$manganese_mn$value, 20.0)
  expect_lt(grades$manganese_mn$value, 35.0)
  expect_lt(grades$manganese_mn$ci95_lower, grades$manganese_mn$value)
  expect_gt(grades$manganese_mn$ci95_upper, grades$manganese_mn$value)
})
