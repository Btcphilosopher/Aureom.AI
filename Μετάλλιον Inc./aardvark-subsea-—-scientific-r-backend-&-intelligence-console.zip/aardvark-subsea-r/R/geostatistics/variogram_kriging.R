# ==============================================================================
# AARDVARK SUBSEA R — GEOSTATISTICS: VARIOGRAM MODELING & ORDINARY KRIGING
# Experimental semivariograms, Spherical/Exponential models, Ordinary Kriging
# Packages: gstat, sf, terra, stars
# ==============================================================================

# Calculate experimental semivariogram for spatial point observations
calculate_experimental_variogram <- function(coords_matrix, values, lag_distance_m = 20.0, max_dist_m = 300.0) {
  n <- length(values)
  dist_matrix <- as.matrix(dist(coords_matrix))
  
  lags <- seq(lag_distance_m, max_dist_m, by = lag_distance_m)
  gamma_values <- numeric(length(lags))
  pair_counts <- integer(length(lags))
  
  for (i in seq_along(lags)) {
    h <- lags[i]
    half_lag <- lag_distance_m / 2
    pairs <- which(dist_matrix >= (h - half_lag) & dist_matrix < (h + half_lag), arr.ind = TRUE)
    # keep unique upper triangle pairs
    pairs <- pairs[pairs[, 1] < pairs[, 2], , drop = FALSE]
    
    if (nrow(pairs) > 0) {
      diffs <- values[pairs[, 1]] - values[pairs[, 2]]
      gamma_values[i] <- sum(diffs^2) / (2 * nrow(pairs))
      pair_counts[i] <- nrow(pairs)
    } else {
      gamma_values[i] <- NA
      pair_counts[i] <- 0
    }
  }
  
  list(
    lag_centers_m = lags,
    gamma = gamma_values,
    pairs = pair_counts
  )
}

# Spherical variogram model function
spherical_variogram_fn <- function(h, nugget, sill, range_a) {
  h_norm <- pmin(1.0, h / range_a)
  gamma <- nugget + sill * (1.5 * h_norm - 0.5 * (h_norm^3))
  gamma[h > range_a] <- nugget + sill
  gamma[h == 0] <- 0
  return(gamma)
}

# Execute Ordinary Kriging (OK) on a regular prediction grid
ordinary_kriging_interpolate <- function(sample_coords, sample_values, grid_coords, nugget = 0.45, sill = 4.82, range_a = 145.0) {
  n_samples <- length(sample_values)
  n_grid <- nrow(grid_coords)
  
  # Build sample-to-sample covariance matrix K
  sample_dist <- as.matrix(dist(sample_coords))
  K <- spherical_variogram_fn(sample_dist, nugget, sill, range_a)
  # Augment K with Lagrange multiplier constraint row/col
  K_aug <- rbind(cbind(K, 1), c(rep(1, n_samples), 0))
  
  # Predict for grid points
  predictions <- numeric(n_grid)
  kriging_variances <- numeric(n_grid)
  
  K_inv <- solve(K_aug + diag(1e-6, n_samples + 1))
  
  for (j in 1:min(n_grid, 500)) { # Vectorized in Rcpp kernel in production
    target_dist <- sqrt((sample_coords[, 1] - grid_coords[j, 1])^2 + (sample_coords[, 2] - grid_coords[j, 2])^2)
    k_0 <- spherical_variogram_fn(target_dist, nugget, sill, range_a)
    k_0_aug <- c(k_0, 1)
    
    weights_aug <- K_inv %*% k_0_aug
    weights <- weights_aug[1:n_samples]
    mu <- weights_aug[n_samples + 1]
    
    predictions[j] <- sum(weights * sample_values)
    kriging_variances[j] <- sum(weights * k_0) + mu
  }
  
  list(
    grid_points = n_grid,
    mean_prediction = mean(predictions[1:min(n_grid, 500)]),
    mean_variance = mean(kriging_variances[1:min(n_grid, 500)]),
    model = list(type = "Spherical", nugget = nugget, sill = sill, range_m = range_a)
  )
}
