# ==============================================================================
# AARDVARK SUBSEA R — CALIBRATION: INSTRUMENT PROFILES & METADATA
# Sensor intrinsic models, camera pinhole parameters, spectrometer wavelength arrays
# ==============================================================================

# Camera Intrinsic Matrix K for underwater stereo imaging head
# Includes refractive index compensation for flat sapphire port window (n_water = 1.341, n_sapphire = 1.77)
CAMERA_INTRINSIC_PROFILE <- list(
  model = "Brown-Conrady Distortion with Underwater Refraction Port Model",
  sensor_resolution = c(3840, 2160),
  fx_px = 2840.5,
  fy_px = 2841.2,
  cx_px = 1920.0,
  cy_px = 1080.0,
  distortion_k1 = -0.0842,
  distortion_k2 = 0.0125,
  distortion_p1 = 0.0001,
  distortion_p2 = -0.0002,
  port_thickness_mm = 28.0,
  port_refractive_index = 1.77
)

# 224-Band VNIR Hyperspectral Calibration Array
HYPERSPECTRAL_WAVELENGTHS <- seq(400.0, 1000.0, length.out = 224)
