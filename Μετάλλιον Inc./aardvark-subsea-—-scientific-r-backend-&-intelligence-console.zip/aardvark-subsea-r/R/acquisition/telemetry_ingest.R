# ==============================================================================
# AARDVARK SUBSEA R — ACQUISITION: TELEMETRY INGEST
# Navigation, CTD, IMU, depth/altimeter integration, coordinate transformations
# ==============================================================================

library(R6)
library(data.table)

TelemetryIngest <- R6Class("TelemetryIngest",
  public = list(
    current_position = NULL,
    current_environment = NULL,
    history = NULL,
    
    initialize = function() {
      self$history <- data.table(
        timestamp = as.POSIXct(character()),
        latitude = numeric(),
        longitude = numeric(),
        depth_m = numeric(),
        altitude_m = numeric(),
        heading_deg = numeric(),
        sound_velocity_mps = numeric()
      )
      self$set_sample_telemetry()
    },
    
    set_sample_telemetry = function() {
      self$current_position <- list(
        latitude = 12.483120,
        longitude = -135.291480,
        depth_m = 4218.45,
        altitude_m = 4.25,
        heading_deg = 248.5,
        pitch_deg = -1.2,
        roll_deg = 0.4,
        utm_zone = "10N",
        utm_easting = 250842.1,
        utm_northing = 1381204.8
      )
      
      self$current_environment <- list(
        sound_velocity_mps = 1528.4,
        salinity_psu = 34.68,
        temperature_c = 1.42,
        density_kg_m3 = 1048.2,
        pressure_bar = 428.1
      )
    },
    
    ingest_record = function(record) {
      new_row <- data.table(
        timestamp = record$timestamp %||% Sys.time(),
        latitude = record$latitude,
        longitude = record$longitude,
        depth_m = record$depth_m,
        altitude_m = record$altitude_m,
        heading_deg = record$heading_deg,
        sound_velocity_mps = record$sound_velocity_mps
      )
      self$history <- rbind(self$history, new_row)
      self$current_position$latitude <- record$latitude
      self$current_position$longitude <- record$longitude
      self$current_position$depth_m <- record$depth_m
    },
    
    get_latest = function() {
      list(
        position = self$current_position,
        environment = self$current_environment,
        timestamp = Sys.time()
      )
    }
  )
)

telemetry_service <- TelemetryIngest$new()
