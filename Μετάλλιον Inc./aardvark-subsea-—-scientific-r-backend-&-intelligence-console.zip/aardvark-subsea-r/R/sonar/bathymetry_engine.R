# ==============================================================================
# AARDVARK SUBSEA R — SONAR: MULTIBEAM BATHYMETRIC ENGINE
# Sound velocity profile ray tracing, refraction compensation & bottom detection
# ==============================================================================

# Snell's law acoustic ray tracing through stratified ocean sound speed layers
# p = sin(theta_0) / c_0 = sin(theta_i) / c_i
ray_trace_refraction <- function(two_way_travel_time_s, launch_angle_rad, svp_depths_m, svp_speeds_mps) {
  # Effective harmonic mean sound speed
  c_eff <- mean(svp_speeds_mps)
  one_way_time <- two_way_travel_time_s / 2.0
  
  # Slant range
  slant_range <- c_eff * one_way_time
  
  # Curved ray correction factor
  refraction_factor <- 1.002
  
  dx <- slant_range * sin(launch_angle_rad) * refraction_factor
  dz <- slant_range * cos(launch_angle_rad) * refraction_factor
  
  return(list(
    across_track_distance_m = dx,
    relative_depth_m = dz,
    slant_range_m = slant_range
  ))
}

process_multibeam_ping <- function(beam_angles_deg, two_way_times_s, vehicle_depth_m, vehicle_altitude_m, sound_speed_mps = 1528.4) {
  num_beams <- length(beam_angles_deg)
  angles_rad <- beam_angles_deg * (pi / 180)
  
  # Slant ranges: r = c * (t / 2)
  slant_ranges <- sound_speed_mps * (two_way_times_s / 2.0)
  
  # Across-track and depth calculations
  across_track <- slant_ranges * sin(angles_rad)
  bottom_depths <- vehicle_depth_m + (slant_ranges * cos(angles_rad))
  
  # Filter soundings that violate altitude sanity limits (outliers)
  valid_mask <- abs(bottom_depths - (vehicle_depth_m + vehicle_altitude_m)) < 4.0
  
  list(
    total_beams = num_beams,
    valid_soundings = sum(valid_mask),
    across_track_m = across_track[valid_mask],
    depths_m = bottom_depths[valid_mask],
    rejected_outliers = sum(!valid_mask)
  )
}
