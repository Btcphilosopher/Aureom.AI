# ==============================================================================
# AARDVARK SUBSEA R — SONAR: ACOUSTIC BACKSCATTER & SIDE-SCAN ENGINE
# TVG compensation, slant-range correction, angular response equalization
# ==============================================================================

# Time-Varying Gain (TVG) acoustic transmission loss compensation:
# TL = 20 * log10(R) + 2 * alpha * R
# where R is range in meters, alpha is seawater absorption in dB/m (e.g. 0.08 dB/m at 400kHz in deep sea)
apply_tvg_compensation <- function(raw_amplitudes, sample_ranges_m, alpha_db_m = 0.08) {
  tvg_gain_db <- (20 * log10(pmax(1.0, sample_ranges_m))) + (2 * alpha_db_m * sample_ranges_m)
  # Convert gain from dB to linear multiplier: 10^(gain_db / 20)
  gain_linear <- 10^(tvg_gain_db / 20)
  
  compensated <- raw_amplitudes * gain_linear
  return(compensated)
}

# Slant-range to ground-range geometric projection
# ground_range = sqrt(max(0, slant_range^2 - altitude^2))
correct_slant_range <- function(slant_ranges_m, altitude_m) {
  ground_ranges <- sqrt(pmax(0, slant_ranges_m^2 - altitude_m^2))
  return(ground_ranges)
}

# Acoustic facies classifier for polymetallic nodule pavement
# High backscatter (-22 to -26 dB) with high micro-roughness strongly correlates with nodule fields
classify_acoustic_facies <- function(backscatter_db, roughness_index) {
  if (backscatter_db > -26.0 && roughness_index > 0.45) {
    return(list(facies = "Dense Polymetallic Nodule Pavement", probability = 0.92))
  } else if (backscatter_db > -32.0) {
    return(list(facies = "Sparse Nodules on Pelagic Sediment", probability = 0.81))
  } else {
    return(list(facies = "Soft Pelagic Clay / Siliceous Ooze", probability = 0.95))
  }
}
