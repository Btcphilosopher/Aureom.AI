# ==============================================================================
# AARDVARK SUBSEA R — FUSION: MULTI-SENSOR SPATIO-TEMPORAL ALIGNMENT
# 6-DoF lever arms, Euler rotation matrices, timestamp sync & covariance propagation
# ==============================================================================

# Sensor lever arm offsets relative to AUV Center of Navigation (IMU center) in meters: [X_fwd, Y_stbd, Z_down]
SENSOR_LEVER_ARMS <- list(
  stereo_camera_port = c(1.85, -0.42, 0.65),
  hyperspectral_head = c(1.92, 0.00, 0.68),
  raman_probe        = c(1.75, 0.35, 0.72),
  multibeam_sonar    = c(0.45, 0.00, 0.85)
)

# 3D Rotation matrix from Roll (phi), Pitch (theta), Heading (psi) in radians
build_rotation_matrix <- function(roll_rad, pitch_rad, heading_rad) {
  # Body-to-NED (North-East-Down) rotation
  cr <- cos(roll_rad);   sr <- sin(roll_rad)
  cp <- cos(pitch_rad);  sp <- sin(pitch_rad)
  ch <- cos(heading_rad); sh <- sin(heading_rad)
  
  R_z <- matrix(c(ch, -sh, 0, sh, ch, 0, 0, 0, 1), nrow = 3, byrow = TRUE)
  R_y <- matrix(c(cp, 0, sp, 0, 1, 0, -sp, 0, cp), nrow = 3, byrow = TRUE)
  R_x <- matrix(c(1, 0, 0, 0, cr, -sr, 0, sr, cr), nrow = 3, byrow = TRUE)
  
  R <- R_z %*% R_y %*% R_x
  return(R)
}

# Georeference target point detected in sensor frame to world coordinates (UTM / Depth)
transform_sensor_point_to_world <- function(point_sensor_frame, sensor_id, vehicle_pos, roll_deg, pitch_deg, heading_deg) {
  lever_arm <- SENSOR_LEVER_ARMS[[sensor_id]] %||% c(0, 0, 0)
  
  # Total offset in body coordinates
  p_body <- lever_arm + point_sensor_frame
  
  # Convert angles to radians
  R <- build_rotation_matrix(roll_deg * pi/180, pitch_deg * pi/180, heading_deg * pi/180)
  p_ned <- as.vector(R %*% p_body)
  
  # Global coordinates
  world_easting <- vehicle_pos$utm_easting + p_ned[2]
  world_northing <- vehicle_pos$utm_northing + p_ned[1]
  world_depth <- vehicle_pos$depth_m + p_ned[3]
  
  # Positional uncertainty covariance propagation
  uncertainty_sd_m <- sqrt(vehicle_pos$position_uncertainty_sd_m^2 + (0.02 * norm(point_sensor_frame, "2"))^2)
  
  list(
    easting_m = world_easting,
    northing_m = world_northing,
    depth_m = world_depth,
    positional_uncertainty_sd_m = round(uncertainty_sd_m, 3),
    lever_arm_applied = lever_arm
  )
}
