# ==============================================================================
# AARDVARK SUBSEA R — CARBON: SPECTRAL CHARACTERISATION & TYPING
# D-band/G-band ratio, crystallite size La, structural order & carbonate classification
# ==============================================================================

characterise_carbon_spectrum <- function(d_band_fit, g_band_fit, carbonate_fit = NULL, laser_nm = 532.0) {
  # 1. Intensity and Area Ratios
  id_ig_ratio <- d_band_fit$height_counts / max(1e-6, g_band_fit$height_counts)
  ad_ag_ratio <- d_band_fit$area_counts / max(1e-6, g_band_fit$area_counts)
  
  # 2. In-plane crystallite size La (nm) via Tuinstra-Koenig formula:
  # La (nm) = (2.4 * 10^-10) * (laser_nm)^4 * (ID / IG)^(-1)
  # For 532 nm laser:
  c_lambda <- (2.4e-10) * (laser_nm^4) # ~19.2 nm
  crystallite_size_la_nm <- c_lambda * (1.0 / max(0.01, id_ig_ratio))
  
  # 3. Structural Ordering Classification
  order_desc <- if (id_ig_ratio < 0.5) {
    "Highly Ordered / Graphitic Structure"
  } else if (id_ig_ratio <= 1.2) {
    "Disordered Microcrystalline Carbonaceous Material (Kerogen-like)"
  } else {
    "Amorphous / High-Defect Carbonaceous Phase"
  }
  
  # 4. Carbonate Detection Check (~1085 cm^-1 symmetric stretch)
  has_carbonate <- !is.null(carbonate_fit) && (carbonate_fit$height_counts > 500)
  
  list(
    id_ig_ratio = round(id_ig_ratio, 3),
    ad_ag_ratio = round(ad_ag_ratio, 3),
    crystallite_size_la_nm = round(crystallite_size_la_nm, 1),
    structural_order = order_desc,
    carbonate_detected = has_carbonate,
    carbonate_phase = if (has_carbonate) "Biogenic Aragonite / Calcite (Benthic Shell Remnants)" else "Below Detection Limit",
    regulatory_disclaimer = "Raman spectroscopy provides structural defect and vibrational fingerprinting. Quantitative Total Organic Carbon (TOC) or Total Inorganic Carbon (TIC) weight percentages require direct correlation with certified combustion elemental analysis (ISO 10694) or coulometric assays."
  )
}
