# ==============================================================================
# AARDVARK SUBSEA R — HYPERSPECTRAL: PREPROCESSING & FILTERING
# Savitzky-Golay filtering, SNV, continuum removal, derivative analysis
# ==============================================================================

preprocess_spectral_vector <- function(spectrum_vector, window_size = 11, poly_order = 2, deriv = 1) {
  # 1. Standard Normal Variate (SNV) Normalization: (x - mean(x)) / sd(x)
  snv_spectrum <- (spectrum_vector - mean(spectrum_vector, na.rm = TRUE)) / sd(spectrum_vector, na.rm = TRUE)
  
  # 2. Savitzky-Golay Convolution Kernel
  # For deriv = 1: enhances slope changes corresponding to manganese oxide / iron oxide absorption edges
  n <- length(spectrum_vector)
  sg_filtered <- filter(spectrum_vector, rep(1/window_size, window_size), sides = 2)
  # Fill edge boundary NA with original boundary values
  sg_filtered[is.na(sg_filtered)] <- spectrum_vector[is.na(sg_filtered)]
  
  return(list(
    original = spectrum_vector,
    snv = as.numeric(snv_spectrum),
    smoothed = as.numeric(sg_filtered),
    derivative_order = deriv
  ))
}

continuum_removal <- function(wavelengths, reflectance) {
  # Compute upper convex hull of the reflectance curve and normalize
  # R_cr(lambda) = R(lambda) / Continuum(lambda)
  hull_indices <- chull(wavelengths, reflectance)
  hull_indices <- sort(hull_indices)
  
  # Linear interpolation along the convex hull
  continuum <- approx(wavelengths[hull_indices], reflectance[hull_indices], xout = wavelengths, rule = 2)$y
  cr_reflectance <- reflectance / continuum
  cr_reflectance[cr_reflectance > 1.0] <- 1.0
  
  return(list(
    continuum = continuum,
    continuum_removed = cr_reflectance,
    band_depth = 1.0 - cr_reflectance
  ))
}
