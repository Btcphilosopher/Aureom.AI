# ==============================================================================
# AARDVARK SUBSEA R — HYPERSPECTRAL: SCIENTIFIC ANALYSIS ENGINE
# Spectral Angle Mapper (SAM), Spectral Information Divergence (SID), PCA & PLS-DA
# ==============================================================================

# Spectral Angle Mapper (SAM) calculation between target and reference spectrum
# theta = arccos( (t . r) / (||t|| * ||r||) )
calculate_sam_angle_rad <- function(target_spectrum, reference_spectrum) {
  dot_prod <- sum(target_spectrum * reference_spectrum)
  norm_t <- sqrt(sum(target_spectrum^2))
  norm_r <- sqrt(sum(reference_spectrum^2))
  
  if (norm_t == 0 || norm_r == 0) return(pi / 2)
  
  cos_theta <- dot_prod / (norm_t * norm_r)
  cos_theta <- max(-1.0, min(1.0, cos_theta))
  return(acos(cos_theta))
}

# Spectral Information Divergence (SID)
# Measures probabilistic divergence of normalized spectral probability distribution
calculate_sid_divergence <- function(target_spectrum, reference_spectrum) {
  p <- target_spectrum / sum(target_spectrum)
  q <- reference_spectrum / sum(reference_spectrum)
  
  eps <- 1e-12
  p <- pmax(p, eps)
  q <- pmax(q, eps)
  
  sid <- sum(p * log(p / q)) + sum(q * log(q / p))
  return(max(0, sid))
}

classify_hyperspectral_pixel <- function(pixel_spectrum, endmembers_matrix, threshold_rad = 0.15) {
  # Match against reference endmembers
  angles <- sapply(1:ncol(endmembers_matrix), function(i) {
    calculate_sam_angle_rad(pixel_spectrum, endmembers_matrix[, i])
  })
  names(angles) <- colnames(endmembers_matrix)
  
  best_idx <- which.min(angles)
  best_angle <- angles[best_idx]
  
  if (best_angle <= threshold_rad) {
    class_label <- names(angles)[best_idx]
    confidence <- 1.0 - (best_angle / threshold_rad)
  } else {
    class_label <- "unclassified_anomaly"
    confidence <- 0.0
  }
  
  list(
    assigned_class = class_label,
    spectral_angle_rad = best_angle,
    confidence = confidence,
    all_angles = angles
  )
}
