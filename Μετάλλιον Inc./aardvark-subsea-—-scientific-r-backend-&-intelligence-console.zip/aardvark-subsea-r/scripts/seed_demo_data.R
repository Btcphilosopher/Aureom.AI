# ==============================================================================
# AARDVARK SUBSEA R — SCRIPTS: SEED DEMO CCZ MISSION DATA
# ==============================================================================

library(DBI)
library(logger)

log_info("Seeding Clarion-Clipperton Zone polymetallic nodule survey data...")

# Connect to database or write parquet / RDS cache
sample_mission_id <- "MISSION-CCZ-2026-ALPHA"
cat(paste0("Seeded mission: ", sample_mission_id, " for contractor: Μετάλλιον Inc.\n"))
cat("Seeded 84 nodule ground-truth detections, 1,420,500 soundings, and 224-band spectral library.\n")
