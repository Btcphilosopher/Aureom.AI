# ==============================================================================
# AARDVARK SUBSEA R — SCRIPTS: LAUNCH PLUMBER REST API SERVICE
# ==============================================================================

library(plumber)
library(logger)

log_info("Starting Aardvark Subsea R Plumber Service on port 8000...")

pr <- plumb("api/plumber.R")
pr$run(host = "0.0.0.0", port = 8000, swagger = TRUE)
