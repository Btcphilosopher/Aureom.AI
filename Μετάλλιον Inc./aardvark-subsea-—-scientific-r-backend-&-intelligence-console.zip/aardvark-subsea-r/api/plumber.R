# ==============================================================================
# AARDVARK SUBSEA R — SCIENTIFIC BACKEND
# Enterprise Plumber REST API Router
#
# Client: Μετάλλιον Inc. (Polymetallic Nodule Survey Operations)
# Architecture: Plumber REST + R6 + data.table + sf + gstat + Rcpp
# Interoperability: Kotlin Android Operator Workstation & Silica Flux FPGA
# ==============================================================================

library(plumber)
library(jsonlite)
library(logger)

# Configure structured JSON logger
log_formatter(formatter_json)
log_threshold(INFO)
log_info("Initializing AARDVARK SUBSEA scientific backend...")

# Source R services and utilities
source("R/utilities/logger.R")
source("R/acquisition/sensor_manager.R")
source("R/optical/underwater_enhancement.R")
source("R/hyperspectral/analysis_engine.R")
source("R/raman/peak_fitting.R")
source("R/carbon/characterisation.R")
source("R/sonar/bathymetry_engine.R")
source("R/sonar/backscatter_processing.R")
source("R/fusion/sensor_fusion.R")
source("R/nodules/detection_pipeline.R")
source("R/nodules/grade_estimation.R")
source("R/geostatistics/variogram_kriging.R")
source("R/reconstruction/mesh_generator.R")
source("R/reporting/scientific_report.R")

#* @apiTitle AARDVARK SUBSEA Scientific Backend API
#* @apiDescription Enterprise REST service for subsea spectral imaging, sonar signal processing, polymetallic nodule characterisation, and marine geostatistics.
#* @apiVersion 1.4.0
#* @apiContact list(name = "Aardvark Imaging Subsea Systems", email = "scientific-systems@aardvarkimaging.com")

#* Cross-Origin Resource Sharing (CORS) & Audit Filter
#* @filter cors
function(req, res) {
  res$setHeader("Access-Control-Allow-Origin", "*")
  res$setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
  res$setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Operator-Id, X-Mission-Id")
  res$setHeader("X-Aardvark-Backend", "R-Plumber-4.4.1/Subsea-v1.4")
  
  if (req$REQUEST_METHOD == "OPTIONS") {
    res$status <- 200
    return(list())
  }
  
  # Audit event log
  log_info(paste0(req$REQUEST_METHOD, " ", req$PATH_INFO),
           client_ip = req$REMOTE_ADDR,
           operator = req$HTTP_X_OPERATOR_ID %||% "ANONYMOUS_WORKSTATION")
  
  plumber::forward()
}

# Mount modular route handlers
#* @plumber
function(pr) {
  pr %>%
    pr_mount("/api/v1/sensors", pr("api/routes/sensors.R")) %>%
    pr_mount("/api/v1/imaging", pr("api/routes/imaging.R")) %>%
    pr_mount("/api/v1/spectral", pr("api/routes/spectral.R")) %>%
    pr_mount("/api/v1/raman", pr("api/routes/carbon.R")) %>%
    pr_mount("/api/v1/carbon", pr("api/routes/carbon.R")) %>%
    pr_mount("/api/v1/sonar", pr("api/routes/sonar.R")) %>%
    pr_mount("/api/v1/nodules", pr("api/routes/nodules.R")) %>%
    pr_mount("/api/v1/mapping", pr("api/routes/mapping.R")) %>%
    pr_mount("/api/v1/missions", pr("api/routes/missions.R")) %>%
    pr_mount("/api/v1", pr("api/routes/diagnostics.R"))
}
