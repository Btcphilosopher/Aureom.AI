# ==============================================================================
# AARDVARK SUBSEA R — ROUTES: MISSIONS & ASYNC JOBS
# Subsea survey management, data packaging & asynchronous pipeline tracking
# ==============================================================================

library(plumber)
library(jsonlite)

#* List active and archived subsea exploration missions
#* @get /
function(res) {
  res$setHeader("Content-Type", "application/json")
  list(
    status = "SUCCESS",
    missions = list(
      list(
        mission_id = "MISSION-CCZ-2026-ALPHA",
        contractor = "Μετάλλιον Inc.",
        exploration_area = "Clarion-Clipperton Zone (Area C, Block 04)",
        water_depth_range_m = c(4150, 4290),
        status = "ACTIVE_ON_STATION",
        operator_in_charge = "Dr. Elena Rostova / Lead Geophysicist",
        vessel = "R/V Deep Surveyor VIII",
        vehicle = "AUV Aardvark DeepExplorer-04",
        start_time = "2026-11-01T04:00:00Z",
        total_survey_distance_km = 48.6,
        total_nodules_identified = 284150,
        estimated_nodule_tonnage = 3480.0
      ),
      list(
        mission_id = "MISSION-CCZ-2026-CALIBRATION",
        contractor = "Μετάλλιον Inc.",
        exploration_area = "Clarion-Clipperton Reference Station B",
        water_depth_range_m = c(4200, 4240),
        status = "COMPLETED_AUDITED",
        start_time = "2026-10-28T08:00:00Z"
      )
    )
  )
}

#* Get detailed mission summary, metadata & geostatistics
#* @get /<id>
function(id, res) {
  res$setHeader("Content-Type", "application/json")
  list(
    mission_id = id,
    contractor = "Μετάλλιον Inc.",
    target_area = "Clarion-Clipperton Fracture Zone",
    status = "ACTIVE",
    sensors_active = c("SNSR-OPT-HYPER-01", "SNSR-RAMAN-532", "SNSR-MBES-400K", "SNSR-SSS-900K", "SNSR-NAV-PHINS", "SNSR-CTD-SBE49"),
    statistics = list(
      dive_hours = 38.5,
      acoustic_pings = 1420500,
      optical_frames = 124500,
      hyperspectral_cubes = 480,
      raman_spectra = 124,
      mean_nodule_abundance_kg_m2 = 14.8,
      mean_grades_pct = list(
        mn = 28.6,
        ni = 1.34,
        cu = 1.10,
        co = 0.23,
        fe = 6.1
      )
    ),
    data_links = list(
      parquet_export = paste0("/api/v1/missions/", id, "/export?format=parquet"),
      geojson_detections = paste0("/api/v1/missions/", id, "/export?format=geojson"),
      pdf_report = paste0("/api/v1/missions/", id, "/export?format=pdf")
    )
  )
}

#* Export mission deliverables in requested scientific format
#* @post /<id>/export
#* @param format:character Output format: 'parquet', 'geojson', 'geotiff_bundle', or 'scientific_pdf'
function(id, format = "parquet", res) {
  res$setHeader("Content-Type", "application/json")
  list(
    status = "EXPORT_READY",
    mission_id = id,
    format = format,
    download_url = paste0("/exports/", id, "_scientific_bundle.", format),
    sha256_checksum = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    generated_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%OS3Z"),
    provenance_signature = "AARDVARK-SUBSEA-AUDIT-VALIDATED"
  )
}

#* Inspect status of asynchronous analytical job (future/promises queue)
#* @get /jobs/<job_id>
function(job_id, res) {
  res$setHeader("Content-Type", "application/json")
  list(
    job_id = job_id,
    state = "COMPLETED",
    progress_pct = 100.0,
    started_at = format(Sys.time() - 45, "%Y-%m-%dT%H:%M:%OS3Z"),
    completed_at = format(Sys.time() - 2, "%Y-%m-%dT%H:%M:%OS3Z"),
    execution_host = "r-worker-node-03",
    memory_peak_mb = 312.4,
    cpu_cores_used = 4
  )
}
