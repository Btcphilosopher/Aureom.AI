# ==============================================================================
# AARDVARK SUBSEA R — ROUTES: SENSORS & TELEMETRY
# Real-time sensor states, hardware streams & subsea telemetry
# ==============================================================================

library(plumber)
library(jsonlite)

#* Get list of all registered subsea sensors and acquisition modules
#* @get /
function(res) {
  res$setHeader("Content-Type", "application/json")
  sensors <- list(
    list(
      sensor_id = "SNSR-OPT-HYPER-01",
      sensor_name = "Aardvark HyperEye VNIR 400-1000nm",
      sensor_type = "hyperspectral_imager",
      spectral_bands = 224,
      frame_rate_hz = 30.0,
      status = "NOMINAL",
      fov_degrees = 42.5,
      calibration_id = "CAL-VNIR-2026-Q1",
      interface = "Silica Flux FPGA PCIe Gen3"
    ),
    list(
      sensor_id = "SNSR-RAMAN-532",
      sensor_name = "DeepOcean Raman In-Situ Spectrometer",
      sensor_type = "raman_spectrometer",
      excitation_wavelength_nm = 532.0,
      spectral_range_cm1 = c(200, 3400),
      status = "NOMINAL",
      integration_time_ms = 1200,
      calibration_id = "CAL-RAM-532-2026",
      interface = "Isolated High-Pressure Fiber Probe"
    ),
    list(
      sensor_id = "SNSR-MBES-400K",
      sensor_name = "Reson SeaBat T50-P Equivalent Multibeam",
      sensor_type = "multibeam_sonar",
      frequency_khz = 400.0,
      beams = 512,
      swath_angle_deg = 140.0,
      status = "ACTIVE",
      calibration_id = "CAL-MBES-PATCH-2026",
      interface = "GbE UDP Multicast"
    ),
    list(
      sensor_id = "SNSR-SSS-900K",
      sensor_name = "Dual-Frequency Side-Scan Sonar",
      sensor_type = "sidescan_sonar",
      frequency_khz = c(455.0, 900.0),
      range_per_side_m = 75.0,
      status = "ACTIVE",
      interface = "Direct High-Speed Serial / FPGA"
    ),
    list(
      sensor_id = "SNSR-NAV-PHINS",
      sensor_name = "iXblue Phins Subsea FOG IMU + DVL",
      sensor_type = "inertial_navigation",
      heading_accuracy_deg = 0.01,
      roll_pitch_accuracy_deg = 0.005,
      status = "LOCKED_DVL_BOTTOM",
      interface = "RS-422 NMEA / Binary"
    ),
    list(
      sensor_id = "SNSR-CTD-SBE49",
      sensor_name = "Seabird FastCAT SBE49 CTD",
      sensor_type = "environmental_ctd",
      sampling_rate_hz = 16.0,
      status = "STREAMING",
      interface = "RS-232"
    )
  )
  
  return(list(
    status = "success",
    timestamp = format(Sys.time(), "%Y-%m-%dT%H:%M:%OS3Z"),
    count = length(sensors),
    sensors = sensors
  ))
}

#* Get specific sensor metadata and calibration by ID
#* @get /<id>
function(id, res) {
  res$setHeader("Content-Type", "application/json")
  
  if (id == "SNSR-OPT-HYPER-01") {
    return(list(
      sensor_id = id,
      sensor_name = "Aardvark HyperEye VNIR 400-1000nm",
      status = "NOMINAL",
      temperature_sensor_c = -0.4,
      housing_pressure_bar = 425.2,
      wavelengths_nm = seq(400, 1000, length.out = 224),
      snr_db = 48.2,
      bad_bands = c(1, 2, 223, 224),
      exposure_ms = 12.5,
      white_ref_file = "data/spectral/white_ref_20261103.rds",
      dark_ref_file = "data/spectral/dark_ref_20261103.rds"
    ))
  }
  
  return(list(
    sensor_id = id,
    status = "NOMINAL",
    last_ping = format(Sys.time(), "%Y-%m-%dT%H:%M:%OS3Z"),
    health_score = 0.994
  ))
}

#* Get latest fused navigation telemetry and subsea environmental parameters
#* @get /telemetry/latest
function(res) {
  res$setHeader("Content-Type", "application/json")
  
  # Realistic Clarion-Clipperton Zone polymetallic nodule belt deep-sea telemetry
  list(
    timestamp = format(Sys.time(), "%Y-%m-%dT%H:%M:%OS3Z"),
    mission_id = "MISSION-CCZ-2026-ALPHA",
    vehicle_id = "AUV-AARDVARK-DEEPEXPLORER-04",
    navigation = list(
      latitude = 12.483120,
      longitude = -135.291480,
      crs = "EPSG:4326",
      depth_m = 4218.45,
      altitude_m = 4.25,
      heading_deg = 248.5,
      pitch_deg = -1.2,
      roll_deg = 0.4,
      surge_velocity_ms = 0.85,
      position_uncertainty_sd_m = 0.18
    ),
    environment = list(
      sound_velocity_mps = 1528.4,
      salinity_psu = 34.68,
      water_temperature_c = 1.42,
      dissolved_oxygen_umol_kg = 142.6,
      turbidity_ntu = 0.12,
      ambient_pressure_bar = 428.1
    ),
    fpga_bus = list(
      link_state = "SYNCED",
      buffer_utilization_pct = 14.8,
      dropped_packets = 0,
      bandwidth_mbps = 642.0
    )
  )
}
