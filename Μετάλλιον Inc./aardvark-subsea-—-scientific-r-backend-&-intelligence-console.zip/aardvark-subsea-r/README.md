# AARDVARK SUBSEA R — SCIENTIFIC BACKEND & SEABED INTELLIGENCE
**Developer**: Aardvark Imaging  
**Client / Industrial Operator**: Μετάλλιον Inc.  
**Domain**: Deep-Ocean Polymetallic Nodule Exploration, High-Resolution Spectral Imaging & Marine Geostatistics  
**Operational Area**: Clarion-Clipperton Fracture Zone (CCZ), Eastern Tropical Pacific (Water Depth 4,150 m – 4,300 m)  

---

## Architecture Overview
The AARDVARK SUBSEA scientific backend is an enterprise R 4.4+ service designed for subsea edge compute (AUV / ROV pressure vessels) and vessel-based operator workstations. It seamlessly bridges:
1. **Silica Flux / SystemVerilog FPGA**: High-bandwidth streaming ingestion via PCIe Gen3 & shared memory ring buffers.
2. **Plumber REST API**: Exposing OpenAPI 3.1 endpoints to the Kotlin Android operator workstation.
3. **Compiled C++ Kernels (Rcpp & RcppArmadillo)**: Vectorized spectral angle unmixing, acoustic refraction ray tracing, and image segmentation.
4. **PostgreSQL & PostGIS Database**: Spatio-temporal persistence, geospatial indexing (GiST), and ISA/JORC regulatory audit compliance.

```
aardvark-subsea-r/
├── api/
│   ├── plumber.R                 # Main Plumber API router & CORS/audit filters
│   ├── routes/                   # Modular REST endpoints
│   └── middleware/               # Bearer auth & audit logging
├── R/
│   ├── acquisition/              # Sensor manager & telemetry ingest
│   ├── optical/                  # Attenuation-aware enhancement (Jaffe-McGlamery)
│   ├── hyperspectral/            # 224-band calibration, Savitzky-Golay, SAM & SID
│   ├── raman/                    # In-situ 532nm Raman deconvolution & baseline
│   ├── carbon/                   # D/G-band ratios, crystallite sizing (La), carbon typing
│   ├── sonar/                    # Multibeam ray-tracing, bottom pick, TVG backscatter
│   ├── fusion/                   # 6-DoF lever arms, Euler rotations & covariance
│   ├── nodules/                  # Watershed segmentation, morphometrics, Mn/Ni/Cu/Co grades
│   ├── geostatistics/            # Semivariograms & Ordinary Kriging variance
│   ├── reconstruction/           # 3D bathymetric mesh (PLY/GLB) & GeoTIFF/GeoJSON
│   ├── calibration/              # Camera intrinsics & optical port models
│   ├── reporting/                # Automated JORC/NI 43-101 scientific reports
│   └── utilities/                # Structured logging & async task queues
├── src/                          # C++ Rcpp compiled performance kernels
├── database/                     # PostgreSQL + PostGIS schema & migrations
├── config/                       # Configuration YAML
├── data/                         # Calibrated spectral libraries, pings & test datasets
├── tests/testthat/               # Comprehensive unit & algorithmic test suite
├── benchmarks/                   # Measured execution benchmarks
├── scripts/                      # Launch scripts & demo data seeders
└── docs/                         # Kotlin Android contracts, API spec & validation reports
```

---

## Key Capabilities & Compliance

- **Hyperspectral SAM & SID**: 224-band VNIR cube classification distinguishing polymetallic nodules (vernadite, todorokite), pelagic clay, and biogenic carbonates.
- **Raman Carbon Characterisation**: Deconvolves D-band (~1350 cm⁻¹) and G-band (~1582 cm⁻¹) to determine crystallite size $L_a$ and carbon structural order. Distinguishes organic nuclei from biogenic carbonate shell fragments.
- **Sonar Refraction Correction**: Snell's law acoustic ray tracing utilizing in-situ CTD sound speed profiles.
- **Polymetallic Nodule Detection**: Morphometric extraction (Feret diameters, circularity, volume model) and multi-element grade estimates (Mn, Ni, Cu, Co, Fe) with rigorous 95% confidence bounds.
- **Marine Geostatistics**: Experimental semivariograms and Ordinary Kriging generating continuous seabed abundance maps ($kg/m^2$) with associated spatial estimation variance.
- **Regulatory Integrity**: Strictly enforces JORC Code (2012) and NI 43-101 compliance—distinguishing image-derived estimates from certified physical assays.
