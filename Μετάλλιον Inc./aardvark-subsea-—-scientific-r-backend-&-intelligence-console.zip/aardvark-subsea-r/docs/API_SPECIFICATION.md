# AARDVARK SUBSEA R — API SPECIFICATION (OpenAPI 3.1 & Plumber)
**Client**: Μετάλλιον Inc.  
**Platform**: Aardvark Subsea Scientific Backend  
**Protocols**: HTTP REST / Plumber / JSON / GeoJSON / Parquet / Binary PLY  

---

## Base URL
- Production Subsea Edge: `http://subsea-compute.local:8000/api/v1`
- Operator Workstation Proxy: `http://localhost:3000/api/v1`

---

## 1. System & Telemetry Endpoints

### `GET /health`
Returns service status, component health, and hardware link states.
**Response (200 OK)**:
```json
{
  "status": "HEALTHY",
  "service": "aardvark-subsea-r",
  "version": "1.4.0",
  "r_version": "4.4.1",
  "components": {
    "database_postgresql": "CONNECTED_POSTGIS_3.4",
    "fpga_sensor_bridge": "STREAMING_NOMINAL",
    "rcpp_acceleration": "LOADED_ARMADILLO_ACTIVE"
  }
}
```

### `GET /sensors`
Returns registry of all configured underwater sensors and calibrations.

### `GET /sensors/telemetry/latest`
High-frequency navigation, IMU orientation, depth, altitude, and CTD physical oceanography.

---

## 2. Imaging & Spectral Endpoints

### `POST /imaging/process`
Applies attenuation-aware Jaffe-McGlamery restoration, dark/flat corrections, and CLAHE.
- **Parameters**: `frame_id`, `method`, `dark_subtract`, `white_balance`

### `POST /spectral/analyse`
Executes 224-band hyperspectral cube unmixing and SAM/SID mineral endmember matching.
- **Parameters**: `cube_id`, `classifier` ('sam'/'sid'), `angle_threshold_rad`, `continuum_removal`

---

## 3. Raman & Carbon Characterisation

### `POST /raman/analyse`
Performs cosmic spike suppression, ALS baseline subtraction, and D/G band Lorentzian fitting.
- **Parameters**: `spectrum_id`, `laser_power_mw`, `integration_time_ms`, `cosmic_filter`
- **Returns**: `d_band`, `g_band`, `id_ig_intensity_ratio`, `crystallite_size_la_nm`, `carbonate_sym_stretch`

---

## 4. Sonar & Bathymetry

### `POST /sonar/process`
Ingests multibeam acoustic pings, executes refraction ray-tracing with CTD sound speed profiles, and produces gridded DEMs.
- **Parameters**: `ping_batch_id`, `sound_speed_mps`, `grid_resolution_m`

---

## 5. Polymetallic Nodule Detection & Geostatistics

### `POST /nodules/detect`
Segments nodules from optical/spectral data, calculates Feret diameters, area, circularity, mass, and statistical Mn/Ni/Cu/Co grade estimates with 95% confidence intervals.

### `POST /mapping/generate`
Fits empirical semivariograms and executes Ordinary Kriging to produce continuous seabed abundance surfaces ($kg/m^2$) and kriging variance uncertainty maps.

### `GET /mapping/layers`
Returns downloadable GeoTIFF, GeoJSON, Parquet, and 3D PLY/GLB spatial layers.
