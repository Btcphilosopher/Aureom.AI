package com.aardvark.subsea.api

import com.google.gson.annotations.SerializedName
import retrofit2.http.*
import kotlinx.coroutines.flow.Flow

/**
 * ==============================================================================
 * AARDVARK SUBSEA — KOTLIN OPERATOR WORKSTATION CONTRACTS
 * Client: Μετάλλιον Inc.
 * Target: Android Subsea Workstation Tablet & Rugged ROV/AUV Console
 * Integrates with Aardvark Subsea R Plumber Backend & Silica Flux FPGA
 * ==============================================================================
 */

// 1. Telemetry & Navigation Data Models
data class SubseaTelemetry(
    @SerializedName("timestamp") val timestamp: String,
    @SerializedName("mission_id") val missionId: String,
    @SerializedName("vehicle_id") val vehicleId: String,
    @SerializedName("navigation") val navigation: NavigationState,
    @SerializedName("environment") val environment: EnvironmentalState,
    @SerializedName("fpga_bus") val fpgaBus: FpgaBusHealth
)

data class NavigationState(
    @SerializedName("latitude") val latitude: Double,
    @SerializedName("longitude") val longitude: Double,
    @SerializedName("crs") val crs: String,
    @SerializedName("depth_m") val depthMeters: Double,
    @SerializedName("altitude_m") val altitudeMeters: Double,
    @SerializedName("heading_deg") val headingDegrees: Double,
    @SerializedName("pitch_deg") val pitchDegrees: Double,
    @SerializedName("roll_deg") val rollDegrees: Double,
    @SerializedName("surge_velocity_ms") val surgeVelocityMs: Double,
    @SerializedName("position_uncertainty_sd_m") val positionUncertaintySdMeters: Double
)

data class EnvironmentalState(
    @SerializedName("sound_velocity_mps") val soundVelocityMps: Double,
    @SerializedName("salinity_psu") val salinityPsu: Double,
    @SerializedName("water_temperature_c") val waterTemperatureCelsius: Double,
    @SerializedName("dissolved_oxygen_umol_kg") val dissolvedOxygenUmolKg: Double,
    @SerializedName("turbidity_ntu") val turbidityNtu: Double,
    @SerializedName("ambient_pressure_bar") val ambientPressureBar: Double
)

data class FpgaBusHealth(
    @SerializedName("link_state") val linkState: String,
    @SerializedName("buffer_utilization_pct") val bufferUtilizationPct: Double,
    @SerializedName("dropped_packets") val droppedPackets: Long,
    @SerializedName("bandwidth_mbps") val bandwidthMbps: Double
)

// 2. Polymetallic Nodule Detection & Morphometrics
data class NoduleDetectionResponse(
    @SerializedName("status") val status: String,
    @SerializedName("frame_id") val frameId: String,
    @SerializedName("surveyed_seabed_area_m2") val surveyedAreaM2: Double,
    @SerializedName("total_nodules_detected") val totalNodulesDetected: Int,
    @SerializedName("spatial_density_count_per_m2") val spatialDensityCountPerM2: Double,
    @SerializedName("seabed_coverage_pct") val seabedCoveragePct: Double,
    @SerializedName("estimated_wet_abundance_kg_per_m2") val estimatedWetAbundanceKgM2: Double,
    @SerializedName("sample_nodules") val sampleNodules: List<SubseaNodule>,
    @SerializedName("compliance_statement") val complianceStatement: String
)

data class SubseaNodule(
    @SerializedName("nodule_id") val noduleId: String,
    @SerializedName("center_x_px") val centerX: Int,
    @SerializedName("center_y_px") val centerY: Int,
    @SerializedName("latitude") val latitude: Double,
    @SerializedName("longitude") val longitude: Double,
    @SerializedName("feret_max_diameter_cm") val feretMaxDiameterCm: Double,
    @SerializedName("feret_min_diameter_cm") val feretMinDiameterCm: Double,
    @SerializedName("equivalent_diameter_cm") val equivalentDiameterCm: Double,
    @SerializedName("projected_area_cm2") val projectedAreaCm2: Double,
    @SerializedName("circularity") val circularity: Double,
    @SerializedName("estimated_volume_cm3") val estimatedVolumeCm3: Double,
    @SerializedName("estimated_wet_mass_g") val estimatedWetMassGrams: Double,
    @SerializedName("confidence_score") val confidenceScore: Double,
    @SerializedName("spectral_class") val spectralClass: String,
    @SerializedName("assay_estimates_pct") val assayEstimates: NoduleGradeAssays
)

data class NoduleGradeAssays(
    @SerializedName("manganese_mn") val manganese: GradeEstimate,
    @SerializedName("nickel_ni") val nickel: GradeEstimate,
    @SerializedName("copper_cu") val copper: GradeEstimate,
    @SerializedName("cobalt_co") val cobalt: GradeEstimate,
    @SerializedName("iron_fe") val iron: GradeEstimate
)

data class GradeEstimate(
    @SerializedName("value") val value: Double,
    @SerializedName("ci95_lower") val ci95Lower: Double,
    @SerializedName("ci95_upper") val ci95Upper: Double
)

// 3. Hyperspectral & Raman Analysis Models
data class RamanAnalysisResponse(
    @SerializedName("status") val status: String,
    @SerializedName("spectrum_id") val spectrumId: String,
    @SerializedName("peak_fits") val peakFits: RamanPeakFits,
    @SerializedName("carbon_structural_metrics") val carbonMetrics: CarbonStructuralMetrics,
    @SerializedName("carbon_classification") val carbonClassification: CarbonClassification,
    @SerializedName("scientific_disclaimer") val scientificDisclaimer: String
)

data class RamanPeakFits(
    @SerializedName("d_band") val dBand: PeakDetails,
    @SerializedName("g_band") val gBand: PeakDetails,
    @SerializedName("carbonate_sym_stretch") val carbonatePeak: PeakDetails?
)

data class PeakDetails(
    @SerializedName("peak_center_cm1") val centerCm1: Double,
    @SerializedName("peak_intensity_counts") val intensityCounts: Double,
    @SerializedName("fwhm_cm1") val fwhmCm1: Double,
    @SerializedName("peak_area") val peakArea: Double?
)

data class CarbonStructuralMetrics(
    @SerializedName("id_ig_intensity_ratio") val idIgRatio: Double,
    @SerializedName("crystallite_size_la_nm") val crystalliteSizeLaNm: Double,
    @SerializedName("structural_order") val structuralOrder: String
)

data class CarbonClassification(
    @SerializedName("primary_signature") val primarySignature: String,
    @SerializedName("confidence") val confidence: Double,
    @SerializedName("secondary_signature") val secondarySignature: String?
)

// 4. Retrofit REST API Client Interface for Kotlin Operator Workstation
interface AardvarkSubseaApiService {

    @GET("api/v1/health")
    suspend fun getHealth(): Map<String, Any>

    @GET("api/v1/sensors")
    suspend fun listSensors(): Map<String, Any>

    @GET("api/v1/sensors/telemetry/latest")
    suspend fun getLatestTelemetry(): SubseaTelemetry

    @POST("api/v1/nodules/detect")
    suspend fun detectNodules(
        @Query("frame_id") frameId: String,
        @Query("min_diameter_cm") minDiameterCm: Double = 1.5,
        @Query("confidence_threshold") confidenceThreshold: Double = 0.75
    ): NoduleDetectionResponse

    @POST("api/v1/raman/analyse")
    suspend fun analyseRaman(
        @Query("spectrum_id") spectrumId: String,
        @Query("laser_power_mw") laserPowerMw: Double = 45.0,
        @Query("integration_time_ms") integrationTimeMs: Int = 1500
    ): RamanAnalysisResponse

    @POST("api/v1/sonar/process")
    suspend fun processSonarPings(
        @Query("ping_batch_id") pingBatchId: String,
        @Query("sound_speed_mps") soundSpeedMps: Double = 1528.4
    ): Map<String, Any>

    @POST("api/v1/mapping/generate")
    suspend fun generateKrigingSurface(
        @Query("mission_id") missionId: String,
        @Query("variable") variable: String = "abundance_kg_m2",
        @Query("variogram_model") variogramModel: String = "Sph"
    ): Map<String, Any>
}
