# AARDVARK SUBSEA R — ENTERPRISE DEPLOYMENT GUIDE
**Hardware Target**: Subsea Pressure-Vessel Edge Compute (AUV / ROV) & Survey Ship Workstation  
**Platform**: Docker / Linux x86_64 / Kubernetes (k3s edge)  
**Host Specifications**: Intel Xeon-D or AMD EPYC Embedded, 64 GB ECC RAM, PCIe NVMe array, Silica Flux FPGA PCIe Gen3 card  

---

## 1. Containerised Deployment
The backend runs as a high-reliability container with hardware device pass-through for the Silica Flux PCIe interface.

```bash
# Build production Docker container
docker build -t aardvark-subsea-r:1.4.0 -f Dockerfile .

# Launch container with FPGA PCIe and PostGIS integration
docker run -d \
  --name aardvark-subsea-backend \
  --restart always \
  --network host \
  --device=/dev/silica_flux_fpga0 \
  -v /var/subsea/data:/aardvark-subsea-r/data \
  -e POSTGRES_HOST=127.0.0.1 \
  -e POSTGRES_PORT=5432 \
  -e POSTGRES_DB=aardvark_subsea \
  aardvark-subsea-r:1.4.0
```

---

## 2. PostgreSQL + PostGIS Initialization
Apply schema and spatial indices:
```bash
psql -U aardvark_admin -d aardvark_subsea -f database/schema.sql
psql -U aardvark_admin -d aardvark_subsea -f database/migrations/001_initial_schema.sql
```

---

## 3. Package Management with `renv`
To restore the exact reproducible R package environment:
```R
Rscript -e 'renv::restore()'
```

---

## 4. Hardware Safety Interlocks & Watchdog
Hardware safety interlocks for the 532 nm Raman laser and pressure vessel housing operate independently in the hardware domain:
- FPGA watchdog requires heartbeat from R process every 500 ms.
- If the R process halts or memory exceeds limits, hardware physical shutters instantly de-energize the laser and lock payload power.
