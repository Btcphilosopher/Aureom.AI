# Sample feeds and submissions

The CSV/JSON feeds used by the demonstration live with their fictional supplier
sites so the collector retrieves them over (in-process) HTTP exactly as it would
a real feed:

| Feed | Format | Path |
|---|---|---|
| Ohmly product feed | CSV, comma, en-GB prices | `../supplier_sites/ohmly.fixture.test/feeds/products.csv` |
| GreenBasket assortment | CSV, semicolon, decimal commas (de-DE) | `../supplier_sites/greenbasket.fixture.test/export/sortiment.csv` |
| FreshCart products | JSON | `../supplier_sites/freshcart.fixture.test/feed/products.json` |
| DailyPantry products | JSON | `../supplier_sites/dailypantry.fixture.test/feed/products.json` |
| GadgetGrove offers API | JSON, paginated, bearer token | `../supplier_sites/gadgetgrove.fixture.test/api/v1/offers.json` |

`clubtronics_submission.json` is a manual supplier submission, posted to
`POST /api/v1/supplier/listings` by an authenticated supplier account.
