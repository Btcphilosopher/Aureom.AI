// Renders the product from a JSON document: without a browser the page has no product data.
(async function () {
  const root = document.getElementById('app');
  const response = await fetch('/data/' + root.dataset.product + '.json');
  const p = await response.json();
  const el = (tag, cls, text) => { const n = document.createElement(tag); n.className = cls; n.textContent = text; return n; };
  root.textContent = '';
  root.appendChild(el('h1', 'pp-title', p.title));
  root.appendChild(el('p', 'pp-brand', p.brand));
  root.appendChild(el('p', 'pp-model', p.model));
  root.appendChild(el('p', 'pp-sku', p.sku));
  root.appendChild(el('p', 'pp-price', p.price));
  root.appendChild(el('p', 'pp-vat', p.vat));
  root.appendChild(el('p', 'pp-condition', p.condition));
  root.appendChild(el('p', 'pp-stock', p.stock));
  root.appendChild(el('p', 'pp-delivery', p.delivery));
  const table = document.createElement('table'); table.className = 'pp-specs';
  for (const [k, v] of Object.entries(p.specs)) {
    const tr = document.createElement('tr');
    tr.appendChild(el('th', '', k)); tr.appendChild(el('td', '', v)); table.appendChild(tr);
  }
  root.appendChild(table);
})();
