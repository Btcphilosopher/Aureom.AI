// Price Watch progressive enhancement. The site works without this file.
(function () {
  'use strict';

  // Price-history chart: crosshair + tooltip for the nearest observation.
  function enhanceChart(figure) {
    var svg = figure.querySelector('svg');
    var tooltip = figure.querySelector('.chart-tooltip');
    var crosshair = svg && svg.querySelector('.crosshair');
    var points = svg ? Array.prototype.slice.call(svg.querySelectorAll('.point')) : [];
    if (!svg || !tooltip || !points.length) { return; }

    function hide() {
      tooltip.hidden = true;
      crosshair.setAttribute('visibility', 'hidden');
      points.forEach(function (p) { p.setAttribute('r', '4'); });
    }

    svg.addEventListener('pointermove', function (event) {
      var box = svg.getBoundingClientRect();
      var view = svg.viewBox.baseVal;
      var scale = view.width / box.width;
      var x = (event.clientX - box.left) * scale;
      var y = (event.clientY - box.top) * scale;
      var nearest = null;
      var best = Infinity;
      points.forEach(function (p) {
        var dx = parseFloat(p.getAttribute('cx')) - x;
        var dy = parseFloat(p.getAttribute('cy')) - y;
        var distance = dx * dx * 4 + dy * dy; // favour the x direction
        if (distance < best) { best = distance; nearest = p; }
      });
      if (!nearest) { return hide(); }
      points.forEach(function (p) { p.setAttribute('r', p === nearest ? '6' : '4'); });
      var cx = parseFloat(nearest.getAttribute('cx'));
      var cy = parseFloat(nearest.getAttribute('cy'));
      crosshair.setAttribute('x1', cx);
      crosshair.setAttribute('x2', cx);
      crosshair.setAttribute('visibility', 'visible');
      tooltip.textContent = nearest.dataset.supplier + ' · ' + nearest.dataset.price + ' · checked ' + nearest.dataset.time;
      tooltip.hidden = false;
      var figureBox = figure.getBoundingClientRect();
      var left = box.left - figureBox.left + cx / scale;
      var half = tooltip.offsetWidth / 2;
      left = Math.max(half, Math.min(figureBox.width - half, left));
      tooltip.style.left = left + 'px';
      tooltip.style.top = (box.top - figureBox.top + cy / scale) + 'px';
    });
    svg.addEventListener('pointerleave', hide);
  }

  function init(root) {
    Array.prototype.forEach.call(root.querySelectorAll('[data-chart]'), enhanceChart);
  }

  document.addEventListener('DOMContentLoaded', function () { init(document); });
  document.body && document.body.addEventListener('htmx:afterSwap', function (event) { init(event.target); });
})();
