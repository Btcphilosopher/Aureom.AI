#!/usr/bin/env sh
# Create a compressed, consistent PostgreSQL backup (custom format).
#
#   DATABASE_URL=postgresql://user:pass@host:5432/pricewatch scripts/backup.sh [output-directory]
#
# Docker Compose (uses the database container's own pg_dump, so versions always match):
#   docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -Fc "$POSTGRES_DB"' > backups/pricewatch-$(date -u +%Y%m%dT%H%M%SZ).dump
set -eu

: "${DATABASE_URL:?Set DATABASE_URL to the database to back up}"
OUT_DIR="${1:-backups}"
mkdir -p "$OUT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
FILE="$OUT_DIR/pricewatch-$STAMP.dump"

umask 077  # backups contain personal data (accounts, alerts): owner-only
pg_dump --dbname="$DATABASE_URL" --format=custom --no-owner --no-privileges --file="$FILE.partial"
mv "$FILE.partial" "$FILE"
sha256sum "$FILE" > "$FILE.sha256"
echo "$FILE"
