#!/usr/bin/env sh
# Restore a backup made by scripts/backup.sh into an EMPTY database.
#
#   TARGET_DATABASE_URL=postgresql://user:pass@host:5432/pricewatch_restore scripts/restore.sh backups/pricewatch-....dump
#
# The target must already exist and be empty (createdb). This script never drops anything.
set -eu

DUMP="${1:?Usage: restore.sh <dump file>}"
: "${TARGET_DATABASE_URL:?Set TARGET_DATABASE_URL to the empty database to restore into}"

if [ -f "$DUMP.sha256" ]; then
  sha256sum --check --quiet "$DUMP.sha256"
fi

TABLES="$(psql "$TARGET_DATABASE_URL" -At -c "select count(*) from information_schema.tables where table_schema = 'public'")"
if [ "$TABLES" != "0" ]; then
  echo "Refusing to restore: target database already contains $TABLES tables." >&2
  exit 1
fi

pg_restore --dbname="$TARGET_DATABASE_URL" --no-owner --no-privileges --exit-on-error --single-transaction "$DUMP"
echo "Restored $DUMP"
