#!/usr/bin/env sh
# Prove a backup is restorable: back up, restore into a scratch database, compare, drop the scratch database.
#
#   DATABASE_URL=postgresql://user:pass@host:5432/pricewatch scripts/verify_restore.sh [output-directory]
#
# Requires a role allowed to CREATE DATABASE. Exits non-zero on any difference.
# The verified dump and the comparison files are kept in the output directory.
set -eu

: "${DATABASE_URL:?Set DATABASE_URL}"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT_DIR="${1:-backups}"
SCRATCH="pricewatch_restore_check_$$"
SCRATCH_URL="${DATABASE_URL%/*}/$SCRATCH"

drop_scratch() {
  # Only ever drops the uniquely named scratch database this run created.
  psql "$DATABASE_URL" -q -c "DROP DATABASE IF EXISTS \"$SCRATCH\"" >/dev/null 2>&1 || true
}
trap drop_scratch EXIT

DUMP="$("$HERE/backup.sh" "$OUT_DIR")"
psql "$DATABASE_URL" -q -c "CREATE DATABASE \"$SCRATCH\""
TARGET_DATABASE_URL="$SCRATCH_URL" "$HERE/restore.sh" "$DUMP" >/dev/null

# Row counts for every table, plus a content checksum of the immutable price history.
COUNTS="select table_name, (xpath('/row/c/text()', query_to_xml('select count(*) as c from public.' || quote_ident(table_name), false, true, '')))[1]::text from information_schema.tables where table_schema = 'public' order by 1"
HISTORY="select md5(coalesce(string_agg(id || ':' || listing_id || ':' || coalesce(price_amount::text, '') || ':' || currency || ':' || status || ':' || observed_at, ',' order by id), '')) from suppliers_offerobservation"

psql "$DATABASE_URL" -At -c "$COUNTS" > "$DUMP.source-counts"
psql "$SCRATCH_URL" -At -c "$COUNTS" > "$DUMP.restored-counts"
SOURCE_SUM="$(psql "$DATABASE_URL" -At -c "$HISTORY")"
RESTORED_SUM="$(psql "$SCRATCH_URL" -At -c "$HISTORY")"

if ! diff "$DUMP.source-counts" "$DUMP.restored-counts" >/dev/null; then
  echo "FAILED: row counts differ" >&2
  diff "$DUMP.source-counts" "$DUMP.restored-counts" >&2 || true
  exit 1
fi
if [ "$SOURCE_SUM" != "$RESTORED_SUM" ]; then
  echo "FAILED: price history checksum differs" >&2
  exit 1
fi
TABLE_COUNT="$(wc -l < "$DUMP.source-counts" | tr -d ' ')"
OBSERVATIONS="$(psql "$SCRATCH_URL" -At -c 'select count(*) from suppliers_offerobservation')"
echo "OK: restore verified — $TABLE_COUNT tables match, $OBSERVATIONS price observations, history checksum $RESTORED_SUM"
echo "Verified dump: $DUMP"
