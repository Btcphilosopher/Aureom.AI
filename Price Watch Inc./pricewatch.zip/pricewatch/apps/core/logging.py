"""Structured JSON logging with request correlation and credential redaction."""
from __future__ import annotations

import contextvars
import json
import logging
import re
from datetime import datetime, timezone

request_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("request_id", default="-")

_SENSITIVE_KEYS = re.compile(r"(authorization|api[-_]?key|token|secret|password|cookie|credential)", re.I)
_SENSITIVE_INLINE = re.compile(
    r"(?i)\b(authorization|api[-_]?key|token|secret|password)\b(\s*[=:]\s*)(bearer\s+)?[^\s,;&\"']+"
)
_URL_USERINFO = re.compile(r"(https?://)[^/\s:@]+:[^/\s@]+@")

_RESERVED = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__) | {"message", "asctime"}


def redact(value):
    """Remove credentials from anything about to be logged or stored as evidence."""
    if isinstance(value, dict):
        return {k: ("[REDACTED]" if _SENSITIVE_KEYS.search(str(k)) else redact(v)) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact(v) for v in value]
    if isinstance(value, str):
        value = _URL_USERINFO.sub(r"\1[REDACTED]@", value)
        return _SENSITIVE_INLINE.sub(lambda m: f"{m.group(1)}{m.group(2)}[REDACTED]", value)
    return value


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.fromtimestamp(record.created, timezone.utc).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "message": redact(record.getMessage()),
            "request_id": request_id_var.get(),
        }
        extras = {k: v for k, v in record.__dict__.items() if k not in _RESERVED and not k.startswith("_")}
        if extras:
            payload.update(redact(extras))
        if record.exc_info:
            payload["exception"] = redact(self.formatException(record.exc_info))
        return json.dumps(payload, default=str, ensure_ascii=False)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"pricewatch.{name}")
