"""Sanitisation of untrusted supplier text and safe tabular export.

Supplier content is data, never markup: we strip tags and control characters at
extraction time, and Django's template auto-escaping protects display. Nothing
in the templates uses ``|safe`` on supplier-derived values.
"""
from __future__ import annotations

import html
import re
import unicodedata
from urllib.parse import urlsplit

_TAG = re.compile(r"<[^>]*>")
_SCRIPT_BLOCK = re.compile(r"<(script|style|template|noscript)\b[^>]*>.*?</\1\s*>", re.I | re.S)
_WHITESPACE = re.compile(r"\s+")
# Bidi overrides and zero-width characters can be used to disguise text.
_INVISIBLE = {0x200B, 0x200C, 0x200D, 0x2060, 0xFEFF, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069}

_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r", "\n")


def clean_text(value: object, max_length: int = 300) -> str:
    """Return plain, single-line, length-capped text from untrusted input."""
    if value is None:
        return ""
    text = str(value)
    text = _SCRIPT_BLOCK.sub(" ", text)
    text = _TAG.sub(" ", text)
    text = html.unescape(text)
    text = _TAG.sub(" ", text)  # entities may have decoded into tags
    text = unicodedata.normalize("NFKC", text)
    text = "".join(
        ch for ch in text if ord(ch) not in _INVISIBLE and (ch in "\n\t " or unicodedata.category(ch)[0] != "C")
    )
    text = _WHITESPACE.sub(" ", text).strip()
    if len(text) > max_length:
        text = text[: max_length - 1].rstrip() + "…"
    return text


def clean_http_url(value: object, max_length: int = 1000) -> str:
    """Accept only absolute http(s) URLs without embedded credentials; otherwise ''."""
    if not value:
        return ""
    candidate = str(value).strip()
    if len(candidate) > max_length or any(ord(ch) < 0x20 for ch in candidate):
        return ""
    try:
        parts = urlsplit(candidate)
    except ValueError:
        return ""
    if parts.scheme not in {"http", "https"} or not parts.hostname or parts.username or parts.password:
        return ""
    return candidate


def spreadsheet_safe(value: object) -> str:
    """Neutralise spreadsheet formula injection (CSV/XLSX exports).

    Cells beginning with ``= + - @`` (or tab/CR/LF) are prefixed with an
    apostrophe so spreadsheet software treats them as text. Plain numbers such
    as ``-5.00`` are left alone.
    """
    text = "" if value is None else str(value)
    if not text:
        return text
    if text[0] in _FORMULA_PREFIXES:
        if re.fullmatch(r"[+-]?\d+(\.\d+)?", text):
            return text
        return "'" + text
    return text
