"""Idempotent creation of the demonstration catalogue, suppliers and sources."""
from __future__ import annotations

from decimal import Decimal

from django.db import transaction

from apps.catalogue.models import Category, Product, ProductVariant
from apps.suppliers.models import SourceConfiguration, Supplier

from . import demo_data


@transaction.atomic
def seed_catalogue_and_sources() -> dict[str, int]:
    categories = {}
    for spec in demo_data.CATEGORIES:
        categories[spec["slug"]], _ = Category.objects.update_or_create(slug=spec["slug"], defaults={k: v for k, v in spec.items() if k != "slug"})

    variant_count = 0
    for spec in demo_data.PRODUCTS:
        product, _ = Product.objects.update_or_create(
            slug=spec["slug"],
            defaults=dict(category=categories[spec["category"]], brand=spec["brand"], name=spec["name"], model=spec["model"],
                          description=spec["description"], specs=spec["specs"]),
        )
        for variant in spec["variants"]:
            values = dict(variant)
            name = values.pop("name")
            if values.get("net_quantity") is not None:
                values["net_quantity"] = Decimal(values["net_quantity"])
            ProductVariant.objects.update_or_create(product=product, name=name, defaults=values)
            variant_count += 1

    suppliers = {}
    for spec in demo_data.SUPPLIERS:
        suppliers[spec["slug"]], _ = Supplier.objects.update_or_create(
            slug=spec["slug"],
            defaults=dict(name=spec["name"], website_url=f"https://{spec['host']}/", allowed_domains=[spec["host"]],
                          membership_programme=spec.get("membership_programme", ""), is_fixture=True),
        )

    for spec in demo_data.SOURCES:
        existing = SourceConfiguration.objects.filter(key=spec["key"]).first()
        values = dict(
            supplier=suppliers[spec["supplier"]], name=spec["name"], kind=spec["kind"], entry_urls=spec["entry_urls"],
            settings=spec["settings"], authorisation_basis=spec["authorisation_basis"],
            credential_env_var=spec.get("credential_env_var", ""), min_request_interval_ms=200,
        )
        if existing is None:
            SourceConfiguration.objects.create(key=spec["key"], **values)
        else:
            for name, value in values.items():
                setattr(existing, name, value)
            existing.save()  # bumps the configuration version only if extraction settings changed
    return {"categories": len(categories), "products": len(demo_data.PRODUCTS), "variants": variant_count,
            "suppliers": len(suppliers), "sources": len(demo_data.SOURCES)}
