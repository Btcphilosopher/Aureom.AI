from __future__ import annotations

import re
import uuid

from .logging import request_id_var

_SAFE_ID = re.compile(r"^[A-Za-z0-9._-]{8,64}$")

# No inline scripts anywhere in the templates, so a strict policy is workable.
CONTENT_SECURITY_POLICY = (
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
    "connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'; object-src 'none'"
)
# Swagger UI/ReDoc (served from the sidecar package, same origin) need inline bootstrapping.
DOCS_CONTENT_SECURITY_POLICY = (
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data:; worker-src 'self' blob:; frame-ancestors 'none'; base-uri 'self'; object-src 'none'"
)


class RequestIdMiddleware:
    """Attach a request id to the request, the response and every log line."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        supplied = request.headers.get("X-Request-ID", "")
        request_id = supplied if _SAFE_ID.match(supplied) else uuid.uuid4().hex
        request.request_id = request_id
        # Set, not reset: Django logs 4xx/5xx after the middleware chain returns and should keep the id.
        request_id_var.set(request_id)
        response = self.get_response(request)
        response["X-Request-ID"] = request_id
        return response


class SecurityHeadersMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        if "Content-Security-Policy" not in response:
            docs = request.path.startswith("/api/v1/docs") or request.path.startswith("/api/v1/redoc")
            response["Content-Security-Policy"] = DOCS_CONTENT_SECURITY_POLICY if docs else CONTENT_SECURITY_POLICY
        response.setdefault("Permissions-Policy", "geolocation=(), camera=(), microphone=()")
        response.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        return response
