"""Liveness and readiness probes.

``/healthz`` answers if the process is up. ``/readyz`` checks the database, the
cache and (when a broker is configured) Redis, and reports each separately.
"""
from __future__ import annotations

from django.conf import settings
from django.core.cache import cache
from django.db import connection
from django.http import JsonResponse
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET


@never_cache
@require_GET
def liveness(request):
    return JsonResponse({"status": "ok"})


def _check_database() -> str:
    with connection.cursor() as cursor:
        cursor.execute("SELECT 1")
        cursor.fetchone()
    return "ok"


def _check_cache() -> str:
    cache.set("pricewatch:health", "1", 5)
    return "ok" if cache.get("pricewatch:health") == "1" else "failed"


def _check_broker() -> str:
    if settings.CELERY_TASK_ALWAYS_EAGER:
        return "skipped (eager mode)"
    import redis

    client = redis.Redis.from_url(settings.CELERY_BROKER_URL, socket_connect_timeout=1, socket_timeout=1)
    try:
        return "ok" if client.ping() else "failed"
    finally:
        client.close()


@never_cache
@require_GET
def readiness(request):
    checks: dict[str, str] = {}
    for name, check in (("database", _check_database), ("cache", _check_cache), ("broker", _check_broker)):
        try:
            checks[name] = check()
        except Exception as exc:  # report the class only; never leak connection strings
            checks[name] = f"failed ({exc.__class__.__name__})"
    healthy = all(v == "ok" or v.startswith("skipped") for v in checks.values())
    return JsonResponse({"status": "ok" if healthy else "degraded", "checks": checks}, status=200 if healthy else 503)
