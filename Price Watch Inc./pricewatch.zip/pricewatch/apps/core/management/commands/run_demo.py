"""Run the ten acceptance demonstrations against the fixture suppliers and print real results.

Requires ``PRICEWATCH_FIXTURE_MODE=true``. Uses a fixed, simulated timeline ending
at the current time so the price history has several points and the final state
on the website shows fresh, stale, conditional and incomplete offers together.
"""
from __future__ import annotations

import json
import os
import secrets
from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError

from apps.accounts.models import User
from apps.alerts.services import create_alert, evaluate_alert
from apps.catalogue.models import Category, ProductVariant
from apps.collection.pipeline import run_collection
from apps.comparisons.services import (
    BasketRequestItem,
    Requirements,
    compare_grocery_basket,
    compare_variant,
    money,
    price_history,
)
from apps.core.clock import FixedClock, system_clock
from apps.matching.models import MatchDecision
from apps.matching.services import review_decision
from apps.pricing.units import Quantity
from apps.suppliers.models import OfferObservation, SourceConfiguration, Supplier, SupplierListing
from apps.suppliers.submissions import submit_offer

X5_128 = "5060999000011"
BOOK14_16 = "5060999000042"


class Command(BaseCommand):
    help = "Demonstrate collection, matching, quarantine, totals, history, refresh, staleness, alerts and review."

    def add_arguments(self, parser):
        parser.add_argument("--password", help="Password for the demo accounts (default: random, printed once).")
        parser.add_argument("--force", action="store_true", help="Run even if observations already exist.")

    # -- output helpers ---------------------------------------------------------
    def step(self, number: int, title: str) -> None:
        self.stdout.write("")
        self.stdout.write(self.style.MIGRATE_HEADING(f"[{number}/10] {title}"))

    def show(self, result) -> None:
        for view in result.ranked:
            stale = "  STALE" if view.freshness.is_stale else ""
            self.stdout.write(f"    #{view.rank} {view.supplier.name:12} total {money(view.breakdown.total, 'GBP'):>9}  "
                              f"(items {money(view.breakdown.item_subtotal, 'GBP')}, delivery {money(view.breakdown.delivery_total, 'GBP')}, "
                              f"tax {money(view.breakdown.tax_total, 'GBP')}){stale}")
        for view in result.conditional:
            self.stdout.write(f"    conditional  {view.supplier.name:12} {money(view.breakdown.total, 'GBP')} — {' '.join(view.breakdown.conditions)}")
        for view in result.ineligible:
            self.stdout.write(f"    ineligible   {view.supplier.name:12} {money(view.breakdown.total, 'GBP')} — {' '.join(view.breakdown.conditions)}")
        for view in result.incomplete:
            self.stdout.write(f"    TOTAL INCOMPLETE {view.supplier.name:12} known {money(view.breakdown.known_subtotal, 'GBP')} — {'; '.join(view.breakdown.missing)}")

    def collect(self, clock, scenario=None, only=None) -> None:
        sources = SourceConfiguration.objects.select_related("supplier").exclude(kind="manual").order_by("key")
        if only:
            sources = sources.filter(key__in=only)
        for source in sources:
            run = run_collection(source, trigger="demo", clock=clock, scenario=scenario)
            detail = f" — {run.error_class}: {run.error_message}" if run.error_class else ""
            self.stdout.write(f"    {source.key:22} {run.status:9} valid={run.observations_valid} quarantined={run.observations_quarantined}{detail}")

    # -- the demonstration --------------------------------------------------------
    def handle(self, *args, **options):
        if not settings.PRICEWATCH["FIXTURE_MODE"]:
            raise CommandError("Set PRICEWATCH_FIXTURE_MODE=true: the demonstration only runs against fixture suppliers.")
        if OfferObservation.objects.exists() and not options["force"]:
            raise CommandError("Observations already exist. Use a fresh database (manage.py flush) or pass --force.")
        os.environ.setdefault("GADGETGROVE_API_KEY", "fixture-demo-key")  # matches the fixture API's expected token
        password = options["password"] or secrets.token_urlsafe(12)
        call_command("seed_demo", with_users=True, password=password, stdout=self.stdout)

        end = system_clock.now().replace(microsecond=0)
        clock = FixedClock(end - timedelta(hours=72))
        variant = ProductVariant.objects.select_related("product__category").get(gtin=X5_128)
        clubtronics = Supplier.objects.get(slug="clubtronics")
        supplier_user = User.objects.get(username="clubtronics-supplier")
        demo_user = User.objects.get(username="demo")
        reviewer = User.objects.get(username="reviewer")
        submission = json.loads((settings.BASE_DIR / "fixtures" / "feeds" / "clubtronics_submission.json").read_text())
        unknown = Requirements()
        not_member = Requirements.from_dict({"memberships": {"clubtronics": "not_held"}})

        self.step(1, "Collect a product's offers (HTML, JSON-LD, browser, CSV, API, JSON feeds, manual submission)")
        for hours in (72, 48, 24):
            clock.current = end - timedelta(hours=hours)
            self.stdout.write(f"  Collection at T-{hours}h")
            self.collect(clock)
            manual = submit_offer(clubtronics, submission, actor=supplier_user, clock=clock)
            self.stdout.write(f"    clubtronics-manual     {manual.observation.status:9} (supplier submission)")
        SupplierListing.objects.filter(supplier__slug="ohmly", supplier_sku="OH-X5-128").update(is_sponsored=True)
        result = compare_variant(variant, unknown, clock=clock)
        self.stdout.write(f"  {len(result.all_offers)} comparable offers for {variant.display_name}; "
                          f"{len(result.not_comparable)} excluded; {len(result.pending_review)} awaiting review.")

        self.step(2, "Reject an incompatible variant")
        for excluded in result.not_comparable:
            self.stdout.write(f"    {excluded.listing.supplier.name}: “{excluded.listing.title}” [{excluded.listing.supplier_sku}]")
            for reason in excluded.reasons:
                self.stdout.write(f"        - {reason}")

        self.step(3, "Quarantine an invalid price")
        for observation in OfferObservation.objects.filter(status="quarantined").select_related("listing__supplier").order_by("listing_id", "id").distinct("listing_id"):
            codes = ", ".join(issue["code"] for issue in observation.issues)
            self.stdout.write(f"    {observation.listing.supplier.name} {observation.listing.supplier_sku}: raw price “{observation.raw_price}” → {codes} (not published)")

        self.step(4, "Calculate complete totals")
        self.show(result)

        self.step(5, "Explain the winning eligible offer")
        self.stdout.write("  Membership unknown:")
        for line in result.explanation:
            self.stdout.write(f"    {line}")
        self.stdout.write("  Customer says they do NOT hold ClubTronics Plus:")
        for line in compare_variant(variant, not_member, clock=clock).explanation:
            self.stdout.write(f"    {line}")

        self.step(6, "Save price history")
        for series in price_history(variant):
            points = ", ".join(f"{t:%d %b %H:%M} {money(p, 'GBP')}" for t, p in series.points)
            self.stdout.write(f"    {series.listing.supplier.name:12} {len(series.points)} observations: {points}")
        alert = create_alert(user=demo_user, variant=variant, target_total=Decimal("400.00"), requirements=not_member, clock=clock)
        self.stdout.write(f"  Alert created for demo: total ≤ £400.00, new, ClubTronics membership not held → {evaluate_alert(alert, clock=clock).outcome}")

        self.step(7, "Refresh after a supplier change (scenario: price_change)")
        clock.current = end - timedelta(hours=6)
        self.collect(clock, scenario="price_change")
        submit_offer(clubtronics, submission, actor=supplier_user, clock=clock)
        result = compare_variant(variant, not_member, clock=clock)
        self.show(result)
        voltmart = SupplierListing.objects.get(supplier__slug="voltmart", supplier_sku="VM-X5-128")
        self.stdout.write(f"  VoltMart change first seen at the {voltmart.last_price_change_observed_at:%d %b %H:%M} check; "
                          f"it changed some time after the {voltmart.last_price_change_previous_check_at:%d %b %H:%M} check.")
        for observation in OfferObservation.objects.filter(status="quarantined", observed_at=clock.now()).select_related("listing__supplier"):
            for issue in observation.issues:
                if issue["severity"] == "quarantine":
                    self.stdout.write(f"  Quarantined {observation.listing.supplier.name} {observation.listing.supplier_sku}: {issue['message']}")

        self.step(8, "Keep stale information visible after a failure (scenario: outage)")
        clock.current = end - timedelta(hours=1)
        self.collect(clock, scenario="outage", only=["techhaven-html"])
        result = compare_variant(variant, not_member, clock=clock)
        self.show(result)
        for view in result.ranked:
            if view.freshness.is_stale:
                self.stdout.write(f"    {view.supplier.name}: last verified {view.freshness.observed_at:%d %b %H:%M} — {view.freshness.reason}")
        self.step(9, "Trigger a qualifying price alert")
        first = evaluate_alert(alert, clock=clock)
        self.stdout.write(f"    evaluation 1: {first.outcome} — {first.supplier} {money(first.total, 'GBP') if first.total else ''}")
        second = evaluate_alert(alert, clock=clock)
        self.stdout.write(f"    evaluation 2: {second.outcome} — {second.detail}")
        self.stdout.write(f"    notifications sent for this alert: {alert.notifications.count()}")

        self.step(10, "Review and correct a match")
        clock.current = end
        pending = MatchDecision.objects.filter(is_current=True, outcome="needs_review", listing__supplier__slug="pixelpoint", variant=variant).first()
        if pending is None:
            self.stdout.write("    PixelPoint listing not available (browser source did not collect); skipping the review example.")
        else:
            accepted = review_decision(pending, reviewer=reviewer, accept=True, note="Checked the product page: UK 128GB model.", clock=clock)
            self.stdout.write(f"    Review: PixelPoint “{pending.listing.title}” v{pending.version} needs_review → v{accepted.version} accepted by {reviewer.username}")
        laptop = ProductVariant.objects.get(gtin=BOOK14_16)
        wrong = MatchDecision.objects.filter(is_current=True, listing__supplier_sku="GG-61007", variant=laptop).first()
        if wrong is not None:
            reasons = "; ".join(r["message"] for r in wrong.reasons_against)
            corrected = review_decision(wrong, reviewer=reviewer, accept=True, clock=clock,
                                        note="Supplier confirmed a GTIN typo in their feed; specs are 16GB/512GB.")
            self.stdout.write(f"    Correction: GadgetGrove GG-61007 v{wrong.version} rejected by rules ({reasons})")
            self.stdout.write(f"                → v{corrected.version} accepted by {reviewer.username}; v{wrong.version} kept as history.")
            self.stdout.write(f"  {laptop.display_name} after the correction:")
            self.show(compare_variant(laptop, unknown, clock=clock))
        self.stdout.write(f"  {variant.display_name} after review (membership unknown):")
        self.show(compare_variant(variant, unknown, clock=clock))

        self.stdout.write("")
        self.stdout.write(self.style.MIGRATE_HEADING("Extensibility: grocery basket (unit conversion, packs, delivery per supplier)"))
        categories = {c.slug: c for c in Category.objects.filter(vertical="grocery")}
        items = [
            BasketRequestItem("rice", "2 kg basmati rice", categories["rice"], Quantity(Decimal(2), "kg"), "basmati"),
            BasketRequestItem("milk", "4 l semi-skimmed milk", categories["milk"], Quantity(Decimal(4), "l"), "semi-skimmed"),
            BasketRequestItem("eggs", "12 free range eggs", categories["eggs"], Quantity(Decimal(12), "each"), "free range"),
        ]
        basket = compare_grocery_basket(items, unknown, clock=clock).comparison
        for label, plan in (("Cheapest single supplier", basket.best_single_supplier), ("Baseline split (heuristic)", basket.baseline_split),
                            ("Exhaustive split", basket.exhaustive_split)):
            if plan is None:
                self.stdout.write(f"    {label}: none")
                continue
            suppliers = " + ".join(order.supplier_name for order in plan.orders)
            self.stdout.write(f"    {label}: {money(plan.total, 'GBP')} from {suppliers} ({plan.delivery_count} deliver{'y' if plan.delivery_count == 1 else 'ies'})")
        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS("Demonstration complete. Start the site with: python manage.py runserver"))
