"""Load the fictional catalogue, suppliers, source configurations and demo accounts."""
import secrets

from django.core.management.base import BaseCommand
from rest_framework.authtoken.models import Token

from apps.accounts.models import SupplierAccount, User
from apps.core.seeding import seed_catalogue_and_sources
from apps.suppliers.models import Supplier


class Command(BaseCommand):
    help = "Create demonstration data (idempotent). Demo accounts are created only with --with-users."

    def add_arguments(self, parser):
        parser.add_argument("--with-users", action="store_true", help="Create demo, reviewer and clubtronics-supplier accounts.")
        parser.add_argument("--password", help="Password for demo accounts (default: a random one, printed once).")

    def handle(self, *args, **options):
        counts = seed_catalogue_and_sources()
        self.stdout.write(self.style.SUCCESS("Seeded: " + ", ".join(f"{v} {k}" for k, v in counts.items())))
        if not options["with_users"]:
            return
        password = options["password"] or secrets.token_urlsafe(12)
        created_any = False
        for username, email, staff in (("demo", "demo@example.test", False), ("reviewer", "reviewer@example.test", True),
                                       ("clubtronics-supplier", "feeds@clubtronics.fixture.test", False)):
            user, created = User.objects.get_or_create(username=username, defaults={"email": email, "is_staff": staff})
            if created or options["password"]:
                user.set_password(password)
                user.is_staff = staff
                user.save()
                created_any = True
        supplier_user = User.objects.get(username="clubtronics-supplier")
        SupplierAccount.objects.get_or_create(user=supplier_user, supplier=Supplier.objects.get(slug="clubtronics"))
        token, _ = Token.objects.get_or_create(user=supplier_user)
        if created_any:
            self.stdout.write(f"Demo accounts: demo, reviewer (staff), clubtronics-supplier — password: {password}")
        self.stdout.write(f"Supplier API token for clubtronics-supplier: {token.key}")
