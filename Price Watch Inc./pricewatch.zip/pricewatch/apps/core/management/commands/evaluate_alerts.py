from django.core.management.base import BaseCommand

from apps.alerts.services import evaluate_active_alerts


class Command(BaseCommand):
    help = "Evaluate every active price alert once and print the outcome of each."

    def handle(self, *args, **options):
        for evaluation in evaluate_active_alerts():
            self.stdout.write(f"alert {evaluation.alert_id}: {evaluation.outcome} {evaluation.total or ''} {evaluation.supplier} {evaluation.detail}".rstrip())
