"""Collect from one or all sources synchronously and print what actually happened."""
from django.core.management.base import BaseCommand, CommandError

from apps.collection.pipeline import run_collection
from apps.suppliers.models import SourceConfiguration


class Command(BaseCommand):
    help = "Run collection now (without Celery). Exit status is non-zero if any run failed."

    def add_arguments(self, parser):
        parser.add_argument("--source", action="append", help="Source key (repeatable). Default: every collectable source.")
        parser.add_argument("--scenario", help="Fixture scenario (fixture mode only): baseline, price_change, outage, redesign.")

    def handle(self, *args, **options):
        sources = SourceConfiguration.objects.select_related("supplier").exclude(kind=SourceConfiguration.Kind.MANUAL)
        if options["source"]:
            sources = sources.filter(key__in=options["source"])
            missing = set(options["source"]) - set(sources.values_list("key", flat=True))
            if missing:
                raise CommandError(f"Unknown or manual source(s): {', '.join(sorted(missing))}")
        failed = 0
        for source in sources.order_by("key"):
            run = run_collection(source, scenario=options["scenario"])
            line = (f"{source.key:24} {run.status:10} documents={run.documents_fetched} valid={run.observations_valid} "
                    f"quarantined={run.observations_quarantined}")
            if run.error_class:
                line += f" error={run.error_class}: {run.error_message}"
            for failure in run.failures:
                line += f"\n    {failure['error']}: {failure['url']} — {failure['message']}"
            if run.status == "succeeded":
                self.stdout.write(self.style.SUCCESS(line))
            else:
                failed += 1
                self.stdout.write(self.style.WARNING(line))
        if failed:
            raise CommandError(f"{failed} source(s) did not complete successfully")
