"""Injectable clocks so services and tests never depend on wall-clock time."""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Iterator, Protocol


class Clock(Protocol):
    def now(self) -> datetime:
        """Return an aware UTC datetime."""
        ...


class SystemClock:
    """The process clock. Views and tasks use it by default; tests can freeze it."""

    def __init__(self) -> None:
        self._frozen: Clock | None = None

    def now(self) -> datetime:
        if self._frozen is not None:
            return self._frozen.now()
        return datetime.now(timezone.utc)

    @contextmanager
    def frozen(self, clock: "Clock") -> Iterator[None]:
        """Route ``now()`` to another clock for the duration (tests and demonstrations only)."""
        previous, self._frozen = self._frozen, clock
        try:
            yield
        finally:
            self._frozen = previous


@dataclass
class FixedClock:
    """Deterministic clock for tests and demonstrations."""

    current: datetime

    def __post_init__(self) -> None:
        if self.current.tzinfo is None:
            raise ValueError("FixedClock requires an aware datetime")

    def now(self) -> datetime:
        return self.current

    def advance(self, **kwargs: float) -> datetime:
        self.current = self.current + timedelta(**kwargs)
        return self.current


system_clock = SystemClock()
