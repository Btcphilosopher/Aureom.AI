"""Fictional catalogue, suppliers and source configurations for the demonstration.

Everything here is invented. The ``*.fixture.test`` hosts are served from
``fixtures/supplier_sites`` when ``PRICEWATCH_FIXTURE_MODE`` is on; ``.test`` is a
reserved TLD and never resolves on the public internet.
"""
from __future__ import annotations

PHONE_BOX = ["handset", "usb-c cable"]

CATEGORIES = [
    dict(slug="smartphones", name="Smartphones", vertical="electronics", identity_attributes=["storage_gb", "region"],
         filter_attributes=["storage_gb", "ram_gb", "brand"], description="Compare the exact model, storage and region."),
    dict(slug="laptops", name="Laptops", vertical="electronics", identity_attributes=["ram_gb", "storage_gb"],
         filter_attributes=["ram_gb", "storage_gb", "brand"], description="Exact models, or anything meeting your minimum spec."),
    dict(slug="rice", name="Rice", vertical="grocery", identity_attributes=["product_form", "organic"],
         filter_attributes=["product_form", "organic", "brand"], description="Compared by unit price across pack sizes."),
    dict(slug="milk", name="Milk", vertical="grocery", identity_attributes=["product_form", "organic"],
         filter_attributes=["product_form", "organic", "brand"], description="Compared by unit price across pack sizes."),
    dict(slug="eggs", name="Eggs", vertical="grocery", identity_attributes=["product_form", "organic"],
         filter_attributes=["product_form", "organic", "brand"], description="Compared per egg across pack sizes."),
]

# (category, brand, name, model, slug, description, variants[])
PRODUCTS = [
    dict(category="smartphones", brand="Lumio", name="Aurora X5", model="X5", slug="lumio-aurora-x5",
         description="6.4-inch 5G smartphone (fictional).", specs={"screen_inches": "6.4"}, variants=[
             dict(name="128GB", gtin="5060999000011", mpn="LUM-X5-128", attributes={"storage_gb": 128, "ram_gb": 8, "region": "UK"},
                  included_contents=PHONE_BOX, warranty="2 year manufacturer warranty"),
             dict(name="256GB", gtin="5060999000028", mpn="LUM-X5-256", attributes={"storage_gb": 256, "ram_gb": 8, "region": "UK"},
                  included_contents=PHONE_BOX, warranty="2 year manufacturer warranty"),
         ]),
    dict(category="smartphones", brand="Lumio", name="Aurora X5 Pro", model="X5 Pro", slug="lumio-aurora-x5-pro",
         description="The larger Pro model (fictional).", specs={"screen_inches": "6.8"}, variants=[
             dict(name="256GB", gtin="5060999000035", mpn="LUM-X5P-256", attributes={"storage_gb": 256, "ram_gb": 12, "region": "UK"},
                  included_contents=PHONE_BOX, warranty="2 year manufacturer warranty"),
         ]),
    dict(category="laptops", brand="Nimbus", name="Book 14", model="Book 14", slug="nimbus-book-14",
         description="14-inch everyday laptop (fictional).", specs={"screen_inches": "14"}, variants=[
             dict(name="16GB / 512GB", gtin="5060999000042", mpn="NIM-B14-16-512", attributes={"ram_gb": 16, "storage_gb": 512},
                  warranty="1 year manufacturer warranty"),
             dict(name="8GB / 256GB", gtin="5060999000059", mpn="NIM-B14-8-256", attributes={"ram_gb": 8, "storage_gb": 256},
                  warranty="1 year manufacturer warranty"),
         ]),
    dict(category="laptops", brand="Zephyr", name="Slate 15", model="Slate 15", slug="zephyr-slate-15",
         description="15.6-inch performance laptop (fictional).", specs={"screen_inches": "15.6"}, variants=[
             dict(name="16GB / 1TB", gtin="5060999000066", mpn="ZEP-S15-16-1T", attributes={"ram_gb": 16, "storage_gb": 1024},
                  warranty="2 year manufacturer warranty"),
         ]),
    dict(category="rice", brand="Sona", name="Basmati Rice", model="", slug="sona-basmati-rice", description="", specs={}, variants=[
        dict(name="500g", gtin="5060999000073", attributes={"product_form": "basmati", "organic": False}, net_quantity="500", net_quantity_unit="g"),
        dict(name="1kg", gtin="5060999000080", attributes={"product_form": "basmati", "organic": False}, net_quantity="1", net_quantity_unit="kg"),
        dict(name="2kg", gtin="5060999000097", attributes={"product_form": "basmati", "organic": False}, net_quantity="2", net_quantity_unit="kg"),
    ]),
    dict(category="rice", brand="Harvest Moon", name="Organic Basmati Rice", model="", slug="harvest-moon-organic-basmati-rice",
         description="", specs={}, variants=[
             dict(name="1kg", gtin="5060999000103", attributes={"product_form": "basmati", "organic": True}, net_quantity="1", net_quantity_unit="kg"),
         ]),
    dict(category="rice", brand="Sona", name="Long Grain Rice", model="", slug="sona-long-grain-rice", description="", specs={}, variants=[
        dict(name="1kg", gtin="5060999000110", attributes={"product_form": "long grain", "organic": False}, net_quantity="1", net_quantity_unit="kg"),
    ]),
    dict(category="milk", brand="Meadow", name="Semi-Skimmed Milk", model="", slug="meadow-semi-skimmed-milk", description="", specs={}, variants=[
        dict(name="1 litre", gtin="5060999000127", attributes={"product_form": "semi-skimmed", "organic": False}, net_quantity="1", net_quantity_unit="l"),
        dict(name="2 litres", gtin="5060999000134", attributes={"product_form": "semi-skimmed", "organic": False}, net_quantity="2", net_quantity_unit="l"),
        dict(name="4 pints", gtin="5060999000141", attributes={"product_form": "semi-skimmed", "organic": False}, net_quantity="4", net_quantity_unit="pt"),
    ]),
    dict(category="milk", brand="Meadow", name="Whole Milk", model="", slug="meadow-whole-milk", description="", specs={}, variants=[
        dict(name="2 litres", gtin="5060999000158", attributes={"product_form": "whole", "organic": False}, net_quantity="2", net_quantity_unit="l"),
    ]),
    dict(category="eggs", brand="Hillside", name="Free Range Eggs", model="", slug="hillside-free-range-eggs", description="", specs={}, variants=[
        dict(name="6 pack", gtin="5060999000165", attributes={"product_form": "free range", "organic": False}, pack_count=6,
             net_quantity="1", net_quantity_unit="each"),
        dict(name="12 pack", gtin="5060999000172", attributes={"product_form": "free range", "organic": False}, pack_count=12,
             net_quantity="1", net_quantity_unit="each"),
    ]),
]

SUPPLIERS = [
    dict(slug="techhaven", name="TechHaven", host="techhaven.fixture.test"),
    dict(slug="voltmart", name="VoltMart", host="voltmart.fixture.test"),
    dict(slug="pixelpoint", name="PixelPoint", host="pixelpoint.fixture.test"),
    dict(slug="ohmly", name="Ohmly", host="ohmly.fixture.test"),
    dict(slug="gadgetgrove", name="GadgetGrove", host="gadgetgrove.fixture.test"),
    dict(slug="clubtronics", name="ClubTronics", host="clubtronics.fixture.test", membership_programme="ClubTronics Plus"),
    dict(slug="freshcart", name="FreshCart", host="freshcart.fixture.test"),
    dict(slug="dailypantry", name="DailyPantry", host="dailypantry.fixture.test"),
    dict(slug="greenbasket", name="GreenBasket", host="greenbasket.fixture.test"),
]

_GBP_INC = {"currency": "GBP", "locale": "en-GB", "tax_treatment": "included"}
_GROCERY_FIELDS = {"sku": "sku", "title": "name", "brand": "brand", "gtin": "gtin", "net_quantity": "size",
                   "product_form": "form", "organic": "organic", "price": "price", "availability": "stock"}

SOURCES = [
    dict(
        key="techhaven-html", supplier="techhaven", name="Product pages (static HTML)", kind="html",
        entry_urls=["https://techhaven.fixture.test/catalogue.html"],
        authorisation_basis="Fictional fixture site. Public product pages; robots.txt honoured.",
        settings={
            "link_selector": "a.product-link",
            "extraction": {
                "fields": {
                    "title": {"selector": "h1.product-title"},
                    "brand": {"selector": "p.brand"},
                    "price": {"selector": "p.price .amount"},
                    "tax_treatment": {"selector": "p.price .vat"},
                    "condition": {"selector": "p.condition"},
                    "availability": {"selector": "p.stock"},
                    "delivery_cost": {"selector": ".delivery-cost"},
                    "delivery_free_threshold": {"selector": ".delivery-threshold"},
                    "gtin": {"selector": "dl.ids dd.gtin"},
                    "mpn": {"selector": "dl.ids dd.mpn"},
                    "model": {"selector": "dl.ids dd.model"},
                    "sku": {"selector": "main[data-sku]", "attr": "data-sku"},
                    "included": {"selector": "ul.in-the-box li", "many": True},
                    "warranty": {"selector": "p.warranty"},
                },
                "required": ["title", "price"],
                "specs": {"row": "table.specs tr", "key": "th", "value": "td"},
                "cross_check_structured_data": True,
            },
            "defaults": {"currency": "GBP", "locale": "en-GB"},
        },
    ),
    dict(
        key="voltmart-structured", supplier="voltmart", name="Product pages (schema.org JSON-LD)", kind="structured_data",
        entry_urls=["https://voltmart.fixture.test/index.html"],
        authorisation_basis="Fictional fixture site. Public structured data; robots.txt honoured.",
        settings={"link_selector": "a.item", "defaults": {"currency": "GBP", "locale": "en-GB"}},
    ),
    dict(
        key="pixelpoint-browser", supplier="pixelpoint", name="Product page (JavaScript-rendered)", kind="browser",
        entry_urls=["https://pixelpoint.fixture.test/product/aurora-x5.html"],
        authorisation_basis="Fictional fixture site. Explicitly authorised for rendered collection.",
        settings={
            "wait_for_selector": ".pp-price",
            "extraction": {
                "fields": {
                    "title": {"selector": ".pp-title"}, "brand": {"selector": ".pp-brand"}, "model": {"selector": ".pp-model"},
                    "sku": {"selector": ".pp-sku"}, "price": {"selector": ".pp-price"}, "tax_treatment": {"selector": ".pp-vat"},
                    "condition": {"selector": ".pp-condition"}, "availability": {"selector": ".pp-stock"},
                    "delivery_cost": {"selector": ".pp-delivery"},
                },
                "required": ["title", "price"],
                "specs": {"row": "table.pp-specs tr", "key": "th", "value": "td"},
            },
            "defaults": {"currency": "GBP", "locale": "en-GB"},
        },
    ),
    dict(
        key="ohmly-csv", supplier="ohmly", name="Product feed (CSV)", kind="csv_feed",
        entry_urls=["https://ohmly.fixture.test/feeds/products.csv"],
        authorisation_basis="Fictional fixture feed supplied under a (fictional) feed agreement.",
        settings={
            "field_map": {"sku": "sku", "title": "name", "brand": "brand", "gtin": "ean", "mpn": "mpn", "model": "model",
                          "condition": "condition", "price": "price_gbp", "tax_treatment": "vat", "delivery_cost": "delivery",
                          "availability": "stock", "url": "url"},
            "spec_map": {"storage": "storage", "ram": "ram", "region": "region"},
            "defaults": {"currency": "GBP", "locale": "en-GB"},
        },
    ),
    dict(
        key="gadgetgrove-api", supplier="gadgetgrove", name="Offers API (JSON, bearer token)", kind="api",
        entry_urls=["https://gadgetgrove.fixture.test/api/v1/offers.json"],
        authorisation_basis="Fictional partner API; key issued to Price Watch and held in the environment.",
        credential_env_var="GADGETGROVE_API_KEY",
        settings={
            "items_path": "items", "next_path": "next",
            "field_map": {"sku": "id", "title": "title", "brand": "brand", "gtin": "gtin", "mpn": "mpn", "model": "model",
                          "condition": "condition", "price": "pricing.net", "currency": "pricing.currency",
                          "tax_treatment": "pricing.vat", "tax_rate": "pricing.vat_rate", "delivery_cost": "shipping.cost",
                          "availability": "stock", "url": "link", "included": "included", "promotions": "promotions",
                          "tiers": "tiers"},
            "spec_map": {"storage": "specs.storage", "ram": "specs.ram", "region": "specs.region"},
            "defaults": {"locale": "en-GB"},
        },
    ),
    dict(
        key="clubtronics-manual", supplier="clubtronics", name="Manual submissions", kind="manual", entry_urls=[],
        authorisation_basis="Fictional supplier submits its own listings through the authenticated supplier API.",
        settings={"defaults": {"locale": "en-GB"}},
    ),
    dict(
        key="freshcart-json", supplier="freshcart", name="Grocery feed (JSON)", kind="json_feed",
        entry_urls=["https://freshcart.fixture.test/feed/products.json"],
        authorisation_basis="Fictional fixture feed.",
        settings={"items_path": "products", "field_map": _GROCERY_FIELDS,
                  "defaults": {**_GBP_INC, "delivery": {"amount": "3.50", "free_threshold": "40.00"}}},
    ),
    dict(
        key="dailypantry-json", supplier="dailypantry", name="Grocery feed (JSON)", kind="json_feed",
        entry_urls=["https://dailypantry.fixture.test/feed/products.json"],
        authorisation_basis="Fictional fixture feed.",
        settings={"items_path": "products", "field_map": _GROCERY_FIELDS,
                  "defaults": {**_GBP_INC, "delivery": {"amount": "4.99", "free_threshold": "15.00"}}},
    ),
    dict(
        key="greenbasket-csv", supplier="greenbasket", name="Assortment export (CSV; semicolons, decimal commas)", kind="csv_feed",
        entry_urls=["https://greenbasket.fixture.test/export/sortiment.csv"],
        authorisation_basis="Fictional fixture feed.",
        settings={
            "delimiter": ";",
            "field_map": {"sku": "Artikel", "title": "Bezeichnung", "brand": "Marke", "gtin": "EAN", "net_quantity": "Inhalt",
                          "product_form": "Sorte", "organic": "Bio", "price": "Preis", "availability": "Bestand"},
            "defaults": {"currency": "GBP", "locale": "de-DE", "tax_treatment": "included", "delivery": {"amount": "2.00"}},
        },
    ),
]
