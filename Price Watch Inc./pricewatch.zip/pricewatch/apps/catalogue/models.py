"""Canonical product identity. Independent of any supplier listing or price."""
from decimal import Decimal

from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import Q


class Category(models.Model):
    class Vertical(models.TextChoices):
        ELECTRONICS = "electronics", "Consumer electronics"
        GROCERY = "grocery", "Grocery"

    name = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100, unique=True)
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.PROTECT, related_name="children")
    vertical = models.CharField(max_length=20, choices=Vertical.choices, default=Vertical.ELECTRONICS)
    # Attributes that must agree for two items to be "the same variant" in this category.
    identity_attributes = models.JSONField(default=list, blank=True)
    # Attributes offered as filters / specification requirements in the UI and API.
    filter_attributes = models.JSONField(default=list, blank=True)
    description = models.CharField(max_length=300, blank=True)

    class Meta:
        verbose_name_plural = "categories"
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name


class Product(models.Model):
    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        HIDDEN = "hidden", "Hidden"

    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products")
    brand = models.CharField(max_length=100)
    name = models.CharField(max_length=200)
    model = models.CharField(max_length=100, blank=True)
    slug = models.SlugField(max_length=200, unique=True)
    description = models.TextField(blank=True)
    specs = models.JSONField(default=dict, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.ACTIVE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["brand", "name"]
        indexes = [models.Index(fields=["brand", "model"]), models.Index(fields=["category", "status"])]

    def __str__(self) -> str:
        return f"{self.brand} {self.name}"


class ProductVariant(models.Model):
    """A specific sellable configuration: storage, RAM, region, pack size..."""

    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        RETIRED = "retired", "Retired"

    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="variants")
    name = models.CharField(max_length=200)
    gtin = models.CharField(max_length=14, null=True, blank=True, unique=True)
    mpn = models.CharField(max_length=60, blank=True)
    attributes = models.JSONField(default=dict, blank=True)
    included_contents = models.JSONField(null=True, blank=True)  # null: not recorded
    warranty = models.CharField(max_length=120, blank=True)
    pack_count = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    net_quantity = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True,
                                       validators=[MinValueValidator(Decimal("0.001"))])
    net_quantity_unit = models.CharField(max_length=10, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.ACTIVE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["product", "name"]
        constraints = [
            models.UniqueConstraint(fields=["product", "name"], name="uniq_variant_name_per_product"),
            models.CheckConstraint(condition=Q(pack_count__gte=1), name="variant_pack_count_positive"),
            models.CheckConstraint(
                condition=Q(net_quantity__isnull=True) | (Q(net_quantity__gt=0) & ~Q(net_quantity_unit="")),
                name="variant_quantity_has_unit",
            ),
        ]
        indexes = [models.Index(fields=["mpn"])]

    def __str__(self) -> str:
        return f"{self.product} — {self.name}"

    @property
    def display_name(self) -> str:
        return f"{self.product.brand} {self.product.name} {self.name}".strip()
