from django.contrib import admin

from .models import Category, Product, ProductVariant


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "vertical", "parent")
    prepopulated_fields = {"slug": ("name",)}


class VariantInline(admin.TabularInline):
    model = ProductVariant
    extra = 0


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("brand", "name", "model", "category", "status")
    list_filter = ("category", "status")
    search_fields = ("brand", "name", "model")
    prepopulated_fields = {"slug": ("brand", "name")}
    inlines = [VariantInline]
