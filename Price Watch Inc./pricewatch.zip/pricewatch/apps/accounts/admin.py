from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import CustomerMembership, SupplierAccount, User

admin.site.register(User, UserAdmin)


@admin.register(SupplierAccount)
class SupplierAccountAdmin(admin.ModelAdmin):
    list_display = ("user", "supplier", "role", "is_active")


@admin.register(CustomerMembership)
class CustomerMembershipAdmin(admin.ModelAdmin):
    list_display = ("user", "supplier", "status")
