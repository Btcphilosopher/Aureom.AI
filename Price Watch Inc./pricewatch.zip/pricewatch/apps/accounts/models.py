from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """Custom user from day one so the schema can evolve without a painful swap."""

    class Meta(AbstractUser.Meta):
        db_table = "accounts_user"


class SupplierAccount(models.Model):
    """Authorises a user to submit listings and prices for exactly one supplier."""

    class Role(models.TextChoices):
        SUBMITTER = "submitter", "Submitter"
        ADMIN = "admin", "Administrator"

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="supplier_accounts")
    supplier = models.ForeignKey("suppliers.Supplier", on_delete=models.CASCADE, related_name="accounts")
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.SUBMITTER)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user", "supplier"], name="uniq_supplier_account")]

    def __str__(self) -> str:
        return f"{self.user} @ {self.supplier}"


class CustomerMembership(models.Model):
    """What a customer has told us about a supplier membership programme.

    Absence of a row means *unknown*, which is different from "not held".
    """

    class Status(models.TextChoices):
        HELD = "held", "Held"
        NOT_HELD = "not_held", "Not held"

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="memberships")
    supplier = models.ForeignKey("suppliers.Supplier", on_delete=models.CASCADE, related_name="customer_memberships")
    status = models.CharField(max_length=10, choices=Status.choices)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user", "supplier"], name="uniq_customer_membership")]
