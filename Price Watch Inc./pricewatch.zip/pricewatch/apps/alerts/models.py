from decimal import Decimal

from django.conf import settings
from django.db import models
from django.db.models import Q


class PriceAlert(models.Model):
    """Notify when the cheapest complete, eligible total for a variant reaches a target.

    The alert stores the customer's full requirements (condition, quantity,
    membership answers, coupon codes, currency, whether delivery counts) so it
    is evaluated exactly as the comparison they saw.
    """

    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        PAUSED = "paused", "Paused"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="price_alerts")
    variant = models.ForeignKey("catalogue.ProductVariant", on_delete=models.CASCADE, related_name="price_alerts")
    target_total = models.DecimalField(max_digits=12, decimal_places=2)
    currency = models.CharField(max_length=3, default="GBP")
    requirements = models.JSONField(default=dict)
    status = models.CharField(max_length=8, choices=Status.choices, default=Status.ACTIVE)
    min_interval_hours = models.PositiveIntegerField(default=24)
    last_evaluated_at = models.DateTimeField(null=True, blank=True)
    last_notified_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField()

    class Meta:
        ordering = ["-created_at"]
        constraints = [
            models.CheckConstraint(condition=Q(target_total__gt=Decimal("0")), name="alert_target_positive"),
            models.CheckConstraint(condition=Q(min_interval_hours__gte=1), name="alert_interval_at_least_hourly"),
        ]
        indexes = [models.Index(fields=["status", "variant"])]

    def __str__(self) -> str:
        return f"{self.user}: {self.variant} ≤ {self.target_total} {self.currency}"


class AlertNotification(models.Model):
    """A notification that was sent. ``dedupe_key`` prevents repeats for the same price."""

    alert = models.ForeignKey(PriceAlert, on_delete=models.CASCADE, related_name="notifications")
    observation = models.ForeignKey("suppliers.OfferObservation", on_delete=models.PROTECT, related_name="+")
    total = models.DecimalField(max_digits=12, decimal_places=2)
    currency = models.CharField(max_length=3)
    dedupe_key = models.CharField(max_length=200, unique=True)
    channel = models.CharField(max_length=20, default="email")
    message = models.TextField()
    sent_at = models.DateTimeField()

    class Meta:
        ordering = ["-sent_at"]
