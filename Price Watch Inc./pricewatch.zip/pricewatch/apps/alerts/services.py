"""Price alert evaluation.

An alert fires only for the cheapest offer that is *complete, eligible and fresh*
under the customer's stored requirements. Conditional, incomplete and stale
offers never trigger a notification. Notifications are rate-limited per alert
and de-duplicated per (alert, listing, total).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.core.mail import send_mail
from django.db import IntegrityError, transaction

from apps.audit.services import record
from apps.comparisons.services import Requirements, compare_variant, money
from apps.core.clock import Clock, system_clock
from apps.core.logging import get_logger

from .models import AlertNotification, PriceAlert

logger = get_logger("alerts")


@dataclass(frozen=True)
class AlertEvaluation:
    alert_id: int
    outcome: str  # notified | above_target | no_confirmed_offer | rate_limited | duplicate
    total: Decimal | None = None
    supplier: str = ""
    detail: str = ""


def create_alert(*, user, variant, target_total: Decimal, requirements: Requirements, clock: Clock = system_clock,
                 min_interval_hours: int | None = None) -> PriceAlert:
    if isinstance(target_total, float):
        raise TypeError("target_total must be a Decimal")
    alert = PriceAlert.objects.create(
        user=user, variant=variant, target_total=target_total, currency=requirements.currency,
        requirements=requirements.as_dict(), created_at=clock.now(),
        min_interval_hours=min_interval_hours or settings.PRICEWATCH["ALERT_MIN_INTERVAL_HOURS"],
    )
    record("alert.created", alert, actor=user, data={"variant": variant.pk, "target": str(target_total)}, at=alert.created_at)
    return alert


def evaluate_alert(alert: PriceAlert, *, clock: Clock = system_clock) -> AlertEvaluation:
    now = clock.now()
    requirements = Requirements.from_dict(alert.requirements)
    result = compare_variant(alert.variant, requirements, clock=clock)
    PriceAlert.objects.filter(pk=alert.pk).update(last_evaluated_at=now)

    confirmed = [view for view in result.ranked if not view.freshness.is_stale]
    if not confirmed:
        detail = "Only stale, conditional or incomplete offers are available." if result.all_offers else "No offers."
        return AlertEvaluation(alert.pk, "no_confirmed_offer", detail=detail)
    best = confirmed[0]
    total = best.breakdown.total
    if total > alert.target_total:
        return AlertEvaluation(alert.pk, "above_target", total, best.supplier.name)

    dedupe_key = f"alert:{alert.pk}:listing:{best.listing.pk}:total:{total}:{alert.currency}"
    if AlertNotification.objects.filter(dedupe_key=dedupe_key).exists():
        return AlertEvaluation(alert.pk, "duplicate", total, best.supplier.name, "Already notified for this price.")
    if alert.last_notified_at and now - alert.last_notified_at < timedelta(hours=alert.min_interval_hours):
        return AlertEvaluation(alert.pk, "rate_limited", total, best.supplier.name,
                               f"Notified within the last {alert.min_interval_hours} hours.")

    conditions = [
        f"condition: {requirements.condition.replace('_', ' ')}",
        f"quantity: {requirements.quantity}",
        "delivery included",
    ]
    for slug, state in sorted(requirements.memberships.items()):
        conditions.append(f"{slug} membership: {state.replace('_', ' ')}")
    message = (
        f"{alert.variant.display_name} is available for {money(total, alert.currency)} in total from "
        f"{best.supplier.name}, at or below your target of {money(alert.target_total, alert.currency)}.\n\n"
        f"Compared on your requirements ({'; '.join(conditions)}).\n"
        f"We observed this price at {best.observation.observed_at:%d %b %Y %H:%M} UTC; "
        "it may have changed since, and stock is not reserved.\n"
    )
    try:
        with transaction.atomic():
            notification = AlertNotification.objects.create(
                alert=alert, observation=best.observation, total=total, currency=alert.currency,
                dedupe_key=dedupe_key, message=message, sent_at=now,
            )
            PriceAlert.objects.filter(pk=alert.pk).update(last_notified_at=now)
    except IntegrityError:  # a concurrent worker sent the same notification
        return AlertEvaluation(alert.pk, "duplicate", total, best.supplier.name)
    if alert.user.email:
        send_mail(f"Price alert: {alert.variant.display_name}", message, settings.DEFAULT_FROM_EMAIL, [alert.user.email],
                  fail_silently=True)
    record("alert.notified", alert, data={"notification": notification.pk, "total": str(total), "listing": best.listing.pk}, at=now)
    logger.info("alert notified", extra={"alert": alert.pk, "total": str(total), "supplier": best.supplier.slug})
    return AlertEvaluation(alert.pk, "notified", total, best.supplier.name)


def evaluate_active_alerts(*, clock: Clock = system_clock) -> list[AlertEvaluation]:
    alerts = PriceAlert.objects.filter(status=PriceAlert.Status.ACTIVE).select_related("variant__product__category", "user")
    return [evaluate_alert(alert, clock=clock) for alert in alerts]
