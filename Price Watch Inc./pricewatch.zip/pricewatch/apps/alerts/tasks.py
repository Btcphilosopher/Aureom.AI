from celery import shared_task

from . import services


@shared_task(name="apps.alerts.tasks.evaluate_active_alerts", ignore_result=True)
def evaluate_active_alerts() -> int:
    return sum(1 for evaluation in services.evaluate_active_alerts() if evaluation.outcome == "notified")
