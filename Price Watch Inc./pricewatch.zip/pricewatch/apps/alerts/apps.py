from django.apps import AppConfig


class AlertsConfig(AppConfig):
    name = "apps.alerts"
    label = "alerts"
