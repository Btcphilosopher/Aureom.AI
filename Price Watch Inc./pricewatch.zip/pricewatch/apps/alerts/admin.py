from django.contrib import admin

from apps.suppliers.admin import ReadOnlyAdmin

from .models import AlertNotification, PriceAlert


@admin.register(PriceAlert)
class PriceAlertAdmin(admin.ModelAdmin):
    list_display = ("user", "variant", "target_total", "currency", "status", "last_notified_at")
    list_filter = ("status",)


@admin.register(AlertNotification)
class AlertNotificationAdmin(ReadOnlyAdmin):
    list_display = ("alert", "total", "currency", "sent_at")
