from django.conf import settings
from django.db import models

from apps.suppliers.models import ImmutableRecordError


class AuditEvent(models.Model):
    """Append-only record of who did what to which object."""

    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="audit_events")
    actor_label = models.CharField(max_length=80, default="system")  # survives user deletion
    action = models.CharField(max_length=60)
    target_type = models.CharField(max_length=60)
    target_id = models.CharField(max_length=40)
    data = models.JSONField(default=dict, blank=True)
    request_id = models.CharField(max_length=64, blank=True)
    created_at = models.DateTimeField()

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["target_type", "target_id"]), models.Index(fields=["action", "-created_at"])]

    def save(self, *args, **kwargs):
        if self.pk is not None and not self._state.adding:
            raise ImmutableRecordError("Audit events are append-only.")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ImmutableRecordError("Audit events are append-only.")

    def __str__(self) -> str:
        return f"{self.created_at:%Y-%m-%d %H:%M} {self.actor_label} {self.action} {self.target_type}#{self.target_id}"


class CorrectionRequest(models.Model):
    """A report that published information is wrong."""

    class Kind(models.TextChoices):
        WRONG_PRICE = "wrong_price", "Price is wrong"
        WRONG_MATCH = "wrong_match", "Not the same product"
        WRONG_DETAILS = "wrong_details", "Details are wrong"
        OTHER = "other", "Something else"

    class Status(models.TextChoices):
        OPEN = "open", "Open"
        ACCEPTED = "accepted", "Accepted"
        REJECTED = "rejected", "Rejected"

    reporter = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="correction_requests")
    listing = models.ForeignKey("suppliers.SupplierListing", null=True, blank=True, on_delete=models.SET_NULL, related_name="correction_requests")
    variant = models.ForeignKey("catalogue.ProductVariant", null=True, blank=True, on_delete=models.SET_NULL, related_name="correction_requests")
    kind = models.CharField(max_length=14, choices=Kind.choices)
    description = models.TextField(max_length=2000)
    status = models.CharField(max_length=8, choices=Status.choices, default=Status.OPEN)
    resolution_note = models.CharField(max_length=500, blank=True)
    resolved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    resolved_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField()

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["status", "-created_at"])]

    def __str__(self) -> str:
        return f"{self.get_kind_display()} [{self.status}]"
