from django.contrib import admin

from apps.suppliers.admin import ReadOnlyAdmin

from .models import AuditEvent, CorrectionRequest


@admin.register(AuditEvent)
class AuditEventAdmin(ReadOnlyAdmin):
    list_display = ("created_at", "actor_label", "action", "target_type", "target_id")
    list_filter = ("action",)
    date_hierarchy = "created_at"


@admin.register(CorrectionRequest)
class CorrectionRequestAdmin(admin.ModelAdmin):
    list_display = ("created_at", "kind", "status", "listing", "variant")
    list_filter = ("status", "kind")
