from __future__ import annotations

from datetime import datetime
from typing import Any

from apps.core.clock import system_clock
from apps.core.logging import get_logger, redact, request_id_var

from .models import AuditEvent

logger = get_logger("audit")


def record(action: str, target: Any, *, actor=None, data: dict | None = None, at: datetime | None = None) -> AuditEvent:
    """Append an audit event. ``target`` is a model instance or a ``(type, id)`` pair."""
    if isinstance(target, tuple):
        target_type, target_id = target
    else:
        target_type, target_id = target._meta.label_lower, target.pk
    actor = actor if getattr(actor, "is_authenticated", False) else None
    event = AuditEvent.objects.create(
        actor=actor,
        actor_label=actor.get_username() if actor else "system",
        action=action,
        target_type=target_type,
        target_id=str(target_id),
        data=redact(data or {}),
        request_id=request_id_var.get(),
        created_at=at or system_clock.now(),
    )
    logger.info("audit", extra={"action": action, "target_type": target_type, "target_id": str(target_id), "actor": event.actor_label})
    return event
