from django.conf import settings
from django.db import models
from django.db.models import Q


class ComparisonRequest(models.Model):
    """A comparison that was run, with the customer's requirements and a result snapshot."""

    class Kind(models.TextChoices):
        VARIANT = "variant", "Exact product comparison"
        SPECIFICATION = "specification", "Specification comparison"
        UNIT_PRICE = "unit_price", "Unit-price comparison"
        BASKET = "basket", "Basket comparison"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="comparisons")
    kind = models.CharField(max_length=14, choices=Kind.choices)
    variant = models.ForeignKey("catalogue.ProductVariant", null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    category = models.ForeignKey("catalogue.Category", null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    requirements = models.JSONField(default=dict)
    currency = models.CharField(max_length=3, default="GBP")
    result = models.JSONField(default=dict)
    created_at = models.DateTimeField()

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["user", "-created_at"])]


class SavedSearch(models.Model):
    """An item on a customer's saved list: a variant and/or a search with requirements."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="saved_searches")
    list_name = models.CharField(max_length=80, default="My list")
    label = models.CharField(max_length=200)
    variant = models.ForeignKey("catalogue.ProductVariant", null=True, blank=True, on_delete=models.CASCADE, related_name="+")
    query = models.CharField(max_length=200, blank=True)
    requirements = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["list_name", "-created_at"]
        constraints = [
            models.UniqueConstraint(fields=["user", "list_name", "variant"], condition=Q(variant__isnull=False), name="uniq_saved_variant_per_list"),
            models.CheckConstraint(condition=Q(variant__isnull=False) | ~Q(query=""), name="saved_search_has_target"),
        ]

    def __str__(self) -> str:
        return f"{self.user}: {self.label}"
