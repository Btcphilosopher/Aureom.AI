"""Comparison service: turns stored observations into ranked, explained offers.

Reads the database, delegates all arithmetic to ``apps.pricing`` and all
equivalence judgements to ``apps.matching``, and never performs I/O beyond the ORM.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Any, Iterable, Mapping, Sequence

from django.db.models import Prefetch

from apps.catalogue.models import Category, ProductVariant
from apps.core.clock import Clock, system_clock
from apps.extraction.types import Condition
from apps.matching.matcher import RuleBasedMatcher, condition_check
from apps.matching.models import MatchDecision
from apps.matching.services import listing_to_normalised
from apps.matching.types import MatchMode, MatchOutcome, ProductSpecification, Requirement
from apps.pricing.basket import BasketComparison, BasketItem, compare_basket
from apps.pricing.engine import DefaultPricingEngine
from apps.pricing.types import (
    Charge,
    ComparisonContext,
    ComponentStatus,
    CurrencyMismatchError,
    Eligibility,
    MembershipState,
    Offer,
    PriceBreakdown,
    PriceTier,
    PricingEngine,
    PromotionTerms,
    TaxTreatment,
    UNKNOWN_DELIVERY,
)
from apps.pricing.units import DEFAULT_BASIS, EACH, IncompatibleUnitsError, Quantity, UnknownUnitError, unit_price
from apps.suppliers.models import OfferObservation, PriceComponent, Supplier, SupplierListing

MAX_QUANTITY = 999


class InvalidRequirementsError(ValueError):
    """The customer's requirements are malformed."""


@dataclass(frozen=True)
class Requirements:
    """What the customer needs. Stored verbatim with comparisons and alerts."""

    condition: str = "new"
    quantity: int = 1
    memberships: Mapping[str, str] = field(default_factory=dict)  # supplier slug -> held | not_held | unknown
    coupon_codes: tuple[str, ...] = ()
    currency: str = "GBP"

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> "Requirements":
        data = dict(data or {})
        condition = str(data.get("condition") or "new")
        if condition not in (Condition.NEW, Condition.REFURBISHED, Condition.USED, Condition.OPEN_BOX):
            raise InvalidRequirementsError(f"Unsupported condition: {condition!r}")
        try:
            quantity = int(data.get("quantity") or 1)
        except (TypeError, ValueError):
            raise InvalidRequirementsError("quantity must be a whole number") from None
        if not 1 <= quantity <= MAX_QUANTITY:
            raise InvalidRequirementsError(f"quantity must be between 1 and {MAX_QUANTITY}")
        memberships = data.get("memberships") or {}
        if not isinstance(memberships, Mapping):
            raise InvalidRequirementsError("memberships must be an object of supplier slug -> state")
        cleaned: dict[str, str] = {}
        for slug, state in memberships.items():
            if state not in ("held", "not_held", "unknown"):
                raise InvalidRequirementsError(f"Unknown membership state: {state!r}")
            cleaned[str(slug)[:120]] = state
        codes = data.get("coupon_codes") or ()
        if isinstance(codes, str):
            codes = [c for c in codes.replace(",", " ").split() if c]
        codes = tuple(sorted({str(c).strip()[:40] for c in codes if str(c).strip()}))[:10]
        currency = str(data.get("currency") or "GBP").upper()
        if len(currency) != 3 or not currency.isalpha():
            raise InvalidRequirementsError("currency must be an ISO 4217 code")
        return cls(condition, quantity, cleaned, codes, currency)

    def as_dict(self) -> dict[str, Any]:
        return {
            "condition": self.condition, "quantity": self.quantity, "memberships": dict(self.memberships),
            "coupon_codes": list(self.coupon_codes), "currency": self.currency,
        }


@dataclass(frozen=True)
class Freshness:
    state: str  # fresh | stale
    observed_at: datetime
    reason: str = ""

    @property
    def is_stale(self) -> bool:
        return self.state == "stale"


@dataclass
class OfferView:
    listing: SupplierListing
    observation: OfferObservation
    offer: Offer
    breakdown: PriceBreakdown
    freshness: Freshness
    group: str  # ranked | conditional | incomplete | ineligible | unavailable
    rank: int | None = None
    notes: list[str] = field(default_factory=list)
    match: MatchDecision | None = None
    match_reasons: list[dict] = field(default_factory=list)
    differences: list[str] = field(default_factory=list)
    unit_price: Decimal | None = None
    unit_basis: Quantity | None = None

    @property
    def supplier(self) -> Supplier:
        return self.listing.supplier

    @property
    def sponsored(self) -> bool:
        return self.listing.is_sponsored


@dataclass
class ExcludedListing:
    listing: SupplierListing
    reasons: list[str]
    kind: str  # condition | currency | rejected_match | needs_review | units


@dataclass
class ComparisonResult:
    title: str
    mode: str
    requirements: Requirements
    generated_at: datetime
    ranked: list[OfferView] = field(default_factory=list)
    conditional: list[OfferView] = field(default_factory=list)
    incomplete: list[OfferView] = field(default_factory=list)
    ineligible: list[OfferView] = field(default_factory=list)
    unavailable: list[OfferView] = field(default_factory=list)
    not_comparable: list[ExcludedListing] = field(default_factory=list)
    pending_review: list[ExcludedListing] = field(default_factory=list)
    explanation: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    programmes: list[Supplier] = field(default_factory=list)  # membership programmes that matter here

    @property
    def winner(self) -> OfferView | None:
        return self.ranked[0] if self.ranked else None

    @property
    def sponsored(self) -> list[OfferView]:
        return [view for view in self.all_offers if view.sponsored]

    @property
    def all_offers(self) -> list[OfferView]:
        return self.ranked + self.conditional + self.incomplete + self.ineligible + self.unavailable

    @property
    def has_stale(self) -> bool:
        return any(view.freshness.is_stale for view in self.all_offers)


# --------------------------------------------------------------------------- helpers

def money(amount: Decimal | None, currency: str) -> str:
    if amount is None:
        return "unknown"
    symbol = {"GBP": "£", "EUR": "€", "USD": "$"}.get(currency)
    return f"{symbol}{amount:,.2f}" if symbol else f"{amount:,.2f} {currency}"


def listing_queryset():
    return SupplierListing.objects.filter(
        status=SupplierListing.Status.ACTIVE, supplier__status=Supplier.Status.ACTIVE, latest_valid_observation__isnull=False
    ).select_related("supplier", "source_configuration", "latest_valid_observation", "variant__product__category").prefetch_related(
        Prefetch("latest_valid_observation__components", queryset=PriceComponent.objects.all()),
        "latest_valid_observation__promotions",
    )


def pack_size_for(listing: SupplierListing) -> Quantity:
    """What one purchasable pack of this listing contains."""
    count = listing.pack_count or 1
    if listing.net_quantity and listing.net_quantity_unit:
        try:
            return Quantity(Decimal(listing.net_quantity) * count, listing.net_quantity_unit)
        except (UnknownUnitError, ValueError):
            pass
    return Quantity(Decimal(count), "each")


def offer_from_observation(listing: SupplierListing, observation: OfferObservation, *, item_key: str = "",
                           pack_size: Quantity | None = None) -> Offer:
    delivery = UNKNOWN_DELIVERY
    fees: list[Charge] = []
    tiers: list[PriceTier] = []
    for component in observation.components.all():
        status = ComponentStatus(component.status)
        if component.kind == PriceComponent.Kind.DELIVERY:
            delivery = Charge(component.label, status, component.amount if status is ComponentStatus.ADDITIONAL else None,
                              free_threshold=component.free_threshold, note=component.note)
        elif component.kind == PriceComponent.Kind.FEE:
            fees.append(Charge(component.label, status, component.amount if status is ComponentStatus.ADDITIONAL else None,
                               mandatory=component.mandatory, note=component.note))
        elif component.kind == PriceComponent.Kind.ITEM_TIER and component.amount:
            tiers.append(PriceTier(component.min_quantity, component.amount))
    promotions = tuple(
        PromotionTerms(
            label=p.label, discount_type=p.discount_type, value=p.value, code=p.code or None,
            membership_programme=p.membership_programme or None, min_spend=p.min_spend, starts_at=p.starts_at, ends_at=p.ends_at,
        )
        for p in observation.promotions.all()
    )
    return Offer(
        offer_id=str(listing.pk),
        supplier_key=listing.supplier.slug,
        supplier_name=listing.supplier.name,
        currency=observation.currency,
        unit_price=observation.price_amount,
        tax_treatment=TaxTreatment(observation.tax_treatment),
        tax_rate=observation.tax_rate,
        delivery=delivery,
        fees=tuple(fees),
        tiers=tuple(tiers),
        promotions=promotions,
        membership_required=observation.membership_programme or None,
        minimum_order_amount=observation.minimum_order_amount,
        pack_size=pack_size or EACH,
        item_key=item_key,
    )


def freshness_for(listing: SupplierListing, observation: OfferObservation, now: datetime) -> Freshness:
    """Fresh only if the most recent attempt on the source re-confirmed this price recently."""
    source = listing.source_configuration
    hours = source.freshness_hours if source else 24
    if source and source.last_attempt_at and source.last_attempt_at > observation.observed_at:
        newer_held = listing.observations.filter(
            status=OfferObservation.Status.QUARANTINED, observed_at__gt=observation.observed_at
        ).exists()
        if newer_held:
            reason = "A newer price reading is held for review; showing the last verified price."
        elif source.has_failed_since_success:
            reason = "The latest refresh failed; showing the last price we verified."
        else:
            reason = "This listing was not found in the latest refresh; showing the last price we verified."
        return Freshness("stale", observation.observed_at, reason)
    if now - observation.observed_at > timedelta(hours=hours):
        return Freshness("stale", observation.observed_at, f"Not re-checked in the last {hours} hours.")
    return Freshness("fresh", observation.observed_at)


def build_context(requirements: Requirements, now: datetime, *, quantity: Quantity | None = None) -> ComparisonContext:
    programmes = dict(
        Supplier.objects.filter(slug__in=list(requirements.memberships)).exclude(membership_programme="")
        .values_list("slug", "membership_programme")
    )
    memberships = {
        programmes[slug]: MembershipState(state) for slug, state in requirements.memberships.items() if slug in programmes
    }
    return ComparisonContext(
        now=now, currency=requirements.currency,
        required_quantity=quantity or Quantity(Decimal(requirements.quantity), "each"),
        memberships=memberships, coupon_codes=frozenset(requirements.coupon_codes),
    )


def _group(view_breakdown: PriceBreakdown, observation: OfferObservation) -> str:
    if observation.availability == OfferObservation.Availability.OUT_OF_STOCK:
        return "unavailable"
    if view_breakdown.eligibility is Eligibility.INELIGIBLE:
        return "ineligible"
    if not view_breakdown.is_complete:
        return "incomplete"
    if view_breakdown.eligibility is Eligibility.CONDITIONAL:
        return "conditional"
    return "ranked"


def _place(result: ComparisonResult, view: OfferView) -> None:
    getattr(result, view.group).append(view)


def _finalise(result: ComparisonResult) -> ComparisonResult:
    result.ranked.sort(key=lambda v: (v.breakdown.total, v.supplier.name, v.listing.pk))
    for index, view in enumerate(result.ranked, start=1):
        view.rank = index
    for group in (result.conditional, result.incomplete, result.ineligible, result.unavailable):
        group.sort(key=lambda v: (v.breakdown.known_subtotal, v.supplier.name))
    seen: dict[int, Supplier] = {}
    for view in result.all_offers:
        if view.observation.membership_programme or any(p.membership_programme for p in view.offer.promotions):
            seen[view.supplier.pk] = view.supplier
    result.programmes = sorted(seen.values(), key=lambda s: s.name)
    result.explanation = explain(result)
    notes: list[str] = []
    for view in result.all_offers:
        notes.extend(view.breakdown.assumptions)
    result.assumptions = list(dict.fromkeys(result.assumptions + notes))
    return result


def explain(result: ComparisonResult) -> list[str]:
    """Plain-language account of why the winner won and what was left out."""
    currency = result.requirements.currency
    lines: list[str] = []
    winner = result.winner
    if winner is None:
        if result.all_offers:
            lines.append("No offer can be confirmed as cheapest: every offer is conditional, incomplete or unavailable.")
        else:
            lines.append("No comparable offers were found for these requirements.")
    else:
        b = winner.breakdown
        parts = [f"items {money(b.item_subtotal, currency)}"]
        if b.discount_total:
            parts.append(f"discount −{money(b.discount_total, currency)}")
        if b.fees_total:
            parts.append(f"fees {money(b.fees_total, currency)}")
        parts.append(f"delivery {money(b.delivery_total, currency)}")
        if b.tax_total:
            parts.append(f"tax {money(b.tax_total, currency)}")
        lines.append(
            f"{winner.supplier.name} is the cheapest complete offer you are eligible for: "
            f"{money(b.total, currency)} ({', '.join(parts)})."
        )
        if len(result.ranked) > 1:
            runner = result.ranked[1]
            rb = runner.breakdown
            gap = rb.total - b.total
            detail = f"items {money(rb.item_subtotal, currency)} + delivery {money(rb.delivery_total, currency)}"
            if gap == 0:
                lines.append(f"{runner.supplier.name} costs the same ({money(rb.total, currency)}: {detail}).")
            else:
                lines.append(f"Next is {runner.supplier.name} at {money(rb.total, currency)} ({detail}), {money(gap, currency)} more.")
        if winner.freshness.is_stale:
            lines.append(f"Caution: this price was last verified {winner.freshness.observed_at:%d %b %Y %H:%M} UTC. {winner.freshness.reason}")
    threshold = winner.breakdown.total if winner else None
    for view in result.conditional:
        if threshold is None or view.breakdown.total < threshold:
            lines.append(
                f"{view.supplier.name} shows {money(view.breakdown.total, currency)}, but it is conditional and not ranked: "
                + " ".join(view.breakdown.conditions)
            )
    for view in result.ineligible:
        if view.breakdown.total is not None and (threshold is None or view.breakdown.total < threshold):
            lines.append(
                f"{view.supplier.name} shows {money(view.breakdown.total, currency)} but you are not eligible: "
                + " ".join(view.breakdown.conditions)
            )
    if result.incomplete:
        names = ", ".join(sorted({v.supplier.name for v in result.incomplete}))
        lines.append(f"Total incomplete for {names}: a mandatory cost is unknown, so these cannot be ranked as cheapest.")
    if result.not_comparable:
        lines.append(f"{len(result.not_comparable)} similar listing(s) were excluded as not like-for-like; see the reasons below.")
    return lines


def _accepted_decisions(listing_ids: Iterable[int]) -> dict[int, MatchDecision]:
    decisions = MatchDecision.objects.filter(listing_id__in=list(listing_ids), is_current=True, outcome=MatchDecision.Outcome.ACCEPTED)
    return {d.listing_id: d for d in decisions}


# ------------------------------------------------------------------ exact comparison

def compare_variant(variant: ProductVariant, requirements: Requirements, *, clock: Clock = system_clock,
                    engine: PricingEngine | None = None) -> ComparisonResult:
    """Exact like-for-like comparison of one canonical variant."""
    engine = engine or DefaultPricingEngine()
    now = clock.now()
    context = build_context(requirements, now)
    result = ComparisonResult(variant.display_name, MatchMode.EXACT.value, requirements, now)
    listings = list(listing_queryset().filter(variant=variant))
    decisions = _accepted_decisions(l.pk for l in listings)

    for listing in listings:
        observation = listing.latest_valid_observation
        failure = condition_check(listing.condition, requirements.condition)
        if failure is not None:
            result.not_comparable.append(ExcludedListing(listing, [failure.message], "condition"))
            continue
        try:
            offer = offer_from_observation(listing, observation, pack_size=Quantity(Decimal(listing.pack_count or 1), "each"))
            breakdown = engine.calculate(offer, context)
        except CurrencyMismatchError:
            result.not_comparable.append(ExcludedListing(
                listing, [f"Priced in {observation.currency}; no currency conversion is applied."], "currency"))
            continue
        decision = decisions.get(listing.pk)
        view = OfferView(
            listing=listing, observation=observation, offer=offer, breakdown=breakdown,
            freshness=freshness_for(listing, observation, now), group=_group(breakdown, observation),
            match=decision, match_reasons=list(decision.reasons_for) if decision else [],
            differences=list(decision.differences) if decision else [],
        )
        if view.group == "unavailable":
            view.notes.append("Out of stock at the last check.")
        elif observation.availability == OfferObservation.Availability.UNKNOWN:
            view.notes.append("Availability not stated by the supplier.")
        _place(result, view)

    others = (
        MatchDecision.objects.filter(variant=variant, is_current=True)
        .exclude(outcome=MatchDecision.Outcome.ACCEPTED)
        .select_related("listing__supplier", "listing__latest_valid_observation")
        .order_by("-candidate_score")[:20]
    )
    for decision in others:
        reasons = [r["message"] for r in decision.reasons_against] or list(decision.differences) or [
            "Not enough evidence to confirm this is the same product."
        ]
        if decision.outcome == MatchDecision.Outcome.REJECTED:
            result.not_comparable.append(ExcludedListing(decision.listing, reasons, "rejected_match"))
        else:
            missing = ", ".join(u.replace("_", " ") for u in decision.unknowns)
            if missing:
                reasons = reasons + [f"Supplier does not state: {missing}."]
            result.pending_review.append(ExcludedListing(decision.listing, reasons, "needs_review"))
    return _finalise(result)


# ---------------------------------------------------------- specification equivalent

def parse_requirements(category: Category, raw: Sequence[Mapping[str, Any]]) -> tuple[Requirement, ...]:
    allowed = set(category.filter_attributes or []) | {"brand"}
    parsed = []
    for entry in raw:
        attribute = str(entry.get("attribute", ""))
        if attribute not in allowed:
            raise InvalidRequirementsError(f"{attribute!r} is not a comparable attribute for {category.name}")
        try:
            parsed.append(Requirement(attribute, str(entry.get("op", "eq")), entry.get("value")))
        except ValueError as exc:
            raise InvalidRequirementsError(str(exc)) from None
        if entry.get("value") in (None, ""):
            raise InvalidRequirementsError(f"Requirement for {attribute} has no value")
    return tuple(parsed)


def _merged_listing(listing: SupplierListing):
    """Listing evidence, with verified canonical attributes filling gaps for matched listings."""
    normalised = listing_to_normalised(listing)
    if listing.variant_id:
        merged = {**(listing.variant.attributes or {}), **dict(normalised.attributes)}
        from dataclasses import replace

        normalised = replace(normalised, attributes=merged, brand=normalised.brand or listing.variant.product.brand)
    return normalised


def compare_specification(category: Category, spec_requirements: Sequence[Requirement], requirements: Requirements, *,
                          clock: Clock = system_clock, engine: PricingEngine | None = None) -> ComparisonResult:
    """Different products that meet explicit requirements, ranked by comparable total."""
    engine = engine or DefaultPricingEngine()
    matcher = RuleBasedMatcher()
    now = clock.now()
    context = build_context(requirements, now)
    described = ", ".join(r.describe() for r in spec_requirements) or "any specification"
    result = ComparisonResult(f"{category.name}: {described}", MatchMode.SPEC_EQUIVALENT.value, requirements, now)
    spec = ProductSpecification(key=f"category:{category.pk}", title=category.name, requirements=tuple(spec_requirements),
                                condition=Condition(requirements.condition), mode=MatchMode.SPEC_EQUIVALENT)
    for listing in listing_queryset().filter(variant__product__category=category):
        observation = listing.latest_valid_observation
        match = matcher.evaluate(_merged_listing(listing), spec)
        if match.outcome is MatchOutcome.REJECTED:
            continue  # simply does not meet the requirements
        if match.outcome is MatchOutcome.NEEDS_REVIEW:
            missing = ", ".join(u.replace("_", " ") for u in match.unknowns)
            result.pending_review.append(ExcludedListing(listing, [f"Insufficient evidence — supplier does not state: {missing}."], "needs_review"))
            continue
        try:
            offer = offer_from_observation(listing, observation, pack_size=Quantity(Decimal(listing.pack_count or 1), "each"))
            breakdown = engine.calculate(offer, context)
        except CurrencyMismatchError:
            result.not_comparable.append(ExcludedListing(listing, [f"Priced in {observation.currency}; no conversion applied."], "currency"))
            continue
        _place(result, OfferView(
            listing=listing, observation=observation, offer=offer, breakdown=breakdown,
            freshness=freshness_for(listing, observation, now), group=_group(breakdown, observation),
            match_reasons=[r.as_dict() for r in match.reasons_for], differences=list(match.differences),
        ))
    result.assumptions.append("Specification comparison: products differ; only the stated requirements are guaranteed.")
    return _finalise(result)


# -------------------------------------------------------------------------- unit price

def _unit_price_candidates(category: Category, product_form: str | None, attribute_requirements: Sequence[Requirement],
                           required: Quantity, requirements: Requirements):
    matcher = RuleBasedMatcher()
    attributes = {"product_form": product_form} if product_form else {}
    spec = ProductSpecification(key=f"category:{category.pk}", title=category.name, attributes=attributes,
                                net_quantity=required, requirements=tuple(attribute_requirements), mode=MatchMode.UNIT_PRICE)
    for listing in listing_queryset().filter(variant__product__category=category):
        failure = condition_check(listing.condition, requirements.condition)
        if failure is not None and listing.condition != Condition.UNKNOWN:
            yield listing, None, [failure.message]
            continue
        match = matcher.evaluate(_merged_listing(listing), spec)
        yield listing, match, []


def compare_unit_price(category: Category, required: Quantity, requirements: Requirements, *, product_form: str | None = None,
                       attribute_requirements: Sequence[Requirement] = (), clock: Clock = system_clock,
                       engine: PricingEngine | None = None) -> ComparisonResult:
    """Compatible quantities compared by unit price; pack and brand differences stay visible."""
    engine = engine or DefaultPricingEngine()
    now = clock.now()
    context = build_context(requirements, now, quantity=required)
    label = f"{product_form} " if product_form else ""
    result = ComparisonResult(f"{required} of {label}{category.name}".strip(), MatchMode.UNIT_PRICE.value, requirements, now)
    basis = DEFAULT_BASIS[required.dimension]
    for listing, match, reasons in _unit_price_candidates(category, product_form, attribute_requirements, required, requirements):
        observation = listing.latest_valid_observation
        if match is None:
            result.not_comparable.append(ExcludedListing(listing, reasons, "condition"))
            continue
        if match.outcome is MatchOutcome.REJECTED:
            result.not_comparable.append(ExcludedListing(listing, [r.message for r in match.reasons_against], "rejected_match"))
            continue
        if match.outcome is MatchOutcome.NEEDS_REVIEW:
            missing = ", ".join(u.replace("_", " ") for u in match.unknowns)
            result.pending_review.append(ExcludedListing(listing, [f"Insufficient evidence — not stated: {missing}."], "needs_review"))
            continue
        try:
            offer = offer_from_observation(listing, observation, pack_size=pack_size_for(listing))
            breakdown = engine.calculate(offer, context)
        except CurrencyMismatchError:
            result.not_comparable.append(ExcludedListing(listing, [f"Priced in {observation.currency}; no conversion applied."], "currency"))
            continue
        except IncompatibleUnitsError as exc:
            result.not_comparable.append(ExcludedListing(listing, [str(exc)], "units"))
            continue
        view = OfferView(
            listing=listing, observation=observation, offer=offer, breakdown=breakdown,
            freshness=freshness_for(listing, observation, now), group=_group(breakdown, observation),
            match_reasons=[r.as_dict() for r in match.reasons_for], differences=list(match.differences),
            unit_price=unit_price(breakdown.item_subtotal - breakdown.discount_total, breakdown.purchased_quantity, basis),
            unit_basis=basis,
        )
        _place(result, view)
    result.assumptions.append("Ranked by the total to buy at least the quantity you asked for, in whole packs; unit price is shown for reference.")
    return _finalise(result)


# ------------------------------------------------------------------------------ basket

@dataclass
class BasketRequestItem:
    key: str
    label: str
    category: Category
    required: Quantity
    product_form: str | None = None
    attribute_requirements: tuple[Requirement, ...] = ()


@dataclass
class BasketResult:
    comparison: BasketComparison
    items: list[BasketRequestItem]
    listings: dict[str, SupplierListing]  # offer_id -> listing
    stale_offer_ids: set[str]
    generated_at: datetime
    requirements: Requirements


def compare_grocery_basket(items: Sequence[BasketRequestItem], requirements: Requirements, *, clock: Clock = system_clock,
                           engine: DefaultPricingEngine | None = None) -> BasketResult:
    now = clock.now()
    context = build_context(requirements, now)
    candidates: dict[str, list[Offer]] = {}
    listings: dict[str, SupplierListing] = {}
    stale: set[str] = set()
    for item in items:
        offers: list[Offer] = []
        for listing, match, _reasons in _unit_price_candidates(item.category, item.product_form, item.attribute_requirements,
                                                               item.required, requirements):
            if match is None or match.outcome is not MatchOutcome.ACCEPTED:
                continue
            observation = listing.latest_valid_observation
            if observation.availability == OfferObservation.Availability.OUT_OF_STOCK:
                continue
            offers.append(offer_from_observation(listing, observation, item_key=item.key, pack_size=pack_size_for(listing)))
            listings[str(listing.pk)] = listing
            if freshness_for(listing, observation, now).is_stale:
                stale.add(str(listing.pk))
        candidates[item.key] = offers
    comparison = compare_basket([BasketItem(i.key, i.label, i.required) for i in items], candidates, context, engine)
    return BasketResult(comparison, list(items), listings, stale, now, requirements)


# ----------------------------------------------------------------------------- history

@dataclass
class HistorySeries:
    listing: SupplierListing
    points: list[tuple[datetime, Decimal]]
    currency: str


def price_history(variant: ProductVariant, *, condition: str = "new", currency: str = "GBP", limit_per_listing: int = 500) -> list[HistorySeries]:
    """Item prices as observed. Points are the times we checked, not the times prices changed."""
    series: list[HistorySeries] = []
    listings = SupplierListing.objects.filter(variant=variant, condition=condition).select_related("supplier").order_by("supplier__name")
    for listing in listings:
        observations = list(
            listing.observations.filter(status=OfferObservation.Status.VALID, currency=currency)
            .order_by("-observed_at").values_list("observed_at", "price_amount")[:limit_per_listing]
        )
        if observations:
            series.append(HistorySeries(listing, list(reversed(observations)), currency))
    return series


# ----------------------------------------------------------------------- serialisation

def breakdown_to_dict(breakdown: PriceBreakdown) -> dict[str, Any]:
    def text(value: Decimal | None) -> str | None:
        return None if value is None else str(value)

    return {
        "currency": breakdown.currency,
        "total": text(breakdown.total),
        "known_subtotal": text(breakdown.known_subtotal),
        "completeness": breakdown.completeness.value,
        "eligibility": breakdown.eligibility.value,
        "item_subtotal": text(breakdown.item_subtotal),
        "discount_total": text(breakdown.discount_total),
        "fees_total": text(breakdown.fees_total),
        "delivery_total": text(breakdown.delivery_total),
        "tax_total": text(breakdown.tax_total),
        "packs": breakdown.packs,
        "purchased_quantity": {"value": str(breakdown.purchased_quantity.value), "unit": breakdown.purchased_quantity.unit},
        "surplus_quantity": str(breakdown.surplus_quantity),
        "lines": [
            {"kind": l.kind, "label": l.label, "amount": text(l.amount), "status": l.status.value, "note": l.note}
            for l in breakdown.lines
        ],
        "missing": list(breakdown.missing),
        "conditions": list(breakdown.conditions),
        "conditional_discounts": [
            {"label": d.label, "potential_saving": str(d.potential_saving), "condition": d.condition}
            for d in breakdown.conditional_discounts
        ],
        "assumptions": list(breakdown.assumptions),
    }


def offer_view_to_dict(view: OfferView) -> dict[str, Any]:
    observation = view.observation
    return {
        "listing_id": view.listing.pk,
        "supplier": {"slug": view.supplier.slug, "name": view.supplier.name},
        "title": view.listing.title,
        "condition": view.listing.condition,
        "included_contents": view.listing.included_contents,
        "warranty": view.listing.warranty or None,
        "availability": observation.availability,
        "rank": view.rank,
        "group": view.group,
        "sponsored": view.sponsored,
        "price": breakdown_to_dict(view.breakdown),
        "unit_price": None if view.unit_price is None else {"amount": str(view.unit_price), "per": str(view.unit_basis)},
        "freshness": {"state": view.freshness.state, "observed_at": view.freshness.observed_at.isoformat(), "reason": view.freshness.reason},
        "supplier_effective_at": observation.supplier_effective_at.isoformat() if observation.supplier_effective_at else None,
        "last_price_change": None if not view.listing.last_price_change_observed_at else {
            "first_observed_at": view.listing.last_price_change_observed_at.isoformat(),
            "previous_check_at": view.listing.last_price_change_previous_check_at.isoformat()
            if view.listing.last_price_change_previous_check_at else None,
            "note": "The price changed at some point between these two checks.",
        },
        "match": {"reasons": view.match_reasons, "differences": view.differences,
                  "decided_by": view.match.decided_by if view.match else None, "version": view.match.version if view.match else None},
        "notes": view.notes,
        "provenance": {
            "source_url": observation.source_url, "extraction_method": observation.extraction_method,
            "configuration_version": observation.configuration_version, "observation_id": observation.pk,
        },
        "purchase_path": f"/out/{view.listing.pk}/",
    }


def result_to_dict(result: ComparisonResult) -> dict[str, Any]:
    def excluded(items: list[ExcludedListing]) -> list[dict[str, Any]]:
        return [
            {"listing_id": e.listing.pk, "supplier": e.listing.supplier.name, "title": e.listing.title, "kind": e.kind, "reasons": e.reasons}
            for e in items
        ]

    return {
        "title": result.title,
        "mode": result.mode,
        "requirements": result.requirements.as_dict(),
        "generated_at": result.generated_at.isoformat(),
        "winner_listing_id": result.winner.listing.pk if result.winner else None,
        "explanation": result.explanation,
        "ranked": [offer_view_to_dict(v) for v in result.ranked],
        "conditional": [offer_view_to_dict(v) for v in result.conditional],
        "total_incomplete": [offer_view_to_dict(v) for v in result.incomplete],
        "ineligible": [offer_view_to_dict(v) for v in result.ineligible],
        "unavailable": [offer_view_to_dict(v) for v in result.unavailable],
        "sponsored_listing_ids": [v.listing.pk for v in result.sponsored],
        "not_comparable": excluded(result.not_comparable),
        "insufficient_evidence": excluded(result.pending_review),
        "assumptions": result.assumptions,
    }


def basket_to_dict(result: BasketResult) -> dict[str, Any]:
    def plan(p) -> dict[str, Any] | None:
        if p is None:
            return None
        return {
            "strategy": p.strategy, "method_note": p.method_note, "complete": p.complete,
            "total": None if p.total is None else str(p.total), "currency": p.currency,
            "supplier_count": p.supplier_count, "delivery_count": p.delivery_count,
            "missing_items": [i.label for i in p.missing_items], "combinations_evaluated": p.combinations_evaluated,
            "orders": [
                {
                    "supplier": o.supplier_name, "goods_total": str(o.goods_total),
                    "delivery": None if o.delivery is None else str(o.delivery), "delivery_note": o.delivery_note,
                    "total": None if o.total is None else str(o.total), "problems": list(o.problems),
                    "lines": [
                        {
                            "item": l.item.label, "listing_id": int(l.offer.offer_id),
                            "title": result.listings[l.offer.offer_id].title, "packs": l.breakdown.packs,
                            "purchased": str(l.breakdown.purchased_quantity), "surplus": str(l.breakdown.surplus_quantity),
                            "goods_total": str(l.goods_total), "stale": l.offer.offer_id in result.stale_offer_ids,
                        }
                        for l in o.lines
                    ],
                }
                for o in p.orders
            ],
        }

    c = result.comparison
    return {
        "generated_at": result.generated_at.isoformat(),
        "requirements": result.requirements.as_dict(),
        "items": [{"key": i.key, "label": i.label, "required": str(i.required)} for i in result.items],
        "cheapest_single_supplier": plan(c.best_single_supplier),
        "single_supplier_options": [plan(p) for p in c.single_supplier],
        "baseline_split": plan(c.baseline_split),
        "exhaustive_split": plan(c.exhaustive_split),
        "conditional_discounts": list(c.conditional_notes),
        "excluded": list(c.excluded),
        "assumptions": list(c.assumptions),
    }
