"""API v1. Thin views over the same services the website uses."""
from __future__ import annotations

from django.db.models import Q
from django.shortcuts import get_object_or_404
from drf_spectacular.utils import OpenApiParameter, extend_schema
from rest_framework import generics, permissions, status
from rest_framework.exceptions import NotFound, PermissionDenied, ValidationError
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from rest_framework.views import APIView

from apps.accounts.models import SupplierAccount
from apps.alerts.models import PriceAlert
from apps.alerts.services import create_alert
from apps.audit.models import CorrectionRequest
from apps.audit.services import record
from apps.catalogue.models import Category, Product, ProductVariant
from apps.comparisons.models import ComparisonRequest
from apps.comparisons.services import (
    BasketRequestItem,
    Requirements,
    basket_to_dict,
    compare_grocery_basket,
    compare_specification,
    compare_unit_price,
    compare_variant,
    parse_requirements,
    price_history,
    result_to_dict,
)
from apps.core.clock import system_clock
from apps.core.text import clean_text
from apps.pricing.units import Quantity
from apps.suppliers.models import SupplierListing
from apps.suppliers.submissions import NoManualSourceError, submit_offer

from . import serializers as s
from .idempotency import IdempotentPostMixin

ERRORS = {400: s.ErrorSerializer, 404: s.ErrorSerializer, 429: s.ErrorSerializer}
IDEMPOTENCY_HEADER = OpenApiParameter(
    "Idempotency-Key", str, OpenApiParameter.HEADER, required=False,
    description="Optional. Retrying with the same key and body returns the original response.",
)


def _requirements(data: dict | None) -> Requirements:
    return Requirements.from_dict(data or {})


def _variant(product: Product, raw: str | None) -> ProductVariant:
    variants = product.variants.filter(status=ProductVariant.Status.ACTIVE).order_by("id")
    if raw:
        if not raw.isdigit():
            raise ValidationError({"variant": "Must be a variant id."})
        variant = variants.filter(pk=int(raw)).first()
    else:
        variant = variants.first()
    if variant is None:
        raise NotFound()
    return variant


# ------------------------------------------------------------------------- catalogue

class ProductList(generics.ListAPIView):
    """Search and browse canonical products."""

    serializer_class = s.ProductSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        queryset = Product.objects.filter(status=Product.Status.ACTIVE).select_related("category").prefetch_related("variants").order_by("brand", "name", "id")
        params = self.request.query_params
        for token in clean_text(params.get("q", ""), 100).split()[:6]:
            queryset = queryset.filter(
                Q(name__icontains=token) | Q(brand__icontains=token) | Q(model__icontains=token)
                | Q(variants__name__icontains=token) | Q(variants__gtin=token) | Q(variants__mpn__iexact=token)
            )
        if params.get("category"):
            queryset = queryset.filter(category__slug=params["category"])
        if params.get("brand"):
            queryset = queryset.filter(brand__iexact=params["brand"])
        return queryset.distinct()

    @extend_schema(parameters=[
        OpenApiParameter("q", str, description="Search text, GTIN or part number."),
        OpenApiParameter("category", str, description="Category slug."),
        OpenApiParameter("brand", str),
    ], responses={200: s.ProductSerializer(many=True), **ERRORS})
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)


class ProductDetail(generics.RetrieveAPIView):
    serializer_class = s.ProductSerializer
    permission_classes = [permissions.AllowAny]
    queryset = Product.objects.filter(status=Product.Status.ACTIVE).select_related("category").prefetch_related("variants")


OFFER_PARAMETERS = [
    OpenApiParameter("variant", int, description="Variant id; defaults to the product's first variant."),
    OpenApiParameter("condition", str, enum=s.CONDITIONS, description="Default: new."),
    OpenApiParameter("quantity", int, description="Default: 1."),
    OpenApiParameter("membership.<supplier-slug>", str, enum=s.MEMBERSHIP_STATES,
                     description="Repeatable, e.g. membership.clubtronics=not_held. Omitted means unknown."),
    OpenApiParameter("coupon", str, description="Space- or comma-separated codes you want applied."),
]


class ProductOffers(APIView):
    """Ranked, explained offers for one variant under the caller's requirements."""

    permission_classes = [permissions.AllowAny]

    @extend_schema(parameters=OFFER_PARAMETERS, responses={200: s.ComparisonResultSerializer, **ERRORS})
    def get(self, request, pk: int):
        product = get_object_or_404(Product, pk=pk, status=Product.Status.ACTIVE)
        params = request.query_params
        memberships = {key.split(".", 1)[1]: value for key, value in params.items() if key.startswith("membership.")}
        requirements = _requirements({
            "condition": params.get("condition"), "quantity": params.get("quantity"),
            "memberships": memberships, "coupon_codes": params.get("coupon", ""),
        })
        return Response(result_to_dict(compare_variant(_variant(product, params.get("variant")), requirements)))


class ProductHistory(APIView):
    """Observed item prices over time. Times are when we checked, not when prices changed."""

    permission_classes = [permissions.AllowAny]

    @extend_schema(parameters=OFFER_PARAMETERS[:2], responses={200: s.HistorySerializer, **ERRORS})
    def get(self, request, pk: int):
        product = get_object_or_404(Product, pk=pk, status=Product.Status.ACTIVE)
        variant = _variant(product, request.query_params.get("variant"))
        condition = request.query_params.get("condition") or "new"
        if condition not in s.CONDITIONS:
            raise ValidationError({"condition": "Unsupported condition."})
        return Response({
            "variant_id": variant.pk,
            "condition": condition,
            "note": "Each point is a time we checked. A price change happened at some time between two consecutive points.",
            "series": [
                {
                    "listing_id": series.listing.pk, "supplier": series.listing.supplier.name, "currency": series.currency,
                    "points": [{"observed_at": t.isoformat(), "item_price": str(p)} for t, p in series.points],
                }
                for series in price_history(variant, condition=condition)
            ],
        })


# ----------------------------------------------------------------------- comparisons

class ComparisonCreate(IdempotentPostMixin, APIView):
    """Run and record a comparison: exact variant, specification-equivalent or unit-price."""

    permission_classes = [permissions.AllowAny]

    @extend_schema(request=s.ComparisonCreateSerializer, parameters=[IDEMPOTENCY_HEADER],
                   responses={201: s.ComparisonResultSerializer, 409: s.ErrorSerializer, **ERRORS})
    def post(self, request, *args, **kwargs):
        return super().post(request, *args, **kwargs)

    def create(self, request):
        serializer = s.ComparisonCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        requirements = _requirements(data["requirements"])
        variant = category = None
        if data["kind"] == "variant":
            variant = ProductVariant.objects.filter(pk=data["variant_id"], status=ProductVariant.Status.ACTIVE).select_related("product__category").first()
            if variant is None:
                raise NotFound()
            result = compare_variant(variant, requirements)
        else:
            category = Category.objects.filter(slug=data["category"]).first()
            if category is None:
                raise NotFound()
            spec = parse_requirements(category, data["specification"])
            if data["kind"] == "specification":
                result = compare_specification(category, spec, requirements)
            else:
                quantity = Quantity(data["quantity"]["value"], data["quantity"]["unit"])
                result = compare_unit_price(category, quantity, requirements, product_form=data.get("product_form") or None,
                                            attribute_requirements=spec)
        body = result_to_dict(result)
        stored = ComparisonRequest.objects.create(
            user=request.user if request.user.is_authenticated else None,
            kind={"variant": "variant", "specification": "specification", "unit_price": "unit_price"}[data["kind"]],
            variant=variant, category=category, requirements=requirements.as_dict(), currency=requirements.currency,
            result=body, created_at=result.generated_at,
        )
        return Response({"id": stored.pk, **body}, status=status.HTTP_201_CREATED)


class BasketComparisonCreate(IdempotentPostMixin, APIView):
    """Compare a grocery basket: cheapest single supplier and transparent split baskets."""

    permission_classes = [permissions.AllowAny]

    @extend_schema(request=s.BasketCreateSerializer, parameters=[IDEMPOTENCY_HEADER],
                   responses={201: s.BasketResultSerializer, 409: s.ErrorSerializer, **ERRORS})
    def post(self, request, *args, **kwargs):
        return super().post(request, *args, **kwargs)

    def create(self, request):
        serializer = s.BasketCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        requirements = _requirements(data["requirements"])
        categories = {c.slug: c for c in Category.objects.filter(slug__in=[i["category"] for i in data["items"]])}
        items = []
        for index, item in enumerate(data["items"]):
            category = categories.get(item["category"])
            if category is None:
                raise ValidationError({"items": {index: {"category": "Unknown category."}}})
            quantity = Quantity(item["quantity"]["value"], item["quantity"]["unit"])
            form = item.get("product_form") or None
            label = " ".join(part for part in (str(quantity), form, category.name.lower()) if part)
            items.append(BasketRequestItem(f"item-{index}", label, category, quantity, form,
                                           parse_requirements(category, item["specification"])))
        result = compare_grocery_basket(items, requirements)
        body = basket_to_dict(result)
        stored = ComparisonRequest.objects.create(
            user=request.user if request.user.is_authenticated else None, kind=ComparisonRequest.Kind.BASKET,
            requirements=requirements.as_dict(), currency=requirements.currency, result=body, created_at=result.generated_at,
        )
        return Response({"id": stored.pk, **body}, status=status.HTTP_201_CREATED)


# ----------------------------------------------------------------- alerts, corrections

class AlertCreate(IdempotentPostMixin, APIView):
    """Create a price alert that keeps the caller's full requirements."""

    permission_classes = [permissions.IsAuthenticated]

    @extend_schema(request=s.AlertCreateSerializer, parameters=[IDEMPOTENCY_HEADER],
                   responses={201: s.AlertSerializer, 401: s.ErrorSerializer, 409: s.ErrorSerializer, **ERRORS})
    def post(self, request, *args, **kwargs):
        return super().post(request, *args, **kwargs)

    def create(self, request):
        serializer = s.AlertCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        variant = ProductVariant.objects.filter(pk=data["variant_id"], status=ProductVariant.Status.ACTIVE).first()
        if variant is None:
            raise NotFound()
        if PriceAlert.objects.filter(user=request.user).count() >= 50:
            raise ValidationError("Alert limit reached (50).")
        alert = create_alert(user=request.user, variant=variant, target_total=data["target_total"],
                             requirements=_requirements(data["requirements"]))
        return Response(s.AlertSerializer(alert).data, status=status.HTTP_201_CREATED)


class CorrectionCreate(IdempotentPostMixin, APIView):
    """Report incorrect information about a listing or product."""

    permission_classes = [permissions.AllowAny]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "corrections"

    @extend_schema(request=s.CorrectionCreateSerializer, parameters=[IDEMPOTENCY_HEADER],
                   responses={201: s.CorrectionSerializer, 409: s.ErrorSerializer, **ERRORS})
    def post(self, request, *args, **kwargs):
        return super().post(request, *args, **kwargs)

    def create(self, request):
        serializer = s.CorrectionCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        listing = SupplierListing.objects.filter(pk=data.get("listing_id")).first() if data.get("listing_id") else None
        variant = ProductVariant.objects.filter(pk=data.get("variant_id")).first() if data.get("variant_id") else None
        if listing is None and variant is None:
            raise NotFound()
        correction = CorrectionRequest.objects.create(
            reporter=request.user if request.user.is_authenticated else None, listing=listing, variant=variant,
            kind=data["kind"], description=clean_text(data["description"], 2000), created_at=system_clock.now(),
        )
        record("correction.reported", correction, actor=request.user, data={"kind": correction.kind, "via": "api"})
        return Response(s.CorrectionSerializer(correction).data, status=status.HTTP_201_CREATED)


# -------------------------------------------------------------------------- supplier

class IsSupplierAccount(permissions.BasePermission):
    message = "A supplier account is required."

    def has_permission(self, request, view) -> bool:
        return bool(
            request.user and request.user.is_authenticated
            and SupplierAccount.objects.filter(user=request.user, is_active=True, supplier__status="active").exists()
        )


def acting_supplier(request, slug: str | None = None):
    """The supplier this caller may act for. A caller can never name someone else's supplier."""
    accounts = SupplierAccount.objects.filter(user=request.user, is_active=True, supplier__status="active").select_related("supplier")
    if slug:
        account = accounts.filter(supplier__slug=slug).first()
        if account is None:
            raise PermissionDenied()
        return account.supplier
    if accounts.count() != 1:
        raise ValidationError({"supplier": "Your account acts for several suppliers; say which one."})
    return accounts.first().supplier


def _submission_response(result) -> dict:
    return {
        "listing_id": result.listing.pk, "supplier_sku": result.listing.supplier_sku,
        "observation_id": result.observation.pk, "status": result.observation.status,
        "issues": result.observation.issues, "matched_variant_id": result.listing.variant_id,
    }


def _to_payload(data: dict) -> dict:
    """Validated serializer data -> submission payload with exact decimal strings."""
    payload = {}
    for key, value in data.items():
        if value is None or key == "supplier":
            continue
        if key == "fees":
            payload[key] = [{**fee, "amount": None if fee.get("amount") is None else str(fee["amount"])} for fee in value]
        elif key == "effective_date":
            payload[key] = value.isoformat()
        elif isinstance(value, bool) or isinstance(value, (list, dict)):
            payload[key] = value
        else:
            payload[key] = str(value)
    return payload


class SupplierListings(IdempotentPostMixin, APIView):
    """Submit (create or update) one of your own listings with its current price."""

    permission_classes = [permissions.IsAuthenticated, IsSupplierAccount]

    @extend_schema(responses={200: s.SupplierListingSerializer(many=True), 401: s.ErrorSerializer, 403: s.ErrorSerializer},
                   parameters=[OpenApiParameter("supplier", str, description="Only if your account acts for several suppliers.")])
    def get(self, request):
        supplier = acting_supplier(request, request.query_params.get("supplier"))
        listings = SupplierListing.objects.filter(supplier=supplier).order_by("supplier_sku")[:500]
        return Response(s.SupplierListingSerializer(listings, many=True).data)

    @extend_schema(request=s.ListingSubmissionSerializer, parameters=[IDEMPOTENCY_HEADER],
                   responses={201: s.SubmissionResultSerializer, 401: s.ErrorSerializer, 403: s.ErrorSerializer,
                              409: s.ErrorSerializer, **ERRORS})
    def post(self, request, *args, **kwargs):
        return super().post(request, *args, **kwargs)

    def create(self, request):
        serializer = s.ListingSubmissionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        supplier = acting_supplier(request, data.get("supplier"))
        try:
            result = submit_offer(supplier, _to_payload(data), actor=request.user)
        except NoManualSourceError as exc:
            raise ValidationError(str(exc)) from None
        return Response(_submission_response(result), status=status.HTTP_201_CREATED)


class SupplierListingPrices(IdempotentPostMixin, APIView):
    """Record a new price observation for one of your existing listings."""

    permission_classes = [permissions.IsAuthenticated, IsSupplierAccount]

    @extend_schema(request=s.PriceSubmissionSerializer, parameters=[
        IDEMPOTENCY_HEADER, OpenApiParameter("supplier", str, description="Only if your account acts for several suppliers."),
    ], responses={201: s.SubmissionResultSerializer, 401: s.ErrorSerializer, 403: s.ErrorSerializer, 409: s.ErrorSerializer, **ERRORS})
    def post(self, request, *args, **kwargs):
        return super().post(request, *args, **kwargs)

    def create(self, request, sku: str):
        supplier = acting_supplier(request, request.query_params.get("supplier"))
        # Scoped to the caller's supplier: another supplier's SKU is simply not found.
        listing = SupplierListing.objects.filter(supplier=supplier, supplier_sku=sku).first()
        if listing is None:
            raise NotFound()
        serializer = s.PriceSubmissionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        payload = _to_payload(serializer.validated_data)
        payload.update({
            "supplier_sku": listing.supplier_sku, "title": listing.title, "brand": listing.brand, "gtin": listing.gtin,
            "mpn": listing.mpn, "model": listing.model, "condition": listing.condition, "url": listing.url,
            "specs": {k: str(v) for k, v in (listing.attributes or {}).items()},
            "included": listing.included_contents, "warranty": listing.warranty,
        })
        if listing.pack_count:
            payload["pack_quantity"] = str(listing.pack_count)
        try:
            result = submit_offer(supplier, payload, actor=request.user)
        except NoManualSourceError as exc:
            raise ValidationError(str(exc)) from None
        return Response(_submission_response(result), status=status.HTTP_201_CREATED)
