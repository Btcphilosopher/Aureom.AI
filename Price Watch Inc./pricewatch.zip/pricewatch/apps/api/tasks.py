from datetime import timedelta

from celery import shared_task

from apps.core.clock import system_clock

from .models import IdempotencyRecord

RETENTION = timedelta(hours=48)


@shared_task(name="apps.api.tasks.prune_idempotency_records", ignore_result=True)
def prune_idempotency_records() -> int:
    """Idempotency keys only need to outlive client retries; drop stored responses after 48 hours."""
    deleted, _ = IdempotencyRecord.objects.filter(created_at__lt=system_clock.now() - RETENTION).delete()
    return deleted
