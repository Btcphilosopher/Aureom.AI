from django.db import models


class IdempotencyRecord(models.Model):
    """Stored response for an ``Idempotency-Key`` so retried POSTs are not applied twice."""

    scope = models.CharField(max_length=120)  # "user:<id>" or "anon:<session/ip hash>" + endpoint
    key = models.CharField(max_length=128)
    request_hash = models.CharField(max_length=64)
    response_status = models.PositiveSmallIntegerField()
    response_body = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["scope", "key"], name="uniq_idempotency_key_per_scope")]
        indexes = [models.Index(fields=["created_at"])]
