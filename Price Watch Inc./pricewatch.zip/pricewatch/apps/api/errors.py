"""Structured API errors.

Every error response has the same shape::

    {"error": {"code": "validation_error", "message": "...", "details": {...}, "request_id": "..."}}
"""
from __future__ import annotations

from django.core.exceptions import PermissionDenied
from django.http import Http404
from rest_framework import exceptions, status
from rest_framework.response import Response
from rest_framework.views import exception_handler

from apps.comparisons.services import InvalidRequirementsError
from apps.core.logging import get_logger
from apps.pricing.units import IncompatibleUnitsError, UnknownUnitError

logger = get_logger("api")


class Conflict(exceptions.APIException):
    status_code = status.HTTP_409_CONFLICT
    default_detail = "The request conflicts with the current state."
    default_code = "conflict"


def error_response(code: str, message: str, http_status: int, request=None, details=None) -> Response:
    request_id = getattr(getattr(request, "_request", request), "request_id", "") if request is not None else ""
    return Response(
        {"error": {"code": code, "message": message, "details": details or {}, "request_id": request_id}}, status=http_status
    )


def structured_exception_handler(exc, context):
    request = context.get("request")
    if isinstance(exc, (InvalidRequirementsError, IncompatibleUnitsError, UnknownUnitError)):
        return error_response("invalid_requirements", str(exc), status.HTTP_400_BAD_REQUEST, request)
    response = exception_handler(exc, context)
    if response is None:
        logger.exception("unhandled API error")
        return error_response("server_error", "An unexpected error occurred.", status.HTTP_500_INTERNAL_SERVER_ERROR, request)
    if isinstance(exc, exceptions.ValidationError):
        code, message, details = "validation_error", "The request is invalid.", exc.detail
        if not isinstance(details, dict):
            details = {"non_field_errors": details}
    elif isinstance(exc, (Http404, exceptions.NotFound)):
        code, message, details = "not_found", "The requested resource was not found.", {}
    elif isinstance(exc, (PermissionDenied, exceptions.PermissionDenied)):
        code, message, details = "permission_denied", "You do not have permission to do this.", {}
    elif isinstance(exc, (exceptions.NotAuthenticated, exceptions.AuthenticationFailed)):
        code, message, details = "not_authenticated", "Authentication is required.", {}
    elif isinstance(exc, exceptions.Throttled):
        code, message, details = "throttled", "Too many requests.", {"retry_after_seconds": exc.wait}
    elif isinstance(exc, exceptions.APIException):
        code, message, details = exc.default_code, str(exc.detail), {}
    else:
        code, message, details = "error", "The request could not be processed.", {}
    structured = error_response(code, message, response.status_code, request, details)
    for header, value in response.headers.items():
        if header.lower() in ("retry-after", "www-authenticate", "allow"):
            structured[header] = value
    return structured
