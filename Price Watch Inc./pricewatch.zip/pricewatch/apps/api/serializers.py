"""Request validation and documented response shapes for API v1."""
from __future__ import annotations

from decimal import Decimal

from rest_framework import serializers

from apps.audit.models import CorrectionRequest
from apps.catalogue.models import Product, ProductVariant

CONDITIONS = ["new", "refurbished", "used", "open_box"]
MEMBERSHIP_STATES = ["held", "not_held", "unknown"]
MONEY = dict(max_digits=12, decimal_places=2, min_value=Decimal("0.00"))


# ------------------------------------------------------------------------- catalogue

class VariantSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductVariant
        fields = ["id", "name", "gtin", "mpn", "attributes", "included_contents", "warranty", "pack_count",
                  "net_quantity", "net_quantity_unit"]


class ProductSerializer(serializers.ModelSerializer):
    category = serializers.SlugRelatedField(slug_field="slug", read_only=True)
    variants = VariantSerializer(many=True, read_only=True)

    class Meta:
        model = Product
        fields = ["id", "slug", "brand", "name", "model", "category", "description", "specs", "variants"]


# ---------------------------------------------------------------------- requirements

class RequirementsSerializer(serializers.Serializer):
    """The customer's situation. Anything omitted is treated as unknown, never assumed."""

    condition = serializers.ChoiceField(choices=CONDITIONS, default="new")
    quantity = serializers.IntegerField(min_value=1, max_value=999, default=1)
    memberships = serializers.DictField(
        child=serializers.ChoiceField(choices=MEMBERSHIP_STATES), required=False, default=dict,
        help_text="Supplier slug -> held | not_held | unknown. Omitted suppliers are unknown.",
    )
    coupon_codes = serializers.ListField(child=serializers.CharField(max_length=40), required=False, default=list, max_length=10)
    currency = serializers.RegexField(r"^[A-Z]{3}$", default="GBP")


class SpecRequirementSerializer(serializers.Serializer):
    attribute = serializers.CharField(max_length=40)
    op = serializers.ChoiceField(choices=["eq", "ne", "gte", "lte", "in"], default="eq")
    value = serializers.JSONField()


class QuantitySerializer(serializers.Serializer):
    value = serializers.DecimalField(max_digits=12, decimal_places=3, min_value=Decimal("0.001"))
    unit = serializers.CharField(max_length=10, default="each")


class ComparisonCreateSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=["variant", "specification", "unit_price"], default="variant")
    variant_id = serializers.IntegerField(required=False, help_text="Required for kind=variant.")
    category = serializers.SlugField(required=False, help_text="Category slug; required for specification and unit_price.")
    specification = SpecRequirementSerializer(many=True, required=False, default=list)
    quantity = QuantitySerializer(required=False, help_text="Required for kind=unit_price.")
    product_form = serializers.CharField(max_length=60, required=False, allow_blank=True)
    requirements = RequirementsSerializer(required=False, default=dict)

    def validate(self, data):
        kind = data["kind"]
        if kind == "variant" and not data.get("variant_id"):
            raise serializers.ValidationError({"variant_id": "This field is required for kind=variant."})
        if kind in ("specification", "unit_price") and not data.get("category"):
            raise serializers.ValidationError({"category": f"This field is required for kind={kind}."})
        if kind == "specification" and not data.get("specification"):
            raise serializers.ValidationError({"specification": "Give at least one requirement."})
        if kind == "unit_price" and not data.get("quantity"):
            raise serializers.ValidationError({"quantity": "This field is required for kind=unit_price."})
        return data


class BasketItemSerializer(serializers.Serializer):
    category = serializers.SlugField()
    quantity = QuantitySerializer()
    product_form = serializers.CharField(max_length=60, required=False, allow_blank=True)
    specification = SpecRequirementSerializer(many=True, required=False, default=list)


class BasketCreateSerializer(serializers.Serializer):
    items = BasketItemSerializer(many=True, min_length=1, max_length=25)
    requirements = RequirementsSerializer(required=False, default=dict)


class AlertCreateSerializer(serializers.Serializer):
    variant_id = serializers.IntegerField()
    target_total = serializers.DecimalField(max_digits=12, decimal_places=2, min_value=Decimal("0.01"))
    requirements = RequirementsSerializer(required=False, default=dict)


class AlertSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    variant_id = serializers.IntegerField()
    target_total = serializers.DecimalField(max_digits=12, decimal_places=2)
    currency = serializers.CharField()
    requirements = serializers.JSONField()
    status = serializers.CharField()
    min_interval_hours = serializers.IntegerField()
    created_at = serializers.DateTimeField()


class CorrectionCreateSerializer(serializers.Serializer):
    kind = serializers.ChoiceField(choices=CorrectionRequest.Kind.values)
    description = serializers.CharField(min_length=10, max_length=2000)
    listing_id = serializers.IntegerField(required=False)
    variant_id = serializers.IntegerField(required=False)

    def validate(self, data):
        if not data.get("listing_id") and not data.get("variant_id"):
            raise serializers.ValidationError("Give a listing_id or a variant_id so we know what to check.")
        return data


class CorrectionSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    kind = serializers.CharField()
    status = serializers.CharField()
    created_at = serializers.DateTimeField()


# -------------------------------------------------------------------------- supplier

class FeeSerializer(serializers.Serializer):
    label = serializers.CharField(max_length=80)
    amount = serializers.DecimalField(required=False, allow_null=True, **MONEY)
    mandatory = serializers.BooleanField(default=True)


class PriceSubmissionSerializer(serializers.Serializer):
    """Price fields. Omitted optional fields are stored as unknown, not as zero."""

    price = serializers.DecimalField(max_digits=12, decimal_places=2, min_value=Decimal("0.01"))
    currency = serializers.RegexField(r"^[A-Z]{3}$")
    tax_treatment = serializers.ChoiceField(choices=["included", "excluded"])
    tax_rate = serializers.DecimalField(max_digits=5, decimal_places=4, min_value=Decimal("0"), max_value=Decimal("0.9999"),
                                        required=False, allow_null=True)
    delivery_cost = serializers.DecimalField(required=False, allow_null=True, **MONEY)
    delivery_free_threshold = serializers.DecimalField(required=False, allow_null=True, **MONEY)
    availability = serializers.ChoiceField(choices=["in_stock", "out_of_stock", "preorder", "unknown"], default="unknown")
    membership_required = serializers.BooleanField(default=False)
    min_order = serializers.DecimalField(required=False, allow_null=True, **MONEY)
    fees = FeeSerializer(many=True, required=False, default=list, max_length=10)
    effective_date = serializers.DateTimeField(required=False, allow_null=True)

    def validate(self, data):
        if data["tax_treatment"] == "excluded" and data.get("tax_rate") is None:
            raise serializers.ValidationError({"tax_rate": "Required when tax_treatment is 'excluded'."})
        return data


class ListingSubmissionSerializer(PriceSubmissionSerializer):
    supplier = serializers.SlugField(required=False, help_text="Only needed if your account acts for several suppliers.")
    supplier_sku = serializers.RegexField(r"^[A-Za-z0-9._\-]{1,100}$")
    title = serializers.CharField(max_length=300)
    brand = serializers.CharField(max_length=100, required=False, allow_blank=True)
    gtin = serializers.RegexField(r"^\d{8,14}$", required=False, allow_blank=True)
    mpn = serializers.CharField(max_length=60, required=False, allow_blank=True)
    model = serializers.CharField(max_length=100, required=False, allow_blank=True)
    condition = serializers.ChoiceField(choices=CONDITIONS)
    specs = serializers.DictField(child=serializers.CharField(max_length=120), required=False, default=dict)
    included = serializers.ListField(child=serializers.CharField(max_length=80), required=False, max_length=30)
    warranty = serializers.CharField(max_length=120, required=False, allow_blank=True)
    pack_quantity = serializers.IntegerField(min_value=1, max_value=10000, required=False)
    net_quantity = serializers.CharField(max_length=40, required=False, allow_blank=True)
    url = serializers.URLField(max_length=1000)


class SubmissionResultSerializer(serializers.Serializer):
    listing_id = serializers.IntegerField()
    supplier_sku = serializers.CharField()
    observation_id = serializers.IntegerField()
    status = serializers.CharField(help_text="valid (published) or quarantined (held for review)")
    issues = serializers.ListField(child=serializers.DictField())
    matched_variant_id = serializers.IntegerField(allow_null=True)


class SupplierListingSerializer(serializers.Serializer):
    listing_id = serializers.IntegerField(source="pk")
    supplier_sku = serializers.CharField()
    title = serializers.CharField()
    status = serializers.CharField()
    condition = serializers.CharField()
    matched_variant_id = serializers.IntegerField(source="variant_id", allow_null=True)
    last_seen_at = serializers.DateTimeField()


# --------------------------------------------------------------- documented responses

class ErrorBodySerializer(serializers.Serializer):
    code = serializers.CharField()
    message = serializers.CharField()
    details = serializers.DictField()
    request_id = serializers.CharField()


class ErrorSerializer(serializers.Serializer):
    error = ErrorBodySerializer()


class PriceLineSerializer(serializers.Serializer):
    kind = serializers.CharField()
    label = serializers.CharField()
    amount = serializers.CharField(allow_null=True, help_text="Decimal string; null when unknown.")
    status = serializers.ChoiceField(choices=["included", "additional", "unknown", "not_applicable"])
    note = serializers.CharField()


class PriceSerializer(serializers.Serializer):
    currency = serializers.CharField()
    total = serializers.CharField(allow_null=True, help_text="Comparable payable total; null means 'Total incomplete'.")
    known_subtotal = serializers.CharField()
    completeness = serializers.ChoiceField(choices=["complete", "incomplete"])
    eligibility = serializers.ChoiceField(choices=["eligible", "conditional", "ineligible"])
    lines = PriceLineSerializer(many=True)
    missing = serializers.ListField(child=serializers.CharField())
    conditions = serializers.ListField(child=serializers.CharField())
    conditional_discounts = serializers.ListField(child=serializers.DictField())
    assumptions = serializers.ListField(child=serializers.CharField())


class OfferSerializer(serializers.Serializer):
    listing_id = serializers.IntegerField()
    supplier = serializers.DictField()
    title = serializers.CharField()
    condition = serializers.CharField()
    included_contents = serializers.ListField(child=serializers.CharField(), allow_null=True)
    availability = serializers.CharField()
    rank = serializers.IntegerField(allow_null=True)
    group = serializers.ChoiceField(choices=["ranked", "conditional", "incomplete", "ineligible", "unavailable"])
    sponsored = serializers.BooleanField(help_text="Paid placement flag. Never affects rank.")
    price = PriceSerializer()
    unit_price = serializers.DictField(allow_null=True)
    freshness = serializers.DictField(help_text="state is fresh or stale; stale offers keep the last verified price.")
    match = serializers.DictField()
    provenance = serializers.DictField()
    purchase_path = serializers.CharField()


class ExcludedSerializer(serializers.Serializer):
    listing_id = serializers.IntegerField()
    supplier = serializers.CharField()
    title = serializers.CharField()
    kind = serializers.CharField()
    reasons = serializers.ListField(child=serializers.CharField())


class ComparisonResultSerializer(serializers.Serializer):
    id = serializers.IntegerField(required=False, help_text="Present on POST /comparisons.")
    title = serializers.CharField()
    mode = serializers.ChoiceField(choices=["exact", "spec_equivalent", "unit_price"])
    requirements = serializers.DictField()
    generated_at = serializers.DateTimeField()
    winner_listing_id = serializers.IntegerField(allow_null=True)
    explanation = serializers.ListField(child=serializers.CharField())
    ranked = OfferSerializer(many=True)
    conditional = OfferSerializer(many=True)
    total_incomplete = OfferSerializer(many=True)
    ineligible = OfferSerializer(many=True)
    unavailable = OfferSerializer(many=True)
    sponsored_listing_ids = serializers.ListField(child=serializers.IntegerField())
    not_comparable = ExcludedSerializer(many=True)
    insufficient_evidence = ExcludedSerializer(many=True)
    assumptions = serializers.ListField(child=serializers.CharField())


class HistoryPointSerializer(serializers.Serializer):
    observed_at = serializers.DateTimeField()
    item_price = serializers.CharField()


class HistorySeriesSerializer(serializers.Serializer):
    listing_id = serializers.IntegerField()
    supplier = serializers.CharField()
    currency = serializers.CharField()
    points = HistoryPointSerializer(many=True)


class HistorySerializer(serializers.Serializer):
    variant_id = serializers.IntegerField()
    condition = serializers.CharField()
    note = serializers.CharField()
    series = HistorySeriesSerializer(many=True)


class BasketResultSerializer(serializers.Serializer):
    id = serializers.IntegerField(required=False)
    generated_at = serializers.DateTimeField()
    requirements = serializers.DictField()
    items = serializers.ListField(child=serializers.DictField())
    cheapest_single_supplier = serializers.DictField(allow_null=True)
    single_supplier_options = serializers.ListField(child=serializers.DictField())
    baseline_split = serializers.DictField(allow_null=True, help_text="Heuristic; not guaranteed optimal.")
    exhaustive_split = serializers.DictField(allow_null=True, help_text="Exact for the documented model; null beyond the search bound.")
    conditional_discounts = serializers.ListField(child=serializers.CharField())
    excluded = serializers.ListField(child=serializers.CharField())
    assumptions = serializers.ListField(child=serializers.CharField())
