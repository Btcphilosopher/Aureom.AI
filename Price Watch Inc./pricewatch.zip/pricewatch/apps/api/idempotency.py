"""Idempotent POST handling.

Send ``Idempotency-Key: <unique string>`` with a POST. Repeating the request
with the same key and the same body returns the original response (with
``Idempotent-Replayed: true``) and performs no new work. Reusing a key with a
different body is rejected with 409. Keys are scoped to the caller and endpoint.
"""
from __future__ import annotations

import hashlib
import json
import re

from django.db import IntegrityError, transaction
from rest_framework.response import Response

from .errors import Conflict, error_response
from .models import IdempotencyRecord

_KEY = re.compile(r"^[A-Za-z0-9._:\-]{8,128}$")


def _scope(request) -> str:
    if request.user and request.user.is_authenticated:
        caller = f"user:{request.user.pk}"
    else:
        caller = "anon:" + hashlib.sha256(request.META.get("REMOTE_ADDR", "").encode()).hexdigest()[:16]
    return f"{caller}:{request.path}"[:120]


def _replay(record: IdempotencyRecord) -> Response:
    response = Response(record.response_body, status=record.response_status)
    response["Idempotent-Replayed"] = "true"
    return response


class IdempotentPostMixin:
    """Wraps ``create(request)`` so a retried request cannot be applied twice."""

    def post(self, request, *args, **kwargs):
        key = request.headers.get("Idempotency-Key")
        if key is None:
            return self.create(request, *args, **kwargs)
        if not _KEY.match(key):
            return error_response("invalid_idempotency_key", "Idempotency-Key must be 8-128 characters: letters, digits, . _ : -", 400, request)
        scope = _scope(request)
        request_hash = hashlib.sha256(json.dumps(request.data, sort_keys=True, default=str).encode()).hexdigest()
        existing = IdempotencyRecord.objects.filter(scope=scope, key=key).first()
        if existing is not None:
            if existing.request_hash != request_hash:
                raise Conflict("This Idempotency-Key was already used with a different request body.")
            return _replay(existing)
        try:
            with transaction.atomic():
                response = self.create(request, *args, **kwargs)
                if response.status_code < 500:
                    IdempotencyRecord.objects.create(
                        scope=scope, key=key, request_hash=request_hash,
                        response_status=response.status_code, response_body=json.loads(json.dumps(response.data, default=str)),
                    )
        except IntegrityError:
            # A concurrent request with the same key won the race; our work was rolled back.
            existing = IdempotencyRecord.objects.filter(scope=scope, key=key).first()
            if existing is None or existing.request_hash != request_hash:
                raise Conflict("This Idempotency-Key is in use by another request.") from None
            return _replay(existing)
        return response
