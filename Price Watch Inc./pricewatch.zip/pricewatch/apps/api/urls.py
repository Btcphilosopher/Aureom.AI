"""API v1 routes. The version is explicit in the path (``/api/v1/``)."""
from django.urls import path
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView

from . import views

urlpatterns = [
    path("products", views.ProductList.as_view(), name="product-list"),
    path("products/<int:pk>", views.ProductDetail.as_view(), name="product-detail"),
    path("products/<int:pk>/offers", views.ProductOffers.as_view(), name="product-offers"),
    path("products/<int:pk>/history", views.ProductHistory.as_view(), name="product-history"),
    path("comparisons", views.ComparisonCreate.as_view(), name="comparison-create"),
    path("basket-comparisons", views.BasketComparisonCreate.as_view(), name="basket-comparison-create"),
    path("alerts", views.AlertCreate.as_view(), name="alert-create"),
    path("corrections", views.CorrectionCreate.as_view(), name="correction-create"),
    path("supplier/listings", views.SupplierListings.as_view(), name="supplier-listings"),
    path("supplier/listings/<str:sku>/prices", views.SupplierListingPrices.as_view(), name="supplier-listing-prices"),
    path("schema/", SpectacularAPIView.as_view(api_version="v1"), name="schema"),
    path("docs/", SpectacularSwaggerView.as_view(url_name="v1:schema"), name="docs"),
    path("redoc/", SpectacularRedocView.as_view(url_name="v1:schema"), name="redoc"),
]
