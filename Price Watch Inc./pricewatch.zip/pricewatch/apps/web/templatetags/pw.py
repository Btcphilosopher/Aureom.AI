"""Template helpers. None of these mark supplier-derived text as safe."""
from decimal import Decimal

from django import template

from apps.comparisons.services import money as format_money

register = template.Library()


@register.filter
def money(amount, currency="GBP"):
    if amount is None or amount == "":
        return "unknown"
    return format_money(Decimal(amount), currency)


_LABELS = {"ram_gb": "RAM (GB)", "storage_gb": "Storage (GB)", "json_ld": "JSON-LD structured data", "css_selector": "HTML selector",
           "browser_dom": "Browser-rendered page", "csv_column": "CSV feed", "json_field": "JSON feed", "api_field": "Supplier API",
           "manual_submission": "Supplier submission", "gtin": "GTIN", "screen_inches": "Screen (inches)"}


@register.filter
def label(value):
    """'refurbished' / 'open_box' / 'storage_gb' -> human text."""
    key = str(value or "")
    if key in _LABELS:
        return _LABELS[key]
    text = key.replace("_", " ")
    return text[:1].upper() + text[1:]


@register.filter
def get_item(mapping, key):
    try:
        return mapping.get(key)
    except AttributeError:
        return None


@register.filter
def quantity(value):
    """Decimal without trailing zeros."""
    if value is None:
        return ""
    text = format(Decimal(value).normalize(), "f")
    return text


@register.simple_tag(takes_context=True)
def query_with(context, **changes):
    """Current query string with some parameters replaced (for filter/pagination links)."""
    params = context["request"].GET.copy()
    for key, value in changes.items():
        if value in (None, ""):
            params.pop(key, None)
        else:
            params[key] = value
    return params.urlencode()
