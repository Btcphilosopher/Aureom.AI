from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("search/", views.search, name="search"),
    path("c/<slug:slug>/", views.category_detail, name="category"),
    path("p/<slug:slug>/", views.product_detail, name="product"),
    path("p/<slug:slug>/history.csv", views.history_csv, name="history_csv"),
    path("out/<int:listing_id>/", views.outbound, name="outbound"),
    path("basket/", views.basket, name="basket"),
    path("lists/", views.saved_lists, name="lists"),
    path("alerts/", views.alerts, name="alerts"),
    path("report/", views.report_correction, name="report"),
    path("review/", views.review, name="review"),
    path("ops/", views.operations, name="operations"),
    path("accounts/signup/", views.signup, name="signup"),
]
