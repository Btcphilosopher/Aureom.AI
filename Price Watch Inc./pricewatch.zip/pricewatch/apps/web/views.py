"""Server-rendered pages. Views parse input, call services and choose a template."""
from __future__ import annotations

import csv
import hashlib
from decimal import Decimal, InvalidOperation
from urllib.parse import urlsplit

from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.core.cache import cache
from django.core.paginator import Paginator
from django.db.models import Count, Min, Q
from django.http import Http404, HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_GET, require_http_methods, require_POST

from apps.accounts.models import CustomerMembership, User
from apps.alerts.models import PriceAlert
from apps.alerts.services import create_alert
from apps.audit.models import AuditEvent, CorrectionRequest
from apps.audit.services import record
from apps.catalogue.models import Category, Product, ProductVariant
from apps.collection.models import CollectionRun
from apps.collection.tasks import collect_source
from apps.comparisons.models import SavedSearch
from apps.comparisons.services import (
    BasketRequestItem,
    InvalidRequirementsError,
    Requirements,
    compare_grocery_basket,
    compare_specification,
    compare_unit_price,
    compare_variant,
    price_history,
)
from apps.core.clock import system_clock
from apps.core.text import clean_text, spreadsheet_safe
from apps.matching.models import MatchDecision
from apps.matching.services import review_decision
from apps.matching.types import Requirement
from apps.pricing.units import IncompatibleUnitsError, Quantity, UnknownUnitError
from apps.suppliers.models import OfferObservation, SourceConfiguration, Supplier, SupplierListing
from apps.suppliers.services import review_observation

from .charts import build_history_chart

CONDITIONS = [("new", "New"), ("refurbished", "Refurbished"), ("used", "Used"), ("open_box", "Open box")]
GROCERY_UNITS = [("kg", "kg"), ("g", "g"), ("l", "litres"), ("ml", "ml"), ("pt", "pints"), ("each", "items")]


class CustomerSignupForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email")


def is_htmx(request) -> bool:
    return request.headers.get("HX-Request") == "true"


def client_key(request) -> str:
    """Stable, non-reversible key for rate limiting anonymous actions."""
    if request.user.is_authenticated:
        return f"user:{request.user.pk}"
    return "ip:" + hashlib.sha256(request.META.get("REMOTE_ADDR", "").encode()).hexdigest()[:20]


def rate_limited(request, action: str, limit: int, window_seconds: int = 3600) -> bool:
    key = f"pricewatch:rl:{action}:{client_key(request)}"
    cache.add(key, 0, window_seconds)
    try:
        return cache.incr(key) > limit
    except ValueError:
        return False


def requirements_from_request(request, params=None) -> Requirements:
    """Requirements from the query string, falling back to saved membership answers."""
    params = params if params is not None else request.GET
    memberships: dict[str, str] = {}
    if request.user.is_authenticated:
        memberships.update(
            CustomerMembership.objects.filter(user=request.user).values_list("supplier__slug", "status")
        )
    for key, value in params.items():
        if key.startswith("m_") and value in ("held", "not_held", "unknown"):
            memberships[key[2:]] = value
    return Requirements.from_dict({
        "condition": params.get("condition") or "new",
        "quantity": params.get("quantity") or 1,
        "memberships": memberships,
        "coupon_codes": params.get("coupon", ""),
    })


def _remember_memberships(request, requirements: Requirements) -> None:
    """Persist explicit membership answers for signed-in customers."""
    if not request.user.is_authenticated:
        return
    explicit = {k[2:]: v for k, v in request.GET.items() if k.startswith("m_")}
    for supplier in Supplier.objects.filter(slug__in=explicit).exclude(membership_programme=""):
        state = explicit[supplier.slug]
        if state == "unknown":
            CustomerMembership.objects.filter(user=request.user, supplier=supplier).delete()
        elif state in ("held", "not_held"):
            CustomerMembership.objects.update_or_create(user=request.user, supplier=supplier, defaults={"status": state})


def _product_queryset():
    # "From" prices only count tax-inclusive offers for new (or condition-less grocery) listings.
    listing_filter = Q(
        variants__listings__status=SupplierListing.Status.ACTIVE,
        variants__listings__condition__in=["new", "unknown"],
        variants__listings__latest_valid_observation__tax_treatment="included",
    )
    return (
        Product.objects.filter(status=Product.Status.ACTIVE)
        .select_related("category")
        .annotate(
            from_price=Min("variants__listings__latest_valid_observation__price_amount", filter=listing_filter),
            supplier_count=Count("variants__listings__supplier", filter=listing_filter, distinct=True),
        )
    )


def _search(queryset, query: str):
    for token in query.split()[:6]:
        queryset = queryset.filter(
            Q(name__icontains=token) | Q(brand__icontains=token) | Q(model__icontains=token)
            | Q(variants__name__icontains=token) | Q(variants__gtin=token) | Q(variants__mpn__iexact=token)
            | Q(category__name__icontains=token)
        )
    return queryset.distinct()


# ------------------------------------------------------------------------------ pages

@require_GET
def home(request):
    return render(request, "web/home.html", {
        "categories": Category.objects.annotate(product_count=Count("products")).order_by("vertical", "name"),
        "featured": _product_queryset().filter(category__vertical="electronics").order_by("-supplier_count", "name")[:4],
    })


@require_GET
def search(request):
    query = clean_text(request.GET.get("q", ""), 100)
    products = _product_queryset()
    if query:
        products = _search(products, query)
    category = None
    if request.GET.get("category"):
        category = Category.objects.filter(slug=request.GET["category"]).first()
        if category:
            products = products.filter(category=category)
    if request.GET.get("brand"):
        products = products.filter(brand__iexact=request.GET["brand"])
    page = Paginator(products.order_by("brand", "name"), 12).get_page(request.GET.get("page"))
    context = {
        "query": query, "page": page, "category": category, "categories": Category.objects.all(),
        "brands": Product.objects.order_by("brand").values_list("brand", flat=True).distinct(),
        "selected_brand": request.GET.get("brand", ""),
    }
    return render(request, "partials/_product_results.html" if is_htmx(request) else "web/search.html", context)


def _spec_requirements(request, category: Category) -> list[Requirement]:
    requirements: list[Requirement] = []
    for attribute in category.filter_attributes or []:
        if attribute == "brand":
            if request.GET.get("brand"):
                requirements.append(Requirement("brand", "eq", clean_text(request.GET["brand"], 60)))
        elif attribute.endswith("_gb"):
            value = request.GET.get(f"min_{attribute}", "")
            if value.isdigit() and int(value) > 0:
                requirements.append(Requirement(attribute, "gte", int(value)))
        elif attribute == "organic":
            if request.GET.get("organic") == "1":
                requirements.append(Requirement("organic", "eq", True))
    return requirements


@require_GET
def category_detail(request, slug):
    category = get_object_or_404(Category, slug=slug)
    products = _product_queryset().filter(category=category).order_by("brand", "name")
    context = {"category": category, "products": products, "conditions": CONDITIONS, "units": GROCERY_UNITS, "error": ""}
    variants = ProductVariant.objects.filter(product__category=category)
    context["brands"] = sorted({p.brand for p in products})
    try:
        requirements = requirements_from_request(request)
        if category.vertical == Category.Vertical.GROCERY:
            forms = sorted({(v.attributes or {}).get("product_form") for v in variants} - {None})
            context["forms"] = forms
            form = request.GET.get("form") if request.GET.get("form") in forms else None
            amount = request.GET.get("amount", "")
            context.update(selected_form=form or "", amount=amount, unit=request.GET.get("unit", ""),
                           organic=request.GET.get("organic") == "1")
            if amount:
                required = Quantity(Decimal(amount), request.GET.get("unit") or "each")
                context["result"] = compare_unit_price(
                    category, required, requirements, product_form=form,
                    attribute_requirements=[r for r in _spec_requirements(request, category) if r.attribute != "product_form"],
                )
        else:
            spec = _spec_requirements(request, category)
            context["spec_values"] = {f"min_{a}": request.GET.get(f"min_{a}", "") for a in category.filter_attributes or []}
            context["options"] = {
                a: sorted({(v.attributes or {}).get(a) for v in variants} - {None})
                for a in category.filter_attributes or [] if a.endswith("_gb")
            }
            context["selected_brand"] = request.GET.get("brand", "")
            if spec:
                context["result"] = compare_specification(category, spec, requirements)
    except (InvalidRequirementsError, InvalidOperation, UnknownUnitError, IncompatibleUnitsError, ValueError) as exc:
        context["error"] = f"We could not use those filters: {exc}"
    context["requirements"] = context["result"].requirements if context.get("result") else None
    template = "partials/_category_results.html" if is_htmx(request) else "web/category.html"
    return render(request, template, context)


def _variant_for(request, product: Product) -> ProductVariant:
    variants = list(product.variants.filter(status=ProductVariant.Status.ACTIVE).order_by("id"))
    if not variants:
        raise Http404("This product has no variants")
    chosen = request.GET.get("variant") or request.POST.get("variant")
    if chosen and chosen.isdigit():
        for variant in variants:
            if variant.pk == int(chosen):
                return variant
        raise Http404("Unknown variant")
    return variants[0]


def _comparison_context(request, product: Product, variant: ProductVariant) -> dict:
    error = ""
    try:
        requirements = requirements_from_request(request)
    except InvalidRequirementsError as exc:
        error = str(exc)
        requirements = Requirements()
    result = compare_variant(variant, requirements)
    return {
        "product": product, "variant": variant, "result": result, "requirements": requirements,
        "conditions": CONDITIONS, "error": error, "now": result.generated_at,
        "coupon": " ".join(requirements.coupon_codes),
    }


@require_GET
def product_detail(request, slug):
    product = get_object_or_404(Product.objects.select_related("category"), slug=slug, status=Product.Status.ACTIVE)
    variant = _variant_for(request, product)
    context = _comparison_context(request, product, variant)
    if is_htmx(request):
        _remember_memberships(request, context["requirements"])
        return render(request, "partials/_comparison.html", context)
    history = price_history(variant, condition=context["requirements"].condition)
    saved = alerts = None
    if request.user.is_authenticated:
        saved = SavedSearch.objects.filter(user=request.user, variant=variant).first()
        alerts = PriceAlert.objects.filter(user=request.user, variant=variant)
    context.update({
        "variants": product.variants.filter(status=ProductVariant.Status.ACTIVE).order_by("id"),
        "history": history, "chart": build_history_chart(history), "saved": saved, "alerts": alerts,
        "correction_kinds": CorrectionRequest.Kind.choices,
    })
    return render(request, "web/product_detail.html", context)


@require_GET
def history_csv(request, slug):
    product = get_object_or_404(Product, slug=slug, status=Product.Status.ACTIVE)
    variant = _variant_for(request, product)
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="price-history-{product.slug}-{variant.pk}.csv"'
    response["X-Content-Type-Options"] = "nosniff"
    writer = csv.writer(response)
    writer.writerow(["supplier", "listing_title", "condition", "observed_at_utc", "item_price", "currency"])
    condition = request.GET.get("condition") or "new"
    for series in price_history(variant, condition=condition):
        for observed_at, price in series.points:
            # Supplier text is untrusted: neutralise spreadsheet formulas.
            writer.writerow([
                spreadsheet_safe(series.listing.supplier.name), spreadsheet_safe(series.listing.title),
                spreadsheet_safe(series.listing.condition), observed_at.strftime("%Y-%m-%dT%H:%M:%SZ"), str(price), series.currency,
            ])
    return response


@require_GET
def outbound(request, listing_id: int):
    """Send the customer to the supplier. Only stored URLs on the supplier's own domains are allowed."""
    listing = get_object_or_404(SupplierListing.objects.select_related("supplier"), pk=listing_id)
    target = listing.url or listing.supplier.website_url
    parts = urlsplit(target)
    host = (parts.hostname or "").lower()
    allowed = {d.lower() for d in (listing.supplier.allowed_domains or [])}
    if parts.scheme not in ("http", "https") or parts.username or not any(host == d or host.endswith("." + d) for d in allowed):
        record("outbound.blocked", listing, actor=request.user, data={"host": host})
        return render(request, "web/error.html", {
            "title": "Link unavailable", "message": "We could not verify this supplier link, so we have not sent you there.",
        }, status=400)
    if not rate_limited(request, "outbound-audit", 200):
        record("outbound.click", listing, actor=request.user, data={"supplier": listing.supplier.slug})
    response = redirect(target)
    response["Referrer-Policy"] = "no-referrer"
    return response


# ------------------------------------------------------------------- lists and alerts

@login_required
@require_http_methods(["GET", "POST"])
def saved_lists(request):
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "delete":
            SavedSearch.objects.filter(user=request.user, pk=request.POST.get("id") or 0).delete()  # scoped to owner
            messages.success(request, "Removed from your list.")
        else:
            list_name = clean_text(request.POST.get("list_name") or "My list", 80)
            variant_id = request.POST.get("variant")
            try:
                requirements = requirements_from_request(request, request.POST).as_dict()
            except InvalidRequirementsError:
                requirements = Requirements().as_dict()
            if variant_id and variant_id.isdigit():
                variant = get_object_or_404(ProductVariant, pk=int(variant_id))
                SavedSearch.objects.update_or_create(
                    user=request.user, list_name=list_name, variant=variant,
                    defaults={"label": variant.display_name, "requirements": requirements},
                )
                messages.success(request, f"Saved {variant.display_name} to “{list_name}”.")
            elif clean_text(request.POST.get("query"), 200):
                query = clean_text(request.POST.get("query"), 200)
                SavedSearch.objects.create(user=request.user, list_name=list_name, label=f"Search: {query}", query=query)
                messages.success(request, "Search saved.")
            else:
                return HttpResponseBadRequest("Nothing to save")
        return redirect(request.POST.get("next") if _safe_next(request.POST.get("next")) else "web:lists")
    items = []
    for saved in SavedSearch.objects.filter(user=request.user).select_related("variant__product__category"):
        best = None
        if saved.variant:
            try:
                best = compare_variant(saved.variant, Requirements.from_dict(saved.requirements)).winner
            except InvalidRequirementsError:
                best = None
        items.append({"saved": saved, "best": best})
    return render(request, "web/lists.html", {"items": items})


def _safe_next(target: str | None) -> bool:
    """Only same-site relative paths are accepted as redirect targets."""
    return bool(target) and target.startswith("/") and not target.startswith("//") and "\\" not in target


@login_required
@require_http_methods(["GET", "POST"])
def alerts(request):
    if request.method == "POST":
        action = request.POST.get("action")
        owned = PriceAlert.objects.filter(user=request.user)  # never touch another account's alerts
        if action == "delete":
            owned.filter(pk=request.POST.get("id") or 0).delete()
            messages.success(request, "Alert deleted.")
        elif action in ("pause", "resume"):
            owned.filter(pk=request.POST.get("id") or 0).update(
                status=PriceAlert.Status.PAUSED if action == "pause" else PriceAlert.Status.ACTIVE
            )
        else:
            variant = get_object_or_404(ProductVariant, pk=request.POST.get("variant") or 0)
            try:
                target = Decimal(request.POST.get("target_total", "")).quantize(Decimal("0.01"))
                requirements = requirements_from_request(request, request.POST)
                if target <= 0 or target > Decimal("1000000"):
                    raise InvalidOperation
            except (InvalidOperation, InvalidRequirementsError):
                messages.error(request, "Enter a target total greater than zero, for example 399.00.")
            else:
                if owned.count() >= 50:
                    messages.error(request, "You have reached the limit of 50 alerts.")
                else:
                    create_alert(user=request.user, variant=variant, target_total=target, requirements=requirements)
                    messages.success(request, f"We will email you when {variant.display_name} reaches {target} {requirements.currency} in total.")
        return redirect(request.POST.get("next") if _safe_next(request.POST.get("next")) else "web:alerts")
    mine = PriceAlert.objects.filter(user=request.user).select_related("variant__product").prefetch_related("notifications")
    return render(request, "web/alerts.html", {"alerts": mine})


@require_POST
def report_correction(request):
    if rate_limited(request, "correction", 10):
        return render(request, "partials/_correction_result.html", {"ok": False, "message": "Too many reports; please try again later."}, status=429)
    description = clean_text(request.POST.get("description"), 2000)
    kind = request.POST.get("kind")
    if kind not in CorrectionRequest.Kind.values or len(description) < 10:
        return render(request, "partials/_correction_result.html",
                      {"ok": False, "message": "Choose what is wrong and describe it in at least 10 characters."}, status=400)
    listing = SupplierListing.objects.filter(pk=request.POST.get("listing") or 0).first()
    variant = ProductVariant.objects.filter(pk=request.POST.get("variant") or 0).first()
    correction = CorrectionRequest.objects.create(
        reporter=request.user if request.user.is_authenticated else None, listing=listing, variant=variant,
        kind=kind, description=description, created_at=system_clock.now(),
    )
    record("correction.reported", correction, actor=request.user, data={"kind": kind})
    return render(request, "partials/_correction_result.html", {"ok": True, "message": "Thank you. A reviewer will check this."})


# ----------------------------------------------------------------------------- basket

@require_GET
def basket(request):
    categories = list(Category.objects.filter(vertical=Category.Vertical.GROCERY).order_by("name"))
    forms = {}
    for category in categories:
        variants = ProductVariant.objects.filter(product__category=category)
        forms[category.slug] = sorted({(v.attributes or {}).get("product_form") for v in variants} - {None})
    rows = []
    items: list[BasketRequestItem] = []
    error = ""
    for category in categories:
        amount = request.GET.get(f"amount_{category.slug}", "")
        unit = request.GET.get(f"unit_{category.slug}", "")
        form = request.GET.get(f"form_{category.slug}", "")
        rows.append({"category": category, "amount": amount, "unit": unit, "form": form, "forms": forms[category.slug]})
        if not amount:
            continue
        try:
            required = Quantity(Decimal(amount), unit or "each")
        except (InvalidOperation, UnknownUnitError, ValueError, TypeError):
            error = f"Enter a positive quantity for {category.name}."
            continue
        chosen = form if form in forms[category.slug] else None
        label = f"{required} {chosen or ''} {category.name.lower()}".replace("  ", " ")
        items.append(BasketRequestItem(category.slug, label, category, required, chosen))
    result = None
    if items and not error:
        result = compare_grocery_basket(items, requirements_from_request(request))
    return render(request, "web/basket.html", {"rows": rows, "units": GROCERY_UNITS, "result": result, "error": error})


# --------------------------------------------------------------------- staff: review

@staff_member_required
@require_http_methods(["GET", "POST"])
def review(request):
    if request.method == "POST":
        note = clean_text(request.POST.get("note"), 500)
        kind = request.POST.get("kind")
        try:
            if kind == "match":
                decision = get_object_or_404(MatchDecision, pk=request.POST.get("id") or 0, is_current=True)
                review_decision(decision, reviewer=request.user, accept=request.POST.get("verdict") == "accept", note=note)
                messages.success(request, "Match decision recorded as a new version.")
            elif kind == "observation":
                observation = get_object_or_404(OfferObservation, pk=request.POST.get("id") or 0)
                review_observation(observation, reviewer=request.user, release=request.POST.get("verdict") == "release", note=note)
                messages.success(request, "Observation reviewed.")
            elif kind == "correction":
                correction = get_object_or_404(CorrectionRequest, pk=request.POST.get("id") or 0, status=CorrectionRequest.Status.OPEN)
                correction.status = (CorrectionRequest.Status.ACCEPTED if request.POST.get("verdict") == "accept"
                                     else CorrectionRequest.Status.REJECTED)
                correction.resolution_note = note
                correction.resolved_by = request.user
                correction.resolved_at = system_clock.now()
                correction.save()
                record(f"correction.{correction.status}", correction, actor=request.user, data={"note": note})
                messages.success(request, "Report resolved.")
            else:
                return HttpResponseBadRequest("Unknown review type")
        except ValueError as exc:
            messages.error(request, str(exc))
        return redirect("web:review")
    pending = (
        MatchDecision.objects.filter(is_current=True, outcome=MatchDecision.Outcome.NEEDS_REVIEW)
        .select_related("listing__supplier", "listing__latest_valid_observation", "variant__product")
        .order_by("-candidate_score")[:50]
    )
    unmatched = (
        MatchDecision.objects.filter(is_current=True, outcome=MatchDecision.Outcome.REJECTED, listing__variant__isnull=True,
                                     listing__status=SupplierListing.Status.ACTIVE)
        .select_related("listing__supplier", "listing__latest_valid_observation", "variant__product")
        .order_by("listing_id", "-candidate_score")[:50]
    )
    quarantined = (
        OfferObservation.objects.filter(status=OfferObservation.Status.QUARANTINED)
        .select_related("listing__supplier", "listing__latest_valid_observation").order_by("-observed_at")[:50]
    )
    return render(request, "web/review.html", {
        "pending": pending, "unmatched": unmatched, "quarantined": quarantined,
        "corrections": CorrectionRequest.objects.filter(status=CorrectionRequest.Status.OPEN).select_related("listing__supplier", "variant__product")[:50],
        "recent": MatchDecision.objects.filter(decided_by=MatchDecision.DecidedBy.HUMAN).select_related(
            "listing__supplier", "variant__product", "reviewer", "supersedes")[:10],
    })


@staff_member_required
@require_http_methods(["GET", "POST"])
def operations(request):
    if request.method == "POST":
        source = get_object_or_404(SourceConfiguration, pk=request.POST.get("source") or 0)
        if source.kind == SourceConfiguration.Kind.MANUAL:
            messages.error(request, "Manual sources are submitted by suppliers and cannot be collected.")
        else:
            collect_source.delay(source.pk, CollectionRun.Trigger.MANUAL)
            record("collection.requested", source, actor=request.user)
            messages.success(request, f"Collection queued for {source.name}.")
        return redirect("web:operations")
    return render(request, "web/operations.html", {
        "sources": SourceConfiguration.objects.select_related("supplier").annotate(listing_count=Count("listings")),
        "runs": CollectionRun.objects.select_related("source_configuration__supplier")[:30],
        "events": AuditEvent.objects.all()[:20],
        "now": system_clock.now(),
    })


# ---------------------------------------------------------------------------- account

@require_http_methods(["GET", "POST"])
def signup(request):
    form = CustomerSignupForm(request.POST or None)
    if request.method == "POST":
        if rate_limited(request, "signup", 10):
            return render(request, "web/error.html", {"title": "Slow down", "message": "Too many sign-up attempts."}, status=429)
        if form.is_valid():
            login(request, form.save())
            return redirect("web:home")
    return render(request, "registration/signup.html", {"form": form})


def not_found(request, exception=None):
    return render(request, "web/error.html", {"title": "Page not found", "message": "We could not find that page."}, status=404)


def server_error(request):
    return render(request, "web/error.html", {"title": "Something went wrong", "message": "Please try again shortly."}, status=500)
