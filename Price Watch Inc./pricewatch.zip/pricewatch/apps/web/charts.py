"""Server-side geometry for the price-history chart (rendered as inline SVG).

Form: change over time -> line chart, one line per supplier, one y-axis.
Markers sit at the moments we *checked*; the connecting line is only a guide.
Colours are a validated categorical palette assigned in fixed order by supplier
(never by rank), with a legend, end-of-line labels and a table view so identity
never depends on colour alone.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal
from typing import Sequence

# Reference categorical palette, light surface. Validated with the dataviz validator:
# adjacent CVD dE >= 9.1, normal-vision dE >= 19.6; three slots are below 3:1 contrast on
# white, which is why direct labels and the table view always accompany the chart.
SERIES_COLOURS = ("#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300")
MAX_SERIES = len(SERIES_COLOURS)

WIDTH, HEIGHT = 760, 300
LEFT, RIGHT, TOP, BOTTOM = 56, 150, 16, 34


def _nice_step(span: Decimal, target: int = 4) -> Decimal:
    raw = span / target if span > 0 else Decimal(1)
    magnitude = Decimal(10) ** (raw.adjusted())
    for multiple in (1, 2, 5, 10):
        if raw <= magnitude * multiple:
            return magnitude * multiple
    return magnitude * 10


def build_history_chart(series: Sequence, currency_symbol: str = "£") -> dict | None:
    """``series`` is a list of ``HistorySeries``. Returns template-ready geometry, or None."""
    series = [s for s in series if s.points][:MAX_SERIES]
    if not series:
        return None
    times = [t for s in series for t, _ in s.points]
    prices = [p for s in series for _, p in s.points]
    t0, t1 = min(times), max(times)
    if t0 == t1:
        t0, t1 = t0 - timedelta(hours=12), t1 + timedelta(hours=12)
    low, high = min(prices), max(prices)
    step = _nice_step(high - low if high > low else max(high * Decimal("0.05"), Decimal(1)))
    y0 = (low / step).to_integral_value(rounding="ROUND_FLOOR") * step
    y1 = (high / step).to_integral_value(rounding="ROUND_CEILING") * step
    if y0 == y1:
        y0, y1 = y0 - step, y1 + step
    plot_w, plot_h = WIDTH - LEFT - RIGHT, HEIGHT - TOP - BOTTOM
    span_seconds = (t1 - t0).total_seconds()

    def x(moment: datetime) -> float:
        return round(LEFT + plot_w * ((moment - t0).total_seconds() / span_seconds), 1)

    def y(price: Decimal) -> float:
        return round(TOP + plot_h * float((y1 - price) / (y1 - y0)), 1)

    ticks = []
    value = y0
    while value <= y1:
        ticks.append({"y": y(value), "label_y": round(y(value) + 4, 1), "label": f"{currency_symbol}{value:,.0f}" if step >= 1 else f"{currency_symbol}{value:,.2f}"})
        value += step
    multi_day = (t1 - t0) > timedelta(days=2)
    x_ticks = []
    for index in range(5):
        moment = t0 + (t1 - t0) * index / 4
        x_ticks.append({"x": x(moment), "label": moment.strftime("%d %b") if multi_day else moment.strftime("%d %b %H:%M")})

    out = []
    label_slots: list[float] = []
    for index, item in enumerate(series):
        points = [{"x": x(t), "y": y(p), "time": t, "price": p} for t, p in item.points]
        last = points[-1]
        label_y = last["y"]
        # nudge end labels apart so they never overlap
        while any(abs(label_y - used) < 14 for used in label_slots):
            label_y += 14
        label_slots.append(label_y)
        out.append({
            "name": item.listing.supplier.name,
            "colour": SERIES_COLOURS[index],
            "polyline": " ".join(f"{p['x']},{p['y']}" for p in points),
            "points": points,
            "label_x": WIDTH - RIGHT + 10,
            "label_y": round(min(label_y, HEIGHT - BOTTOM) + 4, 1),
            "last_price": last["price"],
            "show_label": len(series) <= 4,
        })
    return {
        "width": WIDTH, "height": HEIGHT, "left": LEFT, "right": WIDTH - RIGHT, "top": TOP, "bottom": HEIGHT - BOTTOM,
        "axis_x": LEFT - 8, "axis_y": HEIGHT - BOTTOM + 20, "ticks": ticks, "x_ticks": x_ticks, "series": out, "single": len(out) == 1,
        "start": t0, "end": t1, "symbol": currency_symbol,
    }
