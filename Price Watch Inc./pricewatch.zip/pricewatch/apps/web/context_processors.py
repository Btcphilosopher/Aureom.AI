from django.conf import settings


def site(request):
    return {"site_name": "Price Watch", "default_currency": settings.PRICEWATCH["DEFAULT_CURRENCY"]}
