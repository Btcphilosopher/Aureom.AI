"""Quantities, unit conversion with explicit dimensional checks, and pack maths.

Pure functions, ``Decimal`` only. Converting between dimensions (for example
grams to millilitres) raises :class:`IncompatibleUnitsError`; nothing is ever
guessed from a product's density.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import ROUND_CEILING, ROUND_HALF_UP, Decimal
from enum import StrEnum


class IncompatibleUnitsError(ValueError):
    """Raised when two quantities do not share a dimension."""


class UnknownUnitError(ValueError):
    """Raised when a unit string is not recognised."""


class Dimension(StrEnum):
    MASS = "mass"
    VOLUME = "volume"
    COUNT = "count"
    LENGTH = "length"


# unit -> (dimension, factor to the base unit: g, ml, each, mm)
_UNITS: dict[str, tuple[Dimension, Decimal]] = {
    "mg": (Dimension.MASS, Decimal("0.001")),
    "g": (Dimension.MASS, Decimal("1")),
    "kg": (Dimension.MASS, Decimal("1000")),
    "oz": (Dimension.MASS, Decimal("28.349523125")),
    "lb": (Dimension.MASS, Decimal("453.59237")),
    "ml": (Dimension.VOLUME, Decimal("1")),
    "cl": (Dimension.VOLUME, Decimal("10")),
    "l": (Dimension.VOLUME, Decimal("1000")),
    "floz": (Dimension.VOLUME, Decimal("28.4130625")),  # UK fluid ounce
    "pt": (Dimension.VOLUME, Decimal("568.26125")),  # UK pint
    "each": (Dimension.COUNT, Decimal("1")),
    "mm": (Dimension.LENGTH, Decimal("1")),
    "cm": (Dimension.LENGTH, Decimal("10")),
    "m": (Dimension.LENGTH, Decimal("1000")),
}

_ALIASES = {
    "gram": "g", "grams": "g", "gr": "g", "kilo": "kg", "kilos": "kg", "kilogram": "kg", "kilograms": "kg",
    "kgs": "kg", "ounce": "oz", "ounces": "oz", "lbs": "lb", "pound": "lb", "pounds": "lb",
    "millilitre": "ml", "millilitres": "ml", "milliliter": "ml", "milliliters": "ml", "mls": "ml",
    "centilitre": "cl", "centilitres": "cl", "litre": "l", "litres": "l", "liter": "l", "liters": "l",
    "ltr": "l", "ltrs": "l", "lt": "l", "pint": "pt", "pints": "pt", "pts": "pt", "fl oz": "floz",
    "fl. oz": "floz", "fl.oz": "floz", "ea": "each", "unit": "each", "units": "each", "pack": "each",
    "packs": "each", "pk": "each", "pc": "each", "pcs": "each", "piece": "each", "pieces": "each",
    "count": "each", "ct": "each", "item": "each", "items": "each", "metre": "m", "metres": "m",
    "meter": "m", "meters": "m",
}


def canonical_unit(unit: str) -> str:
    key = re.sub(r"\s+", " ", unit.strip().lower().rstrip("."))
    key = _ALIASES.get(key, key)
    if key not in _UNITS:
        raise UnknownUnitError(f"Unknown unit: {unit!r}")
    return key


@dataclass(frozen=True)
class Quantity:
    value: Decimal
    unit: str

    def __post_init__(self) -> None:
        if isinstance(self.value, float):
            raise TypeError("Quantity values must be Decimal or int, not float")
        object.__setattr__(self, "value", Decimal(self.value))
        object.__setattr__(self, "unit", canonical_unit(self.unit))
        if self.value <= 0:
            raise ValueError("Quantity must be positive")

    @property
    def dimension(self) -> Dimension:
        return _UNITS[self.unit][0]

    @property
    def base_value(self) -> Decimal:
        """Value in the dimension's base unit (g, ml, each, mm)."""
        return self.value * _UNITS[self.unit][1]

    def to(self, unit: str) -> "Quantity":
        target = canonical_unit(unit)
        dimension, factor = _UNITS[target]
        if dimension is not self.dimension:
            raise IncompatibleUnitsError(
                f"Cannot convert {self.unit} ({self.dimension}) to {target} ({dimension})"
            )
        return Quantity(self.base_value / factor, target)

    def times(self, count: int) -> "Quantity":
        return Quantity(self.value * count, self.unit)

    def __str__(self) -> str:
        return f"{format_decimal(self.value)} {self.unit}" if self.unit != "each" else format_decimal(self.value)


EACH = Quantity(Decimal(1), "each")


def format_decimal(value: Decimal) -> str:
    text = format(value.normalize(), "f")
    return text if "." not in text else text.rstrip("0").rstrip(".")


def require_same_dimension(a: Quantity, b: Quantity) -> None:
    if a.dimension is not b.dimension:
        raise IncompatibleUnitsError(
            f"Quantities are not comparable: {a.unit} is {a.dimension}, {b.unit} is {b.dimension}"
        )


def packs_required(required: Quantity, per_pack: Quantity) -> int:
    """``ceiling(required_quantity / quantity_per_pack)`` with a dimensional check."""
    require_same_dimension(required, per_pack)
    ratio = required.base_value / per_pack.base_value
    return int(ratio.to_integral_value(rounding=ROUND_CEILING))


def surplus(required: Quantity, per_pack: Quantity, packs: int) -> Decimal:
    """Purchased minus required, expressed in the pack's unit (never negative)."""
    require_same_dimension(required, per_pack)
    return per_pack.value * packs - required.to(per_pack.unit).value


def unit_price(total: Decimal, purchased: Quantity, basis: Quantity) -> Decimal:
    """Price per ``basis`` (e.g. per 100 g), to four decimal places."""
    require_same_dimension(purchased, basis)
    return (total / (purchased.base_value / basis.base_value)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)


DEFAULT_BASIS = {
    Dimension.MASS: Quantity(Decimal(100), "g"),
    Dimension.VOLUME: Quantity(Decimal(100), "ml"),
    Dimension.COUNT: EACH,
    Dimension.LENGTH: Quantity(Decimal(1), "m"),
}


@dataclass(frozen=True)
class PackDescription:
    """``pack_count`` items of ``item`` each, e.g. 6 x 330 ml."""

    pack_count: int
    item: Quantity

    @property
    def total(self) -> Quantity:
        return self.item.times(self.pack_count)


_NUMBER = r"(\d+(?:[.,]\d+)?)"
_UNIT = r"(fl\.?\s?oz|[a-zA-Z]+)"
_MULTI = re.compile(rf"(\d+)\s*(?:x|×|\*)\s*{_NUMBER}\s*{_UNIT}", re.I)
_SINGLE = re.compile(rf"(?<![\w.]){_NUMBER}\s*{_UNIT}\b", re.I)


def _number(text: str) -> Decimal:
    return Decimal(text.replace(",", "."))


def parse_pack(text: str | None) -> PackDescription | None:
    """Parse '6 x 330ml', '500 g', '1.5kg', '4 pints', '12 pack'. ``None`` if not understood."""
    if not text:
        return None
    multi = _MULTI.search(text)
    try:
        if multi:
            count = int(multi.group(1))
            if count < 1:
                return None
            return PackDescription(count, Quantity(_number(multi.group(2)), multi.group(3)))
        for single in _SINGLE.finditer(text):
            try:
                quantity = Quantity(_number(single.group(1)), single.group(2))
            except UnknownUnitError:
                continue
            if quantity.dimension is Dimension.COUNT:
                if quantity.value != quantity.value.to_integral_value():
                    return None
                return PackDescription(int(quantity.value), EACH)
            return PackDescription(1, quantity)
    except (UnknownUnitError, ValueError, ArithmeticError):
        return None
    return None
