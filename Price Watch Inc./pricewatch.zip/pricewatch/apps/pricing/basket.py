"""Basket comparison.

Model and constraints (documented because they bound what "cheapest" means):

* Each basket item is bought from exactly one supplier, as whole packs of a single
  listing (pack sizes are not mixed within an item).
* Only lines with a complete goods cost that the customer is known to be eligible for
  are candidates. Conditional lines are reported, never silently used.
* Delivery is charged once per supplier order; free-delivery thresholds and minimum
  orders are tested against that supplier's goods total, not the whole basket.
* Promotions are evaluated per line.

Three strategies are reported:

``single_supplier``   every item from one supplier.
``baseline_split``    a transparent *heuristic*: cheapest goods price per item, then
                      delivery added per supplier. It can be beaten, and is labelled so.
``exhaustive_split``  every item→supplier assignment is enumerated. Exact *for this
                      model*, and only run when the number of assignments is at most
                      ``max_combinations``. Validated in tests against hand-worked
                      examples and against the heuristic.
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field, replace
from decimal import Decimal
from typing import Iterable, Mapping, Sequence

from .engine import DefaultPricingEngine, delivery_amount
from .types import (
    Charge,
    ComparisonContext,
    ComponentStatus,
    CurrencyMismatchError,
    Offer,
    PriceBreakdown,
    TaxTreatment,
    quantize_money,
)
from .units import IncompatibleUnitsError, Quantity

ZERO = Decimal("0")
DEFAULT_MAX_COMBINATIONS = 20_000


@dataclass(frozen=True)
class BasketItem:
    key: str
    label: str
    required: Quantity


@dataclass(frozen=True)
class BasketLine:
    item: BasketItem
    offer: Offer
    breakdown: PriceBreakdown  # goods only (no delivery)

    @property
    def goods_total(self) -> Decimal:
        assert self.breakdown.total is not None
        return self.breakdown.total


@dataclass(frozen=True)
class SupplierOrder:
    supplier_key: str
    supplier_name: str
    lines: tuple[BasketLine, ...]
    goods_total: Decimal
    delivery: Decimal | None
    delivery_note: str
    total: Decimal | None
    problems: tuple[str, ...] = ()

    @property
    def complete(self) -> bool:
        return self.total is not None and not self.problems


@dataclass(frozen=True)
class BasketPlan:
    strategy: str
    method_note: str
    orders: tuple[SupplierOrder, ...]
    missing_items: tuple[BasketItem, ...]
    total: Decimal | None
    currency: str
    combinations_evaluated: int | None = None

    @property
    def complete(self) -> bool:
        return self.total is not None and not self.missing_items and all(o.complete for o in self.orders)

    @property
    def supplier_count(self) -> int:
        return len(self.orders)

    @property
    def delivery_count(self) -> int:
        return len(self.orders)

    @property
    def delivery_total(self) -> Decimal | None:
        if any(o.delivery is None for o in self.orders):
            return None
        return sum((o.delivery for o in self.orders), ZERO)


@dataclass(frozen=True)
class BasketComparison:
    items: tuple[BasketItem, ...]
    single_supplier: tuple[BasketPlan, ...]  # complete plans first, cheapest first
    baseline_split: BasketPlan | None
    exhaustive_split: BasketPlan | None
    conditional_notes: tuple[str, ...]
    assumptions: tuple[str, ...]
    excluded: tuple[str, ...] = field(default_factory=tuple)

    @property
    def best_single_supplier(self) -> BasketPlan | None:
        return next((plan for plan in self.single_supplier if plan.complete), None)


ASSUMPTIONS = (
    "Each item is bought as whole packs of one listing from one supplier.",
    "Delivery is counted once per supplier order; thresholds use that supplier's goods total.",
    "Only complete prices you are known to be eligible for are used; conditional offers are listed separately.",
    "Discounts are evaluated per item line.",
)


def _supplier_delivery(lines: Sequence[BasketLine]) -> tuple[Charge, Offer]:
    """A supplier's delivery terms for an order.

    Offers from one supplier normally share terms. If they differ we take the
    least favourable (unknown beats known; otherwise the highest charge and the
    highest free threshold) so the basket total is never understated.
    """
    def rank(line: BasketLine) -> tuple:
        charge = line.offer.delivery
        unknown = charge.status is ComponentStatus.UNKNOWN
        return (unknown, charge.amount or ZERO, charge.free_threshold or Decimal("Infinity") if charge.amount else ZERO)

    worst = max(lines, key=rank)
    return worst.offer.delivery, worst.offer


def price_supplier_order(lines: Sequence[BasketLine], currency: str) -> SupplierOrder:
    first = lines[0].offer
    goods_total = sum((line.goods_total for line in lines), ZERO)
    charge, terms_offer = _supplier_delivery(lines)
    delivery, note = delivery_amount(charge, goods_total)
    problems: list[str] = []
    minimum = max((l.offer.minimum_order_amount for l in lines if l.offer.minimum_order_amount is not None), default=None)
    if minimum is not None and goods_total < minimum:
        problems.append(f"Minimum order of {minimum} {currency} not met (goods {goods_total}).")
    total: Decimal | None = None
    if delivery is not None:
        delivery = quantize_money(delivery, currency)
        delivery_tax = ZERO
        if terms_offer.tax_treatment is TaxTreatment.EXCLUDED and terms_offer.tax_rate is not None:
            delivery_tax = quantize_money(delivery * terms_offer.tax_rate, currency)
            if delivery_tax:
                note = (note + "; " if note else "") + f"includes {delivery_tax} tax on delivery"
        delivery += delivery_tax
        total = goods_total + delivery
    return SupplierOrder(
        supplier_key=first.supplier_key,
        supplier_name=first.supplier_name,
        lines=tuple(lines),
        goods_total=goods_total,
        delivery=delivery,
        delivery_note=note,
        total=total,
        problems=tuple(problems),
    )


def _plan(strategy: str, note: str, assignment: Mapping[str, BasketLine], items: Sequence[BasketItem],
          currency: str, combinations: int | None = None) -> BasketPlan:
    by_supplier: dict[str, list[BasketLine]] = {}
    for item in items:
        line = assignment.get(item.key)
        if line is not None:
            by_supplier.setdefault(line.offer.supplier_key, []).append(line)
    orders = tuple(price_supplier_order(lines, currency) for _, lines in sorted(by_supplier.items()))
    missing = tuple(item for item in items if item.key not in assignment)
    total = None
    if orders and all(order.total is not None for order in orders):
        total = sum((order.total for order in orders), ZERO)
    return BasketPlan(strategy, note, orders, missing, total, currency, combinations)


def compare_basket(
    items: Sequence[BasketItem],
    candidates: Mapping[str, Iterable[Offer]],
    context: ComparisonContext,
    engine: DefaultPricingEngine | None = None,
    max_combinations: int = DEFAULT_MAX_COMBINATIONS,
) -> BasketComparison:
    """Compare single-supplier and split baskets.

    ``candidates`` maps each item key to the offers that satisfy that item's
    requirements (matching has already happened).
    """
    engine = engine or DefaultPricingEngine()
    conditional_notes: list[str] = []
    excluded: list[str] = []
    # best[item_key][supplier_key] -> cheapest usable line for that item at that supplier
    best: dict[str, dict[str, BasketLine]] = {item.key: {} for item in items}

    for item in items:
        item_context = replace(context, required_quantity=item.required)
        for offer in candidates.get(item.key, ()):
            try:
                breakdown = engine.goods_only(offer, item_context)
            except (CurrencyMismatchError, IncompatibleUnitsError) as exc:
                excluded.append(f"{item.label} at {offer.supplier_name}: {exc}")
                continue
            for discount in breakdown.conditional_discounts:
                conditional_notes.append(
                    f"{item.label} at {offer.supplier_name}: {discount.label} could save "
                    f"{discount.potential_saving} {offer.currency}. {discount.condition}"
                )
            if not breakdown.is_rankable:
                reason = "; ".join(breakdown.conditions + breakdown.missing) or "not eligible"
                excluded.append(f"{item.label} at {offer.supplier_name}: {reason}")
                continue
            line = BasketLine(item, offer, breakdown)
            current = best[item.key].get(offer.supplier_key)
            if current is None or (line.goods_total, offer.offer_id) < (current.goods_total, current.offer.offer_id):
                best[item.key][offer.supplier_key] = line

    suppliers = sorted({key for lines in best.values() for key in lines})

    single: list[BasketPlan] = []
    for supplier in suppliers:
        assignment = {item.key: best[item.key][supplier] for item in items if supplier in best[item.key]}
        single.append(_plan("single_supplier", "Every item from one supplier.", assignment, items, context.currency))
    single.sort(key=lambda p: (not p.complete, len(p.missing_items), p.total if p.total is not None else Decimal("Infinity"),
                               p.orders[0].supplier_key if p.orders else ""))

    baseline = None
    exhaustive = None
    if suppliers:
        greedy = {
            item.key: min(best[item.key].values(), key=lambda l: (l.goods_total, l.offer.supplier_key))
            for item in items if best[item.key]
        }
        baseline = _plan(
            "baseline_split",
            "Baseline heuristic: the cheapest goods price for each item, with delivery then added once per "
            "supplier. This is a comparison baseline, not a guaranteed lowest total.",
            greedy, items, context.currency,
        )

        available = [item for item in items if best[item.key]]
        combinations = 1
        for item in available:
            combinations *= len(best[item.key])
        if available and combinations <= max_combinations:
            best_plan: BasketPlan | None = None
            option_lists = [sorted(best[item.key].values(), key=lambda l: l.offer.supplier_key) for item in available]
            for combo in itertools.product(*option_lists):
                assignment = {line.item.key: line for line in combo}
                plan = _plan("exhaustive_split", "", assignment, items, context.currency, combinations)
                if plan.total is None or any(order.problems for order in plan.orders):
                    continue
                key = (plan.total, plan.supplier_count)
                if best_plan is None or key < (best_plan.total, best_plan.supplier_count):
                    best_plan = plan
            if best_plan is not None:
                exhaustive = replace(
                    best_plan,
                    method_note=(
                        f"Lowest total among all {combinations} ways of assigning these items to suppliers "
                        "(exact for the stated assumptions; ties prefer fewer deliveries)."
                    ),
                )

    return BasketComparison(
        items=tuple(items),
        single_supplier=tuple(single),
        baseline_split=baseline,
        exhaustive_split=exhaustive,
        conditional_notes=tuple(dict.fromkeys(conditional_notes)),
        assumptions=ASSUMPTIONS,
        excluded=tuple(dict.fromkeys(excluded)),
    )
