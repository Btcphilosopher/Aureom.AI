"""Comparable payable total.

    eligible item subtotal
    + mandatory fees
    + applicable delivery
    + applicable tax not already included
    - eligible discounts
    = comparable payable total

Rules that keep the result honest:

* Tax is added only when the price is declared tax-exclusive *and* the rate is known.
  Tax-inclusive prices are never taxed again.
* A mandatory charge with unknown status makes the total incomplete (``total is None``).
* Membership-only offers are eligible only when the customer says they hold the
  membership; unknown membership makes the offer conditional, never the confirmed cheapest.
* Coupons apply only when the customer explicitly supplies the code.
* At most one promotion is applied (the largest eligible saving); stacking is not assumed.
"""
from __future__ import annotations

from dataclasses import replace
from decimal import Decimal

from .types import (
    BreakdownLine,
    Charge,
    ComparisonContext,
    Completeness,
    ComponentStatus,
    ConditionalDiscount,
    CurrencyMismatchError,
    Eligibility,
    MembershipState,
    Offer,
    PriceBreakdown,
    PromotionTerms,
    TaxTreatment,
    quantize_money,
)
from .units import packs_required, surplus

ZERO = Decimal("0")


def tier_price(offer: Offer, packs: int) -> Decimal:
    """Per-pack price after simple quantity tiers."""
    price = offer.unit_price
    best_min = 0
    for tier in offer.tiers:
        if tier.min_packs <= packs and tier.min_packs > best_min:
            price, best_min = tier.unit_price, tier.min_packs
    return price


def delivery_amount(charge: Charge, goods_total: Decimal) -> tuple[Decimal | None, str]:
    """Delivery payable for an order of ``goods_total``. ``None`` means unknown."""
    if charge.status in (ComponentStatus.INCLUDED, ComponentStatus.NOT_APPLICABLE):
        return ZERO, "Delivery included in price" if charge.status is ComponentStatus.INCLUDED else "No delivery charge applies"
    if charge.status is ComponentStatus.UNKNOWN or charge.amount is None:
        return None, charge.note or "Delivery cost not stated by supplier"
    if charge.free_threshold is not None and goods_total >= charge.free_threshold:
        return ZERO, f"Free delivery: order reaches the {charge.free_threshold} threshold"
    if charge.free_threshold is not None:
        return charge.amount, f"Order is below the {charge.free_threshold} free-delivery threshold"
    return charge.amount, charge.note


def _promotion_active(promotion: PromotionTerms, context: ComparisonContext) -> bool:
    if promotion.starts_at is not None and context.now < promotion.starts_at:
        return False
    if promotion.ends_at is not None and context.now >= promotion.ends_at:
        return False
    return True


def _promotion_saving(promotion: PromotionTerms, base: Decimal, currency: str) -> Decimal:
    if promotion.discount_type == "percent":
        saving = quantize_money(base * promotion.value / Decimal(100), currency)
    else:
        saving = quantize_money(promotion.value, currency)
    return min(saving, base)


class DefaultPricingEngine:
    """Deterministic implementation of :class:`apps.pricing.types.PricingEngine`."""

    def calculate(self, offer: Offer, context: ComparisonContext) -> PriceBreakdown:
        if offer.currency != context.currency:
            raise CurrencyMismatchError(
                f"Offer is priced in {offer.currency}; comparison currency is {context.currency}. "
                "No currency conversion is applied."
            )
        currency = offer.currency
        packs = packs_required(context.required_quantity, offer.pack_size)
        purchased = offer.pack_size.times(packs)
        surplus_quantity = surplus(context.required_quantity, offer.pack_size, packs)

        lines: list[BreakdownLine] = []
        missing: list[str] = []
        conditions: list[str] = []
        assumptions: list[str] = []
        conditional_discounts: list[ConditionalDiscount] = []
        eligibility = Eligibility.ELIGIBLE

        # --- items ----------------------------------------------------------
        applied_price = tier_price(offer, packs)
        item_subtotal = quantize_money(applied_price * packs, currency)
        note = f"{packs} × {quantize_money(applied_price, currency)}"
        if applied_price != offer.unit_price:
            note += f" (quantity price; single price {quantize_money(offer.unit_price, currency)})"
        lines.append(BreakdownLine("item", "Items", item_subtotal, ComponentStatus.ADDITIONAL, note))

        # --- membership needed to buy at all ---------------------------------
        if offer.membership_required:
            state = context.membership_state(offer.membership_required)
            if state is MembershipState.HELD:
                assumptions.append(f"You told us you hold {offer.membership_required} membership.")
            elif state is MembershipState.NOT_HELD:
                eligibility = Eligibility.INELIGIBLE
                conditions.append(f"Requires {offer.membership_required} membership, which you do not hold.")
            else:
                eligibility = Eligibility.CONDITIONAL
                conditions.append(
                    f"Requires {offer.membership_required} membership; we do not know whether you hold it."
                )

        # --- discounts ------------------------------------------------------
        applicable: list[tuple[Decimal, PromotionTerms]] = []
        for promotion in offer.promotions:
            if not _promotion_active(promotion, context):
                continue
            saving = _promotion_saving(promotion, item_subtotal, currency)
            if promotion.min_spend is not None and item_subtotal < promotion.min_spend:
                conditional_discounts.append(
                    ConditionalDiscount(promotion.label, saving, f"Requires a minimum spend of {promotion.min_spend}; not applied.")
                )
                continue
            if promotion.membership_programme:
                state = context.membership_state(promotion.membership_programme)
                if state is MembershipState.NOT_HELD:
                    continue
                if state is MembershipState.UNKNOWN:
                    conditional_discounts.append(
                        ConditionalDiscount(
                            promotion.label, saving,
                            f"Only for {promotion.membership_programme} members; not applied because membership is unknown.",
                        )
                    )
                    continue
            if promotion.code and promotion.code not in context.coupon_codes:
                conditional_discounts.append(
                    ConditionalDiscount(promotion.label, saving, f"Needs code {promotion.code}; not applied unless you add it.")
                )
                continue
            applicable.append((saving, promotion))

        discount_total = ZERO
        if applicable:
            applicable.sort(key=lambda pair: pair[0], reverse=True)
            saving, promotion = applicable[0]
            discount_total = saving
            lines.append(BreakdownLine("discount", promotion.label, -saving, ComponentStatus.ADDITIONAL))
            if len(applicable) > 1:
                assumptions.append("Several discounts qualify; only the largest is applied because stacking is not confirmed.")
        goods_total = item_subtotal - discount_total

        # --- minimum order --------------------------------------------------
        if offer.minimum_order_amount is not None and goods_total < offer.minimum_order_amount:
            eligibility = Eligibility.INELIGIBLE
            conditions.append(
                f"Minimum order of {offer.minimum_order_amount} {currency} not met (goods {goods_total})."
            )

        # --- mandatory fees -------------------------------------------------
        fees_total: Decimal | None = ZERO
        for fee in offer.fees:
            if fee.status is ComponentStatus.NOT_APPLICABLE or not fee.mandatory:
                continue
            if fee.status is ComponentStatus.INCLUDED:
                lines.append(BreakdownLine("fee", fee.label, quantize_money(ZERO, currency), fee.status, "Included in the item price"))
            elif fee.status is ComponentStatus.ADDITIONAL:
                amount = quantize_money(fee.amount or ZERO, currency)
                lines.append(BreakdownLine("fee", fee.label, amount, fee.status, fee.note))
                if fees_total is not None:
                    fees_total += amount
            else:
                lines.append(BreakdownLine("fee", fee.label, None, fee.status, fee.note or "Amount not stated"))
                missing.append(f"Mandatory fee unknown: {fee.label}")
                fees_total = None

        # --- delivery -------------------------------------------------------
        delivery_total: Decimal | None = ZERO
        if context.include_delivery:
            delivery_total, delivery_note = delivery_amount(offer.delivery, goods_total)
            if delivery_total is None:
                missing.append("Delivery cost unknown")
                lines.append(BreakdownLine("delivery", "Delivery", None, ComponentStatus.UNKNOWN, delivery_note))
            else:
                delivery_total = quantize_money(delivery_total, currency)
                lines.append(BreakdownLine("delivery", "Delivery", delivery_total, offer.delivery.status, delivery_note))
        else:
            assumptions.append("Delivery is calculated once per supplier order, not per item.")

        # --- tax ------------------------------------------------------------
        tax_total: Decimal | None = ZERO
        if offer.tax_treatment is TaxTreatment.INCLUDED:
            lines.append(BreakdownLine("tax", "Tax", quantize_money(ZERO, currency), ComponentStatus.INCLUDED, "Prices include tax; not added again"))
        elif offer.tax_treatment is TaxTreatment.NOT_APPLICABLE:
            pass
        elif offer.tax_treatment is TaxTreatment.EXCLUDED:
            if offer.tax_rate is None:
                tax_total = None
                missing.append("Tax is extra but the rate is unknown")
                lines.append(BreakdownLine("tax", "Tax", None, ComponentStatus.UNKNOWN, "Price excludes tax; rate not stated"))
            elif fees_total is None or delivery_total is None:
                tax_total = None
                lines.append(BreakdownLine("tax", "Tax", None, ComponentStatus.UNKNOWN, "Depends on unknown charges"))
            else:
                tax_total = quantize_money((goods_total + fees_total + delivery_total) * offer.tax_rate, currency)
                lines.append(
                    BreakdownLine("tax", "Tax", tax_total, ComponentStatus.ADDITIONAL,
                                  f"{(offer.tax_rate * 100).normalize():f}% on goods, fees and delivery")
                )
                assumptions.append("Tax-exclusive supplier: tax applied to goods, mandatory fees and delivery.")
        else:
            tax_total = None
            missing.append("Tax treatment unknown (price may or may not include tax)")
            lines.append(BreakdownLine("tax", "Tax", None, ComponentStatus.UNKNOWN, "Supplier does not say whether tax is included"))

        known_subtotal = goods_total + (fees_total or ZERO) + (delivery_total or ZERO) + (tax_total or ZERO)
        known_subtotal = quantize_money(known_subtotal, currency)
        complete = not missing
        return PriceBreakdown(
            offer_id=offer.offer_id,
            currency=currency,
            lines=tuple(lines),
            packs=packs,
            purchased_quantity=purchased,
            surplus_quantity=surplus_quantity,
            unit_price_applied=applied_price,
            item_subtotal=item_subtotal,
            discount_total=discount_total,
            fees_total=fees_total,
            delivery_total=delivery_total,
            tax_total=tax_total,
            total=known_subtotal if complete else None,
            known_subtotal=known_subtotal,
            completeness=Completeness.COMPLETE if complete else Completeness.INCOMPLETE,
            eligibility=eligibility,
            missing=tuple(missing),
            conditions=tuple(conditions),
            conditional_discounts=tuple(conditional_discounts),
            assumptions=tuple(assumptions),
        )

    def goods_only(self, offer: Offer, context: ComparisonContext) -> PriceBreakdown:
        """Goods, fees and tax for one basket line; delivery is added per supplier order."""
        return self.calculate(offer, replace(context, include_delivery=False))
