"""Typed value objects for pricing. No Django imports; no I/O; ``Decimal`` only."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal
from enum import StrEnum
from typing import Mapping, Protocol

from .units import EACH, Quantity


class PricingError(Exception):
    """Base class for pricing failures that make an offer impossible to calculate."""


class CurrencyMismatchError(PricingError):
    """The offer is not priced in the comparison currency. No FX conversion is ever applied."""


class InvalidOfferError(PricingError):
    """The offer violates an invariant (non-positive price, float money, negative charge)."""


class ComponentStatus(StrEnum):
    INCLUDED = "included"  # already inside the item price; adds nothing
    ADDITIONAL = "additional"  # charged on top; amount must be known
    UNKNOWN = "unknown"  # we do not know whether/what is charged
    NOT_APPLICABLE = "not_applicable"


class TaxTreatment(StrEnum):
    INCLUDED = "included"
    EXCLUDED = "excluded"
    UNKNOWN = "unknown"
    NOT_APPLICABLE = "not_applicable"


class Completeness(StrEnum):
    COMPLETE = "complete"
    INCOMPLETE = "incomplete"


class Eligibility(StrEnum):
    ELIGIBLE = "eligible"
    CONDITIONAL = "conditional"  # depends on something we do not know (e.g. membership)
    INELIGIBLE = "ineligible"


class MembershipState(StrEnum):
    HELD = "held"
    NOT_HELD = "not_held"
    UNKNOWN = "unknown"


_EXPONENTS = {"JPY": 0, "KRW": 0, "BHD": 3, "KWD": 3}


def quantize_money(amount: Decimal, currency: str = "GBP") -> Decimal:
    exponent = Decimal(1).scaleb(-_EXPONENTS.get(currency, 2))
    return amount.quantize(exponent, rounding=ROUND_HALF_UP)


def _require_decimal(name: str, value: object, allow_none: bool = True) -> None:
    if value is None and allow_none:
        return
    if isinstance(value, bool) or not isinstance(value, Decimal):
        raise InvalidOfferError(f"{name} must be a Decimal, got {type(value).__name__}")
    if not value.is_finite():
        raise InvalidOfferError(f"{name} must be finite")


@dataclass(frozen=True)
class Money:
    amount: Decimal
    currency: str

    def __post_init__(self) -> None:
        _require_decimal("amount", self.amount, allow_none=False)
        if len(self.currency) != 3 or not self.currency.isupper():
            raise InvalidOfferError(f"Invalid currency code: {self.currency!r}")

    def __str__(self) -> str:
        return f"{self.currency} {quantize_money(self.amount, self.currency)}"


@dataclass(frozen=True)
class Charge:
    """A fee or delivery charge and how it relates to the item price."""

    label: str
    status: ComponentStatus
    amount: Decimal | None = None
    mandatory: bool = True
    free_threshold: Decimal | None = None  # goods value at/above which the charge is waived
    note: str = ""

    def __post_init__(self) -> None:
        _require_decimal(f"charge {self.label!r}", self.amount)
        _require_decimal("free_threshold", self.free_threshold)
        if self.amount is not None and self.amount < 0:
            raise InvalidOfferError(f"Charge {self.label!r} cannot be negative")
        if self.status is ComponentStatus.ADDITIONAL and self.amount is None:
            raise InvalidOfferError(f"Additional charge {self.label!r} needs an amount; use UNKNOWN instead")


UNKNOWN_DELIVERY = Charge("Delivery", ComponentStatus.UNKNOWN, note="Delivery cost not stated by supplier")
FREE_DELIVERY = Charge("Delivery", ComponentStatus.ADDITIONAL, Decimal("0.00"))


@dataclass(frozen=True)
class PriceTier:
    """Unit (per-pack) price that applies when at least ``min_packs`` are bought."""

    min_packs: int
    unit_price: Decimal

    def __post_init__(self) -> None:
        _require_decimal("tier unit_price", self.unit_price, allow_none=False)
        if self.min_packs < 1 or self.unit_price <= 0:
            raise InvalidOfferError("Invalid quantity tier")


@dataclass(frozen=True)
class PromotionTerms:
    label: str
    discount_type: str  # "fixed" | "percent"
    value: Decimal
    code: str | None = None  # explicit coupon code the customer must choose to apply
    membership_programme: str | None = None  # discount only for members of this programme
    min_spend: Decimal | None = None
    starts_at: datetime | None = None
    ends_at: datetime | None = None

    def __post_init__(self) -> None:
        _require_decimal("promotion value", self.value, allow_none=False)
        _require_decimal("min_spend", self.min_spend)
        if self.discount_type not in {"fixed", "percent"}:
            raise InvalidOfferError(f"Unknown discount type {self.discount_type!r}")
        if self.value <= 0 or (self.discount_type == "percent" and self.value > 100):
            raise InvalidOfferError("Promotion value out of range")


@dataclass(frozen=True)
class Offer:
    """One supplier's observed offer, as needed for calculation."""

    offer_id: str
    supplier_key: str
    supplier_name: str
    currency: str
    unit_price: Decimal  # price of one pack
    tax_treatment: TaxTreatment = TaxTreatment.UNKNOWN
    tax_rate: Decimal | None = None  # e.g. Decimal("0.20"); only used when tax is EXCLUDED
    delivery: Charge = UNKNOWN_DELIVERY
    fees: tuple[Charge, ...] = ()
    tiers: tuple[PriceTier, ...] = ()
    promotions: tuple[PromotionTerms, ...] = ()
    membership_required: str | None = None  # programme key required to buy at all
    minimum_order_amount: Decimal | None = None
    pack_size: Quantity = EACH  # what one pack contains
    item_key: str = ""

    def __post_init__(self) -> None:
        _require_decimal("unit_price", self.unit_price, allow_none=False)
        _require_decimal("tax_rate", self.tax_rate)
        _require_decimal("minimum_order_amount", self.minimum_order_amount)
        if len(self.currency) != 3:
            raise InvalidOfferError(f"Invalid currency code: {self.currency!r}")
        if self.unit_price <= 0:
            raise InvalidOfferError("Offer price must be positive; zero or negative prices are never published")
        if self.tax_rate is not None and not (Decimal(0) <= self.tax_rate < Decimal(1)):
            raise InvalidOfferError("tax_rate must be a fraction such as 0.20")


@dataclass(frozen=True)
class ComparisonContext:
    """The customer's situation. Anything not stated is treated as unknown, never assumed."""

    now: datetime
    currency: str = "GBP"
    required_quantity: Quantity = EACH
    memberships: Mapping[str, MembershipState] = field(default_factory=dict)
    default_membership_state: MembershipState = MembershipState.UNKNOWN
    coupon_codes: frozenset[str] = frozenset()
    include_delivery: bool = True

    def membership_state(self, programme: str) -> MembershipState:
        return MembershipState(self.memberships.get(programme, self.default_membership_state))


@dataclass(frozen=True)
class BreakdownLine:
    kind: str  # item | discount | fee | delivery | tax
    label: str
    amount: Decimal | None  # signed contribution to the total; None when unknown
    status: ComponentStatus
    note: str = ""


@dataclass(frozen=True)
class ConditionalDiscount:
    label: str
    potential_saving: Decimal
    condition: str


@dataclass(frozen=True)
class PriceBreakdown:
    offer_id: str
    currency: str
    lines: tuple[BreakdownLine, ...]
    packs: int
    purchased_quantity: Quantity
    surplus_quantity: Decimal
    unit_price_applied: Decimal
    item_subtotal: Decimal
    discount_total: Decimal
    fees_total: Decimal | None
    delivery_total: Decimal | None
    tax_total: Decimal | None
    total: Decimal | None  # comparable payable total; None when incomplete
    known_subtotal: Decimal  # sum of everything that is known (for "from £x + unknown")
    completeness: Completeness
    eligibility: Eligibility
    missing: tuple[str, ...] = ()  # why the total is incomplete
    conditions: tuple[str, ...] = ()  # why the offer is conditional / ineligible
    conditional_discounts: tuple[ConditionalDiscount, ...] = ()
    assumptions: tuple[str, ...] = ()

    @property
    def is_complete(self) -> bool:
        return self.completeness is Completeness.COMPLETE

    @property
    def is_rankable(self) -> bool:
        """Only complete totals the customer is known to be eligible for are ranked."""
        return self.is_complete and self.eligibility is Eligibility.ELIGIBLE and self.total is not None


class PricingEngine(Protocol):
    def calculate(self, offer: Offer, context: ComparisonContext) -> PriceBreakdown:
        """Pure calculation.

        Raises ``CurrencyMismatchError`` when currencies differ and
        ``IncompatibleUnitsError`` when the required quantity cannot be expressed
        in the offer's pack unit. Unknown inputs never raise: they yield an
        incomplete breakdown.
        """
        ...
