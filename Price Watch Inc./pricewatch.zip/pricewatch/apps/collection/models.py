from django.db import models


class CollectionRun(models.Model):
    """Job history: one row per attempt to collect from a source."""

    class Status(models.TextChoices):
        RUNNING = "running", "Running"
        SUCCEEDED = "succeeded", "Succeeded"
        PARTIAL = "partial", "Partially succeeded"
        FAILED = "failed", "Failed"

    class Trigger(models.TextChoices):
        SCHEDULE = "schedule", "Schedule"
        MANUAL = "manual", "Operator"
        SUBMISSION = "submission", "Supplier submission"
        DEMO = "demo", "Demonstration"

    source_configuration = models.ForeignKey("suppliers.SourceConfiguration", on_delete=models.PROTECT, related_name="runs")
    configuration_version = models.PositiveIntegerField()
    trigger = models.CharField(max_length=12, choices=Trigger.choices, default=Trigger.MANUAL)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.RUNNING)
    started_at = models.DateTimeField()
    finished_at = models.DateTimeField(null=True, blank=True)
    documents_fetched = models.PositiveIntegerField(default=0)
    listings_seen = models.PositiveIntegerField(default=0)
    observations_valid = models.PositiveIntegerField(default=0)
    observations_quarantined = models.PositiveIntegerField(default=0)
    failures = models.JSONField(default=list, blank=True)  # [{url, error, message}]
    error_class = models.CharField(max_length=80, blank=True)
    error_message = models.CharField(max_length=500, blank=True)

    class Meta:
        ordering = ["-started_at", "-id"]
        indexes = [models.Index(fields=["source_configuration", "-started_at"]), models.Index(fields=["status"])]

    def __str__(self) -> str:
        return f"Run {self.pk} {self.source_configuration.key} [{self.status}]"


class SourceDocument(models.Model):
    """The retrieved bytes an observation was extracted from (evidence)."""

    class Method(models.TextChoices):
        HTTP = "http", "HTTP"
        BROWSER = "browser", "Browser render"
        SUBMISSION = "submission", "Supplier submission"

    collection_run = models.ForeignKey(CollectionRun, on_delete=models.PROTECT, related_name="documents")
    url = models.URLField(max_length=1000)
    final_url = models.URLField(max_length=1000, blank=True)
    retrieval_method = models.CharField(max_length=12, choices=Method.choices)
    fetched_at = models.DateTimeField()
    http_status = models.PositiveSmallIntegerField(null=True, blank=True)
    content_type = models.CharField(max_length=100, blank=True)
    content_sha256 = models.CharField(max_length=64)
    byte_length = models.PositiveIntegerField()
    from_cache = models.BooleanField(default=False)
    body = models.TextField(blank=True)  # bounded by the source's max_response_bytes

    class Meta:
        ordering = ["-fetched_at"]
        indexes = [models.Index(fields=["content_sha256"])]

    def __str__(self) -> str:
        return f"{self.url} ({self.fetched_at:%Y-%m-%d %H:%M})"
