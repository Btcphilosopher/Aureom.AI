"""HTTP retrieval with per-source limits.

``SafeFetcher`` is the only place that talks HTTP. It provides:

* URL safety checks on the entry URL and on every redirect hop (no auto-follow);
* robots.txt compliance and ``Crawl-delay``;
* per-source timeout, bounded retries with exponential backoff (``Retry-After`` honoured);
* a streamed response-size limit;
* a minimum interval between requests;
* a short-lived response cache;
* explicit, typed failure states. 401/403/407/451 and challenge pages stop the fetch —
  authentication, CAPTCHAs and paywalls are never worked around.

The transport, DNS resolver, sleep function and clocks are injected so tests run
without network or real time.
"""
from __future__ import annotations

import asyncio
import hashlib
import re
import time
from dataclasses import replace
from typing import Any, Awaitable, Callable, Mapping, Protocol
from urllib.parse import urljoin, urlsplit
from urllib.robotparser import RobotFileParser

import httpx

from apps.core.clock import Clock, system_clock
from apps.core.logging import get_logger

from .safety import Resolver, check_url, system_resolver
from .types import (
    AccessDeniedError,
    CollectionError,
    FetchedDocument,
    FetchPolicy,
    ResponseTooLargeError,
    RetryExhaustedError,
    RobotsDisallowedError,
    RobotsUnavailableError,
    TooManyRedirectsError,
)

logger = get_logger("collection.fetcher")

_REDIRECTS = {301, 302, 303, 307, 308}
_DENIED = {401, 403, 407, 451}
_TRANSIENT = {408, 425, 429, 500, 502, 503, 504}
_CHALLENGE = re.compile(r"g-recaptcha|h-captcha|hcaptcha\.com|cf-challenge|challenge-platform|captcha-delivery", re.I)
_SENSITIVE_HEADERS = {"authorization", "cookie", "x-api-key", "proxy-authorization"}


class HttpStatusError(CollectionError):
    """A non-retryable HTTP status such as 404."""

    def __init__(self, status: int, url: str):
        super().__init__(f"HTTP {status} for {url}")
        self.status = status


class _Transient(Exception):
    def __init__(self, message: str, retry_after: float | None = None):
        super().__init__(message)
        self.retry_after = retry_after


class DocumentCache(Protocol):
    def get(self, key: str) -> Any: ...
    def set(self, key: str, value: Any, timeout: int) -> None: ...


def _retry_after(value: str | None) -> float | None:
    if value and value.strip().isdigit():
        return float(value.strip())
    return None


class SafeFetcher:
    def __init__(
        self,
        policy: FetchPolicy,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        resolver: Resolver = system_resolver,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
        monotonic: Callable[[], float] = time.monotonic,
        clock: Clock = system_clock,
        cache: DocumentCache | None = None,
        cache_namespace: str = "",
    ) -> None:
        self.policy = policy
        self._transport = transport
        self._resolver = resolver
        self._sleep = sleep
        self._monotonic = monotonic
        self._clock = clock
        self._cache = cache
        self._cache_namespace = cache_namespace
        self._client: httpx.AsyncClient | None = None
        self._last_request_at: float | None = None
        self._min_interval = policy.min_request_interval_seconds
        self._robots: dict[str, RobotFileParser | bool | str] = {}
        self.request_count = 0

    async def __aenter__(self) -> "SafeFetcher":
        self._client = httpx.AsyncClient(
            transport=self._transport,
            follow_redirects=False,  # every hop is validated by us
            timeout=httpx.Timeout(self.policy.timeout_seconds),
            headers={"User-Agent": self.policy.user_agent, "Accept-Encoding": "gzip, deflate"},
            limits=httpx.Limits(max_connections=4, max_keepalive_connections=2),
        )
        return self

    async def __aexit__(self, *exc_info) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    # ------------------------------------------------------------------ public
    async def ensure_allowed(self, url: str) -> None:
        """URL safety plus robots.txt. Used directly by the browser adapter."""
        self._check(url)
        if self.policy.respect_robots and not await self._robots_allow(url):
            raise RobotsDisallowedError(f"robots.txt disallows {url}")

    async def fetch(self, url: str, *, headers: Mapping[str, str] | None = None) -> FetchedDocument:
        cache_key = self._cache_key(url)
        if self._cache is not None and self.policy.cache_ttl_seconds > 0:
            cached = self._cache.get(cache_key)
            if cached:
                return replace(FetchedDocument(**cached), from_cache=True)

        await self.ensure_allowed(url)
        attempts = self.policy.max_retries + 1
        last_error = "no attempt made"
        for attempt in range(attempts):
            try:
                document = await self._get(url, headers or {})
                break
            except _Transient as exc:
                last_error = str(exc)
                if attempt + 1 >= attempts:
                    raise RetryExhaustedError(f"{last_error} after {attempts} attempt(s)") from None
                delay = min(self.policy.backoff_base_seconds * (2 ** attempt), self.policy.backoff_max_seconds)
                if exc.retry_after is not None:
                    delay = min(max(delay, exc.retry_after), self.policy.backoff_max_seconds)
                logger.warning("fetch retry", extra={"url": url, "attempt": attempt + 1, "delay": delay, "reason": last_error})
                await self._sleep(delay)
        if self._cache is not None and self.policy.cache_ttl_seconds > 0:
            self._cache.set(cache_key, document.__dict__ | {"from_cache": False}, self.policy.cache_ttl_seconds)
        return document

    # ---------------------------------------------------------------- internals
    def _cache_key(self, url: str) -> str:
        digest = hashlib.sha256(url.encode()).hexdigest()
        return f"pricewatch:doc:{self._cache_namespace}:{digest}"

    def _check(self, url: str) -> None:
        check_url(
            url,
            resolver=self._resolver,
            allowed_private_hosts=self.policy.allowed_private_hosts,
            allowed_ports=self.policy.allowed_ports,
        )

    async def _throttle(self) -> None:
        if self._last_request_at is not None and self._min_interval > 0:
            wait = self._min_interval - (self._monotonic() - self._last_request_at)
            if wait > 0:
                await self._sleep(wait)
        self._last_request_at = self._monotonic()

    async def _get(self, url: str, headers: Mapping[str, str], *, max_bytes: int | None = None) -> FetchedDocument:
        assert self._client is not None, "SafeFetcher must be used as an async context manager"
        limit = max_bytes or self.policy.max_response_bytes
        current = url
        request_headers = dict(headers)
        origin_host = urlsplit(url).hostname
        for _hop in range(self.policy.max_redirects + 1):
            self._check(current)  # validates redirects too: no private-network pivots
            await self._throttle()
            self.request_count += 1
            try:
                async with self._client.stream("GET", current, headers=request_headers) as response:
                    status = response.status_code
                    if status in _REDIRECTS:
                        location = response.headers.get("location")
                        if not location:
                            raise HttpStatusError(status, current)
                        current = urljoin(current, location)
                        if urlsplit(current).hostname != origin_host:
                            # never forward credentials to another host
                            request_headers = {k: v for k, v in request_headers.items() if k.lower() not in _SENSITIVE_HEADERS}
                        continue
                    if status in _DENIED:
                        raise AccessDeniedError(f"HTTP {status}: access to {current} is controlled; not attempting to bypass")
                    if status in _TRANSIENT:
                        raise _Transient(f"HTTP {status} from {current}", _retry_after(response.headers.get("retry-after")))
                    if status >= 400:
                        raise HttpStatusError(status, current)
                    declared = response.headers.get("content-length")
                    if declared and declared.isdigit() and int(declared) > limit:
                        raise ResponseTooLargeError(f"Response declares {declared} bytes; limit is {limit}")
                    chunks: list[bytes] = []
                    size = 0
                    async for chunk in response.aiter_bytes():
                        size += len(chunk)
                        if size > limit:
                            raise ResponseTooLargeError(f"Response exceeded {limit} bytes and was abandoned")
                        chunks.append(chunk)
                    body = b"".join(chunks)
                    text = body.decode(response.encoding or "utf-8", errors="replace")
                    content_type = response.headers.get("content-type", "").split(";")[0].strip().lower()
            except httpx.TimeoutException:
                raise _Transient(f"Timed out after {self.policy.timeout_seconds}s fetching {current}") from None
            except httpx.TransportError as exc:
                raise _Transient(f"{exc.__class__.__name__} fetching {current}") from None
            if "html" in content_type and _CHALLENGE.search(text[:20000]):
                raise AccessDeniedError(f"{current} returned a challenge page; not attempting to bypass")
            return FetchedDocument(
                url=url, final_url=current, status=status, content_type=content_type, body=text,
                sha256=hashlib.sha256(body).hexdigest(), byte_length=size, fetched_at=self._clock.now(),
            )
        raise TooManyRedirectsError(f"More than {self.policy.max_redirects} redirects from {url}")

    async def _robots_allow(self, url: str) -> bool:
        parts = urlsplit(url)
        origin = f"{parts.scheme}://{parts.netloc}"
        rules = self._robots.get(origin)
        if rules is None:
            rules = await self._load_robots(origin)
            self._robots[origin] = rules
        if isinstance(rules, str):
            raise RobotsUnavailableError(f"Could not read {origin}/robots.txt ({rules}); not collecting until the crawling policy is known")
        if isinstance(rules, bool):
            return rules
        return rules.can_fetch(self.policy.user_agent, url)

    async def _load_robots(self, origin: str) -> RobotFileParser | bool | str:
        try:
            document = await self._get(f"{origin}/robots.txt", {}, max_bytes=500_000)
        except HttpStatusError:
            return True  # 404/410 etc.: no robots policy published
        except AccessDeniedError:
            return False  # 401/403 on robots.txt: treat the whole site as disallowed
        except (CollectionError, _Transient) as exc:
            return str(exc) or exc.__class__.__name__  # policy unknown: be conservative for this run
        parser = RobotFileParser()
        parser.parse(document.body.splitlines())
        delay = parser.crawl_delay(self.policy.user_agent)
        if delay:
            self._min_interval = max(self._min_interval, min(float(delay), 60.0))
        return parser
