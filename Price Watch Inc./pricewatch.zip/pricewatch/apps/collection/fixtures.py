"""Local fixture supplier sites.

In fixture mode every request for a ``*.fixture.test`` host is answered from
``fixtures/supplier_sites/<host>/<path>`` by an in-process HTTPX transport, so the
real fetcher (safety checks, robots, retries, size limits) is exercised with no
network. A *scenario* overlays files and injects failures::

    fixtures/supplier_sites/_scenarios/<scenario>/<host>/<path>   # replaces a baseline file
    fixtures/supplier_sites/_scenarios/<scenario>/scenario.json   # {"failures": {"<host>": 503}}

Optional ``<host>/_site.json`` may contain ``{"require_bearer": "<token>"}`` to make the
fixture demand an ``Authorization`` header, which exercises server-side credentials.
"""
from __future__ import annotations

import json
import mimetypes
from pathlib import Path

import httpx

FIXTURE_SUFFIX = ".fixture.test"


class FixtureSite:
    def __init__(self, root: Path, scenario: str = "baseline") -> None:
        self.root = Path(root).resolve()
        self.scenario = scenario or "baseline"
        self._overlay = self.root / "_scenarios" / self.scenario
        self.failures: dict[str, int] = {}
        scenario_file = self._overlay / "scenario.json"
        if self.scenario != "baseline":
            if not self._overlay.is_dir():
                raise ValueError(f"Unknown fixture scenario: {self.scenario}")
            if scenario_file.is_file():
                self.failures = json.loads(scenario_file.read_text()).get("failures", {})

    def _resolve(self, base: Path, host: str, path: str) -> Path | None:
        if host.startswith("_") or "/" in host or ".." in host:
            return None
        site = (base / host).resolve()
        target = (site / path.lstrip("/")).resolve()
        if not target.is_relative_to(site) or not site.is_relative_to(self.root):
            return None  # path traversal
        if target.is_dir():
            target = target / "index.html"
        if target.name.startswith("_") or not target.is_file():
            return None
        return target

    def lookup(self, host: str, path: str) -> tuple[bytes, str] | None:
        """Return ``(body, content_type)`` or None when the fixture has no such file."""
        target = self._resolve(self._overlay, host, path) if self.scenario != "baseline" else None
        target = target or self._resolve(self.root, host, path)
        if target is None:
            return None
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in ("application/json", "application/javascript"):
            content_type += "; charset=utf-8"
        return target.read_bytes(), content_type

    def failure_status(self, host: str, path: str) -> int | None:
        return self.failures.get(f"{host}{path}") or self.failures.get(host)

    def required_bearer(self, host: str) -> str | None:
        config = self.root / host / "_site.json"
        if config.is_file():
            return json.loads(config.read_text()).get("require_bearer")
        return None


class FixtureTransport(httpx.AsyncBaseTransport):
    """Serves fixture supplier sites to HTTPX. Unknown hosts fail like an unreachable server."""

    def __init__(self, site: FixtureSite) -> None:
        self.site = site
        self.requests: list[str] = []

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        host, path = request.url.host, request.url.path
        self.requests.append(str(request.url))
        if not host.endswith(FIXTURE_SUFFIX):
            raise httpx.ConnectError(f"Fixture mode: {host} is not a fixture host", request=request)
        status = self.site.failure_status(host, path)
        if status:
            return httpx.Response(status, text=f"Injected failure {status}", request=request)
        bearer = self.site.required_bearer(host)
        if bearer and path != "/robots.txt" and request.headers.get("authorization") != f"Bearer {bearer}":
            return httpx.Response(401, json={"error": "unauthorised"}, request=request)
        found = self.site.lookup(host, path)
        if found is None:
            return httpx.Response(404, text="Not found", request=request)
        body, content_type = found
        return httpx.Response(200, content=body, headers={"content-type": content_type}, request=request)
