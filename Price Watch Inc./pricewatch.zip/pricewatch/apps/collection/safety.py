"""Server-side request forgery (SSRF) defences for collection URLs.

Every URL — the entry URL *and each redirect hop* — must pass :func:`check_url`:

* scheme is http or https, no embedded credentials;
* port is in the allow-list;
* every address the hostname resolves to is globally routable (no loopback,
  RFC 1918, link-local/metadata, CGNAT, multicast, reserved, IPv4-mapped tricks).

A hostname may be exempted only by listing it exactly in
``PRICEWATCH_ALLOWED_PRIVATE_HOSTS`` (for example an on-premises supplier feed).

Residual risk: DNS can change between this check and the connection (rebinding).
In production, also route collection through an egress proxy that enforces the
same rule at connect time; see ``docs/operations.md``.
"""
from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from typing import Callable, Iterable
from urllib.parse import urlsplit

from .types import UnsafeUrlError

Resolver = Callable[[str], Iterable[str]]

_BLOCKED_SUFFIXES = (".localhost", ".local", ".internal", ".lan", ".home.arpa", ".intranet")


def system_resolver(hostname: str) -> list[str]:
    try:
        infos = socket.getaddrinfo(hostname, None, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise UnsafeUrlError(f"Hostname does not resolve: {hostname}") from exc
    return sorted({info[4][0] for info in infos})


def _address_is_public(address: str) -> bool:
    try:
        ip = ipaddress.ip_address(address.split("%", 1)[0])
    except ValueError:
        return False
    if isinstance(ip, ipaddress.IPv6Address):
        mapped = ip.ipv4_mapped or ip.sixtofour or (ip.teredo[1] if ip.teredo else None)
        if mapped is not None:
            return _address_is_public(str(mapped))
    return ip.is_global and not ip.is_multicast


def _literal_ip(hostname: str) -> str | None:
    """Recognise IP literals including legacy forms such as ``2130706433`` or ``0x7f.1``."""
    try:
        return str(ipaddress.ip_address(hostname.strip("[]")))
    except ValueError:
        pass
    try:
        return socket.inet_ntoa(socket.inet_aton(hostname))
    except (OSError, UnicodeError):
        return None


@dataclass(frozen=True)
class CheckedUrl:
    url: str
    hostname: str
    port: int
    addresses: tuple[str, ...]


def check_url(
    url: str,
    *,
    resolver: Resolver = system_resolver,
    allowed_private_hosts: frozenset[str] = frozenset(),
    allowed_ports: frozenset[int] = frozenset({80, 443}),
) -> CheckedUrl:
    if not isinstance(url, str) or len(url) > 2000 or any(ord(ch) < 0x21 for ch in url):
        raise UnsafeUrlError("URL is malformed")
    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError as exc:
        raise UnsafeUrlError("URL is malformed") from exc
    if parts.scheme not in ("http", "https"):
        raise UnsafeUrlError(f"Scheme {parts.scheme or '(none)'!r} is not allowed; only http and https")
    if parts.username is not None or parts.password is not None:
        raise UnsafeUrlError("URLs with embedded credentials are not allowed")
    hostname = (parts.hostname or "").lower().rstrip(".")
    if not hostname:
        raise UnsafeUrlError("URL has no hostname")
    port = port or (443 if parts.scheme == "https" else 80)

    if hostname in allowed_private_hosts:
        return CheckedUrl(url, hostname, port, ())  # explicit operator exemption (exact hostname)

    if port not in allowed_ports:
        raise UnsafeUrlError(f"Port {port} is not allowed")
    if hostname == "localhost" or hostname.endswith(_BLOCKED_SUFFIXES):
        raise UnsafeUrlError(f"Hostname {hostname} is internal")

    literal = _literal_ip(hostname)
    addresses = [literal] if literal else list(resolver(hostname))
    if not addresses:
        raise UnsafeUrlError(f"Hostname does not resolve: {hostname}")
    for address in addresses:
        if not _address_is_public(address):
            raise UnsafeUrlError(f"{hostname} resolves to a non-public address")
    return CheckedUrl(url, hostname, port, tuple(addresses))
