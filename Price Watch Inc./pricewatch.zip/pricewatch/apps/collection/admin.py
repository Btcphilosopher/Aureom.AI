from django.contrib import admin

from apps.suppliers.admin import ReadOnlyAdmin

from .models import CollectionRun, SourceDocument


@admin.register(CollectionRun)
class CollectionRunAdmin(ReadOnlyAdmin):
    list_display = ("id", "source_configuration", "trigger", "status", "started_at", "observations_valid", "observations_quarantined", "error_class")
    list_filter = ("status", "trigger")
    date_hierarchy = "started_at"


@admin.register(SourceDocument)
class SourceDocumentAdmin(ReadOnlyAdmin):
    list_display = ("url", "retrieval_method", "http_status", "byte_length", "fetched_at", "from_cache")
    list_filter = ("retrieval_method",)
