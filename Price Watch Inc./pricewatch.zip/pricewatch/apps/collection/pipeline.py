"""Collection orchestration: source → documents → observations → matches.

``run_collection`` is synchronous and is what Celery tasks, management commands
and tests call. All I/O dependencies (fetcher, renderer, clock) are injectable.
A failed run never touches existing observations, so the last valid price stays
visible and is labelled stale by the comparison layer.
"""
from __future__ import annotations

import os
from contextlib import AbstractAsyncContextManager
from decimal import Decimal
from typing import Callable
from urllib.parse import urlsplit

from asgiref.sync import async_to_sync
from django.conf import settings
from django.core.cache import cache as django_cache
from django.db import transaction

from apps.audit.services import record
from apps.core.clock import Clock, system_clock
from apps.core.logging import get_logger
from apps.extraction.types import Condition, SourceDefaults
from apps.matching.services import match_listing
from apps.pricing.types import Charge, ComponentStatus, TaxTreatment
from apps.suppliers.models import SourceConfiguration
from apps.suppliers.services import ingest_listing

from .adapters import build_adapter
from .browser import PlaywrightRenderer
from .fetcher import SafeFetcher
from .fixtures import FIXTURE_SUFFIX, FixtureSite, FixtureTransport
from .models import CollectionRun, SourceDocument
from .types import (
    CollectionError,
    CollectionQuery,
    CollectionResult,
    FetchPolicy,
    SourceConfigurationError,
    SourceSnapshot,
)

logger = get_logger("collection.pipeline")

FetcherFactory = Callable[[SourceSnapshot], AbstractAsyncContextManager]
RendererFactory = Callable[[SourceSnapshot], AbstractAsyncContextManager]


def _decimal(value) -> Decimal | None:
    return None if value in (None, "") else Decimal(str(value))


def defaults_from_config(config: SourceConfiguration) -> SourceDefaults:
    declared = (config.settings or {}).get("defaults") or {}
    delivery = None
    if isinstance(declared.get("delivery"), dict):
        spec = declared["delivery"]
        if spec.get("status") == "unknown":
            delivery = Charge("Delivery", ComponentStatus.UNKNOWN, note=spec.get("note", "Delivery calculated at checkout"))
        elif spec.get("status") == "included":
            delivery = Charge("Delivery", ComponentStatus.INCLUDED)
        elif spec.get("amount") is not None:
            delivery = Charge("Delivery", ComponentStatus.ADDITIONAL, Decimal(str(spec["amount"])),
                              free_threshold=_decimal(spec.get("free_threshold")))
    return SourceDefaults(
        supplier_key=config.supplier.slug,
        currency=declared.get("currency"),
        locale=declared.get("locale", "en-GB"),
        tax_treatment=TaxTreatment(declared["tax_treatment"]) if declared.get("tax_treatment") else None,
        tax_rate=_decimal(declared.get("tax_rate")),
        condition=Condition(declared["condition"]) if declared.get("condition") else None,
        delivery=delivery,
        membership_programme=config.supplier.membership_programme or None,
        config_locator=f"source configuration {config.key} v{config.version} defaults",
    )


def snapshot_source(config: SourceConfiguration) -> SourceSnapshot:
    app = settings.PRICEWATCH
    credential = None
    if config.credential_env_var:
        credential = os.environ.get(config.credential_env_var)
        if not credential:
            raise SourceConfigurationError(f"Credential environment variable {config.credential_env_var} is not set")
    allowed_private = set(app["ALLOWED_PRIVATE_HOSTS"])
    if app["FIXTURE_MODE"]:
        # Fixture hosts are answered in-process and never resolved or connected to.
        allowed_private |= {
            host for host in (urlsplit(u).hostname for u in config.entry_urls) if host and host.endswith(FIXTURE_SUFFIX)
        }
    policy = FetchPolicy(
        user_agent=app["COLLECTION_USER_AGENT"],
        timeout_seconds=float(config.timeout_seconds),
        max_retries=config.max_retries,
        max_response_bytes=config.max_response_bytes,
        min_request_interval_seconds=config.min_request_interval_ms / 1000,
        cache_ttl_seconds=config.cache_ttl_seconds,
        respect_robots=config.respect_robots,
        allowed_private_hosts=frozenset(allowed_private),
        allowed_ports=frozenset(app["ALLOWED_PORTS"]),
    )
    return SourceSnapshot(
        key=config.key, supplier_key=config.supplier.slug, kind=config.kind, version=config.version,
        entry_urls=tuple(config.entry_urls or ()), settings=config.settings or {},
        defaults=defaults_from_config(config), policy=policy, credential=credential,
    )


def default_factories(scenario: str | None = None) -> tuple[FetcherFactory, RendererFactory]:
    """Production wiring, or in-process fixture sites when ``PRICEWATCH_FIXTURE_MODE`` is on."""
    app = settings.PRICEWATCH
    site = FixtureSite(app["FIXTURE_ROOT"], scenario or app["FIXTURE_SCENARIO"]) if app["FIXTURE_MODE"] else None

    def fetcher_factory(source: SourceSnapshot):
        if site is not None:
            # Fixture runs skip the cache and politeness delay so scenario changes show immediately.
            from dataclasses import replace

            policy = replace(source.policy, cache_ttl_seconds=0, min_request_interval_seconds=0.0, backoff_base_seconds=0.0)
            return SafeFetcher(policy, transport=FixtureTransport(site))
        return SafeFetcher(source.policy, cache=django_cache, cache_namespace=f"{source.key}:v{source.version}")

    def renderer_factory(source: SourceSnapshot):
        return PlaywrightRenderer(
            source.policy,
            executable_path=app["BROWSER_EXECUTABLE"],
            no_sandbox=app["BROWSER_NO_SANDBOX"],
            max_concurrent_pages=app["BROWSER_MAX_CONCURRENT_PAGES"],
            fixture_lookup=site.lookup if site is not None else None,
        )

    return fetcher_factory, renderer_factory


async def _collect(source: SourceSnapshot, query: CollectionQuery, fetcher_factory: FetcherFactory,
                   renderer_factory: RendererFactory) -> CollectionResult:
    async with fetcher_factory(source) as fetcher:
        if source.kind == "browser":
            async with renderer_factory(source) as renderer:
                return await build_adapter(source, fetcher, renderer).collect(query)
        return await build_adapter(source, fetcher).collect(query)


def _finish_failed(run: CollectionRun, config: SourceConfiguration, exc: BaseException, clock: Clock) -> CollectionRun:
    now = clock.now()
    message = str(exc)[:500] or exc.__class__.__name__
    run.status = CollectionRun.Status.FAILED
    run.finished_at = now
    run.error_class = exc.__class__.__name__
    run.error_message = message
    run.save()
    SourceConfiguration.objects.filter(pk=config.pk).update(
        last_failure_at=now, last_failure_reason=f"{exc.__class__.__name__}: {message}"[:300],
        consecutive_failures=config.consecutive_failures + 1,
    )
    record("collection.failed", run, data={"source": config.key, "error": exc.__class__.__name__, "message": message}, at=now)
    logger.error("collection failed", extra={"source": config.key, "run": run.pk, "error": exc.__class__.__name__, "detail": message})
    return run


def run_collection(
    config: SourceConfiguration,
    *,
    trigger: str = CollectionRun.Trigger.MANUAL,
    clock: Clock = system_clock,
    fetcher_factory: FetcherFactory | None = None,
    renderer_factory: RendererFactory | None = None,
    scenario: str | None = None,
    urls: tuple[str, ...] = (),
) -> CollectionRun:
    started = clock.now()
    run = CollectionRun.objects.create(
        source_configuration=config, configuration_version=config.version, trigger=trigger, started_at=started
    )
    SourceConfiguration.objects.filter(pk=config.pk).update(last_attempt_at=started)
    config.refresh_from_db()
    logger.info("collection started", extra={"source": config.key, "run": run.pk, "trigger": str(trigger)})

    try:
        if config.status == SourceConfiguration.Status.PAUSED:
            raise SourceConfigurationError("Source is paused")
        source = snapshot_source(config)
        if fetcher_factory is None or renderer_factory is None:
            default_fetcher, default_renderer = default_factories(scenario)
            fetcher_factory = fetcher_factory or default_fetcher
            renderer_factory = renderer_factory or default_renderer
        query = CollectionQuery(source_key=config.key, requested_at=started, urls=urls)
        result = async_to_sync(_collect)(source, query, fetcher_factory, renderer_factory)
    except CollectionError as exc:
        return _finish_failed(run, config, exc, clock)
    except Exception as exc:  # unexpected: record a visible failure, keep the traceback in logs
        logger.exception("unexpected collection error", extra={"source": config.key, "run": run.pk})
        return _finish_failed(run, config, exc, clock)

    if result.status == "failed":
        first = result.failures[0]
        run.failures = [f.as_dict() for f in result.failures]
        run.save(update_fields=["failures"])
        return _finish_failed(run, config, CollectionError(f"{first.error}: {first.message}"), clock)

    observed_at = clock.now()
    valid = quarantined = broken = 0
    to_match = []
    try:
        with transaction.atomic():
            documents: dict[str, SourceDocument] = {}
            for document in result.documents:
                stored = SourceDocument.objects.create(
                    collection_run=run, url=document.url, final_url=document.final_url,
                    retrieval_method=document.method, fetched_at=document.fetched_at, http_status=document.status,
                    content_type=document.content_type[:100], content_sha256=document.sha256,
                    byte_length=document.byte_length, from_cache=document.from_cache, body=document.body,
                )
                documents[document.final_url] = documents[document.url] = stored
            for raw in result.listings:
                ingested = ingest_listing(
                    source=config, run=run, raw=raw, defaults=source.defaults, observed_at=observed_at,
                    document=documents.get(raw.source_url),
                )
                if ingested.published:
                    valid += 1
                    if ingested.identity_changed or ingested.listing.variant_id is None:
                        to_match.append(ingested.listing)
                else:
                    quarantined += 1
                    if any(issue.get("code") == "broken_selector" for issue in ingested.observation.issues):
                        broken += 1
        for listing in to_match:
            match_listing(listing, clock=clock)
    except Exception as exc:  # storage or matching failed: nothing from this run is half-published
        logger.exception("collection ingest error", extra={"source": config.key, "run": run.pk})
        return _finish_failed(run, config, exc, clock)

    finished = clock.now()
    run.status = result.status
    run.finished_at = finished
    run.documents_fetched = len(result.documents)
    run.listings_seen = len(result.listings)
    run.observations_valid = valid
    run.observations_quarantined = quarantined
    run.failures = [f.as_dict() for f in result.failures]
    run.save()

    updates: dict = {}
    selectors_broken = bool(result.listings) and broken == len(result.listings)
    if selectors_broken:
        updates.update(
            status=SourceConfiguration.Status.BROKEN, last_failure_at=finished,
            last_failure_reason="Extraction rules matched nothing; selectors need updating",
            consecutive_failures=config.consecutive_failures + 1,
        )
        record("source.marked_broken", config, data={"run": run.pk}, at=finished)
    elif result.status == "succeeded":
        updates.update(last_success_at=finished, consecutive_failures=0)
        if config.status == SourceConfiguration.Status.BROKEN:
            updates["status"] = SourceConfiguration.Status.ACTIVE
    else:  # partial: some URLs failed. Recorded as a failure; successes are visible per listing.
        first = result.failures[0]
        updates.update(
            last_failure_at=finished, last_failure_reason=f"{first.error}: {first.message}"[:300],
            consecutive_failures=config.consecutive_failures + 1,
        )
    SourceConfiguration.objects.filter(pk=config.pk).update(**updates)
    config.refresh_from_db()
    record("collection.finished", run, at=finished, data={
        "source": config.key, "status": run.status, "valid": valid, "quarantined": quarantined, "failures": len(result.failures),
    })
    logger.info("collection finished", extra={
        "source": config.key, "run": run.pk, "status": run.status, "valid": valid, "quarantined": quarantined,
        "documents": len(result.documents), "failures": len(result.failures),
    })
    return run
