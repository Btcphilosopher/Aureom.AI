"""Bounded Playwright rendering for authorised JavaScript-rendered sources.

Limits that keep browser use contained:

* one browser per collection run, always closed in ``__aexit__``;
* a semaphore caps concurrent pages; a per-run page budget caps total pages;
* every navigation has a hard deadline (``asyncio.wait_for``) on top of Playwright's own;
* every network request the page makes is intercepted: images/media/fonts are dropped and
  each URL is re-validated by the SSRF check, so a page cannot pivot to private addresses;
* downloads and service workers are disabled, dialogs dismissed, DOM size is capped.

The renderer only loads pages. It never fills in logins or interacts with challenges.
"""
from __future__ import annotations

import asyncio
import hashlib
from typing import Callable
from urllib.parse import urlsplit

from apps.core.clock import Clock, system_clock
from apps.core.logging import get_logger

from .safety import Resolver, check_url, system_resolver
from .types import (
    BrowserUnavailableError,
    CollectionError,
    FetchedDocument,
    FetchPolicy,
    ResponseTooLargeError,
    UnsafeUrlError,
)

logger = get_logger("collection.browser")

FixtureLookup = Callable[[str, str], "tuple[bytes, str] | None"]
_BLOCKED_RESOURCES = {"image", "media", "font"}


class PlaywrightRenderer:
    def __init__(
        self,
        policy: FetchPolicy,
        *,
        resolver: Resolver = system_resolver,
        executable_path: str | None = None,
        no_sandbox: bool = False,
        max_concurrent_pages: int = 2,
        max_pages_per_run: int = 25,
        fixture_lookup: FixtureLookup | None = None,
        clock: Clock = system_clock,
    ) -> None:
        self.policy = policy
        self._resolver = resolver
        self._executable_path = executable_path
        self._no_sandbox = no_sandbox
        self._semaphore = asyncio.Semaphore(max(1, max_concurrent_pages))
        self._max_pages = max_pages_per_run
        self._fixture_lookup = fixture_lookup
        self._clock = clock
        self._playwright = None
        self._browser = None
        self.pages_rendered = 0
        self.blocked_requests: list[str] = []

    async def __aenter__(self) -> "PlaywrightRenderer":
        try:
            from playwright.async_api import async_playwright

            self._playwright = await async_playwright().start()
            args = ["--disable-dev-shm-usage", "--disable-extensions", "--disable-background-networking"]
            if self._no_sandbox:
                args.append("--no-sandbox")
            self._browser = await asyncio.wait_for(
                self._playwright.chromium.launch(headless=True, executable_path=self._executable_path or None, args=args),
                timeout=30,
            )
        except Exception as exc:
            await self.__aexit__(None, None, None)
            raise BrowserUnavailableError(f"Could not start a browser: {exc.__class__.__name__}") from exc
        return self

    async def __aexit__(self, *exc_info) -> None:
        for closer in (getattr(self._browser, "close", None), getattr(self._playwright, "stop", None)):
            if closer is not None:
                try:
                    await asyncio.wait_for(closer(), timeout=10)
                except Exception:  # shutting down must never mask the original error
                    logger.warning("browser shutdown problem", exc_info=True)
        self._browser = None
        self._playwright = None

    def _check(self, url: str) -> None:
        check_url(url, resolver=self._resolver, allowed_private_hosts=self.policy.allowed_private_hosts,
                  allowed_ports=self.policy.allowed_ports)

    async def _route(self, route) -> None:
        request = route.request
        url = request.url
        try:
            if request.resource_type in _BLOCKED_RESOURCES:
                await route.abort()
                return
            try:
                self._check(url)
            except UnsafeUrlError:
                self.blocked_requests.append(url)
                await route.abort("blockedbyclient")
                return
            if self._fixture_lookup is not None:
                parts = urlsplit(url)
                found = self._fixture_lookup(parts.hostname or "", parts.path)
                if found is None:
                    await route.fulfill(status=404, body="Not found")
                else:
                    await route.fulfill(status=200, body=found[0], content_type=found[1])
                return
            await route.continue_()
        except Exception:  # the page may already be closing
            logger.debug("route handling failed", exc_info=True)

    async def render(self, url: str, *, wait_for_selector: str | None = None) -> FetchedDocument:
        if self._browser is None:
            raise BrowserUnavailableError("Renderer is not started")
        if self.pages_rendered >= self._max_pages:
            raise CollectionError(f"Browser page budget of {self._max_pages} exhausted for this run")
        self._check(url)
        timeout_ms = int(self.policy.timeout_seconds * 1000)
        async with self._semaphore:
            self.pages_rendered += 1
            context = await self._browser.new_context(
                user_agent=self.policy.user_agent, accept_downloads=False, service_workers="block",
            )
            try:
                context.set_default_timeout(timeout_ms)
                await context.route("**/*", self._route)
                page = await context.new_page()
                page.on("dialog", lambda dialog: asyncio.ensure_future(dialog.dismiss()))

                async def load() -> tuple[int | None, str, str]:
                    response = await page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)
                    if wait_for_selector:
                        await page.wait_for_selector(wait_for_selector, state="attached", timeout=timeout_ms)
                    return (response.status if response else None), page.url, await page.content()

                try:
                    status, final_url, html = await asyncio.wait_for(load(), timeout=self.policy.timeout_seconds * 2 + 5)
                except asyncio.TimeoutError:
                    raise CollectionError(f"Rendering {url} exceeded its deadline") from None
                except CollectionError:
                    raise
                except Exception as exc:
                    raise CollectionError(f"Rendering failed: {exc.__class__.__name__}: {str(exc)[:200]}") from None
            finally:
                await context.close()
        self._check(final_url)
        body = html.encode()
        if len(body) > self.policy.max_response_bytes:
            raise ResponseTooLargeError(f"Rendered DOM exceeded {self.policy.max_response_bytes} bytes")
        if status is not None and status >= 400:
            raise CollectionError(f"HTTP {status} rendering {url}")
        return FetchedDocument(
            url=url, final_url=final_url, status=status, content_type="text/html", body=html,
            sha256=hashlib.sha256(body).hexdigest(), byte_length=len(body), fetched_at=self._clock.now(), method="browser",
        )
