"""Typed values and errors for source collection. No Django imports."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Mapping, Protocol

from apps.extraction.types import RawListing, SourceDefaults


class CollectionError(Exception):
    """Base class. ``retryable`` tells the fetcher whether backing off can help."""

    retryable = False


class UnsafeUrlError(CollectionError):
    """URL is not http(s), targets a private/reserved address, or uses a disallowed port."""


class RobotsDisallowedError(CollectionError):
    """The site's robots.txt does not permit this fetch."""


class RobotsUnavailableError(CollectionError):
    """robots.txt could not be read, so the site's crawling policy is unknown; we do not collect."""


class AccessDeniedError(CollectionError):
    """401/403/407/451 or a challenge page. We stop; access controls are never bypassed."""


class ResponseTooLargeError(CollectionError):
    """The response exceeded the source's size limit and was abandoned."""


class TooManyRedirectsError(CollectionError):
    pass


class RetryExhaustedError(CollectionError):
    """A transient failure persisted through every permitted retry."""


class BrowserUnavailableError(CollectionError):
    """No browser could be launched for a browser-rendered source."""


class SourceConfigurationError(CollectionError):
    """The stored configuration is unusable (missing URL, bad selector map, missing credential)."""


@dataclass(frozen=True)
class FetchPolicy:
    """Per-source retrieval limits."""

    user_agent: str
    timeout_seconds: float = 10.0
    max_retries: int = 2
    backoff_base_seconds: float = 0.5
    backoff_max_seconds: float = 30.0
    max_response_bytes: int = 2_000_000
    max_redirects: int = 5
    min_request_interval_seconds: float = 1.0
    cache_ttl_seconds: int = 300
    respect_robots: bool = True
    allowed_private_hosts: frozenset[str] = frozenset()
    allowed_ports: frozenset[int] = frozenset({80, 443})


@dataclass(frozen=True)
class FetchedDocument:
    url: str
    final_url: str
    status: int | None
    content_type: str
    body: str
    sha256: str
    byte_length: int
    fetched_at: datetime
    method: str = "http"  # http | browser | submission
    from_cache: bool = False


@dataclass(frozen=True)
class SourceSnapshot:
    """A database-free copy of a source configuration handed to an adapter."""

    key: str
    supplier_key: str
    kind: str
    version: int
    entry_urls: tuple[str, ...]
    settings: Mapping[str, Any]
    defaults: SourceDefaults
    policy: FetchPolicy
    credential: str | None = field(default=None, repr=False)  # never logged, never stored


@dataclass(frozen=True)
class CollectionQuery:
    source_key: str
    requested_at: datetime
    urls: tuple[str, ...] = ()  # empty: use the source's configured entry URLs
    search_term: str | None = None
    max_documents: int = 50


@dataclass(frozen=True)
class CollectionFailure:
    url: str
    error: str  # exception class name
    message: str

    def as_dict(self) -> dict[str, str]:
        return {"url": self.url, "error": self.error, "message": self.message}


@dataclass
class CollectionResult:
    documents: list[FetchedDocument] = field(default_factory=list)
    listings: list[RawListing] = field(default_factory=list)
    failures: list[CollectionFailure] = field(default_factory=list)

    @property
    def status(self) -> str:
        if self.failures and not self.documents:
            return "failed"
        if self.failures:
            return "partial"
        return "succeeded"


class Fetcher(Protocol):
    async def fetch(self, url: str, *, headers: Mapping[str, str] | None = None) -> FetchedDocument:
        """Retrieve one URL within the source's policy, or raise a ``CollectionError``."""
        ...


class PageRenderer(Protocol):
    async def render(self, url: str, *, wait_for_selector: str | None = None) -> FetchedDocument:
        """Return the rendered DOM of an authorised JavaScript page, or raise a ``CollectionError``."""
        ...


class SourceAdapter(Protocol):
    async def collect(self, query: CollectionQuery) -> CollectionResult:
        """Collect raw listings.

        Per-URL problems (timeouts, denials, oversized responses, unparseable
        documents) are returned in ``CollectionResult.failures``; the adapter
        carries on with remaining URLs. Only an unusable configuration raises
        ``SourceConfigurationError``. Adapters never touch the database.
        """
        ...
