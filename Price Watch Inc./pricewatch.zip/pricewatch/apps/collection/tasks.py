"""Celery tasks. Thin wrappers: all logic lives in ``pipeline``."""
from __future__ import annotations

from datetime import timedelta

from celery import shared_task

from apps.core.clock import system_clock
from apps.core.logging import get_logger
from apps.suppliers.models import SourceConfiguration

from .models import CollectionRun
from .pipeline import run_collection

logger = get_logger("collection.tasks")


@shared_task(name="apps.collection.tasks.collect_source", ignore_result=True)
def collect_source(source_id: int, trigger: str = CollectionRun.Trigger.SCHEDULE) -> int | None:
    config = SourceConfiguration.objects.select_related("supplier").filter(pk=source_id).first()
    if config is None:
        logger.warning("collect_source: unknown source", extra={"source_id": source_id})
        return None
    return run_collection(config, trigger=trigger).pk


def due_sources(now=None):
    """Active, collectable sources whose schedule interval has elapsed.

    Sources that keep failing back off: each consecutive failure doubles the
    wait (capped at 8x) so a broken supplier is not hammered.
    """
    now = now or system_clock.now()
    candidates = SourceConfiguration.objects.filter(status=SourceConfiguration.Status.ACTIVE).exclude(
        kind=SourceConfiguration.Kind.MANUAL
    )
    due = []
    for config in candidates:
        multiplier = min(2 ** config.consecutive_failures, 8)
        interval = timedelta(minutes=config.schedule_minutes * multiplier)
        if config.last_attempt_at is None or config.last_attempt_at + interval <= now:
            due.append(config)
    return due


@shared_task(name="apps.collection.tasks.collect_due_sources", ignore_result=True)
def collect_due_sources() -> int:
    due = due_sources()
    for config in due:
        collect_source.delay(config.pk)
    return len(due)
