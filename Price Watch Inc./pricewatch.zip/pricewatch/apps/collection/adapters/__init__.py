"""Source adapters. Each implements :class:`apps.collection.types.SourceAdapter`.

Adapters retrieve and extract; they never interpret values and never touch the
database. Add a new source type by subclassing :class:`BaseAdapter` and
registering it in ``ADAPTERS``.
"""
from __future__ import annotations

from typing import Mapping
from urllib.parse import urljoin, urlsplit

from bs4 import BeautifulSoup

from apps.extraction.feeds import FeedFormatError, parse_csv_feed, parse_json_feed
from apps.extraction.html import ExtractionConfigError, extract_with_selectors
from apps.extraction.structured import extract_json_ld
from apps.extraction.types import ExtractionMethod, RawListing

from ..types import (
    CollectionError,
    CollectionFailure,
    CollectionQuery,
    CollectionResult,
    Fetcher,
    FetchedDocument,
    PageRenderer,
    SourceConfigurationError,
    SourceSnapshot,
)

MAX_API_PAGES = 20


class BaseAdapter:
    def __init__(self, source: SourceSnapshot, fetcher: Fetcher, renderer: PageRenderer | None = None) -> None:
        self.source = source
        self.fetcher = fetcher
        self.renderer = renderer

    # -- hooks ---------------------------------------------------------------
    def request_headers(self) -> Mapping[str, str]:
        return {}

    async def retrieve(self, url: str) -> FetchedDocument:
        return await self.fetcher.fetch(url, headers=self.request_headers())

    def extract(self, document: FetchedDocument) -> list[RawListing]:
        raise NotImplementedError

    async def discover(self, urls: list[str], result: CollectionResult, limit: int) -> list[str]:
        """Optionally expand listing pages into product page URLs (same host only)."""
        selector = self.source.settings.get("link_selector")
        if not selector:
            return urls[:limit]
        found: list[str] = []
        for url in urls:
            try:
                page = await self.retrieve(url)
            except CollectionError as exc:
                result.failures.append(CollectionFailure(url, exc.__class__.__name__, str(exc)))
                continue
            host = urlsplit(page.final_url).hostname
            for anchor in BeautifulSoup(page.body, "lxml").select(selector, limit=500):
                href = anchor.get("href")
                if not href:
                    continue
                target = urljoin(page.final_url, href)
                if urlsplit(target).hostname == host and target not in found:
                    found.append(target)
        return found[:limit]

    # -- protocol --------------------------------------------------------------
    async def collect(self, query: CollectionQuery) -> CollectionResult:
        result = CollectionResult()
        urls = list(query.urls or self.source.entry_urls)
        if not urls:
            raise SourceConfigurationError(f"Source {self.source.key} has no entry URLs")
        for url in await self.discover(urls, result, query.max_documents):
            await self.collect_url(url, result)
        return result

    async def collect_url(self, url: str, result: CollectionResult) -> FetchedDocument | None:
        try:
            document = await self.retrieve(url)
        except CollectionError as exc:
            result.failures.append(CollectionFailure(url, exc.__class__.__name__, str(exc)))
            return None
        try:
            listings = self.extract(document)
        except ExtractionConfigError as exc:
            raise SourceConfigurationError(str(exc)) from exc
        except FeedFormatError as exc:
            result.documents.append(document)  # keep the evidence of what we received
            result.failures.append(CollectionFailure(url, exc.__class__.__name__, str(exc)))
            return document
        result.documents.append(document)
        result.listings.extend(listings)
        return document


class HtmlAdapter(BaseAdapter):
    """Static HTML with configured CSS selectors."""

    method = ExtractionMethod.CSS_SELECTOR

    def extract(self, document: FetchedDocument) -> list[RawListing]:
        config = self.source.settings.get("extraction")
        if not config:
            raise ExtractionConfigError("HTML source needs an 'extraction' selector configuration")
        return extract_with_selectors(document.body, document.final_url, config, self.method)


class StructuredDataAdapter(BaseAdapter):
    """Pages that embed schema.org JSON-LD."""

    method = ExtractionMethod.JSON_LD

    def extract(self, document: FetchedDocument) -> list[RawListing]:
        listings = extract_json_ld(document.body, document.final_url, self.method)
        if not listings:
            broken = RawListing(source_url=document.final_url)
            broken.errors.append("no schema.org Product found in structured data")
            return [broken]
        return listings


class BrowserAdapter(HtmlAdapter):
    """JavaScript-rendered pages, loaded in a bounded headless browser."""

    method = ExtractionMethod.BROWSER_DOM

    async def retrieve(self, url: str) -> FetchedDocument:
        if self.renderer is None:
            raise SourceConfigurationError("Browser source requires a page renderer")
        await self.fetcher.ensure_allowed(url)  # same URL safety and robots rules as plain HTTP
        return await self.renderer.render(url, wait_for_selector=self.source.settings.get("wait_for_selector"))

    async def discover(self, urls, result, limit):
        return urls[:limit]


class CsvFeedAdapter(BaseAdapter):
    def extract(self, document: FetchedDocument) -> list[RawListing]:
        return parse_csv_feed(document.body, document.final_url, self.source.settings)


class JsonFeedAdapter(BaseAdapter):
    method = ExtractionMethod.JSON_FIELD

    def extract(self, document: FetchedDocument) -> list[RawListing]:
        return parse_json_feed(document.body, document.final_url, self.source.settings, self.method)


class ApiAdapter(JsonFeedAdapter):
    """Supplier JSON API with a server-side credential and simple ``next`` pagination."""

    method = ExtractionMethod.API_FIELD

    def request_headers(self) -> Mapping[str, str]:
        if not self.source.credential:
            return {}
        header = self.source.settings.get("auth_header", "Authorization")
        scheme = self.source.settings.get("auth_scheme", "Bearer")
        return {header: f"{scheme} {self.source.credential}".strip()}

    async def collect(self, query: CollectionQuery) -> CollectionResult:
        import json

        result = CollectionResult()
        urls = list(query.urls or self.source.entry_urls)
        if not urls:
            raise SourceConfigurationError(f"Source {self.source.key} has no entry URLs")
        next_path = self.source.settings.get("next_path")
        for url in urls:
            host = urlsplit(url).hostname
            pages = 0
            current: str | None = url
            while current and pages < min(MAX_API_PAGES, query.max_documents):
                pages += 1
                document = await self.collect_url(current, result)
                current = None
                if document is not None and next_path:
                    try:
                        following = json.loads(document.body).get(next_path)
                    except (ValueError, AttributeError):
                        following = None
                    if isinstance(following, str) and following:
                        target = urljoin(document.final_url, following)
                        if urlsplit(target).hostname == host:  # pagination never leaves the API host
                            current = target
        return result


class ManualAdapter(BaseAdapter):
    async def collect(self, query: CollectionQuery) -> CollectionResult:
        raise SourceConfigurationError("Manual sources receive supplier submissions; there is nothing to collect")


ADAPTERS: dict[str, type[BaseAdapter]] = {
    "api": ApiAdapter,
    "csv_feed": CsvFeedAdapter,
    "json_feed": JsonFeedAdapter,
    "structured_data": StructuredDataAdapter,
    "html": HtmlAdapter,
    "browser": BrowserAdapter,
    "manual": ManualAdapter,
}


def build_adapter(source: SourceSnapshot, fetcher: Fetcher, renderer: PageRenderer | None = None) -> BaseAdapter:
    try:
        adapter_class = ADAPTERS[source.kind]
    except KeyError:
        raise SourceConfigurationError(f"No adapter for source kind {source.kind!r}") from None
    return adapter_class(source, fetcher, renderer)
