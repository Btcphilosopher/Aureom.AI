"""Deterministic parsers for prices, identifiers and attributes. Pure functions."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

from apps.pricing.types import TaxTreatment

from .types import Availability, Condition


class PriceParseError(ValueError):
    """The text cannot be read as exactly one unambiguous, non-negative price."""


@dataclass(frozen=True)
class ParsedPrice:
    amount: Decimal
    currency: str | None  # None when the text carries no currency marker


_SYMBOLS = {"£": "GBP", "€": "EUR", "$": "USD"}
_CODES = {"GBP", "EUR", "USD"}
_CODE_RE = re.compile(r"(?<![A-Za-z])(GBP|EUR|USD)(?![A-Za-z])", re.I)
_SPACES = dict.fromkeys(map(ord, "    '’"), None)
_DECIMAL_SEPARATOR = {"en-GB": ".", "en-US": ".", "en-IE": ".", "de-DE": ",", "fr-FR": ",", "es-ES": ",", "it-IT": ",", "nl-NL": ","}
MAX_PRICE = Decimal("10000000")


def decimal_separator_for(locale: str | None) -> str:
    return _DECIMAL_SEPARATOR.get(locale or "en-GB", ".")


def _grouped(digits: str, separator: str) -> bool:
    return re.fullmatch(rf"\d{{1,3}}(?:{re.escape(separator)}\d{{3}})+", digits) is not None


def parse_price(text: object, locale: str | None = "en-GB") -> ParsedPrice:
    """Parse one price. Raises :class:`PriceParseError` rather than guessing.

    Accepts ``£1,299.99``, ``1.299,99 €``, ``1 299,99``, ``GBP 99``, ``99p``.
    Rejects ranges, "from" prices, trailing junk, negative values, malformed
    digit grouping and anything with too many decimal places.
    """
    if text is None:
        raise PriceParseError("no price text")
    if isinstance(text, bool) or isinstance(text, float):
        raise PriceParseError("binary floats are not accepted as prices")
    if isinstance(text, (int, Decimal)):
        text = str(text)
    raw = str(text).strip()
    if not raw:
        raise PriceParseError("empty price text")
    if len(raw) > 40:
        raise PriceParseError("price text too long")

    currencies = {_SYMBOLS[ch] for ch in raw if ch in _SYMBOLS} | {m.upper() for m in _CODE_RE.findall(raw)}
    if len(currencies) > 1:
        raise PriceParseError(f"conflicting currency markers in {raw!r}")
    currency = next(iter(currencies), None)
    body = _CODE_RE.sub("", raw)
    for symbol in _SYMBOLS:
        body = body.replace(symbol, "")
    body = body.strip()

    pence = re.fullmatch(r"(\d{1,3})\s?p", body)
    if pence:
        return ParsedPrice(Decimal(pence.group(1)) / Decimal(100), currency or "GBP")

    if body.startswith("-") or body.startswith("−"):
        raise PriceParseError("negative price")
    digits = body.translate(_SPACES)
    if not digits or not re.fullmatch(r"[\d.,]+", digits):
        raise PriceParseError(f"not a single numeric price: {raw!r}")
    if re.search(r"\d\s+\d{1,2}(?!\d)", body) and not re.search(r"\d[\s  ]\d{3}", body):
        raise PriceParseError(f"ambiguous spacing in {raw!r}")

    decimal_sep = decimal_separator_for(locale)
    thousands_sep = "," if decimal_sep == "." else "."
    has_dot, has_comma = "." in digits, "," in digits
    integer_part, fraction = digits, ""

    if has_dot and has_comma:
        last = max(digits.rfind("."), digits.rfind(","))
        actual_decimal = digits[last]
        actual_thousands = "," if actual_decimal == "." else "."
        integer_part, fraction = digits[:last], digits[last + 1:]
        if actual_decimal in integer_part:
            raise PriceParseError(f"malformed separators in {raw!r}")
        if not _grouped(integer_part, actual_thousands):
            raise PriceParseError(f"malformed digit grouping in {raw!r}")
        integer_part = integer_part.replace(actual_thousands, "")
    elif has_dot or has_comma:
        separator = "." if has_dot else ","
        if digits.count(separator) > 1:
            if not _grouped(digits, separator):
                raise PriceParseError(f"malformed digit grouping in {raw!r}")
            integer_part = digits.replace(separator, "")
        else:
            head, tail = digits.split(separator)
            if not head or not tail:
                raise PriceParseError(f"malformed number in {raw!r}")
            if len(tail) == 3:
                # "1,299" / "1.299": thousands only if that is the locale's grouping character.
                if separator == thousands_sep and 1 <= len(head) <= 3:
                    integer_part = head + tail
                else:
                    raise PriceParseError(f"ambiguous or over-precise price {raw!r} for locale {locale}")
            elif len(tail) <= 2:
                integer_part, fraction = head, tail
            else:
                raise PriceParseError(f"too many decimal places in {raw!r}")
    if not integer_part.isdigit() or (fraction and not fraction.isdigit()) or len(fraction) > 2:
        raise PriceParseError(f"malformed number in {raw!r}")
    try:
        amount = Decimal(f"{integer_part}.{fraction or '0'}")
    except InvalidOperation as exc:  # pragma: no cover - guarded above
        raise PriceParseError(str(exc)) from exc
    if amount >= MAX_PRICE:
        raise PriceParseError("implausibly large price")
    return ParsedPrice(amount, currency)


def parse_percentage(text: object) -> Decimal | None:
    """'20%', '20', '0.2' -> Decimal('0.20'). None when unreadable."""
    if text is None or isinstance(text, (bool, float)):
        return None
    match = re.fullmatch(r"\s*(\d{1,2}(?:\.\d+)?)\s*(%?)\s*", str(text))
    if not match:
        return None
    value = Decimal(match.group(1))
    if match.group(2) or value >= 1:
        value = value / Decimal(100)
    return value if Decimal(0) <= value < Decimal(1) else None


_CONDITIONS = (
    (Condition.REFURBISHED, re.compile(r"refurb|renewed|reconditioned|remanufactured|grade\s?[abc]\b", re.I)),
    (Condition.OPEN_BOX, re.compile(r"open[\s-]?box|ex[\s-]?display", re.I)),
    (Condition.USED, re.compile(r"\bused\b|pre[\s-]?owned|second[\s-]?hand|usedcondition", re.I)),
    (Condition.NEW, re.compile(r"\bnew\b|newcondition", re.I)),
)


def parse_condition(text: object) -> Condition | None:
    if not text:
        return None
    value = str(text)
    for condition, pattern in _CONDITIONS:
        if pattern.search(value):
            return condition
    return None


def condition_from_title(title: str) -> Condition | None:
    """Only non-new conditions are inferred from a title; 'New' in a title is marketing."""
    found = parse_condition(title)
    return found if found in (Condition.REFURBISHED, Condition.USED, Condition.OPEN_BOX) else None


def parse_availability(text: object) -> Availability:
    if not text:
        return Availability.UNKNOWN
    value = str(text).lower().replace("_", " ")
    compact = re.sub(r"[^a-z]", "", value)
    if "outofstock" in compact or "soldout" in compact or "unavailable" in compact or "discontinued" in compact:
        return Availability.OUT_OF_STOCK
    if "preorder" in compact or "backorder" in compact:
        return Availability.PREORDER
    if "instock" in compact or "available" in compact or compact in {"yes", "true"}:
        return Availability.IN_STOCK
    return Availability.UNKNOWN


def parse_tax_treatment(text: object) -> TaxTreatment | None:
    if text is None or text == "":
        return None
    if isinstance(text, bool):
        return TaxTreatment.INCLUDED if text else TaxTreatment.EXCLUDED
    value = str(text).lower()
    if re.search(r"\b(ex|exc|excl|excluding|excludes|excluded|plus)\b\.?\s*(vat|tax)|\+\s*vat|^excluded$|^false$", value):
        return TaxTreatment.EXCLUDED
    if re.search(r"\b(inc|incl|including|includes|included)\b\.?\s*(vat|tax)|(vat|tax) included|^included$|^true$", value):
        return TaxTreatment.INCLUDED
    if re.search(r"zero[\s-]?rated|not applicable|exempt", value):
        return TaxTreatment.NOT_APPLICABLE
    return None


def parse_bool(text: object) -> bool | None:
    if isinstance(text, bool):
        return text
    if text is None:
        return None
    value = str(text).strip().lower()
    if value in {"1", "true", "yes", "y", "ja", "oui", "required", "members only", "member only"}:
        return True
    if value in {"0", "false", "no", "n", "nein", "non", "", "none", "not required"}:
        return False
    return None


def normalise_gtin(text: object) -> tuple[str | None, bool]:
    """Return ``(gtin, valid)``. A GTIN with a bad check digit is returned as ``(None, False)``."""
    if not text:
        return None, True
    digits = re.sub(r"[\s-]", "", str(text))
    if not digits.isdigit() or len(digits) not in (8, 12, 13, 14):
        return None, False
    body, check = digits[:-1], int(digits[-1])
    total = sum(int(d) * (3 if i % 2 == 0 else 1) for i, d in enumerate(reversed(body)))
    if (10 - total % 10) % 10 != check:
        return None, False
    return digits, True


def normalise_code(text: object) -> str:
    """Canonical form for MPN/model comparison: upper-case alphanumerics only."""
    return re.sub(r"[^A-Z0-9]", "", str(text or "").upper())


_CAPACITY = re.compile(r"(\d+(?:\.\d+)?)\s?(TB|GB|MB)\b", re.I)


def parse_capacity_gb(text: object) -> int | None:
    """'128GB' -> 128, '1 TB' -> 1024. None when not a clean capacity."""
    if text is None:
        return None
    if isinstance(text, int) and not isinstance(text, bool):
        return text if text > 0 else None
    match = _CAPACITY.search(str(text))
    if not match:
        return int(str(text)) if str(text).strip().isdigit() and int(str(text)) > 0 else None
    value = Decimal(match.group(1))
    unit = match.group(2).upper()
    gb = value * 1024 if unit == "TB" else value / 1024 if unit == "MB" else value
    return int(gb) if gb == gb.to_integral_value() and gb > 0 else None


_RAM_LABELLED = re.compile(r"(\d+)\s?GB\s*(?:RAM|memory)|(?:RAM|memory)[:\s]+(\d+)\s?GB", re.I)


def attributes_from_title(title: str) -> dict[str, int]:
    """Weak evidence only: capacities mentioned in a title."""
    found: dict[str, int] = {}
    ram = _RAM_LABELLED.search(title)
    remaining = title
    if ram:
        found["ram_gb"] = int(ram.group(1) or ram.group(2))
        remaining = title[: ram.start()] + " " + title[ram.end():]
    capacities = [c for c in (parse_capacity_gb(m.group(0)) for m in _CAPACITY.finditer(remaining)) if c]
    if len(capacities) == 1:
        found["storage_gb"] = capacities[0]
    elif len(capacities) == 2 and "ram_gb" not in found and capacities[0] != capacities[1]:
        found["ram_gb"], found["storage_gb"] = min(capacities), max(capacities)
    return found


def parse_datetime(text: object) -> datetime | None:
    if not text:
        return None
    try:
        value = datetime.fromisoformat(str(text).strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
