"""Turn a :class:`RawListing` into a typed :class:`NormalisedOffer`.

Interpretation is deterministic. Anything that cannot be read stays missing and,
where it matters for publication, raises a quarantine :class:`Issue`.
"""
from __future__ import annotations

import hashlib
import re
from decimal import Decimal
from typing import Any, Iterable
from urllib.parse import urljoin

from apps.core.text import clean_http_url, clean_text
from apps.pricing.types import Charge, ComponentStatus, InvalidOfferError, PriceTier, PromotionTerms, TaxTreatment
from apps.pricing.units import parse_pack

from .parsing import (
    PriceParseError,
    attributes_from_title,
    condition_from_title,
    normalise_gtin,
    parse_availability,
    parse_bool,
    parse_capacity_gb,
    parse_condition,
    parse_datetime,
    parse_percentage,
    parse_price,
    parse_tax_treatment,
)
from .types import (
    Condition,
    Evidence,
    ExtractionMethod,
    Issue,
    NormalisedListing,
    NormalisedOffer,
    RawListing,
    Severity,
    SourceDefaults,
)

# Supplier spec labels -> canonical attribute names.
_SPEC_ALIASES = {
    "storage": "storage_gb", "storage capacity": "storage_gb", "internal storage": "storage_gb",
    "capacity": "storage_gb", "storage_gb": "storage_gb", "ssd": "storage_gb",
    "ram": "ram_gb", "memory": "ram_gb", "ram_gb": "ram_gb",
    "colour": "colour", "color": "colour",
    "region": "region", "market": "region", "version": "region",
    "generation": "generation", "model year": "generation",
    "form": "product_form", "product form": "product_form", "product_form": "product_form",
    "organic": "organic", "screen size": "screen_inches", "screen": "screen_inches", "screen_inches": "screen_inches",
    "fat": "fat_level", "type": "product_form",
}
_FREE = re.compile(r"^\s*(free|free delivery|free shipping|included|£?0(\.00)?)\s*$", re.I)


def _split_list(value: Any) -> list[str]:
    if isinstance(value, (list, tuple)):
        items: Iterable[Any] = value
    else:
        items = re.split(r"[;|\n]|,(?!\d)", str(value))
    return [text for text in (clean_text(item, 80) for item in items) if text]


def _canonical_spec(name: str, value: str) -> tuple[str, Any] | None:
    key = _SPEC_ALIASES.get(clean_text(name, 60).lower())
    text = clean_text(value, 120)
    if not key or not text:
        return None
    if key in ("storage_gb", "ram_gb"):
        capacity = parse_capacity_gb(text)
        return (key, capacity) if capacity else None
    if key == "organic":
        flag = parse_bool(text)
        return (key, flag) if flag is not None else None
    if key == "region":
        return key, text.upper()
    if key == "screen_inches":
        match = re.search(r"\d+(\.\d+)?", text)
        return (key, match.group(0)) if match else None
    return key, text.lower()


def _money(value: Any, locale: str) -> Decimal | None:
    try:
        return parse_price(value, locale).amount
    except PriceParseError:
        return None


def normalise(raw: RawListing, defaults: SourceDefaults) -> NormalisedOffer:
    fields = raw.fields
    issues: list[Issue] = []
    evidence: dict[str, Evidence] = dict(raw.evidence)

    def default_evidence(name: str, value: object) -> None:
        evidence[name] = Evidence(name, ExtractionMethod.SOURCE_DEFAULT, defaults.config_locator, str(value), raw.source_url)

    # --- identity ----------------------------------------------------------
    title = clean_text(fields.get("title"), 300)
    if not title:
        issues.append(Issue("missing_title", "No product title could be extracted.", field="title"))
    brand = clean_text(fields.get("brand"), 100) or None
    mpn = clean_text(fields.get("mpn"), 60) or None
    model = clean_text(fields.get("model"), 100) or None
    gtin, gtin_valid = normalise_gtin(fields.get("gtin"))
    if not gtin_valid:
        issues.append(Issue("invalid_gtin", "GTIN failed its check digit and was discarded.", Severity.WARNING, "gtin"))
        evidence.pop("gtin", None)

    purchase_url = clean_http_url(urljoin(raw.source_url, str(fields.get("url") or "")) if fields.get("url") else raw.source_url)
    sku = clean_text(fields.get("sku"), 100)
    if not sku:
        sku = "url-" + hashlib.sha256((purchase_url or raw.source_url).encode()).hexdigest()[:16]

    condition = parse_condition(fields.get("condition"))
    if condition is None and title:
        condition = condition_from_title(title)
        if condition is not None:
            evidence["condition"] = Evidence("condition", ExtractionMethod.TITLE_PARSE, "title", title[:300], raw.source_url)
    if condition is None and defaults.condition is not None:
        condition = defaults.condition
        default_evidence("condition", condition.value)
    if condition is None:
        condition = Condition.UNKNOWN

    attributes: dict[str, Any] = {}
    sources: dict[str, str] = {}
    specs = fields.get("specs") if isinstance(fields.get("specs"), dict) else {}
    for name, value in specs.items():
        mapped = _canonical_spec(str(name), str(value))
        if mapped:
            attributes[mapped[0]], sources[mapped[0]] = mapped[1], "structured"
    for direct in ("product_form", "organic", "region", "generation"):
        if fields.get(direct) not in (None, "") and direct not in attributes:
            mapped = _canonical_spec(direct, str(fields[direct]))
            if mapped:
                attributes[mapped[0]], sources[mapped[0]] = mapped[1], "structured"
    for name, value in attributes_from_title(title).items():
        if name not in attributes:
            attributes[name], sources[name] = value, "title"

    included = frozenset(item.lower() for item in _split_list(fields["included"])) if fields.get("included") else None
    warranty = clean_text(fields.get("warranty"), 120) or None

    pack_count: int | None = None
    net_quantity = None
    if fields.get("pack_quantity") not in (None, ""):
        text = str(fields["pack_quantity"]).strip()
        if text.isdigit() and int(text) >= 1:
            pack_count = int(text)
        else:
            issues.append(Issue("unreadable_pack_quantity", f"Pack quantity {text[:30]!r} not understood.", Severity.WARNING, "pack_quantity"))
    pack = parse_pack(str(fields["net_quantity"])) if fields.get("net_quantity") else None
    if pack is None and fields.get("net_quantity"):
        issues.append(Issue("unreadable_quantity", "Net quantity not understood; unit price unavailable.", Severity.WARNING, "net_quantity"))
    if pack is not None:
        net_quantity = pack.item
        if pack_count is None:
            pack_count = pack.pack_count
        elif pack.pack_count not in (1, pack_count):
            issues.append(Issue("pack_conflict", "Pack count disagrees with the quantity text.", Severity.QUARANTINE, "pack_quantity"))

    listing = NormalisedListing(
        supplier_key=defaults.supplier_key, supplier_sku=sku, title=title, brand=brand, gtin=gtin, mpn=mpn,
        model=model, condition=condition, attributes=attributes, attribute_sources=sources, included=included,
        warranty=warranty, pack_count=pack_count, net_quantity=net_quantity, url=purchase_url,
    )

    # --- price -------------------------------------------------------------
    raw_price = "" if fields.get("price") is None else clean_text(fields.get("price"), 60)
    price: Decimal | None = None
    currency: str | None = None
    if not raw_price:
        issues.append(Issue("missing_price", "No price could be extracted.", field="price"))
    else:
        try:
            parsed = parse_price(fields.get("price"), defaults.locale)
            price, currency = parsed.amount, parsed.currency
        except PriceParseError as exc:
            issues.append(Issue("malformed_price", f"Price text {raw_price!r} rejected: {exc}", field="price"))
    if price is not None and price <= 0:
        issues.append(Issue("zero_price", "A zero price is treated as a parsing failure, not an offer.", field="price"))

    declared = clean_text(fields.get("currency"), 8).upper() or None
    if declared and not re.fullmatch(r"[A-Z]{3}", declared):
        issues.append(Issue("invalid_currency", f"Currency {declared!r} is not an ISO 4217 code.", field="currency"))
        declared = None
    if declared and currency and declared != currency:
        issues.append(Issue("currency_conflict", f"Price symbol implies {currency} but the currency field says {declared}.", field="currency"))
    currency = declared or currency
    if currency is None and defaults.currency:
        currency = defaults.currency
        default_evidence("currency", currency)
    if currency is None and price is not None:
        issues.append(Issue("missing_currency", "No currency stated and the source has no declared default.", field="currency"))

    # --- tax ---------------------------------------------------------------
    tax_treatment = parse_tax_treatment(fields.get("tax_treatment"))
    if tax_treatment is None and defaults.tax_treatment is not None:
        tax_treatment = defaults.tax_treatment
        default_evidence("tax_treatment", tax_treatment.value)
    tax_treatment = tax_treatment or TaxTreatment.UNKNOWN
    tax_rate = parse_percentage(fields.get("tax_rate"))
    if tax_rate is None and defaults.tax_rate is not None and tax_treatment is TaxTreatment.EXCLUDED:
        tax_rate = defaults.tax_rate
        default_evidence("tax_rate", tax_rate)

    # --- delivery ----------------------------------------------------------
    threshold = _money(fields.get("delivery_free_threshold"), defaults.locale) if fields.get("delivery_free_threshold") else None
    delivery_text = fields.get("delivery_cost")
    if delivery_text not in (None, ""):
        text = clean_text(delivery_text, 120)
        if _FREE.match(text):
            delivery = Charge("Delivery", ComponentStatus.ADDITIONAL, Decimal("0.00"), note="Free delivery")
        else:
            amount = _money(delivery_text, defaults.locale)
            if amount is None:
                delivery = Charge("Delivery", ComponentStatus.UNKNOWN, note=f"Supplier says: {text}")
            else:
                delivery = Charge("Delivery", ComponentStatus.ADDITIONAL, amount, free_threshold=threshold)
    elif defaults.delivery is not None:
        delivery = defaults.delivery
        default_evidence("delivery_cost", f"{delivery.status.value} {delivery.amount}")
    else:
        delivery = Charge("Delivery", ComponentStatus.UNKNOWN, note="Delivery cost not stated by supplier")

    # --- fees --------------------------------------------------------------
    fees: list[Charge] = []
    raw_fees = fields.get("fees")
    if isinstance(raw_fees, dict):
        raw_fees = [raw_fees]
    for entry in raw_fees if isinstance(raw_fees, list) else []:
        if not isinstance(entry, dict):
            continue
        label = clean_text(entry.get("label") or "Fee", 80)
        mandatory = parse_bool(entry.get("mandatory"))
        amount = _money(entry.get("amount"), defaults.locale) if entry.get("amount") not in (None, "") else None
        status = ComponentStatus.ADDITIONAL if amount is not None else ComponentStatus.UNKNOWN
        if str(entry.get("status", "")).lower() == "included":
            status, amount = ComponentStatus.INCLUDED, None
        fees.append(Charge(label, status, amount, mandatory=True if mandatory is None else mandatory))
    if fields.get("fee_amount") not in (None, ""):
        amount = _money(fields.get("fee_amount"), defaults.locale)
        label = clean_text(fields.get("fee_label") or "Mandatory fee", 80)
        fees.append(Charge(label, ComponentStatus.ADDITIONAL if amount is not None else ComponentStatus.UNKNOWN, amount))

    # --- tiers, promotions, conditions ---------------------------------------
    tiers: list[PriceTier] = []
    for entry in fields.get("tiers") if isinstance(fields.get("tiers"), list) else []:
        try:
            tiers.append(PriceTier(int(entry["min_quantity"]), parse_price(entry["price"], defaults.locale).amount))
        except (KeyError, TypeError, ValueError, InvalidOfferError):
            issues.append(Issue("unreadable_tier", "A quantity tier could not be read and was ignored.", Severity.WARNING, "tiers"))

    promotions: list[PromotionTerms] = []
    for entry in fields.get("promotions") if isinstance(fields.get("promotions"), list) else []:
        try:
            kind = str(entry.get("type", "fixed")).lower()
            value = parse_percentage(entry["value"]) * 100 if kind == "percent" else parse_price(entry["value"], defaults.locale).amount
            promotions.append(PromotionTerms(
                label=clean_text(entry.get("label") or "Discount", 80), discount_type=kind, value=Decimal(value),
                code=clean_text(entry.get("code"), 40) or None,
                membership_programme=clean_text(entry.get("membership"), 80) or None,
                min_spend=_money(entry.get("min_spend"), defaults.locale) if entry.get("min_spend") not in (None, "") else None,
                starts_at=parse_datetime(entry.get("starts_at")), ends_at=parse_datetime(entry.get("ends_at")),
            ))
        except (KeyError, TypeError, ValueError, AttributeError, InvalidOfferError):
            issues.append(Issue("unreadable_promotion", "A promotion could not be read and was ignored.", Severity.WARNING, "promotions"))

    membership_required: str | None = None
    flag = fields.get("membership_required")
    if flag not in (None, ""):
        parsed_flag = parse_bool(flag)
        if parsed_flag is True or (parsed_flag is None and clean_text(flag, 80)):
            named = clean_text(fields.get("membership_programme"), 80) or (clean_text(flag, 80) if parsed_flag is None else "")
            membership_required = named or defaults.membership_programme or "membership"

    minimum_order = _money(fields.get("min_order"), defaults.locale) if fields.get("min_order") not in (None, "") else None

    return NormalisedOffer(
        listing=listing, price=price, currency=currency, raw_price=raw_price, tax_treatment=tax_treatment,
        tax_rate=tax_rate, delivery=delivery, fees=tuple(fees), tiers=tuple(tiers), promotions=tuple(promotions),
        availability=parse_availability(fields.get("availability")), membership_required=membership_required,
        minimum_order_amount=minimum_order, effective_at=parse_datetime(fields.get("effective_date")),
        purchase_url=purchase_url, evidence={name: item.as_dict() for name, item in evidence.items()}, issues=issues,
    )
