"""Embedded structured data (schema.org JSON-LD ``Product``/``Offer``)."""
from __future__ import annotations

import json
from typing import Any, Iterator

from bs4 import BeautifulSoup

from .types import ExtractionMethod, RawListing

MAX_JSON_LD_BLOCKS = 50


def _as_list(value: Any) -> list:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _types(node: dict) -> set[str]:
    return {str(t).rsplit("/", 1)[-1] for t in _as_list(node.get("@type"))}


def _walk(node: Any, depth: int = 0) -> Iterator[dict]:
    if depth > 6:
        return
    if isinstance(node, list):
        for item in node:
            yield from _walk(item, depth + 1)
    elif isinstance(node, dict):
        if "Product" in _types(node):
            yield node
        for key in ("@graph", "mainEntity", "itemListElement", "item"):
            if key in node:
                yield from _walk(node[key], depth + 1)


def _name(value: Any) -> str | None:
    if isinstance(value, dict):
        value = value.get("name")
    return str(value) if value not in (None, "") else None


def _text(value: Any) -> str | None:
    if isinstance(value, (dict, list)) or value in (None, ""):
        return None
    return str(value)


def json_ld_products(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "lxml")
    products: list[dict] = []
    for script in soup.find_all("script", attrs={"type": "application/ld+json"})[:MAX_JSON_LD_BLOCKS]:
        try:
            data = json.loads(script.string or script.get_text() or "")
        except (json.JSONDecodeError, TypeError):
            continue  # malformed blocks are ignored, never repaired by guesswork
        products.extend(_walk(data))
    return products


def extract_json_ld(html: str, url: str, method: ExtractionMethod = ExtractionMethod.JSON_LD) -> list[RawListing]:
    """One :class:`RawListing` per Product × Offer found in JSON-LD."""
    listings: list[RawListing] = []
    for product in json_ld_products(html):
        offers = _as_list(product.get("offers"))
        expanded: list[dict] = []
        for offer in offers:
            if isinstance(offer, dict) and "AggregateOffer" in _types(offer):
                expanded.extend(o for o in _as_list(offer.get("offers")) if isinstance(o, dict))
            elif isinstance(offer, dict):
                expanded.append(offer)
        for index, offer in enumerate(expanded or [{}]):
            raw = RawListing(source_url=url)
            base = "Product"
            put = lambda name, value, path: raw.put(name, value, method, f"{base}.{path}")  # noqa: E731
            put("title", _text(product.get("name")), "name")
            put("brand", _name(product.get("brand")), "brand")
            for key in ("gtin", "gtin14", "gtin13", "gtin12", "gtin8"):
                if product.get(key) or offer.get(key):
                    put("gtin", _text(product.get(key) or offer.get(key)), key)
                    break
            put("mpn", _text(product.get("mpn") or offer.get("mpn")), "mpn")
            put("sku", _text(offer.get("sku") or product.get("sku")), "sku")
            put("model", _name(product.get("model")), "model")
            specs: dict[str, str] = {}
            for prop in _as_list(product.get("additionalProperty")):
                if isinstance(prop, dict) and prop.get("name") and prop.get("value") not in (None, ""):
                    specs[str(prop["name"])] = str(prop["value"])
            if specs:
                raw.put("specs", specs, method, f"{base}.additionalProperty", json.dumps(specs)[:300])
            if offer:
                opath = f"offers[{index}]"
                spec = offer.get("priceSpecification") if isinstance(offer.get("priceSpecification"), dict) else {}
                put("price", _text(offer.get("price") if offer.get("price") not in (None, "") else spec.get("price")), f"{opath}.price")
                put("currency", _text(offer.get("priceCurrency") or spec.get("priceCurrency")), f"{opath}.priceCurrency")
                put("condition", _text(offer.get("itemCondition") or product.get("itemCondition")), f"{opath}.itemCondition")
                put("availability", _text(offer.get("availability")), f"{opath}.availability")
                put("url", _text(offer.get("url") or product.get("url")), f"{opath}.url")
                put("effective_date", _text(offer.get("validFrom") or offer.get("priceValidFrom")), f"{opath}.validFrom")
                if isinstance(spec.get("valueAddedTaxIncluded"), bool):
                    put("tax_treatment", "included" if spec["valueAddedTaxIncluded"] else "excluded",
                        f"{opath}.priceSpecification.valueAddedTaxIncluded")
                shipping = offer.get("shippingDetails")
                if isinstance(shipping, dict) and isinstance(shipping.get("shippingRate"), dict):
                    rate = shipping["shippingRate"]
                    put("delivery_cost", _text(rate.get("value")), f"{opath}.shippingDetails.shippingRate.value")
                warranty = offer.get("warranty")
                if isinstance(warranty, dict):
                    put("warranty", _name(warranty) or _text(warranty.get("description")), f"{opath}.warranty")
            if raw.fields:
                listings.append(raw)
    return listings
