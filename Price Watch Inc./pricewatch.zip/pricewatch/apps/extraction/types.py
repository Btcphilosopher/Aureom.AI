"""Typed values passed between collection, extraction, validation and matching."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any, Mapping

from apps.pricing.types import Charge, PriceTier, PromotionTerms, TaxTreatment
from apps.pricing.units import Quantity


class ExtractionMethod(StrEnum):
    JSON_LD = "json_ld"
    CSS_SELECTOR = "css_selector"
    BROWSER_DOM = "browser_dom"
    CSV_COLUMN = "csv_column"
    JSON_FIELD = "json_field"
    API_FIELD = "api_field"
    MANUAL = "manual_submission"
    SOURCE_DEFAULT = "source_default"  # declared once in the source configuration
    TITLE_PARSE = "title_parse"  # weaker: inferred from the listing title
    LLM_SUGGESTION = "llm_suggestion"


class Condition(StrEnum):
    NEW = "new"
    REFURBISHED = "refurbished"
    USED = "used"
    OPEN_BOX = "open_box"
    UNKNOWN = "unknown"


class Availability(StrEnum):
    IN_STOCK = "in_stock"
    OUT_OF_STOCK = "out_of_stock"
    PREORDER = "preorder"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class Evidence:
    """Where a published value came from."""

    field: str
    method: ExtractionMethod
    locator: str  # selector, column name, JSON path or config key
    snippet: str  # the supporting raw text, truncated
    source_url: str

    def as_dict(self) -> dict[str, str]:
        return {
            "method": self.method.value,
            "locator": self.locator,
            "snippet": self.snippet,
            "source_url": self.source_url,
        }


@dataclass(frozen=True)
class FieldConflict:
    field: str
    first: str
    second: str
    detail: str


@dataclass
class RawListing:
    """Field strings exactly as extracted, before any interpretation."""

    source_url: str
    fields: dict[str, Any] = field(default_factory=dict)
    evidence: dict[str, Evidence] = field(default_factory=dict)
    conflicts: list[FieldConflict] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)  # e.g. "selector matched nothing: price"

    def put(self, name: str, value: Any, method: ExtractionMethod, locator: str, snippet: str | None = None) -> None:
        if value is None or value == "" or value == [] or value == {}:
            return
        self.fields[name] = value
        text = snippet if snippet is not None else str(value)
        self.evidence[name] = Evidence(name, method, locator, text[:300], self.source_url)


class Severity(StrEnum):
    QUARANTINE = "quarantine"  # must not be published without human review
    WARNING = "warning"  # published, but recorded


@dataclass(frozen=True)
class Issue:
    code: str
    message: str
    severity: Severity = Severity.QUARANTINE
    field: str = ""

    def as_dict(self) -> dict[str, str]:
        return {"code": self.code, "message": self.message, "severity": self.severity.value, "field": self.field}


@dataclass(frozen=True)
class NormalisedListing:
    """Supplier listing identity, as evidence for the matcher. Missing stays ``None``."""

    supplier_key: str
    supplier_sku: str
    title: str
    brand: str | None = None
    gtin: str | None = None
    mpn: str | None = None
    model: str | None = None
    condition: Condition = Condition.UNKNOWN
    attributes: Mapping[str, Any] = field(default_factory=dict)
    attribute_sources: Mapping[str, str] = field(default_factory=dict)  # "structured" | "title"
    included: frozenset[str] | None = None
    warranty: str | None = None
    pack_count: int | None = None
    net_quantity: Quantity | None = None  # per item in the pack
    url: str = ""


@dataclass
class NormalisedOffer:
    listing: NormalisedListing
    price: Decimal | None
    currency: str | None
    raw_price: str
    tax_treatment: TaxTreatment
    tax_rate: Decimal | None
    delivery: Charge
    fees: tuple[Charge, ...]
    tiers: tuple[PriceTier, ...]
    promotions: tuple[PromotionTerms, ...]
    availability: Availability
    membership_required: str | None
    minimum_order_amount: Decimal | None
    effective_at: datetime | None
    purchase_url: str
    evidence: dict[str, dict[str, str]]
    issues: list[Issue] = field(default_factory=list)

    @property
    def quarantined(self) -> bool:
        return any(issue.severity is Severity.QUARANTINE for issue in self.issues)


@dataclass(frozen=True)
class SourceDefaults:
    """Facts a source configuration asserts for every listing it yields.

    These are explicit, versioned declarations (for example "this supplier's
    terms state all prices include VAT"), recorded as evidence with method
    ``source_default`` — they are not guesses made per page.
    """

    supplier_key: str
    currency: str | None = None
    locale: str = "en-GB"
    tax_treatment: TaxTreatment | None = None
    tax_rate: Decimal | None = None
    condition: Condition | None = None
    delivery: Charge | None = None
    membership_programme: str | None = None
    config_locator: str = "source configuration"


@dataclass(frozen=True)
class PreviousObservation:
    price: Decimal
    currency: str
    gtin: str | None = None
