"""Configured HTML extraction with CSS selectors.

Selector configuration (stored, versioned, in ``SourceConfiguration.settings``)::

    {
      "item_selector": ".product",            # optional: several products per page
      "fields": {
        "title": {"selector": "h1.title"},
        "price": {"selector": ".price", "attr": "data-price", "regex": "..."},
        "included": {"selector": "ul.box li", "many": true}
      },
      "required": ["title", "price"],
      "specs": {"row": "table.specs tr", "key": "th", "value": "td"},
      "cross_check_structured_data": true
    }

A required selector that matches nothing is reported as a broken selector; it
never silently becomes an empty or zero value.
"""
from __future__ import annotations

import re
from typing import Any, Mapping

from bs4 import BeautifulSoup, Tag

from .parsing import PriceParseError, parse_price
from .structured import extract_json_ld
from .types import ExtractionMethod, FieldConflict, RawListing

MAX_ITEMS_PER_PAGE = 500


class ExtractionConfigError(ValueError):
    """The selector configuration itself is invalid."""


def _node_text(node: Tag, attr: str | None) -> str:
    if attr:
        value = node.get(attr)
        return " ".join(value) if isinstance(value, list) else (value or "")
    return node.get_text(" ", strip=True)


def _extract_field(scope: Tag, name: str, spec: Mapping[str, Any]) -> tuple[Any, str] | None:
    selector = spec.get("selector")
    if not selector:
        raise ExtractionConfigError(f"Field {name!r} has no selector")
    try:
        nodes = scope.select(selector, limit=50 if spec.get("many") else 1)
    except Exception as exc:  # soupsieve raises several types for invalid selectors
        raise ExtractionConfigError(f"Invalid selector for {name!r}: {selector!r}") from exc
    if not nodes:
        return None
    values = [_node_text(node, spec.get("attr")) for node in nodes]
    if spec.get("regex"):
        pattern = re.compile(spec["regex"])
        matched = []
        for value in values:
            match = pattern.search(value)
            if match:
                matched.append(match.group(1) if match.groups() else match.group(0))
        values = matched
        if not values:
            return None
    values = [v for v in values if v != ""]
    if not values:
        return None
    snippet = str(nodes[0])[:300]
    return (values if spec.get("many") else values[0]), snippet


def extract_with_selectors(
    html: str,
    url: str,
    config: Mapping[str, Any],
    method: ExtractionMethod = ExtractionMethod.CSS_SELECTOR,
) -> list[RawListing]:
    fields: Mapping[str, Mapping[str, Any]] = config.get("fields") or {}
    if not fields:
        raise ExtractionConfigError("Selector configuration defines no fields")
    required = list(config.get("required") or ["title", "price"])
    soup = BeautifulSoup(html, "lxml")

    item_selector = config.get("item_selector")
    if item_selector:
        scopes = soup.select(item_selector, limit=MAX_ITEMS_PER_PAGE)
        if not scopes:
            broken = RawListing(source_url=url)
            broken.errors.append(f"item selector matched nothing: {item_selector}")
            return [broken]
    else:
        scopes = [soup]

    structured = extract_json_ld(html, url) if config.get("cross_check_structured_data") else []
    listings: list[RawListing] = []
    for scope in scopes:
        raw = RawListing(source_url=url)
        for name, spec in fields.items():
            found = _extract_field(scope, name, spec)
            if found is None:
                if name in required:
                    raw.errors.append(f"selector matched nothing: {name} ({spec.get('selector')})")
                continue
            value, snippet = found
            raw.put(name, value, method, spec["selector"], snippet)
        spec_config = config.get("specs")
        if spec_config:
            specs: dict[str, str] = {}
            for row in scope.select(spec_config["row"], limit=200):
                key = row.select_one(spec_config["key"])
                value = row.select_one(spec_config["value"])
                if key and value and key.get_text(strip=True):
                    specs[key.get_text(" ", strip=True)] = value.get_text(" ", strip=True)
            if specs:
                raw.put("specs", specs, method, spec_config["row"], "; ".join(f"{k}={v}" for k, v in specs.items())[:300])
        if structured and not item_selector:
            _cross_check(raw, structured[0])
        listings.append(raw)
    return listings


def _cross_check(raw: RawListing, structured: RawListing) -> None:
    """Flag disagreement between visible values and embedded structured data."""
    visible, embedded = raw.fields.get("price"), structured.fields.get("price")
    if visible and embedded:
        try:
            a, b = parse_price(visible), parse_price(embedded)
        except PriceParseError:
            a = b = None
        if a and b and a.amount != b.amount:
            raw.conflicts.append(
                FieldConflict("price", str(visible), str(embedded),
                              f"Visible price {visible} disagrees with structured data price {embedded}")
            )
    for name in ("gtin", "mpn"):
        visible, embedded = raw.fields.get(name), structured.fields.get(name)
        if visible and embedded and re.sub(r"\W", "", str(visible)).upper() != re.sub(r"\W", "", str(embedded)).upper():
            raw.conflicts.append(
                FieldConflict(name, str(visible), str(embedded), f"Visible {name} disagrees with structured data")
            )
    # Structured data may fill gaps the selectors do not cover; provenance is kept per field.
    for name, value in structured.fields.items():
        if name not in raw.fields:
            raw.fields[name] = value
            raw.evidence[name] = structured.evidence[name]
