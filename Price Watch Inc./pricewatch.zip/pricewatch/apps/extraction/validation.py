"""Publication gate. Decides whether an observation is published or quarantined."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from .types import Issue, NormalisedOffer, PreviousObservation, RawListing, Severity


@dataclass(frozen=True)
class ValidationThresholds:
    suspicious_drop_ratio: Decimal = Decimal("0.50")  # > 50% cheaper than the last valid price
    suspicious_rise_ratio: Decimal = Decimal("3.00")  # > 3x the last valid price


def validate(
    offer: NormalisedOffer,
    raw: RawListing,
    previous: PreviousObservation | None = None,
    thresholds: ValidationThresholds = ValidationThresholds(),
) -> list[Issue]:
    """Return all issues (those already found during normalisation plus cross-checks)."""
    issues = list(offer.issues)

    for error in raw.errors:
        issues.append(Issue("broken_selector", f"Extraction rule failed: {error}", Severity.QUARANTINE))
    for conflict in raw.conflicts:
        issues.append(Issue("conflicting_data", conflict.detail, Severity.QUARANTINE, conflict.field))

    if offer.price is not None and offer.price > 0 and previous is not None and previous.currency == offer.currency:
        if offer.price < previous.price * (Decimal(1) - thresholds.suspicious_drop_ratio):
            issues.append(Issue(
                "suspicious_drop",
                f"Price fell from {previous.price} to {offer.price} {offer.currency} since the last valid check "
                f"(more than {thresholds.suspicious_drop_ratio * 100:.0f}%). Held for review.",
                Severity.QUARANTINE, "price",
            ))
        elif offer.price > previous.price * thresholds.suspicious_rise_ratio:
            issues.append(Issue(
                "suspicious_rise",
                f"Price rose from {previous.price} to {offer.price} {offer.currency} since the last valid check. Held for review.",
                Severity.QUARANTINE, "price",
            ))
    if previous is not None and previous.gtin and offer.listing.gtin and previous.gtin != offer.listing.gtin:
        issues.append(Issue(
            "identity_changed",
            f"GTIN for this supplier SKU changed from {previous.gtin} to {offer.listing.gtin}.",
            Severity.QUARANTINE, "gtin",
        ))

    seen: set[tuple[str, str]] = set()
    unique: list[Issue] = []
    for issue in issues:
        key = (issue.code, issue.message)
        if key not in seen:
            seen.add(key)
            unique.append(issue)
    return unique


def is_publishable(issues: list[Issue]) -> bool:
    return not any(issue.severity is Severity.QUARANTINE for issue in issues)
