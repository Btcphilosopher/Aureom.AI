"""CSV and JSON feeds, and JSON API payloads.

``field_map`` maps canonical field names to a column (CSV) or dotted path (JSON).
``spec_map`` maps specification names to columns/paths. Unmapped columns are ignored.
"""
from __future__ import annotations

import csv
import io
import json
from typing import Any, Mapping

from .html import ExtractionConfigError
from .types import ExtractionMethod, RawListing

MAX_FEED_ROWS = 20_000
MAX_FIELD_CHARS = 5_000

csv.field_size_limit(1_000_000)


class FeedFormatError(ValueError):
    """The feed could not be parsed at all (wrong format, missing mapped columns)."""


def parse_csv_feed(text: str, url: str, config: Mapping[str, Any]) -> list[RawListing]:
    field_map: Mapping[str, str] = config.get("field_map") or {}
    if not field_map:
        raise ExtractionConfigError("CSV feed configuration needs a field_map")
    spec_map: Mapping[str, str] = config.get("spec_map") or {}
    reader = csv.DictReader(io.StringIO(text.lstrip("﻿")), delimiter=config.get("delimiter", ","))
    header = [h.strip() for h in (reader.fieldnames or [])]
    missing = [column for column in field_map.values() if column not in header]
    if missing:
        raise FeedFormatError(f"Feed is missing mapped columns: {', '.join(sorted(missing))}")
    listings: list[RawListing] = []
    for number, row in enumerate(reader, start=2):
        if number - 1 > MAX_FEED_ROWS:
            raise FeedFormatError(f"Feed exceeds {MAX_FEED_ROWS} rows")
        row = {(k or "").strip(): (v or "").strip()[:MAX_FIELD_CHARS] for k, v in row.items() if k}
        if not any(row.values()):
            continue
        raw = RawListing(source_url=url)
        for name, column in field_map.items():
            raw.put(name, row.get(column), ExtractionMethod.CSV_COLUMN, f"row {number}, column {column}")
        specs = {spec: row[column] for spec, column in spec_map.items() if row.get(column)}
        if specs:
            raw.put("specs", specs, ExtractionMethod.CSV_COLUMN, f"row {number}", json.dumps(specs)[:300])
        listings.append(raw)
    return listings


def _dig(node: Any, path: str) -> Any:
    for part in path.split("."):
        if isinstance(node, dict):
            node = node.get(part)
        elif isinstance(node, list) and part.isdigit() and int(part) < len(node):
            node = node[int(part)]
        else:
            return None
    return node


def parse_json_items(
    payload: Any, url: str, config: Mapping[str, Any], method: ExtractionMethod = ExtractionMethod.JSON_FIELD
) -> list[RawListing]:
    field_map: Mapping[str, str] = config.get("field_map") or {}
    if not field_map:
        raise ExtractionConfigError("JSON source configuration needs a field_map")
    spec_map: Mapping[str, str] = config.get("spec_map") or {}
    items = _dig(payload, config["items_path"]) if config.get("items_path") else payload
    if not isinstance(items, list):
        raise FeedFormatError("JSON payload does not contain a list of items at the configured path")
    if len(items) > MAX_FEED_ROWS:
        raise FeedFormatError(f"Feed exceeds {MAX_FEED_ROWS} items")
    listings: list[RawListing] = []
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        raw = RawListing(source_url=url)
        for name, path in field_map.items():
            value = _dig(item, path)
            if isinstance(value, float):
                # JSON numbers arrive as binary floats; keep the literal text for exact Decimal parsing.
                value = repr(value)
            snippet = json.dumps(value, default=str)[:300] if isinstance(value, (dict, list)) else None
            raw.put(name, value, method, f"items[{index}].{path}", snippet)
        specs = {}
        for spec, path in spec_map.items():
            value = _dig(item, path)
            if value not in (None, ""):
                specs[spec] = str(value)
        if specs:
            raw.put("specs", specs, method, f"items[{index}]", json.dumps(specs)[:300])
        listings.append(raw)
    return listings


def parse_json_feed(
    text: str, url: str, config: Mapping[str, Any], method: ExtractionMethod = ExtractionMethod.JSON_FIELD
) -> list[RawListing]:
    try:
        # parse_float=str keeps prices exact: 105.10 never becomes 105.09999999999999
        payload = json.loads(text, parse_float=str)
    except json.JSONDecodeError as exc:
        raise FeedFormatError(f"Invalid JSON: {exc.msg}") from exc
    return parse_json_items(payload, url, config, method)
