"""Suppliers, their source configurations, listings and immutable price observations.

Three layers are deliberately separate:

* ``catalogue.ProductVariant``   – canonical identity (what the thing *is*)
* ``SupplierListing``            – a supplier's page/feed row (what they *call* it)
* ``OfferObservation``           – what we *saw* at a point in time (never edited)
"""
from __future__ import annotations

from decimal import Decimal

from django.conf import settings
from django.db import models
from django.db.models import Q


class ImmutableRecordError(Exception):
    """Raised when code tries to modify or delete an immutable historical record."""


class Supplier(models.Model):
    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        SUSPENDED = "suspended", "Suspended"

    name = models.CharField(max_length=120, unique=True)
    slug = models.SlugField(max_length=120, unique=True)
    website_url = models.URLField(max_length=300)
    # Hostnames customers may be redirected to. Outbound links are checked against this list.
    allowed_domains = models.JSONField(default=list)
    default_currency = models.CharField(max_length=3, default="GBP")
    membership_programme = models.CharField(max_length=80, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.ACTIVE)
    is_fixture = models.BooleanField(default=False, help_text="Fictional demonstration supplier.")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name


class SourceConfiguration(models.Model):
    class Kind(models.TextChoices):
        API = "api", "Supplier API"
        CSV_FEED = "csv_feed", "CSV feed"
        JSON_FEED = "json_feed", "JSON feed"
        STRUCTURED_DATA = "structured_data", "Embedded structured data"
        HTML = "html", "Configured HTML extraction"
        BROWSER = "browser", "Browser-rendered extraction"
        MANUAL = "manual", "Manual supplier submission"

    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        PAUSED = "paused", "Paused"
        BROKEN = "broken", "Broken (needs attention)"

    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name="sources")
    key = models.SlugField(max_length=80, unique=True)
    name = models.CharField(max_length=120)
    kind = models.CharField(max_length=20, choices=Kind.choices)
    entry_urls = models.JSONField(default=list, blank=True)
    settings = models.JSONField(default=dict, blank=True)  # selectors, field maps, declared defaults
    version = models.PositiveIntegerField(default=1)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.ACTIVE)
    # Why we are permitted to collect from this source (public page, feed agreement, ...).
    authorisation_basis = models.CharField(max_length=300)
    respect_robots = models.BooleanField(default=True)
    # Name of the environment variable holding the credential. The secret itself is never stored.
    credential_env_var = models.CharField(max_length=80, blank=True)
    schedule_minutes = models.PositiveIntegerField(default=360)
    freshness_hours = models.PositiveIntegerField(default=24)
    timeout_seconds = models.PositiveIntegerField(default=10)
    max_retries = models.PositiveSmallIntegerField(default=2)
    max_response_bytes = models.PositiveIntegerField(default=2_000_000)
    min_request_interval_ms = models.PositiveIntegerField(default=1000)
    cache_ttl_seconds = models.PositiveIntegerField(default=300)
    # Tracked separately: an attempt, a success and a failure are different facts.
    last_attempt_at = models.DateTimeField(null=True, blank=True)
    last_success_at = models.DateTimeField(null=True, blank=True)
    last_failure_at = models.DateTimeField(null=True, blank=True)
    last_failure_reason = models.CharField(max_length=300, blank=True)
    consecutive_failures = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["supplier__name", "name"]
        constraints = [
            models.CheckConstraint(condition=Q(timeout_seconds__gte=1) & Q(timeout_seconds__lte=120), name="source_timeout_bounds"),
            models.CheckConstraint(condition=Q(max_retries__lte=5), name="source_retry_bounds"),
            models.CheckConstraint(condition=Q(max_response_bytes__lte=50_000_000), name="source_size_bounds"),
        ]
        indexes = [models.Index(fields=["status", "last_attempt_at"])]

    def __str__(self) -> str:
        return f"{self.supplier.name}: {self.name} (v{self.version})"

    def save(self, *args, **kwargs):
        """Bump ``version`` whenever extraction-relevant configuration changes."""
        if self.pk:
            previous = type(self).objects.filter(pk=self.pk).values("settings", "entry_urls", "kind").first()
            if previous and (previous["settings"], previous["entry_urls"], previous["kind"]) != (
                self.settings, self.entry_urls, self.kind,
            ):
                self.version += 1
                if kwargs.get("update_fields") is not None:
                    kwargs["update_fields"] = set(kwargs["update_fields"]) | {"version"}
        super().save(*args, **kwargs)

    @property
    def has_failed_since_success(self) -> bool:
        if self.last_failure_at is None:
            return False
        return self.last_success_at is None or self.last_failure_at > self.last_success_at


class SupplierListing(models.Model):
    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        QUARANTINED = "quarantined", "Quarantined (no valid observation yet)"
        WITHDRAWN = "withdrawn", "Withdrawn"

    class Condition(models.TextChoices):
        NEW = "new", "New"
        REFURBISHED = "refurbished", "Refurbished"
        USED = "used", "Used"
        OPEN_BOX = "open_box", "Open box"
        UNKNOWN = "unknown", "Not stated"

    supplier = models.ForeignKey(Supplier, on_delete=models.PROTECT, related_name="listings")
    source_configuration = models.ForeignKey(SourceConfiguration, null=True, blank=True, on_delete=models.SET_NULL, related_name="listings")
    supplier_sku = models.CharField(max_length=100)
    url = models.URLField(max_length=1000, blank=True)
    title = models.CharField(max_length=300)
    brand = models.CharField(max_length=100, blank=True)
    gtin = models.CharField(max_length=14, blank=True)
    mpn = models.CharField(max_length=60, blank=True)
    model = models.CharField(max_length=100, blank=True)
    condition = models.CharField(max_length=12, choices=Condition.choices, default=Condition.UNKNOWN)
    attributes = models.JSONField(default=dict, blank=True)
    attribute_sources = models.JSONField(default=dict, blank=True)
    included_contents = models.JSONField(null=True, blank=True)
    warranty = models.CharField(max_length=120, blank=True)
    pack_count = models.PositiveIntegerField(null=True, blank=True)
    net_quantity = models.DecimalField(max_digits=12, decimal_places=3, null=True, blank=True)
    net_quantity_unit = models.CharField(max_length=10, blank=True)
    # Current accepted identity match (denormalised from matching.MatchDecision).
    variant = models.ForeignKey("catalogue.ProductVariant", null=True, blank=True, on_delete=models.SET_NULL, related_name="listings")
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.QUARANTINED)
    is_sponsored = models.BooleanField(default=False, help_text="Paid placement. Never affects organic ranking.")
    first_seen_at = models.DateTimeField()
    last_seen_at = models.DateTimeField()
    latest_valid_observation = models.ForeignKey("OfferObservation", null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    # We only know a change happened *between* two checks, so both ends are stored.
    last_price_change_observed_at = models.DateTimeField(null=True, blank=True)
    last_price_change_previous_check_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["supplier", "supplier_sku"], name="uniq_listing_per_supplier_sku")]
        indexes = [
            models.Index(fields=["variant", "status"]),
            models.Index(fields=["gtin"]),
            models.Index(fields=["supplier", "status"]),
        ]

    def __str__(self) -> str:
        return f"{self.supplier.name}: {self.title}"


class OfferObservation(models.Model):
    """One immutable observation of a listing's offer.

    ``observed_at`` is when *we* saw it. ``supplier_effective_at`` is the date
    the supplier declares (if any). Neither claims to be the moment the price
    actually changed. Rows are insert-only; the sole permitted update is the
    audited review transition performed by :func:`apps.suppliers.services.review_observation`.
    """

    class Status(models.TextChoices):
        VALID = "valid", "Valid (published)"
        QUARANTINED = "quarantined", "Quarantined for review"
        REJECTED = "rejected", "Rejected on review"

    class Availability(models.TextChoices):
        IN_STOCK = "in_stock", "In stock"
        OUT_OF_STOCK = "out_of_stock", "Out of stock"
        PREORDER = "preorder", "Pre-order"
        UNKNOWN = "unknown", "Not stated"

    class TaxTreatment(models.TextChoices):
        INCLUDED = "included", "Tax included"
        EXCLUDED = "excluded", "Tax excluded"
        UNKNOWN = "unknown", "Unknown"
        NOT_APPLICABLE = "not_applicable", "Not applicable"

    listing = models.ForeignKey(SupplierListing, on_delete=models.PROTECT, related_name="observations")
    collection_run = models.ForeignKey("collection.CollectionRun", on_delete=models.PROTECT, related_name="observations")
    source_document = models.ForeignKey("collection.SourceDocument", null=True, blank=True, on_delete=models.PROTECT, related_name="observations")
    observed_at = models.DateTimeField()
    supplier_effective_at = models.DateTimeField(null=True, blank=True)
    price_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    currency = models.CharField(max_length=3, blank=True)
    raw_price = models.CharField(max_length=60, blank=True)
    tax_treatment = models.CharField(max_length=14, choices=TaxTreatment.choices, default=TaxTreatment.UNKNOWN)
    tax_rate = models.DecimalField(max_digits=5, decimal_places=4, null=True, blank=True)
    availability = models.CharField(max_length=12, choices=Availability.choices, default=Availability.UNKNOWN)
    membership_programme = models.CharField(max_length=80, blank=True, help_text="Non-empty: membership is required to buy.")
    minimum_order_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    status = models.CharField(max_length=12, choices=Status.choices)
    issues = models.JSONField(default=list, blank=True)
    # Provenance for every published value.
    source_url = models.URLField(max_length=1000)
    extraction_method = models.CharField(max_length=30)
    configuration_version = models.PositiveIntegerField()
    evidence = models.JSONField(default=dict)
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    reviewed_at = models.DateTimeField(null=True, blank=True)
    review_note = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["-observed_at", "-id"]
        constraints = [
            # A published observation always has a positive price and a currency.
            models.CheckConstraint(
                condition=~Q(status="valid") | (Q(price_amount__gt=0) & ~Q(currency="")),
                name="valid_observation_has_positive_price",
            ),
            models.CheckConstraint(condition=Q(price_amount__isnull=True) | Q(price_amount__gte=0), name="observation_price_not_negative"),
        ]
        indexes = [
            models.Index(fields=["listing", "-observed_at"]),
            models.Index(fields=["status", "-observed_at"]),
        ]

    def __str__(self) -> str:
        return f"{self.listing_id} @ {self.observed_at:%Y-%m-%d %H:%M} {self.price_amount} {self.currency} [{self.status}]"

    def save(self, *args, **kwargs):
        if self.pk is not None and not self._state.adding:
            raise ImmutableRecordError("Offer observations are immutable; record a new observation instead.")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ImmutableRecordError("Offer observations are never deleted; they are the price history.")


class PriceComponent(models.Model):
    """A part of the payable total and its relationship to the item price."""

    class Kind(models.TextChoices):
        ITEM_TIER = "item_tier", "Quantity price"
        FEE = "fee", "Fee"
        DELIVERY = "delivery", "Delivery"

    class Status(models.TextChoices):
        INCLUDED = "included", "Included in price"
        ADDITIONAL = "additional", "Charged in addition"
        UNKNOWN = "unknown", "Unknown"
        NOT_APPLICABLE = "not_applicable", "Not applicable"

    observation = models.ForeignKey(OfferObservation, on_delete=models.CASCADE, related_name="components")
    kind = models.CharField(max_length=10, choices=Kind.choices)
    label = models.CharField(max_length=80)
    status = models.CharField(max_length=14, choices=Status.choices)
    amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    currency = models.CharField(max_length=3, blank=True)
    mandatory = models.BooleanField(default=True)
    min_quantity = models.PositiveIntegerField(default=1)  # item tiers
    free_threshold = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)  # delivery
    note = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ["id"]
        constraints = [
            models.CheckConstraint(condition=Q(amount__isnull=True) | Q(amount__gte=0), name="component_amount_not_negative"),
            models.CheckConstraint(condition=~Q(status="additional") | Q(amount__isnull=False), name="additional_component_has_amount"),
            models.CheckConstraint(condition=Q(min_quantity__gte=1), name="component_min_quantity_positive"),
        ]

    def save(self, *args, **kwargs):
        if self.pk is not None and not self._state.adding:
            raise ImmutableRecordError("Price components belong to an immutable observation.")
        super().save(*args, **kwargs)


class Promotion(models.Model):
    class DiscountType(models.TextChoices):
        FIXED = "fixed", "Fixed amount"
        PERCENT = "percent", "Percentage"

    observation = models.ForeignKey(OfferObservation, on_delete=models.CASCADE, related_name="promotions")
    label = models.CharField(max_length=80)
    discount_type = models.CharField(max_length=10, choices=DiscountType.choices)
    value = models.DecimalField(max_digits=12, decimal_places=2)
    code = models.CharField(max_length=40, blank=True)
    membership_programme = models.CharField(max_length=80, blank=True)
    min_spend = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    starts_at = models.DateTimeField(null=True, blank=True)
    ends_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["id"]
        constraints = [
            models.CheckConstraint(condition=Q(value__gt=Decimal("0")), name="promotion_value_positive"),
            models.CheckConstraint(condition=~Q(discount_type="percent") | Q(value__lte=100), name="promotion_percent_max_100"),
        ]

    def save(self, *args, **kwargs):
        if self.pk is not None and not self._state.adding:
            raise ImmutableRecordError("Promotions belong to an immutable observation.")
        super().save(*args, **kwargs)
