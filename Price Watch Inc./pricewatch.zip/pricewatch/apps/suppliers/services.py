"""Persisting observations (the only writers of listings and observations)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal

from django.conf import settings
from django.db import transaction

from apps.audit.services import record
from apps.core.clock import Clock, system_clock
from apps.extraction.normalise import normalise
from apps.extraction.types import Issue, NormalisedOffer, PreviousObservation, RawListing, SourceDefaults
from apps.extraction.validation import ValidationThresholds, is_publishable, validate
from apps.pricing.types import ComponentStatus

from .models import OfferObservation, PriceComponent, Promotion, SourceConfiguration, SupplierListing

IDENTITY_FIELDS = ("title", "brand", "gtin", "mpn", "model", "condition", "attributes", "included_contents", "pack_count",
                   "net_quantity", "net_quantity_unit")


def thresholds_from_settings() -> ValidationThresholds:
    config = settings.PRICEWATCH
    return ValidationThresholds(Decimal(config["SUSPICIOUS_DROP_RATIO"]), Decimal(config["SUSPICIOUS_RISE_RATIO"]))


@dataclass
class IngestResult:
    listing: SupplierListing
    observation: OfferObservation
    created_listing: bool
    identity_changed: bool
    price_changed: bool

    @property
    def published(self) -> bool:
        return self.observation.status == OfferObservation.Status.VALID


def _listing_values(offer: NormalisedOffer) -> dict:
    listing = offer.listing
    return {
        "title": listing.title or "(untitled listing)",
        "brand": listing.brand or "",
        "gtin": listing.gtin or "",
        "mpn": listing.mpn or "",
        "model": listing.model or "",
        "condition": listing.condition.value,
        "attributes": dict(listing.attributes),
        "attribute_sources": dict(listing.attribute_sources),
        "included_contents": sorted(listing.included) if listing.included is not None else None,
        "warranty": listing.warranty or "",
        "pack_count": listing.pack_count,
        "net_quantity": listing.net_quantity.value if listing.net_quantity else None,
        "net_quantity_unit": listing.net_quantity.unit if listing.net_quantity else "",
        "url": offer.purchase_url,
    }


def _primary_method(offer: NormalisedOffer) -> str:
    for name in ("price", "title", "sku"):
        if name in offer.evidence:
            return offer.evidence[name]["method"]
    return next((item["method"] for item in offer.evidence.values()), "unknown")


@transaction.atomic
def ingest_listing(
    *,
    source: SourceConfiguration,
    run,
    raw: RawListing,
    defaults: SourceDefaults,
    observed_at: datetime,
    document=None,
    extra_issues: list[Issue] | None = None,
    thresholds: ValidationThresholds | None = None,
) -> IngestResult:
    """Normalise, validate and store one raw listing as an immutable observation.

    A quarantined observation is stored (so reviewers can see it) but never
    becomes the listing's published price and never overwrites listing details.
    """
    offer = normalise(raw, defaults)
    values = _listing_values(offer)
    listing = (
        SupplierListing.objects.select_for_update(of=("self",))
        .filter(supplier=source.supplier, supplier_sku=offer.listing.supplier_sku)
        .select_related("latest_valid_observation")
        .first()
    )
    previous_obs = listing.latest_valid_observation if listing else None
    previous = None
    if previous_obs is not None:
        previous = PreviousObservation(previous_obs.price_amount, previous_obs.currency, listing.gtin or None)

    issues = validate(offer, raw, previous, thresholds or thresholds_from_settings())
    issues.extend(extra_issues or [])
    publishable = is_publishable(issues)

    created = listing is None
    if created:
        listing = SupplierListing(
            supplier=source.supplier, supplier_sku=offer.listing.supplier_sku, source_configuration=source,
            first_seen_at=observed_at, last_seen_at=observed_at, status=SupplierListing.Status.QUARANTINED, **values,
        )
        listing.save()

    observation = OfferObservation.objects.create(
        listing=listing,
        collection_run=run,
        source_document=document,
        observed_at=observed_at,
        supplier_effective_at=offer.effective_at,
        price_amount=offer.price,
        currency=offer.currency or "",
        raw_price=offer.raw_price,
        tax_treatment=offer.tax_treatment.value,
        tax_rate=offer.tax_rate,
        availability=offer.availability.value,
        membership_programme=offer.membership_required or "",
        minimum_order_amount=offer.minimum_order_amount,
        status=OfferObservation.Status.VALID if publishable else OfferObservation.Status.QUARANTINED,
        issues=[issue.as_dict() for issue in issues],
        source_url=raw.source_url,
        extraction_method=_primary_method(offer),
        configuration_version=run.configuration_version,
        evidence=offer.evidence,
    )
    currency = offer.currency or ""
    components = [
        PriceComponent(
            observation=observation, kind=PriceComponent.Kind.DELIVERY, label=offer.delivery.label,
            status=offer.delivery.status.value, amount=offer.delivery.amount, currency=currency,
            free_threshold=offer.delivery.free_threshold, note=offer.delivery.note[:200],
        )
    ]
    for fee in offer.fees:
        components.append(PriceComponent(
            observation=observation, kind=PriceComponent.Kind.FEE, label=fee.label, status=fee.status.value,
            amount=fee.amount if fee.status is ComponentStatus.ADDITIONAL else None, currency=currency,
            mandatory=fee.mandatory, note=fee.note[:200],
        ))
    for tier in offer.tiers:
        components.append(PriceComponent(
            observation=observation, kind=PriceComponent.Kind.ITEM_TIER, label=f"{tier.min_packs}+",
            status=PriceComponent.Status.ADDITIONAL, amount=tier.unit_price, currency=currency, min_quantity=tier.min_packs,
        ))
    PriceComponent.objects.bulk_create(components)
    Promotion.objects.bulk_create([
        Promotion(
            observation=observation, label=p.label, discount_type=p.discount_type, value=p.value, code=p.code or "",
            membership_programme=p.membership_programme or "", min_spend=p.min_spend, starts_at=p.starts_at, ends_at=p.ends_at,
        )
        for p in offer.promotions
    ])

    identity_changed = created
    price_changed = False
    listing.last_seen_at = observed_at
    listing.source_configuration = source
    if publishable:
        if not created:
            identity_changed = any(getattr(listing, name) != values[name] for name in IDENTITY_FIELDS)
            for name, value in values.items():
                setattr(listing, name, value)
        if previous_obs is not None and (previous_obs.price_amount, previous_obs.currency) != (offer.price, currency):
            price_changed = True
            listing.last_price_change_observed_at = observed_at
            listing.last_price_change_previous_check_at = previous_obs.observed_at
        listing.latest_valid_observation = observation
        listing.status = SupplierListing.Status.ACTIVE
    listing.save()
    if not publishable:
        record("observation.quarantined", observation, data={"issues": [i.code for i in issues], "listing": listing.pk}, at=observed_at)
    return IngestResult(listing, observation, created, identity_changed, price_changed)


@transaction.atomic
def review_observation(observation: OfferObservation, *, reviewer, release: bool, note: str = "", clock: Clock = system_clock) -> OfferObservation:
    """Human review of a quarantined observation: release it for publication, or reject it.

    The observed values are never altered; only the review status changes, and
    the change is audited.
    """
    if observation.status != OfferObservation.Status.QUARANTINED:
        raise ValueError("Only quarantined observations can be reviewed")
    now = clock.now()
    blocking = {"missing_price", "malformed_price", "zero_price", "missing_currency", "missing_title", "broken_selector"}
    codes = {issue.get("code") for issue in observation.issues}
    if release and (codes & blocking or not observation.price_amount or observation.price_amount <= 0 or not observation.currency):
        raise ValueError("This observation has no usable price and cannot be released; fix the source and re-collect")
    new_status = OfferObservation.Status.VALID if release else OfferObservation.Status.REJECTED
    OfferObservation.objects.filter(pk=observation.pk, status=OfferObservation.Status.QUARANTINED).update(
        status=new_status, reviewed_by=reviewer, reviewed_at=now, review_note=note[:300]
    )
    observation.refresh_from_db()
    if release:
        listing = SupplierListing.objects.select_for_update(of=("self",)).select_related("latest_valid_observation").get(pk=observation.listing_id)
        latest = listing.latest_valid_observation
        if latest is None or latest.observed_at <= observation.observed_at:
            if latest is not None and (latest.price_amount, latest.currency) != (observation.price_amount, observation.currency):
                listing.last_price_change_observed_at = observation.observed_at
                listing.last_price_change_previous_check_at = latest.observed_at
            listing.latest_valid_observation = observation
            listing.status = SupplierListing.Status.ACTIVE
            listing.save()
    record("observation.released" if release else "observation.rejected", observation, actor=reviewer, data={"note": note}, at=now)
    return observation
