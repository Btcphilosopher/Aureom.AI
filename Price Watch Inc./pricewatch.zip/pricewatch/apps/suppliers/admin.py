from django.contrib import admin

from .models import OfferObservation, PriceComponent, Promotion, SourceConfiguration, Supplier, SupplierListing


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ("name", "status", "membership_programme", "is_fixture")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(SourceConfiguration)
class SourceConfigurationAdmin(admin.ModelAdmin):
    list_display = ("key", "supplier", "kind", "status", "version", "last_success_at", "last_failure_at", "consecutive_failures")
    list_filter = ("kind", "status")
    readonly_fields = ("version", "last_attempt_at", "last_success_at", "last_failure_at", "last_failure_reason", "consecutive_failures")


@admin.register(SupplierListing)
class SupplierListingAdmin(admin.ModelAdmin):
    list_display = ("supplier", "supplier_sku", "title", "condition", "status", "variant", "is_sponsored", "last_seen_at")
    list_filter = ("supplier", "status", "condition", "is_sponsored")
    search_fields = ("title", "supplier_sku", "gtin", "mpn")
    raw_id_fields = ("variant", "latest_valid_observation")


class ReadOnlyAdmin(admin.ModelAdmin):
    """History is immutable: visible in the admin, never editable or deletable."""

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class ComponentInline(admin.TabularInline):
    model = PriceComponent
    extra = 0
    can_delete = False


class PromotionInline(admin.TabularInline):
    model = Promotion
    extra = 0
    can_delete = False


@admin.register(OfferObservation)
class OfferObservationAdmin(ReadOnlyAdmin):
    list_display = ("listing", "observed_at", "price_amount", "currency", "status", "extraction_method", "configuration_version")
    list_filter = ("status", "extraction_method")
    date_hierarchy = "observed_at"
    inlines = [ComponentInline, PromotionInline]
