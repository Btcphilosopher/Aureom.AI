"""Manual supplier submissions.

A submission goes through exactly the same normalisation, validation,
quarantine and matching as collected data. The submitted payload is stored as
the source document, so provenance is uniform across source types.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

from django.db import transaction

from apps.audit.services import record
from apps.collection.models import CollectionRun, SourceDocument
from apps.collection.pipeline import defaults_from_config
from apps.core.clock import Clock, system_clock
from apps.extraction.types import ExtractionMethod, RawListing
from apps.matching.services import match_listing

from .models import SourceConfiguration, Supplier
from .services import IngestResult, ingest_listing

SUBMISSION_FIELDS = (
    "title", "brand", "gtin", "mpn", "model", "condition", "specs", "price", "currency", "tax_treatment", "tax_rate",
    "delivery_cost", "delivery_free_threshold", "availability", "membership_required", "min_order", "url",
    "included", "warranty", "pack_quantity", "net_quantity", "effective_date", "fees", "promotions", "tiers",
)


class NoManualSourceError(Exception):
    """The supplier has no active manual-submission source configured."""


def manual_source_for(supplier: Supplier) -> SourceConfiguration:
    source = supplier.sources.filter(kind=SourceConfiguration.Kind.MANUAL, status=SourceConfiguration.Status.ACTIVE).first()
    if source is None:
        raise NoManualSourceError(f"{supplier.name} is not set up for manual submissions")
    return source


def submit_offer(supplier: Supplier, payload: Mapping[str, Any], *, actor, clock: Clock = system_clock) -> IngestResult:
    """Record a supplier-submitted listing and price as a new observation."""
    source = manual_source_for(supplier)
    now = clock.now()
    body = json.dumps(payload, sort_keys=True, default=str)
    url = f"{supplier.website_url.rstrip('/')}/#submission"
    with transaction.atomic():
        run = CollectionRun.objects.create(
            source_configuration=source, configuration_version=source.version, trigger=CollectionRun.Trigger.SUBMISSION,
            started_at=now,
        )
        document = SourceDocument.objects.create(
            collection_run=run, url=url, final_url=url, retrieval_method=SourceDocument.Method.SUBMISSION,
            fetched_at=now, content_type="application/json", content_sha256=hashlib.sha256(body.encode()).hexdigest(),
            byte_length=len(body.encode()), body=body,
        )
        raw = RawListing(source_url=url)
        raw.put("sku", payload.get("supplier_sku"), ExtractionMethod.MANUAL, "supplier_sku")
        for name in SUBMISSION_FIELDS:
            value = payload.get(name)
            if isinstance(value, bool):
                value = "true" if value else "false"
            snippet = json.dumps(value, default=str)[:300] if isinstance(value, (dict, list)) else None
            raw.put(name, value, ExtractionMethod.MANUAL, name, snippet)
        result = ingest_listing(
            source=source, run=run, raw=raw, defaults=defaults_from_config(source), observed_at=now, document=document
        )
        run.status = CollectionRun.Status.SUCCEEDED
        run.finished_at = now
        run.documents_fetched = 1
        run.listings_seen = 1
        run.observations_valid = int(result.published)
        run.observations_quarantined = int(not result.published)
        run.save()
        SourceConfiguration.objects.filter(pk=source.pk).update(last_attempt_at=now, last_success_at=now, consecutive_failures=0)
        record("supplier.submission", result.observation, actor=actor, at=now,
               data={"supplier": supplier.slug, "sku": result.listing.supplier_sku, "status": result.observation.status})
    if result.published and (result.identity_changed or result.listing.variant_id is None):
        match_listing(result.listing, clock=clock)
        result.listing.refresh_from_db()
    return result
