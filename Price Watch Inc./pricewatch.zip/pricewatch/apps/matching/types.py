"""Typed values for like-for-like matching. No Django imports."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Mapping, Protocol

from apps.extraction.types import Condition, NormalisedListing
from apps.pricing.units import Quantity


class MatchMode(StrEnum):
    EXACT = "exact"  # same product, variant, condition and included contents
    SPEC_EQUIVALENT = "spec_equivalent"  # different products meeting explicit requirements
    UNIT_PRICE = "unit_price"  # compatible quantities, differences visible
    INSUFFICIENT = "insufficient_evidence"  # not eligible for definitive ranking


class MatchOutcome(StrEnum):
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    NEEDS_REVIEW = "needs_review"


@dataclass(frozen=True)
class Requirement:
    attribute: str
    op: str  # eq | ne | gte | lte | in
    value: Any

    def __post_init__(self) -> None:
        if self.op not in {"eq", "ne", "gte", "lte", "in"}:
            raise ValueError(f"Unsupported requirement operator: {self.op!r}")

    def describe(self) -> str:
        symbol = {"eq": "=", "ne": "≠", "gte": "≥", "lte": "≤", "in": "in"}[self.op]
        return f"{self.attribute.replace('_', ' ')} {symbol} {self.value}"


@dataclass(frozen=True)
class ProductSpecification:
    """What the customer (or a canonical variant) requires a listing to be."""

    key: str
    title: str
    brand: str | None = None
    model: str | None = None
    gtin: str | None = None
    mpn: str | None = None
    attributes: Mapping[str, Any] = field(default_factory=dict)
    identity_attributes: tuple[str, ...] = ()  # attributes that must agree for an exact match
    condition: Condition | None = None  # None: identity only, condition checked per request
    included: frozenset[str] | None = None
    warranty: str | None = None
    pack_count: int | None = None
    net_quantity: Quantity | None = None
    requirements: tuple[Requirement, ...] = ()
    mode: MatchMode = MatchMode.EXACT


@dataclass(frozen=True)
class Reason:
    code: str
    message: str
    attribute: str = ""
    strength: str = "structured"  # verified | structured | title

    def as_dict(self) -> dict[str, str]:
        return {"code": self.code, "message": self.message, "attribute": self.attribute, "strength": self.strength}


@dataclass(frozen=True)
class MatchResult:
    mode: MatchMode
    outcome: MatchOutcome
    reasons_for: tuple[Reason, ...] = ()
    reasons_against: tuple[Reason, ...] = ()
    unknowns: tuple[str, ...] = ()  # evidence we would need but do not have
    differences: tuple[str, ...] = ()  # visible, non-blocking differences
    candidate_score: float = 0.0  # title similarity; retrieval only, never proof

    @property
    def accepted(self) -> bool:
        return self.outcome is MatchOutcome.ACCEPTED


class ProductMatcher(Protocol):
    def evaluate(self, listing: NormalisedListing, product: ProductSpecification) -> MatchResult:
        """Pure evaluation; never raises for missing evidence (that yields INSUFFICIENT)."""
        ...
