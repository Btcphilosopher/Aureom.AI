from django.conf import settings
from django.db import models
from django.db.models import Q


class MatchDecision(models.Model):
    """Whether a supplier listing is a canonical variant, with the reasons.

    Decisions are versioned: a correction never edits a row, it inserts
    ``version + 1`` with ``supersedes`` pointing at the old row and flips
    ``is_current``. The full chain is the audit trail.
    """

    class Mode(models.TextChoices):
        EXACT = "exact", "Exact match"
        SPEC_EQUIVALENT = "spec_equivalent", "Specification equivalent"
        UNIT_PRICE = "unit_price", "Unit-price comparison"
        INSUFFICIENT = "insufficient_evidence", "Insufficient evidence"

    class Outcome(models.TextChoices):
        ACCEPTED = "accepted", "Accepted"
        REJECTED = "rejected", "Rejected"
        NEEDS_REVIEW = "needs_review", "Needs review"

    class DecidedBy(models.TextChoices):
        SYSTEM = "system", "Rules"
        HUMAN = "human", "Human reviewer"

    listing = models.ForeignKey("suppliers.SupplierListing", on_delete=models.CASCADE, related_name="match_decisions")
    variant = models.ForeignKey("catalogue.ProductVariant", on_delete=models.CASCADE, related_name="match_decisions")
    mode = models.CharField(max_length=24, choices=Mode.choices)
    outcome = models.CharField(max_length=12, choices=Outcome.choices)
    reasons_for = models.JSONField(default=list)
    reasons_against = models.JSONField(default=list)
    unknowns = models.JSONField(default=list)
    differences = models.JSONField(default=list)
    candidate_score = models.DecimalField(max_digits=5, decimal_places=4, default=0)
    matcher_version = models.CharField(max_length=30)
    decided_by = models.CharField(max_length=6, choices=DecidedBy.choices, default=DecidedBy.SYSTEM)
    reviewer = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="match_reviews")
    review_note = models.CharField(max_length=500, blank=True)
    version = models.PositiveIntegerField(default=1)
    supersedes = models.OneToOneField("self", null=True, blank=True, on_delete=models.PROTECT, related_name="superseded_by")
    is_current = models.BooleanField(default=True)
    created_at = models.DateTimeField()

    class Meta:
        ordering = ["-created_at", "-id"]
        constraints = [
            models.UniqueConstraint(fields=["listing", "variant"], condition=Q(is_current=True), name="one_current_decision_per_pair"),
            models.UniqueConstraint(fields=["listing", "variant", "version"], name="uniq_decision_version"),
            # A listing can be the accepted match for at most one variant at a time.
            models.UniqueConstraint(fields=["listing"], condition=Q(is_current=True, outcome="accepted"), name="one_accepted_variant_per_listing"),
            models.CheckConstraint(condition=~Q(decided_by="human") | Q(reviewer__isnull=False), name="human_decision_has_reviewer"),
        ]
        indexes = [models.Index(fields=["outcome", "is_current"]), models.Index(fields=["variant", "is_current"])]

    def __str__(self) -> str:
        return f"{self.listing_id}→{self.variant_id} v{self.version} {self.outcome}"
