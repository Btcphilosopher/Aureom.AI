from django.contrib import admin

from apps.suppliers.admin import ReadOnlyAdmin

from .models import MatchDecision


@admin.register(MatchDecision)
class MatchDecisionAdmin(ReadOnlyAdmin):
    """Read-only: decisions change only through the review workflow, which versions them."""

    list_display = ("listing", "variant", "mode", "outcome", "decided_by", "version", "is_current", "created_at")
    list_filter = ("outcome", "mode", "decided_by", "is_current")
