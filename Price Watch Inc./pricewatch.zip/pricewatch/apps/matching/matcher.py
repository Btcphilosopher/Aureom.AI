"""Rule-based like-for-like matcher.

Order of evidence:

1. Verified identifiers (GTIN with a valid check digit; MPN together with brand).
2. Required identity attributes for the category (storage, RAM, generation, region...).
3. Condition, included contents, pack size.
4. Title similarity — used only to *retrieve candidates*. It can never accept a match.

Any contradiction rejects an exact match. Missing evidence without a verified
identifier yields ``insufficient_evidence`` or a human-review request.
"""
from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation
from difflib import SequenceMatcher
from typing import Any, Iterable, Sequence

from apps.extraction.parsing import normalise_code
from apps.extraction.types import Condition, NormalisedListing

from .types import MatchMode, MatchOutcome, MatchResult, ProductSpecification, Reason, Requirement

MATCHER_VERSION = "rules-1"
CANDIDATE_THRESHOLD = 0.45

_LABELS = {
    "storage_gb": ("Storage", " GB"), "ram_gb": ("RAM", " GB"), "region": ("Region", ""),
    "generation": ("Generation", ""), "colour": ("Colour", ""), "product_form": ("Product form", ""),
    "screen_inches": ("Screen", '"'), "organic": ("Organic", ""), "fat_level": ("Fat level", ""),
}


def _label(attribute: str) -> str:
    return _LABELS.get(attribute, (attribute.replace("_", " ").capitalize(), ""))[0]


def _show(attribute: str, value: Any) -> str:
    if isinstance(value, bool):
        return "yes" if value else "no"
    return f"{value}{_LABELS.get(attribute, ('', ''))[1]}"


def _number(value: Any) -> Decimal | None:
    if isinstance(value, bool):
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None


def values_equal(a: Any, b: Any) -> bool:
    if isinstance(a, bool) or isinstance(b, bool):
        return a is b if isinstance(a, bool) and isinstance(b, bool) else str(a).lower() == str(b).lower()
    na, nb = _number(a), _number(b)
    if na is not None and nb is not None:
        return na == nb
    return re.sub(r"\s+", " ", str(a)).strip().lower() == re.sub(r"\s+", " ", str(b)).strip().lower()


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def title_similarity(a: str, b: str) -> float:
    """0..1 similarity for candidate retrieval only."""
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0
    jaccard = len(ta & tb) / len(ta | tb)
    ratio = SequenceMatcher(None, " ".join(sorted(ta)), " ".join(sorted(tb))).ratio()
    return round((jaccard + ratio) / 2, 4)


def requirement_met(requirement: Requirement, value: Any) -> bool | None:
    """True/False, or None when the listing does not state the attribute."""
    if value is None:
        return None
    if requirement.op == "eq":
        return values_equal(value, requirement.value)
    if requirement.op == "ne":
        return not values_equal(value, requirement.value)
    if requirement.op == "in":
        return any(values_equal(value, option) for option in requirement.value)
    left, right = _number(value), _number(requirement.value)
    if left is None or right is None:
        return None
    return left >= right if requirement.op == "gte" else left <= right


def condition_check(listing_condition: Condition | str, required: Condition | str) -> Reason | None:
    """Reason the listing fails a condition requirement, or None if it satisfies it."""
    have, want = Condition(listing_condition), Condition(required)
    if have is Condition.UNKNOWN:
        return Reason("condition_unknown", f"Supplier does not state the condition; you asked for {want.value}.", "condition")
    if have is not want:
        return Reason("condition_mismatch", f"Condition is {have.value.replace('_', ' ')}; you asked for {want.value}.", "condition")
    return None


class RuleBasedMatcher:
    """Deterministic implementation of :class:`apps.matching.types.ProductMatcher`."""

    version = MATCHER_VERSION

    def evaluate(self, listing: NormalisedListing, product: ProductSpecification) -> MatchResult:
        if product.mode is MatchMode.SPEC_EQUIVALENT:
            return self._evaluate_specification(listing, product)
        if product.mode is MatchMode.UNIT_PRICE:
            return self._evaluate_unit_price(listing, product)
        return self._evaluate_exact(listing, product)

    # ------------------------------------------------------------------ exact
    def _evaluate_exact(self, listing: NormalisedListing, product: ProductSpecification) -> MatchResult:
        supports: list[Reason] = []
        against: list[Reason] = []
        unknowns: list[str] = []
        differences: list[str] = []

        gtin_match = False
        if listing.gtin and product.gtin:
            if listing.gtin.lstrip("0") == product.gtin.lstrip("0"):
                gtin_match = True
                supports.append(Reason("gtin_match", f"GTIN {listing.gtin} matches.", "gtin", "verified"))
            else:
                against.append(Reason("gtin_conflict", f"GTIN {listing.gtin} differs from the product's {product.gtin}.", "gtin", "verified"))
        elif product.gtin:
            unknowns.append("gtin")

        brand_match = False
        if listing.brand and product.brand:
            if normalise_code(listing.brand) == normalise_code(product.brand):
                brand_match = True
                supports.append(Reason("brand_match", f"Brand {product.brand} matches.", "brand"))
            else:
                against.append(Reason("brand_mismatch", f"Brand is {listing.brand}, not {product.brand}.", "brand"))
        elif product.brand:
            unknowns.append("brand")

        mpn_match = False
        if listing.mpn and product.mpn:
            if normalise_code(listing.mpn) == normalise_code(product.mpn):
                mpn_match = True
                supports.append(Reason("mpn_match", f"Manufacturer part number {listing.mpn} matches.", "mpn", "verified"))
            else:
                against.append(Reason("mpn_conflict", f"Part number {listing.mpn} differs from {product.mpn}.", "mpn", "verified"))

        model_match = False
        if listing.model and product.model:
            if normalise_code(listing.model) == normalise_code(product.model):
                model_match = True
                supports.append(Reason("model_match", f"Model {product.model} matches.", "model"))
            else:
                against.append(Reason("model_mismatch", f"Model is {listing.model}, not {product.model}.", "model"))
        elif product.model:
            unknowns.append("model")

        for attribute in product.identity_attributes:
            wanted = product.attributes.get(attribute)
            if wanted is None:
                continue
            have = listing.attributes.get(attribute)
            source = listing.attribute_sources.get(attribute, "structured")
            if have is None:
                unknowns.append(attribute)
            elif values_equal(have, wanted):
                suffix = " (read from the title)" if source == "title" else ""
                supports.append(Reason("attribute_match", f"{_label(attribute)} {_show(attribute, have)} matches{suffix}.", attribute, source))
            else:
                against.append(Reason(
                    "attribute_mismatch",
                    f"{_label(attribute)}: listing is {_show(attribute, have)}, product is {_show(attribute, wanted)}.",
                    attribute, source,
                ))

        if product.condition is not None:
            failure = condition_check(listing.condition, product.condition)
            if failure is None:
                supports.append(Reason("condition_match", f"Condition {listing.condition.value} matches.", "condition"))
            elif failure.code == "condition_unknown":
                unknowns.append("condition")
            else:
                against.append(failure)

        if product.included is not None:
            if listing.included is None:
                unknowns.append("included_contents")
            else:
                missing = sorted(product.included - listing.included)
                extra = sorted(listing.included - product.included)
                if missing:
                    against.append(Reason("contents_missing", f"Does not include: {', '.join(missing)}.", "included_contents"))
                if extra:
                    against.append(Reason("contents_extra", f"Bundle adds: {', '.join(extra)} — not like-for-like.", "included_contents"))
                if not missing and not extra:
                    supports.append(Reason("contents_match", "Included contents match.", "included_contents"))

        if product.pack_count is not None and listing.pack_count is not None:
            if listing.pack_count == product.pack_count:
                supports.append(Reason("pack_match", f"Pack of {listing.pack_count} matches.", "pack_count"))
            else:
                against.append(Reason("pack_mismatch", f"Pack of {listing.pack_count}, product is a pack of {product.pack_count}.", "pack_count"))
        if product.net_quantity is not None and listing.net_quantity is not None:
            same_dimension = listing.net_quantity.dimension is product.net_quantity.dimension
            if same_dimension and listing.net_quantity.base_value == product.net_quantity.base_value:
                supports.append(Reason("quantity_match", f"Net quantity {listing.net_quantity} matches.", "net_quantity"))
            else:
                against.append(Reason("quantity_mismatch", f"Net quantity {listing.net_quantity}, product is {product.net_quantity}.", "net_quantity"))
        elif product.net_quantity is not None:
            unknowns.append("net_quantity")

        if product.warranty and listing.warranty and not values_equal(product.warranty, listing.warranty):
            differences.append(f"Warranty described as “{listing.warranty}” (product: “{product.warranty}”).")
        elif product.warranty and not listing.warranty:
            differences.append("Supplier does not describe the warranty.")

        score = title_similarity(listing.title, product.title)
        verified = gtin_match or (mpn_match and brand_match)
        # A verified identifier names the exact retail unit, so unknown attributes do not block it.
        blocking_unknowns = [u for u in unknowns if u == "condition"] if verified else unknowns

        if against:
            mode, outcome = MatchMode.EXACT, MatchOutcome.REJECTED
        elif verified and not blocking_unknowns:
            mode, outcome = MatchMode.EXACT, MatchOutcome.ACCEPTED
        elif not verified and brand_match and model_match and not unknowns_block_review(unknowns):
            # Attributes agree but no identifier proves it: a person must confirm.
            mode, outcome = MatchMode.EXACT, MatchOutcome.NEEDS_REVIEW
            supports.append(Reason("no_verified_identifier", "No GTIN or part number to verify; attributes agree. Needs human confirmation.", "", "structured"))
        else:
            mode, outcome = MatchMode.INSUFFICIENT, MatchOutcome.NEEDS_REVIEW
        return MatchResult(mode, outcome, tuple(supports), tuple(against), tuple(dict.fromkeys(unknowns)), tuple(differences), score)

    # ------------------------------------------------------- spec equivalent
    def _evaluate_specification(self, listing: NormalisedListing, product: ProductSpecification) -> MatchResult:
        supports: list[Reason] = []
        against: list[Reason] = []
        unknowns: list[str] = []
        for requirement in product.requirements:
            have = listing.attributes.get(requirement.attribute)
            if requirement.attribute == "brand":
                have = listing.brand
            met = requirement_met(requirement, have)
            source = listing.attribute_sources.get(requirement.attribute, "structured")
            if met is None:
                unknowns.append(requirement.attribute)
            elif met:
                supports.append(Reason("requirement_met", f"{_label(requirement.attribute)} {_show(requirement.attribute, have)} meets “{requirement.describe()}”.", requirement.attribute, source))
            else:
                against.append(Reason("requirement_failed", f"{_label(requirement.attribute)} {_show(requirement.attribute, have)} does not meet “{requirement.describe()}”.", requirement.attribute, source))
        if product.condition is not None:
            failure = condition_check(listing.condition, product.condition)
            if failure is None:
                supports.append(Reason("condition_match", f"Condition {listing.condition.value} matches.", "condition"))
            elif failure.code == "condition_unknown":
                unknowns.append("condition")
            else:
                against.append(failure)
        differences = ("Different products can appear here; only the stated requirements are guaranteed to be met.",)
        if against:
            return MatchResult(MatchMode.SPEC_EQUIVALENT, MatchOutcome.REJECTED, tuple(supports), tuple(against), tuple(unknowns), differences)
        if unknowns:
            return MatchResult(MatchMode.INSUFFICIENT, MatchOutcome.NEEDS_REVIEW, tuple(supports), (), tuple(unknowns), differences)
        return MatchResult(MatchMode.SPEC_EQUIVALENT, MatchOutcome.ACCEPTED, tuple(supports), (), (), differences)

    # ------------------------------------------------------------ unit price
    def _evaluate_unit_price(self, listing: NormalisedListing, product: ProductSpecification) -> MatchResult:
        supports: list[Reason] = []
        against: list[Reason] = []
        unknowns: list[str] = []
        differences: list[str] = []

        wanted_form = product.attributes.get("product_form")
        have_form = listing.attributes.get("product_form")
        if wanted_form is not None:
            if have_form is None:
                unknowns.append("product_form")
            elif values_equal(have_form, wanted_form):
                supports.append(Reason("form_match", f"Product form “{have_form}” matches.", "product_form"))
            else:
                against.append(Reason("form_mismatch", f"Product form is “{have_form}”, not “{wanted_form}”.", "product_form"))

        if listing.net_quantity is None:
            unknowns.append("net_quantity")
        elif product.net_quantity is not None and listing.net_quantity.dimension is not product.net_quantity.dimension:
            against.append(Reason("dimension_mismatch", f"Sold by {listing.net_quantity.dimension.value}; comparison is by {product.net_quantity.dimension.value}.", "net_quantity"))
        else:
            supports.append(Reason("quantity_comparable", f"Quantity {listing.net_quantity} per item can be compared by unit price.", "net_quantity"))
            if product.net_quantity is not None and listing.net_quantity.base_value != product.net_quantity.base_value:
                differences.append(f"Different size: {listing.net_quantity} per item.")
        if listing.pack_count and listing.pack_count > 1:
            differences.append(f"Multipack of {listing.pack_count}.")

        for requirement in product.requirements:
            have = listing.brand if requirement.attribute == "brand" else listing.attributes.get(requirement.attribute)
            met = requirement_met(requirement, have)
            if met is None:
                unknowns.append(requirement.attribute)
            elif met:
                supports.append(Reason("requirement_met", f"Meets your requirement: {requirement.describe()}.", requirement.attribute))
            else:
                against.append(Reason("requirement_failed", f"Does not meet your requirement: {requirement.describe()}.", requirement.attribute))

        if product.brand and listing.brand and normalise_code(product.brand) != normalise_code(listing.brand):
            differences.append(f"Different brand: {listing.brand}.")

        if against:
            return MatchResult(MatchMode.UNIT_PRICE, MatchOutcome.REJECTED, tuple(supports), tuple(against), tuple(unknowns), tuple(differences))
        if unknowns:
            return MatchResult(MatchMode.INSUFFICIENT, MatchOutcome.NEEDS_REVIEW, tuple(supports), (), tuple(unknowns), tuple(differences))
        return MatchResult(MatchMode.UNIT_PRICE, MatchOutcome.ACCEPTED, tuple(supports), (), (), tuple(differences))


def unknowns_block_review(unknowns: Sequence[str]) -> bool:
    """Without an identifier, every identity attribute must be stated; a missing GTIN alone is fine."""
    return any(u not in ("gtin", "included_contents") for u in unknowns)


def retrieve_candidates(
    listing: NormalisedListing,
    products: Iterable[ProductSpecification],
    limit: int = 5,
    threshold: float = CANDIDATE_THRESHOLD,
) -> list[tuple[ProductSpecification, float]]:
    """Shortlist specifications worth evaluating. Fuzzy text only *retrieves*; it never decides."""
    scored: list[tuple[ProductSpecification, float]] = []
    for product in products:
        if listing.gtin and product.gtin and listing.gtin.lstrip("0") == product.gtin.lstrip("0"):
            scored.append((product, 1.0))
            continue
        if listing.mpn and product.mpn and normalise_code(listing.mpn) == normalise_code(product.mpn):
            scored.append((product, 0.95))
            continue
        if listing.brand and product.brand and normalise_code(listing.brand) != normalise_code(product.brand):
            continue
        score = title_similarity(listing.title, product.title)
        if listing.brand and product.brand:
            score = min(0.9, score + 0.1)
        if score >= threshold:
            scored.append((product, score))
    scored.sort(key=lambda pair: (-pair[1], pair[0].key))
    return scored[:limit]

