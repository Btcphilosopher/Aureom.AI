"""Database side of matching: build specifications, store versioned decisions, human review."""
from __future__ import annotations

from decimal import Decimal

from django.db import transaction
from django.db.models import Q

from apps.audit.services import record
from apps.catalogue.models import ProductVariant
from apps.core.clock import Clock, system_clock
from apps.extraction.types import Condition, NormalisedListing
from apps.pricing.units import Quantity, UnknownUnitError
from apps.suppliers.models import SupplierListing

from .matcher import MATCHER_VERSION, RuleBasedMatcher, retrieve_candidates
from .models import MatchDecision
from .types import MatchMode, MatchOutcome, MatchResult, ProductMatcher, ProductSpecification, Requirement


def _quantity(value, unit) -> Quantity | None:
    if value is None or not unit:
        return None
    try:
        return Quantity(Decimal(value), unit)
    except (UnknownUnitError, ValueError):
        return None


def listing_to_normalised(listing: SupplierListing) -> NormalisedListing:
    return NormalisedListing(
        supplier_key=listing.supplier.slug,
        supplier_sku=listing.supplier_sku,
        title=listing.title,
        brand=listing.brand or None,
        gtin=listing.gtin or None,
        mpn=listing.mpn or None,
        model=listing.model or None,
        condition=Condition(listing.condition),
        attributes=listing.attributes or {},
        attribute_sources=listing.attribute_sources or {},
        included=frozenset(listing.included_contents) if listing.included_contents is not None else None,
        warranty=listing.warranty or None,
        pack_count=listing.pack_count,
        net_quantity=_quantity(listing.net_quantity, listing.net_quantity_unit),
        url=listing.url,
    )


def spec_from_variant(
    variant: ProductVariant,
    *,
    condition: Condition | None = None,
    mode: MatchMode = MatchMode.EXACT,
    requirements: tuple[Requirement, ...] = (),
) -> ProductSpecification:
    product = variant.product
    category = product.category
    return ProductSpecification(
        key=str(variant.pk),
        title=variant.display_name,
        brand=product.brand or None,
        model=product.model or None,
        gtin=variant.gtin or None,
        mpn=variant.mpn or None,
        attributes=variant.attributes or {},
        identity_attributes=tuple(category.identity_attributes or ()),
        condition=condition,
        included=frozenset(variant.included_contents) if variant.included_contents is not None else None,
        warranty=variant.warranty or None,
        pack_count=variant.pack_count if category.vertical == "grocery" else None,
        net_quantity=_quantity(variant.net_quantity, variant.net_quantity_unit),
        requirements=requirements,
        mode=mode,
    )


def _candidate_variants(listing: SupplierListing):
    query = Q()
    if listing.gtin:
        query |= Q(gtin=listing.gtin)
    if listing.mpn:
        query |= Q(mpn__iexact=listing.mpn)
    if listing.brand:
        query |= Q(product__brand__iexact=listing.brand)
    variants = ProductVariant.objects.filter(status=ProductVariant.Status.ACTIVE).select_related("product__category")
    return (variants.filter(query) if query else variants)[:500]


def _store(listing: SupplierListing, variant: ProductVariant, result: MatchResult, *, decided_by: str, now,
           reviewer=None, note: str = "") -> MatchDecision:
    """Insert a new decision version, superseding the current one for this pair."""
    current = MatchDecision.objects.select_for_update().filter(listing=listing, variant=variant, is_current=True).first()
    if current is not None:
        MatchDecision.objects.filter(pk=current.pk).update(is_current=False)
    return MatchDecision.objects.create(
        listing=listing, variant=variant, mode=result.mode.value, outcome=result.outcome.value,
        reasons_for=[r.as_dict() for r in result.reasons_for],
        reasons_against=[r.as_dict() for r in result.reasons_against],
        unknowns=list(result.unknowns), differences=list(result.differences),
        candidate_score=Decimal(str(result.candidate_score)).quantize(Decimal("0.0001")),
        matcher_version=MATCHER_VERSION, decided_by=decided_by, reviewer=reviewer, review_note=note[:500],
        version=(current.version + 1) if current else 1, supersedes=current, is_current=True, created_at=now,
    )


def _same(decision: MatchDecision, result: MatchResult) -> bool:
    return (
        decision.mode == result.mode.value
        and decision.outcome == result.outcome.value
        and decision.reasons_for == [r.as_dict() for r in result.reasons_for]
        and decision.reasons_against == [r.as_dict() for r in result.reasons_against]
    )


@transaction.atomic
def match_listing(listing: SupplierListing, *, clock: Clock = system_clock, matcher: ProductMatcher | None = None) -> list[MatchDecision]:
    """Evaluate a listing against candidate variants and store system decisions.

    Human decisions are never overwritten by the rules; they can only be changed
    by another human review.
    """
    matcher = matcher or RuleBasedMatcher()
    now = clock.now()
    listing = SupplierListing.objects.select_for_update(of=("self",)).select_related("supplier").get(pk=listing.pk)
    normalised = listing_to_normalised(listing)
    variants = {str(v.pk): v for v in _candidate_variants(listing)}
    specs = [spec_from_variant(v) for v in variants.values()]
    evaluated: list[tuple[ProductVariant, MatchResult]] = []
    for spec, _score in retrieve_candidates(normalised, specs):
        evaluated.append((variants[spec.key], matcher.evaluate(normalised, spec)))

    accepted = [pair for pair in evaluated if pair[1].outcome is MatchOutcome.ACCEPTED]
    if len(accepted) > 1:  # two variants cannot both be the same listing: ask a person
        evaluated = [
            (v, MatchResult(r.mode, MatchOutcome.NEEDS_REVIEW, r.reasons_for, r.reasons_against, r.unknowns,
                            r.differences + ("More than one variant matched; needs human confirmation.",), r.candidate_score))
            if r.outcome is MatchOutcome.ACCEPTED else (v, r)
            for v, r in evaluated
        ]
        accepted = []

    human_pairs = set(
        MatchDecision.objects.filter(listing=listing, is_current=True, decided_by=MatchDecision.DecidedBy.HUMAN)
        .values_list("variant_id", flat=True)
    )
    human_accept = MatchDecision.objects.filter(
        listing=listing, is_current=True, decided_by=MatchDecision.DecidedBy.HUMAN, outcome=MatchDecision.Outcome.ACCEPTED
    ).exists()

    decisions: list[MatchDecision] = []
    # Clear stale system acceptances first so the "one accepted variant" constraint holds.
    keep = {v.pk for v, r in evaluated if r.outcome is MatchOutcome.ACCEPTED}
    stale = MatchDecision.objects.filter(
        listing=listing, is_current=True, outcome=MatchDecision.Outcome.ACCEPTED, decided_by=MatchDecision.DecidedBy.SYSTEM
    ).exclude(variant_id__in=keep)
    for decision in stale:
        outdated = MatchResult(MatchMode.INSUFFICIENT, MatchOutcome.NEEDS_REVIEW, differences=("Listing details changed; earlier match no longer verified.",))
        decisions.append(_store(listing, decision.variant, outdated, decided_by=MatchDecision.DecidedBy.SYSTEM, now=now))

    for variant, result in evaluated:
        if variant.pk in human_pairs:
            continue
        if result.outcome is MatchOutcome.ACCEPTED and human_accept:
            continue  # a person already chose a variant for this listing
        current = MatchDecision.objects.filter(listing=listing, variant=variant, is_current=True).first()
        if current is not None and _same(current, result):
            decisions.append(current)
            continue
        decisions.append(_store(listing, variant, result, decided_by=MatchDecision.DecidedBy.SYSTEM, now=now))

    if not human_accept:
        new_variant = accepted[0][0] if accepted else None
        if listing.variant_id != (new_variant.pk if new_variant else None):
            listing.variant = new_variant
            listing.save(update_fields=["variant"])
    return decisions


@transaction.atomic
def review_decision(decision: MatchDecision, *, reviewer, accept: bool, note: str = "", clock: Clock = system_clock) -> MatchDecision:
    """Human review/correction. Always writes a new version; history is kept."""
    # Re-read under a lock: the caller's copy may be stale if someone else reviewed it meanwhile.
    decision = MatchDecision.objects.select_for_update(of=("self",)).select_related("variant").get(pk=decision.pk)
    if not decision.is_current:
        raise ValueError("Only the current decision for a listing/variant pair can be reviewed")
    now = clock.now()
    listing = SupplierListing.objects.select_for_update().get(pk=decision.listing_id)
    variant = decision.variant
    if accept:
        # Accepting this variant retires any other accepted variant for the listing.
        others = MatchDecision.objects.filter(
            listing=listing, is_current=True, outcome=MatchDecision.Outcome.ACCEPTED
        ).exclude(variant=variant)
        for other in others:
            retired = MatchResult(MatchMode(other.mode), MatchOutcome.REJECTED,
                                  differences=(f"Superseded: reviewer matched this listing to variant {variant.pk}.",))
            _store(listing, other.variant, retired, decided_by=MatchDecision.DecidedBy.HUMAN, now=now, reviewer=reviewer,
                   note="Superseded by correction")
    result = MatchResult(
        mode=MatchMode.EXACT if accept else MatchMode(decision.mode),
        outcome=MatchOutcome.ACCEPTED if accept else MatchOutcome.REJECTED,
    )
    new = _store(listing, variant, result, decided_by=MatchDecision.DecidedBy.HUMAN, now=now, reviewer=reviewer, note=note)
    # Keep the evidence the rules gathered alongside the human verdict.
    MatchDecision.objects.filter(pk=new.pk).update(
        reasons_for=decision.reasons_for, reasons_against=decision.reasons_against,
        unknowns=decision.unknowns, differences=decision.differences, candidate_score=decision.candidate_score,
    )
    new.refresh_from_db()
    if accept:
        listing.variant = variant
    elif listing.variant_id == variant.pk:
        listing.variant = None
    listing.save(update_fields=["variant"])
    record(
        "match.accepted" if accept else "match.rejected", new, actor=reviewer, at=now,
        data={"listing": listing.pk, "variant": variant.pk, "previous_version": decision.version,
              "previous_outcome": decision.outcome, "note": note},
    )
    return new
