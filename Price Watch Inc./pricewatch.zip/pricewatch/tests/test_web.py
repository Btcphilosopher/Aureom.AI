"""Website: rendering, honest labelling, and browser-facing security controls."""
import re
from decimal import Decimal

import pytest
from django.urls import reverse

from apps.accounts.models import CustomerMembership
from apps.alerts.models import PriceAlert
from apps.audit.models import AuditEvent, CorrectionRequest
from apps.comparisons.models import SavedSearch
from apps.matching.models import MatchDecision
from apps.suppliers.models import SupplierListing

from .support import collect, submit_clubtronics

pytestmark = pytest.mark.django_db
D = Decimal


def html(response) -> str:
    return response.content.decode()


def product_url(phone, **params):
    query = "&".join(f"{k}={v}" for k, v in {"variant": phone.pk, **params}.items())
    return f"/p/{phone.product.slug}/?{query}"


def test_public_pages_render(client, baseline):
    for url in ("/", "/search/", "/search/?q=aurora", "/c/smartphones/", "/c/laptops/?min_ram_gb=16&min_storage_gb=512",
                "/c/rice/?form=basmati&amount=2&unit=kg", "/basket/", "/accounts/login/", "/accounts/signup/",
                "/basket/?amount_rice=2&unit_rice=kg&form_rice=basmati&amount_eggs=12&unit_eggs=each"):
        response = client.get(url)
        assert response.status_code == 200, url
        assert "<h1" in html(response)
    assert "No products found" in html(client.get("/search/?q=zzzznotfound"))
    assert client.get("/p/does-not-exist/").status_code == 404
    assert "could not use those filters" in html(client.get("/c/rice/?amount=2&unit=furlongs"))


def test_product_page_shows_ranking_conditions_and_exclusions(client, baseline, phone, clock):
    page = html(client.get(product_url(phone)))
    assert "TechHaven is the cheapest complete offer you are eligible for: £403.99" in page
    assert "Cheapest eligible total" in page and "Conditional offers" in page
    assert "Requires ClubTronics Plus membership; we do not know whether you hold it." in page
    assert "Storage: listing is 256 GB, product is 128 GB." in page
    assert "Condition is refurbished; you asked for new." in page
    assert "Insufficient evidence" in page and "PixelPoint" in page
    assert "Includes: handset, usb-c cable" in page and "Contents not stated" in page
    assert "https://techhaven.fixture.test/products/aurora-x5-128.html" in page  # provenance is shown
    assert "Go to supplier" in page and "Price history" in page and "<svg" in page
    assert "Sponsored" not in page.split("<main")[1].split("</main>")[0]
    member = html(client.get(product_url(phone, m_clubtronics="held")))
    assert "ClubTronics is the cheapest complete offer you are eligible for: £385.00" in member


def test_stale_and_incomplete_states_are_labelled(client, baseline, phone, clock, reviewer):
    from apps.matching.services import review_decision

    pending = MatchDecision.objects.get(listing__supplier_sku="PP-778812", variant=phone, is_current=True)
    review_decision(pending, reviewer=reviewer, accept=True, clock=clock)
    clock.advance(hours=3)
    collect(clock, scenario="outage", only=["techhaven-html"])
    page = html(client.get(product_url(phone)))
    assert "Total incomplete" in page and "£389.00 + unknown costs" in page and "Delivery cost unknown." in page
    assert "Some prices are stale." in page and "The latest refresh failed; showing the last price we verified." in page
    assert page.count('<span class="tag tag-amber">Stale</span>') == 1


def test_sponsored_placement_is_labelled_and_separate(client, baseline, phone):
    SupplierListing.objects.filter(supplier_sku="OH-X5-128").update(is_sponsored=True)
    page = html(client.get(product_url(phone)))
    assert 'aria-label="Sponsored placement"' in page and "Paid placement. It does not affect the ranking below" in page
    ranked = page.split("Ranked offers:")[1]
    assert ranked.index("TechHaven") < ranked.index("Ohmly")  # the sponsor stays in its organic position
    assert 'rel="nofollow noopener sponsored"' in page


def test_htmx_request_returns_only_the_comparison_fragment(client, baseline, phone):
    fragment = html(client.get(product_url(phone, condition="refurbished"), HTTP_HX_REQUEST="true"))
    assert "<html" not in fragment and "Best offer for your requirements" in fragment
    assert "Ohmly is the cheapest complete offer you are eligible for: £338.50" in fragment


def test_pages_have_strict_csp_and_no_inline_script_or_style(client, baseline, phone):
    response = client.get(product_url(phone))
    policy = response["Content-Security-Policy"]
    assert "script-src 'self'" in policy and "unsafe-inline" not in policy and "frame-ancestors 'none'" in policy
    assert response["X-Content-Type-Options"] == "nosniff" and response["X-Frame-Options"] == "DENY"
    assert response["X-Request-ID"]
    page = html(response)
    assert not re.search(r"<script(?![^>]*\bsrc=)[^>]*>", page)  # every script is an external same-origin file
    assert not re.search(r"\sstyle=\"", page) and not re.search(r"\son[a-z]+=\"", page)


def test_supplier_text_cannot_inject_markup(client, baseline, phone, clock):
    clock.advance(hours=1)
    submit_clubtronics(clock, title='Lumio Aurora X5 128GB<img src=x onerror=alert(1)><script>alert(2)</script>',
                       warranty='"><svg onload=alert(3)>')
    page = html(client.get(product_url(phone)))
    assert "onerror" not in page and "alert(2)" not in page and "<svg onload" not in page
    assert "Lumio Aurora X5 128GB" in page


def test_outbound_redirect_only_goes_to_the_suppliers_own_domain(client, baseline):
    good = SupplierListing.objects.get(supplier_sku="TH-1001")
    response = client.get(f"/out/{good.pk}/")
    assert response.status_code == 302 and response["Location"] == "https://techhaven.fixture.test/products/aurora-x5-128.html"
    assert response["Referrer-Policy"] == "no-referrer"
    assert AuditEvent.objects.filter(action="outbound.click", target_id=str(good.pk)).exists()
    for bad in ("https://evil.example/phish", "https://techhaven.fixture.test.evil.example/", "javascript:alert(1)",
                "https://techhaven.fixture.test@evil.example/"):
        SupplierListing.objects.filter(pk=good.pk).update(url=bad)
        blocked = client.get(f"/out/{good.pk}/")
        assert blocked.status_code == 400 and "Location" not in blocked, bad
    assert client.get("/out/999999/").status_code == 404
    assert client.get(f"/out/{good.pk}/?next=https://evil.example").status_code == 400  # no caller-supplied target exists


def test_history_export_neutralises_spreadsheet_formulas(client, baseline, phone):
    SupplierListing.objects.filter(supplier_sku="TH-1001").update(title='=HYPERLINK("http://evil.example","Click")')
    response = client.get(f"/p/{phone.product.slug}/history.csv?variant={phone.pk}")
    assert response["Content-Type"].startswith("text/csv") and "attachment" in response["Content-Disposition"]
    rows = html(response).splitlines()
    assert rows[0] == "supplier,listing_title,condition,observed_at_utc,item_price,currency"
    techhaven = next(row for row in rows if row.startswith("TechHaven"))
    assert "'=HYPERLINK" in techhaven and ",=HYPERLINK" not in techhaven
    assert techhaven.endswith("2026-03-02T09:00:00Z,399.00,GBP")


def test_saved_lists_and_alerts_are_private_to_their_owner(client, baseline, phone, customer, other_customer, clock):
    assert client.get("/lists/").status_code == 302 and client.get("/alerts/").status_code == 302  # sign-in required
    client.force_login(customer)
    saved = client.post("/lists/", {"variant": phone.pk, "list_name": "Phones", "condition": "new", "quantity": "1",
                                    "next": "//evil.example/steal"})
    assert saved.status_code == 302 and saved["Location"] == reverse("web:lists")  # open redirect refused
    client.post("/alerts/", {"variant": phone.pk, "target_total": "400.00", "condition": "new", "quantity": "1",
                             "m_clubtronics": "not_held", "next": product_url(phone)})
    item, alert = SavedSearch.objects.get(), PriceAlert.objects.get()
    assert item.user == customer and alert.user == customer
    assert alert.requirements["memberships"] == {"clubtronics": "not_held"} and alert.target_total == D("400.00")
    page = html(client.get("/lists/"))
    assert "Phones" in page and "best eligible total £403.99 at TechHaven" in page

    client.force_login(other_customer)
    assert "Lumio" not in html(client.get("/lists/")) and "Lumio" not in html(client.get("/alerts/"))
    client.post("/lists/", {"action": "delete", "id": item.pk})
    client.post("/alerts/", {"action": "delete", "id": alert.pk})
    client.post("/alerts/", {"action": "pause", "id": alert.pk})
    assert SavedSearch.objects.filter(pk=item.pk).exists()
    alert.refresh_from_db()
    assert alert.status == "active"  # another account could neither delete nor pause it

    client.force_login(customer)
    client.post("/alerts/", {"action": "pause", "id": alert.pk})
    alert.refresh_from_db()
    assert alert.status == "paused"
    client.post("/alerts/", {"variant": phone.pk, "target_total": "abc"})
    assert PriceAlert.objects.count() == 1


def test_membership_answers_are_remembered_for_signed_in_customers(client, baseline, phone, customer):
    client.force_login(customer)
    client.get(product_url(phone, m_clubtronics="held"), HTTP_HX_REQUEST="true")
    assert CustomerMembership.objects.get(user=customer).status == "held"
    assert "ClubTronics is the cheapest complete offer" in html(client.get(product_url(phone)))
    client.get(product_url(phone, m_clubtronics="unknown"), HTTP_HX_REQUEST="true")
    assert not CustomerMembership.objects.filter(user=customer).exists()


def test_incorrect_information_report(client, baseline, phone):
    listing = SupplierListing.objects.get(supplier_sku="VM-X5-128")
    short = client.post("/report/", {"listing": listing.pk, "kind": "wrong_price", "description": "bad"})
    assert short.status_code == 400 and CorrectionRequest.objects.count() == 0
    ok = client.post("/report/", {"listing": listing.pk, "variant": phone.pk, "kind": "wrong_match",
                                  "description": "This is the EU model, not the UK one."})
    assert ok.status_code == 200 and "A reviewer will check this" in html(ok)
    report = CorrectionRequest.objects.get()
    assert (report.listing, report.variant, report.kind, report.status) == (listing, phone, "wrong_match", "open")


def test_csrf_is_enforced_on_state_changing_forms(baseline, phone, customer):
    from django.test import Client

    strict = Client(enforce_csrf_checks=True)
    strict.force_login(customer)
    assert strict.post("/alerts/", {"variant": phone.pk, "target_total": "400.00"}).status_code == 403
    assert strict.post("/report/", {"kind": "other", "description": "long enough description"}).status_code == 403
    assert PriceAlert.objects.count() == 0


def test_review_and_operations_are_staff_only(client, baseline, phone, customer, reviewer):
    for url in ("/review/", "/ops/"):
        assert client.get(url).status_code == 302
    client.force_login(customer)
    pending = MatchDecision.objects.get(listing__supplier_sku="PP-778812", variant=phone, is_current=True)
    for url in ("/review/", "/ops/"):
        assert client.get(url).status_code == 302  # signed in, but not staff
    assert client.post("/review/", {"kind": "match", "id": pending.pk, "verdict": "accept"}).status_code == 302
    pending.refresh_from_db()
    assert pending.is_current and pending.outcome == "needs_review"  # nothing changed

    client.force_login(reviewer)
    queue = html(client.get("/review/"))
    assert "Matches needing confirmation (1)" in queue and "PixelPoint" in queue
    assert "Quarantined price observations (2)" in queue and "malformed_price" in queue and "zero_price" in queue
    client.post("/review/", {"kind": "match", "id": pending.pk, "verdict": "accept", "note": "Verified on site"})
    current = MatchDecision.objects.get(listing__supplier_sku="PP-778812", variant=phone, is_current=True)
    assert (current.outcome, current.reviewer, current.version, current.review_note) == ("accepted", reviewer, 2, "Verified on site")
    operations = html(client.get("/ops/"))
    assert "Job history" in operations and "techhaven-html" in operations and "Healthy" in operations


def test_operator_can_queue_a_collection(client, baseline, reviewer, clock):
    from apps.collection.models import CollectionRun
    from apps.suppliers.models import SourceConfiguration

    client.force_login(reviewer)
    source = SourceConfiguration.objects.get(key="ohmly-csv")
    before = CollectionRun.objects.filter(source_configuration=source).count()
    clock.advance(hours=1)
    assert client.post("/ops/", {"source": source.pk}).status_code == 302  # Celery runs eagerly in tests
    assert CollectionRun.objects.filter(source_configuration=source).count() == before + 1
    manual = SourceConfiguration.objects.get(key="clubtronics-manual")
    client.post("/ops/", {"source": manual.pk})
    assert CollectionRun.objects.filter(source_configuration=manual, trigger="manual").count() == 0


def test_health_endpoints(client, db):
    assert client.get("/healthz").json() == {"status": "ok"}
    ready = client.get("/readyz")
    assert ready.status_code == 200 and ready.json()["checks"]["database"] == "ok" and ready.json()["checks"]["cache"] == "ok"


def test_signup_creates_a_non_staff_account(client, db, django_user_model):
    response = client.post("/accounts/signup/", {"username": "carol", "email": "carol@example.test",
                                                 "password1": "a-long-unique-pass-77", "password2": "a-long-unique-pass-77",
                                                 "is_staff": "on", "is_superuser": "on"})
    assert response.status_code == 302
    carol = django_user_model.objects.get(username="carol")
    assert not carol.is_staff and not carol.is_superuser  # privilege fields cannot be mass-assigned
    weak = client.post("/accounts/signup/", {"username": "dave", "password1": "12345", "password2": "12345"})
    assert weak.status_code == 200 and not django_user_model.objects.filter(username="dave").exists()
