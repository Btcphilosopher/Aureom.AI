from datetime import datetime, timezone
from decimal import Decimal

import pytest

from apps.pricing.basket import BasketItem, compare_basket
from apps.pricing.engine import DefaultPricingEngine
from apps.pricing.types import Charge, ComparisonContext, ComponentStatus, Offer, TaxTreatment
from apps.pricing.units import (
    IncompatibleUnitsError,
    Quantity,
    UnknownUnitError,
    packs_required,
    parse_pack,
    surplus,
    unit_price,
)

D = Decimal
NOW = datetime(2026, 3, 1, 12, 0, tzinfo=timezone.utc)


def q(value: str, unit: str) -> Quantity:
    return Quantity(D(value), unit)


# --- unit conversion -------------------------------------------------------------

def test_compatible_conversions():
    assert q("1.5", "kg").to("g").value == D("1500")
    assert q("750", "ml").to("l").value == D("0.75")
    assert q("4", "pints").to("ml").value == D("2273.045")
    assert q("2", "litres").unit == "l"


def test_dimension_mismatch_raises():
    with pytest.raises(IncompatibleUnitsError):
        q("500", "g").to("ml")
    with pytest.raises(IncompatibleUnitsError):
        packs_required(q("1", "kg"), q("1", "l"))
    with pytest.raises(IncompatibleUnitsError):
        unit_price(D("1.00"), q("1", "each"), q("100", "g"))


def test_unknown_unit_and_float_are_rejected():
    with pytest.raises(UnknownUnitError):
        q("1", "furlong")
    with pytest.raises(TypeError):
        Quantity(1.5, "kg")  # type: ignore[arg-type]


def test_packs_required_is_ceiling():
    assert packs_required(q("2", "kg"), q("500", "g")) == 4
    assert packs_required(q("2.1", "kg"), q("500", "g")) == 5
    assert packs_required(q("7", "each"), q("6", "each")) == 2
    assert surplus(q("7", "each"), q("6", "each"), 2) == D("5")
    assert surplus(q("2.1", "kg"), q("500", "g"), 5) == D("400")


def test_unit_price_per_100g():
    assert unit_price(D("2.40"), q("750", "g"), q("100", "g")) == D("0.3200")
    assert unit_price(D("1.55"), q("4", "pt"), q("1", "l")) == D("0.6819")


@pytest.mark.parametrize(
    "text,count,value,unit",
    [
        ("6 x 330ml", 6, "330", "ml"),
        ("500 g", 1, "500", "g"),
        ("1.5kg", 1, "1.5", "kg"),
        ("2 Litres", 1, "2", "l"),
        ("4 pints", 1, "4", "pt"),
        ("12 pack", 12, "1", "each"),
        ("Basmati Rice 1kg bag", 1, "1", "kg"),
        ("4×125g", 4, "125", "g"),
    ],
)
def test_parse_pack(text, count, value, unit):
    pack = parse_pack(text)
    assert pack is not None
    assert (pack.pack_count, pack.item.value, pack.item.unit) == (count, D(value), unit)


def test_parse_pack_missing_stays_missing():
    assert parse_pack("Family size") is None
    assert parse_pack("") is None


# --- pack maths in the engine ------------------------------------------------------

def _offer(key, supplier, price, pack, delivery="0.00", threshold=None, item="", minimum=None):
    return Offer(
        offer_id=key, supplier_key=supplier, supplier_name=supplier.title(), currency="GBP", unit_price=D(price),
        tax_treatment=TaxTreatment.INCLUDED, pack_size=pack, item_key=item,
        delivery=Charge("Delivery", ComponentStatus.ADDITIONAL, D(delivery), free_threshold=D(threshold) if threshold else None),
        minimum_order_amount=D(minimum) if minimum else None,
    )


def test_engine_reports_purchased_and_surplus():
    breakdown = DefaultPricingEngine().calculate(
        _offer("r", "s", "1.20", q("500", "g")), ComparisonContext(now=NOW, required_quantity=q("1.2", "kg"))
    )
    assert breakdown.packs == 3
    assert breakdown.purchased_quantity == q("1500", "g")
    assert breakdown.surplus_quantity == D("300")
    assert breakdown.total == D("3.60")


# --- baskets ------------------------------------------------------------------------

ITEMS = [BasketItem("milk", "Milk", q("2", "l")), BasketItem("rice", "Rice", q("1", "kg"))]


def test_delivery_counted_once_per_supplier_and_threshold_uses_supplier_basket():
    candidates = {
        "milk": [_offer("fm", "fresh", "1.50", q("2", "l"), "3.00", "4.00")],
        "rice": [_offer("fr", "fresh", "2.60", q("1", "kg"), "3.00", "4.00")],
    }
    result = compare_basket(ITEMS, candidates, ComparisonContext(now=NOW))
    plan = result.best_single_supplier
    assert plan is not None and plan.supplier_count == 1 and plan.delivery_count == 1
    # goods 4.10 reaches the 4.00 threshold only as a combined supplier basket
    assert plan.orders[0].goods_total == D("4.10")
    assert plan.orders[0].delivery == D("0.00")
    assert plan.total == D("4.10")


def test_heuristic_split_can_be_beaten_and_is_checked_against_exhaustive_search():
    # Greedy picks rice from B (cheapest goods) and pays a second delivery.
    candidates = {
        "milk": [_offer("am", "a", "1.50", q("2", "l"), "3.00"), _offer("bm", "b", "2.50", q("2", "l"), "3.00")],
        "rice": [_offer("ar", "a", "2.20", q("1", "kg"), "3.00"), _offer("br", "b", "2.00", q("1", "kg"), "3.00")],
    }
    result = compare_basket(ITEMS, candidates, ComparisonContext(now=NOW))
    assert result.baseline_split.total == D("9.50")  # 1.50 + 2.00 + two deliveries
    assert result.baseline_split.supplier_count == 2
    assert "not a guaranteed lowest total" in result.baseline_split.method_note
    # Hand-enumerated: AA=6.70, AB=9.50, BA=10.70, BB=7.50
    assert result.exhaustive_split.total == D("6.70")
    assert result.exhaustive_split.combinations_evaluated == 4
    assert result.exhaustive_split.total <= result.baseline_split.total
    assert result.best_single_supplier.total == D("6.70")


def test_exhaustive_search_matches_brute_force_on_small_examples():
    import itertools

    prices = {"a": ("1.00", "4.00", "2.00"), "b": ("1.40", "3.10", "2.60"), "c": ("0.90", "5.00", "1.80")}
    deliveries = {"a": ("2.50", "6.00"), "b": ("1.00", None), "c": ("3.00", None)}
    items = [BasketItem(f"i{n}", f"Item {n}", q("1", "each")) for n in range(3)]
    candidates = {
        f"i{n}": [_offer(f"{s}{n}", s, prices[s][n], q("1", "each"), *deliveries[s]) for s in prices] for n in range(3)
    }
    result = compare_basket(items, candidates, ComparisonContext(now=NOW))

    def brute(assignment):
        total = D(0)
        for supplier in set(assignment):
            goods = sum(D(prices[supplier][n]) for n, s in enumerate(assignment) if s == supplier)
            charge, threshold = deliveries[supplier]
            total += goods + (D(0) if threshold and goods >= D(threshold) else D(charge))
        return total

    expected = min(brute(a) for a in itertools.product(prices, repeat=3))
    assert result.exhaustive_split.total == expected
    assert result.exhaustive_split.combinations_evaluated == 27


def test_missing_items_are_reported_and_plan_is_not_complete():
    candidates = {"milk": [_offer("am", "a", "1.50", q("2", "l"))], "rice": []}
    result = compare_basket(ITEMS, candidates, ComparisonContext(now=NOW))
    assert result.best_single_supplier is None
    assert [i.key for i in result.single_supplier[0].missing_items] == ["rice"]
    assert not result.baseline_split.complete


def test_exhaustive_solver_is_skipped_beyond_its_documented_bound():
    candidates = {
        "milk": [_offer(f"m{n}", f"s{n}", "1.50", q("2", "l")) for n in range(5)],
        "rice": [_offer(f"r{n}", f"s{n}", "2.00", q("1", "kg")) for n in range(5)],
    }
    result = compare_basket(ITEMS, candidates, ComparisonContext(now=NOW), max_combinations=10)
    assert result.exhaustive_split is None and result.baseline_split is not None


def test_supplier_minimum_order_applies_to_that_suppliers_basket():
    candidates = {
        "milk": [_offer("am", "a", "1.50", q("2", "l"), minimum="10.00"), _offer("bm", "b", "1.80", q("2", "l"))],
        "rice": [_offer("br", "b", "2.00", q("1", "kg"))],
    }
    result = compare_basket(ITEMS, candidates, ComparisonContext(now=NOW))
    assert result.exhaustive_split.supplier_count == 1
    assert result.exhaustive_split.orders[0].supplier_key == "b"
