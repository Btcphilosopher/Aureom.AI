"""Unsafe URLs, redirect abuse, size limits, retries, robots and access controls. No network."""
import asyncio

import httpx
import pytest

from apps.collection.fetcher import HttpStatusError, SafeFetcher
from apps.collection.safety import check_url
from apps.collection.types import (
    AccessDeniedError,
    FetchPolicy,
    ResponseTooLargeError,
    RetryExhaustedError,
    RobotsDisallowedError,
    RobotsUnavailableError,
    TooManyRedirectsError,
    UnsafeUrlError,
)

PUBLIC = "93.184.216.34"
HOSTS = {"shop.example": [PUBLIC], "other.example": [PUBLIC], "rebind.example": [PUBLIC, "10.0.0.5"],
         "intranet.example": ["192.168.1.20"], "v6.example": ["::1"]}


def resolver(host):
    return HOSTS.get(host, [])


@pytest.mark.parametrize(
    "url",
    [
        "file:///etc/passwd",
        "ftp://shop.example/feed.csv",
        "gopher://shop.example/",
        "http://localhost/admin",
        "http://127.0.0.1/",
        "http://127.1/",
        "http://2130706433/",  # decimal form of 127.0.0.1
        "http://0x7f.0.0.1/",
        "http://[::1]/",
        "http://[::ffff:10.0.0.1]/",  # IPv4-mapped private address
        "http://169.254.169.254/latest/meta-data/",  # cloud metadata
        "http://10.1.2.3/",
        "http://172.16.0.9/",
        "http://192.168.0.1/",
        "http://100.64.0.1/",  # carrier-grade NAT
        "http://0.0.0.0/",
        "http://intranet.example/",  # resolves to a private address
        "http://rebind.example/",  # one of several addresses is private
        "http://v6.example/",
        "http://printer.local/",
        "http://db.internal/",
        "https://user:secret@shop.example/",  # embedded credentials
        "https://shop.example:8443/",  # port not allowed
        "https://shop.example:22/",
        "http://unresolvable.example/",
        "https:///nohost",
        "https://shop.example/\r\nHost: evil",
        "javascript:alert(1)",
    ],
)
def test_unsafe_urls_are_refused(url):
    with pytest.raises(UnsafeUrlError):
        check_url(url, resolver=resolver)


def test_public_urls_and_explicit_exemptions():
    assert check_url("https://shop.example/p/1?x=1", resolver=resolver).addresses == (PUBLIC,)
    assert check_url("http://8.8.8.8/", resolver=resolver).port == 80
    # An operator may exempt an exact hostname (e.g. an on-prem feed); nothing else is affected.
    exempt = frozenset({"intranet.example"})
    assert check_url("http://intranet.example:8080/feed", resolver=resolver, allowed_private_hosts=exempt).hostname == "intranet.example"
    with pytest.raises(UnsafeUrlError):
        check_url("http://sub.intranet.example/", resolver=resolver, allowed_private_hosts=exempt)


# --------------------------------------------------------------------------- fetcher

class Harness:
    """A SafeFetcher wired to a scripted transport, a fake sleep and a fake monotonic clock."""

    def __init__(self, handler, **policy):
        self.requests: list[httpx.Request] = []
        self.sleeps: list[float] = []
        self.time = 0.0
        self.cache: dict = {}
        self.handler = handler
        defaults = dict(user_agent="PriceWatchBot/1.0", max_retries=2, backoff_base_seconds=0.5, min_request_interval_seconds=0.0,
                        max_response_bytes=1000, cache_ttl_seconds=0)
        defaults.update(policy)
        self.policy = FetchPolicy(**defaults)

    def _handle(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        if request.url.path == "/robots.txt" and not getattr(self, "robots", None):
            return httpx.Response(404)
        if request.url.path == "/robots.txt":
            return self.robots(request)
        return self.handler(request)

    async def _sleep(self, seconds: float) -> None:
        self.sleeps.append(seconds)
        self.time += seconds

    def fetch(self, url, headers=None):
        class Cache:
            def get(inner, key):
                return self.cache.get(key)

            def set(inner, key, value, timeout):
                self.cache[key] = value

        async def run():
            fetcher = SafeFetcher(self.policy, transport=httpx.MockTransport(self._handle), resolver=resolver, sleep=self._sleep,
                                  monotonic=lambda: self.time, cache=Cache())
            async with fetcher:
                return await fetcher.fetch(url, headers=headers)

        return asyncio.run(run())

    @property
    def page_requests(self):
        return [r for r in self.requests if r.url.path != "/robots.txt"]


def test_successful_fetch_records_evidence():
    harness = Harness(lambda request: httpx.Response(200, text="<html>ok</html>", headers={"content-type": "text/html; charset=utf-8"}))
    document = harness.fetch("https://shop.example/p/1")
    assert document.status == 200 and document.body == "<html>ok</html>" and document.content_type == "text/html"
    assert len(document.sha256) == 64 and document.byte_length == 15
    assert harness.page_requests[0].headers["user-agent"] == "PriceWatchBot/1.0"


def test_transient_errors_retry_with_exponential_backoff_then_succeed():
    responses = iter([httpx.Response(503), httpx.Response(502), httpx.Response(200, text="ok")])
    harness = Harness(lambda request: next(responses))
    assert harness.fetch("https://shop.example/p/1").body == "ok"
    assert harness.sleeps == [0.5, 1.0]


def test_retries_are_bounded_and_failure_is_explicit():
    harness = Harness(lambda request: httpx.Response(503))
    with pytest.raises(RetryExhaustedError, match="HTTP 503.*after 3 attempt"):
        harness.fetch("https://shop.example/p/1")
    assert len(harness.page_requests) == 3


def test_retry_after_is_honoured_but_capped():
    responses = iter([httpx.Response(429, headers={"retry-after": "7"}), httpx.Response(429, headers={"retry-after": "9999"}),
                      httpx.Response(200, text="ok")])
    harness = Harness(lambda request: next(responses), backoff_max_seconds=30.0)
    harness.fetch("https://shop.example/p/1")
    assert harness.sleeps == [7.0, 30.0]


def test_timeouts_are_retried_then_reported():
    def handler(request):
        raise httpx.ReadTimeout("slow", request=request)

    harness = Harness(handler, max_retries=1)
    with pytest.raises(RetryExhaustedError, match="Timed out"):
        harness.fetch("https://shop.example/p/1")
    assert len(harness.page_requests) == 2


@pytest.mark.parametrize("status", [401, 403, 407, 451])
def test_access_controls_stop_the_fetch_without_retrying(status):
    harness = Harness(lambda request: httpx.Response(status))
    with pytest.raises(AccessDeniedError, match="not attempting to bypass"):
        harness.fetch("https://shop.example/account")
    assert len(harness.page_requests) == 1 and harness.sleeps == []


def test_challenge_pages_are_treated_as_access_denied():
    html = '<html><body><div class="g-recaptcha" data-sitekey="x"></div></body></html>'
    harness = Harness(lambda request: httpx.Response(200, text=html, headers={"content-type": "text/html"}))
    with pytest.raises(AccessDeniedError, match="challenge page"):
        harness.fetch("https://shop.example/p/1")
    assert len(harness.page_requests) == 1


def test_not_found_is_not_retried():
    harness = Harness(lambda request: httpx.Response(404))
    with pytest.raises(HttpStatusError):
        harness.fetch("https://shop.example/gone")
    assert len(harness.page_requests) == 1


def test_oversized_responses_are_abandoned():
    declared = Harness(lambda request: httpx.Response(200, headers={"content-length": "5000"}, content=b"x" * 5000))
    with pytest.raises(ResponseTooLargeError, match="declares 5000"):
        declared.fetch("https://shop.example/big")

    async def chunks():
        for _ in range(50):
            yield b"y" * 100

    streamed = Harness(lambda request: httpx.Response(200, content=chunks()))  # no content-length header
    with pytest.raises(ResponseTooLargeError, match="exceeded 1000 bytes"):
        streamed.fetch("https://shop.example/stream")


def test_redirect_to_private_network_is_blocked():
    harness = Harness(lambda request: httpx.Response(302, headers={"location": "http://169.254.169.254/latest/meta-data/"}))
    with pytest.raises(UnsafeUrlError):
        harness.fetch("https://shop.example/redirect")
    assert [r.url.host for r in harness.page_requests] == ["shop.example"]  # the private address was never contacted


def test_redirect_to_a_host_that_resolves_privately_is_blocked():
    harness = Harness(lambda request: httpx.Response(301, headers={"location": "http://intranet.example/feed"}))
    with pytest.raises(UnsafeUrlError):
        harness.fetch("https://shop.example/redirect")


def test_redirect_loops_are_bounded():
    harness = Harness(lambda request: httpx.Response(302, headers={"location": "/again"}), max_redirects=3)
    with pytest.raises(TooManyRedirectsError):
        harness.fetch("https://shop.example/start")
    assert len(harness.page_requests) == 4


def test_safe_redirects_are_followed_and_credentials_do_not_leak_across_hosts():
    def handler(request):
        if request.url.host == "shop.example":
            return httpx.Response(302, headers={"location": "https://other.example/landing"})
        return httpx.Response(200, text="landed")

    harness = Harness(handler)
    document = harness.fetch("https://shop.example/go", headers={"Authorization": "Bearer secret-token", "X-Trace": "1"})
    assert document.final_url == "https://other.example/landing" and document.url == "https://shop.example/go"
    first, second = harness.page_requests
    assert first.headers["authorization"] == "Bearer secret-token"
    assert "authorization" not in second.headers and second.headers["x-trace"] == "1"


def test_robots_txt_is_obeyed():
    harness = Harness(lambda request: httpx.Response(200, text="ok"))
    harness.robots = lambda request: httpx.Response(200, text="User-agent: *\nDisallow: /private/\n")
    assert harness.fetch("https://shop.example/public/1").body == "ok"
    with pytest.raises(RobotsDisallowedError):
        harness.fetch("https://shop.example/private/prices")
    ignoring = Harness(lambda request: httpx.Response(200, text="ok"), respect_robots=False)
    ignoring.robots = harness.robots
    assert ignoring.fetch("https://shop.example/private/prices").body == "ok"  # only by explicit, authorised configuration


def test_unreadable_robots_txt_means_do_not_collect():
    harness = Harness(lambda request: httpx.Response(200, text="ok"))
    harness.robots = lambda request: httpx.Response(503)
    with pytest.raises(RobotsUnavailableError):
        harness.fetch("https://shop.example/p/1")
    forbidden = Harness(lambda request: httpx.Response(200, text="ok"))
    forbidden.robots = lambda request: httpx.Response(403)
    with pytest.raises(RobotsDisallowedError):
        forbidden.fetch("https://shop.example/p/1")
    assert harness.page_requests == [] and forbidden.page_requests == []


def test_crawl_delay_and_minimum_interval_are_respected():
    harness = Harness(lambda request: httpx.Response(200, text="ok"), min_request_interval_seconds=0.2)
    harness.robots = lambda request: httpx.Response(200, text="User-agent: *\nCrawl-delay: 2\nAllow: /\n")

    async def run():
        fetcher = SafeFetcher(harness.policy, transport=httpx.MockTransport(harness._handle), resolver=resolver,
                              sleep=harness._sleep, monotonic=lambda: harness.time)
        async with fetcher:
            await fetcher.fetch("https://shop.example/a")
            await fetcher.fetch("https://shop.example/b")

    asyncio.run(run())
    # robots.txt is read first; its Crawl-delay (2s) then outranks the configured 0.2s between every request
    assert harness.sleeps == [2.0, 2.0]


def test_responses_are_cached_per_source():
    harness = Harness(lambda request: httpx.Response(200, text="ok"), cache_ttl_seconds=300)
    first = harness.fetch("https://shop.example/p/1")
    second = harness.fetch("https://shop.example/p/1")
    assert not first.from_cache and second.from_cache and second.body == "ok"
    assert len(harness.page_requests) == 1


def test_unsafe_entry_url_never_reaches_the_transport():
    harness = Harness(lambda request: httpx.Response(200, text="secret"))
    with pytest.raises(UnsafeUrlError):
        harness.fetch("http://127.0.0.1:80/admin")
    assert harness.requests == []
