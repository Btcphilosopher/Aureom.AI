"""Like-for-like matching: identifiers and attributes before titles. Pure."""
from decimal import Decimal

from apps.extraction.types import Condition, NormalisedListing
from apps.matching.matcher import RuleBasedMatcher, condition_check, retrieve_candidates, title_similarity
from apps.matching.types import MatchMode, MatchOutcome, ProductSpecification, Requirement
from apps.pricing.units import Quantity

matcher = RuleBasedMatcher()
BOX = frozenset({"handset", "usb-c cable"})

X5_128 = ProductSpecification(
    key="x5-128", title="Lumio Aurora X5 128GB", brand="Lumio", model="X5", gtin="5060999000011", mpn="LUM-X5-128",
    attributes={"storage_gb": 128, "ram_gb": 8, "region": "UK"}, identity_attributes=("storage_gb", "region"), included=BOX,
    warranty="2 year manufacturer warranty",
)
X5_256 = ProductSpecification(
    key="x5-256", title="Lumio Aurora X5 256GB", brand="Lumio", model="X5", gtin="5060999000028", mpn="LUM-X5-256",
    attributes={"storage_gb": 256, "ram_gb": 8, "region": "UK"}, identity_attributes=("storage_gb", "region"), included=BOX,
)


def listing(**kwargs) -> NormalisedListing:
    values = dict(supplier_key="s", supplier_sku="1", title="Lumio Aurora X5 128GB", brand="Lumio", model="X5",
                  condition=Condition.NEW, attributes={"storage_gb": 128, "region": "UK"},
                  attribute_sources={"storage_gb": "structured", "region": "structured"})
    values.update(kwargs)
    return NormalisedListing(**values)


def against(result):
    return {reason.code for reason in result.reasons_against}


def test_verified_gtin_is_an_exact_match():
    result = matcher.evaluate(listing(gtin="5060999000011", mpn="LUM-X5-128"), X5_128)
    assert (result.mode, result.outcome) == (MatchMode.EXACT, MatchOutcome.ACCEPTED)
    assert {"gtin_match", "mpn_match", "attribute_match"} <= {r.code for r in result.reasons_for}


def test_similar_title_with_different_storage_is_rejected():
    hidden = listing(title="Lumio Aurora X5 5G Smartphone", gtin="5060999000028", mpn="LUM-X5-256",
                     attributes={"storage_gb": 256, "region": "UK"})
    assert title_similarity(hidden.title, X5_128.title) > 0.4  # similar enough to be retrieved...
    result = matcher.evaluate(hidden, X5_128)
    assert result.outcome is MatchOutcome.REJECTED  # ...but never accepted
    assert {"gtin_conflict", "mpn_conflict", "attribute_mismatch"} <= against(result)
    assert any("256 GB" in r.message and "128 GB" in r.message for r in result.reasons_against)


def test_identical_title_alone_is_never_an_exact_match():
    title_only = NormalisedListing(supplier_key="s", supplier_sku="1", title="Lumio Aurora X5 128GB")
    result = matcher.evaluate(title_only, X5_128)
    assert result.mode is MatchMode.INSUFFICIENT and result.outcome is MatchOutcome.NEEDS_REVIEW
    assert result.candidate_score == 1.0  # a perfect title score still proves nothing


def test_attributes_agree_but_no_identifier_needs_human_review():
    result = matcher.evaluate(listing(), X5_128)
    assert (result.mode, result.outcome) == (MatchMode.EXACT, MatchOutcome.NEEDS_REVIEW)
    assert "gtin" in result.unknowns


def test_storage_read_from_title_conflicts_with_product():
    from_title = listing(title="Lumio Aurora X5 256GB", attributes={"storage_gb": 256, "region": "UK"},
                         attribute_sources={"storage_gb": "title", "region": "structured"})
    result = matcher.evaluate(from_title, X5_128)
    assert result.outcome is MatchOutcome.REJECTED
    assert [r.strength for r in result.reasons_against if r.attribute == "storage_gb"] == ["title"]


def test_gtin_match_cannot_override_a_conflicting_region():
    eu = listing(gtin="5060999000011", attributes={"storage_gb": 128, "region": "EU"})
    result = matcher.evaluate(eu, X5_128)
    assert result.outcome is MatchOutcome.REJECTED and against(result) == {"attribute_mismatch"}


def test_different_model_generation_is_rejected():
    pro = listing(title="Lumio Aurora X5 Pro 128GB", model="X5 Pro")
    assert "model_mismatch" in against(matcher.evaluate(pro, X5_128))


def test_refurbished_is_the_same_identity_but_fails_a_new_requirement():
    refurbished = listing(gtin="5060999000011", condition=Condition.REFURBISHED)
    assert matcher.evaluate(refurbished, X5_128).accepted  # identity only: spec.condition is None
    from dataclasses import replace

    wants_new = replace(X5_128, condition=Condition.NEW)
    result = matcher.evaluate(refurbished, wants_new)
    assert result.outcome is MatchOutcome.REJECTED and against(result) == {"condition_mismatch"}
    assert condition_check("refurbished", "new").message == "Condition is refurbished; you asked for new."
    assert condition_check("new", "new") is None
    assert condition_check("unknown", "new").code == "condition_unknown"


def test_bundles_and_missing_accessories_are_not_like_for_like():
    bundle = listing(gtin="5060999000011", included=BOX | {"case"})
    assert "contents_extra" in against(matcher.evaluate(bundle, X5_128))
    stripped = listing(gtin="5060999000011", included=frozenset({"handset"}))
    assert "contents_missing" in against(matcher.evaluate(stripped, X5_128))
    assert matcher.evaluate(listing(gtin="5060999000011", included=BOX), X5_128).accepted


def test_warranty_difference_is_visible_but_not_blocking():
    result = matcher.evaluate(listing(gtin="5060999000011", warranty="1 year seller warranty"), X5_128)
    assert result.accepted and any("1 year seller warranty" in d for d in result.differences)


def test_candidate_retrieval_ranks_identifiers_first_and_never_decides():
    hidden = listing(title="Lumio Aurora X5 5G Smartphone", gtin="5060999000028", attributes={"storage_gb": 256})
    candidates = retrieve_candidates(hidden, [X5_128, X5_256])
    assert [spec.key for spec, _ in candidates] == ["x5-256", "x5-128"]
    assert candidates[0][1] == 1.0
    other_brand = listing(brand="Zephyr", title="Zephyr Aurora X5 128GB")
    assert retrieve_candidates(other_brand, [X5_128]) == []


def test_specification_equivalent_mode():
    spec = ProductSpecification(key="laptops", title="Laptops", mode=MatchMode.SPEC_EQUIVALENT, condition=Condition.NEW,
                                requirements=(Requirement("ram_gb", "gte", 16), Requirement("storage_gb", "gte", 512)))
    big = listing(title="Zephyr Slate 15", brand="Zephyr", attributes={"ram_gb": 16, "storage_gb": 1024})
    small = listing(title="Nimbus Book 14", brand="Nimbus", attributes={"ram_gb": 8, "storage_gb": 256})
    vague = listing(title="Mystery laptop", attributes={"ram_gb": 16})
    assert matcher.evaluate(big, spec).mode is MatchMode.SPEC_EQUIVALENT and matcher.evaluate(big, spec).accepted
    assert matcher.evaluate(small, spec).outcome is MatchOutcome.REJECTED
    insufficient = matcher.evaluate(vague, spec)
    assert insufficient.mode is MatchMode.INSUFFICIENT and insufficient.unknowns == ("storage_gb",)


def test_unit_price_mode_preserves_form_and_requirements():
    spec = ProductSpecification(key="rice", title="Rice", mode=MatchMode.UNIT_PRICE, attributes={"product_form": "basmati"},
                                net_quantity=Quantity(Decimal(2), "kg"), requirements=(Requirement("organic", "eq", True),))

    def rice(**kwargs):
        values = dict(supplier_key="s", supplier_sku="r", title="Rice", attributes={"product_form": "basmati", "organic": True},
                      net_quantity=Quantity(Decimal(500), "g"), pack_count=1)
        values.update(kwargs)
        return NormalisedListing(**values)

    ok = matcher.evaluate(rice(), spec)
    assert ok.mode is MatchMode.UNIT_PRICE and ok.accepted and "Different size: 500 g per item." in ok.differences
    assert "form_mismatch" in against(matcher.evaluate(rice(attributes={"product_form": "long grain", "organic": True}), spec))
    assert "requirement_failed" in against(matcher.evaluate(rice(attributes={"product_form": "basmati", "organic": False}), spec))
    assert "dimension_mismatch" in against(matcher.evaluate(rice(net_quantity=Quantity(Decimal(1), "l")), spec))
    assert matcher.evaluate(rice(net_quantity=None), spec).mode is MatchMode.INSUFFICIENT
