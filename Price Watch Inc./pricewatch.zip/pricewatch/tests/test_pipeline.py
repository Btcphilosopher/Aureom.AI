"""End-to-end acceptance: fixture source -> extraction -> validation -> matching -> pricing -> comparison."""
from datetime import timedelta
from decimal import Decimal

import pytest
from django.core import mail
from django.db import IntegrityError, transaction

from apps.alerts.services import create_alert, evaluate_alert
from apps.audit.models import AuditEvent
from apps.collection.models import SourceDocument
from apps.collection.tasks import due_sources
from apps.comparisons.services import (
    BasketRequestItem,
    Requirements,
    compare_grocery_basket,
    compare_specification,
    compare_unit_price,
    compare_variant,
    price_history,
)
from apps.catalogue.models import Category, ProductVariant
from apps.matching.models import MatchDecision
from apps.matching.services import review_decision
from apps.matching.types import Requirement
from apps.pricing.units import Quantity
from apps.suppliers.models import (
    ImmutableRecordError,
    OfferObservation,
    SourceConfiguration,
    SupplierListing,
)
from apps.suppliers.services import review_observation

from .support import BASE_TIME, X5_256, collect, submit_clubtronics

D = Decimal
pytestmark = pytest.mark.django_db
UNKNOWN = Requirements()
NOT_MEMBER = Requirements.from_dict({"memberships": {"clubtronics": "not_held"}})
MEMBER = Requirements.from_dict({"memberships": {"clubtronics": "held"}})


def totals(result):
    return [(view.supplier.slug, view.breakdown.total) for view in result.ranked]


def listing(sku):
    return SupplierListing.objects.select_related("supplier", "variant", "latest_valid_observation").get(supplier_sku=sku)


# 1 ------------------------------------------------------------------ collect offers

def test_collects_every_source_type(baseline):
    assert {key: run.status for key, run in baseline.items()} == {key: "succeeded" for key in baseline}
    methods = set(OfferObservation.objects.values_list("extraction_method", flat=True))
    assert methods == {"css_selector", "json_ld", "browser_dom", "csv_column", "api_field", "json_field", "manual_submission"}
    assert baseline["gadgetgrove-api"].documents_fetched == 2  # followed the API's pagination
    assert baseline["techhaven-html"].documents_fetched == 5  # discovered product pages from the catalogue


def test_every_published_value_keeps_its_provenance(baseline):
    observation = listing("TH-1001").latest_valid_observation
    assert observation.source_url == "https://techhaven.fixture.test/products/aurora-x5-128.html"
    assert observation.extraction_method == "css_selector" and observation.configuration_version == 1
    assert observation.observed_at == BASE_TIME
    price = observation.evidence["price"]
    assert price["locator"] == "p.price .amount" and "£399.00" in price["snippet"]
    assert observation.source_document.content_sha256 and "£399.00" in observation.source_document.body
    declared = listing("VM-X5-128").latest_valid_observation
    assert declared.supplier_effective_at.isoformat() == "2026-01-05T00:00:00+00:00"  # supplier's date, kept separately
    assert declared.observed_at == BASE_TIME


# 2 --------------------------------------------------------- reject incompatible variant

def test_similar_title_with_different_storage_is_not_compared(baseline, phone):
    hidden = listing("TH-1002")  # "Lumio Aurora X5 5G Smartphone": 256GB only in the spec table
    assert hidden.variant.gtin == X5_256
    result = compare_variant(phone, UNKNOWN, clock=FixedAt(BASE_TIME))
    assert "techhaven" in dict(totals(result)) and all(v.listing.pk != hidden.pk for v in result.all_offers)
    excluded = {e.listing.supplier_sku: e.reasons for e in result.not_comparable}
    assert "Storage: listing is 256 GB, product is 128 GB." in excluded["TH-1002"]
    assert excluded["OH-X5-128-EU"] == ["Region: listing is EU, product is UK."]


def test_refurbished_listing_is_excluded_from_new_and_ranked_for_refurbished(baseline, phone):
    clock = FixedAt(BASE_TIME)
    new = compare_variant(phone, UNKNOWN, clock=clock)
    assert {e.listing.supplier_sku: e.reasons for e in new.not_comparable}["OH-X5-128-R"] == ["Condition is refurbished; you asked for new."]
    refurbished = compare_variant(phone, Requirements.from_dict({"condition": "refurbished"}), clock=clock)
    assert totals(refurbished) == [("ohmly", D("338.50"))]


# 3 ------------------------------------------------------------------ quarantine

def test_invalid_prices_are_quarantined_and_never_published(baseline):
    quarantined = {o.listing.supplier_sku: [i["code"] for i in o.issues] for o in OfferObservation.objects.filter(status="quarantined")}
    assert quarantined == {"TH-1003": ["malformed_price"], "VM-X5P-256": ["zero_price"]}
    for sku in quarantined:
        item = listing(sku)
        assert item.status == "quarantined" and item.latest_valid_observation is None and item.variant is None
    assert baseline["techhaven-html"].observations_quarantined == 1
    assert AuditEvent.objects.filter(action="observation.quarantined").count() == 2


def test_database_refuses_a_published_zero_price(baseline):
    source = listing("TH-1001")
    with pytest.raises(IntegrityError), transaction.atomic():
        OfferObservation.objects.create(
            listing=source, collection_run=source.latest_valid_observation.collection_run, observed_at=BASE_TIME,
            price_amount=D("0.00"), currency="GBP", status="valid", source_url="https://x.test/", extraction_method="manual",
            configuration_version=1,
        )


def test_observations_are_immutable(baseline):
    observation = listing("TH-1001").latest_valid_observation
    observation.price_amount = D("1.00")
    with pytest.raises(ImmutableRecordError):
        observation.save()
    with pytest.raises(ImmutableRecordError):
        observation.delete()


# 4, 5 ------------------------------------------------------- totals and explanation

def test_complete_totals_and_winner(baseline, phone):
    result = compare_variant(phone, NOT_MEMBER, clock=FixedAt(BASE_TIME))
    assert totals(result) == [("techhaven", D("403.99")), ("ohmly", D("404.50")), ("voltmart", D("405.00")), ("gadgetgrove", D("408.00"))]
    grove = next(v for v in result.ranked if v.supplier.slug == "gadgetgrove")
    assert grove.breakdown.tax_total == D("68.00")  # ex-VAT supplier: 20% on £335 + £5 delivery
    assert grove.breakdown.conditional_discounts[0].potential_saving == D("15.00")  # coupon not applied unasked
    assert result.winner.supplier.slug == "techhaven"
    assert result.explanation[0] == (
        "TechHaven is the cheapest complete offer you are eligible for: £403.99 (items £399.00, delivery £4.99)."
    )
    assert [v.supplier.slug for v in result.ineligible] == ["clubtronics"]


def test_membership_unknown_is_conditional_and_never_the_confirmed_cheapest(baseline, phone):
    clock = FixedAt(BASE_TIME)
    unknown = compare_variant(phone, UNKNOWN, clock=clock)
    assert unknown.winner.supplier.slug == "techhaven"
    [conditional] = unknown.conditional
    assert conditional.supplier.slug == "clubtronics" and conditional.breakdown.total == D("385.00") and conditional.rank is None
    assert any("conditional and not ranked" in line for line in unknown.explanation)
    assert [s.slug for s in unknown.programmes] == ["clubtronics"]
    member = compare_variant(phone, MEMBER, clock=clock)
    assert totals(member)[0] == ("clubtronics", D("385.00"))


def test_coupon_applies_only_when_the_customer_supplies_it(baseline, phone):
    with_code = compare_variant(phone, Requirements.from_dict({"coupon_codes": ["GROVE15"]}), clock=FixedAt(BASE_TIME))
    assert totals(with_code)[0] == ("gadgetgrove", D("390.00"))  # (335 - 15 + 5) x 1.2


def test_quantity_changes_delivery_threshold(baseline, phone):
    two = compare_variant(phone, Requirements.from_dict({"quantity": 2}), clock=FixedAt(BASE_TIME))
    techhaven = next(v for v in two.ranked if v.supplier.slug == "techhaven")
    assert techhaven.breakdown.delivery_total == D("0.00") and techhaven.breakdown.total == D("798.00")  # over the £500 threshold


def test_needs_review_listing_is_not_ranked_until_confirmed(baseline, phone):
    result = compare_variant(phone, UNKNOWN, clock=FixedAt(BASE_TIME))
    assert [e.listing.supplier.slug for e in result.pending_review] == ["pixelpoint"]
    assert all(v.supplier.slug != "pixelpoint" for v in result.all_offers)


def test_sponsored_flag_never_changes_ranking(baseline, phone):
    clock = FixedAt(BASE_TIME)
    before = totals(compare_variant(phone, NOT_MEMBER, clock=clock))
    SupplierListing.objects.filter(supplier_sku="GG-50012").update(is_sponsored=True)  # the most expensive offer pays
    after = compare_variant(phone, NOT_MEMBER, clock=clock)
    assert totals(after) == before
    assert [v.supplier.slug for v in after.sponsored] == ["gadgetgrove"] and after.sponsored[0].rank == 4


# 6, 7 ---------------------------------------------------------- history and refresh

def test_refresh_after_supplier_change_keeps_history_and_reranks(baseline, phone, clock):
    clock.advance(hours=6)
    collect(clock, scenario="price_change")
    submit_clubtronics(clock)
    result = compare_variant(phone, NOT_MEMBER, clock=clock)
    assert totals(result)[0] == ("voltmart", D("398.00"))
    voltmart = listing("VM-X5-128")
    # We only know the change happened between two checks; both ends are recorded.
    assert voltmart.last_price_change_previous_check_at == BASE_TIME
    assert voltmart.last_price_change_observed_at == BASE_TIME + timedelta(hours=6)
    history = {s.listing.supplier.slug: s.points for s in price_history(phone)}
    assert history["voltmart"] == [(BASE_TIME, D("405.00")), (BASE_TIME + timedelta(hours=6), D("398.00"))]
    assert history["techhaven"] == [(BASE_TIME, D("399.00")), (BASE_TIME + timedelta(hours=6), D("399.00"))]
    assert listing("TH-1001").last_price_change_observed_at is None  # unchanged price is not reported as a change


def test_suspicious_drop_is_quarantined_and_last_valid_price_stays_with_stale_label(baseline, phone, clock):
    clock.advance(hours=6)
    collect(clock, scenario="price_change", only=["ohmly-csv"])
    ohmly = listing("OH-X5-128")
    assert ohmly.latest_valid_observation.price_amount == D("395.00")
    held = ohmly.observations.get(status="quarantined")
    assert held.price_amount == D("150.00") and held.issues[0]["code"] == "suspicious_drop"
    view = next(v for v in compare_variant(phone, UNKNOWN, clock=clock).ranked if v.supplier.slug == "ohmly")
    assert view.breakdown.total == D("404.50") and view.freshness.is_stale
    assert "held for review" in view.freshness.reason


def test_reviewer_can_release_a_genuine_price_drop(baseline, phone, clock, reviewer):
    clock.advance(hours=6)
    collect(clock, scenario="price_change", only=["ohmly-csv"])
    held = listing("OH-X5-128").observations.get(status="quarantined")
    review_observation(held, reviewer=reviewer, release=True, note="Confirmed clearance price", clock=clock)
    item = listing("OH-X5-128")
    assert item.latest_valid_observation.pk == held.pk and item.last_price_change_observed_at == held.observed_at
    held.refresh_from_db()
    assert (held.status, held.reviewed_by, held.price_amount) == ("valid", reviewer, D("150.00"))  # values untouched
    assert AuditEvent.objects.filter(action="observation.released", actor=reviewer).exists()
    assert totals(compare_variant(phone, UNKNOWN, clock=clock))[0] == ("ohmly", D("159.50"))


def test_unusable_observation_cannot_be_released(baseline, reviewer, clock):
    broken = OfferObservation.objects.get(listing__supplier_sku="TH-1003")
    with pytest.raises(ValueError):
        review_observation(broken, reviewer=reviewer, release=True, clock=clock)
    assert review_observation(broken, reviewer=reviewer, release=False, clock=clock).status == "rejected"


def test_conflicting_structured_data_is_quarantined(baseline, laptop, clock):
    clock.advance(hours=6)
    collect(clock, scenario="price_change", only=["techhaven-html"])
    held = listing("TH-2001").observations.get(status="quarantined")
    assert [i["code"] for i in held.issues] == ["conflicting_data"]
    view = next(v for v in compare_variant(laptop, UNKNOWN, clock=clock).ranked if v.supplier.slug == "techhaven")
    assert view.breakdown.total == D("749.00") and view.freshness.is_stale


# 8 ---------------------------------------------------------------- source failures

def test_failed_refresh_keeps_last_valid_observation_visible_as_stale(baseline, phone, clock):
    clock.advance(hours=3)
    runs = collect(clock, scenario="outage", only=["techhaven-html"])
    run = runs["techhaven-html"]
    assert run.status == "failed" and run.observations_valid == 0 and "503" in run.error_message
    source = SourceConfiguration.objects.get(key="techhaven-html")
    # attempt, success and failure are tracked separately
    assert source.last_attempt_at == BASE_TIME + timedelta(hours=3)
    assert source.last_success_at == BASE_TIME
    assert source.last_failure_at == BASE_TIME + timedelta(hours=3)
    assert source.consecutive_failures == 1 and "503" in source.last_failure_reason
    result = compare_variant(phone, NOT_MEMBER, clock=clock)
    techhaven = next(v for v in result.ranked if v.supplier.slug == "techhaven")
    assert techhaven.breakdown.total == D("403.99")  # last verified price is still shown
    assert techhaven.freshness.is_stale and "latest refresh failed" in techhaven.freshness.reason
    assert techhaven.freshness.observed_at == BASE_TIME
    assert result.has_stale and "Caution" in result.explanation[2]
    assert not next(v for v in result.ranked if v.supplier.slug == "voltmart").freshness.is_stale
    assert OfferObservation.objects.filter(listing__supplier_sku="TH-1001").count() == 1  # nothing invented


def test_recovery_clears_the_stale_label(baseline, phone, clock):
    clock.advance(hours=3)
    collect(clock, scenario="outage", only=["techhaven-html"])
    clock.advance(hours=1)
    collect(clock, only=["techhaven-html"])
    source = SourceConfiguration.objects.get(key="techhaven-html")
    assert source.consecutive_failures == 0 and source.last_success_at > source.last_failure_at
    view = next(v for v in compare_variant(phone, UNKNOWN, clock=clock).ranked if v.supplier.slug == "techhaven")
    assert not view.freshness.is_stale


def test_offers_go_stale_when_not_rechecked(baseline, phone, clock):
    clock.advance(hours=25)
    result = compare_variant(phone, NOT_MEMBER, clock=clock)
    assert all(view.freshness.is_stale for view in result.ranked)
    assert "Not re-checked in the last 24 hours." in result.ranked[0].freshness.reason


def test_broken_selectors_quarantine_everything_and_flag_the_source(baseline, phone, clock):
    clock.advance(hours=2)
    run = collect(clock, scenario="redesign", only=["techhaven-html"])["techhaven-html"]
    assert run.observations_valid == 0 and run.observations_quarantined == 5
    source = SourceConfiguration.objects.get(key="techhaven-html")
    assert source.status == "broken" and "selectors" in source.last_failure_reason
    item = listing("TH-1001")
    assert item.title == "Lumio Aurora X5 Smartphone 128GB"  # garbage never overwrote the listing
    assert item.latest_valid_observation.price_amount == D("399.00")
    assert source not in due_sources(clock.now() + timedelta(days=30))  # broken sources wait for an operator


def test_missing_credential_is_a_visible_failure(seeded, clock, monkeypatch):
    monkeypatch.delenv("GADGETGROVE_API_KEY")
    run = collect(clock, only=["gadgetgrove-api"])["gadgetgrove-api"]
    assert run.status == "failed" and run.error_class == "SourceConfigurationError"
    assert "GADGETGROVE_API_KEY" in run.error_message  # names the variable, never a secret


def test_wrong_credential_is_access_denied_and_not_retried(seeded, clock, monkeypatch):
    monkeypatch.setenv("GADGETGROVE_API_KEY", "wrong")
    run = collect(clock, only=["gadgetgrove-api"])["gadgetgrove-api"]
    assert run.status == "failed" and "AccessDeniedError" in run.error_message
    assert "wrong" not in run.error_message and SourceDocument.objects.count() == 0


def test_scheduler_backs_off_failing_sources(baseline, clock):
    source = SourceConfiguration.objects.get(key="voltmart-structured")
    assert source not in due_sources(BASE_TIME + timedelta(minutes=30))
    assert source in due_sources(BASE_TIME + timedelta(minutes=361))
    SourceConfiguration.objects.filter(pk=source.pk).update(consecutive_failures=2)
    assert source not in due_sources(BASE_TIME + timedelta(minutes=361))  # 4x interval after two failures
    assert all(s.kind != "manual" for s in due_sources(BASE_TIME + timedelta(days=9)))


def test_configuration_version_is_recorded_and_bumped_on_change(baseline, clock):
    source = SourceConfiguration.objects.get(key="ohmly-csv")
    source.name = "Renamed"
    source.save()
    assert source.version == 1  # cosmetic change: same extraction rules
    source.settings = {**source.settings, "spec_map": {"storage": "storage"}}
    source.save()
    assert source.version == 2
    clock.advance(hours=1)
    collect(clock, only=["ohmly-csv"])
    assert listing("OH-X5-256").latest_valid_observation.configuration_version == 2


# 9 --------------------------------------------------------------------------- alerts

def test_price_alert_triggers_once_and_keeps_requirements(baseline, phone, clock, customer):
    alert = create_alert(user=customer, variant=phone, target_total=D("400.00"), requirements=NOT_MEMBER, clock=clock)
    assert alert.requirements == {"condition": "new", "quantity": 1, "memberships": {"clubtronics": "not_held"},
                                  "coupon_codes": [], "currency": "GBP"}
    assert evaluate_alert(alert, clock=clock).outcome == "above_target"  # £403.99; the £385 member price does not count
    clock.advance(hours=6)
    collect(clock, scenario="price_change")
    fired = evaluate_alert(alert, clock=clock)
    assert (fired.outcome, fired.total, fired.supplier) == ("notified", D("398.00"), "VoltMart")
    assert len(mail.outbox) == 1 and mail.outbox[0].to == ["alice@example.test"]
    assert "£398.00" in mail.outbox[0].body and "clubtronics membership: not held" in mail.outbox[0].body
    assert evaluate_alert(alert, clock=clock).outcome == "duplicate"
    clock.advance(hours=30)
    collect(clock, scenario="price_change")
    assert evaluate_alert(alert, clock=clock).outcome == "duplicate"  # same price, same supplier: no repeat
    assert len(mail.outbox) == 1 and alert.notifications.count() == 1


def test_alert_frequency_limit(baseline, phone, clock, customer):
    alert = create_alert(user=customer, variant=phone, target_total=D("404.00"), requirements=NOT_MEMBER, clock=clock)
    assert evaluate_alert(alert, clock=clock).outcome == "notified"  # TechHaven £403.99
    alert.refresh_from_db()
    clock.advance(hours=6)
    collect(clock, scenario="price_change")
    assert evaluate_alert(alert, clock=clock).outcome == "rate_limited"  # new, lower price but within 24h
    clock.advance(hours=20)
    collect(clock, scenario="price_change")
    alert.refresh_from_db()
    assert evaluate_alert(alert, clock=clock).outcome == "notified"
    assert len(mail.outbox) == 2


def test_alert_ignores_conditional_and_stale_offers(baseline, phone, clock, customer):
    unknown_membership = create_alert(user=customer, variant=phone, target_total=D("390.00"), requirements=UNKNOWN, clock=clock)
    assert evaluate_alert(unknown_membership, clock=clock).outcome == "above_target"  # £385 is conditional, not confirmed
    member = create_alert(user=customer, variant=phone, target_total=D("390.00"), requirements=MEMBER, clock=clock)
    clock.advance(hours=30)  # nothing re-collected: every offer is stale
    assert evaluate_alert(member, clock=clock).outcome == "no_confirmed_offer"
    assert mail.outbox == []


# 10 -------------------------------------------------------------------------- review

def test_review_accepts_a_pending_match_as_a_new_version(baseline, phone, clock, reviewer):
    pending = MatchDecision.objects.get(listing__supplier_sku="PP-778812", variant=phone, is_current=True)
    assert (pending.outcome, pending.decided_by, pending.version) == ("needs_review", "system", 1)
    accepted = review_decision(pending, reviewer=reviewer, accept=True, note="Checked page", clock=clock)
    pending.refresh_from_db()
    assert not pending.is_current and accepted.supersedes == pending
    assert (accepted.version, accepted.outcome, accepted.decided_by, accepted.reviewer) == (2, "accepted", "human", reviewer)
    assert accepted.reasons_for == pending.reasons_for  # evidence kept with the verdict
    result = compare_variant(phone, UNKNOWN, clock=clock)
    [incomplete] = result.incomplete
    assert incomplete.supplier.slug == "pixelpoint" and incomplete.breakdown.total is None
    assert incomplete.breakdown.known_subtotal == D("389.00") and incomplete.breakdown.missing == ("Delivery cost unknown",)
    assert incomplete.rank is None and result.winner.supplier.slug == "techhaven"  # cheaper item price, but total incomplete
    assert any("Total incomplete for PixelPoint" in line for line in result.explanation)


def test_correction_overrides_rules_and_survives_recollection(baseline, laptop, clock, reviewer):
    wrong = MatchDecision.objects.get(listing__supplier_sku="GG-61007", variant=laptop, is_current=True)
    assert wrong.outcome == "rejected" and wrong.reasons_against[0]["code"] == "gtin_conflict"
    assert listing("GG-61007").variant is None
    corrected = review_decision(wrong, reviewer=reviewer, accept=True, note="GTIN typo confirmed by supplier", clock=clock)
    assert listing("GG-61007").variant == laptop and corrected.version == 2
    assert totals(compare_variant(laptop, UNKNOWN, clock=clock))[0] == ("gadgetgrove", D("738.00"))
    clock.advance(hours=2)
    collect(clock, only=["gadgetgrove-api"])  # rules run again but must not undo the human decision
    assert listing("GG-61007").variant == laptop
    current = MatchDecision.objects.get(listing__supplier_sku="GG-61007", variant=laptop, is_current=True)
    assert current.pk == corrected.pk and current.decided_by == "human"
    event = AuditEvent.objects.get(action="match.accepted")
    assert event.actor == reviewer and event.data["previous_outcome"] == "rejected" and event.data["previous_version"] == 1


def test_reviewer_can_reject_a_system_match_and_history_is_kept(baseline, phone, clock, reviewer):
    accepted = MatchDecision.objects.get(listing__supplier_sku="VM-X5-128", variant=phone, is_current=True)
    rejected = review_decision(accepted, reviewer=reviewer, accept=False, note="Customer report: EU model", clock=clock)
    assert listing("VM-X5-128").variant is None and rejected.version == 2
    assert "voltmart" not in dict(totals(compare_variant(phone, UNKNOWN, clock=clock)))
    chain = MatchDecision.objects.filter(listing__supplier_sku="VM-X5-128", variant=phone).order_by("version")
    assert [(d.version, d.outcome, d.decided_by, d.is_current) for d in chain] == [
        (1, "accepted", "system", False), (2, "rejected", "human", True)]
    with pytest.raises(ValueError):
        review_decision(accepted, reviewer=reviewer, accept=True, clock=clock)  # stale version cannot be reviewed


def test_a_listing_can_be_accepted_for_only_one_variant(baseline, phone, clock, reviewer):
    other = ProductVariant.objects.get(gtin=X5_256)
    decision = MatchDecision.objects.get(listing__supplier_sku="VM-X5-128", variant=other, is_current=True)
    review_decision(decision, reviewer=reviewer, accept=True, note="Moved", clock=clock)
    assert listing("VM-X5-128").variant == other
    assert MatchDecision.objects.filter(listing__supplier_sku="VM-X5-128", is_current=True, outcome="accepted").count() == 1


# ------------------------------------------------------- other comparison modes, grocery

def test_specification_equivalent_comparison(baseline, clock):
    laptops = Category.objects.get(slug="laptops")
    spec = [Requirement("ram_gb", "gte", 16), Requirement("storage_gb", "gte", 512)]
    result = compare_specification(laptops, spec, UNKNOWN, clock=clock)
    assert result.mode == "spec_equivalent"
    assert totals(result) == [("voltmart", D("739.00")), ("techhaven", D("749.00")), ("ohmly", D("808.50")), ("techhaven", D("815.00"))]
    assert {v.listing.variant.product.name for v in result.ranked} == {"Book 14", "Slate 15"}  # different products
    assert all(v.listing.supplier_sku != "VM-B14-8" for v in result.all_offers)  # 8GB/256GB fails the requirement


def test_unit_price_comparison_across_pack_sizes(baseline, clock):
    rice = Category.objects.get(slug="rice")
    result = compare_unit_price(rice, Quantity(D(2), "kg"), UNKNOWN, product_form="basmati", clock=clock)
    rows = [(v.listing.supplier_sku, v.breakdown.packs, v.breakdown.total, v.unit_price) for v in result.ranked]
    assert rows[0] == ("GB-100", 1, D("6.20"), D("0.2100"))  # 1 x 2kg at £4.20 + £2.00 delivery
    assert ("GB-101", 4, D("6.80"), D("0.2400")) in rows  # 4 x 500g
    assert ("FC-R-2K", 1, D("8.00"), D("0.2250")) in rows
    assert all(v.listing.supplier_sku != "DP-12" for v in result.ranked)  # long grain is a different product form
    assert any(e.listing.supplier_sku == "DP-12" and "long grain" in e.reasons[0] for e in result.not_comparable)
    organic = compare_unit_price(rice, Quantity(D(1), "kg"), UNKNOWN, product_form="basmati",
                                 attribute_requirements=[Requirement("organic", "eq", True)], clock=clock)
    assert [v.listing.supplier_sku for v in organic.ranked] == ["FC-R-ORG"]


def test_unit_price_converts_units_and_reports_surplus(baseline, clock):
    milk = Category.objects.get(slug="milk")
    result = compare_unit_price(milk, Quantity(D(4), "l"), UNKNOWN, product_form="semi-skimmed", clock=clock)
    pints = next(v for v in result.ranked if v.listing.supplier_sku == "DP-21")  # 4 pints = 2.273 l
    assert pints.breakdown.packs == 2 and pints.breakdown.purchased_quantity == Quantity(D(8), "pt")
    assert pints.breakdown.surplus_quantity.quantize(D("0.001")) == D("0.961")  # pints bought beyond 4 litres
    by_count = compare_unit_price(milk, Quantity(D(6), "each"), UNKNOWN, clock=clock)
    assert by_count.ranked == [] and any("Sold by volume" in e.reasons[0] for e in by_count.not_comparable)


def test_grocery_basket(baseline, clock):
    categories = {c.slug: c for c in Category.objects.filter(vertical="grocery")}
    items = [
        BasketRequestItem("rice", "2 kg basmati rice", categories["rice"], Quantity(D(2), "kg"), "basmati"),
        BasketRequestItem("milk", "4 l semi-skimmed milk", categories["milk"], Quantity(D(4), "l"), "semi-skimmed"),
        BasketRequestItem("eggs", "12 eggs", categories["eggs"], Quantity(D(12), "each"), "free range"),
    ]
    comparison = compare_grocery_basket(items, UNKNOWN, clock=clock).comparison
    best = comparison.best_single_supplier
    assert (best.orders[0].supplier_key, best.total, best.delivery_count) == ("greenbasket", D("12.80"), 1)
    assert comparison.baseline_split.total == D("17.29") and comparison.baseline_split.supplier_count == 2
    assert "not a guaranteed lowest total" in comparison.baseline_split.method_note
    assert comparison.exhaustive_split.total == D("12.80") <= comparison.baseline_split.total
    eggs = next(line for line in best.orders[0].lines if line.item.key == "eggs")
    assert eggs.breakdown.packs == 2  # the 12-pack is out of stock at GreenBasket, so two 6-packs
    freshcart = next(p for p in comparison.single_supplier if p.orders[0].supplier_key == "freshcart")
    assert freshcart.complete and freshcart.orders[0].delivery == D("3.50")  # below the £40 threshold


class FixedAt:
    def __init__(self, moment):
        self.moment = moment

    def now(self):
        return self.moment
