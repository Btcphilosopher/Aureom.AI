"""Real Playwright rendering. Skipped (visibly) when no Chromium can be launched."""
import asyncio
import os
import shutil

import pytest

from apps.collection.browser import PlaywrightRenderer
from apps.collection.fixtures import FixtureSite
from apps.collection.pipeline import run_collection
from apps.collection.types import BrowserUnavailableError, FetchPolicy, UnsafeUrlError
from apps.suppliers.models import SourceConfiguration, SupplierListing

from .support import FIXTURE_ROOT

pytestmark = pytest.mark.browser
EXECUTABLE = os.environ.get("PLAYWRIGHT_CHROMIUM_EXECUTABLE") or None
POLICY = FetchPolicy(user_agent="PriceWatchBot/1.0", timeout_seconds=15, allowed_private_hosts=frozenset({"pixelpoint.fixture.test"}))


def launchable() -> bool:
    async def probe():
        async with PlaywrightRenderer(POLICY, executable_path=EXECUTABLE, no_sandbox=True):
            return True

    try:
        return asyncio.run(probe())
    except BrowserUnavailableError:
        return False


requires_browser = pytest.mark.skipif(not launchable(), reason="No launchable Chromium (set PLAYWRIGHT_CHROMIUM_EXECUTABLE)")


@requires_browser
def test_javascript_rendered_page_yields_product_data():
    site = FixtureSite(FIXTURE_ROOT)
    raw_html = site.lookup("pixelpoint.fixture.test", "/product/aurora-x5.html")[0].decode()
    assert "pp-price" not in raw_html  # the price exists only after JavaScript runs

    async def render():
        async with PlaywrightRenderer(POLICY, executable_path=EXECUTABLE, no_sandbox=True, fixture_lookup=site.lookup) as renderer:
            return await renderer.render("https://pixelpoint.fixture.test/product/aurora-x5.html", wait_for_selector=".pp-price")

    document = asyncio.run(render())
    assert document.method == "browser" and '<p class="pp-price">£389.00</p>' in document.body


@requires_browser
def test_rendered_pages_cannot_reach_private_addresses(tmp_path):
    host = tmp_path / "pixelpoint.fixture.test"
    host.mkdir()
    (host / "index.html").write_text(
        "<html><body><p id='out'>pending</p><script src='/probe.js'></script></body></html>")
    (host / "probe.js").write_text(
        "fetch('http://169.254.169.254/latest/meta-data/').then(() => { document.getElementById('out').textContent = 'LEAKED'; })"
        ".catch(() => { document.getElementById('out').textContent = 'blocked'; });")
    site = FixtureSite(tmp_path)

    async def run_and_wait():
        async with PlaywrightRenderer(POLICY, executable_path=EXECUTABLE, no_sandbox=True, fixture_lookup=site.lookup) as renderer:
            document = await renderer.render("https://pixelpoint.fixture.test/index.html", wait_for_selector="#out")
            return document, list(renderer.blocked_requests)

    document, blocked = asyncio.run(run_and_wait())
    assert "LEAKED" not in document.body
    assert blocked == ["http://169.254.169.254/latest/meta-data/"]

    async def direct():
        async with PlaywrightRenderer(POLICY, executable_path=EXECUTABLE, no_sandbox=True) as renderer:
            await renderer.render("http://127.0.0.1/")

    with pytest.raises(UnsafeUrlError):
        asyncio.run(direct())


@requires_browser
def test_page_budget_bounds_browser_work():
    site = FixtureSite(FIXTURE_ROOT)

    async def run():
        async with PlaywrightRenderer(POLICY, executable_path=EXECUTABLE, no_sandbox=True, fixture_lookup=site.lookup,
                                      max_pages_per_run=1) as renderer:
            await renderer.render("https://pixelpoint.fixture.test/product/aurora-x5.html")
            await renderer.render("https://pixelpoint.fixture.test/product/aurora-x5.html")

    with pytest.raises(Exception, match="page budget"):
        asyncio.run(run())


@requires_browser
@pytest.mark.django_db(transaction=True)
def test_browser_source_collects_through_the_full_pipeline(settings, seeded):
    settings.PRICEWATCH = {**settings.PRICEWATCH, "BROWSER_EXECUTABLE": EXECUTABLE, "BROWSER_NO_SANDBOX": True}
    run = run_collection(SourceConfiguration.objects.get(key="pixelpoint-browser"))
    assert (run.status, run.observations_valid) == ("succeeded", 1)
    listing = SupplierListing.objects.get(supplier_sku="PP-778812")
    observation = listing.latest_valid_observation
    assert str(observation.price_amount) == "389.00" and observation.extraction_method == "browser_dom"
    assert observation.source_document.retrieval_method == "browser"
    assert listing.attributes == {"storage_gb": 128, "ram_gb": 8, "region": "UK"}


def test_missing_browser_is_a_visible_failure_not_a_crash():
    async def run():
        async with PlaywrightRenderer(POLICY, executable_path="/nonexistent/chromium"):
            pass

    with pytest.raises(BrowserUnavailableError):
        asyncio.run(run())
    assert shutil.which("definitely-not-a-browser") is None
