"""Locale-aware price parsing, identifiers and sanitisation. Pure."""
from decimal import Decimal

import pytest

from apps.core.logging import redact
from apps.core.text import clean_http_url, clean_text, spreadsheet_safe
from apps.extraction.parsing import (
    PriceParseError,
    attributes_from_title,
    normalise_gtin,
    parse_availability,
    parse_capacity_gb,
    parse_condition,
    parse_percentage,
    parse_price,
    parse_tax_treatment,
)
from apps.extraction.types import Availability, Condition
from apps.pricing.types import TaxTreatment

D = Decimal


@pytest.mark.parametrize(
    "text,locale,amount,currency",
    [
        ("£1,299.99", "en-GB", "1299.99", "GBP"),
        ("1.299,99 €", "de-DE", "1299.99", "EUR"),
        ("1 299,99", "fr-FR", "1299.99", None),
        ("1 299,99 €", "fr-FR", "1299.99", "EUR"),
        ("GBP 99", "en-GB", "99", "GBP"),
        ("99p", "en-GB", "0.99", "GBP"),
        ("£399", "en-GB", "399", "GBP"),
        ("4,20", "de-DE", "4.20", None),
        ("1,299", "en-GB", "1299", None),  # comma groups thousands in en-GB
        ("1.299", "de-DE", "1299", None),  # dot groups thousands in de-DE
        ("1,345,678.90", "en-GB", "1345678.90", None),
        ("$10.5", "en-US", "10.5", "USD"),
        ("0.00", "en-GB", "0.00", None),  # parsed; the validator then quarantines zero
    ],
)
def test_parse_price_accepts(text, locale, amount, currency):
    parsed = parse_price(text, locale)
    assert parsed.amount == D(amount)
    assert parsed.currency == currency


@pytest.mark.parametrize(
    "text,locale",
    [
        ("£6,49.00", "en-GB"),  # malformed grouping
        ("1.299", "en-GB"),  # three decimals or mis-read thousands: ambiguous in en-GB
        ("1,299", "de-DE"),
        ("Call for price", "en-GB"),
        ("from £10", "en-GB"),
        ("£10 - £20", "en-GB"),
        ("£10 €12", "en-GB"),
        ("-5.00", "en-GB"),
        ("", "en-GB"),
        ("£12.345", "en-GB"),
        ("1,2,3", "en-GB"),
        ("99999999999", "en-GB"),
        ("12 5", "en-GB"),
    ],
)
def test_parse_price_rejects_rather_than_guessing(text, locale):
    with pytest.raises(PriceParseError):
        parse_price(text, locale)


def test_parse_price_rejects_binary_floats():
    with pytest.raises(PriceParseError):
        parse_price(19.99)
    assert parse_price(D("19.99")).amount == D("19.99")
    assert parse_price(20).amount == D("20")


def test_percentage():
    assert parse_percentage("20%") == D("0.20")
    assert parse_percentage("0.2") == D("0.2")
    assert parse_percentage("20") == D("0.20")
    assert parse_percentage("VAT") is None


def test_gtin_check_digit():
    assert normalise_gtin("5060999000011") == ("5060999000011", True)
    assert normalise_gtin("5060999000012") == (None, False)
    assert normalise_gtin("50609 99000 011") == ("5060999000011", True)
    assert normalise_gtin("") == (None, True)
    assert normalise_gtin("ABC") == (None, False)


def test_condition_availability_tax():
    assert parse_condition("https://schema.org/RefurbishedCondition") is Condition.REFURBISHED
    assert parse_condition("Brand new") is Condition.NEW
    assert parse_condition("Grade A") is Condition.REFURBISHED
    assert parse_condition("pre-owned") is Condition.USED
    assert parse_condition("") is None
    assert parse_availability("https://schema.org/OutOfStock") is Availability.OUT_OF_STOCK
    assert parse_availability("In stock") is Availability.IN_STOCK
    assert parse_availability("ships soon") is Availability.UNKNOWN
    assert parse_tax_treatment("inc. VAT") is TaxTreatment.INCLUDED
    assert parse_tax_treatment("ex VAT") is TaxTreatment.EXCLUDED
    assert parse_tax_treatment("Price includes VAT") is TaxTreatment.INCLUDED
    assert parse_tax_treatment("great value") is None


def test_capacity_and_title_attributes():
    assert parse_capacity_gb("1TB") == 1024
    assert parse_capacity_gb("256 GB") == 256
    assert attributes_from_title("Lumio Aurora X5 128GB") == {"storage_gb": 128}
    assert attributes_from_title("Nimbus Book 14 Laptop 16GB RAM 512GB SSD") == {"ram_gb": 16, "storage_gb": 512}
    assert attributes_from_title("Nimbus Book 14 16GB/512GB") == {"ram_gb": 16, "storage_gb": 512}
    assert attributes_from_title("Lumio Aurora X5 5G Smartphone") == {}


def test_supplier_text_is_reduced_to_plain_text():
    assert clean_text('<b>Phone</b><script>alert(1)</script> &lt;img src=x onerror=alert(1)&gt;') == "Phone"
    assert clean_text("A‮B​C\x00D") == "ABCD"
    assert len(clean_text("x" * 1000, 50)) == 50


def test_purchase_urls_must_be_plain_http():
    assert clean_http_url("https://shop.example/p/1") == "https://shop.example/p/1"
    assert clean_http_url("javascript:alert(1)") == ""
    assert clean_http_url("https://user:pw@shop.example/") == ""
    assert clean_http_url("data:text/html,x") == ""


@pytest.mark.parametrize("value", ['=HYPERLINK("http://evil","x")', "+1+1", "-2+3", "@SUM(A1)", "\tcmd", "=1+1"])
def test_spreadsheet_formulas_are_neutralised(value):
    assert spreadsheet_safe(value).startswith("'")


def test_spreadsheet_safe_keeps_plain_values():
    assert spreadsheet_safe("TechHaven") == "TechHaven"
    assert spreadsheet_safe("-5.00") == "-5.00"
    assert spreadsheet_safe(None) == ""


def test_credentials_are_redacted_from_logs():
    assert redact({"Authorization": "Bearer abc", "url": "https://u:p@host/x"}) == {"Authorization": "[REDACTED]", "url": "https://[REDACTED]@host/x"}
    assert "abc123" not in redact("api_key=abc123 failed")
