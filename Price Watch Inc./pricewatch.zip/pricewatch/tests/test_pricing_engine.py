"""Pure pricing tests: no database, no network, no wall clock."""
from datetime import datetime, timezone
from decimal import Decimal

import pytest

from apps.pricing.engine import DefaultPricingEngine
from apps.pricing.types import (
    Charge,
    ComparisonContext,
    Completeness,
    ComponentStatus,
    CurrencyMismatchError,
    Eligibility,
    InvalidOfferError,
    MembershipState,
    Offer,
    PriceTier,
    PromotionTerms,
    TaxTreatment,
)
from apps.pricing.units import Quantity

NOW = datetime(2026, 3, 1, 12, 0, tzinfo=timezone.utc)
D = Decimal
engine = DefaultPricingEngine()


def delivery(amount: str, threshold: str | None = None) -> Charge:
    return Charge("Delivery", ComponentStatus.ADDITIONAL, D(amount), free_threshold=D(threshold) if threshold else None)


def offer(key: str, price: str, **kwargs) -> Offer:
    kwargs.setdefault("tax_treatment", TaxTreatment.INCLUDED)
    kwargs.setdefault("delivery", delivery("0.00"))
    return Offer(offer_id=key, supplier_key=key, supplier_name=f"Supplier {key}", currency="GBP", unit_price=D(price), **kwargs)


def context(**kwargs) -> ComparisonContext:
    return ComparisonContext(now=NOW, **kwargs)


def rank(offers, ctx):
    results = [(o, engine.calculate(o, ctx)) for o in offers]
    ranked = sorted((r for r in results if r[1].is_rankable), key=lambda r: (r[1].total, r[0].offer_id))
    return ranked, results


# --- Section 9: the deterministic A/B/C example --------------------------------

def abc_offers():
    return [
        offer("A", "100.00", delivery=delivery("10.00")),
        offer("B", "105.00", delivery=delivery("0.00")),
        offer("C", "95.00", membership_required="Club C"),
    ]


def test_cheapest_complete_eligible_offer_is_supplier_b_when_membership_not_held():
    ranked, results = rank(abc_offers(), context(memberships={"Club C": MembershipState.NOT_HELD}))
    assert [(o.offer_id, b.total) for o, b in ranked] == [("B", D("105.00")), ("A", D("110.00"))]
    c = dict((o.offer_id, b) for o, b in results)["C"]
    assert c.eligibility is Eligibility.INELIGIBLE
    assert not c.is_rankable


def test_unknown_membership_makes_supplier_c_conditional_not_cheapest():
    ranked, results = rank(abc_offers(), context())  # membership unknown by default
    assert ranked[0][0].offer_id == "B" and ranked[0][1].total == D("105.00")
    c = dict((o.offer_id, b) for o, b in results)["C"]
    assert c.eligibility is Eligibility.CONDITIONAL
    assert c.total == D("95.00")  # shown separately as a conditional price
    assert not c.is_rankable
    assert "do not know" in c.conditions[0]


def test_membership_held_makes_supplier_c_cheapest():
    ranked, _ = rank(abc_offers(), context(memberships={"Club C": MembershipState.HELD}))
    assert [o.offer_id for o, _ in ranked] == ["C", "B", "A"]


# --- money arithmetic ----------------------------------------------------------

def test_float_money_is_rejected():
    with pytest.raises(InvalidOfferError):
        Offer(offer_id="x", supplier_key="x", supplier_name="x", currency="GBP", unit_price=19.99)  # type: ignore[arg-type]
    with pytest.raises(InvalidOfferError):
        Charge("Delivery", ComponentStatus.ADDITIONAL, 3.99)  # type: ignore[arg-type]


def test_decimal_arithmetic_has_no_binary_drift():
    breakdown = engine.calculate(offer("x", "0.10"), context(required_quantity=Quantity(D(3), "each")))
    assert breakdown.item_subtotal == D("0.30")
    assert str(breakdown.total) == "0.30"


def test_zero_or_negative_price_cannot_become_an_offer():
    for bad in ("0.00", "-1.00"):
        with pytest.raises(InvalidOfferError):
            offer("x", bad)


def test_currency_mismatch_is_an_error_not_a_conversion():
    eur = Offer(offer_id="e", supplier_key="e", supplier_name="E", currency="EUR", unit_price=D("90.00"))
    with pytest.raises(CurrencyMismatchError):
        engine.calculate(eur, context())


# --- tax -----------------------------------------------------------------------

def test_tax_is_not_added_twice_when_included():
    breakdown = engine.calculate(offer("x", "120.00", tax_treatment=TaxTreatment.INCLUDED, tax_rate=D("0.20")), context())
    assert breakdown.tax_total == D("0")
    assert breakdown.total == D("120.00")


def test_excluded_tax_is_added_to_goods_fees_and_delivery():
    o = offer("x", "100.00", tax_treatment=TaxTreatment.EXCLUDED, tax_rate=D("0.20"), delivery=delivery("5.00"),
              fees=(Charge("Handling", ComponentStatus.ADDITIONAL, D("2.50")),))
    breakdown = engine.calculate(o, context())
    assert breakdown.tax_total == D("21.50")
    assert breakdown.total == D("129.00")


def test_excluded_tax_with_unknown_rate_is_incomplete():
    breakdown = engine.calculate(offer("x", "100.00", tax_treatment=TaxTreatment.EXCLUDED), context())
    assert breakdown.completeness is Completeness.INCOMPLETE and breakdown.total is None


def test_unknown_tax_treatment_is_incomplete():
    breakdown = engine.calculate(offer("x", "100.00", tax_treatment=TaxTreatment.UNKNOWN), context())
    assert breakdown.total is None
    assert any("Tax treatment unknown" in m for m in breakdown.missing)


# --- incomplete totals ---------------------------------------------------------

def test_unknown_delivery_is_total_incomplete_and_not_rankable():
    cheap_but_unknown = offer("U", "50.00", delivery=Charge("Delivery", ComponentStatus.UNKNOWN))
    ranked, results = rank([cheap_but_unknown, offer("K", "80.00")], context())
    assert [o.offer_id for o, _ in ranked] == ["K"]
    unknown = results[0][1]
    assert unknown.total is None and unknown.known_subtotal == D("50.00")
    assert unknown.missing == ("Delivery cost unknown",)


def test_unknown_mandatory_fee_is_incomplete_but_optional_fee_is_ignored():
    mandatory = offer("m", "10.00", fees=(Charge("Booking fee", ComponentStatus.UNKNOWN),))
    optional = offer("o", "10.00", fees=(Charge("Gift wrap", ComponentStatus.UNKNOWN, mandatory=False),))
    assert engine.calculate(mandatory, context()).total is None
    assert engine.calculate(optional, context()).total == D("10.00")


def test_included_fee_adds_nothing():
    o = offer("x", "10.00", fees=(Charge("Recycling levy", ComponentStatus.INCLUDED),))
    assert engine.calculate(o, context()).total == D("10.00")


# --- delivery thresholds, tiers, minimum order, coupons ---------------------------

def test_delivery_threshold_boundaries():
    o = offer("x", "25.00", delivery=delivery("3.99", "50.00"))
    assert engine.calculate(o, context()).total == D("28.99")
    two = engine.calculate(o, context(required_quantity=Quantity(D(2), "each")))
    assert two.delivery_total == D("0.00") and two.total == D("50.00")  # exactly at threshold


def test_threshold_uses_goods_after_discount():
    promo = PromotionTerms("10% off", "percent", D("10"))
    o = offer("x", "52.00", delivery=delivery("4.00", "50.00"), promotions=(promo,))
    breakdown = engine.calculate(o, context())
    assert breakdown.discount_total == D("5.20")
    assert breakdown.delivery_total == D("4.00")  # 46.80 is below the threshold
    assert breakdown.total == D("50.80")


def test_quantity_tiers():
    o = offer("x", "10.00", tiers=(PriceTier(3, D("9.00")), PriceTier(10, D("8.00"))))
    assert engine.calculate(o, context(required_quantity=Quantity(D(2), "each"))).total == D("20.00")
    assert engine.calculate(o, context(required_quantity=Quantity(D(3), "each"))).total == D("27.00")
    assert engine.calculate(o, context(required_quantity=Quantity(D(12), "each"))).total == D("96.00")


def test_minimum_order_not_met_is_ineligible():
    breakdown = engine.calculate(offer("x", "12.00", minimum_order_amount=D("20.00")), context())
    assert breakdown.eligibility is Eligibility.INELIGIBLE and not breakdown.is_rankable


def test_coupon_applies_only_when_customer_supplies_code():
    promo = PromotionTerms("SAVE5", "fixed", D("5.00"), code="SAVE5", min_spend=D("20.00"))
    o = offer("x", "30.00", promotions=(promo,))
    without = engine.calculate(o, context())
    assert without.total == D("30.00")
    assert without.conditional_discounts[0].potential_saving == D("5.00")
    assert engine.calculate(o, context(coupon_codes=frozenset({"SAVE5"}))).total == D("25.00")


def test_member_discount_not_assumed_when_membership_unknown():
    promo = PromotionTerms("Member price", "fixed", D("10.00"), membership_programme="Plus")
    o = offer("x", "100.00", promotions=(promo,))
    unknown = engine.calculate(o, context())
    assert unknown.total == D("100.00") and unknown.eligibility is Eligibility.ELIGIBLE
    assert unknown.conditional_discounts[0].potential_saving == D("10.00")
    held = engine.calculate(o, context(memberships={"Plus": MembershipState.HELD}))
    assert held.total == D("90.00")


def test_expired_promotion_is_ignored_using_injected_clock():
    promo = PromotionTerms("Old sale", "percent", D("50"), ends_at=datetime(2026, 2, 1, tzinfo=timezone.utc))
    assert engine.calculate(offer("x", "40.00", promotions=(promo,)), context()).total == D("40.00")


def test_only_largest_discount_is_applied():
    promos = (PromotionTerms("5 off", "fixed", D("5.00")), PromotionTerms("10%", "percent", D("10")))
    breakdown = engine.calculate(offer("x", "100.00", promotions=promos), context())
    assert breakdown.discount_total == D("10.00") and breakdown.total == D("90.00")


def test_percent_discount_rounds_half_up():
    promo = PromotionTerms("15%", "percent", D("15"))
    assert engine.calculate(offer("x", "9.99", promotions=(promo,)), context()).discount_total == D("1.50")
