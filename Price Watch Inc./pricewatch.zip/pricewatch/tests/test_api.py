"""API v1: contracts, structured errors, pagination, idempotency and server-side permissions."""
from decimal import Decimal

import pytest
from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient

from apps.accounts.models import SupplierAccount
from apps.alerts.models import PriceAlert
from apps.audit.models import CorrectionRequest
from apps.catalogue.models import Product
from apps.comparisons.models import ComparisonRequest
from apps.suppliers.models import OfferObservation, Supplier, SupplierListing

from .support import clubtronics_payload

pytestmark = pytest.mark.django_db
D = Decimal


@pytest.fixture
def api():
    return APIClient()


@pytest.fixture
def supplier_api(seeded, django_user_model):
    user = django_user_model.objects.create_user("ct-feeds", password="x-pass-12345")
    SupplierAccount.objects.create(user=user, supplier=Supplier.objects.get(slug="clubtronics"))
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Token {Token.objects.create(user=user).key}")
    return client


def assert_error(response, status, code):
    assert response.status_code == status, response.content
    body = response.json()
    assert set(body) == {"error"} and set(body["error"]) == {"code", "message", "details", "request_id"}
    assert body["error"]["code"] == code
    return body["error"]


# ------------------------------------------------------------------------- read API

def test_products_are_paginated_and_searchable(api, seeded):
    page = api.get("/api/v1/products", {"page_size": 3}).json()
    assert page["count"] == 10 and len(page["results"]) == 3 and page["next"] and page["previous"] is None
    found = api.get("/api/v1/products", {"q": "aurora x5"}).json()["results"]
    assert [p["slug"] for p in found] == ["lumio-aurora-x5", "lumio-aurora-x5-pro"]
    by_gtin = api.get("/api/v1/products", {"q": "5060999000011"}).json()["results"]
    assert [p["slug"] for p in by_gtin] == ["lumio-aurora-x5"]
    assert by_gtin[0]["variants"][0]["attributes"] == {"storage_gb": 128, "ram_gb": 8, "region": "UK"}
    assert api.get("/api/v1/products", {"category": "laptops"}).json()["count"] == 2
    assert api.get("/api/v1/products", {"page_size": 1000}).json()["results"].__len__() == 10  # capped at 100 per page


def test_product_detail_and_structured_404(api, seeded):
    product = Product.objects.get(slug="lumio-aurora-x5")
    body = api.get(f"/api/v1/products/{product.pk}").json()
    assert body["brand"] == "Lumio" and len(body["variants"]) == 2 and body["category"] == "smartphones"
    assert_error(api.get("/api/v1/products/999999"), 404, "not_found")
    assert api.get("/api/v2/products").status_code == 404  # only v1 exists; the version is explicit in the path


def test_offers_endpoint_ranks_explains_and_separates_groups(api, baseline, phone):
    url = f"/api/v1/products/{phone.product_id}/offers"
    body = api.get(url, {"variant": phone.pk}).json()
    assert [(o["supplier"]["slug"], o["price"]["total"]) for o in body["ranked"]] == [
        ("techhaven", "403.99"), ("ohmly", "404.50"), ("voltmart", "405.00"), ("gadgetgrove", "408.00")]
    assert body["winner_listing_id"] == body["ranked"][0]["listing_id"]
    assert body["mode"] == "exact" and body["requirements"]["currency"] == "GBP"
    assert [o["supplier"]["slug"] for o in body["conditional"]] == ["clubtronics"]
    assert body["conditional"][0]["price"]["eligibility"] == "conditional" and body["conditional"][0]["rank"] is None
    offer = body["ranked"][0]
    assert offer["price"]["currency"] == "GBP" and offer["price"]["completeness"] == "complete"
    assert offer["freshness"]["state"] == "fresh" and offer["condition"] == "new"
    assert offer["provenance"]["extraction_method"] == "css_selector" and offer["provenance"]["configuration_version"] == 1
    assert offer["match"]["reasons"][0]["code"] == "gtin_match"
    assert any("Storage: listing is 256 GB" in r for item in body["not_comparable"] for r in item["reasons"])
    assert [i["supplier"] for i in body["insufficient_evidence"]] == ["PixelPoint"]
    member = api.get(url, {"variant": phone.pk, "membership.clubtronics": "held"}).json()
    assert member["ranked"][0]["supplier"]["slug"] == "clubtronics" and member["ranked"][0]["price"]["total"] == "385.00"
    coupon = api.get(url, {"variant": phone.pk, "coupon": "GROVE15"}).json()
    assert coupon["ranked"][0]["price"]["total"] == "390.00"


def test_offers_endpoint_rejects_bad_requirements(api, baseline, phone):
    url = f"/api/v1/products/{phone.product_id}/offers"
    assert_error(api.get(url, {"condition": "mint"}), 400, "invalid_requirements")
    assert_error(api.get(url, {"quantity": "0"}), 400, "invalid_requirements")
    assert_error(api.get(url, {"membership.clubtronics": "maybe"}), 400, "invalid_requirements")
    assert_error(api.get(url, {"variant": "abc"}), 400, "validation_error")
    assert_error(api.get(url, {"variant": "999999"}), 404, "not_found")


def test_history_endpoint(api, baseline, phone):
    body = api.get(f"/api/v1/products/{phone.product_id}/history", {"variant": phone.pk}).json()
    assert body["variant_id"] == phone.pk and "between two consecutive points" in body["note"]
    series = {s["supplier"]: s["points"] for s in body["series"]}
    assert series["VoltMart"] == [{"observed_at": "2026-03-02T09:00:00+00:00", "item_price": "405.00"}]
    assert "PixelPoint" not in series  # not a confirmed match yet


# -------------------------------------------------------------- comparisons (POST)

def test_comparison_post_is_recorded_and_idempotent(api, baseline, phone):
    payload = {"kind": "variant", "variant_id": phone.pk, "requirements": {"memberships": {"clubtronics": "not_held"}}}
    first = api.post("/api/v1/comparisons", payload, format="json", HTTP_IDEMPOTENCY_KEY="cmp-0001-abcd")
    assert first.status_code == 201 and "Idempotent-Replayed" not in first
    body = first.json()
    assert body["ranked"][0]["supplier"]["slug"] == "techhaven" and body["ineligible"][0]["supplier"]["slug"] == "clubtronics"
    stored = ComparisonRequest.objects.get(pk=body["id"])
    assert stored.requirements["memberships"] == {"clubtronics": "not_held"} and stored.result["winner_listing_id"]
    replay = api.post("/api/v1/comparisons", payload, format="json", HTTP_IDEMPOTENCY_KEY="cmp-0001-abcd")
    assert replay.status_code == 201 and replay["Idempotent-Replayed"] == "true" and replay.json()["id"] == body["id"]
    assert ComparisonRequest.objects.count() == 1
    different = api.post("/api/v1/comparisons", {**payload, "requirements": {"quantity": 2}}, format="json",
                         HTTP_IDEMPOTENCY_KEY="cmp-0001-abcd")
    assert_error(different, 409, "conflict")
    assert_error(api.post("/api/v1/comparisons", payload, format="json", HTTP_IDEMPOTENCY_KEY="short"), 400, "invalid_idempotency_key")
    api.post("/api/v1/comparisons", payload, format="json")  # no key: processed again
    assert ComparisonRequest.objects.count() == 2


def test_comparison_post_specification_and_unit_price(api, baseline):
    spec = api.post("/api/v1/comparisons", {
        "kind": "specification", "category": "laptops",
        "specification": [{"attribute": "ram_gb", "op": "gte", "value": 16}, {"attribute": "storage_gb", "op": "gte", "value": 1000}],
    }, format="json").json()
    assert spec["mode"] == "spec_equivalent"
    assert [(o["supplier"]["slug"], o["price"]["total"]) for o in spec["ranked"]] == [("ohmly", "808.50"), ("techhaven", "815.00")]
    unit = api.post("/api/v1/comparisons", {
        "kind": "unit_price", "category": "rice", "product_form": "basmati", "quantity": {"value": "2", "unit": "kg"},
    }, format="json").json()
    assert unit["mode"] == "unit_price"
    best = unit["ranked"][0]
    assert best["price"]["total"] == "6.20" and best["unit_price"] == {"amount": "0.2100", "per": "100 g"}
    assert best["price"]["purchased_quantity"] == {"value": "2.000", "unit": "kg"}


def test_comparison_post_validation(api, baseline):
    assert_error(api.post("/api/v1/comparisons", {"kind": "variant"}, format="json"), 400, "validation_error")
    assert_error(api.post("/api/v1/comparisons", {"kind": "variant", "variant_id": 999999}, format="json"), 404, "not_found")
    bad_attribute = api.post("/api/v1/comparisons", {
        "kind": "specification", "category": "laptops", "specification": [{"attribute": "is_staff", "value": True}]}, format="json")
    assert_error(bad_attribute, 400, "invalid_requirements")
    bad_unit = api.post("/api/v1/comparisons", {"kind": "unit_price", "category": "rice", "quantity": {"value": "1", "unit": "furlong"}}, format="json")
    assert_error(bad_unit, 400, "invalid_requirements")
    details = assert_error(api.post("/api/v1/comparisons", {"kind": "variant", "variant_id": 1, "requirements": {"quantity": 0}}, format="json"),
                           400, "validation_error")["details"]
    assert "quantity" in details["requirements"]
    assert api.post("/api/v1/comparisons", "{not json", content_type="application/json").status_code == 400


def test_basket_comparison_post(api, baseline):
    body = api.post("/api/v1/basket-comparisons", {"items": [
        {"category": "rice", "product_form": "basmati", "quantity": {"value": "2", "unit": "kg"}},
        {"category": "milk", "product_form": "semi-skimmed", "quantity": {"value": "4", "unit": "l"}},
        {"category": "eggs", "product_form": "free range", "quantity": {"value": "12", "unit": "each"}},
    ]}, format="json")
    assert body.status_code == 201
    data = body.json()
    assert data["cheapest_single_supplier"]["total"] == "12.80" and data["cheapest_single_supplier"]["delivery_count"] == 1
    assert data["baseline_split"]["total"] == "17.29" and "not a guaranteed lowest total" in data["baseline_split"]["method_note"]
    assert data["exhaustive_split"]["total"] == "12.80" and data["exhaustive_split"]["combinations_evaluated"] == 27
    assert data["assumptions"] and ComparisonRequest.objects.filter(kind="basket").count() == 1
    assert_error(api.post("/api/v1/basket-comparisons", {"items": []}, format="json"), 400, "validation_error")
    assert_error(api.post("/api/v1/basket-comparisons", {"items": [{"category": "nope", "quantity": {"value": "1"}}]}, format="json"),
                 400, "validation_error")


# ---------------------------------------------------------------- alerts, corrections

def test_alerts_require_authentication_and_belong_to_the_caller(api, baseline, phone, customer):
    payload = {"variant_id": phone.pk, "target_total": "400.00",
               "requirements": {"condition": "new", "memberships": {"clubtronics": "not_held"}, "currency": "GBP"}}
    denied = api.post("/api/v1/alerts", payload, format="json")
    assert_error(denied, 401, "not_authenticated")
    assert denied["WWW-Authenticate"] == "Token" and PriceAlert.objects.count() == 0
    api.force_authenticate(customer)
    created = api.post("/api/v1/alerts", payload, format="json", HTTP_IDEMPOTENCY_KEY="alert-key-0001")
    assert created.status_code == 201
    alert = PriceAlert.objects.get()
    assert alert.user == customer and alert.target_total == D("400.00")
    assert alert.requirements == {"condition": "new", "quantity": 1, "memberships": {"clubtronics": "not_held"},
                                  "coupon_codes": [], "currency": "GBP"}
    api.post("/api/v1/alerts", payload, format="json", HTTP_IDEMPOTENCY_KEY="alert-key-0001")
    assert PriceAlert.objects.count() == 1  # retried request did not create a second alert
    assert_error(api.post("/api/v1/alerts", {**payload, "target_total": "-1"}, format="json"), 400, "validation_error")
    assert_error(api.post("/api/v1/alerts", {**payload, "user": 1, "variant_id": 999999}, format="json"), 404, "not_found")


def test_idempotency_keys_are_scoped_per_caller(api, baseline, phone, customer, other_customer):
    payload = {"variant_id": phone.pk, "target_total": "400.00"}
    api.force_authenticate(customer)
    assert api.post("/api/v1/alerts", payload, format="json", HTTP_IDEMPOTENCY_KEY="shared-key-123").status_code == 201
    api.force_authenticate(other_customer)
    assert api.post("/api/v1/alerts", payload, format="json", HTTP_IDEMPOTENCY_KEY="shared-key-123").status_code == 201
    assert set(PriceAlert.objects.values_list("user__username", flat=True)) == {"alice", "bob"}


def test_corrections_post(api, baseline, phone):
    listing = SupplierListing.objects.get(supplier_sku="VM-X5-128")
    created = api.post("/api/v1/corrections", {"listing_id": listing.pk, "kind": "wrong_price",
                                               "description": "The site shows £410 <script>alert(1)</script> not £405."}, format="json")
    assert created.status_code == 201 and created.json()["status"] == "open"
    correction = CorrectionRequest.objects.get()
    assert correction.listing == listing and correction.reporter is None and "<script>" not in correction.description
    assert_error(api.post("/api/v1/corrections", {"kind": "wrong_price", "description": "Too vague to act on."}, format="json"),
                 400, "validation_error")
    assert_error(api.post("/api/v1/corrections", {"variant_id": phone.pk, "kind": "nonsense", "description": "long enough text"}, format="json"),
                 400, "validation_error")


# -------------------------------------------------------------------- supplier API

def test_supplier_endpoints_require_a_supplier_account(api, seeded, customer):
    assert_error(api.post("/api/v1/supplier/listings", clubtronics_payload(), format="json"), 401, "not_authenticated")
    api.force_authenticate(customer)  # an ordinary customer is authenticated but not authorised
    assert_error(api.post("/api/v1/supplier/listings", clubtronics_payload(), format="json"), 403, "permission_denied")
    assert_error(api.get("/api/v1/supplier/listings"), 403, "permission_denied")
    assert SupplierListing.objects.count() == 0


def test_supplier_submits_listing_through_the_same_pipeline(supplier_api, seeded, phone):
    response = supplier_api.post("/api/v1/supplier/listings", clubtronics_payload(), format="json", HTTP_IDEMPOTENCY_KEY="sub-0001-xyz")
    assert response.status_code == 201, response.content
    body = response.json()
    assert body["status"] == "valid" and body["matched_variant_id"] == phone.pk and body["issues"] == []
    listing = SupplierListing.objects.get(pk=body["listing_id"])
    assert listing.supplier.slug == "clubtronics" and listing.supplier_sku == "CT-AX5-128"
    observation = listing.latest_valid_observation
    assert observation.price_amount == D("385.00") and observation.membership_programme == "ClubTronics Plus"
    assert observation.extraction_method == "manual_submission" and observation.evidence["price"]["snippet"] == "385.00"
    assert '"price": "385.00"' in observation.source_document.body  # the submission itself is the evidence
    supplier_api.post("/api/v1/supplier/listings", clubtronics_payload(), format="json", HTTP_IDEMPOTENCY_KEY="sub-0001-xyz")
    assert OfferObservation.objects.filter(listing=listing).count() == 1  # the retry was replayed, not re-applied
    assert [l["supplier_sku"] for l in supplier_api.get("/api/v1/supplier/listings").json()] == ["CT-AX5-128"]


def test_supplier_submission_validation_and_quarantine(supplier_api, seeded):
    zero = supplier_api.post("/api/v1/supplier/listings", {**clubtronics_payload(), "price": "0.00"}, format="json")
    assert "price" in assert_error(zero, 400, "validation_error")["details"]
    no_rate = supplier_api.post("/api/v1/supplier/listings", {**clubtronics_payload(), "tax_treatment": "excluded"}, format="json")
    assert "tax_rate" in assert_error(no_rate, 400, "validation_error")["details"]
    bad_url = supplier_api.post("/api/v1/supplier/listings", {**clubtronics_payload(), "url": "javascript:alert(1)"}, format="json")
    assert "url" in assert_error(bad_url, 400, "validation_error")["details"]
    assert OfferObservation.objects.count() == 0
    assert supplier_api.post("/api/v1/supplier/listings", clubtronics_payload(), format="json").status_code == 201
    crash = supplier_api.post("/api/v1/supplier/listings/CT-AX5-128/prices",
                              {"price": "38.50", "currency": "GBP", "tax_treatment": "included"}, format="json")
    assert crash.status_code == 201 and crash.json()["status"] == "quarantined"  # 90% drop is held for review
    assert crash.json()["issues"][0]["code"] == "suspicious_drop"
    assert SupplierListing.objects.get(supplier_sku="CT-AX5-128").latest_valid_observation.price_amount == D("385.00")


def test_supplier_price_update_omits_nothing_it_does_not_know(supplier_api, seeded):
    supplier_api.post("/api/v1/supplier/listings", clubtronics_payload(), format="json")
    updated = supplier_api.post("/api/v1/supplier/listings/CT-AX5-128/prices",
                                {"price": "379.00", "currency": "GBP", "tax_treatment": "included"}, format="json")
    assert updated.status_code == 201 and updated.json()["status"] == "valid"
    listing = SupplierListing.objects.get(supplier_sku="CT-AX5-128")
    latest = listing.latest_valid_observation
    assert latest.price_amount == D("379.00") and listing.observations.count() == 2
    delivery = latest.components.get(kind="delivery")
    assert delivery.status == "unknown" and delivery.amount is None  # not sent, so not assumed free
    assert listing.attributes == {"storage_gb": 128, "ram_gb": 8, "region": "UK"}  # identity preserved


def test_supplier_cannot_touch_another_suppliers_data(supplier_api, baseline):
    theirs = SupplierListing.objects.get(supplier_sku="VM-X5-128")
    before = theirs.observations.count()
    response = supplier_api.post("/api/v1/supplier/listings/VM-X5-128/prices",
                                 {"price": "1.00", "currency": "GBP", "tax_treatment": "included"}, format="json")
    assert_error(response, 404, "not_found")  # another supplier's SKU does not exist as far as this caller can tell
    named = supplier_api.post("/api/v1/supplier/listings", {**clubtronics_payload(), "supplier": "voltmart"}, format="json")
    assert_error(named, 403, "permission_denied")
    assert_error(supplier_api.get("/api/v1/supplier/listings", {"supplier": "voltmart"}), 403, "permission_denied")
    assert theirs.observations.count() == before
    assert not SupplierListing.objects.filter(supplier__slug="voltmart", supplier_sku="CT-AX5-128").exists()
    own = [l["supplier_sku"] for l in supplier_api.get("/api/v1/supplier/listings").json()]
    assert own == ["CT-AX5-128"]


def test_deactivated_supplier_account_loses_access(supplier_api, seeded):
    SupplierAccount.objects.update(is_active=False)
    assert_error(supplier_api.post("/api/v1/supplier/listings", clubtronics_payload(), format="json"), 403, "permission_denied")


# ---------------------------------------------------------------------- documentation

def test_openapi_schema_documents_every_endpoint(api, seeded):
    response = api.get("/api/v1/schema/", HTTP_ACCEPT="application/json")
    assert response.status_code == 200
    schema = response.json()
    assert schema["info"]["title"] == "Price Watch API" and schema["openapi"].startswith("3.")
    assert set(schema["paths"]) >= {
        "/api/v1/products", "/api/v1/products/{id}", "/api/v1/products/{id}/offers", "/api/v1/products/{id}/history",
        "/api/v1/comparisons", "/api/v1/basket-comparisons", "/api/v1/alerts", "/api/v1/corrections",
        "/api/v1/supplier/listings", "/api/v1/supplier/listings/{sku}/prices",
    }
    post = schema["paths"]["/api/v1/comparisons"]["post"]
    assert any(p["name"] == "Idempotency-Key" for p in post["parameters"]) and "409" in post["responses"]
    assert api.get("/api/v1/docs/").status_code == 200
