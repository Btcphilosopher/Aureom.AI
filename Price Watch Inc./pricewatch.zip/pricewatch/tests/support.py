"""Shared test doubles and helpers."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from html import escape
from pathlib import Path
from urllib.parse import urlsplit

from django.conf import settings

from apps.collection.fixtures import FixtureSite
from apps.collection.pipeline import run_collection
from apps.collection.types import CollectionError, FetchedDocument
from apps.suppliers.models import SourceConfiguration, Supplier
from apps.suppliers.submissions import submit_offer

BASE_TIME = datetime(2026, 3, 2, 9, 0, tzinfo=timezone.utc)
X5_128 = "5060999000011"
X5_256 = "5060999000028"
BOOK14_16 = "5060999000042"
FIXTURE_ROOT = Path(settings.BASE_DIR) / "fixtures" / "supplier_sites"


class PreRenderedRenderer:
    """Stands in for Playwright: builds the DOM PixelPoint's script would produce from its JSON."""

    def __init__(self, scenario: str = "baseline", clock=None):
        self.site = FixtureSite(FIXTURE_ROOT, scenario)
        self.clock = clock
        self.rendered: list[str] = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        return None

    async def render(self, url: str, *, wait_for_selector=None) -> FetchedDocument:
        parts = urlsplit(url)
        found = self.site.lookup(parts.hostname, parts.path)
        if found is None:
            raise CollectionError(f"HTTP 404 rendering {url}")
        shell = found[0].decode()
        product = shell.split('data-product="')[1].split('"')[0]
        data = json.loads(self.site.lookup(parts.hostname, f"/data/{product}.json")[0])
        rows = "".join(f"<tr><th>{escape(k)}</th><td>{escape(v)}</td></tr>" for k, v in data["specs"].items())
        html = (
            f'<html><body><div id="app"><h1 class="pp-title">{escape(data["title"])}</h1>'
            f'<p class="pp-brand">{escape(data["brand"])}</p><p class="pp-model">{escape(data["model"])}</p>'
            f'<p class="pp-sku">{escape(data["sku"])}</p><p class="pp-price">{escape(data["price"])}</p>'
            f'<p class="pp-vat">{escape(data["vat"])}</p><p class="pp-condition">{escape(data["condition"])}</p>'
            f'<p class="pp-stock">{escape(data["stock"])}</p><p class="pp-delivery">{escape(data["delivery"])}</p>'
            f'<table class="pp-specs">{rows}</table></div></body></html>'
        )
        self.rendered.append(url)
        body = html.encode()
        return FetchedDocument(url, url, 200, "text/html", html, hashlib.sha256(body).hexdigest(), len(body),
                               self.clock.now() if self.clock else BASE_TIME, method="browser")


def collect(clock, *, scenario: str | None = None, only: list[str] | None = None) -> dict:
    """Collect fixture sources synchronously; returns ``{source key: CollectionRun}``."""
    sources = SourceConfiguration.objects.select_related("supplier").exclude(kind="manual").order_by("key")
    if only:
        sources = sources.filter(key__in=only)
    runs = {}
    for source in sources:
        runs[source.key] = run_collection(
            source, clock=clock, scenario=scenario,
            renderer_factory=lambda snapshot: PreRenderedRenderer(scenario or "baseline", clock),
        )
    return runs


def clubtronics_payload() -> dict:
    return json.loads((Path(settings.BASE_DIR) / "fixtures" / "feeds" / "clubtronics_submission.json").read_text())


def submit_clubtronics(clock, actor=None, **changes):
    return submit_offer(Supplier.objects.get(slug="clubtronics"), {**clubtronics_payload(), **changes}, actor=actor, clock=clock)
