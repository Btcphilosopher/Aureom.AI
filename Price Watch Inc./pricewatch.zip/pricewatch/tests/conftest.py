import pytest
from django.core.cache import cache

from apps.catalogue.models import ProductVariant
from apps.core.clock import FixedClock, system_clock
from apps.core.seeding import seed_catalogue_and_sources

from .support import BASE_TIME, BOOK14_16, X5_128, collect, submit_clubtronics


@pytest.fixture(autouse=True)
def _clean_cache():
    cache.clear()
    yield
    cache.clear()


@pytest.fixture
def clock():
    """A fixed clock. The process clock is frozen to it, so views and services agree on "now"."""
    fixed = FixedClock(BASE_TIME)
    with system_clock.frozen(fixed):
        yield fixed


@pytest.fixture
def seeded(db):
    seed_catalogue_and_sources()


@pytest.fixture
def baseline(seeded, clock):
    """Every fixture source collected once at BASE_TIME, plus the ClubTronics manual submission."""
    runs = collect(clock)
    submit_clubtronics(clock)
    return runs


@pytest.fixture
def phone(seeded):
    return ProductVariant.objects.select_related("product__category").get(gtin=X5_128)


@pytest.fixture
def laptop(seeded):
    return ProductVariant.objects.select_related("product__category").get(gtin=BOOK14_16)


@pytest.fixture
def customer(db, django_user_model):
    return django_user_model.objects.create_user("alice", "alice@example.test", "alice-pass-123")


@pytest.fixture
def other_customer(db, django_user_model):
    return django_user_model.objects.create_user("bob", "bob@example.test", "bob-pass-123")


@pytest.fixture
def reviewer(db, django_user_model):
    return django_user_model.objects.create_user("rev", "rev@example.test", "rev-pass-123", is_staff=True)
