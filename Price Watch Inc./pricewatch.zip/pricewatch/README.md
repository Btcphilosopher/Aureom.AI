# Price Watch — Comparison Engine

A price-comparison website that collects supplier offers, matches products like-for-like, calculates the
comparable payable total, and explains which offer is cheapest **for the customer's stated requirements**.

Customers are redirected to the supplier to buy. Price Watch takes no payment and does not claim to reserve stock.
Everything is priced in an explicit currency (GBP by default); no currency conversion is performed.

* [docs/architecture.md](docs/architecture.md) — module boundaries, schema, interfaces, design decisions, dependency pins
* [docs/operations.md](docs/operations.md) — health, logs, job history, collection safety, backup and tested restore
* [docs/api-examples.md](docs/api-examples.md) — sample API requests · [docs/openapi.yaml](docs/openapi.yaml) — generated schema
* [docs/demo-output.txt](docs/demo-output.txt) — real output of the ten-step demonstration

## What is in this milestone

The end-to-end path is complete and tested:
**fixture source → extraction → validation → matching → price calculation → comparison page**,
for consumer electronics, plus a grocery adapter (unit price and baskets) built on the same pipeline.

| Area | Implemented |
|---|---|
| Sources | Supplier API (paginated, bearer credential from the environment), CSV feed, JSON feed, schema.org JSON-LD, configured CSS-selector HTML with link discovery, Playwright-rendered pages, manual supplier submissions |
| Retrieval | URL safety on every hop, robots.txt + Crawl-delay, timeouts, bounded retries with backoff and `Retry-After`, streamed size limit, request interval, response cache, typed visible failures |
| Extraction | Title, brand, GTIN (check digit), MPN, SKU, model, condition, pack/net quantity, specifications, price, currency, tax treatment and rate, fees, delivery and free threshold, availability, membership, minimum order, tiers, promotions, purchase URL |
| Provenance | Per-field evidence (method, locator, snippet, source URL), configuration version, stored source document with SHA-256, observation time separate from supplier-declared date |
| Quarantine | Malformed, zero or missing price; missing/conflicting currency; broken selectors; conflicting structured data; suspicious drop or rise; SKU identity change. Reviewed in the staff queue |
| Matching | Exact, specification-equivalent, unit-price and insufficient-evidence modes; reasons for and against stored; human review; versioned corrections |
| Pricing | `Decimal` only; item tiers, discounts, mandatory fees, delivery thresholds, tax-exclusive suppliers, minimum orders, explicit coupons, membership tri-state, "Total incomplete" |
| Baskets | Unit conversion with dimensional checks, whole-pack maths with surplus, delivery once per supplier, single-supplier baskets, labelled heuristic split, bounded exhaustive split |
| Website | Search, category browsing, specification filters, product detail, comparison table with expandable breakdown and match explanation, price-history chart with table view, saved lists, price alerts, incorrect-information reports, sponsored labelling, stale/empty/error/loading states, staff review and operations pages |
| API | The eight endpoints in the brief plus supplier listing/price endpoints; pagination, structured errors, idempotency keys, token/session auth, OpenAPI |
| Alerts | Stored requirements, complete+eligible+fresh offers only, per-alert rate limit, de-duplication |
| Operations | JSON logs with request ids and redaction, `/healthz`, `/readyz`, job history, audit trail, backup/restore scripts with a verification script |

### Not implemented, or deliberately limited

* **Docker image and Compose stack were not built or run here** — no Docker daemon was available in the build
  environment. `Dockerfile` and `compose.yaml` are provided and unverified. Everything else below was run
  directly against PostgreSQL 16 and Redis 7.
* **LLM extraction** is an interface and a deterministic validator only (`apps/extraction/llm.py`). No model
  provider is bundled and it is not called by the pipeline.
* **DNS rebinding** between the address check and the connection is not closed in-process; use an egress proxy.
* No currency conversion: offers in another currency are listed as not comparable.
* Promotions: fixed/percentage, coupon, membership and minimum-spend. Multi-buy ("3 for 2") is not modelled, and
  only the single largest eligible discount is applied.
* Baskets cover the grocery (unit-price) categories; pack sizes are not mixed within one item.
* Search is simple substring matching, not ranked full-text search.
* Alerts notify by email only (console backend by default); there is no unsubscribe link.
* Listings that disappear from a source are labelled stale but are not automatically withdrawn.
* The request-interval limit is per collection run, not coordinated across workers.
* The UI is built with semantic HTML, labelled controls, visible focus, a skip link and keyboard-operable
  disclosures, and was checked visually at desktop and phone widths. It has **not** been audited with a screen
  reader or an automated accessibility checker.
* The price-history chart plots at most six suppliers; the table view and CSV export contain all of them.

## Run it locally (no Docker)

Requirements: Python 3.13 (the only version tested), PostgreSQL 14+ (tested on 16), Redis 6.2+ (tested on 7.0). Chromium is needed only for the browser-rendered
fixture supplier.

```bash
python -m venv .venv && . .venv/bin/activate
```

```bash
pip install -r requirements.lock
```

```bash
playwright install chromium
```

Create a database and role:

```bash
psql -U postgres -c "CREATE ROLE pricewatch LOGIN CREATEDB PASSWORD 'pricewatch'" -c "CREATE DATABASE pricewatch OWNER pricewatch"
```

Configure the environment for local development:

```bash
export DJANGO_DEBUG=true DATABASE_URL=postgresql://pricewatch:pricewatch@127.0.0.1:5432/pricewatch PRICEWATCH_FIXTURE_MODE=true GADGETGROVE_API_KEY=fixture-demo-key REDIS_URL=redis://127.0.0.1:6379/1 CELERY_BROKER_URL=redis://127.0.0.1:6379/0
```

```bash
python manage.py migrate
```

Run the ten-step demonstration (seeds the fictional catalogue, suppliers and accounts, then collects, changes
prices, fails a source, fires an alert and reviews matches). It prints a one-time password for the `demo`,
`reviewer` (staff) and `clubtronics-supplier` accounts, or pass your own:

```bash
python manage.py run_demo --password 'choose-a-password'
```

```bash
python manage.py runserver
```

Open <http://127.0.0.1:8000/>. Try `/p/lumio-aurora-x5/`, change "ClubTronics Plus member?", sign in as `reviewer`
for `/review/` and `/ops/`, and see `/api/v1/docs/`.

Background jobs (optional for the demo; the operations page and schedules use them):

```bash
celery -A config worker --loglevel INFO --concurrency 2
```

```bash
celery -A config beat --loglevel INFO
```

Other commands:

```bash
python manage.py seed_demo --with-users
```

```bash
python manage.py collect_sources --scenario price_change
```

```bash
python manage.py collect_sources --source techhaven-html --scenario outage
```

```bash
python manage.py evaluate_alerts
```

```bash
python manage.py spectacular --file docs/openapi.yaml --validate
```

If Chromium is not installed where Playwright expects it, set `PLAYWRIGHT_CHROMIUM_EXECUTABLE=/path/to/chrome`
(and `PLAYWRIGHT_NO_SANDBOX=true` when running as root). Without a browser, the PixelPoint source fails visibly
and everything else still works.

## Run with Docker Compose (provided, not verified here)

```bash
cp .env.example .env
```

Edit `.env` (at least `DJANGO_SECRET_KEY` and `POSTGRES_PASSWORD`, and the same password inside `DATABASE_URL`), then:

```bash
docker compose up --build
```

```bash
docker compose exec web python manage.py run_demo --password 'choose-a-password'
```

## Tests

```bash
pytest
```

Tests need PostgreSQL (a role with `CREATEDB`) and use `config.settings_test`: fixture suppliers, eager Celery,
in-memory email and cache, and a fixed clock. No test touches the network or the wall clock. The browser tests
launch a real Chromium and are skipped with a reason if none can be started.

| File | What it covers |
|---|---|
| `tests/test_pricing_engine.py` | The Supplier A/B/C example, money arithmetic, tax, incomplete totals, thresholds, tiers, coupons, membership |
| `tests/test_units_and_basket.py` | Unit conversion, dimensional errors, pack maths, basket strategies vs. brute force |
| `tests/test_parsing.py` | Locale price parsing, GTIN, conditions, sanitisation, spreadsheet-formula neutralisation, log redaction |
| `tests/test_extraction.py` | JSON-LD, selectors, feeds, missing-stays-missing, quarantine rules, LLM suggestion gate |
| `tests/test_matching.py` | Variant identity: storage, region, model, condition, contents; candidate retrieval; other modes |
| `tests/test_collection_safety.py` | Unsafe URLs, redirect abuse, size limits, retries, robots, access controls, credential forwarding |
| `tests/test_pipeline.py` | The ten acceptance demonstrations end to end, source failures, alerts, review, grocery |
| `tests/test_api.py` | Contracts, structured errors, pagination, idempotency, authentication, cross-supplier isolation |
| `tests/test_web.py` | Rendering, state labels, CSP, markup injection, outbound-redirect allow-list, CSV export, cross-account access, CSRF, staff-only pages |
| `tests/test_browser.py` | Real Playwright render, private-address blocking inside the page, page budget, full pipeline |

## The pricing rule

```
  eligible item subtotal        (whole packs × tier price)
− eligible discounts            (largest single eligible promotion; coupons only when you supply the code)
+ mandatory fees                (included → adds nothing; unknown → total incomplete)
+ applicable delivery           (free threshold tested against goods after discount; unknown → total incomplete)
+ applicable tax not included   (only when the price is tax-exclusive and the rate is known)
= comparable payable total
```

Only **complete** totals the customer is **known to be eligible for** are ranked. Conditional (membership
unknown), incomplete, ineligible and out-of-stock offers are shown in their own groups with the reason.

The deterministic example from the brief is `tests/test_pricing_engine.py`: Supplier A £100 + £10 delivery,
Supplier B £105 + £0, Supplier C £95 members-only. With membership not held, B wins at £105.00; with membership
unknown, C is shown as conditional at £95.00 and B is still the confirmed cheapest; with membership held, C wins.

## Repository layout

```
manage.py · pyproject.toml · requirements.lock · compose.yaml · Dockerfile · .env.example
config/            settings, test settings, urls, celery
apps/
  core/            clock, logging, middleware, health, sanitisation, demo data and commands
  accounts/        User, SupplierAccount, CustomerMembership
  catalogue/       Category, Product, ProductVariant
  suppliers/       Supplier, SourceConfiguration, SupplierListing, OfferObservation, PriceComponent, Promotion; ingest; submissions
  collection/      CollectionRun, SourceDocument; safety, fetcher, browser, fixtures, adapters/, pipeline, tasks
  extraction/      parsing, structured (JSON-LD), html (selectors), feeds, normalise, validation, llm (gate only)
  matching/        MatchDecision; matcher (pure), services (storage, review)
  pricing/         types, units, engine, basket (all pure)
  comparisons/     ComparisonRequest, SavedSearch; comparison service and serialisation
  alerts/          PriceAlert, AlertNotification; evaluation; task
  audit/           AuditEvent, CorrectionRequest
  api/             DRF serializers, views, idempotency, structured errors, pagination
  web/             views, chart geometry, template tags
templates/ · static/ (css, js, vendored htmx 2.0.11)
fixtures/supplier_sites/   nine fictional suppliers + _scenarios/{price_change,outage,redesign}
fixtures/feeds/            sample manual submission and a guide to the feeds
scripts/                   backup.sh, restore.sh, verify_restore.sh
tests/ · docs/
```

Departures from the suggested structure: `apps/api` and `apps/web` were added to keep presentation out of the
domain apps, and `apps/core` holds cross-cutting code. The CSV/JSON feeds live inside `fixtures/supplier_sites/`
so they are fetched through the same path as a real feed; `fixtures/feeds/` documents them.

## Suggested next milestone

Each item names the files it would add or change:

1. **Build and verify the container stack** — run `docker compose up --build`, fix anything found in
   `Dockerfile` / `compose.yaml`, add `.github/workflows/ci.yml` running `pytest` against service containers.
2. **Egress enforcement** — `apps/collection/transport.py` (connect to the already-validated address) or a
   proxy service in `compose.yaml`, with tests in `tests/test_collection_safety.py`.
3. **Wire optional LLM suggestions** — `apps/extraction/llm_provider.py` implementing `LLMSuggester`, a pipeline
   hook in `apps/collection/pipeline.py` behind `PRICEWATCH_LLM_EXTRACTION`, review UI in `templates/web/review.html`.
4. **Source configuration UI** — `apps/web/views_sources.py`, `templates/web/source_edit.html` with a
   "test these selectors" preview against a stored `SourceDocument`.
5. **Search and scale** — PostgreSQL full-text search migration in `apps/catalogue/migrations/`, a
   `ListingPriceSummary` read model in `apps/comparisons/models.py` for list pages.
6. **Alerts** — unsubscribe tokens and digest emails in `apps/alerts/services.py`, templates in `templates/email/`.
7. **Accessibility audit** — automated checks in `tests/test_accessibility.py` plus a manual screen-reader pass.
