"""Test settings: fixture suppliers, eager Celery, in-memory mail and cache. No network, no wall clock."""
import os

os.environ.setdefault("DJANGO_SECRET_KEY", "test-only-secret-key")
os.environ.setdefault("PRICEWATCH_INSECURE_HTTP", "true")
os.environ.setdefault("GADGETGROVE_API_KEY", "fixture-demo-key")

from .settings import *  # noqa: E402,F401,F403
from .settings import PRICEWATCH, REST_FRAMEWORK  # noqa: E402

DEBUG = False
PRICEWATCH = {**PRICEWATCH, "FIXTURE_MODE": True, "FIXTURE_SCENARIO": "baseline", "ALLOWED_PRIVATE_HOSTS": frozenset()}
CELERY_TASK_ALWAYS_EAGER = True
EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"
CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache", "LOCATION": "pricewatch-tests"}}
PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]
REST_FRAMEWORK = {**REST_FRAMEWORK, "DEFAULT_THROTTLE_RATES": {"anon": "10000/min", "user": "10000/min", "corrections": "10000/min"}}
LOGGING = {"version": 1, "disable_existing_loggers": False, "root": {"handlers": [], "level": "CRITICAL"}}
