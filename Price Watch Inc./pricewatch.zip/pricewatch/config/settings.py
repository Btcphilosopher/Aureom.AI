"""Price Watch settings.

Every deployment-specific value comes from the environment (see ``.env.example``).
Nothing secret is committed; source credentials are referenced by *environment
variable name* from ``SourceConfiguration.credential_env_var`` and never stored
in the database.
"""
from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import unquote, urlsplit

from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent


def env(name: str, default: str | None = None) -> str | None:
    value = os.environ.get(name)
    return default if value is None or value == "" else value


def env_bool(name: str, default: bool = False) -> bool:
    value = env(name)
    return default if value is None else value.strip().lower() in {"1", "true", "yes", "on"}


def env_list(name: str, default: str = "") -> list[str]:
    return [item.strip() for item in (env(name, default) or "").split(",") if item.strip()]


def database_from_url(url: str) -> dict:
    parts = urlsplit(url)
    if parts.scheme in {"postgres", "postgresql"}:
        return {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": unquote(parts.path.lstrip("/")),
            "USER": unquote(parts.username or ""),
            "PASSWORD": unquote(parts.password or ""),
            "HOST": parts.hostname or "",
            "PORT": str(parts.port or ""),
            "CONN_MAX_AGE": 60,
            "CONN_HEALTH_CHECKS": True,
        }
    if parts.scheme == "sqlite":
        # Convenience for quick local experiments only; PostgreSQL is the supported store.
        name = parts.path[1:] if parts.path.startswith("/") else parts.path
        return {"ENGINE": "django.db.backends.sqlite3", "NAME": name or str(BASE_DIR / "db.sqlite3")}
    raise ImproperlyConfigured(f"Unsupported DATABASE_URL scheme: {parts.scheme!r}")


DEBUG = env_bool("DJANGO_DEBUG", False)

SECRET_KEY = env("DJANGO_SECRET_KEY")
if not SECRET_KEY:
    if DEBUG or env_bool("PRICEWATCH_ALLOW_INSECURE_KEY", False):
        SECRET_KEY = "insecure-development-key-do-not-use-in-production"
    else:
        raise ImproperlyConfigured("DJANGO_SECRET_KEY must be set when DJANGO_DEBUG is false.")

ALLOWED_HOSTS = env_list("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1")
CSRF_TRUSTED_ORIGINS = env_list("DJANGO_CSRF_TRUSTED_ORIGINS")

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.humanize",
    "rest_framework",
    "rest_framework.authtoken",
    "drf_spectacular",
    "drf_spectacular_sidecar",
    "apps.core",
    "apps.accounts",
    "apps.catalogue",
    "apps.suppliers",
    "apps.collection",
    "apps.extraction",
    "apps.matching",
    "apps.pricing",
    "apps.comparisons",
    "apps.alerts",
    "apps.audit",
    "apps.api",
    "apps.web",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "apps.core.middleware.RequestIdMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "apps.core.middleware.SecurityHeadersMiddleware",
]

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "apps.web.context_processors.site",
            ],
        },
    }
]

DATABASES = {
    "default": database_from_url(
        env("DATABASE_URL", "postgresql://pricewatch:pricewatch@127.0.0.1:5432/pricewatch")
    )
}
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

AUTH_USER_MODEL = "accounts.User"
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", "OPTIONS": {"min_length": 10}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]
LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "web:home"
LOGOUT_REDIRECT_URL = "web:home"

LANGUAGE_CODE = "en-gb"
TIME_ZONE = "Europe/London"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"
STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage"},
}

REDIS_URL = env("REDIS_URL")
if REDIS_URL:
    CACHES = {"default": {"BACKEND": "django.core.cache.backends.redis.RedisCache", "LOCATION": REDIS_URL}}
else:
    CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache", "LOCATION": "pricewatch"}}

# --- Celery -----------------------------------------------------------------
CELERY_BROKER_URL = env("CELERY_BROKER_URL", REDIS_URL or "redis://127.0.0.1:6379/0")
CELERY_RESULT_BACKEND = env("CELERY_RESULT_BACKEND", CELERY_BROKER_URL)
CELERY_TASK_ALWAYS_EAGER = env_bool("CELERY_TASK_ALWAYS_EAGER", False)
CELERY_TASK_EAGER_PROPAGATES = True
CELERY_TASK_TIME_LIMIT = 300
CELERY_TASK_SOFT_TIME_LIMIT = 240
CELERY_TASK_ACKS_LATE = True
CELERY_WORKER_MAX_TASKS_PER_CHILD = 100  # recycles workers so browser leaks cannot accumulate
CELERY_TIMEZONE = "UTC"
CELERY_BEAT_SCHEDULE = {
    "collect-due-sources": {"task": "apps.collection.tasks.collect_due_sources", "schedule": 300.0},
    "evaluate-price-alerts": {"task": "apps.alerts.tasks.evaluate_active_alerts", "schedule": 900.0},
    "prune-idempotency-records": {"task": "apps.api.tasks.prune_idempotency_records", "schedule": 86400.0},
}

# --- Django REST Framework --------------------------------------------------
REST_FRAMEWORK = {
    "DEFAULT_VERSIONING_CLASS": "rest_framework.versioning.NamespaceVersioning",
    "DEFAULT_VERSION": "v1",
    "ALLOWED_VERSIONS": ["v1"],
    "DEFAULT_AUTHENTICATION_CLASSES": [
        # Token first so unauthenticated API calls get 401 + WWW-Authenticate rather than 403.
        "rest_framework.authentication.TokenAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.IsAuthenticatedOrReadOnly"],
    "DEFAULT_PAGINATION_CLASS": "apps.api.pagination.StandardPagination",
    "PAGE_SIZE": 20,
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "EXCEPTION_HANDLER": "apps.api.errors.structured_exception_handler",
    "DEFAULT_THROTTLE_CLASSES": [
        "rest_framework.throttling.AnonRateThrottle",
        "rest_framework.throttling.UserRateThrottle",
    ],
    "DEFAULT_THROTTLE_RATES": {
        "anon": env("API_THROTTLE_ANON", "120/min"),
        "user": env("API_THROTTLE_USER", "600/min"),
        "corrections": env("API_THROTTLE_CORRECTIONS", "20/hour"),
    },
    "DEFAULT_RENDERER_CLASSES": ["rest_framework.renderers.JSONRenderer"],
    "DEFAULT_PARSER_CLASSES": ["rest_framework.parsers.JSONParser"],
    "COERCE_DECIMAL_TO_STRING": True,
    "TEST_REQUEST_DEFAULT_FORMAT": "json",
}
SPECTACULAR_SETTINGS = {
    "TITLE": "Price Watch API",
    "DESCRIPTION": (
        "Comparison Engine API. Money values are decimal strings with an explicit ISO 4217 "
        "currency. POST endpoints accept an `Idempotency-Key` header."
    ),
    "VERSION": "1.0.0",
    "SERVE_INCLUDE_SCHEMA": False,
    "SWAGGER_UI_DIST": "SIDECAR",
    "SWAGGER_UI_FAVICON_HREF": "SIDECAR",
    "REDOC_DIST": "SIDECAR",
    "SCHEMA_PATH_PREFIX": r"/api/v1",
}

# --- Price Watch ------------------------------------------------------------
PRICEWATCH = {
    "DEFAULT_CURRENCY": "GBP",
    "COLLECTION_USER_AGENT": env(
        "PRICEWATCH_USER_AGENT", "PriceWatchBot/1.0 (+https://pricewatch.example/bot)"
    ),
    # Fixture mode serves the fictional supplier sites from ./fixtures instead of the network.
    "FIXTURE_MODE": env_bool("PRICEWATCH_FIXTURE_MODE", False),
    "FIXTURE_ROOT": BASE_DIR / "fixtures" / "supplier_sites",
    "FIXTURE_SCENARIO": env("PRICEWATCH_FIXTURE_SCENARIO", "baseline"),
    # Exact hostnames that may resolve to private addresses (e.g. an on-prem supplier feed).
    "ALLOWED_PRIVATE_HOSTS": frozenset(env_list("PRICEWATCH_ALLOWED_PRIVATE_HOSTS")),
    "ALLOWED_PORTS": frozenset({80, 443}),
    "SUSPICIOUS_DROP_RATIO": "0.50",  # quarantine if the price falls by more than 50% between checks
    "SUSPICIOUS_RISE_RATIO": "3.00",  # ... or more than triples
    "BROWSER_MAX_CONCURRENT_PAGES": int(env("PRICEWATCH_BROWSER_MAX_PAGES", "2") or 2),
    "BROWSER_EXECUTABLE": env("PLAYWRIGHT_CHROMIUM_EXECUTABLE"),
    "BROWSER_NO_SANDBOX": env_bool("PLAYWRIGHT_NO_SANDBOX", False),
    "ALERT_MIN_INTERVAL_HOURS": 24,
    "LLM_EXTRACTION_ENABLED": env_bool("PRICEWATCH_LLM_EXTRACTION", False),
}

EMAIL_BACKEND = env("DJANGO_EMAIL_BACKEND", "django.core.mail.backends.console.EmailBackend")
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", "alerts@pricewatch.example")

# --- Security ---------------------------------------------------------------
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"
X_FRAME_OPTIONS = "DENY"
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"
if not DEBUG and not env_bool("PRICEWATCH_INSECURE_HTTP", False):
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_SSL_REDIRECT = env_bool("DJANGO_SECURE_SSL_REDIRECT", True)
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    SECURE_REDIRECT_EXEMPT = [r"^healthz$", r"^readyz$"]
DATA_UPLOAD_MAX_MEMORY_SIZE = 1_000_000

# --- Logging ----------------------------------------------------------------
LOG_LEVEL = env("LOG_LEVEL", "INFO")
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "json": {"()": "apps.core.logging.JsonFormatter"},
        "plain": {"format": "%(levelname)s %(name)s %(message)s"},
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "plain" if env_bool("LOG_PLAIN", False) else "json",
        }
    },
    "root": {"handlers": ["console"], "level": LOG_LEVEL},
    "loggers": {
        "django.request": {"level": "WARNING"},
        "httpx": {"level": "WARNING"},
        "pricewatch": {"level": LOG_LEVEL},
    },
}
