from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path

from apps.core import health

urlpatterns = [
    path("healthz", health.liveness, name="healthz"),
    path("readyz", health.readiness, name="readyz"),
    path("admin/", admin.site.urls),
    path("accounts/login/", auth_views.LoginView.as_view(), name="login"),
    path("accounts/logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("api/v1/", include(("apps.api.urls", "api"), namespace="v1")),
    path("", include(("apps.web.urls", "web"), namespace="web")),
]

handler404 = "apps.web.views.not_found"
handler500 = "apps.web.views.server_error"
