"""Celery application. Tasks live in ``apps.<app>.tasks`` and only orchestrate services."""
import os

from celery import Celery

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

app = Celery("pricewatch")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()
