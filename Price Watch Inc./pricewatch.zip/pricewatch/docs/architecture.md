# Architecture

Price Watch is a Django monolith with strict internal module boundaries. The pure
domain logic (pricing, matching, extraction) has no Django or I/O dependencies and is
tested without a database.

```
                 ┌────────────────────────── Celery beat / operator / supplier API ─────────────────────────┐
                 ▼                                                                                            │
 collection ──► extraction ──► validation ──► suppliers.services.ingest ──► matching ──► comparisons ──► web / api
 (fetch only)   (parse only)   (publish or     (immutable observations)     (versioned    (read models,    (presentation
                               quarantine)                                   decisions)    explanation)     only)
                                                                                  ▲              │
                                                                               pricing ◄─────────┘  (pure Decimal arithmetic)
```

| Module | Responsibility | May import |
|---|---|---|
| `apps/pricing` | `Decimal` money, units, pack maths, total calculation, basket strategies | stdlib only |
| `apps/extraction` | Parse HTML/JSON-LD/CSV/JSON into `RawListing`, normalise, validate, (optional) LLM suggestion gate | `pricing` types |
| `apps/matching` | `RuleBasedMatcher` (pure) + versioned `MatchDecision` storage and review | `extraction`, `pricing` types |
| `apps/collection` | URL safety, `SafeFetcher` (HTTPX), `PlaywrightRenderer`, adapters, pipeline, Celery tasks, job history | all of the above |
| `apps/suppliers` | Suppliers, source configurations, listings, immutable observations, ingest, manual submissions | — |
| `apps/catalogue` | Canonical categories, products, variants | — |
| `apps/comparisons` | Builds `Offer`s from observations, runs engine + matcher, ranks, explains, serialises | — |
| `apps/alerts` | Alert storage and evaluation | `comparisons` |
| `apps/audit` | Append-only audit events, correction requests | — |
| `apps/api`, `apps/web` | DRF endpoints and server-rendered HTMX pages. No business rules. | services only |
| `apps/core` | Clock, logging, middleware, health checks, sanitisation, demo commands | — |

## Typed interfaces

The three protocols from the brief exist as written, with their referenced types:

* `apps/collection/types.py` — `SourceAdapter.collect(CollectionQuery) -> CollectionResult`, plus `Fetcher`,
  `PageRenderer`, `FetchPolicy`, `FetchedDocument`, `SourceSnapshot` and the `CollectionError` hierarchy.
* `apps/matching/types.py` — `ProductMatcher.evaluate(NormalisedListing, ProductSpecification) -> MatchResult`.
* `apps/pricing/types.py` — `PricingEngine.calculate(Offer, ComparisonContext) -> PriceBreakdown`.

Error behaviour:

| Interface | Raises | Never raises for |
|---|---|---|
| `SourceAdapter.collect` | `SourceConfigurationError` (unusable configuration) | Per-URL failures: timeouts, denials, oversize, bad feeds. These are returned in `CollectionResult.failures` and the adapter continues. |
| `ProductMatcher.evaluate` | nothing | Missing evidence → `insufficient_evidence` / `needs_review`. |
| `PricingEngine.calculate` | `CurrencyMismatchError`, `IncompatibleUnitsError`; `InvalidOfferError` at `Offer` construction (float money, non-positive price) | Unknown charges or tax → an **incomplete** breakdown (`total is None`). |

HTTP retrieval lives only in `SafeFetcher` and `PlaywrightRenderer`. Adapters receive them by injection; the
matcher and engine never see a URL. Clocks are injected (`apps/core/clock.py`), so tests use `FixedClock` and
never read wall-clock time.

## Material decisions

**Identity, listing and observation are three separate things.** `ProductVariant` is what a product *is*;
`SupplierListing` is what a supplier calls it; `OfferObservation` is what we saw at a moment. Observations are
insert-only (`save()` and `delete()` refuse; the admin is read-only), which is what makes price history
trustworthy. The only permitted update is the audited review transition of a quarantined observation's status;
the observed values never change.

**Two timestamps, never a "changed at".** `observed_at` is when we checked; `supplier_effective_at` is the
supplier's own declared date. When a price differs from the previous valid observation the listing stores both
ends of the window (`last_price_change_previous_check_at`, `last_price_change_observed_at`) and the UI says the
change happened "some time after" the earlier check.

**Quarantine is a publication gate, not a filter.** Malformed prices, zero prices, missing currency, broken
selectors, conflicting structured data and suspicious jumps are stored as `quarantined` observations with their
issues, so reviewers can see them — but they never become a listing's `latest_valid_observation`, never overwrite
listing details, and a database check constraint refuses a `valid` observation without a positive price and currency.

**Identifiers before attributes before text.** A verified GTIN (check digit validated) or MPN+brand identifies
the retail unit. Any contradiction rejects an exact match — including a matching GTIN with a conflicting region.
Title similarity is used only by `retrieve_candidates`; a perfect title score with no other evidence yields
`insufficient_evidence`. Attributes read from a title are marked `title` strength and can reject but not accept.

**Condition is a per-request requirement.** Stored match decisions are about identity (product, variant, contents).
The customer's required condition is checked at comparison time, so one refurbished listing is excluded from "new"
comparisons and ranked in "refurbished" ones.

**Corrections are new versions.** `MatchDecision` rows are never edited. A review inserts `version + 1` with
`supersedes` pointing at the previous row. Rules never overwrite a human decision; a partial unique index allows
at most one accepted variant per listing.

**Unknown is a first-class value.** Component status is `included | additional | unknown | not_applicable`; tax
treatment and membership state are tri-state. An unknown mandatory cost yields "Total incomplete" and removes the
offer from the ranking. Unknown membership makes an offer *conditional*: shown with its price, never ranked.

**Source defaults are explicit, versioned declarations.** A source may declare, for example, "prices include VAT"
or "delivery £3.50, free over £40". These are stored in the configuration, recorded as evidence with method
`source_default`, and tied to `configuration_version`. They are not per-page guesses.

**Freshness is about re-confirmation.** An offer is stale if the source was attempted after the observation
without re-confirming it (failed run, newer reading quarantined, listing absent), or if it is older than the
source's `freshness_hours`. Stale offers stay visible and labelled; they never trigger alerts.

**Sponsored placement is separate from ranking.** `is_sponsored` renders a labelled box; the sort key is
`(total, supplier name, id)` and never reads the flag. A test asserts the order is identical with and without it.

**Basket optimisation is bounded and labelled.** The baseline split is called a heuristic everywhere. The
exhaustive split enumerates every item→supplier assignment and only runs up to 20,000 combinations; it is
validated against hand-enumerated and brute-force examples in `tests/test_units_and_basket.py`.

**Fixture suppliers run through the real fetch path.** In fixture mode an in-process HTTPX transport answers
`*.fixture.test`, so URL checks, robots.txt, retries and size limits are all exercised with no network. Scenario
overlays (`price_change`, `outage`, `redesign`) simulate supplier changes.

**No inline script or style.** The CSP is `script-src 'self'; style-src 'self'`; htmx is vendored. Supplier text is
stripped to plain text at extraction and auto-escaped at render; no template marks supplier data safe.

## Schema

```
catalogue.Category ─┐
catalogue.Product ──┴─< catalogue.ProductVariant >───────────────┐ (accepted match, denormalised)
                                                                  │
suppliers.Supplier ─< suppliers.SourceConfiguration ─< collection.CollectionRun ─< collection.SourceDocument
        │                                                   │                              │
        └─< suppliers.SupplierListing ─< suppliers.OfferObservation (immutable) >──────────┘
                     │                          ├─< suppliers.PriceComponent  (delivery, fees, quantity tiers)
                     │                          └─< suppliers.Promotion
                     └─< matching.MatchDecision >─ ProductVariant   (versioned; supersedes → previous)

comparisons.ComparisonRequest · comparisons.SavedSearch · alerts.PriceAlert ─< alerts.AlertNotification
audit.AuditEvent (append-only) · audit.CorrectionRequest · api.IdempotencyRecord
accounts.User ─< accounts.SupplierAccount · accounts.CustomerMembership
```

All seventeen models named in the brief exist. Additions: `AlertNotification` (dedupe/rate-limit record),
`IdempotencyRecord`, `SupplierAccount`, `CustomerMembership`. Constraints worth knowing:

* `valid_observation_has_positive_price`, `observation_price_not_negative`, `additional_component_has_amount`
* `uniq_listing_per_supplier_sku`, `one_current_decision_per_pair`, `one_accepted_variant_per_listing`
* `human_decision_has_reviewer`, `alert_target_positive`, `promotion_percent_max_100`, source timeout/retry/size bounds

Money is `DecimalField(max_digits=12, decimal_places=2)` with an explicit `currency` column beside every amount.

## Dependency compatibility

Verified on 2026-11-24 from PyPI metadata and the documentation bundled in each sdist (the official
documentation sites were not reachable from the build environment, so those were the primary sources):

| Package | Pin | Basis |
|---|---|---|
| Django | 5.2.19 (LTS) | Supports Python 3.10–3.14 and PostgreSQL 14+ |
| djangorestframework | 3.17.2 | Declares Django 4.2–6.0. 3.18.x exists but drf-spectacular does not yet declare it |
| drf-spectacular | 0.30.0 | Declares Django 3.2–6.0, DRF 3.12–3.17 |
| psycopg | 3.3.9 | Django 5.2 requires ≥ 3.1.8 |
| celery | 5.7.0 | Requires redis-py ≥ 6.4, Redis server ≥ 6.2 |
| redis | 8.2.0 | Within kombu's supported range (≥ 6.4, < 9) |
| httpx | 0.28.1 | Latest stable; 1.0 is pre-release only |
| playwright | 1.65.2 | Python ≥ 3.10; `executable_path` supported |
| beautifulsoup4 / lxml | 4.15.0 / 6.1.3 | cp313 wheels available |
| htmx | 2.0.11 (vendored) | npm `latest` tag; `next` is 4.x and was deliberately not used |

`requirements.lock` is the exact set installed and tested (Python 3.13.18, PostgreSQL 16.15, Redis 7).
