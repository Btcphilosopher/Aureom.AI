# API v1 — sample requests

Base URL in these examples: `http://localhost:8000`. Interactive documentation is at `/api/v1/docs/` (Swagger UI),
`/api/v1/redoc/`, and the schema at `/api/v1/schema/`; a generated copy is in `docs/openapi.yaml`.

Conventions:

* The version is in the path (`/api/v1/`). There is no other version.
* Money is a decimal **string** with an explicit `currency`. `null` means unknown, never zero.
* List endpoints are paginated: `?page=2&page_size=50` (maximum 100) → `{"count", "next", "previous", "results"}`.
* POST endpoints accept `Idempotency-Key: <8–128 chars>`. Same key + same body returns the original response
  with `Idempotent-Replayed: true`; same key + different body returns 409.
* Errors always look like this:

```json
{"error": {"code": "validation_error", "message": "The request is invalid.", "details": {"variant_id": ["This field is required for kind=variant."]}, "request_id": "5f0c…"}}
```

Codes: `validation_error`, `invalid_requirements`, `invalid_idempotency_key`, `not_authenticated`,
`permission_denied`, `not_found`, `conflict`, `throttled`, `server_error`.

## Products

```bash
curl -s 'http://localhost:8000/api/v1/products?q=aurora&page_size=5'
```

```bash
curl -s 'http://localhost:8000/api/v1/products/1'
```

## Offers for a variant

Requirements are query parameters. Anything you omit is treated as unknown.

```bash
curl -s 'http://localhost:8000/api/v1/products/1/offers?variant=1&condition=new&quantity=1&membership.clubtronics=not_held'
```

Abbreviated response from the demonstration data at its baseline state (ids and timestamps will differ on your
system; fields omitted here are shown as `…` or left out):

```json
{
  "mode": "exact",
  "requirements": {"condition": "new", "quantity": 1, "memberships": {"clubtronics": "not_held"}, "coupon_codes": [], "currency": "GBP"},
  "explanation": ["TechHaven is the cheapest complete offer you are eligible for: £403.99 (items £399.00, delivery £4.99).", "…"],
  "ranked": [{
    "rank": 1, "group": "ranked", "sponsored": false,
    "supplier": {"slug": "techhaven", "name": "TechHaven"}, "condition": "new",
    "price": {"currency": "GBP", "total": "403.99", "completeness": "complete", "eligibility": "eligible",
              "lines": [{"kind": "item", "label": "Items", "amount": "399.00", "status": "additional", "note": "1 × 399.00"},
                        {"kind": "delivery", "label": "Delivery", "amount": "4.99", "status": "additional", "note": "Order is below the 500.00 free-delivery threshold"},
                        {"kind": "tax", "label": "Tax", "amount": "0.00", "status": "included", "note": "Prices include tax; not added again"}]},
    "freshness": {"state": "fresh", "observed_at": "2026-03-02T09:00:00+00:00", "reason": ""},
    "provenance": {"source_url": "https://techhaven.fixture.test/products/aurora-x5-128.html", "extraction_method": "css_selector", "configuration_version": 1, "observation_id": 31}
  }],
  "conditional": [], "total_incomplete": [], "unavailable": [],
  "ineligible": [{"supplier": {"slug": "clubtronics", "name": "ClubTronics"}, "rank": null, "price": {"total": "385.00", "eligibility": "ineligible", "conditions": ["Requires ClubTronics Plus membership, which you do not hold."]}}],
  "not_comparable": [{"supplier": "TechHaven", "title": "Lumio Aurora X5 5G Smartphone", "kind": "rejected_match", "reasons": ["Storage: listing is 256 GB, product is 128 GB."]}],
  "insufficient_evidence": [{"supplier": "PixelPoint", "kind": "needs_review", "reasons": ["Supplier does not state: gtin, included contents."]}]
}
```

Apply a discount code explicitly:

```bash
curl -s 'http://localhost:8000/api/v1/products/1/offers?variant=1&coupon=GROVE15'
```

## Price history

```bash
curl -s 'http://localhost:8000/api/v1/products/1/history?variant=1&condition=new'
```

Points are the times we checked. A change happened at some time between two consecutive points.

## Comparisons

Exact variant (recorded, returns an `id`):

```bash
curl -s -X POST http://localhost:8000/api/v1/comparisons \
  -H 'Content-Type: application/json' -H 'Idempotency-Key: demo-compare-0001' \
  -d '{"kind": "variant", "variant_id": 1, "requirements": {"condition": "new", "quantity": 2, "memberships": {"clubtronics": "held"}, "currency": "GBP"}}'
```

Specification-equivalent (different products that meet explicit requirements):

```bash
curl -s -X POST http://localhost:8000/api/v1/comparisons \
  -H 'Content-Type: application/json' \
  -d '{"kind": "specification", "category": "laptops", "specification": [{"attribute": "ram_gb", "op": "gte", "value": 16}, {"attribute": "storage_gb", "op": "gte", "value": 512}]}'
```

Unit price (compatible quantities; pack and brand differences stay visible):

```bash
curl -s -X POST http://localhost:8000/api/v1/comparisons \
  -H 'Content-Type: application/json' \
  -d '{"kind": "unit_price", "category": "rice", "product_form": "basmati", "quantity": {"value": "2", "unit": "kg"}}'
```

## Basket comparisons

```bash
curl -s -X POST http://localhost:8000/api/v1/basket-comparisons \
  -H 'Content-Type: application/json' \
  -d '{"items": [
        {"category": "rice", "product_form": "basmati", "quantity": {"value": "2", "unit": "kg"}},
        {"category": "milk", "product_form": "semi-skimmed", "quantity": {"value": "4", "unit": "l"}},
        {"category": "eggs", "product_form": "free range", "quantity": {"value": "12", "unit": "each"}}]}'
```

The response contains `cheapest_single_supplier`, `single_supplier_options`, `baseline_split` (a heuristic, and
labelled so in `method_note`), `exhaustive_split` (exact for the documented model; `null` beyond 20,000
combinations), `conditional_discounts`, `excluded` and `assumptions`. With the demonstration data:
single supplier £12.80 (GreenBasket, 1 delivery); baseline split £17.29 (2 deliveries); exhaustive £12.80 over 27 combinations.

## Alerts (authenticated)

```bash
curl -s -X POST http://localhost:8000/api/v1/alerts \
  -H 'Authorization: Token YOUR_TOKEN' -H 'Content-Type: application/json' -H 'Idempotency-Key: demo-alert-0001' \
  -d '{"variant_id": 1, "target_total": "400.00", "requirements": {"condition": "new", "quantity": 1, "memberships": {"clubtronics": "not_held"}, "currency": "GBP"}}'
```

The alert stores those requirements and is evaluated with exactly them. Without credentials the response is 401
`not_authenticated`. Customers can also sign in on the website and use session authentication.

## Corrections

```bash
curl -s -X POST http://localhost:8000/api/v1/corrections \
  -H 'Content-Type: application/json' \
  -d '{"listing_id": 12, "kind": "wrong_price", "description": "The supplier page shows £410.00, not £405.00."}'
```

## Supplier endpoints (authenticated, supplier accounts only)

A supplier account can act only for its own supplier. Another supplier's SKU returns 404; naming another supplier
returns 403. Submissions pass through the same validation, quarantine and matching as collected data.

Create or update a listing with its current price:

```bash
curl -s -X POST http://localhost:8000/api/v1/supplier/listings \
  -H 'Authorization: Token SUPPLIER_TOKEN' -H 'Content-Type: application/json' -H 'Idempotency-Key: ct-ax5-128-2026-11-24' \
  --data @fixtures/feeds/clubtronics_submission.json
```

```json
{"listing_id": 37, "supplier_sku": "CT-AX5-128", "observation_id": 204, "status": "valid", "issues": [], "matched_variant_id": 1}
```

Record a new price for an existing listing. Fields you omit (for example `delivery_cost`) are stored as unknown,
not as zero:

```bash
curl -s -X POST http://localhost:8000/api/v1/supplier/listings/CT-AX5-128/prices \
  -H 'Authorization: Token SUPPLIER_TOKEN' -H 'Content-Type: application/json' \
  -d '{"price": "379.00", "currency": "GBP", "tax_treatment": "included", "delivery_cost": "0.00", "availability": "in_stock", "membership_required": true}'
```

A response with `"status": "quarantined"` means the observation was stored but held for review (for example a
drop of more than 50% since the last valid price); the previously published price remains in place.

List your own listings:

```bash
curl -s http://localhost:8000/api/v1/supplier/listings -H 'Authorization: Token SUPPLIER_TOKEN'
```

The `seed_demo --with-users` command prints a token for the fictional `clubtronics-supplier` account. Tokens for
other users are created in the admin under "Auth Token".
