# Operations

## Health checks

| Endpoint | Meaning |
|---|---|
| `GET /healthz` | Process is up. Use for liveness. |
| `GET /readyz` | Database, cache and Celery broker reachable; each reported separately. 503 if any fails. Use for readiness. |

Both are exempt from the HTTPS redirect so load balancers can probe over plain HTTP.

## Logs

Logs are JSON on stdout, one object per line, with `ts`, `level`, `logger`, `message`, `request_id` and any
structured extras (`source`, `run`, `status`, `valid`, `quarantined`, ...). Send `X-Request-ID` to correlate; one
is generated otherwise and echoed in the response header and in API error bodies. Values under keys such as
`authorization`, `api_key`, `token`, `password` and URL userinfo are redacted before logging and before being
stored in audit data. Set `LOG_PLAIN=true` for human-readable local output.

## Job history and source state

* **Operations page** (`/ops/`, staff only): every source with its last attempt, last success and last failure
  shown separately, a "Collect now" button, the most recent collection runs and audit events.
* **Admin** (`/admin/`): `CollectionRun`, `SourceDocument`, `OfferObservation`, `MatchDecision` and `AuditEvent`
  are read-only there by design.
* Command line: `python manage.py collect_sources [--source KEY] [--scenario NAME]` prints the real outcome of
  each run and exits non-zero if any did not succeed.

Collection states you will see:

| State | Meaning | What customers see |
|---|---|---|
| `succeeded` | Every URL fetched and parsed | Fresh prices |
| `partial` | Some URLs failed | Listings not re-confirmed are labelled stale |
| `failed` | Nothing usable (timeout, denial, robots unreadable, missing credential, ...) | Last verified prices, labelled stale |
| source `broken` | Extraction rules matched nothing (site redesign) | Last verified prices, stale; the source stops being scheduled until an operator fixes the selectors |

Failing sources back off automatically: each consecutive failure doubles the schedule interval, capped at 8×.

## Scheduling

Celery beat enqueues `collect_due_sources` every 5 minutes and `evaluate_active_alerts` every 15 minutes. Each
source has its own `schedule_minutes`. Tasks are thin wrappers around `apps.collection.pipeline.run_collection`
and `apps.alerts.services`, so everything can also be run synchronously from a shell.

Worker limits: `CELERY_TASK_TIME_LIMIT=300`, soft limit 240, `--max-tasks-per-child 50`, and in Compose
`mem_limit` and `pids_limit` on the worker. The Playwright renderer additionally caps concurrent pages, pages per
run and per-page time, and always closes the browser when the run ends.

## Collection safety

* Only `http`/`https`, ports 80/443, no embedded credentials, and every resolved address must be globally
  routable. Checked for the entry URL **and every redirect hop**; inside the browser, for every sub-request.
* `PRICEWATCH_ALLOWED_PRIVATE_HOSTS` exempts exact hostnames only. Leave it empty unless you have an
  on-premises feed.
* robots.txt is honoured, including `Crawl-delay`. If robots.txt cannot be read (5xx, timeout) the source is not
  collected on that run. 401/403/407/451 and challenge pages end the attempt; nothing tries to get around them.
* Per source: timeout, retry count with exponential backoff (`Retry-After` honoured, capped), maximum response
  size (streamed, abandoned when exceeded), minimum interval between requests, cache TTL.
* **Residual risk — DNS rebinding.** The address check happens before connecting; a hostile DNS server could
  answer differently a moment later. In production, send collection traffic through an egress proxy or network
  policy that blocks private ranges at connect time. This is not implemented in the application.

Source credentials live only in environment variables. `SourceConfiguration.credential_env_var` stores the
variable's *name*. A missing variable is a visible `SourceConfigurationError`; a rejected credential is an
`AccessDeniedError`. Credentials are not forwarded across hosts on redirect.

## Backup

The database is the only state that must be backed up (Redis holds only the task queue and cache).

```bash
# Host tools (pg_dump must be the same major version as the server, or newer)
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/pricewatch scripts/backup.sh backups
```

```bash
# Docker Compose: uses the database container's own pg_dump
mkdir -p backups
docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -Fc "$POSTGRES_DB"' > backups/pricewatch-$(date -u +%Y%m%dT%H%M%SZ).dump
```

`backup.sh` writes a custom-format dump with owner-only permissions plus a `.sha256` file. Backups contain
personal data (accounts, alert preferences): store them encrypted and apply your retention policy.

## Restore

Restore into an **empty** database; `restore.sh` refuses to touch a database that already has tables and never
drops anything.

```bash
createdb -h HOST -U USER pricewatch_restored
```

```bash
TARGET_DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/pricewatch_restored scripts/restore.sh backups/pricewatch-YYYYMMDDTHHMMSSZ.dump
```

Then point `DATABASE_URL` at the restored database and run:

```bash
python manage.py migrate --check
```

Docker Compose equivalent, restoring into the Compose database after recreating its volume:

```bash
docker compose exec -T db sh -c 'pg_restore -U "$POSTGRES_USER" -d "$POSTGRES_DB" --no-owner --exit-on-error --single-transaction' < backups/pricewatch-YYYYMMDDTHHMMSSZ.dump
```

## Verifying that backups restore

```bash
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/pricewatch scripts/verify_restore.sh backups
```

This takes a backup, restores it into a uniquely named scratch database, compares the row count of every table
and a checksum of the price history between source and restored copies, then drops the scratch database. The
role needs `CREATEDB`. Run it on a schedule: an untested backup is not a backup.

Result recorded when this was built (PostgreSQL 16.15, demonstration data):

```
OK: restore verified — 32 tables match, 144 price observations, history checksum 85590a53a70af5cbff1812fbbc51223f
```

The Docker Compose backup and restore commands above were **not** executed in the build environment (no Docker
daemon was available); the host-tool scripts were.

## Data growth

* `SourceDocument.body` keeps the retrieved bytes as evidence (bounded per document by the source's
  `max_response_bytes`). There is no automatic retention policy yet: decide how long evidence must be kept and
  archive or trim old bodies accordingly. Observations themselves are the price history and are never deleted.
* Stored idempotency responses are pruned after 48 hours by the daily `prune_idempotency_records` task.

## Review workflow

`/review/` (staff only) has four queues: matches needing confirmation, unmatched listings whose candidates the
rules rejected, quarantined price observations, and customer reports. Every decision writes an `AuditEvent` with
the actor, and match decisions are stored as a new version.

## Production checklist

* Set a long random `DJANGO_SECRET_KEY`; set `DJANGO_ALLOWED_HOSTS` and `DJANGO_CSRF_TRUSTED_ORIGINS`.
* Remove `PRICEWATCH_INSECURE_HTTP` so secure cookies, HSTS and the HTTPS redirect are on. Terminate TLS at a
  proxy that sets `X-Forwarded-Proto`.
* Set `PRICEWATCH_FIXTURE_MODE=false`, remove the fixture suppliers, and configure real sources only where you
  have a recorded `authorisation_basis`.
* Use a real `DJANGO_EMAIL_BACKEND` for alerts.
* Put an egress control in front of the workers (see "Collection safety").
* Keep `PLAYWRIGHT_NO_SANDBOX=false` wherever user namespaces are available.
