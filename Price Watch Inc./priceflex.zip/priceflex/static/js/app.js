// PRICEFLEX: small progressive enhancements. The interface works without this file.
(function () {
  "use strict";
  // Hover tooltip for chart hit areas.
  document.addEventListener("mousemove", function (event) {
    var target = event.target.closest ? event.target.closest("[data-tip]") : null;
    var wrap = target ? target.closest(".chart-wrap") : null;
    document.querySelectorAll(".tooltip").forEach(function (el) {
      if (!wrap || el.parentNode !== wrap) { el.remove(); }
    });
    if (!target || !wrap) { return; }
    var tip = wrap.querySelector(".tooltip");
    if (!tip) {
      tip = document.createElement("div");
      tip.className = "tooltip";
      tip.setAttribute("role", "status");
      wrap.appendChild(tip);
    }
    tip.textContent = target.getAttribute("data-tip");
    var box = wrap.getBoundingClientRect();
    var x = Math.max(90, Math.min(box.width - 90, event.clientX - box.left));
    tip.style.left = x + "px";
    tip.style.top = (event.clientY - box.top) + "px";
  });
  // Ask before irreversible-looking actions.
  document.addEventListener("submit", function (event) {
    var message = event.target.getAttribute("data-confirm");
    if (message && !window.confirm(message)) { event.preventDefault(); }
  });
})();
