from django.conf import settings
from django.db import models


class PricingPolicy(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        ACTIVE = "active", "Active"
        ARCHIVED = "archived", "Archived"

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="policies")
    code = models.SlugField(max_length=64)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.ACTIVE)
    current_version = models.ForeignKey("PolicyVersion", null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    automation_authorised = models.BooleanField(
        default=False,
        help_text="An administrator must authorise bounded automation; the policy config alone is not enough.")
    automation_authorised_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                                                 on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "pricing policies"
        constraints = [models.UniqueConstraint(fields=["organisation", "code"], name="uniq_policy_code")]

    def __str__(self) -> str:
        return self.name


class PolicyVersion(models.Model):
    """An immutable revision of a policy's configuration."""

    policy = models.ForeignKey(PricingPolicy, on_delete=models.CASCADE, related_name="versions")
    number = models.PositiveIntegerField()
    config = models.JSONField()
    config_hash = models.CharField(max_length=64)
    change_note = models.CharField(max_length=300, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["policy", "-number"]
        constraints = [models.UniqueConstraint(fields=["policy", "number"], name="uniq_policy_version")]

    def save(self, *args, **kwargs):
        if self.pk is not None:
            raise RuntimeError("Policy versions are immutable; create a new version instead")
        super().save(*args, **kwargs)

    @property
    def label(self) -> str:
        return f"{self.policy.code}@v{self.number}"

    def __str__(self) -> str:
        return self.label


class Promotion(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        APPROVED = "approved", "Approved"
        CANCELLED = "cancelled", "Cancelled"

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="promotions")
    code = models.SlugField(max_length=64)
    name = models.CharField(max_length=200)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.DRAFT)
    kind = models.CharField(max_length=16, choices=[("fixed_price", "Fixed price"), ("percent_off", "Percent off")])
    value = models.DecimalField(max_digits=12, decimal_places=4)
    funding = models.CharField(max_length=12, default="merchant",
                               choices=[("merchant", "Merchant"), ("supplier", "Supplier"), ("shared", "Shared")])
    supplier_funding_per_unit = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    approved_min_contribution_margin = models.DecimalField(max_digits=6, decimal_places=4, null=True, blank=True)
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField()
    eligibility = models.CharField(max_length=300, blank=True)
    listings = models.ManyToManyField("catalogue.ChannelListing", related_name="promotions", blank=True)
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    approved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-starts_at"]
        constraints = [models.UniqueConstraint(fields=["organisation", "code"], name="uniq_promotion_code")]

    def __str__(self) -> str:
        return self.name


class PriceCommitment(models.Model):
    """An explicitly recorded contractual restriction on a listing's price."""

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="commitments")
    listing = models.ForeignKey("catalogue.ChannelListing", on_delete=models.CASCADE, related_name="commitments")
    kind = models.CharField(max_length=12, choices=[("min_price", "Minimum price"), ("max_price", "Maximum price"),
                                                    ("fixed_price", "Fixed price")])
    value = models.DecimalField(max_digits=12, decimal_places=2)
    reference = models.CharField(max_length=200, help_text="Contract or agreement reference")
    valid_from = models.DateTimeField(null=True, blank=True)
    valid_to = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
