from __future__ import annotations

from django.db import transaction
from django.utils import timezone

from apps.accounts.permissions import require
from apps.audit.services import record
from engine.policy import PolicyValidationError, validate_policy
from engine.types import snapshot_hash

from .models import PolicyVersion, PricingPolicy, Promotion


def save_policy(membership, *, code: str, name: str, config: dict, description: str = "",
                change_note: str = "") -> PolicyVersion:
    """Create a policy, or a new immutable version of an existing one.

    The configuration is validated by the pricing engine before anything is
    stored. Policies are only ever written by authorised members - nothing
    supplied by an external feed can create or alter one.
    """
    require(membership, "edit_policy")
    errors = validate_policy(config)
    if errors:
        raise PolicyValidationError(errors)
    org = membership.organisation
    with transaction.atomic():
        policy, created = PricingPolicy.objects.select_for_update().get_or_create(
            organisation=org, code=code, defaults={"name": name, "description": description})
        digest = snapshot_hash(config)
        latest = policy.versions.order_by("-number").first()
        if latest and latest.config_hash == digest:
            return latest
        if not created:
            policy.name, policy.description = name or policy.name, description or policy.description
        version = PolicyVersion.objects.create(policy=policy, number=(latest.number + 1) if latest else 1,
                                               config=config, config_hash=digest, change_note=change_note[:300],
                                               created_by=membership.user)
        policy.current_version = version
        if config.get("automation", {}).get("enabled") is not True:
            policy.automation_authorised = False
        policy.save()
        record(org, membership.user, "policy.version_created", version,
               f"Policy '{policy.code}' revised to v{version.number}",
               {"change_note": change_note, "config_hash": digest,
                "previous_version": latest.number if latest else None})
    return version


def authorise_automation(membership, policy: PricingPolicy, authorised: bool) -> None:
    require(membership, "administer")
    policy.automation_authorised = authorised
    policy.automation_authorised_by = membership.user if authorised else None
    policy.save(update_fields=["automation_authorised", "automation_authorised_by"])
    record(membership.organisation, membership.user, "policy.automation_authorised" if authorised
           else "policy.automation_revoked", policy, f"Bounded automation {'authorised' if authorised else 'revoked'} "
           f"for policy '{policy.code}'")


def approve_promotion(membership, promotion: Promotion) -> None:
    require(membership, "approve")
    promotion.status = Promotion.Status.APPROVED
    promotion.approved_by, promotion.approved_at = membership.user, timezone.now()
    promotion.save(update_fields=["status", "approved_by", "approved_at"])
    record(membership.organisation, membership.user, "promotion.approved", promotion,
           f"Promotion '{promotion.code}' approved")
