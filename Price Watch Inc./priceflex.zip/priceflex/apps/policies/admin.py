from django.contrib import admin

from .models import PolicyVersion, PriceCommitment, PricingPolicy, Promotion


@admin.register(PricingPolicy)
class PricingPolicyAdmin(admin.ModelAdmin):
    """Policy content is revised through validated, versioned saves - not edited here."""

    list_display = ("name", "code", "status", "current_version", "automation_authorised", "organisation")
    list_filter = ("organisation", "status")
    readonly_fields = ("current_version", "automation_authorised", "automation_authorised_by")


@admin.register(PolicyVersion)
class PolicyVersionAdmin(admin.ModelAdmin):
    list_display = ("policy", "number", "created_by", "created_at", "change_note")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Promotion)
class PromotionAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "status", "kind", "value", "funding", "starts_at", "ends_at", "approved_by")
    list_filter = ("organisation", "status")
    filter_horizontal = ("listings",)
    readonly_fields = ("status", "approved_by", "approved_at")


@admin.register(PriceCommitment)
class PriceCommitmentAdmin(admin.ModelAdmin):
    list_display = ("listing", "kind", "value", "reference", "valid_from", "valid_to")
    list_filter = ("organisation", "kind")
