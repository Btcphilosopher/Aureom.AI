from django.contrib import admin

from .models import ComparableOfferSet, CompetitorObservation, FeedStatus


@admin.register(CompetitorObservation)
class CompetitorObservationAdmin(admin.ModelAdmin):
    list_display = ("observed_at", "variant", "supplier", "condition", "item_price", "comparable_total", "availability",
                    "variant_match", "match_confidence", "match_status", "source")
    list_filter = ("organisation", "source", "supplier", "condition", "availability", "variant_match", "match_status")
    search_fields = ("variant__sku", "supplier", "title")


@admin.register(FeedStatus)
class FeedStatusAdmin(admin.ModelAdmin):
    list_display = ("source", "organisation", "last_attempt_at", "last_success_at", "last_failure_at", "last_error")


@admin.register(ComparableOfferSet)
class ComparableOfferSetAdmin(admin.ModelAdmin):
    list_display = ("built_at", "listing", "basis", "eligible_count", "excluded_count", "lowest", "median", "highest")
