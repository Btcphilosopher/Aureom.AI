from django.db import models


class CompetitorObservation(models.Model):
    """One observed competitor offer, as imported. Market input only - never an instruction."""

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="competitor_observations")
    variant = models.ForeignKey("catalogue.ProductVariant", null=True, blank=True, on_delete=models.CASCADE,
                                related_name="competitor_observations",
                                help_text="Our variant this observation was collected for")
    source = models.CharField(max_length=40, default="pricewatch")
    external_observation_id = models.CharField(max_length=80)
    external_listing_id = models.CharField(max_length=80, blank=True)
    supplier = models.CharField(max_length=120)
    supplier_slug = models.CharField(max_length=120, blank=True)
    title = models.CharField(max_length=300, blank=True)
    product_identity = models.JSONField(default=dict, blank=True)
    variant_match = models.CharField(max_length=12, default="unknown")  # exact | different | unknown
    condition = models.CharField(max_length=16, default="unknown")
    item_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    delivery_charge = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    mandatory_charges = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    charges_complete = models.BooleanField(default=False)
    comparable_total = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    currency = models.CharField(max_length=3)
    availability = models.CharField(max_length=16, default="unknown")
    eligibility = models.CharField(max_length=16, default="eligible")  # eligible | conditional | ineligible
    membership_required = models.BooleanField(default=False)
    eligibility_conditions = models.JSONField(default=list, blank=True)
    observed_at = models.DateTimeField(db_index=True)
    match_confidence = models.DecimalField(max_digits=5, decimal_places=4, default=0)
    match_status = models.CharField(max_length=12, default="unresolved")  # confirmed | probable | unresolved | rejected
    match_evidence = models.JSONField(default=dict, blank=True)
    provenance = models.JSONField(default=dict, blank=True)
    retained_after_feed_failure = models.BooleanField(default=False)
    ingested_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-observed_at", "-id"]
        constraints = [models.UniqueConstraint(fields=["organisation", "source", "external_observation_id"],
                                               name="uniq_competitor_observation")]
        indexes = [models.Index(fields=["variant", "-observed_at"])]

    def __str__(self) -> str:
        return f"{self.supplier} {self.item_price} @ {self.observed_at:%Y-%m-%d %H:%M}"


class FeedStatus(models.Model):
    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="feeds")
    source = models.CharField(max_length=40)
    last_attempt_at = models.DateTimeField(null=True, blank=True)
    last_success_at = models.DateTimeField(null=True, blank=True)
    last_failure_at = models.DateTimeField(null=True, blank=True)
    last_error = models.CharField(max_length=500, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["organisation", "source"], name="uniq_feed_status")]

    @property
    def failing(self) -> bool:
        return self.last_failure_at is not None and (
            self.last_success_at is None or self.last_failure_at > self.last_success_at)


class ComparableOfferSet(models.Model):
    """The exact set of competitor offers a recommendation was (and was not) based on."""

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="+")
    listing = models.ForeignKey("catalogue.ChannelListing", on_delete=models.CASCADE, related_name="comparable_sets")
    basis = models.CharField(max_length=20)
    built_at = models.DateTimeField()
    eligible_count = models.PositiveIntegerField(default=0)
    excluded_count = models.PositiveIntegerField(default=0)
    lowest = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    median = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    highest = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    eligible = models.JSONField(default=list)
    excluded = models.JSONField(default=list)
    warnings = models.JSONField(default=list)

    class Meta:
        ordering = ["-built_at", "-id"]
