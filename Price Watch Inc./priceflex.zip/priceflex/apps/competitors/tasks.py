from celery import shared_task

from apps.accounts.models import Organisation
from apps.recommendations.tasks import system_membership

from . import services


@shared_task
def import_price_watch() -> dict:
    out = {}
    for organisation in Organisation.objects.all():
        membership = system_membership(organisation)
        if membership is not None:
            out[organisation.slug] = services.pull_price_watch(membership).to_dict()
    return out
