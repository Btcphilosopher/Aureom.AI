from __future__ import annotations

from datetime import datetime, timedelta

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from adapters.pricewatch import (
    SOURCE,
    HttpPriceWatchClient,
    NormalisedObservation,
    PriceWatchError,
    fetch_observations,
)
from adapters.pricewatch_simulated import SimulatedPriceWatch
from apps.accounts.permissions import require
from apps.audit.services import raise_alert, record, resolve_alerts
from apps.catalogue.importing import ImportResult, Lookups, RowErrors
from apps.catalogue.models import ProductVariant
from engine import types as engine_types

from .models import CompetitorObservation, FeedStatus

VARIANT_MATCHES = ("exact", "different", "unknown")
MATCH_STATUSES = ("confirmed", "probable", "unresolved", "rejected")
AVAILABILITY = ("in_stock", "out_of_stock", "preorder", "unknown")


def get_client(now: datetime | None = None, *, outage: bool = False):
    if settings.PRICEWATCH_MODE == "http":
        return HttpPriceWatchClient(settings.PRICEWATCH_BASE_URL, settings.PRICEWATCH_API_TOKEN,
                                    settings.PRICEWATCH_TIMEOUT_SECONDS)
    return SimulatedPriceWatch(settings.PRICEFLEX_DEMO_FIXTURES / "pricewatch_scenarios.json",
                               now=now or timezone.now(), outage=outage)


def _store(org, variant, obs: NormalisedObservation) -> bool:
    _, created = CompetitorObservation.objects.update_or_create(
        organisation=org, source=SOURCE, external_observation_id=obs.external_observation_id,
        defaults=dict(
            variant=variant, external_listing_id=obs.external_listing_id, supplier=obs.supplier,
            supplier_slug=obs.supplier_slug, title=obs.title, product_identity=obs.product_identity,
            variant_match=obs.variant_match, condition=obs.condition, item_price=obs.item_price,
            delivery_charge=obs.delivery_charge, mandatory_charges=obs.mandatory_charges,
            charges_complete=obs.charges_complete, comparable_total=obs.comparable_total, currency=obs.currency,
            availability=obs.availability, eligibility=obs.eligibility, membership_required=obs.membership_required,
            eligibility_conditions=obs.eligibility_conditions, observed_at=obs.observed_at,
            match_confidence=obs.match_confidence, match_status=obs.match_status,
            match_evidence=obs.match_evidence, provenance=obs.provenance, retained_after_feed_failure=False,
        ),
    )
    return created


def pull_price_watch(membership, *, variants=None, client=None, now: datetime | None = None) -> ImportResult:
    """Import competitor observations from Price Watch for our variants.

    If Price Watch cannot be read, nothing is deleted or zeroed: the last valid
    observations stay, flagged as retained, each with its original timestamp.
    """
    require(membership, "import_data")
    org = membership.organisation
    now = now or timezone.now()
    client = client or get_client(now)
    variants = variants if variants is not None else ProductVariant.objects.filter(
        organisation=org, is_active=True).exclude(gtin="")
    result = ImportResult(kind="competitor_observations", received=0)
    feed, _ = FeedStatus.objects.get_or_create(organisation=org, source=SOURCE)
    feed.last_attempt_at = now
    failures: list[str] = []
    failed_variants = []
    for variant in variants:
        try:
            observations, rejected = fetch_observations(client, variant.gtin, fetched_at=now, condition=variant.condition)
        except PriceWatchError as exc:
            failures.append(f"{variant.sku}: {exc}")
            failed_variants.append(variant.pk)
            continue
        result.received += len(observations) + len(rejected)
        with transaction.atomic():
            CompetitorObservation.objects.filter(organisation=org, source=SOURCE, variant=variant).update(
                retained_after_feed_failure=False)
            for obs in observations:
                if _store(org, variant, obs):
                    result.created += 1
                else:
                    result.updated += 1
        for item in rejected:
            result.rejected.append({"row": 0, "sku": variant.sku, "errors": [f"{item['list']}: {item['reason']}"]})
    if failures:
        # A failure never deletes or zeroes anything: the affected products keep their last valid
        # observations, flagged as retained, each with its original observation time.
        feed.last_failure_at, feed.last_error = now, "; ".join(failures)[:500]
        retained = CompetitorObservation.objects.filter(organisation=org, source=SOURCE,
                                                        variant_id__in=failed_variants).update(retained_after_feed_failure=True)
        raise_alert(org, "competitor_feed_failed", f"Price Watch import failed for {len(failures)} product(s); "
                    f"{retained} last valid observation(s) retained with their original timestamps.",
                    payload={"failures": failures[:20]})
    else:
        # Only a completely successful pull counts as a feed success; a partial failure keeps the
        # feed marked as failing so the affected products stay visible.
        feed.last_success_at, feed.last_error = now, ""
        resolve_alerts(org, "competitor_feed_failed")
    feed.save()
    record(org, membership.user, "competitor.import", None,
           f"Price Watch import: {result.created} new, {result.updated} refreshed, {len(result.rejected)} not usable, "
           f"{len(failures)} fetch failure(s)", {"failures": failures[:20]})
    result.batch = "failed" if failures and not (result.created or result.updated) else "ok"
    return result


def import_observations(membership, rows: list[dict], *, source: str = "api") -> ImportResult:
    """Import already-normalised observations pushed through the API."""
    require(membership, "import_data")
    org = membership.organisation
    result = ImportResult(kind="competitor_observations", received=len(rows))
    lookups = Lookups(org)
    with transaction.atomic():
        for index, row in enumerate(rows, start=1):
            errors = RowErrors()
            variant = lookups.variant(row, errors)
            ext_id = str(row.get("external_observation_id") or "").strip()
            supplier = str(row.get("supplier") or "").strip()
            if not ext_id:
                errors.append("external_observation_id is required")
            if not supplier:
                errors.append("supplier is required")
            item = errors.dec(row, "item_price", default=None, minimum="0.01")
            delivery = errors.dec(row, "delivery_charge", default=None)
            mandatory = errors.dec(row, "mandatory_charges", default=None)
            total = errors.dec(row, "comparable_total", default=None, minimum="0.01")
            confidence = errors.dec(row, "match_confidence", required=True, maximum="1")
            observed = errors.when(row, "observed_at", required=True)
            currency = str(row.get("currency") or "").strip().upper()
            if len(currency) != 3:
                errors.append("currency must be a 3-letter code")
            vm = str(row.get("variant_match") or "unknown")
            ms = str(row.get("match_status") or "unresolved")
            av = str(row.get("availability") or "unknown")
            if vm not in VARIANT_MATCHES:
                errors.append(f"variant_match must be one of {', '.join(VARIANT_MATCHES)}")
            if ms not in MATCH_STATUSES:
                errors.append(f"match_status must be one of {', '.join(MATCH_STATUSES)}")
            if av not in AVAILABILITY:
                errors.append(f"availability must be one of {', '.join(AVAILABILITY)}")
            if observed and observed > timezone.now() + timedelta(minutes=5):
                errors.append("observed_at is in the future")
            complete = errors.boolean(row, "charges_complete")
            if complete and total is None and item is not None and delivery is not None and mandatory is not None:
                total = item + delivery + mandatory
            if complete and total is None:
                errors.append("charges_complete is true but no comparable_total can be established")
            if errors:
                result.reject(index, row, list(errors))
                continue
            membership_required = errors.boolean(row, "membership_required")
            _, created = CompetitorObservation.objects.update_or_create(
                organisation=org, source=str(row.get("source") or source)[:40], external_observation_id=ext_id,
                defaults=dict(
                    variant=variant, supplier=supplier, supplier_slug=str(row.get("supplier_slug") or ""),
                    external_listing_id=str(row.get("external_listing_id") or ""), title=str(row.get("title") or "")[:300],
                    variant_match=vm, condition=str(row.get("condition") or "unknown"), item_price=item,
                    delivery_charge=delivery, mandatory_charges=mandatory, charges_complete=complete,
                    comparable_total=total if complete else None, currency=currency, availability=av,
                    eligibility="conditional" if membership_required else "eligible",
                    membership_required=membership_required,
                    eligibility_conditions=list(row.get("eligibility_conditions") or []), observed_at=observed,
                    match_confidence=confidence, match_status=ms, match_evidence=row.get("match_evidence") or {},
                    provenance=row.get("provenance") or {"source": source},
                ),
            )
            result.created += 1 if created else 0
            result.updated += 0 if created else 1
        record(org, membership.user, "competitor.import", None,
               f"Competitor observations import: {result.created} created, {result.updated} updated, "
               f"{len(result.rejected)} rejected", {"rejected": result.rejected[:50]})
    return result


def engine_observations(variant, at: datetime, days: int = 7) -> tuple[engine_types.CompetitorObservation, ...]:
    rows = CompetitorObservation.objects.filter(variant=variant, observed_at__lte=at,
                                                observed_at__gte=at - timedelta(days=days)).order_by("observed_at", "id")
    return tuple(engine_types.CompetitorObservation(
        observation_id=str(r.pk), supplier=r.supplier, variant_match=r.variant_match, condition=r.condition,
        item_price=r.item_price, delivery_charge=r.delivery_charge, mandatory_charges=r.mandatory_charges,
        charges_complete=r.charges_complete, comparable_total=r.comparable_total, currency=r.currency,
        availability=r.availability, membership_required=r.membership_required, observed_at=r.observed_at,
        match_confidence=r.match_confidence, match_status=r.match_status,
        eligibility_conditions=tuple(r.eligibility_conditions or ()), source=r.source,
        retained_after_feed_failure=r.retained_after_feed_failure,
        listing_key=r.external_listing_id,
    ) for r in rows)


def engine_feeds(org) -> tuple[engine_types.FeedStatus, ...]:
    return tuple(engine_types.FeedStatus(source=f.source, last_success_at=f.last_success_at,
                                         last_failure_at=f.last_failure_at, last_error=f.last_error)
                 for f in FeedStatus.objects.filter(organisation=org).order_by("source"))
