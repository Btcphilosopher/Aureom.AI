"""SIMULATED storefront backed by database tables, with fault injection.

It behaves like a remote system: compare-and-set on a version, idempotency
keys, a shopper-facing displayed price that can lag the accepted price, and
configurable failures. It is for demonstration and tests only.
"""

from __future__ import annotations

from decimal import Decimal

from django.db import transaction
from django.db.models import F
from django.utils import timezone

from adapters.storefront import (
    StorefrontPrice,
    StorefrontRejected,
    StorefrontTimeout,
    StorefrontVersionConflict,
)

from .models import MockStorefrontFault, MockStorefrontPrice, MockStorefrontQuote, MockStorefrontRequest


class MockStorefront:
    name = "simulated-storefront"

    def get_price(self, channel_code: str, sku: str) -> StorefrontPrice:
        row = MockStorefrontPrice.objects.filter(channel_code=channel_code, sku=sku).first()
        if row is None:
            return StorefrontPrice(None, "", {"found": False})
        return StorefrontPrice(row.displayed_price, str(row.version),
                               {"found": True, "displayed_price": str(row.displayed_price), "version": row.version,
                                "updated_at": row.updated_at.isoformat()})

    def _take_fault(self, channel_code: str, sku: str) -> str | None:
        fault = MockStorefrontFault.objects.filter(channel_code=channel_code, sku=sku, remaining__gt=0).order_by("id").first()
        if fault is None:
            return None
        MockStorefrontFault.objects.filter(pk=fault.pk).update(remaining=F("remaining") - 1)
        return fault.mode

    def set_price(self, channel_code: str, sku: str, price: Decimal, *, expected_version: str,
                  idempotency_key: str) -> dict:
        prior = MockStorefrontRequest.objects.filter(idempotency_key=idempotency_key).first()
        if prior is not None:
            return {**prior.response, "idempotent_replay": True}
        mode = self._take_fault(channel_code, sku)
        if mode == "reject":
            raise StorefrontRejected("Simulated storefront rejected the price update (HTTP 422).")
        if mode == "timeout_before_apply":
            raise StorefrontTimeout("Simulated storefront timed out before applying the update.")
        with transaction.atomic():
            row = MockStorefrontPrice.objects.select_for_update().filter(channel_code=channel_code, sku=sku).first()
            if row is None:
                raise StorefrontRejected(f"Simulated storefront has no listing for {sku} on {channel_code}.")
            if str(row.version) != str(expected_version):
                raise StorefrontVersionConflict(
                    f"Simulated storefront version is {row.version}, expected {expected_version}.")
            row.price = price
            if mode != "accepted_not_displayed":
                row.displayed_price = price
            row.version += 1
            row.save()
            response = {"status": "accepted", "http_status": 200, "sku": sku, "channel": channel_code,
                        "price": str(price), "version": row.version, "accepted_at": timezone.now().isoformat(),
                        "storefront": self.name}
            MockStorefrontRequest.objects.create(idempotency_key=idempotency_key, channel_code=channel_code,
                                                 sku=sku, response=response)
        if mode == "timeout_after_apply":
            raise StorefrontTimeout("Simulated storefront applied the update but the response was lost.")
        return response

    # -- helpers used by seeding, the demo and tests (not part of the adapter contract) ----

    @staticmethod
    def seed_price(channel_code: str, sku: str, price: Decimal) -> None:
        MockStorefrontPrice.objects.update_or_create(channel_code=channel_code, sku=sku,
                                                     defaults={"price": price, "displayed_price": price})

    @staticmethod
    def inject_fault(channel_code: str, sku: str, mode: str, times: int = 1) -> None:
        MockStorefrontFault.objects.create(channel_code=channel_code, sku=sku, mode=mode, remaining=times)

    @staticmethod
    def refresh_display(channel_code: str, sku: str) -> None:
        """Simulate the storefront's display cache catching up with the accepted price."""
        MockStorefrontPrice.objects.filter(channel_code=channel_code, sku=sku).update(displayed_price=F("price"))

    @staticmethod
    def price_for_order(channel_code: str, sku: str, quote_reference: str | None = None) -> Decimal | None:
        """The price an order is charged: a live locked quote wins over the displayed price."""
        if quote_reference:
            quote = MockStorefrontQuote.objects.filter(reference=quote_reference, channel_code=channel_code, sku=sku,
                                                       expires_at__gt=timezone.now()).first()
            if quote:
                return quote.locked_price
        row = MockStorefrontPrice.objects.filter(channel_code=channel_code, sku=sku).first()
        return row.displayed_price if row else None
