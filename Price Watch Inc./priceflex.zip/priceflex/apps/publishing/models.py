from django.conf import settings
from django.db import models
from django.db.models import Q


class PublicationControl(models.Model):
    """The pause switch. While paused, no publication is sent (rollbacks excepted)."""

    organisation = models.OneToOneField("accounts.Organisation", on_delete=models.CASCADE, related_name="publication_control")
    paused = models.BooleanField(default=False)
    reason = models.CharField(max_length=300, blank=True)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    changed_at = models.DateTimeField(null=True, blank=True)


class AttemptStatus(models.TextChoices):
    PENDING = "pending", "Pending"
    SENT = "sent", "Sent, awaiting verification"
    VERIFIED = "verified", "Verified by read-back"
    FAILED = "failed", "Failed"
    UNCERTAIN = "uncertain", "Outcome uncertain"
    BLOCKED = "blocked", "Blocked by pre-publication checks"


OPEN_ATTEMPT_STATUSES = (AttemptStatus.PENDING, AttemptStatus.SENT, AttemptStatus.UNCERTAIN)


class PublicationAttempt(models.Model):
    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="publication_attempts")
    recommendation = models.ForeignKey("recommendations.PriceRecommendation", on_delete=models.CASCADE, related_name="attempts")
    listing = models.ForeignKey("catalogue.ChannelListing", on_delete=models.CASCADE, related_name="attempts")
    kind = models.CharField(max_length=12, default="publish")  # publish | rollback
    attempt_number = models.PositiveIntegerField(default=1)
    idempotency_key = models.CharField(max_length=120, help_text="Sent to the storefront; identical across retries")
    price = models.DecimalField(max_digits=12, decimal_places=2)
    expected_previous_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    expected_version = models.PositiveIntegerField()
    status = models.CharField(max_length=12, choices=AttemptStatus.choices, default=AttemptStatus.PENDING, db_index=True)
    resolution = models.CharField(max_length=40, blank=True)
    request = models.JSONField(default=dict, blank=True)
    external_response = models.JSONField(default=dict, blank=True)
    error = models.CharField(max_length=500, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    reconciled_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        constraints = [
            # At most one in-flight publication per listing, enforced by the database.
            models.UniqueConstraint(fields=["listing"], condition=Q(status__in=["pending", "sent", "uncertain"]),
                                    name="one_open_publication_per_listing"),
            models.UniqueConstraint(fields=["recommendation", "attempt_number"], name="uniq_attempt_number"),
        ]

    def __str__(self) -> str:
        return f"Attempt {self.pk} {self.listing} -> {self.price} [{self.status}]"


class ObservedPublishedPrice(models.Model):
    """What the storefront actually showed when PRICEFLEX read it back."""

    listing = models.ForeignKey("catalogue.ChannelListing", on_delete=models.CASCADE, related_name="observed_prices")
    attempt = models.ForeignKey(PublicationAttempt, null=True, blank=True, on_delete=models.SET_NULL, related_name="observations")
    price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    storefront_version = models.CharField(max_length=40, blank=True)
    source = models.CharField(max_length=24)  # publish_readback | reconciliation | monitor | pre_publish_check
    expected_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    matches_expected = models.BooleanField(null=True)
    observed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-observed_at", "-id"]


class PriceHistory(models.Model):
    """Ledger of confirmed published prices for a listing."""

    class Kind(models.TextChoices):
        INITIAL = "initial", "Initial price"
        PUBLISH = "publish", "Published change"
        ROLLBACK = "rollback", "Rollback"
        EXTERNAL = "external", "Changed outside PRICEFLEX"

    listing = models.ForeignKey("catalogue.ChannelListing", on_delete=models.CASCADE, related_name="price_history")
    price = models.DecimalField(max_digits=12, decimal_places=2)
    previous_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    effective_at = models.DateTimeField(db_index=True)
    kind = models.CharField(max_length=12, choices=Kind.choices)
    recommendation = models.ForeignKey("recommendations.PriceRecommendation", null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    attempt = models.ForeignKey(PublicationAttempt, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    note = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ["-effective_at", "-id"]
        verbose_name_plural = "price history"


# -- Simulated storefront ---------------------------------------------------------
# These tables ARE the mock storefront. A real deployment replaces the adapter and
# does not use them.


class MockStorefrontPrice(models.Model):
    channel_code = models.CharField(max_length=32)
    sku = models.CharField(max_length=64)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    displayed_price = models.DecimalField(max_digits=12, decimal_places=2,
                                          help_text="What shoppers see; can lag the accepted price")
    version = models.PositiveIntegerField(default=1)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["channel_code", "sku"], name="uniq_mock_storefront_price")]


class MockStorefrontRequest(models.Model):
    idempotency_key = models.CharField(max_length=120, unique=True)
    channel_code = models.CharField(max_length=32)
    sku = models.CharField(max_length=64)
    response = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)


class MockStorefrontFault(models.Model):
    """Fault injection for the simulated storefront (demo and tests)."""

    MODES = [
        ("reject", "Reject the request"),
        ("timeout_before_apply", "Time out; the change is NOT applied"),
        ("timeout_after_apply", "Time out; the change IS applied"),
        ("accepted_not_displayed", "Accept, but keep displaying the old price"),
    ]
    channel_code = models.CharField(max_length=32)
    sku = models.CharField(max_length=64)
    mode = models.CharField(max_length=32, choices=MODES)
    remaining = models.PositiveIntegerField(default=1)


class MockStorefrontQuote(models.Model):
    """An accepted quote or open order at a locked price. Publication never alters these."""

    channel_code = models.CharField(max_length=32)
    sku = models.CharField(max_length=64)
    reference = models.CharField(max_length=64, unique=True)
    locked_price = models.DecimalField(max_digits=12, decimal_places=2)
    expires_at = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
