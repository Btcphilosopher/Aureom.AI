"""Publication, verification, reconciliation, rollback and the pause switch.

A publication is only *verified* when the storefront's displayed price has
been read back and matches. An accepted API call alone proves nothing about
what shoppers see, so it leaves the attempt 'uncertain' until reconciled.

Existing commitments: publishing changes the price offered to *new* orders on
one channel listing. Accepted quotes and placed orders keep their own locked
prices in the storefront and are never rewritten by PRICEFLEX; contractual
restrictions are enforced as hard constraints before anything is sent.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal

from django.conf import settings
from django.db import IntegrityError, transaction
from django.db.models import Q
from django.utils import timezone

from adapters.storefront import StorefrontError, StorefrontRejected, StorefrontTimeout, load_adapter
from apps.accounts.permissions import require
from apps.audit.services import raise_alert, record, resolve_alerts
from apps.catalogue.models import ChannelListing
from apps.recommendations.models import ApprovalDecision, InputSnapshot, PriceRecommendation
from apps.recommendations.models import RecommendationStatus as S
from apps.recommendations.services import build_input, expire_if_due
from apps.recommendations.workflow import WorkflowError, transition
from engine import ALGORITHM_VERSION
from engine.evaluation import validate_price
from engine.types import snapshot_hash

from .models import (
    OPEN_ATTEMPT_STATUSES,
    AttemptStatus,
    ObservedPublishedPrice,
    PriceHistory,
    PublicationAttempt,
    PublicationControl,
)

PENDING_RECONCILE_AFTER_MINUTES = 5


def storefront():
    return load_adapter(settings.PRICEFLEX_STOREFRONT_ADAPTER)


def control_for(organisation) -> PublicationControl:
    return PublicationControl.objects.get_or_create(organisation=organisation)[0]


def set_pause(membership, paused: bool, reason: str = "") -> PublicationControl:
    require(membership, "publish")
    if paused and not reason.strip():
        raise WorkflowError("reason_required", "Pausing publication needs a recorded reason.", http_status=422)
    control = control_for(membership.organisation)
    control.paused, control.reason = paused, reason[:300]
    control.changed_by, control.changed_at = membership.user, timezone.now()
    control.save()
    record(membership.organisation, membership.user, "publication.paused" if paused else "publication.resumed",
           control, f"Publication {'paused' if paused else 'resumed'}" + (f": {reason}" if reason else ""))
    return control


def _observe(listing, attempt, source: str, expected: Decimal | None):
    seen = storefront().get_price(listing.channel.code, listing.variant.sku)
    ObservedPublishedPrice.objects.create(
        listing=listing, attempt=attempt, price=seen.price, storefront_version=seen.version, source=source,
        expected_price=expected, matches_expected=None if expected is None else seen.price == expected)
    return seen


def _finalise_verified(attempt: PublicationAttempt, actor, resolution: str) -> None:
    with transaction.atomic():
        listing = ChannelListing.objects.select_for_update().get(pk=attempt.listing_id)
        rec = PriceRecommendation.objects.select_for_update().get(pk=attempt.recommendation_id)
        now = timezone.now()
        previous = listing.confirmed_price
        listing.confirmed_price, listing.confirmed_at = attempt.price, now
        listing.price_version += 1
        listing.save(update_fields=["confirmed_price", "confirmed_at", "price_version"])
        PriceHistory.objects.create(listing=listing, price=attempt.price, previous_price=previous, effective_at=now,
                                    kind="rollback" if attempt.kind == "rollback" else "publish",
                                    recommendation=rec, attempt=attempt, actor=attempt.created_by,
                                    note=f"Verified by storefront read-back ({resolution}).")
        attempt.status, attempt.resolution, attempt.completed_at = AttemptStatus.VERIFIED, resolution, now
        attempt.save(update_fields=["status", "resolution", "completed_at", "reconciled_at"])
        transition(rec, S.VERIFIED, actor=actor, audit=False,
                   note=f"Storefront shows {rec.currency} {attempt.price} ({resolution}).")
        record(rec.organisation, actor, f"publication.{attempt.kind}_verified", attempt,
               f"{listing}: {previous} -> {attempt.price} verified on the storefront",
               {"previous_price": str(previous) if previous is not None else None, "price": str(attempt.price),
                "resolution": resolution, "price_version": listing.price_version})
        # Open decisions for this listing were evaluated against the old price.
        stale = PriceRecommendation.objects.select_for_update().filter(
            listing=listing, status__in=[S.EVALUATED, S.AWAITING_APPROVAL, S.APPROVED, S.SCHEDULED]).exclude(pk=rec.pk)
        for other in stale:
            transition(other, S.SUPERSEDED, audit=False, note="The live price changed after this was evaluated.")
    resolve_alerts(attempt.organisation, "publication_uncertain", listing=attempt.listing)


def _fail(attempt: PublicationAttempt, actor, error: str, resolution: str, *, rec_status: str = S.FAILED) -> None:
    with transaction.atomic():
        rec = PriceRecommendation.objects.select_for_update().get(pk=attempt.recommendation_id)
        attempt.status, attempt.error, attempt.resolution = AttemptStatus.FAILED, error[:500], resolution
        attempt.completed_at = timezone.now()
        attempt.save(update_fields=["status", "error", "resolution", "completed_at", "reconciled_at"])
        if rec.status == S.PUBLISHING:
            transition(rec, rec_status, actor=actor, note=error, audit=False)
        record(rec.organisation, actor, "publication.failed", attempt, f"{attempt.listing}: {error}",
               {"resolution": resolution, "price": str(attempt.price)})


def publish(membership, rec: PriceRecommendation, *, kind: str = "publish") -> PublicationAttempt:
    """Publish an approved price as an authorised member."""
    require(membership, "publish", rec.listing.channel)
    return _publish(rec, membership.user, kind=kind)


def _publish(rec: PriceRecommendation, actor, *, kind: str = "publish") -> PublicationAttempt:
    now = timezone.now()
    deferred: WorkflowError | None = None
    blocked_attempt: PublicationAttempt | None = None
    with transaction.atomic():
        listing = ChannelListing.objects.select_for_update(of=("self",)).select_related(
            "variant", "variant__product", "channel", "channel__organisation", "policy",
            "policy__current_version").get(pk=rec.listing_id)
        rec = PriceRecommendation.objects.select_for_update().get(pk=rec.pk)
        rec.listing = listing
        org = listing.channel.organisation
        control = control_for(org)
        if control.paused and kind != "rollback":
            raise WorkflowError("publication_paused", f"Publication is paused: {control.reason or 'no reason given'}.")
        if rec.status not in (S.APPROVED, S.SCHEDULED, S.FAILED):
            raise WorkflowError("invalid_state", f"Only approved or scheduled prices can be published "
                                                 f"(this recommendation is '{rec.status}').", {"status": rec.status})
        if PublicationAttempt.objects.filter(listing=listing, status__in=OPEN_ATTEMPT_STATUSES).exists():
            raise WorkflowError("publication_in_progress", "Another publication for this listing is still in "
                                "flight or awaiting reconciliation.")
        price = rec.price_to_publish
        if price is None:
            raise WorkflowError("invalid_state", "The recommendation has no approved price.")
        number = rec.attempts.count() + 1

        # -- re-check essential conditions as they are now ------------------------
        if expire_if_due(rec, now):
            deferred = WorkflowError("expired", "The approval has expired; run a new evaluation.")
        elif listing.price_version != rec.expected_price_version:
            transition(rec, S.SUPERSEDED, actor=actor,
                       note="The live price changed after this price was evaluated; it was not published.")
            deferred = WorkflowError("stale_price_version", "The live price changed since this recommendation was "
                                     "evaluated. It has been superseded; evaluate again.",
                                     {"expected_version": rec.expected_price_version,
                                      "current_version": listing.price_version})
        else:
            check = validate_price(build_input(listing, now), price)
            if not check["ok"]:
                detail = "; ".join([i["message"] for i in check["blocking_issues"]]
                                   + [f"{v['name']} ({v['side']} {v['value']})" for v in check["violations"]])
                blocked_attempt = PublicationAttempt.objects.create(
                    organisation=org, recommendation=rec, listing=listing, kind=kind, attempt_number=number,
                    idempotency_key=f"pf-{org.pk}-{rec.pk}-v{listing.price_version}", price=price,
                    expected_previous_price=listing.confirmed_price, expected_version=listing.price_version,
                    status=AttemptStatus.BLOCKED, error=f"Pre-publication check failed: {detail}"[:500],
                    request={"check": check}, created_by=actor if not isinstance(actor, str) else None,
                    completed_at=now)
                transition(rec, S.FAILED, actor=actor, note=blocked_attempt.error)
        if deferred is None and blocked_attempt is None:
            key = f"pf-{org.pk}-{rec.pk}-v{listing.price_version}"
            try:
                with transaction.atomic():
                    attempt = PublicationAttempt.objects.create(
                        organisation=org, recommendation=rec, listing=listing, kind=kind, attempt_number=number,
                        idempotency_key=key, price=price, expected_previous_price=listing.confirmed_price,
                        expected_version=listing.price_version, status=AttemptStatus.PENDING,
                        request={"channel": listing.channel.code, "sku": listing.variant.sku, "price": str(price),
                                 "idempotency_key": key},
                        created_by=actor if not isinstance(actor, str) else None)
            except IntegrityError:
                raise WorkflowError("publication_in_progress", "Another publication for this listing is in flight.")
            transition(rec, S.PUBLISHING, actor=actor, audit=False)
    if deferred is not None:
        raise deferred
    if blocked_attempt is not None:
        return blocked_attempt

    # -- talk to the storefront outside the transaction, so the pending attempt is durable --
    channel_code, sku = listing.channel.code, listing.variant.sku
    try:
        before = _observe(listing, attempt, "pre_publish_check", attempt.expected_previous_price)
        if attempt.expected_previous_price is not None and before.price != attempt.expected_previous_price:
            raise_alert(org, "storefront_price_drift", f"{listing}: storefront shows {before.price} but the "
                        f"confirmed price is {attempt.expected_previous_price}.", severity="critical", listing=listing)
            _fail(attempt, actor, f"Storefront shows {before.price}, not the expected current price "
                                  f"{attempt.expected_previous_price}; nothing was sent.", "precondition_failed")
            return PublicationAttempt.objects.get(pk=attempt.pk)
        attempt.request = {**attempt.request, "expected_storefront_version": before.version}
        response = storefront().set_price(channel_code, sku, attempt.price, expected_version=before.version,
                                          idempotency_key=attempt.idempotency_key)
    except StorefrontTimeout as exc:
        attempt.status, attempt.error = AttemptStatus.UNCERTAIN, str(exc)[:500]
        attempt.save(update_fields=["status", "error", "request"])
        raise_alert(org, "publication_uncertain", f"{listing}: publication outcome is unknown ({exc}). "
                    "Reconciliation will read the storefront back.", listing=listing)
        record(org, actor, "publication.uncertain", attempt, f"{listing}: outcome unknown - {exc}")
        return attempt
    except StorefrontRejected as exc:
        attempt.save(update_fields=["request"])
        _fail(attempt, actor, str(exc), "rejected_by_storefront")
        return PublicationAttempt.objects.get(pk=attempt.pk)
    except StorefrontError as exc:
        attempt.status, attempt.error = AttemptStatus.UNCERTAIN, str(exc)[:500]
        attempt.save(update_fields=["status", "error", "request"])
        return attempt

    attempt.external_response, attempt.status = response, AttemptStatus.SENT
    attempt.save(update_fields=["external_response", "status", "request"])
    after = _observe(listing, attempt, "publish_readback", attempt.price)
    if after.price == attempt.price:
        _finalise_verified(attempt, actor, "verified_on_publish")
    else:
        attempt.status = AttemptStatus.UNCERTAIN
        attempt.error = (f"Storefront accepted the request but displays {after.price}, not {attempt.price}.")
        attempt.save(update_fields=["status", "error"])
        raise_alert(org, "publication_uncertain", f"{listing}: {attempt.error} Reconciliation will re-check.",
                    listing=listing)
        record(org, actor, "publication.uncertain", attempt, f"{listing}: {attempt.error}")
    return PublicationAttempt.objects.get(pk=attempt.pk)


def reconcile(membership, attempt: PublicationAttempt) -> PublicationAttempt:
    require(membership, "publish", attempt.listing.channel)
    return _reconcile(attempt, membership.user)


def _reconcile(attempt: PublicationAttempt, actor) -> PublicationAttempt:
    """Resolve an uncertain attempt by reading the storefront back."""
    attempt = PublicationAttempt.objects.select_related("listing", "listing__variant", "listing__channel",
                                                        "organisation").get(pk=attempt.pk)
    if attempt.status not in (AttemptStatus.UNCERTAIN, AttemptStatus.SENT, AttemptStatus.PENDING):
        raise WorkflowError("invalid_state", f"Attempt is '{attempt.status}'; nothing to reconcile.")
    seen = _observe(attempt.listing, attempt, "reconciliation", attempt.price)
    attempt.reconciled_at = timezone.now()
    if seen.price == attempt.price:
        _finalise_verified(attempt, actor, "reconciled_applied")
    elif seen.price == attempt.expected_previous_price and (attempt.external_response or {}).get("status") == "accepted":
        # The storefront confirmed it accepted the change but still displays the old price. That is not
        # "not applied": it stays uncertain, and stays visible, until a read-back shows the new price.
        attempt.error = (f"Storefront accepted {attempt.price} but still displays {seen.price}. "
                         "Left uncertain; reconcile again once the storefront display has refreshed.")
        attempt.save(update_fields=["error", "reconciled_at"])
        raise_alert(attempt.organisation, "publication_uncertain", f"{attempt.listing}: {attempt.error}",
                    listing=attempt.listing)
    elif seen.price == attempt.expected_previous_price:
        _fail(attempt, actor, f"Reconciliation: storefront still shows {seen.price}; the change was not applied. "
                              "It can be retried safely with the same idempotency key.", "reconciled_not_applied")
        resolve_alerts(attempt.organisation, "publication_uncertain", listing=attempt.listing)
    else:
        _fail(attempt, actor, f"Reconciliation: storefront shows {seen.price}, which is neither the intended "
                              f"{attempt.price} nor the previous {attempt.expected_previous_price}.",
              "reconciled_unexpected_price")
        raise_alert(attempt.organisation, "storefront_price_drift",
                    f"{attempt.listing}: unexpected storefront price {seen.price}.", severity="critical",
                    listing=attempt.listing)
    return PublicationAttempt.objects.get(pk=attempt.pk)


def reconcile_open(organisation=None, actor="system") -> int:
    # 'pending' attempts older than a few minutes mean a worker died between recording the attempt
    # and hearing from the storefront; they are resolved by read-back like any other unknown outcome.
    stale = timezone.now() - timedelta(minutes=PENDING_RECONCILE_AFTER_MINUTES)
    qs = PublicationAttempt.objects.filter(
        Q(status__in=[AttemptStatus.UNCERTAIN, AttemptStatus.SENT]) | Q(status=AttemptStatus.PENDING, created_at__lt=stale))
    if organisation is not None:
        qs = qs.filter(organisation=organisation)
    count = 0
    for attempt in qs:
        _reconcile(attempt, actor)
        count += 1
    return count


def publish_due(now: datetime | None = None) -> int:
    """Publish scheduled prices whose time has come. Paused organisations are skipped."""
    now = now or timezone.now()
    count = 0
    for rec in PriceRecommendation.objects.filter(status=S.SCHEDULED, scheduled_for__lte=now).select_related(
            "listing", "listing__channel", "listing__variant"):
        try:
            _publish(rec, "system (scheduled)")
            count += 1
        except WorkflowError:
            continue
    return count


def monitor(organisation, actor="system") -> dict:
    """Read every listing's displayed price back and flag drift. Never auto-corrects."""
    checked = mismatched = 0
    for listing in ChannelListing.objects.filter(channel__organisation=organisation, is_active=True,
                                                 confirmed_price__isnull=False).select_related("variant", "channel"):
        if PublicationAttempt.objects.filter(listing=listing, status__in=OPEN_ATTEMPT_STATUSES).exists():
            continue
        seen = _observe(listing, None, "monitor", listing.confirmed_price)
        checked += 1
        if seen.price != listing.confirmed_price:
            mismatched += 1
            raise_alert(organisation, "storefront_price_drift",
                        f"{listing}: storefront displays {seen.price} but the confirmed price is "
                        f"{listing.confirmed_price}.", severity="critical", listing=listing)
        else:
            resolve_alerts(organisation, "storefront_price_drift", listing=listing)
    return {"checked": checked, "mismatched": mismatched}


def request_rollback(membership, listing: ChannelListing, *, reason: str) -> PublicationAttempt:
    """Audited rollback to the previously confirmed price.

    The earlier price is not restored blindly: it must satisfy the hard
    constraints under *current* costs, tax and commitments, otherwise the
    rollback is refused with the reason. A rollback may proceed while
    publication is paused, because it is a safety action.
    """
    require(membership, "publish", listing.channel)
    if not reason.strip():
        raise WorkflowError("reason_required", "A rollback needs a recorded reason.", http_status=422)
    now = timezone.now()
    latest = PriceHistory.objects.filter(listing=listing).order_by("-effective_at", "-id").first()
    if latest is None or latest.previous_price is None:
        raise WorkflowError("nothing_to_roll_back", "There is no earlier confirmed price to roll back to.")
    target = latest.previous_price
    fresh = build_input(listing, now)
    check = validate_price(fresh, target)
    org = listing.channel.organisation
    if not check["ok"]:
        record(org, membership.user, "publication.rollback_refused", listing,
               f"{listing}: rollback to {target} refused under current conditions", {"check": check, "reason": reason})
        raise WorkflowError("rollback_blocked", f"Rolling back to {target} would breach the hard constraints under "
                            "current conditions.", {"violations": check["violations"],
                                                    "blocking_issues": check["blocking_issues"]}, http_status=422)
    payload = fresh.to_dict()
    with transaction.atomic():
        snapshot = InputSnapshot.objects.create(organisation=org, listing=listing, payload=payload,
                                                sha256=snapshot_hash(payload))
        text = (f"Rollback requested by {membership.user.get_username()}: {reason}",
                f"Restores the previously confirmed price {listing.channel.currency} {target}, which passes the "
                "hard constraints under current conditions.")
        rec = PriceRecommendation.objects.create(
            organisation=org, listing=listing, kind="rollback", snapshot=snapshot,
            policy_version=listing.policy.current_version if listing.policy_id else None,
            algorithm_version=ALGORITHM_VERSION, evaluated_at=now, status=S.APPROVED, outcome="change",
            selected_strategy="rollback", currency=listing.channel.currency, current_price=listing.confirmed_price,
            recommended_price=target, approved_price=target, expected_price_version=listing.price_version,
            reasons=list(text), result={"outcome": "change", "reasons": list(text), "validation": check,
                                        "currency": listing.channel.currency,
                                        "current_price": str(listing.confirmed_price), "recommended_price": str(target),
                                        "algorithm_version": ALGORITHM_VERSION, "evaluation_time": now.isoformat(),
                                        "selected_strategy": "rollback", "constraints_applied": [], "warnings": [],
                                        "blocking_issues": []},
        )
        ApprovalDecision.objects.create(recommendation=rec, decision="approved", decided_by=membership.user,
                                        approved_price=target, is_override=True, comment=f"Rollback: {reason}")
        record(org, membership.user, "publication.rollback_requested", rec,
               f"{listing}: rollback {listing.confirmed_price} -> {target}", {"reason": reason})
    return _publish(rec, membership.user, kind="rollback")
