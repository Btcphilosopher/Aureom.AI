from celery import shared_task

from apps.accounts.models import Organisation

from . import services


@shared_task
def publish_due() -> int:
    return services.publish_due()


@shared_task
def reconcile_uncertain() -> int:
    return services.reconcile_open()


@shared_task
def monitor_storefront() -> dict:
    totals = {"checked": 0, "mismatched": 0}
    for organisation in Organisation.objects.all():
        result = services.monitor(organisation)
        totals = {k: totals[k] + result[k] for k in totals}
    return totals


@shared_task
def publish_recommendation(recommendation_id: int, user_id: int) -> int:
    from django.contrib.auth import get_user_model

    from apps.accounts.permissions import membership_for
    from apps.recommendations.models import PriceRecommendation

    rec = PriceRecommendation.objects.select_related("listing", "listing__channel", "organisation").get(pk=recommendation_id)
    membership = membership_for(get_user_model().objects.get(pk=user_id), rec.organisation)
    return services.publish(membership, rec).pk
