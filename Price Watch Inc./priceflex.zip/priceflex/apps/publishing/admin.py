from django.contrib import admin

from .models import (
    MockStorefrontFault,
    MockStorefrontPrice,
    MockStorefrontQuote,
    ObservedPublishedPrice,
    PriceHistory,
    PublicationAttempt,
    PublicationControl,
)


class ReadOnlyAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(PublicationAttempt)
class PublicationAttemptAdmin(ReadOnlyAdmin):
    list_display = ("created_at", "listing", "kind", "price", "status", "resolution", "idempotency_key", "created_by")
    list_filter = ("organisation", "status", "kind")


@admin.register(ObservedPublishedPrice)
class ObservedPublishedPriceAdmin(ReadOnlyAdmin):
    list_display = ("observed_at", "listing", "price", "expected_price", "matches_expected", "source")
    list_filter = ("source", "matches_expected")


@admin.register(PriceHistory)
class PriceHistoryAdmin(ReadOnlyAdmin):
    list_display = ("effective_at", "listing", "price", "previous_price", "kind", "actor")
    list_filter = ("kind",)


@admin.register(PublicationControl)
class PublicationControlAdmin(ReadOnlyAdmin):
    list_display = ("organisation", "paused", "reason", "changed_by", "changed_at")


@admin.register(MockStorefrontPrice)
class MockStorefrontPriceAdmin(admin.ModelAdmin):
    list_display = ("channel_code", "sku", "price", "displayed_price", "version", "updated_at")


@admin.register(MockStorefrontFault)
class MockStorefrontFaultAdmin(admin.ModelAdmin):
    list_display = ("channel_code", "sku", "mode", "remaining")


@admin.register(MockStorefrontQuote)
class MockStorefrontQuoteAdmin(admin.ModelAdmin):
    list_display = ("reference", "channel_code", "sku", "locked_price", "expires_at")
