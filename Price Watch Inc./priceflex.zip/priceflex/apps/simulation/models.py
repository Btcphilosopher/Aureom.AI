from django.conf import settings
from django.db import models


class DemandModel(models.Model):
    """A fitted demand estimate for a listing. Only 'validated' estimates may drive prices."""

    listing = models.ForeignKey("catalogue.ChannelListing", on_delete=models.CASCADE, related_name="demand_models")
    status = models.CharField(max_length=24)  # validated | insufficient_evidence
    estimate = models.JSONField()
    fitted_at = models.DateTimeField()
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")

    class Meta:
        ordering = ["-fitted_at", "-id"]


class SimulationRun(models.Model):
    """An isolated what-if run. Never touches live prices, recommendations or sales."""

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="simulations")
    listing = models.ForeignKey("catalogue.ChannelListing", on_delete=models.CASCADE, related_name="simulations")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    config = models.JSONField()
    results = models.JSONField()
    label = models.CharField(max_length=120)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-id"]


class Experiment(models.Model):
    """A product-group price test.

    Assignment is by listing (product on a channel), never by individual
    customer: PRICEFLEX does not profile willingness to pay.
    """

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        RUNNING = "running", "Running"
        COMPLETED = "completed", "Completed"
        CANCELLED = "cancelled", "Cancelled"

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="experiments")
    name = models.CharField(max_length=200)
    hypothesis = models.TextField(blank=True)
    channel = models.ForeignKey("catalogue.Channel", on_delete=models.CASCADE, related_name="experiments")
    control_listings = models.ManyToManyField("catalogue.ChannelListing", related_name="experiments_as_control", blank=True)
    treatment_listings = models.ManyToManyField("catalogue.ChannelListing", related_name="experiments_as_treatment", blank=True)
    control_policy_version = models.ForeignKey("policies.PolicyVersion", null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    treatment_policy_version = models.ForeignKey("policies.PolicyVersion", null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    starts_at = models.DateField()
    ends_at = models.DateField()
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.DRAFT)
    results = models.JSONField(default=dict, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return self.name
