from django.contrib import admin

from .models import DemandModel, Experiment, SimulationRun


@admin.register(DemandModel)
class DemandModelAdmin(admin.ModelAdmin):
    list_display = ("listing", "status", "fitted_at", "created_by")
    list_filter = ("status",)


@admin.register(SimulationRun)
class SimulationRunAdmin(admin.ModelAdmin):
    list_display = ("id", "listing", "label", "created_by", "created_at")


@admin.register(Experiment)
class ExperimentAdmin(admin.ModelAdmin):
    list_display = ("name", "channel", "status", "starts_at", "ends_at", "organisation")
    list_filter = ("organisation", "status")
    filter_horizontal = ("control_listings", "treatment_listings")
