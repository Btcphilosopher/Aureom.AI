"""Simulation workspace, demand-model fitting and experiments.

Nothing in this module writes to live prices, recommendations, publications
or sales. Simulation output is stored only as a labelled ``SimulationRun``.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal

from django.utils import timezone

from apps.accounts.permissions import require
from apps.audit.services import record
from apps.competitors.services import engine_observations
from apps.costs.models import CostVersion
from apps.costs.services import cost_for, cost_inputs
from apps.inventory.models import SalesObservation
from apps.inventory.services import inventory_input, sales_periods
from apps.publishing.models import PriceHistory
from apps.recommendations.services import build_input
from apps.recommendations.workflow import WorkflowError
from engine.demand import DemandObservation, estimate_demand
from engine.policy import parse_policy
from engine.simulation import Arm, DemandSimulatorConfig, SimulationScenario, run_simulation
from engine.strategies import inventory_metrics
from engine.types import PricePoint

from .models import DemandModel, Experiment, SimulationRun


def demand_observations(listing, until: datetime) -> list[DemandObservation]:
    rows = SalesObservation.objects.filter(variant=listing.variant, channel=listing.channel,
                                           period_start__lt=until.date()).order_by("period_start")
    return [DemandObservation(day=r.period_start, price=r.exposed_price or r.unit_price, units=r.units_sold,
                              stockout=r.stockout, promotion=r.promotion_active, available_units=r.available_units,
                              traffic=float(r.traffic) if r.traffic else None, returns=r.returns_units,
                              cancellations=r.cancellations) for r in rows]


def fit_demand_model(membership, listing, *, at: datetime | None = None) -> DemandModel:
    """Fit and store a demand estimate using only sales recorded before ``at``."""
    require(membership, "simulate", listing.channel)
    at = at or timezone.now()
    estimate = estimate_demand(demand_observations(listing, at))
    model = DemandModel.objects.create(listing=listing, status=estimate.status, estimate=estimate.to_dict(),
                                       fitted_at=at, created_by=membership.user)
    record(listing.channel.organisation, membership.user, "demand_model.fitted", model,
           f"{listing}: demand estimate {estimate.status}", {"reasons": estimate.reasons})
    return model


def _arm_policy(config: dict, order: list[str], **overrides) -> dict | None:
    """Derive an arm's policy from the listing's policy; None if it would be invalid."""
    cfg, _ = parse_policy(config)
    usable = []
    for name in order:
        if name == "clearance" and not (cfg and cfg.clearance.enabled):
            continue
        if name == "margin_led" and config.get("target_contribution_margin") is None:
            continue
        usable.append(name)
    if not usable:
        return None
    derived = {**config, "strategy_order": usable, **overrides}
    return derived if parse_policy(derived)[0] is not None else None


def simulate_listing(membership, listing, *, days: int = 28, elasticity: Decimal = Decimal("-1.5"),
                     base_units_per_day: Decimal | None = None, competitor_sensitivity: Decimal = Decimal("0"),
                     initial_on_hand: int | None = None, seed: int = 20240101,
                     replenishments: list[tuple[int, int]] | None = None, now: datetime | None = None) -> SimulationRun:
    """Backtest pricing strategies over the last ``days`` using an explicit demand simulator."""
    require(membership, "simulate", listing.channel)
    if not (1 <= days <= 180):
        raise WorkflowError("validation_error", "days must be between 1 and 180.", http_status=422)
    if elasticity >= 0 or elasticity < Decimal("-10"):
        raise WorkflowError("validation_error", "elasticity must be negative (between -10 and 0).", http_status=422)
    if not listing.policy_id or not listing.policy.current_version_id:
        raise WorkflowError("validation_error", "The listing has no pricing policy to simulate.", http_status=422)
    now = now or timezone.now()
    start = (now - timedelta(days=days)).replace(hour=6, minute=0, second=0, microsecond=0)
    variant, channel = listing.variant, listing.channel
    config = listing.policy.current_version.config

    base = build_input(listing, start)
    if base.tax is None:
        raise WorkflowError("validation_error", f"Cannot simulate: {base.tax_issue}", http_status=422)
    history = list(PriceHistory.objects.filter(listing=listing, effective_at__lte=start).order_by("effective_at", "id"))
    initial_price = history[-1].price if history else listing.confirmed_price
    if initial_price is None:
        raise WorkflowError("validation_error", "The listing has no price to start from.", http_status=422)

    times = sorted({cv.effective_from for cv in CostVersion.objects.filter(variant=variant, effective_from__lte=now)})
    timeline = []
    for t in times:
        resolved = cost_inputs(cost_for(variant, channel, t))
        if resolved is not None:
            timeline.append((t, resolved))
    if not timeline:
        raise WorkflowError("validation_error", "Cannot simulate without any cost version.", http_status=422)

    inventory_now = inventory_input(variant, channel)
    on_hand = initial_on_hand if initial_on_hand is not None else (inventory_now.on_hand if inventory_now else 0)
    assumptions = []
    if initial_on_hand is None:
        assumptions.append(f"Starting stock is today's on-hand quantity ({on_hand}); historical stock levels are "
                           "not reconstructed.")
    if base_units_per_day is None:
        metrics = inventory_metrics(base, parse_policy(config)[0]) if parse_policy(config)[0] else None
        rate = metrics.avg_daily_sales if (metrics and metrics.avg_daily_sales) else None
        base_units_per_day = rate if rate and rate > 0 else Decimal("1")
        assumptions.append(f"Base demand of {base_units_per_day} units/day at the starting price is the in-stock "
                           "sales rate recorded before the simulation start." if rate and rate > 0 else
                           "No in-stock sales were recorded before the start; base demand defaults to 1 unit/day.")
    demand = DemandSimulatorConfig(
        base_units_per_day=float(base_units_per_day), reference_price=initial_price, elasticity=float(elasticity),
        competitor_sensitivity=float(competitor_sensitivity), seed=seed)

    arms = [Arm("fixed", "Current fixed pricing", None)]
    skipped = []
    rules = _arm_policy(config, ["clearance", "inventory_led", "margin_led"])
    if rules:
        arms.append(Arm("rules", "Rules-based (margin, inventory, clearance)", rules))
    else:
        skipped.append({"key": "rules", "reason": "The policy defines no rules-based strategy that can run."})
    competitor = _arm_policy(config, ["clearance", "competitor_aware", "margin_led"])
    if competitor:
        arms.append(Arm("competitor_aware", "Competitor-aware", competitor))
    model = DemandModel.objects.filter(listing=listing, fitted_at__lte=start, status="validated").order_by("-fitted_at").first()
    if model is not None:
        demand_policy = _arm_policy(config, ["demand_led", "margin_led"], demand={"enabled": True, "max_model_age_days": 365})
        if demand_policy:
            arms.append(Arm("demand_model", "Demand-model pricing", demand_policy, use_demand_model=True))
    else:
        skipped.append({"key": "demand_model", "reason": "No validated demand estimate existed before the simulation "
                        "start, so demand-model pricing was not run (using a later estimate would leak future data)."})

    scenario = SimulationScenario(
        start=start, days=days, base_input=base, initial_price=initial_price, initial_on_hand=on_hand,
        cost_timeline=tuple(timeline), competitor_timeline=engine_observations(variant, now, days=days + 30),
        demand=demand, arms=tuple(arms), guard_policy=config, replenishments=tuple(replenishments or ()),
        history_sales=sales_periods(variant, channel, start, 90),
        history_prices=tuple(PricePoint(p.effective_at, p.price) for p in history),
    )
    results = run_simulation(scenario)
    results["assumptions"] = assumptions + results["assumptions"]
    results["skipped_arms"] = skipped
    results["policy_version"] = listing.policy.current_version.label
    run = SimulationRun.objects.create(
        organisation=channel.organisation, listing=listing, created_by=membership.user, label=results["label"],
        config={"days": days, "elasticity": str(elasticity), "base_units_per_day": str(base_units_per_day),
                "competitor_sensitivity": str(competitor_sensitivity), "initial_on_hand": on_hand, "seed": seed,
                "replenishments": replenishments or [], "start": start.isoformat()},
        results=results)
    record(channel.organisation, membership.user, "simulation.run", run, f"Simulation for {listing} over {days} days")
    return run


def experiment_readout(experiment: Experiment) -> dict:
    """Descriptive comparison of realised results for the two listing groups."""
    from .reports import realised_frame

    out = {"label": "Realised transactions during the experiment window. A descriptive comparison of two product "
                    "groups; it is causal evidence only if the groups were assigned at random and are comparable.",
           "groups": {}}
    for name, listings in (("control", experiment.control_listings.all()), ("treatment", experiment.treatment_listings.all())):
        frame = realised_frame(experiment.organisation, experiment.starts_at, experiment.ends_at,
                               listing_ids=[listing.pk for listing in listings])
        units = int(frame["units"].sum()) if len(frame) else 0
        revenue = frame["net_revenue"].sum() if len(frame) else Decimal("0")
        known = frame[frame["contribution"].notna()] if len(frame) else frame
        contribution = known["contribution"].sum() if len(known) else Decimal("0")
        out["groups"][name] = {"listings": listings.count(), "units": units, "net_revenue": f"{revenue:.2f}",
                               "contribution": f"{contribution:.2f}",
                               "contribution_margin": f"{(contribution / revenue):.4f}" if revenue else None}
    return out
