"""Realised results, kept apart from projections.

*Realised* figures are computed only from recorded transactions
(``SalesObservation``) at their actual transaction prices and the cost version
in force on the day. *Projected* figures come from recommendations and are
never mixed into realised totals.
"""

from __future__ import annotations

from datetime import UTC, date, datetime, time, timedelta
from decimal import Decimal

import pandas as pd
from django.utils import timezone

from apps.catalogue.models import ChannelListing
from apps.costs.services import cost_for, cost_inputs, tax_for
from apps.inventory.models import SalesObservation
from apps.policies.models import Promotion
from apps.publishing.models import PriceHistory
from apps.recommendations.models import PriceRecommendation
from engine.money import margin_breakdown

COLUMNS = ["listing_id", "sku", "product", "channel", "day", "units", "unit_price", "net_revenue", "contribution",
           "synthetic", "cost_known"]


def realised_frame(organisation, since: date, until: date, *, listing_ids: list[int] | None = None) -> pd.DataFrame:
    listings = ChannelListing.objects.filter(channel__organisation=organisation).select_related(
        "variant", "variant__product", "channel")
    if listing_ids is not None:
        listings = listings.filter(pk__in=listing_ids)
    by_key = {(listing.variant_id, listing.channel_id): listing for listing in listings}
    now = timezone.now()
    rows = []
    sales = SalesObservation.objects.filter(organisation=organisation, period_start__gte=since, period_start__lte=until)
    for s in sales.order_by("period_start"):
        listing = by_key.get((s.variant_id, s.channel_id))
        if listing is None:
            continue
        # Costs and funding as they stood at the end of the sales period (never later than now).
        at = min(datetime.combine(s.period_end, time.max, tzinfo=UTC), now)
        cost = cost_inputs(cost_for(listing.variant, listing.channel, at))
        promo = Promotion.objects.filter(listings=listing, status="approved", starts_at__lte=at, ends_at__gt=at).first()
        funding = promo.supplier_funding_per_unit if promo else Decimal("0")
        tax, _ = tax_for(listing.channel, listing.variant.product, at)
        net = contribution = None
        if s.units_sold == 0:
            net, contribution = Decimal("0"), Decimal("0")
        elif s.unit_price is not None and tax is not None:
            net = tax.net(s.unit_price) * s.units_sold
            if cost is not None:
                b = margin_breakdown(s.unit_price, cost, tax, customer_delivery_charge=listing.channel.customer_delivery_charge,
                                     promotion_funding=funding)
                per_unit = b.contribution + b.expected_returns_and_warranty - cost.warranty_cost
                contribution = per_unit * s.units_sold - cost.cost_per_return * s.returns_units
        rows.append({"listing_id": listing.pk, "sku": listing.variant.sku, "product": listing.variant.name,
                     "channel": listing.channel.code, "day": s.period_start, "units": s.units_sold,
                     "unit_price": s.unit_price, "net_revenue": net, "contribution": contribution,
                     "synthetic": s.is_synthetic, "cost_known": cost is not None})
    return pd.DataFrame(rows, columns=COLUMNS)


def _sum(series) -> Decimal:
    return sum((v for v in series if v is not None and not pd.isna(v)), Decimal("0"))


def realised_summary(organisation, since: date, until: date) -> dict:
    frame = realised_frame(organisation, since, until)
    by_listing = []
    if len(frame):
        for (listing_id, sku, product, channel), g in frame.groupby(["listing_id", "sku", "product", "channel"], sort=True):
            revenue, contribution = _sum(g["net_revenue"]), _sum(g["contribution"])
            units = int(g["units"].sum())
            complete = bool(g[g["units"] > 0]["contribution"].notna().all())
            by_listing.append({
                "listing_id": int(listing_id), "sku": sku, "product": product, "channel": channel, "units": units,
                "net_revenue": revenue, "contribution": contribution if complete else None,
                "contribution_margin": (contribution / revenue) if (revenue and complete) else None,
                "average_transaction_price": (_sum(g["unit_price"] * g["units"]) / units) if units else None,
                "synthetic": bool(g["synthetic"].any()), "cost_known": complete,
            })
    revenue = sum((r["net_revenue"] for r in by_listing), Decimal("0"))
    contribution = sum((r["contribution"] for r in by_listing if r["contribution"] is not None), Decimal("0"))
    return {
        "label": "REALISED - from recorded transactions at actual transaction prices",
        "since": since, "until": until, "rows": by_listing,
        "totals": {"units": sum(r["units"] for r in by_listing), "net_revenue": revenue, "contribution": contribution,
                   "contribution_margin": (contribution / revenue) if revenue else None,
                   "listings_without_cost": sum(1 for r in by_listing if not r["cost_known"])},
        "contains_synthetic": any(r["synthetic"] for r in by_listing),
    }


def projection_vs_realised(organisation, *, days_after: int = 14) -> list[dict]:
    """For each verified price change: the projected unit contribution next to what was realised afterwards."""
    out = []
    recs = PriceRecommendation.objects.filter(organisation=organisation, status="verified").select_related(
        "listing", "listing__variant", "listing__channel").order_by("-evaluated_at")[:100]
    for rec in recs:
        entry = PriceHistory.objects.filter(recommendation=rec).order_by("-effective_at").first()
        if entry is None:
            continue
        since = entry.effective_at.date()
        frame = realised_frame(organisation, since, since + timedelta(days=days_after), listing_ids=[rec.listing_id])
        sold = frame[(frame["units"] > 0) & frame["contribution"].notna()] if len(frame) else frame
        units = int(sold["units"].sum()) if len(sold) else 0
        realised_unit = (_sum(sold["contribution"]) / units) if units else None
        projection = (rec.result or {}).get("projection") or {}
        projected = projection.get("unit_contribution_recommended")
        out.append({
            "recommendation_id": rec.pk, "sku": rec.listing.variant.sku, "channel": rec.listing.channel.code,
            "published_at": entry.effective_at, "published_price": entry.price,
            "projected_unit_contribution": Decimal(projected) if projected else None,
            "realised_units": units, "realised_unit_contribution": realised_unit,
            "realised_average_price": (_sum(sold["unit_price"] * sold["units"]) / units) if units else None,
            "difference": (realised_unit - Decimal(projected)) if (realised_unit is not None and projected) else None,
        })
    return out
