from __future__ import annotations

import uuid
from datetime import datetime

from django.db import transaction
from django.db.models import Q

from apps.accounts.permissions import require
from apps.audit.services import record
from apps.catalogue.importing import ImportResult, Lookups, RowErrors
from engine.money import FEE_BASES, CostInputs, TaxConfig

from .models import CostVersion, TaxRule

COST_FIELDS = (
    "acquisition_cost", "freight_landed", "packaging", "fulfilment", "merchant_funded_delivery", "fee_percent",
    "fee_fixed", "expected_return_rate", "cost_per_return", "warranty_cost", "non_recoverable_input_tax",
    "recoverable_input_tax", "overhead_allocation",
)


def cost_for(variant, channel, at: datetime) -> CostVersion | None:
    """The cost version in force at ``at``: channel-specific first, then the general one."""
    base = CostVersion.objects.filter(variant=variant, effective_from__lte=at).order_by("-effective_from", "-id")
    return base.filter(channel=channel).first() or base.filter(channel__isnull=True).first()


def cost_inputs(cv: CostVersion | None) -> CostInputs | None:
    if cv is None:
        return None
    return CostInputs(
        currency=cv.currency, fee_basis=cv.fee_basis, tax_basis=cv.tax_basis, cost_version_id=str(cv.pk),
        effective_from=cv.effective_from.isoformat(), source=cv.source,
        **{name: getattr(cv, name) for name in COST_FIELDS},
    )


def tax_rules_for(channel, product, at: datetime):
    return TaxRule.objects.filter(
        organisation=channel.organisation, region=channel.region, tax_category=product.tax_category,
        effective_from__lte=at,
    ).filter(Q(effective_to__isnull=True) | Q(effective_to__gt=at)).order_by("-effective_from")


def tax_for(channel, product, at: datetime) -> tuple[TaxConfig | None, str]:
    """Resolve the tax rule, or explain why the configuration is uncertain."""
    rules = list(tax_rules_for(channel, product, at)[:2])
    if not rules:
        return None, (f"No tax rule is configured for tax category '{product.tax_category}' in region "
                      f"'{channel.region}'.")
    if len(rules) > 1 and rules[0].effective_from == rules[1].effective_from:
        return None, (f"Two tax rules for '{product.tax_category}' in '{channel.region}' take effect at the same "
                      "time; the configuration is ambiguous.")
    r = rules[0]
    return TaxConfig(rate=r.rate, prices_include_tax=r.prices_include_tax, jurisdiction=r.region,
                     category=r.tax_category, source=r.source or f"tax_rule:{r.pk}"), ""


def import_costs(membership, rows: list[dict], *, source: str = "import") -> ImportResult:
    """Create cost versions from validated rows. Rejected rows write nothing."""
    require(membership, "import_data")
    org = membership.organisation
    result = ImportResult(kind="costs", batch=uuid.uuid4().hex[:12], received=len(rows))
    lookups = Lookups(org)
    accepted: list[CostVersion] = []
    for index, row in enumerate(rows, start=1):
        errors = RowErrors()
        variant = lookups.variant(row, errors)
        channel = lookups.channel(row, errors, required=False)
        currency = str(row.get("currency") or "").strip().upper()
        if len(currency) != 3:
            errors.append("currency must be a 3-letter code")
        values = {"acquisition_cost": errors.dec(row, "acquisition_cost", required=True)}
        for name in COST_FIELDS[1:]:
            limit = "0.99" if name == "fee_percent" else ("1" if name == "expected_return_rate" else None)
            values[name] = errors.dec(row, name, maximum=limit)
        fee_basis = str(row.get("fee_basis") or "gross_item").strip()
        if fee_basis not in FEE_BASES:
            errors.append(f"fee_basis must be one of {', '.join(FEE_BASES)}")
        effective = errors.when(row, "effective_from", required=True)
        if errors:
            result.reject(index, row, list(errors))
            continue
        accepted.append(CostVersion(
            organisation=org, variant=variant, channel=channel, currency=currency, fee_basis=fee_basis,
            tax_basis=str(row.get("tax_basis") or "net_of_recoverable_tax"), effective_from=effective,
            source=str(row.get("source") or source)[:200], import_batch=result.batch, created_by=membership.user,
            **values,
        ))
    with transaction.atomic():
        for cv in accepted:
            previous = cost_for(cv.variant, cv.channel, cv.effective_from)
            cv.save()
            result.created += 1
            record(org, membership.user, "cost.version_created", cv,
                   f"Cost for {cv.variant.sku} set to {cv.currency} {cv.acquisition_cost} from {cv.effective_from:%Y-%m-%d}",
                   {"previous_acquisition_cost": str(previous.acquisition_cost) if previous else None,
                    "acquisition_cost": str(cv.acquisition_cost), "channel": cv.channel.code if cv.channel else None,
                    "batch": result.batch, "source": cv.source})
        record(org, membership.user, "cost.import", None,
               f"Cost import {result.batch}: {result.created} created, {len(result.rejected)} rejected",
               {"batch": result.batch, "rejected": result.rejected[:50]})
    return result
