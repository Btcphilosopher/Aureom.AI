from django.contrib import admin

from .models import CostVersion, TaxRule


@admin.register(TaxRule)
class TaxRuleAdmin(admin.ModelAdmin):
    list_display = ("region", "tax_category", "rate", "prices_include_tax", "effective_from", "effective_to", "organisation")
    list_filter = ("organisation", "region")


@admin.register(CostVersion)
class CostVersionAdmin(admin.ModelAdmin):
    """Cost versions are immutable history: view only. New costs arrive through audited imports."""

    list_display = ("variant", "channel", "currency", "acquisition_cost", "fee_percent", "fee_basis", "effective_from", "source")
    list_filter = ("organisation", "channel")
    search_fields = ("variant__sku", "source")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
