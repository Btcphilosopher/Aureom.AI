from django.conf import settings
from django.db import models

FEE_BASIS_CHOICES = [
    ("gross_item", "Tax-inclusive item price"),
    ("net_item", "Item price excluding tax"),
    ("gross_item_plus_delivery", "Tax-inclusive item price plus delivery charge"),
]


class TaxRule(models.Model):
    """Output-tax treatment for a tax category in a region. Never assumed; always configured."""

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="tax_rules")
    region = models.CharField(max_length=16)
    tax_category = models.CharField(max_length=32)
    rate = models.DecimalField(max_digits=6, decimal_places=4, help_text="Fraction, e.g. 0.2000 for 20%")
    prices_include_tax = models.BooleanField(help_text="Whether displayed customer prices include this tax")
    effective_from = models.DateTimeField()
    effective_to = models.DateTimeField(null=True, blank=True)
    source = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ["region", "tax_category", "-effective_from"]

    def __str__(self) -> str:
        return f"{self.region}/{self.tax_category} {self.rate:.2%}"


class CostVersion(models.Model):
    """An immutable, dated statement of unit cost. A new cost is a new row."""

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="cost_versions")
    variant = models.ForeignKey("catalogue.ProductVariant", on_delete=models.CASCADE, related_name="cost_versions")
    channel = models.ForeignKey("catalogue.Channel", null=True, blank=True, on_delete=models.CASCADE,
                                related_name="cost_versions",
                                help_text="Blank applies to every channel without a channel-specific version.")
    currency = models.CharField(max_length=3)
    acquisition_cost = models.DecimalField(max_digits=12, decimal_places=4)
    freight_landed = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    packaging = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    fulfilment = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    merchant_funded_delivery = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    fee_percent = models.DecimalField(max_digits=7, decimal_places=5, default=0, help_text="Fraction, 0.02900 = 2.9%")
    fee_fixed = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    fee_basis = models.CharField(max_length=32, choices=FEE_BASIS_CHOICES, default="gross_item")
    expected_return_rate = models.DecimalField(max_digits=6, decimal_places=4, default=0)
    cost_per_return = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    warranty_cost = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    non_recoverable_input_tax = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    recoverable_input_tax = models.DecimalField(
        max_digits=12, decimal_places=4, default=0,
        help_text="Recorded for reference only. Recoverable tax is not an economic cost.")
    overhead_allocation = models.DecimalField(max_digits=12, decimal_places=4, default=0)
    tax_basis = models.CharField(max_length=40, default="net_of_recoverable_tax")
    effective_from = models.DateTimeField(db_index=True)
    source = models.CharField(max_length=200)
    import_batch = models.CharField(max_length=64, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-effective_from", "-id"]
        indexes = [models.Index(fields=["variant", "channel", "-effective_from"])]

    def __str__(self) -> str:
        return f"{self.variant.sku} cost from {self.effective_from:%Y-%m-%d}"
