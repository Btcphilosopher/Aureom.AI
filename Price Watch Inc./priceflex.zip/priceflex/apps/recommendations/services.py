"""Pricing runs, evaluation, approval and reproducibility checks."""

from __future__ import annotations

from datetime import datetime, timedelta
from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from apps.accounts.permissions import require, scope_listings
from apps.audit.services import record
from apps.catalogue.models import ChannelListing
from apps.competitors.models import ComparableOfferSet
from apps.competitors.services import engine_feeds, engine_observations
from apps.costs.services import cost_for, cost_inputs, tax_for
from apps.inventory.services import inventory_input, sales_periods
from apps.policies.models import PriceCommitment, Promotion
from apps.publishing.models import PriceHistory
from apps.simulation.models import DemandModel
from engine import ALGORITHM_VERSION
from engine.evaluation import OUTCOME_BLOCKED, OUTCOME_CHANGE, OUTCOME_CONFLICT, evaluate, validate_price
from engine.explanations import recommendation_response
from engine.money import D
from engine.policy import parse_policy
from engine.types import (
    CommitmentInput,
    DemandModelInput,
    EvaluationInput,
    PricePoint,
    PromotionInput,
    snapshot_hash,
)

from .models import ApprovalDecision, InputSnapshot, PriceRecommendation, PricingRun
from .models import RecommendationStatus as S
from .workflow import OPEN_STATUSES, WorkflowError, transition

HISTORY_DAYS = 120
SALES_DAYS = 90


def listing_queryset():
    return ChannelListing.objects.select_related(
        "variant", "variant__product", "channel", "channel__organisation", "policy", "policy__current_version")


def build_input(listing: ChannelListing, at: datetime, *, policy_version=None) -> EvaluationInput:
    """Assemble everything the engine may look at for one listing, as known at ``at``."""
    variant, channel, product = listing.variant, listing.channel, listing.variant.product
    org = channel.organisation
    version = policy_version or (listing.policy.current_version if listing.policy_id else None)
    cv = cost_for(variant, channel, at)
    tax, tax_issue = tax_for(channel, product, at)
    history = list(PriceHistory.objects.filter(listing=listing, effective_at__lte=at,
                                               effective_at__gte=at - timedelta(days=HISTORY_DAYS)).order_by("effective_at", "id"))
    earlier = PriceHistory.objects.filter(listing=listing, effective_at__lt=at - timedelta(days=HISTORY_DAYS)
                                          ).order_by("-effective_at", "-id").first()
    points = ([earlier] if earlier else []) + history
    promotions = Promotion.objects.filter(listings=listing, ends_at__gt=at).exclude(status="cancelled").order_by("starts_at", "id")
    commitments = PriceCommitment.objects.filter(listing=listing).order_by("id")
    model = DemandModel.objects.filter(listing=listing, fitted_at__lte=at).order_by("-fitted_at", "-id").first()
    demand = None
    if model is not None:
        e = model.estimate
        demand = DemandModelInput(
            model_id=str(model.pk), status=model.status,
            elasticity=D(str(e["elasticity"]), allow_none=True) if e.get("elasticity") is not None else None,
            ci_low=D(str(e["ci_low"])) if e.get("ci_low") is not None else None,
            ci_high=D(str(e["ci_high"])) if e.get("ci_high") is not None else None,
            reference_price=D(e.get("reference_price"), allow_none=True),
            reference_units_per_day=D(str(e["reference_units_per_day"])) if e.get("reference_units_per_day") is not None else None,
            fitted_at=model.fitted_at, reasons=tuple(e.get("reasons", ())),
        )
    return EvaluationInput(
        evaluation_time=at,
        product_id=str(product.pk), variant_id=str(variant.pk), sku=variant.sku, product_name=variant.name,
        category=product.category, condition=variant.condition, channel=channel.code, region=channel.region,
        currency=channel.currency,
        policy=version.config if version else {}, policy_version=version.label if version else "",
        current_price=listing.confirmed_price, current_price_confirmed_at=listing.confirmed_at,
        standard_retail_price=listing.standard_retail_price,
        customer_delivery_charge=channel.customer_delivery_charge,
        cost=cost_inputs(cv),
        cost_issue="" if cv else f"No cost version is effective for {variant.sku} on channel '{channel.code}'.",
        tax=tax, tax_issue=tax_issue,
        inventory=inventory_input(variant, channel),
        sales=sales_periods(variant, channel, at, SALES_DAYS),
        competitor_observations=engine_observations(variant, at),
        feeds=engine_feeds(org),
        price_history=tuple(PricePoint(p.effective_at, p.price) for p in points),
        promotions=tuple(PromotionInput(
            promotion_id=str(p.pk), name=p.name, status=p.status, starts_at=p.starts_at, ends_at=p.ends_at,
            kind=p.kind, value=p.value, funding=p.funding, supplier_funding_per_unit=p.supplier_funding_per_unit,
            eligibility=p.eligibility, approved_min_contribution_margin=p.approved_min_contribution_margin,
        ) for p in promotions),
        commitments=tuple(CommitmentInput(commitment_id=str(c.pk), kind=c.kind, value=c.value, reference=c.reference,
                                          valid_from=c.valid_from, valid_to=c.valid_to) for c in commitments),
        demand_model=demand,
    )


def _automation_allows(listing, policy_cfg, result) -> tuple[bool, str]:
    """Bounded automation: authorised policy, named product group, small change, no warnings."""
    auto = policy_cfg.automation
    if not auto.enabled or not listing.policy.automation_authorised:
        return False, ""
    if result.outcome != OUTCOME_CHANGE or result.current_price is None or result.warnings:
        return False, ""
    if listing.variant.product.category not in auto.allowed_categories:
        return False, ""
    change = (result.recommended_price - result.current_price) / result.current_price
    if abs(change) > auto.max_auto_change_pct or (change > 0 and not auto.allow_price_increases):
        return False, ""
    return True, (f"Approved by bounded automation: {change:+.2%} is within the authorised "
                  f"{auto.max_auto_change_pct:.1%} for category '{listing.variant.product.category}'.")


def evaluate_listing(run: PricingRun | None, listing: ChannelListing, at: datetime) -> PriceRecommendation:
    org = listing.channel.organisation
    if listing.policy_id is None or listing.policy.current_version_id is None:
        raise WorkflowError("no_policy", f"{listing} has no pricing policy version to evaluate against.", http_status=422)
    version = listing.policy.current_version
    payload = build_input(listing, at, policy_version=version).to_dict()
    with transaction.atomic():
        snapshot = InputSnapshot.objects.create(organisation=org, listing=listing, payload=payload,
                                                sha256=snapshot_hash(payload))
        # Evaluate from the stored form, so a later replay sees byte-identical inputs.
        result = evaluate(EvaluationInput.from_dict(payload))
        data = result.to_dict()
        comparable = None
        if result.comparables is not None:
            c = result.comparables
            comparable = ComparableOfferSet.objects.create(
                organisation=org, listing=listing, basis=c.basis, built_at=at, eligible_count=len(c.eligible),
                excluded_count=len(c.excluded), lowest=c.lowest, median=c.median, highest=c.highest,
                eligible=data["comparables"]["eligible"], excluded=data["comparables"]["excluded"],
                warnings=list(c.warnings))
        for old in PriceRecommendation.objects.select_for_update().filter(listing=listing, status__in=OPEN_STATUSES):
            transition(old, S.SUPERSEDED, note="Replaced by a newer evaluation.", audit=False)
        policy_cfg, _ = parse_policy(payload["policy"])
        ttl = policy_cfg.recommendation_ttl_hours if policy_cfg else 24
        rec = PriceRecommendation.objects.create(
            organisation=org, run=run, listing=listing, snapshot=snapshot, policy_version=version,
            comparable_set=comparable, algorithm_version=result.algorithm_version, evaluated_at=at,
            status=S.DRAFT, outcome=result.outcome, selected_strategy=result.selected_strategy or "",
            currency=result.currency, current_price=result.current_price,
            recommended_price=result.recommended_price if result.outcome == OUTCOME_CHANGE else None,
            expected_price_version=listing.price_version, result=data, reasons=data["reasons"],
            constraints_applied=data["constraints_applied"], warnings=data["warnings"],
            has_warnings=bool(data["warnings"] or data["blocking_issues"]),
            expires_at=at + timedelta(hours=ttl),
        )
        transition(rec, S.EVALUATED, audit=False)
        if result.outcome in (OUTCOME_CHANGE, OUTCOME_CONFLICT):
            transition(rec, S.AWAITING_APPROVAL, audit=False)
        if policy_cfg is not None:
            ok, note = _automation_allows(listing, policy_cfg, result)
            if ok:
                ApprovalDecision.objects.create(recommendation=rec, decision="auto_approved", decided_by=None,
                                                approved_price=rec.recommended_price, comment=note)
                rec.approved_price = rec.recommended_price
                rec.save(update_fields=["approved_price"])
                transition(rec, S.APPROVED, actor="automation", note=note)
    return rec


def run_pricing(membership, *, channel=None, skus: list[str] | None = None, listing_ids: list[int] | None = None,
                trigger: str = "manual", at: datetime | None = None) -> PricingRun:
    require(membership, "run_pricing", channel)
    org = membership.organisation
    at = at or timezone.now()
    listings = scope_listings(membership, listing_queryset().filter(is_active=True, variant__is_active=True))
    if channel is not None:
        listings = listings.filter(channel=channel)
    if skus:
        listings = listings.filter(variant__sku__in=skus)
    if listing_ids:
        listings = listings.filter(pk__in=listing_ids)
    run = PricingRun.objects.create(
        organisation=org, trigger=trigger, triggered_by=membership.user, evaluation_time=at,
        algorithm_version=ALGORITHM_VERSION,
        scope={"channel": channel.code if channel else None, "skus": skus or None, "listing_ids": listing_ids or None})
    counts = {"evaluated": 0, "change": 0, "no_change": 0, "conflict": 0, "blocked": 0, "skipped_no_policy": 0,
              "auto_approved": 0}
    try:
        for listing in listings.order_by("variant__sku", "channel__code"):
            if not listing.policy_id or not listing.policy.current_version_id or listing.policy.status != "active":
                counts["skipped_no_policy"] += 1
                continue
            rec = evaluate_listing(run, listing, at)
            counts["evaluated"] += 1
            counts[rec.outcome] += 1
            counts["auto_approved"] += 1 if rec.status == S.APPROVED else 0
        run.status = "completed"
    except Exception:
        run.status = "failed"
        raise
    finally:
        run.counts, run.finished_at = counts, timezone.now()
        run.save(update_fields=["status", "counts", "finished_at"])
    record(org, membership.user, "pricing_run.completed", run,
           f"Pricing run {run.pk}: {counts['evaluated']} evaluated, {counts['change']} changes, "
           f"{counts['conflict']} conflicts, {counts['blocked']} blocked", counts)
    return run


def _locked(rec: PriceRecommendation) -> PriceRecommendation:
    return PriceRecommendation.objects.select_for_update(of=("self",)).select_related(
        "listing", "listing__variant", "listing__variant__product", "listing__channel",
        "listing__channel__organisation", "listing__policy", "listing__policy__current_version").get(pk=rec.pk)


def expire_if_due(rec: PriceRecommendation, now: datetime) -> bool:
    if rec.expires_at and rec.expires_at <= now and rec.status in (S.AWAITING_APPROVAL, S.APPROVED, S.SCHEDULED, S.FAILED):
        transition(rec, S.EXPIRED, note="The recommendation's validity period ended before it was actioned.")
        return True
    return False


def approve(membership, rec: PriceRecommendation, *, approved_price: Decimal | None = None, comment: str = "",
            scheduled_for: datetime | None = None) -> PriceRecommendation:
    """Approve the recommended price, or an override that still passes every hard constraint."""
    require(membership, "approve", rec.listing.channel)
    now = timezone.now()
    expired = False
    with transaction.atomic():
        rec = _locked(rec)
        if rec.status != S.AWAITING_APPROVAL:
            raise WorkflowError("invalid_state", f"Only recommendations awaiting approval can be approved "
                                                 f"(this one is '{rec.status}').", {"status": rec.status})
        expired = expire_if_due(rec, now)
        if not expired:
            price = approved_price if approved_price is not None else rec.recommended_price
            if price is None:
                raise WorkflowError("price_required", "This recommendation has no recommended price (constraint "
                                    "conflict); an explicit approved_price is required.", http_status=422)
            price = price.quantize(Decimal("0.01"))
            is_override = rec.recommended_price is None or price != rec.recommended_price
            if is_override and not comment.strip():
                raise WorkflowError("override_reason_required", "An override needs a recorded reason.", http_status=422)
            if scheduled_for is not None:
                require(membership, "publish", rec.listing.channel)
                if scheduled_for <= now:
                    raise WorkflowError("invalid_schedule", "scheduled_for must be in the future.", http_status=422)
                if rec.expires_at and scheduled_for >= rec.expires_at:
                    raise WorkflowError("invalid_schedule", "scheduled_for is after the recommendation expires "
                                        f"({rec.expires_at.isoformat()}).", http_status=422)
            check = validate_price(build_input(rec.listing, now), price)
            if not check["ok"]:
                raise WorkflowError(
                    "constraint_violation", "The price does not satisfy the hard constraints under current "
                    "conditions, so it cannot be approved.",
                    {"violations": check["violations"], "blocking_issues": check["blocking_issues"]}, http_status=422)
            ApprovalDecision.objects.create(recommendation=rec, decision="approved", decided_by=membership.user,
                                            approved_price=price, is_override=is_override, comment=comment)
            rec.approved_price = price
            if scheduled_for is not None:
                rec.scheduled_price, rec.scheduled_for = price, scheduled_for
            rec.save(update_fields=["approved_price", "scheduled_price", "scheduled_for"])
            action = "recommendation.override_approved" if is_override else "recommendation.approval"
            record(rec.organisation, membership.user, action, rec,
                   f"{rec.listing}: approved {rec.currency} {price}" + (" (override)" if is_override else ""),
                   {"recommended_price": str(rec.recommended_price) if rec.recommended_price is not None else None,
                    "approved_price": str(price), "is_override": is_override, "comment": comment,
                    "scheduled_for": scheduled_for.isoformat() if scheduled_for else None})
            transition(rec, S.SCHEDULED if scheduled_for else S.APPROVED, actor=membership.user, audit=False)
    if expired:
        raise WorkflowError("expired", "The recommendation has expired; run a new evaluation.")
    return rec


def reject(membership, rec: PriceRecommendation, *, comment: str) -> PriceRecommendation:
    require(membership, "approve", rec.listing.channel)
    if not comment.strip():
        raise WorkflowError("reason_required", "A rejection needs a recorded reason.", http_status=422)
    with transaction.atomic():
        rec = _locked(rec)
        if rec.status != S.AWAITING_APPROVAL:
            raise WorkflowError("invalid_state", f"Only recommendations awaiting approval can be rejected "
                                                 f"(this one is '{rec.status}').", {"status": rec.status})
        ApprovalDecision.objects.create(recommendation=rec, decision="rejected", decided_by=membership.user, comment=comment)
        transition(rec, S.REJECTED, actor=membership.user, note=comment)
    return rec


def withdraw(membership, rec: PriceRecommendation, *, comment: str) -> PriceRecommendation:
    require(membership, "approve", rec.listing.channel)
    with transaction.atomic():
        rec = _locked(rec)
        ApprovalDecision.objects.create(recommendation=rec, decision="withdrawn", decided_by=membership.user, comment=comment)
        transition(rec, S.WITHDRAWN, actor=membership.user, note=comment or "Withdrawn.")
    return rec


def expire_recommendations(now: datetime | None = None) -> int:
    now = now or timezone.now()
    count = 0
    stale = PriceRecommendation.objects.filter(expires_at__lte=now,
                                               status__in=[S.AWAITING_APPROVAL, S.APPROVED, S.SCHEDULED, S.FAILED])
    for rec in stale.select_related("listing", "organisation"):
        with transaction.atomic():
            locked = PriceRecommendation.objects.select_for_update().get(pk=rec.pk)
            count += 1 if expire_if_due(locked, now) else 0
    return count


def replay(rec: PriceRecommendation) -> dict:
    """Re-run the stored input snapshot and compare with the stored decision."""
    payload = rec.snapshot.payload
    hash_ok = snapshot_hash(payload) == rec.snapshot.sha256
    recomputed = evaluate(EvaluationInput.from_dict(payload)).to_dict()
    same_algorithm = rec.algorithm_version == ALGORITHM_VERSION
    differing = sorted(k for k in recomputed if recomputed[k] != rec.result.get(k))
    return {
        "reproducible": hash_ok and not differing,
        "snapshot_hash_matches": hash_ok,
        "stored_algorithm_version": rec.algorithm_version,
        "current_algorithm_version": ALGORITHM_VERSION,
        "same_algorithm_version": same_algorithm,
        "differing_fields": differing,
        "recomputed_recommended_price": recomputed["recommended_price"],
    }


def response_document(rec: PriceRecommendation, *, detail: bool = False) -> dict:
    listing = rec.listing
    doc = recommendation_response(
        rec.result, product_id=str(listing.variant.product_id), variant_id=str(listing.variant_id),
        sku=listing.variant.sku, channel=listing.channel.code, status=rec.status,
        input_snapshot_id=rec.snapshot.public_id,
        policy_version=rec.policy_version.label if rec.policy_version_id else "",
        recommendation_id=str(rec.pk),
    )
    doc.update(
        kind=rec.kind, product_name=listing.variant.name,
        approved_customer_price=None if rec.approved_price is None else str(rec.approved_price),
        scheduled_customer_price=None if rec.scheduled_price is None else str(rec.scheduled_price),
        scheduled_for=rec.scheduled_for.isoformat() if rec.scheduled_for else None,
        confirmed_published_price=None if listing.confirmed_price is None else str(listing.confirmed_price),
        expires_at=rec.expires_at.isoformat() if rec.expires_at else None,
        input_snapshot_sha256=rec.snapshot.sha256, status_note=rec.status_note,
    )
    if detail:
        r = rec.result
        doc.update(
            feasible_interval=r.get("feasible_interval"), selection_trace=r.get("selection_trace"),
            comparables=r.get("comparables"), inventory=r.get("inventory"),
            margin_current=r.get("margin_current"), margin_recommended=r.get("margin_recommended"),
            projection=r.get("projection"), mode=r.get("mode"),
            decisions=[{"decision": d.decision, "decided_by": d.decided_by.get_username() if d.decided_by else "automation",
                        "decided_at": d.decided_at.isoformat(),
                        "approved_price": None if d.approved_price is None else str(d.approved_price),
                        "is_override": d.is_override, "comment": d.comment} for d in rec.decisions.all()],
        )
    return doc


__all__ = ["build_input", "evaluate_listing", "run_pricing", "approve", "reject", "withdraw", "replay",
           "expire_recommendations", "response_document", "listing_queryset", "OUTCOME_BLOCKED"]
