"""Recommendation state machine.

::

    draft -> evaluated -> awaiting_approval -> approved -> scheduled -> publishing -> verified
                                   |              |            |             |
                                rejected       withdrawn    withdrawn      failed -> publishing (retry)

    plus: expired (time limit passed), superseded (a newer evaluation or a
    changed live price replaced it), withdrawn (pulled back by a person).

Only the transitions listed in :data:`TRANSITIONS` are possible.
"""

from __future__ import annotations

from apps.audit.services import record

from .models import PriceRecommendation
from .models import RecommendationStatus as S

TRANSITIONS: dict[str, set[str]] = {
    S.DRAFT: {S.EVALUATED},
    S.EVALUATED: {S.AWAITING_APPROVAL, S.SUPERSEDED, S.EXPIRED},
    S.AWAITING_APPROVAL: {S.APPROVED, S.SCHEDULED, S.REJECTED, S.EXPIRED, S.SUPERSEDED, S.WITHDRAWN},
    S.APPROVED: {S.SCHEDULED, S.PUBLISHING, S.FAILED, S.EXPIRED, S.SUPERSEDED, S.WITHDRAWN},
    S.SCHEDULED: {S.APPROVED, S.PUBLISHING, S.FAILED, S.EXPIRED, S.SUPERSEDED, S.WITHDRAWN},
    S.PUBLISHING: {S.VERIFIED, S.FAILED},
    S.FAILED: {S.PUBLISHING, S.SUPERSEDED, S.WITHDRAWN, S.EXPIRED},
    S.VERIFIED: set(),
    S.REJECTED: set(),
    S.EXPIRED: set(),
    S.SUPERSEDED: set(),
    S.WITHDRAWN: set(),
}
OPEN_STATUSES = (S.EVALUATED, S.AWAITING_APPROVAL)
TERMINAL_STATUSES = tuple(s for s, nxt in TRANSITIONS.items() if not nxt)


class WorkflowError(Exception):
    """A requested action is not valid for the current state or conditions."""

    def __init__(self, code: str, message: str, details: dict | None = None, http_status: int = 409):
        super().__init__(message)
        self.code, self.message, self.details, self.http_status = code, message, details or {}, http_status


def transition(rec: PriceRecommendation, new_status: str, *, actor=None, note: str = "", audit: bool = True) -> None:
    if new_status not in TRANSITIONS[rec.status]:
        raise WorkflowError("invalid_transition",
                            f"A recommendation that is '{rec.status}' cannot become '{new_status}'.",
                            {"from": rec.status, "to": new_status})
    previous, rec.status = rec.status, new_status
    if note:
        rec.status_note = note[:500]
    rec.save(update_fields=["status", "status_note", "updated_at"])
    if audit:
        record(rec.organisation, actor or "system", f"recommendation.{new_status}", rec,
               f"{rec.listing} {previous} -> {new_status}" + (f": {note}" if note else ""),
               {"from": previous, "to": new_status})
