from celery import shared_task
from django.contrib.auth import get_user_model

from apps.accounts.models import Membership, Organisation

from . import services


def system_membership(organisation) -> Membership | None:
    """Scheduled work runs as the organisation's designated service account, if one exists."""
    user = get_user_model().objects.filter(username=f"svc-{organisation.slug}", is_active=True).first()
    return Membership.objects.filter(user=user, organisation=organisation, is_active=True).first() if user else None


@shared_task
def evaluate_organisation(organisation_id: int) -> dict:
    organisation = Organisation.objects.get(pk=organisation_id)
    membership = system_membership(organisation)
    if membership is None:
        return {"skipped": "no service account (svc-<slug>) with a membership exists"}
    return services.run_pricing(membership, trigger="scheduled").counts


@shared_task
def evaluate_all_organisations() -> int:
    ids = list(Organisation.objects.values_list("id", flat=True))
    for organisation_id in ids:
        evaluate_organisation.delay(organisation_id)
    return len(ids)


@shared_task
def expire_recommendations() -> int:
    return services.expire_recommendations()
