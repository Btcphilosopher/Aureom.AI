from django.contrib import admin

from .models import ApprovalDecision, InputSnapshot, PriceRecommendation, PricingRun


class ReadOnlyAdmin(admin.ModelAdmin):
    """Decisions and their evidence are records: view only."""

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(PricingRun)
class PricingRunAdmin(ReadOnlyAdmin):
    list_display = ("id", "organisation", "trigger", "status", "evaluation_time", "algorithm_version", "counts")
    list_filter = ("organisation", "trigger", "status")


@admin.register(InputSnapshot)
class InputSnapshotAdmin(ReadOnlyAdmin):
    list_display = ("id", "listing", "sha256", "created_at")
    search_fields = ("sha256",)


@admin.register(PriceRecommendation)
class PriceRecommendationAdmin(ReadOnlyAdmin):
    list_display = ("id", "listing", "kind", "outcome", "status", "current_price", "recommended_price", "approved_price",
                    "policy_version", "evaluated_at")
    list_filter = ("organisation", "status", "outcome", "kind")
    search_fields = ("listing__variant__sku",)


@admin.register(ApprovalDecision)
class ApprovalDecisionAdmin(ReadOnlyAdmin):
    list_display = ("decided_at", "recommendation", "decision", "decided_by", "approved_price", "is_override")
    list_filter = ("decision", "is_override")
