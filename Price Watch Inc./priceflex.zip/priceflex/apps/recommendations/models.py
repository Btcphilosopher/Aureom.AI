from django.conf import settings
from django.db import models


class PricingRun(models.Model):
    class Trigger(models.TextChoices):
        MANUAL = "manual", "Manual"
        SCHEDULED = "scheduled", "Scheduled"
        API = "api", "API"
        DEMO = "demo", "Demo"

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="pricing_runs")
    trigger = models.CharField(max_length=12, choices=Trigger.choices, default=Trigger.MANUAL)
    triggered_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    status = models.CharField(max_length=12, default="running")  # running | completed | failed
    evaluation_time = models.DateTimeField()
    algorithm_version = models.CharField(max_length=64)
    scope = models.JSONField(default=dict, blank=True)
    counts = models.JSONField(default=dict, blank=True)
    started_at = models.DateTimeField(auto_now_add=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-started_at", "-id"]

    def __str__(self) -> str:
        return f"Run {self.pk} at {self.evaluation_time:%Y-%m-%d %H:%M}"


class InputSnapshot(models.Model):
    """The exact, complete inputs one evaluation saw. Immutable."""

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="+")
    listing = models.ForeignKey("catalogue.ChannelListing", on_delete=models.CASCADE, related_name="snapshots")
    payload = models.JSONField()
    sha256 = models.CharField(max_length=64, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.pk is not None:
            raise RuntimeError("Input snapshots are immutable")
        super().save(*args, **kwargs)

    @property
    def public_id(self) -> str:
        return f"snap_{self.pk}"


class RecommendationStatus(models.TextChoices):
    DRAFT = "draft", "Draft"
    EVALUATED = "evaluated", "Evaluated"
    AWAITING_APPROVAL = "awaiting_approval", "Awaiting approval"
    APPROVED = "approved", "Approved"
    SCHEDULED = "scheduled", "Scheduled"
    PUBLISHING = "publishing", "Publishing"
    VERIFIED = "verified", "Verified"
    REJECTED = "rejected", "Rejected"
    EXPIRED = "expired", "Expired"
    FAILED = "failed", "Failed"
    SUPERSEDED = "superseded", "Superseded"
    WITHDRAWN = "withdrawn", "Withdrawn"


class PriceRecommendation(models.Model):
    """One decision for one listing.

    The price fields are deliberately separate and never overwrite each other:

    ``current_price``      confirmed published price when the decision was evaluated
    ``recommended_price``  what the engine recommended
    ``approved_price``     what a person (or bounded automation) approved - may be an override
    ``scheduled_price``    the approved price queued for a future time
    (confirmed published price lives on ``ChannelListing``/``PriceHistory``;
    actual transaction prices live on ``SalesObservation``.)
    """

    class Kind(models.TextChoices):
        EVALUATION = "evaluation", "Evaluation"
        ROLLBACK = "rollback", "Rollback"

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="recommendations")
    run = models.ForeignKey(PricingRun, null=True, blank=True, on_delete=models.SET_NULL, related_name="recommendations")
    listing = models.ForeignKey("catalogue.ChannelListing", on_delete=models.CASCADE, related_name="recommendations")
    kind = models.CharField(max_length=12, choices=Kind.choices, default=Kind.EVALUATION)
    snapshot = models.ForeignKey(InputSnapshot, on_delete=models.PROTECT, related_name="recommendations")
    policy_version = models.ForeignKey("policies.PolicyVersion", null=True, on_delete=models.PROTECT, related_name="recommendations")
    comparable_set = models.ForeignKey("competitors.ComparableOfferSet", null=True, blank=True, on_delete=models.SET_NULL, related_name="recommendations")
    algorithm_version = models.CharField(max_length=64)
    evaluated_at = models.DateTimeField(db_index=True)
    status = models.CharField(max_length=20, choices=RecommendationStatus.choices, default=RecommendationStatus.DRAFT, db_index=True)
    outcome = models.CharField(max_length=12, db_index=True)  # change | no_change | conflict | blocked
    selected_strategy = models.CharField(max_length=32, blank=True)
    currency = models.CharField(max_length=3)
    current_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    recommended_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    approved_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    scheduled_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    scheduled_for = models.DateTimeField(null=True, blank=True)
    expected_price_version = models.PositiveIntegerField(default=0)
    result = models.JSONField(default=dict)
    reasons = models.JSONField(default=list)
    constraints_applied = models.JSONField(default=list)
    warnings = models.JSONField(default=list)
    has_warnings = models.BooleanField(default=False, db_index=True)
    status_note = models.CharField(max_length=500, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-evaluated_at", "-id"]
        indexes = [models.Index(fields=["listing", "-evaluated_at"])]

    def __str__(self) -> str:
        return f"Rec {self.pk} {self.listing} {self.outcome}/{self.status}"

    @property
    def price_to_publish(self):
        return self.scheduled_price if self.scheduled_price is not None else self.approved_price


class ApprovalDecision(models.Model):
    class Decision(models.TextChoices):
        APPROVED = "approved", "Approved"
        AUTO_APPROVED = "auto_approved", "Approved by bounded automation"
        REJECTED = "rejected", "Rejected"
        WITHDRAWN = "withdrawn", "Withdrawn"

    recommendation = models.ForeignKey(PriceRecommendation, on_delete=models.CASCADE, related_name="decisions")
    decision = models.CharField(max_length=16, choices=Decision.choices)
    decided_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT, related_name="+")
    decided_at = models.DateTimeField(auto_now_add=True)
    approved_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    is_override = models.BooleanField(default=False)
    comment = models.TextField(blank=True)

    class Meta:
        ordering = ["-decided_at", "-id"]
