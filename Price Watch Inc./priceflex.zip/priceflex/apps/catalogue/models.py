from django.db import models


class Product(models.Model):
    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="products")
    code = models.CharField(max_length=64)
    name = models.CharField(max_length=200)
    brand = models.CharField(max_length=100, blank=True)
    category = models.CharField(max_length=64, db_index=True)
    tax_category = models.CharField(max_length=32, default="standard")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]
        constraints = [models.UniqueConstraint(fields=["organisation", "code"], name="uniq_product_code")]

    def __str__(self) -> str:
        return self.name


class ProductVariant(models.Model):
    class Condition(models.TextChoices):
        NEW = "new", "New"
        REFURBISHED = "refurbished", "Refurbished"
        USED = "used", "Used"
        OPEN_BOX = "open_box", "Open box"

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="variants")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="variants")
    sku = models.CharField(max_length=64)
    name = models.CharField(max_length=200)
    attributes = models.JSONField(default=dict, blank=True)
    gtin = models.CharField(max_length=14, blank=True, db_index=True)
    mpn = models.CharField(max_length=64, blank=True)
    condition = models.CharField(max_length=16, choices=Condition.choices, default=Condition.NEW)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["sku"]
        constraints = [models.UniqueConstraint(fields=["organisation", "sku"], name="uniq_variant_sku")]

    def __str__(self) -> str:
        return f"{self.sku} - {self.name}"


class Channel(models.Model):
    class Kind(models.TextChoices):
        WEB = "web", "Own web store"
        MARKETPLACE = "marketplace", "Marketplace"
        STORE = "store", "Physical store"

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="channels")
    code = models.SlugField(max_length=32)
    name = models.CharField(max_length=100)
    kind = models.CharField(max_length=16, choices=Kind.choices, default=Kind.WEB)
    region = models.CharField(max_length=16, help_text="Tax jurisdiction / region code, e.g. GB")
    currency = models.CharField(max_length=3)
    customer_delivery_charge = models.DecimalField(
        max_digits=12, decimal_places=2, default=0,
        help_text="Delivery charge shown to the customer on this channel (in the channel's tax presentation).",
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["code"]
        constraints = [models.UniqueConstraint(fields=["organisation", "code"], name="uniq_channel_code")]

    def __str__(self) -> str:
        return self.name


class Location(models.Model):
    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="locations")
    code = models.SlugField(max_length=32)
    name = models.CharField(max_length=100)
    region = models.CharField(max_length=16, blank=True)
    channels = models.ManyToManyField(Channel, blank=True, related_name="locations",
                                      help_text="Channels fulfilled from this location. Empty means all.")

    class Meta:
        ordering = ["code"]
        constraints = [models.UniqueConstraint(fields=["organisation", "code"], name="uniq_location_code")]

    def __str__(self) -> str:
        return self.name


class ChannelListing(models.Model):
    """A variant offered on a channel, and the price state PRICEFLEX has confirmed there.

    ``confirmed_price`` only changes after a publication has been read back
    from the storefront. ``price_version`` increments with each confirmed
    change and is the optimistic-concurrency token for publication.
    """

    variant = models.ForeignKey(ProductVariant, on_delete=models.CASCADE, related_name="listings")
    channel = models.ForeignKey(Channel, on_delete=models.CASCADE, related_name="listings")
    policy = models.ForeignKey("policies.PricingPolicy", null=True, blank=True, on_delete=models.SET_NULL, related_name="listings")
    standard_retail_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    confirmed_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    price_version = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["variant__sku", "channel__code"]
        constraints = [models.UniqueConstraint(fields=["variant", "channel"], name="uniq_listing")]

    def __str__(self) -> str:
        return f"{self.variant.sku} @ {self.channel.code}"
