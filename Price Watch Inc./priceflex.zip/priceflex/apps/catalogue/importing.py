"""Shared helpers for validated, row-by-row imports.

Imports never guess. A row that fails validation is rejected with a reason
and nothing is written for it; a missing number is never replaced by zero.
"""

from __future__ import annotations

import csv
import io
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal

from engine.money import D, MoneyError

from .models import Channel, Location, ProductVariant


@dataclass
class ImportResult:
    kind: str
    batch: str = ""
    received: int = 0
    created: int = 0
    updated: int = 0
    unchanged: int = 0
    rejected: list[dict] = field(default_factory=list)

    def reject(self, index: int, row: dict, errors: list[str]) -> None:
        ident = row.get("sku") or row.get("external_observation_id") or ""
        self.rejected.append({"row": index, "sku": str(ident), "errors": errors})

    def to_dict(self) -> dict:
        return {"kind": self.kind, "batch": self.batch, "received": self.received, "created": self.created,
                "updated": self.updated, "unchanged": self.unchanged, "rejected_count": len(self.rejected),
                "rejected": self.rejected}


class RowErrors(list):
    def dec(self, row: dict, key: str, *, required: bool = False, default: str | None = "0",
            minimum: str | None = "0", maximum: str | None = None) -> Decimal | None:
        raw = row.get(key)
        if raw is None or (isinstance(raw, str) and raw.strip() == ""):
            if required:
                self.append(f"{key} is required")
                return None
            return None if default is None else Decimal(default)
        try:
            value = D(raw)
        except MoneyError as exc:
            self.append(f"{key}: {exc}")
            return None
        if minimum is not None and value < Decimal(minimum):
            self.append(f"{key} must be >= {minimum}")
        if maximum is not None and value > Decimal(maximum):
            self.append(f"{key} must be <= {maximum}")
        return value

    def integer(self, row: dict, key: str, *, required: bool = False, default: int | None = 0,
                minimum: int | None = 0) -> int | None:
        raw = row.get(key)
        if raw is None or (isinstance(raw, str) and raw.strip() == ""):
            if required:
                self.append(f"{key} is required")
                return None
            return default
        try:
            if isinstance(raw, bool):
                raise ValueError
            value = int(str(raw).strip())
        except ValueError:
            self.append(f"{key} must be a whole number")
            return None
        if minimum is not None and value < minimum:
            self.append(f"{key} must be >= {minimum}")
        return value

    def boolean(self, row: dict, key: str, default: bool = False) -> bool:
        raw = row.get(key)
        if raw is None or raw == "":
            return default
        if isinstance(raw, bool):
            return raw
        text = str(raw).strip().lower()
        if text in ("1", "true", "yes", "y"):
            return True
        if text in ("0", "false", "no", "n"):
            return False
        self.append(f"{key} must be true or false")
        return default

    def when(self, row: dict, key: str, *, required: bool = False) -> datetime | None:
        raw = row.get(key)
        if raw is None or raw == "":
            if required:
                self.append(f"{key} is required")
            return None
        if isinstance(raw, datetime):
            value = raw
        else:
            try:
                value = datetime.fromisoformat(str(raw).strip().replace("Z", "+00:00"))
            except ValueError:
                self.append(f"{key} must be an ISO-8601 datetime")
                return None
        if value.tzinfo is None:
            self.append(f"{key} must include a timezone offset")
            return None
        return value

    def day(self, row: dict, key: str, *, required: bool = False) -> date | None:
        raw = row.get(key)
        if raw is None or raw == "":
            if required:
                self.append(f"{key} is required")
            return None
        if isinstance(raw, datetime):
            return raw.date()
        if isinstance(raw, date):
            return raw
        try:
            return date.fromisoformat(str(raw).strip()[:10])
        except ValueError:
            self.append(f"{key} must be an ISO date (YYYY-MM-DD)")
            return None


class Lookups:
    """Organisation-scoped lookups by natural key, cached for one import."""

    def __init__(self, organisation):
        self.organisation = organisation
        self._variants = {v.sku: v for v in ProductVariant.objects.filter(organisation=organisation).select_related("product")}
        self._channels = {c.code: c for c in Channel.objects.filter(organisation=organisation)}
        self._locations = {loc.code: loc for loc in Location.objects.filter(organisation=organisation)}

    def variant(self, row: dict, errors: list[str]):
        sku = str(row.get("sku") or "").strip()
        if not sku:
            errors.append("sku is required")
            return None
        found = self._variants.get(sku)
        if found is None:
            errors.append(f"Unknown sku '{sku}'")
        return found

    def channel(self, row: dict, errors: list[str], *, required: bool = True):
        code = str(row.get("channel") or "").strip()
        if not code:
            if required:
                errors.append("channel is required")
            return None
        found = self._channels.get(code)
        if found is None:
            errors.append(f"Unknown channel '{code}'")
        return found

    def location(self, row: dict, errors: list[str]):
        code = str(row.get("location") or "").strip()
        if not code:
            errors.append("location is required")
            return None
        found = self._locations.get(code)
        if found is None:
            errors.append(f"Unknown location '{code}'")
        return found


def rows_from_csv(text: str) -> list[dict]:
    reader = csv.DictReader(io.StringIO(text))
    return [{(k or "").strip(): (v.strip() if isinstance(v, str) else v) for k, v in row.items()} for row in reader]
