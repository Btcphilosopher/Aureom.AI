from django.contrib import admin

from .models import Channel, ChannelListing, Location, Product, ProductVariant


class VariantInline(admin.TabularInline):
    model = ProductVariant
    extra = 0
    fields = ("organisation", "sku", "name", "gtin", "mpn", "condition", "is_active")


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "brand", "category", "tax_category", "organisation", "is_active")
    list_filter = ("organisation", "category", "is_active")
    search_fields = ("name", "code", "brand")
    inlines = [VariantInline]


@admin.register(Channel)
class ChannelAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "kind", "region", "currency", "customer_delivery_charge", "organisation")
    list_filter = ("organisation", "kind")


@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "region", "organisation")
    filter_horizontal = ("channels",)


@admin.register(ChannelListing)
class ChannelListingAdmin(admin.ModelAdmin):
    """Confirmed prices are set only by verified publication, so they are read-only here."""

    list_display = ("variant", "channel", "policy", "standard_retail_price", "confirmed_price", "price_version", "is_active")
    list_filter = ("channel", "policy", "is_active")
    search_fields = ("variant__sku", "variant__name")
    readonly_fields = ("confirmed_price", "confirmed_at", "price_version")
