from django.urls import path

from . import views

urlpatterns = [
    path("cost-imports", views.cost_imports, name="cost-imports"),
    path("inventory-imports", views.inventory_imports, name="inventory-imports"),
    path("sales-imports", views.sales_imports, name="sales-imports"),
    path("competitor-observations", views.competitor_observations, name="competitor-observations"),
    path("policies", views.policies, name="policies"),
    path("pricing-runs", views.pricing_runs, name="pricing-runs"),
    path("recommendations", views.recommendation_list, name="recommendations"),
    path("recommendations/<int:pk>", views.recommendation_detail, name="recommendation-detail"),
    path("recommendations/<int:pk>/approve", views.recommendation_approve, name="recommendation-approve"),
    path("recommendations/<int:pk>/reject", views.recommendation_reject, name="recommendation-reject"),
    path("publications", views.publications, name="publications"),
    path("publications/<int:pk>", views.publication_detail, name="publication-detail"),
    path("simulations", views.simulations, name="simulations"),
    path("products/<int:pk>/price-history", views.product_price_history, name="product-price-history"),
]
