from apps.accounts.models import Membership

from .errors import ApiError


def membership_from(request) -> Membership:
    """Resolve the caller's organisation membership.

    Callers who belong to several organisations name one with the
    ``X-Organisation: <slug>`` header. Every query downstream is filtered by
    the resolved organisation, so data from other organisations is unreachable.
    """
    cached = getattr(request, "_pf_membership", None)
    if cached is not None:
        return cached
    memberships = Membership.objects.filter(user=request.user, is_active=True).select_related("organisation")
    slug = request.headers.get("X-Organisation")
    if slug:
        membership = memberships.filter(organisation__slug=slug).first()
        if membership is None:
            raise ApiError("permission_denied", "You are not a member of that organisation.", http_status=403)
    else:
        found = list(memberships[:2])
        if not found:
            raise ApiError("permission_denied", "Your account is not a member of any organisation.", http_status=403)
        if len(found) > 1:
            raise ApiError("organisation_required", "You belong to several organisations; send an "
                           "X-Organisation header.")
        membership = found[0]
    request._pf_membership = membership
    return membership
