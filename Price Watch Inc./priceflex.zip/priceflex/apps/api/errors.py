"""One error envelope for every API failure::

    {"error": {"code": "...", "message": "...", "details": {...}}}
"""

from django.core.exceptions import ObjectDoesNotExist
from django.http import Http404
from rest_framework import exceptions, status
from rest_framework.response import Response
from rest_framework.views import exception_handler as drf_handler

from apps.accounts.permissions import PermissionDenied
from apps.recommendations.workflow import WorkflowError
from engine.policy import PolicyValidationError


class ApiError(Exception):
    def __init__(self, code: str, message: str, details=None, http_status: int = 400):
        super().__init__(message)
        self.code, self.message, self.details, self.http_status = code, message, details or {}, http_status


def error_response(code: str, message: str, details=None, http_status: int = 400, headers=None) -> Response:
    return Response({"error": {"code": code, "message": message, "details": details or {}}}, status=http_status,
                    headers=headers)


CODES = {
    exceptions.NotAuthenticated: "not_authenticated",
    exceptions.AuthenticationFailed: "not_authenticated",
    exceptions.PermissionDenied: "permission_denied",
    exceptions.NotFound: "not_found",
    exceptions.MethodNotAllowed: "method_not_allowed",
    exceptions.Throttled: "throttled",
    exceptions.ParseError: "parse_error",
    exceptions.UnsupportedMediaType: "unsupported_media_type",
    exceptions.ValidationError: "validation_error",
}


def exception_handler(exc, context):
    if isinstance(exc, ApiError):
        return error_response(exc.code, exc.message, exc.details, exc.http_status)
    if isinstance(exc, PermissionDenied):
        return error_response(exc.code, str(exc), http_status=status.HTTP_403_FORBIDDEN)
    if isinstance(exc, WorkflowError):
        return error_response(exc.code, exc.message, exc.details, exc.http_status)
    if isinstance(exc, PolicyValidationError):
        return error_response("invalid_policy", "The policy configuration is invalid.", {"errors": exc.errors}, 422)
    if isinstance(exc, Http404 | ObjectDoesNotExist):
        return error_response("not_found", "The requested resource was not found.", http_status=404)
    response = drf_handler(exc, context)
    if response is None:
        return None  # unexpected error: let Django log it and return a 500
    code = next((c for klass, c in CODES.items() if isinstance(exc, klass)), "error")
    details = response.data if isinstance(exc, exceptions.ValidationError) else {}
    if isinstance(exc, exceptions.Throttled):
        details = {"retry_after_seconds": exc.wait}
    message = "Validation failed." if isinstance(exc, exceptions.ValidationError) else str(getattr(exc, "detail", exc))
    response.data = {"error": {"code": code, "message": message, "details": details}}
    return response
