"""Idempotency-Key support for POST endpoints.

* Same key + same body  -> the original response is replayed with
  ``Idempotent-Replayed: true`` and nothing runs twice.
* Same key + different body -> 409 ``idempotency_key_reused``.
* Keys are scoped to the organisation and the request path.
"""

import hashlib
import json
import re
from functools import wraps

from django.db import IntegrityError, transaction
from rest_framework.response import Response

from .context import membership_from
from .errors import ApiError
from .models import IdempotencyRecord

KEY_PATTERN = re.compile(r"^[A-Za-z0-9._:\-]{8,128}$")


def _hash(data) -> str:
    return hashlib.sha256(json.dumps(data, sort_keys=True, default=str).encode()).hexdigest()


def idempotent(required: bool = False):
    def decorator(view):
        @wraps(view)
        def wrapper(request, *args, **kwargs):
            key = request.headers.get("Idempotency-Key")
            if not key:
                if required:
                    raise ApiError("idempotency_key_required", "This endpoint requires an Idempotency-Key header.")
                return view(request, *args, **kwargs)
            if not KEY_PATTERN.match(key):
                raise ApiError("invalid_idempotency_key", "Idempotency-Key must be 8-128 characters of "
                               "letters, digits, '.', '_', ':' or '-'.")
            membership = membership_from(request)
            scope = f"{request.method} {request.path}"
            digest = _hash(request.data)
            try:
                with transaction.atomic():
                    entry = IdempotencyRecord.objects.create(organisation=membership.organisation, key=key,
                                                             scope=scope, request_hash=digest)
            except IntegrityError:
                existing = IdempotencyRecord.objects.get(organisation=membership.organisation, key=key, scope=scope)
                if existing.request_hash != digest:
                    raise ApiError("idempotency_key_reused", "This Idempotency-Key was already used with a "
                                   "different request body.", http_status=409)
                if existing.response_status is None:
                    raise ApiError("request_in_progress", "The original request with this Idempotency-Key is "
                                   "still being processed.", http_status=409)
                return Response(existing.response_body, status=existing.response_status,
                                headers={"Idempotent-Replayed": "true"})
            try:
                response = view(request, *args, **kwargs)
            except Exception:
                entry.delete()  # the request did not complete; the key may be retried
                raise
            entry.response_status = response.status_code
            entry.response_body = json.loads(json.dumps(response.data, default=str))
            entry.save(update_fields=["response_status", "response_body"])
            return response
        return wrapper
    return decorator
