import codecs
import json
from decimal import Decimal

from rest_framework.exceptions import ParseError
from rest_framework.parsers import BaseParser, JSONParser

from apps.catalogue.importing import rows_from_csv


class DecimalJSONParser(JSONParser):
    """JSON parser that reads numbers with a fractional part as Decimal, never float."""

    def parse(self, stream, media_type=None, parser_context=None):
        encoding = (parser_context or {}).get("encoding", "utf-8")
        try:
            return json.load(codecs.getreader(encoding)(stream), parse_float=Decimal)
        except ValueError as exc:
            raise ParseError(f"JSON parse error - {exc}")


class CSVParser(BaseParser):
    """``text/csv`` bodies for the import endpoints: a header row, then one row per record."""

    media_type = "text/csv"

    def parse(self, stream, media_type=None, parser_context=None):
        try:
            return {"rows": rows_from_csv(stream.read().decode("utf-8-sig"))}
        except UnicodeDecodeError as exc:
            raise ParseError(f"CSV must be UTF-8: {exc}")
