from django.db import models


class IdempotencyRecord(models.Model):
    """Stored response for a POST made with an Idempotency-Key header."""

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="+")
    key = models.CharField(max_length=128)
    scope = models.CharField(max_length=200, help_text="HTTP method and path")
    request_hash = models.CharField(max_length=64)
    response_status = models.PositiveSmallIntegerField(null=True)
    response_body = models.JSONField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["organisation", "key", "scope"], name="uniq_idempotency_key")]
