"""PRICEFLEX API v1. See docs/api.md for the full contract."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.decorators import api_view, parser_classes
from rest_framework.response import Response

from apps.accounts.permissions import channel_ids, require, scope_listings
from apps.catalogue.models import Channel, ChannelListing, Product
from apps.competitors.services import import_observations, pull_price_watch
from apps.costs.services import import_costs
from apps.inventory.services import import_inventory, import_sales
from apps.policies.models import PricingPolicy
from apps.policies.services import save_policy
from apps.publishing import services as publishing
from apps.publishing.models import PriceHistory, PublicationAttempt
from apps.recommendations import services as recommendations
from apps.recommendations.models import PriceRecommendation
from apps.simulation.services import simulate_listing
from engine.money import D, MoneyError

from .context import membership_from
from .errors import ApiError
from .idempotency import idempotent
from .pagination import StandardPagination
from .parsers import CSVParser, DecimalJSONParser

IMPORT_PARSERS = [DecimalJSONParser, CSVParser]
MAX_IMPORT_ROWS = 5000


def _rows(request) -> list[dict]:
    data = request.data
    rows = data.get("rows") if isinstance(data, dict) else None
    if not isinstance(rows, list) or not all(isinstance(r, dict) for r in rows):
        raise ApiError("validation_error", "Body must be an object with a 'rows' list (or a text/csv upload).",
                       http_status=422)
    if not rows:
        raise ApiError("validation_error", "'rows' is empty.", http_status=422)
    if len(rows) > MAX_IMPORT_ROWS:
        raise ApiError("validation_error", f"At most {MAX_IMPORT_ROWS} rows per request.", http_status=422)
    return rows


def _import_response(result) -> Response:
    body = result.to_dict()
    accepted = result.created + result.updated + result.unchanged
    return Response(body, status=status.HTTP_201_CREATED if accepted else status.HTTP_422_UNPROCESSABLE_ENTITY)


def _decimal(data: dict, key: str, *, required: bool = False) -> Decimal | None:
    try:
        value = D(data.get(key), allow_none=not required)
    except MoneyError as exc:
        raise ApiError("validation_error", f"{key}: {exc}", http_status=422)
    return value


def _datetime(data: dict, key: str) -> datetime | None:
    raw = data.get(key)
    if raw in (None, ""):
        return None
    try:
        value = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except ValueError:
        raise ApiError("validation_error", f"{key} must be an ISO-8601 datetime.", http_status=422)
    if value.tzinfo is None:
        raise ApiError("validation_error", f"{key} must include a timezone offset.", http_status=422)
    return value


def _channel(membership, code) -> Channel | None:
    if not code:
        return None
    channel = Channel.objects.filter(organisation=membership.organisation, code=code).first()
    if channel is None:
        raise ApiError("validation_error", f"Unknown channel '{code}'.", http_status=422)
    return channel


def _recommendation(membership, pk: int) -> PriceRecommendation:
    qs = PriceRecommendation.objects.filter(organisation=membership.organisation).select_related(
        "listing", "listing__variant", "listing__variant__product", "listing__channel", "snapshot",
        "policy_version", "policy_version__policy")
    limited = channel_ids(membership)
    if limited is not None:
        qs = qs.filter(listing__channel_id__in=limited)
    return get_object_or_404(qs, pk=pk)


# -- imports -----------------------------------------------------------------------


@api_view(["POST"])
@parser_classes(IMPORT_PARSERS)
@idempotent()
def cost_imports(request, **kwargs):
    membership = membership_from(request)
    return _import_response(import_costs(membership, _rows(request), source=str(request.data.get("source") or "api")))


@api_view(["POST"])
@parser_classes(IMPORT_PARSERS)
@idempotent()
def inventory_imports(request, **kwargs):
    membership = membership_from(request)
    return _import_response(import_inventory(membership, _rows(request), source=str(request.data.get("source") or "api")))


@api_view(["POST"])
@parser_classes(IMPORT_PARSERS)
@idempotent()
def sales_imports(request, **kwargs):
    membership = membership_from(request)
    return _import_response(import_sales(membership, _rows(request), source=str(request.data.get("source") or "api")))


@api_view(["POST"])
@idempotent()
def competitor_observations(request, **kwargs):
    """Push normalised observations (``rows``), or ask PRICEFLEX to pull from Price Watch (``pull``)."""
    membership = membership_from(request)
    if isinstance(request.data, dict) and request.data.get("pull") == "pricewatch":
        from apps.catalogue.models import ProductVariant

        variants = ProductVariant.objects.filter(organisation=membership.organisation, is_active=True).exclude(gtin="")
        skus = request.data.get("skus")
        if skus:
            variants = variants.filter(sku__in=skus)
        result = pull_price_watch(membership, variants=variants)
        return Response(result.to_dict(), status=status.HTTP_502_BAD_GATEWAY if result.batch == "failed"
                        else status.HTTP_201_CREATED)
    return _import_response(import_observations(membership, _rows(request)))


# -- policies ------------------------------------------------------------------------


def _policy_doc(policy: PricingPolicy) -> dict:
    version = policy.current_version
    return {"id": policy.pk, "code": policy.code, "name": policy.name, "description": policy.description,
            "status": policy.status, "automation_authorised": policy.automation_authorised,
            "current_version": None if version is None else {
                "label": version.label, "number": version.number, "config": version.config,
                "config_hash": version.config_hash, "change_note": version.change_note,
                "created_at": version.created_at.isoformat(),
                "created_by": version.created_by.get_username() if version.created_by else None}}


@api_view(["GET", "POST"])
@idempotent()
def policies(request, **kwargs):
    membership = membership_from(request)
    if request.method == "GET":
        require(membership, "view")
        qs = PricingPolicy.objects.filter(organisation=membership.organisation).select_related(
            "current_version", "current_version__policy", "current_version__created_by").order_by("code")
        paginator = StandardPagination()
        page = paginator.paginate_queryset(qs, request)
        return paginator.get_paginated_response([_policy_doc(p) for p in page])
    data = request.data if isinstance(request.data, dict) else {}
    code, name, config = data.get("code"), data.get("name"), data.get("config")
    if not code or not isinstance(code, str) or not isinstance(config, dict):
        raise ApiError("validation_error", "'code' (string) and 'config' (object) are required.", http_status=422)
    existed = PricingPolicy.objects.filter(organisation=membership.organisation, code=code).exists()
    if not existed and not name:
        raise ApiError("validation_error", "'name' is required for a new policy.", http_status=422)
    version = save_policy(membership, code=code, name=str(name or ""), config=config,
                          description=str(data.get("description") or ""), change_note=str(data.get("change_note") or ""))
    return Response(_policy_doc(version.policy), status=status.HTTP_200_OK if existed else status.HTTP_201_CREATED)


# -- pricing runs and recommendations --------------------------------------------------


@api_view(["POST"])
@idempotent()
def pricing_runs(request, **kwargs):
    membership = membership_from(request)
    data = request.data if isinstance(request.data, dict) else {}
    skus = data.get("skus")
    if skus is not None and (not isinstance(skus, list) or not all(isinstance(s, str) for s in skus)):
        raise ApiError("validation_error", "'skus' must be a list of SKU strings.", http_status=422)
    run = recommendations.run_pricing(membership, channel=_channel(membership, data.get("channel")), skus=skus,
                                      trigger="api")
    recs = run.recommendations.select_related("listing__variant", "listing__channel").order_by("id")
    return Response({
        "id": run.pk, "status": run.status, "evaluation_time": run.evaluation_time.isoformat(),
        "algorithm_version": run.algorithm_version, "counts": run.counts,
        "recommendations": [{"id": r.pk, "sku": r.listing.variant.sku, "channel": r.listing.channel.code,
                             "outcome": r.outcome, "status": r.status} for r in recs],
    }, status=status.HTTP_201_CREATED)


@api_view(["GET"])
def recommendation_list(request, **kwargs):
    membership = membership_from(request)
    require(membership, "view")
    qs = PriceRecommendation.objects.filter(organisation=membership.organisation).select_related(
        "listing", "listing__variant", "listing__channel", "snapshot", "policy_version", "policy_version__policy")
    limited = channel_ids(membership)
    if limited is not None:
        qs = qs.filter(listing__channel_id__in=limited)
    p = request.query_params
    if p.get("status"):
        qs = qs.filter(status__in=p["status"].split(","))
    if p.get("outcome"):
        qs = qs.filter(outcome__in=p["outcome"].split(","))
    if p.get("channel"):
        qs = qs.filter(listing__channel__code=p["channel"])
    if p.get("sku"):
        qs = qs.filter(listing__variant__sku=p["sku"])
    if p.get("product"):
        if not p["product"].isdigit():
            raise ApiError("validation_error", "'product' must be a numeric product id.", http_status=422)
        qs = qs.filter(listing__variant__product_id=int(p["product"]))
    if p.get("policy"):
        qs = qs.filter(policy_version__policy__code=p["policy"])
    if p.get("run"):
        if not p["run"].isdigit():
            raise ApiError("validation_error", "'run' must be a numeric run id.", http_status=422)
        qs = qs.filter(run_id=int(p["run"]))
    if p.get("has_warnings") in ("true", "false"):
        qs = qs.filter(has_warnings=p["has_warnings"] == "true")
    paginator = StandardPagination()
    page = paginator.paginate_queryset(qs.order_by("-evaluated_at", "-id"), request)
    return paginator.get_paginated_response([recommendations.response_document(r) for r in page])


@api_view(["GET"])
def recommendation_detail(request, pk: int, **kwargs):
    membership = membership_from(request)
    require(membership, "view")
    rec = _recommendation(membership, pk)
    doc = recommendations.response_document(rec, detail=True)
    if request.query_params.get("verify") == "true" and rec.kind == "evaluation":
        doc["reproducibility"] = recommendations.replay(rec)
    return Response(doc)


@api_view(["POST"])
@idempotent()
def recommendation_approve(request, pk: int, **kwargs):
    membership = membership_from(request)
    rec = _recommendation(membership, pk)
    data = request.data if isinstance(request.data, dict) else {}
    expected = data.get("expected_status")
    if expected and expected != rec.status:
        raise ApiError("conflict", f"The recommendation is '{rec.status}', not '{expected}'.", http_status=409)
    rec = recommendations.approve(membership, rec, approved_price=_decimal(data, "approved_price"),
                                  comment=str(data.get("comment") or ""), scheduled_for=_datetime(data, "scheduled_for"))
    return Response(recommendations.response_document(_recommendation(membership, rec.pk), detail=True))


@api_view(["POST"])
@idempotent()
def recommendation_reject(request, pk: int, **kwargs):
    membership = membership_from(request)
    rec = _recommendation(membership, pk)
    data = request.data if isinstance(request.data, dict) else {}
    rec = recommendations.reject(membership, rec, comment=str(data.get("comment") or ""))
    return Response(recommendations.response_document(_recommendation(membership, rec.pk), detail=True))


# -- publications ------------------------------------------------------------------------


def _attempt_doc(a: PublicationAttempt) -> dict:
    listing = a.listing
    return {
        "id": a.pk, "recommendation_id": a.recommendation_id, "kind": a.kind, "attempt_number": a.attempt_number,
        "sku": listing.variant.sku, "channel": listing.channel.code, "status": a.status, "resolution": a.resolution,
        "price": str(a.price),
        "expected_previous_price": None if a.expected_previous_price is None else str(a.expected_previous_price),
        "expected_version": a.expected_version, "storefront_idempotency_key": a.idempotency_key,
        "external_response": a.external_response, "error": a.error,
        "recommendation_status": a.recommendation.status,
        "confirmed_published_price": None if listing.confirmed_price is None else str(listing.confirmed_price),
        "observed_prices": [{"price": None if o.price is None else str(o.price), "source": o.source,
                             "matches_expected": o.matches_expected, "observed_at": o.observed_at.isoformat()}
                            for o in a.observations.order_by("observed_at", "id")],
        "created_at": a.created_at.isoformat(),
        "completed_at": a.completed_at.isoformat() if a.completed_at else None,
        "reconciled_at": a.reconciled_at.isoformat() if a.reconciled_at else None,
    }


def _attempt(membership, pk: int) -> PublicationAttempt:
    qs = PublicationAttempt.objects.filter(organisation=membership.organisation).select_related(
        "listing", "listing__variant", "listing__channel", "recommendation")
    limited = channel_ids(membership)
    if limited is not None:
        qs = qs.filter(listing__channel_id__in=limited)
    return get_object_or_404(qs, pk=pk)


@api_view(["POST"])
@idempotent(required=True)
def publications(request, **kwargs):
    membership = membership_from(request)
    data = request.data if isinstance(request.data, dict) else {}
    rec_id = data.get("recommendation_id")
    if isinstance(rec_id, bool) or not isinstance(rec_id, int):
        raise ApiError("validation_error", "'recommendation_id' (integer) is required.", http_status=422)
    rec = _recommendation(membership, rec_id)
    expected = data.get("expected_price_version")
    if expected is not None and expected != rec.listing.price_version:
        raise ApiError("conflict", "The listing's price version has changed.",
                       {"expected": expected, "current": rec.listing.price_version}, http_status=409)
    attempt = publishing.publish(membership, rec)
    return Response(_attempt_doc(_attempt(membership, attempt.pk)), status=status.HTTP_201_CREATED)


@api_view(["GET"])
def publication_detail(request, pk: int, **kwargs):
    membership = membership_from(request)
    require(membership, "view")
    return Response(_attempt_doc(_attempt(membership, pk)))


# -- simulations ----------------------------------------------------------------------------


@api_view(["POST"])
@idempotent()
def simulations(request, **kwargs):
    membership = membership_from(request)
    data = request.data if isinstance(request.data, dict) else {}
    channel = _channel(membership, data.get("channel"))
    if channel is None or not data.get("sku"):
        raise ApiError("validation_error", "'sku' and 'channel' are required.", http_status=422)
    listing = scope_listings(membership, recommendations.listing_queryset()).filter(
        variant__sku=data["sku"], channel=channel).first()
    if listing is None:
        raise ApiError("not_found", "No such listing.", http_status=404)
    days = data.get("days", 28)
    if isinstance(days, bool) or not isinstance(days, int):
        raise ApiError("validation_error", "'days' must be an integer.", http_status=422)
    on_hand = data.get("initial_on_hand")
    if on_hand is not None and (isinstance(on_hand, bool) or not isinstance(on_hand, int) or on_hand < 0):
        raise ApiError("validation_error", "'initial_on_hand' must be a non-negative integer.", http_status=422)
    seed = data.get("seed", 20240101)
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ApiError("validation_error", "'seed' must be an integer.", http_status=422)
    run = simulate_listing(
        membership, listing, days=days,
        elasticity=_decimal(data, "elasticity") if data.get("elasticity") is not None else Decimal("-1.5"),
        base_units_per_day=_decimal(data, "base_units_per_day"),
        competitor_sensitivity=_decimal(data, "competitor_sensitivity") or Decimal("0"),
        initial_on_hand=on_hand, seed=seed)
    return Response({"id": run.pk, "label": run.label, "config": run.config, "results": run.results},
                    status=status.HTTP_201_CREATED)


# -- price history ------------------------------------------------------------------------------


@api_view(["GET"])
def product_price_history(request, pk: int, **kwargs):
    membership = membership_from(request)
    require(membership, "view")
    product = get_object_or_404(Product, organisation=membership.organisation, pk=pk)
    listings = scope_listings(membership, ChannelListing.objects.filter(variant__product=product))
    p = request.query_params
    if p.get("channel"):
        listings = listings.filter(channel__code=p["channel"])
    if p.get("sku"):
        listings = listings.filter(variant__sku=p["sku"])
    qs = PriceHistory.objects.filter(listing__in=listings).select_related(
        "listing__variant", "listing__channel", "actor").order_by("-effective_at", "-id")
    paginator = StandardPagination()
    page = paginator.paginate_queryset(qs, request)
    return paginator.get_paginated_response([{
        "id": h.pk, "product_id": product.pk, "sku": h.listing.variant.sku, "channel": h.listing.channel.code,
        "currency": h.listing.channel.currency, "confirmed_published_price": str(h.price),
        "previous_price": None if h.previous_price is None else str(h.previous_price),
        "effective_at": h.effective_at.isoformat(), "kind": h.kind, "recommendation_id": h.recommendation_id,
        "publication_id": h.attempt_id, "actor": h.actor.get_username() if h.actor else None, "note": h.note,
    } for h in page])

