"""Demonstration data and the ten-step demonstration.

Everything created here is FICTIONAL. Sales history is synthetic and flagged
``is_synthetic``; competitor offers come from the simulated Price Watch; the
storefront is the simulated storefront. No value printed by the demonstration
is hard-coded: each one is read back from what the services actually did.
"""

from __future__ import annotations

import csv
import json
import math
import zlib
from datetime import datetime, timedelta
from decimal import Decimal

import numpy as np
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import connection, transaction
from django.utils import timezone

from apps.audit.models import AuditEvent
from apps.audit.services import record
from apps.catalogue.models import Channel, ChannelListing, Location, Product, ProductVariant
from apps.competitors.models import CompetitorObservation
from apps.costs.models import TaxRule
from apps.costs.services import import_costs
from apps.inventory.models import SalesObservation
from apps.policies.models import PriceCommitment, PricingPolicy, Promotion
from apps.policies.services import save_policy
from apps.publishing.mock_storefront import MockStorefront
from apps.publishing.models import (
    MockStorefrontFault,
    MockStorefrontPrice,
    MockStorefrontQuote,
    MockStorefrontRequest,
    PriceHistory,
)

from .models import Membership, Organisation

DEMO_SLUG = "northlight"
DEMO_PASSWORD_ENV = "PRICEFLEX_DEMO_PASSWORD"


def fixture_path(name: str):
    return settings.PRICEFLEX_DEMO_FIXTURES / name


def load_json(name: str) -> dict:
    return json.loads(fixture_path(name).read_text())


def load_csv(name: str) -> list[dict]:
    with fixture_path(name).open(newline="") as handle:
        return list(csv.DictReader(handle))


def resolve_relative(rows: list[dict], now: datetime) -> list[dict]:
    """Turn the fixtures' relative time columns into absolute timestamps."""
    out = []
    for row in rows:
        row = dict(row)
        if row.get("effective_days_ago") not in (None, ""):
            row["effective_from"] = (now - timedelta(days=int(row.pop("effective_days_ago")))).isoformat()
        if row.get("effective_hours_ago") not in (None, ""):
            row["effective_from"] = (now - timedelta(hours=int(row.pop("effective_hours_ago")))).isoformat()
        if row.get("as_of_hours_ago") not in (None, ""):
            row["as_of"] = (now - timedelta(hours=int(row.pop("as_of_hours_ago")))).isoformat()
        if "oldest_stock_received_days_ago" in row:
            days = row.pop("oldest_stock_received_days_ago")
            row["oldest_stock_received_at"] = (now - timedelta(days=int(days))).isoformat() if days else ""
        if "clearance_in_days" in row:
            days = row.pop("clearance_in_days")
            row["clearance_date"] = (now.date() + timedelta(days=int(days))).isoformat() if days else ""
        out.append(row)
    return out


def member(username: str) -> Membership:
    return Membership.objects.select_related("organisation", "user").get(
        user__username=username, organisation__slug=DEMO_SLUG)


def reset_demo() -> None:
    """Remove the demo organisation. Refuses if any other organisation has audit history."""
    org = Organisation.objects.filter(slug=DEMO_SLUG).first()
    if AuditEvent.objects.exclude(organisation=org).exists():
        raise RuntimeError("Refusing to reset: audit events exist for other organisations. The audit table is "
                           "append-only and is only cleared when the demo organisation is its sole content.")
    codes = [c["code"] for c in load_json("catalogue.json")["channels"]]
    with transaction.atomic():
        with connection.cursor() as cursor:
            cursor.execute("TRUNCATE TABLE audit_auditevent")
        for model in (MockStorefrontPrice, MockStorefrontRequest, MockStorefrontFault, MockStorefrontQuote):
            model.objects.filter(channel_code__in=codes).delete()
        if org is not None:
            from apps.recommendations.models import PriceRecommendation
            from apps.simulation.models import Experiment

            usernames = [u["username"] for u in load_json("catalogue.json")["users"]]
            # Rows that protect what they reference go first.
            Experiment.objects.filter(organisation=org).delete()
            PriceRecommendation.objects.filter(organisation=org).delete()
            org.delete()
            get_user_model().objects.filter(username__in=usernames).delete()


def _synthetic_sales(org, listing, spec: dict, now: datetime) -> list[SalesObservation]:
    rate = float(spec.get("daily_sales") or 0)
    if rate <= 0:
        return []
    rng = np.random.default_rng(zlib.crc32(f"{listing.variant.sku}|{listing.channel.code}".encode()))
    experiment = spec.get("price_experiment")
    days = 84 if experiment else 60
    stockout_days = int(spec.get("stockout_last_days") or 0)
    base_price = Decimal(spec["price"])
    weekday = (0.9, 0.9, 0.95, 1.0, 1.1, 1.25, 1.15)
    rows = []
    for back in range(days, 0, -1):
        day = now.date() - timedelta(days=back)
        price = base_price
        lam = rate
        if experiment:
            for start_back, level in experiment["schedule"]:
                if back <= start_back:
                    price = Decimal(level)
            lam = rate * (float(price) / float(base_price)) ** float(experiment["elasticity"])
        if spec.get("previous_price") and back * 24 > spec["previous_price"]["changed_hours_ago"]:
            price = Decimal(spec["previous_price"]["price"])
        out = back <= stockout_days
        units = 0 if out else int(rng.poisson(lam * weekday[day.weekday()]))
        rows.append(SalesObservation(
            organisation=org, variant=listing.variant, channel=listing.channel, period_start=day, period_end=day,
            units_sold=units, unit_price=price if units else None, exposed_price=price,
            available_units=0 if out else None, stockout=out, traffic=None,
            returns_units=int(rng.binomial(units, 0.03)) if units else 0, is_synthetic=True,
            source="Demo seed (synthetic sales history)"))
    return rows


def _competitor_history(org, variants: dict, now: datetime) -> int:
    """Older observations so the simulator has a competitor timeline to replay."""
    scenarios = load_json("pricewatch_scenarios.json")
    rows = []
    for v in scenarios["variants"]:
        if not v.get("history") or v["sku_hint"] not in variants:
            continue
        for index, offer in enumerate(v["offers"], start=1):
            if offer.get("item") is None or offer.get("delivery") is None or offer.get("availability", "in_stock") != "in_stock":
                continue
            listing_id = v["variant_id"] * 100 + index
            supplier = scenarios["suppliers"][offer["supplier"]]["name"]
            for back in range(34, 2, -2):
                wiggle = Decimal(str(round(1 + 0.012 * math.sin(back * 0.9 + index), 4)))
                item = (Decimal(offer["item"]) * wiggle).quantize(Decimal("0.01"))
                delivery = Decimal(offer["delivery"])
                rows.append(CompetitorObservation(
                    organisation=org, variant=variants[v["sku_hint"]], source="pricewatch",
                    external_observation_id=f"hist-{listing_id}-{back}", external_listing_id=str(listing_id),
                    supplier=supplier, supplier_slug=offer["supplier"], title=v["name"], variant_match="exact",
                    condition="new", item_price=item, delivery_charge=delivery, mandatory_charges=Decimal("0"),
                    charges_complete=True, comparable_total=item + delivery, currency="GBP", availability="in_stock",
                    observed_at=now - timedelta(days=back, hours=3), match_confidence=Decimal("0.99"),
                    match_status="confirmed", match_evidence={"note": "Demo seed history"},
                    provenance={"source": "pricewatch", "note": "Simulated historical observation (demo seed)"}))
    CompetitorObservation.objects.bulk_create(rows)
    return len(rows)


@transaction.atomic
def seed_demo(*, password: str, now: datetime | None = None) -> dict:
    """Create the demo organisation in its starting state (before the demonstration runs)."""
    now = now or timezone.now()
    data = load_json("catalogue.json")
    org = Organisation.objects.create(**data["organisation"])
    channels = {c["code"]: Channel.objects.create(organisation=org, **c) for c in data["channels"]}
    for loc in data["locations"]:
        location = Location.objects.create(organisation=org, code=loc["code"], name=loc["name"], region=loc["region"])
        location.channels.set([channels[c] for c in loc["channels"]])
    for rule in data["tax_rules"]:
        TaxRule.objects.create(organisation=org, effective_from=now - timedelta(days=730), **rule)

    User = get_user_model()
    for u in data["users"]:
        user = User.objects.create_user(username=u["username"], password=None if u.get("service") else password,
                                        is_staff=bool(u.get("superuser")), is_superuser=bool(u.get("superuser")))
        m = Membership.objects.create(user=user, organisation=org, roles=u["roles"])
        m.channels.set([channels[c] for c in u.get("channels", [])])

    editor, admin, analyst = member("pol.editor"), member("ada.admin"), member("ana.analyst")
    policies = {}
    for p in data["policies"]:
        save_policy(editor, code=p["code"], name=p["name"], description=p["description"], config=p["config"],
                    change_note="Initial demo policy")
        policy = PricingPolicy.objects.get(organisation=org, code=p["code"])
        if p.get("automation_authorised"):
            from apps.policies.services import authorise_automation
            authorise_automation(admin, policy, True)
        policies[p["code"]] = policy

    variants, listings, sales = {}, [], []
    for p in data["products"]:
        product = Product.objects.create(organisation=org, code=p["code"], name=p["name"], brand=p["brand"],
                                         category=p["category"])
        for v in p["variants"]:
            variant = ProductVariant.objects.create(
                organisation=org, product=product, sku=v["sku"], name=v["name"], gtin=v["gtin"], mpn=v["mpn"],
                attributes=v.get("attributes", {}))
            variants[v["sku"]] = variant
            for spec in v["listings"]:
                channel = channels[spec["channel"]]
                price = Decimal(spec["price"])
                start = now - timedelta(days=120)
                listing = ChannelListing.objects.create(
                    variant=variant, channel=channel, policy=policies[spec["policy"]],
                    standard_retail_price=Decimal(spec["standard_retail_price"]), confirmed_price=price,
                    confirmed_at=start, price_version=1)
                first = price
                if spec.get("price_experiment"):
                    first = Decimal(spec["price_experiment"]["schedule"][0][1])
                if spec.get("previous_price"):
                    first = Decimal(spec["previous_price"]["price"])
                PriceHistory.objects.create(listing=listing, price=first, effective_at=start, kind="initial",
                                            note="Demo seed: opening price")
                previous = first
                if spec.get("price_experiment"):
                    for back, level in spec["price_experiment"]["schedule"][1:]:
                        when = now - timedelta(days=back)
                        PriceHistory.objects.create(listing=listing, price=Decimal(level), previous_price=previous,
                                                    effective_at=when, kind="publish", note="Demo seed: earlier price change")
                        previous, listing.confirmed_at = Decimal(level), when
                        listing.price_version += 1
                if spec.get("previous_price"):
                    when = now - timedelta(hours=spec["previous_price"]["changed_hours_ago"])
                    PriceHistory.objects.create(listing=listing, price=price, previous_price=previous, effective_at=when,
                                                kind="publish", note="Demo seed: recent price change")
                    listing.confirmed_at = when
                    listing.price_version += 1
                listing.save()
                MockStorefront.seed_price(channel.code, variant.sku, price)
                if spec.get("commitment"):
                    c = spec["commitment"]
                    PriceCommitment.objects.create(organisation=org, listing=listing, kind=c["kind"],
                                                   value=Decimal(c["value"]), reference=c["reference"],
                                                   created_by=admin.user)
                if spec.get("promotion"):
                    pr = spec["promotion"]
                    promo = Promotion.objects.create(
                        organisation=org, code=pr["code"], name=pr["name"], status=pr["status"], kind=pr["kind"],
                        value=Decimal(pr["value"]), funding=pr["funding"],
                        supplier_funding_per_unit=Decimal(pr["supplier_funding_per_unit"]),
                        starts_at=now - timedelta(hours=pr["starts_hours_ago"]),
                        ends_at=now + timedelta(days=pr["ends_in_days"]), eligibility=pr["eligibility"],
                        approved_by=member("apo.approver").user, approved_at=now - timedelta(days=1))
                    promo.listings.add(listing)
                listings.append(listing)
                sales.extend(_synthetic_sales(org, listing, spec, now))
    SalesObservation.objects.bulk_create(sales)
    costs = import_costs(analyst, resolve_relative(load_csv("costs_baseline.csv"), now), source="demo baseline")
    history = _competitor_history(org, variants, now)
    MockStorefrontQuote.objects.create(channel_code="web", sku="ORB-MOUSE", reference="QUOTE-DEMO-1",
                                       locked_price=Decimal("27.99"), expires_at=now + timedelta(days=7))
    record(org, "system", "demo.seeded", org, "Demo organisation seeded with fictional data")
    return {"organisation": org.slug, "products": Product.objects.filter(organisation=org).count(),
            "variants": len(variants), "listings": len(listings), "sales_rows": len(sales),
            "cost_versions": costs.created, "cost_rows_rejected": len(costs.rejected),
            "competitor_history_rows": history}
