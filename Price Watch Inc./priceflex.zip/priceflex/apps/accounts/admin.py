from django.contrib import admin

from .models import Membership, Organisation


@admin.register(Organisation)
class OrganisationAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "base_currency")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Membership)
class MembershipAdmin(admin.ModelAdmin):
    list_display = ("user", "organisation", "roles", "is_active")
    list_filter = ("organisation", "is_active")
    filter_horizontal = ("channels",)
