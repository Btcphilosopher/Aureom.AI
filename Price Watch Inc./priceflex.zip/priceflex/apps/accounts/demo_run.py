"""The ten-step demonstration. Prints what the services actually did."""

from __future__ import annotations

import zlib
from datetime import timedelta
from decimal import Decimal

import numpy as np
from django.utils import timezone

from adapters.pricewatch_simulated import SimulatedPriceWatch
from apps.audit.models import Alert, AuditEvent
from apps.catalogue.models import ChannelListing
from apps.competitors.models import CompetitorObservation
from apps.competitors.services import import_observations, pull_price_watch
from apps.costs.services import import_costs
from apps.inventory.services import import_inventory, import_sales
from apps.publishing import services as publishing
from apps.publishing.mock_storefront import MockStorefront
from apps.publishing.models import MockStorefrontPrice
from apps.recommendations import services as recs
from apps.recommendations.models import PriceRecommendation
from apps.recommendations.workflow import WorkflowError
from apps.simulation.reports import projection_vs_realised, realised_summary
from apps.simulation.services import fit_demand_model, simulate_listing

from .demo import DEMO_SLUG, fixture_path, load_csv, member, resolve_relative
from .permissions import PermissionDenied

SCENARIOS = [
    ("LUM-X5-128", "web", "A profitable product eligible for a small price reduction"),
    ("NIM-B14-16", "web", "A cost increase requiring a higher price"),
    ("NIM-B14-8", "web", "A competitor below the retailer's floor"),
    ("ARC-BUDS", "web", "Excess stock approaching a clearance date"),
    ("PULSE-SPK", "web", "A stockout"),
    ("VOLT-PB20", "web", "Missing cost data"),
    ("LUM-X5-256", "web", "An incompatible competitor variant"),
    ("HALO-CAM", "web", "A stale feed"),
    ("FLUX-CBL", "web", "A conflicting floor and ceiling"),
    ("ORB-MOUSE", "web", "A failed publication followed by reconciliation (see step 7)"),
]


class Printer:
    def __init__(self, write):
        self.write = write

    def step(self, number, title):
        self.write("")
        self.write("=" * 100)
        self.write(f"STEP {number}. {title}")
        self.write("=" * 100)

    def line(self, text=""):
        self.write(text)

    def table(self, headers, rows):
        rows = [[("" if c is None else str(c)) for c in r] for r in rows]
        widths = [max(len(str(h)), *(len(r[i]) for r in rows)) if rows else len(str(h)) for i, h in enumerate(headers)]
        self.write("  " + "  ".join(str(h).ljust(w) for h, w in zip(headers, widths)))
        self.write("  " + "  ".join("-" * w for w in widths))
        for r in rows:
            self.write("  " + "  ".join(c.ljust(w) for c, w in zip(r, widths)))


def _listing(sku, channel="web"):
    return recs.listing_queryset().get(variant__sku=sku, channel__code=channel, channel__organisation__slug=DEMO_SLUG)


def _rec(run, sku, channel="web"):
    return PriceRecommendation.objects.select_related(
        "listing", "listing__variant", "listing__variant__product", "listing__channel", "snapshot",
        "policy_version", "policy_version__policy").get(run=run, listing__variant__sku=sku, listing__channel__code=channel)


def run_demonstration(write) -> dict:
    p = Printer(write)
    now = timezone.now()
    analyst, approver, publisher, admin = (member(u) for u in ("ana.analyst", "apo.approver", "pub.publisher", "ada.admin"))
    org = analyst.organisation
    summary: dict = {}
    p.line("PRICEFLEX demonstration - all data is fictional; the storefront, Price Watch feed and sales are simulated.")

    # ------------------------------------------------------------------ 1
    p.step(1, "Import costs and inventory")
    costs = import_costs(analyst, resolve_relative(load_csv("costs_update.csv"), now), source="demo cost update")
    p.line(f"Cost import {costs.batch}: {costs.created} cost version(s) created, {len(costs.rejected)} row(s) rejected.")
    for r in costs.rejected:
        p.line(f"  rejected row {r['row']} ({r['sku'] or 'no sku'}): {'; '.join(r['errors'])}")
    inv = import_inventory(analyst, resolve_relative(load_csv("inventory.csv"), now), source="demo WMS export")
    p.line(f"Inventory import {inv.batch}: {inv.created} position(s) created, {inv.updated} updated, "
           f"{len(inv.rejected)} row(s) rejected.")
    for r in inv.rejected:
        p.line(f"  rejected row {r['row']} ({r['sku']}): {'; '.join(r['errors'])}")
    summary["cost_versions_created"], summary["cost_rows_rejected"] = costs.created, len(costs.rejected)

    # ------------------------------------------------------------------ 2
    p.step(2, "Retrieve Price Watch observations (simulated Price Watch, real adapter)")
    outage = pull_price_watch(analyst, client=SimulatedPriceWatch(fixture_path("pricewatch_scenarios.json"), now=now, outage=True), now=now)
    retained = CompetitorObservation.objects.filter(organisation=org, retained_after_feed_failure=True).count()
    zero = CompetitorObservation.objects.filter(organisation=org, item_price=0).count()
    p.line(f"2a. Simulated outage: {outage.created + outage.updated} observations imported; {retained} earlier "
           f"observations retained with their original timestamps; observations with a zero price: {zero}.")
    pulled = pull_price_watch(analyst, now=now)
    p.line(f"2b. Feed recovered: {pulled.created} new observation(s), {pulled.updated} refreshed, "
           f"{len(pulled.rejected)} Price Watch entr(ies) carried no usable price:")
    for r in pulled.rejected:
        p.line(f"      {r['sku']}: {r['errors'][0]}")
    pushed = import_observations(analyst, [{
        "sku": "ECHO-HP", "external_observation_id": "manual-echo-refurb-1", "supplier": "TechHaven",
        "title": "Echo over-ear headphones (refurbished)", "variant_match": "exact", "condition": "refurbished",
        "item_price": "89.00", "delivery_charge": "4.99", "mandatory_charges": "0.00", "charges_complete": True,
        "currency": "GBP", "availability": "in_stock", "observed_at": (now - timedelta(hours=3)).isoformat(),
        "match_confidence": "0.95", "match_status": "confirmed", "external_listing_id": "manual-echo-refurb",
        "provenance": {"source": "manual", "note": "Demo: refurbished listing pushed through the API import path"},
    }], source="manual")
    p.line(f"2c. Pushed {pushed.created} refurbished listing through the normalised import path (to show it is excluded).")
    model = fit_demand_model(analyst, _listing("TERRA-SSD"), at=now)
    e = model.estimate
    p.line(f"2d. Optional demand estimate for TERRA-SSD: {model.status} "
           f"(elasticity {e['elasticity']}, 95% interval {e['ci_low']} to {e['ci_high']}, "
           f"{e['n_days_used']} in-stock days, holdout improvement {e['holdout_improvement']}).")
    for reason in e["reasons"]:
        p.line(f"      - {reason}")
    summary["observations_imported"] = pulled.created + pulled.updated

    # ------------------------------------------------------------------ 3
    p.step(3, "Generate recommendations")
    run = recs.run_pricing(analyst, trigger="demo", at=now)
    p.line(f"Pricing run {run.pk}: {run.counts}")
    rows = []
    for r in run.recommendations.select_related("listing__variant", "listing__channel").order_by("listing__variant__sku", "listing__channel__code"):
        rows.append([r.listing.variant.sku, r.listing.channel.code, r.current_price, r.recommended_price or "-",
                     r.outcome, r.selected_strategy or "-", r.status, ", ".join(r.constraints_applied) or "-"])
    p.table(["SKU", "channel", "current", "recommended", "outcome", "strategy", "status", "constraints applied"], rows)
    summary["run_counts"] = run.counts

    # ------------------------------------------------------------------ 4
    p.step(4, "Inspect explanations")
    for sku, channel, title in SCENARIOS:
        r = _rec(run, sku, channel)
        p.line("")
        p.line(f"--- {title}: {sku} on {channel} ---")
        p.line(f"  outcome={r.outcome}  status={r.status}  current={r.current_price}  recommended={r.recommended_price}"
               f"  snapshot={r.snapshot.public_id}  policy={r.policy_version.label}  algorithm={r.algorithm_version}")
        for reason in r.reasons:
            p.line(f"  reason:  {reason}")
        for w in r.warnings:
            p.line(f"  warning: {w}")
        comp = r.result.get("comparables") or {}
        for ex in comp.get("excluded", []):
            p.line(f"  excluded competitor offer: {ex['supplier']} ({ex['observed_value']}) - {'; '.join(ex['reason_text'])}")
    check = recs.replay(_rec(run, "LUM-X5-128"))
    p.line("")
    p.line(f"Reproducibility check for LUM-X5-128: replaying the stored input snapshot gives the same decision = "
           f"{check['reproducible']} (snapshot hash matches = {check['snapshot_hash_matches']}).")
    summary["reproducible"] = check["reproducible"]

    # ------------------------------------------------------------------ 5
    p.step(5, "Simulate alternatives (isolated workspace; results are SIMULATED)")
    for sku, elasticity in (("LUM-X5-128", Decimal("-2.0")), ("ARC-BUDS", Decimal("-1.6"))):
        sim = simulate_listing(analyst, _listing(sku), days=28, elasticity=elasticity,
                               competitor_sensitivity=Decimal("1.0"), now=now)
        res = sim.results
        p.line("")
        p.line(f"{sku}: {res['label']}")
        p.table(["arm", "revenue (net)", "units", "contribution", "margin", "end stock", "stockout days",
                 "price changes", "volatility", "breach days", "rejected"],
                [[a["label"], a["revenue_net"], a["units_sold"], a["contribution"], a["contribution_margin"],
                  a["ending_inventory"], a["stockout_days"], a["price_changes"], a["price_volatility"],
                  a["constraint_breach_days"], a["rejected_recommendations"]] for a in res["arms"]])
        for s in res["skipped_arms"]:
            p.line(f"  not run - {s['key']}: {s['reason']}")
        p.line(f"  key assumption: {res['assumptions'][-6]}")

    # ------------------------------------------------------------------ 6
    p.step(6, "Approve selected changes")
    try:
        recs.approve(analyst, _rec(run, "LUM-X5-128"))
    except PermissionDenied as exc:
        p.line(f"An analyst tries to approve: refused - {exc}")
    approved = []
    for sku, channel in (("LUM-X5-128", "web"), ("NIM-B14-16", "web"), ("NIM-B14-16", "trade"), ("NIM-B14-8", "web"),
                         ("ARC-BUDS", "web"), ("ORB-MOUSE", "web"), ("PULSE-BAR", "web"), ("ORB-KEYS", "web"),
                         ("ECHO-HP", "web")):
        r = _rec(run, sku, channel)
        if r.status != "awaiting_approval":
            p.line(f"  {sku}/{channel}: nothing to approve (outcome {r.outcome}, status {r.status})")
            continue
        r = recs.approve(approver, r, comment="Reviewed in the demonstration")
        approved.append((sku, channel))
        p.line(f"  approved {sku}/{channel}: {r.current_price} -> {r.approved_price}")
    r = _rec(run, "VOLT-CHG")
    if r.status == "awaiting_approval":
        try:
            recs.approve(approver, r, approved_price=Decimal("9.99"), comment="Try to undercut everyone")
        except WorkflowError as exc:
            names = ", ".join(v["name"] for v in exc.details.get("violations", []))
            p.line(f"  override of VOLT-CHG to 9.99 refused: {exc.message} [{names}]")
        r = recs.approve(approver, r, comment="Reviewed in the demonstration")
        approved.append(("VOLT-CHG", "web"))
        p.line(f"  approved VOLT-CHG/web at the recommended {r.approved_price}")
    r = _rec(run, "FLUX-CBL")
    try:
        recs.approve(approver, r, approved_price=Decimal("6.99"), comment="Keep the contract price")
    except WorkflowError as exc:
        detail = "; ".join(i["message"] for i in exc.details.get("blocking_issues", []))
        p.line(f"  FLUX-CBL conflict cannot be approved away: {exc.message} {detail}")
    r = _rec(run, "HALO-RING")
    if r.status == "awaiting_approval":
        recs.reject(approver, r, comment="Hold for the new-season bundle launch")
        p.line("  rejected HALO-RING/web markdown: 'Hold for the new-season bundle launch'")
    r = _rec(run, "TERRA-SD")
    decision = r.decisions.first()
    p.line(f"  TERRA-SD/web: status {r.status}" + (f" - {decision.comment}" if decision else ""))
    r = _rec(run, "TERRA-SSD")
    if r.status == "awaiting_approval":
        r = recs.approve(admin, r, comment="Schedule for the evening", scheduled_for=now + timedelta(hours=2))
        p.line(f"  TERRA-SSD/web scheduled: approved {r.approved_price}, scheduled price {r.scheduled_price} "
               f"for {r.scheduled_for:%Y-%m-%d %H:%M} UTC (status {r.status})")
    summary["approved"] = len(approved)

    # ------------------------------------------------------------------ 7
    p.step(7, "Publish to the mock storefront")
    publishing.set_pause(publisher, True, "Demo: storefront maintenance window")
    try:
        publishing.publish(publisher, _rec(run, "LUM-X5-128"))
    except WorkflowError as exc:
        p.line(f"Pause switch on: publication refused - {exc.message}")
    publishing.set_pause(publisher, False)
    p.line("Pause switch off: publication resumed.")
    try:
        publishing.publish(approver, _rec(run, "LUM-X5-128"))
    except PermissionDenied as exc:
        p.line(f"An approver tries to publish: refused - {exc}")

    MockStorefront.inject_fault("web", "ORB-MOUSE", "timeout_after_apply")
    MockStorefront.inject_fault("web", "PULSE-BAR", "timeout_before_apply")
    rows, uncertain = [], []
    targets = approved + ([("TERRA-SD", "web")] if _rec(run, "TERRA-SD").status == "approved" else [])
    for sku, channel in targets:
        attempt = publishing.publish(publisher, _rec(run, sku, channel))
        rows.append([sku, channel, attempt.price, attempt.status, attempt.resolution or "-", attempt.error or "-"])
        if attempt.status == "uncertain":
            uncertain.append((sku, channel, attempt))
    p.table(["SKU", "channel", "price sent", "attempt status", "resolution", "detail"], rows)
    for sku, channel, attempt in uncertain:
        resolved = publishing.reconcile(publisher, attempt)
        p.line(f"Reconciliation of {sku}/{channel}: storefront read back -> attempt {resolved.status} "
               f"({resolved.resolution}); recommendation is now '{_rec(run, sku, channel).status}'.")
        if resolved.status == "failed":
            retry = publishing.publish(publisher, _rec(run, sku, channel))
            p.line(f"  retried {sku}/{channel} with the same storefront idempotency key "
                   f"({retry.idempotency_key}): attempt {retry.attempt_number} is {retry.status} ({retry.resolution}).")
    quote = MockStorefront.price_for_order("web", "ORB-MOUSE", "QUOTE-DEMO-1")
    p.line(f"Accepted quote QUOTE-DEMO-1 for ORB-MOUSE is still honoured at {quote}; publication did not alter it.")
    due = publishing.publish_due(now=timezone.now() + timedelta(hours=3))
    p.line(f"Scheduler (simulated 3 hours later): {due} scheduled price(s) published; TERRA-SSD is now "
           f"'{_rec(run, 'TERRA-SSD').status}'.")
    try:
        publishing.request_rollback(publisher, _listing("NIM-B14-16"), reason="Customer complaints about the increase")
    except WorkflowError as exc:
        names = ", ".join(v["name"] for v in exc.details.get("violations", []))
        p.line(f"Rollback of NIM-B14-16 refused under current conditions: {exc.message} [{names}]")
    rollback = publishing.request_rollback(publisher, _listing("ECHO-HP"), reason="Demo: change published a day early")
    p.line(f"Rollback of ECHO-HP: attempt {rollback.status} ({rollback.resolution}); price restored to {rollback.price}.")
    summary["uncertain_reconciled"] = len(uncertain)

    # ------------------------------------------------------------------ 8
    p.step(8, "Verify the observed prices")
    result = publishing.monitor(org)
    p.line(f"Storefront monitor read back {result['checked']} listing(s); mismatches: {result['mismatched']}.")
    rows = []
    for sku, channel in targets + [("TERRA-SSD", "web")]:
        listing = ChannelListing.objects.get(variant__sku=sku, channel__code=channel, channel__organisation=org)
        shown = MockStorefrontPrice.objects.get(channel_code=channel, sku=sku)
        rows.append([sku, channel, listing.confirmed_price, shown.displayed_price, listing.price_version,
                     "match" if listing.confirmed_price == shown.displayed_price else "MISMATCH"])
    p.table(["SKU", "channel", "confirmed published", "storefront displays", "price version", "check"], rows)
    summary["monitor"] = result

    # ------------------------------------------------------------------ 9
    p.step(9, "Record subsequent synthetic sales (flagged is_synthetic)")
    sales_rows = []
    today = timezone.now().date()
    for sku, channel in targets + [("TERRA-SSD", "web")]:
        listing = ChannelListing.objects.get(variant__sku=sku, channel__code=channel, channel__organisation=org)
        rng = np.random.default_rng(zlib.crc32(f"after|{sku}|{channel}".encode()))
        units = int(rng.poisson(4)) + 1
        price = listing.confirmed_price
        if sku == "ORB-MOUSE":  # one of the orders used the accepted quote at its locked price
            price = ((listing.confirmed_price * (units - 1) + quote) / units).quantize(Decimal("0.01"))
        sales_rows.append({"sku": sku, "channel": channel, "period_start": today.isoformat(), "units_sold": units,
                           "unit_price": str(price), "exposed_price": str(listing.confirmed_price)})
    sales = import_sales(analyst, sales_rows, source="Demo synthetic post-publication sales", synthetic=True)
    p.line(f"Recorded {sales.created + sales.updated} synthetic sales row(s) for {today}.")

    # ------------------------------------------------------------------ 10
    p.step(10, "Review realised contribution separately from projections")
    p.line("PROJECTED (from recommendations)            |  REALISED (from recorded transactions)")
    rows = []
    for row in projection_vs_realised(org):
        rows.append([row["sku"], row["channel"], row["published_price"],
                     f"{row['projected_unit_contribution']:.2f}" if row["projected_unit_contribution"] is not None else "-",
                     "|", row["realised_units"],
                     f"{row['realised_average_price']:.2f}" if row["realised_average_price"] is not None else "-",
                     f"{row['realised_unit_contribution']:.2f}" if row["realised_unit_contribution"] is not None else "-",
                     f"{row['difference']:+.2f}" if row["difference"] is not None else "-"])
    p.table(["SKU", "channel", "published", "projected unit contribution", "|", "units sold",
             "avg transaction price", "realised unit contribution", "difference"], rows)
    realised = realised_summary(org, today, today)
    t = realised["totals"]
    p.line(f"{realised['label']} for {today} (synthetic demo sales): {t['units']} units, net revenue "
           f"{t['net_revenue']:.2f}, contribution {t['contribution']:.2f}.")
    p.line("")
    p.line(f"Audit events recorded: {AuditEvent.objects.filter(organisation=org).count()}; "
           f"open alerts: {Alert.objects.filter(organisation=org, resolved_at__isnull=True).count()}.")
    summary["audit_events"] = AuditEvent.objects.filter(organisation=org).count()
    return summary
