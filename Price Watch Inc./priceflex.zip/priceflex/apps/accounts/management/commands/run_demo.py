import os

from django.core.management.base import BaseCommand, CommandError

from apps.accounts import demo
from apps.accounts.demo_run import run_demonstration
from apps.accounts.models import Organisation


class Command(BaseCommand):
    help = "Seed the fictional demo organisation and run the ten-step PRICEFLEX demonstration."

    def add_arguments(self, parser):
        parser.add_argument("--password", default=os.environ.get(demo.DEMO_PASSWORD_ENV, ""),
                            help=f"Password for the demo users (or set {demo.DEMO_PASSWORD_ENV})")
        parser.add_argument("--no-seed", action="store_true", help="Run against an already seeded, untouched demo organisation")

    def handle(self, *args, **options):
        if not options["no_seed"]:
            if not options["password"]:
                raise CommandError(f"Provide --password or set {demo.DEMO_PASSWORD_ENV}.")
            if Organisation.objects.filter(slug=demo.DEMO_SLUG).exists():
                demo.reset_demo()
            demo.seed_demo(password=options["password"])
        run_demonstration(self.stdout.write)
        self.stdout.write(self.style.SUCCESS("\nDemonstration complete."))
