import os

from django.core.management.base import BaseCommand, CommandError

from apps.accounts import demo
from apps.accounts.models import Organisation


class Command(BaseCommand):
    help = "Create the fictional PRICEFLEX demo organisation (20 products, 3 simulated competitors)."

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="Delete and recreate the demo organisation")
        parser.add_argument("--password", default=os.environ.get(demo.DEMO_PASSWORD_ENV, ""),
                            help=f"Password for the demo users (or set {demo.DEMO_PASSWORD_ENV})")

    def handle(self, *args, **options):
        if not options["password"]:
            raise CommandError(f"Provide --password or set {demo.DEMO_PASSWORD_ENV}; demo users get no default password.")
        if Organisation.objects.filter(slug=demo.DEMO_SLUG).exists():
            if not options["reset"]:
                raise CommandError("The demo organisation already exists. Use --reset to recreate it.")
            demo.reset_demo()
        summary = demo.seed_demo(password=options["password"])
        for key, value in summary.items():
            self.stdout.write(f"  {key}: {value}")
        self.stdout.write(self.style.SUCCESS("Demo organisation seeded. Run 'python manage.py run_demo' next."))
