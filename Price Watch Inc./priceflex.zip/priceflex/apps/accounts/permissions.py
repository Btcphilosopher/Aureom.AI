"""Organisation, role and channel permissions.

Every service that changes state calls :func:`require` first. Views and API
endpoints resolve the caller's :class:`Membership` and pass it down; there is
no path to a price change that skips this module.

Role matrix
-----------
============== ======= ============= ======== ========= =====
permission     analyst policy_editor approver publisher admin
============== ======= ============= ======== ========= =====
view           yes     yes           yes      yes       yes
import_data    yes     yes           -        -         yes
run_pricing    yes     yes           yes      -         yes
simulate       yes     yes           yes      -         yes
edit_policy    -       yes           -        -         yes
approve        -       -             yes      -         yes
publish        -       -             -        yes       yes
administer     -       -             -        -         yes
============== ======= ============= ======== ========= =====

``publish`` covers publication, reconciliation, rollback and the pause switch.
"""

from __future__ import annotations

from .models import Membership, Role

A, E, P, U, X = Role.ANALYST.value, Role.POLICY_EDITOR.value, Role.APPROVER.value, Role.PUBLISHER.value, Role.ADMIN.value

PERMISSIONS: dict[str, set[str]] = {
    "view": {A, E, P, U, X},
    "import_data": {A, E, X},
    "run_pricing": {A, E, P, X},
    "simulate": {A, E, P, X},
    "edit_policy": {E, X},
    "approve": {P, X},
    "publish": {U, X},
    "administer": {X},
}


class PermissionDenied(Exception):
    """The caller lacks the role or channel access for an action."""

    def __init__(self, message: str, code: str = "permission_denied"):
        super().__init__(message)
        self.code = code


def membership_for(user, organisation=None) -> Membership | None:
    if user is None or not user.is_authenticated:
        return None
    qs = Membership.objects.filter(user=user, is_active=True).select_related("organisation")
    if organisation is not None:
        qs = qs.filter(organisation=organisation)
    return qs.order_by("organisation__name").first()


def channel_ids(membership: Membership) -> set[int] | None:
    """Channel ids the member is limited to, or None for all channels."""
    ids = set(membership.channels.values_list("id", flat=True))
    return ids or None


def can(membership: Membership | None, permission: str, channel=None) -> bool:
    if membership is None or not membership.is_active:
        return False
    if not set(membership.roles) & PERMISSIONS[permission]:
        return False
    if channel is not None:
        if channel.organisation_id != membership.organisation_id:
            return False
        limited = channel_ids(membership)
        if limited is not None and channel.id not in limited:
            return False
    return True


def require(membership: Membership | None, permission: str, channel=None) -> None:
    if membership is None:
        raise PermissionDenied("You are not a member of an organisation.")
    if not set(membership.roles) & PERMISSIONS[permission]:
        needed = ", ".join(sorted(PERMISSIONS[permission]))
        raise PermissionDenied(f"This action needs one of the roles: {needed}.")
    if channel is not None and not can(membership, permission, channel):
        raise PermissionDenied(f"You do not have access to the '{channel.code}' channel.", code="channel_denied")


def scope_listings(membership: Membership, queryset):
    """Restrict a ChannelListing queryset to the member's organisation and channels."""
    queryset = queryset.filter(channel__organisation=membership.organisation)
    limited = channel_ids(membership)
    return queryset if limited is None else queryset.filter(channel_id__in=limited)
