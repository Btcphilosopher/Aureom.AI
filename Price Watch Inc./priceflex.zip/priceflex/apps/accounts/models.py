from django.conf import settings
from django.db import models


class Organisation(models.Model):
    name = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    base_currency = models.CharField(max_length=3, default="GBP")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]

    def __str__(self) -> str:
        return self.name


class Role(models.TextChoices):
    ANALYST = "analyst", "Analyst"
    POLICY_EDITOR = "policy_editor", "Policy editor"
    APPROVER = "approver", "Approver"
    PUBLISHER = "publisher", "Publisher"
    ADMIN = "admin", "Administrator"


class Membership(models.Model):
    """A user's roles inside one organisation, optionally limited to channels."""

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="memberships")
    organisation = models.ForeignKey(Organisation, on_delete=models.CASCADE, related_name="memberships")
    roles = models.JSONField(default=list, help_text="List of role codes, e.g. ['analyst', 'approver']")
    channels = models.ManyToManyField(
        "catalogue.Channel", blank=True, related_name="memberships",
        help_text="Channels this member may act on. Empty means every channel in the organisation.",
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user", "organisation"], name="uniq_membership")]

    def __str__(self) -> str:
        return f"{self.user} @ {self.organisation} ({', '.join(self.roles)})"

    def has_role(self, *roles: str) -> bool:
        return bool(set(self.roles) & set(roles))
