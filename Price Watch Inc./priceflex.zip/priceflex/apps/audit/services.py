from __future__ import annotations

from django.utils import timezone

from .models import Alert, AuditEvent


def record(organisation, actor, action: str, obj=None, summary: str = "", payload: dict | None = None) -> AuditEvent:
    """Write one audit event. ``actor`` may be a user, or a string such as 'system'."""
    user = actor if (actor is not None and not isinstance(actor, str)) else None
    label = actor if isinstance(actor, str) else (actor.get_username() if actor is not None else "system")
    return AuditEvent.objects.create(
        organisation=organisation, actor=user, actor_label=label, action=action,
        object_type=obj.__class__.__name__ if obj is not None else "",
        object_id=str(obj.pk) if obj is not None and obj.pk is not None else "",
        summary=summary[:500], payload=payload or {},
    )


def raise_alert(organisation, kind: str, message: str, *, severity: str = "warning", listing=None,
                payload: dict | None = None) -> Alert:
    """Open an alert unless an identical unresolved one already exists."""
    existing = Alert.objects.filter(organisation=organisation, kind=kind, listing=listing, resolved_at__isnull=True).first()
    if existing:
        existing.message, existing.payload = message[:500], payload or {}
        existing.save(update_fields=["message", "payload"])
        return existing
    return Alert.objects.create(organisation=organisation, kind=kind, message=message[:500], severity=severity,
                                listing=listing, payload=payload or {})


def resolve_alerts(organisation, kind: str, listing=None) -> int:
    return Alert.objects.filter(organisation=organisation, kind=kind, listing=listing,
                                resolved_at__isnull=True).update(resolved_at=timezone.now())
