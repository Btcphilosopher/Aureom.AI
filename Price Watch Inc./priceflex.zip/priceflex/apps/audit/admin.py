from django.contrib import admin

from .models import Alert, AuditEvent


@admin.register(AuditEvent)
class AuditEventAdmin(admin.ModelAdmin):
    """Read-only: audit events can be inspected here but never added, changed or deleted."""

    list_display = ("created_at", "organisation", "actor_label", "action", "summary")
    list_filter = ("organisation", "action")
    search_fields = ("summary", "actor_label", "object_id")
    date_hierarchy = "created_at"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Alert)
class AlertAdmin(admin.ModelAdmin):
    list_display = ("created_at", "organisation", "severity", "kind", "message", "resolved_at")
    list_filter = ("organisation", "severity", "kind")
