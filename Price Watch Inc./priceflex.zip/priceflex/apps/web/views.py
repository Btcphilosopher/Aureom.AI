"""Management interface. Every state change goes through the same services as the API."""

from __future__ import annotations

import json
from datetime import date, datetime, timedelta
from decimal import Decimal
from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db import connection
from django.db.models import Count, OuterRef, Q, Subquery, Sum
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from apps.accounts.models import Membership
from apps.accounts.permissions import PermissionDenied, can, channel_ids, membership_for, require, scope_listings
from apps.audit.models import Alert, AuditEvent
from apps.catalogue.importing import rows_from_csv
from apps.catalogue.models import Channel
from apps.competitors.models import CompetitorObservation, FeedStatus
from apps.competitors.services import pull_price_watch
from apps.costs.models import CostVersion, TaxRule
from apps.costs.services import cost_for, import_costs
from apps.inventory.models import InventoryPosition
from apps.inventory.services import import_inventory, positions_for
from apps.policies.models import PricingPolicy, Promotion
from apps.policies.services import authorise_automation, save_policy
from apps.publishing import services as publishing
from apps.publishing.models import (
    MockStorefrontPrice,
    ObservedPublishedPrice,
    PriceHistory,
    PublicationAttempt,
)
from apps.recommendations import services as recommendations
from apps.recommendations.models import PriceRecommendation, PricingRun
from apps.recommendations.workflow import WorkflowError
from apps.simulation.models import DemandModel, Experiment, SimulationRun
from apps.simulation.reports import projection_vs_realised, realised_summary
from apps.simulation.services import experiment_readout, fit_demand_model, simulate_listing
from engine.money import D, MoneyError
from engine.policy import PolicyValidationError


def healthz(request):
    return JsonResponse({"status": "ok"})


def readyz(request):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
    except Exception:  # noqa: BLE001 - readiness must report, not raise
        return JsonResponse({"status": "database unavailable"}, status=503)
    return JsonResponse({"status": "ok"})


def workspace(view):
    """Resolve the member's organisation and turn service refusals into messages."""

    @login_required
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        membership = membership_for(request.user)
        if membership is None:
            return render(request, "web/no_membership.html", status=403)
        request.membership = membership
        try:
            return view(request, *args, **kwargs)
        except (PermissionDenied, WorkflowError, PolicyValidationError) as exc:
            text = exc.message if isinstance(exc, WorkflowError) else str(exc)
            details = getattr(exc, "details", {}) or {}
            extra = [v["name"].replace("_", " ") for v in details.get("violations", [])]
            extra += [i["message"] for i in details.get("blocking_issues", [])]
            if isinstance(exc, PolicyValidationError):
                text, extra = "The policy configuration is invalid.", exc.errors
            full = text + (" — " + "; ".join(extra) if extra else "")
            if request.headers.get("HX-Request"):
                return HttpResponse(f'<div class="notice notice-bad" role="alert">{_escape(full)}</div>', status=200)
            messages.error(request, full)
            return redirect(request.META.get("HTTP_REFERER") or "web:overview")
    return wrapper


def _escape(text: str) -> str:
    from django.utils.html import escape

    return escape(text)


def _listings(request):
    return scope_listings(request.membership, recommendations.listing_queryset())


def _recs(request):
    qs = PriceRecommendation.objects.filter(organisation=request.membership.organisation).select_related(
        "listing", "listing__variant", "listing__variant__product", "listing__channel", "snapshot",
        "policy_version", "policy_version__policy", "run")
    limited = channel_ids(request.membership)
    return qs if limited is None else qs.filter(listing__channel_id__in=limited)


def _back(request, fallback: str):
    return redirect(request.POST.get("next") or request.META.get("HTTP_REFERER") or fallback)


def _hard_floor(rec) -> Decimal | None:
    interval = (rec.result or {}).get("feasible_interval") if rec else None
    if not interval:
        return None
    hard = [Decimal(b["value"]) for b in interval["bounds"] if b["side"] == "lower" and b["kind"] == "hard"]
    return max(hard) if hard else None


# -- overview -------------------------------------------------------------------------


@workspace
def overview(request):
    org = request.membership.organisation
    recs = _recs(request)
    listings = _listings(request).filter(is_active=True)
    now = timezone.now()
    latest_run = PricingRun.objects.filter(organisation=org).first()
    missing_cost = [listing for listing in listings if cost_for(listing.variant, listing.channel, now) is None]
    stale_inventory = InventoryPosition.objects.filter(
        variant__organisation=org, as_of__lt=now - timedelta(hours=48)).select_related("variant", "location")
    context = {
        "tiles": [
            ("Awaiting approval", recs.filter(status="awaiting_approval").exclude(outcome="conflict").count(),
             "recommendations?status=awaiting_approval", "Price changes waiting for a decision"),
            ("Constraint conflicts", recs.filter(status="awaiting_approval", outcome="conflict").count(),
             "recommendations?outcome=conflict&status=awaiting_approval", "No feasible price; review needed"),
            ("Blocked by inputs", recs.filter(status="evaluated", outcome="blocked").count(),
             "recommendations?outcome=blocked&status=evaluated", "Missing cost, tax or policy"),
            ("Ready to publish", recs.filter(status__in=["approved", "scheduled"]).count(), "publishing",
             "Approved or scheduled prices"),
            ("Uncertain publications", PublicationAttempt.objects.filter(organisation=org, status__in=["uncertain", "sent"]).count(),
             "publishing", "Awaiting reconciliation"),
            ("Open alerts", Alert.objects.filter(organisation=org, resolved_at__isnull=True).count(), "publishing",
             "Feed, storefront and publication alerts"),
        ],
        "latest_run": latest_run,
        "runs": PricingRun.objects.filter(organisation=org)[:5],
        "alerts": Alert.objects.filter(organisation=org, resolved_at__isnull=True).select_related("listing")[:8],
        "feeds": FeedStatus.objects.filter(organisation=org),
        "missing_cost": missing_cost,
        "stale_inventory": stale_inventory[:10],
        "status_counts": recs.filter(run=latest_run).values("outcome").annotate(n=Count("id")).order_by("outcome") if latest_run else [],
        "recent": recs.filter(status="awaiting_approval")[:8],
        "channels": Channel.objects.filter(organisation=org, is_active=True),
    }
    return render(request, "web/overview.html", context)


@workspace
@require_POST
def run_pricing(request):
    channel = None
    if request.POST.get("channel"):
        channel = get_object_or_404(Channel, organisation=request.membership.organisation, code=request.POST["channel"])
    listing_ids = [int(request.POST["listing"])] if request.POST.get("listing", "").isdigit() else None
    run = recommendations.run_pricing(request.membership, channel=channel, listing_ids=listing_ids, trigger="manual")
    c = run.counts
    messages.success(request, f"Pricing run {run.pk}: {c['evaluated']} evaluated — {c['change']} changes, "
                              f"{c['no_change']} unchanged, {c['conflict']} conflicts, {c['blocked']} blocked.")
    return _back(request, "web:recommendations")


# -- products ---------------------------------------------------------------------------


@workspace
def products(request):
    org = request.membership.organisation
    latest = PriceRecommendation.objects.filter(listing=OuterRef("pk"), kind="evaluation").order_by("-evaluated_at", "-id")
    qs = _listings(request).annotate(
        latest_rec_id=Subquery(latest.values("id")[:1]),
        on_hand=Sum("variant__inventory_positions__on_hand"),
    )
    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(Q(variant__sku__icontains=q) | Q(variant__name__icontains=q) | Q(variant__product__brand__icontains=q))
    if request.GET.get("channel"):
        qs = qs.filter(channel__code=request.GET["channel"])
    if request.GET.get("policy"):
        qs = qs.filter(policy__code=request.GET["policy"])
    if request.GET.get("category"):
        qs = qs.filter(variant__product__category=request.GET["category"])
    page = Paginator(qs.order_by("variant__sku", "channel__code"), 40).get_page(request.GET.get("page"))
    recs = {r.pk: r for r in PriceRecommendation.objects.filter(pk__in=[row.latest_rec_id for row in page if row.latest_rec_id])}
    for row in page:
        row.latest = recs.get(row.latest_rec_id)
    context = {
        "page": page, "q": q,
        "channels": Channel.objects.filter(organisation=org), "policies": PricingPolicy.objects.filter(organisation=org),
        "categories": sorted(set(_listings(request).values_list("variant__product__category", flat=True))),
    }
    template = "web/partials/product_rows.html" if request.headers.get("HX-Request") else "web/products.html"
    return render(request, template, context)


def _decision_context(request, rec, listing) -> dict:
    now = timezone.now()
    history = list(PriceHistory.objects.filter(listing=listing).order_by("effective_at", "id"))
    cv = cost_for(listing.variant, listing.channel, now)
    positions = list(positions_for(listing.variant, listing.channel))
    newest_obs = CompetitorObservation.objects.filter(variant=listing.variant).order_by("-observed_at").first()
    feed = FeedStatus.objects.filter(organisation=listing.channel.organisation).first()
    freshness = [
        ("Cost version", cv.effective_from if cv else None, "effective", cv is None),
        ("Inventory", min((p.as_of for p in positions), default=None), "oldest location update",
         not positions or min(p.as_of for p in positions) < now - timedelta(hours=48)),
        ("Competitor observation", newest_obs.observed_at if newest_obs else None, "most recent",
         newest_obs is None or newest_obs.observed_at < now - timedelta(hours=48)),
        ("Price Watch feed", feed.last_success_at if feed else None, "last success", bool(feed and feed.failing)),
        ("Confirmed price", listing.confirmed_at, "last confirmed by read-back", listing.confirmed_price is None),
    ]
    result = rec.result if rec else {}
    return {
        "listing": listing, "rec": rec, "result": result, "history": history,
        "history_recent": list(reversed(history))[:12], "floor": _hard_floor(rec),
        "freshness": freshness, "positions": positions, "cost": cv,
        "attempts": PublicationAttempt.objects.filter(listing=listing).select_related("recommendation")[:6],
        "observed": ObservedPublishedPrice.objects.filter(listing=listing)[:6],
        "decisions": rec.decisions.select_related("decided_by") if rec else [],
        "promotions": Promotion.objects.filter(listings=listing, ends_at__gt=now).exclude(status="cancelled"),
        "commitments": listing.commitments.all(),
        "margin_rows": _margin_rows(result),
        "storefront": MockStorefrontPrice.objects.filter(channel_code=listing.channel.code, sku=listing.variant.sku).first(),
        "can_approve": can(request.membership, "approve", listing.channel),
        "can_publish": can(request.membership, "publish", listing.channel),
    }


MARGIN_LINES = [
    ("customer_price", "Customer price", "money"), ("output_tax", "Output tax", "money"),
    ("net_revenue", "Net revenue", "money"), ("cost_of_goods", "Cost of goods", "money"),
    ("variable_fulfilment", "Variable fulfilment", "money"), ("transaction_fees", "Transaction fees", "money"),
    ("expected_returns_and_warranty", "Expected returns / warranty", "money"),
    ("promotion_funding", "Supplier promotion funding", "money"), ("contribution", "Contribution", "money"),
    ("contribution_margin", "Contribution margin", "pct"), ("gross_margin", "Gross margin", "pct"),
    ("markup", "Markup on cost", "pct"), ("operating_profit", "Operating profit", "money"),
]


def _margin_rows(result: dict) -> list[dict]:
    current, proposed = result.get("margin_current") or {}, result.get("margin_recommended") or {}
    if not current and not proposed:
        return []
    return [{"label": label, "kind": kind, "current": current.get(key), "proposed": proposed.get(key),
             "strong": key in ("net_revenue", "contribution", "contribution_margin")}
            for key, label, kind in MARGIN_LINES]


@workspace
def product_detail(request, pk: int):
    listing = get_object_or_404(_listings(request), pk=pk)
    rec = _recs(request).filter(listing=listing).order_by("-evaluated_at", "-id").first()
    context = _decision_context(request, rec, listing)
    context["other_listings"] = _listings(request).filter(variant__product=listing.variant.product).exclude(pk=listing.pk)
    return render(request, "web/product_detail.html", context)


# -- costs --------------------------------------------------------------------------------


@workspace
def costs(request):
    org = request.membership.organisation
    now = timezone.now()
    if request.method == "POST":
        upload = request.FILES.get("file")
        if upload is None:
            messages.error(request, "Choose a CSV file to import.")
            return redirect("web:costs")
        rows = rows_from_csv(upload.read().decode("utf-8-sig"))
        kind = request.POST.get("kind", "costs")
        result = (import_inventory if kind == "inventory" else import_costs)(request.membership, rows, source=f"upload:{upload.name}")
        level = messages.warning if result.rejected else messages.success
        level(request, f"{kind.title()} import {result.batch}: {result.created} created, {result.updated} updated, "
                       f"{len(result.rejected)} rejected.")
        request.session["last_import"] = result.to_dict()
        return redirect("web:costs")
    listings = _listings(request).filter(is_active=True)
    rows = []
    for listing in listings.order_by("variant__sku", "channel__code"):
        rows.append({"listing": listing, "cost": cost_for(listing.variant, listing.channel, now)})
    context = {
        "rows": rows, "missing": [r for r in rows if r["cost"] is None],
        "tax_rules": TaxRule.objects.filter(organisation=org),
        "recent": CostVersion.objects.filter(organisation=org).select_related("variant", "channel", "created_by")[:15],
        "last_import": request.session.pop("last_import", None),
    }
    return render(request, "web/costs.html", context)


# -- competitors ------------------------------------------------------------------------------


@workspace
def competitors(request):
    org = request.membership.organisation
    qs = CompetitorObservation.objects.filter(organisation=org).select_related("variant")
    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(Q(variant__sku__icontains=q) | Q(supplier__icontains=q) | Q(title__icontains=q))
    flag = request.GET.get("flag")
    if flag == "different_variant":
        qs = qs.filter(variant_match="different")
    elif flag == "not_new":
        qs = qs.exclude(condition="new")
    elif flag == "unavailable":
        qs = qs.exclude(availability="in_stock")
    elif flag == "conditional":
        qs = qs.filter(membership_required=True)
    elif flag == "incomplete":
        qs = qs.filter(charges_complete=False)
    elif flag == "weak":
        qs = qs.filter(Q(match_confidence__lt=Decimal("0.85")) | Q(match_status__in=["unresolved", "rejected"]))
    elif flag == "retained":
        qs = qs.filter(retained_after_feed_failure=True)
    if not request.GET.get("history"):
        qs = qs.exclude(external_observation_id__startswith="hist-")
    page = Paginator(qs.order_by("-observed_at", "-id"), 40).get_page(request.GET.get("page"))
    context = {"page": page, "q": q, "flag": flag, "feeds": FeedStatus.objects.filter(organisation=org),
               "stale_cutoff": timezone.now() - timedelta(hours=48)}
    template = "web/partials/competitor_rows.html" if request.headers.get("HX-Request") else "web/competitors.html"
    return render(request, template, context)


@workspace
@require_POST
def pull_competitors(request):
    result = pull_price_watch(request.membership)
    if result.batch == "failed":
        messages.error(request, "Price Watch could not be read. The last valid observations are kept with their "
                                "original timestamps; nothing was overwritten.")
    else:
        messages.success(request, f"Price Watch: {result.created} new, {result.updated} refreshed, "
                                  f"{len(result.rejected)} entries without a usable price.")
    return redirect("web:competitors")


# -- policies -----------------------------------------------------------------------------------


@workspace
def policies(request):
    org = request.membership.organisation
    qs = PricingPolicy.objects.filter(organisation=org).select_related("current_version").annotate(n=Count("listings"))
    return render(request, "web/policies.html", {"policies": qs})


@workspace
def policy_detail(request, pk: int):
    policy = get_object_or_404(PricingPolicy, organisation=request.membership.organisation, pk=pk)
    draft, errors = None, []
    if request.method == "POST":
        action = request.POST.get("action")
        if action == "authorise":
            authorise_automation(request.membership, policy, request.POST.get("authorised") == "1")
            messages.success(request, "Automation authorisation updated.")
            return redirect("web:policy_detail", pk=policy.pk)
        draft = request.POST.get("config", "")
        try:
            config = json.loads(draft, parse_float=Decimal)
            config = json.loads(json.dumps(config, default=str))
            save_policy(request.membership, code=policy.code, name=policy.name, config=config,
                        change_note=request.POST.get("change_note", ""))
            messages.success(request, "New policy version saved. It applies from the next evaluation.")
            return redirect("web:policy_detail", pk=policy.pk)
        except json.JSONDecodeError as exc:
            errors = [f"Not valid JSON: {exc}"]
        except PolicyValidationError as exc:
            errors = exc.errors
    version = policy.current_version
    context = {
        "policy": policy, "versions": policy.versions.select_related("created_by"),
        "config_json": draft if draft is not None else json.dumps(version.config if version else {}, indent=2),
        "errors": errors, "listings": policy.listings.select_related("variant", "channel")[:50],
    }
    return render(request, "web/policy_detail.html", context)


# -- recommendations ---------------------------------------------------------------------------


@workspace
def recommendation_list(request):
    org = request.membership.organisation
    qs = _recs(request)
    g = request.GET
    q = g.get("q", "").strip()
    if q:
        qs = qs.filter(Q(listing__variant__sku__icontains=q) | Q(listing__variant__name__icontains=q))
    if g.get("channel"):
        qs = qs.filter(listing__channel__code=g["channel"])
    if g.get("policy"):
        qs = qs.filter(policy_version__policy__code=g["policy"])
    if g.get("status"):
        qs = qs.filter(status=g["status"])
    if g.get("outcome"):
        qs = qs.filter(outcome=g["outcome"])
    if g.get("warning") == "yes":
        qs = qs.filter(has_warnings=True)
    elif g.get("warning") == "no":
        qs = qs.filter(has_warnings=False)
    if not g.get("all") and not g.get("status"):
        qs = qs.exclude(status__in=["superseded", "expired"])
    page = Paginator(qs.order_by("-evaluated_at", "-id"), 30).get_page(g.get("page"))
    for rec in page:
        rec.can_approve = can(request.membership, "approve", rec.listing.channel)
    context = {
        "page": page, "q": q, "filters": g,
        "channels": Channel.objects.filter(organisation=org), "policies": PricingPolicy.objects.filter(organisation=org),
        "statuses": [s for s, _ in PriceRecommendation._meta.get_field("status").choices],
        "outcomes": ["change", "no_change", "conflict", "blocked"],
    }
    template = "web/partials/recommendation_rows.html" if request.headers.get("HX-Request") else "web/recommendations.html"
    return render(request, template, context)


@workspace
def recommendation_detail(request, pk: int):
    rec = get_object_or_404(_recs(request), pk=pk)
    listing = recommendations.listing_queryset().get(pk=rec.listing_id)
    context = _decision_context(request, rec, listing)
    if request.GET.get("verify") and rec.kind == "evaluation":
        context["replay"] = recommendations.replay(rec)
    context["snapshot_json"] = json.dumps(rec.snapshot.payload, indent=2) if request.GET.get("snapshot") else None
    return render(request, "web/recommendation_detail.html", context)


def _price(request, key: str) -> Decimal | None:
    raw = request.POST.get(key, "").strip()
    if not raw:
        return None
    try:
        return D(raw)
    except MoneyError:
        raise WorkflowError("validation_error", f"'{raw}' is not a valid price.", http_status=422)


@workspace
@require_POST
def recommendation_action(request, pk: int, action: str):
    rec = get_object_or_404(_recs(request), pk=pk)
    comment = request.POST.get("comment", "")
    if action == "approve":
        scheduled = None
        if request.POST.get("scheduled_for"):
            scheduled = timezone.make_aware(datetime.fromisoformat(request.POST["scheduled_for"]))
        rec = recommendations.approve(request.membership, rec, approved_price=_price(request, "approved_price"),
                                      comment=comment, scheduled_for=scheduled)
        messages.success(request, f"Approved {rec.listing} at {rec.currency} {rec.approved_price}.")
    elif action == "reject":
        recommendations.reject(request.membership, rec, comment=comment)
        messages.success(request, f"Rejected the recommendation for {rec.listing}.")
    elif action == "withdraw":
        recommendations.withdraw(request.membership, rec, comment=comment)
        messages.success(request, f"Withdrew the recommendation for {rec.listing}.")
    elif action == "publish":
        attempt = publishing.publish(request.membership, rec)
        _flash_attempt(request, attempt)
    else:
        raise WorkflowError("validation_error", "Unknown action.")
    if request.headers.get("HX-Request"):
        fresh = get_object_or_404(_recs(request), pk=pk)
        fresh.can_approve = can(request.membership, "approve", fresh.listing.channel)
        return render(request, "web/partials/recommendation_row.html", {"rec": fresh, "flash": True})
    return _back(request, "web:recommendations")


def _flash_attempt(request, attempt) -> None:
    if attempt.status == "verified":
        messages.success(request, f"{attempt.listing}: {attempt.price} published and verified by storefront read-back.")
    elif attempt.status == "uncertain":
        messages.warning(request, f"{attempt.listing}: outcome uncertain — {attempt.error} Reconcile to resolve it.")
    else:
        messages.error(request, f"{attempt.listing}: publication {attempt.status} — {attempt.error}")


# -- simulator -------------------------------------------------------------------------------------


@workspace
def simulator(request):
    listings = _listings(request).filter(is_active=True, policy__isnull=False).order_by("variant__sku", "channel__code")
    run = None
    if request.method == "POST":
        listing = get_object_or_404(listings, pk=request.POST.get("listing"))
        on_hand = request.POST.get("initial_on_hand", "").strip()
        base = request.POST.get("base_units_per_day", "").strip()
        run = simulate_listing(
            request.membership, listing, days=int(request.POST.get("days") or 28),
            elasticity=D(request.POST.get("elasticity") or "-1.5"),
            base_units_per_day=D(base) if base else None,
            competitor_sensitivity=D(request.POST.get("competitor_sensitivity") or "0"),
            initial_on_hand=int(on_hand) if on_hand else None, seed=int(request.POST.get("seed") or 20240101))
        if request.headers.get("HX-Request"):
            return render(request, "web/partials/simulation_result.html", _simulation_context(run))
    elif request.GET.get("run"):
        run = get_object_or_404(SimulationRun, organisation=request.membership.organisation, pk=request.GET["run"])
    context = {"listings": listings, "recent": SimulationRun.objects.filter(
        organisation=request.membership.organisation).select_related("listing__variant", "listing__channel")[:10],
        "demand_models": DemandModel.objects.filter(listing__channel__organisation=request.membership.organisation
                                                    ).select_related("listing__variant", "listing__channel")[:8]}
    if run:
        context.update(_simulation_context(run))
    return render(request, "web/simulator.html", context)


SIM_METRICS = [("revenue_net", "Revenue (net)", "money"), ("contribution", "Contribution", "money"),
               ("units_sold", "Units sold", "int"), ("ending_inventory", "Ending inventory", "int")]


def _simulation_context(run: SimulationRun) -> dict:
    arms = run.results["arms"]
    charts = []
    for key, label, kind in SIM_METRICS:
        values = [Decimal(str(a[key])) for a in arms]
        charts.append({"label": label, "kind": kind, "max": max(values + [Decimal("0.01")]),
                       "bars": [{"arm": a["label"], "value": v} for a, v in zip(arms, values)]})
    return {"run": run, "results": run.results, "arms": arms, "charts": charts}


@workspace
@require_POST
def fit_demand(request):
    listing = get_object_or_404(_listings(request), pk=request.POST.get("listing"))
    model = fit_demand_model(request.membership, listing)
    messages.info(request, f"Demand estimate for {listing}: {model.status.replace('_', ' ')}.")
    return redirect("web:simulator")


# -- publishing ----------------------------------------------------------------------------------------


@workspace
def publishing_view(request):
    org = request.membership.organisation
    recs = _recs(request)
    context = {
        "control": publishing.control_for(org),
        "ready": recs.filter(status__in=["approved", "scheduled", "failed"]).order_by("scheduled_for", "-evaluated_at"),
        "attempts": PublicationAttempt.objects.filter(organisation=org).select_related(
            "listing__variant", "listing__channel", "recommendation", "created_by")[:40],
        "alerts": Alert.objects.filter(organisation=org, resolved_at__isnull=True).select_related("listing")[:12],
        "can_publish": can(request.membership, "publish"),
        "storefront": MockStorefrontPrice.objects.filter(
            channel_code__in=Channel.objects.filter(organisation=org).values("code")).order_by("sku", "channel_code")[:80],
    }
    return render(request, "web/publishing.html", context)


@workspace
@require_POST
def publishing_action(request, action: str):
    org = request.membership.organisation
    if action == "pause":
        publishing.set_pause(request.membership, True, request.POST.get("reason", ""))
        messages.warning(request, "Publication is paused. No price will be sent until it is resumed.")
    elif action == "resume":
        publishing.set_pause(request.membership, False)
        messages.success(request, "Publication resumed.")
    elif action == "reconcile":
        attempt = get_object_or_404(PublicationAttempt, organisation=org, pk=request.POST.get("attempt"))
        _flash_attempt(request, publishing.reconcile(request.membership, attempt))
    elif action == "monitor":
        require(request.membership, "publish")
        result = publishing.monitor(org, actor=request.user)
        messages.info(request, f"Read back {result['checked']} storefront prices; {result['mismatched']} mismatched.")
    elif action == "rollback":
        listing = get_object_or_404(_listings(request), pk=request.POST.get("listing"))
        _flash_attempt(request, publishing.request_rollback(request.membership, listing, reason=request.POST.get("reason", "")))
    else:
        raise WorkflowError("validation_error", "Unknown action.")
    return _back(request, "web:publishing")


# -- experiments ------------------------------------------------------------------------------------------


@workspace
def experiments(request):
    org = request.membership.organisation
    if request.method == "POST":
        require(request.membership, "edit_policy")
        channel = get_object_or_404(Channel, organisation=org, code=request.POST.get("channel"))
        try:
            starts, ends = date.fromisoformat(request.POST["starts_at"]), date.fromisoformat(request.POST["ends_at"])
        except (KeyError, ValueError):
            raise WorkflowError("validation_error", "Start and end dates are required.")
        if ends < starts or not request.POST.get("name", "").strip():
            raise WorkflowError("validation_error", "A name is required and the end date cannot precede the start.")
        pool = _listings(request).filter(channel=channel)

        def pick(field):
            skus = [s.strip() for s in request.POST.get(field, "").replace("\n", ",").split(",") if s.strip()]
            return list(pool.filter(variant__sku__in=skus))

        control, treatment = pick("control"), pick("treatment")
        if not control or not treatment or {c.pk for c in control} & {t.pk for t in treatment}:
            raise WorkflowError("validation_error", "Give at least one known SKU per group; a SKU cannot be in both.")
        exp = Experiment.objects.create(organisation=org, name=request.POST["name"].strip()[:200],
                                        hypothesis=request.POST.get("hypothesis", ""), channel=channel,
                                        starts_at=starts, ends_at=ends, status="running", created_by=request.user)
        exp.control_listings.set(control)
        exp.treatment_listings.set(treatment)
        messages.success(request, "Experiment recorded.")
        return redirect("web:experiments")
    rows = []
    for exp in Experiment.objects.filter(organisation=org).select_related("channel").prefetch_related(
            "control_listings__variant", "treatment_listings__variant"):
        rows.append({"experiment": exp, "readout": experiment_readout(exp)})
    return render(request, "web/experiments.html", {"rows": rows, "channels": Channel.objects.filter(organisation=org)})


# -- reports --------------------------------------------------------------------------------------------------


@workspace
def reports(request):
    org = request.membership.organisation
    today = timezone.now().date()
    try:
        since = date.fromisoformat(request.GET.get("since", ""))
    except ValueError:
        since = today - timedelta(days=13)
    try:
        until = date.fromisoformat(request.GET.get("until", ""))
    except ValueError:
        until = today
    recs = _recs(request).filter(outcome="change", status__in=["awaiting_approval", "approved", "scheduled"])
    projected = []
    for rec in recs.order_by("listing__variant__sku")[:60]:
        proj = (rec.result or {}).get("projection") or {}
        projected.append({"rec": rec, "current": proj.get("unit_contribution_current"),
                          "recommended": proj.get("unit_contribution_recommended"),
                          "change": proj.get("unit_contribution_change"), "volume": proj.get("volume_forecast")})
    context = {"since": since, "until": until, "realised": realised_summary(org, since, until),
               "comparison": projection_vs_realised(org), "projected": projected}
    return render(request, "web/reports.html", context)


# -- administration --------------------------------------------------------------------------------------------


@workspace
def administration(request):
    org = request.membership.organisation
    events = AuditEvent.objects.filter(organisation=org)
    action = request.GET.get("action", "").strip()
    if action:
        events = events.filter(action__startswith=action)
    page = Paginator(events, 40).get_page(request.GET.get("page"))
    context = {
        "members": Membership.objects.filter(organisation=org).select_related("user").prefetch_related("channels"),
        "page": page, "action": action,
        "actions": sorted({a.split(".")[0] for a in AuditEvent.objects.filter(organisation=org).values_list("action", flat=True).distinct()}),
        "policies": PricingPolicy.objects.filter(organisation=org),
    }
    template = "web/partials/audit_rows.html" if request.headers.get("HX-Request") else "web/administration.html"
    return render(request, template, context)
