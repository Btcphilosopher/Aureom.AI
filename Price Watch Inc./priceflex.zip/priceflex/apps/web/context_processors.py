from apps.accounts.permissions import PERMISSIONS, membership_for

NAV = [
    ("web:overview", "Overview"), ("web:products", "Products"), ("web:costs", "Costs"),
    ("web:competitors", "Competitors"), ("web:policies", "Policies"), ("web:recommendations", "Recommendations"),
    ("web:simulator", "Simulator"), ("web:publishing", "Publishing"), ("web:experiments", "Experiments"),
    ("web:reports", "Reports"), ("web:administration", "Administration"),
]


def workspace(request):
    user = getattr(request, "user", None)
    if user is None or not user.is_authenticated:
        return {}
    membership = getattr(request, "membership", None) or membership_for(user)
    if membership is None:
        return {"nav": []}
    from apps.publishing.services import control_for

    roles = set(membership.roles)
    return {
        "nav": NAV, "membership": membership, "organisation": membership.organisation,
        "can": {name: bool(roles & allowed) for name, allowed in PERMISSIONS.items()},
        "publication_paused": control_for(membership.organisation).paused,
    }
