from django.urls import path

from . import views

urlpatterns = [
    path("", views.overview, name="overview"),
    path("pricing-runs/", views.run_pricing, name="run_pricing"),
    path("products/", views.products, name="products"),
    path("products/<int:pk>/", views.product_detail, name="product_detail"),
    path("costs/", views.costs, name="costs"),
    path("competitors/", views.competitors, name="competitors"),
    path("competitors/pull/", views.pull_competitors, name="pull_competitors"),
    path("policies/", views.policies, name="policies"),
    path("policies/<int:pk>/", views.policy_detail, name="policy_detail"),
    path("recommendations/", views.recommendation_list, name="recommendations"),
    path("recommendations/<int:pk>/", views.recommendation_detail, name="recommendation_detail"),
    path("recommendations/<int:pk>/<str:action>/", views.recommendation_action, name="recommendation_action"),
    path("simulator/", views.simulator, name="simulator"),
    path("simulator/demand-model/", views.fit_demand, name="fit_demand"),
    path("publishing/", views.publishing_view, name="publishing"),
    path("publishing/<str:action>/", views.publishing_action, name="publishing_action"),
    path("experiments/", views.experiments, name="experiments"),
    path("reports/", views.reports, name="reports"),
    path("administration/", views.administration, name="administration"),
]
