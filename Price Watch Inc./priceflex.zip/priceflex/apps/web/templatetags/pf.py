import math
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation

from django import template
from django.utils import timezone
from django.utils.html import format_html
from django.utils.safestring import mark_safe

from engine.explanations import CONSTRAINT_LABELS, OUTCOME_LABELS, STRATEGY_LABELS

register = template.Library()


def _dec(value):
    if value in (None, ""):
        return None
    try:
        return value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None


@register.filter
def money(value, currency=""):
    amount = _dec(value)
    if amount is None:
        return "—"
    text = f"{amount:,.2f}"
    return f"{currency} {text}".strip()


@register.filter
def pct(value, places=1):
    amount = _dec(value)
    return "—" if amount is None else f"{amount * 100:.{int(places)}f}%"


@register.filter
def signed(value):
    amount = _dec(value)
    return "—" if amount is None else f"{amount:+,.2f}"


@register.filter
def isodt(value):
    """Format an ISO-8601 string stored in a result document."""
    try:
        return datetime.fromisoformat(str(value)).strftime("%d %b %H:%M")
    except (TypeError, ValueError):
        return value or "—"


@register.filter
def change_pct(rec):
    """Recommended vs current price, as a signed percentage."""
    if rec.recommended_price is None or not rec.current_price:
        return "—"
    return f"{(rec.recommended_price - rec.current_price) / rec.current_price * 100:+.1f}%"


@register.filter
def get(mapping, key):
    try:
        return mapping.get(key)
    except AttributeError:
        return None


@register.filter
def constraint_label(code):
    return CONSTRAINT_LABELS.get(code, str(code).replace("_", " "))


@register.filter
def strategy_label(code):
    return STRATEGY_LABELS.get(code, str(code).replace("_", " ")) if code else "—"


@register.filter
def outcome_label(code):
    return OUTCOME_LABELS.get(code, code)


@register.filter
def humanise(code):
    return str(code).replace("_", " ")


STATUS_TONES = {
    "verified": "good", "approved": "info", "scheduled": "info", "publishing": "warn", "awaiting_approval": "warn",
    "evaluated": "muted", "draft": "muted", "rejected": "bad", "failed": "bad", "expired": "muted",
    "superseded": "muted", "withdrawn": "muted", "uncertain": "warn", "blocked": "bad", "sent": "warn",
    "pending": "warn", "change": "info", "no_change": "muted", "conflict": "bad", "active": "good",
    "draft_policy": "muted", "archived": "muted", "validated": "good", "insufficient_evidence": "muted",
    "running": "info", "completed": "good", "cancelled": "muted", "critical": "bad", "warning": "warn", "info": "info",
}
ICONS = {"good": "✓", "warn": "!", "bad": "✕", "info": "→", "muted": "·"}


@register.simple_tag
def badge(code, label=None):
    tone = STATUS_TONES.get(code, "muted")
    return format_html('<span class="badge badge-{}"><span aria-hidden="true">{}</span> {}</span>', tone, ICONS[tone],
                       label or str(code).replace("_", " "))


@register.filter
def age(when):
    if when is None:
        return "never"
    delta = timezone.now() - when
    if delta < timedelta(minutes=1):
        return "just now"
    if delta < timedelta(hours=1):
        return f"{int(delta.total_seconds() // 60)} min ago"
    if delta < timedelta(hours=48):
        return f"{int(delta.total_seconds() // 3600)} h ago"
    return f"{delta.days} days ago"


def _ticks(lo: float, hi: float, target: int = 4) -> list[float]:
    """Clean axis ticks (1 / 2 / 2.5 / 5 x a power of ten) inside [lo, hi]."""
    raw = max(hi - lo, 1e-9) / target
    magnitude = 10 ** math.floor(math.log10(raw))
    step = next(m * magnitude for m in (1, 2, 2.5, 5, 10) if m * magnitude >= raw)
    value, ticks = math.ceil(lo / step) * step, []
    while value <= hi + step * 1e-6:
        ticks.append(round(value, 6))
        value += step
    return ticks


@register.simple_tag
def price_chart(points, currency="", floor=None, days=120):
    """Step chart of confirmed published prices. One series, so the title names it (no legend).

    ``points`` is an iterable of objects with ``effective_at`` and ``price``, oldest first.
    """
    points = list(points)
    if not points:
        return mark_safe('<p class="muted">No confirmed price history yet.</p>')
    now = timezone.now()
    start = max(now - timedelta(days=days), points[0].effective_at)
    if (now - start).total_seconds() < 3600:
        start = now - timedelta(days=7)
    width, height, left, right, top, bottom = 760, 240, 56, 84, 16, 30
    values = [float(p.price) for p in points] + ([float(floor)] if floor is not None else [])
    lo, hi = min(values), max(values)
    pad = max((hi - lo) * 0.18, hi * 0.01, 0.05)
    lo, hi = lo - pad, hi + pad
    span_t = (now - start).total_seconds()

    def x(when):
        return left + (width - left - right) * max(0.0, min(1.0, (when - start).total_seconds() / span_t))

    def y(value):
        return top + (height - top - bottom) * (1 - (float(value) - lo) / (hi - lo))

    parts = [f'<svg class="chart" viewBox="0 0 {width} {height}" role="img" '
             f'aria-label="Confirmed published price over time, in {currency}">']
    for tick in _ticks(lo, hi):
        parts.append(f'<line class="grid" x1="{left}" x2="{width - right}" y1="{y(tick):.1f}" y2="{y(tick):.1f}"/>')
        parts.append(f'<text class="axis" x="{left - 8}" y="{y(tick) + 4:.1f}" text-anchor="end">{tick:,.2f}</text>')
    for i in range(5):
        when = start + (now - start) * i / 4
        anchor = "start" if i == 0 else ("end" if i == 4 else "middle")
        parts.append(f'<text class="axis" x="{x(when):.1f}" y="{height - 8}" text-anchor="{anchor}">{when:%d %b}</text>')
    if floor is not None:
        fy = y(floor)
        parts.append(f'<line class="reference" x1="{left}" x2="{width - right}" y1="{fy:.1f}" y2="{fy:.1f}"/>')
        parts.append(f'<text class="axis" x="{width - right + 8}" y="{fy + 4:.1f}">floor {float(floor):,.2f}</text>')
    visible = [p for p in points if p.effective_at >= start]
    before = [p for p in points if p.effective_at < start]
    series = ([type("P", (), {"effective_at": start, "price": before[-1].price})()] if before else []) + visible
    path, segments = [], []
    for i, point in enumerate(series):
        px, py = x(point.effective_at), y(point.price)
        nxt = series[i + 1].effective_at if i + 1 < len(series) else now
        path.append(f'{"M" if i == 0 else "L"}{px:.1f},{py:.1f} L{x(nxt):.1f},{py:.1f}')
        segments.append((px, x(nxt), py, point, nxt))
    parts.append(f'<path class="series" d="{" ".join(path)}"/>')
    for px, nx, _py, point, nxt in segments:
        label = f"{currency} {float(point.price):,.2f} from {point.effective_at:%d %b %Y %H:%M} to {nxt:%d %b %Y %H:%M}"
        parts.append(f'<rect class="hit" x="{px:.1f}" y="{top}" width="{max(nx - px, 6):.1f}" '
                     f'height="{height - top - bottom}" data-tip="{label}"><title>{label}</title></rect>')
    for px, _nx, py, _point, _nxt in segments[1:]:
        parts.append(f'<circle class="marker" cx="{px:.1f}" cy="{py:.1f}" r="4"/>')
    last = series[-1]
    parts.append(f'<circle class="marker" cx="{x(now):.1f}" cy="{y(last.price):.1f}" r="4"/>')
    parts.append(f'<text class="endlabel" x="{x(now) + 8:.1f}" y="{y(last.price) - 8:.1f}">{float(last.price):,.2f}</text>')
    parts.append("</svg>")
    return mark_safe("".join(parts))


@register.simple_tag
def bar_width(value, maximum):
    amount, top = _dec(value), _dec(maximum)
    if amount is None or not top or top <= 0:
        return 0
    return max(0, min(100, round(float(amount / top) * 100, 1)))
