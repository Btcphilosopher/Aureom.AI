from django.contrib import admin

from .models import InventoryMovement, InventoryPosition, SalesObservation


@admin.register(InventoryPosition)
class InventoryPositionAdmin(admin.ModelAdmin):
    list_display = ("variant", "location", "on_hand", "reserved", "inbound", "clearance_date", "as_of")
    list_filter = ("location",)
    search_fields = ("variant__sku",)


@admin.register(InventoryMovement)
class InventoryMovementAdmin(admin.ModelAdmin):
    list_display = ("occurred_at", "variant", "location", "kind", "quantity", "reference")
    list_filter = ("kind", "location")


@admin.register(SalesObservation)
class SalesObservationAdmin(admin.ModelAdmin):
    list_display = ("period_start", "variant", "channel", "units_sold", "unit_price", "exposed_price", "stockout", "is_synthetic")
    list_filter = ("channel", "stockout", "is_synthetic")
    search_fields = ("variant__sku",)
