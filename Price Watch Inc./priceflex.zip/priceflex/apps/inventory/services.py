from __future__ import annotations

import uuid
from datetime import datetime, timedelta

from django.db import transaction
from django.db.models import Q

from apps.accounts.permissions import require
from apps.audit.services import record
from apps.catalogue.importing import ImportResult, Lookups, RowErrors
from engine.types import InventoryInput, SalesPeriod

from .models import InventoryMovement, InventoryPosition, SalesObservation


def positions_for(variant, channel):
    """Positions at locations that fulfil ``channel`` (a location with no channels serves all)."""
    return InventoryPosition.objects.filter(variant=variant).filter(
        Q(location__channels=channel) | Q(location__channels__isnull=True)
    ).select_related("location").distinct()


def inventory_input(variant, channel) -> InventoryInput | None:
    positions = list(positions_for(variant, channel))
    if not positions:
        return None
    lead = [p.replenishment_lead_time_days for p in positions if p.replenishment_lead_time_days is not None]
    oldest = [p.oldest_stock_received_at for p in positions if p.oldest_stock_received_at and p.on_hand > 0]
    clearance = [p.clearance_date for p in positions if p.clearance_date]
    return InventoryInput(
        on_hand=sum(p.on_hand for p in positions), reserved=sum(p.reserved for p in positions),
        inbound=sum(p.inbound for p in positions),
        replenishment_lead_time_days=min(lead) if lead else None,
        oldest_stock_received_at=min(oldest) if oldest else None,
        clearance_date=min(clearance) if clearance else None,
        as_of=min(p.as_of for p in positions),  # the stalest location decides freshness
        locations=tuple({"location": p.location.code, "on_hand": p.on_hand, "reserved": p.reserved,
                         "inbound": p.inbound, "as_of": p.as_of.isoformat()} for p in sorted(positions, key=lambda p: p.location.code)),
    )


def sales_periods(variant, channel, at: datetime, lookback_days: int) -> tuple[SalesPeriod, ...]:
    since = at.date() - timedelta(days=lookback_days)
    rows = SalesObservation.objects.filter(variant=variant, channel=channel, period_start__gte=since,
                                           period_start__lt=at.date()).order_by("period_start")
    return tuple(SalesPeriod(day=r.period_start, units=r.units_sold, stockout=r.stockout,
                             promotion=r.promotion_active, price=r.exposed_price or r.unit_price,
                             days=(r.period_end - r.period_start).days + 1) for r in rows)


def import_inventory(membership, rows: list[dict], *, source: str = "import") -> ImportResult:
    require(membership, "import_data")
    org = membership.organisation
    result = ImportResult(kind="inventory", batch=uuid.uuid4().hex[:12], received=len(rows))
    lookups = Lookups(org)
    with transaction.atomic():
        for index, row in enumerate(rows, start=1):
            errors = RowErrors()
            variant = lookups.variant(row, errors)
            location = lookups.location(row, errors)
            on_hand = errors.integer(row, "on_hand", required=True)
            reserved = errors.integer(row, "reserved")
            inbound = errors.integer(row, "inbound")
            lead = errors.integer(row, "replenishment_lead_time_days", default=None)
            received = errors.when(row, "oldest_stock_received_at")
            clearance = errors.day(row, "clearance_date")
            as_of = errors.when(row, "as_of", required=True)
            if errors:
                result.reject(index, row, list(errors))
                continue
            existing = InventoryPosition.objects.select_for_update().filter(variant=variant, location=location).first()
            if existing and existing.as_of > as_of:
                result.reject(index, row, [f"as_of is older than the stored position ({existing.as_of.isoformat()})"])
                continue
            before = existing.on_hand if existing else 0
            values = dict(on_hand=on_hand, reserved=reserved, inbound=inbound, replenishment_lead_time_days=lead,
                          oldest_stock_received_at=received, clearance_date=clearance, as_of=as_of,
                          source=str(row.get("source") or source)[:200])
            if existing:
                for k, v in values.items():
                    setattr(existing, k, v)
                existing.save()
                result.updated += 1
            else:
                InventoryPosition.objects.create(variant=variant, location=location, **values)
                result.created += 1
            if on_hand != before:
                InventoryMovement.objects.create(variant=variant, location=location, kind="adjustment",
                                                 quantity=on_hand - before, occurred_at=as_of,
                                                 reference=f"import:{result.batch}")
        record(org, membership.user, "inventory.import", None,
               f"Inventory import {result.batch}: {result.created} created, {result.updated} updated, "
               f"{len(result.rejected)} rejected", {"batch": result.batch, "rejected": result.rejected[:50]})
    return result


def import_sales(membership, rows: list[dict], *, source: str = "import", synthetic: bool = False) -> ImportResult:
    require(membership, "import_data")
    org = membership.organisation
    result = ImportResult(kind="sales", batch=uuid.uuid4().hex[:12], received=len(rows))
    lookups = Lookups(org)
    with transaction.atomic():
        for index, row in enumerate(rows, start=1):
            errors = RowErrors()
            variant = lookups.variant(row, errors)
            channel = lookups.channel(row, errors)
            start = errors.day(row, "period_start", required=True)
            end = errors.day(row, "period_end") or start
            units = errors.integer(row, "units_sold", required=True)
            unit_price = errors.dec(row, "unit_price", default=None, minimum="0.01")
            exposed = errors.dec(row, "exposed_price", default=None, minimum="0.01")
            available = errors.integer(row, "available_units", default=None, minimum=None)
            traffic = errors.integer(row, "traffic", default=None)
            returns = errors.integer(row, "returns_units")
            cancellations = errors.integer(row, "cancellations")
            stockout = errors.boolean(row, "stockout")
            promo = errors.boolean(row, "promotion_active")
            if start and end and end < start:
                errors.append("period_end cannot be before period_start")
            if units and unit_price is None:
                errors.append("unit_price is required when units were sold")
            if errors:
                result.reject(index, row, list(errors))
                continue
            _, created = SalesObservation.objects.update_or_create(
                variant=variant, channel=channel, period_start=start,
                defaults=dict(organisation=org, period_end=end, units_sold=units, unit_price=unit_price,
                              exposed_price=exposed, available_units=available, stockout=stockout,
                              promotion_active=promo, traffic=traffic, returns_units=returns,
                              cancellations=cancellations, is_synthetic=synthetic or errors.boolean(row, "is_synthetic"),
                              source=str(row.get("source") or source)[:200]),
            )
            result.created += 1 if created else 0
            result.updated += 0 if created else 1
        record(org, membership.user, "sales.import", None,
               f"Sales import {result.batch}: {result.created} created, {result.updated} updated, "
               f"{len(result.rejected)} rejected", {"batch": result.batch, "rejected": result.rejected[:50]})
    return result
