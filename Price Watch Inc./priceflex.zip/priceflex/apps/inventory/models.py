from django.db import models


class InventoryPosition(models.Model):
    variant = models.ForeignKey("catalogue.ProductVariant", on_delete=models.CASCADE, related_name="inventory_positions")
    location = models.ForeignKey("catalogue.Location", on_delete=models.CASCADE, related_name="inventory_positions")
    on_hand = models.IntegerField()
    reserved = models.IntegerField(default=0)
    inbound = models.IntegerField(default=0)
    replenishment_lead_time_days = models.PositiveIntegerField(null=True, blank=True)
    oldest_stock_received_at = models.DateTimeField(null=True, blank=True)
    clearance_date = models.DateField(null=True, blank=True)
    as_of = models.DateTimeField(help_text="When this position was true at source")
    source = models.CharField(max_length=200, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["variant", "location"], name="uniq_inventory_position")]

    def __str__(self) -> str:
        return f"{self.variant.sku} @ {self.location.code}: {self.on_hand}"


class InventoryMovement(models.Model):
    class Kind(models.TextChoices):
        RECEIPT = "receipt", "Receipt"
        SALE = "sale", "Sale"
        RETURN = "return", "Return"
        ADJUSTMENT = "adjustment", "Adjustment (import delta)"
        TRANSFER = "transfer", "Transfer"

    variant = models.ForeignKey("catalogue.ProductVariant", on_delete=models.CASCADE, related_name="inventory_movements")
    location = models.ForeignKey("catalogue.Location", on_delete=models.CASCADE, related_name="inventory_movements")
    kind = models.CharField(max_length=16, choices=Kind.choices)
    quantity = models.IntegerField(help_text="Signed change to on-hand stock")
    occurred_at = models.DateTimeField(db_index=True)
    reference = models.CharField(max_length=120, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-occurred_at", "-id"]


class SalesObservation(models.Model):
    """Realised sales for a variant on a channel over a period (normally one day).

    ``unit_price`` is the actual average transaction price paid, which can
    differ from the displayed price (``exposed_price``) because of quotes,
    order-level promotions or orders placed before a price change.
    """

    organisation = models.ForeignKey("accounts.Organisation", on_delete=models.CASCADE, related_name="sales")
    variant = models.ForeignKey("catalogue.ProductVariant", on_delete=models.CASCADE, related_name="sales")
    channel = models.ForeignKey("catalogue.Channel", on_delete=models.CASCADE, related_name="sales")
    period_start = models.DateField(db_index=True)
    period_end = models.DateField(help_text="Inclusive")
    units_sold = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True,
                                     help_text="Actual average transaction price (customer price)")
    exposed_price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True,
                                        help_text="Price displayed during the period")
    available_units = models.IntegerField(null=True, blank=True)
    stockout = models.BooleanField(default=False, help_text="Stock was unavailable for some or all of the period")
    promotion_active = models.BooleanField(default=False)
    traffic = models.PositiveIntegerField(null=True, blank=True)
    returns_units = models.PositiveIntegerField(default=0)
    cancellations = models.PositiveIntegerField(default=0)
    is_synthetic = models.BooleanField(default=False, help_text="Generated demo data, not real transactions")
    source = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ["-period_start"]
        constraints = [models.UniqueConstraint(fields=["variant", "channel", "period_start"], name="uniq_sales_period")]
