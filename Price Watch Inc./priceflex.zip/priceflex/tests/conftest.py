"""Shared builders and fixtures.

``engine_*`` helpers build plain engine inputs (no database). The ``world``
fixture builds a small organisation in PostgreSQL for the Django tests.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal as D
from types import SimpleNamespace

import pytest

from engine.money import CostInputs, TaxConfig
from engine.types import CompetitorObservation, EvaluationInput, InventoryInput, PricePoint

NOW = datetime(2026, 11, 24, 12, 0, tzinfo=UTC)


def pytest_configure(config):
    # WhiteNoise warns when collectstatic has not been run; irrelevant to the tests.
    config.addinivalue_line("filterwarnings", "ignore:No directory at:UserWarning")

BASE_POLICY = {
    "strategy_order": ["margin_led"],
    "min_contribution_margin": "0.12",
    "target_contribution_margin": "0.25",
}


def make_cost(**overrides) -> CostInputs:
    values = dict(
        currency="GBP", acquisition_cost=D("30.00"), freight_landed=D("1.50"), packaging=D("0.50"),
        fulfilment=D("2.00"), fee_percent=D("0.029"), fee_fixed=D("0.30"), expected_return_rate=D("0.05"),
        cost_per_return=D("6.00"), effective_from=(NOW - timedelta(days=30)).isoformat(),
    )
    values.update(overrides)
    return CostInputs(**values)


def make_tax(rate: str = "0.20", inclusive: bool = True) -> TaxConfig:
    return TaxConfig(D(rate), inclusive, "GB", "standard", "test")


def make_obs(obs_id="1", supplier="TechHaven", *, item="54.00", delivery="3.99", total="auto", hours_ago=3,
             now=NOW, **overrides) -> CompetitorObservation:
    item_d = None if item is None else D(item)
    delivery_d = None if delivery is None else D(delivery)
    if total == "auto":
        total_d = None if (item_d is None or delivery_d is None) else item_d + delivery_d
    else:
        total_d = None if total is None else D(total)
    values = dict(
        observation_id=str(obs_id), supplier=supplier, variant_match="exact", condition="new", item_price=item_d,
        delivery_charge=delivery_d, mandatory_charges=D("0"), charges_complete=total_d is not None,
        comparable_total=total_d, currency="GBP", availability="in_stock", membership_required=False,
        observed_at=now - timedelta(hours=hours_ago), match_confidence=D("0.95"), match_status="confirmed",
        listing_key=f"{supplier}-{obs_id}",
    )
    values.update(overrides)
    return CompetitorObservation(**values)


def make_input(policy: dict | None = None, **overrides) -> EvaluationInput:
    values = dict(
        evaluation_time=NOW, product_id="1", variant_id="1", sku="SKU-1", product_name="Test product",
        category="audio", condition="new", channel="web", region="GB", currency="GBP",
        policy=policy if policy is not None else dict(BASE_POLICY), policy_version="test@v1",
        current_price=D("59.99"), standard_retail_price=D("64.99"), customer_delivery_charge=D("3.99"),
        cost=make_cost(), tax=make_tax(),
        inventory=InventoryInput(on_hand=100, as_of=NOW - timedelta(hours=1), replenishment_lead_time_days=14),
        price_history=(PricePoint(NOW - timedelta(days=90), D("59.99")),),
    )
    values.update(overrides)
    return EvaluationInput(**values)


def policy_with(**overrides) -> dict:
    cfg = dict(BASE_POLICY)
    cfg.update(overrides)
    return cfg


# --------------------------------------------------------------------------- Django world

WORLD_POLICY = {
    "strategy_order": ["competitor_aware", "margin_led"],
    "min_contribution_margin": "0.12",
    "target_contribution_margin": "0.20",
    "max_change_pct_per_evaluation": "0.10",
    "price_endings": ["0.99"],
    "competitor": {"basis": "delivered_total", "position": "match_lowest", "on_no_eligible": "skip",
                   "max_observation_age_hours": 48, "min_match_confidence": "0.85"},
}


def build_world(slug: str = "acme"):
    from django.contrib.auth import get_user_model
    from django.utils import timezone as dj_tz

    from apps.accounts.models import Membership, Organisation
    from apps.catalogue.models import Channel, ChannelListing, Location, Product, ProductVariant
    from apps.costs.models import CostVersion, TaxRule
    from apps.inventory.models import InventoryPosition
    from apps.policies.services import save_policy
    from apps.publishing.mock_storefront import MockStorefront
    from apps.publishing.models import PriceHistory

    now = dj_tz.now()
    org = Organisation.objects.create(name=f"{slug} ltd", slug=slug, base_currency="GBP")
    web = Channel.objects.create(organisation=org, code="web", name="Web", kind="web", region="GB", currency="GBP",
                                 customer_delivery_charge=D("3.99"))
    market = Channel.objects.create(organisation=org, code="marketplace", name="Marketplace", kind="marketplace",
                                    region="GB", currency="GBP", customer_delivery_charge=D("0.00"))
    location = Location.objects.create(organisation=org, code="dc", name="DC", region="GB")
    TaxRule.objects.create(organisation=org, region="GB", tax_category="standard", rate=D("0.2000"),
                           prices_include_tax=True, effective_from=now - timedelta(days=400), source="test")
    User = get_user_model()
    members = {}
    for username, roles in (("analyst", ["analyst"]), ("editor", ["policy_editor"]), ("approver", ["approver"]),
                            ("publisher", ["publisher"]), ("admin", ["admin"])):
        user = User.objects.create_user(username=f"{slug}-{username}", password="pw-not-used-12345")
        members[username] = Membership.objects.create(user=user, organisation=org, roles=roles)
    limited_user = User.objects.create_user(username=f"{slug}-limited", password="pw-not-used-12345")
    limited = Membership.objects.create(user=limited_user, organisation=org, roles=["analyst", "approver", "publisher"])
    limited.channels.set([market])
    members["limited"] = limited

    version = save_policy(members["editor"], code="core", name="Core", config=WORLD_POLICY)
    product = Product.objects.create(organisation=org, code="widget", name="Widget", brand="Acme", category="audio")
    variant = ProductVariant.objects.create(organisation=org, product=product, sku="WID-1", name="Widget one",
                                            gtin="5060999000011", mpn="WID-1")
    listings = {}
    for channel in (web, market):
        listing = ChannelListing.objects.create(variant=variant, channel=channel, policy=version.policy,
                                                standard_retail_price=D("64.99"), confirmed_price=D("59.99"),
                                                confirmed_at=now - timedelta(days=120), price_version=1)
        PriceHistory.objects.create(listing=listing, price=D("59.99"), effective_at=now - timedelta(days=120),
                                    kind="initial")
        MockStorefront.seed_price(channel.code, variant.sku, D("59.99"))
        listings[channel.code] = listing
    cost = CostVersion.objects.create(
        organisation=org, variant=variant, currency="GBP", acquisition_cost=D("30"), freight_landed=D("1.5"),
        packaging=D("0.5"), fulfilment=D("2"), fee_percent=D("0.029"), fee_fixed=D("0.30"),
        expected_return_rate=D("0.05"), cost_per_return=D("6"), effective_from=now - timedelta(days=60), source="test")
    InventoryPosition.objects.create(variant=variant, location=location, on_hand=100, as_of=now - timedelta(hours=1),
                                     replenishment_lead_time_days=14)
    return SimpleNamespace(org=org, web=web, marketplace=market, location=location, members=members,
                           policy=version.policy, policy_version=version, product=product, variant=variant,
                           listing=listings["web"], market_listing=listings["marketplace"], cost=cost, now=now)


def add_observation(world, *, item="55.00", delivery="3.99", hours_ago=2, supplier="TechHaven", ext_id=None, **extra):
    from django.utils import timezone as dj_tz

    from apps.competitors.models import CompetitorObservation as Obs

    item_d, delivery_d = D(item), D(delivery)
    values = dict(
        organisation=world.org, variant=world.variant, source="test", supplier=supplier,
        external_observation_id=ext_id or f"{supplier}-{item}-{hours_ago}", external_listing_id=f"{supplier}-listing",
        variant_match="exact", condition="new", item_price=item_d, delivery_charge=delivery_d,
        mandatory_charges=D("0"), charges_complete=True, comparable_total=item_d + delivery_d, currency="GBP",
        availability="in_stock", observed_at=dj_tz.now() - timedelta(hours=hours_ago), match_confidence=D("0.95"),
        match_status="confirmed",
    )
    values.update(extra)
    return Obs.objects.create(**values)


@pytest.fixture
def world(db):
    return build_world()


@pytest.fixture
def approved_rec(world):
    """A change recommendation (59.99 -> 54.99) approved and ready to publish on the web listing."""
    from apps.recommendations import services as recs

    add_observation(world)  # delivered total 58.99 -> item target 55.00 -> 54.99
    run = recs.run_pricing(world.members["analyst"], channel=world.web)
    rec = run.recommendations.get(listing=world.listing)
    assert rec.status == "awaiting_approval", rec.reasons
    return recs.approve(world.members["approver"], rec)
