"""Concurrent publications against real PostgreSQL row locks."""

import threading
from decimal import Decimal as D

import pytest
from django.db import connection

from apps.accounts.models import Membership
from apps.publishing import services as publishing
from apps.publishing.models import MockStorefrontPrice, MockStorefrontRequest, PriceHistory, PublicationAttempt
from apps.recommendations import services as recs
from apps.recommendations.models import PriceRecommendation
from apps.recommendations.workflow import WorkflowError

from .conftest import add_observation, build_world

pytestmark = pytest.mark.django_db(transaction=True)

EXPECTED_REFUSALS = {"publication_in_progress", "stale_price_version", "invalid_state"}


def _publish(rec_id: int, membership_id: int, barrier: threading.Barrier, results: list) -> None:
    try:
        membership = Membership.objects.select_related("organisation", "user").get(pk=membership_id)
        rec = PriceRecommendation.objects.select_related("listing", "listing__channel").get(pk=rec_id)
        barrier.wait(timeout=15)
        attempt = publishing.publish(membership, rec)
        results.append(("published", attempt.status))
    except WorkflowError as exc:
        results.append(("refused", exc.code))
    except Exception as exc:  # noqa: BLE001 - any other outcome fails the test with its detail
        results.append(("error", repr(exc)))
    finally:
        connection.close()


def _race(rec_ids, membership_id):
    barrier = threading.Barrier(len(rec_ids))
    results: list = []
    threads = [threading.Thread(target=_publish, args=(rec_id, membership_id, barrier, results)) for rec_id in rec_ids]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=60)
    assert all(not t.is_alive() for t in threads), "publication threads deadlocked"
    return sorted(results)


def _approved(world):
    run = recs.run_pricing(world.members["analyst"], channel=world.web)
    return recs.approve(world.members["approver"], run.recommendations.get(listing=world.listing))


def _assert_exactly_one_change(world, results):
    assert [r for r in results if r[0] == "error"] == []
    assert results.count(("published", "verified")) == 1, results
    refused = [code for kind, code in results if kind == "refused"]
    assert len(refused) == len(results) - 1 and set(refused) <= EXPECTED_REFUSALS, results
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("54.99") and world.listing.price_version == 2
    assert PriceHistory.objects.filter(listing=world.listing, kind="publish").count() == 1
    assert PublicationAttempt.objects.filter(listing=world.listing, status="verified").count() == 1
    assert not PublicationAttempt.objects.filter(listing=world.listing, status__in=["pending", "sent", "uncertain"]).exists()
    assert MockStorefrontPrice.objects.get(channel_code="web", sku="WID-1").version == 2
    assert MockStorefrontRequest.objects.count() == 1


@pytest.mark.parametrize("round_number", range(3))
def test_two_approved_recommendations_published_at_once_change_the_price_once(transactional_db, round_number):
    world = build_world(f"race{round_number}")
    add_observation(world)
    first, second = _approved(world), _approved(world)
    assert first.status == second.status == "approved" and first.pk != second.pk
    results = _race([first.pk, second.pk], world.members["publisher"].pk)
    _assert_exactly_one_change(world, results)
    statuses = set(PriceRecommendation.objects.filter(pk__in=[first.pk, second.pk]).values_list("status", flat=True))
    assert statuses == {"verified", "superseded"}


def test_the_same_recommendation_published_three_times_at_once_is_sent_once(transactional_db):
    world = build_world("triple")
    add_observation(world)
    rec = _approved(world)
    results = _race([rec.pk, rec.pk, rec.pk], world.members["publisher"].pk)
    _assert_exactly_one_change(world, results)
    assert PublicationAttempt.objects.filter(recommendation=rec).count() == 1
