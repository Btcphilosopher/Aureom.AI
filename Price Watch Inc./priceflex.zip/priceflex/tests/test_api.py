"""API v1: authentication, ownership, validation, pagination, idempotency, concurrency and errors."""

import json
from datetime import timedelta
from decimal import Decimal as D

import pytest
from django.contrib.auth import get_user_model
from django.utils import timezone
from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient

from apps.accounts.models import Membership
from apps.costs.models import CostVersion
from apps.policies.models import PricingPolicy
from apps.publishing.models import PublicationAttempt
from apps.recommendations import services as recs
from apps.recommendations.models import PricingRun

from .conftest import WORLD_POLICY, add_observation, build_world

pytestmark = pytest.mark.django_db


def client_for(membership, *, token=False) -> APIClient:
    client = APIClient()
    if token:
        key = Token.objects.create(user=membership.user).key
        client.credentials(HTTP_AUTHORIZATION=f"Token {key}")
    else:
        client.force_authenticate(membership.user)
    return client


def post(client, path, body, **headers):
    return client.post(path, data=json.dumps(body), content_type="application/json", **headers)


def error(response):
    assert set(response.json()) == {"error"}
    assert set(response.json()["error"]) == {"code", "message", "details"}
    return response.json()["error"]


@pytest.fixture
def pending(world):
    add_observation(world)
    run = recs.run_pricing(world.members["analyst"], channel=world.web)
    return run.recommendations.get(listing=world.listing)


# ------------------------------------------------------------------ authentication and ownership


@pytest.mark.parametrize("method,path", [
    ("get", "/api/v1/recommendations"), ("get", "/api/v1/policies"), ("post", "/api/v1/pricing-runs"),
    ("post", "/api/v1/cost-imports"), ("post", "/api/v1/publications"), ("get", "/api/v1/products/1/price-history"),
])
def test_every_endpoint_requires_authentication(db, method, path):
    response = getattr(APIClient(), method)(path)
    assert response.status_code == 401
    assert error(response)["code"] == "not_authenticated"


def test_token_authentication(world, pending):
    response = client_for(world.members["analyst"], token=True).get("/api/v1/recommendations")
    assert response.status_code == 200 and response.json()["count"] == 1
    bad = APIClient()
    bad.credentials(HTTP_AUTHORIZATION="Token not-a-real-token")
    assert bad.get("/api/v1/recommendations").status_code == 401


def test_other_organisations_data_is_unreachable(world, pending):
    other = build_world("other")
    outsider = client_for(other.members["admin"])
    assert outsider.get(f"/api/v1/recommendations/{pending.pk}").status_code == 404
    assert error(post(outsider, f"/api/v1/recommendations/{pending.pk}/approve", {}))["code"] == "not_found"
    assert outsider.get("/api/v1/recommendations").json()["count"] == 0
    assert outsider.get(f"/api/v1/products/{world.product.pk}/price-history").status_code == 404
    response = post(outsider, "/api/v1/publications", {"recommendation_id": pending.pk}, HTTP_IDEMPOTENCY_KEY="outsider-key-1")
    assert response.status_code == 404
    pending.refresh_from_db()
    assert pending.status == "awaiting_approval"


def test_user_without_membership_is_forbidden(world):
    stranger = get_user_model().objects.create_user("stranger", password="pw-not-used-12345")
    client = APIClient()
    client.force_authenticate(stranger)
    response = client.get("/api/v1/recommendations")
    assert response.status_code == 403 and error(response)["code"] == "permission_denied"


def test_member_of_several_organisations_must_name_one(world, pending):
    other = build_world("other")
    user = world.members["analyst"].user
    Membership.objects.create(user=user, organisation=other.org, roles=["analyst"])
    client = APIClient()
    client.force_authenticate(user)
    assert error(client.get("/api/v1/recommendations"))["code"] == "organisation_required"
    assert client.get("/api/v1/recommendations", HTTP_X_ORGANISATION="acme").json()["count"] == 1
    assert client.get("/api/v1/recommendations", HTTP_X_ORGANISATION="other").json()["count"] == 0
    assert client.get("/api/v1/recommendations", HTTP_X_ORGANISATION="nope").status_code == 403


def test_channel_limited_member_only_sees_their_channels(world, pending):
    limited = client_for(world.members["limited"])
    assert limited.get("/api/v1/recommendations").json()["count"] == 0
    assert limited.get(f"/api/v1/recommendations/{pending.pk}").status_code == 404
    assert post(limited, f"/api/v1/recommendations/{pending.pk}/approve", {}).status_code == 404
    response = post(limited, "/api/v1/pricing-runs", {"channel": "web"})
    assert response.status_code == 403 and error(response)["code"] == "channel_denied"


# ------------------------------------------------------------------ recommendations


def test_recommendation_document_and_detail(world, pending):
    client = client_for(world.members["analyst"])
    listing = client.get("/api/v1/recommendations").json()
    assert set(listing) == {"count", "next", "previous", "results"}
    doc = listing["results"][0]
    for key in ("product_id", "channel", "currency", "current_customer_price", "recommended_customer_price", "status",
                "input_snapshot_id", "policy_version", "reasons", "constraints_applied", "warnings"):
        assert key in doc
    assert (doc["current_customer_price"], doc["recommended_customer_price"]) == ("59.99", "54.99")
    assert doc["status"] == "awaiting_approval" and doc["policy_version"] == "core@v1" and doc["currency"] == "GBP"
    assert doc["constraints_applied"] == ["price_ending"]
    detail = client.get(f"/api/v1/recommendations/{pending.pk}?verify=true").json()
    assert detail["reproducibility"]["reproducible"] is True
    assert detail["comparables"]["eligible_count"] == 1 and detail["comparables"]["basis"] == "delivered_total"
    assert detail["margin_current"]["contribution"] == "13.65"
    assert detail["projection"]["label"].startswith("PROJECTION")
    assert [p["strategy"] for p in detail["selection_trace"]] == ["competitor_aware", "margin_led"]
    assert detail["approved_customer_price"] is None and detail["confirmed_published_price"] == "59.99"


def test_recommendation_filters_and_pagination(world, pending):
    market = recs.run_pricing(world.members["analyst"], channel=world.marketplace).recommendations.get()
    assert market.recommended_price == D("58.99")  # no delivery charge on this channel, so the full 58.99 total applies
    recs.reject(world.members["approver"], market, comment="Marketplace price stays")
    client = client_for(world.members["analyst"])

    def count(query):
        return client.get(f"/api/v1/recommendations?{query}").json()["count"]

    assert count("") == 2
    assert count("status=awaiting_approval") == 1 and count("status=rejected") == 1 and count("status=verified") == 0
    assert count("status=awaiting_approval,rejected") == 2
    assert count("outcome=change") == 2 and count("outcome=blocked") == 0
    assert count("channel=web") == 1 and count("channel=marketplace") == 1
    assert count("sku=WID-1") == 2 and count("sku=OTHER") == 0
    assert count(f"product={world.product.pk}") == 2 and count("policy=core") == 2 and count("policy=other") == 0
    assert count("has_warnings=true") == 0 and count("has_warnings=false") == 2
    assert count(f"run={pending.run_id}") == 1
    page = client.get("/api/v1/recommendations?page_size=1").json()
    assert page["count"] == 2 and len(page["results"]) == 1 and page["next"] and page["previous"] is None
    assert len(client.get("/api/v1/recommendations?page_size=1&page=2").json()["results"]) == 1
    assert client.get("/api/v1/recommendations?page=9").status_code == 404
    bad = client.get("/api/v1/recommendations?product=abc")
    assert bad.status_code == 422 and error(bad)["code"] == "validation_error"


def test_approve_and_reject_through_the_api(world, pending):
    analyst, approver = client_for(world.members["analyst"]), client_for(world.members["approver"])
    denied = post(analyst, f"/api/v1/recommendations/{pending.pk}/approve", {})
    assert denied.status_code == 403 and error(denied)["code"] == "permission_denied"
    stale = post(approver, f"/api/v1/recommendations/{pending.pk}/approve", {"expected_status": "evaluated"})
    assert stale.status_code == 409 and error(stale)["code"] == "conflict"
    below = post(approver, f"/api/v1/recommendations/{pending.pk}/approve",
                 {"approved_price": "39.99", "comment": "undercut"})
    assert below.status_code == 422 and error(below)["code"] == "constraint_violation"
    assert error(below)["details"]["violations"][0]["name"] == "minimum_contribution_margin"
    bad_price = post(approver, f"/api/v1/recommendations/{pending.pk}/approve", {"approved_price": "cheap"})
    assert bad_price.status_code == 422
    ok = post(approver, f"/api/v1/recommendations/{pending.pk}/approve", {"comment": "fine"})
    assert ok.status_code == 200
    assert ok.json()["status"] == "approved" and ok.json()["approved_customer_price"] == "54.99"
    assert ok.json()["decisions"][0]["decided_by"] == world.members["approver"].user.username
    again = post(approver, f"/api/v1/recommendations/{pending.pk}/approve", {})
    assert again.status_code == 409 and error(again)["code"] == "invalid_state"
    reject = post(approver, f"/api/v1/recommendations/{pending.pk}/reject", {"comment": "changed my mind"})
    assert reject.status_code == 409


def test_reject_requires_a_reason(world, pending):
    approver = client_for(world.members["approver"])
    missing = post(approver, f"/api/v1/recommendations/{pending.pk}/reject", {})
    assert missing.status_code == 422 and error(missing)["code"] == "reason_required"
    done = post(approver, f"/api/v1/recommendations/{pending.pk}/reject", {"comment": "Not this week"})
    assert done.status_code == 200 and done.json()["status"] == "rejected"


# ------------------------------------------------------------------ idempotency


def test_idempotency_key_replays_the_original_response(world):
    add_observation(world)
    client = client_for(world.members["analyst"])
    first = post(client, "/api/v1/pricing-runs", {"channel": "web"}, HTTP_IDEMPOTENCY_KEY="run-key-0001")
    second = post(client, "/api/v1/pricing-runs", {"channel": "web"}, HTTP_IDEMPOTENCY_KEY="run-key-0001")
    assert first.status_code == second.status_code == 201
    assert "Idempotent-Replayed" not in first.headers and second.headers["Idempotent-Replayed"] == "true"
    assert second.json() == first.json()
    assert PricingRun.objects.count() == 1  # the run did not happen twice
    assert first.json()["counts"]["change"] == 1 and first.json()["recommendations"][0]["sku"] == "WID-1"
    reused = post(client, "/api/v1/pricing-runs", {"channel": "marketplace"}, HTTP_IDEMPOTENCY_KEY="run-key-0001")
    assert reused.status_code == 409 and error(reused)["code"] == "idempotency_key_reused"
    invalid = post(client, "/api/v1/pricing-runs", {}, HTTP_IDEMPOTENCY_KEY="short")
    assert invalid.status_code == 400 and error(invalid)["code"] == "invalid_idempotency_key"
    without = post(client, "/api/v1/pricing-runs", {"channel": "web"})
    assert without.status_code == 201 and PricingRun.objects.count() == 2


def test_idempotency_keys_are_scoped_per_organisation(world):
    other = build_world("other")
    a = post(client_for(world.members["analyst"]), "/api/v1/pricing-runs", {}, HTTP_IDEMPOTENCY_KEY="shared-key-01")
    b = post(client_for(other.members["analyst"]), "/api/v1/pricing-runs", {}, HTTP_IDEMPOTENCY_KEY="shared-key-01")
    assert a.status_code == b.status_code == 201 and a.json()["id"] != b.json()["id"]
    assert "Idempotent-Replayed" not in b.headers


def test_failed_request_does_not_consume_the_key(world, pending):
    approver = client_for(world.members["approver"])
    path = f"/api/v1/recommendations/{pending.pk}/reject"
    assert post(approver, path, {}, HTTP_IDEMPOTENCY_KEY="reject-key-01").status_code == 422
    retry = post(approver, path, {"comment": "Not now"}, HTTP_IDEMPOTENCY_KEY="reject-key-02")
    assert retry.status_code == 200


# ------------------------------------------------------------------ publications


def test_publication_requires_idempotency_key_and_is_not_repeated(world, approved_rec):
    publisher = client_for(world.members["publisher"])
    missing = post(publisher, "/api/v1/publications", {"recommendation_id": approved_rec.pk})
    assert missing.status_code == 400 and error(missing)["code"] == "idempotency_key_required"
    assert not PublicationAttempt.objects.exists()
    first = post(publisher, "/api/v1/publications", {"recommendation_id": approved_rec.pk}, HTTP_IDEMPOTENCY_KEY="pub-key-0001")
    assert first.status_code == 201
    body = first.json()
    assert body["status"] == "verified" and body["price"] == "54.99" and body["confirmed_published_price"] == "54.99"
    assert body["recommendation_status"] == "verified" and body["expected_version"] == 1
    assert [o["source"] for o in body["observed_prices"]] == ["pre_publish_check", "publish_readback"]
    replay = post(publisher, "/api/v1/publications", {"recommendation_id": approved_rec.pk}, HTTP_IDEMPOTENCY_KEY="pub-key-0001")
    assert replay.status_code == 201 and replay.headers["Idempotent-Replayed"] == "true" and replay.json()["id"] == body["id"]
    assert PublicationAttempt.objects.count() == 1
    fresh_key = post(publisher, "/api/v1/publications", {"recommendation_id": approved_rec.pk}, HTTP_IDEMPOTENCY_KEY="pub-key-0002")
    assert fresh_key.status_code == 409 and error(fresh_key)["code"] == "invalid_state"
    detail = client_for(world.members["analyst"]).get(f"/api/v1/publications/{body['id']}")
    assert detail.status_code == 200 and detail.json()["storefront_idempotency_key"] == body["storefront_idempotency_key"]


def test_publication_permissions_validation_and_version_precondition(world, approved_rec):
    approver = client_for(world.members["approver"])
    denied = post(approver, "/api/v1/publications", {"recommendation_id": approved_rec.pk}, HTTP_IDEMPOTENCY_KEY="pub-key-0003")
    assert denied.status_code == 403
    publisher = client_for(world.members["publisher"])
    invalid = post(publisher, "/api/v1/publications", {"recommendation_id": "1"}, HTTP_IDEMPOTENCY_KEY="pub-key-0004")
    assert invalid.status_code == 422
    conflict = post(publisher, "/api/v1/publications", {"recommendation_id": approved_rec.pk, "expected_price_version": 7},
                    HTTP_IDEMPOTENCY_KEY="pub-key-0005")
    assert conflict.status_code == 409 and error(conflict)["details"] == {"expected": 7, "current": 1}
    assert not PublicationAttempt.objects.exists()
    ok = post(publisher, "/api/v1/publications", {"recommendation_id": approved_rec.pk, "expected_price_version": 1},
              HTTP_IDEMPOTENCY_KEY="pub-key-0006")
    assert ok.status_code == 201 and ok.json()["status"] == "verified"


def test_price_history_endpoint(world, approved_rec):
    from apps.publishing import services as publishing

    publishing.publish(world.members["publisher"], approved_rec)
    client = client_for(world.members["analyst"])
    body = client.get(f"/api/v1/products/{world.product.pk}/price-history?channel=web").json()
    assert body["count"] == 2
    latest, initial = body["results"]
    assert (latest["kind"], latest["confirmed_published_price"], latest["previous_price"]) == ("publish", "54.99", "59.99")
    assert latest["recommendation_id"] == approved_rec.pk and latest["actor"] == world.members["publisher"].user.username
    assert initial["kind"] == "initial" and initial["confirmed_published_price"] == "59.99"
    assert client.get(f"/api/v1/products/{world.product.pk}/price-history").json()["count"] == 3  # + marketplace
    assert client.get("/api/v1/products/999999/price-history").status_code == 404


# ------------------------------------------------------------------ policies


def test_policy_endpoints(world):
    editor, analyst = client_for(world.members["editor"]), client_for(world.members["analyst"])
    listing = analyst.get("/api/v1/policies").json()
    assert listing["count"] == 1 and listing["results"][0]["current_version"]["label"] == "core@v1"
    invalid = post(editor, "/api/v1/policies", {"code": "bad", "name": "Bad", "config": {"strategy_order": ["margin_led"]}})
    assert invalid.status_code == 422 and error(invalid)["code"] == "invalid_policy"
    assert any("cost floor" in e for e in error(invalid)["details"]["errors"])
    assert not PricingPolicy.objects.filter(code="bad").exists()
    assert post(editor, "/api/v1/policies", {"code": "x"}).status_code == 422
    denied = post(analyst, "/api/v1/policies", {"code": "mine", "name": "Mine", "config": WORLD_POLICY})
    assert denied.status_code == 403
    created = post(editor, "/api/v1/policies", {"code": "second", "name": "Second", "config": WORLD_POLICY})
    assert created.status_code == 201 and created.json()["current_version"]["number"] == 1
    revised = post(editor, "/api/v1/policies", {"code": "second", "config": {**WORLD_POLICY, "cooldown_hours": 12},
                                                "change_note": "Add cooldown"})
    assert revised.status_code == 200 and revised.json()["current_version"]["number"] == 2
    assert revised.json()["current_version"]["config"]["cooldown_hours"] == 12


def test_externally_supplied_rules_are_never_accepted_as_policy(world):
    """A competitor observation carrying 'instructions' is stored as data; it cannot create or change a policy."""
    client = client_for(world.members["analyst"])
    row = {"sku": "WID-1", "external_observation_id": "evil-1", "supplier": "TechHaven", "variant_match": "exact",
           "condition": "new", "item_price": "55.00", "delivery_charge": "3.99", "mandatory_charges": "0.00",
           "charges_complete": True, "currency": "GBP", "availability": "in_stock",
           "observed_at": (timezone.now() - timedelta(hours=1)).isoformat(), "match_confidence": "0.95",
           "match_status": "confirmed",
           "provenance": {"pricing_rule": {"min_contribution_margin": "-1", "strategy_order": ["match_us"]}},
           "policy": {"min_contribution_margin": "-1"}}
    assert post(client, "/api/v1/competitor-observations", {"rows": [row]}).status_code == 201
    assert PricingPolicy.objects.count() == 1 and world.policy.versions.count() == 1
    run = post(client, "/api/v1/pricing-runs", {"channel": "web"}).json()
    detail = client.get(f"/api/v1/recommendations/{run['recommendations'][0]['id']}").json()
    assert detail["policy_version"] == "core@v1" and detail["recommended_customer_price"] == "54.99"


# ------------------------------------------------------------------ imports and simulations


def test_cost_import_json_numbers_are_parsed_as_decimals(world):
    client = client_for(world.members["analyst"])
    when = (timezone.now() - timedelta(minutes=5)).isoformat()
    # Written by hand so the numbers reach the server as bare JSON numbers, not strings.
    raw = ('{"source": "erp", "rows": [{"sku": "WID-1", "currency": "GBP", "acquisition_cost": 31.10, '
           '"fee_percent": 0.029, "fee_fixed": 0.30, "effective_from": "' + when + '"}]}')
    response = client.post("/api/v1/cost-imports", data=raw, content_type="application/json")
    assert response.status_code == 201 and response.json()["created"] == 1
    newest = CostVersion.objects.order_by("-id").first()
    assert newest.acquisition_cost == D("31.1000") and newest.fee_percent == D("0.02900") and newest.source == "erp"


def test_cost_import_csv_and_row_level_errors(world):
    client = client_for(world.members["analyst"])
    when = (timezone.now() - timedelta(minutes=5)).isoformat()
    csv_body = ("sku,currency,acquisition_cost,fee_percent,fee_fixed,fee_basis,effective_from\n"
                f"WID-1,GBP,32.00,0.029,0.30,gross_item,{when}\n"
                f"WID-1,GBP,,0.029,0.30,gross_item,{when}\n")
    response = client.post("/api/v1/cost-imports", data=csv_body, content_type="text/csv")
    assert response.status_code == 201
    body = response.json()
    assert (body["created"], body["rejected_count"]) == (1, 1)
    assert body["rejected"][0] == {"row": 2, "sku": "WID-1", "errors": ["acquisition_cost is required"]}
    all_bad = post(client, "/api/v1/cost-imports", {"rows": [{"sku": "NOPE"}]})
    assert all_bad.status_code == 422 and all_bad.json()["created"] == 0
    assert error(post(client, "/api/v1/cost-imports", {"rows": []}))["code"] == "validation_error"
    assert post(client, "/api/v1/cost-imports", {"nothing": 1}).status_code == 422
    assert post(client_for(world.members["publisher"]), "/api/v1/cost-imports", {"rows": [{"sku": "WID-1"}]}).status_code == 403


def test_inventory_sales_and_competitor_endpoints(world):
    client = client_for(world.members["analyst"])
    inv = post(client, "/api/v1/inventory-imports", {"rows": [
        {"sku": "WID-1", "location": "dc", "on_hand": 70, "as_of": timezone.now().isoformat()}]})
    assert inv.status_code == 201 and inv.json()["updated"] == 1
    sales = post(client, "/api/v1/sales-imports", {"rows": [
        {"sku": "WID-1", "channel": "web", "period_start": "2026-11-20", "units_sold": 2, "unit_price": "59.99"}]})
    assert sales.status_code == 201 and sales.json()["created"] == 1
    pull = post(client, "/api/v1/competitor-observations", {"pull": "pricewatch", "skus": ["WID-1"]})
    assert pull.status_code == 201 and pull.json()["created"] == 3 and pull.json()["kind"] == "competitor_observations"


def test_simulation_endpoint_is_labelled_and_validated(world):
    client = client_for(world.members["analyst"])
    response = post(client, "/api/v1/simulations", {"sku": "WID-1", "channel": "web", "days": 14, "elasticity": "-1.8",
                                                    "base_units_per_day": "5", "seed": 3})
    assert response.status_code == 201
    body = response.json()
    assert body["label"].startswith("SIMULATED") and body["results"]["days"] == 14
    assert [a["key"] for a in body["results"]["arms"]] == ["fixed", "rules", "competitor_aware"]
    assert any(s["key"] == "demand_model" for s in body["results"]["skipped_arms"])
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("59.99") and not PricingRun.objects.exists()  # isolated from live state
    bad = post(client, "/api/v1/simulations", {"sku": "WID-1", "channel": "web", "elasticity": "1.5"})
    assert bad.status_code == 422
    assert post(client, "/api/v1/simulations", {"sku": "WID-1"}).status_code == 422
    assert post(client, "/api/v1/simulations", {"sku": "NOPE", "channel": "web"}).status_code == 404
    assert post(client_for(world.members["publisher"]), "/api/v1/simulations", {"sku": "WID-1", "channel": "web"}).status_code == 403


# ------------------------------------------------------------------ errors and versioning


def test_error_envelope_for_common_failures(world):
    client = client_for(world.members["analyst"])
    assert error(client.get("/api/v1/recommendations/999999"))["code"] == "not_found"
    not_allowed = client.delete("/api/v1/recommendations")
    assert not_allowed.status_code == 405 and error(not_allowed)["code"] == "method_not_allowed"
    malformed = client.post("/api/v1/pricing-runs", data="{not json", content_type="application/json")
    assert malformed.status_code == 400 and error(malformed)["code"] == "parse_error"
    unsupported = client.post("/api/v1/pricing-runs", data="<x/>", content_type="application/xml")
    assert unsupported.status_code == 415 and error(unsupported)["code"] == "unsupported_media_type"
    unknown_channel = post(client, "/api/v1/pricing-runs", {"channel": "nowhere"})
    assert unknown_channel.status_code == 422 and error(unknown_channel)["code"] == "validation_error"


def test_only_v1_exists(world):
    client = client_for(world.members["analyst"])
    assert client.get("/api/v2/recommendations").status_code == 404
    assert client.get("/api/v1/recommendations").status_code == 200
