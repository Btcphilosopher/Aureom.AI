"""Pricing runs, references, reproducibility, approvals, permissions and automation."""

from datetime import timedelta
from decimal import Decimal as D

import pytest
from django.utils import timezone

from apps.accounts.permissions import PermissionDenied, can
from apps.audit.models import AuditEvent
from apps.costs.models import CostVersion
from apps.policies.services import authorise_automation, save_policy
from apps.recommendations import services as recs
from apps.recommendations.models import ApprovalDecision, InputSnapshot, PriceRecommendation
from apps.recommendations.workflow import TRANSITIONS, WorkflowError, transition
from engine import ALGORITHM_VERSION
from engine.policy import PolicyValidationError
from engine.types import snapshot_hash

from .conftest import WORLD_POLICY, add_observation

pytestmark = pytest.mark.django_db


def run_web(world, **kwargs):
    run = recs.run_pricing(world.members["analyst"], channel=world.web, **kwargs)
    return run, run.recommendations.get(listing=world.listing)


def test_every_decision_references_snapshot_policy_version_algorithm_and_time(world):
    add_observation(world)
    run, rec = run_web(world)
    assert rec.outcome == "change" and rec.status == "awaiting_approval"
    assert (rec.current_price, rec.recommended_price) == (D("59.99"), D("54.99"))
    assert rec.approved_price is None and rec.scheduled_price is None  # separate price fields
    assert rec.snapshot.sha256 == snapshot_hash(rec.snapshot.payload)
    assert rec.snapshot.payload["current_price"] == "59.99" and rec.snapshot.payload["policy"] == WORLD_POLICY
    assert rec.policy_version == world.policy_version and rec.snapshot.payload["policy_version"] == "core@v1"
    assert rec.algorithm_version == ALGORITHM_VERSION == run.algorithm_version
    assert rec.evaluated_at == run.evaluation_time
    assert rec.expected_price_version == 1
    assert rec.comparable_set.eligible_count == 1 and rec.comparable_set.lowest == D("58.99")
    assert rec.constraints_applied == ["price_ending"]
    doc = recs.response_document(rec)
    assert doc["input_snapshot_id"] == f"snap_{rec.snapshot_id}" and doc["policy_version"] == "core@v1"
    assert doc["current_customer_price"] == "59.99" and doc["recommended_customer_price"] == "54.99"
    assert doc["status"] == "awaiting_approval" and doc["reasons"] and doc["warnings"] == []
    assert run.counts["change"] == 1 and run.status == "completed"


def test_no_change_is_explained_and_needs_no_approval(world):
    _, rec = run_web(world)
    assert rec.outcome == "no_change" and rec.status == "evaluated" and rec.recommended_price is None
    assert rec.reasons[0].startswith("No price change is recommended")


def test_missing_cost_blocks_and_cannot_be_approved(world):
    CostVersion.objects.all().delete()
    _, rec = run_web(world)
    assert rec.outcome == "blocked" and rec.status == "evaluated" and rec.has_warnings
    assert rec.result["blocking_issues"][0]["code"] == "missing_cost"
    with pytest.raises(WorkflowError) as excinfo:
        recs.approve(world.members["approver"], rec, approved_price=D("59.99"), comment="force it")
    assert excinfo.value.code == "invalid_state"


def test_newer_evaluation_supersedes_older_open_recommendation(world):
    add_observation(world)
    _, first = run_web(world)
    _, second = run_web(world)
    first.refresh_from_db()
    assert first.status == "superseded" and second.status == "awaiting_approval"
    assert first.snapshot_id != second.snapshot_id
    with pytest.raises(WorkflowError):
        recs.approve(world.members["approver"], first)


def test_stored_snapshot_replays_to_the_same_decision_even_after_everything_changes(world):
    add_observation(world)
    _, rec = run_web(world)
    # Change the policy, the cost and the competitor data after the fact.
    save_policy(world.members["editor"], code="core", name="Core", config={**WORLD_POLICY, "price_endings": ["0.49"]})
    CostVersion.objects.create(organisation=world.org, variant=world.variant, currency="GBP",
                               acquisition_cost=D("45"), effective_from=timezone.now(), source="later")
    add_observation(world, item="40.00", supplier="VoltMart")
    check = recs.replay(rec)
    assert check == {**check, "reproducible": True, "snapshot_hash_matches": True, "differing_fields": [],
                     "recomputed_recommended_price": "54.99"}
    assert rec.policy_version.number == 1  # the decision still points at the policy version it used
    _, newer = run_web(world)
    assert newer.policy_version.number == 2 and newer.snapshot.payload["policy"]["price_endings"] == ["0.49"]


def test_tampered_snapshot_is_detected(world):
    add_observation(world)
    _, rec = run_web(world)
    payload = dict(rec.snapshot.payload, current_price="10.00")
    InputSnapshot.objects.filter(pk=rec.snapshot_id).update(payload=payload)
    rec.refresh_from_db()
    check = recs.replay(rec)
    assert not check["reproducible"] and not check["snapshot_hash_matches"]
    with pytest.raises(RuntimeError):
        rec.snapshot.save()  # snapshots are immutable through the model


def test_policy_versions_are_immutable_and_validated(world):
    with pytest.raises(RuntimeError):
        world.policy_version.save()
    with pytest.raises(PolicyValidationError) as excinfo:
        save_policy(world.members["editor"], code="core", name="Core", config={"strategy_order": ["margin_led"]})
    assert any("cost floor" in e for e in excinfo.value.errors)
    assert world.policy.versions.count() == 1
    same = save_policy(world.members["editor"], code="core", name="Core", config=WORLD_POLICY)
    assert same == world.policy_version  # identical config does not create a new version
    with pytest.raises(PermissionDenied):
        save_policy(world.members["analyst"], code="core", name="Core", config=WORLD_POLICY)
    assert AuditEvent.objects.filter(action="policy.version_created").count() == 1


# ------------------------------------------------------------------ permissions


def test_role_matrix(world):
    m = world.members
    assert can(m["analyst"], "run_pricing") and not can(m["analyst"], "approve") and not can(m["analyst"], "publish")
    assert can(m["approver"], "approve") and not can(m["approver"], "publish") and not can(m["approver"], "edit_policy")
    assert can(m["publisher"], "publish") and not can(m["publisher"], "approve") and not can(m["publisher"], "run_pricing")
    assert can(m["editor"], "edit_policy") and not can(m["editor"], "approve")
    assert all(can(m["admin"], p) for p in ("approve", "publish", "edit_policy", "administer", "import_data"))
    assert not can(None, "view")


def test_analyst_cannot_approve_or_reject(world):
    add_observation(world)
    _, rec = run_web(world)
    for action in (lambda: recs.approve(world.members["analyst"], rec),
                   lambda: recs.reject(world.members["analyst"], rec, comment="no"),
                   lambda: recs.approve(world.members["publisher"], rec)):
        with pytest.raises(PermissionDenied):
            action()
    rec.refresh_from_db()
    assert rec.status == "awaiting_approval" and not ApprovalDecision.objects.exists()


def test_channel_limited_member_is_denied_on_other_channels(world):
    add_observation(world)
    _, rec = run_web(world)
    limited = world.members["limited"]  # approver + publisher, marketplace only
    assert can(limited, "approve", world.marketplace) and not can(limited, "approve", world.web)
    with pytest.raises(PermissionDenied) as excinfo:
        recs.approve(limited, rec)
    assert excinfo.value.code == "channel_denied"
    with pytest.raises(PermissionDenied):
        recs.run_pricing(limited, channel=world.web)
    scoped = recs.run_pricing(limited)  # no channel: silently limited to the member's channels
    assert list(scoped.recommendations.values_list("listing__channel__code", flat=True)) == ["marketplace"]


def test_member_of_another_organisation_has_no_access(world):
    from .conftest import build_world

    other = build_world("other")
    add_observation(world)
    _, rec = run_web(world)
    with pytest.raises(PermissionDenied):
        recs.approve(other.members["approver"], rec)
    assert not can(other.members["admin"], "approve", world.web)
    assert recs.run_pricing(other.members["analyst"]).recommendations.filter(organisation=world.org).count() == 0


# ------------------------------------------------------------------ approval


def test_approval_records_decision_and_keeps_prices_separate(world):
    add_observation(world)
    _, rec = run_web(world)
    rec = recs.approve(world.members["approver"], rec, comment="ok")
    assert rec.status == "approved" and rec.approved_price == D("54.99") == rec.recommended_price
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("59.99")  # approval does not change the confirmed published price
    decision = rec.decisions.get()
    assert decision.decision == "approved" and decision.decided_by == world.members["approver"].user
    assert not decision.is_override
    assert AuditEvent.objects.filter(action="recommendation.approval", object_id=str(rec.pk)).count() == 1


def test_override_needs_a_reason_and_must_pass_hard_constraints(world):
    add_observation(world)
    _, rec = run_web(world)
    approver = world.members["approver"]
    with pytest.raises(WorkflowError) as excinfo:
        recs.approve(approver, rec, approved_price=D("56.49"))
    assert excinfo.value.code == "override_reason_required"
    with pytest.raises(WorkflowError) as excinfo:
        recs.approve(approver, rec, approved_price=D("39.99"), comment="beat everyone")
    assert excinfo.value.code == "constraint_violation"
    assert [v["name"] for v in excinfo.value.details["violations"]] == ["minimum_contribution_margin"]
    rec.refresh_from_db()
    assert rec.status == "awaiting_approval" and rec.approved_price is None
    # 50.49 is a 15.8% cut - beyond the 10% automatic movement limit - but passes every hard constraint.
    rec = recs.approve(approver, rec, approved_price=D("50.49"), comment="Clearing space for the new model")
    assert rec.approved_price == D("50.49") and rec.recommended_price == D("54.99")
    assert rec.decisions.get().is_override
    assert AuditEvent.objects.filter(action="recommendation.override_approved").count() == 1


def test_conflict_needs_an_explicit_price_and_cannot_be_approved_past_the_constraints(world):
    from apps.policies.models import PriceCommitment

    PriceCommitment.objects.create(organisation=world.org, listing=world.listing, kind="max_price", value=D("45.00"),
                                   reference="FA-1")
    _, rec = run_web(world)
    assert rec.outcome == "conflict" and rec.status == "awaiting_approval" and rec.recommended_price is None
    with pytest.raises(WorkflowError) as excinfo:
        recs.approve(world.members["approver"], rec)
    assert excinfo.value.code == "price_required"
    with pytest.raises(WorkflowError) as excinfo:
        recs.approve(world.members["approver"], rec, approved_price=D("45.00"), comment="keep the contract price")
    assert excinfo.value.code == "constraint_violation"
    assert excinfo.value.details["blocking_issues"][0]["code"] == "constraint_conflict"


def test_reject_needs_a_reason_and_is_final(world):
    add_observation(world)
    _, rec = run_web(world)
    with pytest.raises(WorkflowError):
        recs.reject(world.members["approver"], rec, comment="  ")
    rec = recs.reject(world.members["approver"], rec, comment="Hold for the campaign")
    assert rec.status == "rejected" and rec.status_note == "Hold for the campaign"
    with pytest.raises(WorkflowError) as excinfo:
        recs.approve(world.members["approver"], rec)
    assert excinfo.value.code == "invalid_state"


def test_state_machine_only_allows_listed_transitions(world):
    add_observation(world)
    _, rec = run_web(world)
    for target in ("verified", "publishing", "draft", "evaluated"):
        with pytest.raises(WorkflowError) as excinfo:
            transition(rec, target)
        assert excinfo.value.code == "invalid_transition"
    rec.refresh_from_db()
    assert rec.status == "awaiting_approval"
    for terminal in ("verified", "rejected", "expired", "superseded", "withdrawn"):
        assert TRANSITIONS[terminal] == set()
    assert "verified" not in TRANSITIONS["approved"]  # nothing is verified without going through publishing
    assert TRANSITIONS["publishing"] == {"verified", "failed"}
    withdrawn = recs.withdraw(world.members["approver"], rec, comment="Not now")
    assert withdrawn.status == "withdrawn"


def test_expired_recommendation_cannot_be_approved(world):
    add_observation(world)
    _, rec = run_web(world)
    assert rec.expires_at == rec.evaluated_at + timedelta(hours=24)
    PriceRecommendation.objects.filter(pk=rec.pk).update(expires_at=timezone.now() - timedelta(minutes=1))
    with pytest.raises(WorkflowError) as excinfo:
        recs.approve(world.members["approver"], rec)
    assert excinfo.value.code == "expired"
    rec.refresh_from_db()
    assert rec.status == "expired" and rec.approved_price is None


def test_expiry_sweep_covers_approved_and_scheduled(world):
    add_observation(world)
    _, rec = run_web(world)
    recs.approve(world.members["approver"], rec)
    assert recs.expire_recommendations() == 0
    assert recs.expire_recommendations(now=timezone.now() + timedelta(hours=25)) == 1
    rec.refresh_from_db()
    assert rec.status == "expired"


def test_scheduling_needs_publish_permission_and_a_future_time(world):
    add_observation(world)
    _, rec = run_web(world)
    when = timezone.now() + timedelta(hours=2)
    with pytest.raises(PermissionDenied):
        recs.approve(world.members["approver"], rec, scheduled_for=when)
    with pytest.raises(WorkflowError) as excinfo:
        recs.approve(world.members["admin"], rec, scheduled_for=timezone.now() - timedelta(hours=1))
    assert excinfo.value.code == "invalid_schedule"
    rec = recs.approve(world.members["admin"], rec, scheduled_for=when)
    assert rec.status == "scheduled" and rec.scheduled_price == D("54.99") and rec.scheduled_for == when


# ------------------------------------------------------------------ bounded automation

AUTO_POLICY = {**WORLD_POLICY, "automation": {"enabled": True, "max_auto_change_pct": "0.03",
                                              "allowed_categories": ["audio"], "allow_price_increases": False}}


def test_automation_needs_administrator_authorisation(world):
    save_policy(world.members["editor"], code="core", name="Core", config=AUTO_POLICY)
    add_observation(world, item="58.99")  # -1.7%
    _, rec = run_web(world)
    assert rec.recommended_price == D("58.99") and rec.status == "awaiting_approval"  # configured but not authorised
    with pytest.raises(PermissionDenied):
        authorise_automation(world.members["editor"], world.policy, True)
    world.policy.refresh_from_db()
    authorise_automation(world.members["admin"], world.policy, True)
    run, rec = run_web(world)
    assert rec.status == "approved" and rec.approved_price == D("58.99") and run.counts["auto_approved"] == 1
    decision = rec.decisions.get()
    assert decision.decision == "auto_approved" and decision.decided_by is None
    assert "bounded automation" in decision.comment
    assert AuditEvent.objects.filter(action="recommendation.approved", actor_label="automation").count() == 1


def _authorised(world, config=AUTO_POLICY):
    save_policy(world.members["editor"], code="core", name="Core", config=config)
    world.policy.refresh_from_db()
    authorise_automation(world.members["admin"], world.policy, True)


def test_automation_is_bounded_by_size_category_direction_and_warnings(world):
    _authorised(world)
    add_observation(world, item="55.00")  # -8.3%: too large
    assert run_web(world)[1].status == "awaiting_approval"


def test_automation_only_for_named_product_groups(world):
    _authorised(world, {**AUTO_POLICY, "automation": {**AUTO_POLICY["automation"], "allowed_categories": ["cables"]}})
    add_observation(world, item="58.99")
    assert run_web(world)[1].status == "awaiting_approval"


def test_automation_does_not_raise_prices_unless_allowed(world):
    _authorised(world)
    add_observation(world, item="60.99")  # +1.7%
    rec = run_web(world)[1]
    assert rec.recommended_price == D("60.99") and rec.status == "awaiting_approval"


def test_automation_skips_recommendations_with_warnings(world):
    from apps.inventory.models import InventoryPosition

    _authorised(world)
    InventoryPosition.objects.update(as_of=timezone.now() - timedelta(days=10))  # stale inventory -> warning
    add_observation(world, item="58.99")
    rec = run_web(world)[1]
    assert rec.warnings and rec.status == "awaiting_approval"


def test_editing_a_policy_to_disable_automation_revokes_authorisation(world):
    _authorised(world)
    save_policy(world.members["editor"], code="core", name="Core", config=WORLD_POLICY)
    world.policy.refresh_from_db()
    assert not world.policy.automation_authorised
