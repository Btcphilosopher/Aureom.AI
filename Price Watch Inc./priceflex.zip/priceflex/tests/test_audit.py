"""Audit trail: what is recorded, and that it cannot be rewritten."""

from decimal import Decimal as D

import pytest
from django.db import Error as DatabaseError
from django.db import connection, transaction

from apps.audit.models import AuditEvent
from apps.audit.services import raise_alert, record, resolve_alerts
from apps.publishing import services as publishing
from apps.recommendations import services as recs

from .conftest import WORLD_POLICY, add_observation

pytestmark = pytest.mark.django_db


def test_audit_rows_cannot_be_changed_through_the_model(world):
    event = record(world.org, world.members["admin"].user, "test.event", world.listing, "created")
    event.summary = "rewritten"
    with pytest.raises(RuntimeError):
        event.save()
    with pytest.raises(RuntimeError):
        event.delete()
    assert AuditEvent.objects.get(pk=event.pk).summary == "created"


@pytest.mark.parametrize("statement", [
    "UPDATE audit_auditevent SET summary = 'rewritten' WHERE id = %s",
    "DELETE FROM audit_auditevent WHERE id = %s",
])
def test_database_trigger_blocks_update_and_delete(world, statement):
    event = record(world.org, "system", "test.event", None, "original")
    with pytest.raises(DatabaseError) as excinfo, transaction.atomic():
        with connection.cursor() as cursor:
            cursor.execute(statement, [event.pk])
    assert "append-only" in str(excinfo.value)
    assert AuditEvent.objects.get(pk=event.pk).summary == "original"


def test_bulk_orm_update_and_delete_are_blocked_by_the_database(world):
    record(world.org, "system", "test.event", None, "original")
    with pytest.raises(DatabaseError), transaction.atomic():
        AuditEvent.objects.filter(action="test.event").update(summary="rewritten")
    with pytest.raises(DatabaseError), transaction.atomic():
        AuditEvent.objects.filter(action="test.event").delete()
    assert AuditEvent.objects.get(action="test.event").summary == "original"


def test_the_governed_actions_all_leave_audit_events(world):
    from apps.costs.services import import_costs
    from apps.policies.services import save_policy

    m = world.members
    import_costs(m["analyst"], [{"sku": "WID-1", "currency": "GBP", "acquisition_cost": "30.50",
                                 "fee_percent": "0.029", "fee_fixed": "0.30",
                                 "effective_from": world.now.isoformat()}])
    save_policy(m["editor"], code="core", name="Core", config={**WORLD_POLICY, "cooldown_hours": 0},
                change_note="Explicit cooldown")
    add_observation(world)
    rec = recs.run_pricing(m["analyst"], channel=world.web).recommendations.get(listing=world.listing)
    rec = recs.approve(m["approver"], rec, approved_price=D("55.49"), comment="Round up slightly")
    publishing.publish(m["publisher"], rec)
    world.listing.refresh_from_db()
    publishing.request_rollback(m["publisher"], world.listing, reason="Test rollback")
    # oldest first, so the dictionary keeps the most recent event of each kind
    by_action = {e.action: e for e in AuditEvent.objects.filter(organisation=world.org).order_by("id")}
    expected = {
        "cost.version_created": "analyst", "policy.version_created": "editor", "pricing_run.completed": "analyst",
        "recommendation.override_approved": "approver", "publication.publish_verified": "publisher",
        "publication.rollback_requested": "publisher", "publication.rollback_verified": "publisher",
    }
    for action, role in expected.items():
        assert action in by_action, f"missing audit event {action}"
        assert by_action[action].actor == m[role].user
    override = by_action["recommendation.override_approved"].payload
    assert override == {"recommended_price": "54.99", "approved_price": "55.49", "is_override": True,
                        "comment": "Round up slightly", "scheduled_for": None}
    assert by_action["policy.version_created"].payload["previous_version"] == 1


def test_alerts_deduplicate_and_resolve(world):
    first = raise_alert(world.org, "storefront_price_drift", "first", listing=world.listing)
    second = raise_alert(world.org, "storefront_price_drift", "second", listing=world.listing)
    assert first.pk == second.pk and second.message == "second"
    assert resolve_alerts(world.org, "storefront_price_drift", listing=world.listing) == 1
    assert raise_alert(world.org, "storefront_price_drift", "third", listing=world.listing).pk != first.pk
