"""Publication, read-back verification, reconciliation, pause, rollback and monitoring."""

from datetime import timedelta
from decimal import Decimal as D

import pytest
from django.db import IntegrityError, transaction
from django.utils import timezone

from adapters.storefront import StorefrontVersionConflict
from apps.accounts.permissions import PermissionDenied
from apps.audit.models import Alert, AuditEvent
from apps.costs.models import CostVersion
from apps.publishing import services as publishing
from apps.publishing.mock_storefront import MockStorefront
from apps.publishing.models import (
    MockStorefrontPrice,
    MockStorefrontQuote,
    MockStorefrontRequest,
    ObservedPublishedPrice,
    PriceHistory,
    PublicationAttempt,
)
from apps.recommendations import services as recs
from apps.recommendations.models import PriceRecommendation
from apps.recommendations.workflow import WorkflowError

pytestmark = pytest.mark.django_db


def shown(world):
    return MockStorefrontPrice.objects.get(channel_code="web", sku="WID-1")


def second_approved_rec(world):
    run = recs.run_pricing(world.members["analyst"], channel=world.web)
    return recs.approve(world.members["approver"], run.recommendations.get(listing=world.listing))


def raise_cost(world, acquisition="45.00"):
    CostVersion.objects.create(organisation=world.org, variant=world.variant, currency="GBP",
                               acquisition_cost=D(acquisition), freight_landed=D("1.5"), packaging=D("0.5"),
                               fulfilment=D("2"), fee_percent=D("0.029"), fee_fixed=D("0.30"),
                               effective_from=timezone.now() - timedelta(seconds=5), source="cost increase")


def test_publication_is_verified_by_read_back_and_recorded(world, approved_rec):
    attempt = publishing.publish(world.members["publisher"], approved_rec)
    assert attempt.status == "verified" and attempt.resolution == "verified_on_publish"
    assert attempt.price == D("54.99") and attempt.expected_previous_price == D("59.99") and attempt.expected_version == 1
    assert attempt.external_response["status"] == "accepted" and attempt.external_response["price"] == "54.99"
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("54.99") and world.listing.price_version == 2
    assert world.listing.confirmed_at is not None
    history = PriceHistory.objects.filter(listing=world.listing).order_by("-effective_at").first()
    assert (history.kind, history.price, history.previous_price) == ("publish", D("54.99"), D("59.99"))
    assert history.attempt == attempt and history.recommendation_id == approved_rec.pk
    observations = list(ObservedPublishedPrice.objects.filter(attempt=attempt).order_by("id"))
    assert [(o.source, o.price, o.matches_expected) for o in observations] == [
        ("pre_publish_check", D("59.99"), True), ("publish_readback", D("54.99"), True)]
    approved_rec.refresh_from_db()
    assert approved_rec.status == "verified"
    assert shown(world).displayed_price == D("54.99")
    event = AuditEvent.objects.get(action="publication.publish_verified")
    assert event.actor == world.members["publisher"].user and event.payload["previous_price"] == "59.99"


def test_only_publishers_publish(world, approved_rec):
    for role in ("analyst", "approver", "editor", "limited"):
        with pytest.raises(PermissionDenied):
            publishing.publish(world.members[role], approved_rec)
    assert not PublicationAttempt.objects.exists() and shown(world).price == D("59.99")


def test_unapproved_recommendation_cannot_be_published(world):
    from .conftest import add_observation

    add_observation(world)
    rec = recs.run_pricing(world.members["analyst"], channel=world.web).recommendations.get(listing=world.listing)
    with pytest.raises(WorkflowError) as excinfo:
        publishing.publish(world.members["publisher"], rec)
    assert excinfo.value.code == "invalid_state"
    assert shown(world).price == D("59.99")


def test_pause_switch_blocks_publication_and_is_audited(world, approved_rec):
    publisher = world.members["publisher"]
    with pytest.raises(WorkflowError):
        publishing.set_pause(publisher, True, "")  # a reason is required
    with pytest.raises(PermissionDenied):
        publishing.set_pause(world.members["approver"], True, "not mine to pause")
    publishing.set_pause(publisher, True, "Storefront maintenance")
    with pytest.raises(WorkflowError) as excinfo:
        publishing.publish(publisher, approved_rec)
    assert excinfo.value.code == "publication_paused" and "Storefront maintenance" in excinfo.value.message
    approved_rec.refresh_from_db()
    assert approved_rec.status == "approved" and not PublicationAttempt.objects.exists()
    assert shown(world).price == D("59.99")
    publishing.set_pause(publisher, False)
    assert publishing.publish(publisher, approved_rec).status == "verified"
    switch_events = AuditEvent.objects.filter(action__in=["publication.paused", "publication.resumed"]).order_by("id")
    assert [e.action for e in switch_events] == ["publication.paused", "publication.resumed"]
    assert all(e.actor == publisher.user for e in switch_events) and "Storefront maintenance" in switch_events[0].summary


def test_essential_constraints_are_rechecked_at_publication_time(world, approved_rec):
    raise_cost(world)  # the floor is now above the approved 54.99
    attempt = publishing.publish(world.members["publisher"], approved_rec)
    assert attempt.status == "blocked" and "minimum_contribution_margin" in attempt.error
    approved_rec.refresh_from_db()
    assert approved_rec.status == "failed"
    assert shown(world).price == D("59.99") and not MockStorefrontRequest.objects.exists()  # nothing was sent
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("59.99") and world.listing.price_version == 1


def test_changed_live_price_version_supersedes_the_approval(world, approved_rec):
    world.listing.price_version = 2
    world.listing.save(update_fields=["price_version"])
    with pytest.raises(WorkflowError) as excinfo:
        publishing.publish(world.members["publisher"], approved_rec)
    assert excinfo.value.code == "stale_price_version"
    assert excinfo.value.details == {"expected_version": 1, "current_version": 2}
    approved_rec.refresh_from_db()
    assert approved_rec.status == "superseded" and not MockStorefrontRequest.objects.exists()


def test_storefront_drift_stops_publication_before_anything_is_sent(world, approved_rec):
    MockStorefrontPrice.objects.filter(sku="WID-1", channel_code="web").update(price=D("61.00"), displayed_price=D("61.00"))
    attempt = publishing.publish(world.members["publisher"], approved_rec)
    assert attempt.status == "failed" and attempt.resolution == "precondition_failed"
    assert not MockStorefrontRequest.objects.exists() and shown(world).price == D("61.00")
    assert Alert.objects.filter(kind="storefront_price_drift", severity="critical", resolved_at__isnull=True).exists()


def test_expired_approval_is_not_published(world, approved_rec):
    PriceRecommendation.objects.filter(pk=approved_rec.pk).update(expires_at=timezone.now() - timedelta(minutes=1))
    with pytest.raises(WorkflowError) as excinfo:
        publishing.publish(world.members["publisher"], approved_rec)
    assert excinfo.value.code == "expired"
    approved_rec.refresh_from_db()
    assert approved_rec.status == "expired" and shown(world).price == D("59.99")


def test_rejection_by_storefront_fails_and_retry_reuses_the_idempotency_key(world, approved_rec):
    MockStorefront.inject_fault("web", "WID-1", "reject")
    first = publishing.publish(world.members["publisher"], approved_rec)
    assert first.status == "failed" and first.resolution == "rejected_by_storefront"
    approved_rec.refresh_from_db()
    assert approved_rec.status == "failed" and shown(world).price == D("59.99")
    second = publishing.publish(world.members["publisher"], approved_rec)
    assert second.status == "verified" and second.attempt_number == 2
    assert second.idempotency_key == first.idempotency_key
    assert shown(world).version == 2


def test_timeout_after_apply_is_uncertain_until_reconciled_as_applied(world, approved_rec):
    MockStorefront.inject_fault("web", "WID-1", "timeout_after_apply")
    attempt = publishing.publish(world.members["publisher"], approved_rec)
    assert attempt.status == "uncertain" and "response was lost" in attempt.error
    approved_rec.refresh_from_db()
    world.listing.refresh_from_db()
    assert approved_rec.status == "publishing"
    # The storefront did change, but nothing is treated as confirmed until it has been read back.
    assert shown(world).price == D("54.99")
    assert world.listing.confirmed_price == D("59.99") and world.listing.price_version == 1
    assert Alert.objects.filter(kind="publication_uncertain", resolved_at__isnull=True).count() == 1
    with pytest.raises(PermissionDenied):
        publishing.reconcile(world.members["approver"], attempt)
    resolved = publishing.reconcile(world.members["publisher"], attempt)
    assert resolved.status == "verified" and resolved.resolution == "reconciled_applied"
    assert resolved.reconciled_at is not None
    approved_rec.refresh_from_db()
    world.listing.refresh_from_db()
    assert approved_rec.status == "verified"
    assert world.listing.confirmed_price == D("54.99") and world.listing.price_version == 2
    assert not Alert.objects.filter(kind="publication_uncertain", resolved_at__isnull=True).exists()
    assert ObservedPublishedPrice.objects.filter(attempt=attempt, source="reconciliation", matches_expected=True).exists()
    assert PriceHistory.objects.filter(listing=world.listing, kind="publish").count() == 1


def test_timeout_before_apply_reconciles_as_not_applied_then_retry_succeeds(world, approved_rec):
    MockStorefront.inject_fault("web", "WID-1", "timeout_before_apply")
    attempt = publishing.publish(world.members["publisher"], approved_rec)
    assert attempt.status == "uncertain" and shown(world).price == D("59.99")
    resolved = publishing.reconcile(world.members["publisher"], attempt)
    assert resolved.status == "failed" and resolved.resolution == "reconciled_not_applied"
    approved_rec.refresh_from_db()
    world.listing.refresh_from_db()
    assert approved_rec.status == "failed" and world.listing.price_version == 1
    assert not PriceHistory.objects.filter(listing=world.listing, kind="publish").exists()
    retry = publishing.publish(world.members["publisher"], approved_rec)
    assert retry.status == "verified" and retry.idempotency_key == attempt.idempotency_key
    assert MockStorefrontRequest.objects.count() == 1 and shown(world).version == 2
    with pytest.raises(WorkflowError):
        publishing.reconcile(world.members["publisher"], retry)  # nothing left to reconcile


def test_accepted_request_is_not_enough_when_the_storefront_still_displays_the_old_price(world, approved_rec):
    MockStorefront.inject_fault("web", "WID-1", "accepted_not_displayed")
    attempt = publishing.publish(world.members["publisher"], approved_rec)
    assert attempt.external_response["status"] == "accepted"  # the API call succeeded...
    assert attempt.status == "uncertain" and "displays 59.99" in attempt.error  # ...but shoppers see the old price
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("59.99")
    readback = ObservedPublishedPrice.objects.get(attempt=attempt, source="publish_readback")
    assert readback.price == D("59.99") and readback.matches_expected is False
    MockStorefront.refresh_display("web", "WID-1")
    resolved = publishing.reconcile(world.members["publisher"], attempt)
    assert resolved.status == "verified" and resolved.resolution == "reconciled_applied"
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("54.99")


def test_accepted_but_undisplayed_change_stays_uncertain_until_the_display_catches_up(world, approved_rec):
    MockStorefront.inject_fault("web", "WID-1", "accepted_not_displayed")
    first = publishing.publish(world.members["publisher"], approved_rec)
    # Reconciling while the storefront still shows 59.99 must not conclude "not applied":
    # the storefront told us it accepted the change.
    still = publishing.reconcile(world.members["publisher"], first)
    assert still.status == "uncertain" and "accepted" in still.error and still.reconciled_at is not None
    approved_rec.refresh_from_db()
    assert approved_rec.status == "publishing"
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("59.99") and world.listing.price_version == 1
    with pytest.raises(WorkflowError) as exc:  # no second publication can start meanwhile
        publishing.publish(world.members["publisher"], approved_rec)
    assert exc.value.code in ("invalid_state", "publication_in_progress")
    assert shown(world).version == 2 and MockStorefrontRequest.objects.count() == 1  # applied exactly once
    MockStorefront.refresh_display("web", "WID-1")
    assert publishing.reconcile_open(world.org) == 1
    first.refresh_from_db()
    assert first.status == "verified" and first.resolution == "reconciled_applied"
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("54.99") and world.listing.price_version == 2


def test_stale_pending_attempt_is_picked_up_by_reconciliation(world, approved_rec):
    """A worker that dies after recording the attempt must not block the listing for ever."""
    from datetime import timedelta

    from django.utils import timezone

    from apps.publishing.models import PublicationAttempt
    from apps.recommendations.workflow import transition

    transition(approved_rec, "publishing", audit=False)
    attempt = PublicationAttempt.objects.create(
        organisation=world.org, recommendation=approved_rec, listing=world.listing, idempotency_key="pf-crash-test-1",
        price=approved_rec.approved_price, expected_previous_price=world.listing.confirmed_price,
        expected_version=world.listing.price_version, status="pending")
    assert publishing.reconcile_open(world.org) == 0  # too recent: the publisher may still be working
    PublicationAttempt.objects.filter(pk=attempt.pk).update(created_at=timezone.now() - timedelta(minutes=30))
    assert publishing.reconcile_open(world.org) == 1
    attempt.refresh_from_db()
    assert attempt.status == "failed" and attempt.resolution == "reconciled_not_applied"
    approved_rec.refresh_from_db()
    assert approved_rec.status == "failed"  # and it can now be retried


def test_mock_storefront_is_idempotent_and_compare_and_set(world):
    store = MockStorefront()
    first = store.set_price("web", "WID-1", D("57.99"), expected_version="1", idempotency_key="key-12345")
    again = store.set_price("web", "WID-1", D("57.99"), expected_version="1", idempotency_key="key-12345")
    assert again == {**first, "idempotent_replay": True}
    assert shown(world).version == 2 and store.get_price("web", "WID-1").price == D("57.99")
    with pytest.raises(StorefrontVersionConflict):
        store.set_price("web", "WID-1", D("56.99"), expected_version="1", idempotency_key="key-67890")
    assert shown(world).price == D("57.99")
    assert store.get_price("web", "NOPE").price is None


def test_open_attempt_blocks_other_publications_for_the_listing(world, approved_rec):
    other = second_approved_rec(world)
    MockStorefront.inject_fault("web", "WID-1", "timeout_before_apply")
    uncertain = publishing.publish(world.members["publisher"], approved_rec)
    assert uncertain.status == "uncertain"
    with pytest.raises(WorkflowError) as excinfo:
        publishing.publish(world.members["publisher"], other)
    assert excinfo.value.code == "publication_in_progress"
    with pytest.raises(IntegrityError), transaction.atomic():  # the database enforces it too
        PublicationAttempt.objects.create(
            organisation=world.org, recommendation=other, listing=world.listing, idempotency_key="x", price=D("54.99"),
            expected_version=1, status="pending")


def test_verified_change_supersedes_other_pending_decisions_for_the_listing(world, approved_rec):
    other = second_approved_rec(world)
    publishing.publish(world.members["publisher"], approved_rec)
    other.refresh_from_db()
    assert other.status == "superseded"
    with pytest.raises(WorkflowError):
        publishing.publish(world.members["publisher"], other)
    assert shown(world).version == 2


def test_accepted_quotes_are_not_altered_by_publication(world, approved_rec):
    quote = MockStorefrontQuote.objects.create(channel_code="web", sku="WID-1", reference="Q-1",
                                               locked_price=D("59.99"), expires_at=timezone.now() + timedelta(days=3))
    publishing.publish(world.members["publisher"], approved_rec)
    quote.refresh_from_db()
    assert quote.locked_price == D("59.99")
    assert MockStorefront.price_for_order("web", "WID-1", "Q-1") == D("59.99")
    assert MockStorefront.price_for_order("web", "WID-1") == D("54.99")


def test_rollback_restores_the_previous_price_with_an_audit_trail(world, approved_rec):
    publisher = world.members["publisher"]
    publishing.publish(publisher, approved_rec)
    with pytest.raises(WorkflowError) as excinfo:
        publishing.request_rollback(publisher, world.listing, reason=" ")
    assert excinfo.value.code == "reason_required"
    with pytest.raises(PermissionDenied):
        publishing.request_rollback(world.members["approver"], world.listing, reason="oops")
    world.listing.refresh_from_db()
    attempt = publishing.request_rollback(publisher, world.listing, reason="Published a day early")
    assert attempt.status == "verified" and attempt.kind == "rollback" and attempt.price == D("59.99")
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("59.99") and world.listing.price_version == 3
    assert shown(world).displayed_price == D("59.99")
    latest = PriceHistory.objects.filter(listing=world.listing).order_by("-effective_at", "-id").first()
    assert (latest.kind, latest.price, latest.previous_price) == ("rollback", D("59.99"), D("54.99"))
    rollback_rec = attempt.recommendation
    assert rollback_rec.kind == "rollback" and rollback_rec.status == "verified"
    assert rollback_rec.snapshot.payload["current_price"] == "54.99"
    assert "Published a day early" in rollback_rec.decisions.get().comment
    actions = set(AuditEvent.objects.values_list("action", flat=True))
    assert {"publication.rollback_requested", "publication.rollback_verified"} <= actions


def test_rollback_respects_current_conditions(world, approved_rec):
    publisher = world.members["publisher"]
    publishing.publish(publisher, approved_rec)
    raise_cost(world, "48.00")  # the old 59.99 would now be below the floor
    world.listing.refresh_from_db()
    with pytest.raises(WorkflowError) as excinfo:
        publishing.request_rollback(publisher, world.listing, reason="Customer complaints")
    assert excinfo.value.code == "rollback_blocked"
    assert [v["name"] for v in excinfo.value.details["violations"]] == ["minimum_contribution_margin"]
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("54.99") and shown(world).price == D("54.99")
    assert AuditEvent.objects.filter(action="publication.rollback_refused").count() == 1
    assert not PriceRecommendation.objects.filter(kind="rollback").exists()


def test_rollback_needs_an_earlier_price_and_works_while_paused(world, approved_rec):
    publisher = world.members["publisher"]
    with pytest.raises(WorkflowError) as excinfo:
        publishing.request_rollback(publisher, world.listing, reason="nothing published yet")
    assert excinfo.value.code == "nothing_to_roll_back"
    publishing.publish(publisher, approved_rec)
    publishing.set_pause(publisher, True, "Incident")
    world.listing.refresh_from_db()
    assert publishing.request_rollback(publisher, world.listing, reason="Incident rollback").status == "verified"


def test_monitor_flags_drift_without_auto_correcting(world, approved_rec):
    publishing.publish(world.members["publisher"], approved_rec)
    assert publishing.monitor(world.org) == {"checked": 2, "mismatched": 0}
    MockStorefrontPrice.objects.filter(sku="WID-1", channel_code="web").update(displayed_price=D("49.99"))
    assert publishing.monitor(world.org) == {"checked": 2, "mismatched": 1}
    world.listing.refresh_from_db()
    assert world.listing.confirmed_price == D("54.99") and shown(world).displayed_price == D("49.99")
    alert = Alert.objects.get(kind="storefront_price_drift", resolved_at__isnull=True)
    assert alert.listing == world.listing and alert.severity == "critical"
    assert ObservedPublishedPrice.objects.filter(source="monitor", matches_expected=False).count() == 1
    MockStorefront.refresh_display("web", "WID-1")
    publishing.monitor(world.org)
    assert not Alert.objects.filter(kind="storefront_price_drift", resolved_at__isnull=True).exists()


def test_scheduled_price_is_published_only_when_due_and_not_while_paused(world):
    from .conftest import add_observation

    add_observation(world)
    rec = recs.run_pricing(world.members["analyst"], channel=world.web).recommendations.get(listing=world.listing)
    rec = recs.approve(world.members["admin"], rec, scheduled_for=timezone.now() + timedelta(hours=2))
    assert publishing.publish_due() == 0 and shown(world).price == D("59.99")
    later = timezone.now() + timedelta(hours=3)
    publishing.set_pause(world.members["publisher"], True, "Freeze")
    assert publishing.publish_due(now=later) == 0
    publishing.set_pause(world.members["publisher"], False)
    assert publishing.publish_due(now=later) == 1
    rec.refresh_from_db()
    world.listing.refresh_from_db()
    assert rec.status == "verified" and world.listing.confirmed_price == D("54.99")
    assert AuditEvent.objects.get(action="publication.publish_verified").actor_label == "system (scheduled)"
