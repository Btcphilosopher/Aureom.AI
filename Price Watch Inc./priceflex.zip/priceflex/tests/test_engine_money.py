"""Tax, fee and margin arithmetic with hand-computed expectations."""

from decimal import Decimal as D

import pytest

from engine.money import (
    CostInputs,
    MoneyError,
    TaxConfig,
    fee_basis_amount,
    margin_breakdown,
    minimum_price_for,
)
from engine.money import (
    D as to_decimal,
)

from .conftest import make_cost, make_tax

pytestmark = pytest.mark.engine


def test_inclusive_tax_breakdown_hand_computed():
    # 59.99 incl. 20% tax -> net 49.99 (49.9917 rounded), tax 10.00
    # fee: 2.9% of the tax-inclusive 59.99 = 1.7397 -> 1.74, plus 0.30 fixed = 2.04
    # cost of goods 30 + 1.50 + 0.50 = 32.00; fulfilment 2.00; returns 5% x 6.00 = 0.30
    b = margin_breakdown(D("59.99"), make_cost(), make_tax())
    assert b.net_revenue == D("49.99")
    assert b.output_tax == D("10.00")
    assert b.fee_basis_amount == D("59.99")
    assert b.transaction_fees == D("2.04")
    assert b.cost_of_goods == D("32.00")
    assert b.variable_fulfilment == D("2.00")
    assert b.expected_returns_and_warranty == D("0.30")
    assert b.contribution == D("13.65")  # 49.99 - 32.00 - 2.00 - 2.04 - 0.30
    assert b.contribution_margin == D("0.2731")


def test_exclusive_tax_breakdown_hand_computed():
    # Displayed 50.00 excludes tax: net is 50.00, the customer pays 60.00.
    tax = make_tax(inclusive=False)
    b = margin_breakdown(D("50.00"), make_cost(), tax)
    assert b.net_revenue == D("50.00")
    assert b.output_tax == D("10.00")
    assert tax.gross(D("50.00")) == D("60.00")
    # gross-item fee is charged on the 60.00 the customer pays: 1.74 + 0.30
    assert b.transaction_fees == D("2.04")
    assert b.contribution == D("50.00") - D("32.00") - D("2.00") - D("2.04") - D("0.30")


def test_tax_rate_is_configuration_not_an_assumption():
    cost = make_cost()
    at_20 = margin_breakdown(D("60.00"), cost, make_tax("0.20"))
    at_5 = margin_breakdown(D("60.00"), cost, make_tax("0.05"))
    at_0 = margin_breakdown(D("60.00"), cost, make_tax("0"))
    assert at_20.net_revenue == D("50.00")
    assert at_5.net_revenue == D("57.14")
    assert at_0.net_revenue == D("60.00") and at_0.output_tax == D("0.00")
    with pytest.raises(MoneyError):
        TaxConfig(D("20"), True)  # 20 is not a fraction


@pytest.mark.parametrize("basis,inclusive,expected_basis,expected_fee", [
    ("gross_item", True, "59.99", "2.04"),                # 1.7397 -> 1.74 + 0.30
    ("net_item", True, "49.99", "1.75"),                  # 1.4497 -> 1.45 + 0.30
    ("gross_item_plus_delivery", True, "63.98", "2.16"),  # 59.99 + 3.99; 1.8554 -> 1.86 + 0.30
    ("gross_item", False, "71.99", "2.39"),               # 59.99 x 1.2 = 71.988 -> 71.99; 2.0877 -> 2.09 + 0.30
    ("net_item", False, "59.99", "2.04"),
    ("gross_item_plus_delivery", False, "76.78", "2.53"),  # 71.99 + 4.79 (3.99 x 1.2); 2.2266 -> 2.23 + 0.30
])
def test_fee_is_charged_on_its_actual_basis(basis, inclusive, expected_basis, expected_fee):
    cost, tax = make_cost(fee_basis=basis), make_tax(inclusive=inclusive)
    assert fee_basis_amount(D("59.99"), cost, tax, D("3.99")) == D(expected_basis)
    b = margin_breakdown(D("59.99"), cost, tax, customer_delivery_charge=D("3.99"))
    assert b.transaction_fees == D(expected_fee)


def test_margin_markup_gross_margin_and_operating_profit_are_distinct():
    cost = make_cost(overhead_allocation=D("4.00"))
    b = margin_breakdown(D("59.99"), cost, make_tax())
    assert b.gross_profit == D("17.99")            # net 49.99 - cost of goods 32.00
    assert b.gross_margin == D("0.3599")           # 17.99 / 49.99 (on revenue)
    assert b.markup == D("0.5622")                 # 17.99 / 32.00 (on cost)
    assert b.contribution_margin == D("0.2731")    # 13.65 / 49.99
    assert b.operating_profit == D("9.65")         # contribution 13.65 - overhead 4.00
    assert len({b.gross_margin, b.markup, b.contribution_margin}) == 3
    assert b.contribution < b.gross_profit


def test_recoverable_tax_is_not_a_cost_but_non_recoverable_is():
    base = margin_breakdown(D("59.99"), make_cost(), make_tax())
    recoverable = margin_breakdown(D("59.99"), make_cost(recoverable_input_tax=D("6.00")), make_tax())
    blocked = margin_breakdown(D("59.99"), make_cost(non_recoverable_input_tax=D("6.00")), make_tax())
    assert recoverable.contribution == base.contribution
    assert recoverable.cost_of_goods == base.cost_of_goods
    assert recoverable.recoverable_input_tax_excluded == D("6.00")
    assert blocked.cost_of_goods == base.cost_of_goods + D("6.00")
    assert blocked.contribution == base.contribution - D("6.00")


def test_supplier_promotion_funding_adds_to_contribution_only():
    base = margin_breakdown(D("59.99"), make_cost(), make_tax())
    funded = margin_breakdown(D("59.99"), make_cost(), make_tax(), promotion_funding=D("3.00"))
    assert funded.contribution == base.contribution + D("3.00")
    assert funded.net_revenue == base.net_revenue


def test_floats_and_non_numbers_are_rejected():
    for bad in (59.99, True, "abc", "NaN", "Infinity", None, ""):
        with pytest.raises(MoneyError):
            to_decimal(bad)
    assert to_decimal("59.99") == D("59.99")
    assert to_decimal(60) == D("60")
    assert to_decimal(None, allow_none=True) is None


def test_cost_inputs_validation():
    with pytest.raises(MoneyError):
        make_cost(fee_basis="gross_basket")
    with pytest.raises(MoneyError):
        make_cost(acquisition_cost=D("-1"))
    with pytest.raises(MoneyError):
        make_cost(fee_percent=D("2.9"))  # a percentage, not a fraction


def test_cost_round_trip_is_lossless():
    cost = make_cost(warranty_cost=D("0.75"), fee_basis="net_item", cost_version_id="42")
    assert CostInputs.from_dict(cost.to_dict()) == cost


def _meets(price, cost, tax, delivery, margin, amount):
    b = margin_breakdown(price, cost, tax, customer_delivery_charge=delivery)
    ok = b.net_revenue > 0
    if margin is not None:
        ok = ok and b.contribution >= margin * b.net_revenue
    if amount is not None:
        ok = ok and b.contribution >= amount
    return ok


GRID = [
    (basis, inclusive, rate, margin, amount, acq)
    for basis in ("gross_item", "net_item", "gross_item_plus_delivery")
    for inclusive in (True, False)
    for rate in ("0.20", "0.05", "0")
    for margin, amount in ((D("0.15"), None), (None, D("5.00")), (D("0.10"), D("8.00")), (D("0"), None))
    for acq in ("4.20", "30.00", "505.00")
]


@pytest.mark.parametrize("basis,inclusive,rate,margin,amount,acq", GRID)
def test_minimum_price_is_exactly_the_lowest_price_meeting_the_requirement(basis, inclusive, rate, margin, amount, acq):
    cost = make_cost(fee_basis=basis, acquisition_cost=D(acq))
    tax = make_tax(rate, inclusive)
    delivery = D("3.99")
    solution = minimum_price_for(cost, tax, min_margin=margin, min_amount=amount, customer_delivery_charge=delivery)
    assert solution.feasible
    assert _meets(solution.price, cost, tax, delivery, margin, amount)
    assert not _meets(solution.price - D("0.01"), cost, tax, delivery, margin, amount)


def test_floor_differs_by_fee_basis():
    tax = make_tax()
    gross = minimum_price_for(make_cost(fee_basis="gross_item"), tax, min_margin=D("0.15")).price
    net = minimum_price_for(make_cost(fee_basis="net_item"), tax, min_margin=D("0.15")).price
    plus = minimum_price_for(make_cost(fee_basis="gross_item_plus_delivery"), tax, min_margin=D("0.15"),
                             customer_delivery_charge=D("3.99")).price
    assert gross == D("50.94")
    assert net < gross < plus


def test_unattainable_margin_is_reported_not_forced():
    # 60% fee on the tax-inclusive price leaves 1 - 0.6 x 1.2 = 28% of net revenue; a 30% margin cannot exist.
    cost = make_cost(fee_percent=D("0.60"))
    solution = minimum_price_for(cost, make_tax(), min_margin=D("0.30"))
    assert not solution.feasible and solution.price is None
    assert "not attainable" in solution.detail
    # 90% fee on gross consumes more than all net revenue.
    assert not minimum_price_for(make_cost(fee_percent=D("0.90")), make_tax(), min_amount=D("1")).feasible


def test_break_even_price_when_no_requirement_given():
    cost, tax = make_cost(), make_tax()
    price = minimum_price_for(cost, tax).price
    assert margin_breakdown(price, cost, tax).contribution >= 0
    assert margin_breakdown(price - D("0.01"), cost, tax).contribution < 0
