"""Validated imports: costs, inventory, sales and competitor observations."""

from datetime import timedelta
from decimal import Decimal as D

import pytest
from django.utils import timezone

from adapters.pricewatch_simulated import SimulatedPriceWatch
from apps.accounts.permissions import PermissionDenied
from apps.audit.models import Alert, AuditEvent
from apps.competitors.models import CompetitorObservation, FeedStatus
from apps.competitors.services import import_observations, pull_price_watch
from apps.costs.models import CostVersion, TaxRule
from apps.costs.services import cost_for, import_costs, tax_for
from apps.inventory.models import InventoryMovement, InventoryPosition, SalesObservation
from apps.inventory.services import import_inventory, import_sales, inventory_input
from apps.recommendations.services import build_input

from .test_adapters_pricewatch import SCENARIOS

pytestmark = pytest.mark.django_db


def cost_row(world, **overrides):
    row = {"sku": "WID-1", "currency": "GBP", "acquisition_cost": "33.00", "freight_landed": "1.50",
           "packaging": "0.50", "fulfilment": "2.00", "fee_percent": "0.029", "fee_fixed": "0.30",
           "fee_basis": "gross_item", "effective_from": (world.now - timedelta(hours=1)).isoformat()}
    row.update(overrides)
    return row


def test_cost_import_creates_an_immutable_version_and_audits_it(world):
    result = import_costs(world.members["analyst"], [cost_row(world)], source="supplier file")
    assert (result.created, result.rejected) == (1, [])
    assert CostVersion.objects.filter(variant=world.variant).count() == 2  # the old version is kept
    current = cost_for(world.variant, world.web, timezone.now())
    assert current.acquisition_cost == D("33.0000") and current.import_batch == result.batch
    event = AuditEvent.objects.get(action="cost.version_created")
    assert event.actor == world.members["analyst"].user
    assert event.payload["previous_acquisition_cost"] == "30.0000" and event.payload["acquisition_cost"] == "33.00"
    assert AuditEvent.objects.filter(action="cost.import").count() == 1


@pytest.mark.parametrize("overrides,fragment", [
    ({"acquisition_cost": ""}, "acquisition_cost is required"),
    ({"acquisition_cost": None}, "acquisition_cost is required"),
    ({"acquisition_cost": 30.5}, "Floats are not accepted"),
    ({"acquisition_cost": "-1"}, "must be >= 0"),
    ({"sku": "NOPE"}, "Unknown sku 'NOPE'"),
    ({"channel": "nowhere"}, "Unknown channel 'nowhere'"),
    ({"fee_basis": "gross_basket"}, "fee_basis must be one of"),
    ({"fee_percent": "2.9"}, "fee_percent must be <= 0.99"),
    ({"currency": "POUNDS"}, "3-letter code"),
    ({"effective_from": "2026-11-01T00:00:00"}, "must include a timezone offset"),
    ({"effective_from": ""}, "effective_from is required"),
])
def test_invalid_cost_rows_are_rejected_and_write_nothing(world, overrides, fragment):
    result = import_costs(world.members["analyst"], [cost_row(world, **overrides), cost_row(world)])
    assert result.created == 1 and len(result.rejected) == 1
    assert result.rejected[0]["row"] == 1 and any(fragment in e for e in result.rejected[0]["errors"])
    assert CostVersion.objects.filter(variant=world.variant).count() == 2


def test_missing_cost_is_never_defaulted_to_zero(world):
    CostVersion.objects.all().delete()
    import_costs(world.members["analyst"], [cost_row(world, acquisition_cost="")])
    assert CostVersion.objects.count() == 0
    snapshot = build_input(world.listing, timezone.now())
    assert snapshot.cost is None and "No cost version is effective" in snapshot.cost_issue


def test_only_permitted_roles_import_costs(world):
    for role in ("approver", "publisher"):
        with pytest.raises(PermissionDenied):
            import_costs(world.members[role], [cost_row(world)])
    assert CostVersion.objects.count() == 1


def test_cost_resolution_prefers_channel_specific_and_respects_effective_dates(world):
    import_costs(world.members["analyst"], [
        cost_row(world, channel="marketplace", fee_percent="0.08", fee_basis="gross_item_plus_delivery"),
        cost_row(world, acquisition_cost="40.00", effective_from=(world.now + timedelta(days=3)).isoformat()),
    ])
    now = timezone.now()
    assert cost_for(world.variant, world.marketplace, now).fee_percent == D("0.08000")
    assert cost_for(world.variant, world.web, now).acquisition_cost == D("30.0000")  # future version not yet in force
    assert cost_for(world.variant, world.web, now + timedelta(days=4)).acquisition_cost == D("40.0000")
    assert cost_for(world.variant, world.web, now - timedelta(days=365)) is None


def test_tax_is_resolved_from_configuration_or_reported_as_uncertain(world):
    tax, issue = tax_for(world.web, world.product, timezone.now())
    assert tax.rate == D("0.2000") and tax.prices_include_tax and issue == ""
    world.product.tax_category = "reduced"
    world.product.save()
    tax, issue = tax_for(world.web, world.product, timezone.now())
    assert tax is None and "No tax rule is configured for tax category 'reduced'" in issue
    world.product.tax_category = "standard"
    world.product.save()
    TaxRule.objects.create(organisation=world.org, region="GB", tax_category="standard", rate=D("0.05"),
                           prices_include_tax=True, effective_from=TaxRule.objects.get().effective_from, source="dup")
    tax, issue = tax_for(world.web, world.product, timezone.now())
    assert tax is None and "ambiguous" in issue


def inv_row(world, **overrides):
    row = {"sku": "WID-1", "location": "dc", "on_hand": 80, "reserved": 5, "inbound": 0,
           "replenishment_lead_time_days": 14, "as_of": timezone.now().isoformat()}
    row.update(overrides)
    return row


def test_inventory_import_updates_position_and_records_the_movement(world):
    result = import_inventory(world.members["analyst"], [inv_row(world)])
    assert (result.created, result.updated, result.rejected) == (0, 1, [])
    position = InventoryPosition.objects.get(variant=world.variant)
    assert (position.on_hand, position.reserved) == (80, 5)
    movement = InventoryMovement.objects.get(variant=world.variant)
    assert movement.kind == "adjustment" and movement.quantity == -20
    assert inventory_input(world.variant, world.web).available == 75


@pytest.mark.parametrize("overrides,fragment", [
    ({"on_hand": -4}, "on_hand must be >= 0"),
    ({"on_hand": ""}, "on_hand is required"),
    ({"on_hand": "lots"}, "whole number"),
    ({"location": "nowhere"}, "Unknown location"),
    ({"as_of": ""}, "as_of is required"),
    ({"clearance_date": "soon"}, "ISO date"),
])
def test_invalid_inventory_rows_are_rejected(world, overrides, fragment):
    result = import_inventory(world.members["analyst"], [inv_row(world, **overrides)])
    assert result.updated == 0 and any(fragment in e for e in result.rejected[0]["errors"])
    assert InventoryPosition.objects.get(variant=world.variant).on_hand == 100


def test_older_inventory_snapshot_cannot_overwrite_a_newer_one(world):
    stale = inv_row(world, on_hand=1, as_of=(timezone.now() - timedelta(days=2)).isoformat())
    result = import_inventory(world.members["analyst"], [stale])
    assert "older than the stored position" in result.rejected[0]["errors"][0]
    assert InventoryPosition.objects.get(variant=world.variant).on_hand == 100


def sales_row(**overrides):
    row = {"sku": "WID-1", "channel": "web", "period_start": "2026-11-20", "units_sold": 3, "unit_price": "59.99",
           "exposed_price": "59.99"}
    row.update(overrides)
    return row


def test_sales_import_upserts_and_keeps_transaction_price_separate_from_displayed_price(world):
    first = import_sales(world.members["analyst"], [sales_row(unit_price="57.49")])
    again = import_sales(world.members["analyst"], [sales_row(unit_price="57.49", units_sold=4)])
    assert (first.created, again.updated) == (1, 1)
    row = SalesObservation.objects.get()
    assert row.units_sold == 4 and row.unit_price == D("57.49") and row.exposed_price == D("59.99")
    assert not row.is_synthetic


@pytest.mark.parametrize("overrides,fragment", [
    ({"unit_price": ""}, "unit_price is required when units were sold"),
    ({"units_sold": -1}, "units_sold must be >= 0"),
    ({"period_end": "2026-11-01"}, "period_end cannot be before period_start"),
    ({"stockout": "maybe"}, "stockout must be true or false"),
    ({"channel": ""}, "channel is required"),
    ({"unit_price": "0"}, "unit_price must be >= 0.01"),
])
def test_invalid_sales_rows_are_rejected(world, overrides, fragment):
    result = import_sales(world.members["analyst"], [sales_row(**overrides)])
    assert result.created == 0 and any(fragment in e for e in result.rejected[0]["errors"])
    assert SalesObservation.objects.count() == 0


def test_stockout_sales_rows_reach_the_engine_flagged(world):
    yesterday = (timezone.now().date() - timedelta(days=1)).isoformat()
    import_sales(world.members["analyst"], [sales_row(period_start=yesterday, units_sold=0, unit_price="", stockout="true")])
    periods = build_input(world.listing, timezone.now()).sales
    assert len(periods) == 1 and periods[0].stockout and periods[0].units == 0


def obs_row(**overrides):
    row = {"sku": "WID-1", "external_observation_id": "x-1", "supplier": "TechHaven", "variant_match": "exact",
           "condition": "new", "item_price": "55.00", "delivery_charge": "3.99", "mandatory_charges": "0.00",
           "charges_complete": True, "currency": "GBP", "availability": "in_stock",
           "observed_at": (timezone.now() - timedelta(hours=2)).isoformat(), "match_confidence": "0.95",
           "match_status": "confirmed"}
    row.update(overrides)
    return row


def test_pushed_observation_is_stored_with_a_derived_total(world):
    result = import_observations(world.members["analyst"], [obs_row()])
    assert result.created == 1
    obs = CompetitorObservation.objects.get()
    assert obs.comparable_total == D("58.99") and obs.variant == world.variant


def test_pushed_observation_with_unknown_delivery_keeps_null_not_zero(world):
    import_observations(world.members["analyst"], [obs_row(delivery_charge=None, charges_complete=False)])
    obs = CompetitorObservation.objects.get()
    assert obs.delivery_charge is None and obs.comparable_total is None and not obs.charges_complete


@pytest.mark.parametrize("overrides,fragment", [
    ({"observed_at": "2099-01-01T00:00:00+00:00"}, "in the future"),
    ({"item_price": "0"}, "item_price must be >= 0.01"),
    ({"match_status": "sure"}, "match_status must be one of"),
    ({"variant_match": "close"}, "variant_match must be one of"),
    ({"match_confidence": "1.5"}, "match_confidence must be <= 1"),
    ({"delivery_charge": None, "charges_complete": True}, "no comparable_total can be established"),
    ({"supplier": ""}, "supplier is required"),
])
def test_invalid_pushed_observations_are_rejected(world, overrides, fragment):
    result = import_observations(world.members["analyst"], [obs_row(**overrides)])
    assert result.created == 0 and any(fragment in e for e in result.rejected[0]["errors"])
    assert CompetitorObservation.objects.count() == 0


def test_price_watch_pull_imports_normalised_observations(world):
    now = timezone.now()
    result = pull_price_watch(world.members["analyst"], client=SimulatedPriceWatch(SCENARIOS, now=now), now=now)
    assert result.created == 3 and result.batch == "ok"
    totals = sorted(CompetitorObservation.objects.values_list("comparable_total", flat=True))
    assert totals == [D("403.99"), D("405.00"), D("408.00")]
    feed = FeedStatus.objects.get(organisation=world.org, source="pricewatch")
    assert feed.last_success_at == now and not feed.failing
    obs = CompetitorObservation.objects.get(supplier="TechHaven")
    assert obs.provenance["adapter_version"].startswith("pricewatch-adapter/")
    assert obs.match_status == "confirmed" and obs.match_confidence == D("0.9900")


def test_feed_failure_retains_last_valid_observations_and_never_writes_zero(world):
    earlier = timezone.now() - timedelta(hours=5)
    pull_price_watch(world.members["analyst"], client=SimulatedPriceWatch(SCENARIOS, now=earlier), now=earlier)
    before = list(CompetitorObservation.objects.order_by("id").values("id", "item_price", "comparable_total", "observed_at"))
    now = timezone.now()
    result = pull_price_watch(world.members["analyst"], client=SimulatedPriceWatch(SCENARIOS, now=now, outage=True), now=now)
    assert result.batch == "failed" and result.created == 0 and result.updated == 0
    after = list(CompetitorObservation.objects.order_by("id").values("id", "item_price", "comparable_total", "observed_at"))
    assert after == before  # same rows, same prices, same original timestamps
    assert CompetitorObservation.objects.filter(retained_after_feed_failure=True).count() == 3
    assert not CompetitorObservation.objects.filter(item_price=0).exists()
    feed = FeedStatus.objects.get(organisation=world.org)
    assert feed.failing and feed.last_success_at == earlier and "outage" in feed.last_error
    assert Alert.objects.filter(kind="competitor_feed_failed", resolved_at__isnull=True).count() == 1
    # The engine is told the feed is failing and which observations were retained.
    snapshot = build_input(world.listing, now)
    assert snapshot.feeds[0].failing and all(o.retained_after_feed_failure for o in snapshot.competitor_observations)
    # Recovery clears the flags and the alert.
    later = timezone.now()
    pull_price_watch(world.members["analyst"], client=SimulatedPriceWatch(SCENARIOS, now=later), now=later)
    assert not CompetitorObservation.objects.filter(retained_after_feed_failure=True).exists()
    assert not Alert.objects.filter(kind="competitor_feed_failed", resolved_at__isnull=True).exists()


def test_partial_price_watch_failure_flags_only_the_affected_product(world):
    """One product failing must not mark another product's fresh observations as retained."""
    from adapters.pricewatch import PriceWatchUnavailable
    from apps.catalogue.models import ProductVariant
    from apps.competitors.models import CompetitorObservation, FeedStatus

    other = ProductVariant.objects.create(organisation=world.org, product=world.variant.product, sku="WID-2",
                                          name="Widget two", gtin="5060999000257", mpn="WID-2")
    earlier, now = timezone.now() - timedelta(hours=6), timezone.now()
    analyst = world.members["analyst"]
    pull_price_watch(analyst, client=SimulatedPriceWatch(SCENARIOS, now=earlier), now=earlier)
    assert CompetitorObservation.objects.filter(variant=other).exists()

    class Flaky(SimulatedPriceWatch):
        def find_variant(self, gtin):
            if gtin == other.gtin:
                raise PriceWatchUnavailable("simulated failure for one product")
            return super().find_variant(gtin)

    result = pull_price_watch(analyst, client=Flaky(SCENARIOS, now=now), now=now)
    assert result.batch == "ok" and result.updated + result.created > 0
    assert not CompetitorObservation.objects.filter(variant=world.variant, retained_after_feed_failure=True).exists()
    kept = CompetitorObservation.objects.filter(variant=other)
    assert kept.exists() and all(o.retained_after_feed_failure for o in kept)
    assert all(o.item_price is None or o.item_price > 0 for o in kept)  # never replaced by zero
    feed = FeedStatus.objects.get(organisation=world.org)
    assert feed.failing and feed.last_success_at == earlier  # a partial failure is not a feed success
