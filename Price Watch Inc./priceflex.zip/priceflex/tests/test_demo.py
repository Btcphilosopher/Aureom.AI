"""The seeded demonstration: run it once and check the ten required scenarios end to end."""

from decimal import Decimal as D

import pytest
from django.db import transaction

from apps.accounts import demo
from apps.accounts.demo_run import run_demonstration
from apps.audit.models import Alert, AuditEvent
from apps.catalogue.models import ChannelListing, Product, ProductVariant
from apps.competitors.models import CompetitorObservation
from apps.inventory.models import SalesObservation
from apps.publishing.models import MockStorefrontPrice, MockStorefrontQuote, PriceHistory, PublicationAttempt
from apps.recommendations.models import PriceRecommendation, PricingRun
from apps.recommendations.services import replay
from apps.simulation.models import DemandModel, SimulationRun


@pytest.fixture(scope="module")
def demo_run(django_db_setup, django_db_blocker):
    """Seed and run the demonstration once inside a transaction that is rolled back afterwards."""
    with django_db_blocker.unblock():
        atomic = transaction.atomic()
        atomic.__enter__()
        try:
            seeded = demo.seed_demo(password="demo-test-password-123")
            lines: list[str] = []
            summary = run_demonstration(lines.append)
            run = PricingRun.objects.get(organisation__slug=demo.DEMO_SLUG, trigger="demo")
            yield {"seeded": seeded, "summary": summary, "output": "\n".join(lines), "run": run}
        finally:
            transaction.set_rollback(True)
            atomic.__exit__(None, None, None)


def rec(demo_run, sku, channel="web"):
    return PriceRecommendation.objects.select_related("snapshot", "listing").get(
        run=demo_run["run"], listing__variant__sku=sku, listing__channel__code=channel)


def listing(sku, channel="web"):
    return ChannelListing.objects.get(variant__sku=sku, channel__code=channel, channel__organisation__slug=demo.DEMO_SLUG)


def test_seed_has_twenty_products_three_competitors_and_three_channels(demo_run):
    assert Product.objects.filter(organisation__slug=demo.DEMO_SLUG).count() == 20
    assert demo_run["seeded"]["products"] == 20 and demo_run["seeded"]["cost_rows_rejected"] == 0
    assert ProductVariant.objects.filter(organisation__slug=demo.DEMO_SLUG).count() == 22
    suppliers = set(CompetitorObservation.objects.filter(source="pricewatch").values_list("supplier", flat=True))
    assert suppliers == {"TechHaven", "VoltMart", "GadgetGrove"}
    assert set(ChannelListing.objects.values_list("channel__code", flat=True)) == {"web", "marketplace", "trade"}
    assert not SalesObservation.objects.filter(is_synthetic=False).exists()  # all demo sales are flagged synthetic


def test_run_evaluated_every_listing(demo_run):
    counts = demo_run["run"].counts
    assert counts["evaluated"] == 31 and counts["skipped_no_policy"] == 0
    assert counts["conflict"] == 1 and counts["blocked"] == 1 and counts["auto_approved"] == 1
    assert counts["change"] + counts["no_change"] + counts["conflict"] + counts["blocked"] == 31


def test_scenario_profitable_product_small_reduction(demo_run):
    r = rec(demo_run, "LUM-X5-128")
    assert r.outcome == "change" and r.selected_strategy == "competitor_aware"
    assert (r.current_price, r.recommended_price) == (D("404.99"), D("399.99"))
    assert D(r.result["margin_recommended"]["contribution_margin"]) > D("0.12")  # still comfortably profitable
    assert r.result["comparables"]["eligible_count"] == 3 and r.result["comparables"]["lowest"] == "403.99"
    assert r.status == "verified" and listing("LUM-X5-128").confirmed_price == D("399.99")


def test_scenario_cost_increase_requires_higher_price(demo_run):
    r = rec(demo_run, "NIM-B14-16")
    assert r.outcome == "change" and r.selected_strategy == "margin_led"
    assert r.current_price == D("759.99") and r.recommended_price == D("793.99")
    assert r.snapshot.payload["cost"]["acquisition_cost"] == "505.0000"  # the newly imported cost version
    assert any("below the configured target" in x for x in r.reasons)
    assert D(r.result["margin_current"]["contribution_margin"]) < D("0.15")  # below the floor at the old price
    assert D(r.result["margin_recommended"]["contribution_margin"]) >= D("0.15")


def test_scenario_competitor_below_floor_is_not_followed(demo_run):
    r = rec(demo_run, "NIM-B14-8")
    floor = D(r.result["feasible_interval"]["lower"])
    assert r.result["comparables"]["lowest"] == "629.00"
    assert r.recommended_price == D("687.99") and r.recommended_price >= floor > D("629.00")
    assert "minimum_contribution_margin" in r.constraints_applied
    assert any("floor is kept" in x for x in r.reasons)
    assert D(r.result["margin_recommended"]["contribution"]) > 0


def test_scenario_excess_stock_approaching_clearance(demo_run):
    r = rec(demo_run, "ARC-BUDS")
    assert r.selected_strategy == "clearance" and r.result["mode"] == "clearance"
    assert r.recommended_price == D("63.99")  # 20% off the 79.99 standard retail price, 12 days out
    assert r.result["inventory"]["days_to_clearance"] == 12 and r.result["inventory"]["available"] == 416
    assert any("12 days to the clearance date" in x for x in r.reasons)


def test_scenario_stockout_holds_price(demo_run):
    r = rec(demo_run, "PULSE-SPK")
    assert r.outcome == "no_change" and r.selected_strategy == "stockout_hold" and r.recommended_price is None
    assert r.result["inventory"]["available"] == 0 and r.result["inventory"]["stockout_days_excluded"] == 9
    assert D(r.result["inventory"]["avg_daily_sales_in_stock"]) > 0  # demand is not read as zero
    assert r.result["comparables"]["eligible_count"] == 2  # cheaper competitors exist but are not chased


def test_scenario_missing_cost_blocks(demo_run):
    r = rec(demo_run, "VOLT-PB20")
    assert r.outcome == "blocked" and r.status == "evaluated" and r.recommended_price is None
    assert [i["code"] for i in r.result["blocking_issues"]] == ["missing_cost"]
    assert r.snapshot.payload["cost"] is None
    assert "rejected row 3 (VOLT-PB20): acquisition_cost is required" in demo_run["output"]
    assert not PublicationAttempt.objects.filter(listing=listing("VOLT-PB20")).exists()


def test_scenario_incompatible_competitor_variant_is_excluded(demo_run):
    r = rec(demo_run, "LUM-X5-256")
    comparables = r.result["comparables"]
    assert comparables["eligible_count"] == 0 and len(comparables["excluded"]) == 2
    assert all("different_variant" in e["reasons"] for e in comparables["excluded"])
    assert r.selected_strategy == "margin_led"  # policy fallback: continue to the next strategy


def test_scenario_stale_feed_is_not_used(demo_run):
    r = rec(demo_run, "HALO-CAM")
    comparables = r.result["comparables"]
    assert r.outcome == "no_change" and comparables["eligible_count"] == 0
    assert all(e["reasons"] == ["stale"] for e in comparables["excluded"]) and len(comparables["excluded"]) == 2
    assert comparables["last_valid_observation_at"] is not None  # timestamp of the last valid observation is kept
    assert any("fresh enough" in w for w in r.warnings)
    assert all(D(e["observed_value"]) > 0 for e in comparables["excluded"])  # never replaced by zero


def test_scenario_conflicting_floor_and_ceiling(demo_run):
    r = rec(demo_run, "FLUX-CBL")
    assert r.outcome == "conflict" and r.status == "awaiting_approval" and r.recommended_price is None
    text = " ".join(r.reasons)
    assert "minimum_contribution_margin" in text and "contractual_maximum_price" in text
    assert listing("FLUX-CBL").confirmed_price == D("6.99")  # nothing was published
    assert "FLUX-CBL conflict cannot be approved away" in demo_run["output"]


def test_scenario_failed_publication_followed_by_reconciliation(demo_run):
    r = rec(demo_run, "ORB-MOUSE")
    attempt = PublicationAttempt.objects.get(recommendation=r)
    assert attempt.status == "verified" and attempt.resolution == "reconciled_applied"
    assert attempt.reconciled_at is not None and "response was lost" in attempt.error
    assert [o.source for o in attempt.observations.order_by("id")] == ["pre_publish_check", "reconciliation"]
    assert r.status == "verified" and listing("ORB-MOUSE").confirmed_price == D("25.99")
    # The other fault: not applied, reconciled as such, then retried with the same storefront idempotency key.
    attempts = list(PublicationAttempt.objects.filter(recommendation=rec(demo_run, "PULSE-BAR")).order_by("attempt_number"))
    assert [(a.status, a.resolution) for a in attempts] == [("failed", "reconciled_not_applied"),
                                                            ("verified", "verified_on_publish")]
    assert attempts[0].idempotency_key == attempts[1].idempotency_key


def test_published_prices_match_what_the_storefront_displays(demo_run):
    assert demo_run["summary"]["monitor"]["mismatched"] == 0
    for item in ChannelListing.objects.filter(channel__organisation__slug=demo.DEMO_SLUG).select_related("variant", "channel"):
        shown = MockStorefrontPrice.objects.get(channel_code=item.channel.code, sku=item.variant.sku)
        assert shown.displayed_price == item.confirmed_price, item
    assert not PublicationAttempt.objects.filter(status__in=["pending", "sent", "uncertain"]).exists()
    assert not Alert.objects.filter(organisation__slug=demo.DEMO_SLUG, resolved_at__isnull=True).exists()


def test_governance_steps_in_the_demo(demo_run):
    out = demo_run["output"]
    assert "An analyst tries to approve: refused" in out and "An approver tries to publish: refused" in out
    assert "Pause switch on: publication refused" in out
    assert "override of VOLT-CHG to 9.99 refused" in out
    assert "Rollback of NIM-B14-16 refused under current conditions" in out
    assert rec(demo_run, "HALO-RING").status == "rejected"
    auto = rec(demo_run, "TERRA-SD")
    assert auto.decisions.get().decision == "auto_approved" and auto.status == "verified"
    rollback = PriceRecommendation.objects.get(kind="rollback")
    assert rollback.status == "verified" and listing("ECHO-HP").confirmed_price == D("119.99")
    assert PriceHistory.objects.filter(listing=listing("ECHO-HP"), kind="rollback").count() == 1
    assert MockStorefrontQuote.objects.get(reference="QUOTE-DEMO-1").locked_price == D("27.99")
    assert AuditEvent.objects.filter(organisation__slug=demo.DEMO_SLUG).count() == demo_run["summary"]["audit_events"] > 50


def test_refurbished_and_membership_and_incomplete_offers_are_excluded_in_the_demo(demo_run):
    echo = rec(demo_run, "ECHO-HP").result["comparables"]
    reasons = {e["supplier"]: set(e["reasons"]) for e in echo["excluded"]}
    assert "condition_mismatch" in reasons["TechHaven"] and "unavailable" in reasons["VoltMart"]
    tab = rec(demo_run, "NOVA-TAB").result["comparables"]
    reasons = {e["supplier"]: set(e["reasons"]) for e in tab["excluded"]}
    assert "membership_only" in reasons["GadgetGrove"] and "incomplete_mandatory_charges" in reasons["VoltMart"]
    assert tab["eligible_count"] == 1
    hub = rec(demo_run, "FLUX-HUB")
    assert "weak_match" in hub.result["comparables"]["excluded"][0]["reasons"] and "cooldown" in hub.constraints_applied


def test_every_demo_decision_is_reproducible_from_its_snapshot(demo_run):
    recommendations = PriceRecommendation.objects.filter(run=demo_run["run"]).select_related("snapshot")
    assert recommendations.count() == 31
    for r in recommendations:
        check = replay(r)
        assert check["reproducible"], (r, check["differing_fields"])
    assert demo_run["summary"]["reproducible"] is True


def test_simulations_and_demand_model_are_labelled_and_isolated(demo_run):
    runs = SimulationRun.objects.filter(organisation__slug=demo.DEMO_SLUG)
    assert runs.count() == 2 and all(r.label.startswith("SIMULATED") for r in runs)
    for r in runs:
        keys = [a["key"] for a in r.results["arms"]]
        assert keys[:1] == ["fixed"] and "competitor_aware" in keys
        assert any(s["key"] == "demand_model" for s in r.results["skipped_arms"])
    model = DemandModel.objects.get()
    assert model.status in ("validated", "insufficient_evidence")
    assert any("not a causal price elasticity" in c for c in model.estimate["caveats"])
    terra = rec(demo_run, "TERRA-SSD")
    assert terra.selected_strategy == ("demand_led" if model.status == "validated" else "margin_led")


def test_realised_results_are_reported_separately_from_projections(demo_run):
    out = demo_run["output"]
    assert "PROJECTED (from recommendations)" in out and "REALISED - from recorded transactions" in out
    today_rows = SalesObservation.objects.filter(source="Demo synthetic post-publication sales")
    assert today_rows.count() == 12 and all(s.is_synthetic for s in today_rows)
    mouse = today_rows.get(variant__sku="ORB-MOUSE")
    # One order used the accepted quote, so the average transaction price differs from the displayed price.
    assert mouse.exposed_price == D("25.99") and mouse.unit_price > mouse.exposed_price
