"""Which competitor observations may be compared, and on what basis."""

from datetime import timedelta
from decimal import Decimal as D

import pytest

from engine.comparables import build_comparable_set
from engine.evaluation import evaluate
from engine.policy import load_policy
from engine.types import FeedStatus

from .conftest import NOW, make_input, make_obs, policy_with

pytestmark = pytest.mark.engine


def comp_policy(**overrides):
    return load_policy(policy_with(competitor=overrides)).competitor


def build(observations, **overrides):
    feeds = overrides.pop("feeds", ())
    own_condition = overrides.pop("own_condition", "new")
    return build_comparable_set(tuple(observations), comp_policy(**overrides), evaluation_time=NOW, currency="GBP",
                                own_condition=own_condition, own_delivery_charge=D("3.99"), feeds=feeds)


def reasons_for(comparable_set, obs_id):
    return next(set(e.reasons) for e in comparable_set.excluded if e.observation_id == obs_id)


@pytest.mark.parametrize("overrides,expected", [
    (dict(variant_match="different"), "different_variant"),
    (dict(variant_match="unknown"), "variant_unknown"),
    (dict(condition="refurbished"), "condition_mismatch"),
    (dict(condition="used"), "condition_mismatch"),
    (dict(availability="out_of_stock"), "unavailable"),
    (dict(availability="unknown"), "unavailable"),
    (dict(membership_required=True), "membership_only"),
    (dict(match_confidence=D("0.60")), "weak_match"),
    (dict(match_status="unresolved"), "unresolved_match"),
    (dict(match_status="rejected"), "unresolved_match"),
    (dict(currency="EUR"), "currency_mismatch"),
    (dict(observed_at=NOW - timedelta(hours=49)), "stale"),
])
def test_each_exclusion_rule(overrides, expected):
    good = make_obs("good", "VoltMart", item="50.00")
    bad = make_obs("bad", "TechHaven", item="40.00", **overrides)
    result = build([good, bad])
    assert [o.observation_id for o in result.eligible] == ["good"]
    assert expected in reasons_for(result, "bad")
    assert result.lowest == D("53.99")  # the excluded 40.00 offer never becomes the reference


def test_missing_price_is_excluded_and_never_read_as_zero():
    result = build([make_obs("none", item=None, delivery=None), make_obs("zero", "VoltMart", item="0.00", delivery="0.00")])
    assert result.eligible == ()
    assert "missing_price" in reasons_for(result, "none")
    assert "missing_price" in reasons_for(result, "zero")
    assert result.lowest is None


def test_incomplete_charges_exclude_on_delivered_basis_but_only_flag_on_item_basis():
    unknown_delivery = make_obs("inc", item="50.00", delivery=None)
    delivered = build([unknown_delivery], basis="delivered_total")
    assert delivered.eligible == ()
    assert "incomplete_mandatory_charges" in reasons_for(delivered, "inc")
    item = build([unknown_delivery], basis="item")
    assert [o.value for o in item.eligible] == [D("50.00")]
    assert "mandatory_charges_incomplete" in item.eligible[0].flags


def test_future_observations_are_ignored_entirely():
    future = make_obs("future", item="10.00", hours_ago=-5)
    result = build([future, make_obs("now", "VoltMart", item="50.00")])
    assert [o.observation_id for o in result.eligible] == ["now"]
    assert all(e.observation_id != "future" for e in result.excluded)


def test_membership_prices_allowed_only_when_policy_says_so():
    member = make_obs("m", item="45.00", membership_required=True)
    assert build([member]).eligible == ()
    assert build([member], allow_membership_prices=True).lowest == D("48.99")


def test_refurbished_allowed_only_when_pricing_refurbished_stock():
    refurb = make_obs("r", item="45.00", condition="refurbished")
    assert build([refurb], allowed_conditions=["new", "refurbished"]).eligible == ()  # we are pricing new stock
    result = build([refurb], allowed_conditions=["refurbished"], own_condition="refurbished")
    assert result.lowest == D("48.99")


def test_only_newest_observation_per_supplier_listing_is_judged():
    old = make_obs("old", item="40.00", hours_ago=30, listing_key="th-1")
    new = make_obs("new", item="52.00", hours_ago=2, listing_key="th-1")
    result = build([old, new])
    assert [o.observation_id for o in result.eligible] == ["new"]
    assert result.lowest == D("55.99")


def test_median_smoothing_uses_recent_valid_observations_of_the_same_listing():
    series = [make_obs(f"o{i}", item=price, hours_ago=hours, listing_key="th-1")
              for i, (price, hours) in enumerate((("50.00", 40), ("58.00", 20), ("60.00", 2)))]
    plain = build(series)
    smoothed = build(series, smoothing="median_recent", smoothing_window_hours=72)
    assert plain.lowest == D("63.99")     # the newest observation alone
    assert smoothed.lowest == D("61.99")  # median of 53.99, 61.99, 63.99
    assert smoothed.eligible[0].smoothed_from == 3


def test_one_value_per_supplier_and_reference_positions():
    obs = [make_obs("a", "TechHaven", item="50.00"), make_obs("b", "VoltMart", item="54.00"),
           make_obs("c", "GadgetGrove", item="60.00"), make_obs("a2", "TechHaven", item="48.00", listing_key="th-2")]
    result = build(obs)
    assert len(result.eligible) == 3
    assert (result.lowest, result.median, result.highest) == (D("51.99"), D("57.99"), D("63.99"))
    assert result.reference("match_median") == D("57.99")


def test_stale_feed_keeps_last_valid_timestamp_and_warns():
    stale = make_obs("s", item="50.00", hours_ago=96)
    feed = FeedStatus("pricewatch", last_success_at=NOW - timedelta(hours=96), last_failure_at=NOW - timedelta(hours=1),
                      last_error="timeout")
    result = build([stale], feeds=(feed,))
    assert result.eligible == ()
    assert result.last_valid_observation_at == stale.observed_at
    assert any("failing" in w for w in result.warnings)
    assert any("last valid observation" in w for w in result.warnings)


def competitor_policy(**competitor):
    return policy_with(strategy_order=["competitor_aware"], competitor=competitor)


def test_delivered_total_basis_deducts_our_delivery_charge():
    # Competitor: 54.00 + 3.99 delivery = 57.99 delivered. We charge 3.99 delivery, so our item target is 54.00.
    inp = make_input(competitor_policy(basis="delivered_total"), competitor_observations=(make_obs(item="54.00"),))
    result = evaluate(inp)
    assert result.comparables.basis == "delivered_total"
    assert result.comparables.own_basis_addition == D("3.99")
    assert result.recommended_price == D("54.00")


def test_item_basis_compares_item_prices_only():
    # Same competitor offer; delivery is ignored on both sides, so the item target is the competitor's item price.
    obs = make_obs(item="54.00", delivery="9.99")
    item = evaluate(make_input(competitor_policy(basis="item"), competitor_observations=(obs,)))
    delivered = evaluate(make_input(competitor_policy(basis="delivered_total"), competitor_observations=(obs,)))
    assert item.comparables.own_basis_addition == D("0")
    assert item.recommended_price == D("54.00")
    assert delivered.recommended_price == D("60.00")  # 63.99 delivered - our 3.99


def test_position_offsets_are_applied_on_the_comparison_basis():
    obs = (make_obs("a", item="54.00"), make_obs("b", "VoltMart", item="58.00"))
    inp = make_input(competitor_policy(position="match_lowest", offset_pct="-0.01", offset_amount="-0.50"),
                     competitor_observations=obs)
    # lowest delivered 57.99 -> x0.99 = 57.4101 - 0.50 = 56.9101 -> minus our delivery 3.99 = 52.92
    assert evaluate(inp).recommended_price == D("52.92")


@pytest.mark.parametrize("fallback,outcome,strategy", [
    ("hold", "no_change", "competitor_aware"), ("block", "blocked", "competitor_aware")])
def test_policy_controls_fallback_when_no_offer_is_eligible(fallback, outcome, strategy):
    stale = make_obs(item="40.00", hours_ago=200)
    result = evaluate(make_input(competitor_policy(on_no_eligible=fallback), competitor_observations=(stale,)))
    assert result.outcome == outcome and result.selected_strategy == strategy
    assert result.recommended_price in (None, D("59.99"))
    if outcome == "blocked":
        assert result.blocking_issues[0]["code"] == "insufficient_competitor_evidence"


def test_skip_fallback_continues_to_next_strategy():
    policy = policy_with(strategy_order=["competitor_aware", "margin_led"], target_contribution_margin="0.30",
                         competitor={"on_no_eligible": "skip"})
    result = evaluate(make_input(policy, competitor_observations=(make_obs(item="40.00", hours_ago=200),)))
    assert result.selected_strategy == "margin_led"
    assert result.outcome == "change" and result.recommended_price > D("59.99")
    assert any("fresh enough" in w for w in result.warnings)
