"""Optional demand estimation and the isolated simulator."""

from dataclasses import replace
from datetime import date, timedelta
from decimal import Decimal as D

import numpy as np
import pytest

from engine.demand import DemandObservation, estimate_demand
from engine.simulation import Arm, DemandSimulatorConfig, SimulationScenario, run_simulation

from .conftest import NOW, make_cost, make_input, make_obs, policy_with

pytestmark = pytest.mark.engine

START = date(2026, 6, 1)


def synthetic(days=120, elasticity=-2.0, base=20.0, levels=("80.00", "90.00", "100.00", "110.00"), block=15, seed=7,
              stockout_days=()):
    rng = np.random.default_rng(seed)
    out = []
    for i in range(days):
        price = D(levels[(i // block) % len(levels)])
        lam = base * (float(price) / 100.0) ** elasticity
        stockout = i in stockout_days
        out.append(DemandObservation(day=START + timedelta(days=i), price=price,
                                     units=0 if stockout else int(rng.poisson(lam)), stockout=stockout))
    return out


def test_strong_price_variation_validates_and_recovers_the_sign_and_size():
    est = estimate_demand(synthetic())
    assert est.status == "validated", est.reasons
    assert est.elasticity < 0 and est.ci_high < 0
    assert est.ci_low <= -2.0 <= est.ci_high  # the true value is inside the reported interval
    assert est.holdout_improvement >= 0.02 and est.holdout_days == 30
    assert est.n_days_used == 120 and est.n_distinct_prices == 4
    assert any("not a causal price elasticity" in c for c in est.caveats)
    as_input = est.to_model_input("m1", NOW)
    assert as_input.status == "validated" and as_input.elasticity < 0 and as_input.reference_price == D("95.00")


def test_too_little_data_is_insufficient_evidence():
    est = estimate_demand(synthetic(days=10))
    assert est.status == "insufficient_evidence"
    assert any("usable in-stock days" in r for r in est.reasons)
    assert est.elasticity is None


def test_single_price_cannot_relate_sales_to_price():
    est = estimate_demand(synthetic(levels=("100.00",)))
    assert est.status == "insufficient_evidence"
    assert any("distinct price" in r for r in est.reasons)


def test_tiny_price_range_is_rejected():
    est = estimate_demand(synthetic(levels=("100.00", "100.50", "101.00")))
    assert est.status == "insufficient_evidence"
    assert any("too little variation" in r for r in est.reasons)


def test_no_real_price_effect_is_not_validated():
    est = estimate_demand(synthetic(elasticity=0.0, base=3.0, seed=11))
    assert est.status == "insufficient_evidence"
    assert any("includes zero" in r or "baseline" in r for r in est.reasons)


def test_stockout_days_are_censored_not_zero_demand():
    stockouts = set(range(15, 30))  # the whole 90.00 block of the first cycle
    flagged = estimate_demand(synthetic(stockout_days=stockouts))
    assert flagged.n_days_excluded_stockout == 15 and flagged.n_days_used == 105
    assert any("not read as zero demand" in c for c in flagged.caveats)
    # The same zeros treated as genuine demand drag the baseline down; excluding them keeps it near the truth.
    unflagged = estimate_demand([replace(o, stockout=False) for o in synthetic(stockout_days=stockouts)])
    assert flagged.reference_units_per_day > unflagged.reference_units_per_day
    # Selling everything that was available is censored too.
    sold_out = [replace(o, available_units=o.units) if i < 10 else o for i, o in enumerate(synthetic())]
    assert estimate_demand(sold_out).n_days_excluded_stockout == 10


# ------------------------------------------------------------------ simulation

SIM_START = NOW - timedelta(days=30)
COMPETITOR_ARM = policy_with(strategy_order=["competitor_aware", "margin_led"], target_contribution_margin="0.15",
                             max_change_pct_per_evaluation="0.10", competitor={"on_no_eligible": "skip"})
RULES_ARM = policy_with(strategy_order=["margin_led"], target_contribution_margin="0.15")
GUARD = policy_with(strategy_order=["margin_led"], target_contribution_margin="0.15")


def timeline(days, price_for_day, start=0):
    return tuple(make_obs(f"d{d}", item=price_for_day(d), now=SIM_START + timedelta(days=d), hours_ago=1,
                          listing_key="th-1") for d in range(start, days))


def scenario(*, days=30, costs=None, competitors=None, seed=5, arms=None):
    costs = costs or ((SIM_START - timedelta(days=60), make_cost()),)
    return SimulationScenario(
        start=SIM_START, days=days, base_input=make_input(GUARD, evaluation_time=SIM_START, inventory=None),
        initial_price=D("59.99"), initial_on_hand=400, cost_timeline=tuple(costs),
        competitor_timeline=competitors if competitors is not None else timeline(days, lambda d: "56.00"),
        demand=DemandSimulatorConfig(base_units_per_day=6.0, reference_price=D("59.99"), elasticity=-2.0,
                                     competitor_sensitivity=1.0, seed=seed),
        arms=arms or (Arm("fixed", "Fixed", None), Arm("rules", "Rules", RULES_ARM),
                      Arm("competitor_aware", "Competitor-aware", COMPETITOR_ARM)),
        guard_policy=GUARD,
    )


def arm(results, key):
    return next(a for a in results["arms"] if a["key"] == key)


def test_simulation_is_deterministic_for_a_seed_and_labelled():
    first, second = run_simulation(scenario()), run_simulation(scenario())
    assert first == second
    assert first["label"].startswith("SIMULATED")
    assert any("cannot show what would have sold" in a for a in first["assumptions"])
    other_seed = run_simulation(scenario(seed=6))
    assert arm(other_seed, "fixed")["daily"] != arm(first, "fixed")["daily"]


def test_simulation_reports_required_metrics_and_arms_differ_by_pricing():
    results = run_simulation(scenario())
    fixed, competitive = arm(results, "fixed"), arm(results, "competitor_aware")
    for key in ("revenue_net", "units_sold", "contribution", "contribution_margin", "ending_inventory",
                "stockout_days", "price_volatility", "constraint_breach_days", "rejected_recommendations"):
        assert key in fixed
    assert fixed["price_changes"] == 0 and fixed["final_price"] == "59.99" and fixed["price_volatility"] == 0.0
    # Competitor at 56.00 + 3.99 delivered -> our item target 56.00.
    assert competitive["final_price"] == "56.00" and competitive["price_changes"] == 1
    assert competitive["units_sold"] > fixed["units_sold"]
    assert fixed["ending_inventory"] == 400 - fixed["units_sold"]


def test_no_future_competitor_data_leaks_into_earlier_decisions():
    base = timeline(15, lambda d: "58.00")
    future = timeline(30, lambda d: "50.00", start=15)  # a price drop that only becomes visible on day 15
    without = arm(run_simulation(scenario(competitors=base)), "competitor_aware")
    with_future = arm(run_simulation(scenario(competitors=base + future)), "competitor_aware")
    assert with_future["daily"][:15] == without["daily"][:15]
    assert [d for d in with_future["decisions"] if d["day"] < 15] == [d for d in without["decisions"] if d["day"] < 15]
    # ...and the drop is acted on once it has been observed.
    assert any(d["day"] >= 15 for d in with_future["decisions"])
    assert with_future["final_price"] != without["final_price"]


def test_no_future_cost_leaks_into_earlier_decisions():
    early = (SIM_START - timedelta(days=60), make_cost())
    increase = (SIM_START + timedelta(days=20), make_cost(acquisition_cost=D("44.00")))
    without = arm(run_simulation(scenario(costs=(early,))), "rules")
    with_future = arm(run_simulation(scenario(costs=(early, increase))), "rules")
    assert with_future["daily"][:20] == without["daily"][:20]
    assert with_future["decisions"] and all(d["day"] >= 20 for d in with_future["decisions"])
    assert without["decisions"] == []


def test_fixed_price_breaches_the_floor_after_a_cost_increase_while_rules_react():
    costs = ((SIM_START - timedelta(days=60), make_cost()),
             (SIM_START + timedelta(days=10), make_cost(acquisition_cost=D("44.00"))))
    results = run_simulation(scenario(costs=costs, competitors=()))
    fixed, rules = arm(results, "fixed"), arm(results, "rules")
    assert fixed["constraint_breach_days"] == 20  # days 10..29 at a price below the new floor
    assert rules["constraint_breach_days"] == 0
    assert rules["decisions"][0]["day"] == 10 and D(rules["final_price"]) > D("59.99")
    assert D(rules["contribution"]) / D(rules["revenue_net"]) > D(fixed["contribution"]) / D(fixed["revenue_net"])


def test_stockouts_are_counted_and_sales_are_capped_by_stock():
    sc = replace(scenario(arms=(Arm("fixed", "Fixed", None),)), initial_on_hand=40)
    fixed = arm(run_simulation(sc), "fixed")
    assert fixed["units_sold"] == 40 and fixed["ending_inventory"] == 0
    assert fixed["stockout_days"] > 0 and fixed["unmet_demand_units"] > 0


def test_conflicts_count_as_rejected_recommendations():
    conflicted = policy_with(strategy_order=["margin_led"], target_contribution_margin="0.15", absolute_max_price="40.00")
    results = run_simulation(scenario(days=5, arms=(Arm("bad", "Conflicted", conflicted),)))
    assert arm(results, "bad")["rejected_recommendations"] == 5
    assert arm(results, "bad")["price_changes"] == 0
