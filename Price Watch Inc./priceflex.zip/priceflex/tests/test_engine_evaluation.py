"""The deterministic evaluation: blocking, conflicts, strategies, stability, reproducibility."""

import json
from datetime import date, timedelta
from decimal import Decimal as D

import pytest

from engine import ALGORITHM_VERSION
from engine.constraints import apply_price_ending, compute_interval
from engine.evaluation import evaluate, validate_price
from engine.money import margin_breakdown, minimum_price_for
from engine.policy import load_policy, parse_policy, validate_policy
from engine.strategies import inventory_metrics
from engine.types import (
    CommitmentInput,
    DemandModelInput,
    EvaluationInput,
    InventoryInput,
    PricePoint,
    PromotionInput,
    SalesPeriod,
    snapshot_hash,
)

from .conftest import NOW, make_cost, make_input, make_obs, make_tax, policy_with

pytestmark = pytest.mark.engine

FLOOR_12 = minimum_price_for(make_cost(), make_tax(), min_margin=D("0.12"), customer_delivery_charge=D("3.99")).price


def competitor_policy(**extra):
    competitor = extra.pop("competitor", {})
    return policy_with(strategy_order=["competitor_aware"], competitor=competitor, **extra)


def codes(result):
    return [i["code"] for i in result.blocking_issues]


# ------------------------------------------------------------------ blocking


def test_floor_constant_is_what_we_think_it_is():
    assert FLOOR_12 == D("49.13")
    assert margin_breakdown(FLOOR_12, make_cost(), make_tax()).contribution_margin >= D("0.12")


def test_missing_cost_blocks_with_explanation():
    result = evaluate(make_input(cost=None, cost_issue="No cost version is effective for SKU-1."))
    assert result.outcome == "blocked" and result.recommended_price is None
    assert codes(result) == ["missing_cost"]
    assert "No cost version" in result.reasons[0]
    assert not result.publishable


def test_missing_tax_blocks_as_uncertain_configuration():
    result = evaluate(make_input(tax=None))
    assert result.outcome == "blocked" and codes(result) == ["uncertain_tax_configuration"]


def test_invalid_policy_blocks_instead_of_being_repaired():
    result = evaluate(make_input({"strategy_order": ["margin_led"]}))
    assert result.outcome == "blocked" and codes(result) == ["invalid_policy"]
    assert "cost floor" in result.blocking_issues[0]["message"]


def test_currency_mismatch_blocks_without_conversion():
    result = evaluate(make_input(cost=make_cost(currency="EUR")))
    assert codes(result) == ["currency_mismatch"]


def test_stale_cost_blocks_when_policy_sets_a_limit():
    old = make_cost(effective_from=(NOW - timedelta(days=400)).isoformat())
    assert evaluate(make_input(policy_with(max_cost_age_days=365), cost=old)).outcome == "blocked"
    assert codes(evaluate(make_input(policy_with(max_cost_age_days=365), cost=old))) == ["stale_cost"]
    assert evaluate(make_input(policy_with(), cost=old)).outcome != "blocked"  # no limit configured
    assert evaluate(make_input(policy_with(max_cost_age_days=365))).outcome != "blocked"  # fresh cost


@pytest.mark.parametrize("behaviour", ["warn", "block"])
def test_stale_inventory_follows_policy(behaviour):
    stale = InventoryInput(on_hand=100, as_of=NOW - timedelta(hours=100))
    policy = policy_with(inventory={"on_stale_inventory": behaviour, "max_inventory_age_hours": 48})
    result = evaluate(make_input(policy, inventory=stale))
    if behaviour == "block":
        assert result.outcome == "blocked" and codes(result) == ["stale_inventory"]
    else:
        assert result.outcome == "no_change"
        assert any("stale" in w for w in result.warnings)


def test_all_blocking_issues_are_reported_together():
    result = evaluate(make_input(cost=None, tax=None))
    assert set(codes(result)) == {"missing_cost", "uncertain_tax_configuration"}


# ------------------------------------------------------------------ margin-led


def test_margin_led_raises_to_the_lowest_price_meeting_the_target():
    result = evaluate(make_input(policy_with(target_contribution_margin="0.30")))
    expected = minimum_price_for(make_cost(), make_tax(), min_margin=D("0.30"), customer_delivery_charge=D("3.99")).price
    assert result.outcome == "change" and result.selected_strategy == "margin_led"
    assert result.recommended_price == expected > D("59.99")
    assert result.margin_recommended.contribution_margin >= D("0.30")
    assert any("below the configured target" in r for r in result.reasons)


def test_margin_led_never_cuts_a_price_that_meets_the_target():
    result = evaluate(make_input(policy_with(target_contribution_margin="0.15")))
    assert result.outcome == "no_change" and result.recommended_price == D("59.99")
    assert result.reasons[0].startswith("No price change is recommended")
    assert any("meets the configured target" in r for r in result.reasons)


def test_current_price_below_floor_must_rise_even_without_a_strategy_target():
    # Cost rises so the 12% floor is above the current price; the target (15%) is higher still.
    cost = make_cost(acquisition_cost=D("42.00"))
    floor = minimum_price_for(cost, make_tax(), min_margin=D("0.12"), customer_delivery_charge=D("3.99")).price
    assert floor > D("59.99")
    result = evaluate(make_input(policy_with(strategy_order=["inventory_led"], target_contribution_margin=None), cost=cost))
    assert result.outcome == "change" and result.recommended_price == floor
    assert "minimum_contribution_margin" in result.constraints_applied
    assert any("must rise" in r for r in result.reasons)


# ------------------------------------------------------------------ competitor below floor


def test_competitor_below_floor_keeps_the_floor_and_explains():
    obs = make_obs(item="36.01", delivery="3.99")  # delivered 40.00 -> item target 36.01
    result = evaluate(make_input(competitor_policy(), competitor_observations=(obs,)))
    assert result.outcome == "change"
    assert result.recommended_price == FLOOR_12
    assert "minimum_contribution_margin" in result.constraints_applied
    assert any("floor is kept" in r and "not" in r for r in result.reasons)
    assert result.margin_recommended.contribution_margin >= D("0.12")
    assert result.margin_recommended.contribution > 0


# ------------------------------------------------------------------ conflicts


def test_floor_above_absolute_maximum_is_a_conflict_with_no_price():
    result = evaluate(make_input(policy_with(absolute_max_price="40.00")))
    assert result.outcome == "conflict" and result.recommended_price is None
    assert result.interval.conflict
    text = " ".join(result.reasons)
    assert "minimum_contribution_margin" in text and "absolute_maximum_price" in text
    assert not result.publishable


def test_floor_above_contractual_maximum_is_a_conflict():
    commitment = CommitmentInput("c1", "max_price", D("45.00"), reference="FA-1")
    result = evaluate(make_input(commitments=(commitment,)))
    assert result.outcome == "conflict" and result.recommended_price is None
    assert "contractual_maximum_price" in " ".join(result.reasons)
    expired = CommitmentInput("c1", "max_price", D("45.00"), valid_to=NOW - timedelta(days=1))
    assert evaluate(make_input(commitments=(expired,))).outcome == "no_change"


def test_movement_limit_cannot_override_the_cost_floor():
    result = evaluate(make_input(policy_with(max_change_pct_per_evaluation="0.05"), current_price=D("40.00"),
                                 price_history=(PricePoint(NOW - timedelta(days=90), D("40.00")),)))
    assert result.outcome == "conflict" and result.recommended_price is None
    assert "maximum_price_change" in " ".join(result.reasons)
    assert any("below the hard floor" in w for w in result.warnings)


def test_contractual_minimum_and_fixed_price_bounds():
    low_obs = make_obs(item="46.01")  # delivered 50.00 -> target 46.01, below MAP
    map_price = CommitmentInput("c1", "min_price", D("57.00"), reference="MAP")
    result = evaluate(make_input(competitor_policy(), competitor_observations=(low_obs,), commitments=(map_price,)))
    assert result.recommended_price == D("57.00")
    assert "contractual_minimum_price" in result.constraints_applied
    fixed = CommitmentInput("c2", "fixed_price", D("58.00"))
    result = evaluate(make_input(competitor_policy(), competitor_observations=(low_obs,), commitments=(fixed,)))
    assert result.recommended_price == D("58.00")


# ------------------------------------------------------------------ price endings


def test_price_ending_applied_after_clamping_and_stays_inside_interval():
    obs = make_obs(item="36.01")  # target far below the floor of 49.13
    result = evaluate(make_input(competitor_policy(price_endings=["0.99"]), competitor_observations=(obs,)))
    # 48.99 is the nearest .99 to the floor but would breach it; the ending must round up to 49.99.
    assert result.recommended_price == D("49.99")
    assert result.recommended_price >= result.interval.lower
    assert result.constraints_applied == ["minimum_contribution_margin", "price_ending"]
    assert result.interval.violations(result.recommended_price) == []


def test_price_ending_picks_nearest_and_ties_go_down():
    policy = competitor_policy(price_endings=["0.99", "0.49"])
    near = evaluate(make_input(policy, competitor_observations=(make_obs(item="55.10"),)))
    assert near.recommended_price == D("54.99")
    tie = evaluate(make_input(policy, competitor_observations=(make_obs(item="55.24"),)))
    assert tie.recommended_price == D("54.99")  # 55.24 is 0.25 from both 54.99 and 55.49
    up = evaluate(make_input(policy, competitor_observations=(make_obs(item="55.30"),)))
    assert up.recommended_price == D("55.49")


@pytest.mark.parametrize("fallback", ["keep_unrounded", "conflict"])
def test_ending_fallback_when_no_ending_fits(fallback):
    # Interval is 59.70..60.28 (0.5% movement); the only allowed ending is .49, which cannot fit.
    policy = competitor_policy(price_endings=["0.49"], max_change_pct_per_evaluation="0.005", ending_fallback=fallback)
    result = evaluate(make_input(policy, competitor_observations=(make_obs(item="59.75"),)))
    if fallback == "keep_unrounded":
        assert result.outcome == "change" and result.recommended_price == D("59.75")
        assert any("No allowed price ending fits" in w for w in result.warnings)
        assert "price_ending" not in result.constraints_applied
    else:
        assert result.outcome == "conflict" and result.recommended_price is None


def test_apply_price_ending_unit():
    interval = compute_interval(policy=load_policy(policy_with()), cost=make_cost(), tax=make_tax(), currency="GBP",
                                evaluation_time=NOW, current_price=None, standard_retail_price=None)
    assert interval.lower == minimum_price_for(make_cost(), make_tax(), min_margin=D("0.12")).price
    assert apply_price_ending(D("52.30"), (D("0.99"),), interval) == D("51.99")
    assert apply_price_ending(interval.lower, (D("0.99"),), interval) >= interval.lower
    assert apply_price_ending(D("52.30"), (), interval) == D("52.30")


def test_rounding_back_to_current_price_is_no_change():
    policy = competitor_policy(price_endings=["0.99"])
    result = evaluate(make_input(policy, competitor_observations=(make_obs(item="60.20"),)))
    assert result.outcome == "no_change" and result.recommended_price == D("59.99")


# ------------------------------------------------------------------ movement and stability


def test_maximum_change_per_evaluation_bounds_the_move():
    policy = competitor_policy(max_change_pct_per_evaluation="0.05")
    result = evaluate(make_input(policy, competitor_observations=(make_obs(item="52.00"),)))
    assert result.recommended_price == D("57.00")  # 59.99 x 0.95 = 56.9905, rounded up to stay inside the limit
    assert "maximum_price_change" in result.constraints_applied


def test_cumulative_movement_uses_recorded_price_history():
    history = (PricePoint(NOW - timedelta(days=60), D("70.00")), PricePoint(NOW - timedelta(days=20), D("66.00")),
               PricePoint(NOW - timedelta(days=5), D("59.99")))
    policy = competitor_policy(max_cumulative_change_pct="0.20", cumulative_window_days=30)
    result = evaluate(make_input(policy, price_history=history, competitor_observations=(make_obs(item="50.00"),)))
    # 30 days ago the price in effect was 70.00, so the lowest allowed price is 56.00 - not 59.99 x 0.8.
    assert result.recommended_price == D("56.00")
    assert "maximum_cumulative_movement" in result.constraints_applied
    # With a short window the reference becomes the 66.00 price in effect 10 days ago.
    short = evaluate(make_input(dict(policy, cumulative_window_days=10), price_history=history,
                                competitor_observations=(make_obs(item="50.00"),)))
    assert short.recommended_price == D("52.80")


def test_cooldown_holds_the_price_and_says_until_when():
    history = (PricePoint(NOW - timedelta(days=90), D("62.99")), PricePoint(NOW - timedelta(hours=6), D("59.99")))
    policy = competitor_policy(cooldown_hours=24)
    held = evaluate(make_input(policy, price_history=history, competitor_observations=(make_obs(item="52.00"),)))
    assert held.outcome == "no_change" and held.recommended_price == D("59.99")
    assert "cooldown" in held.constraints_applied
    assert any("Cooldown" in r and "no change before" in r for r in held.reasons)
    later = evaluate(make_input(policy, competitor_observations=(make_obs(item="52.00"),),
                                price_history=(PricePoint(NOW - timedelta(hours=30), D("59.99")),)))
    assert later.outcome == "change" and later.recommended_price == D("52.00")


def test_cooldown_cannot_hide_a_floor_breach():
    history = (PricePoint(NOW - timedelta(hours=6), D("59.99")),)
    result = evaluate(make_input(policy_with(cooldown_hours=24), cost=make_cost(acquisition_cost=D("42.00")),
                                 price_history=history))
    assert result.outcome == "conflict"
    assert "cooldown" in " ".join(result.reasons)


def test_minimum_meaningful_change_prevents_churn():
    policy = competitor_policy(min_meaningful_change_amount="0.25", min_meaningful_change_pct="0.005")
    small = evaluate(make_input(policy, competitor_observations=(make_obs(item="59.79"),)))  # -0.20 < 0.30 (0.5%)
    assert small.outcome == "no_change" and "minimum_meaningful_change" in small.constraints_applied
    large = evaluate(make_input(policy, competitor_observations=(make_obs(item="59.49"),)))  # -0.50
    assert large.outcome == "change" and large.recommended_price == D("59.49")


def test_hysteresis_blocks_small_reversals_only():
    rose = (PricePoint(NOW - timedelta(days=90), D("57.99")), PricePoint(NOW - timedelta(days=5), D("59.99")))
    policy = competitor_policy(hysteresis_pct="0.02")
    reversal = evaluate(make_input(policy, price_history=rose, competitor_observations=(make_obs(item="59.49"),)))
    assert reversal.outcome == "no_change" and "hysteresis" in reversal.constraints_applied
    same_direction = evaluate(make_input(policy, price_history=rose, competitor_observations=(make_obs(item="60.49"),)))
    assert same_direction.outcome == "change" and same_direction.recommended_price == D("60.49")
    big_reversal = evaluate(make_input(policy, price_history=rose, competitor_observations=(make_obs(item="57.00"),)))
    assert big_reversal.outcome == "change" and big_reversal.recommended_price == D("57.00")


# ------------------------------------------------------------------ inventory


def sales(units_per_day, days, *, stockout_last=0, start_back=None):
    start_back = start_back or days
    out = []
    for back in range(start_back, 0, -1):
        stockout = back <= stockout_last
        out.append(SalesPeriod(day=NOW.date() - timedelta(days=back), units=0 if stockout else units_per_day,
                               stockout=stockout))
    return tuple(out)


def inventory_policy(**inventory):
    return policy_with(strategy_order=["inventory_led"], target_contribution_margin=None, inventory=inventory)


def test_stockout_days_are_excluded_from_the_sales_rate():
    inp = make_input(sales=sales(4, 15, stockout_last=5))
    metrics = inventory_metrics(inp, load_policy(inp.policy))
    assert metrics.in_stock_days == 10 and metrics.stockout_days == 5
    assert metrics.avg_daily_sales == D("4.0000")  # not 40 / 15 = 2.67
    assert metrics.cover_days == D("25.0")
    result = evaluate(inp)
    assert any("5 stockout day(s) were excluded" in w for w in result.warnings)


def test_unknown_demand_is_not_zero_demand():
    inp = make_input(sales=sales(0, 10, stockout_last=10))
    metrics = inventory_metrics(inp, load_policy(inp.policy))
    assert metrics.avg_daily_sales is None and metrics.cover_days is None
    assert not metrics.no_sales_while_in_stock


def test_stockout_holds_the_price_despite_a_lower_competitor():
    out = InventoryInput(on_hand=0, as_of=NOW - timedelta(hours=1))
    result = evaluate(make_input(competitor_policy(), inventory=out, sales=sales(4, 20, stockout_last=9),
                                 competitor_observations=(make_obs(item="52.00"),)))
    assert result.outcome == "no_change" and result.selected_strategy == "stockout_hold"
    assert any("out of stock" in r for r in result.reasons)
    ignoring = evaluate(make_input(competitor_policy(on_stockout="ignore"), inventory=out,
                                   competitor_observations=(make_obs(item="52.00"),)))
    assert ignoring.selected_strategy == "competitor_aware" and ignoring.recommended_price == D("52.00")


def test_inventory_led_overstock_markdown_is_bounded():
    inv = InventoryInput(on_hand=1000, as_of=NOW - timedelta(hours=1))
    result = evaluate(make_input(inventory_policy(), inventory=inv, sales=sales(2, 28)))
    assert result.selected_strategy == "inventory_led"
    assert result.recommended_price == D("56.99")  # one 5% step from 59.99
    assert any("above the 90-day threshold" in r for r in result.reasons)


def test_inventory_led_scarcity_markup_needs_short_cover_long_lead_time_and_nothing_inbound():
    scarce = InventoryInput(on_hand=6, as_of=NOW - timedelta(hours=1), replenishment_lead_time_days=14)
    result = evaluate(make_input(inventory_policy(), inventory=scarce, sales=sales(3, 28)))
    assert result.recommended_price == D("61.79")  # 59.99 x 1.03
    inbound = InventoryInput(on_hand=6, inbound=50, as_of=NOW - timedelta(hours=1), replenishment_lead_time_days=14)
    assert evaluate(make_input(inventory_policy(), inventory=inbound, sales=sales(3, 28))).outcome == "no_change"


def test_inventory_led_aged_stock_and_in_band():
    aged = InventoryInput(on_hand=60, as_of=NOW - timedelta(hours=1), oldest_stock_received_at=NOW - timedelta(days=200))
    result = evaluate(make_input(inventory_policy(), inventory=aged, sales=sales(2, 28)))
    assert result.recommended_price == D("55.19")  # 8% aged-stock step
    healthy = InventoryInput(on_hand=60, as_of=NOW - timedelta(hours=1))
    in_band = evaluate(make_input(inventory_policy(), inventory=healthy, sales=sales(2, 28)))
    assert in_band.outcome == "no_change"
    assert any("No strategy in the policy's order applied" in r for r in in_band.reasons)


def clearance_policy(**extra):
    return policy_with(
        strategy_order=["clearance", "margin_led"], target_contribution_margin="0.15",
        clearance={"enabled": True, "min_contribution_margin": "0.00", "min_contribution_amount": "0.50",
                   "schedule": [{"days_before": 30, "markdown_pct": "0.10"}, {"days_before": 14, "markdown_pct": "0.20"},
                                {"days_before": 7, "markdown_pct": "0.30"}]}, **extra)


@pytest.mark.parametrize("days_left,expected,outcome", [
    (40, "59.99", "no_change"),   # window not open
    (25, "58.49", "change"),      # 10% off 64.99
    (12, "51.99", "change"),      # 20% off
    (5, "45.49", "change"),       # 30% off - below the standard 12% floor (49.13), allowed by the clearance floor
])
def test_clearance_tiers(days_left, expected, outcome):
    inv = InventoryInput(on_hand=400, as_of=NOW - timedelta(hours=1), clearance_date=NOW.date() + timedelta(days=days_left))
    result = evaluate(make_input(clearance_policy(), inventory=inv, sales=sales(1, 28)))
    assert result.outcome == outcome and result.recommended_price == D(expected)
    if outcome == "change":
        assert result.selected_strategy == "clearance" and result.mode == "clearance"


def test_clearance_floor_is_explicit_and_still_enforced():
    inv = InventoryInput(on_hand=400, as_of=NOW - timedelta(hours=1), clearance_date=NOW.date() + timedelta(days=5))
    cost = make_cost(acquisition_cost=D("44.00"))
    result = evaluate(make_input(clearance_policy(), inventory=inv, sales=sales(1, 28), cost=cost))
    floor = max(
        minimum_price_for(cost, make_tax(), min_margin=D("0"), customer_delivery_charge=D("3.99")).price,
        minimum_price_for(cost, make_tax(), min_amount=D("0.50"), customer_delivery_charge=D("3.99")).price)
    assert result.recommended_price == floor > D("45.49")
    assert result.margin_recommended.contribution >= D("0.50")
    assert "clearance_minimum_contribution_amount" in result.constraints_applied


def test_clearance_not_applied_when_on_track_to_sell_through():
    inv = InventoryInput(on_hand=20, as_of=NOW - timedelta(hours=1), clearance_date=NOW.date() + timedelta(days=12))
    result = evaluate(make_input(clearance_policy(), inventory=inv, sales=sales(4, 28)))  # cover 5 days
    assert result.selected_strategy == "margin_led" and result.outcome == "no_change"
    trace = {p.strategy: p for p in result.selection_trace}
    assert "on track" in trace["clearance"].reasons[0]


# ------------------------------------------------------------------ promotion


def promo(**overrides):
    values = dict(promotion_id="p1", name="Autumn offer", status="approved", starts_at=NOW - timedelta(hours=2),
                  ends_at=NOW + timedelta(days=5), kind="percent_off", value=D("0.20"))
    values.update(overrides)
    return PromotionInput(**values)


def promo_policy(**extra):
    base = dict(strategy_order=["promotion", "competitor_aware"], max_change_pct_per_evaluation="0.05",
                cooldown_hours=24, price_endings=["0.49"])
    base.update(extra)
    return policy_with(**base)


def test_promotion_takes_precedence_and_is_exempt_from_movement_limits_and_endings():
    recent = (PricePoint(NOW - timedelta(hours=3), D("59.99")),)  # inside the cooldown
    result = evaluate(make_input(promo_policy(), promotions=(promo(),), price_history=recent,
                                 competitor_observations=(make_obs(item="58.00"),)))
    assert result.selected_strategy == "promotion" and result.mode == "promotion"
    assert result.recommended_price == D("51.99")  # 20% off 64.99, a 13% move, not re-rounded to .49
    assert "price_ending" not in result.constraints_applied
    assert [p.strategy for p in result.selection_trace] == ["promotion", "competitor_aware"]
    assert result.selection_trace[0].selected and not result.selection_trace[1].selected


def test_promotion_respects_movement_limits_when_policy_removes_the_exemption():
    result = evaluate(make_input(promo_policy(promotion_exempt_from_movement_limits=False, price_endings=[],
                                              cooldown_hours=0), promotions=(promo(),)))
    assert result.recommended_price == D("57.00")
    assert "maximum_price_change" in result.constraints_applied


@pytest.mark.parametrize("overrides", [
    dict(status="draft"), dict(starts_at=NOW + timedelta(hours=1)), dict(ends_at=NOW - timedelta(minutes=1))])
def test_unapproved_or_inactive_promotions_are_ignored(overrides):
    result = evaluate(make_input(promo_policy(cooldown_hours=0, price_endings=[]), promotions=(promo(**overrides),),
                                 competitor_observations=(make_obs(item="58.00"),)))
    assert result.selected_strategy == "competitor_aware" and result.mode == "standard"
    assert result.recommended_price == D("58.00")


def test_promotion_cannot_go_below_floor_but_supplier_funding_and_approved_floor_count():
    deep = promo(kind="fixed_price", value=D("42.00"))
    held = evaluate(make_input(promo_policy(), promotions=(deep,)))
    assert held.recommended_price == FLOOR_12
    funded = evaluate(make_input(promo_policy(), promotions=(promo(kind="fixed_price", value=D("42.00"),
                                                                   supplier_funding_per_unit=D("6.00")),)))
    assert funded.recommended_price < FLOOR_12
    assert funded.margin_recommended.promotion_funding == D("6.00")
    assert funded.margin_recommended.contribution_margin >= D("0.12")
    approved_floor = evaluate(make_input(promo_policy(), promotions=(promo(kind="fixed_price", value=D("42.00"),
                                         approved_min_contribution_margin=D("0.00")),)))
    assert approved_floor.recommended_price == max(
        D("42.00"), minimum_price_for(make_cost(), make_tax(), min_margin=D("0"), customer_delivery_charge=D("3.99")).price)


# ------------------------------------------------------------------ demand-led fallback


def demand_policy():
    return policy_with(strategy_order=["demand_led", "margin_led"], target_contribution_margin="0.15",
                       max_change_pct_per_evaluation="0.05", demand={"enabled": True, "max_model_age_days": 30})


def model(**overrides):
    values = dict(model_id="m1", status="validated", elasticity=D("-3.0"), ci_low=D("-4.0"), ci_high=D("-2.0"),
                  reference_price=D("59.99"), reference_units_per_day=D("6"), fitted_at=NOW - timedelta(days=1))
    values.update(overrides)
    return DemandModelInput(**values)


def test_demand_led_only_with_a_validated_fresh_model():
    none = evaluate(make_input(demand_policy()))
    assert none.selected_strategy == "margin_led"
    weak = evaluate(make_input(demand_policy(), demand_model=model(status="insufficient_evidence", reasons=("Too few days",))))
    assert weak.selected_strategy == "margin_led" and weak.outcome == "no_change"
    trace = {p.strategy: p for p in weak.selection_trace}
    assert not trace["demand_led"].applicable and "rules baseline" in trace["demand_led"].reasons[0]
    old = evaluate(make_input(demand_policy(), demand_model=model(fitted_at=NOW - timedelta(days=45))))
    assert old.selected_strategy == "margin_led"


def test_demand_led_optimises_inside_the_feasible_interval_and_labels_the_projection():
    result = evaluate(make_input(demand_policy(), demand_model=model()))
    assert result.selected_strategy == "demand_led"
    assert result.interval.lower <= result.recommended_price <= result.interval.upper
    # The unconstrained optimum for elasticity -3 is about 64.50, above the 5% movement limit (62.98), so the
    # answer sits at the top of the feasible range (to within cent-level tax/fee rounding).
    assert result.interval.upper == D("62.98")
    assert result.interval.upper - D("0.10") <= result.recommended_price <= result.interval.upper
    from engine.demand import expected_units

    def daily(price):
        b = margin_breakdown(price, make_cost(), make_tax(), customer_delivery_charge=D("3.99"))
        return float(b.contribution) * expected_units(model(), price)

    assert daily(result.recommended_price) > daily(D("59.99")) > daily(result.interval.lower)
    forecast = result.projection["volume_forecast"]
    assert forecast["expected_units_per_day_low"] <= forecast["expected_units_per_day"] <= forecast["expected_units_per_day_high"]
    assert "observational" in result.projection["volume_forecast_note"]
    assert any("not a proven causal effect" in r for r in result.reasons)


def test_no_volume_forecast_is_invented_without_a_demand_model():
    result = evaluate(make_input(policy_with(target_contribution_margin="0.30")))
    assert result.projection["volume_forecast"] is None
    assert result.projection["label"].startswith("PROJECTION")
    assert D(result.projection["unit_contribution_change"]) == (
        result.margin_recommended.contribution - result.margin_current.contribution)


# ------------------------------------------------------------------ reproducibility


def rich_input():
    policy = policy_with(
        strategy_order=["promotion", "clearance", "competitor_aware", "inventory_led", "margin_led"],
        max_change_pct_per_evaluation="0.08", max_cumulative_change_pct="0.20", cooldown_hours=12,
        price_endings=["0.99", "0.49"], hysteresis_pct="0.01", min_meaningful_change_amount="0.10",
        clearance={"enabled": True, "schedule": [{"days_before": 14, "markdown_pct": "0.2"}]})
    return make_input(
        policy,
        competitor_observations=(make_obs("1", item="54.00"), make_obs("2", "VoltMart", item="40.00", condition="used"),
                                 make_obs("3", "GadgetGrove", item=None, delivery=None)),
        sales=sales(3, 30, stockout_last=4),
        promotions=(promo(status="draft"),),
        commitments=(CommitmentInput("c", "min_price", D("45.00"), reference="MAP", valid_from=NOW - timedelta(days=5)),),
        price_history=(PricePoint(NOW - timedelta(days=80), D("62.99")), PricePoint(NOW - timedelta(days=9), D("59.99"))),
        demand_model=model(status="insufficient_evidence"),
        inventory=InventoryInput(on_hand=80, reserved=3, as_of=NOW - timedelta(hours=2),
                                 clearance_date=date(2027, 3, 1), oldest_stock_received_at=NOW - timedelta(days=40)),
    )


def test_snapshot_round_trip_reproduces_the_decision_exactly():
    inp = rich_input()
    payload = inp.to_dict()
    stored = json.loads(json.dumps(payload))  # what a JSON column gives back
    first = evaluate(inp).to_dict()
    replayed = evaluate(EvaluationInput.from_dict(stored)).to_dict()
    assert first == replayed
    assert first["outcome"] == "change" and first["algorithm_version"] == ALGORITHM_VERSION
    assert EvaluationInput.from_dict(stored).to_dict() == payload
    assert json.loads(json.dumps(first)) == first  # the result itself is plain JSON


def test_snapshot_hash_is_stable_and_sensitive():
    inp = rich_input()
    assert snapshot_hash(inp.to_dict()) == snapshot_hash(json.loads(json.dumps(inp.to_dict())))
    assert len(snapshot_hash(inp.to_dict())) == 64
    changed = make_input(inp.policy, current_price=D("60.00"))
    assert snapshot_hash(changed.to_dict()) != snapshot_hash(make_input(inp.policy).to_dict())


def test_same_inputs_same_policy_same_answer_and_policy_change_is_visible():
    obs = (make_obs(item="54.00"),)
    a = evaluate(make_input(competitor_policy(), competitor_observations=obs))
    b = evaluate(make_input(competitor_policy(), competitor_observations=obs))
    assert a.to_dict() == b.to_dict()
    c = evaluate(make_input(competitor_policy(competitor={"offset_pct": "-0.02"}), competitor_observations=obs))
    assert c.recommended_price != a.recommended_price


def test_evaluation_requires_timezone_aware_times():
    payload = make_input().to_dict()
    payload["evaluation_time"] = "2026-11-24T12:00:00"
    with pytest.raises(ValueError):
        EvaluationInput.from_dict(payload)


# ------------------------------------------------------------------ policy validation


@pytest.mark.parametrize("config,fragment", [
    ({"strategy_order": ["margin_led"], "target_contribution_margin": "0.2"}, "cost floor always exists"),
    (policy_with(surprise="x"), "Unknown policy keys: surprise"),
    (policy_with(strategy_order=["margin_led", "follow_the_leader"]), "unknown strategies"),
    (policy_with(strategy_order=["margin_led", "margin_led"]), "only once"),
    (policy_with(target_contribution_margin=None), "target_contribution_margin is required"),
    (policy_with(target_contribution_margin="0.05"), "cannot be below min_contribution_margin"),
    (policy_with(strategy_order=["clearance", "margin_led"]), "clearance.enabled must be true"),
    (policy_with(strategy_order=["demand_led", "margin_led"]), "demand.enabled must be true"),
    (policy_with(absolute_min_price="50", absolute_max_price="40"), "cannot exceed absolute_max_price"),
    (policy_with(price_endings=["1.99"]), "price_endings"),
    (policy_with(max_change_pct_per_evaluation=0.1), "Floats are not accepted"),
    (policy_with(competitor={"basis": "whatever"}), "competitor.basis"),
    (policy_with(automation={"enabled": True}), "allowed_categories must name"),
    (policy_with(automation={"enabled": True, "allowed_categories": ["audio"], "max_auto_change_pct": "0.5"}), "must be <= 0.10"),
    ("not a dict", "must be a JSON object"),
])
def test_policy_validation_errors(config, fragment):
    errors = validate_policy(config)
    assert any(fragment in e for e in errors), errors
    assert parse_policy(config)[0] is None


def test_valid_policy_parses_with_decimal_values():
    cfg = load_policy(policy_with(price_endings=["0.99", "0.49"], max_change_pct_per_evaluation="0.08"))
    assert cfg.min_contribution_margin == D("0.12")
    assert cfg.price_endings == (D("0.49"), D("0.99"))
    assert validate_policy(policy_with()) == []


# ------------------------------------------------------------------ validate_price


def test_validate_price_checks_hard_constraints_only():
    inp = make_input(policy_with(max_change_pct_per_evaluation="0.02"))
    below = validate_price(inp, FLOOR_12 - D("0.01"))
    assert not below["ok"] and [v["name"] for v in below["violations"]] == ["minimum_contribution_margin"]
    # 52.00 is a 13% move - outside the 2% movement limit - but passes every hard constraint.
    assert validate_price(inp, D("52.00"))["ok"]
    assert not validate_price(make_input(cost=None), D("52.00"))["ok"]
    capped = make_input(commitments=(CommitmentInput("c", "max_price", D("55.00")),))
    over = validate_price(capped, D("56.00"))
    assert not over["ok"] and over["violations"][0]["name"] == "contractual_maximum_price"


@pytest.mark.engine
def test_unknown_keys_inside_policy_sections_are_rejected():
    """A typo in a nested section must fail validation, not silently fall back to a default."""
    from engine.policy import validate_policy

    base = {"strategy_order": ["margin_led"], "min_contribution_margin": "0.10", "target_contribution_margin": "0.20"}
    assert validate_policy(base) == []
    errors = validate_policy({**base, "competitor": {"basis": "item", "max_age_hours": 12},
                              "inventory": {"high_cover": "60"}})
    assert any("competitor: unknown keys max_age_hours" in e for e in errors)
    assert any("inventory: unknown keys high_cover" in e for e in errors)
