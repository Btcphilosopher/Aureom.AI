"""Price Watch adapter: normalisation of responses in the real Price Watch v1 shape."""

import copy
from datetime import UTC, datetime
from decimal import Decimal as D
from pathlib import Path

import pytest

from adapters.pricewatch import (
    ObservationRejected,
    PriceWatchUnavailable,
    derive_match,
    fetch_observations,
    normalise_comparison,
    normalise_offer,
)
from adapters.pricewatch_simulated import SimulatedPriceWatch

pytestmark = pytest.mark.engine

FETCHED = datetime(2026, 3, 2, 10, 0, tzinfo=UTC)
SCENARIOS = Path(__file__).resolve().parent.parent / "fixtures" / "demo" / "pricewatch_scenarios.json"


def offer(listing_id=11, slug="techhaven", name="TechHaven", **price_overrides):
    price = {
        "currency": "GBP", "total": "403.99", "known_subtotal": "403.99", "completeness": "complete",
        "eligibility": "eligible", "item_subtotal": "399.00", "discount_total": "0.00", "fees_total": "0.00",
        "delivery_total": "4.99", "tax_total": "0.00", "packs": 1,
        "purchased_quantity": {"value": "1", "unit": "each"}, "surplus_quantity": "0",
        "lines": [{"kind": "item", "label": "Item", "amount": "399.00", "status": "included", "note": ""},
                  {"kind": "delivery", "label": "Standard delivery", "amount": "4.99", "status": "additional", "note": ""}],
        "missing": [], "conditions": [], "conditional_discounts": [], "assumptions": [],
    }
    price.update(price_overrides)
    return {
        "listing_id": listing_id, "supplier": {"slug": slug, "name": name}, "title": "Lumio Aurora X5 128GB",
        "condition": "new", "included_contents": None, "warranty": None, "availability": "in_stock", "rank": 1,
        "group": "ranked", "sponsored": False, "price": price, "unit_price": None,
        "freshness": {"state": "fresh", "observed_at": "2026-03-02T09:00:00+00:00", "reason": ""},
        "supplier_effective_at": None, "last_price_change": None,
        "match": {"reasons": [{"code": "gtin_match", "message": "GTIN matches", "attribute": "gtin", "strength": "verified"}],
                  "differences": [], "decided_by": "system", "version": 1},
        "notes": [],
        "provenance": {"source_url": "https://techhaven.fixture.test/products/aurora-x5-128.html",
                       "extraction_method": "css_selector", "configuration_version": 3, "observation_id": 9001 + listing_id},
        "purchase_path": f"/out/{listing_id}/",
    }


def comparison(**lists):
    result = {"title": "Lumio Aurora X5 128GB", "mode": "exact",
              "requirements": {"condition": "new", "quantity": 1, "memberships": {}, "coupon_codes": [], "currency": "GBP"},
              "generated_at": "2026-03-02T09:30:00+00:00", "winner_listing_id": 11, "explanation": [],
              "ranked": [], "conditional": [], "total_incomplete": [], "ineligible": [], "unavailable": [],
              "sponsored_listing_ids": [], "not_comparable": [], "insufficient_evidence": [], "assumptions": []}
    result.update(lists)
    return result


def test_complete_ranked_offer_maps_every_field():
    obs = normalise_offer(offer(), mode="exact", fetched_at=FETCHED, context={"gtin": "5060999000011"})
    assert (obs.supplier, obs.supplier_slug) == ("TechHaven", "techhaven")
    assert obs.external_listing_id == "11" and obs.external_observation_id == "9012"
    assert obs.item_price == D("399.00") and obs.delivery_charge == D("4.99")
    assert obs.mandatory_charges == D("0.00") and obs.comparable_total == D("403.99")
    assert obs.charges_complete and obs.currency == "GBP" and obs.availability == "in_stock"
    assert obs.eligibility == "eligible" and not obs.membership_required
    assert obs.observed_at == datetime(2026, 3, 2, 9, 0, tzinfo=UTC)
    assert obs.variant_match == "exact" and obs.condition == "new"
    assert (obs.match_confidence, obs.match_status) == (D("0.99"), "confirmed")
    assert "Derived by the PRICEFLEX adapter" in obs.match_evidence["confidence_derivation"]
    assert obs.provenance["source_url"].startswith("https://techhaven.fixture.test/")
    assert obs.provenance["extraction_method"] == "css_selector" and obs.provenance["source"] == "pricewatch"
    assert obs.product_identity["gtin"] == "5060999000011"
    assert obs.to_dict()["item_price"] == "399.00"


def test_unknown_delivery_stays_none_and_total_is_not_invented():
    incomplete = offer(delivery_total=None, total=None, completeness="incomplete", missing=["delivery"])
    obs = normalise_offer(incomplete, mode="exact", fetched_at=FETCHED)
    assert obs.delivery_charge is None          # never coerced to 0.00
    assert obs.comparable_total is None and not obs.charges_complete
    assert obs.item_price == D("399.00")


def test_unknown_fee_makes_mandatory_charges_unknown():
    obs = normalise_offer(offer(fees_total=None, total=None, completeness="incomplete"), mode="exact", fetched_at=FETCHED)
    assert obs.mandatory_charges is None and obs.comparable_total is None


def test_discounts_and_fees_are_reflected():
    obs = normalise_offer(offer(item_subtotal="405.00", discount_total="15.00", fees_total="2.50", tax_total="0.00",
                                total="397.49"), mode="exact", fetched_at=FETCHED)
    assert obs.item_price == D("390.00") and obs.mandatory_charges == D("2.50")
    assert obs.comparable_total == D("397.49")


def test_membership_offer_is_conditional():
    member = offer(eligibility="conditional", total="385.00",
                   conditions=["Requires ClubTronics Plus membership, which is unknown."])
    obs = normalise_offer(member, mode="exact", fetched_at=FETCHED)
    assert obs.eligibility == "conditional" and obs.membership_required
    assert "ClubTronics Plus" in obs.eligibility_conditions[0]


def test_spec_equivalent_comparison_is_a_different_variant():
    obs = normalise_offer(offer(), mode="spec_equivalent", fetched_at=FETCHED)
    assert obs.variant_match == "different"
    assert normalise_offer(offer(), mode="something_new", fetched_at=FETCHED).variant_match == "unknown"


@pytest.mark.parametrize("match,confidence,status", [
    ({"reasons": [{"strength": "verified"}], "differences": []}, "0.99", "confirmed"),
    ({"reasons": [{"strength": "structured"}], "differences": []}, "0.90", "probable"),
    ({"reasons": [{"strength": "title"}], "differences": []}, "0.60", "probable"),
    ({"reasons": [{"strength": "title"}, {"strength": "structured"}], "differences": []}, "0.90", "probable"),
    ({"reasons": [{"strength": "structured"}], "differences": ["storage: 128GB vs 256GB"]}, "0.75", "probable"),
    ({"reasons": [{"strength": "title"}], "differences": ["x"], "decided_by": "human"}, "1.00", "confirmed"),
    ({"reasons": [], "differences": []}, "0", "unresolved"),
    (None, "0", "unresolved"),
])
def test_match_confidence_is_derived_from_reported_strength(match, confidence, status):
    got_confidence, got_status, evidence = derive_match(match, "ranked")
    assert (got_confidence, got_status) == (D(confidence), status)
    assert evidence["pricewatch_group"] == "ranked"


@pytest.mark.parametrize("mutate,fragment", [
    (lambda o: o["price"].update(item_subtotal=399.0), "expected a decimal string"),
    (lambda o: o["price"].update(item_subtotal="three hundred"), "not a decimal number"),
    (lambda o: o["price"].update(delivery_total="-1.00"), "invalid amount"),
    (lambda o: o["price"].update(item_subtotal="0.00"), "not positive"),
    (lambda o: o["price"].update(currency=None), "price.currency is missing"),
    (lambda o: o["provenance"].pop("observation_id"), "observation_id is missing"),
    (lambda o: o["supplier"].pop("name"), "supplier.name is missing"),
    (lambda o: o["freshness"].update(observed_at="yesterday"), "observed_at"),
    (lambda o: o["freshness"].update(observed_at="2026-03-02T09:00:00"), "timezone is required"),
])
def test_unsafe_offers_are_rejected_with_a_reason(mutate, fragment):
    bad = copy.deepcopy(offer())
    mutate(bad)
    with pytest.raises(ObservationRejected) as excinfo:
        normalise_offer(bad, mode="exact", fetched_at=FETCHED)
    assert fragment in str(excinfo.value)


def test_comparison_keeps_good_offers_and_reports_everything_else():
    bad = offer(listing_id=13, slug="voltmart", name="VoltMart")
    bad["price"]["item_subtotal"] = 405.0  # a float: rejected, not guessed
    payload = comparison(
        ranked=[offer(), bad],
        conditional=[offer(listing_id=14, slug="clubtronics", name="ClubTronics", eligibility="conditional")],
        total_incomplete=[offer(listing_id=15, slug="ohmly", name="Ohmly", delivery_total=None, total=None,
                                completeness="incomplete")],
        unavailable=[dict(offer(listing_id=16, slug="gadgetgrove", name="GadgetGrove"), availability="out_of_stock")],
        not_comparable=[{"listing_id": 99, "supplier": "PixelPoint", "title": "Aurora X5 (used)", "kind": "condition",
                         "reasons": ["Listing is used"]}],
        insufficient_evidence=[{"listing_id": 98, "supplier": "Ohmly", "title": "Aurora phone", "kind": "needs_review",
                                "reasons": ["No identifier"]}],
    )
    observations, rejected = normalise_comparison(payload, fetched_at=FETCHED)
    assert [o.supplier for o in observations] == ["TechHaven", "ClubTronics", "Ohmly", "GadgetGrove"]
    by_supplier = {o.supplier: o for o in observations}
    assert by_supplier["Ohmly"].comparable_total is None
    assert by_supplier["GadgetGrove"].availability == "out_of_stock"
    assert by_supplier["ClubTronics"].membership_required
    reasons = {r["listing_id"]: r for r in rejected}
    assert set(reasons) == {13, 99, 98}
    assert reasons[13]["list"] == "ranked" and "decimal string" in reasons[13]["reason"]
    assert reasons[99]["reason"].startswith("condition: Listing is used")
    assert all(o.item_price is None or o.item_price > 0 for o in observations)


def test_duplicate_observation_ids_are_collapsed():
    observations, _ = normalise_comparison(comparison(ranked=[offer()], conditional=[offer()]), fetched_at=FETCHED)
    assert len(observations) == 1


def test_simulated_price_watch_serves_the_real_shape_through_the_adapter():
    now = datetime(2026, 11, 24, 12, tzinfo=UTC)
    client = SimulatedPriceWatch(SCENARIOS, now=now)
    observations, rejected = fetch_observations(client, "5060999000271", fetched_at=now)  # NOVA-TAB
    by_supplier = {o.supplier: o for o in observations}
    assert by_supplier["TechHaven"].comparable_total == D("239.98")
    assert by_supplier["GadgetGrove"].membership_required
    assert by_supplier["VoltMart"].delivery_charge is None and by_supplier["VoltMart"].comparable_total is None
    assert any("rejected_match" in r["reason"] for r in rejected)
    assert by_supplier["TechHaven"].observed_at == now.replace(hour=9)
    assert by_supplier["TechHaven"].product_identity["gtin"] == "5060999000271"
    # A 256GB request answered with 128GB listings is a different variant, with capped confidence.
    different, _ = fetch_observations(client, "5060999000028", fetched_at=now)
    assert {o.variant_match for o in different} == {"different"}
    assert all(o.match_confidence == D("0.75") for o in different)


def test_unknown_gtin_and_outage():
    now = datetime(2026, 11, 24, 12, tzinfo=UTC)
    observations, rejected = fetch_observations(SimulatedPriceWatch(SCENARIOS, now=now), "0000000000000", fetched_at=now)
    assert observations == [] and "not known to Price Watch" in rejected[0]["reason"]
    down = SimulatedPriceWatch(SCENARIOS, now=now, outage=True)
    with pytest.raises(PriceWatchUnavailable):
        fetch_observations(down, "5060999000011", fetched_at=now)
    with pytest.raises(PriceWatchUnavailable):
        down.get_offers(9101, 101)
