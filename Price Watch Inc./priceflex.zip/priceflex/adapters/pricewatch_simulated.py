"""A SIMULATED Price Watch for the demonstration and tests.

It answers the two calls PRICEFLEX makes with responses in the real Price
Watch v1 shape, built from a compact scenario file
(``fixtures/demo/pricewatch_scenarios.json``). Observation times in that file
are relative ("hours_ago") so the demo's freshness scenarios stay true
whenever it is run. Nothing here contacts a network.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path

from .pricewatch import PriceWatchUnavailable


def _s(value) -> str | None:
    return None if value is None else format(Decimal(str(value)), ".2f")


class SimulatedPriceWatch:
    def __init__(self, scenario_path: str | Path, *, now: datetime, outage: bool = False):
        self.data = json.loads(Path(scenario_path).read_text())
        self.now = now
        self.outage = outage
        self._variants = {v["gtin"]: v for v in self.data["variants"]}

    def find_variant(self, gtin: str) -> dict | None:
        if self.outage:
            raise PriceWatchUnavailable("Simulated Price Watch outage")
        v = self._variants.get(gtin)
        if v is None:
            return None
        return {"product_id": v["product_id"], "variant_id": v["variant_id"], "brand": v.get("brand"),
                "name": v.get("name"), "gtin": gtin, "mpn": v.get("mpn"), "attributes": v.get("attributes", {})}

    def _offer(self, variant: dict, o: dict, index: int) -> dict:
        supplier = self.data["suppliers"][o["supplier"]]
        observed = self.now - timedelta(hours=o["hours_ago"])
        item, delivery, fees = o.get("item"), o.get("delivery", "0.00"), o.get("fees", "0.00")
        unknown = [name for name, v in (("delivery", delivery), ("fee", fees)) if v is None]
        complete = item is not None and not unknown
        total = None if not complete else Decimal(str(item)) + Decimal(str(delivery)) + Decimal(str(fees))
        membership = o.get("membership")
        eligibility = "conditional" if membership else "eligible"
        group = o.get("group") or ("conditional" if membership else ("incomplete" if not complete else (
            "unavailable" if o.get("availability", "in_stock") != "in_stock" else "ranked")))
        freshness_hours = supplier.get("freshness_hours", 24)
        stale = o["hours_ago"] > freshness_hours
        lines = [{"kind": "item", "label": "Item", "amount": _s(item), "status": "included", "note": ""}]
        lines.append({"kind": "delivery", "label": "Standard delivery", "amount": _s(delivery),
                      "status": "unknown" if delivery is None else "additional",
                      "note": "Delivery cost not stated by supplier" if delivery is None else ""})
        if fees is None or Decimal(str(fees)) > 0:
            lines.append({"kind": "fee", "label": "Mandatory handling fee", "amount": _s(fees),
                          "status": "unknown" if fees is None else "additional",
                          "note": "Mandatory fee amount not stated by supplier" if fees is None else ""})
        listing_id = variant["variant_id"] * 100 + index
        observation_id = listing_id * 1000 + int(o.get("sequence", 1))
        return {
            "listing_id": listing_id,
            "supplier": {"slug": o["supplier"], "name": supplier["name"]},
            "title": o.get("title") or variant["name"],
            "condition": o.get("condition", "new"),
            "included_contents": None, "warranty": None,
            "availability": o.get("availability", "in_stock"),
            "rank": None, "group": group, "sponsored": False,
            "price": {
                "currency": o.get("currency", "GBP"), "total": _s(total), "known_subtotal": _s(item),
                "completeness": "complete" if complete else "incomplete", "eligibility": eligibility,
                "item_subtotal": _s(item), "discount_total": "0.00", "fees_total": _s(fees),
                "delivery_total": _s(delivery), "tax_total": "0.00", "packs": 1,
                "purchased_quantity": {"value": "1", "unit": "each"}, "surplus_quantity": "0",
                "lines": lines, "missing": unknown,
                "conditions": [f"Requires {membership} membership, which is unknown."] if membership else [],
                "conditional_discounts": [], "assumptions": [],
            },
            "unit_price": None,
            "freshness": {"state": "stale" if stale else "fresh", "observed_at": observed.isoformat(),
                          "reason": f"Last verified more than {freshness_hours}h ago" if stale else ""},
            "supplier_effective_at": None, "last_price_change": None,
            "match": {"reasons": [{"code": o.get("match_code", "gtin_match"), "message": o.get("match_message", "GTIN matches"),
                                   "attribute": o.get("match_attribute", "gtin"),
                                   "strength": o.get("match_strength", "verified")}],
                      "differences": o.get("differences", []), "decided_by": o.get("decided_by", "system"), "version": 1},
            "notes": [],
            "provenance": {"source_url": f"https://{o['supplier']}.fixture.test/p/{variant['mpn'].lower()}",
                           "extraction_method": supplier.get("extraction_method", "json_ld"),
                           "configuration_version": 1, "observation_id": observation_id},
            "purchase_path": f"/out/{listing_id}/",
        }

    def get_offers(self, product_id: int, variant_id: int, condition: str = "new") -> dict:
        if self.outage:
            raise PriceWatchUnavailable("Simulated Price Watch outage")
        variant = next(v for v in self.data["variants"] if v["variant_id"] == variant_id)
        result = {
            "title": variant["name"], "mode": variant.get("mode", "exact"),
            "requirements": {"condition": condition, "quantity": 1, "memberships": {}, "coupon_codes": [], "currency": "GBP"},
            "generated_at": self.now.isoformat(), "winner_listing_id": None, "explanation": [],
            "ranked": [], "conditional": [], "total_incomplete": [], "ineligible": [], "unavailable": [],
            "sponsored_listing_ids": [], "not_comparable": [], "insufficient_evidence": [], "assumptions": [],
        }
        key = {"ranked": "ranked", "conditional": "conditional", "incomplete": "total_incomplete",
               "ineligible": "ineligible", "unavailable": "unavailable"}
        for index, o in enumerate(variant.get("offers", []), start=1):
            offer = self._offer(variant, o, index)
            result[key[offer["group"]]].append(offer)
        for entry in variant.get("not_comparable", []):
            result["not_comparable"].append(entry)
        return result
