"""Price Watch adapter: competitor observations in, normalised and validated.

Contract (Price Watch API v1)
-----------------------------
PRICEFLEX reads two Price Watch endpoints. Both are read-only GETs.

``GET /api/v1/products?q=<gtin>``
    Paginated ``{"count", "next", "previous", "results"}``. Each product has
    ``variants[]`` with ``id``, ``gtin``, ``mpn``, ``name``, ``attributes``.
    Used to resolve our GTIN to a Price Watch ``(product id, variant id)``.

``GET /api/v1/products/<id>/offers?variant=<id>&condition=new&quantity=1``
    A computed comparison for one variant. Offers arrive in five lists -
    ``ranked``, ``conditional``, ``total_incomplete``, ``ineligible``,
    ``unavailable`` - plus ``not_comparable`` / ``insufficient_evidence``
    entries that carry no price.

Authentication is ``Authorization: Token <key>``. Errors use the envelope
``{"error": {"code", "message", "details", "request_id"}}``.

Price Watch conventions this adapter relies on:

* money is a decimal **string**; ``null`` means *unknown*, never zero;
* ``price.total`` is the comparable total (item + mandatory fees + delivery +
  tax not already included - discounts) and is ``null`` when incomplete;
* ``freshness.observed_at`` is when Price Watch checked the price.

Field mapping (Price Watch offer -> PRICEFLEX observation)
----------------------------------------------------------
====================================  ==========================================
``supplier.name`` / ``supplier.slug``  ``supplier`` / ``supplier_slug``
``listing_id``                         ``external_listing_id``
``provenance.observation_id``          ``external_observation_id``
``condition``                          ``condition``
``price.item_subtotal - discounts``    ``item_price``
``price.delivery_total``               ``delivery_charge`` (null stays null)
``price.fees_total + price.tax_total`` ``mandatory_charges`` (null if either is)
``price.total``                        ``comparable_total``
``price.completeness == "complete"``   ``charges_complete``
``price.currency``                     ``currency``
``availability``                       ``availability``
``price.eligibility`` / ``conditions`` ``eligibility`` / ``eligibility_conditions``
``freshness.observed_at``              ``observed_at``
``match.reasons[].strength``           ``match_confidence`` (derived, see below)
``match`` + list membership            ``match_status``, ``match_evidence``
comparison ``mode``                    ``variant_match``
``provenance`` + ids                   ``provenance``
====================================  ==========================================

Price Watch does not expose a numeric match score. ``match_confidence`` is
*derived* here from the strongest evidence it reports
(:data:`STRENGTH_CONFIDENCE`), capped when Price Watch lists differences, and
documented as derived in the stored ``match_evidence``.

This module has no Django dependency.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Protocol

ADAPTER_VERSION = "pricewatch-adapter/1.0"
SOURCE = "pricewatch"

STRENGTH_CONFIDENCE = {"verified": Decimal("0.99"), "structured": Decimal("0.90"), "title": Decimal("0.60")}
DIFFERENCE_CAP = Decimal("0.75")
HUMAN_CONFIDENCE = Decimal("1.00")

OFFER_LISTS = ("ranked", "conditional", "total_incomplete", "ineligible", "unavailable")
CONDITIONS = {"new", "refurbished", "used", "open_box", "unknown"}
AVAILABILITY = {"in_stock", "out_of_stock", "preorder", "unknown"}


class PriceWatchError(Exception):
    """Price Watch could not be read. Callers keep their last valid observations."""


class PriceWatchUnavailable(PriceWatchError):
    pass


class ObservationRejected(ValueError):
    """A single offer could not be normalised safely."""


@dataclass
class NormalisedObservation:
    external_observation_id: str
    external_listing_id: str
    supplier: str
    supplier_slug: str
    title: str
    condition: str
    variant_match: str
    item_price: Decimal | None
    delivery_charge: Decimal | None
    mandatory_charges: Decimal | None
    charges_complete: bool
    comparable_total: Decimal | None
    currency: str
    availability: str
    eligibility: str
    membership_required: bool
    eligibility_conditions: list[str]
    observed_at: datetime
    match_confidence: Decimal
    match_status: str
    match_evidence: dict = field(default_factory=dict)
    product_identity: dict = field(default_factory=dict)
    provenance: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        data = asdict(self)
        for key in ("item_price", "delivery_charge", "mandatory_charges", "comparable_total", "match_confidence"):
            data[key] = None if data[key] is None else format(data[key], "f")
        data["observed_at"] = self.observed_at.isoformat()
        return data


def _money(value: Any, name: str) -> Decimal | None:
    """Parse a Price Watch money value. ``None`` stays ``None``; it is never coerced to zero."""
    if value is None:
        return None
    if isinstance(value, bool | float):
        raise ObservationRejected(f"{name}: expected a decimal string, got {type(value).__name__}")
    try:
        amount = Decimal(str(value))
    except InvalidOperation:
        raise ObservationRejected(f"{name}: not a decimal number: {value!r}")
    if not amount.is_finite() or amount < 0:
        raise ObservationRejected(f"{name}: invalid amount {value!r}")
    return amount


def _when(value: Any) -> datetime:
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        raise ObservationRejected(f"observed_at: not an ISO-8601 datetime: {value!r}")
    if dt.tzinfo is None:
        raise ObservationRejected("observed_at: timezone is required")
    return dt


def derive_match(match: dict | None, group: str) -> tuple[Decimal, str, dict]:
    """Derive ``(confidence, status, evidence)`` from Price Watch's match block."""
    match = match or {}
    reasons = match.get("reasons") or []
    differences = match.get("differences") or []
    strengths = [r.get("strength") for r in reasons if isinstance(r, dict)]
    best = max((STRENGTH_CONFIDENCE.get(s, Decimal("0")) for s in strengths), default=Decimal("0"))
    human = match.get("decided_by") == "human"
    confidence = HUMAN_CONFIDENCE if human else best
    if differences and not human:
        confidence = min(confidence, DIFFERENCE_CAP)
    if human or "verified" in strengths:
        status = "confirmed"
    elif confidence > 0:
        status = "probable"
    else:
        status = "unresolved"
    evidence = {
        "reasons": reasons, "differences": differences, "decided_by": match.get("decided_by"),
        "version": match.get("version"), "pricewatch_group": group,
        "confidence_derivation": "Derived by the PRICEFLEX adapter from Price Watch match strength "
                                 "(verified 0.99, structured 0.90, title 0.60; capped at 0.75 when differences "
                                 "are listed; 1.00 for a human decision). Price Watch exposes no numeric score.",
    }
    return confidence, status, evidence


def normalise_offer(offer: dict, *, mode: str, fetched_at: datetime, context: dict | None = None) -> NormalisedObservation:
    """Normalise one Price Watch offer. Raises :class:`ObservationRejected` if unsafe to use."""
    if not isinstance(offer, dict):
        raise ObservationRejected("offer is not an object")
    price = offer.get("price") or {}
    supplier = offer.get("supplier") or {}
    provenance = offer.get("provenance") or {}
    freshness = offer.get("freshness") or {}
    observation_id = provenance.get("observation_id")
    if observation_id in (None, ""):
        raise ObservationRejected("provenance.observation_id is missing")
    if not supplier.get("name"):
        raise ObservationRejected("supplier.name is missing")
    currency = price.get("currency")
    if not isinstance(currency, str) or len(currency) != 3:
        raise ObservationRejected("price.currency is missing")
    condition = offer.get("condition") if offer.get("condition") in CONDITIONS else "unknown"
    availability = offer.get("availability") if offer.get("availability") in AVAILABILITY else "unknown"

    item_subtotal = _money(price.get("item_subtotal"), "price.item_subtotal")
    discount = _money(price.get("discount_total"), "price.discount_total") or Decimal("0")
    item_price = None if item_subtotal is None else item_subtotal - discount
    delivery = _money(price.get("delivery_total"), "price.delivery_total")
    fees = _money(price.get("fees_total"), "price.fees_total")
    tax = _money(price.get("tax_total"), "price.tax_total")
    mandatory = None if (fees is None or tax is None) else fees + tax
    total = _money(price.get("total"), "price.total")
    complete = price.get("completeness") == "complete" and total is not None
    if item_price is not None and item_price <= 0:
        raise ObservationRejected("item price is not positive")

    eligibility = price.get("eligibility") if price.get("eligibility") in ("eligible", "conditional", "ineligible") else "conditional"
    conditions = [str(c) for c in (price.get("conditions") or [])]
    group = offer.get("group") or ""
    confidence, status, evidence = derive_match(offer.get("match"), group)
    variant_match = {"exact": "exact", "spec_equivalent": "different", "unit_price": "different"}.get(mode, "unknown")

    return NormalisedObservation(
        external_observation_id=str(observation_id),
        external_listing_id=str(offer.get("listing_id") or ""),
        supplier=str(supplier["name"]), supplier_slug=str(supplier.get("slug") or ""),
        title=str(offer.get("title") or "")[:300],
        condition=condition, variant_match=variant_match,
        item_price=item_price, delivery_charge=delivery, mandatory_charges=mandatory,
        charges_complete=complete, comparable_total=total if complete else None,
        currency=currency.upper(), availability=availability,
        eligibility=eligibility, membership_required=eligibility != "eligible",
        eligibility_conditions=conditions, observed_at=_when(freshness.get("observed_at")),
        match_confidence=confidence, match_status=status, match_evidence=evidence,
        product_identity={**(context or {}), "comparison_mode": mode,
                          "included_contents": offer.get("included_contents"), "warranty": offer.get("warranty")},
        provenance={
            "source": SOURCE, "adapter_version": ADAPTER_VERSION, "fetched_at": fetched_at.isoformat(),
            "source_url": provenance.get("source_url"), "extraction_method": provenance.get("extraction_method"),
            "configuration_version": provenance.get("configuration_version"),
            "pricewatch_observation_id": observation_id, "pricewatch_listing_id": offer.get("listing_id"),
            "pricewatch_freshness": freshness.get("state"), "price_lines": price.get("lines"),
            "missing": price.get("missing"), "notes": offer.get("notes"),
        },
    )


def normalise_comparison(comparison: dict, *, fetched_at: datetime, context: dict | None = None
                         ) -> tuple[list[NormalisedObservation], list[dict]]:
    """Normalise every offer in a Price Watch comparison.

    Returns ``(observations, rejected)``; ``rejected`` records offers that could
    not be normalised and the price-less ``not_comparable`` /
    ``insufficient_evidence`` entries, so nothing is dropped silently.
    """
    if not isinstance(comparison, dict):
        raise PriceWatchError("Comparison response is not an object")
    mode = comparison.get("mode") or "unknown"
    observations: list[NormalisedObservation] = []
    rejected: list[dict] = []
    seen: set[str] = set()
    for name in OFFER_LISTS:
        for offer in comparison.get(name) or []:
            try:
                obs = normalise_offer(offer, mode=mode, fetched_at=fetched_at, context=context)
            except ObservationRejected as exc:
                rejected.append({"listing_id": (offer or {}).get("listing_id") if isinstance(offer, dict) else None,
                                 "list": name, "reason": str(exc)})
                continue
            if obs.external_observation_id not in seen:
                seen.add(obs.external_observation_id)
                observations.append(obs)
    for name in ("not_comparable", "insufficient_evidence"):
        for entry in comparison.get(name) or []:
            if isinstance(entry, dict):
                rejected.append({"listing_id": entry.get("listing_id"), "list": name,
                                 "reason": f"{entry.get('kind', name)}: " + "; ".join(entry.get("reasons") or [])})
    return observations, rejected


class PriceWatchClient(Protocol):
    def find_variant(self, gtin: str) -> dict | None: ...
    def get_offers(self, product_id: int, variant_id: int, condition: str = "new") -> dict: ...


class HttpPriceWatchClient:
    """Reads a live Price Watch instance over HTTP (standard library only)."""

    def __init__(self, base_url: str, token: str = "", timeout: float = 10.0):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def _get(self, path: str, params: dict) -> dict:
        url = f"{self.base_url}{path}?{urllib.parse.urlencode(params)}"
        if not url.startswith(("http://", "https://")):
            raise PriceWatchError("Price Watch base URL must be http(s)")
        request = urllib.request.Request(url, headers={"Accept": "application/json"})  # noqa: S310
        if self.token:
            request.add_header("Authorization", f"Token {self.token}")
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:  # noqa: S310
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = json.loads(exc.read().decode("utf-8")).get("error", {}).get("message", "")
            except Exception:  # noqa: BLE001 - the body is best-effort context only
                pass
            raise PriceWatchUnavailable(f"Price Watch returned HTTP {exc.code}: {detail}".strip()) from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise PriceWatchUnavailable(f"Price Watch is unreachable: {exc}") from exc
        except json.JSONDecodeError as exc:
            raise PriceWatchError("Price Watch returned a non-JSON response") from exc

    def find_variant(self, gtin: str) -> dict | None:
        page = self._get("/api/v1/products", {"q": gtin, "page_size": 5})
        for product in page.get("results") or []:
            for variant in product.get("variants") or []:
                if variant.get("gtin") == gtin:
                    return {"product_id": product["id"], "variant_id": variant["id"], "brand": product.get("brand"),
                            "name": variant.get("name") or product.get("name"), "gtin": gtin,
                            "mpn": variant.get("mpn"), "attributes": variant.get("attributes")}
        return None

    def get_offers(self, product_id: int, variant_id: int, condition: str = "new") -> dict:
        return self._get(f"/api/v1/products/{product_id}/offers",
                         {"variant": variant_id, "condition": condition, "quantity": 1})


def fetch_observations(client: PriceWatchClient, gtin: str, *, fetched_at: datetime, condition: str = "new"
                       ) -> tuple[list[NormalisedObservation], list[dict]]:
    """Resolve ``gtin`` in Price Watch and return its normalised offers."""
    variant = client.find_variant(gtin)
    if variant is None:
        return [], [{"listing_id": None, "list": "lookup", "reason": f"GTIN {gtin} is not known to Price Watch"}]
    comparison = client.get_offers(variant["product_id"], variant["variant_id"], condition)
    context = {"pricewatch_product_id": variant["product_id"], "pricewatch_variant_id": variant["variant_id"],
               "gtin": gtin, "mpn": variant.get("mpn"), "brand": variant.get("brand"), "name": variant.get("name")}
    return normalise_comparison(comparison, fetched_at=fetched_at, context=context)
