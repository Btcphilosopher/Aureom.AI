"""Storefront adapter contract.

PRICEFLEX publishes through this small interface so the simulated storefront
can be replaced by a real commerce platform without touching the workflow.

An adapter must provide:

``get_price(channel_code, sku) -> StorefrontPrice``
    What the storefront *currently shows shoppers*, plus an opaque version.
    This is the read-back used to verify publications; it must not be served
    from the adapter's own memory of what it last wrote.

``set_price(channel_code, sku, price, *, expected_version, idempotency_key) -> dict``
    Compare-and-set. Must raise :class:`StorefrontVersionConflict` if the
    storefront's version differs from ``expected_version``, and must treat a
    repeated ``idempotency_key`` as the same request (return the original
    response, change nothing).

Exceptions carry meaning for reconciliation:

* :class:`StorefrontRejected` - the change was definitely **not** applied.
* :class:`StorefrontTimeout`  - the outcome is **unknown**; reconcile by read-back.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from importlib import import_module
from typing import Protocol


class StorefrontError(Exception):
    pass


class StorefrontRejected(StorefrontError):
    """The storefront refused the request; nothing changed."""


class StorefrontVersionConflict(StorefrontRejected):
    """The storefront's price changed since we last read it."""


class StorefrontTimeout(StorefrontError):
    """No definitive answer was received; the change may or may not have been applied."""


@dataclass(frozen=True)
class StorefrontPrice:
    price: Decimal | None
    version: str
    raw: dict


class StorefrontAdapter(Protocol):
    def get_price(self, channel_code: str, sku: str) -> StorefrontPrice: ...

    def set_price(self, channel_code: str, sku: str, price: Decimal, *, expected_version: str,
                  idempotency_key: str) -> dict: ...


def load_adapter(dotted_path: str) -> StorefrontAdapter:
    module_name, _, class_name = dotted_path.rpartition(".")
    return getattr(import_module(module_name), class_name)()
