from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import include, path

from apps.web import views as web_views

urlpatterns = [
    path("healthz", web_views.healthz, name="healthz"),
    path("readyz", web_views.readyz, name="readyz"),
    path("admin/", admin.site.urls),
    path("login/", auth_views.LoginView.as_view(template_name="registration/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("api/v1/", include(("apps.api.urls", "api"), namespace="v1")),
    path("", include(("apps.web.urls", "web"), namespace="web")),
]
