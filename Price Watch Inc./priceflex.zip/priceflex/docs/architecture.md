# PRICEFLEX architecture

PRICEFLEX is a modular monolith: one Django project, one PostgreSQL database, one
Celery worker pool. The pricing calculation itself is a separate, pure-Python
package (`engine/`) that never imports Django.

## 1. Layout

```
priceflex/
├── manage.py
├── pyproject.toml            pinned dependencies
├── config/                   settings, URL root, Celery app, WSGI/ASGI
├── engine/                   deterministic pricing engine (no Django imports)
│   ├── money.py              Decimal helpers, TaxConfig, CostInputs, margin_breakdown, minimum_price_for
│   ├── policy.py             PolicyConfig, parse_policy / validate_policy / load_policy
│   ├── types.py              EvaluationInput and its parts; snapshot_hash
│   ├── comparables.py        build_comparable_set (competitor eligibility)
│   ├── constraints.py        compute_interval, apply_price_ending
│   ├── strategies.py         the six strategies, inventory_metrics, clearance_state
│   ├── evaluation.py         evaluate, validate_price
│   ├── explanations.py       recommendation_response, labels
│   ├── demand.py             optional demand estimation, optimal_price
│   └── simulation.py         demand simulator and backtest runner
├── adapters/                 boundaries to other systems (no Django imports)
│   ├── pricewatch.py         Price Watch contract, normalisation, HTTP client
│   ├── pricewatch_simulated.py  simulated Price Watch for demo and tests
│   └── storefront.py         storefront adapter protocol and exceptions
├── apps/
│   ├── accounts/             Organisation, Membership, roles, permissions, demo commands
│   ├── audit/                AuditEvent (append-only), Alert
│   ├── catalogue/            Product, ProductVariant, Channel, Location, ChannelListing, import helpers
│   ├── costs/                TaxRule, CostVersion, cost/tax resolution, cost import
│   ├── inventory/            InventoryPosition, InventoryMovement, SalesObservation, imports
│   ├── competitors/          CompetitorObservation, FeedStatus, ComparableOfferSet, Price Watch import
│   ├── policies/             PricingPolicy, PolicyVersion, Promotion, PriceCommitment
│   ├── recommendations/      PricingRun, InputSnapshot, PriceRecommendation, ApprovalDecision, workflow
│   ├── publishing/           PublicationAttempt, ObservedPublishedPrice, PriceHistory, PublicationControl, mock storefront
│   ├── simulation/           SimulationRun, Experiment, DemandModel, realised-results reports
│   ├── api/                  REST API v1 (DRF), idempotency records
│   └── web/                  management interface (Django templates + HTMX)
├── fixtures/demo/            fictional demonstration data
├── templates/, static/
├── tests/
└── docs/
```

Dependency direction: `apps/*` → `engine/` and `adapters/`. `engine/` and
`adapters/` depend only on the standard library, NumPy and SciPy
(`engine/demand.py`, `engine/simulation.py`); SciPy is imported lazily by the
demand-led strategy, so a rules-only evaluation needs neither.

Among the apps the direction is roughly
`accounts, audit, catalogue` ← `costs, inventory, competitors, policies` ←
`recommendations` ← `publishing` ← `api, web`. `recommendations.services`
reads `publishing.models.PriceHistory` and `simulation.models.DemandModel`
when assembling inputs; `simulation.services` calls
`recommendations.services.build_input`.

## 2. Core workflow

| Stage | What happens | Where |
|---|---|---|
| Ingest | Row-validated imports for costs, inventory, sales and competitor observations; Price Watch pull | `apps.costs.services.import_costs`, `apps.inventory.services.import_inventory` / `import_sales`, `apps.competitors.services.import_observations` / `pull_price_watch`, `adapters.pricewatch` |
| Validate | Rows are rejected individually with reasons; policies are validated before storage; critical inputs are checked at evaluation time | `apps.catalogue.importing.RowErrors`, `engine.policy.parse_policy`, `engine.evaluation.blocking_issues` |
| Calculate eligible price range | All floors, ceilings and movement limits are intersected into a feasible interval | `engine.constraints.compute_interval` |
| Generate recommendation | The first applicable strategy in the policy's order supplies a target, which is clamped, stabilised and rounded | `engine.evaluation.evaluate`, `engine.strategies` |
| Explain | Reasons, constraints applied, warnings, selection trace, comparable set, margin breakdowns | `EvaluationResult.to_dict`, `engine.explanations.recommendation_response`, `apps.recommendations.services.response_document` |
| Simulate | Backtest of alternative strategies with an explicit demand simulator; stored only as a labelled run | `engine.simulation.run_simulation`, `apps.simulation.services.simulate_listing` |
| Approve | Manual approval, rejection, override (re-validated against hard constraints), optional schedule; bounded automation | `apps.recommendations.services.approve` / `reject` / `withdraw`, `_automation_allows` |
| Publish | Pause check, state check, version check, constraint re-check, idempotent compare-and-set call | `apps.publishing.services.publish` / `_publish`, `adapters.storefront` |
| Verify | Storefront read-back; only a matching read-back confirms a price | `apps.publishing.services._observe`, `_finalise_verified`, `reconcile` |
| Monitor | Periodic read-back of every listing, alerts on drift, reconciliation of uncertain attempts, expiry | `apps.publishing.services.monitor` / `reconcile_open`, `apps.recommendations.services.expire_recommendations`, Celery beat |

A pricing run (`apps.recommendations.services.run_pricing`) does, for each
listing in scope: `build_input` → store `InputSnapshot` → `evaluate` (from the
stored form) → store `ComparableOfferSet` and `PriceRecommendation` →
supersede earlier open recommendations for that listing → apply bounded
automation if the policy and administrator authorisation allow it.

## 3. Domain model

| Model | App | Purpose |
|---|---|---|
| `Organisation` | accounts | Tenant. Every business row belongs to one. |
| `Membership` | accounts | A user's roles in an organisation, optionally limited to channels. |
| `Product` | catalogue | Product family; carries `category` and `tax_category`. |
| `ProductVariant` | catalogue | Sellable SKU with `gtin`, `mpn`, `condition`, attributes. |
| `Channel` | catalogue | Sales channel with `region`, `currency`, `customer_delivery_charge`. |
| `Location` | catalogue | Stock location; optional list of channels it fulfils (empty = all). |
| `ChannelListing` | catalogue | A variant on a channel: assigned policy, `standard_retail_price`, `confirmed_price`, `confirmed_at`, `price_version`. |
| `TaxRule` | costs | Output-tax rate and tax-inclusive/exclusive presentation per region and tax category, with effective dates. |
| `CostVersion` | costs | Immutable dated unit cost (acquisition, freight/landed, packaging, fulfilment, merchant-funded delivery, fees and fee basis, returns, warranty, recoverable and non-recoverable input tax, overhead allocation, currency, tax basis, source). Optional channel-specific versions. |
| `InventoryPosition` | inventory | On hand, reserved, inbound, lead time, oldest stock date, clearance date, `as_of`, per variant and location. |
| `InventoryMovement` | inventory | Signed stock movements; imports record the delta as an adjustment. |
| `SalesObservation` | inventory | Realised sales per variant, channel and period: units, actual transaction price, exposed price, availability, stockout, promotion flag, traffic, returns, cancellations, `is_synthetic`. |
| `CompetitorObservation` | competitors | One observed competitor offer with prices, charges, eligibility, match evidence and provenance. |
| `FeedStatus` | competitors | Last attempt/success/failure of a competitor source. |
| `ComparableOfferSet` | competitors | The eligible and excluded offers one recommendation was based on. |
| `PricingPolicy` | policies | Named policy; `current_version`; `automation_authorised`. |
| `PolicyVersion` | policies | Immutable configuration revision with `config_hash`. |
| `Promotion` | policies | Campaign with start, end, kind, value, funding, eligibility, status and approval. |
| `PriceCommitment` | policies | Recorded contractual minimum, maximum or fixed price for a listing. |
| `PricingRun` | recommendations | One batch evaluation: trigger, evaluation time, algorithm version, scope, counts. |
| `InputSnapshot` | recommendations | Immutable JSON of everything one evaluation saw, with SHA-256. |
| `PriceRecommendation` | recommendations | The decision: status, outcome, strategy, current/recommended/approved/scheduled prices, full result, expiry, expected price version. |
| `ApprovalDecision` | recommendations | Approval, automatic approval, rejection or withdrawal, with actor, price, override flag and comment. |
| `PublicationControl` | publishing | Organisation pause switch. |
| `PublicationAttempt` | publishing | One attempt to publish: idempotency key, expected previous price and version, status, resolution, request, external response. |
| `ObservedPublishedPrice` | publishing | Each storefront read-back (pre-publish check, publish read-back, reconciliation, monitor). |
| `PriceHistory` | publishing | Ledger of confirmed published prices. |
| `MockStorefrontPrice`, `MockStorefrontRequest`, `MockStorefrontFault`, `MockStorefrontQuote` | publishing | The simulated storefront: accepted and displayed price with a version, processed idempotency keys, fault injection, locked quotes. |
| `DemandModel` | simulation | Stored demand estimate for a listing (`validated` or `insufficient_evidence`). |
| `SimulationRun` | simulation | Stored configuration and labelled results of a simulation. |
| `Experiment` | simulation | Product-group price test (control and treatment listings, policy versions, dates, results). |
| `AuditEvent` | audit | Append-only audit record. |
| `Alert` | audit | Operational alert (`competitor_feed_failed`, `publication_uncertain`, `storefront_price_drift`). |
| `IdempotencyRecord` | api | Stored response for a POST made with an `Idempotency-Key`. |

Money columns are PostgreSQL `numeric` (`DecimalField`); the engine uses
Python `Decimal` and rejects floats at its boundary (`engine.money.D`).

## 4. Six separate price concepts

| Concept | Stored in | Written by |
|---|---|---|
| Current observed selling price | `ObservedPublishedPrice.price` (each read-back from the storefront) | `apps.publishing.services._observe` |
| Recommended price | `PriceRecommendation.recommended_price` | `evaluate_listing` |
| Approved price | `PriceRecommendation.approved_price`, `ApprovalDecision.approved_price` | `approve`, bounded automation |
| Scheduled price | `PriceRecommendation.scheduled_price` with `scheduled_for` | `approve(..., scheduled_for=...)` |
| Confirmed published price | `ChannelListing.confirmed_price` / `confirmed_at` / `price_version`; ledger in `PriceHistory` | `_finalise_verified`, only after a matching read-back |
| Actual transaction price | `SalesObservation.unit_price` | `import_sales` |

`PriceRecommendation.current_price` records the confirmed published price at
the moment of evaluation. None of these fields is overwritten by another.

## 5. Decision provenance

Every `PriceRecommendation` references:

- `snapshot` → `InputSnapshot.payload` (the complete `EvaluationInput.to_dict()`)
  and `sha256` (`engine.types.snapshot_hash` over canonical JSON);
- `policy_version` → the immutable `PolicyVersion` (the configuration is also
  embedded in the snapshot);
- `algorithm_version` (`engine.ALGORITHM_VERSION`, currently
  `priceflex-engine/1.0.0`);
- `evaluated_at` (also `evaluation_time` inside the snapshot).

`evaluate` is run on `EvaluationInput.from_dict(payload)`, i.e. on the stored
form. `apps.recommendations.services.replay` re-runs a stored snapshot and
reports whether the hash still matches and whether every field of the result
is identical (`GET /api/v1/recommendations/{id}?verify=true`).

## 6. Recommendation states

```
draft → evaluated → awaiting_approval → approved → scheduled → publishing → verified
```

Other states: `rejected`, `expired`, `failed`, `superseded`, `withdrawn`.
The allowed transitions are the `TRANSITIONS` table in
`apps/recommendations/workflow.py`; `failed → publishing` is the retry path.
Outcomes are separate from states: `change`, `no_change`, `conflict`,
`blocked`. `change` and `conflict` move to `awaiting_approval`; `no_change` and
`blocked` stay at `evaluated`.

Publication attempt statuses: `pending`, `sent`, `verified`, `failed`,
`uncertain`, `blocked`. A partial unique constraint
(`one_open_publication_per_listing`) allows at most one attempt per listing in
`pending`, `sent` or `uncertain`.

## 7. Background tasks (Celery beat, `config/settings.py`)

| Schedule | Task | Effect |
|---|---|---|
| minute 5, every 6 hours | `apps.recommendations.tasks.evaluate_all_organisations` | Queues `evaluate_organisation` per organisation; runs as the service account `svc-<organisation slug>` and is skipped if that account has no membership. |
| every 15 minutes | `apps.recommendations.tasks.expire_recommendations` | Expires recommendations past `expires_at`. |
| every 5 minutes | `apps.publishing.tasks.publish_due` | Publishes scheduled prices whose time has come (paused organisations are refused). |
| every 5 minutes | `apps.publishing.tasks.reconcile_uncertain` | Reads back attempts in `uncertain` or `sent`, and `pending` attempts older than 5 minutes (a worker that died mid-publication). |
| minute 20, hourly | `apps.publishing.tasks.monitor_storefront` | Reads back every listing; raises `storefront_price_drift` alerts. |
| minute 40, hourly | `apps.competitors.tasks.import_price_watch` | Price Watch pull per organisation (service account required). |

`apps.publishing.tasks.publish_recommendation` exists for background
publication of a single recommendation. Redis is the broker, result backend
and Django cache.

## 8. Implemented, simulated, deferred

| Area | Status | Notes |
|---|---|---|
| Deterministic engine: money, tax, fees, floors, ceilings, movement limits, price endings, six strategies, explanations | Implemented | `engine/` |
| Cost, inventory, sales and competitor imports with row-level validation | Implemented | JSON and CSV through the API; service functions |
| Policy versioning and validation | Implemented | |
| Approval workflow, overrides, scheduling, expiry, supersession | Implemented | |
| Bounded automation | Implemented | Off unless the policy enables it and an administrator authorises it |
| Publication with idempotency, compare-and-set, read-back, reconciliation, pause, rollback | Implemented | Against the storefront adapter interface |
| Storefront | **Simulated** | `apps.publishing.mock_storefront.MockStorefront`; no real commerce platform adapter is included |
| Price Watch adapter | Implemented | `HttpPriceWatchClient` follows the Price Watch v1 contract but has not been exercised against a live Price Watch instance in this delivery |
| Price Watch content in the demo | **Simulated** | `adapters.pricewatch_simulated.SimulatedPriceWatch` |
| Demo sales history and post-publication sales | **Simulated** | Flagged `is_synthetic` |
| Demand estimation | Implemented, optional | Poisson regression with validation gates; only a validated estimate can drive a price |
| Simulation / backtesting | Implemented | Counterfactual demand always comes from the explicit simulator |
| Experiments | Basic | Model and a descriptive read-out (`experiment_readout`); no randomised assignment tooling or significance testing |
| Alerts | Basic | Stored `Alert` rows; no e-mail, chat or paging integration |
| Currency conversion | Deferred | A cost in a different currency from the channel blocks the recommendation |
| Multiple tax lines per sale, tax on delivery as a separate rule | Deferred | One output-tax rule per region and tax category |
| OpenAPI schema generation | Deferred | The API is documented by hand in `docs/api.md` |
| AI-written explanations or policy drafts | Deferred | Not implemented; see `docs/governance.md` |
| Per-customer or segment pricing | Out of scope by design | Inputs are product, channel, region and inventory conditions only |
