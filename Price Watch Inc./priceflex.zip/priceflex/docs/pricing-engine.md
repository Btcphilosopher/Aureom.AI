# The PRICEFLEX pricing engine

The engine is the `engine/` package. It has no Django dependency.
`engine.evaluation.evaluate(EvaluationInput) -> EvaluationResult` is a pure
function: it reads no clock, database, network or random source. The same
input and the same `engine.ALGORITHM_VERSION` always give the same result.

## 1. Money, tax and fees (`engine/money.py`)

All amounts are `decimal.Decimal`. `engine.money.D` refuses floats.
Money is rounded to two decimal places, half-up, per unit.

### Tax

`TaxConfig(rate, prices_include_tax, jurisdiction, category, source)` is
resolved per channel region and product tax category from configuration
(`TaxRule`). Nothing assumes a rate or a presentation.

- Customer price `P` is the price as displayed on the channel.
- Net revenue `N` = `P / (1 + rate)` when prices include tax, otherwise `P`.
- Gross amount paid for the item = `P` when prices include tax, otherwise `P × (1 + rate)`.

### Cost

`CostInputs` holds, per unit: `acquisition_cost`, `freight_landed`,
`packaging`, `fulfilment`, `merchant_funded_delivery`, `fee_percent`,
`fee_fixed`, `fee_basis`, `expected_return_rate`, `cost_per_return`,
`warranty_cost`, `non_recoverable_input_tax`, `recoverable_input_tax`,
`overhead_allocation`, `currency`, `tax_basis`, and provenance
(`cost_version_id`, `effective_from`, `source`).

- Cost of goods = acquisition + freight/landed + packaging + non-recoverable input tax.
- Variable fulfilment = fulfilment + merchant-funded delivery.
- Expected returns and warranty = `expected_return_rate × cost_per_return + warranty_cost`.
- `recoverable_input_tax` is carried for information and is never part of any cost.

### Fee basis

A percentage fee is charged on one of:

| `fee_basis` | Amount the percentage applies to |
|---|---|
| `gross_item` | tax-inclusive item amount |
| `net_item` | item amount excluding tax |
| `gross_item_plus_delivery` | tax-inclusive item amount plus the tax-inclusive customer delivery charge |

Transaction fees = `round(fee_percent × basis) + fee_fixed`.

### Margin definitions (`margin_breakdown`)

```
net revenue         = customer price excluding applicable output tax
contribution        = net revenue
                      - cost of goods
                      - variable fulfilment
                      - transaction fees
                      - expected returns and warranty
                      (+ supplier promotion funding, only in promotion mode)
contribution margin = contribution / net revenue
gross profit        = net revenue - cost of goods
gross margin        = gross profit / net revenue
markup              = gross profit / cost of goods
operating profit    = contribution - overhead allocation
```

Margin and markup are different ratios of the same gross profit and are
reported separately. Ratios are rounded to four decimal places.

### Deriving a floor (`minimum_price_for`)

With `t` the tax rate and `f` the fee fraction:

```
fee basis = β × N (+ delivery when the basis includes it)
    β = 1        for net_item
    β = 1 + t    for the gross bases
contribution C(N) = a × N − K
    a = 1 − f × β
    K = cost of goods + variable fulfilment + fixed fee
        + f × gross delivery charge (gross_item_plus_delivery only)
        + expected returns and warranty − promotion funding
margin   C/N ≥ m   ⇔   N ≥ K / (a − m)      requires a > m
amount   C   ≥ A   ⇔   N ≥ (K + A) / a      requires a > 0
```

The required net revenue is converted to a customer price (× `1 + t` when
prices include tax) and rounded up to the cent. Because tax and fees are
rounded per unit, the result is then verified cent by cent against
`margin_breakdown`: stepped up until the requirement holds, then down while
it still holds. If `a ≤ 0` or `a ≤ m` the requirement is unattainable and
the function returns `feasible=False` with an explanation.

## 2. Evaluation sequence (`engine/evaluation.py`)

1. Parse and validate the policy. Invalid → `blocked` (`invalid_policy`).
2. Check critical inputs (`blocking_issues`). Any issue → `blocked`.
3. Build the comparable competitor set.
4. Determine the constraint mode: `standard`, `promotion` or `clearance`.
5. Build the feasible interval. Empty → `conflict`.
6. Evaluate every strategy in `strategy_order`; the first applicable one supplies the target.
7. Clamp the target to the interval and record the binding constraint.
8. Stability: minimum meaningful change, hysteresis.
9. Apply the price ending, then validate the rounded price against the interval again.
10. Produce reasons, including for "no change".

Outcomes: `change`, `no_change`, `conflict`, `blocked`.

## 3. Constraints (`engine/constraints.py`)

Each constraint contributes a named lower and/or upper `Bound`. The feasible
interval is `[highest lower bound, lowest upper bound]`; with no lower bound
the floor is 0.01.

| Name | Kind | Source |
|---|---|---|
| `minimum_contribution_margin` | hard | `min_contribution_margin` via `minimum_price_for` |
| `minimum_contribution_amount` | hard | `min_contribution_amount` |
| `clearance_minimum_contribution_margin` | hard | replaces the margin floor in clearance mode when `clearance.min_contribution_margin` is set |
| `clearance_minimum_contribution_amount` | hard | replaces the amount floor in clearance mode when `clearance.min_contribution_amount` is set |
| `promotion_approved_minimum_contribution_margin` | hard | replaces the margin floor in promotion mode when the promotion records `approved_min_contribution_margin` |
| `absolute_minimum_price`, `absolute_maximum_price` | hard | policy |
| `standard_retail_price_cap` | hard | `cap_at_standard_retail_price` |
| `contractual_minimum_price`, `contractual_maximum_price`, `contractual_fixed_price` | hard | active `PriceCommitment` records |
| `maximum_price_change` | movement | `max_change_pct_per_evaluation` around the current price |
| `maximum_cumulative_movement` | movement | `max_cumulative_change_pct` around the price in effect `cumulative_window_days` ago, taken from recorded price history |
| `cooldown` | movement | pins the price to the current price until `cooldown_hours` after the last recorded change |

Further names can appear in `constraints_applied`: `minimum_meaningful_change`,
`hysteresis`, `price_ending`.

Movement limits are skipped when there is no current price, and in promotion
mode when `promotion_exempt_from_movement_limits` is true (the default); the
reasons say so.

**Conflict.** If the interval is empty, or a floor is unattainable, the
outcome is `conflict` with the conflicting bounds named. No constraint is
relaxed. This includes a hard floor that lies above what the movement limits
or cooldown allow: a reviewer decides. A warning is added when the current
price is below the hard floor.

**Price endings.** `apply_price_ending` picks the allowed ending nearest to
the candidate that is still inside the interval (ties go to the lower
price). If none fits, `ending_fallback` decides: `keep_unrounded` keeps the
unrounded price with a warning, `conflict` returns a conflict. The rounded
price is then checked against every bound again. Endings are not applied to
an approved promotion price.

**`validate_price(inp, price)`** checks an arbitrary price against the hard
constraints only (movement limits excluded). It is used for overrides, for
the pre-publication re-check and for rollbacks.

## 4. Critical inputs and fallbacks

| Condition | Result |
|---|---|
| Policy fails validation | `blocked` — `invalid_policy` |
| No cost version in force | `blocked` — `missing_cost` |
| Cost currency ≠ channel currency | `blocked` — `currency_mismatch` (no conversion) |
| Cost older than `max_cost_age_days` (when set) | `blocked` — `stale_cost` |
| No tax rule, or two rules starting at the same time | `blocked` — `uncertain_tax_configuration` |
| Inventory missing or older than `inventory.max_inventory_age_hours` | `inventory.on_stale_inventory`: `warn` (inventory rules skipped, warning) or `block` (`missing_inventory` / `stale_inventory`) |
| Too few eligible competitor offers | `competitor.on_no_eligible`: `skip` (next strategy), `hold` (keep current price), `block` (`insufficient_competitor_evidence`) |
| No strategy applies and there is no current price | `blocked` — `no_basis_for_price` |
| Demand estimate missing, not validated or too old | demand-led strategy does not apply; the next strategy in the order is the baseline |
| Competitor feed failing | observations are kept with their timestamps and judged by the freshness limit; a warning names the feed. A missing price is never read as zero. |

A blocked recommendation cannot be approved or published.

## 5. Competitor comparables (`engine/comparables.py`)

The policy states the basis:

- `item`: competitor item price against our item price.
- `delivered_total`: competitor comparable total (item + delivery + mandatory
  charges) against our item price + our customer delivery charge. The
  strategy deducts our delivery charge from the target to return to an item price.

Only the newest observation of each supplier listing is judged. Exclusion
reasons:

| Code | Meaning |
|---|---|
| `unresolved_match` | match status `unresolved` or `rejected` |
| `weak_match` | match confidence below `min_match_confidence` |
| `different_variant` / `variant_unknown` | variant match is not `exact` |
| `condition_mismatch` | condition not in `allowed_conditions`, or not `new` when our stock is new |
| `currency_mismatch` | observation currency differs from the channel currency |
| `unavailable` | not `in_stock` (when `require_in_stock`) |
| `membership_only` | conditional price without eligibility (unless `allow_membership_prices`) |
| `missing_price` | no positive item price |
| `incomplete_mandatory_charges` | no value on the chosen basis because charges are incomplete |
| `stale` | older than `max_observation_age_hours` |

On the `item` basis an offer with incomplete charges stays eligible and is
flagged `mandatory_charges_incomplete`. Observations dated after the
evaluation time are ignored. Each supplier contributes one value (its lowest
eligible listing); with `smoothing: median_recent` that value is the median
of the listing's eligible observations inside `smoothing_window_hours`.

## 6. Strategies and precedence (`engine/strategies.py`)

`strategy_order` is the precedence. All strategies are evaluated and kept in
`selection_trace`; the first applicable one is selected.

| Strategy | Applies when | Target |
|---|---|---|
| `promotion` | an `approved` promotion is in force at the evaluation time | fixed price, or percentage off the standard retail price (current price if none) |
| `clearance` | clearance enabled, a clearance date is recorded, inventory is fresh, stock ≥ `min_on_hand`, a schedule tier is open, and stock cover exceeds the days remaining | standard retail price less the tier's `markdown_pct` |
| `demand_led` | demand enabled, the estimate is `validated` and not older than `max_model_age_days`, the interval is bounded | price in the interval with the highest expected daily contribution (`engine.demand.optimal_price`) |
| `competitor_aware` | at least `min_eligible_offers` eligible offers | reference (lowest / median / highest) × (1 + `offset_pct`) + `offset_amount`, less our delivery charge on the delivered basis |
| `inventory_led` | inventory fresh, stock > 0, and a band is breached | markdown step when cover > `high_cover_days`, when nothing sold while in stock, or when stock is older than `max_stock_age_days` (the larger step applies); markup step when cover < `low_cover_days`, shorter than the lead time, and nothing is inbound |
| `margin_led` | a target margin is configured | lowest price meeting `target_contribution_margin` when the current price falls short; **holds** when the current price already meets it. This strategy never reduces a price. |

Additional rules:

- **Mode.** Walking `strategy_order` from the start, if `promotion` is reached
  with an active approved promotion the mode is `promotion`; if `clearance`
  is reached while clearance is active the mode is `clearance`; the walk
  stops at the first other strategy. The mode selects which floors apply
  (section 3) and whether supplier funding counts towards contribution.
- **Stockout hold.** With `on_stockout: hold` (default), fresh inventory
  showing no available stock, a current price, and a mode other than
  promotion, the price is held regardless of the strategy order. If the
  current price lies outside the interval it still moves to the nearest
  feasible price.
- **Competitor below the floor.** The target is clamped to the floor and the
  reasons state that the competitor is not followed.
- **No applicable strategy.** The current price is held and the reason says so.

Stock cover uses in-stock days only: sales periods flagged as stockouts are
excluded from the sales rate, and a warning reports how many were excluded.

## 7. Stability controls

- `cooldown_hours`: no change until that long after the last recorded change.
- `max_change_pct_per_evaluation` and `max_cumulative_change_pct` over
  `cumulative_window_days`, both enforced from recorded price history.
- `min_meaningful_change_pct` / `min_meaningful_change_amount`: a change
  smaller than the larger of the two is not made.
- `hysteresis_pct`: a change that reverses the direction of the previous
  recorded change and is smaller than this fraction of the current price is not made.
- `competitor.smoothing: median_recent`.

The minimum-change and hysteresis rules are bypassed when the current price
is outside the feasible interval, and in promotion mode.

## 8. Policy configuration reference (`engine/policy.py`)

Unknown keys are rejected, both at the top level and inside the `competitor`, `inventory`, `clearance`, `demand` and `automation` sections, so a misspelt key cannot silently fall back to a default. Fractions are decimals (`0.12` = 12%).

| Key | Type | Default | Validation |
|---|---|---|---|
| `strategy_order` | list of strategy names | `["promotion","clearance","margin_led"]` | non-empty, known names, no repeats |
| `min_contribution_margin` | decimal or null | null | −1 to 0.95; at least one of this and `min_contribution_amount` is required |
| `min_contribution_amount` | decimal or null | null | |
| `absolute_min_price`, `absolute_max_price` | decimal or null | null | ≥ 0; min ≤ max |
| `cap_at_standard_retail_price` | bool | false | |
| `max_change_pct_per_evaluation` | decimal or null | null | 0.001 to 1 |
| `max_cumulative_change_pct` | decimal or null | null | 0.001 to 1 |
| `cumulative_window_days` | int | 30 | ≥ 1 |
| `cooldown_hours` | int | 0 | ≥ 0 |
| `min_meaningful_change_pct` | decimal | 0 | 0 to 0.5 |
| `min_meaningful_change_amount` | decimal | 0 | ≥ 0 |
| `hysteresis_pct` | decimal | 0 | 0 to 0.5 |
| `promotion_exempt_from_movement_limits` | bool | true | |
| `price_endings` | list of decimals | `[]` | each 0.00 to 0.99 with two decimals |
| `ending_fallback` | string | `keep_unrounded` | `keep_unrounded` or `conflict` |
| `target_contribution_margin` | decimal or null | null | 0 to 0.95; not below `min_contribution_margin`; required when `margin_led` is in the order |
| `max_cost_age_days` | int or null | null | ≥ 1 |
| `on_stockout` | string | `hold` | `hold` or `ignore` |
| `recommendation_ttl_hours` | int | 24 | ≥ 1 |

`competitor`:

| Key | Default | Validation |
|---|---|---|
| `basis` | `delivered_total` | `item` or `delivered_total` |
| `position` | `match_lowest` | `match_lowest`, `match_median`, `match_highest` |
| `offset_pct` | 0 | −0.5 to 0.5 |
| `offset_amount` | 0 | |
| `min_eligible_offers` | 1 | ≥ 1 |
| `max_observation_age_hours` | 48 | ≥ 1 |
| `min_match_confidence` | 0.80 | 0 to 1 |
| `allowed_conditions` | `["new"]` | non-empty list of strings |
| `require_in_stock` | true | |
| `allow_membership_prices` | false | |
| `smoothing` | `none` | `none` or `median_recent` |
| `smoothing_window_hours` | 72 | ≥ 1 |
| `on_no_eligible` | `skip` | `skip`, `hold`, `block` |

`inventory`:

| Key | Default | Validation |
|---|---|---|
| `enabled` | true | |
| `sales_lookback_days` | 28 | ≥ 1 |
| `high_cover_days` | 90 | ≥ 0; not below `low_cover_days` |
| `low_cover_days` | 7 | ≥ 0 |
| `markdown_step_pct` | 0.05 | 0 to 0.5 |
| `markup_step_pct` | 0.03 | 0 to 0.5 |
| `max_stock_age_days` | 180 | ≥ 1 or null |
| `aged_markdown_step_pct` | 0.08 | 0 to 0.5 |
| `max_inventory_age_hours` | 48 | ≥ 1 |
| `on_stale_inventory` | `warn` | `warn` or `block` |

`clearance`:

| Key | Default | Validation |
|---|---|---|
| `enabled` | false | must be true when `clearance` is in the order |
| `schedule` | `[]` | list of `{"days_before": int ≥ 0, "markdown_pct": 0 to 0.9}`; required when enabled |
| `min_on_hand` | 1 | ≥ 0 |
| `min_contribution_margin` | null | −1 to 0.95 |
| `min_contribution_amount` | null | |

`demand`: `enabled` (false; must be true when `demand_led` is in the order),
`max_model_age_days` (30, ≥ 1).

`automation`: `enabled` (false), `max_auto_change_pct` (0.03, 0 to 0.10),
`allowed_categories` (`[]`; required when enabled), `allow_price_increases`
(false). The configuration alone does not switch automation on; see
`docs/governance.md`.

## 9. Demand estimation (`engine/demand.py`) — optional

Input: one `DemandObservation` per day (price, units, stockout flag,
promotion flag, available units, traffic, returns, cancellations).

- Days flagged as stockouts, and days where available units ≤ units sold, are
  censored and excluded. They are not read as zero demand.
- Model: Poisson regression with a log link fitted by iteratively re-weighted
  least squares: `E[units] = exp(b0 + b1·ln(price/p_ref) + b2·promotion + b3·weekend) × exposure`.
  `b1` is the reported elasticity. The promotion term is included only when
  promotion status varies, the weekend term when the data span at least 28
  days, and traffic is used as exposure only when present for every day.
- Standard errors are scaled by the Pearson dispersion (never below 1). The
  95% interval is `b1 ± 1.96 × se`.
- Out-of-sample check: the most recent 25% of usable days (at least 7) are
  held out; mean Poisson deviance of the model is compared with a
  constant-rate baseline fitted on the training period.

The estimate is `validated` only if all of these hold (defaults of
`estimate_demand`): at least 42 usable days; at least 3 distinct prices
spanning at least 5%; units were sold; the training period contains at least
two prices; the 95% interval excludes zero; the interval is no wider than
3.0; holdout deviance improves on the baseline by at least 2%. Otherwise the
status is `insufficient_evidence` with the reasons listed.

Every estimate carries the caveat that it is an observational association
between price and sales, not a causal elasticity: competitor changes,
promotions, availability and seasonality can confound it. A further caveat
is added when price changes largely coincide with promotions.

`optimal_price` maximises expected daily contribution
`contribution(P) × q_ref × (P/p_ref)^elasticity` over the feasible interval
with `scipy.optimize.minimize_scalar` (bounded), then settles on whole cents
using exact Decimal unit economics. The result includes expected units per
day at the point estimate and at both ends of the elasticity interval; these
appear under `projection.volume_forecast` labelled as a model projection.
When the demand-led strategy is not selected, no volume effect is projected.

## 10. Simulation and backtesting (`engine/simulation.py`)

Historical sales show what sold at the prices that were shown. They cannot
show what would have sold at a different price. The simulator therefore
takes an explicit demand assumption, `DemandSimulatorConfig`:
`base_units_per_day` at `reference_price`, `elasticity`, optional
`competitor_sensitivity`, weekday factors and a `seed`. Demand per day is
Poisson with that mean.

`run_simulation(SimulationScenario)` runs each arm day by day:

- `fixed` — the starting price is held (no policy).
- `rules` — the listing's policy with the order reduced to `clearance`,
  `inventory_led`, `margin_led` (those that are configured).
- `competitor_aware` — `clearance`, `competitor_aware`, `margin_led`.
- `demand_model` — `demand_led`, `margin_led`; only when a validated demand
  estimate existed before the simulation start.

No future-data leakage: at decision time `t` an arm sees only cost versions
effective at or before `t`, competitor observations observed at or before
`t`, its own price path, and its own simulated sales before `t`. A demand
estimate fitted after the start is not used. All arms share the same uniform
random draw per day (common random numbers), so differences come from pricing.

Reported per arm: net revenue, units sold, contribution, contribution margin,
ending inventory, stockout days, unmet demand, number of price changes, price
volatility (standard deviation of daily relative price changes), average and
final price, constraint-breach days (days on which the price in effect
violated the listing's hard constraints), rejected recommendations (conflict
or blocked evaluations), the decisions and the daily series.

Assumptions are returned with every result and include: demand comes from
the simulator; every recommended change is approved and published
instantly; unsold demand during a stockout is lost; and, in
`apps.simulation.services.simulate_listing`, that starting stock is today's
on-hand quantity and base demand is the recorded in-stock sales rate before
the start unless supplied. Results are labelled
`SIMULATED - not a forecast of real sales and not a realised result`.

## 11. Running the engine without Django

```python
from datetime import datetime, timedelta, timezone
from decimal import Decimal as D

from engine.evaluation import evaluate
from engine.money import CostInputs, TaxConfig, margin_breakdown, minimum_price_for
from engine.types import CompetitorObservation, EvaluationInput, PricePoint, snapshot_hash

tax = TaxConfig(rate=D("0.20"), prices_include_tax=True, jurisdiction="GB", category="standard")
cost = CostInputs(
    currency="GBP", acquisition_cost=D("30"), freight_landed=D("1.5"), packaging=D("0.5"),
    fulfilment=D("2"), fee_percent=D("0.029"), fee_fixed=D("0.30"),
    expected_return_rate=D("0.05"), cost_per_return=D("6"),
    effective_from="2026-11-01T00:00:00+00:00",
)
print(margin_breakdown(D("59.99"), cost, tax).to_dict())   # contribution 13.65, margin 0.2731
print(minimum_price_for(cost, tax, min_margin=D("0.15")))  # price 50.94

now = datetime(2026, 11, 24, 12, tzinfo=timezone.utc)
policy = {
    "strategy_order": ["competitor_aware", "margin_led"],
    "min_contribution_margin": "0.12", "target_contribution_margin": "0.25",
    "max_change_pct_per_evaluation": "0.10", "price_endings": ["0.99"],
    "competitor": {"basis": "delivered_total", "position": "match_lowest"},
}
offer = CompetitorObservation(
    observation_id="1", supplier="TechHaven", variant_match="exact", condition="new",
    item_price=D("54.00"), delivery_charge=D("3.99"), mandatory_charges=D("0"), charges_complete=True,
    comparable_total=D("57.99"), currency="GBP", availability="in_stock", membership_required=False,
    observed_at=now - timedelta(hours=3), match_confidence=D("0.95"), match_status="confirmed",
)
inp = EvaluationInput(
    evaluation_time=now, product_id="1", variant_id="1", sku="X", product_name="Example",
    category="audio", condition="new", channel="web", region="GB", currency="GBP",
    policy=policy, policy_version="example@v1", current_price=D("59.99"),
    standard_retail_price=D("64.99"), customer_delivery_charge=D("2.99"), cost=cost, tax=tax,
    competitor_observations=(offer,),
    price_history=(PricePoint(now - timedelta(days=40), D("59.99")),),
)
result = evaluate(inp)
print(result.outcome, result.recommended_price)   # change 54.99
print(result.reasons)

# The stored form replays to the identical decision.
payload = inp.to_dict()
assert evaluate(EvaluationInput.from_dict(payload)).to_dict() == result.to_dict()
print(snapshot_hash(payload))
```

Run it from the project root with only the standard library available
(`python example.py`); NumPy and SciPy are needed only for `engine.demand`
and `engine.simulation`.
