# PRICEFLEX API v1

Base path: `/api/v1/`. Only `v1` exists. Paths have no trailing slash.
Requests and responses are JSON (`application/json`); the four import
endpoints also accept `text/csv`.

Decimal values are returned as strings. In request bodies a decimal may be
sent as a string or as a JSON number; numbers with a fractional part are
parsed as exact decimals, never as floats
(`apps.api.parsers.DecimalJSONParser`). Datetimes are ISO-8601 and must carry
a timezone offset.

## Authentication

- Token: `Authorization: Token <key>` (DRF `TokenAuthentication`). Create a
  token with `python manage.py drf_create_token <username>`.
- Session: a logged-in browser session is also accepted (with CSRF).

Every endpoint requires authentication. An unauthenticated request returns
`401` with code `not_authenticated`.

## Organisation scope and ownership

Each request is resolved to one `Membership` (`apps.api.context.membership_from`):

- If the user belongs to one organisation, that one is used.
- If the user belongs to several, send `X-Organisation: <organisation slug>`;
  otherwise `400 organisation_required`.
- No membership, or a slug the user does not belong to: `403 permission_denied`.

Every query is filtered by that organisation. Objects of another organisation
return `404 not_found`. A membership may be limited to named channels; then
recommendations, publications, listings and price history on other channels
are invisible (`404`) and actions on them are refused (`403 channel_denied`).

## Roles

| Permission | analyst | policy_editor | approver | publisher | admin |
|---|---|---|---|---|---|
| `view` (all GET endpoints) | yes | yes | yes | yes | yes |
| `import_data` (the four import endpoints) | yes | yes | – | – | yes |
| `run_pricing` (`POST /pricing-runs`) | yes | yes | yes | – | yes |
| `simulate` (`POST /simulations`) | yes | yes | yes | – | yes |
| `edit_policy` (`POST /policies`) | – | yes | – | – | yes |
| `approve` (approve, reject) | – | – | yes | – | yes |
| `publish` (`POST /publications`; scheduling an approval) | – | – | – | yes | yes |

A missing role returns `403 permission_denied`. Approving with
`scheduled_for` needs both `approve` and `publish`.

## Pagination

List endpoints use page-number pagination: `?page=<n>&page_size=<n>`
(default 25, maximum 200). Envelope:

```json
{"count": 31, "next": "http://…?page=2", "previous": null, "results": [ … ]}
```

## Idempotency

Every POST accepts an `Idempotency-Key` header (8–128 characters of letters,
digits, `.`, `_`, `:`, `-`). It is **required** on `POST /publications`.

- Same key, same body: the stored response is returned with the header
  `Idempotent-Replayed: true`; nothing is executed again.
- Same key, different body: `409 idempotency_key_reused`.
- Same key while the first request is still running: `409 request_in_progress`.
- Keys are scoped to the organisation and the request method and path.
- If the first request ended in an error raised by the service layer (for
  example a `403` or a `409` workflow error), no response is stored and the
  key may be used again.
- Malformed key: `400 invalid_idempotency_key`. Missing where required:
  `400 idempotency_key_required`.

Independently of the API key, each publication sends its own idempotency key
to the storefront (`storefront_idempotency_key`, of the form
`pf-<organisation>-<recommendation>-v<price version>`). It is identical across
retries of the same intended change.

## Concurrency

- `expected_status` on approve: `409 conflict` if the recommendation is in a
  different state.
- `expected_price_version` on publish: `409 conflict` if the listing's
  `price_version` differs.
- Each recommendation stores the listing's `price_version` at evaluation. At
  publication, a different current version means the live price has changed:
  the recommendation becomes `superseded` and the call returns
  `409 stale_price_version`.
- At most one publication per listing may be `pending`, `sent` or
  `uncertain` (row lock plus a database constraint). A second one returns
  `409 publication_in_progress`.
- Approve, reject and publish lock the recommendation row; a call that
  arrives after the state changed returns `409 invalid_state`.
- Before sending, the storefront is read; if it does not show the confirmed
  price, nothing is sent and the attempt is `failed` with resolution
  `precondition_failed`. The storefront call itself is a compare-and-set on
  the storefront's version.

## Errors

```json
{"error": {"code": "constraint_violation", "message": "…", "details": {}}}
```

| HTTP | Codes |
|---|---|
| 400 | `organisation_required`, `idempotency_key_required`, `invalid_idempotency_key`, `parse_error` |
| 401 | `not_authenticated` |
| 403 | `permission_denied`, `channel_denied` |
| 404 | `not_found` |
| 405 | `method_not_allowed` |
| 409 | `conflict`, `invalid_state`, `invalid_transition`, `expired`, `publication_paused`, `publication_in_progress`, `stale_price_version`, `idempotency_key_reused`, `request_in_progress` |
| 415 | `unsupported_media_type` |
| 422 | `validation_error`, `invalid_policy` (`details.errors`), `price_required`, `override_reason_required`, `reason_required`, `invalid_schedule`, `constraint_violation` (`details.violations`, `details.blocking_issues`) |
| 429 | `throttled` (`details.retry_after_seconds`); default limit 600 requests per minute per user (`PRICEFLEX_API_RATE`) |
| 502 | returned by `POST /competitor-observations` with `pull` when Price Watch could not be read at all (body is the import result) |

Import endpoints are the one exception to the envelope: when every row is
rejected they return `422` with the import result as the body, so the per-row
reasons are available in the same shape as a successful import.

---

## Imports

All four endpoints take `{"rows": [ … ], "source": "<text>"}` (1 to 5000 rows)
or a `text/csv` body whose header row uses the same field names. Rows are
validated one by one; a rejected row writes nothing and never causes a
missing number to be read as zero.

Response (`201` if at least one row was accepted, otherwise `422`):

```json
{"kind": "costs", "batch": "0806aca2dc06", "received": 5, "created": 2, "updated": 0,
 "unchanged": 0, "rejected_count": 3,
 "rejected": [{"row": 3, "sku": "VOLT-PB20", "errors": ["acquisition_cost is required"]}]}
```

### POST /api/v1/cost-imports

Creates immutable `CostVersion` rows; a new cost is always a new row.

| Field | Required | Notes |
|---|---|---|
| `sku` | yes | must exist in the organisation |
| `channel` | no | channel code; blank applies to every channel without its own version |
| `currency` | yes | three letters |
| `acquisition_cost` | yes | ≥ 0; blank is rejected |
| `freight_landed`, `packaging`, `fulfilment`, `merchant_funded_delivery`, `fee_fixed`, `cost_per_return`, `warranty_cost`, `non_recoverable_input_tax`, `recoverable_input_tax`, `overhead_allocation` | no | ≥ 0, default 0 |
| `fee_percent` | no | fraction, 0 to 0.99 |
| `expected_return_rate` | no | fraction, 0 to 1 |
| `fee_basis` | no | `gross_item` (default), `net_item`, `gross_item_plus_delivery` |
| `tax_basis` | no | default `net_of_recoverable_tax` |
| `effective_from` | yes | datetime with offset |
| `source` | no | free text |

```bash
curl -X POST "$BASE/api/v1/cost-imports" -H "Authorization: Token $TOKEN" \
  -H "Content-Type: application/json" -H "Idempotency-Key: costs-2026-11-24-a" \
  -d '{"source": "supplier price list", "rows": [{"sku": "NIM-B14-16", "currency": "GBP",
       "acquisition_cost": "505.00", "freight_landed": "6.00", "packaging": "1.50", "fulfilment": "6.00",
       "fee_percent": "0.029", "fee_fixed": "0.30", "fee_basis": "gross_item",
       "expected_return_rate": "0.03", "cost_per_return": "25.00",
       "effective_from": "2026-11-24T08:00:00+00:00"}]}'
```

CSV upload:

```bash
curl -X POST "$BASE/api/v1/cost-imports" -H "Authorization: Token $TOKEN" \
  -H "Content-Type: text/csv" --data-binary @costs.csv
```

### POST /api/v1/inventory-imports

Upserts one `InventoryPosition` per `(sku, location)` and records the change
in on-hand stock as an `InventoryMovement` of kind `adjustment`.

| Field | Required | Notes |
|---|---|---|
| `sku`, `location` | yes | existing SKU and location code |
| `on_hand` | yes | whole number ≥ 0 |
| `reserved`, `inbound` | no | whole numbers ≥ 0, default 0 |
| `replenishment_lead_time_days` | no | whole number ≥ 0 |
| `oldest_stock_received_at` | no | datetime with offset |
| `clearance_date` | no | `YYYY-MM-DD` |
| `as_of` | yes | datetime with offset; a row older than the stored position is rejected |
| `source` | no | |

### POST /api/v1/sales-imports

Upserts one `SalesObservation` per `(sku, channel, period_start)`.

| Field | Required | Notes |
|---|---|---|
| `sku`, `channel` | yes | |
| `period_start` | yes | date |
| `period_end` | no | date, inclusive; defaults to `period_start` |
| `units_sold` | yes | whole number ≥ 0 |
| `unit_price` | when units > 0 | actual average transaction price (customer price), ≥ 0.01 |
| `exposed_price` | no | price displayed during the period |
| `available_units` | no | |
| `stockout` | no | boolean; such periods are excluded from demand rates |
| `promotion_active` | no | boolean |
| `traffic`, `returns_units`, `cancellations` | no | whole numbers ≥ 0 |
| `is_synthetic` | no | boolean; marks generated data |

### POST /api/v1/competitor-observations

Two modes.

**Push normalised observations** (`rows`), upserted on
`(source, external_observation_id)`:

| Field | Required | Notes |
|---|---|---|
| `sku` | yes | our variant the observation was collected for |
| `external_observation_id`, `supplier` | yes | |
| `currency` | yes | three letters |
| `observed_at` | yes | datetime with offset, not in the future |
| `match_confidence` | yes | 0 to 1 |
| `item_price`, `comparable_total` | no | ≥ 0.01; omit when unknown (never send 0 for unknown) |
| `delivery_charge`, `mandatory_charges` | no | ≥ 0; omit when unknown |
| `charges_complete` | no | boolean; if true and no `comparable_total` is given it is computed from item + delivery + mandatory, and the row is rejected if that is not possible |
| `variant_match` | no | `exact`, `different`, `unknown` (default) |
| `match_status` | no | `confirmed`, `probable`, `unresolved` (default), `rejected` |
| `availability` | no | `in_stock`, `out_of_stock`, `preorder`, `unknown` (default) |
| `condition` | no | default `unknown` |
| `membership_required` | no | boolean |
| `eligibility_conditions`, `match_evidence`, `provenance` | no | list / objects |
| `supplier_slug`, `external_listing_id`, `title`, `source` | no | `source` defaults to `api` |

**Pull from Price Watch**: `{"pull": "pricewatch", "skus": ["LUM-X5-128"]}`
(`skus` optional). Returns the import result; `502` if nothing could be read.
See `docs/pricewatch-adapter.md`.

Observations are stored as market inputs only. Nothing in an observation can
create or change a policy, approve a price or trigger a publication.

---

## Policies

### GET /api/v1/policies

Paginated list:

```json
{"id": 3, "code": "margin-guard", "name": "Margin guard", "description": "…", "status": "active",
 "automation_authorised": false,
 "current_version": {"label": "margin-guard@v1", "number": 1, "config": { … }, "config_hash": "…",
                     "change_note": "Initial demo policy", "created_at": "…", "created_by": "pol.editor"}}
```

### POST /api/v1/policies

Body: `code` (required), `config` (required object), `name` (required for a
new policy), `description`, `change_note`.

- New code: creates the policy with version 1 → `201`.
- Existing code: creates the next immutable version and makes it current → `200`.
  If the configuration is identical to the latest version, no new version is created.
- Invalid configuration: `422 invalid_policy` with every validation message in
  `details.errors`. The configuration reference is in `docs/pricing-engine.md`.

Saving a configuration whose `automation.enabled` is not true clears the
policy's administrator authorisation for automation.

```bash
curl -X POST "$BASE/api/v1/policies" -H "Authorization: Token $TOKEN" -H "Content-Type: application/json" \
  -d '{"code": "margin-guard", "name": "Margin guard", "change_note": "Raise target",
       "config": {"strategy_order": ["promotion", "margin_led"], "min_contribution_margin": "0.15",
                  "target_contribution_margin": "0.20", "max_change_pct_per_evaluation": "0.10",
                  "price_endings": ["0.99"]}}'
```

---

## Pricing runs and recommendations

### POST /api/v1/pricing-runs

Body (all optional): `channel` (code), `skus` (list). Evaluates every active
listing in scope that has an active policy, synchronously. Earlier open
recommendations for those listings become `superseded`.

```json
{"id": 3, "status": "completed", "evaluation_time": "2026-11-24T17:33:06+00:00",
 "algorithm_version": "priceflex-engine/1.0.0",
 "counts": {"evaluated": 31, "change": 15, "no_change": 14, "conflict": 1, "blocked": 1,
            "skipped_no_policy": 0, "auto_approved": 1},
 "recommendations": [{"id": 71, "sku": "ARC-BUDS", "channel": "web", "outcome": "change",
                      "status": "awaiting_approval"}]}
```

### GET /api/v1/recommendations

Filters: `status` and `outcome` (comma-separated), `channel` (code), `sku`,
`product` (numeric id), `policy` (code), `run` (numeric id),
`has_warnings=true|false`. Ordered newest first.

Each result:

```json
{
  "id": "74", "product_id": "12", "variant_id": "15", "sku": "LUM-X5-128", "channel": "web",
  "currency": "GBP",
  "current_customer_price": "404.99",
  "recommended_customer_price": "399.99",
  "outcome": "change", "status": "awaiting_approval",
  "input_snapshot_id": "snap_74", "policy_version": "competitive-core@v1",
  "algorithm_version": "priceflex-engine/1.0.0", "evaluated_at": "2026-11-24T17:33:06+00:00",
  "selected_strategy": "competitor_aware",
  "reasons": ["Recommended reduction from GBP 404.99 to GBP 399.99 (-1.2%).", "…"],
  "constraints_applied": ["price_ending"],
  "warnings": [], "blocking_issues": [],
  "kind": "evaluation", "product_name": "Lumio Aurora X5 128GB",
  "approved_customer_price": null, "scheduled_customer_price": null, "scheduled_for": null,
  "confirmed_published_price": "404.99", "expires_at": "…",
  "input_snapshot_sha256": "…", "status_note": ""
}
```

`outcome` is `change`, `no_change`, `conflict` or `blocked`. For `no_change`
the recommended price equals the current price and `reasons` explains why;
for `conflict` and `blocked` it is null. `confirmed_published_price` is the
listing's confirmed price now, which may differ from
`current_customer_price` (the confirmed price when evaluated).

### GET /api/v1/recommendations/{id}

The same document plus `feasible_interval` (bounds with name, side, value,
kind and detail), `selection_trace` (every strategy, whether it applied, its
target, reasons and evidence), `comparables` (basis, eligible and excluded
offers with reason codes and text), `inventory`, `margin_current`,
`margin_recommended`, `projection`, `mode` and `decisions`.

`?verify=true` adds `reproducibility`: the stored snapshot is replayed and
compared (`reproducible`, `snapshot_hash_matches`, `differing_fields`,
stored and current algorithm versions).

### POST /api/v1/recommendations/{id}/approve

| Field | Notes |
|---|---|
| `approved_price` | optional. Omitted: the recommended price is approved. Different from the recommended price, or supplied for a `conflict`: an override. |
| `comment` | required for an override |
| `scheduled_for` | optional future datetime before `expires_at`; needs the `publish` permission as well; the status becomes `scheduled` |
| `expected_status` | optional concurrency check |

The price is validated against the hard constraints as they stand at the
moment of approval (current cost, tax, commitments). A breach returns
`422 constraint_violation` with the violated bounds. Only recommendations
that are `awaiting_approval` can be approved; an expired one returns
`409 expired`. Returns the detailed recommendation document.

```bash
curl -X POST "$BASE/api/v1/recommendations/74/approve" -H "Authorization: Token $TOKEN" \
  -H "Content-Type: application/json" -d '{"comment": "Reviewed", "expected_status": "awaiting_approval"}'
```

### POST /api/v1/recommendations/{id}/reject

Body: `comment` (required; `422 reason_required` otherwise). Returns the
detailed recommendation document with status `rejected`.

---

## Publications

### POST /api/v1/publications

Header `Idempotency-Key` required. Body: `recommendation_id` (integer,
required), `expected_price_version` (optional). The recommendation must be
`approved`, `scheduled` or `failed` (retry).

The call returns `201` with the attempt whenever an attempt was recorded.
**Read `status`**: a `201` does not mean the price is live.

| Attempt `status` | Meaning |
|---|---|
| `verified` | the storefront was read back and shows the price; the listing's confirmed price and `price_version` were updated |
| `uncertain` | no definitive answer (timeout), or accepted but the read-back shows a different price; reconciliation will read the storefront again |
| `failed` | definitely not applied (rejected by the storefront, precondition failed, or reconciled as not applied) |
| `blocked` | the pre-publication re-check failed (for example the cost floor moved); nothing was sent |

Refusals before any attempt is recorded use the error envelope:
`publication_paused`, `invalid_state`, `publication_in_progress`,
`stale_price_version`, `expired` (all `409`).

```json
{"id": 12, "recommendation_id": 74, "kind": "publish", "attempt_number": 1,
 "sku": "LUM-X5-128", "channel": "web", "status": "verified", "resolution": "verified_on_publish",
 "price": "399.99", "expected_previous_price": "404.99", "expected_version": 1,
 "storefront_idempotency_key": "pf-4-74-v1",
 "external_response": {"status": "accepted", "http_status": 200, "version": 2, "…": "…"},
 "error": "", "recommendation_status": "verified", "confirmed_published_price": "399.99",
 "observed_prices": [
   {"price": "404.99", "source": "pre_publish_check", "matches_expected": true, "observed_at": "…"},
   {"price": "399.99", "source": "publish_readback", "matches_expected": true, "observed_at": "…"}],
 "created_at": "…", "completed_at": "…", "reconciled_at": null}
```

```bash
curl -X POST "$BASE/api/v1/publications" -H "Authorization: Token $TOKEN" \
  -H "Content-Type: application/json" -H "Idempotency-Key: publish-rec-74" \
  -d '{"recommendation_id": 74}'
```

### GET /api/v1/publications/{id}

The attempt document above. `resolution` values: `verified_on_publish`,
`reconciled_applied`, `reconciled_not_applied`, `reconciled_unexpected_price`,
`rejected_by_storefront`, `precondition_failed`.

An attempt the storefront *accepted* but which a read-back still shows at the
old price is never resolved as "not applied": it stays `uncertain` (with the
reason in `error`) until a later read-back shows the new price. Only a timeout
with no acceptance on record can resolve to `reconciled_not_applied`, after
which the recommendation is `failed` and may be published again; the retry
reuses the same storefront idempotency key.

Reconciliation, rollback, the pause switch, withdrawal and demand-model
fitting are not part of API v1. They are service-layer operations
(`apps.publishing.services.reconcile`, `request_rollback`, `set_pause`;
`apps.recommendations.services.withdraw`;
`apps.simulation.services.fit_demand_model`) used by the management interface,
the scheduled tasks and the demonstration.

---

## Simulations

### POST /api/v1/simulations

| Field | Notes |
|---|---|
| `sku`, `channel` | required; the listing must have a policy |
| `days` | integer 1–180, default 28; the backtest covers the last `days` days |
| `elasticity` | negative decimal between −10 and 0, default −1.5; the simulator's demand assumption |
| `base_units_per_day` | optional; default is the recorded in-stock sales rate before the start (1 if none) |
| `competitor_sensitivity` | optional, default 0 |
| `initial_on_hand` | optional non-negative integer; default is today's on-hand stock |
| `seed` | optional integer |

Returns `201` with `{"id", "label", "config", "results"}`. `results` contains
`label` (always `SIMULATED - not a forecast of real sales and not a realised
result`), `assumptions`, `demand_simulator`, `arms` (per arm: `revenue_net`,
`units_sold`, `contribution`, `contribution_margin`, `ending_inventory`,
`stockout_days`, `unmet_demand_units`, `price_changes`, `price_volatility`,
`average_price`, `final_price`, `constraint_breach_days`,
`rejected_recommendations`, `evaluations`, `decisions`, `daily`) and
`skipped_arms` with the reason each was not run. A simulation writes only a
`SimulationRun`; it never touches prices, recommendations or sales.

```bash
curl -X POST "$BASE/api/v1/simulations" -H "Authorization: Token $TOKEN" -H "Content-Type: application/json" \
  -d '{"sku": "LUM-X5-128", "channel": "web", "days": 28, "elasticity": "-2.0", "competitor_sensitivity": "1.0"}'
```

---

## Price history

### GET /api/v1/products/{id}/price-history

`{id}` is the product id. Optional filters: `channel` (code), `sku`.
Paginated, newest first. Each entry is a confirmed published price:

```json
{"id": 40, "product_id": 12, "sku": "LUM-X5-128", "channel": "web", "currency": "GBP",
 "confirmed_published_price": "399.99", "previous_price": "404.99",
 "effective_at": "2026-11-24T17:33:20+00:00", "kind": "publish",
 "recommendation_id": 74, "publication_id": 12, "actor": "pub.publisher",
 "note": "Verified by storefront read-back (verified_on_publish)."}
```

`kind` is `initial`, `publish`, `rollback` or `external`.

---

## Health

`GET /healthz` and `GET /readyz` are outside the API namespace and need no
authentication.
