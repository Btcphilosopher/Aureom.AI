# Demonstration

The demonstration seeds a fictional retailer and runs the full workflow
against the simulated Price Watch and the simulated storefront.

**All demo data is fictional.** The organisation, products, costs, prices and
competitors are invented. Sales history and post-publication sales are
synthetic and flagged `is_synthetic`. Competitor offers come from the
simulated Price Watch. Nothing printed by the demonstration is hard-coded:
each value is read back from what the services did.

## Running it

Requires a migrated PostgreSQL database (`python manage.py migrate`).

```bash
python manage.py run_demo --password '<a password for the demo users>'
```

or

```bash
export PRICEFLEX_DEMO_PASSWORD='<a password for the demo users>'
python manage.py run_demo
```

`run_demo` deletes any existing demo organisation, seeds it again and runs the
ten steps. There is no default password; the command refuses to seed without
one.

Related commands:

| Command | Effect |
|---|---|
| `python manage.py seed_demo --password …` | Seed the starting state only (before step 1). |
| `python manage.py seed_demo --reset --password …` | Delete and reseed. |
| `python manage.py run_demo --no-seed` | Run the ten steps against a freshly seeded, untouched demo organisation. |

Resetting truncates the append-only audit table, so it is refused if audit
events exist for any organisation other than the demo one.

## Demo organisation

"Northlight Electronics (demo)", slug `northlight`, currency GBP.

| User | Roles | Channels |
|---|---|---|
| `ada.admin` | admin (also Django superuser) | all |
| `ana.analyst` | analyst | all |
| `pol.editor` | policy_editor | all |
| `apo.approver` | approver | all |
| `pub.publisher` | publisher | all |
| `mia.marketplace` | analyst, approver | `marketplace` only |
| `svc-northlight` | analyst; service account for scheduled tasks, no usable password | all |

Channels: `web` (region `GB`, prices include 20% tax, delivery charge 3.99),
`marketplace` (region `GB`, delivery charge 0.00, 8% fee on the
tax-inclusive item plus delivery), `trade` (region `GB-TRADE`, prices exclude
tax, 1.5% fee on the net item). Locations: `dc-midlands` (all channels),
`fc-london` (web and marketplace).

Policies: `competitive-core`, `competitive-margin-fallback`, `margin-guard`,
`clearance-inventory`, `demand-pilot`, `auto-small-moves` (bounded
automation, authorised by the administrator during seeding for the category
`memory-cards`).

Competitors (simulated): TechHaven, VoltMart, GadgetGrove.

## Products and scenarios

Twenty products, 22 variants, 31 channel listings. The table shows the web
listing; outcomes are those produced by the demonstration run.

| # | Product (SKU) | Web policy | Scenario | Outcome in the run |
|---|---|---|---|---|
| 1 | Lumio Aurora X5 128GB (`LUM-X5-128`) | competitive-core | **Profitable product eligible for a small reduction** | 404.99 → 399.99, competitor-aware (lowest delivered total 403.99 less our 3.99 delivery, then price ending) |
| 1 | Lumio Aurora X5 256GB (`LUM-X5-256`) | competitive-margin-fallback | **Incompatible competitor variant** | Both offers are 128GB listings: excluded (`different_variant`, `weak_match`). Fallback continues to margin-led: 459.99 → 462.49 |
| 2 | Nimbus Book 14 16GB/512GB (`NIM-B14-16`) | margin-guard | **Cost increase requiring a higher price** | New cost imported in step 1 (480 → 505): 759.99 → 793.99. Also listed on `trade`: 639.99 → 644.99 |
| 2 | Nimbus Book 14 8GB/256GB (`NIM-B14-8`) | competitive-core | **Competitor below the retailer's floor** | Competitor target 625.01 is below the floor 687.96; floor kept: 699.99 → 687.99 with the explanation |
| 3 | Zephyr Slate 15 (`ZEP-S15`) | competitive-core | No change explained | Already at the lowest delivered total: no change |
| 4 | Arc Buds Pro (`ARC-BUDS`) | clearance-inventory | **Excess stock approaching a clearance date** | 416 units, 12 days to clearance: 20% off standard retail, 74.99 → 63.99 |
| 5 | Pulse Mini Speaker (`PULSE-SPK`) | competitive-core | **Stockout** | No stock: price held (`stockout_hold`); 9 stockout days excluded from the sales rate |
| 6 | Volt PowerBank 20000 (`VOLT-PB20`) | margin-guard | **Missing cost data** | Cost row with a blank cost is rejected in step 1; recommendation `blocked` (`missing_cost`) |
| 7 | Halo 4K Webcam (`HALO-CAM`) | competitive-core | **Stale feed** | Observations 96 and 120 hours old are excluded as `stale`; policy fallback holds the price; warning gives the last valid observation time |
| 8 | Flux USB-C Cable 2m (`FLUX-CBL`) | margin-guard | **Conflicting floor and ceiling** | Margin floor 9.03 against a contractual maximum of 6.99: `conflict`, no price recommended, cannot be approved |
| 9 | Orbit Wireless Mouse (`ORB-MOUSE`) | competitive-core | **Failed publication followed by reconciliation** | 27.99 → 25.99 (limited by the 8% maximum change). Publication times out after the storefront applied it: `uncertain` → reconciled as applied → `verified` |
| 10 | Orbit Mechanical Keyboard (`ORB-KEYS`) | margin-guard | Approved promotion | 15% off, part supplier-funded: 89.99 → 76.49; movement limits exempt, no price ending |
| 11 | Nova Tab 11 (`NOVA-TAB`) | competitive-core | Membership-only and incomplete offers | GadgetGrove (membership) and VoltMart (delivery unknown) excluded; TechHaven used: 239.99 → 235.99 |
| 12 | Nova Stylus Pen (`NOVA-PEN`) | margin-guard | Margin-led hold | Meets the target: no change |
| 13 | Echo Over-Ear Headphones (`ECHO-HP`) | competitive-core | Refurbished and unavailable offers | Out-of-stock and refurbished offers excluded: 119.99 → 118.99; later rolled back in step 7 |
| 14 | Terra Portable SSD 1TB (`TERRA-SSD`) | demand-pilot | Optional demand-led pricing | Demand estimate validated in the run: 89.99 → 90.99, scheduled and published by the scheduler |
| 15 | Volt 65W GaN Charger (`VOLT-CHG`) | clearance-inventory | Low stock cover | Cover below the lead time: bounded markup 29.99 → 30.99; an override to 9.99 is refused |
| 16 | Halo Ring Light (`HALO-RING`) | clearance-inventory | Aged stock | Bounded markdown 22.99 → 20.99; rejected by the approver in step 6 |
| 17 | Flux 7-in-1 USB-C Hub (`FLUX-HUB`) | competitive-core | Weak match and cooldown | Title-only match excluded; price changed 6 hours ago, cooldown applies: no change |
| 18 | Pulse Soundbar 2.1 (`PULSE-BAR`) | competitive-core | Publication not applied | 139.99 → 137.99. Publication times out before being applied: reconciled as not applied, retried with the same storefront key, `verified` |
| 19 | Terra microSD 256GB (`TERRA-SD`) | auto-small-moves | Bounded automation | 24.99 → 24.49 (−2.0%) approved automatically |
| 20 | Echo Clip-On Microphone (`ECHO-MIC`) | competitive-core | Stale inventory | Inventory 80 hours old (warning); already at the competitor position: no change |

Marketplace listings exist for `LUM-X5-128`, `ARC-BUDS`, `ORB-MOUSE`,
`NOVA-PEN`, `ECHO-HP` and `PULSE-BAR`; trade listings for `NIM-B14-16`,
`ZEP-S15` and `ORB-KEYS`. They use channel-specific cost versions and the
`margin-guard` policy.

Whether the Terra SSD demand estimate validates depends on the synthetic
sales generated for the run date; if it does not, the listing falls back to
the margin rule and the output says so.

## The ten steps

| Step | What it does | Service calls |
|---|---|---|
| 1. Import costs and inventory | Imports `costs_update.csv` (a cost increase; three deliberately invalid rows are rejected with reasons) and `inventory.csv` (two invalid rows rejected) | `apps.costs.services.import_costs`, `apps.inventory.services.import_inventory` |
| 2. Retrieve Price Watch observations | (a) simulated outage: earlier observations are retained with timestamps, none zeroed; (b) recovery pull; (c) one refurbished listing pushed through the normalised import path; (d) optional demand estimate for `TERRA-SSD` | `apps.competitors.services.pull_price_watch`, `import_observations`, `apps.simulation.services.fit_demand_model` |
| 3. Generate recommendations | One pricing run over all 31 listings | `apps.recommendations.services.run_pricing` |
| 4. Inspect explanations | Prints reasons, warnings and excluded offers for the ten required scenarios, and replays one stored snapshot to confirm reproducibility | `PriceRecommendation.reasons` / `.result`, `apps.recommendations.services.replay` |
| 5. Simulate alternatives | 28-day backtest for `LUM-X5-128` and `ARC-BUDS`: fixed, rules-based and competitor-aware arms; the demand-model arm is reported as not run because no validated estimate existed before the simulation start | `apps.simulation.services.simulate_listing` |
| 6. Approve selected changes | An analyst is refused; the approver approves ten changes; a below-floor override is refused first for one of them; the conflict cannot be approved; one markdown is rejected; one price is approved by bounded automation; one is scheduled by the administrator | `apps.recommendations.services.approve`, `reject` |
| 7. Publish to the mock storefront | Pause switch refuses a publication; an approver is refused; publications are sent with two injected faults, then reconciled; the accepted quote is shown to be unchanged; the scheduler publishes the scheduled price; one rollback is refused under current conditions and one succeeds | `apps.publishing.services.set_pause`, `publish`, `reconcile`, `publish_due`, `request_rollback`, `MockStorefront.inject_fault` |
| 8. Verify the observed prices | Reads every listing back from the storefront and compares confirmed with displayed prices | `apps.publishing.services.monitor` |
| 9. Record subsequent synthetic sales | Imports synthetic sales for today at the new prices; one `ORB-MOUSE` order uses the accepted quote, so its average transaction price differs from the displayed price | `apps.inventory.services.import_sales(synthetic=True)` |
| 10. Review realised contribution separately from projections | Prints projected unit contribution next to realised units, average transaction price and realised unit contribution, and the realised total for the day | `apps.simulation.reports.projection_vs_realised`, `realised_summary` |

## Fixture files (`fixtures/demo/`)

| File | Content |
|---|---|
| `catalogue.json` | Organisation, users, channels, locations, tax rules, policies, products, variants, listings (policy, standard retail price, starting price, daily sales rate), and per-listing extras: `commitment`, `promotion`, `previous_price`, `price_experiment`, `stockout_last_days` |
| `costs_baseline.csv` | Starting cost versions, including channel-specific rows for marketplace and trade (imported during seeding) |
| `costs_update.csv` | Step 1 import: the Nimbus cost increase and three invalid rows |
| `inventory.csv` | Step 1 import: stock positions, and two invalid rows |
| `pricewatch_scenarios.json` | Content served by the simulated Price Watch |

Time columns in the fixtures are relative, so the freshness, cooldown and
clearance scenarios hold whenever the demonstration runs.
`apps.accounts.demo.resolve_relative` converts them before import:

| Fixture column | Becomes |
|---|---|
| `effective_days_ago`, `effective_hours_ago` | `effective_from` |
| `as_of_hours_ago` | `as_of` |
| `oldest_stock_received_days_ago` | `oldest_stock_received_at` |
| `clearance_in_days` | `clearance_date` |

In `catalogue.json` the equivalents are `starts_hours_ago`, `ends_in_days`
and `changed_hours_ago`; in `pricewatch_scenarios.json`, `hours_ago`.

Seeding also creates, directly and labelled as demo data: 60 days of
synthetic daily sales per listing (84 days with four price levels for
`TERRA-SSD`), an opening `PriceHistory` entry 120 days ago for every listing,
older competitor observations every two days for six products so the
simulator has a competitor timeline, the storefront's starting prices, and
one accepted quote (`QUOTE-DEMO-1`, `ORB-MOUSE` at 27.99).

## After the demonstration

Log in to the management interface as any demo user with the password you
supplied. `ada.admin` can also open the Django admin at `/admin/`. To call
the API, create a token: `python manage.py drf_create_token ana.analyst`.
