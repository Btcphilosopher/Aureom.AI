# Price Watch adapter

PRICEFLEX imports competitor observations from Price Watch through
`adapters/pricewatch.py`. The module has no Django dependency; the Django side
is `apps/competitors/services.py` (`pull_price_watch`, `import_observations`).

Competitor observations are **market inputs, never instructions**. An
observation can be filtered, compared against and explained. It cannot create
or change a pricing policy, approve a price or trigger a publication, and
PRICEFLEX does not exchange information with, or coordinate prices with, any
competitor. It only positions against publicly observed offers within the
retailer's own constraints.

## 1. What is read from Price Watch

Two read-only calls of the Price Watch API v1:

| Call | Purpose |
|---|---|
| `GET /api/v1/products?q=<gtin>&page_size=5` | Resolve our GTIN to a Price Watch product id and variant id. The response is paginated (`count`, `next`, `previous`, `results`); the adapter matches `variants[].gtin` exactly. |
| `GET /api/v1/products/<id>/offers?variant=<id>&condition=<condition>&quantity=1` | A computed comparison for that variant. Offers arrive in the lists `ranked`, `conditional`, `total_incomplete`, `ineligible`, `unavailable`; entries in `not_comparable` and `insufficient_evidence` carry no price. |

Authentication: `Authorization: Token <key>`. Price Watch errors use
`{"error": {"code", "message", "details", "request_id"}}`; the adapter
surfaces the message.

Conventions the adapter relies on:

- money is a decimal string; `null` means unknown, never zero;
- `price.total` is Price Watch's comparable total (item + mandatory fees +
  delivery + tax not already included − discounts) and is `null` when any
  part is unknown;
- `freshness.observed_at` is when Price Watch checked the price.

Known gaps in Price Watch v1 and how they are handled:

- There is no bulk export, change feed or "since" parameter, so the adapter
  pulls per GTIN. Variants without a GTIN are not pulled.
- No numeric match score is exposed, so match confidence is derived
  (section 3).
- GTIN, MPN and variant attributes are not present on each offer; the
  identity comes from the product lookup and is stored in `product_identity`.
- The offers endpoint returns GBP only and has no currency parameter. An
  observation in a currency other than the channel's is excluded; nothing is
  converted.

## 2. Field mapping

`normalise_offer` maps one Price Watch offer to a `NormalisedObservation`,
stored as `CompetitorObservation`.

| Price Watch | PRICEFLEX | Notes |
|---|---|---|
| `supplier.name`, `supplier.slug` | `supplier`, `supplier_slug` | |
| `listing_id` | `external_listing_id` | the supplier listing; observations are grouped by it |
| `provenance.observation_id` | `external_observation_id` | upsert key together with source `pricewatch` |
| `title` | `title` | |
| `condition` | `condition` | `new`, `refurbished`, `used`, `open_box`, else `unknown` |
| `price.item_subtotal − price.discount_total` | `item_price` | quantity 1 |
| `price.delivery_total` | `delivery_charge` | `null` stays `null` |
| `price.fees_total + price.tax_total` | `mandatory_charges` | `null` if either is `null` |
| `price.total` | `comparable_total` | kept only when complete |
| `price.completeness == "complete"` and a total exists | `charges_complete` | |
| `price.currency` | `currency` | |
| `availability` | `availability` | `in_stock`, `out_of_stock`, `preorder`, else `unknown` |
| `price.eligibility` | `eligibility` | `eligible`, `conditional`, `ineligible` |
| `price.eligibility != "eligible"` | `membership_required` | covers membership-only and other conditional prices |
| `price.conditions` | `eligibility_conditions` | text shown with the exclusion |
| `freshness.observed_at` | `observed_at` | timezone required |
| comparison `mode` | `variant_match` | `exact` → `exact`; `spec_equivalent`, `unit_price` → `different`; otherwise `unknown` |
| `match` and the list the offer came from | `match_confidence`, `match_status`, `match_evidence` | section 3 |
| `provenance.source_url`, `extraction_method`, `configuration_version`, `freshness.state`, `price.lines`, `price.missing`, `notes` | `provenance` | plus `adapter_version` and `fetched_at` |
| product lookup (ids, GTIN, MPN, brand, name), `included_contents`, `warranty` | `product_identity` | |

An offer is rejected (and reported, not stored) when it has no
`provenance.observation_id`, no supplier name, no currency, an unparsable or
negative amount, a non-positive item price, or an `observed_at` without a
timezone. Price-less `not_comparable` and `insufficient_evidence` entries are
reported in the import result with their kind and reasons.

## 3. Derived match confidence

`derive_match` uses the strongest evidence Price Watch reports in
`match.reasons[].strength`:

| Evidence | Confidence |
|---|---|
| `decided_by == "human"` | 1.00 |
| `verified` | 0.99 |
| `structured` | 0.90 |
| `title` | 0.60 |
| any `match.differences` listed (and not a human decision) | capped at 0.75 |

Status: `confirmed` for a human decision or `verified` evidence, `probable`
for other positive evidence, `unresolved` when there is none. The derivation
is written into `match_evidence.confidence_derivation` so that a reviewer can
see that the number was derived by the adapter.

## 4. From observation to eligibility

Whether an observation is used is decided by the pricing policy in
`engine.comparables.build_comparable_set`, not by the adapter.

| Situation | Exclusion code |
|---|---|
| Different variant (`spec_equivalent` comparison) | `different_variant` |
| Used, refurbished or open-box listing when pricing new stock | `condition_mismatch` |
| Not in stock | `unavailable` |
| Membership-only or otherwise conditional price | `membership_only` |
| Delivery or a mandatory fee unknown (delivered-total basis) | `incomplete_mandatory_charges` |
| Older than the policy's `max_observation_age_hours` | `stale` |
| Confidence below `min_match_confidence` | `weak_match` |
| Unresolved or rejected match | `unresolved_match` |
| No price | `missing_price` |
| Currency differs from the channel | `currency_mismatch` |

**Comparison basis.** The policy's `competitor.basis` states whether the
engine compares item prices (`item`) or delivered totals (`delivered_total`).
On the delivered basis the retailer's own candidate is put on the same basis:
our item price plus the channel's customer delivery charge is compared with
the competitor's comparable total, and the delivery charge is deducted again
to arrive at an item price. Each recommendation's `comparables` section
states the basis in words.

Price Watch reports its own `freshness.state`; PRICEFLEX records it in
`provenance` but applies the policy's own freshness limit.

## 5. Failure behaviour

`pull_price_watch` records `FeedStatus` (`last_attempt_at`,
`last_success_at`, `last_failure_at`, `last_error`).

When Price Watch cannot be read (`PriceWatchUnavailable`, `PriceWatchError`):

- nothing is deleted and no price is replaced with zero;
- the observations of each product that could not be read are kept with their
  original `observed_at` and flagged `retained_after_feed_failure`; products
  that were read successfully in the same pull are refreshed and not flagged;
- only a pull in which every product was read counts as a feed success
  (`last_success_at`); a partial failure leaves the feed marked as failing;
- a `competitor_feed_failed` alert is raised;
- at the next evaluation the retained observations are judged by the policy's
  freshness limit like any others, and the recommendation carries a warning
  that the feed is failing. Once they exceed the limit they are excluded as
  `stale` and the policy's `on_no_eligible` fallback (`skip`, `hold` or
  `block`) applies.

On the next successful pull for a variant the flag is cleared and the alert
is resolved.

## 6. Configuration

| Setting (environment variable) | Meaning |
|---|---|
| `PRICEWATCH_MODE` | `simulated` (default) or `http` |
| `PRICEWATCH_BASE_URL` | base URL of the Price Watch instance, for example `http://pricewatch:8000` |
| `PRICEWATCH_API_TOKEN` | Price Watch API token; sent as `Authorization: Token …` |
| `PRICEWATCH_TIMEOUT_SECONDS` | request timeout, default 10 |

`apps.competitors.services.get_client` returns `HttpPriceWatchClient` in
`http` mode. That client uses only the standard library (`urllib`). It
follows the contract above but was not run against a live Price Watch
instance as part of this delivery; verify it against your deployment before
relying on it.

Ways to import:

- scheduled: `apps.competitors.tasks.import_price_watch` (hourly), run as the
  organisation's service account;
- API: `POST /api/v1/competitor-observations` with `{"pull": "pricewatch"}`;
- any other source: push normalised rows to the same endpoint (see
  `docs/api.md`).

## 7. Simulated Price Watch

`adapters/pricewatch_simulated.py` (`SimulatedPriceWatch`) answers the same
two calls with responses in the Price Watch v1 shape, built from
`fixtures/demo/pricewatch_scenarios.json`. It contacts no network.

The scenario file contains:

- `suppliers`: three fictional competitors (`techhaven`, `voltmart`,
  `gadgetgrove`) with a freshness window and extraction method;
- `variants`: one entry per demo GTIN with `product_id`, `variant_id`,
  optional `mode` (for example `spec_equivalent`), `offers` and optional
  `not_comparable` entries;
- per offer: `supplier`, `item`, `delivery` (`null` = unknown), optional
  `fees`, `hours_ago`, `availability`, `condition`, `membership`,
  `match_strength`, `differences`, `title`.

`hours_ago` is relative to the moment of the pull, so the freshness scenarios
hold whenever the demonstration is run. Constructing the client with
`outage=True` makes both calls raise `PriceWatchUnavailable`, which the
demonstration uses to show the failure behaviour above.

Because the simulated responses have the real shape, the same
`normalise_comparison` code path is exercised in the demo, in tests and
against a live instance.
