# Verification record

What was actually run against this code, where, and what happened. Anything
not run is listed as not run.

Build environment: Linux, Python 3.13.18, PostgreSQL 16.15, Redis 7.0.15,
Chromium via Playwright. Date of the run: 24 November 2026.

## Checks run and their outcomes

| Check | Command | Outcome |
|---|---|---|
| Full test suite (PostgreSQL) | `python -m pytest` | **522 passed** in about 22 s |
| Engine-only tests (no database) | `python -m pytest -m engine` | **373 passed**, 149 deselected, about 2 s |
| Lint | `ruff check .` | All checks passed |
| Django system check | `python manage.py check` | No issues |
| Migrations match models | `python manage.py makemigrations --check --dry-run` | No changes detected |
| Migrations apply on PostgreSQL 16 | `python manage.py migrate` | Applied, including the audit append-only trigger |
| Deployment check, production-like env (`DJANGO_DEBUG=false`, 60-char secret, SSL redirect and HSTS on) | `python manage.py check --deploy` | 1 warning: `security.W021` (HSTS preload not enabled — left as an operator decision) |
| Static collection | `python manage.py collectstatic --noinput` | 158 files collected |
| Ten-step demonstration | `python manage.py run_demo` | Completed; output saved verbatim in [demo-output.txt](demo-output.txt) |
| Celery over Redis | started `celery -A config worker`, called three tasks with `.delay().get()` | `expire_recommendations` → 0, `reconcile_uncertain` → 0, `monitor_storefront` → `{'checked': 31, 'mismatched': 0}` |
| Beat schedule wiring | compared `CELERY_BEAT_SCHEDULE` task names with registered tasks | 8 tasks registered; no schedule entry points at a missing task |
| Engine runs without Django | imported `engine.*` and `adapters.*` with `django` made unimportable; ran the example in `pricing-engine.md` §11 from the project root | Imports succeed; example prints the documented values |
| Management interface, desktop (1440 px) | Playwright: signed in, loaded all 11 navigation pages plus product, decision (with reproducibility check) and policy detail pages, ran a simulation through HTMX | Every page HTTP 200; no JavaScript console errors |
| Management interface, phone width (390 px) | Playwright: 8 main pages | No horizontal page overflow |
| Approval through the interface | Playwright as `apo.approver`: approved a recommendation via the HTMX row action | Row updated to *approved*; the Publishing page shows the approver no publish buttons |

Test counts by file: adapters 12, API 24, audit 5, concurrency 2, demo 18,
engine comparables 15, engine demand and simulation 13, engine evaluation 51,
engine money 14, imports 18, publishing 23, recommendations 25 test functions
(parametrised cases bring the total to 522).

## What the tests cover

Tax and fee arithmetic on each charging basis; margin versus markup; rounding
and price endings; conflicting constraints; stale and missing data; policy
reproducibility from stored snapshots; cumulative movement limits, cooldown
and hysteresis; approval and publication permissions including channel limits
and organisation isolation; concurrent publications on real row locks;
reconciliation of applied, not-applied and accepted-but-not-displayed
outcomes; rollback and its refusal under changed costs; the append-only audit
trigger; API authentication, pagination, error envelope and idempotency; no
future-data leakage in the simulator; and the ten demonstration scenarios.

## Not run, and why

| Item | Status |
|---|---|
| `docker compose up --build` | **Not run.** No Docker daemon was available in the build environment. `compose.yaml` parses as valid YAML and the same commands it issues (migrate, gunicorn's WSGI app import, Celery worker, static collection) were exercised directly, but the image build and container start-up are untested. |
| `HttpPriceWatchClient` against a live Price Watch | **Not run.** The adapter was written to the Price Watch v1 contract read from the Price Watch source in this repository and is tested against literal payloads in that shape and the simulated Price Watch; no Price Watch server was running to call. |
| A real storefront | **Not applicable.** Only the simulated storefront exists. |
| Load, soak and security penetration testing | Not run. |
| Browsers other than Chromium | Not run. |

## Dependency verification

The pinned versions were checked by resolving and installing them together
from PyPI into a clean Python 3.13 virtual environment and running the checks
above against that exact set (`requirements.lock`). The framework pins
(Django 5.2.19, DRF 3.17.2, psycopg 3.3.9, Celery 5.7.0, redis 8.2.0,
WhiteNoise 6.12.0, gunicorn 27.0.1) match those already used by the Price
Watch project in this repository; pandas 3.1.1, NumPy 2.5.5 and SciPy 1.18.1
were the newest releases PyPI offered. htmx 2.0.11 was downloaded from the npm
registry and its SHA-256 matches the copy vendored in Price Watch.

The projects' official documentation sites could **not** be consulted from the
build environment: its network policy blocked them (name resolution failed for
djangoproject.com, django-rest-framework.org, celeryq.dev, psycopg.org,
htmx.org, pandas.pydata.org and scipy.org). Compatibility is therefore
established by installation and testing, not by reading the published support
matrices. Docker Hub was reachable and lists `postgres:16` and `redis:7`, the
images used in `compose.yaml`, among its currently supported tags. Before
deployment, confirm the support windows on the official sites.

## Known limitations worth knowing before relying on it

- The demo reset (`seed_demo --reset`, `run_demo`) clears the audit table with
  `TRUNCATE`, which the row-level append-only trigger does not block. It
  refuses to run if any other organisation has audit history. In production,
  also revoke `TRUNCATE`, `UPDATE` and `DELETE` on `audit_auditevent` from the
  application's database role.
- A competitor observation is stored per product variant and is therefore
  considered on every channel that variant is listed on.
- A rollback restores the price recorded as "previous" on the newest history
  entry, so rolling back twice returns to the price the first rollback undid.
- Bounded automation is switched off by any warning on the recommendation,
  including informational ones.
- Channel-limited members who start an evaluation without naming a channel get
  a run over their own channels only, rather than an error.
- Demand-led prices are chosen from whole-cent candidates around the
  optimiser's answer and can sit a few pence inside a bound.
