# Governance and security

This document describes the controls PRICEFLEX implements and the reviews a
retailer must carry out before using it on live prices. It is not legal
advice.

## 1. Organisations, roles and channels

Every business record belongs to one `Organisation`. A user acts through a
`Membership` holding one or more roles and, optionally, a list of channels.
An empty channel list means all channels of the organisation.

| Permission | analyst | policy_editor | approver | publisher | admin |
|---|---|---|---|---|---|
| `view` | yes | yes | yes | yes | yes |
| `import_data` (costs, inventory, sales, competitor observations) | yes | yes | – | – | yes |
| `run_pricing` | yes | yes | yes | – | yes |
| `simulate` (simulations, demand-model fitting) | yes | yes | yes | – | yes |
| `edit_policy` | – | yes | – | – | yes |
| `approve` (approve, reject, withdraw, approve a promotion) | – | – | yes | – | yes |
| `publish` (publish, reconcile, roll back, pause/resume, schedule) | – | – | – | yes | yes |
| `administer` (authorise automation) | – | – | – | – | yes |

The matrix is `PERMISSIONS` in `apps/accounts/permissions.py`. Service
functions that change state call `require(membership, permission, channel)`
before doing anything, so the API, the management interface, scheduled tasks
and the demonstration all pass through the same checks.

Channel permissions: an action on a listing requires access to its channel
(`channel_denied` otherwise), and list queries are restricted to permitted
channels (`scope_listings`, `channel_ids`). Objects of another organisation
are not reachable.

Approving and publishing are separate permissions. A user needs both roles
(or `admin`) to approve a price with a schedule, because a scheduled price is
later published by the system without a further human step.

Scheduled work (periodic evaluation, Price Watch import) runs as a service
account named `svc-<organisation slug>` and is skipped if that account has no
membership. The demo service account has the `analyst` role and no usable
password.

## 2. Audit

`AuditEvent` records organisation, actor (user, or the label `system`,
`automation`, `system (scheduled)`), action, object type and id, a summary and
a JSON payload.

Append-only is enforced twice: `AuditEvent.save` refuses updates and
`delete` raises, and a PostgreSQL trigger
(`audit_auditevent_no_update_delete`, migration
`apps/audit/migrations/0003_append_only_trigger.py`) rejects any `UPDATE` or
`DELETE` on the table. A database superuser can still `TRUNCATE` the table
or drop the trigger (the demo reset truncates it, and only when the demo
organisation is the table's sole content); restrict those privileges in
production.

Actions emitted by the code:

| Area | Actions |
|---|---|
| Costs | `cost.version_created` (with previous and new acquisition cost), `cost.import` |
| Inventory and sales | `inventory.import`, `sales.import` |
| Competitor data | `competitor.import` |
| Policies | `policy.version_created` (with previous version and config hash), `policy.automation_authorised`, `policy.automation_revoked`, `promotion.approved` |
| Pricing | `pricing_run.completed` |
| Approval | `recommendation.approval`, `recommendation.override_approved` (recommended and approved price, comment), `recommendation.approved` (bounded automation, actor `automation`), `recommendation.rejected`, `recommendation.withdrawn`, `recommendation.expired`, `recommendation.superseded`, `recommendation.failed` |
| Publication | `publication.publish_verified`, `publication.rollback_verified`, `publication.failed`, `publication.uncertain`, `publication.paused`, `publication.resumed`, `publication.rollback_requested`, `publication.rollback_refused` |
| Analysis | `simulation.run`, `demand_model.fitted` |
| Demo | `demo.seeded` |

Routine internal transitions (draft → evaluated → awaiting approval, and
supersession by a newer evaluation) are not audited individually; the
pricing run is. In addition, each recommendation keeps its input snapshot,
policy version, algorithm version and `ApprovalDecision` rows, and each
publication keeps its request, the storefront's response and every
read-back (`ObservedPublishedPrice`).

## 3. Approval rules

- Manual approval is the default. Only a recommendation in
  `awaiting_approval` can be approved or rejected.
- A rejection needs a recorded reason.
- An **override** is an approved price different from the recommended one, or
  any price supplied for a `conflict`. It needs a recorded reason and is
  audited as `recommendation.override_approved`.
- Every approved price, override or not, is validated against the hard
  constraints under the conditions at the moment of approval
  (`engine.evaluation.validate_price`): contribution floors on the current
  cost and tax, absolute limits and contractual restrictions. An override may
  exceed the automatic movement limits; it cannot go below a cost floor or
  outside an absolute or contractual limit. If the hard constraints
  themselves conflict, no price can be approved until the policy, cost or
  commitment is corrected.
- A `blocked` recommendation (missing cost, uncertain tax configuration,
  invalid policy, stale critical input) never reaches approval.
- Recommendations expire (`recommendation_ttl_hours`, default 24) and are
  superseded by a newer evaluation or by a change of the live price.

## 4. Bounded automation

Automatic approval happens only when **all** of the following hold
(`apps.recommendations.services._automation_allows`):

1. the policy version has `automation.enabled: true` and names
   `allowed_categories`;
2. an administrator has authorised automation for that policy
   (`PricingPolicy.automation_authorised`; audited). Saving a policy version
   without automation enabled clears the authorisation;
3. the outcome is a price change with a known current price;
4. the product's category is in `allowed_categories`;
5. the change is within `max_auto_change_pct` (the validator caps this
   setting at 10%);
6. it is a reduction, unless `allow_price_increases` is true;
7. the recommendation has no warnings.

The decision is stored as `ApprovalDecision` with decision `auto_approved`
and no user. Automation approves only; publication still requires a
publisher (or an approved schedule), and still passes every publication
check.

## 5. Publication controls

- **Pause switch** (`PublicationControl`, `set_pause`): while paused, no
  publication is sent, including scheduled ones. Pausing needs a reason and
  both pausing and resuming are audited.
- **Re-check at publication**: state, expiry, the listing's `price_version`,
  the hard constraints under current conditions, and the storefront's
  displayed price must all be as expected, otherwise nothing is sent.
- **Idempotency**: the storefront key is the same across retries of one
  intended change.
- **Verification**: a price is confirmed only by a matching storefront
  read-back. An accepted request whose read-back differs, and a timeout, are
  `uncertain` and raise an alert until reconciled.
- **Monitoring**: the periodic monitor reads back every listing and raises a
  critical `storefront_price_drift` alert on a mismatch. It does not correct
  prices by itself.
- **Rollback** (`request_rollback`): restores the previously confirmed price.
  It needs the `publish` permission and a reason, is audited
  (`publication.rollback_requested`, `publication.rollback_verified`), and is
  refused (`publication.rollback_refused`) if the earlier price would breach
  the hard constraints under current conditions. A rollback is allowed while
  publication is paused, because it is a safety action. It goes through the
  same idempotent, verified publication path.

## 6. Existing commitments

- **Contractual restrictions** are recorded as `PriceCommitment` (minimum,
  maximum or fixed price, with a reference and validity dates) and enforced
  as hard constraints in evaluation, approval, publication and rollback.
- **Accepted quotes and placed orders**: publishing changes the price offered
  to new orders on one channel listing. PRICEFLEX never rewrites a quote or
  an order. In the simulated storefront, `MockStorefrontQuote` holds a locked
  price that `price_for_order` honours over the displayed price. A real
  storefront adapter must preserve the equivalent behaviour of the platform
  it connects to; confirm this for your platform.
- **Promotions** are honoured by the engine only when their status is
  `approved` and the evaluation time lies between their start and end.

## 7. Competitor data

- Observations are stored and used as market inputs. Nothing in an
  observation is executed or interpreted as a rule.
- Pricing policies can only be created or changed by an authorised member
  through `apps.policies.services.save_policy`; there is no path by which an
  external feed supplies or alters a policy.
- PRICEFLEX sends nothing to competitors and has no mechanism for agreeing or
  signalling prices. The competitor-aware strategy positions against publicly
  observed offers inside the retailer's own floors and limits.
- Every recommendation keeps the eligible and excluded offers it used
  (`ComparableOfferSet`), with provenance.

## 8. Personal data

Pricing inputs are product, channel, region and inventory conditions. There
is no customer model, no individual willingness-to-pay estimate and no
sensitive personal attribute anywhere in the engine inputs
(`engine/types.py`). Sales are stored as aggregates per variant, channel and
period. Experiments assign listings (products on a channel), never
individual customers.

## 9. AI

No AI component is included. If one is added later, its role should be
limited to explaining stored decisions or drafting policy proposals for a
policy editor to review. Prices must continue to come only from the
deterministic engine, the validation in `engine.policy` and
`engine.evaluation`, and the authorised approval and publication workflow.

## 10. Application security settings

- Secrets and connection details come from the environment; `DJANGO_SECRET_KEY`
  is required unless `DJANGO_DEBUG` is on.
- Session and CSRF cookies are `Secure` unless debug is on; `X-Frame-Options:
  DENY`; content-type sniffing is disabled.
- The API requires authentication on every endpoint and is rate limited
  (`PRICEFLEX_API_RATE`).
- Demo users receive only the password supplied when seeding; there is no
  built-in default password.

## 11. Before live deployment

The following need review by the retailer's own qualified legal, finance and
compliance reviewers for each jurisdiction and channel. PRICEFLEX does not
perform these reviews.

- [ ] **Consumer pricing law**: price display, tax-inclusive presentation,
  mandatory charges, unit pricing where required, and rules on how often and
  how prices may change.
- [ ] **Promotions and reference prices**: any "was" price, strike-through or
  percentage-off claim must meet the applicable rules on genuine prior
  prices and duration. PRICEFLEX stores a standard retail price and price
  history but does not check the lawfulness of a reference-price claim.
- [ ] **Contracts**: supplier, marketplace and customer agreements (minimum
  or maximum prices, price promises, most-favoured terms, marketplace
  parity clauses) are recorded as `PriceCommitment` where they constrain
  price, and reviewed for terms the system cannot represent.
- [ ] **Competition law**: use of competitor price data, the source and
  lawfulness of its collection, and the configured competitor-aware
  policies; confirm that no information is shared with competitors and that
  third-party data providers do not act as a channel for coordination.
- [ ] **Tax configuration**: every `TaxRule` (rate, inclusive or exclusive
  presentation, effective dates) and the treatment of recoverable and
  non-recoverable input tax in `CostVersion`.
- [ ] **Cost data**: ownership, source and refresh frequency of costs and
  fees; whether `max_cost_age_days` should block stale costs.
- [ ] **Policies**: floors, ceilings, movement limits and fallbacks approved
  by an accountable owner; automation left off unless explicitly authorised.
- [ ] **Storefront adapter**: a real adapter implemented and tested for
  compare-and-set, idempotency, true read-back of the displayed price, and
  preservation of quotes and orders.
- [ ] **Access**: roles assigned by duty; approver and publisher held by
  different people where separation is required; database privileges that
  prevent truncating the audit table.
- [ ] **Operations**: an owner for alerts (`publication_uncertain`,
  `storefront_price_drift`, `competitor_feed_failed`), the pause switch and
  rollback; a tested backup and restore of the database.
