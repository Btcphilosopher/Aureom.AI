"""Structured, human-readable explanations of an evaluation result."""

from __future__ import annotations

from .evaluation import OUTCOME_BLOCKED, OUTCOME_CHANGE, OUTCOME_CONFLICT, OUTCOME_NO_CHANGE

CONSTRAINT_LABELS = {
    "minimum_contribution_margin": "Minimum contribution margin",
    "minimum_contribution_amount": "Minimum contribution amount",
    "clearance_minimum_contribution_margin": "Clearance minimum contribution margin",
    "clearance_minimum_contribution_amount": "Clearance minimum contribution amount",
    "promotion_approved_minimum_contribution_margin": "Promotion's approved contribution floor",
    "absolute_minimum_price": "Absolute minimum price",
    "absolute_maximum_price": "Absolute maximum price",
    "standard_retail_price_cap": "Standard retail price cap",
    "contractual_minimum_price": "Contractual minimum price",
    "contractual_maximum_price": "Contractual maximum price",
    "contractual_fixed_price": "Contractual fixed price",
    "maximum_price_change": "Maximum change per evaluation",
    "maximum_cumulative_movement": "Maximum cumulative movement",
    "cooldown": "Cooldown",
    "minimum_meaningful_change": "Minimum meaningful change",
    "hysteresis": "Hysteresis band",
    "price_ending": "Price ending",
}

STRATEGY_LABELS = {
    "promotion": "Promotion", "clearance": "Clearance", "demand_led": "Demand-led",
    "competitor_aware": "Competitor-aware", "inventory_led": "Inventory-led", "margin_led": "Margin-led",
    "stockout_hold": "Stockout hold",
}

OUTCOME_LABELS = {
    OUTCOME_CHANGE: "Price change recommended",
    OUTCOME_NO_CHANGE: "No change recommended",
    OUTCOME_CONFLICT: "Constraint conflict - review required",
    OUTCOME_BLOCKED: "Blocked - inputs incomplete",
}


def recommendation_response(
    result: dict, *, product_id: str, variant_id: str, sku: str, channel: str, status: str,
    input_snapshot_id: str, policy_version: str, recommendation_id: str | None = None,
) -> dict:
    """The public recommendation document (API section 9 of the specification).

    ``result`` is ``EvaluationResult.to_dict()``. Every value comes from the
    evaluation; nothing here is invented or defaulted.
    """
    return {
        "id": recommendation_id,
        "product_id": product_id,
        "variant_id": variant_id,
        "sku": sku,
        "channel": channel,
        "currency": result["currency"],
        "current_customer_price": result["current_price"],
        "recommended_customer_price": result["recommended_price"],
        "outcome": result["outcome"],
        "status": status,
        "input_snapshot_id": input_snapshot_id,
        "policy_version": policy_version,
        "algorithm_version": result["algorithm_version"],
        "evaluated_at": result["evaluation_time"],
        "selected_strategy": result["selected_strategy"],
        "reasons": result["reasons"],
        "constraints_applied": result["constraints_applied"],
        "warnings": result["warnings"],
        "blocking_issues": result["blocking_issues"],
    }


def summarise(result: dict) -> str:
    """One line for lists and logs."""
    head = OUTCOME_LABELS.get(result["outcome"], result["outcome"])
    first = result["reasons"][0] if result["reasons"] else ""
    return f"{head}: {first}" if first else head
