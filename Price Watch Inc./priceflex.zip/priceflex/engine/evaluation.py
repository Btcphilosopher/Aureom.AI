"""Deterministic evaluation: inputs in, one explained decision out.

``evaluate`` is a pure function of :class:`EvaluationInput`. It reads no
clock, database, network or random source, so replaying a stored input
snapshot with the same ``ALGORITHM_VERSION`` reproduces the decision exactly.

Decision sequence::

    1. validate the policy                      -> blocked if invalid
    2. check critical inputs (cost, tax, ...)   -> blocked if missing/stale
    3. build the comparable competitor set
    4. choose the constraint mode (standard / promotion / clearance)
    5. build the feasible interval              -> conflict if empty
    6. walk strategy_order; first applicable strategy supplies the target
    7. clamp the target to the interval and record the binding constraint
    8. stability: minimum meaningful change, hysteresis
    9. price ending, then validate the rounded price again
   10. explain - including when the answer is "no change"
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from decimal import Decimal

from . import ALGORITHM_VERSION
from .comparables import ComparableSet, build_comparable_set
from .constraints import (
    MODE_CLEARANCE,
    MODE_PROMOTION,
    MODE_STANDARD,
    MOVEMENT,
    FeasibleInterval,
    apply_price_ending,
    compute_interval,
    last_direction,
)
from .money import MarginBreakdown, margin_breakdown, money_str
from .policy import STRATEGY_CLEARANCE, STRATEGY_COMPETITOR, STRATEGY_PROMOTION, PolicyConfig, parse_policy
from .strategies import (
    STRATEGY_FUNCTIONS,
    Context,
    InventoryMetrics,
    Proposal,
    active_promotion,
    clearance_state,
    inventory_metrics,
)
from .types import EvaluationInput, parse_dt

OUTCOME_CHANGE = "change"
OUTCOME_NO_CHANGE = "no_change"
OUTCOME_CONFLICT = "conflict"
OUTCOME_BLOCKED = "blocked"


@dataclass
class EvaluationResult:
    outcome: str
    algorithm_version: str
    evaluation_time: datetime
    currency: str
    current_price: Decimal | None
    recommended_price: Decimal | None
    selected_strategy: str | None = None
    mode: str = MODE_STANDARD
    reasons: list[str] = field(default_factory=list)
    constraints_applied: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    blocking_issues: list[dict] = field(default_factory=list)
    interval: FeasibleInterval | None = None
    selection_trace: list[Proposal] = field(default_factory=list)
    comparables: ComparableSet | None = None
    inventory: InventoryMetrics | None = None
    margin_current: MarginBreakdown | None = None
    margin_recommended: MarginBreakdown | None = None
    projection: dict | None = None

    @property
    def publishable(self) -> bool:
        return self.outcome == OUTCOME_CHANGE and self.recommended_price is not None

    def to_dict(self) -> dict:
        return {
            "outcome": self.outcome,
            "algorithm_version": self.algorithm_version,
            "evaluation_time": self.evaluation_time.isoformat(),
            "currency": self.currency,
            "current_price": money_str(self.current_price),
            "recommended_price": money_str(self.recommended_price),
            "selected_strategy": self.selected_strategy,
            "mode": self.mode,
            "reasons": self.reasons,
            "constraints_applied": self.constraints_applied,
            "warnings": self.warnings,
            "blocking_issues": self.blocking_issues,
            "feasible_interval": self.interval.to_dict() if self.interval else None,
            "selection_trace": [p.to_dict() for p in self.selection_trace],
            "comparables": self.comparables.to_dict() if self.comparables else None,
            "inventory": self.inventory.to_dict() if self.inventory else None,
            "margin_current": self.margin_current.to_dict() if self.margin_current else None,
            "margin_recommended": self.margin_recommended.to_dict() if self.margin_recommended else None,
            "projection": self.projection,
        }


def _add(items: list[str], item: str) -> None:
    if item and item not in items:
        items.append(item)


def blocking_issues(inp: EvaluationInput, policy: PolicyConfig | None, policy_errors: list[str]) -> list[dict]:
    """Conditions under which no price may be recommended or published."""
    issues: list[dict] = []
    if policy_errors or policy is None:
        issues.append({"code": "invalid_policy",
                       "message": "The pricing policy is invalid: " + "; ".join(policy_errors)})
        return issues
    if inp.cost is None:
        issues.append({"code": "missing_cost",
                       "message": inp.cost_issue or "No cost version is effective for this product and channel."})
    else:
        if inp.cost.currency != inp.currency:
            issues.append({"code": "currency_mismatch",
                           "message": f"Cost is recorded in {inp.cost.currency} but the channel prices in "
                                      f"{inp.currency}. No currency conversion is assumed."})
        if policy.max_cost_age_days is not None:
            effective = parse_dt(inp.cost.effective_from) if inp.cost.effective_from else None
            if effective is None or inp.evaluation_time - effective > timedelta(days=policy.max_cost_age_days):
                issues.append({"code": "stale_cost",
                               "message": f"The cost version (effective {inp.cost.effective_from or 'unknown'}) is "
                                          f"older than the policy limit of {policy.max_cost_age_days} days."})
    if inp.tax is None:
        issues.append({"code": "uncertain_tax_configuration",
                       "message": inp.tax_issue or "No tax rule is configured for this product's tax category in "
                                                   "this channel's region."})
    inv_policy = policy.inventory
    if inv_policy.on_stale_inventory == "block":
        if inp.inventory is None:
            issues.append({"code": "missing_inventory", "message": "No inventory position is available."})
        elif inp.inventory.as_of is None or (
            inp.evaluation_time - inp.inventory.as_of > timedelta(hours=inv_policy.max_inventory_age_hours)
        ):
            issues.append({"code": "stale_inventory",
                           "message": f"Inventory was last updated {inp.inventory.as_of}; the policy treats "
                                      f"inventory older than {inv_policy.max_inventory_age_hours} hours as critical."})
    return issues


def _mode(policy: PolicyConfig, promotion, clearance) -> str:
    """Promotion/clearance change the floors only when they would be reached in the order."""
    for name in policy.strategy_order:
        if name == STRATEGY_PROMOTION:
            if promotion is not None:
                return MODE_PROMOTION
        elif name == STRATEGY_CLEARANCE:
            if clearance.active:
                return MODE_CLEARANCE
        else:
            break
    return MODE_STANDARD


def _interval(inp: EvaluationInput, policy: PolicyConfig, mode: str, promotion, *, movement: bool) -> FeasibleInterval:
    return compute_interval(
        policy=policy, cost=inp.cost, tax=inp.tax, currency=inp.currency, evaluation_time=inp.evaluation_time,
        current_price=inp.current_price, standard_retail_price=inp.standard_retail_price,
        customer_delivery_charge=inp.customer_delivery_charge, price_history=inp.price_history,
        commitments=inp.commitments, mode=mode, promotion=promotion, include_movement=movement,
    )


def _breakdown(inp: EvaluationInput, price: Decimal | None, funding: Decimal = Decimal("0")) -> MarginBreakdown | None:
    if price is None or inp.cost is None or inp.tax is None:
        return None
    return margin_breakdown(price, inp.cost, inp.tax, customer_delivery_charge=inp.customer_delivery_charge,
                            promotion_funding=funding)


def evaluate(inp: EvaluationInput) -> EvaluationResult:
    cur = inp.currency
    result = EvaluationResult(
        outcome=OUTCOME_BLOCKED, algorithm_version=ALGORITHM_VERSION, evaluation_time=inp.evaluation_time,
        currency=cur, current_price=inp.current_price, recommended_price=None,
    )
    policy, policy_errors = parse_policy(inp.policy)
    issues = blocking_issues(inp, policy, policy_errors)
    result.margin_current = _breakdown(inp, inp.current_price)
    if issues:
        result.blocking_issues = issues
        result.reasons = ["No recommendation can be made and publication is blocked: "
                          + " ".join(i["message"] for i in issues)]
        return result

    # -- context ---------------------------------------------------------------
    comparables = build_comparable_set(
        inp.competitor_observations, policy.competitor, evaluation_time=inp.evaluation_time, currency=cur,
        own_condition=inp.condition, own_delivery_charge=inp.customer_delivery_charge, feeds=inp.feeds,
    )
    inv = inventory_metrics(inp, policy)
    promotion = active_promotion(inp)
    clearance = clearance_state(inp, policy, inv)
    mode = _mode(policy, promotion, clearance)
    interval = _interval(inp, policy, mode, promotion, movement=True)
    funding = promotion.supplier_funding_per_unit if (mode == MODE_PROMOTION and promotion) else Decimal("0")
    result.comparables, result.inventory, result.interval, result.mode = comparables, inv, interval, mode
    result.margin_current = _breakdown(inp, inp.current_price, funding)

    if inp.current_price is None:
        _add(result.warnings, "No confirmed published price exists for this listing; movement limits cannot apply.")
    if not inv.known:
        _add(result.warnings, "No inventory position is available; inventory-led rules were skipped.")
    elif inv.stale:
        _add(result.warnings, "Inventory position is stale; inventory-led rules were skipped.")
    if inv.stockout_days:
        _add(result.warnings, f"{inv.stockout_days} stockout day(s) were excluded from the sales rate; zero sales "
                              "while out of stock is not read as zero demand.")
    competitor_in_order = STRATEGY_COMPETITOR in policy.strategy_order
    if competitor_in_order:
        for w in comparables.warnings:
            _add(result.warnings, w)

    ctx = Context(inp, policy, inp.cost, inp.tax, comparables, inv, promotion, clearance, interval)
    selected: Proposal | None = None
    for name in policy.strategy_order:
        proposal = STRATEGY_FUNCTIONS[name](ctx)
        result.selection_trace.append(proposal)
        if selected is None and proposal.applicable:
            selected = proposal

    # -- conflict ----------------------------------------------------------------
    if interval.conflict:
        result.outcome = OUTCOME_CONFLICT
        result.reasons = ["The price constraints cannot all be satisfied, so no price is recommended. "
                          "A reviewer must resolve the conflict."] + list(interval.conflict_detail)
        if result.margin_current and inp.current_price is not None:
            hard = _interval(inp, policy, mode, promotion, movement=False)
            if not hard.conflict and inp.current_price < hard.lower:
                _add(result.warnings, f"The current price {cur} {inp.current_price:.2f} is below the hard floor "
                                      f"of {cur} {hard.lower:.2f}.")
        return result

    # -- selection ---------------------------------------------------------------
    stockout = policy.on_stockout == "hold" and inv.known and not inv.stale and inv.available <= 0
    hold_reason = ""
    if stockout and mode != MODE_PROMOTION and inp.current_price is not None:
        hold = Proposal("stockout_hold", True, None, hold=True, selected=True, evidence=inv.to_dict(), reasons=[
            "The product is out of stock on this channel's locations; the policy holds the price until stock "
            "returns. Zero sales during the stockout are not treated as weak demand."])
        result.selection_trace.insert(0, hold)
        selected = hold
    elif selected is not None:
        selected.selected = True

    if selected is not None and selected.block:
        result.outcome = OUTCOME_BLOCKED
        result.selected_strategy = selected.strategy
        result.blocking_issues = [{"code": "insufficient_competitor_evidence", "message": " ".join(selected.reasons)}]
        result.reasons = list(selected.reasons)
        return result

    if selected is None or selected.hold or selected.target is None:
        if inp.current_price is None:
            result.outcome = OUTCOME_BLOCKED
            result.blocking_issues = [{"code": "no_basis_for_price",
                                       "message": "No strategy produced a price and there is no current price to hold."}]
            result.reasons = [result.blocking_issues[0]["message"]]
            return result
        target = inp.current_price
        hold_reason = ("No strategy in the policy's order applied, so the current price is held."
                       if selected is None else "")
    else:
        target = selected.target
    result.selected_strategy = selected.strategy if selected else None
    if selected:
        for r in selected.reasons:
            _add(result.reasons, r)
        for w in selected.warnings:
            _add(result.warnings, w)
    if hold_reason:
        _add(result.reasons, hold_reason)
    for note in interval.notes:
        _add(result.reasons, note)

    # -- clamp to the feasible interval -----------------------------------------
    candidate = interval.clamp(target)
    current = inp.current_price
    if target < interval.lower:
        b = interval.binding_lower
        _add(result.constraints_applied, b.name)
        if selected and selected.strategy == STRATEGY_COMPETITOR and b.kind != MOVEMENT:
            _add(result.reasons, f"The competitor-based target of {cur} {target:.2f} is below the price floor of "
                                 f"{cur} {interval.lower:.2f} ({b.name}). The floor is kept; the competitor is not "
                                 "followed into a loss-making or below-policy price.")
        elif current is not None and target == current:
            _add(result.reasons, f"The current price {cur} {current:.2f} is below the minimum of "
                                 f"{cur} {interval.lower:.2f} required by {b.name}; it must rise to that minimum.")
        else:
            _add(result.reasons, f"The target of {cur} {target:.2f} is limited to {cur} {interval.lower:.2f} "
                                 f"by {b.name}. {b.detail}")
    elif interval.upper is not None and target > interval.upper:
        b = interval.binding_upper
        _add(result.constraints_applied, b.name)
        if current is not None and target == current:
            _add(result.reasons, f"The current price {cur} {current:.2f} is above the maximum of "
                                 f"{cur} {interval.upper:.2f} allowed by {b.name}; it must fall to that maximum.")
        else:
            _add(result.reasons, f"The target of {cur} {target:.2f} is limited to {cur} {interval.upper:.2f} "
                                 f"by {b.name}. {b.detail}")
    for b in interval.bounds:
        if b.name == "cooldown":
            _add(result.constraints_applied, "cooldown")
            _add(result.reasons, b.detail)

    # -- stability ---------------------------------------------------------------
    must_move = current is not None and not interval.contains(current)
    if current is not None and not must_move and candidate != current and mode != MODE_PROMOTION:
        delta = candidate - current
        threshold = max(policy.min_meaningful_change_amount, current * policy.min_meaningful_change_pct)
        direction = last_direction(inp.price_history)
        if abs(delta) < threshold:
            _add(result.constraints_applied, "minimum_meaningful_change")
            _add(result.reasons, f"The indicated change of {cur} {delta:+.2f} is smaller than the minimum meaningful "
                                 f"change of {cur} {threshold:.2f}, so the price is held to avoid churn.")
            candidate = current
        elif (policy.hysteresis_pct and direction and (delta > 0) != (direction > 0)
              and abs(delta) < current * policy.hysteresis_pct):
            _add(result.constraints_applied, "hysteresis")
            _add(result.reasons, f"The indicated change of {cur} {delta:+.2f} would reverse the previous price move "
                                 f"and is inside the {policy.hysteresis_pct:.1%} hysteresis band, so the price is "
                                 "held to prevent oscillation.")
            candidate = current

    # -- price ending, then validate again ---------------------------------------
    promotion_price = mode == MODE_PROMOTION and selected is not None and selected.strategy == STRATEGY_PROMOTION
    if promotion_price and candidate != current and policy.price_endings:
        _add(result.reasons, "Price endings are not applied to an approved promotion price.")
    if candidate != current and policy.price_endings and not promotion_price:
        rounded = apply_price_ending(candidate, policy.price_endings, interval)
        if rounded is None:
            if policy.ending_fallback == "conflict":
                result.outcome = OUTCOME_CONFLICT
                result.reasons.append(f"No allowed price ending fits inside the feasible range {cur} "
                                      f"{interval.lower:.2f} to {money_str(interval.upper) or 'unbounded'}; "
                                      "the policy requires review in this case.")
                return result
            _add(result.warnings, "No allowed price ending fits inside the feasible range; the unrounded "
                                  "price is kept so that no constraint is breached.")
        else:
            if rounded != candidate:
                _add(result.reasons, f"Price ending applied: {cur} {candidate:.2f} becomes {cur} {rounded:.2f}.")
            _add(result.constraints_applied, "price_ending")
            candidate = rounded
    breaches = interval.violations(candidate)
    if breaches:  # pragma: no cover - defensive: a rounded price must never leave the interval
        result.outcome = OUTCOME_CONFLICT
        result.reasons.append("The rounded price failed re-validation against: " + ", ".join(b.name for b in breaches))
        return result

    # -- outcome -----------------------------------------------------------------
    result.recommended_price = candidate
    result.margin_recommended = _breakdown(inp, candidate, funding)
    if current is not None and candidate == current:
        result.outcome = OUTCOME_NO_CHANGE
        result.reasons.insert(0, f"No price change is recommended: {cur} {current:.2f} remains appropriate under "
                                 "the policy.")
    else:
        result.outcome = OUTCOME_CHANGE
        if current is not None:
            pct = (candidate - current) / current
            word = "increase" if candidate > current else "reduction"
            result.reasons.insert(0, f"Recommended {word} from {cur} {current:.2f} to {cur} {candidate:.2f} "
                                     f"({pct:+.1%}).")
        else:
            result.reasons.insert(0, f"Recommended initial price of {cur} {candidate:.2f}.")

    mc, mr = result.margin_current, result.margin_recommended
    result.projection = {
        "label": "PROJECTION - derived from current inputs, not a realised result",
        "unit_contribution_current": money_str(mc.contribution) if mc else None,
        "unit_contribution_recommended": money_str(mr.contribution) if mr else None,
        "unit_contribution_change": money_str(mr.contribution - mc.contribution) if (mc and mr) else None,
        "volume_forecast": None,
        "volume_forecast_note": "No sales-volume effect is projected: no validated demand estimate drives this "
                                "recommendation.",
    }
    if selected and selected.strategy == "demand_led" and "expected_units_per_day" in selected.evidence:
        result.projection["volume_forecast"] = {
            k: selected.evidence[k] for k in
            ("expected_units_per_day", "expected_units_per_day_low", "expected_units_per_day_high",
             "expected_daily_contribution")
        }
        result.projection["volume_forecast_note"] = (
            "Model projection from an observational demand estimate; the interval reflects the elasticity's "
            "95% confidence bounds.")
    return result


def validate_price(inp: EvaluationInput, price: Decimal) -> dict:
    """Check an arbitrary price (an override, or a price about to be published)
    against the *hard* constraints as they stand in ``inp``.

    Movement limits are deliberately excluded: an authorised override may move
    further than the automatic limits, but can never pass a cost floor,
    absolute limit or contractual restriction.
    """
    policy, errors = parse_policy(inp.policy)
    issues = blocking_issues(inp, policy, errors)
    if issues:
        return {"ok": False, "blocking_issues": issues, "violations": [], "interval": None}
    inv = inventory_metrics(inp, policy)
    promotion = active_promotion(inp)
    mode = _mode(policy, promotion, clearance_state(inp, policy, inv))
    hard = _interval(inp, policy, mode, promotion, movement=False)
    if hard.conflict:
        return {"ok": False, "blocking_issues": [{"code": "constraint_conflict",
                                                  "message": " ".join(hard.conflict_detail)}],
                "violations": [], "interval": hard.to_dict()}
    violations = [b.to_dict() for b in hard.violations(price)]
    return {"ok": not violations, "blocking_issues": [], "violations": violations, "interval": hard.to_dict()}


__all__ = ["evaluate", "validate_price", "EvaluationResult", "OUTCOME_CHANGE", "OUTCOME_NO_CHANGE",
           "OUTCOME_CONFLICT", "OUTCOME_BLOCKED"]
