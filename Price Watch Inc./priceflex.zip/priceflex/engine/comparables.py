"""Build the comparable competitor offer set for one evaluation.

Competitor observations are *market inputs*. They are filtered here against
the policy's comparability and freshness rules; nothing an observation says
is ever treated as an instruction, and the engine never coordinates with a
competitor - it only positions against publicly observed offers.

The policy states the comparison basis:

``item``
    competitor item price vs. our item price.
``delivered_total``
    competitor comparable total (item + delivery + mandatory charges) vs. our
    item price + our customer delivery charge.

A missing price is never read as zero.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
from statistics import median

from .money import CENT, ZERO, money_str, q2
from .policy import BASIS_DELIVERED, BASIS_ITEM, CompetitorPolicy
from .types import CompetitorObservation, FeedStatus, iso

EXCLUSION_LABELS = {
    "different_variant": "Different variant from the product being priced",
    "variant_unknown": "Variant could not be established",
    "condition_mismatch": "Condition is not comparable with the stock being priced",
    "unavailable": "Listing is not available to buy",
    "membership_only": "Membership-only or conditional price without applicable eligibility",
    "incomplete_mandatory_charges": "Mandatory charges are incomplete, so no delivered total exists",
    "missing_price": "No price was observed (not treated as zero)",
    "stale": "Observation is older than the policy's freshness limit",
    "weak_match": "Match confidence is below the policy threshold",
    "unresolved_match": "Product match is unresolved or rejected",
    "currency_mismatch": "Currency differs from the channel currency (no conversion is applied)",
}


@dataclass(frozen=True)
class EligibleOffer:
    observation_id: str
    supplier: str
    value: Decimal  # on the policy's comparison basis
    observed_at: datetime
    match_confidence: Decimal
    flags: tuple[str, ...] = ()
    smoothed_from: int = 1

    def to_dict(self) -> dict:
        return {"observation_id": self.observation_id, "supplier": self.supplier,
                "comparable_value": money_str(self.value), "observed_at": iso(self.observed_at),
                "match_confidence": format(self.match_confidence, "f"), "flags": list(self.flags),
                "smoothed_from": self.smoothed_from}


@dataclass(frozen=True)
class ExcludedOffer:
    observation_id: str
    supplier: str
    reasons: tuple[str, ...]
    observed_at: datetime
    observed_value: Decimal | None

    def to_dict(self) -> dict:
        return {"observation_id": self.observation_id, "supplier": self.supplier,
                "reasons": list(self.reasons),
                "reason_text": [EXCLUSION_LABELS.get(r, r) for r in self.reasons],
                "observed_at": iso(self.observed_at), "observed_value": money_str(self.observed_value)}


@dataclass(frozen=True)
class ComparableSet:
    basis: str
    eligible: tuple[EligibleOffer, ...]
    excluded: tuple[ExcludedOffer, ...]
    own_basis_addition: Decimal  # what is added to our item price to reach the basis
    warnings: tuple[str, ...] = ()
    last_valid_observation_at: datetime | None = None

    @property
    def values(self) -> list[Decimal]:
        return sorted(o.value for o in self.eligible)

    @property
    def lowest(self) -> Decimal | None:
        return self.values[0] if self.eligible else None

    @property
    def highest(self) -> Decimal | None:
        return self.values[-1] if self.eligible else None

    @property
    def median(self) -> Decimal | None:
        return q2(Decimal(median(self.values))) if self.eligible else None

    def reference(self, position: str) -> Decimal | None:
        return {"match_lowest": self.lowest, "match_median": self.median, "match_highest": self.highest}[position]

    def to_dict(self) -> dict:
        return {
            "basis": self.basis,
            "basis_description": (
                "Delivered totals: competitor item + delivery + mandatory charges vs. our item price + our "
                "delivery charge" if self.basis == BASIS_DELIVERED else "Item prices only, excluding delivery"
            ),
            "own_basis_addition": money_str(self.own_basis_addition),
            "eligible_count": len(self.eligible),
            "lowest": money_str(self.lowest), "median": money_str(self.median), "highest": money_str(self.highest),
            "eligible": [o.to_dict() for o in self.eligible],
            "excluded": [o.to_dict() for o in self.excluded],
            "warnings": list(self.warnings),
            "last_valid_observation_at": iso(self.last_valid_observation_at),
        }


def _basis_value(obs: CompetitorObservation, basis: str) -> Decimal | None:
    if basis == BASIS_ITEM:
        return obs.item_price
    if obs.comparable_total is not None:
        return obs.comparable_total
    if obs.charges_complete and obs.item_price is not None:
        return obs.item_price + (obs.delivery_charge or ZERO) + (obs.mandatory_charges or ZERO)
    return None


def build_comparable_set(
    observations: tuple[CompetitorObservation, ...],
    policy: CompetitorPolicy,
    *,
    evaluation_time: datetime,
    currency: str,
    own_condition: str,
    own_delivery_charge: Decimal,
    feeds: tuple[FeedStatus, ...] = (),
) -> ComparableSet:
    max_age = timedelta(hours=policy.max_observation_age_hours)
    allowed_conditions = set(policy.allowed_conditions)
    excluded: list[ExcludedOffer] = []
    warnings: list[str] = []
    last_valid: datetime | None = None

    def judge(obs: CompetitorObservation) -> tuple[Decimal | None, list[str], list[str]]:
        reasons: list[str] = []
        flags: list[str] = []
        value = _basis_value(obs, policy.basis)
        if obs.match_status in ("unresolved", "rejected"):
            reasons.append("unresolved_match")
        elif obs.match_confidence < policy.min_match_confidence:
            reasons.append("weak_match")
        if obs.variant_match == "different":
            reasons.append("different_variant")
        elif obs.variant_match != "exact":
            reasons.append("variant_unknown")
        if obs.condition not in allowed_conditions or (own_condition == "new" and obs.condition != "new"):
            reasons.append("condition_mismatch")
        if obs.currency != currency:
            reasons.append("currency_mismatch")
        if policy.require_in_stock and obs.availability != "in_stock":
            reasons.append("unavailable")
        if obs.membership_required and not policy.allow_membership_prices:
            reasons.append("membership_only")
        if obs.item_price is None or obs.item_price <= 0:
            reasons.append("missing_price")
        elif value is None or value <= 0:
            reasons.append("incomplete_mandatory_charges")
        if policy.basis == BASIS_ITEM and not obs.charges_complete:
            flags.append("mandatory_charges_incomplete")
        if evaluation_time - obs.observed_at > max_age:
            reasons.append("stale")
        if obs.retained_after_feed_failure:
            flags.append("retained_after_feed_failure")
        return (q2(value) if value is not None else None), reasons, flags

    # Never use information from after the decision time.
    visible = sorted((o for o in observations if o.observed_at <= evaluation_time),
                     key=lambda o: (o.observed_at, o.observation_id))
    # Only the newest observation of each supplier listing is judged; older ones
    # exist for smoothing and are not listed individually.
    by_listing: dict[tuple[str, str], list[CompetitorObservation]] = {}
    for obs in visible:
        by_listing.setdefault((obs.supplier, obs.listing_key or obs.observation_id), []).append(obs)

    passed: dict[str, list[EligibleOffer]] = {}
    for (supplier, _), series in sorted(by_listing.items()):
        latest = series[-1]
        value, reasons, flags = judge(latest)
        raw_value = latest.item_price if policy.basis == BASIS_ITEM else latest.comparable_total
        if reasons:
            excluded.append(ExcludedOffer(latest.observation_id, supplier, tuple(reasons), latest.observed_at, raw_value))
            if reasons == ["stale"] and (last_valid is None or latest.observed_at > last_valid):
                last_valid = latest.observed_at
            continue
        used = 1
        if policy.smoothing == "median_recent":
            window = timedelta(hours=policy.smoothing_window_hours)
            recent = []
            for older in series:
                v, r, _ = judge(older)
                if not r and evaluation_time - older.observed_at <= window:
                    recent.append(v)
            if len(recent) > 1:
                value, used = q2(Decimal(median(recent))), len(recent)
        if last_valid is None or latest.observed_at > last_valid:
            last_valid = latest.observed_at
        passed.setdefault(supplier, []).append(EligibleOffer(
            latest.observation_id, supplier, value, latest.observed_at, latest.match_confidence, tuple(flags), used))

    # One value per supplier: its lowest eligible listing.
    eligible = [min(offers, key=lambda o: (o.value, o.observation_id)) for _, offers in sorted(passed.items())]

    for feed in feeds:
        if feed.failing:
            warnings.append(
                f"Competitor feed '{feed.source}' is failing (last success "
                f"{iso(feed.last_success_at) or 'never'}); the last valid observations are retained with "
                "their original timestamps and are subject to the freshness limit."
            )
    if visible and not eligible and last_valid is not None:
        warnings.append(
            f"No competitor observation is fresh enough to use; the last valid observation is from {iso(last_valid)}."
        )

    return ComparableSet(
        basis=policy.basis,
        eligible=tuple(eligible),
        excluded=tuple(sorted(excluded, key=lambda e: (e.supplier, e.observed_at, e.observation_id))),
        own_basis_addition=own_delivery_charge if policy.basis == BASIS_DELIVERED else ZERO,
        warnings=tuple(warnings),
        last_valid_observation_at=last_valid,
    )


__all__ = ["ComparableSet", "EligibleOffer", "ExcludedOffer", "build_comparable_set", "EXCLUSION_LABELS", "CENT"]
