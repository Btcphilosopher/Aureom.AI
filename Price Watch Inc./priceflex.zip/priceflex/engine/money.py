"""Money, tax, fee and margin arithmetic.

Rules followed throughout:

* All money is :class:`decimal.Decimal`. Floats are rejected at the boundary.
* ``customer price`` is the price as displayed on the channel. Whether it
  includes output tax is configuration (:class:`TaxConfig`), never assumed.
* ``net revenue`` is the customer price excluding applicable output tax.
* Recoverable input tax is carried for information only and is *not* an
  economic cost. Non-recoverable input tax is part of cost of goods.
* Percentage transaction fees are charged on an explicit basis
  (:data:`FEE_BASES`), which matters when deriving a price floor.

Definitions::

    contribution = net revenue
                   - cost of goods
                   - variable fulfilment costs
                   - transaction fees
                   - expected returns / warranty cost
                   (+ supplier promotion funding, when an approved promotion records it)

    contribution margin = contribution / net revenue
    gross profit        = net revenue - cost of goods
    gross margin        = gross profit / net revenue
    markup              = gross profit / cost of goods
    operating profit    = contribution - allocated fixed overhead
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any

CENT = Decimal("0.01")
ZERO = Decimal("0")
ONE = Decimal("1")
RATIO_QUANT = Decimal("0.0001")

FEE_BASIS_GROSS_ITEM = "gross_item"
FEE_BASIS_NET_ITEM = "net_item"
FEE_BASIS_GROSS_ITEM_PLUS_DELIVERY = "gross_item_plus_delivery"
FEE_BASES = (FEE_BASIS_GROSS_ITEM, FEE_BASIS_NET_ITEM, FEE_BASIS_GROSS_ITEM_PLUS_DELIVERY)


class MoneyError(ValueError):
    """Raised for values that cannot be safely treated as money."""


def D(value: Any, *, allow_none: bool = False) -> Decimal | None:
    """Convert ``value`` to Decimal. Floats are refused to avoid binary drift."""
    if value is None or value == "":
        if allow_none:
            return None
        raise MoneyError("A numeric value is required")
    if isinstance(value, Decimal):
        result = value
    elif isinstance(value, bool):
        raise MoneyError("Booleans are not numeric values")
    elif isinstance(value, int):
        result = Decimal(value)
    elif isinstance(value, float):
        raise MoneyError("Floats are not accepted for money; pass a string or Decimal")
    else:
        try:
            result = Decimal(str(value).strip())
        except (InvalidOperation, ValueError) as exc:
            raise MoneyError(f"Not a decimal number: {value!r}") from exc
    if not result.is_finite():
        raise MoneyError(f"Not a finite number: {value!r}")
    return result


def q2(amount: Decimal, rounding: str = ROUND_HALF_UP) -> Decimal:
    """Quantise to the currency minor unit (two decimal places)."""
    return amount.quantize(CENT, rounding=rounding)


def ceil_cent(amount: Decimal) -> Decimal:
    return amount.quantize(CENT, rounding=ROUND_CEILING)


def floor_cent(amount: Decimal) -> Decimal:
    return amount.quantize(CENT, rounding=ROUND_FLOOR)


def ratio(numerator: Decimal, denominator: Decimal) -> Decimal | None:
    """A ratio rounded to four places, or None when the denominator is zero."""
    if denominator == 0:
        return None
    return (numerator / denominator).quantize(RATIO_QUANT, rounding=ROUND_HALF_UP)


def money_str(amount: Decimal | None) -> str | None:
    return None if amount is None else format(q2(amount), "f")


def dec_str(amount: Decimal | None) -> str | None:
    return None if amount is None else format(amount, "f")


# ---------------------------------------------------------------------------
# Tax
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TaxConfig:
    """Output-tax treatment for one product tax category in one jurisdiction."""

    rate: Decimal
    prices_include_tax: bool
    jurisdiction: str = ""
    category: str = ""
    source: str = ""

    def __post_init__(self) -> None:
        if self.rate < 0 or self.rate >= 1:
            raise MoneyError("Tax rate must be a fraction in [0, 1), e.g. 0.20")

    def net(self, customer_price: Decimal) -> Decimal:
        """Customer price excluding output tax, rounded to the minor unit."""
        if self.prices_include_tax:
            return q2(customer_price / (ONE + self.rate))
        return q2(customer_price)

    def gross(self, customer_price: Decimal) -> Decimal:
        """What the customer actually pays for the item, including tax."""
        if self.prices_include_tax:
            return q2(customer_price)
        return q2(customer_price * (ONE + self.rate))

    def to_dict(self) -> dict:
        return {
            "rate": dec_str(self.rate),
            "prices_include_tax": self.prices_include_tax,
            "jurisdiction": self.jurisdiction,
            "category": self.category,
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, data: dict | None) -> "TaxConfig | None":
        if not data:
            return None
        return cls(
            rate=D(data["rate"]),
            prices_include_tax=bool(data["prices_include_tax"]),
            jurisdiction=data.get("jurisdiction", ""),
            category=data.get("category", ""),
            source=data.get("source", ""),
        )


# ---------------------------------------------------------------------------
# Cost
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CostInputs:
    """Unit economics for one variant on one channel at one point in time.

    All amounts are per unit, in ``currency``, and exclude recoverable tax.
    """

    currency: str
    acquisition_cost: Decimal
    freight_landed: Decimal = ZERO
    packaging: Decimal = ZERO
    fulfilment: Decimal = ZERO
    merchant_funded_delivery: Decimal = ZERO
    fee_percent: Decimal = ZERO  # fraction, e.g. 0.029
    fee_fixed: Decimal = ZERO
    fee_basis: str = FEE_BASIS_GROSS_ITEM
    expected_return_rate: Decimal = ZERO  # probability a sold unit is returned
    cost_per_return: Decimal = ZERO  # handling + write-down per returned unit
    warranty_cost: Decimal = ZERO
    non_recoverable_input_tax: Decimal = ZERO  # economic cost
    recoverable_input_tax: Decimal = ZERO  # informational only, never a cost
    overhead_allocation: Decimal = ZERO  # fixed overhead per unit, for operating profit
    tax_basis: str = "net_of_recoverable_tax"
    cost_version_id: str = ""
    effective_from: str = ""
    source: str = ""

    def __post_init__(self) -> None:
        if self.fee_basis not in FEE_BASES:
            raise MoneyError(f"Unknown fee basis {self.fee_basis!r}; expected one of {FEE_BASES}")
        for name in (
            "acquisition_cost", "freight_landed", "packaging", "fulfilment",
            "merchant_funded_delivery", "fee_percent", "fee_fixed", "expected_return_rate",
            "cost_per_return", "warranty_cost", "non_recoverable_input_tax",
            "recoverable_input_tax", "overhead_allocation",
        ):
            if getattr(self, name) < 0:
                raise MoneyError(f"{name} cannot be negative")
        if self.fee_percent >= 1 or self.expected_return_rate > 1:
            raise MoneyError("fee_percent and expected_return_rate are fractions (0.029 = 2.9%)")

    @property
    def cost_of_goods(self) -> Decimal:
        return self.acquisition_cost + self.freight_landed + self.packaging + self.non_recoverable_input_tax

    @property
    def variable_fulfilment(self) -> Decimal:
        return self.fulfilment + self.merchant_funded_delivery

    @property
    def expected_returns_and_warranty(self) -> Decimal:
        return self.expected_return_rate * self.cost_per_return + self.warranty_cost

    _DECIMAL_FIELDS = (
        "acquisition_cost", "freight_landed", "packaging", "fulfilment", "merchant_funded_delivery",
        "fee_percent", "fee_fixed", "expected_return_rate", "cost_per_return", "warranty_cost",
        "non_recoverable_input_tax", "recoverable_input_tax", "overhead_allocation",
    )

    def to_dict(self) -> dict:
        data = {name: dec_str(getattr(self, name)) for name in self._DECIMAL_FIELDS}
        data.update(
            currency=self.currency, fee_basis=self.fee_basis, tax_basis=self.tax_basis,
            cost_version_id=self.cost_version_id, effective_from=self.effective_from, source=self.source,
        )
        return data

    @classmethod
    def from_dict(cls, data: dict | None) -> "CostInputs | None":
        if not data:
            return None
        kwargs: dict[str, Any] = {
            name: D(data.get(name, "0") if data.get(name) is not None else "0") for name in cls._DECIMAL_FIELDS
        }
        return cls(
            currency=data["currency"],
            fee_basis=data.get("fee_basis", FEE_BASIS_GROSS_ITEM),
            tax_basis=data.get("tax_basis", "net_of_recoverable_tax"),
            cost_version_id=str(data.get("cost_version_id", "")),
            effective_from=str(data.get("effective_from", "")),
            source=data.get("source", ""),
            **kwargs,
        )


# ---------------------------------------------------------------------------
# Margin breakdown
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MarginBreakdown:
    customer_price: Decimal
    output_tax: Decimal
    net_revenue: Decimal
    cost_of_goods: Decimal
    variable_fulfilment: Decimal
    transaction_fees: Decimal
    fee_basis_amount: Decimal
    expected_returns_and_warranty: Decimal
    promotion_funding: Decimal
    contribution: Decimal
    contribution_margin: Decimal | None
    gross_profit: Decimal
    gross_margin: Decimal | None
    markup: Decimal | None
    operating_profit: Decimal
    recoverable_input_tax_excluded: Decimal = ZERO

    def to_dict(self) -> dict:
        return {
            "customer_price": money_str(self.customer_price),
            "output_tax": money_str(self.output_tax),
            "net_revenue": money_str(self.net_revenue),
            "cost_of_goods": money_str(self.cost_of_goods),
            "variable_fulfilment": money_str(self.variable_fulfilment),
            "transaction_fees": money_str(self.transaction_fees),
            "fee_basis_amount": money_str(self.fee_basis_amount),
            "expected_returns_and_warranty": money_str(self.expected_returns_and_warranty),
            "promotion_funding": money_str(self.promotion_funding),
            "contribution": money_str(self.contribution),
            "contribution_margin": dec_str(self.contribution_margin),
            "gross_profit": money_str(self.gross_profit),
            "gross_margin": dec_str(self.gross_margin),
            "markup": dec_str(self.markup),
            "operating_profit": money_str(self.operating_profit),
            "recoverable_input_tax_excluded": money_str(self.recoverable_input_tax_excluded),
        }


def fee_basis_amount(
    customer_price: Decimal, cost: CostInputs, tax: TaxConfig, customer_delivery_charge: Decimal = ZERO
) -> Decimal:
    """The amount a percentage fee is actually charged on."""
    if cost.fee_basis == FEE_BASIS_NET_ITEM:
        return tax.net(customer_price)
    gross_item = tax.gross(customer_price)
    if cost.fee_basis == FEE_BASIS_GROSS_ITEM_PLUS_DELIVERY:
        return gross_item + tax.gross(customer_delivery_charge)
    return gross_item


def margin_breakdown(
    customer_price: Decimal,
    cost: CostInputs,
    tax: TaxConfig,
    *,
    customer_delivery_charge: Decimal = ZERO,
    promotion_funding: Decimal = ZERO,
) -> MarginBreakdown:
    """Full unit economics at ``customer_price``."""
    customer_price = q2(customer_price)
    net = tax.net(customer_price)
    gross = tax.gross(customer_price)
    basis = fee_basis_amount(customer_price, cost, tax, customer_delivery_charge)
    fees = q2(cost.fee_percent * basis) + cost.fee_fixed
    cogs = cost.cost_of_goods
    fulfil = cost.variable_fulfilment
    returns = q2(cost.expected_returns_and_warranty)
    contribution = net - cogs - fulfil - fees - returns + promotion_funding
    gross_profit = net - cogs
    return MarginBreakdown(
        customer_price=customer_price,
        output_tax=gross - net,
        net_revenue=net,
        cost_of_goods=cogs,
        variable_fulfilment=fulfil,
        transaction_fees=fees,
        fee_basis_amount=basis,
        expected_returns_and_warranty=returns,
        promotion_funding=promotion_funding,
        contribution=contribution,
        contribution_margin=ratio(contribution, net),
        gross_profit=gross_profit,
        gross_margin=ratio(gross_profit, net),
        markup=ratio(gross_profit, cogs),
        operating_profit=contribution - cost.overhead_allocation,
        recoverable_input_tax_excluded=cost.recoverable_input_tax,
    )


# ---------------------------------------------------------------------------
# Solving for a price
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PriceSolution:
    price: Decimal | None
    feasible: bool
    detail: str = ""


def _meets(
    price: Decimal, cost: CostInputs, tax: TaxConfig, delivery: Decimal, funding: Decimal,
    min_margin: Decimal | None, min_amount: Decimal | None,
) -> bool:
    b = margin_breakdown(price, cost, tax, customer_delivery_charge=delivery, promotion_funding=funding)
    if b.net_revenue <= 0:
        return False
    if min_amount is not None and b.contribution < min_amount:
        return False
    if min_margin is not None and b.contribution < min_margin * b.net_revenue:
        return False
    return True


def minimum_price_for(
    cost: CostInputs,
    tax: TaxConfig,
    *,
    min_margin: Decimal | None = None,
    min_amount: Decimal | None = None,
    customer_delivery_charge: Decimal = ZERO,
    promotion_funding: Decimal = ZERO,
) -> PriceSolution:
    """Lowest customer price meeting a contribution-margin and/or amount requirement.

    Derivation, with ``N`` = net revenue, ``t`` = tax rate, ``f`` = fee fraction::

        fee basis = beta * N (+ delivery when the basis includes it)
            beta = 1         for a net-item basis
            beta = 1 + t     for gross bases (fees charged on the tax-inclusive amount)
        contribution C(N) = a * N - K
            a = 1 - f * beta
            K = cost of goods + fulfilment + fixed fee + f * gross delivery
                + expected returns/warranty - promotion funding
        margin  C/N >= m   <=>  N >= K / (a - m)        (needs a > m)
        amount  C   >= A   <=>  N >= (K + A) / a        (needs a > 0)

    The analytic answer is then verified cent by cent against
    :func:`margin_breakdown`, because tax and fee rounding happen per unit.
    """
    t = tax.rate
    beta = ONE if cost.fee_basis == FEE_BASIS_NET_ITEM else ONE + t
    a = ONE - cost.fee_percent * beta
    fixed = (
        cost.cost_of_goods + cost.variable_fulfilment + cost.fee_fixed
        + cost.expected_returns_and_warranty - promotion_funding
    )
    if cost.fee_basis == FEE_BASIS_GROSS_ITEM_PLUS_DELIVERY:
        fixed += cost.fee_percent * tax.gross(customer_delivery_charge)

    if a <= 0:
        return PriceSolution(None, False, "Percentage fees consume all net revenue; no price is profitable.")
    required_net = ZERO
    if min_margin is not None:
        if a - min_margin <= 0:
            return PriceSolution(
                None, False,
                f"Required contribution margin {min_margin:.2%} is not attainable: percentage fees leave at "
                f"most {a:.2%} of net revenue before any other cost.",
            )
        required_net = max(required_net, fixed / (a - min_margin))
    if min_amount is not None:
        required_net = max(required_net, (fixed + min_amount) / a)
    if min_margin is None and min_amount is None:
        required_net = fixed / a  # break-even

    k = ONE + t if tax.prices_include_tax else ONE
    price = max(ceil_cent(required_net * k), CENT)
    eff_margin = min_margin
    eff_amount = min_amount if (min_amount is not None or min_margin is not None) else ZERO

    for _ in range(1000):  # rounding can leave the analytic answer a few cents short
        if _meets(price, cost, tax, customer_delivery_charge, promotion_funding, eff_margin, eff_amount):
            break
        price += CENT
    else:  # pragma: no cover - defensive
        return PriceSolution(None, False, "Could not verify a price meeting the requirement.")
    for _ in range(10):  # ...or a few cents high
        lower = price - CENT
        if lower <= 0 or not _meets(
            lower, cost, tax, customer_delivery_charge, promotion_funding, eff_margin, eff_amount
        ):
            break
        price = lower
    return PriceSolution(price, True)
