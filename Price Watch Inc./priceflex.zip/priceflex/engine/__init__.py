"""PRICEFLEX deterministic pricing engine.

This package has no dependency on Django. Every public function takes plain
dataclasses (or the JSON snapshot they serialise to) and returns plain
dataclasses, so the same inputs always yield the same decision.

``ALGORITHM_VERSION`` is stored on every recommendation. Bump it whenever the
arithmetic, constraint handling, precedence or rounding behaviour changes.
"""

ALGORITHM_VERSION = "priceflex-engine/1.0.0"

__all__ = ["ALGORITHM_VERSION"]
