"""Isolated simulation and backtesting workspace.

Why a simulator is needed
-------------------------
Historical sales record what sold at the prices that were actually shown.
They cannot tell us what would have sold at a price that was never shown, so
a backtest that "replays" history under a different pricing rule needs an
explicit model of demand. This module makes that model an explicit, labelled
input (:class:`DemandSimulatorConfig`) instead of hiding it.

Everything returned is SIMULATED and carries its assumptions.

No future-data leakage
----------------------
At each simulated decision time ``t`` an arm is given only: cost versions
effective at or before ``t``, competitor observations observed at or before
``t``, its own price path, and its own simulated sales strictly before ``t``.

Common random numbers
---------------------
All arms share the same uniform draw per day, so differences between arms
come from pricing rather than from sampling noise.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from decimal import Decimal
from statistics import pstdev

import numpy as np
from scipy.stats import poisson

from .comparables import build_comparable_set
from .evaluation import OUTCOME_CHANGE, evaluate, validate_price
from .money import CostInputs, margin_breakdown, money_str, ratio
from .policy import parse_policy
from .types import CompetitorObservation, EvaluationInput, InventoryInput, PricePoint, SalesPeriod

SIMULATION_LABEL = "SIMULATED - not a forecast of real sales and not a realised result"


@dataclass(frozen=True)
class DemandSimulatorConfig:
    """The explicit counterfactual demand assumption."""

    base_units_per_day: float
    reference_price: Decimal
    elasticity: float
    competitor_sensitivity: float = 0.0
    weekday_factors: tuple[float, ...] = (1.0,) * 7
    seed: int = 20240101

    def to_dict(self) -> dict:
        return {"base_units_per_day": self.base_units_per_day,
                "reference_price": format(self.reference_price, "f"), "elasticity": self.elasticity,
                "competitor_sensitivity": self.competitor_sensitivity,
                "weekday_factors": list(self.weekday_factors), "seed": self.seed}


class DemandSimulator:
    def __init__(self, config: DemandSimulatorConfig, days: int):
        self.config = config
        self._uniform = np.random.default_rng(config.seed).uniform(size=max(days, 1))

    def expected(self, price: Decimal, when: datetime, competitor_reference: Decimal | None,
                 own_basis_addition: Decimal) -> float:
        c = self.config
        lam = c.base_units_per_day * (float(price) / float(c.reference_price)) ** c.elasticity
        if competitor_reference is not None and c.competitor_sensitivity:
            lam *= (float(competitor_reference) / float(price + own_basis_addition)) ** c.competitor_sensitivity
        return max(lam * c.weekday_factors[when.weekday() % len(c.weekday_factors)], 0.0)

    def draw(self, lam: float, day_index: int) -> int:
        return int(poisson.ppf(self._uniform[day_index], lam)) if lam > 0 else 0


@dataclass(frozen=True)
class Arm:
    key: str
    label: str
    policy: dict | None  # None = hold the starting price
    use_demand_model: bool = False


@dataclass(frozen=True)
class SimulationScenario:
    start: datetime
    days: int
    base_input: EvaluationInput  # identifiers, tax, delivery charge, commitments, promotions, inventory template
    initial_price: Decimal
    initial_on_hand: int
    cost_timeline: tuple[tuple[datetime, CostInputs], ...]
    competitor_timeline: tuple[CompetitorObservation, ...]
    demand: DemandSimulatorConfig
    arms: tuple[Arm, ...]
    guard_policy: dict  # hard constraints used to count breaches for every arm
    replenishments: tuple[tuple[int, int], ...] = ()
    evaluation_interval_days: int = 1
    history_sales: tuple[SalesPeriod, ...] = ()
    history_prices: tuple[PricePoint, ...] = ()


def _cost_at(timeline: tuple[tuple[datetime, CostInputs], ...], when: datetime) -> CostInputs | None:
    live = [c for at, c in sorted(timeline, key=lambda x: x[0]) if at <= when]
    return live[-1] if live else None


def _run_arm(sc: SimulationScenario, arm: Arm, sim: DemandSimulator) -> dict:
    price = sc.initial_price
    stock = sc.initial_on_hand
    history = list(sc.history_prices) or [PricePoint(sc.start - timedelta(days=365), price)]
    sales = list(sc.history_sales)
    guard_cfg, _ = parse_policy(sc.guard_policy)
    template = sc.base_input.inventory
    revenue = contribution = Decimal("0")
    units = stockout_days = lost_units = changes = breaches = rejected = evaluations = 0
    daily: list[dict] = []
    prices: list[Decimal] = []
    decisions: list[dict] = []

    for d in range(sc.days):
        t = sc.start + timedelta(days=d)
        stock += sum(q for day, q in sc.replenishments if day == d)
        cost = _cost_at(sc.cost_timeline, t)
        visible = tuple(o for o in sc.competitor_timeline if o.observed_at <= t)
        inventory = InventoryInput(
            on_hand=stock, reserved=0, inbound=sum(q for day, q in sc.replenishments if day > d),
            replenishment_lead_time_days=template.replenishment_lead_time_days if template else None,
            oldest_stock_received_at=template.oldest_stock_received_at if template else None,
            clearance_date=template.clearance_date if template else None, as_of=t,
        )
        snapshot = replace(
            sc.base_input, evaluation_time=t, current_price=price, cost=cost, inventory=inventory,
            sales=tuple(sales), competitor_observations=visible, price_history=tuple(history),
            policy=arm.policy or sc.guard_policy,
            demand_model=sc.base_input.demand_model if arm.use_demand_model else None,
        )
        if arm.policy is not None and d % sc.evaluation_interval_days == 0:
            evaluations += 1
            result = evaluate(snapshot)
            if result.outcome == OUTCOME_CHANGE:
                decisions.append({"day": d, "from": money_str(price), "to": money_str(result.recommended_price),
                                  "strategy": result.selected_strategy})
                price = result.recommended_price
                history.append(PricePoint(t, price))
                changes += 1
            elif result.outcome in ("conflict", "blocked"):
                rejected += 1

        guard = validate_price(replace(snapshot, policy=sc.guard_policy), price) if cost else {"ok": False}
        if not guard["ok"]:
            breaches += 1

        reference = None
        if guard_cfg is not None:
            comp = build_comparable_set(
                visible, guard_cfg.competitor, evaluation_time=t, currency=sc.base_input.currency,
                own_condition=sc.base_input.condition, own_delivery_charge=sc.base_input.customer_delivery_charge,
            )
            reference, addition = comp.lowest, comp.own_basis_addition
        lam = sim.expected(price, t, reference, addition if reference is not None else Decimal("0"))
        demand = sim.draw(lam, d)
        sold = min(demand, max(stock, 0))
        out = demand > sold or stock <= 0
        stock -= sold
        if cost is not None and sc.base_input.tax is not None:
            b = margin_breakdown(price, cost, sc.base_input.tax,
                                 customer_delivery_charge=sc.base_input.customer_delivery_charge)
            revenue += b.net_revenue * sold
            contribution += b.contribution * sold
        units += sold
        lost_units += demand - sold
        stockout_days += 1 if out else 0
        sales.append(SalesPeriod(day=t.date(), units=sold, stockout=out, price=price))
        prices.append(price)
        daily.append({"day": d, "date": t.date().isoformat(), "price": money_str(price), "units": sold,
                      "stock_end": stock, "stockout": out})

    moves = [float((b - a) / a) for a, b in zip(prices, prices[1:]) if a]
    return {
        "key": arm.key, "label": arm.label,
        "revenue_net": money_str(revenue), "units_sold": units, "contribution": money_str(contribution),
        "contribution_margin": None if revenue == 0 else format(ratio(contribution, revenue), "f"),
        "ending_inventory": stock, "stockout_days": stockout_days, "unmet_demand_units": lost_units,
        "price_changes": changes, "price_volatility": round(pstdev(moves), 5) if len(moves) > 1 else 0.0,
        "average_price": money_str(sum(prices, Decimal("0")) / len(prices)) if prices else None,
        "final_price": money_str(price), "constraint_breach_days": breaches,
        "rejected_recommendations": rejected, "evaluations": evaluations,
        "decisions": decisions, "daily": daily,
    }


def run_simulation(sc: SimulationScenario) -> dict:
    sim = DemandSimulator(sc.demand, sc.days)
    arms = [_run_arm(sc, arm, sim) for arm in sc.arms]
    return {
        "label": SIMULATION_LABEL,
        "start": sc.start.isoformat(), "days": sc.days, "currency": sc.base_input.currency,
        "sku": sc.base_input.sku, "channel": sc.base_input.channel,
        "arms": arms,
        "demand_simulator": sc.demand.to_dict(),
        "assumptions": [
            "Demand is generated by the explicit simulator below, not taken from history: historical sales "
            "alone cannot show what would have sold at a price that was never offered.",
            f"Demand follows a constant-elasticity curve (elasticity {sc.demand.elasticity}) around "
            f"{sc.demand.base_units_per_day} units/day at {sc.base_input.currency} {sc.demand.reference_price}, "
            f"with Poisson noise (seed {sc.demand.seed}) shared across arms.",
            "Every recommended change is assumed to be approved and published instantly; conflicts and blocked "
            "evaluations leave the price unchanged and are counted as rejected recommendations.",
            "Each decision sees only costs and competitor observations dated at or before that decision.",
            "Constraint breaches count days on which the price in effect violated the listing's hard "
            "constraints (for example a fixed price left below a floor after a cost increase).",
            "Unsold demand during stockouts is lost, not deferred.",
        ],
    }
