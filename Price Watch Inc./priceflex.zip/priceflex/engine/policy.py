"""Pricing policy configuration: parsing, defaults and validation.

A policy is stored as a JSON document on an immutable ``PolicyVersion``. The
engine never reads a policy that fails :func:`validate_policy`; an invalid
policy blocks the recommendation instead of being silently repaired.
"""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from decimal import Decimal
from typing import Any

from .money import D, MoneyError, dec_str

STRATEGY_PROMOTION = "promotion"
STRATEGY_CLEARANCE = "clearance"
STRATEGY_DEMAND = "demand_led"
STRATEGY_COMPETITOR = "competitor_aware"
STRATEGY_INVENTORY = "inventory_led"
STRATEGY_MARGIN = "margin_led"
STRATEGIES = (
    STRATEGY_PROMOTION, STRATEGY_CLEARANCE, STRATEGY_DEMAND,
    STRATEGY_COMPETITOR, STRATEGY_INVENTORY, STRATEGY_MARGIN,
)

BASIS_ITEM = "item"
BASIS_DELIVERED = "delivered_total"
COMPARISON_BASES = (BASIS_ITEM, BASIS_DELIVERED)

POSITIONS = ("match_lowest", "match_median", "match_highest")
ON_NO_ELIGIBLE = ("skip", "hold", "block")
ENDING_FALLBACKS = ("keep_unrounded", "conflict")
STALE_BEHAVIOURS = ("warn", "block")


@dataclass(frozen=True)
class CompetitorPolicy:
    basis: str = BASIS_DELIVERED
    position: str = "match_lowest"
    offset_pct: Decimal = Decimal("0")  # -0.01 = 1% below the reference
    offset_amount: Decimal = Decimal("0")
    min_eligible_offers: int = 1
    max_observation_age_hours: int = 48
    min_match_confidence: Decimal = Decimal("0.80")
    allowed_conditions: tuple[str, ...] = ("new",)
    require_in_stock: bool = True
    allow_membership_prices: bool = False
    smoothing: str = "none"  # or "median_recent"
    smoothing_window_hours: int = 72
    on_no_eligible: str = "skip"


@dataclass(frozen=True)
class InventoryPolicy:
    enabled: bool = True
    sales_lookback_days: int = 28
    high_cover_days: Decimal = Decimal("90")
    low_cover_days: Decimal = Decimal("7")
    markdown_step_pct: Decimal = Decimal("0.05")
    markup_step_pct: Decimal = Decimal("0.03")
    max_stock_age_days: int | None = 180
    aged_markdown_step_pct: Decimal = Decimal("0.08")
    max_inventory_age_hours: int = 48
    on_stale_inventory: str = "warn"


@dataclass(frozen=True)
class ClearancePolicy:
    enabled: bool = False
    # (days before the clearance date, fraction off the standard retail price)
    schedule: tuple[tuple[int, Decimal], ...] = ()
    min_on_hand: int = 1
    # Explicit, recorded floors that replace the standard floors while clearing.
    min_contribution_margin: Decimal | None = None
    min_contribution_amount: Decimal | None = None


@dataclass(frozen=True)
class DemandPolicy:
    enabled: bool = False
    max_model_age_days: int = 30


@dataclass(frozen=True)
class AutomationPolicy:
    """Bounded automation. Off by default; manual approval is the baseline."""

    enabled: bool = False
    max_auto_change_pct: Decimal = Decimal("0.03")
    allowed_categories: tuple[str, ...] = ()
    allow_price_increases: bool = False


@dataclass(frozen=True)
class PolicyConfig:
    strategy_order: tuple[str, ...] = (STRATEGY_PROMOTION, STRATEGY_CLEARANCE, STRATEGY_MARGIN)
    # Hard floors and ceilings
    min_contribution_margin: Decimal | None = None
    min_contribution_amount: Decimal | None = None
    absolute_min_price: Decimal | None = None
    absolute_max_price: Decimal | None = None
    cap_at_standard_retail_price: bool = False
    # Movement and stability
    max_change_pct_per_evaluation: Decimal | None = None
    max_cumulative_change_pct: Decimal | None = None
    cumulative_window_days: int = 30
    cooldown_hours: int = 0
    min_meaningful_change_pct: Decimal = Decimal("0")
    min_meaningful_change_amount: Decimal = Decimal("0")
    hysteresis_pct: Decimal = Decimal("0")
    promotion_exempt_from_movement_limits: bool = True
    # Price endings
    price_endings: tuple[Decimal, ...] = ()
    ending_fallback: str = "keep_unrounded"
    # Strategy parameters
    target_contribution_margin: Decimal | None = None
    competitor: CompetitorPolicy = field(default_factory=CompetitorPolicy)
    inventory: InventoryPolicy = field(default_factory=InventoryPolicy)
    clearance: ClearancePolicy = field(default_factory=ClearancePolicy)
    demand: DemandPolicy = field(default_factory=DemandPolicy)
    automation: AutomationPolicy = field(default_factory=AutomationPolicy)
    # Data quality
    max_cost_age_days: int | None = None
    on_stockout: str = "hold"
    recommendation_ttl_hours: int = 24


class PolicyValidationError(ValueError):
    def __init__(self, errors: list[str]):
        super().__init__("; ".join(errors))
        self.errors = errors


def _dec(data: dict, key: str, errors: list[str], *, default: Any = None, lo: str | None = None,
         hi: str | None = None, path: str = "") -> Decimal | None:
    raw = data.get(key, default)
    if raw is None:
        return None
    try:
        value = D(raw)
    except MoneyError as exc:
        errors.append(f"{path}{key}: {exc}")
        return None
    if lo is not None and value < Decimal(lo):
        errors.append(f"{path}{key}: must be >= {lo}")
    if hi is not None and value > Decimal(hi):
        errors.append(f"{path}{key}: must be <= {hi}")
    return value


def _int(data: dict, key: str, errors: list[str], *, default: Any, lo: int = 0, path: str = "",
         nullable: bool = False) -> int | None:
    raw = data.get(key, default)
    if raw is None and nullable:
        return None
    if isinstance(raw, bool) or not isinstance(raw, int):
        errors.append(f"{path}{key}: must be an integer")
        return default if isinstance(default, int) else None
    if raw < lo:
        errors.append(f"{path}{key}: must be >= {lo}")
    return raw


def _choice(data: dict, key: str, errors: list[str], choices: tuple[str, ...], default: str, path: str = "") -> str:
    raw = data.get(key, default)
    if raw not in choices:
        errors.append(f"{path}{key}: must be one of {', '.join(choices)}")
        return default
    return raw


def _bool(data: dict, key: str, errors: list[str], default: bool, path: str = "") -> bool:
    raw = data.get(key, default)
    if not isinstance(raw, bool):
        errors.append(f"{path}{key}: must be true or false")
        return default
    return raw


_TOP_KEYS = {
    "strategy_order", "min_contribution_margin", "min_contribution_amount", "absolute_min_price",
    "absolute_max_price", "cap_at_standard_retail_price", "max_change_pct_per_evaluation",
    "max_cumulative_change_pct", "cumulative_window_days", "cooldown_hours", "min_meaningful_change_pct",
    "min_meaningful_change_amount", "hysteresis_pct", "promotion_exempt_from_movement_limits",
    "price_endings", "ending_fallback", "target_contribution_margin", "competitor", "inventory",
    "clearance", "demand", "automation", "max_cost_age_days", "on_stockout", "recommendation_ttl_hours",
}


_SECTION_KEYS = {
    "competitor": {f.name for f in fields(CompetitorPolicy)},
    "inventory": {f.name for f in fields(InventoryPolicy)},
    "clearance": {f.name for f in fields(ClearancePolicy)},
    "demand": {f.name for f in fields(DemandPolicy)},
    "automation": {f.name for f in fields(AutomationPolicy)},
}


def parse_policy(data: Any) -> tuple[PolicyConfig | None, list[str]]:
    """Parse and validate a policy document. Returns ``(config, errors)``."""
    errors: list[str] = []
    if not isinstance(data, dict):
        return None, ["Policy configuration must be a JSON object"]
    unknown = sorted(set(data) - _TOP_KEYS)
    if unknown:
        errors.append(f"Unknown policy keys: {', '.join(unknown)}")

    for section, allowed in _SECTION_KEYS.items():
        raw_section = data.get(section)
        if isinstance(raw_section, dict):
            stray = sorted(set(raw_section) - allowed)
            if stray:
                errors.append(f"{section}: unknown keys {', '.join(stray)}")

    order = data.get("strategy_order", list(PolicyConfig.strategy_order))
    if not isinstance(order, list) or not order:
        errors.append("strategy_order: must be a non-empty list")
        order = []
    else:
        bad = [s for s in order if s not in STRATEGIES]
        if bad:
            errors.append(f"strategy_order: unknown strategies {bad}; expected any of {list(STRATEGIES)}")
        if len(set(order)) != len(order):
            errors.append("strategy_order: a strategy may appear only once")

    min_margin = _dec(data, "min_contribution_margin", errors, lo="-1", hi="0.95")
    min_amount = _dec(data, "min_contribution_amount", errors)
    abs_min = _dec(data, "absolute_min_price", errors, lo="0")
    abs_max = _dec(data, "absolute_max_price", errors, lo="0")
    if abs_min is not None and abs_max is not None and abs_min > abs_max:
        errors.append("absolute_min_price cannot exceed absolute_max_price")
    if min_margin is None and min_amount is None:
        errors.append(
            "A policy must define min_contribution_margin and/or min_contribution_amount so that a cost "
            "floor always exists"
        )
    target = _dec(data, "target_contribution_margin", errors, lo="0", hi="0.95")
    if target is not None and min_margin is not None and target < min_margin:
        errors.append("target_contribution_margin cannot be below min_contribution_margin")
    if STRATEGY_MARGIN in order and target is None:
        errors.append("target_contribution_margin is required when margin_led is in strategy_order")

    endings_raw = data.get("price_endings", [])
    endings: list[Decimal] = []
    if not isinstance(endings_raw, list):
        errors.append("price_endings: must be a list of fractional endings such as ['0.99', '0.49']")
    else:
        for item in endings_raw:
            try:
                value = D(item)
            except MoneyError as exc:
                errors.append(f"price_endings: {exc}")
                continue
            if not (Decimal("0") <= value < Decimal("1")) or value != value.quantize(Decimal("0.01")):
                errors.append(f"price_endings: {item!r} must be between 0.00 and 0.99 with two decimals")
            else:
                endings.append(value)

    comp_raw = data.get("competitor", {}) or {}
    comp = CompetitorPolicy()
    if not isinstance(comp_raw, dict):
        errors.append("competitor: must be an object")
    else:
        p = "competitor."
        conditions = comp_raw.get("allowed_conditions", ["new"])
        if not isinstance(conditions, list) or not conditions or not all(isinstance(c, str) for c in conditions):
            errors.append(f"{p}allowed_conditions: must be a non-empty list of strings")
            conditions = ["new"]
        comp = CompetitorPolicy(
            basis=_choice(comp_raw, "basis", errors, COMPARISON_BASES, BASIS_DELIVERED, p),
            position=_choice(comp_raw, "position", errors, POSITIONS, "match_lowest", p),
            offset_pct=_dec(comp_raw, "offset_pct", errors, default="0", lo="-0.5", hi="0.5", path=p) or Decimal("0"),
            offset_amount=_dec(comp_raw, "offset_amount", errors, default="0", path=p) or Decimal("0"),
            min_eligible_offers=_int(comp_raw, "min_eligible_offers", errors, default=1, lo=1, path=p) or 1,
            max_observation_age_hours=_int(comp_raw, "max_observation_age_hours", errors, default=48, lo=1, path=p) or 48,
            min_match_confidence=_dec(comp_raw, "min_match_confidence", errors, default="0.80", lo="0", hi="1", path=p)
            or Decimal("0"),
            allowed_conditions=tuple(conditions),
            require_in_stock=_bool(comp_raw, "require_in_stock", errors, True, p),
            allow_membership_prices=_bool(comp_raw, "allow_membership_prices", errors, False, p),
            smoothing=_choice(comp_raw, "smoothing", errors, ("none", "median_recent"), "none", p),
            smoothing_window_hours=_int(comp_raw, "smoothing_window_hours", errors, default=72, lo=1, path=p) or 72,
            on_no_eligible=_choice(comp_raw, "on_no_eligible", errors, ON_NO_ELIGIBLE, "skip", p),
        )

    inv_raw = data.get("inventory", {}) or {}
    inv = InventoryPolicy()
    if not isinstance(inv_raw, dict):
        errors.append("inventory: must be an object")
    else:
        p = "inventory."
        inv = InventoryPolicy(
            enabled=_bool(inv_raw, "enabled", errors, True, p),
            sales_lookback_days=_int(inv_raw, "sales_lookback_days", errors, default=28, lo=1, path=p) or 28,
            high_cover_days=_dec(inv_raw, "high_cover_days", errors, default="90", lo="0", path=p) or Decimal("90"),
            low_cover_days=_dec(inv_raw, "low_cover_days", errors, default="7", lo="0", path=p) or Decimal("0"),
            markdown_step_pct=_dec(inv_raw, "markdown_step_pct", errors, default="0.05", lo="0", hi="0.5", path=p)
            or Decimal("0"),
            markup_step_pct=_dec(inv_raw, "markup_step_pct", errors, default="0.03", lo="0", hi="0.5", path=p)
            or Decimal("0"),
            max_stock_age_days=_int(inv_raw, "max_stock_age_days", errors, default=180, lo=1, path=p, nullable=True),
            aged_markdown_step_pct=_dec(inv_raw, "aged_markdown_step_pct", errors, default="0.08", lo="0", hi="0.5", path=p)
            or Decimal("0"),
            max_inventory_age_hours=_int(inv_raw, "max_inventory_age_hours", errors, default=48, lo=1, path=p) or 48,
            on_stale_inventory=_choice(inv_raw, "on_stale_inventory", errors, STALE_BEHAVIOURS, "warn", p),
        )
        if inv.low_cover_days > inv.high_cover_days:
            errors.append("inventory.low_cover_days cannot exceed inventory.high_cover_days")

    clr_raw = data.get("clearance", {}) or {}
    clr = ClearancePolicy()
    if not isinstance(clr_raw, dict):
        errors.append("clearance: must be an object")
    else:
        p = "clearance."
        schedule: list[tuple[int, Decimal]] = []
        raw_schedule = clr_raw.get("schedule", [])
        if not isinstance(raw_schedule, list):
            errors.append(f"{p}schedule: must be a list of {{days_before, markdown_pct}} objects")
        else:
            for i, tier in enumerate(raw_schedule):
                if not isinstance(tier, dict) or "days_before" not in tier or "markdown_pct" not in tier:
                    errors.append(f"{p}schedule[{i}]: needs days_before and markdown_pct")
                    continue
                days = tier["days_before"]
                if isinstance(days, bool) or not isinstance(days, int) or days < 0:
                    errors.append(f"{p}schedule[{i}].days_before: must be a non-negative integer")
                    continue
                pct = _dec(tier, "markdown_pct", errors, lo="0", hi="0.9", path=f"{p}schedule[{i}].")
                if pct is not None:
                    schedule.append((days, pct))
        clr = ClearancePolicy(
            enabled=_bool(clr_raw, "enabled", errors, False, p),
            schedule=tuple(sorted(schedule)),
            min_on_hand=_int(clr_raw, "min_on_hand", errors, default=1, lo=0, path=p) or 0,
            min_contribution_margin=_dec(clr_raw, "min_contribution_margin", errors, lo="-1", hi="0.95", path=p),
            min_contribution_amount=_dec(clr_raw, "min_contribution_amount", errors, path=p),
        )
        if clr.enabled and not clr.schedule:
            errors.append("clearance.schedule is required when clearance is enabled")
        if STRATEGY_CLEARANCE in order and not clr.enabled:
            errors.append("clearance.enabled must be true when clearance is in strategy_order")

    dem_raw = data.get("demand", {}) or {}
    dem = DemandPolicy()
    if not isinstance(dem_raw, dict):
        errors.append("demand: must be an object")
    else:
        dem = DemandPolicy(
            enabled=_bool(dem_raw, "enabled", errors, False, "demand."),
            max_model_age_days=_int(dem_raw, "max_model_age_days", errors, default=30, lo=1, path="demand.") or 30,
        )
        if STRATEGY_DEMAND in order and not dem.enabled:
            errors.append("demand.enabled must be true when demand_led is in strategy_order")

    auto_raw = data.get("automation", {}) or {}
    auto = AutomationPolicy()
    if not isinstance(auto_raw, dict):
        errors.append("automation: must be an object")
    else:
        cats = auto_raw.get("allowed_categories", [])
        if not isinstance(cats, list) or not all(isinstance(c, str) for c in cats):
            errors.append("automation.allowed_categories: must be a list of category codes")
            cats = []
        auto = AutomationPolicy(
            enabled=_bool(auto_raw, "enabled", errors, False, "automation."),
            max_auto_change_pct=_dec(auto_raw, "max_auto_change_pct", errors, default="0.03", lo="0", hi="0.10",
                                     path="automation.") or Decimal("0"),
            allowed_categories=tuple(cats),
            allow_price_increases=_bool(auto_raw, "allow_price_increases", errors, False, "automation."),
        )
        if auto.enabled and not auto.allowed_categories:
            errors.append("automation.allowed_categories must name the product groups automation may act on")

    config = PolicyConfig(
        strategy_order=tuple(order),
        min_contribution_margin=min_margin,
        min_contribution_amount=min_amount,
        absolute_min_price=abs_min,
        absolute_max_price=abs_max,
        cap_at_standard_retail_price=_bool(data, "cap_at_standard_retail_price", errors, False),
        max_change_pct_per_evaluation=_dec(data, "max_change_pct_per_evaluation", errors, lo="0.001", hi="1"),
        max_cumulative_change_pct=_dec(data, "max_cumulative_change_pct", errors, lo="0.001", hi="1"),
        cumulative_window_days=_int(data, "cumulative_window_days", errors, default=30, lo=1) or 30,
        cooldown_hours=_int(data, "cooldown_hours", errors, default=0, lo=0) or 0,
        min_meaningful_change_pct=_dec(data, "min_meaningful_change_pct", errors, default="0", lo="0", hi="0.5")
        or Decimal("0"),
        min_meaningful_change_amount=_dec(data, "min_meaningful_change_amount", errors, default="0", lo="0")
        or Decimal("0"),
        hysteresis_pct=_dec(data, "hysteresis_pct", errors, default="0", lo="0", hi="0.5") or Decimal("0"),
        promotion_exempt_from_movement_limits=_bool(data, "promotion_exempt_from_movement_limits", errors, True),
        price_endings=tuple(sorted(set(endings))),
        ending_fallback=_choice(data, "ending_fallback", errors, ENDING_FALLBACKS, "keep_unrounded"),
        target_contribution_margin=target,
        competitor=comp,
        inventory=inv,
        clearance=clr,
        demand=dem,
        automation=auto,
        max_cost_age_days=_int(data, "max_cost_age_days", errors, default=None, lo=1, nullable=True),
        on_stockout=_choice(data, "on_stockout", errors, ("hold", "ignore"), "hold"),
        recommendation_ttl_hours=_int(data, "recommendation_ttl_hours", errors, default=24, lo=1) or 24,
    )
    return (None, errors) if errors else (config, [])


def validate_policy(data: Any) -> list[str]:
    return parse_policy(data)[1]


def load_policy(data: Any) -> PolicyConfig:
    config, errors = parse_policy(data)
    if errors or config is None:
        raise PolicyValidationError(errors)
    return config


__all__ = [
    "PolicyConfig", "CompetitorPolicy", "InventoryPolicy", "ClearancePolicy", "DemandPolicy",
    "AutomationPolicy", "PolicyValidationError", "parse_policy", "validate_policy", "load_policy",
    "STRATEGIES", "dec_str",
]
