"""Optional demand estimation.

This module is *not* required for a recommendation. The rules baseline is
the default; a demand estimate may only drive a price once it is validated:
enough in-stock data, real price variation, an uncertainty interval that
excludes zero, and out-of-sample error better than a naive baseline.

What the estimate is, and is not
--------------------------------
The fitted coefficient describes how sales moved with price in *observed*
history. That is an observational association. Competitor moves, promotions,
availability and seasonality change at the same time as prices and can
confound it, so it is not a causal price elasticity and is labelled
accordingly everywhere it is shown.

Stockouts
---------
Days with no stock (or where everything available sold) are censored: the
sales count is a lower bound on demand, not a measurement of it. They are
excluded from the fit, never read as zero demand.

Model
-----
Poisson regression with a log link, fitted by iteratively re-weighted least
squares::

    E[units per day] = exp(b0 + b1*ln(price/p_ref) + b2*promotion + b3*weekend) * exposure

``b1`` is the elasticity. Standard errors are scaled by the Pearson
dispersion (quasi-Poisson) so that over-dispersed sales widen the interval.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal

import numpy as np

from .money import ZERO, CostInputs, TaxConfig, margin_breakdown, q2
from .types import DemandModelInput


@dataclass(frozen=True)
class DemandObservation:
    day: date
    price: Decimal | None
    units: int
    stockout: bool = False
    promotion: bool = False
    available_units: int | None = None
    traffic: float | None = None
    returns: int = 0
    cancellations: int = 0


@dataclass
class DemandEstimate:
    status: str  # "validated" | "insufficient_evidence"
    reasons: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)
    elasticity: float | None = None
    ci_low: float | None = None
    ci_high: float | None = None
    std_error: float | None = None
    dispersion: float | None = None
    reference_price: Decimal | None = None
    reference_units_per_day: float | None = None
    n_days_used: int = 0
    n_days_excluded_stockout: int = 0
    n_distinct_prices: int = 0
    holdout_days: int = 0
    holdout_deviance_model: float | None = None
    holdout_deviance_baseline: float | None = None
    holdout_improvement: float | None = None
    coefficients: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        def r(v, n=4):
            return None if v is None else round(float(v), n)
        return {
            "status": self.status, "reasons": self.reasons, "caveats": self.caveats,
            "elasticity": r(self.elasticity), "ci_low": r(self.ci_low), "ci_high": r(self.ci_high),
            "std_error": r(self.std_error), "dispersion": r(self.dispersion),
            "reference_price": None if self.reference_price is None else format(self.reference_price, "f"),
            "reference_units_per_day": r(self.reference_units_per_day),
            "n_days_used": self.n_days_used, "n_days_excluded_stockout": self.n_days_excluded_stockout,
            "n_distinct_prices": self.n_distinct_prices, "holdout_days": self.holdout_days,
            "holdout_deviance_model": r(self.holdout_deviance_model),
            "holdout_deviance_baseline": r(self.holdout_deviance_baseline),
            "holdout_improvement": r(self.holdout_improvement),
            "coefficients": {k: r(v) for k, v in self.coefficients.items()},
        }

    def to_model_input(self, model_id: str, fitted_at: datetime) -> DemandModelInput:
        def d(v, q="0.0001"):
            return None if v is None else Decimal(str(round(float(v), 6))).quantize(Decimal(q))
        return DemandModelInput(
            model_id=model_id, status=self.status, elasticity=d(self.elasticity), ci_low=d(self.ci_low),
            ci_high=d(self.ci_high), reference_price=self.reference_price,
            reference_units_per_day=d(self.reference_units_per_day), fitted_at=fitted_at,
            reasons=tuple(self.reasons),
        )


CAVEAT = ("Observational association between price and sales in recorded history - not a causal price "
          "elasticity. Competitor changes, promotions, availability and seasonality can confound it.")


def _design(obs: list[DemandObservation], ref_price: float, use_promo: bool, use_weekend: bool):
    cols = [np.ones(len(obs)), np.array([math.log(float(o.price) / ref_price) for o in obs])]
    names = ["intercept", "ln_price"]
    if use_promo:
        cols.append(np.array([1.0 if o.promotion else 0.0 for o in obs]))
        names.append("promotion")
    if use_weekend:
        cols.append(np.array([1.0 if o.day.weekday() >= 5 else 0.0 for o in obs]))
        names.append("weekend")
    return np.column_stack(cols), names


def _fit_poisson(X: np.ndarray, y: np.ndarray, offset: np.ndarray):
    """IRLS for a log-link Poisson GLM. Returns (beta, covariance, dispersion) or None."""
    n, p = X.shape
    beta = np.zeros(p)
    beta[0] = math.log(max(y.mean(), 1e-6)) - float(offset.mean())
    for _ in range(100):
        eta = np.clip(X @ beta + offset, -30, 30)
        mu = np.exp(eta)
        z = eta - offset + (y - mu) / mu
        XtW = X.T * mu
        try:
            new = np.linalg.solve(XtW @ X + 1e-9 * np.eye(p), XtW @ z)
        except np.linalg.LinAlgError:
            return None
        if not np.all(np.isfinite(new)):
            return None
        done = np.max(np.abs(new - beta)) < 1e-9
        beta = new
        if done:
            break
    mu = np.exp(np.clip(X @ beta + offset, -30, 30))
    try:
        cov = np.linalg.inv((X.T * mu) @ X + 1e-9 * np.eye(p))
    except np.linalg.LinAlgError:
        return None
    dof = max(n - p, 1)
    dispersion = max(float(np.sum((y - mu) ** 2 / mu) / dof), 1.0)
    return beta, cov * dispersion, dispersion


def _deviance(y: np.ndarray, mu: np.ndarray) -> float:
    mu = np.maximum(mu, 1e-9)
    with np.errstate(divide="ignore", invalid="ignore"):
        term = np.where(y > 0, y * np.log(y / mu), 0.0)
    return float(2.0 * np.sum(term - (y - mu)) / len(y))


def estimate_demand(
    observations: list[DemandObservation],
    *,
    min_days: int = 42,
    min_distinct_prices: int = 3,
    min_price_range_pct: float = 0.05,
    holdout_fraction: float = 0.25,
    min_holdout_improvement: float = 0.02,
    max_ci_width: float = 3.0,
) -> DemandEstimate:
    est = DemandEstimate(status="insufficient_evidence", caveats=[CAVEAT])
    ordered = sorted(observations, key=lambda o: o.day)
    usable: list[DemandObservation] = []
    for o in ordered:
        censored = o.stockout or (o.available_units is not None and o.available_units <= o.units)
        if censored or o.price is None or o.price <= 0:
            est.n_days_excluded_stockout += 1 if censored else 0
            continue
        usable.append(o)
    est.n_days_used = len(usable)
    prices = sorted({o.price for o in usable})
    est.n_distinct_prices = len(prices)
    if est.n_days_excluded_stockout:
        est.caveats.append(f"{est.n_days_excluded_stockout} stockout/sold-out day(s) were excluded as censored "
                           "demand; they are not read as zero demand.")
    if len(usable) < min_days:
        est.reasons.append(f"Only {len(usable)} usable in-stock days; at least {min_days} are required.")
    if len(prices) < min_distinct_prices:
        est.reasons.append(f"Only {len(prices)} distinct price(s) were exposed; at least {min_distinct_prices} "
                           "are required to relate sales to price.")
    elif float(prices[-1] - prices[0]) / float(prices[0]) < min_price_range_pct:
        est.reasons.append(f"Exposed prices span less than {min_price_range_pct:.0%}; too little variation.")
    if est.reasons:
        return est

    ref_price = float(np.median([float(o.price) for o in usable]))
    est.reference_price = q2(Decimal(str(ref_price)))
    promo_flags = {o.promotion for o in usable}
    use_promo = len(promo_flags) == 2
    use_weekend = (usable[-1].day - usable[0].day).days >= 28
    have_traffic = all(o.traffic is not None and o.traffic > 0 for o in usable)
    y = np.array([float(max(o.units - o.cancellations, 0)) for o in usable])
    offset = np.array([math.log(o.traffic) for o in usable]) if have_traffic else np.zeros(len(usable))
    if have_traffic:
        est.caveats.append("Traffic was available for every day and is used as exposure.")
    if y.sum() <= 0:
        est.reasons.append("No units were sold on any usable day.")
        return est

    # -- out-of-sample check on the most recent data ---------------------------
    n_test = max(int(round(len(usable) * holdout_fraction)), 7)
    train, test = usable[:-n_test], usable[-n_test:]
    est.holdout_days = len(test)
    if len({o.price for o in train}) < 2:
        est.reasons.append("The training period contains a single price, so the model cannot be tested out of sample.")
        return est
    use_promo_train = use_promo and len({o.promotion for o in train}) == 2
    Xtr, _ = _design(train, ref_price, use_promo_train, use_weekend)
    Xte, _ = _design(test, ref_price, use_promo_train, use_weekend)
    ytr, yte = y[:-n_test], y[-n_test:]
    otr, ote = offset[:-n_test], offset[-n_test:]
    fit_train = _fit_poisson(Xtr, ytr, otr)
    if fit_train is None or ytr.sum() <= 0:
        est.reasons.append("The model could not be fitted on the training period.")
        return est
    mu_model = np.exp(np.clip(Xte @ fit_train[0] + ote, -30, 30))
    base_rate = ytr.sum() / np.exp(otr).sum()
    mu_base = base_rate * np.exp(ote)
    est.holdout_deviance_model = _deviance(yte, mu_model)
    est.holdout_deviance_baseline = _deviance(yte, mu_base)
    if est.holdout_deviance_baseline > 0:
        est.holdout_improvement = 1.0 - est.holdout_deviance_model / est.holdout_deviance_baseline

    # -- final fit on all usable data ------------------------------------------
    X, names = _design(usable, ref_price, use_promo, use_weekend)
    fit = _fit_poisson(X, y, offset)
    if fit is None:
        est.reasons.append("The model did not converge.")
        return est
    beta, cov, dispersion = fit
    se = float(math.sqrt(max(cov[1, 1], 0.0)))
    est.elasticity, est.std_error, est.dispersion = float(beta[1]), se, dispersion
    est.ci_low, est.ci_high = est.elasticity - 1.96 * se, est.elasticity + 1.96 * se
    est.coefficients = dict(zip(names, (float(b) for b in beta)))
    est.reference_units_per_day = float(math.exp(beta[0] + float(offset.mean())))

    if use_promo:
        lp = X[:, 1]
        pr = X[:, names.index("promotion")]
        if lp.std() > 0 and pr.std() > 0 and abs(float(np.corrcoef(lp, pr)[0, 1])) > 0.6:
            est.caveats.append("Price changes largely coincide with promotions, so their effects cannot be "
                               "separated reliably.")
    if est.ci_high >= 0:
        est.reasons.append(f"The 95% interval for the price coefficient ({est.ci_low:.2f} to {est.ci_high:.2f}) "
                           "includes zero; a price effect is not distinguishable from noise.")
    if est.ci_high - est.ci_low > max_ci_width:
        est.reasons.append(f"The 95% interval is {est.ci_high - est.ci_low:.2f} wide, above the limit of "
                           f"{max_ci_width:.2f}; the estimate is too uncertain to act on.")
    if est.holdout_improvement is None or est.holdout_improvement < min_holdout_improvement:
        shown = "n/a" if est.holdout_improvement is None else f"{est.holdout_improvement:.1%}"
        est.reasons.append(f"Out-of-sample deviance improved on the constant-rate baseline by {shown}; at least "
                           f"{min_holdout_improvement:.0%} is required.")
    if not est.reasons:
        est.status = "validated"
    return est


def expected_units(model: DemandModelInput, price: Decimal, elasticity: Decimal | None = None) -> float:
    e = float(elasticity if elasticity is not None else model.elasticity)
    return float(model.reference_units_per_day) * (float(price) / float(model.reference_price)) ** e


def optimal_price(
    model: DemandModelInput, cost: CostInputs, tax: TaxConfig, lower: Decimal, upper: Decimal,
    *, customer_delivery_charge: Decimal = ZERO,
) -> dict:
    """Price in ``[lower, upper]`` with the highest expected daily contribution.

    A bounded scalar optimisation (SciPy) finds the neighbourhood; the answer
    is then settled on whole cents using exact Decimal unit economics.
    """
    from scipy.optimize import minimize_scalar

    def daily(price: Decimal) -> float:
        b = margin_breakdown(price, cost, tax, customer_delivery_charge=customer_delivery_charge)
        return float(b.contribution) * expected_units(model, price)

    lo, hi = float(lower), float(upper)
    if hi - lo < 0.01:
        best = lower
    else:
        res = minimize_scalar(lambda p: -daily(q2(Decimal(str(round(p, 4))))), bounds=(lo, hi), method="bounded",
                              options={"xatol": 0.005})
        centre = q2(Decimal(str(round(float(res.x), 4))))
        cents = [centre + Decimal(i) / 100 for i in range(-5, 6)] + [lower, upper]
        candidates = sorted({min(max(c, lower), upper) for c in cents})
        best = max(candidates, key=lambda c: (round(daily(c), 6), -c))
    b = margin_breakdown(best, cost, tax, customer_delivery_charge=customer_delivery_charge)
    units = expected_units(model, best)
    bounds = sorted((expected_units(model, best, model.ci_low), expected_units(model, best, model.ci_high)))
    return {"price": best, "evidence": {
        "expected_units_per_day": round(units, 3),
        "expected_units_per_day_low": round(bounds[0], 3),
        "expected_units_per_day_high": round(bounds[1], 3),
        "expected_daily_contribution": format(q2(b.contribution * Decimal(str(round(units, 6)))), "f"),
    }}
