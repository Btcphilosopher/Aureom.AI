"""Plain input types for one pricing evaluation.

An :class:`EvaluationInput` round-trips through ``to_dict``/``from_dict``. The
dictionary form is what the application stores as an *input snapshot*, so a
stored decision can be replayed exactly with :func:`engine.evaluation.evaluate`.

Deliberately absent: anything describing an individual customer. Pricing
inputs are product, channel, region and inventory conditions only.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from typing import Any

from .money import ZERO, CostInputs, D, TaxConfig, dec_str, money_str


def parse_dt(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError(f"Timezone-aware datetime required, got {value!r}")
    return dt


def iso(value: datetime | date | None) -> str | None:
    return None if value is None else value.isoformat()


def parse_date(value: Any) -> date | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value)[:10])


@dataclass(frozen=True)
class InventoryInput:
    on_hand: int
    reserved: int = 0
    inbound: int = 0
    replenishment_lead_time_days: int | None = None
    oldest_stock_received_at: datetime | None = None
    clearance_date: date | None = None
    as_of: datetime | None = None
    locations: tuple[dict, ...] = ()

    @property
    def available(self) -> int:
        return self.on_hand - self.reserved

    def to_dict(self) -> dict:
        return {
            "on_hand": self.on_hand, "reserved": self.reserved, "inbound": self.inbound,
            "replenishment_lead_time_days": self.replenishment_lead_time_days,
            "oldest_stock_received_at": iso(self.oldest_stock_received_at),
            "clearance_date": iso(self.clearance_date), "as_of": iso(self.as_of),
            "locations": list(self.locations),
        }

    @classmethod
    def from_dict(cls, d: dict | None) -> "InventoryInput | None":
        if not d:
            return None
        return cls(
            on_hand=int(d["on_hand"]), reserved=int(d.get("reserved", 0)), inbound=int(d.get("inbound", 0)),
            replenishment_lead_time_days=d.get("replenishment_lead_time_days"),
            oldest_stock_received_at=parse_dt(d.get("oldest_stock_received_at")),
            clearance_date=parse_date(d.get("clearance_date")), as_of=parse_dt(d.get("as_of")),
            locations=tuple(d.get("locations", ())),
        )


@dataclass(frozen=True)
class SalesPeriod:
    """One day (or other period) of observed sales with its availability context."""

    day: date
    units: int
    stockout: bool = False
    promotion: bool = False
    price: Decimal | None = None
    days: int = 1

    def to_dict(self) -> dict:
        return {"day": iso(self.day), "units": self.units, "stockout": self.stockout,
                "promotion": self.promotion, "price": money_str(self.price), "days": self.days}

    @classmethod
    def from_dict(cls, d: dict) -> "SalesPeriod":
        return cls(day=parse_date(d["day"]), units=int(d["units"]), stockout=bool(d.get("stockout", False)),
                   promotion=bool(d.get("promotion", False)), price=D(d.get("price"), allow_none=True),
                   days=int(d.get("days", 1)))


@dataclass(frozen=True)
class CompetitorObservation:
    observation_id: str
    supplier: str
    variant_match: str  # "exact" | "different" | "unknown"
    condition: str
    item_price: Decimal | None
    delivery_charge: Decimal | None
    mandatory_charges: Decimal | None
    charges_complete: bool
    comparable_total: Decimal | None
    currency: str
    availability: str  # in_stock | out_of_stock | preorder | unknown
    membership_required: bool
    observed_at: datetime
    match_confidence: Decimal
    match_status: str  # confirmed | probable | unresolved | rejected
    eligibility_conditions: tuple[str, ...] = ()
    source: str = ""
    retained_after_feed_failure: bool = False
    listing_key: str = ""  # the supplier's own listing identity, when known

    def to_dict(self) -> dict:
        return {
            "observation_id": self.observation_id, "supplier": self.supplier, "listing_key": self.listing_key,
            "variant_match": self.variant_match, "condition": self.condition,
            "item_price": money_str(self.item_price), "delivery_charge": money_str(self.delivery_charge),
            "mandatory_charges": money_str(self.mandatory_charges), "charges_complete": self.charges_complete,
            "comparable_total": money_str(self.comparable_total), "currency": self.currency,
            "availability": self.availability, "membership_required": self.membership_required,
            "observed_at": iso(self.observed_at), "match_confidence": dec_str(self.match_confidence),
            "match_status": self.match_status, "eligibility_conditions": list(self.eligibility_conditions),
            "source": self.source, "retained_after_feed_failure": self.retained_after_feed_failure,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "CompetitorObservation":
        return cls(
            observation_id=str(d["observation_id"]), supplier=d["supplier"], variant_match=d["variant_match"],
            condition=d["condition"], item_price=D(d.get("item_price"), allow_none=True),
            delivery_charge=D(d.get("delivery_charge"), allow_none=True),
            mandatory_charges=D(d.get("mandatory_charges"), allow_none=True),
            charges_complete=bool(d["charges_complete"]),
            comparable_total=D(d.get("comparable_total"), allow_none=True), currency=d["currency"],
            availability=d["availability"], membership_required=bool(d.get("membership_required", False)),
            observed_at=parse_dt(d["observed_at"]), match_confidence=D(d["match_confidence"]),
            match_status=d["match_status"], eligibility_conditions=tuple(d.get("eligibility_conditions", ())),
            source=d.get("source", ""), retained_after_feed_failure=bool(d.get("retained_after_feed_failure", False)),
            listing_key=str(d.get("listing_key", "")),
        )


@dataclass(frozen=True)
class PromotionInput:
    """An approved campaign. Unapproved campaigns are never passed to the engine as active."""

    promotion_id: str
    name: str
    status: str  # only "approved" is honoured
    starts_at: datetime
    ends_at: datetime
    kind: str  # "fixed_price" | "percent_off"
    value: Decimal
    funding: str = "merchant"  # "merchant" | "supplier" | "shared"
    supplier_funding_per_unit: Decimal = ZERO
    eligibility: str = ""
    # An explicitly approved floor for the campaign; None keeps the policy floor.
    approved_min_contribution_margin: Decimal | None = None

    def to_dict(self) -> dict:
        return {
            "promotion_id": self.promotion_id, "name": self.name, "status": self.status,
            "starts_at": iso(self.starts_at), "ends_at": iso(self.ends_at), "kind": self.kind,
            "value": dec_str(self.value), "funding": self.funding,
            "supplier_funding_per_unit": dec_str(self.supplier_funding_per_unit),
            "eligibility": self.eligibility,
            "approved_min_contribution_margin": dec_str(self.approved_min_contribution_margin),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PromotionInput":
        return cls(
            promotion_id=str(d["promotion_id"]), name=d.get("name", ""), status=d["status"],
            starts_at=parse_dt(d["starts_at"]), ends_at=parse_dt(d["ends_at"]), kind=d["kind"],
            value=D(d["value"]), funding=d.get("funding", "merchant"),
            supplier_funding_per_unit=D(d.get("supplier_funding_per_unit") or "0"),
            eligibility=d.get("eligibility", ""),
            approved_min_contribution_margin=D(d.get("approved_min_contribution_margin"), allow_none=True),
        )


@dataclass(frozen=True)
class CommitmentInput:
    """An explicitly recorded contractual price restriction."""

    commitment_id: str
    kind: str  # "min_price" | "max_price" | "fixed_price"
    value: Decimal
    reference: str = ""
    valid_from: datetime | None = None
    valid_to: datetime | None = None

    def active_at(self, when: datetime) -> bool:
        return (self.valid_from is None or self.valid_from <= when) and (self.valid_to is None or when < self.valid_to)

    def to_dict(self) -> dict:
        return {"commitment_id": self.commitment_id, "kind": self.kind, "value": money_str(self.value),
                "reference": self.reference, "valid_from": iso(self.valid_from), "valid_to": iso(self.valid_to)}

    @classmethod
    def from_dict(cls, d: dict) -> "CommitmentInput":
        return cls(commitment_id=str(d["commitment_id"]), kind=d["kind"], value=D(d["value"]),
                   reference=d.get("reference", ""), valid_from=parse_dt(d.get("valid_from")),
                   valid_to=parse_dt(d.get("valid_to")))


@dataclass(frozen=True)
class DemandModelInput:
    """A fitted demand estimate. Only ``status == 'validated'`` may drive a price."""

    model_id: str
    status: str
    elasticity: Decimal | None = None
    ci_low: Decimal | None = None
    ci_high: Decimal | None = None
    reference_price: Decimal | None = None
    reference_units_per_day: Decimal | None = None
    fitted_at: datetime | None = None
    reasons: tuple[str, ...] = ()

    def to_dict(self) -> dict:
        return {"model_id": self.model_id, "status": self.status, "elasticity": dec_str(self.elasticity),
                "ci_low": dec_str(self.ci_low), "ci_high": dec_str(self.ci_high),
                "reference_price": money_str(self.reference_price),
                "reference_units_per_day": dec_str(self.reference_units_per_day),
                "fitted_at": iso(self.fitted_at), "reasons": list(self.reasons)}

    @classmethod
    def from_dict(cls, d: dict | None) -> "DemandModelInput | None":
        if not d:
            return None
        return cls(model_id=str(d["model_id"]), status=d["status"],
                   elasticity=D(d.get("elasticity"), allow_none=True), ci_low=D(d.get("ci_low"), allow_none=True),
                   ci_high=D(d.get("ci_high"), allow_none=True),
                   reference_price=D(d.get("reference_price"), allow_none=True),
                   reference_units_per_day=D(d.get("reference_units_per_day"), allow_none=True),
                   fitted_at=parse_dt(d.get("fitted_at")), reasons=tuple(d.get("reasons", ())))


@dataclass(frozen=True)
class PricePoint:
    effective_at: datetime
    price: Decimal

    def to_dict(self) -> dict:
        return {"effective_at": iso(self.effective_at), "price": money_str(self.price)}

    @classmethod
    def from_dict(cls, d: dict) -> "PricePoint":
        return cls(effective_at=parse_dt(d["effective_at"]), price=D(d["price"]))


@dataclass(frozen=True)
class FeedStatus:
    source: str
    last_success_at: datetime | None = None
    last_failure_at: datetime | None = None
    last_error: str = ""

    @property
    def failing(self) -> bool:
        return self.last_failure_at is not None and (
            self.last_success_at is None or self.last_failure_at > self.last_success_at
        )

    def to_dict(self) -> dict:
        return {"source": self.source, "last_success_at": iso(self.last_success_at),
                "last_failure_at": iso(self.last_failure_at), "last_error": self.last_error}

    @classmethod
    def from_dict(cls, d: dict) -> "FeedStatus":
        return cls(source=d["source"], last_success_at=parse_dt(d.get("last_success_at")),
                   last_failure_at=parse_dt(d.get("last_failure_at")), last_error=d.get("last_error", ""))


@dataclass(frozen=True)
class EvaluationInput:
    evaluation_time: datetime
    product_id: str
    variant_id: str
    sku: str
    product_name: str
    category: str
    condition: str
    channel: str
    region: str
    currency: str
    policy: dict
    policy_version: str
    current_price: Decimal | None = None
    current_price_confirmed_at: datetime | None = None
    standard_retail_price: Decimal | None = None
    customer_delivery_charge: Decimal = ZERO
    cost: CostInputs | None = None
    cost_issue: str = ""
    tax: TaxConfig | None = None
    tax_issue: str = ""
    inventory: InventoryInput | None = None
    sales: tuple[SalesPeriod, ...] = ()
    competitor_observations: tuple[CompetitorObservation, ...] = ()
    feeds: tuple[FeedStatus, ...] = ()
    price_history: tuple[PricePoint, ...] = ()
    promotions: tuple[PromotionInput, ...] = ()
    commitments: tuple[CommitmentInput, ...] = ()
    demand_model: DemandModelInput | None = None

    def to_dict(self) -> dict:
        return {
            "evaluation_time": iso(self.evaluation_time),
            "product_id": self.product_id, "variant_id": self.variant_id, "sku": self.sku,
            "product_name": self.product_name, "category": self.category, "condition": self.condition,
            "channel": self.channel, "region": self.region, "currency": self.currency,
            "policy": self.policy, "policy_version": self.policy_version,
            "current_price": money_str(self.current_price),
            "current_price_confirmed_at": iso(self.current_price_confirmed_at),
            "standard_retail_price": money_str(self.standard_retail_price),
            "customer_delivery_charge": money_str(self.customer_delivery_charge),
            "cost": self.cost.to_dict() if self.cost else None, "cost_issue": self.cost_issue,
            "tax": self.tax.to_dict() if self.tax else None, "tax_issue": self.tax_issue,
            "inventory": self.inventory.to_dict() if self.inventory else None,
            "sales": [s.to_dict() for s in self.sales],
            "competitor_observations": [o.to_dict() for o in self.competitor_observations],
            "feeds": [f.to_dict() for f in self.feeds],
            "price_history": [p.to_dict() for p in self.price_history],
            "promotions": [p.to_dict() for p in self.promotions],
            "commitments": [c.to_dict() for c in self.commitments],
            "demand_model": self.demand_model.to_dict() if self.demand_model else None,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "EvaluationInput":
        return cls(
            evaluation_time=parse_dt(d["evaluation_time"]),
            product_id=str(d["product_id"]), variant_id=str(d["variant_id"]), sku=d["sku"],
            product_name=d.get("product_name", ""), category=d.get("category", ""),
            condition=d.get("condition", "new"), channel=d["channel"], region=d.get("region", ""),
            currency=d["currency"], policy=d["policy"], policy_version=str(d["policy_version"]),
            current_price=D(d.get("current_price"), allow_none=True),
            current_price_confirmed_at=parse_dt(d.get("current_price_confirmed_at")),
            standard_retail_price=D(d.get("standard_retail_price"), allow_none=True),
            customer_delivery_charge=D(d.get("customer_delivery_charge") or "0"),
            cost=CostInputs.from_dict(d.get("cost")), cost_issue=d.get("cost_issue", ""),
            tax=TaxConfig.from_dict(d.get("tax")), tax_issue=d.get("tax_issue", ""),
            inventory=InventoryInput.from_dict(d.get("inventory")),
            sales=tuple(SalesPeriod.from_dict(s) for s in d.get("sales", ())),
            competitor_observations=tuple(
                CompetitorObservation.from_dict(o) for o in d.get("competitor_observations", ())
            ),
            feeds=tuple(FeedStatus.from_dict(f) for f in d.get("feeds", ())),
            price_history=tuple(PricePoint.from_dict(p) for p in d.get("price_history", ())),
            promotions=tuple(PromotionInput.from_dict(p) for p in d.get("promotions", ())),
            commitments=tuple(CommitmentInput.from_dict(c) for c in d.get("commitments", ())),
            demand_model=DemandModelInput.from_dict(d.get("demand_model")),
        )


def canonical_json(payload: dict) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def snapshot_hash(payload: dict) -> str:
    """SHA-256 of the canonical JSON form of an input snapshot."""
    return hashlib.sha256(canonical_json(payload).encode("ascii")).hexdigest()
