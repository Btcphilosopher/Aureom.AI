"""Price floors, ceilings and the feasible interval.

Every constraint contributes a named lower and/or upper :class:`Bound`. The
feasible interval is the intersection. When it is empty the engine reports a
*conflict for review*; it never drops a cost floor or any other required
constraint to manufacture a price.

Order of operations (see :mod:`engine.evaluation`):

1. build the interval from all constraints;
2. choose a candidate inside it;
3. apply the price ending;
4. validate the rounded result against the same interval again.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal

from .money import CENT, ONE, ZERO, CostInputs, TaxConfig, ceil_cent, floor_cent, minimum_price_for, money_str
from .policy import PolicyConfig
from .types import CommitmentInput, PricePoint, PromotionInput

HARD = "hard"
MOVEMENT = "movement"

MODE_STANDARD = "standard"
MODE_PROMOTION = "promotion"
MODE_CLEARANCE = "clearance"


@dataclass(frozen=True)
class Bound:
    name: str
    side: str  # "lower" | "upper"
    value: Decimal
    kind: str  # HARD | MOVEMENT
    detail: str

    def to_dict(self) -> dict:
        return {"name": self.name, "side": self.side, "value": money_str(self.value),
                "kind": self.kind, "detail": self.detail}


@dataclass(frozen=True)
class FeasibleInterval:
    lower: Decimal
    upper: Decimal | None
    bounds: tuple[Bound, ...]
    binding_lower: Bound | None
    binding_upper: Bound | None
    conflict: bool
    conflict_detail: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()

    def contains(self, price: Decimal) -> bool:
        return not self.conflict and price >= self.lower and (self.upper is None or price <= self.upper)

    def clamp(self, price: Decimal) -> Decimal:
        if price < self.lower:
            return self.lower
        if self.upper is not None and price > self.upper:
            return self.upper
        return price

    def violations(self, price: Decimal) -> list[Bound]:
        out = []
        for b in self.bounds:
            if (b.side == "lower" and price < b.value) or (b.side == "upper" and price > b.value):
                out.append(b)
        return out

    def to_dict(self) -> dict:
        return {
            "lower": money_str(self.lower), "upper": money_str(self.upper),
            "binding_lower": self.binding_lower.name if self.binding_lower else None,
            "binding_upper": self.binding_upper.name if self.binding_upper else None,
            "conflict": self.conflict, "conflict_detail": list(self.conflict_detail),
            "bounds": [b.to_dict() for b in self.bounds], "notes": list(self.notes),
        }


def cumulative_reference_price(history: tuple[PricePoint, ...], window_start: datetime) -> Decimal | None:
    """The price in effect at ``window_start`` (or the earliest known price after it)."""
    if not history:
        return None
    ordered = sorted(history, key=lambda p: p.effective_at)
    before = [p for p in ordered if p.effective_at <= window_start]
    return before[-1].price if before else ordered[0].price


def last_change_at(history: tuple[PricePoint, ...]) -> datetime | None:
    return max((p.effective_at for p in history), default=None)


def last_direction(history: tuple[PricePoint, ...]) -> int:
    """+1 / -1 for the direction of the most recent recorded change, else 0."""
    ordered = sorted(history, key=lambda p: p.effective_at)
    for newer, older in zip(reversed(ordered), reversed(ordered[:-1])):
        if newer.price != older.price:
            return 1 if newer.price > older.price else -1
    return 0


def compute_interval(
    *,
    policy: PolicyConfig,
    cost: CostInputs,
    tax: TaxConfig,
    currency: str,
    evaluation_time: datetime,
    current_price: Decimal | None,
    standard_retail_price: Decimal | None,
    customer_delivery_charge: Decimal = ZERO,
    price_history: tuple[PricePoint, ...] = (),
    commitments: tuple[CommitmentInput, ...] = (),
    mode: str = MODE_STANDARD,
    promotion: PromotionInput | None = None,
    include_movement: bool = True,
) -> FeasibleInterval:
    bounds: list[Bound] = []
    conflicts: list[str] = []
    notes: list[str] = []
    cur = currency

    # -- contribution floors -------------------------------------------------
    min_margin = policy.min_contribution_margin
    min_amount = policy.min_contribution_amount
    margin_name, amount_name = "minimum_contribution_margin", "minimum_contribution_amount"
    funding = ZERO
    if mode == MODE_CLEARANCE:
        if policy.clearance.min_contribution_margin is not None:
            min_margin = policy.clearance.min_contribution_margin
            margin_name = "clearance_minimum_contribution_margin"
            notes.append("Clearance policy floor replaces the standard contribution-margin floor.")
        if policy.clearance.min_contribution_amount is not None:
            min_amount = policy.clearance.min_contribution_amount
            amount_name = "clearance_minimum_contribution_amount"
    if mode == MODE_PROMOTION and promotion is not None:
        funding = promotion.supplier_funding_per_unit
        if promotion.approved_min_contribution_margin is not None:
            min_margin = promotion.approved_min_contribution_margin
            margin_name = "promotion_approved_minimum_contribution_margin"
            notes.append(f"Approved promotion '{promotion.name}' records its own contribution-margin floor.")

    if min_margin is not None:
        sol = minimum_price_for(cost, tax, min_margin=min_margin, customer_delivery_charge=customer_delivery_charge,
                                promotion_funding=funding)
        if sol.feasible:
            bounds.append(Bound(margin_name, "lower", sol.price, HARD,
                                f"Lowest price giving a contribution margin of at least {min_margin:.1%} "
                                f"after tax, fees on their charging basis and all variable costs."))
        else:
            conflicts.append(f"{margin_name}: {sol.detail}")
    if min_amount is not None:
        sol = minimum_price_for(cost, tax, min_amount=min_amount, customer_delivery_charge=customer_delivery_charge,
                                promotion_funding=funding)
        if sol.feasible:
            bounds.append(Bound(amount_name, "lower", sol.price, HARD,
                                f"Lowest price giving a contribution of at least {cur} {min_amount:.2f} per unit."))
        else:
            conflicts.append(f"{amount_name}: {sol.detail}")

    # -- absolute and contractual limits --------------------------------------
    if policy.absolute_min_price is not None:
        bounds.append(Bound("absolute_minimum_price", "lower", ceil_cent(policy.absolute_min_price), HARD,
                            "Policy absolute minimum price."))
    if policy.absolute_max_price is not None:
        bounds.append(Bound("absolute_maximum_price", "upper", floor_cent(policy.absolute_max_price), HARD,
                            "Policy absolute maximum price."))
    if policy.cap_at_standard_retail_price and standard_retail_price is not None:
        bounds.append(Bound("standard_retail_price_cap", "upper", floor_cent(standard_retail_price), HARD,
                            "Policy caps the price at the standard retail price."))
    for c in sorted(commitments, key=lambda c: c.commitment_id):
        if not c.active_at(evaluation_time):
            continue
        ref = f" ({c.reference})" if c.reference else ""
        if c.kind in ("min_price", "fixed_price"):
            bounds.append(Bound("contractual_minimum_price" if c.kind == "min_price" else "contractual_fixed_price",
                                "lower", ceil_cent(c.value), HARD, f"Recorded contractual restriction{ref}."))
        if c.kind in ("max_price", "fixed_price"):
            bounds.append(Bound("contractual_maximum_price" if c.kind == "max_price" else "contractual_fixed_price",
                                "upper", floor_cent(c.value), HARD, f"Recorded contractual restriction{ref}."))

    # -- movement limits -------------------------------------------------------
    exempt = mode == MODE_PROMOTION and policy.promotion_exempt_from_movement_limits
    if include_movement and current_price is not None:
        if exempt:
            notes.append("Movement limits and cooldown are not applied: the policy exempts approved promotions.")
        else:
            if policy.max_change_pct_per_evaluation is not None:
                x = policy.max_change_pct_per_evaluation
                bounds.append(Bound("maximum_price_change", "lower", ceil_cent(current_price * (ONE - x)), MOVEMENT,
                                    f"At most {x:.1%} below the current price per evaluation."))
                bounds.append(Bound("maximum_price_change", "upper", floor_cent(current_price * (ONE + x)), MOVEMENT,
                                    f"At most {x:.1%} above the current price per evaluation."))
            if policy.max_cumulative_change_pct is not None:
                window_start = evaluation_time - timedelta(days=policy.cumulative_window_days)
                ref_price = cumulative_reference_price(price_history, window_start) or current_price
                y = policy.max_cumulative_change_pct
                detail = (f"within {y:.1%} of {cur} {ref_price:.2f}, the price in effect "
                          f"{policy.cumulative_window_days} days ago (from recorded price history).")
                bounds.append(Bound("maximum_cumulative_movement", "lower", ceil_cent(ref_price * (ONE - y)),
                                    MOVEMENT, f"Cumulative movement limit: {detail}"))
                bounds.append(Bound("maximum_cumulative_movement", "upper", floor_cent(ref_price * (ONE + y)),
                                    MOVEMENT, f"Cumulative movement limit: {detail}"))
            changed = last_change_at(price_history)
            if policy.cooldown_hours and changed is not None:
                until = changed + timedelta(hours=policy.cooldown_hours)
                if evaluation_time < until:
                    detail = f"Cooldown: price last changed {changed.isoformat()}; no change before {until.isoformat()}."
                    bounds.append(Bound("cooldown", "lower", current_price, MOVEMENT, detail))
                    bounds.append(Bound("cooldown", "upper", current_price, MOVEMENT, detail))

    lowers = [b for b in bounds if b.side == "lower"]
    uppers = [b for b in bounds if b.side == "upper"]
    binding_lower = max(lowers, key=lambda b: (b.value, b.kind == HARD), default=None)
    binding_upper = min(uppers, key=lambda b: (b.value, b.kind != HARD), default=None)
    lower = max(binding_lower.value, CENT) if binding_lower else CENT
    upper = binding_upper.value if binding_upper else None

    if upper is not None and lower > upper:
        conflicts.append(
            f"{binding_lower.name} requires at least {cur} {lower:.2f} but {binding_upper.name} allows at most "
            f"{cur} {upper:.2f}. No price satisfies both; the constraints are left intact for review."
        )
    return FeasibleInterval(
        lower=lower, upper=upper, bounds=tuple(bounds), binding_lower=binding_lower, binding_upper=binding_upper,
        conflict=bool(conflicts), conflict_detail=tuple(conflicts), notes=tuple(notes),
    )


def apply_price_ending(
    price: Decimal, endings: tuple[Decimal, ...], interval: FeasibleInterval
) -> Decimal | None:
    """Nearest price with an allowed ending that is still inside the interval.

    Returns ``None`` when no allowed ending fits. Ties go to the lower price.
    """
    if not endings:
        return price
    whole = int(price)
    candidates = {Decimal(w) + e for w in (whole - 1, whole, whole + 1) for e in endings}
    feasible = [c for c in candidates if c > 0 and interval.contains(c)]
    if not feasible:
        return None
    return min(feasible, key=lambda c: (abs(c - price), c))


__all__ = [
    "Bound", "FeasibleInterval", "compute_interval", "apply_price_ending", "cumulative_reference_price",
    "last_change_at", "last_direction", "HARD", "MOVEMENT", "MODE_STANDARD", "MODE_PROMOTION", "MODE_CLEARANCE",
]
