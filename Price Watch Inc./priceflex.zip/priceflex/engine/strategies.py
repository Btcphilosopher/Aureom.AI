"""Transparent pricing strategies.

Each strategy inspects the same context and returns a :class:`Proposal` - a
target price with the evidence behind it, or the reason it does not apply.
Strategies never see the feasible interval as something they may move: the
evaluation clamps every target to it afterwards and records which bound bit.

Precedence is the policy's ``strategy_order``: the first applicable strategy
supplies the target. All proposals are kept in the selection trace.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from decimal import Decimal

from .comparables import ComparableSet
from .constraints import FeasibleInterval
from .money import ONE, CostInputs, TaxConfig, margin_breakdown, minimum_price_for, money_str, q2
from .policy import (
    STRATEGY_CLEARANCE,
    STRATEGY_COMPETITOR,
    STRATEGY_DEMAND,
    STRATEGY_INVENTORY,
    STRATEGY_MARGIN,
    STRATEGY_PROMOTION,
    PolicyConfig,
)
from .types import EvaluationInput, PromotionInput


@dataclass
class Proposal:
    strategy: str
    applicable: bool
    target: Decimal | None = None
    reasons: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    evidence: dict = field(default_factory=dict)
    hold: bool = False
    block: bool = False
    selected: bool = False

    def to_dict(self) -> dict:
        return {"strategy": self.strategy, "applicable": self.applicable, "selected": self.selected,
                "target": money_str(self.target), "hold": self.hold, "block": self.block,
                "reasons": self.reasons, "warnings": self.warnings, "evidence": self.evidence}


@dataclass(frozen=True)
class InventoryMetrics:
    known: bool
    stale: bool = False
    available: int = 0
    inbound: int = 0
    in_stock_days: int = 0
    stockout_days: int = 0
    units_in_stock_days: int = 0
    avg_daily_sales: Decimal | None = None
    cover_days: Decimal | None = None
    no_sales_while_in_stock: bool = False
    stock_age_days: int | None = None
    days_to_clearance: int | None = None
    lead_time_days: int | None = None

    def to_dict(self) -> dict:
        return {
            "known": self.known, "stale": self.stale, "available": self.available, "inbound": self.inbound,
            "in_stock_days_observed": self.in_stock_days, "stockout_days_excluded": self.stockout_days,
            "units_sold_in_stock_days": self.units_in_stock_days,
            "avg_daily_sales_in_stock": None if self.avg_daily_sales is None else format(self.avg_daily_sales, "f"),
            "cover_days": None if self.cover_days is None else format(self.cover_days, "f"),
            "no_sales_while_in_stock": self.no_sales_while_in_stock,
            "stock_age_days": self.stock_age_days, "days_to_clearance": self.days_to_clearance,
            "replenishment_lead_time_days": self.lead_time_days,
        }


def inventory_metrics(inp: EvaluationInput, policy: PolicyConfig) -> InventoryMetrics:
    """Stock cover from in-stock sales only.

    Days flagged as stockouts are excluded from the sales rate: zero sales
    while nothing was available says nothing about demand.
    """
    inv = inp.inventory
    if inv is None:
        return InventoryMetrics(known=False)
    now = inp.evaluation_time
    stale = inv.as_of is None or (now - inv.as_of) > timedelta(hours=policy.inventory.max_inventory_age_hours)
    since = now.date() - timedelta(days=policy.inventory.sales_lookback_days)
    in_stock_days = stockout_days = units = 0
    for s in inp.sales:
        if not (since <= s.day < now.date()):
            continue
        if s.stockout:
            stockout_days += s.days
        else:
            in_stock_days += s.days
            units += s.units
    avg = cover = None
    no_sales = False
    if in_stock_days > 0:
        avg = (Decimal(units) / Decimal(in_stock_days)).quantize(Decimal("0.0001"))
        if avg > 0:
            cover = (Decimal(max(inv.available, 0)) / avg).quantize(Decimal("0.1"))
        else:
            no_sales = inv.available > 0
    age = (now - inv.oldest_stock_received_at).days if inv.oldest_stock_received_at else None
    to_clear = (inv.clearance_date - now.date()).days if inv.clearance_date else None
    return InventoryMetrics(
        known=True, stale=stale, available=inv.available, inbound=inv.inbound, in_stock_days=in_stock_days,
        stockout_days=stockout_days, units_in_stock_days=units, avg_daily_sales=avg, cover_days=cover,
        no_sales_while_in_stock=no_sales, stock_age_days=age, days_to_clearance=to_clear,
        lead_time_days=inv.replenishment_lead_time_days,
    )


def active_promotion(inp: EvaluationInput) -> PromotionInput | None:
    """The approved promotion in force at the evaluation time, if any."""
    live = [p for p in inp.promotions
            if p.status == "approved" and p.starts_at <= inp.evaluation_time < p.ends_at]
    return min(live, key=lambda p: (p.starts_at, p.promotion_id)) if live else None


@dataclass(frozen=True)
class ClearanceState:
    active: bool
    reason: str
    markdown_pct: Decimal | None = None
    days_remaining: int | None = None


def clearance_state(inp: EvaluationInput, policy: PolicyConfig, inv: InventoryMetrics) -> ClearanceState:
    c = policy.clearance
    if not c.enabled:
        return ClearanceState(False, "Clearance is not enabled in this policy.")
    if not inv.known or inv.days_to_clearance is None:
        return ClearanceState(False, "No clearance date is recorded for this stock.")
    if inv.stale:
        return ClearanceState(False, "Inventory data is stale, so clearance pricing is not applied.")
    if inv.available < max(c.min_on_hand, 1):
        return ClearanceState(False, "No stock remains to clear.")
    days = max(inv.days_to_clearance, 0)
    tiers = [(d, pct) for d, pct in c.schedule if d >= days]
    if not tiers:
        opens = max(d for d, _ in c.schedule)
        return ClearanceState(False, f"Clearance window opens {opens} days before the clearance date; "
                                     f"{days} days remain.", days_remaining=days)
    if inv.cover_days is not None and inv.cover_days <= Decimal(days):
        return ClearanceState(False, f"Stock cover of {inv.cover_days} days is within the {days} days remaining; "
                                     "on track to sell through without a markdown.", days_remaining=days)
    _, pct = min(tiers)
    return ClearanceState(True, "", markdown_pct=pct, days_remaining=days)


@dataclass
class Context:
    inp: EvaluationInput
    policy: PolicyConfig
    cost: CostInputs
    tax: TaxConfig
    comparables: ComparableSet
    inventory: InventoryMetrics
    promotion: PromotionInput | None
    clearance: ClearanceState
    interval: FeasibleInterval

    @property
    def cur(self) -> str:
        return self.inp.currency


# ---------------------------------------------------------------------------


def promotion_strategy(ctx: Context) -> Proposal:
    p = ctx.promotion
    if p is None:
        pending = [x for x in ctx.inp.promotions if x.status != "approved"]
        why = "No approved promotion is in force at the evaluation time."
        if pending:
            why += f" {len(pending)} unapproved campaign(s) were ignored."
        return Proposal(STRATEGY_PROMOTION, False, reasons=[why])
    base = ctx.inp.standard_retail_price or ctx.inp.current_price
    if p.kind == "fixed_price":
        target = q2(p.value)
    elif base is None:
        return Proposal(STRATEGY_PROMOTION, False,
                        reasons=["Percentage promotion needs a standard retail price to discount from."])
    else:
        target = q2(base * (ONE - p.value))
    desc = f"{ctx.cur} {p.value:.2f} fixed price" if p.kind == "fixed_price" else f"{p.value:.0%} off {ctx.cur} {base:.2f}"
    reasons = [f"Approved promotion '{p.name}' is in force from {p.starts_at.isoformat()} to "
               f"{p.ends_at.isoformat()} ({desc}; funding: {p.funding})."]
    if p.eligibility:
        reasons.append(f"Promotion eligibility: {p.eligibility}")
    return Proposal(STRATEGY_PROMOTION, True, target, reasons, evidence=p.to_dict())


def clearance_strategy(ctx: Context) -> Proposal:
    st = ctx.clearance
    if not st.active:
        return Proposal(STRATEGY_CLEARANCE, False, reasons=[st.reason],
                        evidence={"days_remaining": st.days_remaining})
    base = ctx.inp.standard_retail_price or ctx.inp.current_price
    if base is None:
        return Proposal(STRATEGY_CLEARANCE, False, reasons=["No standard retail price to mark down from."])
    target = q2(base * (ONE - st.markdown_pct))
    inv = ctx.inventory
    cover = "no in-stock sales recorded" if inv.cover_days is None else f"stock cover {inv.cover_days} days"
    return Proposal(
        STRATEGY_CLEARANCE, True, target,
        [f"{inv.available} units remain with {st.days_remaining} days to the clearance date ({cover}); the "
         f"clearance schedule applies {st.markdown_pct:.0%} off the standard retail price of {ctx.cur} {base:.2f}."],
        evidence={"days_remaining": st.days_remaining, "markdown_pct": format(st.markdown_pct, "f"),
                  "base_price": money_str(base)},
    )


def margin_strategy(ctx: Context) -> Proposal:
    """Protect a contribution target.

    Raises a price that falls short of the target to the lowest price meeting
    it. A price that already meets the target is held: this strategy never
    cuts a price merely because the margin is above target.
    """
    target_margin = ctx.policy.target_contribution_margin
    if target_margin is None:
        return Proposal(STRATEGY_MARGIN, False, reasons=["No target contribution margin is configured."])
    sol = minimum_price_for(ctx.cost, ctx.tax, min_margin=target_margin,
                            customer_delivery_charge=ctx.inp.customer_delivery_charge)
    if not sol.feasible:
        return Proposal(STRATEGY_MARGIN, False, reasons=[f"Target margin cannot be reached: {sol.detail}"])
    evidence = {"target_contribution_margin": format(target_margin, "f"), "price_meeting_target": money_str(sol.price)}
    cur_price = ctx.inp.current_price
    if cur_price is None:
        return Proposal(STRATEGY_MARGIN, True, sol.price, evidence=evidence, reasons=[
            f"{ctx.cur} {sol.price:.2f} is the lowest price meeting the {target_margin:.1%} contribution target."])
    now_margin = margin_breakdown(cur_price, ctx.cost, ctx.tax,
                                  customer_delivery_charge=ctx.inp.customer_delivery_charge).contribution_margin
    shown = "n/a" if now_margin is None else f"{now_margin:.1%}"
    evidence["current_contribution_margin"] = None if now_margin is None else format(now_margin, "f")
    if cur_price >= sol.price:
        return Proposal(STRATEGY_MARGIN, True, None, hold=True, evidence=evidence, reasons=[
            f"Current price gives a contribution margin of {shown}, which meets the configured target of "
            f"{target_margin:.1%}; no margin-led change is needed."])
    return Proposal(STRATEGY_MARGIN, True, sol.price, evidence=evidence, reasons=[
        f"Current price gives a contribution margin of {shown}, below the configured target of {target_margin:.1%}.",
        f"{ctx.cur} {sol.price:.2f} is the lowest price meeting the {target_margin:.1%} contribution target."])


def competitor_strategy(ctx: Context) -> Proposal:
    comp, cp = ctx.comparables, ctx.policy.competitor
    evidence = {"basis": comp.basis, "position": cp.position, "eligible_count": len(comp.eligible),
                "excluded_count": len(comp.excluded)}
    if len(comp.eligible) < cp.min_eligible_offers:
        why = (f"{len(comp.eligible)} eligible comparable offer(s); the policy needs at least "
               f"{cp.min_eligible_offers}. {len(comp.excluded)} observation(s) were excluded.")
        if cp.on_no_eligible == "hold":
            return Proposal(STRATEGY_COMPETITOR, True, None,
                            [why, "Policy fallback: hold the current price when competitor evidence is insufficient."],
                            list(comp.warnings), evidence, hold=True)
        if cp.on_no_eligible == "block":
            return Proposal(STRATEGY_COMPETITOR, True, None,
                            [why, "Policy fallback: block the recommendation when competitor evidence is insufficient."],
                            list(comp.warnings), evidence, block=True)
        return Proposal(STRATEGY_COMPETITOR, False,
                        reasons=[why, "Policy fallback: continue to the next strategy."],
                        warnings=list(comp.warnings), evidence=evidence)
    reference = comp.reference(cp.position)
    target_basis = reference * (ONE + cp.offset_pct) + cp.offset_amount
    target = q2(target_basis - comp.own_basis_addition)
    label = {"match_lowest": "lowest", "match_median": "median", "match_highest": "highest"}[cp.position]
    basis_txt = "delivered total" if comp.basis == "delivered_total" else "item price"
    reasons = [f"{len(comp.eligible)} eligible comparable offer(s) on a {basis_txt} basis; the {label} is "
               f"{ctx.cur} {reference:.2f}."]
    if cp.offset_pct or cp.offset_amount:
        reasons.append(f"Policy position: {cp.offset_pct:+.1%} and {ctx.cur} {cp.offset_amount:+.2f} against the "
                       f"{label}, giving {ctx.cur} {target_basis:.2f}.")
    if comp.own_basis_addition:
        reasons.append(f"Our delivery charge of {ctx.cur} {comp.own_basis_addition:.2f} is deducted to compare like "
                       f"with like, giving an item price target of {ctx.cur} {target:.2f}.")
    evidence.update(reference=money_str(reference), target_on_basis=money_str(target_basis))
    return Proposal(STRATEGY_COMPETITOR, True, target, reasons, list(comp.warnings), evidence)


def inventory_strategy(ctx: Context) -> Proposal:
    ip, inv, cur_price = ctx.policy.inventory, ctx.inventory, ctx.inp.current_price
    ev = inv.to_dict()
    if not ip.enabled:
        return Proposal(STRATEGY_INVENTORY, False, reasons=["Inventory-led pricing is not enabled."], evidence=ev)
    if not inv.known:
        return Proposal(STRATEGY_INVENTORY, False, reasons=["No inventory position is available."], evidence=ev)
    if inv.stale:
        return Proposal(STRATEGY_INVENTORY, False,
                        reasons=["Inventory position is stale, so no inventory-led change is proposed."], evidence=ev)
    if cur_price is None:
        return Proposal(STRATEGY_INVENTORY, False, reasons=["No current price to adjust from."], evidence=ev)
    if inv.available <= 0:
        return Proposal(STRATEGY_INVENTORY, False,
                        reasons=["Out of stock: no inventory-led change is proposed."], evidence=ev)
    steps: list[tuple[Decimal, str]] = []
    if inv.no_sales_while_in_stock and inv.in_stock_days >= ip.sales_lookback_days // 2:
        steps.append((ip.markdown_step_pct, f"No sales in {inv.in_stock_days} in-stock days with {inv.available} "
                                            "units available."))
    elif inv.cover_days is not None and inv.cover_days > ip.high_cover_days:
        steps.append((ip.markdown_step_pct, f"Stock cover is {inv.cover_days} days, above the "
                                            f"{ip.high_cover_days}-day threshold."))
    if ip.max_stock_age_days is not None and inv.stock_age_days is not None and inv.stock_age_days > ip.max_stock_age_days:
        steps.append((ip.aged_markdown_step_pct, f"Oldest stock is {inv.stock_age_days} days old, above the "
                                                 f"{ip.max_stock_age_days}-day limit."))
    if steps:
        pct = max(s[0] for s in steps)
        return Proposal(STRATEGY_INVENTORY, True, q2(cur_price * (ONE - pct)),
                        [s[1] for s in steps] + [f"Bounded markdown step of {pct:.1%} from the current price."],
                        evidence=ev)
    lead = inv.lead_time_days
    if (inv.cover_days is not None and inv.cover_days < ip.low_cover_days and lead is not None
            and inv.cover_days < Decimal(lead) and inv.inbound <= 0):
        return Proposal(
            STRATEGY_INVENTORY, True, q2(cur_price * (ONE + ip.markup_step_pct)),
            [f"Stock cover is {inv.cover_days} days, below the {ip.low_cover_days}-day threshold and shorter than "
             f"the {lead}-day replenishment lead time, with nothing inbound.",
             f"Bounded markup step of {ip.markup_step_pct:.1%} from the current price."], evidence=ev)
    return Proposal(STRATEGY_INVENTORY, False,
                    reasons=["Stock cover and stock age are within the policy's bands."], evidence=ev)


def demand_strategy(ctx: Context) -> Proposal:
    dp, model = ctx.policy.demand, ctx.inp.demand_model
    if not dp.enabled:
        return Proposal(STRATEGY_DEMAND, False, reasons=["Demand-led pricing is not enabled in this policy."])
    if model is None:
        return Proposal(STRATEGY_DEMAND, False,
                        reasons=["No demand estimate exists for this product and channel; the rules baseline applies."])
    ev = model.to_dict()
    if model.status != "validated":
        return Proposal(STRATEGY_DEMAND, False, evidence=ev, reasons=[
            "Demand estimate is not validated (insufficient evidence); the rules baseline applies.", *model.reasons])
    if model.fitted_at is None or ctx.inp.evaluation_time - model.fitted_at > timedelta(days=dp.max_model_age_days):
        return Proposal(STRATEGY_DEMAND, False, evidence=ev,
                        reasons=[f"Demand estimate is older than {dp.max_model_age_days} days; the rules baseline applies."])
    if ctx.interval.conflict or ctx.interval.upper is None:
        return Proposal(STRATEGY_DEMAND, False, evidence=ev,
                        reasons=["Demand-led optimisation needs a bounded feasible interval."])
    from .demand import optimal_price  # SciPy is only needed when this strategy is live

    best = optimal_price(model, ctx.cost, ctx.tax, ctx.interval.lower, ctx.interval.upper,
                         customer_delivery_charge=ctx.inp.customer_delivery_charge)
    ev.update(best["evidence"])
    return Proposal(STRATEGY_DEMAND, True, best["price"], [
        f"Validated demand estimate (elasticity {model.elasticity:.2f}, 95% interval {model.ci_low:.2f} to "
        f"{model.ci_high:.2f}) puts the highest expected contribution within the feasible range at "
        f"{ctx.cur} {best['price']:.2f}.",
        "The estimate is an observational association from past sales, not a proven causal effect.",
    ], evidence=ev)


STRATEGY_FUNCTIONS = {
    STRATEGY_PROMOTION: promotion_strategy,
    STRATEGY_CLEARANCE: clearance_strategy,
    STRATEGY_DEMAND: demand_strategy,
    STRATEGY_COMPETITOR: competitor_strategy,
    STRATEGY_INVENTORY: inventory_strategy,
    STRATEGY_MARGIN: margin_strategy,
}
