# PRICEFLEX — Dynamic Pricing Engine

PRICEFLEX recommends, evaluates, approves and publishes product prices from
costs, inventory, demand, comparable competitor offers and explicit business
constraints. It is a Django modular monolith around a deterministic,
Django-free pricing engine.

```
Ingest → validate → eligible price range → recommend → explain → simulate → approve → publish → verify → monitor
```

Every decision references the exact input snapshot, policy version, algorithm
version and evaluation time, and can be replayed to the same answer.

> All demonstration data is fictional. Sales history is synthetic, competitor
> offers come from a simulated Price Watch, and the storefront is simulated.
> PRICEFLEX has not been reviewed for any jurisdiction's consumer-pricing,
> promotion, contractual or competition rules; see
> [docs/governance.md](docs/governance.md) before any live use.

## What is in the box

| Area | Where |
|---|---|
| Pricing engine (pure Python: money, constraints, strategies, evaluation, explanations, demand, simulation) | `engine/` |
| Price Watch adapter, simulated Price Watch, storefront adapter contract | `adapters/` |
| Domain apps: accounts, catalogue, costs, inventory, competitors, policies, recommendations, publishing, simulation, audit | `apps/` |
| REST API v1 | `apps/api/`, [docs/api.md](docs/api.md) |
| Management interface (Django templates, HTMX, responsive CSS) | `apps/web/`, `templates/`, `static/` |
| Demo data and the ten-step demonstration | `fixtures/demo/`, `apps/accounts/demo*.py` |
| Tests | `tests/` |
| Documentation | `docs/` |

## Quick start with Docker Compose

```bash
cp .env.example .env
```

Set `DJANGO_SECRET_KEY`, `POSTGRES_PASSWORD` and `PRICEFLEX_DEMO_PASSWORD` in
`.env` (for a local trial also set `DJANGO_DEBUG=true`, which allows plain-HTTP
session cookies), then:

```bash
docker compose up --build
```

```bash
docker compose exec web python manage.py run_demo
```

Open <http://localhost:8000> and sign in as one of the demo users below with
the password you set in `PRICEFLEX_DEMO_PASSWORD`.

Services: `db` (PostgreSQL 16), `redis` (Redis 7), `web` (gunicorn, runs
migrations on start), `worker` (Celery) and `beat` (Celery beat schedule).

## Quick start without Docker

Requires Python 3.13, PostgreSQL 15+ and Redis 6+.

```bash
python3.13 -m venv .venv && . .venv/bin/activate
```

```bash
pip install -r requirements.lock -r requirements-dev.lock
```

```bash
createuser --createdb --pwprompt priceflex && createdb --owner priceflex priceflex
```

```bash
cp .env.example .env
```

Fill in `.env`, export it into your shell (`set -a; . ./.env; set +a`), then:

```bash
python manage.py migrate
```

```bash
python manage.py run_demo
```

```bash
python manage.py runserver
```

Background work (scheduled evaluation, scheduled publication, reconciliation,
storefront monitoring, Price Watch import):

```bash
celery -A config worker --loglevel INFO
```

```bash
celery -A config beat --loglevel INFO
```

## The demonstration

`python manage.py run_demo` resets the demo organisation, seeds 20 fictional
electronics products (22 variants, 31 channel listings) and three simulated
competitors, then walks the ten steps and prints what the services actually
did: import costs and inventory → retrieve Price Watch observations → generate
recommendations → inspect explanations → simulate alternatives → approve →
publish to the mock storefront → verify observed prices → record synthetic
sales → compare realised contribution with projections.

`python manage.py seed_demo --reset` creates only the starting state.

| User | Roles | Notes |
|---|---|---|
| `ada.admin` | admin | also a Django superuser (`/admin/`) |
| `ana.analyst` | analyst | imports data, runs evaluations and simulations |
| `pol.editor` | policy editor | revises policies |
| `apo.approver` | approver | approves and rejects |
| `pub.publisher` | publisher | publishes, reconciles, pauses, rolls back |
| `mia.marketplace` | analyst, approver | limited to the `marketplace` channel |

The scenario each product demonstrates is listed in [docs/demo.md](docs/demo.md).

## Using the API

```bash
python manage.py drf_create_token ana.analyst
```

```bash
curl -H "Authorization: Token <token>" http://localhost:8000/api/v1/recommendations?status=awaiting_approval
```

The full contract — authentication, organisation ownership, validation,
pagination, idempotency, concurrency and errors — is in
[docs/api.md](docs/api.md).

## Running the engine on its own

`engine/` imports nothing from Django. See the runnable example in
[docs/pricing-engine.md](docs/pricing-engine.md); in short:

```python
from engine.evaluation import evaluate
from engine.types import EvaluationInput

result = evaluate(EvaluationInput.from_dict(snapshot))   # snapshot = a stored input snapshot payload
print(result.outcome, result.recommended_price, result.reasons)
```

## Tests and checks

```bash
python -m pytest
```

```bash
ruff check .
```

```bash
python manage.py check && python manage.py makemigrations --check --dry-run
```

Tests need a reachable PostgreSQL whose role may create databases; the
concurrency tests rely on real row locks. Results from the build environment
are recorded in [docs/verification.md](docs/verification.md).

## Dependencies

Pinned in `pyproject.toml`; the full resolved set is in `requirements.lock`.

| Package | Version | Used for |
|---|---|---|
| Python | 3.13 | |
| Django | 5.2.19 (LTS series) | application, auth, admin, interface |
| Django REST Framework | 3.17.2 | versioned API |
| psycopg (binary) | 3.3.9 | PostgreSQL driver |
| Celery / redis-py | 5.7.0 / 8.2.0 | scheduled evaluation, background publication |
| pandas / NumPy | 3.1.1 / 2.5.5 | realised-results analysis, demand estimation |
| SciPy | 1.18.1 | bounded price optimisation, simulator demand draws |
| WhiteNoise / gunicorn | 6.12.0 / 27.0.1 | static files, WSGI server |
| htmx | 2.0.11 (vendored in `static/vendor/`) | interactive screens |

How these were verified is stated in [docs/verification.md](docs/verification.md).

## Implemented, simulated, deferred

**Implemented**

- Decimal cost and margin engine: tax configured per region and category,
  fees on their real charging basis, recoverable tax kept out of cost, gross
  margin / contribution margin / markup / operating profit kept distinct.
- Floors and ceilings from every listed constraint, conflict reporting instead
  of silent override, price endings applied after feasibility and re-validated.
- Five transparent strategies with deterministic precedence and a recorded
  selection trace; stability controls; explicit, policy-controlled fallbacks.
- Structured explanations for every outcome, including "no change".
- Versioned policies, immutable input snapshots, reproducibility replay.
- Approval workflow with all required states, overrides validated against hard
  constraints, bounded automation that must be configured *and* authorised.
- Publication with pre-publication re-checks, compare-and-set, idempotency
  keys, recorded external responses, read-back verification, reconciliation,
  pause switch and audited rollback.
- Role, organisation and channel permissions; append-only audit log enforced by
  a PostgreSQL trigger.
- REST API v1, management interface, Celery tasks, Docker Compose deployment.
- Optional demand estimation with validation gates; isolated backtesting
  simulator with an explicit demand model and no future-data leakage.

**Simulated (clearly labelled wherever shown)**

- The storefront (`apps/publishing/mock_storefront.py`), including fault
  injection, a displayed price that can lag, and locked quotes.
- Price Watch content (`adapters/pricewatch_simulated.py`). The adapter itself
  and its HTTP client target the real Price Watch v1 contract, but were
  exercised only against the simulation here.
- All demo sales, costs, products, competitors and users.

**Deferred**

- A production storefront adapter for a real commerce platform.
- Currency conversion (mismatched currencies block; nothing is converted).
- Automated experiment assignment and significance testing (experiments record
  groups and report realised results only).
- AI-drafted explanations or policy proposals (none is implemented; the
  position on how one would be constrained is in the governance document).
- Single sign-on, per-user API throttling tiers, OpenAPI schema generation.
- Legal and compliance review for any market, which is a prerequisite for live
  use and outside what software can supply.
