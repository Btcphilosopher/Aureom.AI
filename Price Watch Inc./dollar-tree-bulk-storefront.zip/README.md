# Dollar Tree Bulk Storefront Concept

An independent bulk-shopping e-commerce concept featuring case-pack pricing, upfront consumer unit pricing, live inventory reservations, business bulk ordering (SKU & CSV), checkout simulation, and role-based fulfilment administration.

> **Disclaimer:** Independent website concept using illustrative products, case counts, policies, and prices. Branding is configurable via `NEXT_PUBLIC_BRAND_NAME`.

## Architecture Overview

- **Storefront & Admin UI**: Next.js 15 App Router, React 19, TypeScript, Tailwind CSS v4.
- **Standalone / Preview Full-Stack Engine**: Next.js API Routes backed by transactional SQLite (`node:sqlite` with `BEGIN IMMEDIATE` locking, versioned SQL migrations, and background reservation expiry worker).
- **Production Service Stack (`/backend` + `docker-compose.yml`)**: Python 3.11, FastAPI modular monolith, SQLAlchemy 2.0 + `psycopg3`, PostgreSQL 16 (`SELECT ... FOR UPDATE`), Alembic migrations, dedicated background worker (`app/worker.py`), and S3-compatible MinIO object storage.

## Local Development

### Option A: Single-Command Next.js Full-Stack Run (Preview / Local)
```bash
npm install
npm run dev
```
Visit `http://localhost:3000`. The database (`data/storefront.db`) automatically runs migrations and seeds 26 illustrative SKUs across all categories on first request.

### Option B: Full Docker Compose Stack (PostgreSQL + MinIO S3 + FastAPI + Worker + Next.js)
1. Copy `.env.example` to `.env` and populate secrets (`POSTGRES_PASSWORD`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `PAYMENT_WEBHOOK_SECRET`).
2. Start all services:
```bash
docker compose up --build
```
- Storefront: `http://localhost:3000`
- FastAPI OpenAPI docs: `http://localhost:8000/docs`
- MinIO Console: `http://localhost:9001`

## Database Migrations

### SQLite (Standalone Next.js)
Versioned migrations in `lib/migrations.ts` run automatically at startup and are tracked in `schema_migrations`.

### PostgreSQL (FastAPI / Docker)
```bash
cd backend
alembic upgrade head
```

## Backup & Restoration

### SQLite Backup & Restore
```bash
# Consistent online backup using SQLite backup API
node -e "const { DatabaseSync } = require('node:sqlite'); const db = new DatabaseSync('data/storefront.db'); db.exec(\"VACUUM INTO 'data/backup-storefront.db'\");"

# Restore (stop server first)
cp data/backup-storefront.db data/storefront.db
```

### PostgreSQL Backup & Restore
```bash
# Create compressed logical backup
pg_dump -Fc -h localhost -U postgres -d dollartree_bulk -f backup_dollartree.dump

# Restore to a clean database
pg_restore -h localhost -U postgres -d dollartree_bulk --clean --if-exists backup_dollartree.dump
```

## Security Safeguards

- Server-side `scrypt` password hashing with per-user salts and `timingSafeEqual` verification.
- `HttpOnly; SameSite=None; Secure; Partitioned` session cookies and SHA-256 hashed server session tokens.
- First-run admin claim form (`POST /api/auth/bootstrap-admin`) that locks once an administrator is claimed.
- Strict server-side RBAC (`catalogue_manager`, `fulfilment_staff`, `customer_service`, `admin`) and account-scoped order access.
- Formula-injection-safe CSV exports (`lib/csv.ts`) and magic-byte-verified image uploads confined to `public/uploads/`.
- Structured JSON logging with automatic redaction of credentials, tokens, and payment secrets (`lib/logger.ts`).
