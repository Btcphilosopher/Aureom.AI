# Dollar Tree Bulk Storefront — API Documentation

All monetary figures use integer USD cents (`case_price_cents`, `unit_price_cents`, `total_cents`). Displayed consumer unit prices are derived from the authoritative `case_price_cents` using half-up integer rounding (`round(case_price_cents / consumer_units_per_case)`).

## 1. Catalogue & Product Endpoints

### `GET /api/catalogue`
Search, filter, and sort bulk case SKUs.
- **Query params**:
  - `q`: Search keyword across title, subtitle, description, brand, category, and SKU (max 100 chars).
  - `category`: Category slug (`cleaning`, `kitchen-dining`, `party-supplies`, `office-school`, `seasonal`, `business-supplies`).
  - `chip`: `all | under2 | business | party`.
  - `under2`: `true` filters on consumer selling unit price `< $2.00` (`unitPriceCents < 200`).
  - `minCasePrice` / `maxCasePrice`: Case price bounds in USD.
  - `minUnitsPerCase`: Minimum consumer units per shipping case.
  - `fulfilmentMethod`: `delivery | pickup`.
  - `locationId`: Location ID (`LOC-DC-EAST`, `LOC-DC-MID`, `LOC-STR-104`, `LOC-STR-218`).
  - `inStockOnly`: `true` filters for `availableCases > 0`.
  - `sort`: `relevance | unit_price_asc | unit_price_desc | case_price_asc | case_price_desc | name_asc`.

### `GET /api/products/{sku}`
Returns SKU detail, packaging breakdown (`unitPriceLabel`, `caseContentsLabel`, `totalIndividualItemsPerCase`), family variants, location-by-location ATP availability, and related SKUs.

## 2. Cart & Bulk Ordering Endpoints

### `GET /api/cart`
Returns active cart lines, saved-for-later lines, total cases, total consumer units, merchandise subtotal, and price/stock revalidation notices. Persists guest carts via `dt_guest_cart` `HttpOnly` cookie.

### `POST /api/cart`
- `action: "add" | "set"` with `{ sku, cases }` (validates `minCaseQuantity`, `caseIncrement`, and `maxCartCasesPerSku`; does **not** reserve inventory).
- `action: "save_for_later" | "move_to_cart"` with `{ sku }`.
- `action: "accept_prices"` acknowledges updated catalogue prices.
- `action: "fulfilment"` with `{ fulfilmentMethod, locationId, destinationState, destinationZip }`.

### `POST /api/bulk-order/validate`
Validates either `csvText` (`sku,cases` header, max 2 MB, max 500 rows) or `items: [{ sku, cases }]`.
- When `commit: false`, returns pre-cart review results (`reviewItems`, `parseErrors`, `summary`) without modifying the cart.
- When `commit: true`, applies valid lines to the cart.

### `POST /api/bulk-order/export`
Generates a downloadable `text/csv` summary with spreadsheet formula-injection sanitization (prefixes cells beginning with `=`, `+`, `-`, `@`, `\t`, `\r` with `'`).

## 3. Checkout & Payment Endpoints

### `POST /api/checkout/quote`
Server-side calculation of merchandise subtotal, discounts, delivery fee ($14.95 under $250.00, free at $250.00+, $0 for store pickup), demonstration tax estimate by state, and single-location eligibility verification.

### `POST /api/checkout/attempt`
Idempotent (`idempotencyKey`) transactional reservation & order attempt creation. Runs inside `BEGIN IMMEDIATE` (or `SELECT ... FOR UPDATE` in PostgreSQL), verifies ATP stock, increments `reserved_cases`, creates expiring `stock_reservations` (default 15 minutes), and stores immutable `order_items` snapshots. Returns `409 Conflict` if stock is insufficient.

### `POST /api/payments/simulate` & `POST /api/payments/webhook`
Processes `payment.succeeded` or `payment.failed` events using HMAC-SHA256 signature verification (`x-webhook-signature`) and `provider_event_id` deduplication.
- Active reservation -> commits stock (`on_hand -= qty`, `reserved -= qty`) and confirms order.
- Expired reservation with available stock -> reallocates & confirms.
- Expired reservation without available stock -> marks `reconciliation_required`, sets `payment_status = refunded`, and records an automatic refund.

## 4. Account, Orders & Administration Endpoints

- `POST /api/auth/register` & `POST /api/auth/login` — `scrypt` password hashing, `HttpOnly` session cookies, and deterministic guest cart merge on sign-in.
- `POST /api/auth/bootstrap-admin` — One-time first-run admin setup (locks once claimed).
- `GET/POST /api/account` — Saved addresses, business purchasing lists, repeat templates, and user order history.
- `GET/POST /api/orders/{id}` — Account- or guest-token-scoped order receipt, live-price reorder, and cancellation requests.
- `GET /api/admin/overview`, `POST/PATCH /api/admin/products`, `POST /api/admin/inventory`, `POST /api/admin/orders/{id}/transition`, `POST /api/admin/orders/{id}/refund`, `PATCH /api/admin/banners`, `POST /api/admin/staff`, `POST /api/admin/upload`, `POST /api/internal/worker/sweep` — Role-protected staff endpoints (`catalogue_manager`, `fulfilment_staff`, `customer_service`, `admin`).
