import { STATE_TAX_RATE_BPS, STORE_CONFIG } from './config';

/**
 * Authoritative monetary arithmetic uses integer USD cents.
 * Displayed consumer unit price is derived from authoritative case_price_cents:
 *   unitPriceCents = Math.round(casePriceCents / consumerUnitsPerCase)
 * (Half-up rounding to the nearest cent when casePriceCents % consumerUnitsPerCase !== 0.)
 */
export function deriveConsumerUnitPriceCents(
  casePriceCents: number,
  consumerUnitsPerCase: number
): number {
  if (consumerUnitsPerCase <= 0) {
    throw new Error('consumerUnitsPerCase must be positive');
  }
  if (!Number.isInteger(casePriceCents) || casePriceCents < 0) {
    throw new Error('casePriceCents must be a non-negative integer');
  }
  // Standard half-up rounding in integer arithmetic:
  return Math.floor((casePriceCents + Math.floor(consumerUnitsPerCase / 2)) / consumerUnitsPerCase);
}

export function formatUsd(cents: number): string {
  const negative = cents < 0;
  const abs = Math.abs(Math.round(cents));
  const dollars = (abs / 100).toFixed(2);
  return `${negative ? '-' : ''}$${dollars}`;
}

export interface PackagingBreakdown {
  consumerSellingUnit: string;
  itemsPerConsumerPack: number | null;
  consumerUnitsPerCase: number;
  totalIndividualItemsPerCase: number;
  unitPriceCents: number;
  casePriceCents: number;
  unitPriceLabel: string;
  caseContentsLabel: string;
  casePriceLabel: string;
}

export function computePackagingBreakdown(params: {
  consumerSellingUnit: string;
  itemsPerConsumerPack: number | null;
  consumerUnitsPerCase: number;
  casePriceCents: number;
}): PackagingBreakdown {
  const { consumerSellingUnit, itemsPerConsumerPack, consumerUnitsPerCase, casePriceCents } = params;
  const unitPriceCents = deriveConsumerUnitPriceCents(casePriceCents, consumerUnitsPerCase);
  const totalIndividualItemsPerCase =
    itemsPerConsumerPack && itemsPerConsumerPack > 1
      ? consumerUnitsPerCase * itemsPerConsumerPack
      : consumerUnitsPerCase;

  const unitLabelNoun = consumerSellingUnit;
  const pluralMap: Record<string, string> = {
    bottle: 'bottles',
    pack: 'packs',
    bag: 'bags',
    notebook: 'notebooks',
    container: 'containers',
    roll: 'rolls',
    box: 'boxes',
    pan: 'pans',
    set: 'sets',
    pad: 'pads',
    item: 'items',
  };
  const pluralUnit = pluralMap[unitLabelNoun] || `${unitLabelNoun}s`;

  let caseContentsLabel = `${consumerUnitsPerCase} ${pluralUnit} per case`;
  if (consumerSellingUnit === 'pack' && itemsPerConsumerPack && itemsPerConsumerPack > 1) {
    caseContentsLabel = `${consumerUnitsPerCase} packs per case · ${totalIndividualItemsPerCase} items total`;
  }

  return {
    consumerSellingUnit,
    itemsPerConsumerPack,
    consumerUnitsPerCase,
    totalIndividualItemsPerCase,
    unitPriceCents,
    casePriceCents,
    unitPriceLabel: `${formatUsd(unitPriceCents)} / ${unitLabelNoun}`,
    caseContentsLabel,
    casePriceLabel: `${formatUsd(casePriceCents)} / case`,
  };
}

export function validateCaseQuantity(
  qty: number,
  minCases: number,
  increment: number,
  maxCases = STORE_CONFIG.maxCartCasesPerSku
): { valid: boolean; reason?: string; normalized?: number } {
  if (!Number.isInteger(qty) || qty <= 0) {
    return { valid: false, reason: 'Case quantity must be a positive whole number.' };
  }
  if (qty < minCases) {
    return { valid: false, reason: `Minimum order is ${minCases} case(s).` };
  }
  if ((qty - minCases) % increment !== 0) {
    return {
      valid: false,
      reason: `Must be ordered in increments of ${increment} case(s) starting at ${minCases}.`,
    };
  }
  if (qty > maxCases) {
    return { valid: false, reason: `Maximum ${maxCases} cases per SKU per order.` };
  }
  return { valid: true, normalized: qty };
}

export function calculateOrderTotals(params: {
  lineSubtotalsCents: number[];
  fulfilmentMethod: 'delivery' | 'pickup';
  destinationState?: string | null;
  discountCents?: number;
}) {
  const merchandiseSubtotalCents = params.lineSubtotalsCents.reduce((sum, n) => sum + n, 0);
  const discountCents = Math.min(
    merchandiseSubtotalCents,
    Math.max(0, Math.round(params.discountCents || 0))
  );
  const taxableMerchandise = merchandiseSubtotalCents - discountCents;

  let deliveryFeeCents = 0;
  if (params.fulfilmentMethod === 'delivery' && taxableMerchandise > 0) {
    deliveryFeeCents =
      taxableMerchandise >= STORE_CONFIG.freeDeliveryThresholdCents
        ? 0
        : STORE_CONFIG.defaultDeliveryBaseFeeCents;
  }

  const stateCode = (params.destinationState || 'NJ').trim().toUpperCase();
  const taxRateBps = STATE_TAX_RATE_BPS[stateCode] ?? 650;
  // Demonstration tax applies to merchandise subtotal after discount
  const taxCents = Math.round((taxableMerchandise * taxRateBps) / 10000);
  const totalCents = taxableMerchandise + deliveryFeeCents + taxCents;

  return {
    merchandiseSubtotalCents,
    discountCents,
    deliveryFeeCents,
    taxRateBps,
    taxCents,
    totalCents,
    taxEstimateNote: STORE_CONFIG.demoPolicies.taxDisclaimer,
  };
}
