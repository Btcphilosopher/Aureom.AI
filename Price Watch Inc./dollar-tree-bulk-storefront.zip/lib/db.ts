import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { runMigrations } from './migrations';
import { seedCatalogueIfEmpty } from './seed';

const globalForDb = globalThis as unknown as {
  __storefrontDb?: DatabaseSync;
  __storefrontDbPath?: string;
};

export function getDbPath(): string {
  if (process.env.STOREFRONT_DB_PATH) {
    return process.env.STOREFRONT_DB_PATH;
  }
  return path.join(process.cwd(), 'data', 'storefront.db');
}

export function getDb(): DatabaseSync {
  const targetPath = getDbPath();
  if (globalForDb.__storefrontDb && globalForDb.__storefrontDbPath === targetPath) {
    return globalForDb.__storefrontDb;
  }

  if (targetPath !== ':memory:') {
    fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  }

  const db = new DatabaseSync(targetPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec('PRAGMA foreign_keys = ON;');

  runMigrations(db);
  seedCatalogueIfEmpty(db);

  globalForDb.__storefrontDb = db;
  globalForDb.__storefrontDbPath = targetPath;
  return db;
}

export function withTransaction<T>(db: DatabaseSync, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch {
      // ignore rollback failure if already rolled back
    }
    throw err;
  }
}
