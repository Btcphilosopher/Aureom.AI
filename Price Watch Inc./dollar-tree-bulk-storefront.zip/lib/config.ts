export interface DemoPolicyConfig {
  cancellationWindowNote: string;
  returnPolicyNote: string;
  businessPaymentTermsNote: string;
  taxDisclaimer: string;
}

export const STORE_CONFIG = {
  brandName: process.env.NEXT_PUBLIC_BRAND_NAME || 'Dollar Tree',
  conceptDisclaimer:
    process.env.NEXT_PUBLIC_CONCEPT_DISCLAIMER ||
    'Independent website concept · Illustrative products and prices',
  currency: 'USD' as const,
  reservationTtlMinutes: 15,
  maxCartCasesPerSku: 50,
  maxCartTotalCases: 200,
  maxCartLineCount: 50,
  maxSearchQueryLength: 100,
  maxCsvBytes: 2 * 1024 * 1024, // 2 MB
  maxCsvRows: 500,
  maxImageUploadBytes: 4 * 1024 * 1024, // 4 MB
  defaultDeliveryBaseFeeCents: 1495, // $14.95 base case delivery
  freeDeliveryThresholdCents: 25000, // $250.00+ free delivery
  demoPolicies: {
    cancellationWindowNote:
      'Demonstration policy: Unfulfilled orders may request cancellation before dispatch. Once a delivery order reaches Dispatched, cancellation is replaced by a return/refund request.',
    returnPolicyNote:
      'Demonstration policy: Full unopened shipping cases may be returned within 30 days of delivery or collection for a full or partial demonstration refund. These are configurable demonstration rules and do not represent Dollar Tree’s actual store policies.',
    businessPaymentTermsNote:
      'Purchase-order references are recorded on receipts and order summaries for internal reconciliation. All demonstration orders remain prepaid unless an approved credit workflow is explicitly enabled.',
    taxDisclaimer:
      'Demonstration tax estimate calculated server-side from destination state rate; final tax may vary by local jurisdiction.',
  } satisfies DemoPolicyConfig,
};

export const NAVIGATION_CATEGORIES = [
  { slug: 'all', name: 'Shop All' },
  { slug: 'party-supplies', name: 'Party Supplies' },
  { slug: 'cleaning', name: 'Cleaning' },
  { slug: 'kitchen-dining', name: 'Kitchen & Dining' },
  { slug: 'office-school', name: 'Office & School' },
  { slug: 'seasonal', name: 'Seasonal' },
  { slug: 'business-supplies', name: 'Business Supplies' },
] as const;

export const STATE_TAX_RATE_BPS: Record<string, number> = {
  NJ: 663, // 6.625% rounded bps for demo
  NY: 800,
  PA: 600,
  CT: 635,
  MA: 625,
  VA: 530,
  MD: 600,
  DE: 0,
  IL: 625,
  OH: 575,
  MI: 600,
  IN: 700,
  WI: 500,
  MO: 423,
};

export type StaffRole =
  | 'customer'
  | 'catalogue_manager'
  | 'fulfilment_staff'
  | 'customer_service'
  | 'admin';

export const STAFF_ROLES: StaffRole[] = [
  'catalogue_manager',
  'fulfilment_staff',
  'customer_service',
  'admin',
];

export const DELIVERY_TRANSITIONS: Record<string, string[]> = {
  unfulfilled: ['picking', 'cancelled'],
  picking: ['packed', 'cancelled'],
  packed: ['dispatched'],
  dispatched: ['delivered'],
  delivered: [],
  cancelled: [],
};

export const PICKUP_TRANSITIONS: Record<string, string[]> = {
  unfulfilled: ['picking', 'cancelled'],
  picking: ['ready_for_pickup', 'cancelled'],
  ready_for_pickup: ['collected', 'cancelled'],
  collected: [],
  cancelled: [],
};
