import crypto from 'node:crypto';
import { cookies } from 'next/headers';
import type { NextResponse } from 'next/server';
import { getDb, withTransaction } from './db';
import { STAFF_ROLES, type StaffRole } from './config';

export const SESSION_COOKIE_NAME = 'dt_session';
export const GUEST_CART_COOKIE_NAME = 'dt_guest_cart';

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: StaffRole;
  companyName: string;
  taxId: string;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, expectedHex] = parts;
  const actualBuf = crypto.scryptSync(password, salt, 64);
  const expectedBuf = Buffer.from(expectedHex, 'hex');
  if (actualBuf.length !== expectedBuf.length) return false;
  return crypto.timingSafeEqual(actualBuf, expectedBuf);
}

export function hashToken(rawToken: string): string {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

export function isStaffBootstrapRequired(): boolean {
  if (process.env.ADMIN_BOOTSTRAP_PASSCODE && process.env.ADMIN_BOOTSTRAP_PASSCODE.trim().length > 0) {
    return false;
  }
  const db = getDb();
  const row = db
    .prepare("SELECT COUNT(*) as cnt FROM users WHERE role = 'admin'")
    .get() as { cnt: number };
  return row.cnt === 0;
}

export function createSessionForUser(userId: string, role: StaffRole): {
  rawToken: string;
  expiresAt: string;
} {
  const db = getDb();
  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = hashToken(rawToken);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString();

  db.prepare(
    'INSERT INTO sessions (token_hash, user_id, role, expires_at, created_at) VALUES (?, ?, ?, ?, ?)'
  ).run(tokenHash, userId, role, expiresAt, now.toISOString());

  return { rawToken, expiresAt };
}

export function attachSessionCookie(res: NextResponse, rawToken: string): void {
  res.cookies.set(SESSION_COOKIE_NAME, rawToken, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    partitioned: true,
    path: '/',
    maxAge: 7 * 24 * 60 * 60,
  });
}

export function clearSessionCookie(res: NextResponse): void {
  res.cookies.set(SESSION_COOKIE_NAME, '', {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    partitioned: true,
    path: '/',
    maxAge: 0,
  });
}

export async function getAuthenticatedUser(req?: Request): Promise<AuthUser | null> {
  const db = getDb();
  let rawToken: string | undefined;

  if (req) {
    const authHeader = req.headers.get('authorization');
    if (authHeader && authHeader.startsWith('Bearer ')) {
      rawToken = authHeader.slice(7).trim();
    }
    if (!rawToken) {
      const cookieHeader = req.headers.get('cookie') || '';
      const match = cookieHeader
        .split(';')
        .map((c) => c.trim())
        .find((c) => c.startsWith(`${SESSION_COOKIE_NAME}=`));
      if (match) {
        rawToken = decodeURIComponent(match.split('=').slice(1).join('='));
      }
    }
  } else {
    const cookieStore = await cookies();
    rawToken = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  }

  if (!rawToken) return null;

  const tokenHash = hashToken(rawToken);
  const row = db
    .prepare(
      `SELECT u.id, u.email, u.name, u.role, u.company_name, u.tax_id, s.expires_at
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ?`
    )
    .get(tokenHash) as
    | {
        id: string;
        email: string;
        name: string;
        role: StaffRole;
        company_name: string;
        tax_id: string;
        expires_at: string;
      }
    | undefined;

  if (!row) return null;
  if (new Date(row.expires_at).getTime() <= Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
    return null;
  }

  return {
    id: row.id,
    email: row.email,
    name: row.name,
    role: row.role,
    companyName: row.company_name,
    taxId: row.tax_id,
  };
}

export function isStaffRole(role: StaffRole): boolean {
  return STAFF_ROLES.includes(role);
}

export function requireStaffRole(
  user: AuthUser | null,
  allowedRoles: StaffRole[]
): { ok: true; user: AuthUser } | { ok: false; status: number; error: string } {
  if (!user) {
    return { ok: false, status: 401, error: 'Authentication required.' };
  }
  if (user.role === 'admin' || allowedRoles.includes(user.role)) {
    return { ok: true, user };
  }
  return {
    ok: false,
    status: 403,
    error: `Role "${user.role}" does not have permission for this action.`,
  };
}

export function verifyMutationOrigin(req: Request): boolean {
  // If Authorization Bearer is explicitly provided, CSRF cookie risk doesn't apply
  if (req.headers.get('authorization')?.startsWith('Bearer ')) {
    return true;
  }
  const origin = req.headers.get('origin');
  const xRequestedWith = req.headers.get('x-requested-with');
  if (xRequestedWith) return true;
  if (!origin) return true; // same-origin curl/server fetch without Origin
  const host = req.headers.get('x-forwarded-host') || req.headers.get('host');
  if (!host) return true;
  try {
    const parsedOrigin = new URL(origin);
    return parsedOrigin.host === host;
  } catch {
    return false;
  }
}

export function bootstrapFirstAdmin(params: {
  email: string;
  name: string;
  password: string;
}): AuthUser {
  const db = getDb();
  const normalizedEmail = params.email.trim().toLowerCase();
  return withTransaction(db, () => {
    const existingAdmin = db
      .prepare("SELECT COUNT(*) as cnt FROM users WHERE role = 'admin'")
      .get() as { cnt: number };
    if (existingAdmin.cnt > 0) {
      throw new Error('Admin account has already been claimed.');
    }

    const now = new Date().toISOString();
    const adminId = `USR-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const pwHash = hashPassword(params.password);

    db.prepare(
      'INSERT INTO users (id, email, name, password_hash, role, company_name, tax_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(adminId, normalizedEmail, params.name.trim(), pwHash, 'admin', 'Storefront Operations', '', now);

    db.prepare(
      'INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      `AUD-${crypto.randomUUID().slice(0, 10)}`,
      adminId,
      normalizedEmail,
      'admin',
      'admin.bootstrap_claimed',
      'user',
      adminId,
      JSON.stringify({ email: normalizedEmail }),
      now
    );

    return {
      id: adminId,
      email: normalizedEmail,
      name: params.name.trim(),
      role: 'admin',
      companyName: 'Storefront Operations',
      taxId: '',
    };
  });
}
