import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { GUEST_CART_COOKIE_NAME } from './auth';

export function attachGuestCartCookie(res: NextResponse, guestToken: string): void {
  if (!guestToken) return;
  res.cookies.set(GUEST_CART_COOKIE_NAME, guestToken, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    partitioned: true,
    path: '/',
    maxAge: 30 * 24 * 60 * 60,
  });
}

export async function readGuestCartToken(req?: Request): Promise<string | null> {
  if (req) {
    const cookieHeader = req.headers.get('cookie') || '';
    const match = cookieHeader
      .split(';')
      .map((c) => c.trim())
      .find((c) => c.startsWith(`${GUEST_CART_COOKIE_NAME}=`));
    if (match) {
      return decodeURIComponent(match.split('=').slice(1).join('='));
    }
    return null;
  }
  const store = await cookies();
  return store.get(GUEST_CART_COOKIE_NAME)?.value ?? null;
}

export function jsonError(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}
