import type { DatabaseSync } from 'node:sqlite';

interface SeedFamily {
  id: string;
  slug: string;
  name: string;
  brand: string;
  categoryId: string;
  description: string;
  isAssorted: boolean;
  assortedSelectionNote: string;
  requiresVariantSelection: boolean;
  tags: string[];
  featuredOrder: number;
}

interface SeedSku {
  sku: string;
  familyId: string;
  title: string;
  subtitle: string;
  description: string;
  images: string[];
  variantAttributes: Record<string, string>;
  consumerSellingUnit: string;
  itemsPerConsumerPack: number | null;
  consumerUnitsPerCase: number;
  casePriceCents: number;
  minCaseQuantity?: number;
  caseIncrement?: number;
  weightOz: number;
  dimensionsIn: string;
  deliveryEligible: boolean;
  pickupEligible: boolean;
  stockByLocation: Record<string, number>;
}

export function seedCatalogueIfEmpty(db: DatabaseSync): void {
  const existing = db.prepare('SELECT COUNT(*) as cnt FROM skus').get() as { cnt: number };
  if (existing.cnt > 0) return;

  const now = new Date().toISOString();

  db.exec('BEGIN IMMEDIATE');
  try {
    // 1. Categories matching navigation bar
    const categories = [
      { id: 'cat-cleaning', slug: 'cleaning', name: 'Cleaning', description: 'Dish soaps, sprays, trash bags, and janitorial supplies by the case.', sort: 1 },
      { id: 'cat-kitchen', slug: 'kitchen-dining', name: 'Kitchen & Dining', description: 'Paper cups, food storage, aluminum pans, and table essentials.', sort: 2 },
      { id: 'cat-party', slug: 'party-supplies', name: 'Party Supplies', description: 'Gift bags, tableware sets, balloons, and event bulk packs.', sort: 3 },
      { id: 'cat-office', slug: 'office-school', name: 'Office & School', description: 'Spiral notebooks, composition books, pens, and classroom supplies.', sort: 4 },
      { id: 'cat-seasonal', slug: 'seasonal', name: 'Seasonal', description: 'Holiday wrap, seasonal ribbon, and rotating event packs.', sort: 5 },
      { id: 'cat-business', slug: 'business-supplies', name: 'Business Supplies', description: 'Shipping boxes, mailers, breakroom consumables, and facility packs.', sort: 6 },
    ];

    const insertCat = db.prepare(
      'INSERT INTO categories (id, slug, name, description, sort_order, active) VALUES (?, ?, ?, ?, ?, 1)'
    );
    for (const c of categories) {
      insertCat.run(c.id, c.slug, c.name, c.description, c.sort);
    }

    // 2. Locations (2 delivery hubs + 2 store pickup locations)
    const locations = [
      {
        id: 'LOC-DC-EAST',
        code: 'DC-EAST-01',
        name: 'Northeast Regional Distribution Hub',
        type: 'warehouse',
        address: '450 Logistics Parkway',
        city: 'Edison',
        state: 'NJ',
        zip: '08817',
        eligibleStates: ['NJ', 'NY', 'PA', 'CT', 'MA', 'VA', 'MD', 'DE'],
        leadHours: 24,
      },
      {
        id: 'LOC-DC-MID',
        code: 'DC-MID-02',
        name: 'Midwest Regional Distribution Hub',
        type: 'warehouse',
        address: '1200 Freight Center Dr',
        city: 'Joliet',
        state: 'IL',
        zip: '60433',
        eligibleStates: ['IL', 'OH', 'MI', 'IN', 'WI', 'MO'],
        leadHours: 24,
      },
      {
        id: 'LOC-STR-104',
        code: 'STORE-104',
        name: 'Cherry Hill Plaza Store #104',
        type: 'store',
        address: '2100 Route 38 East',
        city: 'Cherry Hill',
        state: 'NJ',
        zip: '08002',
        eligibleStates: ['NJ'],
        leadHours: 4,
      },
      {
        id: 'LOC-STR-218',
        code: 'STORE-218',
        name: 'Springfield Commons Store #218',
        type: 'store',
        address: '6400 Springfield Blvd',
        city: 'Springfield',
        state: 'VA',
        zip: '22150',
        eligibleStates: ['VA'],
        leadHours: 4,
      },
    ];

    const insertLoc = db.prepare(
      'INSERT INTO locations (id, code, name, type, address, city, state, zip, eligible_states_json, pickup_lead_time_hours, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)'
    );
    for (const loc of locations) {
      insertLoc.run(
        loc.id,
        loc.code,
        loc.name,
        loc.type,
        loc.address,
        loc.city,
        loc.state,
        loc.zip,
        JSON.stringify(loc.eligibleStates),
        loc.leadHours
      );
    }

    // 3. Product Families
    const families: SeedFamily[] = [
      {
        id: 'fam-dish-soap',
        slug: 'dish-soap-16oz',
        name: 'Dish Soap, 16 fl oz',
        brand: 'Bright Waves',
        categoryId: 'cat-cleaning',
        description:
          'Concentrated grease-cutting liquid dish soap in 16 fl oz squeeze bottles, packed in sturdy 24-bottle wholesale cases for kitchens, breakrooms, and facilities.',
        isAssorted: false,
        assortedSelectionNote: 'Single scent per SKU. Choose your preferred scent variant before adding cases.',
        requiresVariantSelection: true,
        tags: ['everyday', 'business_favourite'],
        featuredOrder: 1,
      },
      {
        id: 'fam-paper-cups',
        slug: 'paper-cups-12-pack',
        name: 'Paper Cups, 12-count pack',
        brand: 'GreenLeaf Table',
        categoryId: 'cat-kitchen',
        description:
          'Sturdy 9 oz coated disposable paper cups printed with a clean botanical leaf border. Sold in 24 retail 12-count packs per shipping case (288 cups total).',
        isAssorted: false,
        assortedSelectionNote: 'Uniform botanical green-leaf design across all 24 packs in each case.',
        requiresVariantSelection: false,
        tags: ['everyday', 'party_ready', 'business_favourite'],
        featuredOrder: 2,
      },
      {
        id: 'fam-gift-bags',
        slug: 'medium-gift-bags',
        name: 'Medium Gift Bags',
        brand: 'Celebration Craft',
        categoryId: 'cat-party',
        description:
          'Heavyweight 9 × 7 × 4 in medium gift bags with twisted paper handles. Packed in assorted cases of 36 bags ready for events, retail counters, and classroom celebrations.',
        isAssorted: true,
        assortedSelectionNote:
          'Assorted case pack: each 36-bag case includes an even mix of Pink Polka Dot, Blue Chevron, and Lime Solid designs. Individual colours cannot be selected separately.',
        requiresVariantSelection: false,
        tags: ['everyday', 'party_ready'],
        featuredOrder: 3,
      },
      {
        id: 'fam-spiral-notebooks',
        slug: 'spiral-notebooks',
        name: 'Spiral Notebooks',
        brand: 'ScholarLine',
        categoryId: 'cat-office',
        description:
          '70-sheet spiral-bound single-subject notebooks with snag-resistant coil binding and perforated pages. Available in Wide Ruled and College Ruled cases.',
        isAssorted: true,
        assortedSelectionNote:
          'Assorted cover colours (Blue, Emerald, Magenta, Lime) packed evenly inside each 24-notebook case. Ruling type is selected by SKU; individual cover colours cannot be chosen.',
        requiresVariantSelection: true,
        tags: ['everyday', 'business_favourite'],
        featuredOrder: 4,
      },
      {
        id: 'fam-storage-containers',
        slug: 'food-storage-containers',
        name: 'Locking Food Storage Containers',
        brand: 'FreshLock Home',
        categoryId: 'cat-kitchen',
        description:
          'BPA-free clear polypropylene food storage containers with silicone-gasket green snap lids. Microwave, freezer, and top-rack dishwasher safe.',
        isAssorted: false,
        assortedSelectionNote: 'Uniform forest-green lid trim. Select container capacity pack size.',
        requiresVariantSelection: true,
        tags: ['everyday', 'business_favourite'],
        featuredOrder: 5,
      },
      {
        id: 'fam-cleaning-sprays',
        slug: 'multi-surface-cleaner',
        name: 'All-Purpose & Disinfecting Cleaners',
        brand: 'Gleam & SanitizeX',
        categoryId: 'cat-cleaning',
        description:
          'Commercial-value spray and concentrate cleaners packaged in full shipping cases for janitorial teams, schools, and community centers.',
        isAssorted: false,
        assortedSelectionNote: 'Choose spray cleaner or concentrated disinfectant SKU.',
        requiresVariantSelection: true,
        tags: ['everyday', 'business_favourite'],
        featuredOrder: 6,
      },
      {
        id: 'fam-paper-towels',
        slug: 'quilted-paper-towels',
        name: 'Quilted Paper Towel Rolls',
        brand: 'Quilted Home',
        categoryId: 'cat-cleaning',
        description:
          'Two-ply absorbent perforated paper towel rolls packaged for breakrooms, restaurants, and household stocking.',
        isAssorted: false,
        assortedSelectionNote: 'Standard white unprinted sheets.',
        requiresVariantSelection: false,
        tags: ['everyday', 'business_favourite'],
        featuredOrder: 7,
      },
      {
        id: 'fam-trash-bags',
        slug: 'drawstring-trash-bags',
        name: 'Tall Kitchen Drawstring Trash Bags',
        brand: 'Force Grip',
        categoryId: 'cat-cleaning',
        description:
          '13-gallon tear-resistant drawstring liners packed in retail dispenser boxes for high-volume facilities and offices.',
        isAssorted: false,
        assortedSelectionNote: 'Choose standard 25-count dispenser box or 50-count heavy-duty box SKU.',
        requiresVariantSelection: true,
        tags: ['business_favourite', 'everyday'],
        featuredOrder: 8,
      },
      {
        id: 'fam-party-tableware',
        slug: 'party-tableware-essentials',
        name: 'Party Plates, Napkins & Cutlery',
        brand: 'Celebration Craft',
        categoryId: 'cat-party',
        description:
          'Coordinated emerald and crisp white paper plates, 2-ply beverage napkins, cutlery packs, and latex balloons for community events and catering.',
        isAssorted: false,
        assortedSelectionNote: 'Select specific tableware item type.',
        requiresVariantSelection: true,
        tags: ['party_ready'],
        featuredOrder: 9,
      },
      {
        id: 'fam-foil-pans',
        slug: 'aluminum-catering-pans',
        name: 'Aluminum Catering Foil Pans with Lids',
        brand: 'ChefPrep',
        categoryId: 'cat-kitchen',
        description:
          'Half-size and full-size heavy-gauge disposable steam-table foil pans paired with clear dome lids for catering and meal prep.',
        isAssorted: false,
        assortedSelectionNote: 'Select pan size variant.',
        requiresVariantSelection: true,
        tags: ['business_favourite', 'party_ready'],
        featuredOrder: 10,
      },
      {
        id: 'fam-hand-soap',
        slug: 'antibacterial-hand-soap',
        name: 'Antibacterial Liquid Hand Soap, 16 fl oz',
        brand: "Nature's Cleanse",
        categoryId: 'cat-cleaning',
        description:
          'Moisturizing aloe and citrus antibacterial pump-bottle hand soap for washrooms, classrooms, and clinics.',
        isAssorted: false,
        assortedSelectionNote: 'Select Fresh Aloe or Citrus Scent.',
        requiresVariantSelection: true,
        tags: ['everyday', 'business_favourite'],
        featuredOrder: 11,
      },
      {
        id: 'fam-office-pens',
        slug: 'office-writing-supplies',
        name: 'Bulk Pens, Highlighters & Sticky Notes',
        brand: 'Pneer Office',
        categoryId: 'cat-office',
        description:
          'Classroom and front-desk multipacks of smooth medium-point ballpoint pens, chisel-tip highlighters, and 3×3 in sticky notes.',
        isAssorted: false,
        assortedSelectionNote: 'Select specific stationery pack.',
        requiresVariantSelection: true,
        tags: ['business_favourite', 'everyday'],
        featuredOrder: 12,
      },
      {
        id: 'fam-composition-books',
        slug: 'composition-books-pencils',
        name: 'Composition Books & #2 Pencils',
        brand: 'ScholarLine',
        categoryId: 'cat-office',
        description:
          'Sewn-binding 100-sheet composition notebooks and pre-sharpened #2 cedar pencils packaged for school districts and non-profit drives.',
        isAssorted: true,
        assortedSelectionNote:
          'Composition book cases contain classic black marble and teal marble covers assorted evenly; individual colours cannot be specified.',
        requiresVariantSelection: true,
        tags: ['everyday', 'business_favourite'],
        featuredOrder: 13,
      },
      {
        id: 'fam-seasonal-wrap',
        slug: 'seasonal-gift-wrap',
        name: 'Seasonal Gift Wrap & Ribbon Assortment',
        brand: 'Holiday Studio',
        categoryId: 'cat-seasonal',
        description:
          '40 sq ft heavyweight wrapping paper rolls and satin gift bows for seasonal fundraisers, retail wrapping stations, and holiday drives.',
        isAssorted: true,
        assortedSelectionNote:
          'Assorted seasonal case includes Emerald Tree, Gold Ornament, and Candy Stripe prints; patterns are pre-packed evenly and cannot be ordered individually.',
        requiresVariantSelection: true,
        tags: ['party_ready'],
        featuredOrder: 14,
      },
      {
        id: 'fam-shipping-boxes',
        slug: 'corrugated-shipping-supplies',
        name: 'Corrugated Mailers, Boxes & Packing Tape',
        brand: 'ParcelPro',
        categoryId: 'cat-business',
        description:
          '32-ECT kraft corrugated shipping cartons, self-seal bubble mailers, and acrylic packing tape rolls engineered for small business fulfilment.',
        isAssorted: false,
        assortedSelectionNote: 'Uniform kraft or clear finish per SKU. Minimum 2 cases for corrugated boxes.',
        requiresVariantSelection: true,
        tags: ['business_favourite'],
        featuredOrder: 15,
      },
    ];

    const insertFam = db.prepare(
      `INSERT INTO product_families
        (id, slug, name, brand, category_id, description, is_assorted, assorted_selection_note, requires_variant_selection, tags_json, featured_order, active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`
    );
    for (const f of families) {
      insertFam.run(
        f.id,
        f.slug,
        f.name,
        f.brand,
        f.categoryId,
        f.description,
        f.isAssorted ? 1 : 0,
        f.assortedSelectionNote,
        f.requiresVariantSelection ? 1 : 0,
        JSON.stringify(f.tags),
        f.featuredOrder
      );
    }

    // 4. 26 Seeded SKUs across all navigation categories
    const skus: SeedSku[] = [
      // === 4 Mockup Hero Products ===
      {
        sku: 'DT-CLN-1001',
        familyId: 'fam-dish-soap',
        title: 'Dish Soap, 16 fl oz',
        subtitle: 'Ultra Fresh Scent',
        description: 'Bright Waves Ultra Fresh liquid dish soap in 16 fl oz flip-cap bottles. Tough on grease, gentle on hands. Packed 24 bottles per shipping case.',
        images: ['/images/products/dish-soap.jpg'],
        variantAttributes: { scent: 'Ultra Fresh', volume: '16 fl oz' },
        consumerSellingUnit: 'bottle',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 24,
        casePriceCents: 3000, // $1.25/bottle -> $30.00/case
        weightOz: 416,
        dimensionsIn: '16 x 12 x 10 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 85, 'LOC-DC-MID': 60, 'LOC-STR-104': 18, 'LOC-STR-218': 14 },
      },
      {
        sku: 'DT-KIT-2001',
        familyId: 'fam-paper-cups',
        title: 'Paper Cups, 12-count pack',
        subtitle: '9 oz Botanical Leaf Print',
        description: 'Disposable 9 oz cold & warm beverage paper cups in sealed 12-count retail packs. 24 packs per shipping case (288 cups total).',
        images: ['/images/products/paper-cups.jpg'],
        variantAttributes: { size: '9 oz', design: 'Botanical Leaf' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 12,
        consumerUnitsPerCase: 24,
        casePriceCents: 3000, // $1.25/pack -> $30.00/case (288 cups)
        weightOz: 144,
        dimensionsIn: '18 x 14 x 12 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 110, 'LOC-DC-MID': 74, 'LOC-STR-104': 22, 'LOC-STR-218': 16 },
      },
      {
        sku: 'DT-PTY-3001',
        familyId: 'fam-gift-bags',
        title: 'Medium Gift Bags',
        subtitle: 'Assorted Patterns (Case of 36)',
        description: 'Medium 9 × 7 × 4 in matte-laminated gift bags with twisted cord handles. Case contains 36 assorted bags (Pink Polka Dot, Blue Chevron, Lime Solid).',
        images: ['/images/products/gift-bags.jpg'],
        variantAttributes: { size: 'Medium (9x7x4 in)', assortment: 'Assorted 3-Design Mix (non-selectable)' },
        consumerSellingUnit: 'bag',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 36,
        casePriceCents: 4500, // $1.25/bag -> $45.00/case
        weightOz: 128,
        dimensionsIn: '16 x 11 x 9 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 64, 'LOC-DC-MID': 48, 'LOC-STR-104': 12, 'LOC-STR-218': 0 },
      },
      {
        sku: 'DT-OFF-4001',
        familyId: 'fam-spiral-notebooks',
        title: 'Spiral Notebooks',
        subtitle: 'Wide Ruled, 70 Sheets (Assorted Covers)',
        description: 'Durable poly-cover 1-subject wide-ruled spiral notebooks. Packed 24 assorted-colour notebooks per wholesale case.',
        images: ['/images/products/spiral-notebooks.jpg'],
        variantAttributes: { ruling: 'Wide Ruled', sheets: '70 Sheets', covers: 'Assorted Colours' },
        consumerSellingUnit: 'notebook',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 24,
        casePriceCents: 3600, // $1.50/notebook -> $36.00/case
        weightOz: 224,
        dimensionsIn: '12 x 11 x 9 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 95, 'LOC-DC-MID': 80, 'LOC-STR-104': 20, 'LOC-STR-218': 15 },
      },

      // === Additional Variants & Cleaning SKUs ===
      {
        sku: 'DT-CLN-1002',
        familyId: 'fam-dish-soap',
        title: 'Dish Soap, 16 fl oz — Lemon Citrus',
        subtitle: 'Lemon Citrus Scent',
        description: 'Bright Waves Lemon Citrus liquid dish soap in 16 fl oz squeeze bottles. Packed 24 bottles per shipping case.',
        images: ['/images/products/dish-soap.jpg'],
        variantAttributes: { scent: 'Lemon Citrus', volume: '16 fl oz' },
        consumerSellingUnit: 'bottle',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 24,
        casePriceCents: 3000,
        weightOz: 416,
        dimensionsIn: '16 x 12 x 10 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 52, 'LOC-DC-MID': 40, 'LOC-STR-104': 10, 'LOC-STR-218': 8 },
      },
      {
        sku: 'DT-CLN-1003',
        familyId: 'fam-cleaning-sprays',
        title: 'All-Purpose Lavender Spray Cleaner, 24 fl oz',
        subtitle: 'Trigger Spray Bottle',
        description: 'Multi-surface lavender trigger spray cleaner safe for countertops, tile, and sealed stone. 12 bottles per case.',
        images: ['/images/products/cleaning-sprays.jpg'],
        variantAttributes: { formula: 'All-Purpose Lavender', size: '24 fl oz' },
        consumerSellingUnit: 'bottle',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 12,
        casePriceCents: 1800, // $1.50/bottle
        weightOz: 320,
        dimensionsIn: '15 x 12 x 11 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 70, 'LOC-DC-MID': 45, 'LOC-STR-104': 14, 'LOC-STR-218': 9 },
      },
      {
        sku: 'DT-CLN-1004',
        familyId: 'fam-cleaning-sprays',
        title: 'Disinfecting Pine & Meadow Cleaner, 32 fl oz',
        subtitle: 'Concentrated Liquid',
        description: 'Heavy-duty disinfecting multi-surface liquid concentrate for schools, restrooms, and janitorial closets. 12 bottles per case.',
        images: ['/images/products/cleaning-sprays.jpg'],
        variantAttributes: { formula: 'Disinfectant Concentrate', size: '32 fl oz' },
        consumerSellingUnit: 'bottle',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 12,
        casePriceCents: 2100, // $1.75/bottle
        weightOz: 420,
        dimensionsIn: '16 x 12 x 12 in',
        deliveryEligible: true,
        pickupEligible: false, // Delivery only!
        stockByLocation: { 'LOC-DC-EAST': 44, 'LOC-DC-MID': 36, 'LOC-STR-104': 0, 'LOC-STR-218': 0 },
      },
      {
        sku: 'DT-CLN-1005',
        familyId: 'fam-paper-towels',
        title: 'Quilted Paper Towels, 2-Roll Pack',
        subtitle: '160 Sheets per Roll',
        description: 'Absorbent 2-ply perforated paper towels sold in 2-roll retail packs. 12 packs (24 rolls total) per case.',
        images: ['/images/products/paper-towels.jpg'],
        variantAttributes: { ply: '2-Ply Quilted', packSize: '2-Roll Pack' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 2,
        consumerUnitsPerCase: 12,
        casePriceCents: 3000, // $2.50/pack -> tests >$2 filter!
        weightOz: 210,
        dimensionsIn: '22 x 16 x 14 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 65, 'LOC-DC-MID': 55, 'LOC-STR-104': 15, 'LOC-STR-218': 11 },
      },
      {
        sku: 'DT-CLN-1006',
        familyId: 'fam-trash-bags',
        title: 'Tall Kitchen Drawstring Trash Bags, 25-count box',
        subtitle: '13 Gallon Heavy-Duty',
        description: 'Tear-resistant 13-gallon drawstring kitchen bags in 25-count dispenser boxes. 16 boxes (400 bags total) per case.',
        images: ['/images/products/trash-bags.jpg'],
        variantAttributes: { capacity: '13 Gallon', count: '25 bags/box' },
        consumerSellingUnit: 'box',
        itemsPerConsumerPack: 25,
        consumerUnitsPerCase: 16,
        casePriceCents: 2400, // $1.50/box
        weightOz: 192,
        dimensionsIn: '15 x 12 x 10 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 90, 'LOC-DC-MID': 72, 'LOC-STR-104': 19, 'LOC-STR-218': 14 },
      },
      {
        sku: 'DT-CLN-1007',
        familyId: 'fam-trash-bags',
        title: 'Contractor Drawstring Trash Bags, 50-count box',
        subtitle: '13 Gallon Extra Thick',
        description: 'Commercial-grade 1.1 mil drawstring kitchen liners in 50-count boxes. 10 boxes (500 bags total) per case.',
        images: ['/images/products/trash-bags.jpg'],
        variantAttributes: { capacity: '13 Gallon Extra Thick', count: '50 bags/box' },
        consumerSellingUnit: 'box',
        itemsPerConsumerPack: 50,
        consumerUnitsPerCase: 10,
        casePriceCents: 2850, // $2.85/box -> >$2 filter!
        weightOz: 240,
        dimensionsIn: '16 x 13 x 11 in',
        deliveryEligible: true,
        pickupEligible: false,
        stockByLocation: { 'LOC-DC-EAST': 48, 'LOC-DC-MID': 35, 'LOC-STR-104': 0, 'LOC-STR-218': 0 },
      },
      {
        sku: 'DT-CLN-1008',
        familyId: 'fam-hand-soap',
        title: 'Antibacterial Hand Soap Pump, 16 fl oz — Fresh Aloe',
        subtitle: 'Fresh Aloe Vera',
        description: 'Hydrating antibacterial liquid hand soap with aloe vera in 16 fl oz pump dispensers. 12 bottles per case.',
        images: ['/images/products/hand-soap.jpg'],
        variantAttributes: { scent: 'Fresh Aloe', size: '16 fl oz Pump' },
        consumerSellingUnit: 'bottle',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 12,
        casePriceCents: 1800, // $1.50/bottle
        weightOz: 220,
        dimensionsIn: '13 x 10 x 9 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 75, 'LOC-DC-MID': 50, 'LOC-STR-104': 16, 'LOC-STR-218': 12 },
      },
      {
        sku: 'DT-CLN-1009',
        familyId: 'fam-hand-soap',
        title: 'Antibacterial Hand Soap Pump, 16 fl oz — Citrus',
        subtitle: 'Citrus Scent',
        description: 'Refreshing citrus-scented antibacterial liquid hand soap in 16 fl oz pump dispensers. 12 bottles per case.',
        images: ['/images/products/hand-soap.jpg'],
        variantAttributes: { scent: 'Citrus Scent', size: '16 fl oz Pump' },
        consumerSellingUnit: 'bottle',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 12,
        casePriceCents: 1800,
        weightOz: 220,
        dimensionsIn: '13 x 10 x 9 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 60, 'LOC-DC-MID': 42, 'LOC-STR-104': 8, 'LOC-STR-218': 6 },
      },

      // === Kitchen & Dining ===
      {
        sku: 'DT-KIT-2002',
        familyId: 'fam-storage-containers',
        title: 'Food Storage Containers, 3-pack',
        subtitle: 'Green Snap Lids (24 oz)',
        description: 'BPA-free clear rectangular food storage containers with airtight green snap lids. 24 3-packs (72 containers) per case.',
        images: ['/images/products/storage-containers.jpg'],
        variantAttributes: { packSize: '3-Pack (24 oz each)', lidColor: 'Forest Green' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 3,
        consumerUnitsPerCase: 24,
        casePriceCents: 3600, // $1.50/pack
        weightOz: 280,
        dimensionsIn: '20 x 14 x 12 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 58, 'LOC-DC-MID': 44, 'LOC-STR-104': 11, 'LOC-STR-218': 9 },
      },
      {
        sku: 'DT-KIT-2003',
        familyId: 'fam-storage-containers',
        title: 'Deep Pantry Storage Containers, 2-pack',
        subtitle: 'Large 64 oz Locking Lid',
        description: 'Extra-deep stackable pantry and freezer containers with measurement markings and green locking tabs. 12 2-packs per case.',
        images: ['/images/products/storage-containers.jpg'],
        variantAttributes: { packSize: '2-Pack (64 oz each)', lidColor: 'Forest Green' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 2,
        consumerUnitsPerCase: 12,
        casePriceCents: 2700, // $2.25/pack
        weightOz: 245,
        dimensionsIn: '18 x 14 x 12 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 42, 'LOC-DC-MID': 38, 'LOC-STR-104': 6, 'LOC-STR-218': 5 },
      },
      {
        sku: 'DT-KIT-2004',
        familyId: 'fam-foil-pans',
        title: 'Half-Size Aluminum Foil Pans with Lids, 4-pack',
        subtitle: 'Catering Steam-Table Pans',
        description: 'Disposable heavy-duty half-size aluminum foil pans with matching snap-on clear plastic lids. 12 4-packs (48 pans) per case.',
        images: ['/images/products/foil-pans.jpg'],
        variantAttributes: { size: 'Half-Size (12.75 x 10.25 in)', count: '4 pans + 4 lids/pack' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 4,
        consumerUnitsPerCase: 12,
        casePriceCents: 2100, // $1.75/pack
        weightOz: 170,
        dimensionsIn: '15 x 12 x 10 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 77, 'LOC-DC-MID': 54, 'LOC-STR-104': 15, 'LOC-STR-218': 10 },
      },
      {
        sku: 'DT-KIT-2005',
        familyId: 'fam-foil-pans',
        title: 'Full-Size Deep Catering Foil Pans, 2-pack',
        subtitle: 'Event & Buffet Trays',
        description: 'Full-size deep steam-table aluminum trays with rigid clear dome lids. 12 2-packs (24 pans) per case.',
        images: ['/images/products/foil-pans.jpg'],
        variantAttributes: { size: 'Full-Size Deep (20.75 x 12.75 in)', count: '2 pans + 2 lids/pack' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 2,
        consumerUnitsPerCase: 12,
        casePriceCents: 3000, // $2.50/pack
        weightOz: 260,
        dimensionsIn: '22 x 14 x 11 in',
        deliveryEligible: true,
        pickupEligible: false,
        stockByLocation: { 'LOC-DC-EAST': 38, 'LOC-DC-MID': 28, 'LOC-STR-104': 0, 'LOC-STR-218': 0 },
      },

      // === Party Supplies ===
      {
        sku: 'DT-PTY-3002',
        familyId: 'fam-party-tableware',
        title: 'Emerald & White Paper Dinner Plates, 20-count pack',
        subtitle: '9 in Heavyweight Coated Plates',
        description: 'Soak-proof coated 9-inch paper dinner plates in emerald green dot and white trim. 24 packs (480 plates total) per case.',
        images: ['/images/products/party-tableware.jpg'],
        variantAttributes: { item: '9 in Dinner Plates', count: '20 plates/pack' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 20,
        consumerUnitsPerCase: 24,
        casePriceCents: 3000, // $1.25/pack
        weightOz: 190,
        dimensionsIn: '18 x 12 x 10 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 88, 'LOC-DC-MID': 62, 'LOC-STR-104': 18, 'LOC-STR-218': 12 },
      },
      {
        sku: 'DT-PTY-3003',
        familyId: 'fam-party-tableware',
        title: 'Event Cutlery & Napkin Bundles, 18-piece pack',
        subtitle: 'Emerald Forks, Knives, Spoons',
        description: 'Heavyweight emerald plastic forks, knives, and spoons paired with 2-ply white luncheon napkins. 24 packs per case.',
        images: ['/images/products/party-tableware.jpg'],
        variantAttributes: { item: 'Cutlery & Napkin Pack', count: '18 pieces/pack' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 18,
        consumerUnitsPerCase: 24,
        casePriceCents: 3000, // $1.25/pack
        weightOz: 150,
        dimensionsIn: '15 x 11 x 9 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 70, 'LOC-DC-MID': 52, 'LOC-STR-104': 14, 'LOC-STR-218': 9 },
      },
      {
        sku: 'DT-PTY-3004',
        familyId: 'fam-party-tableware',
        title: 'Party Latex Balloons & Ribbon, 15-count pack',
        subtitle: 'Emerald, White & Confetti Mix',
        description: '12-inch helium-quality latex balloons with curling ribbon rolls. 36 packs (540 balloons total) per case.',
        images: ['/images/products/party-tableware.jpg'],
        variantAttributes: { item: '12 in Balloons + Ribbon', count: '15 balloons/pack' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 15,
        consumerUnitsPerCase: 36,
        casePriceCents: 4500, // $1.25/pack
        weightOz: 96,
        dimensionsIn: '14 x 10 x 8 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 94, 'LOC-DC-MID': 68, 'LOC-STR-104': 24, 'LOC-STR-218': 15 },
      },

      // === Office & School ===
      {
        sku: 'DT-OFF-4002',
        familyId: 'fam-spiral-notebooks',
        title: 'Spiral Notebooks — College Ruled',
        subtitle: 'College Ruled, 70 Sheets (Assorted Covers)',
        description: 'College-ruled 70-sheet single-subject spiral notebooks with perforated clean-tear pages. 24 assorted notebooks per case.',
        images: ['/images/products/spiral-notebooks.jpg'],
        variantAttributes: { ruling: 'College Ruled', sheets: '70 Sheets', covers: 'Assorted Colours' },
        consumerSellingUnit: 'notebook',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 24,
        casePriceCents: 3600, // $1.50/notebook
        weightOz: 224,
        dimensionsIn: '12 x 11 x 9 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 82, 'LOC-DC-MID': 65, 'LOC-STR-104': 16, 'LOC-STR-218': 11 },
      },
      {
        sku: 'DT-OFF-4003',
        familyId: 'fam-office-pens',
        title: 'Retractable Ballpoint Pens, 12-count pack',
        subtitle: 'Black & Blue Medium 1.0mm',
        description: 'Smooth-glide rubberized grip ballpoint pens in 12-count retail packs. 24 packs (288 pens total) per case.',
        images: ['/images/products/office-pens.jpg'],
        variantAttributes: { tip: '1.0mm Medium', count: '12 pens/pack' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 12,
        consumerUnitsPerCase: 24,
        casePriceCents: 3000, // $1.25/pack
        weightOz: 112,
        dimensionsIn: '12 x 10 x 8 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 130, 'LOC-DC-MID': 90, 'LOC-STR-104': 25, 'LOC-STR-218': 20 },
      },
      {
        sku: 'DT-OFF-4004',
        familyId: 'fam-office-pens',
        title: 'Yellow Sticky Notes & Highlighters Bundle, 6-pad pack',
        subtitle: '3 × 3 in Notes + Fluorescent Highlighters',
        description: 'Self-stick note pads (100 sheets each) and chisel highlighters in classroom-ready packs. 24 packs per case.',
        images: ['/images/products/office-pens.jpg'],
        variantAttributes: { item: 'Sticky Notes + Highlighters', count: '6 pads/pack' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 6,
        consumerUnitsPerCase: 24,
        casePriceCents: 3600, // $1.50/pack
        weightOz: 128,
        dimensionsIn: '13 x 10 x 8 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 84, 'LOC-DC-MID': 60, 'LOC-STR-104': 17, 'LOC-STR-218': 12 },
      },
      {
        sku: 'DT-OFF-4005',
        familyId: 'fam-composition-books',
        title: 'Hardbound Composition Books, 100 Sheets',
        subtitle: 'Assorted Marble Covers',
        description: 'Sewn-spine marble composition notebooks (9.75 × 7.5 in, 100 sheets). 24 assorted books per case.',
        images: ['/images/products/composition-books.jpg'],
        variantAttributes: { binding: 'Sewn Marble Hardcover', sheets: '100 Sheets' },
        consumerSellingUnit: 'notebook',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 24,
        casePriceCents: 3000, // $1.25/notebook
        weightOz: 256,
        dimensionsIn: '13 x 11 x 9 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 96, 'LOC-DC-MID': 78, 'LOC-STR-104': 20, 'LOC-STR-218': 14 },
      },
      {
        sku: 'DT-OFF-4006',
        familyId: 'fam-composition-books',
        title: 'Pre-Sharpened #2 Yellow Pencils, 10-count pack',
        subtitle: 'Latex-Free Pink Erasers',
        description: 'Classic cedar #2 HB graphite pencils pre-sharpened in 10-count blister packs. 36 packs (360 pencils total) per case.',
        images: ['/images/products/composition-books.jpg'],
        variantAttributes: { grade: '#2 HB', count: '10 pencils/pack' },
        consumerSellingUnit: 'pack',
        itemsPerConsumerPack: 10,
        consumerUnitsPerCase: 36,
        casePriceCents: 4500, // $1.25/pack
        weightOz: 144,
        dimensionsIn: '12 x 9 x 8 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 120, 'LOC-DC-MID': 88, 'LOC-STR-104': 28, 'LOC-STR-218': 19 },
      },

      // === Seasonal ===
      {
        sku: 'DT-SEA-5001',
        familyId: 'fam-seasonal-wrap',
        title: 'Holiday Wrapping Paper Rolls, 40 sq ft',
        subtitle: 'Assorted Emerald, Gold & Stripe (Case of 24)',
        description: 'Heavyweight coated gift wrap rolls (30 in × 16 ft each). Case includes 24 assorted rolls in Emerald Pine, Gold Foil, and Candy Stripe.',
        images: ['/images/products/seasonal-wrap.jpg'],
        variantAttributes: { coverage: '40 sq ft/roll', assortment: 'Assorted 3-Pattern Mix (non-selectable)' },
        consumerSellingUnit: 'roll',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 24,
        casePriceCents: 3000, // $1.25/roll
        weightOz: 192,
        dimensionsIn: '31 x 12 x 10 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 72, 'LOC-DC-MID': 56, 'LOC-STR-104': 16, 'LOC-STR-218': 10 },
      },

      // === Business Supplies ===
      {
        sku: 'DT-BUS-6001',
        familyId: 'fam-shipping-boxes',
        title: 'Corrugated Kraft Mailer Boxes, 10 × 8 × 4 in',
        subtitle: '25 Boxes per Case (Min 2 Cases)',
        description: '32-ECT crush-tested corrugated kraft mailing boxes shipped flat. 25 boxes per case; ordered in 2-case increments for pallet stability.',
        images: ['/images/products/shipping-boxes.jpg'],
        variantAttributes: { dimensions: '10 x 8 x 4 in', board: '32-ECT Kraft' },
        consumerSellingUnit: 'box',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 25,
        casePriceCents: 3125, // $1.25/box -> $31.25/case
        minCaseQuantity: 2,
        caseIncrement: 2,
        weightOz: 260,
        dimensionsIn: '20 x 16 x 8 in',
        deliveryEligible: true,
        pickupEligible: false, // Warehouse delivery only
        stockByLocation: { 'LOC-DC-EAST': 90, 'LOC-DC-MID': 70, 'LOC-STR-104': 0, 'LOC-STR-218': 0 },
      },
      {
        sku: 'DT-BUS-6002',
        familyId: 'fam-shipping-boxes',
        title: 'Self-Seal Kraft Bubble Mailers & Packing Tape Set',
        subtitle: '24 Mailers + 6 Tape Rolls per Case',
        description: 'Padded 8.5 × 11 in kraft bubble mailers paired with heavy-duty clear acrylic carton tape rolls for e-commerce fulfilment desks.',
        images: ['/images/products/shipping-boxes.jpg'],
        variantAttributes: { contents: '24 Mailers + Tape', size: '8.5 x 11 in' },
        consumerSellingUnit: 'item',
        itemsPerConsumerPack: null,
        consumerUnitsPerCase: 24,
        casePriceCents: 3600, // $1.50/item
        weightOz: 176,
        dimensionsIn: '16 x 13 x 11 in',
        deliveryEligible: true,
        pickupEligible: true,
        stockByLocation: { 'LOC-DC-EAST': 66, 'LOC-DC-MID': 52, 'LOC-STR-104': 10, 'LOC-STR-218': 7 },
      },
    ];

    const insertSku = db.prepare(
      `INSERT INTO skus
        (sku, family_id, title, subtitle, description, images_json, variant_attributes_json,
         consumer_selling_unit, items_per_consumer_pack, consumer_units_per_case, case_price_cents,
         currency, min_case_quantity, case_increment, weight_oz, dimensions_in,
         delivery_eligible, pickup_eligible, active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'USD', ?, ?, ?, ?, ?, ?, 1, ?, ?)`
    );

    const insertInv = db.prepare(
      'INSERT INTO inventory_levels (sku, location_id, on_hand_cases, reserved_cases, updated_at) VALUES (?, ?, ?, 0, ?)'
    );

    const insertAdj = db.prepare(
      'INSERT INTO inventory_adjustments (id, sku, location_id, delta_cases, reason, actor_user_id, created_at) VALUES (?, ?, ?, ?, ?, NULL, ?)'
    );

    for (const s of skus) {
      insertSku.run(
        s.sku,
        s.familyId,
        s.title,
        s.subtitle,
        s.description,
        JSON.stringify(s.images),
        JSON.stringify(s.variantAttributes),
        s.consumerSellingUnit,
        s.itemsPerConsumerPack,
        s.consumerUnitsPerCase,
        s.casePriceCents,
        s.minCaseQuantity ?? 1,
        s.caseIncrement ?? 1,
        s.weightOz,
        s.dimensionsIn,
        s.deliveryEligible ? 1 : 0,
        s.pickupEligible ? 1 : 0,
        now,
        now
      );

      for (const [locId, qty] of Object.entries(s.stockByLocation)) {
        insertInv.run(s.sku, locId, qty, now);
        if (qty > 0) {
          insertAdj.run(
            `ADJ-SEED-${s.sku}-${locId}`,
            s.sku,
            locId,
            qty,
            'Initial demonstration seed stock',
            now
          );
        }
      }
    }

    // 5. Homepage Banners
    const insertBanner = db.prepare(
      'INSERT INTO homepage_banners (id, slot, headline, subheadline, cta_label, cta_href, active, updated_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?)'
    );
    insertBanner.run(
      'banner-announcement',
      'announcement',
      'Big value. Stock up by the case.',
      '',
      '',
      '',
      now
    );
    insertBanner.run(
      'banner-hero',
      'hero',
      'Small prices. Big possibilities.',
      'Everyday essentials, ready by the case.',
      'Shop bulk essentials',
      '#catalogue',
      now
    );
    insertBanner.run(
      'banner-business',
      'business',
      'Buying for your business?',
      'Schools, offices, hospitality, and community bulk orders with PO reference support.',
      'Build your bulk order',
      '/business',
      now
    );

    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}
