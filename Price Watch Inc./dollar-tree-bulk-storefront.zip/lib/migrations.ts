import type { DatabaseSync } from 'node:sqlite';

export interface Migration {
  version: number;
  name: string;
  sql: string;
}

export const MIGRATIONS: Migration[] = [
  {
    version: 1,
    name: 'initial_schema',
    sql: `
      CREATE TABLE IF NOT EXISTS categories (
        id TEXT PRIMARY KEY,
        slug TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        sort_order INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS product_families (
        id TEXT PRIMARY KEY,
        slug TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        brand TEXT NOT NULL,
        category_id TEXT NOT NULL REFERENCES categories(id),
        description TEXT NOT NULL,
        is_assorted INTEGER NOT NULL DEFAULT 0,
        assorted_selection_note TEXT NOT NULL DEFAULT '',
        requires_variant_selection INTEGER NOT NULL DEFAULT 0,
        tags_json TEXT NOT NULL DEFAULT '[]',
        featured_order INTEGER NOT NULL DEFAULT 999,
        active INTEGER NOT NULL DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS skus (
        sku TEXT PRIMARY KEY,
        family_id TEXT NOT NULL REFERENCES product_families(id),
        title TEXT NOT NULL,
        subtitle TEXT NOT NULL DEFAULT '',
        description TEXT NOT NULL,
        images_json TEXT NOT NULL DEFAULT '[]',
        variant_attributes_json TEXT NOT NULL DEFAULT '{}',
        consumer_selling_unit TEXT NOT NULL,
        items_per_consumer_pack INTEGER,
        consumer_units_per_case INTEGER NOT NULL,
        case_price_cents INTEGER NOT NULL,
        currency TEXT NOT NULL DEFAULT 'USD',
        min_case_quantity INTEGER NOT NULL DEFAULT 1,
        case_increment INTEGER NOT NULL DEFAULT 1,
        weight_oz REAL NOT NULL DEFAULT 160,
        dimensions_in TEXT NOT NULL DEFAULT '16 x 12 x 10 in',
        delivery_eligible INTEGER NOT NULL DEFAULT 1,
        pickup_eligible INTEGER NOT NULL DEFAULT 1,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS locations (
        id TEXT PRIMARY KEY,
        code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('warehouse', 'store')),
        address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        zip TEXT NOT NULL,
        eligible_states_json TEXT NOT NULL DEFAULT '[]',
        pickup_lead_time_hours INTEGER NOT NULL DEFAULT 4,
        active INTEGER NOT NULL DEFAULT 1
      );

      CREATE TABLE IF NOT EXISTS inventory_levels (
        sku TEXT NOT NULL REFERENCES skus(sku),
        location_id TEXT NOT NULL REFERENCES locations(id),
        on_hand_cases INTEGER NOT NULL DEFAULT 0 CHECK(on_hand_cases >= 0),
        reserved_cases INTEGER NOT NULL DEFAULT 0 CHECK(reserved_cases >= 0),
        updated_at TEXT NOT NULL,
        PRIMARY KEY (sku, location_id)
      );

      CREATE TABLE IF NOT EXISTS inventory_adjustments (
        id TEXT PRIMARY KEY,
        sku TEXT NOT NULL REFERENCES skus(sku),
        location_id TEXT NOT NULL REFERENCES locations(id),
        delta_cases INTEGER NOT NULL,
        reason TEXT NOT NULL,
        actor_user_id TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('customer', 'catalogue_manager', 'fulfilment_staff', 'customer_service', 'admin')),
        company_name TEXT NOT NULL DEFAULT '',
        tax_id TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS sessions (
        token_hash TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        role TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS saved_addresses (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        label TEXT NOT NULL,
        recipient_name TEXT NOT NULL,
        line1 TEXT NOT NULL,
        line2 TEXT NOT NULL DEFAULT '',
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        is_default INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS carts (
        id TEXT PRIMARY KEY,
        guest_token TEXT UNIQUE,
        user_id TEXT UNIQUE REFERENCES users(id) ON DELETE CASCADE,
        fulfilment_method TEXT NOT NULL DEFAULT 'delivery' CHECK(fulfilment_method IN ('delivery', 'pickup')),
        location_id TEXT REFERENCES locations(id),
        destination_zip TEXT NOT NULL DEFAULT '08002',
        destination_state TEXT NOT NULL DEFAULT 'NJ',
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS cart_items (
        id TEXT PRIMARY KEY,
        cart_id TEXT NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
        sku TEXT NOT NULL REFERENCES skus(sku),
        cases_qty INTEGER NOT NULL CHECK(cases_qty > 0),
        unit_price_snapshot_cents INTEGER NOT NULL,
        case_price_snapshot_cents INTEGER NOT NULL,
        saved_for_later INTEGER NOT NULL DEFAULT 0,
        added_at TEXT NOT NULL,
        UNIQUE(cart_id, sku, saved_for_later)
      );

      CREATE TABLE IF NOT EXISTS business_lists (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        list_type TEXT NOT NULL CHECK(list_type IN ('purchasing_list', 'repeat_template')),
        po_reference TEXT NOT NULL DEFAULT '',
        company_name TEXT NOT NULL DEFAULT '',
        billing_email TEXT NOT NULL DEFAULT '',
        items_json TEXT NOT NULL DEFAULT '[]',
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS orders (
        id TEXT PRIMARY KEY,
        user_id TEXT REFERENCES users(id),
        guest_access_token_hash TEXT,
        customer_email TEXT NOT NULL,
        customer_name TEXT NOT NULL,
        customer_phone TEXT NOT NULL,
        order_status TEXT NOT NULL CHECK(order_status IN ('pending_payment', 'confirmed', 'cancelled', 'reconciliation_required')),
        payment_status TEXT NOT NULL CHECK(payment_status IN ('unpaid', 'authorized', 'paid', 'failed', 'refunded', 'partially_refunded')),
        fulfilment_status TEXT NOT NULL CHECK(fulfilment_status IN ('unfulfilled', 'picking', 'packed', 'dispatched', 'delivered', 'ready_for_pickup', 'collected', 'cancelled')),
        fulfilment_method TEXT NOT NULL CHECK(fulfilment_method IN ('delivery', 'pickup')),
        location_id TEXT NOT NULL REFERENCES locations(id),
        location_name_snapshot TEXT NOT NULL,
        shipping_address_json TEXT NOT NULL DEFAULT '{}',
        po_reference TEXT NOT NULL DEFAULT '',
        company_billing_json TEXT NOT NULL DEFAULT '{}',
        merchandise_subtotal_cents INTEGER NOT NULL,
        discount_cents INTEGER NOT NULL DEFAULT 0,
        delivery_fee_cents INTEGER NOT NULL DEFAULT 0,
        tax_cents INTEGER NOT NULL DEFAULT 0,
        total_cents INTEGER NOT NULL,
        currency TEXT NOT NULL DEFAULT 'USD',
        tax_rate_bps INTEGER NOT NULL DEFAULT 0,
        tax_estimate_note TEXT NOT NULL DEFAULT '',
        idempotency_key TEXT UNIQUE,
        cancellation_requested INTEGER NOT NULL DEFAULT 0,
        cancellation_reason TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS order_items (
        id TEXT PRIMARY KEY,
        order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        sku TEXT NOT NULL,
        title_snapshot TEXT NOT NULL,
        description_snapshot TEXT NOT NULL,
        brand_snapshot TEXT NOT NULL,
        variant_attributes_snapshot_json TEXT NOT NULL DEFAULT '{}',
        consumer_selling_unit_snapshot TEXT NOT NULL,
        items_per_consumer_pack_snapshot INTEGER,
        consumer_units_per_case_snapshot INTEGER NOT NULL,
        cases_ordered INTEGER NOT NULL,
        total_consumer_units INTEGER NOT NULL,
        case_price_cents_snapshot INTEGER NOT NULL,
        unit_price_cents_snapshot INTEGER NOT NULL,
        line_subtotal_cents INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS stock_reservations (
        id TEXT PRIMARY KEY,
        order_attempt_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        sku TEXT NOT NULL REFERENCES skus(sku),
        location_id TEXT NOT NULL REFERENCES locations(id),
        cases_reserved INTEGER NOT NULL CHECK(cases_reserved > 0),
        status TEXT NOT NULL CHECK(status IN ('active', 'committed', 'released', 'expired')),
        expires_at TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS payment_events (
        id TEXT PRIMARY KEY,
        order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        provider TEXT NOT NULL,
        provider_event_id TEXT NOT NULL UNIQUE,
        event_type TEXT NOT NULL,
        amount_cents INTEGER NOT NULL,
        status TEXT NOT NULL,
        raw_redacted_json TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS refunds (
        id TEXT PRIMARY KEY,
        order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        amount_cents INTEGER NOT NULL,
        reason TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('completed', 'pending')),
        is_partial INTEGER NOT NULL DEFAULT 0,
        actor_user_id TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS fulfilment_transitions (
        id TEXT PRIMARY KEY,
        order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        from_status TEXT NOT NULL,
        to_status TEXT NOT NULL,
        actor_user_id TEXT,
        actor_name TEXT NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS homepage_banners (
        id TEXT PRIMARY KEY,
        slot TEXT NOT NULL UNIQUE,
        headline TEXT NOT NULL,
        subheadline TEXT NOT NULL DEFAULT '',
        cta_label TEXT NOT NULL DEFAULT '',
        cta_href TEXT NOT NULL DEFAULT '',
        active INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        actor_user_id TEXT,
        actor_email TEXT NOT NULL DEFAULT 'system',
        actor_role TEXT NOT NULL DEFAULT 'system',
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        details_json TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_skus_family ON skus(family_id);
      CREATE INDEX IF NOT EXISTS idx_reservations_expiry ON stock_reservations(status, expires_at);
      CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
      CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
    `,
  },
];

export function runMigrations(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      applied_at TEXT NOT NULL
    );
  `);

  const appliedRows = db
    .prepare('SELECT version FROM schema_migrations')
    .all() as Array<{ version: number }>;
  const applied = new Set(appliedRows.map((r) => r.version));

  const insertMigration = db.prepare(
    'INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)'
  );

  for (const migration of MIGRATIONS) {
    if (applied.has(migration.version)) continue;
    db.exec('BEGIN IMMEDIATE');
    try {
      db.exec(migration.sql);
      insertMigration.run(migration.version, migration.name, new Date().toISOString());
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  }
}
