import { STORE_CONFIG } from './config';

/**
 * Prevents spreadsheet formula injection (CSV/Excel macro injection)
 * by prefixing leading =, +, -, @, tab, or CR characters with a single quote.
 */
export function sanitizeCsvCell(value: unknown): string {
  const raw = value === null || value === undefined ? '' : String(value);
  const trimmedStart = raw.replace(/^[\uFEFF]/, '');
  const safe = /^[=+\-@\t\r]/.test(trimmedStart) ? `'${raw}` : raw;
  if (/[",\n\r]/.test(safe)) {
    return `"${safe.replace(/"/g, '""')}"`;
  }
  return safe;
}

export function buildSafeCsv(headers: string[], rows: Array<Array<unknown>>): string {
  const lines = [headers.map(sanitizeCsvCell).join(',')];
  for (const row of rows) {
    lines.push(row.map(sanitizeCsvCell).join(','));
  }
  return lines.join('\r\n');
}

export interface ParsedCsvRow {
  lineNumber: number;
  sku: string;
  cases: number;
}

export function parseBulkOrderCsv(csvText: string): {
  rows: ParsedCsvRow[];
  errors: string[];
} {
  if (Buffer.byteLength(csvText, 'utf8') > STORE_CONFIG.maxCsvBytes) {
    return {
      rows: [],
      errors: [`CSV exceeds maximum allowed size of ${STORE_CONFIG.maxCsvBytes / (1024 * 1024)} MB.`],
    };
  }

  const lines = csvText
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length === 0) {
    return { rows: [], errors: ['CSV file is empty.'] };
  }

  if (lines.length - 1 > STORE_CONFIG.maxCsvRows) {
    return {
      rows: [],
      errors: [`CSV exceeds maximum of ${STORE_CONFIG.maxCsvRows} data rows.`],
    };
  }

  const splitCsvLine = (line: string): string[] => {
    const out: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch === ',' && !inQuotes) {
        out.push(current.trim());
        current = '';
      } else {
        current += ch;
      }
    }
    out.push(current.trim());
    return out;
  };

  const headerCells = splitCsvLine(lines[0]).map((h) => h.toLowerCase().replace(/\s+/g, '_'));
  const skuIdx = headerCells.findIndex((h) => h === 'sku' || h === 'item_sku');
  const qtyIdx = headerCells.findIndex(
    (h) => h === 'cases' || h === 'case_qty' || h === 'quantity' || h === 'qty'
  );

  if (skuIdx === -1 || qtyIdx === -1) {
    return {
      rows: [],
      errors: ['CSV header must include "sku" and "cases" (or "quantity") columns.'],
    };
  }

  const rows: ParsedCsvRow[] = [];
  const errors: string[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cells = splitCsvLine(lines[i]);
    const rawSku = (cells[skuIdx] || '').replace(/^'/, '').trim().toUpperCase();
    const rawQty = (cells[qtyIdx] || '').replace(/^'/, '').trim();
    if (!rawSku) {
      errors.push(`Row ${i + 1}: Missing SKU.`);
      continue;
    }
    if (!/^[A-Z0-9-]{3,32}$/.test(rawSku)) {
      errors.push(`Row ${i + 1}: Invalid SKU format "${rawSku}".`);
      continue;
    }
    const parsedQty = Number(rawQty);
    if (!Number.isInteger(parsedQty) || parsedQty <= 0) {
      errors.push(`Row ${i + 1} (${rawSku}): Cases must be a positive whole number.`);
      continue;
    }
    rows.push({
      lineNumber: i + 1,
      sku: rawSku,
      cases: parsedQty,
    });
  }

  return { rows, errors };
}
