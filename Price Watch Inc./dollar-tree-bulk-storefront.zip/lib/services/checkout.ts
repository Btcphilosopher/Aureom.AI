import crypto from 'node:crypto';
import { getDb, withTransaction } from '../db';
import { STORE_CONFIG } from '../config';
import { calculateOrderTotals, computePackagingBreakdown } from '../pricing';
import { getCartView, type CartSummary } from './cart';
import { expireStaleReservations } from './worker';
import { logEvent } from '../logger';

export interface CheckoutContactInput {
  email: string;
  name: string;
  phone: string;
  poReference?: string;
  companyName?: string;
  billingEmail?: string;
  taxId?: string;
}

export interface ShippingAddressInput {
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postalCode: string;
}

export interface CheckoutQuote {
  eligible: boolean;
  errors: string[];
  fulfilmentMethod: 'delivery' | 'pickup';
  locationId: string;
  locationName: string;
  locationAddress: string;
  pickupLeadTimeHours: number;
  merchandiseSubtotalCents: number;
  discountCents: number;
  deliveryFeeCents: number;
  taxRateBps: number;
  taxCents: number;
  totalCents: number;
  taxEstimateNote: string;
  cart: CartSummary;
}

export function getWebhookSigningSecret(): string {
  if (process.env.PAYMENT_WEBHOOK_SECRET && process.env.PAYMENT_WEBHOOK_SECRET.trim().length > 0) {
    return process.env.PAYMENT_WEBHOOK_SECRET.trim();
  }
  const g = globalThis as unknown as { __demoWebhookSecret?: string };
  if (!g.__demoWebhookSecret) {
    g.__demoWebhookSecret = crypto.randomBytes(32).toString('hex');
  }
  return g.__demoWebhookSecret;
}

export function signWebhookPayload(rawBody: string): string {
  return crypto.createHmac('sha256', getWebhookSigningSecret()).update(rawBody).digest('hex');
}

export function verifyWebhookSignature(rawBody: string, signatureHeader: string | null): boolean {
  if (!signatureHeader) return false;
  const expected = signWebhookPayload(rawBody);
  const actualBuf = Buffer.from(signatureHeader.trim(), 'hex');
  const expectedBuf = Buffer.from(expected, 'hex');
  if (actualBuf.length !== expectedBuf.length) return false;
  return crypto.timingSafeEqual(actualBuf, expectedBuf);
}

export function quoteCheckout(params: {
  cartId: string;
  fulfilmentMethod: 'delivery' | 'pickup';
  locationId: string;
  destinationState?: string;
}): CheckoutQuote {
  expireStaleReservations();
  const db = getDb();
  const cart = getCartView(params.cartId);
  const errors: string[] = [];

  const loc = db
    .prepare('SELECT * FROM locations WHERE id = ? AND active = 1')
    .get(params.locationId) as
    | {
        id: string;
        name: string;
        type: 'warehouse' | 'store';
        address: string;
        city: string;
        state: string;
        zip: string;
        eligible_states_json: string;
        pickup_lead_time_hours: number;
      }
    | undefined;

  if (!loc) {
    return {
      eligible: false,
      errors: ['Selected fulfilment location does not exist or is inactive.'],
      fulfilmentMethod: params.fulfilmentMethod,
      locationId: params.locationId,
      locationName: 'Unknown location',
      locationAddress: '',
      pickupLeadTimeHours: 0,
      merchandiseSubtotalCents: cart.merchandiseSubtotalCents,
      discountCents: 0,
      deliveryFeeCents: 0,
      taxRateCents: 0,
      taxRateBps: 0,
      taxCents: 0,
      totalCents: cart.merchandiseSubtotalCents,
      taxEstimateNote: STORE_CONFIG.demoPolicies.taxDisclaimer,
      cart,
    } as unknown as CheckoutQuote;
  }

  if (cart.activeLines.length === 0) {
    errors.push('Your cart is empty.');
  }

  if (params.fulfilmentMethod === 'delivery' && loc.type !== 'warehouse') {
    errors.push('Delivery orders must ship from a distribution hub rather than a retail store.');
  }
  if (params.fulfilmentMethod === 'pickup' && loc.type !== 'store') {
    errors.push('Store pickup orders must target a retail store location.');
  }

  const eligibleStates = JSON.parse(loc.eligible_states_json || '[]') as string[];
  const destState = (params.destinationState || cart.destinationState || loc.state)
    .trim()
    .toUpperCase();

  if (params.fulfilmentMethod === 'delivery' && eligibleStates.length > 0 && !eligibleStates.includes(destState)) {
    errors.push(
      `${loc.name} only delivers to ${eligibleStates.join(', ')}. Choose another hub or eligible destination state.`
    );
  }

  for (const line of cart.activeLines) {
    if (!line.active) {
      errors.push(`${line.title} (${line.sku}) is inactive.`);
      continue;
    }
    if (params.fulfilmentMethod === 'delivery' && !line.deliveryEligible) {
      errors.push(
        `${line.title} (${line.sku}) is not eligible for delivery from ${loc.name}. Single-method orders cannot mix ineligible items.`
      );
    }
    if (params.fulfilmentMethod === 'pickup' && !line.pickupEligible) {
      errors.push(
        `${line.title} (${line.sku}) is not eligible for store pickup at ${loc.name}. Switch to delivery or remove it to avoid split orders.`
      );
    }

    const inv = db
      .prepare('SELECT on_hand_cases, reserved_cases FROM inventory_levels WHERE sku = ? AND location_id = ?')
      .get(line.sku, loc.id) as { on_hand_cases: number; reserved_cases: number } | undefined;
    const available = inv ? Math.max(0, inv.on_hand_cases - inv.reserved_cases) : 0;
    if (available < line.casesQty) {
      errors.push(
        `${line.title} (${line.sku}) only has ${available} case(s) available at ${loc.name} (requested ${line.casesQty}).`
      );
    }
  }

  const totals = calculateOrderTotals({
    lineSubtotalsCents: cart.activeLines.map((l) => l.lineSubtotalCents),
    fulfilmentMethod: params.fulfilmentMethod,
    destinationState: params.fulfilmentMethod === 'pickup' ? loc.state : destState,
  });

  return {
    eligible: errors.length === 0,
    errors,
    fulfilmentMethod: params.fulfilmentMethod,
    locationId: loc.id,
    locationName: loc.name,
    locationAddress: `${loc.address}, ${loc.city}, ${loc.state} ${loc.zip}`,
    pickupLeadTimeHours: loc.pickup_lead_time_hours,
    ...totals,
    cart,
  };
}

export class CheckoutConflictError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CheckoutConflictError';
  }
}

export function createOrderAttempt(params: {
  cartId: string;
  userId?: string | null;
  fulfilmentMethod: 'delivery' | 'pickup';
  locationId: string;
  contact: CheckoutContactInput;
  shippingAddress?: ShippingAddressInput;
  idempotencyKey: string;
  reservationTtlMinutes?: number;
}) {
  expireStaleReservations();
  const db = getDb();

  // Check idempotency outside/inside cleanly
  const existingByKey = db
    .prepare('SELECT id, total_cents, order_status, payment_status FROM orders WHERE idempotency_key = ?')
    .get(params.idempotencyKey) as
    | { id: string; total_cents: number; order_status: string; payment_status: string }
    | undefined;

  if (existingByKey) {
    return {
      orderId: existingByKey.id,
      totalCents: existingByKey.total_cents,
      orderStatus: existingByKey.order_status,
      paymentStatus: existingByKey.payment_status,
      reusedIdempotent: true,
      guestAccessToken: null as string | null,
      reservationExpiresAt: null as string | null,
    };
  }

  const quote = quoteCheckout({
    cartId: params.cartId,
    fulfilmentMethod: params.fulfilmentMethod,
    locationId: params.locationId,
    destinationState: params.shippingAddress?.state,
  });

  if (!quote.eligible) {
    throw new CheckoutConflictError(quote.errors.join(' '));
  }

  const ttlMinutes = params.reservationTtlMinutes ?? STORE_CONFIG.reservationTtlMinutes;
  const now = new Date();
  const nowIso = now.toISOString();
  const expiresAtIso = new Date(now.getTime() + ttlMinutes * 60_000).toISOString();
  const orderId = `ORD-${now.toISOString().slice(0, 10).replace(/-/g, '')}-${crypto
    .randomBytes(3)
    .toString('hex')
    .toUpperCase()}`;
  const guestAccessToken = params.userId ? null : crypto.randomBytes(24).toString('hex');
  const guestAccessTokenHash = guestAccessToken
    ? crypto.createHash('sha256').update(guestAccessToken).digest('hex')
    : null;

  const result = withTransaction(db, () => {
    const again = db
      .prepare('SELECT id, total_cents, order_status, payment_status FROM orders WHERE idempotency_key = ?')
      .get(params.idempotencyKey) as
      | { id: string; total_cents: number; order_status: string; payment_status: string }
      | undefined;

    if (again) {
      return {
        orderId: again.id,
        totalCents: again.total_cents,
        orderStatus: again.order_status,
        paymentStatus: again.payment_status,
        reusedIdempotent: true,
        guestAccessToken: null as string | null,
        reservationExpiresAt: null as string | null,
      };
    }

    // Re-read authoritative SKUs & inventory inside BEGIN IMMEDIATE transaction
    const items = db
      .prepare(
        `SELECT ci.sku, ci.cases_qty, s.title, s.description, pf.brand,
                s.variant_attributes_json, s.consumer_selling_unit,
                s.items_per_consumer_pack, s.consumer_units_per_case, s.case_price_cents,
                s.delivery_eligible, s.pickup_eligible, s.active
         FROM cart_items ci
         JOIN skus s ON s.sku = ci.sku
         JOIN product_families pf ON pf.id = s.family_id
         WHERE ci.cart_id = ? AND ci.saved_for_later = 0`
      )
      .all(params.cartId) as Array<{
      sku: string;
      cases_qty: number;
      title: string;
      description: string;
      brand: string;
      variant_attributes_json: string;
      consumer_selling_unit: string;
      items_per_consumer_pack: number | null;
      consumer_units_per_case: number;
      case_price_cents: number;
      delivery_eligible: number;
      pickup_eligible: number;
      active: number;
    }>;

    if (items.length === 0) {
      throw new CheckoutConflictError('Cart is empty.');
    }

    const lineSnapshots: Array<{
      sku: string;
      title: string;
      description: string;
      brand: string;
      variantAttributesJson: string;
      consumerSellingUnit: string;
      itemsPerConsumerPack: number | null;
      consumerUnitsPerCase: number;
      casesOrdered: number;
      totalConsumerUnits: number;
      casePriceCents: number;
      unitPriceCents: number;
      lineSubtotalCents: number;
    }> = [];

    for (const item of items) {
      const inv = db
        .prepare('SELECT on_hand_cases, reserved_cases FROM inventory_levels WHERE sku = ? AND location_id = ?')
        .get(item.sku, params.locationId) as { on_hand_cases: number; reserved_cases: number } | undefined;

      const available = inv ? inv.on_hand_cases - inv.reserved_cases : 0;
      if (available < item.cases_qty) {
        throw new CheckoutConflictError(
          `Insufficient available cases for ${item.title} (${item.sku}): requested ${item.cases_qty}, available ${Math.max(0, available)}.`
        );
      }

      const breakdown = computePackagingBreakdown({
        consumerSellingUnit: item.consumer_selling_unit,
        itemsPerConsumerPack: item.items_per_consumer_pack,
        consumerUnitsPerCase: item.consumer_units_per_case,
        casePriceCents: item.case_price_cents,
      });

      lineSnapshots.push({
        sku: item.sku,
        title: item.title,
        description: item.description,
        brand: item.brand,
        variantAttributesJson: item.variant_attributes_json,
        consumerSellingUnit: item.consumer_selling_unit,
        itemsPerConsumerPack: item.items_per_consumer_pack,
        consumerUnitsPerCase: item.consumer_units_per_case,
        casesOrdered: item.cases_qty,
        totalConsumerUnits: item.cases_qty * item.consumer_units_per_case,
        casePriceCents: breakdown.casePriceCents,
        unitPriceCents: breakdown.unitPriceCents,
        lineSubtotalCents: item.cases_qty * breakdown.casePriceCents,
      });
    }

    const destState =
      params.fulfilmentMethod === 'pickup'
        ? quote.locationAddress.split(',').slice(-1)[0]?.trim().split(' ')[0] || 'NJ'
        : (params.shippingAddress?.state || 'NJ').trim().toUpperCase();

    const serverTotals = calculateOrderTotals({
      lineSubtotalsCents: lineSnapshots.map((l) => l.lineSubtotalCents),
      fulfilmentMethod: params.fulfilmentMethod,
      destinationState: destState,
    });

    db.prepare(
      `INSERT INTO orders (
        id, user_id, guest_access_token_hash, customer_email, customer_name, customer_phone,
        order_status, payment_status, fulfilment_status, fulfilment_method,
        location_id, location_name_snapshot, shipping_address_json, po_reference,
        company_billing_json, merchandise_subtotal_cents, discount_cents,
        delivery_fee_cents, tax_cents, total_cents, currency, tax_rate_bps,
        tax_estimate_note, idempotency_key, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'pending_payment', 'unpaid', 'unfulfilled', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'USD', ?, ?, ?, ?, ?)`
    ).run(
      orderId,
      params.userId ?? null,
      guestAccessTokenHash,
      params.contact.email.trim().toLowerCase(),
      params.contact.name.trim(),
      params.contact.phone.trim(),
      params.fulfilmentMethod,
      params.locationId,
      quote.locationName,
      JSON.stringify(params.shippingAddress ?? {}),
      (params.contact.poReference || '').trim(),
      JSON.stringify({
        companyName: (params.contact.companyName || '').trim(),
        billingEmail: (params.contact.billingEmail || '').trim(),
        taxId: (params.contact.taxId || '').trim(),
      }),
      serverTotals.merchandiseSubtotalCents,
      serverTotals.discountCents,
      serverTotals.deliveryFeeCents,
      serverTotals.taxCents,
      serverTotals.totalCents,
      serverTotals.taxRateBps,
      serverTotals.taxEstimateNote,
      params.idempotencyKey,
      nowIso,
      nowIso
    );

    const insertOrderItem = db.prepare(
      `INSERT INTO order_items (
        id, order_id, sku, title_snapshot, description_snapshot, brand_snapshot,
        variant_attributes_snapshot_json, consumer_selling_unit_snapshot,
        items_per_consumer_pack_snapshot, consumer_units_per_case_snapshot,
        cases_ordered, total_consumer_units, case_price_cents_snapshot,
        unit_price_cents_snapshot, line_subtotal_cents
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const insertRes = db.prepare(
      `INSERT INTO stock_reservations
       (id, order_attempt_id, sku, location_id, cases_reserved, status, expires_at, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?)`
    );

    const reserveInv = db.prepare(
      `UPDATE inventory_levels
       SET reserved_cases = reserved_cases + ?, updated_at = ?
       WHERE sku = ? AND location_id = ?`
    );

    for (const snap of lineSnapshots) {
      insertOrderItem.run(
        `OI-${crypto.randomUUID().slice(0, 10)}`,
        orderId,
        snap.sku,
        snap.title,
        snap.description,
        snap.brand,
        snap.variantAttributesJson,
        snap.consumerSellingUnit,
        snap.itemsPerConsumerPack,
        snap.consumerUnitsPerCase,
        snap.casesOrdered,
        snap.totalConsumerUnits,
        snap.casePriceCents,
        snap.unitPriceCents,
        snap.lineSubtotalCents
      );

      insertRes.run(
        `RES-${crypto.randomUUID().slice(0, 10)}`,
        orderId,
        snap.sku,
        params.locationId,
        snap.casesOrdered,
        expiresAtIso,
        nowIso,
        nowIso
      );

      reserveInv.run(snap.casesOrdered, nowIso, snap.sku, params.locationId);
    }

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, ?, 'customer', 'checkout.reservation_created', 'order', ?, ?, ?)`
    ).run(
      `AUD-${crypto.randomUUID().slice(0, 10)}`,
      params.userId ?? null,
      params.contact.email.trim().toLowerCase(),
      orderId,
      JSON.stringify({ totalCents: serverTotals.totalCents, expiresAt: expiresAtIso }),
      nowIso
    );

    return {
      orderId,
      totalCents: serverTotals.totalCents,
      orderStatus: 'pending_payment',
      paymentStatus: 'unpaid',
      reusedIdempotent: false,
      guestAccessToken,
      reservationExpiresAt: expiresAtIso,
      cartId: params.cartId,
    };
  });

  logEvent('info', 'checkout.attempt_created', {
    orderId: result.orderId,
    totalCents: result.totalCents,
  });
  return result;
}

export function processPaymentWebhook(params: {
  provider: 'local_simulator' | 'stripe_sandbox';
  providerEventId: string;
  eventType: 'payment.succeeded' | 'payment.failed';
  orderId: string;
  amountCents: number;
  cartIdToClear?: string;
}): {
  deduplicated: boolean;
  orderStatus: string;
  paymentStatus: string;
  reconciledAction: string;
} {
  const db = getDb();
  const nowIso = new Date().toISOString();

  return withTransaction(db, () => {
    const existingEvent = db
      .prepare('SELECT id FROM payment_events WHERE provider_event_id = ?')
      .get(params.providerEventId) as { id: string } | undefined;

    const order = db
      .prepare('SELECT * FROM orders WHERE id = ?')
      .get(params.orderId) as
      | {
          id: string;
          order_status: string;
          payment_status: string;
          location_id: string;
          total_cents: number;
          user_id: string | null;
        }
      | undefined;

    if (!order) {
      throw new Error(`Order ${params.orderId} not found.`);
    }

    if (existingEvent) {
      return {
        deduplicated: true,
        orderStatus: order.order_status,
        paymentStatus: order.payment_status,
        reconciledAction: 'duplicate_webhook_ignored',
      };
    }

    db.prepare(
      `INSERT INTO payment_events
       (id, order_id, provider, provider_event_id, event_type, amount_cents, status, raw_redacted_json, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      `PEV-${crypto.randomUUID().slice(0, 10)}`,
      order.id,
      params.provider,
      params.providerEventId,
      params.eventType,
      params.amountCents,
      params.eventType === 'payment.succeeded' ? 'succeeded' : 'failed',
      JSON.stringify({ provider: params.provider, eventType: params.eventType, amountCents: params.amountCents }),
      nowIso
    );

    const reservations = db
      .prepare('SELECT * FROM stock_reservations WHERE order_attempt_id = ?')
      .all(order.id) as Array<{
      id: string;
      sku: string;
      location_id: string;
      cases_reserved: number;
      status: string;
      expires_at: string;
    }>;

    if (params.eventType === 'payment.failed') {
      for (const r of reservations) {
        if (r.status === 'active') {
          db.prepare("UPDATE stock_reservations SET status = 'released', updated_at = ? WHERE id = ?").run(
            nowIso,
            r.id
          );
          db.prepare(
            `UPDATE inventory_levels SET reserved_cases = MAX(0, reserved_cases - ?), updated_at = ?
             WHERE sku = ? AND location_id = ?`
          ).run(r.cases_reserved, nowIso, r.sku, r.location_id);
        }
      }
      db.prepare(
        `UPDATE orders
         SET payment_status = 'failed', order_status = 'cancelled', fulfilment_status = 'cancelled', updated_at = ?
         WHERE id = ?`
      ).run(nowIso, order.id);

      return {
        deduplicated: false,
        orderStatus: 'cancelled',
        paymentStatus: 'failed',
        reconciledAction: 'reservations_released',
      };
    }

    // payment.succeeded
    if (order.payment_status === 'paid') {
      return {
        deduplicated: false,
        orderStatus: order.order_status,
        paymentStatus: order.payment_status,
        reconciledAction: 'already_paid',
      };
    }

    const hasActiveValid =
      reservations.length > 0 &&
      reservations.every((r) => r.status === 'active' && new Date(r.expires_at).getTime() > Date.now());

    if (hasActiveValid) {
      for (const r of reservations) {
        db.prepare("UPDATE stock_reservations SET status = 'committed', updated_at = ? WHERE id = ?").run(
          nowIso,
          r.id
        );
        db.prepare(
          `UPDATE inventory_levels
           SET on_hand_cases = MAX(0, on_hand_cases - ?),
               reserved_cases = MAX(0, reserved_cases - ?),
               updated_at = ?
           WHERE sku = ? AND location_id = ?`
        ).run(r.cases_reserved, r.cases_reserved, nowIso, r.sku, r.location_id);
      }

      db.prepare(
        `UPDATE orders
         SET order_status = 'confirmed', payment_status = 'paid', fulfilment_status = 'unfulfilled', updated_at = ?
         WHERE id = ?`
      ).run(nowIso, order.id);

      if (params.cartIdToClear) {
        db.prepare('DELETE FROM cart_items WHERE cart_id = ? AND saved_for_later = 0').run(
          params.cartIdToClear
        );
      } else if (order.user_id) {
        const userCart = db.prepare('SELECT id FROM carts WHERE user_id = ?').get(order.user_id) as
          | { id: string }
          | undefined;
        if (userCart) {
          db.prepare('DELETE FROM cart_items WHERE cart_id = ? AND saved_for_later = 0').run(
            userCart.id
          );
        }
      }

      db.prepare(
        `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
         VALUES (?, NULL, 'payment-webhook', 'system', 'order.payment_confirmed', 'order', ?, ?, ?)`
      ).run(
        `AUD-${crypto.randomUUID().slice(0, 10)}`,
        order.id,
        JSON.stringify({ providerEventId: params.providerEventId, amountCents: params.amountCents }),
        nowIso
      );

      return {
        deduplicated: false,
        orderStatus: 'confirmed',
        paymentStatus: 'paid',
        reconciledAction: 'committed_active_reservation',
      };
    }

    // Delayed webhook arrived after reservation expired!
    const orderLines = db
      .prepare('SELECT sku, cases_ordered FROM order_items WHERE order_id = ?')
      .all(order.id) as Array<{ sku: string; cases_ordered: number }>;

    let canReallocate = orderLines.length > 0;
    for (const line of orderLines) {
      const inv = db
        .prepare('SELECT on_hand_cases, reserved_cases FROM inventory_levels WHERE sku = ? AND location_id = ?')
        .get(line.sku, order.location_id) as { on_hand_cases: number; reserved_cases: number } | undefined;
      if (!inv || inv.on_hand_cases - inv.reserved_cases < line.cases_ordered) {
        canReallocate = false;
        break;
      }
    }

    if (canReallocate) {
      for (const line of orderLines) {
        db.prepare(
          `UPDATE inventory_levels
           SET on_hand_cases = on_hand_cases - ?, updated_at = ?
           WHERE sku = ? AND location_id = ?`
        ).run(line.cases_ordered, nowIso, line.sku, order.location_id);
      }
      db.prepare(
        "UPDATE stock_reservations SET status = 'committed', updated_at = ? WHERE order_attempt_id = ?"
      ).run(nowIso, order.id);
      db.prepare(
        `UPDATE orders
         SET order_status = 'confirmed', payment_status = 'paid', fulfilment_status = 'unfulfilled', updated_at = ?
         WHERE id = ?`
      ).run(nowIso, order.id);

      db.prepare(
        `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
         VALUES (?, NULL, 'payment-webhook', 'system', 'order.delayed_webhook_reallocated', 'order', ?, ?, ?)`
      ).run(
        `AUD-${crypto.randomUUID().slice(0, 10)}`,
        order.id,
        JSON.stringify({ providerEventId: params.providerEventId }),
        nowIso
      );

      return {
        deduplicated: false,
        orderStatus: 'confirmed',
        paymentStatus: 'paid',
        reconciledAction: 'reallocated_after_expiry',
      };
    }

    // Stock no longer available after expiry -> reconciliation + automatic refund!
    db.prepare(
      `UPDATE orders
       SET order_status = 'reconciliation_required',
           payment_status = 'refunded',
           fulfilment_status = 'cancelled',
           updated_at = ?
       WHERE id = ?`
    ).run(nowIso, order.id);

    db.prepare(
      `INSERT INTO refunds (id, order_id, amount_cents, reason, status, is_partial, actor_user_id, created_at)
       VALUES (?, ?, ?, ?, 'completed', 0, NULL, ?)`
    ).run(
      `REF-${crypto.randomUUID().slice(0, 10)}`,
      order.id,
      params.amountCents,
      'Automatic refund: payment webhook succeeded after stock reservation expired and stock became unavailable.',
      nowIso
    );

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, NULL, 'payment-webhook', 'system', 'order.reconciliation_refund_triggered', 'order', ?, ?, ?)`
    ).run(
      `AUD-${crypto.randomUUID().slice(0, 10)}`,
      order.id,
      JSON.stringify({ providerEventId: params.providerEventId, amountCents: params.amountCents }),
      nowIso
    );

    return {
      deduplicated: false,
      orderStatus: 'reconciliation_required',
      paymentStatus: 'refunded',
      reconciledAction: 'auto_refunded_post_expiry_oversell_prevented',
    };
  });
}
