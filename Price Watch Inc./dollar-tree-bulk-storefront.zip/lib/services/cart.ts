import crypto from 'node:crypto';
import { getDb, withTransaction } from '../db';
import { STORE_CONFIG } from '../config';
import {
  computePackagingBreakdown,
  validateCaseQuantity,
  type PackagingBreakdown,
} from '../pricing';

export interface CartLineView {
  id: string;
  sku: string;
  title: string;
  subtitle: string;
  image: string;
  variantAttributes: Record<string, string>;
  isAssorted: boolean;
  assortedSelectionNote: string;
  casesQty: number;
  totalConsumerUnits: number;
  totalIndividualItems: number;
  packaging: PackagingBreakdown;
  lineSubtotalCents: number;
  savedForLater: boolean;
  deliveryEligible: boolean;
  pickupEligible: boolean;
  minCaseQuantity: number;
  caseIncrement: number;
  availableAtSelectedLocation: number;
  priceChanged: boolean;
  previousCasePriceCents: number;
  active: boolean;
}

export interface CartSummary {
  cartId: string;
  fulfilmentMethod: 'delivery' | 'pickup';
  locationId: string;
  destinationZip: string;
  destinationState: string;
  activeLines: CartLineView[];
  savedLines: CartLineView[];
  totalCases: number;
  totalConsumerUnits: number;
  merchandiseSubtotalCents: number;
  notices: string[];
}

export function getOrCreateCart(params: {
  userId?: string | null;
  guestToken?: string | null;
}): { cartId: string; guestToken: string } {
  const db = getDb();
  const now = new Date().toISOString();

  if (params.userId) {
    const existing = db
      .prepare('SELECT id, guest_token FROM carts WHERE user_id = ?')
      .get(params.userId) as { id: string; guest_token: string | null } | undefined;
    if (existing) {
      return { cartId: existing.id, guestToken: existing.guest_token || '' };
    }
    const cartId = `CRT-${crypto.randomUUID().slice(0, 10)}`;
    db.prepare(
      `INSERT INTO carts (id, guest_token, user_id, fulfilment_method, location_id, destination_zip, destination_state, updated_at)
       VALUES (?, NULL, ?, 'delivery', 'LOC-DC-EAST', '08002', 'NJ', ?)`
    ).run(cartId, params.userId, now);
    return { cartId, guestToken: '' };
  }

  const token = params.guestToken?.trim() || crypto.randomBytes(20).toString('hex');
  const existingGuest = db
    .prepare('SELECT id FROM carts WHERE guest_token = ?')
    .get(token) as { id: string } | undefined;
  if (existingGuest) {
    return { cartId: existingGuest.id, guestToken: token };
  }

  const cartId = `CRT-${crypto.randomUUID().slice(0, 10)}`;
  db.prepare(
    `INSERT INTO carts (id, guest_token, user_id, fulfilment_method, location_id, destination_zip, destination_state, updated_at)
     VALUES (?, ?, NULL, 'delivery', 'LOC-DC-EAST', '08002', 'NJ', ?)`
  ).run(cartId, token, now);
  return { cartId, guestToken: token };
}

export function getCartView(cartId: string): CartSummary {
  const db = getDb();
  const cart = db
    .prepare('SELECT * FROM carts WHERE id = ?')
    .get(cartId) as
    | {
        id: string;
        fulfilment_method: 'delivery' | 'pickup';
        location_id: string | null;
        destination_zip: string;
        destination_state: string;
      }
    | undefined;

  if (!cart) {
    throw new Error('Cart not found.');
  }

  const locationId =
    cart.location_id || (cart.fulfilment_method === 'pickup' ? 'LOC-STR-104' : 'LOC-DC-EAST');

  const rows = db
    .prepare(
      `SELECT ci.id, ci.sku, ci.cases_qty, ci.case_price_snapshot_cents, ci.saved_for_later,
              s.title, s.subtitle, s.images_json, s.variant_attributes_json,
              s.consumer_selling_unit, s.items_per_consumer_pack, s.consumer_units_per_case,
              s.case_price_cents, s.min_case_quantity, s.case_increment,
              s.delivery_eligible, s.pickup_eligible, s.active,
              pf.is_assorted, pf.assorted_selection_note,
              COALESCE(il.on_hand_cases - il.reserved_cases, 0) as available_cases
       FROM cart_items ci
       JOIN skus s ON s.sku = ci.sku
       JOIN product_families pf ON pf.id = s.family_id
       LEFT JOIN inventory_levels il ON il.sku = ci.sku AND il.location_id = ?
       WHERE ci.cart_id = ?
       ORDER BY ci.added_at ASC`
    )
    .all(locationId, cartId) as Array<{
    id: string;
    sku: string;
    cases_qty: number;
    case_price_snapshot_cents: number;
    saved_for_later: number;
    title: string;
    subtitle: string;
    images_json: string;
    variant_attributes_json: string;
    consumer_selling_unit: string;
    items_per_consumer_pack: number | null;
    consumer_units_per_case: number;
    case_price_cents: number;
    min_case_quantity: number;
    case_increment: number;
    delivery_eligible: number;
    pickup_eligible: number;
    active: number;
    is_assorted: number;
    assorted_selection_note: string;
    available_cases: number;
  }>;

  const notices: string[] = [];
  const activeLines: CartLineView[] = [];
  const savedLines: CartLineView[] = [];

  for (const r of rows) {
    const packaging = computePackagingBreakdown({
      consumerSellingUnit: r.consumer_selling_unit,
      itemsPerConsumerPack: r.items_per_consumer_pack,
      consumerUnitsPerCase: r.consumer_units_per_case,
      casePriceCents: r.case_price_cents,
    });
    const images = JSON.parse(r.images_json || '[]') as string[];
    const priceChanged = r.case_price_snapshot_cents !== r.case_price_cents;
    const availableAtLoc = Math.max(0, r.available_cases);

    if (!r.saved_for_later) {
      if (priceChanged) {
        notices.push(
          `Price updated for ${r.title} (${r.sku}): case price changed from $${(
            r.case_price_snapshot_cents / 100
          ).toFixed(2)} to $${(r.case_price_cents / 100).toFixed(2)}.`
        );
      }
      if (!r.active) {
        notices.push(`${r.title} (${r.sku}) is currently inactive and cannot be checked out.`);
      } else if (cart.fulfilment_method === 'delivery' && !r.delivery_eligible) {
        notices.push(`${r.title} is not eligible for delivery.`);
      } else if (cart.fulfilment_method === 'pickup' && !r.pickup_eligible) {
        notices.push(`${r.title} is not eligible for store pickup.`);
      } else if (availableAtLoc < r.cases_qty) {
        notices.push(
          `${r.title} only has ${availableAtLoc} case(s) available at the selected location (cart has ${r.cases_qty}).`
        );
      }
    }

    const line: CartLineView = {
      id: r.id,
      sku: r.sku,
      title: r.title,
      subtitle: r.subtitle,
      image: images[0] || '/images/products/dish-soap.jpg',
      variantAttributes: JSON.parse(r.variant_attributes_json || '{}') as Record<string, string>,
      isAssorted: Boolean(r.is_assorted),
      assortedSelectionNote: r.assorted_selection_note,
      casesQty: r.cases_qty,
      totalConsumerUnits: r.cases_qty * packaging.consumerUnitsPerCase,
      totalIndividualItems: r.cases_qty * packaging.totalIndividualItemsPerCase,
      packaging,
      lineSubtotalCents: r.cases_qty * packaging.casePriceCents,
      savedForLater: Boolean(r.saved_for_later),
      deliveryEligible: Boolean(r.delivery_eligible),
      pickupEligible: Boolean(r.pickup_eligible),
      minCaseQuantity: r.min_case_quantity,
      caseIncrement: r.case_increment,
      availableAtSelectedLocation: availableAtLoc,
      priceChanged,
      previousCasePriceCents: r.case_price_snapshot_cents,
      active: Boolean(r.active),
    };

    if (line.savedForLater) {
      savedLines.push(line);
    } else {
      activeLines.push(line);
    }
  }

  const totalCases = activeLines.reduce((s, l) => s + l.casesQty, 0);
  const totalConsumerUnits = activeLines.reduce((s, l) => s + l.totalConsumerUnits, 0);
  const merchandiseSubtotalCents = activeLines.reduce((s, l) => s + l.lineSubtotalCents, 0);

  return {
    cartId,
    fulfilmentMethod: cart.fulfilment_method,
    locationId,
    destinationZip: cart.destination_zip,
    destinationState: cart.destination_state,
    activeLines,
    savedLines,
    totalCases,
    totalConsumerUnits,
    merchandiseSubtotalCents,
    notices,
  };
}

export function upsertCartItem(params: {
  cartId: string;
  sku: string;
  casesDeltaOrSet: number;
  mode: 'add' | 'set';
  savedForLater?: boolean;
}): CartSummary {
  const db = getDb();
  const cleanSku = params.sku.trim().toUpperCase();
  const now = new Date().toISOString();

  withTransaction(db, () => {
    const skuRow = db
      .prepare(
        `SELECT sku, case_price_cents, consumer_units_per_case, min_case_quantity, case_increment, active
         FROM skus WHERE sku = ?`
      )
      .get(cleanSku) as
      | {
          sku: string;
          case_price_cents: number;
          consumer_units_per_case: number;
          min_case_quantity: number;
          case_increment: number;
          active: number;
        }
      | undefined;

    if (!skuRow || !skuRow.active) {
      throw new Error(`Product ${cleanSku} is unavailable or inactive.`);
    }

    const unitPrice = Math.floor(
      (skuRow.case_price_cents + Math.floor(skuRow.consumer_units_per_case / 2)) /
        skuRow.consumer_units_per_case
    );
    const savedFlag = params.savedForLater ? 1 : 0;

    const existing = db
      .prepare(
        'SELECT id, cases_qty FROM cart_items WHERE cart_id = ? AND sku = ? AND saved_for_later = ?'
      )
      .get(params.cartId, cleanSku, savedFlag) as { id: string; cases_qty: number } | undefined;

    if (params.mode === 'set' && params.casesDeltaOrSet <= 0) {
      if (existing) {
        db.prepare('DELETE FROM cart_items WHERE id = ?').run(existing.id);
      }
      db.prepare('UPDATE carts SET updated_at = ? WHERE id = ?').run(now, params.cartId);
      return;
    }

    const nextQty =
      params.mode === 'add'
        ? (existing?.cases_qty ?? 0) + params.casesDeltaOrSet
        : params.casesDeltaOrSet;

    const validation = validateCaseQuantity(
      nextQty,
      skuRow.min_case_quantity,
      skuRow.case_increment,
      STORE_CONFIG.maxCartCasesPerSku
    );
    if (!validation.valid) {
      throw new Error(validation.reason || 'Invalid case quantity.');
    }

    // Enforce bounded cart size & line count
    const totals = db
      .prepare(
        `SELECT COUNT(*) as line_count, COALESCE(SUM(cases_qty), 0) as total_cases
         FROM cart_items WHERE cart_id = ? AND saved_for_later = 0 AND sku != ?`
      )
      .get(params.cartId, cleanSku) as { line_count: number; total_cases: number };

    if (savedFlag === 0) {
      if (!existing && totals.line_count >= STORE_CONFIG.maxCartLineCount) {
        throw new Error(`Cart cannot exceed ${STORE_CONFIG.maxCartLineCount} distinct SKUs.`);
      }
      if (totals.total_cases + nextQty > STORE_CONFIG.maxCartTotalCases) {
        throw new Error(`Cart cannot exceed ${STORE_CONFIG.maxCartTotalCases} total cases.`);
      }
    }

    if (existing) {
      db.prepare(
        `UPDATE cart_items
         SET cases_qty = ?, unit_price_snapshot_cents = ?, case_price_snapshot_cents = ?
         WHERE id = ?`
      ).run(nextQty, unitPrice, skuRow.case_price_cents, existing.id);
    } else {
      db.prepare(
        `INSERT INTO cart_items
         (id, cart_id, sku, cases_qty, unit_price_snapshot_cents, case_price_snapshot_cents, saved_for_later, added_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        `CI-${crypto.randomUUID().slice(0, 10)}`,
        params.cartId,
        cleanSku,
        nextQty,
        unitPrice,
        skuRow.case_price_cents,
        savedFlag,
        now
      );
    }

    db.prepare('UPDATE carts SET updated_at = ? WHERE id = ?').run(now, params.cartId);
  });

  return getCartView(params.cartId);
}

export function toggleSaveForLater(cartId: string, sku: string, save: boolean): CartSummary {
  const db = getDb();
  const cleanSku = sku.trim().toUpperCase();
  const fromFlag = save ? 0 : 1;
  const toFlag = save ? 1 : 0;

  withTransaction(db, () => {
    const src = db
      .prepare(
        'SELECT id, cases_qty, unit_price_snapshot_cents, case_price_snapshot_cents FROM cart_items WHERE cart_id = ? AND sku = ? AND saved_for_later = ?'
      )
      .get(cartId, cleanSku, fromFlag) as
      | {
          id: string;
          cases_qty: number;
          unit_price_snapshot_cents: number;
          case_price_snapshot_cents: number;
        }
      | undefined;

    if (!src) return;

    const target = db
      .prepare(
        'SELECT id, cases_qty FROM cart_items WHERE cart_id = ? AND sku = ? AND saved_for_later = ?'
      )
      .get(cartId, cleanSku, toFlag) as { id: string; cases_qty: number } | undefined;

    if (target) {
      const merged = Math.min(STORE_CONFIG.maxCartCasesPerSku, target.cases_qty + src.cases_qty);
      db.prepare('UPDATE cart_items SET cases_qty = ? WHERE id = ?').run(merged, target.id);
      db.prepare('DELETE FROM cart_items WHERE id = ?').run(src.id);
    } else {
      db.prepare('UPDATE cart_items SET saved_for_later = ? WHERE id = ?').run(toFlag, src.id);
    }
  });

  return getCartView(cartId);
}

export function updateCartFulfilment(params: {
  cartId: string;
  fulfilmentMethod: 'delivery' | 'pickup';
  locationId: string;
  destinationZip?: string;
  destinationState?: string;
}): CartSummary {
  const db = getDb();
  const loc = db
    .prepare('SELECT id, type, state, zip FROM locations WHERE id = ? AND active = 1')
    .get(params.locationId) as
    | { id: string; type: 'warehouse' | 'store'; state: string; zip: string }
    | undefined;
  if (!loc) {
    throw new Error('Selected fulfilment location was not found.');
  }
  if (params.fulfilmentMethod === 'delivery' && loc.type !== 'warehouse') {
    throw new Error('Delivery requires a distribution hub location.');
  }
  if (params.fulfilmentMethod === 'pickup' && loc.type !== 'store') {
    throw new Error('Store pickup requires a store location.');
  }

  db.prepare(
    `UPDATE carts
     SET fulfilment_method = ?, location_id = ?, destination_zip = ?, destination_state = ?, updated_at = ?
     WHERE id = ?`
  ).run(
    params.fulfilmentMethod,
    params.locationId,
    (params.destinationZip || loc.zip).trim(),
    (params.destinationState || loc.state).trim().toUpperCase(),
    new Date().toISOString(),
    params.cartId
  );

  return getCartView(params.cartId);
}

/**
 * Deterministic Cart Merge Rule on Sign-In:
 * 1. Sum guest active quantities into user's active cart by SKU.
 * 2. Clamp to maxCartCasesPerSku and align to SKU case_increment; log notice if adjusted.
 * 3. Move any inactive SKU lines to Saved for Later with an explicit notice.
 * 4. Acknowledge updated case prices against guest snapshot and emit price-change notices.
 * 5. Delete guest cart once merged.
 */
export function mergeGuestCartOnSignIn(
  guestToken: string | null | undefined,
  userId: string
): { cart: CartSummary; mergeNotices: string[] } {
  const db = getDb();
  const mergeNotices: string[] = [];
  const { cartId: userCartId } = getOrCreateCart({ userId });

  if (!guestToken) {
    return { cart: getCartView(userCartId), mergeNotices };
  }

  const guestCart = db
    .prepare('SELECT id, fulfilment_method, location_id, destination_zip, destination_state FROM carts WHERE guest_token = ?')
    .get(guestToken) as
    | {
        id: string;
        fulfilment_method: 'delivery' | 'pickup';
        location_id: string | null;
        destination_zip: string;
        destination_state: string;
      }
    | undefined;

  if (!guestCart || guestCart.id === userCartId) {
    return { cart: getCartView(userCartId), mergeNotices };
  }

  withTransaction(db, () => {
    const guestItems = db
      .prepare(
        `SELECT ci.*, s.title, s.case_price_cents, s.consumer_units_per_case, s.min_case_quantity, s.case_increment, s.active
         FROM cart_items ci
         JOIN skus s ON s.sku = ci.sku
         WHERE ci.cart_id = ?`
      )
      .all(guestCart.id) as Array<{
      id: string;
      sku: string;
      cases_qty: number;
      case_price_snapshot_cents: number;
      saved_for_later: number;
      title: string;
      case_price_cents: number;
      consumer_units_per_case: number;
      min_case_quantity: number;
      case_increment: number;
      active: number;
    }>;

    const now = new Date().toISOString();

    for (const gi of guestItems) {
      const targetSaved = gi.active ? gi.saved_for_later : 1;
      if (!gi.active && gi.saved_for_later === 0) {
        mergeNotices.push(`${gi.title} (${gi.sku}) is inactive and was moved to Saved for later.`);
      }

      const existingUserItem = db
        .prepare(
          'SELECT id, cases_qty FROM cart_items WHERE cart_id = ? AND sku = ? AND saved_for_later = ?'
        )
        .get(userCartId, gi.sku, targetSaved) as { id: string; cases_qty: number } | undefined;

      const rawCombined = (existingUserItem?.cases_qty ?? 0) + gi.cases_qty;
      let finalQty = Math.min(STORE_CONFIG.maxCartCasesPerSku, rawCombined);
      if (finalQty < gi.min_case_quantity) {
        finalQty = gi.min_case_quantity;
      }
      if ((finalQty - gi.min_case_quantity) % gi.case_increment !== 0) {
        finalQty -= (finalQty - gi.min_case_quantity) % gi.case_increment;
      }

      if (finalQty !== rawCombined) {
        mergeNotices.push(
          `Adjusted ${gi.title} (${gi.sku}) from ${rawCombined} to ${finalQty} case(s) to respect case increments and order limits.`
        );
      } else if (existingUserItem && targetSaved === 0) {
        mergeNotices.push(
          `Merged ${gi.cases_qty} guest case(s) of ${gi.title} with ${existingUserItem.cases_qty} saved account case(s) (${finalQty} total).`
        );
      }

      if (gi.case_price_snapshot_cents !== gi.case_price_cents) {
        mergeNotices.push(
          `Updated ${gi.title} price to current $${(gi.case_price_cents / 100).toFixed(2)} / case.`
        );
      }

      const unitPrice = Math.floor(
        (gi.case_price_cents + Math.floor(gi.consumer_units_per_case / 2)) /
          gi.consumer_units_per_case
      );

      if (existingUserItem) {
        db.prepare(
          'UPDATE cart_items SET cases_qty = ?, unit_price_snapshot_cents = ?, case_price_snapshot_cents = ? WHERE id = ?'
        ).run(finalQty, unitPrice, gi.case_price_cents, existingUserItem.id);
      } else {
        db.prepare(
          `INSERT INTO cart_items (id, cart_id, sku, cases_qty, unit_price_snapshot_cents, case_price_snapshot_cents, saved_for_later, added_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          `CI-${crypto.randomUUID().slice(0, 10)}`,
          userCartId,
          gi.sku,
          finalQty,
          unitPrice,
          gi.case_price_cents,
          targetSaved,
          now
        );
      }
    }

    // Preserve guest fulfilment selection if user cart was empty
    const userActiveCount = db
      .prepare('SELECT COUNT(*) as cnt FROM cart_items WHERE cart_id = ? AND saved_for_later = 0')
      .get(userCartId) as { cnt: number };
    if (userActiveCount.cnt > 0 && guestCart.location_id) {
      db.prepare(
        'UPDATE carts SET fulfilment_method = ?, location_id = ?, destination_zip = ?, destination_state = ?, updated_at = ? WHERE id = ?'
      ).run(
        guestCart.fulfilment_method,
        guestCart.location_id,
        guestCart.destination_zip,
        guestCart.destination_state,
        now,
        userCartId
      );
    }

    db.prepare('DELETE FROM carts WHERE id = ?').run(guestCart.id);
  });

  return { cart: getCartView(userCartId), mergeNotices };
}

export function acceptCartPriceChanges(cartId: string): CartSummary {
  const db = getDb();
  db.prepare(
    `UPDATE cart_items
     SET case_price_snapshot_cents = (SELECT case_price_cents FROM skus WHERE skus.sku = cart_items.sku),
         unit_price_snapshot_cents = (
           SELECT (case_price_cents + (consumer_units_per_case / 2)) / consumer_units_per_case
           FROM skus WHERE skus.sku = cart_items.sku
         )
     WHERE cart_id = ?`
  ).run(cartId);
  return getCartView(cartId);
}
