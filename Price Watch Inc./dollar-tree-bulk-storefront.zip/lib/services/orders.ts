import crypto from 'node:crypto';
import { getDb, withTransaction } from '../db';
import { DELIVERY_TRANSITIONS, PICKUP_TRANSITIONS } from '../config';
import type { AuthUser } from '../auth';
import { getOrCreateCart, upsertCartItem } from './cart';

export interface OrderItemSnapshotView {
  id: string;
  sku: string;
  titleSnapshot: string;
  descriptionSnapshot: string;
  brandSnapshot: string;
  variantAttributesSnapshot: Record<string, string>;
  consumerSellingUnitSnapshot: string;
  itemsPerConsumerPackSnapshot: number | null;
  consumerUnitsPerCaseSnapshot: number;
  casesOrdered: number;
  totalConsumerUnits: number;
  casePriceCentsSnapshot: number;
  unitPriceCentsSnapshot: number;
  lineSubtotalCents: number;
}

export interface OrderDetailView {
  id: string;
  userId: string | null;
  customerEmail: string;
  customerName: string;
  customerPhone: string;
  orderStatus: string;
  paymentStatus: string;
  fulfilmentStatus: string;
  fulfilmentMethod: 'delivery' | 'pickup';
  locationId: string;
  locationNameSnapshot: string;
  shippingAddress: Record<string, string>;
  poReference: string;
  companyBilling: Record<string, string>;
  merchandiseSubtotalCents: number;
  discountCents: number;
  deliveryFeeCents: number;
  taxCents: number;
  totalCents: number;
  currency: string;
  taxRateBps: number;
  taxEstimateNote: string;
  cancellationRequested: boolean;
  cancellationReason: string;
  createdAt: string;
  updatedAt: string;
  items: OrderItemSnapshotView[];
  transitions: Array<{
    id: string;
    fromStatus: string;
    toStatus: string;
    actorName: string;
    note: string;
    createdAt: string;
  }>;
  refunds: Array<{
    id: string;
    amountCents: number;
    reason: string;
    status: string;
    isPartial: boolean;
    createdAt: string;
  }>;
}

function hydrateOrder(orderRow: Record<string, unknown>): OrderDetailView {
  const db = getDb();
  const orderId = String(orderRow.id);

  const items = db
    .prepare('SELECT * FROM order_items WHERE order_id = ?')
    .all(orderId) as Array<Record<string, unknown>>;

  const transitions = db
    .prepare('SELECT * FROM fulfilment_transitions WHERE order_id = ? ORDER BY created_at ASC')
    .all(orderId) as Array<Record<string, unknown>>;

  const refunds = db
    .prepare('SELECT * FROM refunds WHERE order_id = ? ORDER BY created_at ASC')
    .all(orderId) as Array<Record<string, unknown>>;

  return {
    id: orderId,
    userId: (orderRow.user_id as string) || null,
    customerEmail: String(orderRow.customer_email),
    customerName: String(orderRow.customer_name),
    customerPhone: String(orderRow.customer_phone),
    orderStatus: String(orderRow.order_status),
    paymentStatus: String(orderRow.payment_status),
    fulfilmentStatus: String(orderRow.fulfilment_status),
    fulfilmentMethod: orderRow.fulfilment_method as 'delivery' | 'pickup',
    locationId: String(orderRow.location_id),
    locationNameSnapshot: String(orderRow.location_name_snapshot),
    shippingAddress: JSON.parse(String(orderRow.shipping_address_json || '{}')),
    poReference: String(orderRow.po_reference || ''),
    companyBilling: JSON.parse(String(orderRow.company_billing_json || '{}')),
    merchandiseSubtotalCents: Number(orderRow.merchandise_subtotal_cents),
    discountCents: Number(orderRow.discount_cents),
    deliveryFeeCents: Number(orderRow.delivery_fee_cents),
    taxCents: Number(orderRow.tax_cents),
    totalCents: Number(orderRow.total_cents),
    currency: String(orderRow.currency),
    taxRateBps: Number(orderRow.tax_rate_bps),
    taxEstimateNote: String(orderRow.tax_estimate_note || ''),
    cancellationRequested: Boolean(orderRow.cancellation_requested),
    cancellationReason: String(orderRow.cancellation_reason || ''),
    createdAt: String(orderRow.created_at),
    updatedAt: String(orderRow.updated_at),
    items: items.map((i) => ({
      id: String(i.id),
      sku: String(i.sku),
      titleSnapshot: String(i.title_snapshot),
      descriptionSnapshot: String(i.description_snapshot),
      brandSnapshot: String(i.brand_snapshot),
      variantAttributesSnapshot: JSON.parse(String(i.variant_attributes_snapshot_json || '{}')),
      consumerSellingUnitSnapshot: String(i.consumer_selling_unit_snapshot),
      itemsPerConsumerPackSnapshot:
        i.items_per_consumer_pack_snapshot === null ? null : Number(i.items_per_consumer_pack_snapshot),
      consumerUnitsPerCaseSnapshot: Number(i.consumer_units_per_case_snapshot),
      casesOrdered: Number(i.cases_ordered),
      totalConsumerUnits: Number(i.total_consumer_units),
      casePriceCentsSnapshot: Number(i.case_price_cents_snapshot),
      unitPriceCentsSnapshot: Number(i.unit_price_cents_snapshot),
      lineSubtotalCents: Number(i.line_subtotal_cents),
    })),
    transitions: transitions.map((t) => ({
      id: String(t.id),
      fromStatus: String(t.from_status),
      toStatus: String(t.to_status),
      actorName: String(t.actor_name),
      note: String(t.note || ''),
      createdAt: String(t.created_at),
    })),
    refunds: refunds.map((r) => ({
      id: String(r.id),
      amountCents: Number(r.amount_cents),
      reason: String(r.reason),
      status: String(r.status),
      isPartial: Boolean(r.is_partial),
      createdAt: String(r.created_at),
    })),
  };
}

export function listOrdersForUser(userId: string): OrderDetailView[] {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC')
    .all(userId) as Array<Record<string, unknown>>;
  return rows.map(hydrateOrder);
}

export function listAllOrdersAdmin(): OrderDetailView[] {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 200')
    .all() as Array<Record<string, unknown>>;
  return rows.map(hydrateOrder);
}

export function getOrderScoped(params: {
  orderId: string;
  user: AuthUser | null;
  guestToken?: string | null;
}): OrderDetailView | null {
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM orders WHERE id = ?')
    .get(params.orderId) as Record<string, unknown> | undefined;
  if (!row) return null;

  const isStaff =
    params.user &&
    ['admin', 'fulfilment_staff', 'customer_service', 'catalogue_manager'].includes(params.user.role);

  if (isStaff) {
    return hydrateOrder(row);
  }
  if (params.user && row.user_id && String(row.user_id) === params.user.id) {
    return hydrateOrder(row);
  }
  if (params.guestToken && row.guest_access_token_hash) {
    const hash = crypto.createHash('sha256').update(params.guestToken).digest('hex');
    if (hash === String(row.guest_access_token_hash)) {
      return hydrateOrder(row);
    }
  }
  return null;
}

export function transitionFulfilmentStatus(params: {
  orderId: string;
  nextStatus: string;
  actor: AuthUser;
  note?: string;
}): OrderDetailView {
  const db = getDb();
  const nowIso = new Date().toISOString();

  return withTransaction(db, () => {
    const row = db
      .prepare('SELECT * FROM orders WHERE id = ?')
      .get(params.orderId) as Record<string, unknown> | undefined;

    if (!row) throw new Error('Order not found.');
    if (String(row.payment_status) !== 'paid' && String(row.payment_status) !== 'partially_refunded') {
      throw new Error('Only paid orders can advance through picking and fulfilment.');
    }

    const method = row.fulfilment_method as 'delivery' | 'pickup';
    const current = String(row.fulfilment_status);
    const allowedMap = method === 'pickup' ? PICKUP_TRANSITIONS : DELIVERY_TRANSITIONS;
    const allowedNext = allowedMap[current] ?? [];

    if (!allowedNext.includes(params.nextStatus)) {
      throw new Error(
        `Invalid ${method} transition from "${current}" to "${params.nextStatus}". Allowed: ${
          allowedNext.join(', ') || 'none'
        }.`
      );
    }

    db.prepare('UPDATE orders SET fulfilment_status = ?, updated_at = ? WHERE id = ?').run(
      params.nextStatus,
      nowIso,
      params.orderId
    );

    if (params.nextStatus === 'cancelled') {
      db.prepare("UPDATE orders SET order_status = 'cancelled', updated_at = ? WHERE id = ?").run(
        nowIso,
        params.orderId
      );
    }

    db.prepare(
      `INSERT INTO fulfilment_transitions
       (id, order_id, from_status, to_status, actor_user_id, actor_name, note, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      `TRN-${crypto.randomUUID().slice(0, 10)}`,
      params.orderId,
      current,
      params.nextStatus,
      params.actor.id,
      `${params.actor.name} (${params.actor.role})`,
      (params.note || '').trim(),
      nowIso
    );

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, ?, ?, 'order.fulfilment_transition', 'order', ?, ?, ?)`
    ).run(
      `AUD-${crypto.randomUUID().slice(0, 10)}`,
      params.actor.id,
      params.actor.email,
      params.actor.role,
      params.orderId,
      JSON.stringify({ from: current, to: params.nextStatus, note: params.note || '' }),
      nowIso
    );

    const updated = db.prepare('SELECT * FROM orders WHERE id = ?').get(params.orderId) as Record<
      string,
      unknown
    >;
    return hydrateOrder(updated);
  });
}

export function issueRefund(params: {
  orderId: string;
  amountCents: number;
  reason: string;
  actor: AuthUser;
}): OrderDetailView {
  const db = getDb();
  const nowIso = new Date().toISOString();

  if (!Number.isInteger(params.amountCents) || params.amountCents <= 0) {
    throw new Error('Refund amount must be a positive integer in cents.');
  }

  return withTransaction(db, () => {
    const row = db
      .prepare('SELECT * FROM orders WHERE id = ?')
      .get(params.orderId) as Record<string, unknown> | undefined;
    if (!row) throw new Error('Order not found.');

    const paymentStatus = String(row.payment_status);
    if (!['paid', 'partially_refunded'].includes(paymentStatus)) {
      throw new Error(`Cannot refund an order with payment status "${paymentStatus}".`);
    }

    const totalCents = Number(row.total_cents);
    const existingRefundRow = db
      .prepare("SELECT COALESCE(SUM(amount_cents), 0) as refunded FROM refunds WHERE order_id = ? AND status = 'completed'")
      .get(params.orderId) as { refunded: number };

    const remainingRefundable = totalCents - existingRefundRow.refunded;
    if (params.amountCents > remainingRefundable) {
      throw new Error(
        `Refund amount ($${(params.amountCents / 100).toFixed(2)}) exceeds remaining refundable balance ($${(
          remainingRefundable / 100
        ).toFixed(2)}).`
      );
    }

    const totalRefundedAfter = existingRefundRow.refunded + params.amountCents;
    const isFull = totalRefundedAfter >= totalCents;
    const nextPaymentStatus = isFull ? 'refunded' : 'partially_refunded';

    db.prepare(
      `INSERT INTO refunds (id, order_id, amount_cents, reason, status, is_partial, actor_user_id, created_at)
       VALUES (?, ?, ?, ?, 'completed', ?, ?, ?)`
    ).run(
      `REF-${crypto.randomUUID().slice(0, 10)}`,
      params.orderId,
      params.amountCents,
      params.reason.trim(),
      isFull ? 0 : 1,
      params.actor.id,
      nowIso
    );

    db.prepare('UPDATE orders SET payment_status = ?, updated_at = ? WHERE id = ?').run(
      nextPaymentStatus,
      nowIso,
      params.orderId
    );

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, ?, ?, 'order.refund_issued', 'order', ?, ?, ?)`
    ).run(
      `AUD-${crypto.randomUUID().slice(0, 10)}`,
      params.actor.id,
      params.actor.email,
      params.actor.role,
      params.orderId,
      JSON.stringify({ amountCents: params.amountCents, isFull, reason: params.reason }),
      nowIso
    );

    const updated = db.prepare('SELECT * FROM orders WHERE id = ?').get(params.orderId) as Record<
      string,
      unknown
    >;
    return hydrateOrder(updated);
  });
}

export function requestOrderCancellation(params: {
  orderId: string;
  reason: string;
  user: AuthUser;
}): OrderDetailView {
  const db = getDb();
  const nowIso = new Date().toISOString();
  const row = db
    .prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?')
    .get(params.orderId, params.user.id) as Record<string, unknown> | undefined;

  if (!row) {
    throw new Error('Order not found for your account.');
  }

  const fStatus = String(row.fulfilment_status);
  if (['dispatched', 'delivered', 'collected', 'cancelled'].includes(fStatus)) {
    throw new Error(
      `Order is already "${fStatus}" and can no longer be cancelled directly. Please contact Customer Service for a return.`
    );
  }

  db.prepare(
    'UPDATE orders SET cancellation_requested = 1, cancellation_reason = ?, updated_at = ? WHERE id = ?'
  ).run(params.reason.trim(), nowIso, params.orderId);

  const updated = db.prepare('SELECT * FROM orders WHERE id = ?').get(params.orderId) as Record<
    string,
    unknown
  >;
  return hydrateOrder(updated);
}

/**
 * Reorder uses CURRENT live catalogue products, prices, and availability,
 * never historical order prices.
 */
export function reorderToCart(params: {
  orderId: string;
  userId?: string | null;
  guestToken?: string | null;
}) {
  const db = getDb();
  const orderItems = db
    .prepare('SELECT sku, title_snapshot, case_price_cents_snapshot, cases_ordered FROM order_items WHERE order_id = ?')
    .all(params.orderId) as Array<{
    sku: string;
    title_snapshot: string;
    case_price_cents_snapshot: number;
    cases_ordered: number;
  }>;

  const { cartId, guestToken } = getOrCreateCart({
    userId: params.userId,
    guestToken: params.guestToken,
  });

  const notices: string[] = [];
  for (const item of orderItems) {
    const liveSku = db
      .prepare('SELECT sku, title, case_price_cents, active FROM skus WHERE sku = ?')
      .get(item.sku) as
      | { sku: string; title: string; case_price_cents: number; active: number }
      | undefined;

    if (!liveSku || !liveSku.active) {
      notices.push(`${item.title_snapshot} (${item.sku}) is no longer active and was skipped.`);
      continue;
    }

    if (liveSku.case_price_cents !== item.case_price_cents_snapshot) {
      notices.push(
        `${liveSku.title} is now $${(liveSku.case_price_cents / 100).toFixed(
          2
        )} / case (previously $${(item.case_price_cents_snapshot / 100).toFixed(2)}).`
      );
    }

    try {
      upsertCartItem({
        cartId,
        sku: item.sku,
        casesDeltaOrSet: item.cases_ordered,
        mode: 'add',
      });
    } catch (err) {
      notices.push(
        `Could not add ${item.title_snapshot}: ${err instanceof Error ? err.message : 'unavailable'}`
      );
    }
  }

  return { cartId, guestToken, notices };
}
