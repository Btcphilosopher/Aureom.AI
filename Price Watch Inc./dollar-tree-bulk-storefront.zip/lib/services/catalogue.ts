import { getDb } from '../db';
import { computePackagingBreakdown, type PackagingBreakdown } from '../pricing';

export interface LocationAvailability {
  locationId: string;
  code: string;
  name: string;
  type: 'warehouse' | 'store';
  city: string;
  state: string;
  zip: string;
  eligibleStates: string[];
  pickupLeadTimeHours: number;
  onHandCases: number;
  reservedCases: number;
  availableCases: number;
}

export interface ProductCatalogItem {
  sku: string;
  familyId: string;
  familySlug: string;
  familyName: string;
  brand: string;
  categorySlug: string;
  categoryName: string;
  title: string;
  subtitle: string;
  description: string;
  images: string[];
  variantAttributes: Record<string, string>;
  requiresVariantSelection: boolean;
  isAssorted: boolean;
  assortedSelectionNote: string;
  tags: string[];
  featuredOrder: number;
  packaging: PackagingBreakdown;
  minCaseQuantity: number;
  caseIncrement: number;
  weightOz: number;
  dimensionsIn: string;
  deliveryEligible: boolean;
  pickupEligible: boolean;
  active: boolean;
  totalDeliveryAvailableCases: number;
  totalPickupAvailableCases: number;
  locationAvailability: LocationAvailability[];
}

export interface ProductSearchFilters {
  q?: string;
  category?: string;
  chip?: 'all' | 'under2' | 'business' | 'party';
  under2?: boolean;
  minCasePriceCents?: number;
  maxCasePriceCents?: number;
  minUnitsPerCase?: number;
  fulfilmentMethod?: 'delivery' | 'pickup' | '';
  locationId?: string;
  inStockOnly?: boolean;
  sort?: 'relevance' | 'unit_price_asc' | 'unit_price_desc' | 'case_price_asc' | 'case_price_desc' | 'name_asc';
  includeInactive?: boolean;
}

interface RawSkuRow {
  sku: string;
  family_id: string;
  family_slug: string;
  family_name: string;
  brand: string;
  category_slug: string;
  category_name: string;
  title: string;
  subtitle: string;
  description: string;
  images_json: string;
  variant_attributes_json: string;
  requires_variant_selection: number;
  is_assorted: number;
  assorted_selection_note: string;
  tags_json: string;
  featured_order: number;
  consumer_selling_unit: string;
  items_per_consumer_pack: number | null;
  consumer_units_per_case: number;
  case_price_cents: number;
  min_case_quantity: number;
  case_increment: number;
  weight_oz: number;
  dimensions_in: string;
  delivery_eligible: number;
  pickup_eligible: number;
  active: number;
}

function hydrateRows(rows: RawSkuRow[]): ProductCatalogItem[] {
  if (rows.length === 0) return [];
  const db = getDb();

  const invRows = db
    .prepare(
      `SELECT il.sku, il.location_id, il.on_hand_cases, il.reserved_cases,
              l.code, l.name, l.type, l.city, l.state, l.zip, l.eligible_states_json, l.pickup_lead_time_hours
       FROM inventory_levels il
       JOIN locations l ON l.id = il.location_id
       WHERE l.active = 1`
    )
    .all() as Array<{
    sku: string;
    location_id: string;
    on_hand_cases: number;
    reserved_cases: number;
    code: string;
    name: string;
    type: 'warehouse' | 'store';
    city: string;
    state: string;
    zip: string;
    eligible_states_json: string;
    pickup_lead_time_hours: number;
  }>;

  const invBySku = new Map<string, LocationAvailability[]>();
  for (const r of invRows) {
    const arr = invBySku.get(r.sku) ?? [];
    arr.push({
      locationId: r.location_id,
      code: r.code,
      name: r.name,
      type: r.type,
      city: r.city,
      state: r.state,
      zip: r.zip,
      eligibleStates: JSON.parse(r.eligible_states_json || '[]') as string[],
      pickupLeadTimeHours: r.pickup_lead_time_hours,
      onHandCases: r.on_hand_cases,
      reservedCases: r.reserved_cases,
      availableCases: Math.max(0, r.on_hand_cases - r.reserved_cases),
    });
    invBySku.set(r.sku, arr);
  }

  return rows.map((row) => {
    const locs = invBySku.get(row.sku) ?? [];
    const totalDeliveryAvailableCases = row.delivery_eligible
      ? locs.filter((l) => l.type === 'warehouse').reduce((s, l) => s + l.availableCases, 0)
      : 0;
    const totalPickupAvailableCases = row.pickup_eligible
      ? locs.filter((l) => l.type === 'store').reduce((s, l) => s + l.availableCases, 0)
      : 0;

    return {
      sku: row.sku,
      familyId: row.family_id,
      familySlug: row.family_slug,
      familyName: row.family_name,
      brand: row.brand,
      categorySlug: row.category_slug,
      categoryName: row.category_name,
      title: row.title,
      subtitle: row.subtitle,
      description: row.description,
      images: JSON.parse(row.images_json || '[]') as string[],
      variantAttributes: JSON.parse(row.variant_attributes_json || '{}') as Record<string, string>,
      requiresVariantSelection: Boolean(row.requires_variant_selection),
      isAssorted: Boolean(row.is_assorted),
      assortedSelectionNote: row.assorted_selection_note,
      tags: JSON.parse(row.tags_json || '[]') as string[],
      featuredOrder: row.featured_order,
      packaging: computePackagingBreakdown({
        consumerSellingUnit: row.consumer_selling_unit,
        itemsPerConsumerPack: row.items_per_consumer_pack,
        consumerUnitsPerCase: row.consumer_units_per_case,
        casePriceCents: row.case_price_cents,
      }),
      minCaseQuantity: row.min_case_quantity,
      caseIncrement: row.case_increment,
      weightOz: row.weight_oz,
      dimensionsIn: row.dimensions_in,
      deliveryEligible: Boolean(row.delivery_eligible),
      pickupEligible: Boolean(row.pickup_eligible),
      active: Boolean(row.active),
      totalDeliveryAvailableCases,
      totalPickupAvailableCases,
      locationAvailability: locs,
    };
  });
}

export function listProducts(filters: ProductSearchFilters = {}): ProductCatalogItem[] {
  const db = getDb();
  const baseQuery = `
    SELECT s.sku, s.family_id, pf.slug as family_slug, pf.name as family_name, pf.brand,
           c.slug as category_slug, c.name as category_name,
           s.title, s.subtitle, s.description, s.images_json, s.variant_attributes_json,
           pf.requires_variant_selection, pf.is_assorted, pf.assorted_selection_note,
           pf.tags_json, pf.featured_order,
           s.consumer_selling_unit, s.items_per_consumer_pack, s.consumer_units_per_case,
           s.case_price_cents, s.min_case_quantity, s.case_increment, s.weight_oz, s.dimensions_in,
           s.delivery_eligible, s.pickup_eligible, s.active
    FROM skus s
    JOIN product_families pf ON pf.id = s.family_id
    JOIN categories c ON c.id = pf.category_id
    WHERE 1=1
    ${filters.includeInactive ? '' : 'AND s.active = 1 AND pf.active = 1 AND c.active = 1'}
  `;

  const rows = db.prepare(baseQuery).all() as RawSkuRow[];
  let items = hydrateRows(rows);

  const q = (filters.q || '').trim().slice(0, 100).toLowerCase();
  if (q) {
    const terms = q.split(/\s+/).filter(Boolean);
    items = items.filter((item) => {
      const haystack = [
        item.sku,
        item.title,
        item.subtitle,
        item.description,
        item.brand,
        item.categoryName,
        item.familyName,
        Object.values(item.variantAttributes).join(' '),
      ]
        .join(' ')
        .toLowerCase();
      return terms.every((t) => haystack.includes(t));
    });
  }

  if (filters.category && filters.category !== 'all') {
    items = items.filter((i) => i.categorySlug === filters.category);
  }

  if (filters.chip === 'under2' || filters.under2) {
    items = items.filter((i) => i.packaging.unitPriceCents < 200);
  } else if (filters.chip === 'business') {
    items = items.filter((i) => i.tags.includes('business_favourite'));
  } else if (filters.chip === 'party') {
    items = items.filter((i) => i.tags.includes('party_ready'));
  }

  if (typeof filters.minCasePriceCents === 'number') {
    items = items.filter((i) => i.packaging.casePriceCents >= filters.minCasePriceCents!);
  }
  if (typeof filters.maxCasePriceCents === 'number') {
    items = items.filter((i) => i.packaging.casePriceCents <= filters.maxCasePriceCents!);
  }
  if (typeof filters.minUnitsPerCase === 'number') {
    items = items.filter((i) => i.packaging.consumerUnitsPerCase >= filters.minUnitsPerCase!);
  }

  if (filters.fulfilmentMethod === 'delivery') {
    items = items.filter((i) => i.deliveryEligible);
  } else if (filters.fulfilmentMethod === 'pickup') {
    items = items.filter((i) => i.pickupEligible);
  }

  if (filters.locationId) {
    items = items.filter((i) => {
      const loc = i.locationAvailability.find((l) => l.locationId === filters.locationId);
      if (!loc) return false;
      if (loc.type === 'warehouse' && !i.deliveryEligible) return false;
      if (loc.type === 'store' && !i.pickupEligible) return false;
      return filters.inStockOnly ? loc.availableCases > 0 : true;
    });
  } else if (filters.inStockOnly) {
    items = items.filter(
      (i) => i.totalDeliveryAvailableCases > 0 || i.totalPickupAvailableCases > 0
    );
  }

  const sortMode = filters.sort || 'relevance';
  items.sort((a, b) => {
    if (sortMode === 'unit_price_asc') {
      return a.packaging.unitPriceCents - b.packaging.unitPriceCents || a.title.localeCompare(b.title);
    }
    if (sortMode === 'unit_price_desc') {
      return b.packaging.unitPriceCents - a.packaging.unitPriceCents || a.title.localeCompare(b.title);
    }
    if (sortMode === 'case_price_asc') {
      return a.packaging.casePriceCents - b.packaging.casePriceCents || a.title.localeCompare(b.title);
    }
    if (sortMode === 'case_price_desc') {
      return b.packaging.casePriceCents - a.packaging.casePriceCents || a.title.localeCompare(b.title);
    }
    if (sortMode === 'name_asc') {
      return a.title.localeCompare(b.title);
    }
    // relevance: prioritize exact/prefix SKU/title matches when searching, else featuredOrder
    if (q) {
      const aTitleMatch = a.title.toLowerCase().includes(q) || a.sku.toLowerCase() === q ? 0 : 1;
      const bTitleMatch = b.title.toLowerCase().includes(q) || b.sku.toLowerCase() === q ? 0 : 1;
      if (aTitleMatch !== bTitleMatch) return aTitleMatch - bTitleMatch;
    }
    return a.featuredOrder - b.featuredOrder || a.sku.localeCompare(b.sku);
  });

  return items;
}

export function getProductDetail(sku: string): {
  product: ProductCatalogItem | null;
  variants: ProductCatalogItem[];
  related: ProductCatalogItem[];
} {
  const db = getDb();
  const cleanSku = sku.trim().toUpperCase();
  const row = db
    .prepare(
      `SELECT s.sku, s.family_id, pf.slug as family_slug, pf.name as family_name, pf.brand,
              c.slug as category_slug, c.name as category_name,
              s.title, s.subtitle, s.description, s.images_json, s.variant_attributes_json,
              pf.requires_variant_selection, pf.is_assorted, pf.assorted_selection_note,
              pf.tags_json, pf.featured_order,
              s.consumer_selling_unit, s.items_per_consumer_pack, s.consumer_units_per_case,
              s.case_price_cents, s.min_case_quantity, s.case_increment, s.weight_oz, s.dimensions_in,
              s.delivery_eligible, s.pickup_eligible, s.active
       FROM skus s
       JOIN product_families pf ON pf.id = s.family_id
       JOIN categories c ON c.id = pf.category_id
       WHERE s.sku = ?`
    )
    .get(cleanSku) as RawSkuRow | undefined;

  if (!row) {
    return { product: null, variants: [], related: [] };
  }

  const [product] = hydrateRows([row]);

  const variantRows = db
    .prepare(
      `SELECT s.sku, s.family_id, pf.slug as family_slug, pf.name as family_name, pf.brand,
              c.slug as category_slug, c.name as category_name,
              s.title, s.subtitle, s.description, s.images_json, s.variant_attributes_json,
              pf.requires_variant_selection, pf.is_assorted, pf.assorted_selection_note,
              pf.tags_json, pf.featured_order,
              s.consumer_selling_unit, s.items_per_consumer_pack, s.consumer_units_per_case,
              s.case_price_cents, s.min_case_quantity, s.case_increment, s.weight_oz, s.dimensions_in,
              s.delivery_eligible, s.pickup_eligible, s.active
       FROM skus s
       JOIN product_families pf ON pf.id = s.family_id
       JOIN categories c ON c.id = pf.category_id
       WHERE s.family_id = ? AND s.active = 1
       ORDER BY s.sku`
    )
    .all(row.family_id) as RawSkuRow[];

  const variants = hydrateRows(variantRows);

  const related = listProducts({ category: product.categorySlug })
    .filter((p) => p.familyId !== product.familyId)
    .slice(0, 4);

  return { product, variants, related };
}

export function listLocations() {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM locations WHERE active = 1 ORDER BY type DESC, name ASC')
    .all() as Array<{
    id: string;
    code: string;
    name: string;
    type: 'warehouse' | 'store';
    address: string;
    city: string;
    state: string;
    zip: string;
    eligible_states_json: string;
    pickup_lead_time_hours: number;
  }>;

  return rows.map((r) => ({
    id: r.id,
    code: r.code,
    name: r.name,
    type: r.type,
    address: r.address,
    city: r.city,
    state: r.state,
    zip: r.zip,
    eligibleStates: JSON.parse(r.eligible_states_json || '[]') as string[],
    pickupLeadTimeHours: r.pickup_lead_time_hours,
  }));
}

export function listCategories() {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, slug, name, description, sort_order, active FROM categories ORDER BY sort_order ASC')
    .all() as Array<{
    id: string;
    slug: string;
    name: string;
    description: string;
    sort_order: number;
    active: number;
  }>;
  return rows.map((r) => ({
    id: String(r.id),
    slug: String(r.slug),
    name: String(r.name),
    description: String(r.description),
    sort_order: Number(r.sort_order),
    active: Number(r.active),
  }));
}

export function listHomepageBanners() {
  const db = getDb();
  const rows = db
    .prepare('SELECT id, slot, headline, subheadline, cta_label, cta_href, active, updated_at FROM homepage_banners')
    .all() as Array<{
    id: string;
    slot: string;
    headline: string;
    subheadline: string;
    cta_label: string;
    cta_href: string;
    active: number;
    updated_at: string;
  }>;
  return rows.map((r) => ({
    id: String(r.id),
    slot: String(r.slot),
    headline: String(r.headline),
    subheadline: String(r.subheadline),
    cta_label: String(r.cta_label),
    cta_href: String(r.cta_href),
    active: Number(r.active),
    updated_at: String(r.updated_at),
  }));
}
