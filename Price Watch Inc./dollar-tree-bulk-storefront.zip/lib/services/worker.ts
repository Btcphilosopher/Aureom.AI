import crypto from 'node:crypto';
import { getDb, withTransaction } from '../db';
import { logEvent } from '../logger';

const globalWorker = globalThis as unknown as {
  __reservationWorkerStarted?: boolean;
};

export interface ExpirySweepResult {
  expiredReservationCount: number;
  cancelledOrderCount: number;
  releasedCasesTotal: number;
}

export function expireStaleReservations(nowIso = new Date().toISOString()): ExpirySweepResult {
  const db = getDb();

  const result = withTransaction(db, () => {
    const stale = db
      .prepare(
        `SELECT id, order_attempt_id, sku, location_id, cases_reserved
         FROM stock_reservations
         WHERE status = 'active' AND expires_at <= ?`
      )
      .all(nowIso) as Array<{
      id: string;
      order_attempt_id: string;
      sku: string;
      location_id: string;
      cases_reserved: number;
    }>;

    if (stale.length === 0) {
      return {
        expiredReservationCount: 0,
        cancelledOrderCount: 0,
        releasedCasesTotal: 0,
      };
    }

    const updateRes = db.prepare(
      "UPDATE stock_reservations SET status = 'expired', updated_at = ? WHERE id = ?"
    );
    const releaseInv = db.prepare(
      `UPDATE inventory_levels
       SET reserved_cases = MAX(0, reserved_cases - ?), updated_at = ?
       WHERE sku = ? AND location_id = ?`
    );

    const touchedOrders = new Set<string>();
    let releasedCasesTotal = 0;

    for (const r of stale) {
      updateRes.run(nowIso, r.id);
      releaseInv.run(r.cases_reserved, nowIso, r.sku, r.location_id);
      touchedOrders.add(r.order_attempt_id);
      releasedCasesTotal += r.cases_reserved;
    }

    let cancelledOrderCount = 0;
    const cancelOrder = db.prepare(
      `UPDATE orders
       SET order_status = 'cancelled',
           fulfilment_status = 'cancelled',
           updated_at = ?
       WHERE id = ? AND order_status = 'pending_payment' AND payment_status = 'unpaid'`
    );
    const insertAudit = db.prepare(
      `INSERT INTO audit_logs
       (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, NULL, 'worker', 'system', ?, 'order', ?, ?, ?)`
    );

    for (const orderId of touchedOrders) {
      const info = cancelOrder.run(nowIso, orderId);
      if (info.changes > 0) {
        cancelledOrderCount++;
        insertAudit.run(
          `AUD-${crypto.randomUUID().slice(0, 10)}`,
          'reservation.expired',
          orderId,
          JSON.stringify({ expiredAt: nowIso }),
          nowIso
        );
      }
    }

    return {
      expiredReservationCount: stale.length,
      cancelledOrderCount,
      releasedCasesTotal,
    };
  });

  if (result.expiredReservationCount > 0) {
    logEvent('info', 'worker.reservations_expired', { ...result });
  }

  return result;
}

export function ensureBackgroundWorkerStarted(): void {
  if (globalWorker.__reservationWorkerStarted) return;
  globalWorker.__reservationWorkerStarted = true;

  // Sweep every 30 seconds in long-running server processes
  const timer = setInterval(() => {
    try {
      expireStaleReservations();
    } catch (err) {
      logEvent('error', 'worker.sweep_failed', {
        message: err instanceof Error ? err.message : String(err),
      });
    }
  }, 30_000);

  if (typeof timer.unref === 'function') {
    timer.unref();
  }
}
