import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.pricing import derive_consumer_unit_price_cents, calculate_server_totals


class FastApiPricingDomainTest(unittest.TestCase):
    def test_half_up_rounding_consistency(self):
        self.assertEqual(derive_consumer_unit_price_cents(3000, 24), 125)
        self.assertEqual(derive_consumer_unit_price_cents(3600, 24), 150)
        self.assertEqual(derive_consumer_unit_price_cents(4500, 36), 125)
        self.assertEqual(derive_consumer_unit_price_cents(3005, 10), 301)
        self.assertEqual(derive_consumer_unit_price_cents(1500, 8), 188)

    def test_server_totals_match_storefront_rules(self):
        # 2x Dish Soap ($60) + 1x Paper Cups ($30) = $90.00 subtotal, NJ delivery
        totals = calculate_server_totals([6000, 3000], "delivery", "NJ")
        self.assertEqual(totals["merchandise_subtotal_cents"], 9000)
        self.assertEqual(totals["delivery_fee_cents"], 1495)
        self.assertEqual(totals["tax_cents"], 597)
        self.assertEqual(totals["total_cents"], 11092)

        # Free delivery >= $250
        free_totals = calculate_server_totals([25000], "delivery", "NJ")
        self.assertEqual(free_totals["delivery_fee_cents"], 0)

        # Store pickup has $0 delivery fee
        pickup_totals = calculate_server_totals([9000], "pickup", "NJ")
        self.assertEqual(pickup_totals["delivery_fee_cents"], 0)


if __name__ == "__main__":
    unittest.main()
