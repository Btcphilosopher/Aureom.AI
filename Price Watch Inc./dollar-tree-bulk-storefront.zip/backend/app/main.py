from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import uuid
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import settings
from .database import get_db
from .models import (
    InventoryLevel,
    Order,
    OrderItemSnapshot,
    PaymentEvent,
    Sku,
    StockReservation,
)
from .pricing import calculate_server_totals, derive_consumer_unit_price_cents
from .worker import expire_stale_reservations

app = FastAPI(
    title="Dollar Tree Bulk Storefront API",
    version="1.0.0",
    description="Modular-monolith FastAPI backend for bulk case-pack ecommerce, inventory reservations, and fulfilment.",
)


class CheckoutLineIn(BaseModel):
    sku: str
    cases: int = Field(gt=0, le=50)


class CheckoutAttemptIn(BaseModel):
    customer_email: str
    fulfilment_method: str = Field(pattern="^(delivery|pickup)$")
    location_id: str
    destination_state: str = "NJ"
    idempotency_key: str = Field(min_length=8)
    items: list[CheckoutLineIn] = Field(min_length=1, max_length=50)


@app.get("/health")
def health():
    return {"ok": True, "service": "dollartree-bulk-fastapi"}


@app.get("/api/v1/catalogue")
def list_catalogue(db: Session = Depends(get_db)):
    skus = db.scalars(select(Sku).where(Sku.active.is_(True))).all()
    return [
        {
            "sku": s.sku,
            "title": s.title,
            "consumer_selling_unit": s.consumer_selling_unit,
            "items_per_consumer_pack": s.items_per_consumer_pack,
            "consumer_units_per_case": s.consumer_units_per_case,
            "unit_price_cents": derive_consumer_unit_price_cents(
                s.case_price_cents, s.consumer_units_per_case
            ),
            "case_price_cents": s.case_price_cents,
            "currency": s.currency,
        }
        for s in skus
    ]


@app.post("/api/v1/checkout/attempt")
def create_checkout_attempt(payload: CheckoutAttemptIn, db: Session = Depends(get_db)):
    expire_stale_reservations(db)

    existing = db.scalar(
        select(Order).where(Order.idempotency_key == payload.idempotency_key)
    )
    if existing:
        return {"order_id": existing.id, "total_cents": existing.total_cents, "idempotent": True}

    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(minutes=settings.reservation_ttl_minutes)
    order_id = f"ORD-{uuid.uuid4().hex[:10].upper()}"

    line_subtotals: list[int] = []
    snapshots: list[OrderItemSnapshot] = []
    reservations: list[StockReservation] = []

    for item in payload.items:
        sku_row = db.scalar(select(Sku).where(Sku.sku == item.sku, Sku.active.is_(True)))
        if not sku_row:
            raise HTTPException(status_code=400, detail=f"SKU {item.sku} unavailable.")

        inv = db.scalar(
            select(InventoryLevel)
            .where(InventoryLevel.sku == item.sku, InventoryLevel.location_id == payload.location_id)
            .with_for_update()
        )
        available = (inv.on_hand_cases - inv.reserved_cases) if inv else 0
        if available < item.cases:
            raise HTTPException(
                status_code=409,
                detail=f"Insufficient available cases for {item.sku}: requested {item.cases}, available {available}.",
            )

        inv.reserved_cases += item.cases
        inv.updated_at = now
        subtotal = item.cases * sku_row.case_price_cents
        line_subtotals.append(subtotal)

        snapshots.append(
            OrderItemSnapshot(
                id=f"OI-{uuid.uuid4().hex[:10]}",
                order_id=order_id,
                sku=sku_row.sku,
                title_snapshot=sku_row.title,
                consumer_selling_unit_snapshot=sku_row.consumer_selling_unit,
                items_per_consumer_pack_snapshot=sku_row.items_per_consumer_pack,
                consumer_units_per_case_snapshot=sku_row.consumer_units_per_case,
                cases_ordered=item.cases,
                case_price_cents_snapshot=sku_row.case_price_cents,
                line_subtotal_cents=subtotal,
            )
        )
        reservations.append(
            StockReservation(
                id=f"RES-{uuid.uuid4().hex[:10]}",
                order_attempt_id=order_id,
                sku=sku_row.sku,
                location_id=payload.location_id,
                cases_reserved=item.cases,
                status="active",
                expires_at=expires_at,
            )
        )

    totals = calculate_server_totals(
        line_subtotals_cents=line_subtotals,
        fulfilment_method=payload.fulfilment_method,
        destination_state=payload.destination_state,
    )

    order = Order(
        id=order_id,
        customer_email=payload.customer_email,
        order_status="pending_payment",
        payment_status="unpaid",
        fulfilment_status="unfulfilled",
        fulfilment_method=payload.fulfilment_method,
        location_id=payload.location_id,
        merchandise_subtotal_cents=totals["merchandise_subtotal_cents"],
        delivery_fee_cents=totals["delivery_fee_cents"],
        tax_cents=totals["tax_cents"],
        total_cents=totals["total_cents"],
        idempotency_key=payload.idempotency_key,
        created_at=now,
    )
    db.add(order)
    db.add_all(snapshots)
    db.add_all(reservations)
    db.commit()

    return {
        "order_id": order.id,
        "total_cents": order.total_cents,
        "reservation_expires_at": expires_at.isoformat(),
        "idempotent": False,
    }


@app.post("/api/v1/payments/webhook")
async def payment_webhook(
    request: Request,
    x_webhook_signature: str | None = Header(default=None),
    db: Session = Depends(get_db),
):
    raw_body = await request.body()
    if settings.payment_webhook_secret:
        expected = hmac.new(
            settings.payment_webhook_secret.encode("utf-8"),
            raw_body,
            hashlib.sha256,
        ).hexdigest()
        if not x_webhook_signature or not hmac.compare_digest(expected, x_webhook_signature):
            raise HTTPException(status_code=401, detail="Invalid webhook signature.")

    payload = await request.json()
    event_id = str(payload.get("providerEventId", ""))
    order_id = str(payload.get("orderId", ""))
    event_type = str(payload.get("eventType", ""))
    amount_cents = int(payload.get("amountCents", 0))

    seen = db.scalar(select(PaymentEvent).where(PaymentEvent.provider_event_id == event_id))
    if seen:
        return {"received": True, "deduplicated": True}

    order = db.scalar(select(Order).where(Order.id == order_id).with_for_update())
    if not order:
        raise HTTPException(status_code=404, detail="Order not found.")

    now = datetime.now(timezone.utc)
    db.add(
        PaymentEvent(
            id=f"PEV-{uuid.uuid4().hex[:10]}",
            order_id=order.id,
            provider=str(payload.get("provider", "local_simulator")),
            provider_event_id=event_id,
            event_type=event_type,
            amount_cents=amount_cents,
            created_at=now,
        )
    )

    if event_type == "payment.succeeded":
        reservations = db.scalars(
            select(StockReservation).where(StockReservation.order_attempt_id == order.id).with_for_update()
        ).all()
        for r in reservations:
            inv = db.scalar(
                select(InventoryLevel)
                .where(InventoryLevel.sku == r.sku, InventoryLevel.location_id == r.location_id)
                .with_for_update()
            )
            if r.status == "active" and inv:
                r.status = "committed"
                inv.on_hand_cases = max(0, inv.on_hand_cases - r.cases_reserved)
                inv.reserved_cases = max(0, inv.reserved_cases - r.cases_reserved)
        order.order_status = "confirmed"
        order.payment_status = "paid"

    db.commit()
    return {"received": True, "order_status": order.order_status, "payment_status": order.payment_status}
