from datetime import datetime
from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from .database import Base


class ProductFamily(Base):
    __tablename__ = "product_families"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    slug: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    brand: Mapped[str] = mapped_column(String(120), nullable=False)
    category_slug: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    is_assorted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    assorted_selection_note: Mapped[str] = mapped_column(Text, default="", nullable=False)


class Sku(Base):
    __tablename__ = "skus"

    sku: Mapped[str] = mapped_column(String(32), primary_key=True)
    family_id: Mapped[str] = mapped_column(ForeignKey("product_families.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    consumer_selling_unit: Mapped[str] = mapped_column(String(32), nullable=False)
    items_per_consumer_pack: Mapped[int | None] = mapped_column(Integer, nullable=True)
    consumer_units_per_case: Mapped[int] = mapped_column(Integer, nullable=False)
    case_price_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="USD", nullable=False)
    min_case_quantity: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    case_increment: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    delivery_eligible: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    pickup_eligible: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class InventoryLevel(Base):
    __tablename__ = "inventory_levels"
    __table_args__ = (
        CheckConstraint("on_hand_cases >= 0", name="ck_on_hand_non_negative"),
        CheckConstraint("reserved_cases >= 0", name="ck_reserved_non_negative"),
    )

    sku: Mapped[str] = mapped_column(ForeignKey("skus.sku"), primary_key=True)
    location_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    on_hand_cases: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    reserved_cases: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class Order(Base):
    __tablename__ = "orders"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    customer_email: Mapped[str] = mapped_column(String(255), nullable=False)
    order_status: Mapped[str] = mapped_column(String(32), nullable=False)
    payment_status: Mapped[str] = mapped_column(String(32), nullable=False)
    fulfilment_status: Mapped[str] = mapped_column(String(32), nullable=False)
    fulfilment_method: Mapped[str] = mapped_column(String(16), nullable=False)
    location_id: Mapped[str] = mapped_column(String(64), nullable=False)
    merchandise_subtotal_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    delivery_fee_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    tax_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    total_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    idempotency_key: Mapped[str | None] = mapped_column(String(128), unique=True, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class OrderItemSnapshot(Base):
    __tablename__ = "order_items"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    order_id: Mapped[str] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), nullable=False)
    sku: Mapped[str] = mapped_column(String(32), nullable=False)
    title_snapshot: Mapped[str] = mapped_column(String(200), nullable=False)
    consumer_selling_unit_snapshot: Mapped[str] = mapped_column(String(32), nullable=False)
    items_per_consumer_pack_snapshot: Mapped[int | None] = mapped_column(Integer, nullable=True)
    consumer_units_per_case_snapshot: Mapped[int] = mapped_column(Integer, nullable=False)
    cases_ordered: Mapped[int] = mapped_column(Integer, nullable=False)
    case_price_cents_snapshot: Mapped[int] = mapped_column(Integer, nullable=False)
    line_subtotal_cents: Mapped[int] = mapped_column(Integer, nullable=False)


class StockReservation(Base):
    __tablename__ = "stock_reservations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    order_attempt_id: Mapped[str] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), nullable=False)
    sku: Mapped[str] = mapped_column(ForeignKey("skus.sku"), nullable=False)
    location_id: Mapped[str] = mapped_column(String(64), nullable=False)
    cases_reserved: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(24), nullable=False, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)


class PaymentEvent(Base):
    __tablename__ = "payment_events"
    __table_args__ = (UniqueConstraint("provider_event_id", name="uq_provider_event_id"),)

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    order_id: Mapped[str] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), nullable=False)
    provider: Mapped[str] = mapped_column(String(32), nullable=False)
    provider_event_id: Mapped[str] = mapped_column(String(128), nullable=False)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    amount_cents: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
