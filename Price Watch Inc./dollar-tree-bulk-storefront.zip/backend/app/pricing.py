from decimal import Decimal, ROUND_HALF_UP

STATE_TAX_RATE_BPS = {
    "NJ": 663,
    "NY": 800,
    "PA": 600,
    "CT": 635,
    "MA": 625,
    "VA": 530,
    "MD": 600,
    "DE": 0,
}


def derive_consumer_unit_price_cents(case_price_cents: int, consumer_units_per_case: int) -> int:
    if consumer_units_per_case <= 0:
        raise ValueError("consumer_units_per_case must be positive")
    raw = Decimal(case_price_cents) / Decimal(consumer_units_per_case)
    return int(raw.quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def calculate_server_totals(
    line_subtotals_cents: list[int],
    fulfilment_method: str,
    destination_state: str,
    discount_cents: int = 0,
) -> dict[str, int]:
    merchandise_subtotal = sum(line_subtotals_cents)
    discount = min(merchandise_subtotal, max(0, discount_cents))
    taxable = merchandise_subtotal - discount

    delivery_fee = 0
    if fulfilment_method == "delivery" and taxable > 0:
        delivery_fee = 0 if taxable >= 25000 else 1495

    bps = STATE_TAX_RATE_BPS.get(destination_state.upper(), 650)
    tax = int((Decimal(taxable) * Decimal(bps) / Decimal(10000)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    total = taxable + delivery_fee + tax
    return {
        "merchandise_subtotal_cents": merchandise_subtotal,
        "discount_cents": discount,
        "delivery_fee_cents": delivery_fee,
        "tax_rate_bps": bps,
        "tax_cents": tax,
        "total_cents": total,
    }
