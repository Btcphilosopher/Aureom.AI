from datetime import datetime, timezone
import time
from sqlalchemy import select
from sqlalchemy.orm import Session

from .database import SessionLocal
from .models import InventoryLevel, Order, StockReservation


def expire_stale_reservations(db: Session, now: datetime | None = None) -> int:
    current = now or datetime.now(timezone.utc)
    stale = db.scalars(
        select(StockReservation)
        .where(StockReservation.status == "active", StockReservation.expires_at <= current)
        .with_for_update()
    ).all()

    if not stale:
        return 0

    touched_orders: set[str] = set()
    for res in stale:
        res.status = "expired"
        inv = db.scalar(
            select(InventoryLevel)
            .where(InventoryLevel.sku == res.sku, InventoryLevel.location_id == res.location_id)
            .with_for_update()
        )
        if inv:
            inv.reserved_cases = max(0, inv.reserved_cases - res.cases_reserved)
            inv.updated_at = current
        touched_orders.add(res.order_attempt_id)

    for order_id in touched_orders:
        order = db.scalar(select(Order).where(Order.id == order_id).with_for_update())
        if order and order.order_status == "pending_payment" and order.payment_status == "unpaid":
            order.order_status = "cancelled"
            order.fulfilment_status = "cancelled"

    db.commit()
    return len(stale)


def run_worker_loop(interval_seconds: int = 30) -> None:
    while True:
        with SessionLocal() as db:
            expire_stale_reservations(db)
        time.sleep(interval_seconds)


if __name__ == "__main__":
    run_worker_loop()
