import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg://postgres:postgres@localhost:5432/dollartree_bulk",
    )
    s3_endpoint: str = os.getenv("S3_ENDPOINT", "http://localhost:9000")
    s3_bucket: str = os.getenv("S3_BUCKET", "bulk-storefront-assets")
    s3_access_key: str = os.getenv("S3_ACCESS_KEY", "")
    s3_secret_key: str = os.getenv("S3_SECRET_KEY", "")
    payment_webhook_secret: str = os.getenv("PAYMENT_WEBHOOK_SECRET", "")
    reservation_ttl_minutes: int = 15
    default_delivery_fee_cents: int = 1495
    free_delivery_threshold_cents: int = 25000


settings = Settings()
