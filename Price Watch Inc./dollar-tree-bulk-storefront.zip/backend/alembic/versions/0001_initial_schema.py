"""Initial PostgreSQL schema for Dollar Tree Bulk Storefront

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-11-25
"""

from alembic import op
import sqlalchemy as sa

revision = "0001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "product_families",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("slug", sa.String(120), nullable=False, unique=True),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("brand", sa.String(120), nullable=False),
        sa.Column("category_slug", sa.String(64), nullable=False),
        sa.Column("is_assorted", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("assorted_selection_note", sa.Text(), nullable=False, server_default=""),
    )

    op.create_table(
        "skus",
        sa.Column("sku", sa.String(32), primary_key=True),
        sa.Column("family_id", sa.String(64), sa.ForeignKey("product_families.id"), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("consumer_selling_unit", sa.String(32), nullable=False),
        sa.Column("items_per_consumer_pack", sa.Integer(), nullable=True),
        sa.Column("consumer_units_per_case", sa.Integer(), nullable=False),
        sa.Column("case_price_cents", sa.Integer(), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="USD"),
        sa.Column("min_case_quantity", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("case_increment", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("delivery_eligible", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("pickup_eligible", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
    )

    op.create_table(
        "inventory_levels",
        sa.Column("sku", sa.String(32), sa.ForeignKey("skus.sku"), primary_key=True),
        sa.Column("location_id", sa.String(64), primary_key=True),
        sa.Column("on_hand_cases", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("reserved_cases", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("on_hand_cases >= 0", name="ck_on_hand_non_negative"),
        sa.CheckConstraint("reserved_cases >= 0", name="ck_reserved_non_negative"),
    )

    op.create_table(
        "orders",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("user_id", sa.String(64), nullable=True),
        sa.Column("customer_email", sa.String(255), nullable=False),
        sa.Column("order_status", sa.String(32), nullable=False),
        sa.Column("payment_status", sa.String(32), nullable=False),
        sa.Column("fulfilment_status", sa.String(32), nullable=False),
        sa.Column("fulfilment_method", sa.String(16), nullable=False),
        sa.Column("location_id", sa.String(64), nullable=False),
        sa.Column("merchandise_subtotal_cents", sa.Integer(), nullable=False),
        sa.Column("delivery_fee_cents", sa.Integer(), nullable=False),
        sa.Column("tax_cents", sa.Integer(), nullable=False),
        sa.Column("total_cents", sa.Integer(), nullable=False),
        sa.Column("idempotency_key", sa.String(128), nullable=True, unique=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )

    op.create_table(
        "order_items",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("order_id", sa.String(64), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sku", sa.String(32), nullable=False),
        sa.Column("title_snapshot", sa.String(200), nullable=False),
        sa.Column("consumer_selling_unit_snapshot", sa.String(32), nullable=False),
        sa.Column("items_per_consumer_pack_snapshot", sa.Integer(), nullable=True),
        sa.Column("consumer_units_per_case_snapshot", sa.Integer(), nullable=False),
        sa.Column("cases_ordered", sa.Integer(), nullable=False),
        sa.Column("case_price_cents_snapshot", sa.Integer(), nullable=False),
        sa.Column("line_subtotal_cents", sa.Integer(), nullable=False),
    )

    op.create_table(
        "stock_reservations",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("order_attempt_id", sa.String(64), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sku", sa.String(32), sa.ForeignKey("skus.sku"), nullable=False),
        sa.Column("location_id", sa.String(64), nullable=False),
        sa.Column("cases_reserved", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("idx_res_status_expiry", "stock_reservations", ["status", "expires_at"])

    op.create_table(
        "payment_events",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("order_id", sa.String(64), sa.ForeignKey("orders.id", ondelete="CASCADE"), nullable=False),
        sa.Column("provider", sa.String(32), nullable=False),
        sa.Column("provider_event_id", sa.String(128), nullable=False, unique=True),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("amount_cents", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("payment_events")
    op.drop_index("idx_res_status_expiry", table_name="stock_reservations")
    op.drop_table("stock_reservations")
    op.drop_table("order_items")
    op.drop_table("orders")
    op.drop_table("inventory_levels")
    op.drop_table("skus")
    op.drop_table("product_families")
