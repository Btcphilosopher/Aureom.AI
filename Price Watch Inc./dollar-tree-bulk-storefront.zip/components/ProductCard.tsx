'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Minus, Plus, ShoppingCart, Truck } from 'lucide-react';
import type { ProductCatalogItem } from '@/lib/services/catalogue';
import { formatUsd } from '@/lib/pricing';
import { useStorefront } from './StorefrontProvider';

export function ProductCard({ product }: { product: ProductCatalogItem }) {
  const { addCasesToCart, openFulfilmentModal } = useStorefront();
  const [casesQty, setCasesQty] = useState<number>(product.minCaseQuantity || 1);
  const [adding, setAdding] = useState(false);
  const [imgFailed, setImgFailed] = useState(false);

  const stepDown = () => {
    setCasesQty((prev) => Math.max(product.minCaseQuantity, prev - product.caseIncrement));
  };

  const stepUp = () => {
    setCasesQty((prev) => Math.min(50, prev + product.caseIncrement));
  };

  const handleAdd = async () => {
    setAdding(true);
    try {
      await addCasesToCart(product.sku, casesQty, product.title);
    } finally {
      setAdding(false);
    }
  };

  const totalOrderCents = casesQty * product.packaging.casePriceCents;

  return (
    <article
      className="bg-white rounded-2xl border border-slate-200 p-4 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow"
      data-testid={`product-card-${product.sku}`}
    >
      {/* Top Product Section: Image + Pricing Summary matching mockup */}
      <div>
        <div className="grid grid-cols-[120px_1fr] sm:grid-cols-[132px_1fr] gap-3 items-start">
          <Link
            href={`/products/${product.sku}`}
            className="block rounded-xl bg-white overflow-hidden aspect-square border border-slate-100"
          >
            {!imgFailed && product.images[0] ? (
              <img
                src={product.images[0]}
                alt={product.title}
                referrerPolicy="no-referrer"
                onError={() => setImgFailed(true)}
                className="w-full h-full object-contain p-1 hover:scale-105 transition-transform duration-200"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-emerald-50 text-xs font-bold text-[#0F6B2E] p-2 text-center">
                {product.title}
              </div>
            )}
          </Link>

          <div className="min-w-0">
            <Link
              href={`/products/${product.sku}`}
              className="block font-display text-[17px] leading-snug font-bold text-slate-900 hover:text-[#0F6B2E] transition-colors"
            >
              {product.title}
            </Link>

            <div className="mt-2 inline-block bg-[#DCF89D] text-[#0A4D1F] px-2.5 py-1 rounded-md font-display text-[17px] font-extrabold tabular-nums">
              {product.packaging.unitPriceLabel}
            </div>

            <div className="mt-2 text-sm text-slate-800 leading-snug">
              <p className="font-medium tabular-nums">
                {product.packaging.consumerSellingUnit === 'pack' &&
                product.packaging.itemsPerConsumerPack
                  ? `${product.packaging.consumerUnitsPerCase} packs per case ·`
                  : `${product.packaging.consumerUnitsPerCase} per case ·`}
              </p>
              <p className="font-bold tabular-nums">{product.packaging.casePriceLabel}</p>
              {product.packaging.consumerSellingUnit === 'pack' &&
                product.packaging.itemsPerConsumerPack && (
                  <p className="text-xs text-slate-600 tabular-nums mt-0.5">
                    {product.packaging.totalIndividualItemsPerCase} items total
                  </p>
                )}
            </div>
          </div>
        </div>

        {/* Assorted / Min Case / Multi-case clarity strip */}
        <div className="mt-3 min-h-[20px] flex flex-wrap items-center justify-between gap-2 text-xs">
          {casesQty >= 2 ? (
            <span className="font-bold text-[#0F6B2E] tabular-nums">
              Ordering {casesQty} cases · {formatUsd(totalOrderCents)}
            </span>
          ) : (
            <span className="text-slate-500">
              {product.isAssorted
                ? 'Assorted mix · patterns not individually selectable'
                : product.minCaseQuantity > 1
                  ? `Min ${product.minCaseQuantity} cases · increment ${product.caseIncrement}`
                  : `${product.sku} · Illustrative price`}
            </span>
          )}
        </div>
      </div>

      {/* Controls Row + Primary Add Button */}
      <div className="mt-3 pt-3 border-t border-slate-100 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-slate-800">Cases</span>
            <div className="inline-flex items-center border border-slate-300 rounded-lg bg-white">
              <button
                type="button"
                onClick={stepDown}
                disabled={casesQty <= product.minCaseQuantity}
                aria-label={`Decrease cases for ${product.title}`}
                className="w-8 h-8 flex items-center justify-center text-slate-700 hover:bg-slate-100 disabled:opacity-40 rounded-l-lg"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <input
                type="number"
                aria-label={`Case quantity for ${product.title}`}
                min={product.minCaseQuantity}
                step={product.caseIncrement}
                max={50}
                value={casesQty}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  if (!Number.isNaN(val) && val >= product.minCaseQuantity) {
                    setCasesQty(Math.min(50, val));
                  }
                }}
                className="w-10 text-center text-sm font-bold text-slate-900 tabular-nums focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
              />
              <button
                type="button"
                onClick={stepUp}
                aria-label={`Increase cases for ${product.title}`}
                className="w-8 h-8 flex items-center justify-center text-slate-700 hover:bg-slate-100 rounded-r-lg"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={() => openFulfilmentModal(product)}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0F6B2E] hover:text-[#0A4D1F] text-right leading-tight"
          >
            <Truck className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>Check delivery options</span>
          </button>
        </div>

        <button
          type="button"
          onClick={() => void handleAdd()}
          disabled={adding}
          className="w-full h-11 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] active:scale-[0.99] text-white font-bold text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-60 shadow-xs"
        >
          <ShoppingCart className="w-4 h-4" aria-hidden="true" />
          <span>
            {adding
              ? 'Adding...'
              : casesQty > 1
                ? `Add ${casesQty} cases to cart`
                : 'Add case to cart'}
          </span>
        </button>
      </div>
    </article>
  );
}
