'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Trees,
  Search,
  User,
  ShoppingCart,
  ChevronDown,
  X,
  Plus,
  Minus,
  Trash2,
  Truck,
  Store,
  Menu,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { NAVIGATION_CATEGORIES, STORE_CONFIG } from '@/lib/config';
import { formatUsd } from '@/lib/pricing';
import { useStorefront } from './StorefrontProvider';

export function StorefrontShell({
  children,
  announcementOverride,
  initialSearchQuery = '',
  activeCategory = 'all',
}: {
  children: React.ReactNode;
  announcementOverride?: string;
  initialSearchQuery?: string;
  activeCategory?: string;
}) {
  const router = useRouter();
  const {
    cart,
    user,
    locations,
    cartDrawerOpen,
    setCartDrawerOpen,
    lastAddedBanner,
    updateCartCases,
    fulfilmentModalProduct,
    closeFulfilmentModal,
    setCartFulfilment,
  } = useStorefront();

  const [searchTerm, setSearchTerm] = useState(initialSearchQuery);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const brandName = STORE_CONFIG.brandName;
  const totalCases = cart?.totalCases ?? 0;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchTerm.trim().slice(0, 100);
    router.push(q ? `/search?q=${encodeURIComponent(q)}` : '/search');
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900">
      {/* Top Announcement Bar */}
      <div className="bg-[#0F6B2E] text-white text-center px-4 py-2 text-sm font-bold tracking-tight">
        {announcementOverride || 'Big value. Stock up by the case.'}
      </div>

      {/* Main Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-[72px] flex items-center justify-between gap-4 lg:gap-8">
          {/* Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setMobileNavOpen((o) => !o)}
              aria-label="Toggle category navigation"
              aria-expanded={mobileNavOpen}
              className="lg:hidden p-2 rounded-lg text-[#0F6B2E] hover:bg-slate-100"
            >
              <Menu className="w-5 h-5" />
            </button>
            <Link
              href="/"
              className="flex items-center gap-2 whitespace-nowrap shrink-0 group"
              aria-label={`${brandName} Home`}
            >
              <span className="w-9 h-9 rounded-full bg-[#137A35] text-white flex items-center justify-center shadow-xs group-hover:bg-[#0F6B2E] transition-colors">
                <Trees className="w-5 h-5" />
              </span>
              <span className="font-display text-xl sm:text-2xl font-extrabold tracking-tight text-[#0F6B2E] uppercase">
                {brandName}
              </span>
            </Link>
          </div>

          {/* Search Bar */}
          <form
            onSubmit={handleSearchSubmit}
            className="hidden md:flex flex-1 max-w-2xl items-center"
            role="search"
            aria-label="Search bulk catalogue"
          >
            <div className="relative w-full">
              <label htmlFor="header-search" className="sr-only">
                Search products, cases and supplies
              </label>
              <Search
                className="w-4 h-4 text-[#0F6B2E] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                id="header-search"
                type="search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                maxLength={100}
                placeholder="Search products, cases & supplies"
                className="w-full h-11 pl-11 pr-24 rounded-full border-2 border-[#137A35] bg-white text-sm text-slate-900 placeholder:text-slate-500 focus:outline-none focus:border-[#0A4D1F]"
              />
              <button
                type="submit"
                className="absolute right-1.5 top-1/2 -translate-y-1/2 px-4 h-8 rounded-full bg-[#137A35] hover:bg-[#0F6B2E] text-white text-xs font-semibold transition-colors whitespace-nowrap"
              >
                Search
              </button>
            </div>
          </form>

          {/* Right Account & Cart Controls */}
          <div className="flex items-center gap-3 sm:gap-5 shrink-0">
            <Link
              href="/account"
              className="flex items-center gap-2 px-2.5 py-2 rounded-lg text-sm font-semibold text-[#0F6B2E] hover:bg-emerald-50 transition-colors whitespace-nowrap shrink-0"
            >
              <User className="w-5 h-5" aria-hidden="true" />
              <span className="hidden sm:inline">
                {user ? user.name.split(' ')[0] : 'My account'}
              </span>
            </Link>

            <button
              type="button"
              onClick={() => setCartDrawerOpen(true)}
              aria-label={`Open cart, ${totalCases} ${totalCases === 1 ? 'case' : 'cases'} in cart`}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-bold text-[#0F6B2E] hover:bg-emerald-50 transition-colors whitespace-nowrap shrink-0 border border-transparent hover:border-emerald-200"
            >
              <ShoppingCart className="w-5 h-5" aria-hidden="true" />
              <span className="tabular-nums">Cart ({totalCases})</span>
            </button>
          </div>
        </div>

        {/* Mobile search input */}
        <div className="md:hidden px-4 pb-3">
          <form onSubmit={handleSearchSubmit} role="search" className="relative">
            <label htmlFor="mobile-header-search" className="sr-only">
              Search products, cases and supplies
            </label>
            <Search className="w-4 h-4 text-[#0F6B2E] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="mobile-header-search"
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              maxLength={100}
              placeholder="Search products, cases & supplies"
              className="w-full h-10 pl-10 pr-20 rounded-full border-2 border-[#137A35] text-sm"
            />
            <button
              type="submit"
              className="absolute right-1.5 top-1/2 -translate-y-1/2 px-3 h-7 rounded-full bg-[#137A35] text-white text-xs font-semibold"
            >
              Go
            </button>
          </form>
        </div>

        {/* Category Navigation Bar */}
        <nav
          aria-label="Main categories"
          className={`${
            mobileNavOpen ? 'block' : 'hidden'
          } lg:block border-t border-slate-100 bg-white`}
        >
          <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-col lg:flex-row lg:items-center lg:justify-center gap-2 lg:gap-7 overflow-x-auto">
            {NAVIGATION_CATEGORIES.map((cat) => {
              const href =
                cat.slug === 'all'
                  ? '/search'
                  : cat.slug === 'business-supplies'
                    ? '/business'
                    : `/search?category=${cat.slug}`;
              const isActive = activeCategory === cat.slug;
              return (
                <Link
                  key={cat.slug}
                  href={href}
                  onClick={() => setMobileNavOpen(false)}
                  className={`flex items-center justify-between lg:justify-start gap-1 text-sm font-bold whitespace-nowrap shrink-0 py-1.5 lg:py-0.5 border-b-2 transition-colors ${
                    isActive
                      ? 'text-[#0F6B2E] border-[#0F6B2E]'
                      : 'text-slate-800 border-transparent hover:text-[#0F6B2E] hover:border-emerald-300'
                  }`}
                >
                  <span>{cat.name}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" aria-hidden="true" />
                </Link>
              );
            })}
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <main className="flex-1">{children}</main>

      {/* Footer */}
      <footer className="mt-12 border-t border-slate-200 bg-slate-50">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-600">
          <p className="font-medium text-slate-700 text-center md:text-left">
            {STORE_CONFIG.conceptDisclaimer}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-5 font-medium">
            <Link href="/search" className="hover:text-[#0F6B2E] whitespace-nowrap">
              Browse Catalogue
            </Link>
            <Link href="/quick-order" className="hover:text-[#0F6B2E] whitespace-nowrap">
              Quick Bulk Order & CSV
            </Link>
            <Link href="/business" className="hover:text-[#0F6B2E] whitespace-nowrap">
              Business Purchasing
            </Link>
            <Link href="/cart" className="hover:text-[#0F6B2E] whitespace-nowrap">
              Cart
            </Link>
            <Link href="/account" className="hover:text-[#0F6B2E] whitespace-nowrap">
              Account & Orders
            </Link>
            <Link href="/admin" className="hover:text-[#0F6B2E] whitespace-nowrap">
              Staff Admin
            </Link>
          </div>
        </div>
      </footer>

      {/* Slide-Over Cart Drawer */}
      <AnimatePresence>
        {cartDrawerOpen && (
          <div
            className="fixed inset-0 z-50 flex justify-end"
            role="dialog"
            aria-modal="true"
            aria-label="Shopping cart drawer"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.16 }}
              onClick={() => setCartDrawerOpen(false)}
              className="fixed inset-0 bg-slate-900/45"
            />
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              className="relative z-10 w-full max-w-md bg-white h-full shadow-2xl flex flex-col"
            >
              <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">
                    Your Bulk Cart ({totalCases} {totalCases === 1 ? 'case' : 'cases'})
                  </h2>
                  <p className="text-xs text-slate-500">
                    Inventory is reserved when you proceed to checkout.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setCartDrawerOpen(false)}
                  aria-label="Close cart drawer"
                  className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {lastAddedBanner && (
                <div className="mx-5 mt-3 px-3.5 py-2.5 rounded-lg bg-[#E5FAAD] border border-[#137A35]/20 text-xs font-semibold text-[#0A4D1F] flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-[#0F6B2E]" />
                  <span>{lastAddedBanner}</span>
                </div>
              )}

              <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
                {!cart || cart.activeLines.length === 0 ? (
                  <div className="text-center py-12 space-y-3">
                    <ShoppingCart className="w-10 h-10 text-slate-300 mx-auto" />
                    <p className="text-sm font-semibold text-slate-700">Your cart is empty</p>
                    <p className="text-xs text-slate-500">
                      Add full shipping cases from the catalogue or upload a SKU list on Quick Bulk Order.
                    </p>
                  </div>
                ) : (
                  cart.activeLines.map((line) => (
                    <div
                      key={line.id}
                      className="border border-slate-200 rounded-xl p-3.5 flex gap-3.5 bg-white"
                    >
                      <img
                        src={line.image}
                        alt={line.title}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 object-contain rounded-lg border border-slate-100 bg-white shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <Link
                            href={`/products/${line.sku}`}
                            onClick={() => setCartDrawerOpen(false)}
                            className="text-sm font-bold text-slate-900 hover:text-[#0F6B2E] line-clamp-1"
                          >
                            {line.title}
                          </Link>
                          <button
                            type="button"
                            onClick={() => void updateCartCases(line.sku, 0)}
                            aria-label={`Remove ${line.title}`}
                            className="text-slate-400 hover:text-red-600 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="text-xs font-mono text-slate-500">{line.sku}</p>
                        <p className="text-xs text-slate-600 mt-1">
                          {line.casesQty} {line.casesQty === 1 ? 'case' : 'cases'} ·{' '}
                          <span className="tabular-nums font-medium">
                            {line.totalConsumerUnits} {line.packaging.consumerSellingUnit}s
                          </span>
                          {line.packaging.itemsPerConsumerPack
                            ? ` (${line.totalIndividualItems} items total)`
                            : ''}
                        </p>
                        <div className="mt-2.5 flex items-center justify-between">
                          <div className="inline-flex items-center border border-slate-300 rounded-lg">
                            <button
                              type="button"
                              aria-label={`Decrease cases for ${line.title}`}
                              onClick={() =>
                                void updateCartCases(
                                  line.sku,
                                  Math.max(0, line.casesQty - line.caseIncrement)
                                )
                              }
                              className="w-8 h-8 flex items-center justify-center text-slate-700 hover:bg-slate-100 rounded-l-lg"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-8 text-center text-xs font-bold tabular-nums">
                              {line.casesQty}
                            </span>
                            <button
                              type="button"
                              aria-label={`Increase cases for ${line.title}`}
                              onClick={() =>
                                void updateCartCases(
                                  line.sku,
                                  line.casesQty + line.caseIncrement
                                )
                              }
                              className="w-8 h-8 flex items-center justify-center text-slate-700 hover:bg-slate-100 rounded-r-lg"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <span className="text-sm font-bold text-slate-900 tabular-nums">
                            {formatUsd(line.lineSubtotalCents)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="border-t border-slate-200 p-5 bg-slate-50 space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">
                    Merchandise subtotal ({totalCases} {totalCases === 1 ? 'case' : 'cases'})
                  </span>
                  <span className="text-lg font-extrabold text-slate-900 tabular-nums">
                    {formatUsd(cart?.merchandiseSubtotalCents ?? 0)}
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  Delivery fees and estimated taxes are calculated during checkout based on destination.
                </p>
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={() => setCartDrawerOpen(false)}
                    className="h-11 px-4 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-sm font-bold text-slate-800 transition-colors"
                  >
                    Continue shopping
                  </button>
                  <Link
                    href="/cart"
                    onClick={() => setCartDrawerOpen(false)}
                    className="h-11 px-4 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white text-sm font-bold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>View cart</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </motion.aside>
          </div>
        )}
      </AnimatePresence>

      {/* Destination & Fulfilment Eligibility Modal */}
      {fulfilmentModalProduct && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50"
          role="dialog"
          aria-modal="true"
          aria-label="Check fulfilment availability by location"
        >
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-mono text-slate-500">{fulfilmentModalProduct.sku}</p>
                <h3 className="text-lg font-bold text-slate-900">
                  Fulfilment options for {fulfilmentModalProduct.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={closeFulfilmentModal}
                aria-label="Close fulfilment dialog"
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2.5">
              {locations.map((loc) => {
                const avail = fulfilmentModalProduct.locationAvailability.find(
                  (a) => a.locationId === loc.id
                );
                const method = loc.type === 'warehouse' ? 'delivery' : 'pickup';
                const skuSupportsMethod =
                  method === 'delivery'
                    ? fulfilmentModalProduct.deliveryEligible
                    : fulfilmentModalProduct.pickupEligible;
                const casesAvail = avail?.availableCases ?? 0;
                const isEligible = skuSupportsMethod && casesAvail > 0;
                const isSelected = cart?.locationId === loc.id;

                return (
                  <div
                    key={loc.id}
                    className={`p-3.5 rounded-xl border ${
                      isSelected ? 'border-[#137A35] bg-emerald-50/40' : 'border-slate-200'
                    } flex items-center justify-between gap-3`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                        {loc.type === 'warehouse' ? (
                          <Truck className="w-4 h-4 text-[#0F6B2E] shrink-0" />
                        ) : (
                          <Store className="w-4 h-4 text-[#0F6B2E] shrink-0" />
                        )}
                        <span className="truncate">{loc.name}</span>
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {loc.type === 'warehouse'
                          ? `Delivery to ${loc.eligibleStates.join(', ')}`
                          : `Store pickup (${loc.city}, ${loc.state}) · Est. ${loc.pickupLeadTimeHours}h prep`}
                      </p>
                      <p className="text-xs mt-1 font-medium">
                        {!skuSupportsMethod ? (
                          <span className="text-amber-700 inline-flex items-center gap-1">
                            <AlertCircle className="w-3.5 h-3.5" />
                            Not eligible for {method}
                          </span>
                        ) : casesAvail > 0 ? (
                          <span className="text-[#0F6B2E] tabular-nums">
                            {casesAvail} cases available to promise
                          </span>
                        ) : (
                          <span className="text-red-600">Out of stock at this location</span>
                        )}
                      </p>
                    </div>

                    <button
                      type="button"
                      disabled={!isEligible}
                      onClick={async () => {
                        await setCartFulfilment({
                          fulfilmentMethod: method,
                          locationId: loc.id,
                          destinationState: loc.state,
                          destinationZip: loc.zip,
                        });
                        closeFulfilmentModal();
                      }}
                      className={`px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap shrink-0 transition-colors ${
                        isEligible
                          ? 'bg-[#137A35] hover:bg-[#0F6B2E] text-white'
                          : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      {isSelected ? 'Selected' : `Use ${method}`}
                    </button>
                  </div>
                );
              })}
            </div>

            <p className="text-xs text-slate-500">
              Single-method orders: all items in a checkout must be fulfilled from one eligible location.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
