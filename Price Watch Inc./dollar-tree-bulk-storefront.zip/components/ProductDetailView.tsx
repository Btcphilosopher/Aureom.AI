'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  CheckCircle2,
  AlertTriangle,
  Minus,
  Plus,
  ShoppingCart,
  Truck,
  Store,
  Package,
  Info,
} from 'lucide-react';
import type { ProductCatalogItem } from '@/lib/services/catalogue';
import { formatUsd } from '@/lib/pricing';
import { useStorefront } from './StorefrontProvider';
import { ProductCard } from './ProductCard';

export function ProductDetailView({
  product,
  variants,
  related,
}: {
  product: ProductCatalogItem;
  variants: ProductCatalogItem[];
  related: ProductCatalogItem[];
}) {
  const { addCasesToCart, cart, setCartFulfilment } = useStorefront();
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSku, setSelectedSku] = useState(
    product.requiresVariantSelection && variants.length > 1 ? product.sku : product.sku
  );
  const [variantConfirmed, setVariantConfirmed] = useState(
    !(product.requiresVariantSelection && variants.length > 1)
  );
  const [casesQty, setCasesQty] = useState(product.minCaseQuantity || 1);
  const [adding, setAdding] = useState(false);

  const activeVariant = variants.find((v) => v.sku === selectedSku) || product;
  const images = activeVariant.images.length > 0 ? activeVariant.images : ['/images/products/dish-soap.jpg'];

  const oneCaseCents = activeVariant.packaging.casePriceCents;
  const twoCasesCents = oneCaseCents * 2;
  const selectedTotalCents = oneCaseCents * casesQty;

  const handleAdd = async () => {
    if (!variantConfirmed) return;
    setAdding(true);
    try {
      await addCasesToCart(activeVariant.sku, casesQty, activeVariant.title);
    } finally {
      setAdding(false);
    }
  };

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-12">
      <nav aria-label="Breadcrumb" className="text-xs font-medium text-slate-500 flex items-center gap-2">
        <Link href="/" className="hover:text-[#0F6B2E]">
          Home
        </Link>
        <span>/</span>
        <Link href={`/search?category=${activeVariant.categorySlug}`} className="hover:text-[#0F6B2E]">
          {activeVariant.categoryName}
        </Link>
        <span>/</span>
        <span className="text-slate-800 font-semibold">{activeVariant.title}</span>
      </nav>

      {/* Main PDP Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Image Gallery */}
        <div className="lg:col-span-6 space-y-3 lg:sticky lg:top-28">
          <div className="aspect-[4/3] rounded-2xl border border-slate-200 bg-white overflow-hidden flex items-center justify-center p-6">
            <img
              src={images[selectedImage] || images[0]}
              alt={activeVariant.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain"
            />
          </div>
          {images.length > 1 && (
            <div className="flex items-center gap-3">
              {images.map((img, idx) => (
                <button
                  key={`${img}-${idx}`}
                  type="button"
                  onClick={() => setSelectedImage(idx)}
                  className={`w-20 h-20 rounded-xl border p-1 bg-white ${
                    selectedImage === idx ? 'border-[#0F6B2E] ring-2 ring-[#0F6B2E]/20' : 'border-slate-200'
                  }`}
                >
                  <img src={img} alt="" referrerPolicy="no-referrer" className="w-full h-full object-contain" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Contiguous Purchase Module */}
        <div className="lg:col-span-6 space-y-6">
          <div>
            <p className="text-xs font-semibold text-slate-500">
              {activeVariant.brand} · <span className="font-mono">{activeVariant.sku}</span> · Illustrative pricing
            </p>
            <h1 className="mt-1 font-display text-3xl sm:text-4xl font-extrabold text-slate-900">
              {activeVariant.title}
            </h1>
            {activeVariant.subtitle && (
              <p className="text-sm font-medium text-slate-600 mt-1">{activeVariant.subtitle}</p>
            )}
          </div>

          {/* Explicit Packaging & Pricing Breakdown Box */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 space-y-3">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <span className="bg-[#DCF89D] text-[#0A4D1F] px-3 py-1 rounded-lg font-display text-xl font-extrabold tabular-nums">
                {activeVariant.packaging.consumerSellingUnit === 'pack' &&
                activeVariant.packaging.itemsPerConsumerPack
                  ? `${formatUsd(activeVariant.packaging.unitPriceCents)} per ${activeVariant.packaging.itemsPerConsumerPack}-count pack`
                  : activeVariant.packaging.unitPriceLabel}
              </span>
              <span className="text-xl font-extrabold text-slate-900 tabular-nums">
                {formatUsd(oneCaseCents)} / case
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200 text-sm">
              <div className="space-y-0.5 tabular-nums">
                <p className="font-bold text-slate-900">
                  {activeVariant.packaging.consumerUnitsPerCase}{' '}
                  {activeVariant.packaging.consumerSellingUnit === 'pack'
                    ? 'packs per case'
                    : `${activeVariant.packaging.consumerSellingUnit}s per case`}
                </p>
                {activeVariant.packaging.itemsPerConsumerPack && (
                  <p className="text-slate-600">
                    {activeVariant.packaging.totalIndividualItemsPerCase} items per case
                  </p>
                )}
              </div>
              <div className="space-y-0.5 tabular-nums sm:text-right">
                <p className="text-slate-700">1 case: {formatUsd(oneCaseCents)}</p>
                <p className="font-bold text-[#0F6B2E]">2 cases: {formatUsd(twoCasesCents)}</p>
              </div>
            </div>

            <p className="text-xs text-slate-500 flex items-start gap-1.5 pt-1">
              <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              <span>
                Taxes and delivery fees are kept separate and calculated at checkout once your destination or pickup store is confirmed.
              </span>
            </p>
          </div>

          {/* Assorted Notice */}
          {activeVariant.isAssorted && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-950 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Assorted Case Pack Notice</p>
                <p className="mt-0.5">{activeVariant.assortedSelectionNote}</p>
              </div>
            </div>
          )}

          {/* Explicit Variant Selection */}
          {variants.length > 1 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-bold text-slate-900">
                  Select variant ({variants.length} options)
                </label>
                {!variantConfirmed && (
                  <span className="text-xs font-bold text-amber-700">
                    Please confirm variant selection
                  </span>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {variants.map((v) => {
                  const isCurrent = v.sku === selectedSku && variantConfirmed;
                  return (
                    <button
                      key={v.sku}
                      type="button"
                      onClick={() => {
                        setSelectedSku(v.sku);
                        setVariantConfirmed(true);
                      }}
                      className={`p-3 rounded-xl border text-left transition-colors ${
                        isCurrent
                          ? 'border-[#0F6B2E] bg-emerald-50/60 ring-1 ring-[#0F6B2E]'
                          : 'border-slate-200 hover:border-slate-400 bg-white'
                      }`}
                    >
                      <p className="text-sm font-bold text-slate-900">{v.subtitle || v.title}</p>
                      <p className="text-xs font-mono text-slate-500 mt-0.5">
                        {v.sku} · {formatUsd(v.packaging.casePriceCents)} / case
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Case Quantity Selector & Add to Cart */}
          <div className="rounded-2xl border border-slate-200 p-5 space-y-4 bg-white">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <label htmlFor="pdp-cases-input" className="block text-sm font-bold text-slate-900">
                  Case quantity
                </label>
                <p className="text-xs text-slate-500">
                  Min {activeVariant.minCaseQuantity} · Increment {activeVariant.caseIncrement}
                </p>
              </div>

              <div className="inline-flex items-center border border-slate-300 rounded-xl bg-white">
                <button
                  type="button"
                  aria-label="Decrease case quantity"
                  onClick={() =>
                    setCasesQty((q) =>
                      Math.max(activeVariant.minCaseQuantity, q - activeVariant.caseIncrement)
                    )
                  }
                  className="w-10 h-10 flex items-center justify-center hover:bg-slate-100 rounded-l-xl"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  id="pdp-cases-input"
                  type="number"
                  min={activeVariant.minCaseQuantity}
                  step={activeVariant.caseIncrement}
                  max={50}
                  value={casesQty}
                  onChange={(e) => {
                    const n = parseInt(e.target.value, 10);
                    if (!Number.isNaN(n) && n >= activeVariant.minCaseQuantity) {
                      setCasesQty(Math.min(50, n));
                    }
                  }}
                  className="w-14 text-center text-base font-extrabold tabular-nums focus:outline-none"
                />
                <button
                  type="button"
                  aria-label="Increase case quantity"
                  onClick={() => setCasesQty((q) => Math.min(50, q + activeVariant.caseIncrement))}
                  className="w-10 h-10 flex items-center justify-center hover:bg-slate-100 rounded-r-xl"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm pt-2 border-t border-slate-100">
              <span className="text-slate-600">
                Subtotal for {casesQty} {casesQty === 1 ? 'case' : 'cases'} (
                <span className="tabular-nums font-semibold">
                  {casesQty * activeVariant.packaging.consumerUnitsPerCase}{' '}
                  {activeVariant.packaging.consumerSellingUnit}s
                </span>
                )
              </span>
              <span className="text-xl font-extrabold text-slate-900 tabular-nums">
                {formatUsd(selectedTotalCents)}
              </span>
            </div>

            <button
              type="button"
              disabled={!variantConfirmed || adding}
              onClick={() => void handleAdd()}
              className="w-full h-12 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-base flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              <ShoppingCart className="w-5 h-5" />
              <span>
                {!variantConfirmed
                  ? 'Select a variant above to add'
                  : adding
                    ? 'Adding to cart...'
                    : `Add ${casesQty} ${casesQty === 1 ? 'case' : 'cases'} to cart — ${formatUsd(selectedTotalCents)}`}
              </span>
            </button>
          </div>

          {/* Fulfilment & Estimated Availability by Location */}
          <div className="rounded-2xl border border-slate-200 p-5 space-y-3">
            <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <Package className="w-4 h-4 text-[#0F6B2E]" />
              <span>Fulfilment options & estimated availability</span>
            </h2>
            <div className="space-y-2">
              {activeVariant.locationAvailability.map((loc) => {
                const method = loc.type === 'warehouse' ? 'delivery' : 'pickup';
                const supportsMethod =
                  method === 'delivery' ? activeVariant.deliveryEligible : activeVariant.pickupEligible;
                const isSelected = cart?.locationId === loc.locationId;
                return (
                  <div
                    key={loc.locationId}
                    className={`p-3 rounded-xl border text-xs flex items-center justify-between gap-3 ${
                      isSelected ? 'border-[#137A35] bg-emerald-50/40' : 'border-slate-200'
                    }`}
                  >
                    <div>
                      <p className="font-bold text-slate-900 flex items-center gap-1.5">
                        {loc.type === 'warehouse' ? (
                          <Truck className="w-3.5 h-3.5 text-[#0F6B2E]" />
                        ) : (
                          <Store className="w-3.5 h-3.5 text-[#0F6B2E]" />
                        )}
                        <span>{loc.name}</span>
                      </p>
                      <p className="text-slate-600 mt-0.5">
                        {!supportsMethod
                          ? `Not eligible for ${method}`
                          : loc.availableCases > 0
                            ? `${loc.availableCases} cases available to promise`
                            : 'Currently out of stock'}
                      </p>
                    </div>
                    {supportsMethod && loc.availableCases > 0 && (
                      <button
                        type="button"
                        onClick={() =>
                          void setCartFulfilment({
                            fulfilmentMethod: method,
                            locationId: loc.locationId,
                            destinationState: loc.state,
                            destinationZip: loc.zip,
                          })
                        }
                        className="px-3 py-1.5 rounded-lg border border-[#137A35] text-[#0F6B2E] font-bold hover:bg-emerald-50 whitespace-nowrap"
                      >
                        {isSelected ? (
                          <span className="inline-flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Selected
                          </span>
                        ) : (
                          `Select ${method}`
                        )}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Description & Specifications */}
          <div className="space-y-4 pt-2 border-t border-slate-200">
            <div>
              <h2 className="text-base font-bold text-slate-900">Description</h2>
              <p className="text-sm text-slate-700 mt-1 leading-relaxed">{activeVariant.description}</p>
            </div>

            <div>
              <h2 className="text-base font-bold text-slate-900">Case Specifications</h2>
              <dl className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2 text-xs border border-slate-200 rounded-xl p-4 bg-slate-50">
                <div>
                  <dt className="text-slate-500">SKU</dt>
                  <dd className="font-mono font-semibold text-slate-900">{activeVariant.sku}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">Brand</dt>
                  <dd className="font-semibold text-slate-900">{activeVariant.brand}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">Shipping Weight</dt>
                  <dd className="font-semibold text-slate-900 tabular-nums">
                    {(activeVariant.weightOz / 16).toFixed(1)} lbs ({activeVariant.weightOz} oz)
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Case Dimensions</dt>
                  <dd className="font-semibold text-slate-900">{activeVariant.dimensionsIn}</dd>
                </div>
                {Object.entries(activeVariant.variantAttributes).map(([k, v]) => (
                  <div key={k}>
                    <dt className="text-slate-500 capitalize">{k}</dt>
                    <dd className="font-semibold text-slate-900">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {related.length > 0 && (
        <section aria-labelledby="related-heading" className="pt-8 border-t border-slate-200 space-y-4">
          <h2 id="related-heading" className="font-display text-2xl font-extrabold text-[#0A4D1F]">
            Related bulk cases
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {related.map((item) => (
              <ProductCard key={item.sku} product={item} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
