'use client';

import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { CartSummary } from '@/lib/services/cart';
import type { ProductCatalogItem } from '@/lib/services/catalogue';
import type { AuthUser } from '@/lib/auth';

export interface StoreLocation {
  id: string;
  code: string;
  name: string;
  type: 'warehouse' | 'store';
  address: string;
  city: string;
  state: string;
  zip: string;
  eligibleStates: string[];
  pickupLeadTimeHours: number;
}

interface StorefrontContextValue {
  cart: CartSummary | null;
  user: AuthUser | null;
  bootstrapRequired: boolean;
  locations: StoreLocation[];
  loadingCart: boolean;
  cartDrawerOpen: boolean;
  setCartDrawerOpen: (open: boolean) => void;
  lastAddedBanner: string | null;
  announcementText: string;
  announce: (msg: string) => void;
  refreshCart: () => Promise<void>;
  refreshSession: () => Promise<void>;
  addCasesToCart: (sku: string, cases: number, title?: string) => Promise<boolean>;
  updateCartCases: (sku: string, cases: number) => Promise<void>;
  toggleSaveForLater: (sku: string, save: boolean) => Promise<void>;
  acceptCartPriceChanges: () => Promise<void>;
  setCartFulfilment: (params: {
    fulfilmentMethod: 'delivery' | 'pickup';
    locationId: string;
    destinationZip?: string;
    destinationState?: string;
  }) => Promise<void>;
  fulfilmentModalProduct: ProductCatalogItem | null;
  openFulfilmentModal: (product: ProductCatalogItem) => void;
  closeFulfilmentModal: () => void;
}

const StorefrontContext = createContext<StorefrontContextValue | null>(null);

export function StorefrontProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<CartSummary | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [bootstrapRequired, setBootstrapRequired] = useState(false);
  const [locations, setLocations] = useState<StoreLocation[]>([]);
  const [loadingCart, setLoadingCart] = useState(true);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [lastAddedBanner, setLastAddedBanner] = useState<string | null>(null);
  const [announcementText, setAnnouncementText] = useState('');
  const [fulfilmentModalProduct, setFulfilmentModalProduct] =
    useState<ProductCatalogItem | null>(null);

  const announce = useCallback((msg: string) => {
    setAnnouncementText('');
    setTimeout(() => setAnnouncementText(msg), 20);
  }, []);

  const refreshCart = useCallback(async () => {
    try {
      const res = await fetch('/api/cart', { cache: 'no-store' });
      if (res.ok) {
        const data = (await res.json()) as { cart: CartSummary };
        setCart(data.cart);
      }
    } finally {
      setLoadingCart(false);
    }
  }, []);

  const refreshSession = useCallback(async () => {
    const res = await fetch('/api/auth/session', { cache: 'no-store' });
    if (res.ok) {
      const data = (await res.json()) as {
        user: AuthUser | null;
        bootstrapRequired: boolean;
      };
      setUser(data.user);
      setBootstrapRequired(data.bootstrapRequired);
    }
  }, []);

  useEffect(() => {
    let active = true;
    void fetch('/api/cart', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { cart?: CartSummary } | null) => {
        if (active && data?.cart) setCart(data.cart);
      })
      .finally(() => {
        if (active) setLoadingCart(false);
      });

    void fetch('/api/auth/session', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { user: AuthUser | null; bootstrapRequired: boolean } | null) => {
        if (active && data) {
          setUser(data.user);
          setBootstrapRequired(data.bootstrapRequired);
        }
      });

    void fetch('/api/catalogue')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (active && data?.locations) setLocations(data.locations);
      });

    return () => {
      active = false;
    };
  }, []);

  const addCasesToCart = useCallback(
    async (sku: string, cases: number, title?: string): Promise<boolean> => {
      const res = await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
        body: JSON.stringify({ action: 'add', sku, cases }),
      });
      const data = (await res.json()) as { cart?: CartSummary; error?: string };
      if (!res.ok || !data.cart) {
        announce(data.error || 'Could not add case to cart.');
        setLastAddedBanner(data.error || 'Could not add case to cart.');
        return false;
      }
      setCart(data.cart);
      const label = `${cases} ${cases === 1 ? 'case' : 'cases'} of ${title || sku} added. Cart now has ${data.cart.totalCases} ${data.cart.totalCases === 1 ? 'case' : 'cases'}.`;
      setLastAddedBanner(label);
      announce(label);
      setCartDrawerOpen(true);
      return true;
    },
    [announce]
  );

  const updateCartCases = useCallback(
    async (sku: string, cases: number) => {
      const res = await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
        body: JSON.stringify({ action: 'set', sku, cases }),
      });
      const data = (await res.json()) as { cart?: CartSummary; error?: string };
      if (res.ok && data.cart) {
        setCart(data.cart);
        announce(`Updated cart. Total cases: ${data.cart.totalCases}.`);
      } else if (data.error) {
        announce(data.error);
      }
    },
    [announce]
  );

  const toggleSaveForLater = useCallback(
    async (sku: string, save: boolean) => {
      const res = await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
        body: JSON.stringify({
          action: save ? 'save_for_later' : 'move_to_cart',
          sku,
        }),
      });
      const data = (await res.json()) as { cart?: CartSummary };
      if (res.ok && data.cart) {
        setCart(data.cart);
        announce(save ? `Saved ${sku} for later.` : `Moved ${sku} back to cart.`);
      }
    },
    [announce]
  );

  const acceptCartPriceChanges = useCallback(async () => {
    const res = await fetch('/api/cart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({ action: 'accept_prices' }),
    });
    const data = (await res.json()) as { cart?: CartSummary };
    if (res.ok && data.cart) {
      setCart(data.cart);
    }
  }, []);

  const setCartFulfilment = useCallback(
    async (params: {
      fulfilmentMethod: 'delivery' | 'pickup';
      locationId: string;
      destinationZip?: string;
      destinationState?: string;
    }) => {
      const res = await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
        body: JSON.stringify({ action: 'fulfilment', ...params }),
      });
      const data = (await res.json()) as { cart?: CartSummary; error?: string };
      if (res.ok && data.cart) {
        setCart(data.cart);
        announce(`Fulfilment set to ${params.fulfilmentMethod}.`);
      } else if (data.error) {
        announce(data.error);
      }
    },
    [announce]
  );

  return (
    <StorefrontContext.Provider
      value={{
        cart,
        user,
        bootstrapRequired,
        locations,
        loadingCart,
        cartDrawerOpen,
        setCartDrawerOpen,
        lastAddedBanner,
        announcementText,
        announce,
        refreshCart,
        refreshSession,
        addCasesToCart,
        updateCartCases,
        toggleSaveForLater,
        acceptCartPriceChanges,
        setCartFulfilment,
        fulfilmentModalProduct,
        openFulfilmentModal: setFulfilmentModalProduct,
        closeFulfilmentModal: () => setFulfilmentModalProduct(null),
      }}
    >
      {children}
      <div
        role="status"
        aria-live="polite"
        aria-atomic="true"
        className="sr-only"
      >
        {announcementText}
      </div>
    </StorefrontContext.Provider>
  );
}

export function useStorefront() {
  const ctx = useContext(StorefrontContext);
  if (!ctx) {
    throw new Error('useStorefront must be used inside StorefrontProvider');
  }
  return ctx;
}
