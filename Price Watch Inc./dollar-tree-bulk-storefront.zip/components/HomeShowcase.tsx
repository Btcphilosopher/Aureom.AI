'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ArrowRight, Package, Tag, Truck, Store } from 'lucide-react';
import type { ProductCatalogItem } from '@/lib/services/catalogue';
import { ProductCard } from './ProductCard';

interface BannerData {
  slot: string;
  headline: string;
  subheadline: string;
  cta_label: string;
  cta_href: string;
  active: number;
}

const FILTER_CHIPS = [
  { id: 'all', label: 'All essentials' },
  { id: 'under2', label: 'Under $2 per item' },
  { id: 'business', label: 'Business favourites' },
  { id: 'party', label: 'Party-ready' },
] as const;

export function HomeShowcase({
  initialProducts,
  banners,
}: {
  initialProducts: ProductCatalogItem[];
  banners: BannerData[];
}) {
  const [activeChip, setActiveChip] = useState<'all' | 'under2' | 'business' | 'party'>('all');
  const [products, setProducts] = useState<ProductCatalogItem[]>(initialProducts);
  const [loading, setLoading] = useState(false);
  const [showAllRows, setShowAllRows] = useState(false);

  const heroBanner = banners.find((b) => b.slot === 'hero');
  const businessBanner = banners.find((b) => b.slot === 'business');

  const handleChipChange = async (chipId: 'all' | 'under2' | 'business' | 'party') => {
    setActiveChip(chipId);
    setLoading(true);
    try {
      const res = await fetch(`/api/catalogue?chip=${chipId}`, { cache: 'no-store' });
      if (res.ok) {
        const data = (await res.json()) as { products: ProductCatalogItem[] };
        setProducts(data.products);
      }
    } finally {
      setLoading(false);
    }
  };

  const visibleProducts = showAllRows ? products : products.slice(0, 4);

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-6 space-y-6 sm:space-y-8">
      {/* Hero Banner */}
      {(!heroBanner || heroBanner.active !== 0) && (
        <section
          aria-label="Featured bulk campaign"
          className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#E4FB9C] via-[#D7F58B] to-[#C2EB68] border border-[#B5E057]"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch min-h-[290px] sm:min-h-[340px]">
            <div className="lg:col-span-5 p-6 sm:p-10 flex flex-col justify-center relative z-10">
              <h1 className="font-display text-4xl sm:text-[48px] font-extrabold tracking-tight leading-[1.06] text-[#0A4D1F]">
                {heroBanner?.headline || 'Small prices. Big possibilities.'}
              </h1>
              <p className="mt-3 text-base sm:text-xl font-semibold text-[#115926]">
                {heroBanner?.subheadline || 'Everyday essentials, ready by the case.'}
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <Link
                  href={heroBanner?.cta_href || '#catalogue'}
                  className="inline-flex items-center gap-2.5 px-6 h-12 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-base shadow-sm transition-colors whitespace-nowrap"
                >
                  <span>{heroBanner?.cta_label || 'Shop bulk essentials'}</span>
                  <ArrowRight className="w-5 h-5" aria-hidden="true" />
                </Link>
              </div>
            </div>

            <div className="lg:col-span-7 relative min-h-[220px] sm:min-h-[280px] lg:min-h-full">
              <img
                src="/images/hero-bulk-essentials.jpg"
                alt="Bulk cleaning supplies, paper cups, colourful gift bags, spiral notebooks, and green-lid food storage containers"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-right lg:object-center"
              />
            </div>
          </div>
        </section>
      )}

      {/* Information Strip */}
      <section
        aria-label="Bulk shopping value promises"
        className="grid grid-cols-1 md:grid-cols-3 gap-4 py-3 border-y border-slate-200"
      >
        <div className="flex items-center justify-center gap-3 py-1">
          <Package className="w-7 h-7 text-[#0F6B2E] shrink-0" aria-hidden="true" />
          <span className="font-display text-base sm:text-lg font-extrabold text-[#0A4D1F]">
            Clear case quantities
          </span>
        </div>
        <div className="flex items-center justify-center gap-3 py-1">
          <Tag className="w-7 h-7 text-[#0F6B2E] shrink-0" aria-hidden="true" />
          <span className="font-display text-base sm:text-lg font-extrabold text-[#0A4D1F]">
            Unit prices upfront
          </span>
        </div>
        <div className="flex items-center justify-center gap-3 py-1">
          <Truck className="w-7 h-7 text-[#0F6B2E] shrink-0" aria-hidden="true" />
          <div>
            <span className="font-display text-base sm:text-lg font-extrabold text-[#0A4D1F] block leading-tight">
              Delivery or store pickup
            </span>
            <span className="text-xs text-slate-600 block">
              Availability depends on SKU & destination
            </span>
          </div>
        </div>
      </section>

      {/* Product Showcase & Filter Chips */}
      <section id="catalogue" aria-labelledby="everyday-value-heading" className="space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2
              id="everyday-value-heading"
              className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-[#0A4D1F]"
            >
              Stock up on everyday value
            </h2>
            {activeChip === 'under2' && (
              <p className="text-xs text-slate-600 mt-1">
                Showing cases with consumer selling unit price under $2.00 (per item or per pack).
              </p>
            )}
          </div>

          <div
            role="group"
            aria-label="Filter featured bulk products"
            className="flex flex-wrap items-center gap-2.5"
          >
            {FILTER_CHIPS.map((chip) => {
              const selected = activeChip === chip.id;
              return (
                <button
                  key={chip.id}
                  type="button"
                  onClick={() => void handleChipChange(chip.id)}
                  aria-pressed={selected}
                  className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap shrink-0 transition-colors border ${
                    selected
                      ? 'bg-[#0F6B2E] border-[#0F6B2E] text-white'
                      : 'bg-white border-[#137A35] text-[#0F6B2E] hover:bg-emerald-50'
                  }`}
                >
                  {chip.label}
                </button>
              );
            })}
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[1, 2, 3, 4].map((n) => (
              <div
                key={n}
                className="h-72 rounded-2xl border border-slate-200 bg-slate-50 animate-pulse"
              />
            ))}
          </div>
        ) : visibleProducts.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 p-10 text-center space-y-2">
            <p className="text-base font-bold text-slate-800">No products match this filter.</p>
            <button
              type="button"
              onClick={() => void handleChipChange('all')}
              className="text-sm font-bold text-[#0F6B2E] underline"
            >
              Reset to all essentials
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {visibleProducts.map((product) => (
              <ProductCard key={product.sku} product={product} />
            ))}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <p className="text-xs text-slate-500">
            Showing {visibleProducts.length} of {products.length} illustrative bulk SKUs
          </p>
          <div className="flex items-center gap-4">
            {products.length > 4 && (
              <button
                type="button"
                onClick={() => setShowAllRows((s) => !s)}
                className="text-sm font-bold text-[#0F6B2E] hover:underline"
              >
                {showAllRows ? 'Show featured 4 cases' : `Expand all ${products.length} matching cases`}
              </button>
            )}
            <Link
              href="/search"
              className="text-sm font-bold text-[#0F6B2E] hover:underline inline-flex items-center gap-1"
            >
              <span>Advanced search & filters</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Business Purchasing Banner */}
      {(!businessBanner || businessBanner.active !== 0) && (
        <section
          aria-label="Business bulk ordering"
          className="rounded-2xl bg-gradient-to-r from-[#E6FB9E] via-[#DDF792] to-[#CBF070] border border-[#B5E057] px-6 py-5 sm:px-10 sm:py-6 flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8"
        >
          <div className="flex items-center gap-4">
            <Store className="w-10 h-10 text-[#0F6B2E] shrink-0" aria-hidden="true" />
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-[#0A4D1F]">
                {businessBanner?.headline || 'Buying for your business?'}
              </h2>
              {businessBanner?.subheadline && (
                <p className="text-sm text-[#115926] font-medium mt-0.5">
                  {businessBanner.subheadline}
                </p>
              )}
            </div>
          </div>

          <div className="hidden md:block w-px h-10 bg-[#0F6B2E]/25" aria-hidden="true" />

          <Link
            href={businessBanner?.cta_href || '/business'}
            className="inline-flex items-center gap-2.5 px-6 h-12 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-base shadow-sm transition-colors whitespace-nowrap shrink-0"
          >
            <span>{businessBanner?.cta_label || 'Build your bulk order'}</span>
            <ArrowRight className="w-5 h-5" aria-hidden="true" />
          </Link>
        </section>
      )}
    </div>
  );
}
