'use client';

import React, { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Filter, RotateCcw, Search } from 'lucide-react';
import type { ProductCatalogItem } from '@/lib/services/catalogue';
import { NAVIGATION_CATEGORIES } from '@/lib/config';
import { ProductCard } from './ProductCard';
import { useStorefront } from './StorefrontProvider';

export function SearchCatalogueView({
  initialProducts,
}: {
  initialProducts: ProductCatalogItem[];
}) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { locations } = useStorefront();

  const [q, setQ] = useState(searchParams.get('q') || '');
  const [category, setCategory] = useState(searchParams.get('category') || 'all');
  const [under2, setUnder2] = useState(searchParams.get('under2') === 'true');
  const [maxCasePrice, setMaxCasePrice] = useState(searchParams.get('maxCasePrice') || '');
  const [minUnitsPerCase, setMinUnitsPerCase] = useState(searchParams.get('minUnitsPerCase') || '');
  const [fulfilmentMethod, setFulfilmentMethod] = useState(
    searchParams.get('fulfilmentMethod') || ''
  );
  const [locationId, setLocationId] = useState(searchParams.get('locationId') || '');
  const [inStockOnly, setInStockOnly] = useState(searchParams.get('inStockOnly') === 'true');
  const [sort, setSort] = useState(searchParams.get('sort') || 'relevance');

  const [products, setProducts] = useState<ProductCatalogItem[]>(initialProducts);
  const [loading, setLoading] = useState(false);

  const syncUrlAndFetch = async (overrides?: Partial<Record<string, string | boolean>>) => {
    const state = {
      q: overrides?.q !== undefined ? String(overrides.q) : q,
      category: overrides?.category !== undefined ? String(overrides.category) : category,
      under2: overrides?.under2 !== undefined ? Boolean(overrides.under2) : under2,
      maxCasePrice:
        overrides?.maxCasePrice !== undefined ? String(overrides.maxCasePrice) : maxCasePrice,
      minUnitsPerCase:
        overrides?.minUnitsPerCase !== undefined
          ? String(overrides.minUnitsPerCase)
          : minUnitsPerCase,
      fulfilmentMethod:
        overrides?.fulfilmentMethod !== undefined
          ? String(overrides.fulfilmentMethod)
          : fulfilmentMethod,
      locationId: overrides?.locationId !== undefined ? String(overrides.locationId) : locationId,
      inStockOnly:
        overrides?.inStockOnly !== undefined ? Boolean(overrides.inStockOnly) : inStockOnly,
      sort: overrides?.sort !== undefined ? String(overrides.sort) : sort,
    };

    const params = new URLSearchParams();
    if (state.q.trim()) params.set('q', state.q.trim().slice(0, 100));
    if (state.category && state.category !== 'all') params.set('category', state.category);
    if (state.under2) params.set('under2', 'true');
    if (state.maxCasePrice) params.set('maxCasePrice', state.maxCasePrice);
    if (state.minUnitsPerCase) params.set('minUnitsPerCase', state.minUnitsPerCase);
    if (state.fulfilmentMethod) params.set('fulfilmentMethod', state.fulfilmentMethod);
    if (state.locationId) params.set('locationId', state.locationId);
    if (state.inStockOnly) params.set('inStockOnly', 'true');
    if (state.sort && state.sort !== 'relevance') params.set('sort', state.sort);

    const qs = params.toString();
    router.replace(qs ? `/search?${qs}` : '/search', { scroll: false });

    setLoading(true);
    try {
      const res = await fetch(`/api/catalogue${qs ? `?${qs}` : ''}`, { cache: 'no-store' });
      if (res.ok) {
        const data = (await res.json()) as { products: ProductCatalogItem[] };
        setProducts(data.products);
      }
    } finally {
      setLoading(false);
    }
  };

  const currentQs = searchParams.toString();
  const mountedQsRef = React.useRef(currentQs);

  useEffect(() => {
    if (mountedQsRef.current === currentQs) return;
    mountedQsRef.current = currentQs;
    let active = true;
    const paramQ = searchParams.get('q') || '';
    const paramCat = searchParams.get('category') || 'all';
    void fetch(`/api/catalogue${currentQs ? `?${currentQs}` : ''}`, { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { products?: ProductCatalogItem[] } | null) => {
        if (!active) return;
        setQ(paramQ);
        setCategory(paramCat);
        if (data?.products) setProducts(data.products);
      });
    return () => {
      active = false;
    };
  }, [currentQs, searchParams]);

  const handleReset = () => {
    setQ('');
    setCategory('all');
    setUnder2(false);
    setMaxCasePrice('');
    setMinUnitsPerCase('');
    setFulfilmentMethod('');
    setLocationId('');
    setInStockOnly(false);
    setSort('relevance');
    void syncUrlAndFetch({
      q: '',
      category: 'all',
      under2: false,
      maxCasePrice: '',
      minUnitsPerCase: '',
      fulfilmentMethod: '',
      locationId: '',
      inStockOnly: false,
      sort: 'relevance',
    });
  };

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#0A4D1F]">
            Bulk Case Catalogue
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Search across titles, descriptions, categories, and SKUs. Filter state is shareable via URL.
          </p>
        </div>
        <p className="text-sm font-bold text-slate-700 tabular-nums">
          {products.length} {products.length === 1 ? 'case SKU' : 'case SKUs'} found
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6 items-start">
        {/* Filter Sidebar */}
        <aside
          aria-label="Catalogue filters"
          className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-5"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <Filter className="w-4 h-4 text-[#0F6B2E]" />
              <span>Filters</span>
            </h2>
            <button
              type="button"
              onClick={handleReset}
              className="text-xs font-bold text-[#0F6B2E] hover:underline inline-flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void syncUrlAndFetch();
            }}
            className="space-y-4"
          >
            <div>
              <label htmlFor="filter-q" className="block text-xs font-bold text-slate-700 mb-1">
                Search keyword or SKU
              </label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="filter-q"
                  type="text"
                  value={q}
                  maxLength={100}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="e.g. dish soap or DT-CLN-1001"
                  className="w-full h-9 pl-8 pr-3 rounded-lg border border-slate-300 bg-white text-sm"
                />
              </div>
            </div>

            <div>
              <label htmlFor="filter-cat" className="block text-xs font-bold text-slate-700 mb-1">
                Category
              </label>
              <select
                id="filter-cat"
                value={category}
                onChange={(e) => {
                  setCategory(e.target.value);
                  void syncUrlAndFetch({ category: e.target.value });
                }}
                className="w-full h-9 px-2.5 rounded-lg border border-slate-300 bg-white text-sm"
              >
                {NAVIGATION_CATEGORIES.map((c) => (
                  <option key={c.slug} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="pt-1">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={under2}
                  onChange={(e) => {
                    setUnder2(e.target.checked);
                    void syncUrlAndFetch({ under2: e.target.checked });
                  }}
                  className="mt-0.5 rounded border-slate-300 text-[#0F6B2E]"
                />
                <span className="text-xs text-slate-800 leading-snug">
                  <strong className="block font-bold">Under $2.00 per consumer unit</strong>
                  <span className="text-slate-500">
                    Evaluated on the product&apos;s consumer selling unit (per item or per pack).
                  </span>
                </span>
              </label>
            </div>

            <div>
              <label htmlFor="filter-max-case" className="block text-xs font-bold text-slate-700 mb-1">
                Max case price (USD)
              </label>
              <select
                id="filter-max-case"
                value={maxCasePrice}
                onChange={(e) => {
                  setMaxCasePrice(e.target.value);
                  void syncUrlAndFetch({ maxCasePrice: e.target.value });
                }}
                className="w-full h-9 px-2.5 rounded-lg border border-slate-300 bg-white text-sm"
              >
                <option value="">Any case price</option>
                <option value="25">Up to $25.00 / case</option>
                <option value="32">Up to $32.00 / case</option>
                <option value="36">Up to $36.00 / case</option>
                <option value="45">Up to $45.00 / case</option>
              </select>
            </div>

            <div>
              <label htmlFor="filter-units" className="block text-xs font-bold text-slate-700 mb-1">
                Minimum case contents
              </label>
              <select
                id="filter-units"
                value={minUnitsPerCase}
                onChange={(e) => {
                  setMinUnitsPerCase(e.target.value);
                  void syncUrlAndFetch({ minUnitsPerCase: e.target.value });
                }}
                className="w-full h-9 px-2.5 rounded-lg border border-slate-300 bg-white text-sm"
              >
                <option value="">Any count per case</option>
                <option value="12">12+ items/packs per case</option>
                <option value="24">24+ items/packs per case</option>
                <option value="36">36+ items/packs per case</option>
              </select>
            </div>

            <div>
              <label htmlFor="filter-fulfil" className="block text-xs font-bold text-slate-700 mb-1">
                Fulfilment method
              </label>
              <select
                id="filter-fulfil"
                value={fulfilmentMethod}
                onChange={(e) => {
                  setFulfilmentMethod(e.target.value);
                  void syncUrlAndFetch({ fulfilmentMethod: e.target.value });
                }}
                className="w-full h-9 px-2.5 rounded-lg border border-slate-300 bg-white text-sm"
              >
                <option value="">Any fulfilment</option>
                <option value="delivery">Delivery eligible</option>
                <option value="pickup">Store pickup eligible</option>
              </select>
            </div>

            <div>
              <label htmlFor="filter-loc" className="block text-xs font-bold text-slate-700 mb-1">
                Location availability
              </label>
              <select
                id="filter-loc"
                value={locationId}
                onChange={(e) => {
                  setLocationId(e.target.value);
                  void syncUrlAndFetch({ locationId: e.target.value });
                }}
                className="w-full h-9 px-2.5 rounded-lg border border-slate-300 bg-white text-sm"
              >
                <option value="">All hubs & stores</option>
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name}
                  </option>
                ))}
              </select>
            </div>

            <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-800">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => {
                  setInStockOnly(e.target.checked);
                  void syncUrlAndFetch({ inStockOnly: e.target.checked });
                }}
                className="rounded border-slate-300 text-[#0F6B2E]"
              />
              <span>In stock only</span>
            </label>

            <button
              type="submit"
              className="w-full h-9 rounded-lg bg-[#137A35] hover:bg-[#0F6B2E] text-white text-xs font-bold transition-colors"
            >
              Apply keyword & filters
            </button>
          </form>
        </aside>

        {/* Results Area */}
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5">
            <span className="text-xs text-slate-600">
              All displayed unit prices are derived from authoritative case prices in USD.
            </span>
            <div className="flex items-center gap-2">
              <label htmlFor="sort-select" className="text-xs font-bold text-slate-700">
                Sort by
              </label>
              <select
                id="sort-select"
                value={sort}
                onChange={(e) => {
                  setSort(e.target.value);
                  void syncUrlAndFetch({ sort: e.target.value });
                }}
                className="h-8 px-2.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold"
              >
                <option value="relevance">Relevance</option>
                <option value="unit_price_asc">Unit price: Low to High</option>
                <option value="unit_price_desc">Unit price: High to Low</option>
                <option value="case_price_asc">Case price: Low to High</option>
                <option value="case_price_desc">Case price: High to Low</option>
                <option value="name_asc">Product name: A–Z</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-72 rounded-2xl border border-slate-200 bg-slate-50 animate-pulse" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 p-12 text-center space-y-3">
              <p className="text-lg font-bold text-slate-900">No bulk cases matched your search</p>
              <p className="text-sm text-slate-600">
                Try clearing location or price filters, or search by category or SKU prefix like DT-CLN.
              </p>
              <button
                type="button"
                onClick={handleReset}
                className="px-4 py-2 rounded-xl bg-[#137A35] text-white text-sm font-bold"
              >
                Clear all filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {products.map((product) => (
                <ProductCard key={product.sku} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
