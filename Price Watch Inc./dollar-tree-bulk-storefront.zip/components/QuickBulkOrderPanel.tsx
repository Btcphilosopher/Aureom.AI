'use client';

import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Plus,
  ShoppingCart,
  Trash2,
  Upload,
} from 'lucide-react';
import { formatUsd } from '@/lib/pricing';
import { useStorefront } from './StorefrontProvider';
import type { BulkOrderReviewItem } from '@/app/api/bulk-order/validate/route';

interface QuickRow {
  id: string;
  sku: string;
  cases: string;
}

export function QuickBulkOrderPanel({
  poReference = '',
  companyName = '',
}: {
  poReference?: string;
  companyName?: string;
}) {
  const { cart, locations, refreshCart, setCartDrawerOpen, announce } = useStorefront();

  const [rows, setRows] = useState<QuickRow[]>([
    { id: '1', sku: 'DT-CLN-1001', cases: '2' },
    { id: '2', sku: 'DT-KIT-2001', cases: '1' },
    { id: '3', sku: '', cases: '1' },
  ]);
  const [csvText, setCsvText] = useState('');
  const [mode, setMode] = useState<'manual' | 'csv'>('manual');
  const [locationId, setLocationId] = useState(cart?.locationId || 'LOC-DC-EAST');

  const [reviewing, setReviewing] = useState(false);
  const [committing, setCommitting] = useState(false);
  const [parseErrors, setParseErrors] = useState<string[]>([]);
  const [reviewItems, setReviewItems] = useState<BulkOrderReviewItem[] | null>(null);
  const [summary, setSummary] = useState<{
    totalValidLines: number;
    totalCases: number;
    totalMerchandiseCents: number;
  } | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      setParseErrors(['Selected CSV file exceeds 2 MB limit.']);
      return;
    }
    const text = await file.text();
    setCsvText(text);
    setMode('csv');
    setReviewItems(null);
  };

  const runValidation = async (commit: boolean) => {
    if (commit) setCommitting(true);
    else setReviewing(true);
    setFeedbackMsg(null);

    try {
      const payload =
        mode === 'csv'
          ? { csvText, locationId, commit }
          : {
              items: rows
                .filter((r) => r.sku.trim().length > 0)
                .map((r) => ({ sku: r.sku.trim(), cases: Number(r.cases) })),
              locationId,
              commit,
            };

      const res = await fetch('/api/bulk-order/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setParseErrors([data.error || 'Validation failed.']);
        return;
      }

      setParseErrors(data.parseErrors || []);
      setReviewItems(data.reviewItems || []);
      if (data.summary) setSummary(data.summary);

      if (commit && data.committed) {
        await refreshCart();
        setFeedbackMsg('Valid bulk order lines have been added to your cart.');
        announce('Bulk order lines added to cart.');
        setCartDrawerOpen(true);
      }
    } finally {
      setReviewing(false);
      setCommitting(false);
    }
  };

  const handleDownloadSummaryCsv = async () => {
    const linesToExport =
      reviewItems?.filter((i) => i.valid).map((i) => ({
        sku: i.sku,
        title: i.title,
        cases: i.cases,
        totalConsumerUnits: i.totalConsumerUnits,
        casePriceCents: i.casePriceCents,
        lineSubtotalCents: i.lineSubtotalCents,
      })) || [];

    const res = await fetch('/api/bulk-order/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        poReference,
        companyName,
        lines: linesToExport,
      }),
    });
    if (!res.ok) return;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'bulk-order-summary.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setMode('manual');
                setReviewItems(null);
              }}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
                mode === 'manual'
                  ? 'bg-[#0F6B2E] text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Quick SKU Entry
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('csv');
                setReviewItems(null);
              }}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
                mode === 'csv'
                  ? 'bg-[#0F6B2E] text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              CSV Bulk Upload
            </button>
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="bulk-loc" className="text-xs font-bold text-slate-700">
              Check stock at:
            </label>
            <select
              id="bulk-loc"
              value={locationId}
              onChange={(e) => {
                setLocationId(e.target.value);
                setReviewItems(null);
              }}
              className="h-9 px-2.5 rounded-lg border border-slate-300 text-xs font-semibold bg-white"
            >
              {locations.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {mode === 'manual' ? (
          <div className="space-y-3">
            <div className="grid grid-cols-[1fr_110px_40px] gap-2 text-xs font-bold text-slate-500 px-1">
              <span>SKU (e.g. DT-CLN-1001)</span>
              <span>Cases</span>
              <span className="sr-only">Remove</span>
            </div>
            {rows.map((r, idx) => (
              <div key={r.id} className="grid grid-cols-[1fr_110px_40px] gap-2 items-center">
                <input
                  type="text"
                  aria-label={`SKU row ${idx + 1}`}
                  value={r.sku}
                  onChange={(e) => {
                    const next = [...rows];
                    next[idx] = { ...r, sku: e.target.value.toUpperCase() };
                    setRows(next);
                    setReviewItems(null);
                  }}
                  placeholder="Enter SKU e.g. DT-CLN-1001"
                  className="h-10 px-3 rounded-lg border border-slate-300 font-mono text-sm"
                />
                <input
                  type="number"
                  min={1}
                  max={50}
                  aria-label={`Cases row ${idx + 1}`}
                  value={r.cases}
                  onChange={(e) => {
                    const next = [...rows];
                    next[idx] = { ...r, cases: e.target.value };
                    setRows(next);
                    setReviewItems(null);
                  }}
                  className="h-10 px-3 rounded-lg border border-slate-300 text-sm font-bold tabular-nums"
                />
                <button
                  type="button"
                  aria-label={`Remove row ${idx + 1}`}
                  onClick={() => setRows(rows.filter((x) => x.id !== r.id))}
                  className="h-10 w-10 flex items-center justify-center rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}

            <button
              type="button"
              onClick={() =>
                setRows([...rows, { id: String(Date.now()), sku: '', cases: '1' }])
              }
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0F6B2E] hover:underline pt-1"
            >
              <Plus className="w-4 h-4" />
              <span>Add another SKU row</span>
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <FileSpreadsheet className="w-8 h-8 text-[#0F6B2E] shrink-0" />
                <div>
                  <p className="text-sm font-bold text-slate-900">
                    Upload CSV (max 2 MB, 500 rows)
                  </p>
                  <p className="text-xs text-slate-600">
                    Required header columns: <code className="font-mono">sku,cases</code>
                  </p>
                </div>
              </div>
              <label className="px-4 py-2 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-xs font-bold text-slate-800 cursor-pointer inline-flex items-center gap-1.5">
                <Upload className="w-4 h-4" />
                <span>Choose CSV file</span>
                <input
                  type="file"
                  accept=".csv,text/csv"
                  onChange={(e) => void handleFileChange(e)}
                  className="sr-only"
                />
              </label>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="csv-textarea" className="text-xs font-bold text-slate-700">
                  Or paste CSV rows
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setCsvText('sku,cases\nDT-CLN-1001,2\nDT-KIT-2001,1\nDT-BUS-6001,2');
                    setReviewItems(null);
                  }}
                  className="text-xs font-bold text-[#0F6B2E] hover:underline"
                >
                  Load sample CSV
                </button>
              </div>
              <textarea
                id="csv-textarea"
                rows={5}
                value={csvText}
                onChange={(e) => {
                  setCsvText(e.target.value);
                  setReviewItems(null);
                }}
                placeholder={'sku,cases\nDT-CLN-1001,2\nDT-KIT-2001,1'}
                className="w-full p-3 rounded-xl border border-slate-300 font-mono text-xs"
              />
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={() => void runValidation(false)}
            disabled={reviewing}
            className="h-11 px-6 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white text-sm font-bold transition-colors disabled:opacity-60"
          >
            {reviewing ? 'Validating...' : 'Validate & Review Order'}
          </button>

          <button
            type="button"
            onClick={() => void handleDownloadSummaryCsv()}
            className="h-10 px-4 rounded-xl border border-slate-300 hover:bg-slate-50 text-xs font-bold text-slate-700 inline-flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>Download summary CSV</span>
          </button>
        </div>
      </div>

      {/* Parse Errors */}
      {parseErrors.length > 0 && (
        <div
          role="alert"
          className="rounded-2xl border border-red-200 bg-red-50 p-4 text-xs text-red-900 space-y-1"
        >
          <p className="font-bold flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 text-red-600" />
            <span>CSV / Input formatting issues</span>
          </p>
          <ul className="list-disc pl-5 space-y-0.5">
            {parseErrors.map((err, i) => (
              <li key={i}>{err}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Pre-Cart Review Screen */}
      {reviewItems && (
        <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                Pre-Cart Validation Review
              </h2>
              <p className="text-xs text-slate-600">
                Review case quantities, increments, and stock before applying lines to your cart.
              </p>
            </div>
            {summary && (
              <div className="text-right tabular-nums">
                <p className="text-xs text-slate-500">
                  {summary.totalValidLines} valid lines · {summary.totalCases} cases
                </p>
                <p className="text-lg font-extrabold text-[#0A4D1F]">
                  {formatUsd(summary.totalMerchandiseCents)}
                </p>
              </div>
            )}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                <tr>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4">SKU</th>
                  <th className="py-2.5 px-4">Product</th>
                  <th className="py-2.5 px-4 text-right">Cases</th>
                  <th className="py-2.5 px-4 text-right">Total Units</th>
                  <th className="py-2.5 px-4 text-right">Case Price</th>
                  <th className="py-2.5 px-4 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {reviewItems.map((item) => (
                  <tr key={`${item.lineNumber}-${item.sku}`}>
                    <td className="py-3 px-4">
                      {item.valid ? (
                        <span className="inline-flex items-center gap-1 font-bold text-[#0F6B2E]">
                          <CheckCircle2 className="w-4 h-4" /> Ready
                        </span>
                      ) : (
                        <span className="inline-flex items-start gap-1 font-bold text-red-600">
                          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                          <span>{item.errors.join(' ')}</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono">{item.sku}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{item.title}</td>
                    <td className="py-3 px-4 text-right font-bold tabular-nums">{item.cases}</td>
                    <td className="py-3 px-4 text-right tabular-nums">{item.totalConsumerUnits}</td>
                    <td className="py-3 px-4 text-right tabular-nums">
                      {formatUsd(item.casePriceCents)}
                    </td>
                    <td className="py-3 px-4 text-right font-bold tabular-nums">
                      {formatUsd(item.lineSubtotalCents)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
            {feedbackMsg ? (
              <p className="text-xs font-bold text-[#0F6B2E]">{feedbackMsg}</p>
            ) : (
              <span className="text-xs text-slate-500">
                Invalid lines will not be added. Fix errors above or apply valid lines only.
              </span>
            )}
            <button
              type="button"
              disabled={!summary || summary.totalValidLines === 0 || committing}
              onClick={() => void runValidation(true)}
              className="h-11 px-6 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white text-sm font-bold inline-flex items-center gap-2 disabled:opacity-50"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>
                {committing
                  ? 'Applying...'
                  : `Apply ${summary?.totalValidLines || 0} valid line(s) to cart`}
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
