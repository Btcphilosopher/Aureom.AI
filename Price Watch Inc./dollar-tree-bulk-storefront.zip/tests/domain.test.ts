import { describe, it, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dt-bulk-tests-'));
const dbFile = path.join(tmpDir, 'test-storefront.db');
process.env.STOREFRONT_DB_PATH = dbFile;

const { getDb } = await import('../lib/db.ts');
const {
  deriveConsumerUnitPriceCents,
  computePackagingBreakdown,
  validateCaseQuantity,
  calculateOrderTotals,
  formatUsd,
} = await import('../lib/pricing.ts');
const { sanitizeCsvCell, buildSafeCsv, parseBulkOrderCsv } = await import('../lib/csv.ts');
const { listProducts, getProductDetail } = await import('../lib/services/catalogue.ts');
const {
  getOrCreateCart,
  getCartView,
  upsertCartItem,
  mergeGuestCartOnSignIn,
} = await import('../lib/services/cart.ts');
const {
  createOrderAttempt,
  processPaymentWebhook,
  CheckoutConflictError,
} = await import('../lib/services/checkout.ts');
const { expireStaleReservations } = await import('../lib/services/worker.ts');
const {
  getOrderScoped,
  transitionFulfilmentStatus,
  issueRefund,
  reorderToCart,
} = await import('../lib/services/orders.ts');
const { hashPassword, requireStaffRole, bootstrapFirstAdmin } = await import('../lib/auth.ts');

function createCustomerHelper(params: { email: string; password: string; name: string }) {
  const db = getDb();
  const id = `USR-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  db.prepare(
    `INSERT INTO users (id, email, name, password_hash, role, company_name, tax_id, created_at)
     VALUES (?, ?, ?, ?, 'customer', '', '', ?)`
  ).run(id, params.email.toLowerCase(), params.name, hashPassword(params.password), new Date().toISOString());
  return {
    id,
    email: params.email.toLowerCase(),
    name: params.name,
    role: 'customer' as const,
    companyName: '',
    taxId: '',
  };
}

function resetDatabase() {
  const g = globalThis as { __storefrontDb?: { close: () => void }; __storefrontDbPath?: string };
  if (g.__storefrontDb) {
    try {
      g.__storefrontDb.close();
    } catch {
      // ignore
    }
    g.__storefrontDb = undefined;
    g.__storefrontDbPath = undefined;
  }
  for (const suffix of ['', '-wal', '-shm']) {
    if (fs.existsSync(dbFile + suffix)) {
      fs.unlinkSync(dbFile + suffix);
    }
  }
  getDb();
}

describe('Dollar Tree Bulk Storefront — Domain, Pricing, Inventory & Order Lifecycle', () => {
  beforeEach(() => {
    resetDatabase();
  });

  after(() => {
    const g = globalThis as { __storefrontDb?: { close: () => void } };
    if (g.__storefrontDb) {
      try {
        g.__storefrontDb.close();
      } catch {
        // ignore
      }
    }
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('1. Packaging & integer-cent case arithmetic matches mockup figures exactly', () => {
    const paperCups = computePackagingBreakdown({
      consumerSellingUnit: 'pack',
      itemsPerConsumerPack: 12,
      consumerUnitsPerCase: 24,
      casePriceCents: 3000,
    });
    assert.equal(paperCups.unitPriceCents, 125);
    assert.equal(paperCups.totalIndividualItemsPerCase, 288);
    assert.equal(formatUsd(paperCups.unitPriceCents), '$1.25');
    assert.equal(formatUsd(paperCups.casePriceCents), '$30.00');

    // Dish Soap (2 cases @ $30.00) + Paper Cups (1 case @ $30.00) = 3 cases, $90.00 subtotal
    const dishSubtotal = 2 * 3000;
    const cupSubtotal = 1 * 3000;
    const totals = calculateOrderTotals({
      lineSubtotalsCents: [dishSubtotal, cupSubtotal],
      fulfilmentMethod: 'delivery',
      destinationState: 'NJ',
    });
    assert.equal(totals.merchandiseSubtotalCents, 9000);
    assert.equal(totals.deliveryFeeCents, 1495);
    assert.equal(totals.taxRateBps, 663);
    assert.equal(totals.taxCents, 597);
    assert.equal(totals.totalCents, 9000 + 1495 + 597);
  });

  it('2. Half-up rounding derives deterministic consumer unit prices from case price', () => {
    assert.equal(deriveConsumerUnitPriceCents(3000, 24), 125);
    assert.equal(deriveConsumerUnitPriceCents(3005, 10), 301); // 300.5 -> 301
    assert.equal(deriveConsumerUnitPriceCents(1500, 8), 188); // 187.5 -> 188
    assert.equal(deriveConsumerUnitPriceCents(2500, 24), 104); // 104.16 -> 104
  });

  it('3. Case quantity increments and minimum case quantities are enforced', () => {
    assert.equal(validateCaseQuantity(1, 2, 2).valid, false);
    assert.equal(validateCaseQuantity(3, 2, 2).valid, false);
    assert.equal(validateCaseQuantity(2, 2, 2).valid, true);
    assert.equal(validateCaseQuantity(4, 2, 2).valid, true);
    assert.equal(validateCaseQuantity(51, 1, 1).valid, false);
  });

  it('4. Seeded catalogue has >= 24 active SKUs and accurate filters & sorting', () => {
    const all = listProducts();
    assert.ok(all.length >= 24, `Expected >= 24 SKUs, got ${all.length}`);

    const under2 = listProducts({ under2: true });
    assert.ok(under2.length > 0);
    for (const p of under2) {
      assert.ok(p.packaging.unitPriceCents < 200, `${p.sku} unit price exceeded $2.00`);
    }

    const sortedAsc = listProducts({ sort: 'case_price_asc' });
    for (let i = 1; i < sortedAsc.length; i++) {
      assert.ok(
        sortedAsc[i].packaging.casePriceCents >= sortedAsc[i - 1].packaging.casePriceCents
      );
    }

    const skuMatch = listProducts({ q: 'DT-CLN-1001' });
    assert.equal(skuMatch.length, 1);
    assert.equal(skuMatch[0].title, 'Dish Soap, 16 fl oz');
  });

  it('5. Guest cart persists and merges deterministically on sign-in', () => {
    const guest = getOrCreateCart({ guestToken: 'guest-token-alpha' });
    upsertCartItem({ cartId: guest.cartId, sku: 'DT-CLN-1001', casesDeltaOrSet: 2, mode: 'add' });
    upsertCartItem({ cartId: guest.cartId, sku: 'DT-KIT-2001', casesDeltaOrSet: 1, mode: 'add' });

    // Cart insertion does NOT reserve inventory
    const detail = getProductDetail('DT-CLN-1001').product!;
    assert.equal(detail.locationAvailability[0].reservedCases, 0);

    const user = createCustomerHelper({
      email: 'buyer@example.org',
      password: 'Password123!',
      name: 'Buyer One',
    });
    const userCart = getOrCreateCart({ userId: user.id });
    upsertCartItem({ cartId: userCart.cartId, sku: 'DT-CLN-1001', casesDeltaOrSet: 3, mode: 'add' });

    const merged = mergeGuestCartOnSignIn('guest-token-alpha', user.id);
    assert.equal(merged.cart.totalCases, 6); // 5 Dish Soap + 1 Paper Cups
    assert.equal(merged.cart.merchandiseSubtotalCents, 18000);
    assert.ok(merged.mergeNotices.some((n) => n.includes('Merged 2 guest case(s)')));
  });

  it('6. Checkout reservations prevent oversell and respect idempotency keys', () => {
    const db = getDb();
    // Set on_hand_cases = 3 for DT-CLN-1001 at LOC-DC-EAST
    db.prepare(
      'UPDATE inventory_levels SET on_hand_cases = 3, reserved_cases = 0 WHERE sku = ? AND location_id = ?'
    ).run('DT-CLN-1001', 'LOC-DC-EAST');

    const cartA = getOrCreateCart({ guestToken: 'guest-a' });
    upsertCartItem({ cartId: cartA.cartId, sku: 'DT-CLN-1001', casesDeltaOrSet: 2, mode: 'add' });
    const attemptA = createOrderAttempt({
      cartId: cartA.cartId,
      fulfilmentMethod: 'delivery',
      locationId: 'LOC-DC-EAST',
      contact: { email: 'a@example.org', name: 'Buyer A', phone: '555-0100' },
      shippingAddress: { line1: '1 Main', city: 'Newark', state: 'NJ', postalCode: '07102' },
      idempotencyKey: 'idem-A',
    });
    assert.equal(attemptA.reusedIdempotent, false);

    // Duplicate idempotencyKey returns existing attempt without double-reserving
    const attemptADup = createOrderAttempt({
      cartId: cartA.cartId,
      fulfilmentMethod: 'delivery',
      locationId: 'LOC-DC-EAST',
      contact: { email: 'a@example.org', name: 'Buyer A', phone: '555-0100' },
      shippingAddress: { line1: '1 Main', city: 'Newark', state: 'NJ', postalCode: '07102' },
      idempotencyKey: 'idem-A',
    });
    assert.equal(attemptADup.reusedIdempotent, true);
    assert.equal(attemptADup.orderId, attemptA.orderId);

    // Second buyer requesting 2 cases when only 1 ATP remains must fail with CheckoutConflictError
    const cartB = getOrCreateCart({ guestToken: 'guest-b' });
    upsertCartItem({ cartId: cartB.cartId, sku: 'DT-CLN-1001', casesDeltaOrSet: 2, mode: 'add' });
    assert.throws(
      () =>
        createOrderAttempt({
          cartId: cartB.cartId,
          fulfilmentMethod: 'delivery',
          locationId: 'LOC-DC-EAST',
          contact: { email: 'b@example.org', name: 'Buyer B', phone: '555-0101' },
          shippingAddress: { line1: '2 Main', city: 'Newark', state: 'NJ', postalCode: '07102' },
          idempotencyKey: 'idem-B',
        }),
      CheckoutConflictError
    );
  });

  it('7. Reservation expiry worker releases reserved stock and cancels unpaid order', () => {
    const db = getDb();
    const cart = getOrCreateCart({ guestToken: 'guest-expire' });
    upsertCartItem({ cartId: cart.cartId, sku: 'DT-CLN-1001', casesDeltaOrSet: 2, mode: 'add' });
    const attempt = createOrderAttempt({
      cartId: cart.cartId,
      fulfilmentMethod: 'delivery',
      locationId: 'LOC-DC-EAST',
      contact: { email: 'exp@example.org', name: 'Exp User', phone: '555-0102' },
      shippingAddress: { line1: '1 Main', city: 'Newark', state: 'NJ', postalCode: '07102' },
      idempotencyKey: 'idem-expire',
      reservationTtlMinutes: -5, // Already expired
    });

    const invBefore = db
      .prepare('SELECT reserved_cases FROM inventory_levels WHERE sku = ? AND location_id = ?')
      .get('DT-CLN-1001', 'LOC-DC-EAST') as { reserved_cases: number };
    assert.equal(invBefore.reserved_cases, 2);

    const sweep = expireStaleReservations();
    assert.equal(sweep.expiredReservationCount, 1);
    assert.equal(sweep.cancelledOrderCount, 1);
    assert.equal(sweep.releasedCasesTotal, 2);

    const invAfter = db
      .prepare('SELECT reserved_cases FROM inventory_levels WHERE sku = ? AND location_id = ?')
      .get('DT-CLN-1001', 'LOC-DC-EAST') as { reserved_cases: number };
    assert.equal(invAfter.reserved_cases, 0);

    const ord = db
      .prepare('SELECT order_status FROM orders WHERE id = ?')
      .get(attempt.orderId) as { order_status: string };
    assert.equal(ord.order_status, 'cancelled');
  });

  it('8. Duplicate & delayed payment webhooks reconcile safely without overselling', () => {
    const db = getDb();
    db.prepare(
      'UPDATE inventory_levels SET on_hand_cases = 2, reserved_cases = 0 WHERE sku = ? AND location_id = ?'
    ).run('DT-CLN-1001', 'LOC-DC-EAST');

    // Buyer 1 reservation expires and is swept
    const cart1 = getOrCreateCart({ guestToken: 'guest-late' });
    upsertCartItem({ cartId: cart1.cartId, sku: 'DT-CLN-1001', casesDeltaOrSet: 2, mode: 'add' });
    const lateAttempt = createOrderAttempt({
      cartId: cart1.cartId,
      fulfilmentMethod: 'delivery',
      locationId: 'LOC-DC-EAST',
      contact: { email: 'late@example.org', name: 'Late Buyer', phone: '555-0103' },
      shippingAddress: { line1: '1 Main', city: 'Newark', state: 'NJ', postalCode: '07102' },
      idempotencyKey: 'idem-late',
      reservationTtlMinutes: -5,
    });
    expireStaleReservations();

    // Buyer 2 buys and pays for those 2 cases
    const cart2 = getOrCreateCart({ guestToken: 'guest-fast' });
    upsertCartItem({ cartId: cart2.cartId, sku: 'DT-CLN-1001', casesDeltaOrSet: 2, mode: 'add' });
    const fastAttempt = createOrderAttempt({
      cartId: cart2.cartId,
      fulfilmentMethod: 'delivery',
      locationId: 'LOC-DC-EAST',
      contact: { email: 'fast@example.org', name: 'Fast Buyer', phone: '555-0104' },
      shippingAddress: { line1: '2 Main', city: 'Newark', state: 'NJ', postalCode: '07102' },
      idempotencyKey: 'idem-fast',
    });
    const fastPay = processPaymentWebhook({
      provider: 'local_simulator',
      providerEventId: 'evt-fast-1',
      eventType: 'payment.succeeded',
      orderId: fastAttempt.orderId,
      amountCents: fastAttempt.totalCents,
    });
    assert.equal(fastPay.orderStatus, 'confirmed');
    assert.equal(fastPay.paymentStatus, 'paid');

    // Duplicate webhook is ignored idempotently
    const dupPay = processPaymentWebhook({
      provider: 'local_simulator',
      providerEventId: 'evt-fast-1',
      eventType: 'payment.succeeded',
      orderId: fastAttempt.orderId,
      amountCents: fastAttempt.totalCents,
    });
    assert.equal(dupPay.deduplicated, true);

    // Delayed webhook arrives for lateAttempt -> triggers automatic reconciliation refund!
    const latePay = processPaymentWebhook({
      provider: 'stripe_sandbox',
      providerEventId: 'evt-late-1',
      eventType: 'payment.succeeded',
      orderId: lateAttempt.orderId,
      amountCents: lateAttempt.totalCents,
    });
    assert.equal(latePay.orderStatus, 'reconciliation_required');
    assert.equal(latePay.paymentStatus, 'refunded');
    assert.equal(latePay.reconciledAction, 'auto_refunded_post_expiry_oversell_prevented');
  });

  it('9. RBAC, customer-scoped order access, fulfilment state machine, refunds, and immutable snapshots', () => {
    const db = getDb();
    const admin = bootstrapFirstAdmin({
      email: 'admin@store.local',
      password: 'AdminPassword123!',
      name: 'Ops Admin',
    });
    const customerA = createCustomerHelper({
      email: 'custA@example.org',
      password: 'Password123!',
      name: 'Customer A',
    });
    const customerB = createCustomerHelper({
      email: 'custB@example.org',
      password: 'Password123!',
      name: 'Customer B',
    });

    assert.equal(requireStaffRole(customerA, ['admin']).ok, false);
    assert.equal(requireStaffRole(admin, ['admin']).ok, true);

    const cart = getOrCreateCart({ userId: customerA.id });
    upsertCartItem({ cartId: cart.cartId, sku: 'DT-CLN-1001', casesDeltaOrSet: 2, mode: 'add' });
    upsertCartItem({ cartId: cart.cartId, sku: 'DT-KIT-2001', casesDeltaOrSet: 1, mode: 'add' });

    const attempt = createOrderAttempt({
      cartId: cart.cartId,
      userId: customerA.id,
      fulfilmentMethod: 'delivery',
      locationId: 'LOC-DC-EAST',
      contact: { email: customerA.email, name: customerA.name, phone: '555-0199' },
      shippingAddress: { line1: '10 Oak', city: 'Cherry Hill', state: 'NJ', postalCode: '08002' },
      idempotencyKey: `idem-${crypto.randomUUID()}`,
    });

    processPaymentWebhook({
      provider: 'local_simulator',
      providerEventId: 'evt-sec-1',
      eventType: 'payment.succeeded',
      orderId: attempt.orderId,
      amountCents: attempt.totalCents,
      cartIdToClear: cart.cartId,
    });

    // Customer B cannot read Customer A's order
    assert.equal(getOrderScoped({ orderId: attempt.orderId, user: customerB }), null);
    const scopedA = getOrderScoped({ orderId: attempt.orderId, user: customerA });
    assert.ok(scopedA);
    assert.equal(scopedA.merchandiseSubtotalCents, 9000);

    // Invalid skip transition rejected
    assert.throws(() =>
      transitionFulfilmentStatus({
        orderId: attempt.orderId,
        nextStatus: 'delivered',
        actor: admin,
      })
    );

    // Valid delivery transitions
    transitionFulfilmentStatus({ orderId: attempt.orderId, nextStatus: 'picking', actor: admin });
    transitionFulfilmentStatus({ orderId: attempt.orderId, nextStatus: 'packed', actor: admin });
    transitionFulfilmentStatus({ orderId: attempt.orderId, nextStatus: 'dispatched', actor: admin });
    const delivered = transitionFulfilmentStatus({
      orderId: attempt.orderId,
      nextStatus: 'delivered',
      actor: admin,
    });
    assert.equal(delivered.fulfilmentStatus, 'delivered');

    // Partial refund + remaining full refund + reject over-refund
    const partial = issueRefund({
      orderId: attempt.orderId,
      amountCents: 3000,
      reason: '1 damaged case',
      actor: admin,
    });
    assert.equal(partial.paymentStatus, 'partially_refunded');

    assert.throws(() =>
      issueRefund({
        orderId: attempt.orderId,
        amountCents: attempt.totalCents,
        reason: 'Over-refund attempt',
        actor: admin,
      })
    );

    const remaining = attempt.totalCents - 3000;
    const full = issueRefund({
      orderId: attempt.orderId,
      amountCents: remaining,
      reason: 'Remaining balance',
      actor: admin,
    });
    assert.equal(full.paymentStatus, 'refunded');

    // Admin updates Dish Soap price to $36.00/case -> historical order snapshot stays $30.00/case
    db.prepare('UPDATE skus SET case_price_cents = 3600 WHERE sku = ?').run('DT-CLN-1001');
    const historical = getOrderScoped({ orderId: attempt.orderId, user: customerA })!;
    const dishItem = historical.items.find((i) => i.sku === 'DT-CLN-1001')!;
    assert.equal(dishItem.casePriceCentsSnapshot, 3000);
    assert.equal(historical.merchandiseSubtotalCents, 9000);

    // Reorder uses CURRENT live SKU prices ($36.00 * 2 + $30.00 * 1 = $102.00)
    const reorder = reorderToCart({ orderId: attempt.orderId, userId: customerA.id });
    assert.ok(reorder.notices.some((n) => n.includes('$36.00')));
    const newCart = getCartView(reorder.cartId);
    assert.equal(newCart.merchandiseSubtotalCents, 10200);
  });

  it('10. CSV parser validation and spreadsheet formula injection neutralization', () => {
    assert.equal(sanitizeCsvCell('=CMD("calc")'), `"'=CMD(""calc"")"`);
    assert.equal(sanitizeCsvCell('+SUM(A1:A2)'), "'+SUM(A1:A2)");
    assert.equal(sanitizeCsvCell('-1+1'), "'-1+1");
    assert.equal(sanitizeCsvCell('@HYPERLINK'), "'@HYPERLINK");

    const exported = buildSafeCsv(['PO', 'SKU'], [['=1+1', 'DT-CLN-1001']]);
    assert.ok(exported.includes("'=1+1"));

    const parsed = parseBulkOrderCsv('sku,cases\nDT-CLN-1001,2\nDT-KIT-2001,1\nBAD SKU,-3');
    assert.equal(parsed.rows.length, 2);
    assert.equal(parsed.errors.length, 1);
  });
});
