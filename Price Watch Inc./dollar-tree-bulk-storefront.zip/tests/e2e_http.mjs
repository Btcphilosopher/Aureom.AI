import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

const EXTERNAL_BASE = process.env.E2E_BASE_URL;
const PORT = 3196;
const BASE = EXTERNAL_BASE || `http://127.0.0.1:${PORT}`;
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dt-e2e-'));
const dbFile = path.join(tmpDir, 'e2e.db');

class CookieJar {
  constructor() {
    this.map = new Map();
  }
  updateFrom(res) {
    const setCookies =
      typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [];
    for (const raw of setCookies) {
      const pair = raw.split(';')[0];
      const eq = pair.indexOf('=');
      if (eq > 0) {
        const name = pair.slice(0, eq).trim();
        const val = pair.slice(eq + 1).trim();
        if (!val) this.map.delete(name);
        else this.map.set(name, val);
      }
    }
  }
  header() {
    return Array.from(this.map.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join('; ');
  }
}

async function req(jar, pathname, init = {}) {
  const headers = new Headers(init.headers || {});
  const cookieHeader = jar?.header();
  if (cookieHeader) headers.set('cookie', cookieHeader);
  if (init.body && !headers.has('content-type')) {
    headers.set('content-type', 'application/json');
  }
  headers.set('x-requested-with', 'fetch');
  const res = await fetch(`${BASE}${pathname}`, { ...init, headers });
  if (jar) jar.updateFrom(res);
  return res;
}

async function waitForReady() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`${BASE}/api/health`);
      if (res.ok) return;
    } catch {
      // retry
    }
    await new Promise((r) => setTimeout(r, 250));
  }
  throw new Error('Test Next.js server did not become ready in time.');
}

let serverLogs = '';
const server = EXTERNAL_BASE
  ? null
  : spawn(
      process.execPath,
      ['./node_modules/next/dist/bin/next', 'start', '-p', String(PORT), '-H', '127.0.0.1'],
      {
        cwd: process.cwd(),
        env: { ...process.env, STOREFRONT_DB_PATH: dbFile },
        stdio: ['ignore', 'pipe', 'pipe'],
        detached: true,
      }
    );
if (server) {
  server.stdout.on('data', (d) => (serverLogs += d.toString()));
  server.stderr.on('data', (d) => (serverLogs += d.toString()));
  server.unref();
}

try {
  await waitForReady();

  // 1. Verify all storefront & console SSR routes return 200 without runtime error
  const ssrChecks = [
    ['/', 'Small prices.'],
    ['/search?under2=true', 'Bulk Case Catalogue'],
    ['/products/DT-CLN-1001', 'Dish Soap, 16 fl oz'],
    ['/products/DT-KIT-2001', '288 items per case'],
    ['/cart', 'Shopping Cart'],
    ['/quick-order', 'Quick Bulk Order'],
    ['/business', 'Institutional Bulk Purchasing'],
    ['/checkout', 'Bulk Checkout'],
    ['/account', 'Customer Account'],
    ['/admin', 'Storefront Operations'],
  ];

  for (const [route, expectedText] of ssrChecks) {
    const res = await fetch(`${BASE}${route}`);
    const html = await res.text();
    const visibleHtml = html.replace(/<!--[\s\S]*?-->/g, '');
    if (res.status !== 200) {
      console.error('Server logs:\n', serverLogs);
      console.error('HTML snippet:\n', html.slice(0, 500));
    }
    assert.equal(res.status, 200, `Expected 200 for ${route}, got ${res.status}`);
    assert.ok(
      visibleHtml.includes(expectedText),
      `Route ${route} missing expected text "${expectedText}"`
    );
  }

  // 2. API health & seeded catalogue check
  const healthRes = await fetch(`${BASE}/api/health`);
  assert.equal(healthRes.status, 200);
  const catRes = await fetch(`${BASE}/api/catalogue`);
  const catData = await catRes.json();
  assert.ok(catData.products.length >= 24, `Expected >= 24 seeded SKUs`);

  // 3. Section 16 E2E Flow: Guest adds 2 cases Dish Soap + 1 case Paper Cups = 3 cases ($90.00)
  const guestJar = new CookieJar();
  const add1 = await req(guestJar, '/api/cart', {
    method: 'POST',
    body: JSON.stringify({ action: 'add', sku: 'DT-CLN-1001', cases: 2 }),
  });
  assert.equal(add1.status, 200);

  const add2 = await req(guestJar, '/api/cart', {
    method: 'POST',
    body: JSON.stringify({ action: 'add', sku: 'DT-KIT-2001', cases: 1 }),
  });
  assert.equal(add2.status, 200);
  const cartData = await add2.json();
  assert.equal(cartData.cart.totalCases, 3);
  assert.equal(cartData.cart.merchandiseSubtotalCents, 9000);

  // 4. Server checkout quote
  const quoteRes = await req(guestJar, '/api/checkout/quote', {
    method: 'POST',
    body: JSON.stringify({
      fulfilmentMethod: 'delivery',
      locationId: 'LOC-DC-EAST',
      destinationState: 'NJ',
    }),
  });
  assert.equal(quoteRes.status, 200);
  const { quote } = await quoteRes.json();
  assert.equal(quote.eligible, true);
  assert.equal(quote.merchandiseSubtotalCents, 9000);
  assert.equal(quote.deliveryFeeCents, 1495);
  assert.equal(quote.taxCents, 597);
  assert.equal(quote.totalCents, 11092);

  // 5. Lock stock reservation via checkout attempt
  const attemptRes = await req(guestJar, '/api/checkout/attempt', {
    method: 'POST',
    body: JSON.stringify({
      idempotencyKey: 'e2e-idem-1',
      fulfilmentMethod: 'delivery',
      locationId: 'LOC-DC-EAST',
      contact: {
        name: 'Jordan Taylor',
        email: 'jordan@example.org',
        phone: '555-0148',
        poReference: '=CMD("test")',
      },
      shippingAddress: {
        line1: '120 Market St',
        city: 'Cherry Hill',
        state: 'NJ',
        postalCode: '08002',
      },
    }),
  });
  assert.ok([200, 201].includes(attemptRes.status), `Unexpected status ${attemptRes.status}`);
  const { attempt } = await attemptRes.json();
  assert.equal(attempt.totalCents, 11092);
  assert.ok(attempt.guestAccessToken);

  // 6. Simulate verified payment webhook settlement
  const payRes = await req(guestJar, '/api/payments/simulate', {
    method: 'POST',
    body: JSON.stringify({
      orderId: attempt.orderId,
      outcome: 'succeed',
      provider: 'local_simulator',
      guestAccessToken: attempt.guestAccessToken,
    }),
  });
  assert.equal(payRes.status, 200);
  const payData = await payRes.json();
  assert.equal(payData.orderStatus, 'confirmed');
  assert.equal(payData.paymentStatus, 'paid');

  // Verify cart cleared after payment
  const cartAfterRes = await req(guestJar, '/api/cart');
  const cartAfter = await cartAfterRes.json();
  assert.equal(cartAfter.cart.totalCases, 0);

  // Verify order access control (unauthenticated without token denied)
  const unauthOrderRes = await fetch(`${BASE}/api/orders/${attempt.orderId}`);
  assert.equal(unauthOrderRes.status, 404);

  // 7. Bootstrap admin & advance fulfilment to dispatched
  const adminJar = new CookieJar();
  const bootRes = await req(adminJar, '/api/auth/bootstrap-admin', {
    method: 'POST',
    body: JSON.stringify({
      name: 'Ops Admin',
      email: 'ops@storefront.local',
      password: 'AdminPassword123!',
    }),
  });
  assert.ok([200, 201].includes(bootRes.status), `Unexpected bootstrap status ${bootRes.status}`);

  for (const nextStatus of ['picking', 'packed', 'dispatched']) {
    const trRes = await req(adminJar, `/api/admin/orders/${attempt.orderId}/transition`, {
      method: 'POST',
      body: JSON.stringify({ nextStatus, note: `E2E ${nextStatus}` }),
    });
    assert.equal(trRes.status, 200);
  }

  // 8. Customer checks updated order status via scoped guest token
  const custOrderRes = await fetch(
    `${BASE}/api/orders/${attempt.orderId}?token=${encodeURIComponent(attempt.guestAccessToken)}`
  );
  assert.equal(custOrderRes.status, 200);
  const { order } = await custOrderRes.json();
  assert.equal(order.fulfilmentStatus, 'dispatched');
  assert.equal(order.transitions.length, 3);

  // 9. Bulk CSV validation & formula-safe export
  const csvValRes = await req(guestJar, '/api/bulk-order/validate', {
    method: 'POST',
    body: JSON.stringify({
      csvText: 'sku,cases\nDT-CLN-1001,2\nDT-KIT-2001,1',
    }),
  });
  assert.equal(csvValRes.status, 200);
  const csvValData = await csvValRes.json();
  assert.equal(csvValData.summary.totalCases, 3);
  assert.equal(csvValData.summary.totalMerchandiseCents, 9000);

  const exportRes = await req(guestJar, '/api/bulk-order/export', {
    method: 'POST',
    body: JSON.stringify({
      poReference: '=CMD()',
      companyName: '+ORG',
      lines: [
        {
          sku: 'DT-CLN-1001',
          title: 'Dish Soap, 16 fl oz',
          cases: 2,
          totalConsumerUnits: 48,
          casePriceCents: 3000,
          lineSubtotalCents: 6000,
        },
      ],
    }),
  });
  assert.equal(exportRes.status, 200);
  const csvOut = await exportRes.text();
  assert.ok(csvOut.includes("'=CMD()"));
  assert.ok(csvOut.includes("'+ORG"));

  console.log('E2E HTTP verification passed all 9 checks (including Section 16 workflow & SSR routes).');
} finally {
  if (server) {
    try {
      process.kill(-server.pid, 'SIGKILL');
    } catch {
      server.kill('SIGKILL');
    }
  }
  fs.rmSync(tmpDir, { recursive: true, force: true });
}
