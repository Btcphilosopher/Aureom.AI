import { register } from 'node:module';
import { pathToFileURL } from 'node:url';

const loaderCode = `
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

export async function resolve(specifier, context, nextResolve) {
  if (specifier === 'next/headers' || specifier === 'next/server') {
    return nextResolve(specifier + '.js', context);
  }
  if ((specifier.startsWith('./') || specifier.startsWith('../')) && !path.extname(specifier)) {
    const parentPath = context.parentURL ? fileURLToPath(context.parentURL) : process.cwd();
    const baseDir = path.dirname(parentPath);
    const tsCandidate = path.resolve(baseDir, specifier + '.ts');
    if (fs.existsSync(tsCandidate)) {
      return nextResolve(specifier + '.ts', context);
    }
    const indexTsCandidate = path.resolve(baseDir, specifier, 'index.ts');
    if (fs.existsSync(indexTsCandidate)) {
      return nextResolve(specifier + '/index.ts', context);
    }
  }
  return nextResolve(specifier, context);
}
`;

register('data:text/javascript;base64,' + Buffer.from(loaderCode).toString('base64'), pathToFileURL(process.cwd() + '/'));
