'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams, useSearchParams } from 'next/navigation';
import {
  CheckCircle2,
  Clock,
  Printer,
  RefreshCw,
  RotateCcw,
  Store,
  Truck,
  XCircle,
} from 'lucide-react';
import { StorefrontShell } from '@/components/StorefrontShell';
import { useStorefront } from '@/components/StorefrontProvider';
import { STORE_CONFIG } from '@/lib/config';
import { formatUsd } from '@/lib/pricing';
import type { OrderDetailView } from '@/lib/services/orders';

export default function OrderDetailPage() {
  const params = useParams<{ id: string }>();
  const searchParams = useSearchParams();
  const { refreshCart, setCartDrawerOpen, announce } = useStorefront();

  const orderId = params.id;
  const guestToken = searchParams.get('token');

  const [order, setOrder] = useState<OrderDetailView | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionMsg, setActionMsg] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState('');

  const loadOrder = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const qs = guestToken ? `?token=${encodeURIComponent(guestToken)}` : '';
      const res = await fetch(`/api/orders/${encodeURIComponent(orderId)}${qs}`, {
        cache: 'no-store',
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Unable to load order.');
        return;
      }
      setOrder(data.order);
    } finally {
      setLoading(false);
    }
  }, [orderId, guestToken]);

  useEffect(() => {
    let active = true;
    const qs = guestToken ? `?token=${encodeURIComponent(guestToken)}` : '';
    void fetch(`/api/orders/${encodeURIComponent(orderId)}${qs}`, {
      cache: 'no-store',
    })
      .then(async (res) => ({ ok: res.ok, data: await res.json() }))
      .then(({ ok, data }) => {
        if (!active) return;
        if (!ok) {
          setError(data.error || 'Unable to load order.');
        } else {
          setOrder(data.order);
          setError(null);
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [orderId, guestToken]);

  const handleReorder = async () => {
    setActionMsg(null);
    const res = await fetch(`/api/orders/${encodeURIComponent(orderId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({ action: 'reorder', guestToken }),
    });
    const data = await res.json();
    if (!res.ok) {
      setActionMsg(data.error || 'Reorder failed.');
      return;
    }
    await refreshCart();
    setCartDrawerOpen(true);
    const noticeText =
      data.notices && data.notices.length > 0
        ? `Items added at current prices. Note: ${data.notices.join(' ')}`
        : 'All available items added to cart using current prices.';
    setActionMsg(noticeText);
    announce(noticeText);
  };

  const handleCancelRequest = async () => {
    setActionMsg(null);
    const res = await fetch(`/api/orders/${encodeURIComponent(orderId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        action: 'cancel_request',
        reason: cancelReason || 'Customer requested cancellation before dispatch.',
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      setActionMsg(data.error || 'Cancellation request failed.');
      return;
    }
    setOrder(data.order);
    setActionMsg('Cancellation request recorded for Customer Service review.');
  };

  const steps =
    order?.fulfilmentMethod === 'pickup'
      ? ['unfulfilled', 'picking', 'ready_for_pickup', 'collected']
      : ['unfulfilled', 'picking', 'packed', 'dispatched', 'delivered'];

  const stepLabels: Record<string, string> = {
    unfulfilled: 'Confirmed',
    picking: 'Picking',
    packed: 'Packed',
    dispatched: 'Dispatched',
    delivered: 'Delivered',
    ready_for_pickup: 'Ready for pickup',
    collected: 'Collected',
  };

  return (
    <StorefrontShell>
      <div className="max-w-[1160px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        {loading ? (
          <div className="h-64 rounded-2xl border border-slate-200 bg-slate-50 animate-pulse" />
        ) : error || !order ? (
          <div className="rounded-2xl border border-red-200 bg-red-50 p-8 text-center space-y-3">
            <XCircle className="w-10 h-10 text-red-600 mx-auto" />
            <h1 className="text-xl font-bold text-slate-900">Order Unavailable</h1>
            <p className="text-sm text-red-800">{error || 'Order not found.'}</p>
            <Link href="/account" className="inline-block text-sm font-bold text-[#0F6B2E] underline">
              Sign in to view account orders
            </Link>
          </div>
        ) : (
          <>
            {/* Header & Receipt Actions */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
              <div>
                <p className="text-xs font-mono text-slate-500">
                  Placed {new Date(order.createdAt).toLocaleString()}
                </p>
                <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#0A4D1F]">
                  Order {order.id}
                </h1>
              </div>
              <div className="flex flex-wrap items-center gap-2.5 print:hidden">
                <button
                  type="button"
                  onClick={() => void loadOrder()}
                  className="h-9 px-3 rounded-lg border border-slate-300 text-xs font-bold text-slate-700 inline-flex items-center gap-1.5 hover:bg-slate-50"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh status</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="h-9 px-3 rounded-lg border border-slate-300 text-xs font-bold text-slate-700 inline-flex items-center gap-1.5 hover:bg-slate-50"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print receipt</span>
                </button>
                <button
                  type="button"
                  onClick={() => void handleReorder()}
                  className="h-9 px-4 rounded-lg bg-[#137A35] hover:bg-[#0F6B2E] text-white text-xs font-bold inline-flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reorder at current prices</span>
                </button>
              </div>
            </div>

            {actionMsg && (
              <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-[#0A4D1F]">
                {actionMsg}
              </div>
            )}

            {/* Separate Order, Payment, and Fulfilment States */}
            <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="rounded-2xl border border-slate-200 p-4 bg-white">
                <span className="text-xs text-slate-500 block">Order State</span>
                <strong className="text-base font-extrabold text-slate-900 capitalize mt-0.5 block">
                  {order.orderStatus.replace(/_/g, ' ')}
                </strong>
              </div>
              <div className="rounded-2xl border border-slate-200 p-4 bg-white">
                <span className="text-xs text-slate-500 block">Payment State</span>
                <strong className="text-base font-extrabold text-[#0F6B2E] capitalize mt-0.5 block">
                  {order.paymentStatus.replace(/_/g, ' ')}
                </strong>
              </div>
              <div className="rounded-2xl border border-slate-200 p-4 bg-white">
                <span className="text-xs text-slate-500 block">Fulfilment State</span>
                <strong className="text-base font-extrabold text-slate-900 capitalize mt-0.5 block">
                  {stepLabels[order.fulfilmentStatus] || order.fulfilmentStatus.replace(/_/g, ' ')}
                </strong>
              </div>
            </section>

            {/* Fulfilment Progress Stepper */}
            {order.fulfilmentStatus !== 'cancelled' && (
              <section className="rounded-2xl border border-slate-200 p-5 bg-slate-50 space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                    {order.fulfilmentMethod === 'pickup' ? (
                      <Store className="w-4 h-4 text-[#0F6B2E]" />
                    ) : (
                      <Truck className="w-4 h-4 text-[#0F6B2E]" />
                    )}
                    <span>
                      {order.fulfilmentMethod === 'pickup'
                        ? `Store Pickup at ${order.locationNameSnapshot}`
                        : `Regional Delivery from ${order.locationNameSnapshot}`}
                    </span>
                  </h2>
                  {order.poReference && (
                    <span className="text-xs font-mono font-bold text-slate-700">
                      PO: {order.poReference}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {steps.map((st, idx) => {
                    const currentIndex = steps.indexOf(order.fulfilmentStatus);
                    const reached = currentIndex >= idx;
                    return (
                      <div
                        key={st}
                        className={`p-3 rounded-xl border text-xs font-bold flex items-center gap-2 ${
                          reached
                            ? 'bg-[#E5FAAD] border-[#137A35]/40 text-[#0A4D1F]'
                            : 'bg-white border-slate-200 text-slate-400'
                        }`}
                      >
                        {reached ? (
                          <CheckCircle2 className="w-4 h-4 shrink-0 text-[#0F6B2E]" />
                        ) : (
                          <Clock className="w-4 h-4 shrink-0" />
                        )}
                        <span>{stepLabels[st]}</span>
                      </div>
                    );
                  })}
                </div>

                {order.fulfilmentMethod === 'pickup' && (
                  <p className="text-xs text-slate-700">
                    {order.fulfilmentStatus === 'ready_for_pickup'
                      ? 'Your cases are staged and ready for collection at the pickup desk. Bring your Order ID.'
                      : order.fulfilmentStatus === 'collected'
                        ? 'Order has been collected at store.'
                        : 'Pickup readiness notice: Please wait until status shows "Ready for pickup" before coming to the store.'}
                  </p>
                )}
              </section>
            )}

            {/* Immutable Order Line Snapshots & Totals */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-8 rounded-2xl border border-slate-200 bg-white overflow-hidden">
                <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <h2 className="text-sm font-extrabold text-slate-900">
                    Immutable Order Line Snapshots
                  </h2>
                  <span className="text-xs text-slate-500">
                    Prices & packaging locked at purchase
                  </span>
                </div>
                <div className="divide-y divide-slate-100">
                  {order.items.map((item) => (
                    <div key={item.id} className="p-4 sm:p-5 flex flex-wrap items-start justify-between gap-4">
                      <div className="space-y-1">
                        <p className="font-bold text-slate-900">{item.titleSnapshot}</p>
                        <p className="text-xs font-mono text-slate-500">
                          {item.sku} · {item.brandSnapshot}
                        </p>
                        <p className="text-xs text-slate-600 tabular-nums">
                          {item.casesOrdered} {item.casesOrdered === 1 ? 'case' : 'cases'} ×{' '}
                          {formatUsd(item.casePriceCentsSnapshot)} / case ·{' '}
                          {item.totalConsumerUnits} {item.consumerSellingUnitSnapshot}s total
                          {item.itemsPerConsumerPackSnapshot
                            ? ` (${item.totalConsumerUnits * item.itemsPerConsumerPackSnapshot} individual items)`
                            : ''}
                        </p>
                      </div>
                      <p className="text-base font-extrabold text-slate-900 tabular-nums">
                        {formatUsd(item.lineSubtotalCents)}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <aside className="lg:col-span-4 space-y-4">
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5 space-y-2.5 text-sm">
                  <h2 className="font-display text-base font-extrabold text-slate-900 pb-2 border-b border-slate-200">
                    Receipt Totals ({order.currency})
                  </h2>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Merchandise subtotal</span>
                    <strong className="tabular-nums">
                      {formatUsd(order.merchandiseSubtotalCents)}
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Discounts</span>
                    <strong className="tabular-nums">{formatUsd(order.discountCents)}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Delivery</span>
                    <strong className="tabular-nums">
                      {order.deliveryFeeCents === 0 ? 'Free' : formatUsd(order.deliveryFeeCents)}
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Tax</span>
                    <strong className="tabular-nums">{formatUsd(order.taxCents)}</strong>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-300 text-base">
                    <span className="font-extrabold text-slate-900">Final Total</span>
                    <strong className="font-extrabold text-[#0A4D1F] tabular-nums">
                      {formatUsd(order.totalCents)}
                    </strong>
                  </div>
                </div>

                {/* Refunds */}
                {order.refunds.length > 0 && (
                  <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 space-y-2 text-xs">
                    <h3 className="font-bold text-amber-950">Refund History</h3>
                    {order.refunds.map((r) => (
                      <div key={r.id} className="border-t border-amber-200/70 pt-2">
                        <p className="font-bold tabular-nums">
                          {formatUsd(r.amountCents)} ({r.isPartial ? 'Partial' : 'Full'} · {r.status})
                        </p>
                        <p className="text-amber-900">{r.reason}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Cancellation Request */}
                {!['dispatched', 'delivered', 'collected', 'cancelled'].includes(
                  order.fulfilmentStatus
                ) &&
                  !order.cancellationRequested && (
                    <div className="rounded-2xl border border-slate-200 p-4 space-y-2 print:hidden">
                      <h3 className="text-xs font-bold text-slate-900">Request Cancellation</h3>
                      <input
                        type="text"
                        value={cancelReason}
                        onChange={(e) => setCancelReason(e.target.value)}
                        placeholder="Optional reason..."
                        className="w-full h-9 px-3 rounded-lg border border-slate-300 text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => void handleCancelRequest()}
                        className="w-full h-9 rounded-lg border border-red-300 text-red-700 hover:bg-red-50 text-xs font-bold"
                      >
                        Request order cancellation
                      </button>
                    </div>
                  )}

                {order.cancellationRequested && (
                  <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-950">
                    Cancellation requested: {order.cancellationReason}
                  </div>
                )}
              </aside>
            </div>

            {/* Staff Transition Log & Demo Policies */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              <section className="rounded-2xl border border-slate-200 p-5 space-y-3 bg-white">
                <h2 className="text-sm font-extrabold text-slate-900">
                  Fulfilment Audit Trail
                </h2>
                {order.transitions.length === 0 ? (
                  <p className="text-xs text-slate-500">
                    No staff transitions recorded yet. Awaiting warehouse/store picking.
                  </p>
                ) : (
                  <ul className="space-y-2 text-xs">
                    {order.transitions.map((t) => (
                      <li key={t.id} className="border-b border-slate-100 pb-2">
                        <p className="font-bold text-slate-900">
                          {t.fromStatus} → {t.toStatus}
                        </p>
                        <p className="text-slate-600">
                          By {t.actorName} · {new Date(t.createdAt).toLocaleString()}
                        </p>
                        {t.note && <p className="text-slate-500 italic">{t.note}</p>}
                      </li>
                    ))}
                  </ul>
                )}
              </section>

              <section className="rounded-2xl border border-slate-200 p-5 space-y-2 bg-slate-50 text-xs text-slate-600">
                <h2 className="text-sm font-extrabold text-slate-900">
                  Demonstration Cancellation & Return Policies
                </h2>
                <p>{STORE_CONFIG.demoPolicies.cancellationWindowNote}</p>
                <p>{STORE_CONFIG.demoPolicies.returnPolicyNote}</p>
              </section>
            </div>
          </>
        )}
      </div>
    </StorefrontShell>
  );
}
