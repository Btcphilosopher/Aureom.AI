'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  CreditCard,
  Lock,
  ShieldCheck,
  Store,
  Truck,
} from 'lucide-react';
import { StorefrontShell } from '@/components/StorefrontShell';
import { useStorefront } from '@/components/StorefrontProvider';
import { formatUsd } from '@/lib/pricing';
import type { CheckoutQuote } from '@/lib/services/checkout';

export default function CheckoutPage() {
  const { cart, user, locations, refreshCart, announce } = useStorefront();

  const [nameOverride, setNameOverride] = useState<string | null>(null);
  const [emailOverride, setEmailOverride] = useState<string | null>(null);
  const [phone, setPhone] = useState('');
  const [poReference, setPoReference] = useState('');
  const [companyNameOverride, setCompanyNameOverride] = useState<string | null>(null);

  const [fulfilmentMethodOverride, setFulfilmentMethodOverride] = useState<
    'delivery' | 'pickup' | null
  >(null);
  const [locationIdOverride, setLocationIdOverride] = useState<string | null>(null);

  const name = nameOverride ?? user?.name ?? '';
  const email = emailOverride ?? user?.email ?? '';
  const companyName = companyNameOverride ?? user?.companyName ?? '';
  const fulfilmentMethod = fulfilmentMethodOverride ?? cart?.fulfilmentMethod ?? 'delivery';
  const locationId = locationIdOverride ?? cart?.locationId ?? 'LOC-DC-EAST';

  const setName = (v: string) => setNameOverride(v);
  const setEmail = (v: string) => setEmailOverride(v);
  const setCompanyName = (v: string) => setCompanyNameOverride(v);
  const setFulfilmentMethod = (v: 'delivery' | 'pickup') => setFulfilmentMethodOverride(v);
  const setLocationId = (v: string) => setLocationIdOverride(v);

  const [line1, setLine1] = useState('120 Market Street');
  const [line2, setLine2] = useState('');
  const [city, setCity] = useState('Cherry Hill');
  const [stateCode, setStateCode] = useState('NJ');
  const [postalCode, setPostalCode] = useState('08002');

  const [quote, setQuote] = useState<CheckoutQuote | null>(null);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [loadingQuote, setLoadingQuote] = useState(false);

  const [idempotencyKey] = useState(() =>
    typeof crypto !== 'undefined' && crypto.randomUUID
      ? `chk-${crypto.randomUUID()}`
      : `chk-${Date.now()}-${Math.random().toString(36).slice(2)}`
  );

  const [attempt, setAttempt] = useState<{
    orderId: string;
    totalCents: number;
    guestAccessToken: string | null;
    reservationExpiresAt: string | null;
  } | null>(null);
  const [attemptError, setAttemptError] = useState<string | null>(null);
  const [submittingAttempt, setSubmittingAttempt] = useState(false);

  const [paymentProvider, setPaymentProvider] = useState<'local_simulator' | 'stripe_sandbox'>(
    'local_simulator'
  );
  const [paying, setPaying] = useState(false);
  const [paymentResult, setPaymentResult] = useState<{
    orderStatus: string;
    paymentStatus: string;
    reconciledAction: string;
  } | null>(null);

  const fetchServerQuote = async (
    nextMethod = fulfilmentMethod,
    nextLoc = locationId,
    nextState = stateCode
  ) => {
    setLoadingQuote(true);
    setQuoteError(null);
    try {
      const res = await fetch('/api/checkout/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
        body: JSON.stringify({
          fulfilmentMethod: nextMethod,
          locationId: nextLoc,
          destinationState: nextState,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setQuoteError(data.error || 'Unable to calculate quote.');
        return;
      }
      setQuote(data.quote);
    } finally {
      setLoadingQuote(false);
    }
  };

  useEffect(() => {
    if (!cart || cart.activeLines.length === 0) return;
    let active = true;
    void fetch('/api/checkout/quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        fulfilmentMethod: cart.fulfilmentMethod,
        locationId: cart.locationId,
        destinationState: stateCode,
      }),
    })
      .then(async (res) => ({ ok: res.ok, data: await res.json() }))
      .then(({ ok, data }) => {
        if (!active) return;
        if (!ok) {
          setQuoteError(data.error || 'Unable to calculate quote.');
        } else {
          setQuote(data.quote);
          setQuoteError(null);
        }
      });
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cart?.cartId, cart?.totalCases]);

  const handleLockReservationAndReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setAttemptError(null);
    setSubmittingAttempt(true);
    try {
      const res = await fetch('/api/checkout/attempt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
        body: JSON.stringify({
          idempotencyKey,
          fulfilmentMethod,
          locationId,
          contact: {
            name,
            email,
            phone,
            poReference,
            companyName,
          },
          shippingAddress:
            fulfilmentMethod === 'delivery'
              ? { line1, line2, city, state: stateCode, postalCode }
              : undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAttemptError(data.error || 'Could not reserve stock for checkout.');
        return;
      }
      setAttempt(data.attempt);
      announce(`Stock reserved for order ${data.attempt.orderId}. Proceed to payment.`);
    } finally {
      setSubmittingAttempt(false);
    }
  };

  const handleSimulatePayment = async (outcome: 'succeed' | 'fail') => {
    if (!attempt) return;
    setPaying(true);
    setAttemptError(null);
    try {
      const res = await fetch('/api/payments/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
        body: JSON.stringify({
          orderId: attempt.orderId,
          outcome,
          provider: paymentProvider,
          guestAccessToken: attempt.guestAccessToken || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAttemptError(data.error || 'Payment webhook processing failed.');
        return;
      }
      setPaymentResult({
        orderStatus: data.orderStatus,
        paymentStatus: data.paymentStatus,
        reconciledAction: data.reconciledAction,
      });
      await refreshCart();
      announce(
        outcome === 'succeed'
          ? `Order ${attempt.orderId} confirmed.`
          : `Payment failed; stock reservation released.`
      );
    } finally {
      setPaying(false);
    }
  };

  const receiptHref = attempt
    ? attempt.guestAccessToken
      ? `/orders/${attempt.orderId}?token=${encodeURIComponent(attempt.guestAccessToken)}`
      : `/orders/${attempt.orderId}`
    : '/';

  return (
    <StorefrontShell>
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        <div className="border-b border-slate-200 pb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-3xl font-extrabold text-[#0A4D1F]">
              Bulk Checkout
            </h1>
            <p className="text-sm text-slate-600">
              All totals, delivery charges, and demonstration taxes are calculated on the server.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold text-[#0F6B2E]">
            <Lock className="w-4 h-4" />
            <span>Idempotent reservation · No raw card data stored</span>
          </div>
        </div>

        {paymentResult && attempt ? (
          <section
            aria-label="Order confirmation"
            className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 max-w-2xl mx-auto space-y-5 text-center"
          >
            {paymentResult.paymentStatus === 'paid' ? (
              <CheckCircle2 className="w-14 h-14 text-[#137A35] mx-auto" />
            ) : (
              <AlertCircle className="w-14 h-14 text-amber-600 mx-auto" />
            )}

            <div>
              <p className="text-xs font-mono text-slate-500">Order ID: {attempt.orderId}</p>
              <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
                {paymentResult.paymentStatus === 'paid'
                  ? 'Order Confirmed'
                  : paymentResult.orderStatus === 'reconciliation_required'
                    ? 'Payment Received After Expiry — Auto-Refunded'
                    : 'Payment Failed — Reservation Released'}
              </h2>
              <p className="text-sm text-slate-600 mt-2">
                Order status: <strong>{paymentResult.orderStatus}</strong> · Payment status:{' '}
                <strong>{paymentResult.paymentStatus}</strong>
              </p>
            </div>

            {fulfilmentMethod === 'pickup' && paymentResult.paymentStatus === 'paid' && (
              <div className="rounded-xl bg-amber-50 border border-amber-200 p-4 text-xs text-amber-950 text-left">
                <strong>Store Pickup Notice:</strong> Your payment is confirmed, and your order is now queued for store picking. A paid order is not automatically ready for collection — check your order status page for the &ldquo;Ready for pickup&rdquo; confirmation before visiting the store.
              </div>
            )}

            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <Link
                href={receiptHref}
                className="h-11 px-6 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-sm flex items-center"
              >
                View Order Details & Receipt
              </Link>
              <Link
                href="/"
                className="h-11 px-6 rounded-xl border border-slate-300 text-slate-800 font-bold text-sm flex items-center"
              >
                Return to storefront
              </Link>
            </div>
          </section>
        ) : !cart || (cart.activeLines.length === 0 && !attempt) ? (
          <div className="rounded-2xl border border-slate-200 p-10 text-center space-y-3">
            <p className="text-lg font-bold text-slate-900">Your cart is empty</p>
            <Link
              href="/search"
              className="inline-block px-5 py-2.5 rounded-xl bg-[#137A35] text-white text-sm font-bold"
            >
              Browse bulk essentials
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Checkout Steps */}
            <div className="lg:col-span-7 space-y-6">
              {!attempt ? (
                <form onSubmit={(e) => void handleLockReservationAndReview(e)} className="space-y-6">
                  {/* Step 1: Contact Details */}
                  <section className="rounded-2xl border border-slate-200 p-5 space-y-4 bg-white">
                    <h2 className="font-display text-lg font-extrabold text-slate-900">
                      1. Contact & Business Details
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label htmlFor="chk-name" className="block text-xs font-bold text-slate-700 mb-1">
                          Full Name *
                        </label>
                        <input
                          id="chk-name"
                          required
                          type="text"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Jordan Taylor"
                          className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                        />
                      </div>
                      <div>
                        <label htmlFor="chk-email" className="block text-xs font-bold text-slate-700 mb-1">
                          Email for receipt *
                        </label>
                        <input
                          id="chk-email"
                          required
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="buyer@example.org"
                          className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                        />
                      </div>
                      <div>
                        <label htmlFor="chk-phone" className="block text-xs font-bold text-slate-700 mb-1">
                          Phone Number *
                        </label>
                        <input
                          id="chk-phone"
                          required
                          type="tel"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="(856) 555-0148"
                          className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                        />
                      </div>
                      <div>
                        <label htmlFor="chk-po" className="block text-xs font-bold text-slate-700 mb-1">
                          PO Reference (optional)
                        </label>
                        <input
                          id="chk-po"
                          type="text"
                          value={poReference}
                          onChange={(e) => setPoReference(e.target.value)}
                          placeholder="PO-2026-101"
                          className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm font-mono"
                        />
                      </div>
                    </div>
                  </section>

                  {/* Step 2: Fulfilment Destination or Pickup Store */}
                  <section className="rounded-2xl border border-slate-200 p-5 space-y-4 bg-white">
                    <h2 className="font-display text-lg font-extrabold text-slate-900">
                      2. Delivery Destination or Pickup Store
                    </h2>

                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          const wh = locations.find((l) => l.type === 'warehouse');
                          const nextLoc = wh?.id || 'LOC-DC-EAST';
                          setFulfilmentMethod('delivery');
                          setLocationId(nextLoc);
                          void fetchServerQuote('delivery', nextLoc, stateCode);
                        }}
                        className={`h-11 rounded-xl border text-sm font-bold flex items-center justify-center gap-2 ${
                          fulfilmentMethod === 'delivery'
                            ? 'bg-[#0F6B2E] border-[#0F6B2E] text-white'
                            : 'bg-white border-slate-300 text-slate-800'
                        }`}
                      >
                        <Truck className="w-4 h-4" />
                        <span>Regional Delivery</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const st = locations.find((l) => l.type === 'store');
                          const nextLoc = st?.id || 'LOC-STR-104';
                          setFulfilmentMethod('pickup');
                          setLocationId(nextLoc);
                          void fetchServerQuote('pickup', nextLoc, st?.state || 'NJ');
                        }}
                        className={`h-11 rounded-xl border text-sm font-bold flex items-center justify-center gap-2 ${
                          fulfilmentMethod === 'pickup'
                            ? 'bg-[#0F6B2E] border-[#0F6B2E] text-white'
                            : 'bg-white border-slate-300 text-slate-800'
                        }`}
                      >
                        <Store className="w-4 h-4" />
                        <span>Store Pickup</span>
                      </button>
                    </div>

                    <div>
                      <label htmlFor="chk-loc" className="block text-xs font-bold text-slate-700 mb-1">
                        {fulfilmentMethod === 'delivery' ? 'Source Distribution Hub' : 'Pickup Store Location'}
                      </label>
                      <select
                        id="chk-loc"
                        value={locationId}
                        onChange={(e) => {
                          setLocationId(e.target.value);
                          void fetchServerQuote(fulfilmentMethod, e.target.value, stateCode);
                        }}
                        className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
                      >
                        {locations
                          .filter((l) =>
                            fulfilmentMethod === 'delivery' ? l.type === 'warehouse' : l.type === 'store'
                          )
                          .map((l) => (
                            <option key={l.id} value={l.id}>
                              {l.name} — {l.city}, {l.state} (
                              {l.type === 'warehouse'
                                ? `Delivers to: ${l.eligibleStates.join(', ')}`
                                : `Est. ${l.pickupLeadTimeHours}h prep`}
                              )
                            </option>
                          ))}
                      </select>
                    </div>

                    {fulfilmentMethod === 'delivery' && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                        <div className="sm:col-span-2">
                          <label htmlFor="addr-1" className="block text-xs font-bold text-slate-700 mb-1">
                            Street Address *
                          </label>
                          <input
                            id="addr-1"
                            required
                            type="text"
                            value={line1}
                            onChange={(e) => setLine1(e.target.value)}
                            className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                          />
                        </div>
                        <div>
                          <label htmlFor="addr-city" className="block text-xs font-bold text-slate-700 mb-1">
                            City *
                          </label>
                          <input
                            id="addr-city"
                            required
                            type="text"
                            value={city}
                            onChange={(e) => setCity(e.target.value)}
                            className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label htmlFor="addr-state" className="block text-xs font-bold text-slate-700 mb-1">
                              State *
                            </label>
                            <input
                              id="addr-state"
                              required
                              maxLength={2}
                              type="text"
                              value={stateCode}
                              onChange={(e) => {
                                const val = e.target.value.toUpperCase();
                                setStateCode(val);
                                if (val.length === 2) {
                                  void fetchServerQuote(fulfilmentMethod, locationId, val);
                                }
                              }}
                              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm uppercase font-mono"
                            />
                          </div>
                          <div>
                            <label htmlFor="addr-zip" className="block text-xs font-bold text-slate-700 mb-1">
                              ZIP *
                            </label>
                            <input
                              id="addr-zip"
                              required
                              type="text"
                              value={postalCode}
                              onChange={(e) => setPostalCode(e.target.value)}
                              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </section>

                  {/* Eligibility / Attempt Errors */}
                  {(quote && !quote.eligible) || quoteError || attemptError ? (
                    <div
                      role="alert"
                      className="rounded-xl border border-red-200 bg-red-50 p-4 text-xs text-red-900 space-y-1"
                    >
                      <p className="font-bold flex items-center gap-1.5">
                        <AlertCircle className="w-4 h-4 text-red-600" />
                        <span>Checkout validation notice</span>
                      </p>
                      {quote?.errors.map((err, i) => <p key={i}>{err}</p>)}
                      {quoteError && <p>{quoteError}</p>}
                      {attemptError && <p>{attemptError}</p>}
                    </div>
                  ) : null}

                  <button
                    type="submit"
                    disabled={submittingAttempt || (quote ? !quote.eligible : false)}
                    className="w-full h-12 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-base transition-colors disabled:opacity-50"
                  >
                    {submittingAttempt
                      ? 'Reserving inventory & creating order attempt...'
                      : '3. Reserve Stock & Proceed to Payment'}
                  </button>
                </form>
              ) : (
                /* Step 4 & 5: Reserved Order Attempt + Payment Simulation */
                <section className="rounded-2xl border border-slate-200 p-6 bg-white space-y-5">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-200">
                    <div>
                      <p className="text-xs font-mono text-slate-500">Order Attempt {attempt.orderId}</p>
                      <h2 className="font-display text-xl font-extrabold text-slate-900">
                        Complete Simulated Payment
                      </h2>
                    </div>
                    {attempt.reservationExpiresAt && (
                      <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0F6B2E] bg-[#E5FAAD] px-3 py-1.5 rounded-lg">
                        <Clock className="w-4 h-4" />
                        <span>
                          Stock reserved until{' '}
                          {new Date(attempt.reservationExpiresAt).toLocaleTimeString()}
                        </span>
                      </span>
                    )}
                  </div>

                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-700 block">
                      Payment Adapter Mode
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setPaymentProvider('local_simulator')}
                        className={`p-3 rounded-xl border text-left text-xs ${
                          paymentProvider === 'local_simulator'
                            ? 'border-[#0F6B2E] bg-emerald-50/50'
                            : 'border-slate-200'
                        }`}
                      >
                        <strong className="block text-sm text-slate-900">Local Payment Simulator</strong>
                        <span className="text-slate-600">
                          Dispatches a signed HMAC webhook directly to our payment processor.
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentProvider('stripe_sandbox')}
                        className={`p-3 rounded-xl border text-left text-xs ${
                          paymentProvider === 'stripe_sandbox'
                            ? 'border-[#0F6B2E] bg-emerald-50/50'
                            : 'border-slate-200'
                        }`}
                      >
                        <strong className="block text-sm text-slate-900">Stripe Sandbox Adapter</strong>
                        <span className="text-slate-600">
                          Simulates external provider webhook settlement without storing card PANs.
                        </span>
                      </button>
                    </div>
                  </div>

                  {attemptError && (
                    <div role="alert" className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-900">
                      {attemptError}
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                      type="button"
                      disabled={paying}
                      onClick={() => void handleSimulatePayment('succeed')}
                      className="flex-1 h-12 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-sm inline-flex items-center justify-center gap-2 disabled:opacity-60"
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>
                        {paying
                          ? 'Processing verified webhook...'
                          : `Pay ${formatUsd(attempt.totalCents)} (Simulate Success)`}
                      </span>
                    </button>
                    <button
                      type="button"
                      disabled={paying}
                      onClick={() => void handleSimulatePayment('fail')}
                      className="h-12 px-5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-sm"
                    >
                      Simulate Failure
                    </button>
                  </div>

                  <p className="text-xs text-slate-500 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-[#0F6B2E]" />
                    <span>
                      Order confirmation requires a verified server webhook; no raw card details are collected or persisted.
                    </span>
                  </p>
                </section>
              )}
            </div>

            {/* Right Server-Calculated Summary */}
            <aside className="lg:col-span-5 rounded-2xl border border-slate-200 bg-slate-50 p-5 space-y-4 lg:sticky lg:top-24">
              <h2 className="font-display text-lg font-extrabold text-slate-900">
                Server-Calculated Order Totals
              </h2>

              <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                {cart.activeLines.map((line) => (
                  <div key={line.id} className="flex items-start justify-between gap-2 text-xs">
                    <div>
                      <p className="font-bold text-slate-900">{line.title}</p>
                      <p className="text-slate-600 tabular-nums">
                        {line.casesQty} cases × {formatUsd(line.packaging.casePriceCents)} ·{' '}
                        {line.totalConsumerUnits} {line.packaging.consumerSellingUnit}s
                      </p>
                    </div>
                    <span className="font-bold text-slate-900 tabular-nums">
                      {formatUsd(line.lineSubtotalCents)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="border-t border-slate-200 pt-3 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">
                    Merchandise subtotal ({cart.totalCases} cases)
                  </span>
                  <strong className="tabular-nums">
                    {formatUsd(quote?.merchandiseSubtotalCents ?? cart.merchandiseSubtotalCents)}
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Discounts</span>
                  <strong className="tabular-nums">{formatUsd(quote?.discountCents ?? 0)}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">
                    {fulfilmentMethod === 'pickup' ? 'Store pickup fee' : 'Delivery fee'}
                  </span>
                  <strong className="tabular-nums">
                    {loadingQuote
                      ? '...'
                      : quote
                        ? quote.deliveryFeeCents === 0
                          ? 'Free'
                          : formatUsd(quote.deliveryFeeCents)
                        : '$0.00'}
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">
                    Estimated Tax ({quote ? `${(quote.taxRateBps / 100).toFixed(2)}%` : 'demo'})
                  </span>
                  <strong className="tabular-nums">
                    {loadingQuote ? '...' : formatUsd(quote?.taxCents ?? 0)}
                  </strong>
                </div>

                <div className="flex justify-between pt-3 border-t border-slate-300">
                  <span className="font-extrabold text-slate-900 text-base">Final Total</span>
                  <span className="font-extrabold text-2xl text-[#0A4D1F] tabular-nums">
                    {formatUsd(attempt?.totalCents ?? quote?.totalCents ?? cart.merchandiseSubtotalCents)}
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-slate-500 leading-relaxed">
                {quote?.taxEstimateNote ||
                  'Demonstration tax estimate calculated server-side; final tax varies by jurisdiction. Free delivery on orders $250.00+.'}
              </p>
            </aside>
          </div>
        )}
      </div>
    </StorefrontShell>
  );
}
