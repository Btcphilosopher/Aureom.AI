'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  Building2,
  ClipboardList,
  Download,
  FileCheck2,
  Info,
  Plus,
  ShoppingCart,
} from 'lucide-react';
import { StorefrontShell } from '@/components/StorefrontShell';
import { QuickBulkOrderPanel } from '@/components/QuickBulkOrderPanel';
import { useStorefront } from '@/components/StorefrontProvider';
import { STORE_CONFIG } from '@/lib/config';
import type { ProductCatalogItem } from '@/lib/services/catalogue';
import { formatUsd } from '@/lib/pricing';

interface BusinessList {
  id: string;
  name: string;
  listType: string;
  poReference: string;
  companyName: string;
  billingEmail: string;
  items: Array<{ sku: string; cases: number }>;
  createdAt: string;
}

export default function BusinessPage() {
  const { user, cart, addCasesToCart, setCartDrawerOpen, announce } = useStorefront();
  const [businessProducts, setBusinessProducts] = useState<ProductCatalogItem[]>([]);
  const [lists, setLists] = useState<BusinessList[]>([]);

  const [companyNameOverride, setCompanyNameOverride] = useState<string | null>(null);
  const [billingEmailOverride, setBillingEmailOverride] = useState<string | null>(null);
  const [poReference, setPoReference] = useState('');
  const [listName, setListName] = useState('');
  const [listType, setListType] = useState<'purchasing_list' | 'repeat_template'>('purchasing_list');
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const companyName = companyNameOverride ?? user?.companyName ?? '';
  const billingEmail = billingEmailOverride ?? user?.email ?? '';
  const setCompanyName = (v: string) => setCompanyNameOverride(v);
  const setBillingEmail = (v: string) => setBillingEmailOverride(v);

  useEffect(() => {
    let active = true;
    void fetch('/api/catalogue?chip=business')
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (active && data?.products) setBusinessProducts(data.products);
      });

    if (user) {
      void fetch('/api/account')
        .then((r) => (r.ok ? r.json() : null))
        .then((data) => {
          if (active && data?.businessLists) setLists(data.businessLists);
        });
    }
    return () => {
      active = false;
    };
  }, [user]);

  const handleSaveCartAsTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setSaveMessage('Please sign in under My account to save purchasing lists and repeat templates.');
      return;
    }
    if (!cart || cart.activeLines.length === 0) {
      setSaveMessage('Add at least one case to your cart before saving a template.');
      return;
    }
    const res = await fetch('/api/account', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        type: 'save_business_list',
        name: listName.trim() || `Bulk Template (${new Date().toLocaleDateString()})`,
        listType,
        poReference,
        companyName,
        billingEmail,
        items: cart.activeLines.map((l) => ({ sku: l.sku, cases: l.casesQty })),
      }),
    });
    if (res.ok) {
      setSaveMessage('Saved purchasing template to your account.');
      setListName('');
      const acc = await fetch('/api/account');
      if (acc.ok) {
        const d = await acc.json();
        setLists(d.businessLists || []);
      }
    }
  };

  const applyTemplateToCart = async (list: BusinessList) => {
    for (const item of list.items) {
      await addCasesToCart(item.sku, item.cases, item.sku);
    }
    announce(`Loaded template ${list.name} into cart.`);
    setCartDrawerOpen(true);
  };

  const downloadOrderSummary = async () => {
    const res = await fetch('/api/bulk-order/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        poReference,
        companyName,
      }),
    });
    if (!res.ok) return;
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `business-order-${poReference || 'summary'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <StorefrontShell activeCategory="business-supplies">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
        {/* Header */}
        <section className="rounded-2xl bg-gradient-to-r from-[#E6FB9E] via-[#DDF792] to-[#C8EE6E] border border-[#B5E057] p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <p className="text-xs font-extrabold text-[#0F6B2E] uppercase tracking-wider">
              Schools · Offices · Hospitality · Community Groups · Small Retailers
            </p>
            <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-[#0A4D1F]">
              Business & Institutional Bulk Purchasing
            </h1>
            <p className="text-sm sm:text-base text-[#115926] font-medium">
              Build full-case orders using quick SKU entry, CSV uploads, repeat-order templates, and PO references.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 shrink-0">
            <button
              type="button"
              onClick={() => void downloadOrderSummary()}
              className="h-11 px-5 rounded-xl bg-white border border-[#0F6B2E] text-[#0F6B2E] font-bold text-sm inline-flex items-center gap-2 hover:bg-emerald-50"
            >
              <Download className="w-4 h-4" />
              <span>Export cart summary CSV</span>
            </button>
            <Link
              href="/checkout"
              className="h-11 px-5 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-sm inline-flex items-center gap-2"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>Checkout ({cart?.totalCases ?? 0} cases)</span>
            </Link>
          </div>
        </section>

        {/* Prepaid Terms Clarification */}
        <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-xs text-slate-700 flex items-start gap-2.5">
          <Info className="w-4 h-4 text-[#0F6B2E] shrink-0 mt-0.5" />
          <span>{STORE_CONFIG.demoPolicies.businessPaymentTermsNote}</span>
        </div>

        {/* Company Billing & PO Reference + Saved Templates */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 space-y-6">
            <QuickBulkOrderPanel poReference={poReference} companyName={companyName} />
          </div>

          <aside className="lg:col-span-5 space-y-6">
            {/* Company Billing & Save Template */}
            <form
              onSubmit={(e) => void handleSaveCartAsTemplate(e)}
              className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4"
            >
              <h2 className="font-display text-lg font-extrabold text-slate-900 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-[#0F6B2E]" />
                <span>Company Billing & PO Details</span>
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="biz-company" className="block text-xs font-bold text-slate-700 mb-1">
                    Organization / School / Business
                  </label>
                  <input
                    id="biz-company"
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Oakridge Elementary PTA"
                    className="w-full h-9 px-3 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="biz-po" className="block text-xs font-bold text-slate-700 mb-1">
                    PO Reference (for receipts)
                  </label>
                  <input
                    id="biz-po"
                    type="text"
                    value={poReference}
                    onChange={(e) => setPoReference(e.target.value)}
                    placeholder="PO-2026-410"
                    className="w-full h-9 px-3 rounded-lg border border-slate-300 text-sm font-mono"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="biz-email" className="block text-xs font-bold text-slate-700 mb-1">
                  Accounts Payable / Billing Email
                </label>
                <input
                  id="biz-email"
                  type="email"
                  value={billingEmail}
                  onChange={(e) => setBillingEmail(e.target.value)}
                  placeholder="ap@organization.org"
                  className="w-full h-9 px-3 rounded-lg border border-slate-300 text-sm"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 space-y-3">
                <p className="text-xs font-bold text-slate-800">
                  Save current cart as a Purchasing List or Repeat-Order Template
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    aria-label="Template name"
                    value={listName}
                    onChange={(e) => setListName(e.target.value)}
                    placeholder="Monthly Janitorial Restock"
                    className="h-9 px-3 rounded-lg border border-slate-300 text-xs"
                  />
                  <select
                    aria-label="List type"
                    value={listType}
                    onChange={(e) =>
                      setListType(e.target.value as 'purchasing_list' | 'repeat_template')
                    }
                    className="h-9 px-2.5 rounded-lg border border-slate-300 text-xs bg-white"
                  >
                    <option value="purchasing_list">Saved Purchasing List</option>
                    <option value="repeat_template">Repeat-Order Template</option>
                  </select>
                </div>
                <button
                  type="submit"
                  className="w-full h-9 rounded-lg bg-[#0F6B2E] text-white text-xs font-bold hover:bg-[#0A4D1F]"
                >
                  Save Current Cart ({cart?.totalCases ?? 0} cases)
                </button>
                {saveMessage && <p className="text-xs font-semibold text-[#0F6B2E]">{saveMessage}</p>}
              </div>
            </form>

            {/* Saved Templates List */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
              <h2 className="font-display text-base font-extrabold text-slate-900 flex items-center gap-2">
                <ClipboardList className="w-4 h-4 text-[#0F6B2E]" />
                <span>Saved Lists & Repeat Templates</span>
              </h2>
              {!user ? (
                <p className="text-xs text-slate-600">
                  <Link href="/account" className="font-bold text-[#0F6B2E] underline">
                    Sign in
                  </Link>{' '}
                  to access saved purchasing lists and repeat templates.
                </p>
              ) : lists.length === 0 ? (
                <p className="text-xs text-slate-500">
                  No saved templates yet. Add cases to your cart and save one above.
                </p>
              ) : (
                <div className="space-y-2.5">
                  {lists.map((l) => (
                    <div
                      key={l.id}
                      className="p-3 rounded-xl border border-slate-200 flex items-center justify-between gap-3"
                    >
                      <div>
                        <p className="text-sm font-bold text-slate-900">{l.name}</p>
                        <p className="text-xs text-slate-500">
                          {l.listType === 'repeat_template' ? 'Repeat template' : 'Purchasing list'} ·{' '}
                          {l.items.length} SKUs {l.poReference ? `· PO ${l.poReference}` : ''}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => void applyTemplateToCart(l)}
                        className="px-3 py-1.5 rounded-lg bg-[#137A35] text-white text-xs font-bold whitespace-nowrap"
                      >
                        Load into cart
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </aside>
        </div>

        {/* Business Favourites Quick-Add Table */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-2xl font-extrabold text-[#0A4D1F] flex items-center gap-2">
              <FileCheck2 className="w-6 h-6 text-[#0F6B2E]" />
              <span>Business & Facility Bulk Catalogue</span>
            </h2>
            <Link href="/search?category=business-supplies" className="text-sm font-bold text-[#0F6B2E] hover:underline">
              Filter all business supplies →
            </Link>
          </div>

          <div className="rounded-2xl border border-slate-200 overflow-hidden bg-white">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                  <tr>
                    <th className="py-3 px-4">SKU</th>
                    <th className="py-3 px-4">Product</th>
                    <th className="py-3 px-4">Case Contents</th>
                    <th className="py-3 px-4 text-right">Unit Price</th>
                    <th className="py-3 px-4 text-right">Case Price</th>
                    <th className="py-3 px-4 text-right">Quick Add</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {businessProducts.map((p) => (
                    <tr key={p.sku} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-mono text-xs">{p.sku}</td>
                      <td className="py-3 px-4 font-bold text-slate-900">
                        <Link href={`/products/${p.sku}`} className="hover:text-[#0F6B2E]">
                          {p.title}
                        </Link>
                      </td>
                      <td className="py-3 px-4 text-slate-600">{p.packaging.caseContentsLabel}</td>
                      <td className="py-3 px-4 text-right font-semibold tabular-nums">
                        {p.packaging.unitPriceLabel}
                      </td>
                      <td className="py-3 px-4 text-right font-bold tabular-nums">
                        {formatUsd(p.packaging.casePriceCents)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => void addCasesToCart(p.sku, p.minCaseQuantity, p.title)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#137A35] hover:bg-[#0F6B2E] text-white text-xs font-bold whitespace-nowrap"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add {p.minCaseQuantity} case{p.minCaseQuantity > 1 ? 's' : ''}</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </StorefrontShell>
  );
}
