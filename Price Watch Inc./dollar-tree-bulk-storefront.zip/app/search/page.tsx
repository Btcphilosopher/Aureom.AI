import React, { Suspense } from 'react';
import { StorefrontShell } from '@/components/StorefrontShell';
import { SearchCatalogueView } from '@/components/SearchCatalogueView';
import { listProducts, type ProductSearchFilters } from '@/lib/services/catalogue';

export const dynamic = 'force-dynamic';

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const q = typeof sp.q === 'string' ? sp.q.slice(0, 100) : '';
  const category = typeof sp.category === 'string' ? sp.category : 'all';
  const under2 = sp.under2 === 'true';
  const maxCasePrice = typeof sp.maxCasePrice === 'string' ? Number(sp.maxCasePrice) : undefined;
  const minUnitsPerCase =
    typeof sp.minUnitsPerCase === 'string' ? Number(sp.minUnitsPerCase) : undefined;
  const fulfilmentMethod =
    sp.fulfilmentMethod === 'delivery' || sp.fulfilmentMethod === 'pickup'
      ? sp.fulfilmentMethod
      : '';
  const locationId = typeof sp.locationId === 'string' ? sp.locationId : undefined;
  const inStockOnly = sp.inStockOnly === 'true';
  const sort = (typeof sp.sort === 'string' ? sp.sort : 'relevance') as ProductSearchFilters['sort'];

  const initialProducts = listProducts({
    q,
    category,
    under2,
    maxCasePriceCents: Number.isFinite(maxCasePrice) ? Math.round(maxCasePrice! * 100) : undefined,
    minUnitsPerCase: Number.isFinite(minUnitsPerCase) ? minUnitsPerCase : undefined,
    fulfilmentMethod,
    locationId,
    inStockOnly,
    sort,
  });

  return (
    <StorefrontShell initialSearchQuery={q} activeCategory={category}>
      <Suspense fallback={<div className="p-10 text-center text-sm text-slate-500">Loading catalogue...</div>}>
        <SearchCatalogueView initialProducts={initialProducts} />
      </Suspense>
    </StorefrontShell>
  );
}
