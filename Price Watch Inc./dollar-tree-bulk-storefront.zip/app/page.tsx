import React from 'react';
import { StorefrontShell } from '@/components/StorefrontShell';
import { HomeShowcase } from '@/components/HomeShowcase';
import { listHomepageBanners, listProducts } from '@/lib/services/catalogue';
import { ensureBackgroundWorkerStarted } from '@/lib/services/worker';

export const dynamic = 'force-dynamic';

export default function HomePage() {
  ensureBackgroundWorkerStarted();
  const products = listProducts({ chip: 'all', sort: 'relevance' });
  const banners = listHomepageBanners();
  const announcementBanner = banners.find((b) => b.slot === 'announcement' && b.active !== 0);

  return (
    <StorefrontShell announcementOverride={announcementBanner?.headline}>
      <HomeShowcase initialProducts={products} banners={banners} />
    </StorefrontShell>
  );
}
