'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import {
  LogOut,
  MapPin,
  PackageCheck,
  Plus,
  Shield,
  Trash2,
  User as UserIcon,
} from 'lucide-react';
import { StorefrontShell } from '@/components/StorefrontShell';
import { useStorefront } from '@/components/StorefrontProvider';
import { formatUsd } from '@/lib/pricing';
import type { OrderDetailView } from '@/lib/services/orders';

interface SavedAddress {
  id: string;
  label: string;
  recipientName: string;
  line1: string;
  line2: string;
  city: string;
  state: string;
  postalCode: string;
  isDefault: boolean;
}

export default function AccountPage() {
  const { user, refreshSession, refreshCart, announce } = useStorefront();

  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [mergeNotices, setMergeNotices] = useState<string[]>([]);

  const [orders, setOrders] = useState<OrderDetailView[]>([]);
  const [addresses, setAddresses] = useState<SavedAddress[]>([]);
  const [loadingAccount, setLoadingAccount] = useState(false);

  const [addrLabel, setAddrLabel] = useState('Warehouse Dock');
  const [addrLine1, setAddrLine1] = useState('');
  const [addrCity, setAddrCity] = useState('');
  const [addrState, setAddrState] = useState('NJ');
  const [addrZip, setAddrZip] = useState('');

  const loadAccountData = useCallback(async () => {
    if (!user) return;
    setLoadingAccount(true);
    try {
      const res = await fetch('/api/account', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        setOrders(data.orders || []);
        setAddresses(data.addresses || []);
      }
    } finally {
      setLoadingAccount(false);
    }
  }, [user]);

  useEffect(() => {
    if (!user) return;
    let active = true;
    void fetch('/api/account', { cache: 'no-store' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!active || !data) return;
        setOrders(data.orders || []);
        setAddresses(data.addresses || []);
      })
      .finally(() => {
        if (active) setLoadingAccount(false);
      });
    return () => {
      active = false;
    };
  }, [user]);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setMergeNotices([]);

    const endpoint = authTab === 'login' ? '/api/auth/login' : '/api/auth/register';
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify(
        authTab === 'login'
          ? { email, password }
          : { email, password, name, companyName }
      ),
    });
    const data = await res.json();
    if (!res.ok) {
      setAuthError(data.error || 'Authentication failed.');
      return;
    }

    if (data.mergeNotices && data.mergeNotices.length > 0) {
      setMergeNotices(data.mergeNotices);
    }
    await refreshSession();
    await refreshCart();
    announce('Signed in successfully.');
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: { 'X-Requested-With': 'fetch' },
    });
    await refreshSession();
    await refreshCart();
    setOrders([]);
    setAddresses([]);
  };

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/account', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        type: 'save_address',
        label: addrLabel,
        line1: addrLine1,
        city: addrCity,
        state: addrState,
        postalCode: addrZip,
        isDefault: true,
      }),
    });
    if (res.ok) {
      setAddrLine1('');
      setAddrCity('');
      setAddrZip('');
      await loadAccountData();
    }
  };

  const handleDeleteAddress = async (id: string) => {
    await fetch('/api/account', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({ type: 'delete_address', id }),
    });
    await loadAccountData();
  };

  return (
    <StorefrontShell>
      <div className="max-w-[1240px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-5">
          <div>
            <h1 className="font-display text-3xl font-extrabold text-[#0A4D1F]">
              {user ? `Welcome, ${user.name}` : 'Customer Account'}
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              {user
                ? `${user.email} · Role: ${user.role.replace(/_/g, ' ')}`
                : 'Sign in or register to persist carts across devices, save delivery addresses, and track bulk orders.'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Link
              href="/admin"
              className="h-9 px-4 rounded-lg border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5"
            >
              <Shield className="w-4 h-4 text-[#0F6B2E]" />
              <span>Staff Administration</span>
            </Link>
            {user && (
              <button
                type="button"
                onClick={() => void handleLogout()}
                className="h-9 px-4 rounded-lg border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign out</span>
              </button>
            )}
          </div>
        </div>

        {mergeNotices.length > 0 && (
          <div className="rounded-2xl border border-emerald-300 bg-emerald-50 p-4 text-xs text-[#0A4D1F] space-y-1">
            <p className="font-bold">Guest cart merged with your account:</p>
            <ul className="list-disc pl-5 space-y-0.5">
              {mergeNotices.map((m, i) => (
                <li key={i}>{m}</li>
              ))}
            </ul>
          </div>
        )}

        {!user ? (
          <div className="max-w-md mx-auto rounded-2xl border border-slate-200 p-6 bg-white space-y-5">
            <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => {
                  setAuthTab('login');
                  setAuthError(null);
                }}
                className={`h-9 rounded-lg text-xs font-bold ${
                  authTab === 'login' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthTab('register');
                  setAuthError(null);
                }}
                className={`h-9 rounded-lg text-xs font-bold ${
                  authTab === 'register' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Create Account
              </button>
            </div>

            <form onSubmit={(e) => void handleAuthSubmit(e)} className="space-y-4">
              {authTab === 'register' && (
                <>
                  <div>
                    <label htmlFor="acc-name" className="block text-xs font-bold text-slate-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      id="acc-name"
                      required
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                    />
                  </div>
                  <div>
                    <label htmlFor="acc-co" className="block text-xs font-bold text-slate-700 mb-1">
                      Organization / Business (optional)
                    </label>
                    <input
                      id="acc-co"
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                    />
                  </div>
                </>
              )}

              <div>
                <label htmlFor="acc-email" className="block text-xs font-bold text-slate-700 mb-1">
                  Email *
                </label>
                <input
                  id="acc-email"
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                />
              </div>

              <div>
                <label htmlFor="acc-pw" className="block text-xs font-bold text-slate-700 mb-1">
                  Password (min 8 characters) *
                </label>
                <input
                  id="acc-pw"
                  required
                  minLength={8}
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                />
              </div>

              {authError && (
                <p role="alert" className="text-xs font-bold text-red-600">
                  {authError}
                </p>
              )}

              <button
                type="submit"
                className="w-full h-11 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-sm flex items-center justify-center gap-2"
              >
                <UserIcon className="w-4 h-4" />
                <span>{authTab === 'login' ? 'Sign In & Merge Cart' : 'Create Account'}</span>
              </button>
            </form>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Order History */}
            <section className="lg:col-span-7 space-y-4">
              <h2 className="font-display text-xl font-extrabold text-slate-900 flex items-center gap-2">
                <PackageCheck className="w-5 h-5 text-[#0F6B2E]" />
                <span>Order History</span>
              </h2>
              {loadingAccount ? (
                <div className="h-32 rounded-2xl border border-slate-200 bg-slate-50 animate-pulse" />
              ) : orders.length === 0 ? (
                <div className="rounded-2xl border border-slate-200 p-8 text-center space-y-2">
                  <p className="text-sm font-bold text-slate-800">No orders placed yet</p>
                  <Link href="/search" className="text-xs font-bold text-[#0F6B2E] underline">
                    Start shopping bulk cases
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {orders.map((o) => (
                    <div
                      key={o.id}
                      className="rounded-2xl border border-slate-200 p-4 bg-white flex flex-wrap items-center justify-between gap-4"
                    >
                      <div>
                        <Link
                          href={`/orders/${o.id}`}
                          className="font-mono text-sm font-bold text-[#0F6B2E] hover:underline"
                        >
                          {o.id}
                        </Link>
                        <p className="text-xs text-slate-600 mt-0.5">
                          {new Date(o.createdAt).toLocaleDateString()} · {o.items.length} SKU lines ·{' '}
                          <span className="capitalize">{o.fulfilmentMethod}</span>
                        </p>
                        <p className="text-xs text-slate-700 mt-1">
                          Order: <strong>{o.orderStatus}</strong> · Payment:{' '}
                          <strong>{o.paymentStatus}</strong> · Fulfilment:{' '}
                          <strong>{o.fulfilmentStatus.replace(/_/g, ' ')}</strong>
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-base font-extrabold text-slate-900 tabular-nums">
                          {formatUsd(o.totalCents)}
                        </p>
                        <Link
                          href={`/orders/${o.id}`}
                          className="text-xs font-bold text-[#0F6B2E] hover:underline"
                        >
                          View receipt →
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* Saved Addresses */}
            <aside className="lg:col-span-5 space-y-5">
              <div className="rounded-2xl border border-slate-200 p-5 bg-white space-y-4">
                <h2 className="font-display text-lg font-extrabold text-slate-900 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-[#0F6B2E]" />
                  <span>Saved Delivery Addresses</span>
                </h2>

                {addresses.length === 0 ? (
                  <p className="text-xs text-slate-500">No saved addresses yet.</p>
                ) : (
                  <div className="space-y-2.5">
                    {addresses.map((a) => (
                      <div
                        key={a.id}
                        className="p-3 rounded-xl border border-slate-200 flex items-start justify-between gap-3 text-xs"
                      >
                        <div>
                          <p className="font-bold text-slate-900">{a.label}</p>
                          <p className="text-slate-600">
                            {a.line1}, {a.city}, {a.state} {a.postalCode}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => void handleDeleteAddress(a.id)}
                          aria-label={`Delete ${a.label}`}
                          className="text-slate-400 hover:text-red-600 p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <form
                  onSubmit={(e) => void handleSaveAddress(e)}
                  className="pt-3 border-t border-slate-100 space-y-2.5"
                >
                  <p className="text-xs font-bold text-slate-800">Add new delivery address</p>
                  <input
                    type="text"
                    required
                    value={addrLabel}
                    onChange={(e) => setAddrLabel(e.target.value)}
                    placeholder="Label (e.g. Main Office)"
                    className="w-full h-9 px-3 rounded-lg border border-slate-300 text-xs"
                  />
                  <input
                    type="text"
                    required
                    value={addrLine1}
                    onChange={(e) => setAddrLine1(e.target.value)}
                    placeholder="Street address"
                    className="w-full h-9 px-3 rounded-lg border border-slate-300 text-xs"
                  />
                  <div className="grid grid-cols-3 gap-2">
                    <input
                      type="text"
                      required
                      value={addrCity}
                      onChange={(e) => setAddrCity(e.target.value)}
                      placeholder="City"
                      className="h-9 px-3 rounded-lg border border-slate-300 text-xs"
                    />
                    <input
                      type="text"
                      required
                      maxLength={2}
                      value={addrState}
                      onChange={(e) => setAddrState(e.target.value.toUpperCase())}
                      placeholder="State"
                      className="h-9 px-3 rounded-lg border border-slate-300 text-xs uppercase font-mono"
                    />
                    <input
                      type="text"
                      required
                      value={addrZip}
                      onChange={(e) => setAddrZip(e.target.value)}
                      placeholder="ZIP"
                      className="h-9 px-3 rounded-lg border border-slate-300 text-xs font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full h-9 rounded-lg bg-[#137A35] text-white text-xs font-bold inline-flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Save Address</span>
                  </button>
                </form>
              </div>
            </aside>
          </div>
        )}
      </div>
    </StorefrontShell>
  );
}
