import type { Metadata } from 'next';
import { Plus_Jakarta_Sans, DM_Sans, JetBrains_Mono } from 'next/font/google';
import './globals.css';
import { StorefrontProvider } from '@/components/StorefrontProvider';

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['600', '700', '800'],
  variable: '--font-plus-jakarta',
  display: 'swap',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '700'],
  variable: '--font-dm-sans',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-jetbrains-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Dollar Tree Bulk Storefront | Everyday Essentials by the Case',
  description:
    'Independent bulk-shopping storefront concept with clear case pricing, upfront unit prices, live inventory reservations, business ordering, and fulfilment management.',
  openGraph: {
    title: 'Dollar Tree Bulk Storefront | Everyday Essentials by the Case',
    description:
      'Small prices. Big possibilities. Everyday essentials, ready by the case.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Dollar Tree Bulk Storefront',
    description: 'Everyday essentials, ready by the case.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${plusJakarta.variable} ${dmSans.variable} ${jetbrainsMono.variable}`}
    >
      <body suppressHydrationWarning className="min-h-screen bg-white text-slate-900">
        <StorefrontProvider>{children}</StorefrontProvider>
      </body>
    </html>
  );
}
