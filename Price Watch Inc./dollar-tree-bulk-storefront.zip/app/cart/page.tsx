'use client';

import React from 'react';
import Link from 'next/link';
import {
  ArrowRight,
  Bookmark,
  Minus,
  Plus,
  ShoppingCart,
  Trash2,
  Truck,
  Store,
  AlertTriangle,
  FileSpreadsheet,
} from 'lucide-react';
import { StorefrontShell } from '@/components/StorefrontShell';
import { useStorefront } from '@/components/StorefrontProvider';
import { formatUsd } from '@/lib/pricing';

export default function CartPage() {
  const {
    cart,
    locations,
    loadingCart,
    updateCartCases,
    toggleSaveForLater,
    acceptCartPriceChanges,
    setCartFulfilment,
  } = useStorefront();

  const hasPriceChanges = Boolean(cart?.activeLines.some((l) => l.priceChanged));

  return (
    <StorefrontShell>
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-5">
          <div>
            <h1 className="font-display text-3xl font-extrabold text-[#0A4D1F]">
              Bulk Shopping Cart
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Review case quantities, total consumer units, and your selected fulfilment location before reserving inventory at checkout.
            </p>
          </div>
          <Link
            href="/quick-order"
            className="inline-flex items-center gap-2 text-sm font-bold text-[#0F6B2E] hover:underline"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Add SKUs via Quick Bulk Order / CSV</span>
          </Link>
        </div>

        {/* Notices / Revalidation Banner */}
        {cart && cart.notices.length > 0 && (
          <div
            role="alert"
            className="rounded-2xl border border-amber-300 bg-amber-50 p-4 space-y-2 text-sm text-amber-950"
          >
            <div className="flex items-center justify-between gap-3">
              <p className="font-bold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-700" />
                <span>Cart revalidation notice</span>
              </p>
              {hasPriceChanges && (
                <button
                  type="button"
                  onClick={() => void acceptCartPriceChanges()}
                  className="px-3 py-1 rounded-lg bg-amber-900 text-white text-xs font-bold"
                >
                  Acknowledge updated prices
                </button>
              )}
            </div>
            <ul className="list-disc pl-5 space-y-1 text-xs">
              {cart.notices.map((n, i) => (
                <li key={i}>{n}</li>
              ))}
            </ul>
          </div>
        )}

        {loadingCart ? (
          <div className="h-48 rounded-2xl border border-slate-200 bg-slate-50 animate-pulse" />
        ) : !cart || (cart.activeLines.length === 0 && cart.savedLines.length === 0) ? (
          <div className="rounded-2xl border border-slate-200 p-12 text-center space-y-4">
            <ShoppingCart className="w-12 h-12 text-slate-300 mx-auto" />
            <h2 className="text-xl font-bold text-slate-900">Your bulk cart is currently empty</h2>
            <p className="text-sm text-slate-600 max-w-md mx-auto">
              Browse everyday essentials by the case or upload a CSV purchase list to populate your cart.
            </p>
            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <Link
                href="/search"
                className="px-5 py-2.5 rounded-xl bg-[#137A35] text-white text-sm font-bold"
              >
                Browse bulk catalogue
              </Link>
              <Link
                href="/quick-order"
                className="px-5 py-2.5 rounded-xl border border-slate-300 text-slate-800 text-sm font-bold"
              >
                Quick Bulk Order
              </Link>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Cart Lines */}
            <div className="lg:col-span-8 space-y-6">
              <div className="space-y-4">
                {cart.activeLines.map((line) => (
                  <div
                    key={line.id}
                    className="rounded-2xl border border-slate-200 p-4 sm:p-5 bg-white flex flex-col sm:flex-row gap-4"
                  >
                    <Link href={`/products/${line.sku}`} className="shrink-0">
                      <img
                        src={line.image}
                        alt={line.title}
                        referrerPolicy="no-referrer"
                        className="w-24 h-24 object-contain rounded-xl border border-slate-100 bg-white"
                      />
                    </Link>

                    <div className="flex-1 min-w-0 space-y-2">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <Link
                            href={`/products/${line.sku}`}
                            className="font-display text-lg font-bold text-slate-900 hover:text-[#0F6B2E]"
                          >
                            {line.title}
                          </Link>
                          <p className="text-xs font-mono text-slate-500">
                            {line.sku}
                            {Object.values(line.variantAttributes).length > 0
                              ? ` · ${Object.values(line.variantAttributes).join(', ')}`
                              : ''}
                          </p>
                        </div>
                        <p className="text-lg font-extrabold text-slate-900 tabular-nums">
                          {formatUsd(line.lineSubtotalCents)}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-slate-50 rounded-xl p-3">
                        <div>
                          <span className="text-slate-500 block">Case price</span>
                          <strong className="text-slate-900 tabular-nums">
                            {formatUsd(line.packaging.casePriceCents)}
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 block">Contents / case</span>
                          <strong className="text-slate-900 tabular-nums">
                            {line.packaging.consumerUnitsPerCase} {line.packaging.consumerSellingUnit}s
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 block">Total units ordered</span>
                          <strong className="text-slate-900 tabular-nums">
                            {line.totalConsumerUnits} {line.packaging.consumerSellingUnit}s
                            {line.packaging.itemsPerConsumerPack
                              ? ` (${line.totalIndividualItems} items)`
                              : ''}
                          </strong>
                        </div>
                        <div>
                          <span className="text-slate-500 block">Fulfilment</span>
                          <strong className="text-[#0F6B2E] capitalize">
                            {cart.fulfilmentMethod} ({line.availableAtSelectedLocation} avail.)
                          </strong>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                        <div className="flex items-center gap-3">
                          <span className="text-xs font-bold text-slate-700">Cases:</span>
                          <div className="inline-flex items-center border border-slate-300 rounded-lg">
                            <button
                              type="button"
                              aria-label={`Decrease cases for ${line.title}`}
                              onClick={() =>
                                void updateCartCases(
                                  line.sku,
                                  Math.max(0, line.casesQty - line.caseIncrement)
                                )
                              }
                              className="w-8 h-8 flex items-center justify-center hover:bg-slate-100 rounded-l-lg"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-9 text-center text-sm font-bold tabular-nums">
                              {line.casesQty}
                            </span>
                            <button
                              type="button"
                              aria-label={`Increase cases for ${line.title}`}
                              onClick={() =>
                                void updateCartCases(
                                  line.sku,
                                  line.casesQty + line.caseIncrement
                                )
                              }
                              className="w-8 h-8 flex items-center justify-center hover:bg-slate-100 rounded-r-lg"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 text-xs font-bold">
                          <button
                            type="button"
                            onClick={() => void toggleSaveForLater(line.sku, true)}
                            className="text-slate-600 hover:text-[#0F6B2E] inline-flex items-center gap-1"
                          >
                            <Bookmark className="w-3.5 h-3.5" />
                            <span>Save for later</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => void updateCartCases(line.sku, 0)}
                            className="text-red-600 hover:underline inline-flex items-center gap-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Remove</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Saved for Later Section */}
              {cart.savedLines.length > 0 && (
                <div className="pt-6 border-t border-slate-200 space-y-3">
                  <h2 className="text-lg font-bold text-slate-900">
                    Saved for later ({cart.savedLines.length})
                  </h2>
                  <div className="space-y-3">
                    {cart.savedLines.map((line) => (
                      <div
                        key={line.id}
                        className="rounded-xl border border-slate-200 p-4 flex items-center justify-between gap-4 bg-slate-50"
                      >
                        <div>
                          <p className="text-sm font-bold text-slate-900">{line.title}</p>
                          <p className="text-xs text-slate-600">
                            {line.sku} · {line.casesQty} cases · {formatUsd(line.lineSubtotalCents)}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => void toggleSaveForLater(line.sku, false)}
                            className="px-3 py-1.5 rounded-lg bg-[#137A35] text-white text-xs font-bold"
                          >
                            Move to cart
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right Summary & Fulfilment Selector */}
            <aside className="lg:col-span-4 rounded-2xl border border-slate-200 bg-slate-50 p-5 space-y-5 lg:sticky lg:top-24">
              <h2 className="font-display text-lg font-extrabold text-slate-900">
                Fulfilment & Order Summary
              </h2>

              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-700 block">
                  Select fulfilment method & source location
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const wh = locations.find((l) => l.type === 'warehouse');
                      if (wh) {
                        void setCartFulfilment({
                          fulfilmentMethod: 'delivery',
                          locationId: wh.id,
                          destinationState: wh.state,
                          destinationZip: wh.zip,
                        });
                      }
                    }}
                    className={`h-10 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 ${
                      cart.fulfilmentMethod === 'delivery'
                        ? 'bg-[#0F6B2E] border-[#0F6B2E] text-white'
                        : 'bg-white border-slate-300 text-slate-700'
                    }`}
                  >
                    <Truck className="w-4 h-4" />
                    <span>Delivery</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const st = locations.find((l) => l.type === 'store');
                      if (st) {
                        void setCartFulfilment({
                          fulfilmentMethod: 'pickup',
                          locationId: st.id,
                          destinationState: st.state,
                          destinationZip: st.zip,
                        });
                      }
                    }}
                    className={`h-10 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 ${
                      cart.fulfilmentMethod === 'pickup'
                        ? 'bg-[#0F6B2E] border-[#0F6B2E] text-white'
                        : 'bg-white border-slate-300 text-slate-700'
                    }`}
                  >
                    <Store className="w-4 h-4" />
                    <span>Store Pickup</span>
                  </button>
                </div>

                <label htmlFor="cart-loc-select" className="sr-only">
                  Source location
                </label>
                <select
                  id="cart-loc-select"
                  value={cart.locationId}
                  onChange={(e) => {
                    const chosen = locations.find((l) => l.id === e.target.value);
                    if (chosen) {
                      void setCartFulfilment({
                        fulfilmentMethod: chosen.type === 'warehouse' ? 'delivery' : 'pickup',
                        locationId: chosen.id,
                        destinationState: chosen.state,
                        destinationZip: chosen.zip,
                      });
                    }
                  }}
                  className="w-full h-10 px-3 rounded-xl border border-slate-300 bg-white text-xs font-semibold"
                >
                  {locations
                    .filter((l) =>
                      cart.fulfilmentMethod === 'delivery' ? l.type === 'warehouse' : l.type === 'store'
                    )
                    .map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.name} ({l.city}, {l.state})
                      </option>
                    ))}
                </select>
              </div>

              <div className="space-y-2 pt-3 border-t border-slate-200 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">Total shipping cases</span>
                  <strong className="tabular-nums text-slate-900">{cart.totalCases} cases</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Total consumer units</span>
                  <strong className="tabular-nums text-slate-900">
                    {cart.totalConsumerUnits} units
                  </strong>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-200">
                  <span className="font-bold text-slate-900">Merchandise subtotal</span>
                  <span className="text-xl font-extrabold text-[#0A4D1F] tabular-nums">
                    {formatUsd(cart.merchandiseSubtotalCents)}
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  Delivery charges and estimated taxes are calculated server-side in checkout.
                </p>
              </div>

              <Link
                href="/checkout"
                className={`w-full h-12 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-colors ${
                  cart.activeLines.length === 0
                    ? 'bg-slate-200 text-slate-400 pointer-events-none'
                    : 'bg-[#137A35] hover:bg-[#0F6B2E] text-white shadow-sm'
                }`}
              >
                <span>Proceed to checkout</span>
                <ArrowRight className="w-5 h-5" />
              </Link>
            </aside>
          </div>
        )}
      </div>
    </StorefrontShell>
  );
}
