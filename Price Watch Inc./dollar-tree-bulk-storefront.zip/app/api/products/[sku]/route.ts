import { NextRequest, NextResponse } from 'next/server';
import { getProductDetail } from '@/lib/services/catalogue';
import { jsonError } from '@/lib/api-helpers';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ sku: string }> }
) {
  const { sku } = await context.params;
  const detail = getProductDetail(sku);
  if (!detail.product) {
    return jsonError(`Product "${sku}" not found.`, 404);
  }
  return NextResponse.json(detail);
}
