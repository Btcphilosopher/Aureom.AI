import { NextRequest, NextResponse } from 'next/server';
import { buildSafeCsv } from '@/lib/csv';
import { formatUsd } from '@/lib/pricing';
import { getAuthenticatedUser, verifyMutationOrigin } from '@/lib/auth';
import { getCartView, getOrCreateCart } from '@/lib/services/cart';
import { readGuestCartToken } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return NextResponse.json({ error: 'Invalid origin' }, { status: 403 });
  }

  let body: Record<string, unknown> = {};
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    body = {};
  }

  const poReference = String(body.poReference || '');
  const companyName = String(body.companyName || '');

  let rows: Array<Array<unknown>> = [];

  if (Array.isArray(body.lines) && body.lines.length > 0) {
    rows = body.lines.map((line) => {
      const l = line as Record<string, unknown>;
      return [
        poReference,
        companyName,
        String(l.sku || ''),
        String(l.title || ''),
        Number(l.cases || 0),
        Number(l.totalConsumerUnits || 0),
        formatUsd(Number(l.casePriceCents || 0)),
        formatUsd(Number(l.lineSubtotalCents || 0)),
      ];
    });
  } else {
    const user = await getAuthenticatedUser(req);
    const guestTokenIn = await readGuestCartToken(req);
    const { cartId } = getOrCreateCart({ userId: user?.id, guestToken: guestTokenIn });
    const cart = getCartView(cartId);
    rows = cart.activeLines.map((l) => [
      poReference,
      companyName,
      l.sku,
      l.title,
      l.casesQty,
      l.totalConsumerUnits,
      formatUsd(l.packaging.casePriceCents),
      formatUsd(l.lineSubtotalCents),
    ]);
  }

  const csv = buildSafeCsv(
    [
      'PO Reference',
      'Company',
      'SKU',
      'Product Title',
      'Cases',
      'Total Consumer Units',
      'Case Price (USD)',
      'Line Subtotal (USD)',
    ],
    rows
  );

  return new NextResponse(csv, {
    status: 200,
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="bulk-order-summary.csv"',
    },
  });
}
