import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { parseBulkOrderCsv } from '@/lib/csv';
import { computePackagingBreakdown, validateCaseQuantity } from '@/lib/pricing';
import { checkRateLimit, getClientKey } from '@/lib/rate-limit';
import { attachGuestCartCookie, jsonError, readGuestCartToken } from '@/lib/api-helpers';
import { getAuthenticatedUser, verifyMutationOrigin } from '@/lib/auth';
import { getCartView, getOrCreateCart, upsertCartItem } from '@/lib/services/cart';

export interface BulkOrderReviewItem {
  lineNumber: number;
  sku: string;
  cases: number;
  valid: boolean;
  errors: string[];
  title: string;
  casePriceCents: number;
  unitPriceLabel: string;
  caseContentsLabel: string;
  lineSubtotalCents: number;
  totalConsumerUnits: number;
  availableAtLocation: number;
  minCaseQuantity: number;
  caseIncrement: number;
}

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }
  const rl = checkRateLimit(getClientKey(req.headers, 'bulk_csv'), 30, 60_000);
  if (!rl.allowed) {
    return jsonError('Too many bulk validation requests. Please wait a minute.', 429);
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const locationId = String(body.locationId || 'LOC-DC-EAST');
  const commit = Boolean(body.commit);

  let parsedRows: Array<{ lineNumber: number; sku: string; cases: number }> = [];
  const parseErrors: string[] = [];

  if (typeof body.csvText === 'string' && body.csvText.trim().length > 0) {
    const parsed = parseBulkOrderCsv(body.csvText);
    parsedRows = parsed.rows;
    parseErrors.push(...parsed.errors);
  } else if (Array.isArray(body.items)) {
    if (body.items.length > 500) {
      return jsonError('Maximum 500 SKU lines per bulk submission.');
    }
    body.items.forEach((raw, idx) => {
      const entry = raw as Record<string, unknown>;
      const sku = String(entry.sku || '').trim().toUpperCase();
      const cases = Number(entry.cases);
      if (!sku) return;
      if (!Number.isInteger(cases) || cases <= 0) {
        parseErrors.push(`Line ${idx + 1} (${sku}): Cases must be a positive whole number.`);
        return;
      }
      parsedRows.push({ lineNumber: idx + 1, sku, cases });
    });
  } else {
    return jsonError('Provide either csvText or items array.');
  }

  // Deduplicate/aggregate duplicate SKUs in review
  const aggregated = new Map<string, { lineNumber: number; sku: string; cases: number }>();
  for (const r of parsedRows) {
    const prev = aggregated.get(r.sku);
    if (prev) {
      prev.cases += r.cases;
    } else {
      aggregated.set(r.sku, { ...r });
    }
  }

  const db = getDb();
  const reviewItems: BulkOrderReviewItem[] = [];

  for (const row of aggregated.values()) {
    const skuRow = db
      .prepare(
        `SELECT s.sku, s.title, s.consumer_selling_unit, s.items_per_consumer_pack,
                s.consumer_units_per_case, s.case_price_cents, s.min_case_quantity,
                s.case_increment, s.active,
                COALESCE(il.on_hand_cases - il.reserved_cases, 0) as available_cases
         FROM skus s
         LEFT JOIN inventory_levels il ON il.sku = s.sku AND il.location_id = ?
         WHERE s.sku = ?`
      )
      .get(locationId, row.sku) as
      | {
          sku: string;
          title: string;
          consumer_selling_unit: string;
          items_per_consumer_pack: number | null;
          consumer_units_per_case: number;
          case_price_cents: number;
          min_case_quantity: number;
          case_increment: number;
          active: number;
          available_cases: number;
        }
      | undefined;

    if (!skuRow) {
      reviewItems.push({
        lineNumber: row.lineNumber,
        sku: row.sku,
        cases: row.cases,
        valid: false,
        errors: [`SKU "${row.sku}" was not found in the catalogue.`],
        title: 'Unknown SKU',
        casePriceCents: 0,
        unitPriceLabel: '-',
        caseContentsLabel: '-',
        lineSubtotalCents: 0,
        totalConsumerUnits: 0,
        availableAtLocation: 0,
        minCaseQuantity: 1,
        caseIncrement: 1,
      });
      continue;
    }

    const errors: string[] = [];
    if (!skuRow.active) {
      errors.push('SKU is currently inactive.');
    }
    const qtyCheck = validateCaseQuantity(
      row.cases,
      skuRow.min_case_quantity,
      skuRow.case_increment
    );
    if (!qtyCheck.valid && qtyCheck.reason) {
      errors.push(qtyCheck.reason);
    }
    const available = Math.max(0, skuRow.available_cases);
    if (available < row.cases) {
      errors.push(`Only ${available} case(s) available at ${locationId}.`);
    }

    const pkg = computePackagingBreakdown({
      consumerSellingUnit: skuRow.consumer_selling_unit,
      itemsPerConsumerPack: skuRow.items_per_consumer_pack,
      consumerUnitsPerCase: skuRow.consumer_units_per_case,
      casePriceCents: skuRow.case_price_cents,
    });

    reviewItems.push({
      lineNumber: row.lineNumber,
      sku: row.sku,
      cases: row.cases,
      valid: errors.length === 0,
      errors,
      title: skuRow.title,
      casePriceCents: pkg.casePriceCents,
      unitPriceLabel: pkg.unitPriceLabel,
      caseContentsLabel: pkg.caseContentsLabel,
      lineSubtotalCents: row.cases * pkg.casePriceCents,
      totalConsumerUnits: row.cases * pkg.consumerUnitsPerCase,
      availableAtLocation: available,
      minCaseQuantity: skuRow.min_case_quantity,
      caseIncrement: skuRow.case_increment,
    });
  }

  const validItems = reviewItems.filter((i) => i.valid);
  const hasErrors = parseErrors.length > 0 || reviewItems.some((i) => !i.valid);

  if (commit) {
    if (validItems.length === 0) {
      return jsonError('No valid bulk order lines to add to cart.', 400);
    }
    const user = await getAuthenticatedUser(req);
    const guestTokenIn = await readGuestCartToken(req);
    const { cartId, guestToken } = getOrCreateCart({
      userId: user?.id,
      guestToken: guestTokenIn,
    });

    const appliedErrors: string[] = [];
    for (const item of validItems) {
      try {
        upsertCartItem({
          cartId,
          sku: item.sku,
          casesDeltaOrSet: item.cases,
          mode: 'add',
        });
      } catch (err) {
        appliedErrors.push(
          `${item.sku}: ${err instanceof Error ? err.message : 'Unable to add to cart'}`
        );
      }
    }

    const cart = getCartView(cartId);
    const res = NextResponse.json({
      committed: true,
      appliedErrors,
      cart,
      reviewItems,
      parseErrors,
    });
    if (!user && guestToken) {
      attachGuestCartCookie(res, guestToken);
    }
    return res;
  }

  return NextResponse.json({
    committed: false,
    hasErrors,
    parseErrors,
    reviewItems,
    summary: {
      totalValidLines: validItems.length,
      totalCases: validItems.reduce((s, i) => s + i.cases, 0),
      totalMerchandiseCents: validItems.reduce((s, i) => s + i.lineSubtotalCents, 0),
    },
  });
}
