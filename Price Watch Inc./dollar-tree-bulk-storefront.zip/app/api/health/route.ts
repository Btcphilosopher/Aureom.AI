import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { ensureBackgroundWorkerStarted, expireStaleReservations } from '@/lib/services/worker';

export async function GET() {
  ensureBackgroundWorkerStarted();
  const db = getDb();
  const row = db.prepare('SELECT COUNT(*) as skuCount FROM skus').get() as { skuCount: number };
  const sweep = expireStaleReservations();
  return NextResponse.json({
    ok: true,
    skuCount: row.skuCount,
    workerSweep: sweep,
  });
}
