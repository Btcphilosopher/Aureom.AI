import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { getAuthenticatedUser, requireStaffRole } from '@/lib/auth';
import {
  listCategories,
  listHomepageBanners,
  listLocations,
  listProducts,
} from '@/lib/services/catalogue';
import { listAllOrdersAdmin } from '@/lib/services/orders';
import { jsonError } from '@/lib/api-helpers';

export async function GET(req: NextRequest) {
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, [
    'catalogue_manager',
    'fulfilment_staff',
    'customer_service',
    'admin',
  ]);
  if (!authz.ok) {
    return jsonError(authz.error, authz.status);
  }

  const db = getDb();
  const auditLogs = db
    .prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100')
    .all() as Array<Record<string, unknown>>;

  const adjustments = db
    .prepare('SELECT * FROM inventory_adjustments ORDER BY created_at DESC LIMIT 80')
    .all() as Array<Record<string, unknown>>;

  const reservations = db
    .prepare('SELECT * FROM stock_reservations ORDER BY created_at DESC LIMIT 80')
    .all() as Array<Record<string, unknown>>;

  const staffUsers =
    authz.user.role === 'admin'
      ? (db
          .prepare(
            "SELECT id, email, name, role, created_at FROM users WHERE role != 'customer' ORDER BY created_at ASC"
          )
          .all() as Array<Record<string, unknown>>)
      : [];

  return NextResponse.json({
    user: authz.user,
    products: listProducts({ includeInactive: true }),
    categories: listCategories(),
    locations: listLocations(),
    orders: listAllOrdersAdmin(),
    banners: listHomepageBanners(),
    auditLogs,
    adjustments,
    reservations,
    staffUsers,
  });
}
