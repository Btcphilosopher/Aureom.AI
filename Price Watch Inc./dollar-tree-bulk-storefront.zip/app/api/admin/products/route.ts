import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb, withTransaction } from '@/lib/db';
import { getAuthenticatedUser, requireStaffRole, verifyMutationOrigin } from '@/lib/auth';
import { jsonError } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) return jsonError('Invalid origin.', 403);
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, ['catalogue_manager']);
  if (!authz.ok) return jsonError(authz.error, authz.status);

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const sku = String(body.sku || '').trim().toUpperCase();
  const title = String(body.title || '').trim();
  const subtitle = String(body.subtitle || '').trim();
  const description = String(body.description || '').trim();
  const brand = String(body.brand || 'Dollar Tree Select').trim();
  const categoryId = String(body.categoryId || 'cat-cleaning');
  const consumerSellingUnit = String(body.consumerSellingUnit || 'item').trim();
  const itemsPerConsumerPack = body.itemsPerConsumerPack ? Number(body.itemsPerConsumerPack) : null;
  const consumerUnitsPerCase = Number(body.consumerUnitsPerCase);
  const casePriceCents = Number(body.casePriceCents);
  const minCaseQuantity = Math.max(1, Number(body.minCaseQuantity || 1));
  const caseIncrement = Math.max(1, Number(body.caseIncrement || 1));
  const deliveryEligible = body.deliveryEligible !== false;
  const pickupEligible = body.pickupEligible !== false;
  const image = String(body.image || '/images/products/dish-soap.jpg').trim();

  if (
    !/^[A-Z0-9-]{3,32}$/.test(sku) ||
    !title ||
    !Number.isInteger(consumerUnitsPerCase) ||
    consumerUnitsPerCase <= 0 ||
    !Number.isInteger(casePriceCents) ||
    casePriceCents <= 0
  ) {
    return jsonError('Valid SKU, title, positive case unit count, and positive integer case price in cents are required.');
  }

  const db = getDb();
  const existing = db.prepare('SELECT sku FROM skus WHERE sku = ?').get(sku);
  if (existing) {
    return jsonError(`SKU ${sku} already exists.`, 409);
  }

  const nowIso = new Date().toISOString();
  const familyId = `fam-${sku.toLowerCase()}`;

  withTransaction(db, () => {
    db.prepare(
      `INSERT INTO product_families
       (id, slug, name, brand, category_id, description, is_assorted, assorted_selection_note, requires_variant_selection, tags_json, featured_order, active)
       VALUES (?, ?, ?, ?, ?, ?, 0, '', 0, '["everyday"]', 50, 1)`
    ).run(familyId, sku.toLowerCase(), title, brand, categoryId, description || title);

    db.prepare(
      `INSERT INTO skus
       (sku, family_id, title, subtitle, description, images_json, variant_attributes_json,
        consumer_selling_unit, items_per_consumer_pack, consumer_units_per_case, case_price_cents,
        currency, min_case_quantity, case_increment, weight_oz, dimensions_in,
        delivery_eligible, pickup_eligible, active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, '{}', ?, ?, ?, ?, 'USD', ?, ?, 160, '16 x 12 x 10 in', ?, ?, 1, ?, ?)`
    ).run(
      sku,
      familyId,
      title,
      subtitle,
      description || title,
      JSON.stringify([image]),
      consumerSellingUnit,
      itemsPerConsumerPack,
      consumerUnitsPerCase,
      casePriceCents,
      minCaseQuantity,
      caseIncrement,
      deliveryEligible ? 1 : 0,
      pickupEligible ? 1 : 0,
      nowIso,
      nowIso
    );

    const locs = db.prepare('SELECT id FROM locations WHERE active = 1').all() as Array<{ id: string }>;
    const insertInv = db.prepare(
      'INSERT INTO inventory_levels (sku, location_id, on_hand_cases, reserved_cases, updated_at) VALUES (?, ?, 20, 0, ?)'
    );
    for (const l of locs) {
      insertInv.run(sku, l.id, nowIso);
    }

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, ?, ?, 'catalogue.sku_created', 'sku', ?, ?, ?)`
    ).run(
      `AUD-${crypto.randomUUID().slice(0, 10)}`,
      authz.user.id,
      authz.user.email,
      authz.user.role,
      sku,
      JSON.stringify({ title, casePriceCents, consumerUnitsPerCase }),
      nowIso
    );
  });

  return NextResponse.json({ created: true, sku }, { status: 201 });
}

export async function PATCH(req: NextRequest) {
  if (!verifyMutationOrigin(req)) return jsonError('Invalid origin.', 403);
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, ['catalogue_manager']);
  if (!authz.ok) return jsonError(authz.error, authz.status);

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const sku = String(body.sku || '').trim().toUpperCase();
  if (!sku) return jsonError('sku is required.');

  const db = getDb();
  const current = db.prepare('SELECT * FROM skus WHERE sku = ?').get(sku) as
    | Record<string, unknown>
    | undefined;
  if (!current) return jsonError('SKU not found.', 404);

  const nextTitle = typeof body.title === 'string' && body.title.trim() ? body.title.trim() : String(current.title);
  const nextDescription =
    typeof body.description === 'string' && body.description.trim()
      ? body.description.trim()
      : String(current.description);
  const nextCasePriceCents =
    typeof body.casePriceCents === 'number' && Number.isInteger(body.casePriceCents) && body.casePriceCents > 0
      ? body.casePriceCents
      : Number(current.case_price_cents);
  const nextUnitsPerCase =
    typeof body.consumerUnitsPerCase === 'number' &&
    Number.isInteger(body.consumerUnitsPerCase) &&
    body.consumerUnitsPerCase > 0
      ? body.consumerUnitsPerCase
      : Number(current.consumer_units_per_case);
  const nextActive = typeof body.active === 'boolean' ? (body.active ? 1 : 0) : Number(current.active);
  const nextDelivery =
    typeof body.deliveryEligible === 'boolean'
      ? body.deliveryEligible
        ? 1
        : 0
      : Number(current.delivery_eligible);
  const nextPickup =
    typeof body.pickupEligible === 'boolean'
      ? body.pickupEligible
        ? 1
        : 0
      : Number(current.pickup_eligible);
  const nextImagesJson =
    typeof body.image === 'string' && body.image.trim()
      ? JSON.stringify([body.image.trim()])
      : String(current.images_json);

  // Check if SKU has open unfulfilled/active orders when deactivating or changing fulfilment flags
  const openOrders = db
    .prepare(
      `SELECT COUNT(*) as cnt FROM order_items oi
       JOIN orders o ON o.id = oi.order_id
       WHERE oi.sku = ? AND o.order_status IN ('pending_payment', 'confirmed')
         AND o.fulfilment_status NOT IN ('delivered', 'collected', 'cancelled')`
    )
    .get(sku) as { cnt: number };

  const nowIso = new Date().toISOString();

  withTransaction(db, () => {
    db.prepare(
      `UPDATE skus
       SET title = ?, description = ?, case_price_cents = ?, consumer_units_per_case = ?,
           active = ?, delivery_eligible = ?, pickup_eligible = ?, images_json = ?, updated_at = ?
       WHERE sku = ?`
    ).run(
      nextTitle,
      nextDescription,
      nextCasePriceCents,
      nextUnitsPerCase,
      nextActive,
      nextDelivery,
      nextPickup,
      nextImagesJson,
      nowIso,
      sku
    );

    db.prepare(
      `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
       VALUES (?, ?, ?, ?, 'catalogue.sku_updated', 'sku', ?, ?, ?)`
    ).run(
      `AUD-${crypto.randomUUID().slice(0, 10)}`,
      authz.user.id,
      authz.user.email,
      authz.user.role,
      sku,
      JSON.stringify({
        previousPriceCents: Number(current.case_price_cents),
        nextCasePriceCents,
        nextActive: Boolean(nextActive),
        openOrdersPreservedWithSnapshot: openOrders.cnt,
      }),
      nowIso
    );
  });

  return NextResponse.json({
    updated: true,
    sku,
    openOrdersWarning:
      openOrders.cnt > 0
        ? `${openOrders.cnt} existing open order line(s) retain their original immutable snapshot prices and packaging.`
        : null,
  });
}
