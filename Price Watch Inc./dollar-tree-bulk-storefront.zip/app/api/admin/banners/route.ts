import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { getAuthenticatedUser, requireStaffRole, verifyMutationOrigin } from '@/lib/auth';
import { jsonError } from '@/lib/api-helpers';

export async function PATCH(req: NextRequest) {
  if (!verifyMutationOrigin(req)) return jsonError('Invalid origin.', 403);
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, ['catalogue_manager']);
  if (!authz.ok) return jsonError(authz.error, authz.status);

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const slot = String(body.slot || '').trim();
  const headline = String(body.headline || '').trim();
  const subheadline = String(body.subheadline || '').trim();
  const ctaLabel = String(body.ctaLabel || '').trim();
  const ctaHref = String(body.ctaHref || '').trim();
  const active = body.active !== false ? 1 : 0;

  if (!['announcement', 'hero', 'business'].includes(slot) || !headline) {
    return jsonError('Valid banner slot and headline are required.');
  }

  // Prevent javascript: or unsafe URL schemes in CTA href
  if (ctaHref && !/^(\/|#)[A-Za-z0-9\-_/?=&%#]*$/.test(ctaHref)) {
    return jsonError('Banner CTA link must be a safe internal path starting with / or #.');
  }

  const db = getDb();
  const nowIso = new Date().toISOString();

  db.prepare(
    `UPDATE homepage_banners
     SET headline = ?, subheadline = ?, cta_label = ?, cta_href = ?, active = ?, updated_at = ?
     WHERE slot = ?`
  ).run(headline, subheadline, ctaLabel, ctaHref, active, nowIso, slot);

  db.prepare(
    `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
     VALUES (?, ?, ?, ?, 'banner.updated', 'banner', ?, ?, ?)`
  ).run(
    `AUD-${crypto.randomUUID().slice(0, 10)}`,
    authz.user.id,
    authz.user.email,
    authz.user.role,
    slot,
    JSON.stringify({ headline, active: Boolean(active) }),
    nowIso
  );

  return NextResponse.json({ updated: true, slot });
}
