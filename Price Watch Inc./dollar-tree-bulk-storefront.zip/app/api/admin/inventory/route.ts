import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb, withTransaction } from '@/lib/db';
import { getAuthenticatedUser, requireStaffRole, verifyMutationOrigin } from '@/lib/auth';
import { jsonError } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) return jsonError('Invalid origin.', 403);
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, ['catalogue_manager', 'fulfilment_staff']);
  if (!authz.ok) return jsonError(authz.error, authz.status);

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const sku = String(body.sku || '').trim().toUpperCase();
  const locationId = String(body.locationId || '').trim();
  const deltaCases = Number(body.deltaCases);
  const reason = String(body.reason || 'Manual stock adjustment').trim();

  if (!sku || !locationId || !Number.isInteger(deltaCases) || deltaCases === 0) {
    return jsonError('SKU, locationId, and non-zero whole number deltaCases are required.');
  }

  const db = getDb();
  const nowIso = new Date().toISOString();

  try {
    const updated = withTransaction(db, () => {
      const inv = db
        .prepare('SELECT on_hand_cases, reserved_cases FROM inventory_levels WHERE sku = ? AND location_id = ?')
        .get(sku, locationId) as { on_hand_cases: number; reserved_cases: number } | undefined;

      if (!inv) {
        throw new Error(`Inventory record not found for ${sku} at ${locationId}.`);
      }

      const nextOnHand = inv.on_hand_cases + deltaCases;
      if (nextOnHand < inv.reserved_cases) {
        throw new Error(
          `Cannot reduce on-hand stock to ${nextOnHand}: ${inv.reserved_cases} case(s) are actively reserved by pending checkouts.`
        );
      }

      db.prepare(
        'UPDATE inventory_levels SET on_hand_cases = ?, updated_at = ? WHERE sku = ? AND location_id = ?'
      ).run(nextOnHand, nowIso, sku, locationId);

      db.prepare(
        'INSERT INTO inventory_adjustments (id, sku, location_id, delta_cases, reason, actor_user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
      ).run(`ADJ-${crypto.randomUUID().slice(0, 10)}`, sku, locationId, deltaCases, reason, authz.user.id, nowIso);

      db.prepare(
        `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
         VALUES (?, ?, ?, ?, 'inventory.adjusted', 'inventory', ?, ?, ?)`
      ).run(
        `AUD-${crypto.randomUUID().slice(0, 10)}`,
        authz.user.id,
        authz.user.email,
        authz.user.role,
        `${sku}@${locationId}`,
        JSON.stringify({ deltaCases, nextOnHand, reason }),
        nowIso
      );

      return { onHandCases: nextOnHand, reservedCases: inv.reserved_cases };
    });

    return NextResponse.json({ adjusted: true, ...updated });
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Inventory adjustment failed.', 400);
  }
}
