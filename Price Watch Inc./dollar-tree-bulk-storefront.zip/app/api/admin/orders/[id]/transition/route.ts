import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, requireStaffRole, verifyMutationOrigin } from '@/lib/auth';
import { transitionFulfilmentStatus } from '@/lib/services/orders';
import { jsonError } from '@/lib/api-helpers';

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  if (!verifyMutationOrigin(req)) return jsonError('Invalid origin.', 403);
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, ['fulfilment_staff', 'customer_service']);
  if (!authz.ok) return jsonError(authz.error, authz.status);

  const { id } = await context.params;
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const nextStatus = String(body.nextStatus || '').trim();
  const note = String(body.note || '');
  if (!nextStatus) {
    return jsonError('nextStatus is required.');
  }

  try {
    const order = transitionFulfilmentStatus({
      orderId: id,
      nextStatus,
      actor: authz.user,
      note,
    });
    return NextResponse.json({ order });
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Transition failed.', 400);
  }
}
