import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, requireStaffRole, verifyMutationOrigin } from '@/lib/auth';
import { issueRefund } from '@/lib/services/orders';
import { jsonError } from '@/lib/api-helpers';

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  if (!verifyMutationOrigin(req)) return jsonError('Invalid origin.', 403);
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, ['customer_service']);
  if (!authz.ok) return jsonError(authz.error, authz.status);

  const { id } = await context.params;
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const amountCents = Number(body.amountCents);
  const reason = String(body.reason || 'Customer service refund').trim();

  try {
    const order = issueRefund({
      orderId: id,
      amountCents,
      reason,
      actor: authz.user,
    });
    return NextResponse.json({ order });
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Refund failed.', 400);
  }
}
