import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import {
  getAuthenticatedUser,
  hashPassword,
  requireStaffRole,
  verifyMutationOrigin,
} from '@/lib/auth';
import { STAFF_ROLES, type StaffRole } from '@/lib/config';
import { jsonError } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) return jsonError('Invalid origin.', 403);
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, ['admin']);
  if (!authz.ok) return jsonError(authz.error, authz.status);
  if (authz.user.role !== 'admin') {
    return jsonError('Only administrators may provision staff accounts.', 403);
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const email = String(body.email || '').trim().toLowerCase();
  const name = String(body.name || '').trim();
  const password = String(body.password || '');
  const role = String(body.role || '') as StaffRole;

  if (!email || !email.includes('@') || !name || password.length < 8) {
    return jsonError('Valid email, name, and password (min 8 characters) are required.');
  }
  if (!STAFF_ROLES.includes(role)) {
    return jsonError('Invalid staff role.');
  }

  const db = getDb();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return jsonError('A user with this email already exists.', 409);
  }

  const id = `STF-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const nowIso = new Date().toISOString();
  db.prepare(
    'INSERT INTO users (id, email, name, password_hash, role, company_name, tax_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(id, email, name, hashPassword(password), role, 'Storefront Staff', '', nowIso);

  db.prepare(
    `INSERT INTO audit_logs (id, actor_user_id, actor_email, actor_role, action, entity_type, entity_id, details_json, created_at)
     VALUES (?, ?, ?, ?, 'staff.account_created', 'user', ?, ?, ?)`
  ).run(
    `AUD-${crypto.randomUUID().slice(0, 10)}`,
    authz.user.id,
    authz.user.email,
    authz.user.role,
    id,
    JSON.stringify({ email, role }),
    nowIso
  );

  return NextResponse.json({ created: true, id, email, name, role }, { status: 201 });
}
