import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, requireStaffRole, verifyMutationOrigin } from '@/lib/auth';
import { STORE_CONFIG } from '@/lib/config';
import { jsonError } from '@/lib/api-helpers';

function detectImageExtension(buf: Buffer): 'png' | 'jpg' | 'webp' | null {
  if (buf.length < 12) return null;
  // PNG: 89 50 4E 47
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) {
    return 'png';
  }
  // JPEG: FF D8 FF
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    return 'jpg';
  }
  // WEBP: RIFF....WEBP
  if (
    buf.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buf.subarray(8, 12).toString('ascii') === 'WEBP'
  ) {
    return 'webp';
  }
  return null;
}

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) return jsonError('Invalid origin.', 403);
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, ['catalogue_manager']);
  if (!authz.ok) return jsonError(authz.error, authz.status);

  const formData = await req.formData();
  const file = formData.get('file');
  if (!(file instanceof File)) {
    return jsonError('Image file field is required.');
  }

  if (file.size <= 0 || file.size > STORE_CONFIG.maxImageUploadBytes) {
    return jsonError('Image must be non-empty and under 4 MB.');
  }

  const arrayBuffer = await file.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  const detectedExt = detectImageExtension(buffer);
  if (!detectedExt) {
    return jsonError('Only valid PNG, JPEG, or WEBP images are permitted.');
  }

  const uploadBaseDir = path.resolve(process.cwd(), 'public', 'uploads');
  fs.mkdirSync(uploadBaseDir, { recursive: true });

  const safeFilename = `sku-${Date.now()}-${crypto.randomBytes(6).toString('hex')}.${detectedExt}`;
  const resolvedDest = path.resolve(uploadBaseDir, safeFilename);

  if (!resolvedDest.startsWith(uploadBaseDir + path.sep)) {
    return jsonError('Invalid destination path.', 400);
  }

  fs.writeFileSync(resolvedDest, buffer);

  return NextResponse.json({
    uploaded: true,
    url: `/uploads/${safeFilename}`,
    bytes: buffer.length,
    format: detectedExt,
  });
}
