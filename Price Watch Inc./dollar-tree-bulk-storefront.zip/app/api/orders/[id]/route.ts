import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, verifyMutationOrigin } from '@/lib/auth';
import {
  getOrderScoped,
  reorderToCart,
  requestOrderCancellation,
} from '@/lib/services/orders';
import { attachGuestCartCookie, jsonError, readGuestCartToken } from '@/lib/api-helpers';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const user = await getAuthenticatedUser(req);
  const guestToken = req.nextUrl.searchParams.get('token');

  const order = getOrderScoped({ orderId: id, user, guestToken });
  if (!order) {
    return jsonError('Order not found or access denied.', 404);
  }
  return NextResponse.json({ order });
}

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }

  const { id } = await context.params;
  const user = await getAuthenticatedUser(req);

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const action = String(body.action || '');
  const guestTokenParam = typeof body.guestToken === 'string' ? body.guestToken : null;

  const order = getOrderScoped({ orderId: id, user, guestToken: guestTokenParam });
  if (!order) {
    return jsonError('Order not found or access denied.', 404);
  }

  try {
    if (action === 'reorder') {
      const guestCartToken = await readGuestCartToken(req);
      const result = reorderToCart({
        orderId: order.id,
        userId: user?.id ?? null,
        guestToken: guestCartToken,
      });
      const res = NextResponse.json(result);
      if (!user && result.guestToken) {
        attachGuestCartCookie(res, result.guestToken);
      }
      return res;
    }

    if (action === 'cancel_request') {
      if (!user) {
        return jsonError('Sign in to request cancellation on an account order.', 401);
      }
      const reason = String(body.reason || 'Customer requested cancellation before dispatch.');
      const updated = requestOrderCancellation({
        orderId: order.id,
        reason,
        user,
      });
      return NextResponse.json({ order: updated });
    }

    return jsonError(`Unsupported order action "${action}".`);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Unable to process order action.', 400);
  }
}
