import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { getAuthenticatedUser, verifyMutationOrigin } from '@/lib/auth';
import { listOrdersForUser } from '@/lib/services/orders';
import { jsonError } from '@/lib/api-helpers';

export async function GET(req: NextRequest) {
  const user = await getAuthenticatedUser(req);
  if (!user) {
    return jsonError('Authentication required.', 401);
  }

  const db = getDb();
  const addresses = db
    .prepare('SELECT * FROM saved_addresses WHERE user_id = ? ORDER BY is_default DESC, label ASC')
    .all(user.id) as Array<Record<string, unknown>>;

  const businessLists = db
    .prepare('SELECT * FROM business_lists WHERE user_id = ? ORDER BY created_at DESC')
    .all(user.id) as Array<Record<string, unknown>>;

  const orders = listOrdersForUser(user.id);

  return NextResponse.json({
    user,
    addresses: addresses.map((a) => ({
      id: String(a.id),
      label: String(a.label),
      recipientName: String(a.recipient_name),
      line1: String(a.line1),
      line2: String(a.line2 || ''),
      city: String(a.city),
      state: String(a.state),
      postalCode: String(a.postal_code),
      isDefault: Boolean(a.is_default),
    })),
    businessLists: businessLists.map((b) => ({
      id: String(b.id),
      name: String(b.name),
      listType: String(b.list_type),
      poReference: String(b.po_reference || ''),
      companyName: String(b.company_name || ''),
      billingEmail: String(b.billing_email || ''),
      items: JSON.parse(String(b.items_json || '[]')),
      createdAt: String(b.created_at),
    })),
    orders,
  });
}

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }
  const user = await getAuthenticatedUser(req);
  if (!user) {
    return jsonError('Authentication required.', 401);
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const db = getDb();
  const type = String(body.type || '');

  if (type === 'save_address') {
    const label = String(body.label || 'Primary Address').trim();
    const recipientName = String(body.recipientName || user.name).trim();
    const line1 = String(body.line1 || '').trim();
    const line2 = String(body.line2 || '').trim();
    const city = String(body.city || '').trim();
    const state = String(body.state || '').trim().toUpperCase();
    const postalCode = String(body.postalCode || '').trim();
    const isDefault = Boolean(body.isDefault);

    if (!line1 || !city || !state || !postalCode) {
      return jsonError('Street address, city, state, and postal code are required.');
    }

    if (isDefault) {
      db.prepare('UPDATE saved_addresses SET is_default = 0 WHERE user_id = ?').run(user.id);
    }

    const id = `ADDR-${crypto.randomUUID().slice(0, 8)}`;
    db.prepare(
      `INSERT INTO saved_addresses
       (id, user_id, label, recipient_name, line1, line2, city, state, postal_code, is_default)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, user.id, label, recipientName, line1, line2, city, state, postalCode, isDefault ? 1 : 0);

    return NextResponse.json({ saved: true, id }, { status: 201 });
  }

  if (type === 'delete_address') {
    const id = String(body.id || '');
    db.prepare('DELETE FROM saved_addresses WHERE id = ? AND user_id = ?').run(id, user.id);
    return NextResponse.json({ deleted: true });
  }

  if (type === 'save_business_list') {
    const name = String(body.name || '').trim();
    const listType = body.listType === 'repeat_template' ? 'repeat_template' : 'purchasing_list';
    const poReference = String(body.poReference || '').trim();
    const companyName = String(body.companyName || user.companyName || '').trim();
    const billingEmail = String(body.billingEmail || user.email).trim();
    const items = Array.isArray(body.items) ? body.items : [];

    if (!name || items.length === 0) {
      return jsonError('List name and at least one SKU item are required.');
    }

    const id = `BL-${crypto.randomUUID().slice(0, 8)}`;
    db.prepare(
      `INSERT INTO business_lists
       (id, user_id, name, list_type, po_reference, company_name, billing_email, items_json, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      user.id,
      name,
      listType,
      poReference,
      companyName,
      billingEmail,
      JSON.stringify(items),
      new Date().toISOString()
    );

    return NextResponse.json({ saved: true, id }, { status: 201 });
  }

  if (type === 'delete_business_list') {
    const id = String(body.id || '');
    db.prepare('DELETE FROM business_lists WHERE id = ? AND user_id = ?').run(id, user.id);
    return NextResponse.json({ deleted: true });
  }

  return jsonError('Unsupported account action.');
}
