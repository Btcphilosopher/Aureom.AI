import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, verifyMutationOrigin } from '@/lib/auth';
import { getOrCreateCart } from '@/lib/services/cart';
import { CheckoutConflictError, createOrderAttempt } from '@/lib/services/checkout';
import { jsonError, readGuestCartToken } from '@/lib/api-helpers';
import { checkRateLimit, getClientKey } from '@/lib/rate-limit';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }

  const rl = checkRateLimit(getClientKey(req.headers, 'checkout_attempt'), 20, 60_000);
  if (!rl.allowed) {
    return jsonError('Too many checkout attempts. Please wait briefly.', 429);
  }

  const user = await getAuthenticatedUser(req);
  const guestTokenIn = await readGuestCartToken(req);
  const { cartId } = getOrCreateCart({ userId: user?.id, guestToken: guestTokenIn });

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const idempotencyKey = String(body.idempotencyKey || req.headers.get('idempotency-key') || '').trim();
  if (!idempotencyKey || idempotencyKey.length < 8) {
    return jsonError('A unique idempotencyKey is required for checkout.');
  }

  const contactRaw = (body.contact || {}) as Record<string, unknown>;
  const email = String(contactRaw.email || '').trim();
  const name = String(contactRaw.name || '').trim();
  const phone = String(contactRaw.phone || '').trim();

  if (!email || !email.includes('@') || !name || !phone) {
    return jsonError('Contact name, valid email, and phone number are required.');
  }

  const fulfilmentMethod = body.fulfilmentMethod === 'pickup' ? 'pickup' : 'delivery';
  const locationId = String(body.locationId || '');
  const addressRaw = (body.shippingAddress || {}) as Record<string, unknown>;

  if (fulfilmentMethod === 'delivery') {
    if (
      !String(addressRaw.line1 || '').trim() ||
      !String(addressRaw.city || '').trim() ||
      !String(addressRaw.state || '').trim() ||
      !String(addressRaw.postalCode || '').trim()
    ) {
      return jsonError('Complete delivery street address, city, state, and postal code are required.');
    }
  }

  const ttlOverride =
    typeof body.reservationTtlMinutes === 'number' && body.reservationTtlMinutes > 0
      ? Math.min(30, body.reservationTtlMinutes)
      : undefined;

  try {
    const attempt = createOrderAttempt({
      cartId,
      userId: user?.id ?? null,
      fulfilmentMethod,
      locationId,
      contact: {
        email,
        name,
        phone,
        poReference: String(contactRaw.poReference || ''),
        companyName: String(contactRaw.companyName || ''),
        billingEmail: String(contactRaw.billingEmail || ''),
        taxId: String(contactRaw.taxId || ''),
      },
      shippingAddress:
        fulfilmentMethod === 'delivery'
          ? {
              line1: String(addressRaw.line1 || '').trim(),
              line2: String(addressRaw.line2 || '').trim(),
              city: String(addressRaw.city || '').trim(),
              state: String(addressRaw.state || '').trim().toUpperCase(),
              postalCode: String(addressRaw.postalCode || '').trim(),
            }
          : undefined,
      idempotencyKey,
      reservationTtlMinutes: ttlOverride,
    });

    return NextResponse.json({ attempt }, { status: attempt.reusedIdempotent ? 200 : 201 });
  } catch (err) {
    if (err instanceof CheckoutConflictError) {
      return jsonError(err.message, 409);
    }
    return jsonError(err instanceof Error ? err.message : 'Checkout attempt failed.', 400);
  }
}
