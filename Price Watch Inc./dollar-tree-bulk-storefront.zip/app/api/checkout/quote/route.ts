import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, verifyMutationOrigin } from '@/lib/auth';
import { getOrCreateCart } from '@/lib/services/cart';
import { quoteCheckout } from '@/lib/services/checkout';
import { jsonError, readGuestCartToken } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }

  const user = await getAuthenticatedUser(req);
  const guestTokenIn = await readGuestCartToken(req);
  const { cartId } = getOrCreateCart({ userId: user?.id, guestToken: guestTokenIn });

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const fulfilmentMethod = body.fulfilmentMethod === 'pickup' ? 'pickup' : 'delivery';
  const locationId = String(
    body.locationId || (fulfilmentMethod === 'pickup' ? 'LOC-STR-104' : 'LOC-DC-EAST')
  );
  const destinationState =
    typeof body.destinationState === 'string' ? body.destinationState : undefined;

  try {
    const quote = quoteCheckout({
      cartId,
      fulfilmentMethod,
      locationId,
      destinationState,
    });
    return NextResponse.json({ quote });
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Quote calculation failed.', 400);
  }
}
