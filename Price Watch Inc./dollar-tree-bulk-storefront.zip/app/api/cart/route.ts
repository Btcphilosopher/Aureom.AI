import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, verifyMutationOrigin } from '@/lib/auth';
import {
  acceptCartPriceChanges,
  getCartView,
  getOrCreateCart,
  toggleSaveForLater,
  updateCartFulfilment,
  upsertCartItem,
} from '@/lib/services/cart';
import { attachGuestCartCookie, jsonError, readGuestCartToken } from '@/lib/api-helpers';
import { ensureBackgroundWorkerStarted } from '@/lib/services/worker';

export async function GET(req: NextRequest) {
  ensureBackgroundWorkerStarted();
  const user = await getAuthenticatedUser(req);
  const guestTokenIn = await readGuestCartToken(req);
  const { cartId, guestToken } = getOrCreateCart({
    userId: user?.id,
    guestToken: guestTokenIn,
  });

  const cart = getCartView(cartId);
  const res = NextResponse.json({ cart });
  if (!user && guestToken) {
    attachGuestCartCookie(res, guestToken);
  }
  return res;
}

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }

  const user = await getAuthenticatedUser(req);
  const guestTokenIn = await readGuestCartToken(req);
  const { cartId, guestToken } = getOrCreateCart({
    userId: user?.id,
    guestToken: guestTokenIn,
  });

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const action = String(body.action || 'add');

  try {
    let cart;
    if (action === 'add' || action === 'set') {
      const sku = String(body.sku || '');
      const cases = Number(body.cases);
      if (!sku || !Number.isInteger(cases)) {
        return jsonError('Valid SKU and whole number case quantity are required.');
      }
      cart = upsertCartItem({
        cartId,
        sku,
        casesDeltaOrSet: cases,
        mode: action,
      });
    } else if (action === 'save_for_later') {
      cart = toggleSaveForLater(cartId, String(body.sku || ''), true);
    } else if (action === 'move_to_cart') {
      cart = toggleSaveForLater(cartId, String(body.sku || ''), false);
    } else if (action === 'accept_prices') {
      cart = acceptCartPriceChanges(cartId);
    } else if (action === 'fulfilment') {
      const method = body.fulfilmentMethod === 'pickup' ? 'pickup' : 'delivery';
      const locationId = String(body.locationId || '');
      cart = updateCartFulfilment({
        cartId,
        fulfilmentMethod: method,
        locationId,
        destinationZip: typeof body.destinationZip === 'string' ? body.destinationZip : undefined,
        destinationState:
          typeof body.destinationState === 'string' ? body.destinationState : undefined,
      });
    } else {
      return jsonError(`Unsupported cart action "${action}".`);
    }

    const res = NextResponse.json({ cart });
    if (!user && guestToken) {
      attachGuestCartCookie(res, guestToken);
    }
    return res;
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Unable to update cart.', 400);
  }
}
