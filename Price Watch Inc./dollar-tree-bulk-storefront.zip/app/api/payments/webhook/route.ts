import { NextRequest, NextResponse } from 'next/server';
import { processPaymentWebhook, verifyWebhookSignature } from '@/lib/services/checkout';
import { jsonError } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get('x-webhook-signature');

  if (!verifyWebhookSignature(rawBody, signature)) {
    return jsonError('Invalid or missing webhook signature.', 401);
  }

  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(rawBody) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON webhook payload.', 400);
  }

  const provider = payload.provider === 'stripe_sandbox' ? 'stripe_sandbox' : 'local_simulator';
  const providerEventId = String(payload.providerEventId || '').trim();
  const eventType = payload.eventType === 'payment.failed' ? 'payment.failed' : 'payment.succeeded';
  const orderId = String(payload.orderId || '').trim();
  const amountCents = Number(payload.amountCents || 0);

  if (!providerEventId || !orderId || !Number.isInteger(amountCents)) {
    return jsonError('Missing required webhook event fields.', 400);
  }

  try {
    const result = processPaymentWebhook({
      provider,
      providerEventId,
      eventType,
      orderId,
      amountCents,
    });
    return NextResponse.json({ received: true, ...result });
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Webhook processing failed.', 400);
  }
}
