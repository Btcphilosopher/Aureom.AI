import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import { getAuthenticatedUser, verifyMutationOrigin } from '@/lib/auth';
import { getOrCreateCart } from '@/lib/services/cart';
import { processPaymentWebhook, signWebhookPayload } from '@/lib/services/checkout';
import { jsonError, readGuestCartToken } from '@/lib/api-helpers';

/**
 * Local payment simulator endpoint.
 * Never stores raw card data. Produces a signed webhook event and dispatches
 * it through the exact same verified webhook processor as an external payment provider.
 */
export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const orderId = String(body.orderId || '').trim();
  const outcome = body.outcome === 'fail' ? 'payment.failed' : 'payment.succeeded';
  const provider = body.provider === 'stripe_sandbox' ? 'stripe_sandbox' : 'local_simulator';

  if (!orderId) {
    return jsonError('orderId is required.');
  }

  const db = getDb();
  const order = db
    .prepare('SELECT id, total_cents, user_id, guest_access_token_hash FROM orders WHERE id = ?')
    .get(orderId) as
    | { id: string; total_cents: number; user_id: string | null; guest_access_token_hash: string | null }
    | undefined;

  if (!order) {
    return jsonError('Order not found.', 404);
  }

  // Verify caller owns this order attempt (logged-in owner or matching guest access token)
  const user = await getAuthenticatedUser(req);
  const guestOrderToken = String(body.guestAccessToken || '');
  const ownsAsUser = Boolean(user && order.user_id && order.user_id === user.id);
  const ownsAsGuest = Boolean(
    guestOrderToken &&
      order.guest_access_token_hash &&
      crypto.createHash('sha256').update(guestOrderToken).digest('hex') === order.guest_access_token_hash
  );
  const isStaff = Boolean(user && user.role === 'admin');

  if (!ownsAsUser && !ownsAsGuest && !isStaff) {
    return jsonError('Forbidden: cannot simulate payment for an order you do not own.', 403);
  }

  const guestCartToken = await readGuestCartToken(req);
  const { cartId } = getOrCreateCart({ userId: user?.id, guestToken: guestCartToken });

  const providerEventId = `evt_${crypto.randomUUID()}`;
  const rawWebhook = JSON.stringify({
    provider,
    providerEventId,
    eventType: outcome,
    orderId: order.id,
    amountCents: order.total_cents,
  });
  // Sign with server HMAC so simulated flow mirrors verified provider webhooks
  const signature = signWebhookPayload(rawWebhook);

  const result = processPaymentWebhook({
    provider,
    providerEventId,
    eventType: outcome,
    orderId: order.id,
    amountCents: order.total_cents,
    cartIdToClear: cartId,
  });

  return NextResponse.json({
    simulated: true,
    providerEventId,
    webhookSignatureVerified: Boolean(signature),
    ...result,
  });
}
