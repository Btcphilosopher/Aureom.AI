import { NextRequest, NextResponse } from 'next/server';
import {
  listCategories,
  listHomepageBanners,
  listLocations,
  listProducts,
  type ProductSearchFilters,
} from '@/lib/services/catalogue';
import { ensureBackgroundWorkerStarted } from '@/lib/services/worker';
import { checkRateLimit, getClientKey } from '@/lib/rate-limit';
import { jsonError } from '@/lib/api-helpers';

export async function GET(req: NextRequest) {
  ensureBackgroundWorkerStarted();
  const rl = checkRateLimit(getClientKey(req.headers, 'catalogue_search'), 120, 60_000);
  if (!rl.allowed) {
    return jsonError('Too many search requests. Please pause briefly.', 429);
  }

  const sp = req.nextUrl.searchParams;
  const q = (sp.get('q') || '').slice(0, 100);
  const category = sp.get('category') || 'all';
  const chipRaw = sp.get('chip') || 'all';
  const chip = (['all', 'under2', 'business', 'party'].includes(chipRaw)
    ? chipRaw
    : 'all') as ProductSearchFilters['chip'];
  const under2 = sp.get('under2') === 'true' || chip === 'under2';
  const minCasePrice = sp.get('minCasePrice') ? Number(sp.get('minCasePrice')) : undefined;
  const maxCasePrice = sp.get('maxCasePrice') ? Number(sp.get('maxCasePrice')) : undefined;
  const minUnitsPerCase = sp.get('minUnitsPerCase')
    ? Number(sp.get('minUnitsPerCase'))
    : undefined;
  const fulfilmentMethodRaw = sp.get('fulfilmentMethod') || '';
  const fulfilmentMethod = (['delivery', 'pickup'].includes(fulfilmentMethodRaw)
    ? fulfilmentMethodRaw
    : '') as ProductSearchFilters['fulfilmentMethod'];
  const locationId = sp.get('locationId') || undefined;
  const inStockOnly = sp.get('inStockOnly') === 'true';
  const sortRaw = sp.get('sort') || 'relevance';
  const sort = (
    [
      'relevance',
      'unit_price_asc',
      'unit_price_desc',
      'case_price_asc',
      'case_price_desc',
      'name_asc',
    ].includes(sortRaw)
      ? sortRaw
      : 'relevance'
  ) as ProductSearchFilters['sort'];

  const products = listProducts({
    q,
    category,
    chip,
    under2,
    minCasePriceCents: Number.isFinite(minCasePrice) ? Math.round(minCasePrice! * 100) : undefined,
    maxCasePriceCents: Number.isFinite(maxCasePrice) ? Math.round(maxCasePrice! * 100) : undefined,
    minUnitsPerCase: Number.isFinite(minUnitsPerCase) ? minUnitsPerCase : undefined,
    fulfilmentMethod,
    locationId,
    inStockOnly,
    sort,
  });

  return NextResponse.json({
    products,
    categories: listCategories(),
    locations: listLocations(),
    banners: listHomepageBanners(),
    total: products.length,
  });
}
