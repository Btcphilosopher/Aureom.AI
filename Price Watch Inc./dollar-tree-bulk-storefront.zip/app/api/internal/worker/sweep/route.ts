import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, requireStaffRole, verifyMutationOrigin } from '@/lib/auth';
import { expireStaleReservations } from '@/lib/services/worker';
import { jsonError } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) return jsonError('Invalid origin.', 403);
  const user = await getAuthenticatedUser(req);
  const authz = requireStaffRole(user, ['admin', 'fulfilment_staff']);
  if (!authz.ok) return jsonError(authz.error, authz.status);

  let nowIso: string | undefined;
  try {
    const body = (await req.json()) as Record<string, unknown>;
    if (typeof body.asOfIso === 'string' && !Number.isNaN(Date.parse(body.asOfIso))) {
      nowIso = body.asOfIso;
    }
  } catch {
    // optional body
  }

  const result = expireStaleReservations(nowIso);
  return NextResponse.json({ swept: true, ...result });
}
