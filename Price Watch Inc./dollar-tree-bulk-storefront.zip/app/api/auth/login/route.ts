import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import {
  attachSessionCookie,
  createSessionForUser,
  verifyMutationOrigin,
  verifyPassword,
} from '@/lib/auth';
import type { StaffRole } from '@/lib/config';
import { mergeGuestCartOnSignIn } from '@/lib/services/cart';
import { checkRateLimit, getClientKey } from '@/lib/rate-limit';
import { jsonError, readGuestCartToken } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }
  const rl = checkRateLimit(getClientKey(req.headers, 'auth_login'), 20, 60_000);
  if (!rl.allowed) {
    return jsonError('Too many login attempts. Please wait a minute.', 429);
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');

  if (!email || !password) {
    return jsonError('Email and password are required.');
  }

  const db = getDb();
  const userRow = db
    .prepare('SELECT id, email, name, password_hash, role, company_name, tax_id FROM users WHERE email = ?')
    .get(email) as
    | {
        id: string;
        email: string;
        name: string;
        password_hash: string;
        role: StaffRole;
        company_name: string;
        tax_id: string;
      }
    | undefined;

  if (!userRow || !verifyPassword(password, userRow.password_hash)) {
    return jsonError('Invalid email or password.', 401);
  }

  const guestToken = await readGuestCartToken(req);
  const { cart, mergeNotices } = mergeGuestCartOnSignIn(guestToken, userRow.id);

  const { rawToken } = createSessionForUser(userRow.id, userRow.role);
  const res = NextResponse.json({
    user: {
      id: userRow.id,
      email: userRow.email,
      name: userRow.name,
      role: userRow.role,
      companyName: userRow.company_name,
      taxId: userRow.tax_id,
    },
    cart,
    mergeNotices,
  });
  attachSessionCookie(res, rawToken);
  return res;
}
