import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import {
  clearSessionCookie,
  hashToken,
  SESSION_COOKIE_NAME,
  verifyMutationOrigin,
} from '@/lib/auth';
import { jsonError } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }

  const cookieHeader = req.headers.get('cookie') || '';
  const match = cookieHeader
    .split(';')
    .map((c) => c.trim())
    .find((c) => c.startsWith(`${SESSION_COOKIE_NAME}=`));

  if (match) {
    const rawToken = decodeURIComponent(match.split('=').slice(1).join('='));
    if (rawToken) {
      const db = getDb();
      db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hashToken(rawToken));
    }
  }

  const res = NextResponse.json({ loggedOut: true });
  clearSessionCookie(res);
  return res;
}
