import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, isStaffBootstrapRequired } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const user = await getAuthenticatedUser(req);
  return NextResponse.json({
    user,
    bootstrapRequired: isStaffBootstrapRequired(),
  });
}
