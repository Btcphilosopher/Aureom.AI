import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/db';
import {
  attachSessionCookie,
  createSessionForUser,
  hashPassword,
  verifyMutationOrigin,
} from '@/lib/auth';
import { mergeGuestCartOnSignIn } from '@/lib/services/cart';
import { checkRateLimit, getClientKey } from '@/lib/rate-limit';
import { jsonError, readGuestCartToken } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }
  const rl = checkRateLimit(getClientKey(req.headers, 'auth_register'), 15, 60_000);
  if (!rl.allowed) {
    return jsonError('Too many registration attempts. Please try again shortly.', 429);
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const email = String(body.email || '').trim().toLowerCase();
  const name = String(body.name || '').trim();
  const password = String(body.password || '');
  const companyName = String(body.companyName || '').trim();
  const taxId = String(body.taxId || '').trim();

  if (!email || !email.includes('@') || !name || password.length < 8) {
    return jsonError('Valid email, name, and password (min 8 characters) are required.');
  }

  const db = getDb();
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return jsonError('An account with this email already exists.', 409);
  }

  const userId = `USR-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const nowIso = new Date().toISOString();
  const pwHash = hashPassword(password);

  db.prepare(
    'INSERT INTO users (id, email, name, password_hash, role, company_name, tax_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(userId, email, name, pwHash, 'customer', companyName, taxId, nowIso);

  const guestToken = await readGuestCartToken(req);
  const { cart, mergeNotices } = mergeGuestCartOnSignIn(guestToken, userId);

  const { rawToken } = createSessionForUser(userId, 'customer');
  const res = NextResponse.json(
    {
      user: {
        id: userId,
        email,
        name,
        role: 'customer',
        companyName,
        taxId,
      },
      cart,
      mergeNotices,
    },
    { status: 201 }
  );
  attachSessionCookie(res, rawToken);
  return res;
}
