import { NextRequest, NextResponse } from 'next/server';
import {
  attachSessionCookie,
  bootstrapFirstAdmin,
  createSessionForUser,
  isStaffBootstrapRequired,
  verifyMutationOrigin,
} from '@/lib/auth';
import { jsonError } from '@/lib/api-helpers';

export async function POST(req: NextRequest) {
  if (!verifyMutationOrigin(req)) {
    return jsonError('Invalid request origin.', 403);
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return jsonError('Invalid JSON payload.');
  }

  const configuredPasscode = process.env.ADMIN_BOOTSTRAP_PASSCODE?.trim();
  if (configuredPasscode) {
    const provided = String(body.bootstrapPasscode || '');
    if (provided !== configuredPasscode) {
      return jsonError('Invalid admin bootstrap passcode.', 403);
    }
  } else if (!isStaffBootstrapRequired()) {
    return jsonError('Initial admin account has already been claimed.', 409);
  }

  const email = String(body.email || '').trim().toLowerCase();
  const name = String(body.name || '').trim();
  const password = String(body.password || '');

  if (!email || !email.includes('@') || !name || password.length < 8) {
    return jsonError('Valid email, name, and password (min 8 characters) are required.');
  }

  try {
    const adminUser = bootstrapFirstAdmin({ email, name, password });
    const { rawToken } = createSessionForUser(adminUser.id, 'admin');
    const res = NextResponse.json({ user: adminUser }, { status: 201 });
    attachSessionCookie(res, rawToken);
    return res;
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Unable to claim admin account.', 409);
  }
}
