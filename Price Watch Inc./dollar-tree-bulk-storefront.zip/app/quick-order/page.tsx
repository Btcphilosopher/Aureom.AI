import React from 'react';
import Link from 'next/link';
import { StorefrontShell } from '@/components/StorefrontShell';
import { QuickBulkOrderPanel } from '@/components/QuickBulkOrderPanel';

export default function QuickOrderPage() {
  return (
    <StorefrontShell>
      <div className="max-w-[1160px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 pb-5">
          <div>
            <h1 className="font-display text-3xl font-extrabold text-[#0A4D1F]">
              Quick Bulk Order & CSV Import
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Enter SKUs directly or upload a CSV list. Every line is validated for case increments and stock before updating your cart.
            </p>
          </div>
          <Link href="/business" className="text-sm font-bold text-[#0F6B2E] hover:underline">
            Go to Business Purchasing Hub →
          </Link>
        </div>

        <QuickBulkOrderPanel />
      </div>
    </StorefrontShell>
  );
}
