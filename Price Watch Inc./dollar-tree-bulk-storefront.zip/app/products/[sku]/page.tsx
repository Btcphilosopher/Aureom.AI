import React from 'react';
import { notFound } from 'next/navigation';
import { StorefrontShell } from '@/components/StorefrontShell';
import { ProductDetailView } from '@/components/ProductDetailView';
import { getProductDetail } from '@/lib/services/catalogue';

export const dynamic = 'force-dynamic';

export default async function ProductDetailPage({
  params,
}: {
  params: Promise<{ sku: string }>;
}) {
  const { sku } = await params;
  const detail = getProductDetail(sku);

  if (!detail.product) {
    notFound();
  }

  return (
    <StorefrontShell activeCategory={detail.product.categorySlug}>
      <ProductDetailView
        product={detail.product}
        variants={detail.variants}
        related={detail.related}
      />
    </StorefrontShell>
  );
}
