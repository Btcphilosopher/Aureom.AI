'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import {
  Boxes,
  CheckCircle2,
  ClipboardList,
  Image as ImageIcon,
  Layers,
  Megaphone,
  RefreshCw,
  ShieldCheck,
  Users,
} from 'lucide-react';
import { StorefrontShell } from '@/components/StorefrontShell';
import { useStorefront } from '@/components/StorefrontProvider';
import {
  DELIVERY_TRANSITIONS,
  PICKUP_TRANSITIONS,
  STAFF_ROLES,
  type StaffRole,
} from '@/lib/config';
import { formatUsd } from '@/lib/pricing';
import type { ProductCatalogItem } from '@/lib/services/catalogue';
import type { OrderDetailView } from '@/lib/services/orders';

interface AdminOverviewData {
  user: { id: string; email: string; name: string; role: StaffRole };
  products: ProductCatalogItem[];
  categories: Array<{ id: string; slug: string; name: string }>;
  locations: Array<{ id: string; name: string; type: string }>;
  orders: OrderDetailView[];
  banners: Array<{
    id: string;
    slot: string;
    headline: string;
    subheadline: string;
    cta_label: string;
    cta_href: string;
    active: number;
  }>;
  auditLogs: Array<{
    id: string;
    actor_email: string;
    actor_role: string;
    action: string;
    entity_type: string;
    entity_id: string;
    details_json: string;
    created_at: string;
  }>;
  reservations: Array<{
    id: string;
    order_attempt_id: string;
    sku: string;
    location_id: string;
    cases_reserved: number;
    status: string;
    expires_at: string;
  }>;
  staffUsers: Array<{
    id: string;
    email: string;
    name: string;
    role: string;
    created_at: string;
  }>;
}

export default function AdminPage() {
  const { user, bootstrapRequired, refreshSession } = useStorefront();

  const [tab, setTab] = useState<'orders' | 'inventory' | 'catalogue' | 'banners' | 'audit'>(
    'orders'
  );
  const [data, setData] = useState<AdminOverviewData | null>(null);
  const [loading, setLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Claim / Login state
  const [claimName, setClaimName] = useState('Operations Admin');
  const [claimEmail, setClaimEmail] = useState('');
  const [claimPassword, setClaimPassword] = useState('');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Catalogue edit / create state
  const [newSku, setNewSku] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newCatId, setNewCatId] = useState('cat-cleaning');
  const [newUnit, setNewUnit] = useState('item');
  const [newUnitsPerCase, setNewUnitsPerCase] = useState('24');
  const [newCasePriceDollars, setNewCasePriceDollars] = useState('30.00');
  const [uploadedImgUrl, setUploadedImgUrl] = useState('/images/products/dish-soap.jpg');

  // Price edit inline
  const [editingSku, setEditingSku] = useState<string | null>(null);
  const [editPriceDollars, setEditPriceDollars] = useState('');

  // Inventory adjustment
  const [adjSku, setAdjSku] = useState('DT-CLN-1001');
  const [adjLoc, setAdjLoc] = useState('LOC-DC-EAST');
  const [adjDelta, setAdjDelta] = useState('10');
  const [adjReason, setAdjReason] = useState('Warehouse cycle count replenishment');

  // Refund input
  const [refundOrderId, setRefundOrderId] = useState<string | null>(null);
  const [refundDollars, setRefundDollars] = useState('');
  const [refundReason, setRefundReason] = useState('Damaged cases reported on delivery');

  // Staff provisioning
  const [staffEmail, setStaffEmail] = useState('');
  const [staffName, setStaffName] = useState('');
  const [staffPw, setStaffPw] = useState('');
  const [staffRole, setStaffRole] = useState<StaffRole>('fulfilment_staff');

  const isStaff = Boolean(user && STAFF_ROLES.includes(user.role));

  const loadOverview = useCallback(async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch('/api/admin/overview', { cache: 'no-store' });
      const json = await res.json();
      if (!res.ok) {
        setErrorMsg(json.error || 'Access denied.');
        return;
      }
      setData(json);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!isStaff) return;
    let active = true;
    void fetch('/api/admin/overview', { cache: 'no-store' })
      .then(async (res) => ({ ok: res.ok, json: await res.json() }))
      .then(({ ok, json }) => {
        if (!active) return;
        if (!ok) {
          setErrorMsg(json.error || 'Access denied.');
        } else {
          setData(json);
          setErrorMsg(null);
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [isStaff]);

  const handleBootstrapClaim = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const res = await fetch('/api/auth/bootstrap-admin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        name: claimName,
        email: claimEmail,
        password: claimPassword,
      }),
    });
    const json = await res.json();
    if (!res.ok) {
      setErrorMsg(json.error || 'Could not claim admin.');
      return;
    }
    await refreshSession();
    setStatusMsg('First-run admin account claimed and signed in.');
  };

  const handleStaffLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({ email: loginEmail, password: loginPassword }),
    });
    const json = await res.json();
    if (!res.ok) {
      setErrorMsg(json.error || 'Invalid credentials.');
      return;
    }
    await refreshSession();
  };

  const handleTransition = async (orderId: string, nextStatus: string) => {
    setStatusMsg(null);
    setErrorMsg(null);
    const res = await fetch(`/api/admin/orders/${encodeURIComponent(orderId)}/transition`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({ nextStatus, note: `Updated via Admin Console` }),
    });
    const json = await res.json();
    if (!res.ok) {
      setErrorMsg(json.error || 'Transition failed.');
      return;
    }
    setStatusMsg(`Order ${orderId} transitioned to "${nextStatus}".`);
    await loadOverview();
  };

  const handleRefundSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refundOrderId) return;
    setErrorMsg(null);
    const amountCents = Math.round(Number(refundDollars) * 100);
    const res = await fetch(`/api/admin/orders/${encodeURIComponent(refundOrderId)}/refund`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({ amountCents, reason: refundReason }),
    });
    const json = await res.json();
    if (!res.ok) {
      setErrorMsg(json.error || 'Refund failed.');
      return;
    }
    setRefundOrderId(null);
    setRefundDollars('');
    setStatusMsg(`Refund processed for order ${refundOrderId}.`);
    await loadOverview();
  };

  const handleAdjustInventory = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const res = await fetch('/api/admin/inventory', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        sku: adjSku,
        locationId: adjLoc,
        deltaCases: Number(adjDelta),
        reason: adjReason,
      }),
    });
    const json = await res.json();
    if (!res.ok) {
      setErrorMsg(json.error || 'Adjustment failed.');
      return;
    }
    setStatusMsg(`Inventory updated for ${adjSku} at ${adjLoc} (On-hand: ${json.onHandCases}).`);
    await loadOverview();
  };

  const handleWorkerSweep = async () => {
    const res = await fetch('/api/internal/worker/sweep', {
      method: 'POST',
      headers: { 'X-Requested-With': 'fetch' },
    });
    const json = await res.json();
    if (res.ok) {
      setStatusMsg(
        `Reservation expiry sweep complete: ${json.expiredReservationCount} expired, ${json.releasedCasesTotal} cases released.`
      );
      await loadOverview();
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    const res = await fetch('/api/admin/upload', {
      method: 'POST',
      headers: { 'X-Requested-With': 'fetch' },
      body: fd,
    });
    const json = await res.json();
    if (!res.ok) {
      setErrorMsg(json.error || 'Upload failed.');
      return;
    }
    setUploadedImgUrl(json.url);
    setStatusMsg(`Uploaded verified ${json.format.toUpperCase()} image to ${json.url}`);
  };

  const handleCreateSku = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const casePriceCents = Math.round(Number(newCasePriceDollars) * 100);
    const res = await fetch('/api/admin/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        sku: newSku,
        title: newTitle,
        categoryId: newCatId,
        consumerSellingUnit: newUnit,
        consumerUnitsPerCase: Number(newUnitsPerCase),
        casePriceCents,
        image: uploadedImgUrl,
      }),
    });
    const json = await res.json();
    if (!res.ok) {
      setErrorMsg(json.error || 'Could not create SKU.');
      return;
    }
    setNewSku('');
    setNewTitle('');
    setStatusMsg(`Created SKU ${json.sku}.`);
    await loadOverview();
  };

  const handleUpdatePrice = async (sku: string) => {
    setErrorMsg(null);
    const casePriceCents = Math.round(Number(editPriceDollars) * 100);
    const res = await fetch('/api/admin/products', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({ sku, casePriceCents }),
    });
    const json = await res.json();
    if (!res.ok) {
      setErrorMsg(json.error || 'Update failed.');
      return;
    }
    setEditingSku(null);
    setStatusMsg(
      json.openOrdersWarning
        ? `Updated ${sku} price. ${json.openOrdersWarning}`
        : `Updated ${sku} case price.`
    );
    await loadOverview();
  };

  const handleUpdateBanner = async (b: AdminOverviewData['banners'][number]) => {
    const res = await fetch('/api/admin/banners', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        slot: b.slot,
        headline: b.headline,
        subheadline: b.subheadline,
        ctaLabel: b.cta_label,
        ctaHref: b.cta_href,
        active: b.active !== 0,
      }),
    });
    if (res.ok) {
      setStatusMsg(`Updated "${b.slot}" homepage banner.`);
      await loadOverview();
    }
  };

  const handleCreateStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const res = await fetch('/api/admin/staff', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({
        email: staffEmail,
        name: staffName,
        password: staffPw,
        role: staffRole,
      }),
    });
    const json = await res.json();
    if (!res.ok) {
      setErrorMsg(json.error || 'Staff creation failed.');
      return;
    }
    setStaffEmail('');
    setStaffName('');
    setStaffPw('');
    setStatusMsg(`Created ${json.role} account for ${json.email}.`);
    await loadOverview();
  };

  return (
    <StorefrontShell>
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-5">
          <div>
            <h1 className="font-display text-3xl font-extrabold text-[#0A4D1F] flex items-center gap-2.5">
              <ShieldCheck className="w-7 h-7 text-[#0F6B2E]" />
              <span>Storefront Operations & Administration</span>
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Role-scoped management for catalogue, pricing, inventory, fulfilment transitions, refunds, banners, and audit logs.
            </p>
          </div>
          {isStaff && (
            <button
              type="button"
              onClick={() => void loadOverview()}
              className="h-9 px-4 rounded-lg border border-slate-300 text-xs font-bold inline-flex items-center gap-1.5 hover:bg-slate-50"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh console</span>
            </button>
          )}
        </div>

        {statusMsg && (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-bold text-[#0A4D1F] flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#0F6B2E]" />
            <span>{statusMsg}</span>
          </div>
        )}
        {errorMsg && (
          <div role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs font-bold text-red-900">
            {errorMsg}
          </div>
        )}

        {!isStaff ? (
          <div className="max-w-lg mx-auto space-y-6">
            {bootstrapRequired ? (
              <form
                onSubmit={(e) => void handleBootstrapClaim(e)}
                className="rounded-2xl border border-[#137A35] bg-emerald-50/40 p-6 space-y-4"
              >
                <div>
                  <h2 className="font-display text-xl font-extrabold text-[#0A4D1F]">
                    First-Run Administrator Setup
                  </h2>
                  <p className="text-xs text-slate-700 mt-1">
                    No administrator has been claimed yet. Choose your initial administrator credentials to lock bootstrap setup and access operations.
                  </p>
                </div>
                <div>
                  <label htmlFor="claim-name" className="block text-xs font-bold text-slate-700 mb-1">
                    Admin Name
                  </label>
                  <input
                    id="claim-name"
                    required
                    type="text"
                    value={claimName}
                    onChange={(e) => setClaimName(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="claim-email" className="block text-xs font-bold text-slate-700 mb-1">
                    Admin Email
                  </label>
                  <input
                    id="claim-email"
                    required
                    type="email"
                    value={claimEmail}
                    onChange={(e) => setClaimEmail(e.target.value)}
                    placeholder="admin@storefront.local"
                    className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="claim-pw" className="block text-xs font-bold text-slate-700 mb-1">
                    Password (min 8 chars)
                  </label>
                  <input
                    id="claim-pw"
                    required
                    minLength={8}
                    type="password"
                    value={claimPassword}
                    onChange={(e) => setClaimPassword(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full h-11 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-sm"
                >
                  Claim Administrator Account
                </button>
              </form>
            ) : (
              <form
                onSubmit={(e) => void handleStaffLogin(e)}
                className="rounded-2xl border border-slate-200 bg-white p-6 space-y-4"
              >
                <h2 className="font-display text-xl font-extrabold text-slate-900">
                  Staff Sign-In Required
                </h2>
                {user && !isStaff && (
                  <p className="text-xs text-amber-800 bg-amber-50 p-3 rounded-lg border border-amber-200">
                    Signed in as customer ({user.email}). Please sign in with a staff account (admin, catalogue manager, fulfilment staff, or customer service).
                  </p>
                )}
                <div>
                  <label htmlFor="stf-email" className="block text-xs font-bold text-slate-700 mb-1">
                    Staff Email
                  </label>
                  <input
                    id="stf-email"
                    required
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="stf-pw" className="block text-xs font-bold text-slate-700 mb-1">
                    Password
                  </label>
                  <input
                    id="stf-pw"
                    required
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full h-11 rounded-xl bg-[#137A35] hover:bg-[#0F6B2E] text-white font-bold text-sm"
                >
                  Sign In to Staff Console
                </button>
              </form>
            )}
          </div>
        ) : loading || !data ? (
          <div className="h-64 rounded-2xl border border-slate-200 bg-slate-50 animate-pulse" />
        ) : (
          <div className="space-y-6">
            {/* Role & Tabs */}
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap gap-2">
                {[
                  { id: 'orders', label: 'Orders & Fulfilment', icon: ClipboardList },
                  { id: 'inventory', label: 'Inventory & Reservations', icon: Boxes },
                  { id: 'catalogue', label: 'Catalogue & Prices', icon: Layers },
                  { id: 'banners', label: 'Homepage Banners', icon: Megaphone },
                  { id: 'audit', label: 'Audit Log & Staff', icon: Users },
                ].map((t) => {
                  const Icon = t.icon;
                  const active = tab === t.id;
                  return (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setTab(t.id as typeof tab)}
                      className={`h-10 px-4 rounded-xl text-xs font-bold inline-flex items-center gap-2 border transition-colors ${
                        active
                          ? 'bg-[#0F6B2E] border-[#0F6B2E] text-white'
                          : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{t.label}</span>
                    </button>
                  );
                })}
              </div>

              <span className="text-xs font-semibold text-slate-600">
                Active role: <strong className="text-[#0F6B2E]">{data.user.role}</strong>
              </span>
            </div>

            {/* Tab 1: Orders & Fulfilment */}
            {tab === 'orders' && (
              <div className="space-y-4">
                {data.orders.length === 0 ? (
                  <div className="rounded-2xl border border-slate-200 p-10 text-center text-sm text-slate-500">
                    No orders yet. Complete a checkout flow to manage fulfilment and refunds here.
                  </div>
                ) : (
                  data.orders.map((order) => {
                    const allowedMap =
                      order.fulfilmentMethod === 'pickup'
                        ? PICKUP_TRANSITIONS
                        : DELIVERY_TRANSITIONS;
                    const nextOptions =
                      order.paymentStatus === 'paid' || order.paymentStatus === 'partially_refunded'
                        ? allowedMap[order.fulfilmentStatus] ?? []
                        : [];

                    return (
                      <div
                        key={order.id}
                        className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-4">
                          <div>
                            <div className="flex items-center gap-3">
                              <Link
                                href={`/orders/${order.id}`}
                                className="font-mono text-base font-bold text-[#0F6B2E] hover:underline"
                              >
                                {order.id}
                              </Link>
                              <span className="text-xs font-semibold text-slate-600 capitalize">
                                {order.fulfilmentMethod} · {order.locationNameSnapshot}
                              </span>
                            </div>
                            <p className="text-xs text-slate-600 mt-1">
                              {order.customerName} ({order.customerEmail}) ·{' '}
                              {new Date(order.createdAt).toLocaleString()}
                            </p>
                            <p className="text-xs mt-1 text-slate-800">
                              Order: <strong>{order.orderStatus}</strong> · Payment:{' '}
                              <strong>{order.paymentStatus}</strong> · Fulfilment:{' '}
                              <strong>{order.fulfilmentStatus.replace(/_/g, ' ')}</strong>
                            </p>
                          </div>

                          <div className="text-right">
                            <p className="text-lg font-extrabold text-slate-900 tabular-nums">
                              {formatUsd(order.totalCents)}
                            </p>
                            <p className="text-xs text-slate-500">
                              {order.items.reduce((s, i) => s + i.casesOrdered, 0)} cases
                            </p>
                          </div>
                        </div>

                        {/* Snapshot lines */}
                        <div className="bg-slate-50 rounded-xl p-3 text-xs space-y-1">
                          {order.items.map((item) => (
                            <div key={item.id} className="flex justify-between">
                              <span>
                                <strong className="font-mono">{item.sku}</strong> · {item.titleSnapshot} ({item.casesOrdered} cases)
                              </span>
                              <span className="font-bold tabular-nums">
                                {formatUsd(item.lineSubtotalCents)} (snapshot: {formatUsd(item.casePriceCentsSnapshot)}/case)
                              </span>
                            </div>
                          ))}
                        </div>

                        {/* Staff Controls */}
                        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                          <div className="flex flex-wrap items-center gap-2">
                            {nextOptions.map((next) => (
                              <button
                                key={next}
                                type="button"
                                onClick={() => void handleTransition(order.id, next)}
                                className="h-8 px-3 rounded-lg bg-[#137A35] hover:bg-[#0F6B2E] text-white text-xs font-bold capitalize"
                              >
                                Advance → {next.replace(/_/g, ' ')}
                              </button>
                            ))}
                          </div>

                          {(order.paymentStatus === 'paid' ||
                            order.paymentStatus === 'partially_refunded') && (
                            <button
                              type="button"
                              onClick={() => {
                                setRefundOrderId(order.id);
                                setRefundDollars((order.totalCents / 100).toFixed(2));
                              }}
                              className="h-8 px-3 rounded-lg border border-amber-400 text-amber-900 hover:bg-amber-50 text-xs font-bold"
                            >
                              Issue Refund
                            </button>
                          )}
                        </div>

                        {refundOrderId === order.id && (
                          <form
                            onSubmit={(e) => void handleRefundSubmit(e)}
                            className="p-3 rounded-xl border border-amber-200 bg-amber-50 flex flex-wrap items-end gap-2 text-xs"
                          >
                            <div>
                              <label className="block font-bold mb-1">Refund USD</label>
                              <input
                                type="number"
                                step="0.01"
                                min="0.01"
                                required
                                value={refundDollars}
                                onChange={(e) => setRefundDollars(e.target.value)}
                                className="h-8 w-28 px-2 rounded border border-amber-300 bg-white"
                              />
                            </div>
                            <div className="flex-1 min-w-[180px]">
                              <label className="block font-bold mb-1">Reason</label>
                              <input
                                type="text"
                                required
                                value={refundReason}
                                onChange={(e) => setRefundReason(e.target.value)}
                                className="h-8 w-full px-2 rounded border border-amber-300 bg-white"
                              />
                            </div>
                            <button
                              type="submit"
                              className="h-8 px-3 rounded bg-amber-900 text-white font-bold"
                            >
                              Confirm Refund
                            </button>
                            <button
                              type="button"
                              onClick={() => setRefundOrderId(null)}
                              className="h-8 px-2 text-slate-600 font-bold"
                            >
                              Cancel
                            </button>
                          </form>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            )}

            {/* Tab 2: Inventory & Reservations */}
            {tab === 'inventory' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  <form
                    onSubmit={(e) => void handleAdjustInventory(e)}
                    className="lg:col-span-5 rounded-2xl border border-slate-200 p-5 bg-white space-y-3"
                  >
                    <h2 className="text-base font-extrabold text-slate-900">
                      Adjust Inventory by Location
                    </h2>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">SKU</label>
                      <select
                        value={adjSku}
                        onChange={(e) => setAdjSku(e.target.value)}
                        className="w-full h-9 px-2.5 rounded-lg border border-slate-300 text-xs font-mono bg-white"
                      >
                        {data.products.map((p) => (
                          <option key={p.sku} value={p.sku}>
                            {p.sku} — {p.title}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Location</label>
                      <select
                        value={adjLoc}
                        onChange={(e) => setAdjLoc(e.target.value)}
                        className="w-full h-9 px-2.5 rounded-lg border border-slate-300 text-xs bg-white"
                      >
                        {data.locations.map((l) => (
                          <option key={l.id} value={l.id}>
                            {l.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Delta Cases (+/-)
                        </label>
                        <input
                          type="number"
                          required
                          value={adjDelta}
                          onChange={(e) => setAdjDelta(e.target.value)}
                          className="w-full h-9 px-3 rounded-lg border border-slate-300 text-xs font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Reason</label>
                        <input
                          type="text"
                          required
                          value={adjReason}
                          onChange={(e) => setAdjReason(e.target.value)}
                          className="w-full h-9 px-3 rounded-lg border border-slate-300 text-xs"
                        />
                      </div>
                    </div>
                    <button
                      type="submit"
                      className="w-full h-10 rounded-xl bg-[#137A35] text-white text-xs font-bold"
                    >
                      Apply Inventory Adjustment
                    </button>
                  </form>

                  <div className="lg:col-span-7 rounded-2xl border border-slate-200 p-5 bg-white space-y-3">
                    <div className="flex items-center justify-between">
                      <h2 className="text-base font-extrabold text-slate-900">
                        Active & Recent Stock Reservations
                      </h2>
                      <button
                        type="button"
                        onClick={() => void handleWorkerSweep()}
                        className="h-8 px-3 rounded-lg border border-[#137A35] text-[#0F6B2E] text-xs font-bold hover:bg-emerald-50"
                      >
                        Run Reservation Expiry Sweep
                      </button>
                    </div>
                    <div className="max-h-60 overflow-y-auto text-xs divide-y divide-slate-100">
                      {data.reservations.length === 0 ? (
                        <p className="text-slate-500 py-4">No checkout reservations recorded yet.</p>
                      ) : (
                        data.reservations.map((r) => (
                          <div key={r.id} className="py-2 flex items-center justify-between gap-2">
                            <div>
                              <span className="font-mono font-bold">{r.sku}</span> @ {r.location_id} ·{' '}
                              <strong>{r.cases_reserved} cases</strong> ({r.order_attempt_id})
                            </div>
                            <span className="font-bold capitalize text-slate-700">{r.status}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                {/* Location Inventory Matrix */}
                <div className="rounded-2xl border border-slate-200 bg-white overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 font-bold text-slate-600">
                      <tr>
                        <th className="py-2.5 px-4">SKU</th>
                        <th className="py-2.5 px-4">Product</th>
                        {data.locations.map((l) => (
                          <th key={l.id} className="py-2.5 px-4 text-right">
                            {l.name.split('—')[0]} (ATP / Res)
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {data.products.map((p) => (
                        <tr key={p.sku}>
                          <td className="py-2.5 px-4 font-mono">{p.sku}</td>
                          <td className="py-2.5 px-4 font-semibold">{p.title}</td>
                          {data.locations.map((l) => {
                            const loc = p.locationAvailability.find((a) => a.locationId === l.id);
                            return (
                              <td key={l.id} className="py-2.5 px-4 text-right tabular-nums">
                                <span className="font-bold text-[#0F6B2E]">
                                  {loc?.availableCases ?? 0}
                                </span>{' '}
                                <span className="text-slate-400">/ {loc?.reservedCases ?? 0}</span>
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab 3: Catalogue & Prices */}
            {tab === 'catalogue' && (
              <div className="space-y-6">
                <form
                  onSubmit={(e) => void handleCreateSku(e)}
                  className="rounded-2xl border border-slate-200 p-5 bg-white space-y-4"
                >
                  <h2 className="text-base font-extrabold text-slate-900">Create New Case SKU</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <input
                      type="text"
                      required
                      value={newSku}
                      onChange={(e) => setNewSku(e.target.value.toUpperCase())}
                      placeholder="SKU e.g. DT-CLN-9001"
                      className="h-9 px-3 rounded-lg border border-slate-300 font-mono"
                    />
                    <input
                      type="text"
                      required
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="Product title"
                      className="h-9 px-3 rounded-lg border border-slate-300 sm:col-span-2"
                    />
                    <select
                      value={newCatId}
                      onChange={(e) => setNewCatId(e.target.value)}
                      className="h-9 px-2.5 rounded-lg border border-slate-300 bg-white"
                    >
                      {data.categories.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      required
                      value={newUnit}
                      onChange={(e) => setNewUnit(e.target.value)}
                      placeholder="Consumer unit (bottle, pack, item)"
                      className="h-9 px-3 rounded-lg border border-slate-300"
                    />
                    <input
                      type="number"
                      min={1}
                      required
                      value={newUnitsPerCase}
                      onChange={(e) => setNewUnitsPerCase(e.target.value)}
                      placeholder="Units per case"
                      className="h-9 px-3 rounded-lg border border-slate-300"
                    />
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      required
                      value={newCasePriceDollars}
                      onChange={(e) => setNewCasePriceDollars(e.target.value)}
                      placeholder="Case price USD"
                      className="h-9 px-3 rounded-lg border border-slate-300"
                    />
                    <label className="h-9 px-3 rounded-lg border border-slate-300 flex items-center gap-2 cursor-pointer bg-slate-50">
                      <ImageIcon className="w-4 h-4 text-[#0F6B2E]" />
                      <span className="truncate">Upload image (PNG/JPG/WEBP)</span>
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        onChange={(e) => void handleImageUpload(e)}
                        className="sr-only"
                      />
                    </label>
                    <button
                      type="submit"
                      className="h-9 rounded-lg bg-[#137A35] text-white font-bold"
                    >
                      Add SKU to Catalogue
                    </button>
                  </div>
                </form>

                <div className="rounded-2xl border border-slate-200 bg-white overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 font-bold text-slate-600">
                      <tr>
                        <th className="py-2.5 px-4">SKU</th>
                        <th className="py-2.5 px-4">Title</th>
                        <th className="py-2.5 px-4">Packaging</th>
                        <th className="py-2.5 px-4 text-right">Case Price</th>
                        <th className="py-2.5 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {data.products.map((p) => (
                        <tr key={p.sku}>
                          <td className="py-2.5 px-4 font-mono">{p.sku}</td>
                          <td className="py-2.5 px-4 font-bold text-slate-900">{p.title}</td>
                          <td className="py-2.5 px-4 text-slate-600">{p.packaging.caseContentsLabel}</td>
                          <td className="py-2.5 px-4 text-right font-bold tabular-nums">
                            {editingSku === p.sku ? (
                              <input
                                type="number"
                                step="0.01"
                                value={editPriceDollars}
                                onChange={(e) => setEditPriceDollars(e.target.value)}
                                className="w-24 h-7 px-2 rounded border border-slate-300 text-right"
                              />
                            ) : (
                              formatUsd(p.packaging.casePriceCents)
                            )}
                          </td>
                          <td className="py-2.5 px-4 text-right">
                            {editingSku === p.sku ? (
                              <div className="inline-flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => void handleUpdatePrice(p.sku)}
                                  className="px-2.5 py-1 rounded bg-[#137A35] text-white font-bold"
                                >
                                  Save
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingSku(null)}
                                  className="text-slate-500 font-bold"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingSku(p.sku);
                                  setEditPriceDollars(
                                    (p.packaging.casePriceCents / 100).toFixed(2)
                                  );
                                }}
                                className="text-[#0F6B2E] font-bold hover:underline"
                              >
                                Edit price
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab 4: Homepage Banners */}
            {tab === 'banners' && (
              <div className="space-y-4">
                {data.banners.map((b, idx) => (
                  <div
                    key={b.id}
                    className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3"
                  >
                    <p className="text-xs font-mono font-bold text-[#0F6B2E] uppercase">
                      Slot: {b.slot}
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <input
                        type="text"
                        value={b.headline}
                        onChange={(e) => {
                          const next = [...data.banners];
                          next[idx] = { ...b, headline: e.target.value };
                          setData({ ...data, banners: next });
                        }}
                        placeholder="Headline"
                        className="h-9 px-3 rounded-lg border border-slate-300 font-bold"
                      />
                      <input
                        type="text"
                        value={b.subheadline}
                        onChange={(e) => {
                          const next = [...data.banners];
                          next[idx] = { ...b, subheadline: e.target.value };
                          setData({ ...data, banners: next });
                        }}
                        placeholder="Subheadline"
                        className="h-9 px-3 rounded-lg border border-slate-300"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => void handleUpdateBanner(b)}
                      className="h-9 px-4 rounded-lg bg-[#137A35] text-white text-xs font-bold"
                    >
                      Save Banner
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Tab 5: Audit Log & Staff */}
            {tab === 'audit' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {data.user.role === 'admin' && (
                  <form
                    onSubmit={(e) => void handleCreateStaff(e)}
                    className="lg:col-span-5 rounded-2xl border border-slate-200 bg-white p-5 space-y-3 text-xs"
                  >
                    <h2 className="text-base font-extrabold text-slate-900">
                      Provision Staff Account
                    </h2>
                    <input
                      type="text"
                      required
                      value={staffName}
                      onChange={(e) => setStaffName(e.target.value)}
                      placeholder="Staff member name"
                      className="w-full h-9 px-3 rounded-lg border border-slate-300"
                    />
                    <input
                      type="email"
                      required
                      value={staffEmail}
                      onChange={(e) => setStaffEmail(e.target.value)}
                      placeholder="Staff email"
                      className="w-full h-9 px-3 rounded-lg border border-slate-300"
                    />
                    <input
                      type="password"
                      required
                      minLength={8}
                      value={staffPw}
                      onChange={(e) => setStaffPw(e.target.value)}
                      placeholder="Password (min 8 chars)"
                      className="w-full h-9 px-3 rounded-lg border border-slate-300"
                    />
                    <select
                      value={staffRole}
                      onChange={(e) => setStaffRole(e.target.value as StaffRole)}
                      className="w-full h-9 px-2.5 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value="catalogue_manager">Catalogue Manager</option>
                      <option value="fulfilment_staff">Fulfilment Staff</option>
                      <option value="customer_service">Customer Service</option>
                      <option value="admin">Administrator</option>
                    </select>
                    <button
                      type="submit"
                      className="w-full h-9 rounded-lg bg-[#137A35] text-white font-bold"
                    >
                      Create Staff Role
                    </button>
                  </form>
                )}

                <div className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
                  <h2 className="text-base font-extrabold text-slate-900">Audit History</h2>
                  <div className="max-h-96 overflow-y-auto divide-y divide-slate-100 text-xs">
                    {data.auditLogs.map((a) => (
                      <div key={a.id} className="py-2.5 space-y-0.5">
                        <div className="flex justify-between font-bold text-slate-900">
                          <span>{a.action}</span>
                          <span className="font-mono text-slate-500">
                            {new Date(a.created_at).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-slate-600">
                          Actor: {a.actor_email} ({a.actor_role}) · Target: {a.entity_type} {a.entity_id}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </StorefrontShell>
  );
}
