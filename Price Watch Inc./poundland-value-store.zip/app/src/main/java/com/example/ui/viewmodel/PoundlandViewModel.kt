package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BasketItem
import com.example.data.model.OrderEntity
import com.example.data.model.Product
import com.example.data.model.ShoppingListEntity
import com.example.data.model.Store
import com.example.data.repository.PoundlandRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

sealed class Screen {
  object Home : Screen()
  object Shop : Screen()
  object Scan : Screen()
  object Stores : Screen()
  object Account : Screen()
  data class ProductDetail(val productId: String) : Screen()
  object Basket : Screen()
  object Checkout : Screen()
  data class OrderConfirmation(val orderId: String) : Screen()
  object ShoppingLists : Screen()
  object StaffAdmin : Screen()
}

data class BasketDisplayItem(
  val product: Product,
  val quantity: Int,
  val savedForLater: Boolean
)

class PoundlandViewModel(application: Application) : AndroidViewModel(application) {
  private val repository = PoundlandRepository(application)

  val allProducts: StateFlow<List<Product>> = repository.allProducts
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allStores: StateFlow<List<Store>> = repository.allStores
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val basketItemsRaw: StateFlow<List<BasketItem>> = repository.basketItems
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val shoppingLists: StateFlow<List<ShoppingListEntity>> = repository.shoppingLists
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val allOrders: StateFlow<List<OrderEntity>> = repository.allOrders
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val auditLogs = repository.auditLogs
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
  val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

  private val _selectedStore = MutableStateFlow<Store?>(null)
  val selectedStore: StateFlow<Store?> = _selectedStore.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _selectedCategory = MutableStateFlow<String?>("All")
  val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

  init {
    viewModelScope.launch {
      repository.seedInitialDataIfNeeded()
    }
  }

  fun navigateTo(screen: Screen) {
    _currentScreen.value = screen
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setSelectedCategory(category: String?) {
    _selectedCategory.value = category
  }

  fun setSelectedStore(store: Store) {
    _selectedStore.value = store
  }

  fun addToBasket(productId: String, quantity: Int = 1) {
    viewModelScope.launch {
      val existing = basketItemsRaw.value.find { it.productId == productId }
      val newQty = (existing?.quantity ?: 0) + quantity
      repository.addBasketItem(productId, newQty)
    }
  }

  fun updateBasketQuantity(productId: String, quantity: Int) {
    viewModelScope.launch {
      if (quantity <= 0) {
        repository.removeBasketItem(productId)
      } else {
        repository.addBasketItem(productId, quantity)
      }
    }
  }

  fun removeFromBasket(productId: String) {
    viewModelScope.launch {
      repository.removeBasketItem(productId)
    }
  }

  fun clearBasket() {
    viewModelScope.launch {
      repository.clearBasket()
    }
  }

  suspend fun getProductById(productId: String): Product? {
    return repository.getProductById(productId)
  }

  suspend fun getProductByBarcode(barcode: String): Product? {
    return repository.getProductByBarcode(barcode)
  }

  fun updateProductDetails(product: Product) {
    viewModelScope.launch {
      repository.updateProduct(product)
    }
  }

  fun saveShoppingList(name: String, itemsJson: String) {
    viewModelScope.launch {
      val id = "list_${System.currentTimeMillis()}"
      repository.saveShoppingList(ShoppingListEntity(id, name, itemsJson))
    }
  }

  fun deleteShoppingList(id: String) {
    viewModelScope.launch {
      repository.deleteShoppingList(id)
    }
  }

  suspend fun createOrder(
    customerName: String,
    email: String,
    storeId: String,
    itemsSummary: String,
    merchandiseTotalPence: Int,
    deliveryFeePence: Int,
    discountPence: Int,
    finalTotalPence: Int,
    fulfilmentType: String,
    paymentMethod: String
  ): String {
    val orderId = "PL-${(100000..999999).random()}"
    val idempotencyKey = UUID.randomUUID().toString()
    val order = OrderEntity(
      orderId = orderId,
      customerName = customerName,
      email = email,
      storeId = storeId,
      itemsSummary = itemsSummary,
      merchandiseTotalPence = merchandiseTotalPence,
      deliveryFeePence = deliveryFeePence,
      discountPence = discountPence,
      finalTotalPence = finalTotalPence,
      status = "Confirmed",
      fulfilmentType = fulfilmentType,
      paymentStatus = "Paid",
      paymentMethod = paymentMethod,
      idempotencyKey = idempotencyKey
    )
    repository.createOrder(order)
    repository.clearBasket()
    return orderId
  }

  fun updateOrderStatus(orderId: String, status: String, staffName: String = "Staff Admin") {
    viewModelScope.launch {
      repository.updateOrderStatus(orderId, status, staffName)
    }
  }
}
