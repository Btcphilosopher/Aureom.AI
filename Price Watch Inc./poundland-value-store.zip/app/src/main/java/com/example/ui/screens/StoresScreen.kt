package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Store
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun StoresScreen(
  stores: List<Store>,
  selectedStore: Store?,
  onSelectStore: (Store) -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  val context = LocalContext.current

  val filteredStores = stores.filter {
    searchQuery.isBlank() ||
      it.name.contains(searchQuery, ignoreCase = true) ||
      it.town.contains(searchQuery, ignoreCase = true) ||
      it.postcode.contains(searchQuery, ignoreCase = true)
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .padding(bottom = 80.dp)
  ) {
    Text(
      text = "Find a Poundland Store",
      fontSize = 22.sp,
      fontWeight = FontWeight.ExtraBold,
      color = TealPrimary
    )
    Spacer(modifier = Modifier.height(12.dp))

    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text("Search by town or postcode (e.g. Birmingham, B4)...") },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(24.dp),
      singleLine = true
    )

    Spacer(modifier = Modifier.height(16.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(filteredStores) { store ->
        val isSelected = selectedStore?.id == store.id

        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isSelected) TealPrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
          ),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(
            modifier = Modifier.padding(16.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Top
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.LocationOn, contentDescription = null, tint = TealPrimary, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = store.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "${store.address}, ${store.town} (${store.postcode})",
                  fontSize = 13.sp,
                  color = Color.DarkGray
                )
              }

              if (isSelected) {
                Surface(
                  color = TealPrimary,
                  shape = RoundedCornerShape(12.dp)
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = YellowAccent, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Selected", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = Color.LightGray.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = "Hours: ${store.openingHours}",
              fontSize = 12.sp,
              color = Color.Gray
            )
            Text(
              text = "Services: ${store.services}",
              fontSize = 12.sp,
              color = TealPrimary,
              fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              OutlinedButton(
                onClick = {
                  val gmmIntentUri = Uri.parse("geo:0,0?q=${Uri.encode("${store.name}, ${store.address}, ${store.town}")}")
                  val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                  mapIntent.setPackage("com.google.android.apps.maps")
                  try {
                    context.startActivity(mapIntent)
                  } catch (e: Exception) {
                    // Fallback to browser or generic intent
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=${Uri.encode(store.name)}"))
                    context.startActivity(browserIntent)
                  }
                },
                modifier = Modifier.weight(1f)
              ) {
                Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Directions")
              }

              Button(
                onClick = { onSelectStore(store) },
                enabled = !isSelected,
                colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black),
                modifier = Modifier.weight(1f)
              ) {
                Text(if (isSelected) "Current Store" else "Select Store")
              }
            }
          }
        }
      }
    }
  }
}
