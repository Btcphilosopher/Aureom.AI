package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Store
import com.example.ui.components.PoundlandBottomBar
import com.example.ui.components.PoundlandTopBar
import com.example.ui.screens.*
import com.example.ui.theme.PoundlandTheme
import com.example.ui.theme.TealPrimary
import com.example.ui.viewmodel.PoundlandViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  private val viewModel: PoundlandViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      PoundlandTheme {
        val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
        val products by viewModel.allProducts.collectAsStateWithLifecycle()
        val stores by viewModel.allStores.collectAsStateWithLifecycle()
        val selectedStore by viewModel.selectedStore.collectAsStateWithLifecycle()
        val basketItems by viewModel.basketItemsRaw.collectAsStateWithLifecycle()
        val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
        val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
        val shoppingLists by viewModel.shoppingLists.collectAsStateWithLifecycle()
        val orders by viewModel.allOrders.collectAsStateWithLifecycle()
        val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

        var showStorePickerDialog by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()

        LaunchedEffect(stores) {
          if (selectedStore == null && stores.isNotEmpty()) {
            viewModel.setSelectedStore(stores.first())
          }
        }

        val totalBasketCount = basketItems.sumOf { it.quantity }

        val activeBottomTab = when (currentScreen) {
          is Screen.Home -> "Home"
          is Screen.Shop -> "Shop"
          is Screen.Scan -> "Scan"
          is Screen.Stores -> "Stores"
          is Screen.Account, is Screen.StaffAdmin -> "Account"
          else -> "Shop"
        }

        Scaffold(
          modifier = Modifier.fillMaxSize(),
          topBar = {
            if (currentScreen !is Screen.OrderConfirmation) {
              PoundlandTopBar(
                title = when (currentScreen) {
                  is Screen.Home -> "Home"
                  is Screen.Shop -> "Shop"
                  is Screen.Scan -> "Barcode Scanner"
                  is Screen.Stores -> "Store Finder"
                  is Screen.Account -> "My Account"
                  is Screen.Basket -> "Basket"
                  is Screen.Checkout -> "Checkout"
                  is Screen.ShoppingLists -> "Shopping Lists"
                  is Screen.StaffAdmin -> "Staff Portal"
                  is Screen.ProductDetail -> "Product"
                  else -> "Poundland"
                },
                selectedStore = selectedStore,
                basketCount = totalBasketCount,
                onStoreClick = { showStorePickerDialog = true },
                onBasketClick = { viewModel.navigateTo(Screen.Basket) }
              )
            }
          },
          bottomBar = {
            if (currentScreen is Screen.Home || currentScreen is Screen.Shop || currentScreen is Screen.Scan || currentScreen is Screen.Stores || currentScreen is Screen.Account) {
              PoundlandBottomBar(
                currentScreen = activeBottomTab,
                basketCount = totalBasketCount,
                onNavigate = { tab ->
                  when (tab) {
                    "Home" -> viewModel.navigateTo(Screen.Home)
                    "Shop" -> viewModel.navigateTo(Screen.Shop)
                    "Scan" -> viewModel.navigateTo(Screen.Scan)
                    "Stores" -> viewModel.navigateTo(Screen.Stores)
                    "Account" -> viewModel.navigateTo(Screen.Account)
                  }
                }
              )
            }
          }
        ) { innerPadding ->
          Box(modifier = Modifier.padding(innerPadding)) {
            when (val screen = currentScreen) {
              is Screen.Home -> {
                HomeScreen(
                  products = products,
                  onSearchClick = { viewModel.navigateTo(Screen.Shop) },
                  onCategoryClick = { category ->
                    viewModel.setSelectedCategory(category)
                    viewModel.navigateTo(Screen.Shop)
                  },
                  onProductClick = { id -> viewModel.navigateTo(Screen.ProductDetail(id)) },
                  onAddToCart = { id -> viewModel.addToBasket(id, 1) },
                  onShoppingListsClick = { viewModel.navigateTo(Screen.ShoppingLists) },
                  onStaffAdminClick = { viewModel.navigateTo(Screen.StaffAdmin) }
                )
              }
              is Screen.Shop -> {
                ShopScreen(
                  products = products,
                  searchQuery = searchQuery,
                  selectedCategory = selectedCategory,
                  onSearchQueryChanged = { viewModel.setSearchQuery(it) },
                  onCategorySelected = { viewModel.setSelectedCategory(it) },
                  onProductClick = { id -> viewModel.navigateTo(Screen.ProductDetail(id)) },
                  onAddToCart = { id -> viewModel.addToBasket(id, 1) }
                )
              }
              is Screen.Scan -> {
                ScanScreen(
                  onLookupBarcode = { barcode -> viewModel.getProductByBarcode(barcode) },
                  onProductClick = { id -> viewModel.navigateTo(Screen.ProductDetail(id)) },
                  onAddToCart = { id -> viewModel.addToBasket(id, 1) }
                )
              }
              is Screen.Stores -> {
                StoresScreen(
                  stores = stores,
                  selectedStore = selectedStore,
                  onSelectStore = { store -> viewModel.setSelectedStore(store) }
                )
              }
              is Screen.Account -> {
                AccountScreen(
                  orders = orders,
                  onStaffAdminClick = { viewModel.navigateTo(Screen.StaffAdmin) },
                  onShoppingListsClick = { viewModel.navigateTo(Screen.ShoppingLists) },
                  onReorderClick = { order ->
                    scope.launch {
                      viewModel.addToBasket("p1", 1)
                      viewModel.navigateTo(Screen.Basket)
                    }
                  }
                )
              }
              is Screen.ProductDetail -> {
                ProductDetailScreen(
                  productId = screen.productId,
                  allProducts = products,
                  onBackClick = { viewModel.navigateTo(Screen.Shop) },
                  onAddToCart = { id, qty -> viewModel.addToBasket(id, qty) },
                  onProductClick = { id -> viewModel.navigateTo(Screen.ProductDetail(id)) }
                )
              }
              is Screen.Basket -> {
                BasketScreen(
                  basketItems = basketItems,
                  allProducts = products,
                  onUpdateQuantity = { id, qty -> viewModel.updateBasketQuantity(id, qty) },
                  onRemoveItem = { id -> viewModel.removeFromBasket(id) },
                  onClearBasket = { viewModel.clearBasket() },
                  onProceedToCheckout = { viewModel.navigateTo(Screen.Checkout) },
                  onContinueShopping = { viewModel.navigateTo(Screen.Shop) }
                )
              }
              is Screen.Checkout -> {
                CheckoutScreen(
                  basketItems = basketItems,
                  allProducts = products,
                  selectedStore = selectedStore,
                  onCompleteOrder = { name, email, storeId, summary, merchTotal, delFee, disc, total, fulfilment, payMethod ->
                    viewModel.createOrder(name, email, storeId, summary, merchTotal, delFee, disc, total, fulfilment, payMethod)
                  },
                  onOrderSuccess = { orderId -> viewModel.navigateTo(Screen.OrderConfirmation(orderId)) },
                  onBackClick = { viewModel.navigateTo(Screen.Basket) }
                )
              }
              is Screen.OrderConfirmation -> {
                OrderConfirmationScreen(
                  orderId = screen.orderId,
                  orders = orders,
                  onViewStaffPortal = { viewModel.navigateTo(Screen.StaffAdmin) },
                  onGoHome = { viewModel.navigateTo(Screen.Home) }
                )
              }
              is Screen.ShoppingLists -> {
                ShoppingListsScreen(
                  shoppingLists = shoppingLists,
                  allProducts = products,
                  onSaveList = { name, json -> viewModel.saveShoppingList(name, json) },
                  onDeleteList = { id -> viewModel.deleteShoppingList(id) },
                  onAddListToBasket = { ids ->
                    scope.launch {
                      ids.forEach { viewModel.addToBasket(it, 1) }
                      viewModel.navigateTo(Screen.Basket)
                    }
                  },
                  onBackClick = { viewModel.navigateTo(Screen.Home) }
                )
              }
              is Screen.StaffAdmin -> {
                StaffAdminScreen(
                  orders = orders,
                  products = products,
                  auditLogs = auditLogs,
                  onUpdateOrderStatus = { orderId, status, staff -> viewModel.updateOrderStatus(orderId, status, staff) },
                  onUpdateProductStock = { prod, newStock -> viewModel.updateProductDetails(prod.copy(stockQuantity = newStock)) },
                  onBackClick = { viewModel.navigateTo(Screen.Home) }
                )
              }
            }
          }
        }

        if (showStorePickerDialog) {
          AlertDialog(
            onDismissRequest = { showStorePickerDialog = false },
            title = { Text("Select Store Location") },
            text = {
              Column {
                stores.forEach { store ->
                  TextButton(
                    onClick = {
                      viewModel.setSelectedStore(store)
                      showStorePickerDialog = false
                    },
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text(store.name, color = TealPrimary)
                  }
                }
              }
            },
            confirmButton = {
              TextButton(onClick = { showStorePickerDialog = false }) {
                Text("Close")
              }
            }
          )
        }
      }
    }
  }
}
