package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.data.model.AuditLogEntity
import com.example.data.model.BasketItem
import com.example.data.model.OrderEntity
import com.example.data.model.Product
import com.example.data.model.ShoppingListEntity
import com.example.data.model.Store
import kotlinx.coroutines.flow.Flow

@Dao
interface PoundlandDao {
  @Query("SELECT * FROM products")
  fun getAllProducts(): Flow<List<Product>>

  @Query("SELECT * FROM products WHERE id = :productId")
  suspend fun getProductById(productId: String): Product?

  @Query("SELECT * FROM products WHERE barcode = :barcode")
  suspend fun getProductByBarcode(barcode: String): Product?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProducts(products: List<Product>)

  @Update
  suspend fun updateProduct(product: Product)

  @Query("SELECT * FROM stores")
  fun getAllStores(): Flow<List<Store>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertStores(stores: List<Store>)

  @Query("SELECT * FROM basket_items")
  fun getBasketItems(): Flow<List<BasketItem>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBasketItem(item: BasketItem)

  @Query("DELETE FROM basket_items WHERE productId = :productId")
  suspend fun removeBasketItem(productId: String)

  @Query("DELETE FROM basket_items")
  suspend fun clearBasket()

  @Query("SELECT * FROM shopping_lists")
  fun getShoppingLists(): Flow<List<ShoppingListEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertShoppingList(list: ShoppingListEntity)

  @Query("DELETE FROM shopping_lists WHERE id = :listId")
  suspend fun deleteShoppingList(listId: String)

  @Query("SELECT * FROM orders ORDER BY createdAt DESC")
  fun getAllOrders(): Flow<List<OrderEntity>>

  @Query("SELECT * FROM orders WHERE orderId = :orderId")
  suspend fun getOrderById(orderId: String): OrderEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrder(order: OrderEntity)

  @Query("UPDATE orders SET status = :status WHERE orderId = :orderId")
  suspend fun updateOrderStatus(orderId: String, status: String)

  @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
  fun getAuditLogs(): Flow<List<AuditLogEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAuditLog(log: AuditLogEntity)
}

@Database(
  entities = [
    Product::class,
    Store::class,
    BasketItem::class,
    ShoppingListEntity::class,
    OrderEntity::class,
    AuditLogEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class PoundlandDatabase : RoomDatabase() {
  abstract fun poundlandDao(): PoundlandDao
}
