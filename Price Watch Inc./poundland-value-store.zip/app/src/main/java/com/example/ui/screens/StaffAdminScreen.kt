package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditLogEntity
import com.example.data.model.OrderEntity
import com.example.data.model.Product
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun StaffAdminScreen(
  orders: List<OrderEntity>,
  products: List<Product>,
  auditLogs: List<AuditLogEntity>,
  onUpdateOrderStatus: (String, String, String) -> Unit,
  onUpdateProductStock: (Product, Int) -> Unit,
  onBackClick: () -> Unit
) {
  var selectedTab by remember { mutableStateOf(0) } // 0: Orders, 1: Products & Stock, 2: Audit Logs
  var staffRole by remember { mutableStateOf("Store Manager") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .padding(bottom = 80.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "Staff Administration Portal",
          fontSize = 20.sp,
          fontWeight = FontWeight.ExtraBold,
          color = TealPrimary
        )
        Text(
          text = "Role: $staffRole",
          fontSize = 12.sp,
          color = Color.Gray
        )
      }

      TextButton(onClick = onBackClick) {
        Text("Exit Portal")
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    TabRow(selectedTabIndex = selectedTab) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = { Text("Orders & Picking") }
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = { Text("Stock & Prices") }
      )
      Tab(
        selected = selectedTab == 2,
        onClick = { selectedTab = 2 },
        text = { Text("Audit Trail") }
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    when (selectedTab) {
      0 -> {
        // Orders list & Status advancement
        if (orders.isEmpty()) {
          Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Text("No customer orders recorded yet.", color = Color.Gray)
          }
        } else {
          LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth().weight(1f)
          ) {
            items(orders) { order ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
              ) {
                Column(modifier = Modifier.padding(16.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text("Order #${order.orderId}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("£%.2f".format(order.finalTotalPence / 100.0), fontWeight = FontWeight.Bold, color = TealPrimary)
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text("Customer: ${order.customerName} (${order.email})", fontSize = 12.sp, color = Color.Gray)
                  Text("Fulfilment: ${order.fulfilmentType} | Status: ${order.status}", fontSize = 12.sp, color = TealPrimary, fontWeight = FontWeight.SemiBold)
                  Text("Items: ${order.itemsSummary}", fontSize = 12.sp, color = Color.DarkGray)

                  Spacer(modifier = Modifier.height(12.dp))

                  // Advancement buttons
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    if (order.status == "Confirmed") {
                      Button(
                        onClick = { onUpdateOrderStatus(order.orderId, "Picking", staffRole) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black)
                      ) {
                        Text("Start Picking", fontSize = 11.sp)
                      }
                    }
                    if (order.status == "Picking") {
                      Button(
                        onClick = {
                          val nextStatus = if (order.fulfilmentType == "Click & Collect") "Ready for collection" else "Dispatched"
                          onUpdateOrderStatus(order.orderId, nextStatus, staffRole)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = TealPrimary)
                      ) {
                        Text(if (order.fulfilmentType == "Click & Collect") "Mark Ready" else "Mark Dispatched", fontSize = 11.sp)
                      }
                    }
                    if (order.status == "Ready for collection" || order.status == "Dispatched") {
                      Button(
                        onClick = {
                          val finalStatus = if (order.fulfilmentType == "Click & Collect") "Collected" else "Delivered"
                          onUpdateOrderStatus(order.orderId, finalStatus, staffRole)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                      ) {
                        Text(if (order.fulfilmentType == "Click & Collect") "Mark Collected" else "Mark Delivered", fontSize = 11.sp)
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      1 -> {
        // Products & Stock
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth().weight(1f)
        ) {
          items(products) { product ->
            Card(
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(8.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(product.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                  Text("SKU: ${product.sku} | Price: ${product.formattedPrice}", fontSize = 12.sp, color = Color.Gray)
                  Text("Stock: ${product.stockQuantity} units", fontSize = 12.sp, color = if (product.inStock) Color(0xFF2E7D32) else Color.Red)
                }

                Button(
                  onClick = { onUpdateProductStock(product, product.stockQuantity + 10) },
                  colors = ButtonDefaults.buttonColors(containerColor = TealPrimary)
                ) {
                  Text("+10 Stock", fontSize = 11.sp)
                }
              }
            }
          }
        }
      }
      2 -> {
        // Audit Logs
        if (auditLogs.isEmpty()) {
          Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Text("No audit records yet.", color = Color.Gray)
          }
        } else {
          LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().weight(1f)
          ) {
            items(auditLogs) { log ->
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(log.action, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TealPrimary)
                    Text(log.staffName, fontSize = 11.sp, color = Color.Gray)
                  }
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(log.details, fontSize = 12.sp, color = Color.DarkGray)
                }
              }
            }
          }
        }
      }
    }
  }
}
