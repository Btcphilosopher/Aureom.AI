package com.example.ui.screens

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun ScanScreen(
  onLookupBarcode: suspend (String) -> Product?,
  onProductClick: (String) -> Unit,
  onAddToCart: (String) -> Unit
) {
  val cameraPermissionState = rememberPermissionState(permission = Manifest.permission.CAMERA)
  var manualBarcode by remember { mutableStateOf("") }
  var scannedProduct by remember { mutableStateOf<Product?>(null) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var lastRefreshedTime by remember { mutableStateOf("") }
  val scope = rememberCoroutineScope()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .padding(bottom = 80.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "Barcode Scanner",
      fontSize = 24.sp,
      fontWeight = FontWeight.ExtraBold,
      color = TealPrimary
    )

    Text(
      text = "Scan any product barcode to check price, stock, and nutritional details in store.",
      fontSize = 13.sp,
      color = Color.Gray,
      textAlign = TextAlign.Center,
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )

    Spacer(modifier = Modifier.height(16.dp))

    // Viewfinder Simulation / Camera Box
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(240.dp)
        .background(Color.Black, RoundedCornerShape(16.dp))
        .border(2.dp, YellowAccent, RoundedCornerShape(16.dp)),
      contentAlignment = Alignment.Center
    ) {
      if (cameraPermissionState.status.isGranted) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            Icons.Default.QrCodeScanner,
            contentDescription = null,
            tint = YellowAccent,
            modifier = Modifier.size(64.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "Camera viewfinder active",
            color = Color.White,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Align barcode within frame or enter below",
            color = Color.LightGray,
            fontSize = 12.sp
          )
        }
      } else {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.padding(16.dp)
        ) {
          Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Camera permission required for live scanning",
            color = Color.White,
            textAlign = TextAlign.Center
          )
          Spacer(modifier = Modifier.height(8.dp))
          Button(
            onClick = { cameraPermissionState.launchPermissionRequest() },
            colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black)
          ) {
            Text("Grant Permission")
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Manual Barcode Entry & Quick Simulate Buttons
    Text(
      text = "Or enter / simulate barcode scan:",
      fontSize = 14.sp,
      fontWeight = FontWeight.SemiBold,
      modifier = Modifier.align(Alignment.Start)
    )

    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      OutlinedTextField(
        value = manualBarcode,
        onValueChange = { manualBarcode = it },
        placeholder = { Text("e.g. 5012345678901") },
        modifier = Modifier.weight(1f),
        singleLine = true,
        shape = RoundedCornerShape(12.dp)
      )

      Button(
        onClick = {
          scope.launch {
            errorMessage = null
            val prod = onLookupBarcode(manualBarcode.trim())
            if (prod != null) {
              scannedProduct = prod
              lastRefreshedTime = SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.UK).format(Date())
            } else {
              errorMessage = "Product not found for barcode: $manualBarcode"
              scannedProduct = null
            }
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = TealPrimary),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.height(56.dp)
      ) {
        Text("Look Up")
      }
    }

    // Quick test buttons for demonstration
    Spacer(modifier = Modifier.height(8.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      OutlinedButton(
        onClick = {
          manualBarcode = "5012345678901"
          scope.launch {
            scannedProduct = onLookupBarcode("5012345678901")
            lastRefreshedTime = SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.UK).format(Date())
          }
        },
        modifier = Modifier.weight(1f)
      ) {
        Text("Scan Fairy Liquid (£1.25)", fontSize = 11.sp)
      }

      OutlinedButton(
        onClick = {
          manualBarcode = "5012345678930"
          scope.launch {
            scannedProduct = onLookupBarcode("5012345678930") // Out of stock example
            lastRefreshedTime = SimpleDateFormat("HH:mm:ss dd/MM/yyyy", Locale.UK).format(Date())
          }
        },
        modifier = Modifier.weight(1f)
      ) {
        Text("Scan Out-of-Stock", fontSize = 11.sp)
      }
    }

    if (errorMessage != null) {
      Spacer(modifier = Modifier.height(16.dp))
      Text(text = errorMessage!!, color = Color.Red, fontWeight = FontWeight.Bold)
    }

    // Scanned Product Display Card
    if (scannedProduct != null) {
      Spacer(modifier = Modifier.height(16.dp))
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
      ) {
        Column(
          modifier = Modifier.padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = scannedProduct!!.name,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
              )
              Text(
                text = "SKU: ${scannedProduct!!.sku} | Barcode: ${scannedProduct!!.barcode}",
                fontSize = 11.sp,
                color = Color.Gray
              )
              Text(
                text = "Pack: ${scannedProduct!!.packContents} (${scannedProduct!!.unitPriceBasis})",
                fontSize = 12.sp,
                color = Color.DarkGray
              )
            }
            Text(
              text = scannedProduct!!.formattedPrice,
              fontSize = 20.sp,
              fontWeight = FontWeight.ExtraBold,
              color = TealPrimary
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (scannedProduct!!.inStock) "In Stock (${scannedProduct!!.stockQuantity} on shelf)" else "Out of Stock at this store",
              fontSize = 12.sp,
              color = if (scannedProduct!!.inStock) Color(0xFF2E7D32) else Color(0xFFD32F2F),
              fontWeight = FontWeight.Bold
            )

            if (lastRefreshedTime.isNotBlank()) {
              Text(
                text = "Refreshed: $lastRefreshedTime",
                fontSize = 10.sp,
                color = Color.Gray
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            OutlinedButton(
              onClick = { onProductClick(scannedProduct!!.id) },
              modifier = Modifier.weight(1f)
            ) {
              Text("View Details")
            }

            Button(
              onClick = { onAddToCart(scannedProduct!!.id) },
              enabled = scannedProduct!!.inStock,
              colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black),
              modifier = Modifier.weight(1f)
            ) {
              Text("Add to Basket")
            }
          }
        }
      }
    }
  }
}
