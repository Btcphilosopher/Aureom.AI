package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.local.PoundlandDao
import com.example.data.local.PoundlandDatabase
import com.example.data.model.AuditLogEntity
import com.example.data.model.BasketItem
import com.example.data.model.OrderEntity
import com.example.data.model.Product
import com.example.data.model.ShoppingListEntity
import com.example.data.model.Store
import kotlinx.coroutines.flow.Flow

class PoundlandRepository(context: Context) {
  private val database = Room.databaseBuilder(
    context.applicationContext,
    PoundlandDatabase::class.java,
    "poundland_db"
  ).fallbackToDestructiveMigration().build()

  private val dao = database.poundlandDao()

  val allProducts: Flow<List<Product>> = dao.getAllProducts()
  val allStores: Flow<List<Store>> = dao.getAllStores()
  val basketItems: Flow<List<BasketItem>> = dao.getBasketItems()
  val shoppingLists: Flow<List<ShoppingListEntity>> = dao.getShoppingLists()
  val allOrders: Flow<List<OrderEntity>> = dao.getAllOrders()
  val auditLogs: Flow<List<AuditLogEntity>> = dao.getAuditLogs()

  suspend fun getProductById(id: String) = dao.getProductById(id)
  suspend fun getProductByBarcode(barcode: String) = dao.getProductByBarcode(barcode)
  suspend fun updateProduct(product: Product) {
    dao.updateProduct(product)
    dao.insertAuditLog(
      AuditLogEntity(
        id = "audit_${System.currentTimeMillis()}",
        staffName = "Manager Store Staff",
        action = "UPDATE_PRODUCT",
        details = "Updated price or stock for SKU ${product.sku} (${product.name})"
      )
    )
  }

  suspend fun addBasketItem(productId: String, quantity: Int) {
    dao.insertBasketItem(BasketItem(productId, quantity))
  }

  suspend fun removeBasketItem(productId: String) {
    dao.removeBasketItem(productId)
  }

  suspend fun clearBasket() {
    dao.clearBasket()
  }

  suspend fun saveShoppingList(list: ShoppingListEntity) {
    dao.insertShoppingList(list)
  }

  suspend fun deleteShoppingList(listId: String) {
    dao.deleteShoppingList(listId)
  }

  suspend fun createOrder(order: OrderEntity): String {
    dao.insertOrder(order)
    dao.insertAuditLog(
      AuditLogEntity(
        id = "audit_${System.currentTimeMillis()}",
        staffName = "System Checkout",
        action = "CREATE_ORDER",
        details = "Order #${order.orderId} placed for £${order.finalTotalPence / 100.0} via ${order.fulfilmentType}"
      )
    )
    return order.orderId
  }

  suspend fun updateOrderStatus(orderId: String, status: String, staffName: String = "Staff Admin") {
    dao.updateOrderStatus(orderId, status)
    dao.insertAuditLog(
      AuditLogEntity(
        id = "audit_${System.currentTimeMillis()}",
        staffName = staffName,
        action = "UPDATE_ORDER_STATUS",
        details = "Advanced Order #$orderId status to '$status'"
      )
    )
  }

  suspend fun seedInitialDataIfNeeded() {
    val stores = listOf(
      Store("store_1", "Birmingham High Street Store", "12 High Street", "Birmingham", "B4 7SL", "Mon-Sat: 8am - 7pm", "Click & Collect, Bakery", true),
      Store("store_2", "London Oxford Street Store", "452 Oxford Street", "London", "W1D 1NS", "Mon-Sat: 8am - 9pm", "Click & Collect, Express"),
      Store("store_3", "Manchester Arndale Store", "Unit 24 Arndale Centre", "Manchester", "M4 3AQ", "Mon-Sat: 8am - 8pm", "Click & Collect, Pharmacy"),
      Store("store_4", "Leeds Trinity Store", "Trinity Shopping Centre", "Leeds", "LS1 5AT", "Mon-Sat: 8.30am - 7pm", "Click & Collect")
    )
    dao.insertStores(stores)

    val products = listOf(
      Product("p1", "PL-1001", "5012345678901", "Fairy Washing-Up Liquid Original", "Food & Drink", "500 ml", 125, "£2.50 per litre", "https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?w=500", true, 45, "store_1", true, true, "Special Value Deal"),
      Product("p2", "PL-1002", "5012345678902", "McVitie's Milk Chocolate Digestives", "Food & Drink", "400 g", 100, "£2.50 per kg", "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=500", true, 80, "store_1", true, false),
      Product("p3", "PL-1003", "5012345678903", "Coca-Cola Original Taste", "Food & Drink", "2 Litre", 145, "£0.73 per litre", "https://images.unsplash.com/photo-1554866585-cd94860890b7?w=500", true, 60, "store_1", false, true, "2 for £2.50 offer"),
      Product("p4", "PL-1004", "5012345678904", "Cadbury Dairy Milk Bar", "Food & Drink", "110 g", 125, "£1.14 per 100g", "https://images.unsplash.com/photo-1548848221-0c3677f52332?w=500", true, 120, "store_1", true, false),
      Product("p5", "PL-1005", "5012345678905", "PG Tips Original Tea Bags", "Food & Drink", "40 bags", 150, "£3.75 per 100", "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=500", true, 40, "store_1", false, false),
      Product("p6", "PL-1006", "5012345678906", "Nescafé Azera Instant Coffee", "Food & Drink", "60 g", 200, "£3.33 per 100g", "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=500", true, 25, "store_1", false, false),
      Product("p7", "PL-1007", "5012345678907", "Walkers Ready Salted Crisps 6 Pack", "Food & Drink", "6 x 25g", 150, "£1.00 per 100g", "https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=500", true, 55, "store_1", true, false),
      Product("p8", "PL-1008", "5012345678908", "Heinz Beanz in Tomato Sauce", "Food & Drink", "415 g", 120, "£2.89 per kg", "https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=500", true, 90, "store_1", false, false),

      Product("p9", "PL-2001", "5012345678909", "Astonish Antibacterial Surface Cleanser", "Cleaning", "750 ml", 100, "£1.33 per litre", "https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?w=500", true, 65, "store_1", true, false),
      Product("p10", "PL-2002", "5012345678910", "Domestos Thick Bleach Original", "Cleaning", "750 ml", 125, "£1.67 per litre", "https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=500", true, 50, "store_1", false, false),
      Product("p11", "PL-2003", "5012345678911", "Fairy Non Bio Washing Powder", "Cleaning", "10 washes", 300, "£0.30 per wash", "https://images.unsplash.com/photo-1610557892470-55d9e80c0bce?w=500", true, 30, "store_1", false, false),
      Product("p12", "PL-2004", "5012345678912", "Cillit Bang Power Cleaner", "Cleaning", "750 ml", 250, "£3.33 per litre", "https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?w=500", true, 15, "store_1", false, false),
      Product("p13", "PL-2005", "5012345678913", "Flash All Purpose Cleaner Lemon", "Cleaning", "500 ml", 125, "£2.50 per litre", "https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=500", true, 40, "store_1", false, false),

      Product("p14", "PL-3001", "5012345678914", "Kleenex Everyday Facial Tissues 3 Pack", "Home", "3 boxes", 150, "£0.50 per box", "https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=500", true, 70, "store_1", true, false),
      Product("p15", "PL-3002", "5012345678915", "Andrex Classic Clean Toilet Roll 4 Pack", "Home", "4 rolls", 175, "£0.44 per roll", "https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?w=500", true, 85, "store_1", true, false),
      Product("p16", "PL-3003", "5012345678916", "Duracell Plus AA Batteries 4 Pack", "Home", "4 pack", 350, "£0.88 per battery", "https://images.unsplash.com/photo-1619725002198-6a6853d9e8e2?w=500", true, 35, "store_1", false, false),
      Product("p17", "PL-3004", "5012345678917", "Glade Air Freshener Spray Lavender", "Home", "300 ml", 125, "£4.17 per litre", "https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=500", true, 50, "store_1", false, false),

      Product("p18", "PL-4001", "5012345678918", "Colgate Total Original Toothpaste", "Health & Beauty", "75 ml", 150, "£2.00 per 100ml", "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500", true, 90, "store_1", true, false),
      Product("p19", "PL-4002", "5012345678919", "Paracetamol Caplets 500mg 16s", "Health & Beauty", "16 tablets", 75, "£4.69 per 100", "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500", true, 150, "store_1", true, false),
      Product("p20", "PL-4003", "5012345678920", "Sanex Dermo Sensitive Shower Gel", "Health & Beauty", "250 ml", 175, "£0.70 per 100ml", "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?w=500", true, 45, "store_1", false, false),
      Product("p21", "PL-4004", "5012345678921", "Sure Men Anti-Perspirant Deodorant", "Health & Beauty", "150 ml", 150, "£1.00 per 100ml", "https://images.unsplash.com/photo-1526947425960-945c6e72858f?w=500", true, 60, "store_1", false, false),
      Product("p22", "PL-4005", "5012345678922", "Head & Shoulders Classic Clean Shampoo", "Health & Beauty", "250 ml", 250, "£1.00 per 100ml", "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?w=500", true, 25, "store_1", false, false),

      Product("p23", "PL-5001", "5012345678923", "A5 Ruled Exercise Notebook", "Stationery", "1 unit", 150, "£1.50 each", "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500", true, 80, "store_1", true, false),
      Product("p24", "PL-5002", "5012345678924", "BIC Cristal Ballpoint Pens 5 Pack", "Stationery", "5 pens", 100, "£0.20 per pen", "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=500", true, 110, "store_1", false, false),
      Product("p25", "PL-5003", "5012345678925", "Pritt Stick Glue 22g", "Stationery", "22 g", 150, "£6.82 per 100g", "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=500", true, 40, "store_1", false, false),

      Product("p26", "PL-6001", "5012345678926", "Classic Playing Cards Deck", "Toys", "1 deck", 100, "£1.00 each", "https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=500", true, 70, "store_1", true, false),
      Product("p27", "PL-6002", "5012345678927", "Hot Wheels Die-Cast Toy Car", "Toys", "1 car", 175, "£1.75 each", "https://images.unsplash.com/photo-1594787318286-3d835c1d207f?w=500", true, 50, "store_1", true, false),
      Product("p28", "PL-6003", "5012345678928", "Bubble Solution Wand 250ml", "Toys", "250 ml", 100, "£0.40 per 100ml", "https://images.unsplash.com/photo-1516627145497-ae6968895b74?w=500", true, 65, "store_1", false, false),

      Product("p29", "PL-7001", "5012345678929", "Cadbury Easter Chocolate Egg", "Seasonal", "150 g", 200, "£1.33 per 100g", "https://images.unsplash.com/photo-1527903067568-d446b4122d20?w=500", true, 30, "store_1", true, true, "Seasonal Special"),
      Product("p30", "PL-7002", "5012345678930", "Halloween Spooky Pumpkin Decoration", "Seasonal", "1 unit", 150, "£1.50 each", "https://images.unsplash.com/photo-1508385082359-f38ae991e8f2?w=500", false, 0, "store_1", false, false),
      Product("p31", "PL-7003", "5012345678931", "Stale Inventory Clearance Coffee Mug", "Home", "1 unit", 100, "£1.00 each", "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=500", true, 3, "store_1", false, true, "Expired Promo Deal")
    ]
    dao.insertProducts(products)

    dao.insertShoppingList(
      ShoppingListEntity(
        id = "list_1",
        name = "Weekly Essentials",
        itemsJson = "[]"
      )
    )
  }
}
