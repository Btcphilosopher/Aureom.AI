package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.components.ProductCard
import com.example.ui.theme.TealDark
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun HomeScreen(
  products: List<Product>,
  onSearchClick: () -> Unit,
  onCategoryClick: (String) -> Unit,
  onProductClick: (String) -> Unit,
  onAddToCart: (String) -> Unit,
  onShoppingListsClick: () -> Unit,
  onStaffAdminClick: () -> Unit
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(bottom = 80.dp)
  ) {
    // Search Bar Trigger
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
        .clickable(onClick = onSearchClick),
      shape = RoundedCornerShape(28.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 2.dp
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray)
        Spacer(modifier = Modifier.width(12.dp))
        Text(
          text = "Search everyday essentials...",
          color = Color.Gray,
          fontSize = 14.sp
        )
      }
    }

    // Hero Banner
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .height(160.dp)
        .background(
          brush = Brush.horizontalGradient(
            colors = listOf(TealPrimary, TealDark)
          ),
          shape = RoundedCornerShape(16.dp)
        )
        .padding(20.dp)
    ) {
      Column(
        modifier = Modifier.fillMaxHeight(),
        verticalArrangement = Arrangement.Center
      ) {
        Surface(
          color = YellowAccent,
          shape = RoundedCornerShape(4.dp)
        ) {
          Text(
            text = " BRAND NEW DEALS ",
            color = Color.Black,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Big value. Everyday.",
          color = Color.White,
          fontSize = 26.sp,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = "Top brands & everyday grocery essentials at amazing prices.",
          color = Color.White.copy(alpha = 0.9f),
          fontSize = 13.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Shortcuts Row (Shopping Lists & Staff Portal)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Button(
        onClick = onShoppingListsClick,
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = TealPrimary),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.List, contentDescription = null, tint = TealPrimary)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Shopping Lists", fontWeight = FontWeight.Bold)
      }

      Button(
        onClick = onStaffAdminClick,
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = TealPrimary),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = TealPrimary)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Staff Portal", fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Categories Section
    Text(
      text = "Shop by Category",
      fontSize = 18.sp,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.padding(horizontal = 16.dp),
      color = MaterialTheme.colorScheme.onBackground
    )

    Spacer(modifier = Modifier.height(12.dp))

    val categories = listOf(
      "Food & Drink", "Cleaning", "Home", "Health & Beauty", "Stationery", "Toys", "Seasonal"
    )

    LazyRow(
      modifier = Modifier.fillMaxWidth(),
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(categories) { category ->
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier
            .width(80.dp)
            .clickable { onCategoryClick(category) }
        ) {
          Box(
            modifier = Modifier
              .size(64.dp)
              .background(TealPrimary.copy(alpha = 0.1f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = when (category) {
                "Food & Drink" -> Icons.Default.Fastfood
                "Cleaning" -> Icons.Default.CleaningServices
                "Home" -> Icons.Default.Home
                "Health & Beauty" -> Icons.Default.Face
                "Stationery" -> Icons.Default.Edit
                "Toys" -> Icons.Default.SportsEsports
                else -> Icons.Default.LocalOffer
              },
              contentDescription = category,
              tint = TealPrimary,
              modifier = Modifier.size(28.dp)
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = category,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            color = MaterialTheme.colorScheme.onBackground
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Featured / Promotional Products
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Top Value Picks & Offers",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
      TextButton(onClick = { onCategoryClick("All") }) {
        Text("See All", color = TealPrimary, fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    val featuredProducts = products.filter { it.isFeatured || it.isSpecialOffer }

    LazyRow(
      modifier = Modifier.fillMaxWidth(),
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(featuredProducts) { product ->
        ProductCard(
          product = product,
          onProductClick = { onProductClick(product.id) },
          onAddClick = { onAddToCart(product.id) }
        )
      }
    }
  }
}
