package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
  @PrimaryKey val id: String,
  val sku: String,
  val barcode: String,
  val name: String,
  val category: String, // Food & Drink, Cleaning, Home, Health & Beauty, Stationery, Toys, Seasonal
  val packContents: String,
  val sellingPricePence: Int, // e.g. 125 for £1.25
  val unitPriceBasis: String, // e.g. "£2.50 per litre"
  val imageUrl: String,
  val inStock: Boolean,
  val stockQuantity: Int,
  val storeId: String,
  val isFeatured: Boolean = false,
  val isSpecialOffer: Boolean = false,
  val offerDescription: String? = null,
  val rating: Float = 4.5f,
  val reviewsCount: Int = 24
) {
  val formattedPrice: String
    get() = "£%.2f".format(sellingPricePence / 100.0)
}

@Entity(tableName = "stores")
data class Store(
  @PrimaryKey val id: String,
  val name: String,
  val address: String,
  val town: String,
  val postcode: String,
  val openingHours: String,
  val services: String, // e.g. "Click & Collect, Parking, Bakery"
  val isDefault: Boolean = false
)

@Entity(tableName = "basket_items")
data class BasketItem(
  @PrimaryKey val productId: String,
  val quantity: Int,
  val savedForLater: Boolean = false
)

@Entity(tableName = "shopping_lists")
data class ShoppingListEntity(
  @PrimaryKey val id: String,
  val name: String,
  val itemsJson: String, // JSON or serialized items: productIds and quantities / reminders
  val createdAt: Long = System.currentTimeMillis()
)

data class ShoppingListItem(
  val id: String,
  val name: String,
  val quantity: Int,
  val estimatedPricePence: Int,
  val isPurchased: Boolean,
  val productId: String? = null
)

@Entity(tableName = "orders")
data class OrderEntity(
  @PrimaryKey val orderId: String,
  val customerName: String,
  val email: String,
  val storeId: String,
  val itemsSummary: String, // JSON or formatted summary
  val merchandiseTotalPence: Int,
  val deliveryFeePence: Int,
  val discountPence: Int,
  val finalTotalPence: Int,
  val status: String, // Confirmed, Picking, Ready for collection / Dispatched, Collected / Delivered, Cancelled
  val fulfilmentType: String, // Click & Collect or Home Delivery
  val paymentStatus: String, // Paid, Failed, Pending
  val paymentMethod: String, // Visa ending in 4242, Apple Pay, PayPal
  val idempotencyKey: String,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
  @PrimaryKey val id: String,
  val timestamp: Long = System.currentTimeMillis(),
  val staffName: String,
  val action: String,
  val details: String
)
