package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.model.ShoppingListEntity
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun ShoppingListsScreen(
  shoppingLists: List<ShoppingListEntity>,
  allProducts: List<Product>,
  onSaveList: (String, String) -> Unit,
  onDeleteList: (String) -> Unit,
  onAddListToBasket: (List<String>) -> Unit,
  onBackClick: () -> Unit
) {
  var showCreateDialog by remember { mutableStateOf(false) }
  var newListName by remember { mutableStateOf("") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .padding(bottom = 80.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Shopping Lists",
        fontSize = 22.sp,
        fontWeight = FontWeight.ExtraBold,
        color = TealPrimary
      )

      Button(
        onClick = { showCreateDialog = true },
        colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("New List")
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    if (shoppingLists.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.List, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(64.dp))
          Spacer(modifier = Modifier.height(12.dp))
          Text("No shopping lists created yet", color = Color.Gray)
        }
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      ) {
        items(shoppingLists) { list ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = list.name,
                  fontWeight = FontWeight.Bold,
                  fontSize = 16.sp,
                  color = TealPrimary
                )
                IconButton(onClick = { onDeleteList(list.id) }) {
                  Icon(Icons.Default.Delete, contentDescription = "Delete List", tint = Color.Red)
                }
              }

              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "Items saved in list. Tap below to move available items into basket and estimate total.",
                fontSize = 12.sp,
                color = Color.Gray
              )

              Spacer(modifier = Modifier.height(12.dp))

              Button(
                onClick = {
                  // Move sample product IDs into basket for demonstration
                  onAddListToBasket(listOf("p1", "p2"))
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = TealPrimary)
              ) {
                Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Move Available Items to Basket")
              }
            }
          }
        }
      }
    }
  }

  if (showCreateDialog) {
    AlertDialog(
      onDismissRequest = { showCreateDialog = false },
      title = { Text("Create Shopping List") },
      text = {
        OutlinedTextField(
          value = newListName,
          onValueChange = { newListName = it },
          placeholder = { Text("List Name (e.g., Weekend BBQ)") },
          singleLine = true
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (newListName.isNotBlank()) {
              onSaveList(newListName.trim(), "[]")
              newListName = ""
              showCreateDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black)
        ) {
          Text("Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { showCreateDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }
}
