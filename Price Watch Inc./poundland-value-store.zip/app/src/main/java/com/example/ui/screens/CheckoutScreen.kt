package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BasketItem
import com.example.data.model.Product
import com.example.data.model.Store
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent
import kotlinx.coroutines.launch

@Composable
fun CheckoutScreen(
  basketItems: List<BasketItem>,
  allProducts: List<Product>,
  selectedStore: Store?,
  onCompleteOrder: suspend (String, String, String, String, Int, Int, Int, Int, String, String) -> String,
  onOrderSuccess: (String) -> Unit,
  onBackClick: () -> Unit
) {
  val productMap = allProducts.associateBy { it.id }
  val cartProducts = basketItems.mapNotNull { item ->
    productMap[item.productId]?.let { product -> Pair(product, item.quantity) }
  }

  val merchandiseTotal = cartProducts.sumOf { (product, qty) -> product.sellingPricePence * qty }
  var fulfilmentType by remember { mutableStateOf("Click & Collect") }
  val deliveryFee = if (fulfilmentType == "Home Delivery") 295 else 0
  val discount = if (merchandiseTotal >= 400) 50 else 0
  val finalTotal = (merchandiseTotal + deliveryFee - discount).coerceAtLeast(0)

  var customerName by remember { mutableStateOf("Jane Smith") }
  var email by remember { mutableStateOf("jane.smith@example.co.uk") }
  var address by remember { mutableStateOf("12 Baker Street, London, W1U 3BW") }
  var paymentMethod by remember { mutableStateOf("Visa ending in 4242") }
  var isProcessing by remember { mutableStateOf(false) }
  var paymentError by remember { mutableStateOf<String?>(null) }
  val scope = rememberCoroutineScope()
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp)
      .padding(bottom = 80.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Secure Checkout",
        fontSize = 22.sp,
        fontWeight = FontWeight.ExtraBold,
        color = TealPrimary
      )
      TextButton(onClick = onBackClick) {
        Text("Back to Basket")
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Fulfilment Method Selector
    Text(text = "1. Choose Fulfilment Method", fontWeight = FontWeight.Bold, fontSize = 16.sp)
    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      OutlinedButton(
        onClick = { fulfilmentType = "Click & Collect" },
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.outlinedButtonColors(
          containerColor = if (fulfilmentType == "Click & Collect") TealPrimary.copy(alpha = 0.1f) else Color.Transparent
        )
      ) {
        Icon(Icons.Default.Store, contentDescription = null, tint = TealPrimary)
        Spacer(modifier = Modifier.width(6.dp))
        Text("Click & Collect (Free)")
      }

      OutlinedButton(
        onClick = { fulfilmentType = "Home Delivery" },
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.outlinedButtonColors(
          containerColor = if (fulfilmentType == "Home Delivery") TealPrimary.copy(alpha = 0.1f) else Color.Transparent
        )
      ) {
        Icon(Icons.Default.LocalShipping, contentDescription = null, tint = TealPrimary)
        Spacer(modifier = Modifier.width(6.dp))
        Text("Delivery (£2.95)")
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Customer & Location details
    Text(text = "2. Contact & Location", fontWeight = FontWeight.Bold, fontSize = 16.sp)
    Spacer(modifier = Modifier.height(8.dp))

    OutlinedTextField(
      value = customerName,
      onValueChange = { customerName = it },
      label = { Text("Full Name") },
      modifier = Modifier.fillMaxWidth(),
      singleLine = true
    )
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
      value = email,
      onValueChange = { email = it },
      label = { Text("Email Address for Receipt") },
      modifier = Modifier.fillMaxWidth(),
      singleLine = true
    )
    Spacer(modifier = Modifier.height(8.dp))
    if (fulfilmentType == "Click & Collect") {
      OutlinedTextField(
        value = selectedStore?.name ?: "Birmingham High Street Store",
        onValueChange = {},
        readOnly = true,
        label = { Text("Collection Store") },
        modifier = Modifier.fillMaxWidth()
      )
    } else {
      OutlinedTextField(
        value = address,
        onValueChange = { address = it },
        label = { Text("Delivery Address") },
        modifier = Modifier.fillMaxWidth()
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Payment Simulator
    Text(text = "3. Payment Simulator", fontWeight = FontWeight.Bold, fontSize = 16.sp)
    Spacer(modifier = Modifier.height(8.dp))

    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.CreditCard, contentDescription = null, tint = TealPrimary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = paymentMethod, fontWeight = FontWeight.SemiBold)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Simulated secure sandbox card payment. No raw card details are stored.", fontSize = 12.sp, color = Color.Gray)
      }
    }

    if (paymentError != null) {
      Spacer(modifier = Modifier.height(8.dp))
      Text(text = paymentError!!, color = Color.Red, fontWeight = FontWeight.Bold)
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Order Summary
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = TealPrimary.copy(alpha = 0.05))
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text("Order Summary", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Merchandise Subtotal")
          Text("£%.2f".format(merchandiseTotal / 100.0))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Fulfilment Fee")
          Text("£%.2f".format(deliveryFee / 100.0))
        }
        if (discount > 0) {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Discount", color = Color(0xFF2E7D32))
            Text("-£%.2f".format(discount / 100.0), color = Color(0xFF2E7D32))
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Divider()
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("Final Total", fontWeight = FontWeight.ExtraBold)
          Text("£%.2f".format(finalTotal / 100.0), fontWeight = FontWeight.ExtraBold, color = TealPrimary, fontSize = 18.sp)
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    Button(
      onClick = {
        scope.launch {
          isProcessing = true
          paymentError = null
          try {
            val itemsSummary = cartProducts.joinToString(", ") { "${it.second}x ${it.first.name}" }
            val orderId = onCompleteOrder(
              customerName,
              email,
              selectedStore?.id ?: "store_1",
              itemsSummary,
              merchandiseTotal,
              deliveryFee,
              discount,
              finalTotal,
              fulfilmentType,
              paymentMethod
            )
            onOrderSuccess(orderId)
          } catch (e: Exception) {
            paymentError = "Payment simulation failed: ${e.message}"
            isProcessing = false
          }
        }
      },
      enabled = !isProcessing && cartProducts.isNotEmpty(),
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp),
      colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black),
      shape = RoundedCornerShape(12.dp)
    ) {
      if (isProcessing) {
        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.Black)
      } else {
        Text("Complete Simulated Payment • £%.2f".format(finalTotal / 100.0), fontWeight = FontWeight.Bold, fontSize = 16.sp)
      }
    }
  }
}
