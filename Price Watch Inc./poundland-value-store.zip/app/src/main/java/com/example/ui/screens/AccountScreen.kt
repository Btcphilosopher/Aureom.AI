package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderEntity
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun AccountScreen(
  orders: List<OrderEntity>,
  onStaffAdminClick: () -> Unit,
  onShoppingListsClick: () -> Unit,
  onReorderClick: (OrderEntity) -> Unit
) {
  var isSignedIn by remember { mutableStateOf(true) }
  var userName by remember { mutableStateOf("Jane Smith") }
  var userEmail by remember { mutableStateOf("jane.smith@example.co.uk") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .padding(bottom = 80.dp)
  ) {
    Text(
      text = "My Account & Orders",
      fontSize = 22.sp,
      fontWeight = FontWeight.ExtraBold,
      color = TealPrimary
    )

    Spacer(modifier = Modifier.height(16.dp))

    // Profile Card
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = TealPrimary),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(56.dp)
            .background(YellowAccent, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = userName.take(1),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
          )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = userName,
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = userEmail,
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 13.sp
          )
        }

        IconButton(onClick = { isSignedIn = !isSignedIn }) {
          Icon(Icons.Default.ExitToApp, contentDescription = "Sign out", tint = YellowAccent)
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Quick Actions
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Button(
        onClick = onShoppingListsClick,
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = TealPrimary),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.List, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("Shopping Lists")
      }

      Button(
        onClick = onStaffAdminClick,
        modifier = Modifier.weight(1f),
        colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("Staff Portal")
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    Text(
      text = "Order History & Receipts",
      fontSize = 18.sp,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground
    )

    Spacer(modifier = Modifier.height(12.dp))

    if (orders.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Text("No previous orders found. Place an order to see it here!", color = Color.Gray, fontSize = 14.sp)
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(orders) { order ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Column(
              modifier = Modifier.padding(16.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Order #${order.orderId}",
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp,
                  color = TealPrimary
                )
                Surface(
                  color = when (order.status) {
                    "Confirmed" -> Color(0xFF1976D2).copy(alpha = 0.1f)
                    "Picking" -> Color(0xFFF57C00).copy(alpha = 0.1f)
                    "Ready for collection", "Dispatched" -> Color(0xFF388E3C).copy(alpha = 0.1f)
                    else -> Color.Gray.copy(alpha = 0.1f)
                  },
                  shape = RoundedCornerShape(8.dp)
                ) {
                  Text(
                    text = order.status,
                    color = when (order.status) {
                      "Confirmed" -> Color(0xFF1976D2)
                      "Picking" -> Color(0xFFF57C00)
                      "Ready for collection", "Dispatched" -> Color(0xFF388E3C)
                      else -> Color.Gray
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = "Fulfilment: ${order.fulfilmentType} | Paid via ${order.paymentMethod}",
                fontSize = 12.sp,
                color = Color.Gray
              )
              Text(
                text = "Total: £%.2f".format(order.finalTotalPence / 100.0),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )

              Spacer(modifier = Modifier.height(12.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedButton(
                  onClick = { onReorderClick(order) },
                  modifier = Modifier.weight(1f)
                ) {
                  Text("Reorder Items")
                }
                OutlinedButton(
                  onClick = { /* View receipt detail */ },
                  modifier = Modifier.weight(1f)
                ) {
                  Text("View Receipt")
                }
              }
            }
          }
        }
      }
    }
  }
}
