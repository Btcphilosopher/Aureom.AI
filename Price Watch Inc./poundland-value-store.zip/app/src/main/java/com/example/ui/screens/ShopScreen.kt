package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.components.ProductCard
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun ShopScreen(
  products: List<Product>,
  searchQuery: String,
  selectedCategory: String?,
  onSearchQueryChanged: (String) -> Unit,
  onCategorySelected: (String?) -> Unit,
  onProductClick: (String) -> Unit,
  onAddToCart: (String) -> Unit
) {
  var sortByPriceAsc by remember { mutableStateOf(false) }

  val categories = listOf("All", "Food & Drink", "Cleaning", "Home", "Health & Beauty", "Stationery", "Toys", "Seasonal")

  val filteredProducts = products.filter { product ->
    val matchesCategory = selectedCategory == null || selectedCategory == "All" || product.category.equals(selectedCategory, ignoreCase = true)
    val matchesQuery = searchQuery.isBlank() ||
      product.name.contains(searchQuery, ignoreCase = true) ||
      product.barcode.contains(searchQuery, ignoreCase = true) ||
      product.category.contains(searchQuery, ignoreCase = true)
    matchesCategory && matchesQuery
  }.let { list ->
    if (sortByPriceAsc) list.sortedBy { it.sellingPricePence } else list
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(bottom = 80.dp)
  ) {
    // Search Bar
    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchQueryChanged,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      placeholder = { Text("Search products, barcode, or category...") },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
      trailingIcon = {
        if (searchQuery.isNotBlank()) {
          IconButton(onClick = { onSearchQueryChanged("") }) {
            Icon(Icons.Default.Clear, contentDescription = "Clear")
          }
        }
      },
      shape = RoundedCornerShape(24.dp),
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = TealPrimary,
        unfocusedBorderColor = Color.LightGray
      )
    )

    // Category Filter Chips
    LazyRow(
      modifier = Modifier.fillMaxWidth(),
      contentPadding = PaddingValues(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(categories) { category ->
        val isSelected = (selectedCategory == category) || (selectedCategory == null && category == "All")
        FilterChip(
          selected = isSelected,
          onClick = { onCategorySelected(if (category == "All") "All" else category) },
          label = { Text(category) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = TealPrimary,
            selectedLabelColor = Color.White
          )
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Sort Row
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "${filteredProducts.size} products found",
        fontSize = 13.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      TextButton(onClick = { sortByPriceAsc = !sortByPriceAsc }) {
        Text(if (sortByPriceAsc) "Sort: Price (Low to High)" else "Sort: Relevance")
      }
    }

    Spacer(modifier = Modifier.height(4.dp))

    if (filteredProducts.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("No products found", fontSize = 16.sp, color = Color.Gray)
          Spacer(modifier = Modifier.height(8.dp))
          Button(onClick = {
            onSearchQueryChanged("")
            onCategorySelected("All")
          }) {
            Text("Reset Filters")
          }
        }
      }
    } else {
      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        items(filteredProducts) { product ->
          ProductCard(
            product = product,
            onProductClick = { onProductClick(product.id) },
            onAddClick = { onAddToCart(product.id) }
          )
        }
      }
    }
  }
}
