package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.format
import androidx.compose.ui.unit.sp
import com.example.data.model.BasketItem
import com.example.data.model.Product
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun BasketScreen(
  basketItems: List<BasketItem>,
  allProducts: List<Product>,
  onUpdateQuantity: (String, Int) -> Unit,
  onRemoveItem: (String) -> Unit,
  onClearBasket: () -> Unit,
  onProceedToCheckout: () -> Unit,
  onContinueShopping: () -> Unit
) {
  val productMap = allProducts.associateBy { it.id }
  val cartProducts = basketItems.mapNotNull { item ->
    productMap[item.productId]?.let { product ->
      Pair(product, item.quantity)
    }
  }

  val merchandiseTotal = cartProducts.sumOf { (product, qty) -> product.sellingPricePence * qty }
  val deliveryFee = if (merchandiseTotal > 0) 295 else 0 // £2.95 standard delivery
  val discount = if (merchandiseTotal >= 400) 50 else 0 // £0.50 multi-buy discount example
  val finalTotal = (merchandiseTotal + deliveryFee - discount).coerceAtLeast(0)

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .padding(bottom = 80.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Shopping Basket",
        fontSize = 22.sp,
        fontWeight = FontWeight.ExtraBold,
        color = TealPrimary
      )

      if (cartProducts.isNotEmpty()) {
        TextButton(onClick = onClearBasket) {
          Text("Clear All", color = Color.Red)
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    if (cartProducts.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            Icons.Default.ShoppingCart,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(64.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(text = "Your basket is empty", fontSize = 16.sp, color = Color.Gray)
          Spacer(modifier = Modifier.height(16.dp))
          Button(
            onClick = onContinueShopping,
            colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black)
          ) {
            Text("Start Shopping")
          }
        }
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      ) {
        items(cartProducts) { (product, quantity) ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = product.name,
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp,
                  maxLines = 1
                )
                Text(
                  text = product.packContents,
                  fontSize = 12.sp,
                  color = Color.Gray
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = product.formattedPrice,
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp,
                  color = TealPrimary
                )
              }

              // Quantity controls & Remove
              Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onUpdateQuantity(product.id, quantity - 1) }) {
                  Text("-", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                  text = "$quantity",
                  fontWeight = FontWeight.Bold,
                  fontSize = 15.sp,
                  modifier = Modifier.padding(horizontal = 8.dp)
                )
                IconButton(onClick = { onUpdateQuantity(product.id, quantity + 1) }) {
                  Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }

                IconButton(onClick = { onRemoveItem(product.id) }) {
                  Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.Red)
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Pricing Breakdown Card
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
      ) {
        Column(
          modifier = Modifier.padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Merchandise Subtotal")
            Text("£%.2f".format(merchandiseTotal / 100.0), fontWeight = FontWeight.SemiBold)
          }

          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Estimated Fulfilment / Delivery")
            Text("£%.2f".format(deliveryFee / 100.0), fontWeight = FontWeight.SemiBold)
          }

          if (discount > 0) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("Promotional Discount", color = Color(0xFF2E7D32))
              Text("-£%.2f".format(discount / 100.0), color = Color(0xFF2E7D32), fontWeight = FontWeight.SemiBold)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Divider()
          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Total (VAT inclusive)", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text("£%.2f".format(finalTotal / 100.0), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = TealPrimary)
          }

          Spacer(modifier = Modifier.height(16.dp))

          Button(
            onClick = onProceedToCheckout,
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black),
            shape = RoundedCornerShape(12.dp)
          ) {
            Text("Proceed to Checkout • £%.2f".format(finalTotal / 100.0), fontWeight = FontWeight.Bold, fontSize = 16.sp)
          }
        }
      }
    }
  }
}
