package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Product
import com.example.data.model.Store
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun PoundlandBottomBar(
  currentScreen: String,
  basketCount: Int,
  onNavigate: (String) -> Unit
) {
  NavigationBar(
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp
  ) {
    NavigationBarItem(
      icon = { Icon(Icons.Outlined.Home, contentDescription = "Home") },
      label = { Text("Home") },
      selected = currentScreen == "Home",
      onClick = { onNavigate("Home") },
      modifier = Modifier.testTag("nav_home")
    )
    NavigationBarItem(
      icon = { Icon(Icons.Outlined.ShoppingBag, contentDescription = "Shop") },
      label = { Text("Shop") },
      selected = currentScreen == "Shop",
      onClick = { onNavigate("Shop") },
      modifier = Modifier.testTag("nav_shop")
    )
    NavigationBarItem(
      icon = { Icon(Icons.Outlined.QrCodeScanner, contentDescription = "Scan") },
      label = { Text("Scan") },
      selected = currentScreen == "Scan",
      onClick = { onNavigate("Scan") },
      modifier = Modifier.testTag("nav_scan")
    )
    NavigationBarItem(
      icon = { Icon(Icons.Outlined.Store, contentDescription = "Stores") },
      label = { Text("Stores") },
      selected = currentScreen == "Stores",
      onClick = { onNavigate("Stores") },
      modifier = Modifier.testTag("nav_stores")
    )
    NavigationBarItem(
      icon = {
        BadgedBox(
          badge = {
            if (basketCount > 0) {
              Badge(
                containerColor = YellowAccent,
                contentColor = Color.Black
              ) {
                Text("$basketCount")
              }
            }
          }
        ) {
          Icon(Icons.Outlined.Person, contentDescription = "Account")
        }
      },
      label = { Text("Account") },
      selected = currentScreen == "Account",
      onClick = { onNavigate("Account") },
      modifier = Modifier.testTag("nav_account")
    )
  }
}

@Composable
fun PoundlandTopBar(
  title: String,
  selectedStore: Store?,
  basketCount: Int,
  onStoreClick: () -> Unit,
  onBasketClick: () -> Unit
) {
  Surface(
    color = TealPrimary,
    tonalElevation = 4.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .background(YellowAccent, RoundedCornerShape(4.dp))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = "Poundland",
              color = Color.Black,
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = title,
            color = Color.White,
            fontWeight = FontWeight.Medium,
            fontSize = 16.sp
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onBasketClick,
            modifier = Modifier.testTag("top_basket_button")
          ) {
            BadgedBox(
              badge = {
                if (basketCount > 0) {
                  Badge(
                    containerColor = YellowAccent,
                    contentColor = Color.Black
                  ) {
                    Text("$basketCount")
                  }
                }
              }
            ) {
              Icon(
                Icons.Default.ShoppingCart,
                contentDescription = "Basket",
                tint = Color.White
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Store Picker Banner
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
          .clickable(onClick = onStoreClick)
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            Icons.Default.LocationOn,
            contentDescription = null,
            tint = YellowAccent,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = selectedStore?.name ?: "Select your local store",
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
        Text(
          text = "Change",
          color = YellowAccent,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }
  }
}

@Composable
fun ProductCard(
  product: Product,
  onProductClick: () -> Unit,
  onAddClick: () -> Unit
) {
  Card(
    onClick = onProductClick,
    modifier = Modifier
      .width(160.dp)
      .height(260.dp)
      .testTag("product_card_${product.id}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(8.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Column {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .background(Color(0xFFF0F0F0), RoundedCornerShape(8.dp))
        ) {
          AsyncImage(
            model = product.imageUrl,
            contentDescription = product.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
              .fillMaxSize()
              .clip(RoundedCornerShape(8.dp))
          )
          if (product.isSpecialOffer && product.offerDescription != null) {
            Box(
              modifier = Modifier
                .align(Alignment.TopStart)
                .background(YellowAccent, RoundedCornerShape(bottomEnd = 8.dp))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = product.offerDescription!!,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = product.name,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
          color = MaterialTheme.colorScheme.onSurface
        )

        Text(
          text = product.packContents,
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Bottom
        ) {
          Column {
            Text(
              text = product.formattedPrice,
              fontSize = 18.sp,
              fontWeight = FontWeight.ExtraBold,
              color = TealPrimary
            )
            Text(
              text = product.unitPriceBasis,
              fontSize = 10.sp,
              color = Color.Gray
            )
          }

          Button(
            onClick = onAddClick,
            colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            modifier = Modifier
              .height(36.dp)
              .testTag("add_to_basket_${product.id}")
          ) {
            Icon(Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
          }
        }
      }
    }
  }
}
