package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF004F47)
val TealDark = Color(0xFF003832)
val TealLight = Color(0xFF007A6D)
val YellowAccent = Color(0xFFFFD100)
val YellowDark = Color(0xFFD4AC0D)
val BackgroundLight = Color(0xFFF9FAFA)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1A1A1A)
val TextSecondary = Color(0xFF555555)
val DividerColor = Color(0xFFE0E0E0)
val RedAccent = Color(0xFFD32F2F)
val GreenAccent = Color(0xFF2E7D32)
