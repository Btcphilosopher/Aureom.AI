package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Product
import com.example.ui.components.ProductCard
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun ProductDetailScreen(
  productId: String,
  allProducts: List<Product>,
  onBackClick: () -> Unit,
  onAddToCart: (String, Int) -> Unit,
  onProductClick: (String) -> Unit
) {
  val product = allProducts.find { it.id == productId }
  var quantity by remember { mutableStateOf(1) }

  if (product == null) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("Product not found")
    }
    return
  }

  val relatedProducts = allProducts.filter { it.category == product.category && it.id != product.id }
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(bottom = 90.dp)
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(260.dp)
        .background(Color(0xFFF2F2F2))
    ) {
      AsyncImage(
        model = product.imageUrl,
        contentDescription = product.name,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
      )

      IconButton(
        onClick = onBackClick,
        modifier = Modifier
          .statusBarsPadding()
          .padding(8.dp)
          .background(Color.White.copy(alpha = 0.8f), RoundedCornerShape(50%))
      ) {
        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
      }

      if (product.isSpecialOffer && product.offerDescription != null) {
        Box(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .background(YellowAccent)
            .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Text(
            text = product.offerDescription!!,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            fontSize = 13.sp
          )
        }
      }
    }

    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = product.category,
          fontSize = 13.sp,
          color = TealPrimary,
          fontWeight = FontWeight.Bold
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = if (product.inStock) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (product.inStock) Color(0xFF2E7D32) else Color(0xFFD32F2F),
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (product.inStock) "In Stock (${product.stockQuantity} available)" else "Out of Stock",
            fontSize = 12.sp,
            color = if (product.inStock) Color(0xFF2E7D32) else Color(0xFFD32F2F),
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = product.name,
        fontSize = 22.sp,
        fontWeight = FontWeight.ExtraBold,
        color = MaterialTheme.colorScheme.onBackground
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = "Pack size: ${product.packContents}",
        fontSize = 14.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(16.dp))

      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = TealPrimary.copy(alpha = 0.08f)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = product.formattedPrice,
              fontSize = 28.sp,
              fontWeight = FontWeight.ExtraBold,
              color = TealPrimary
            )
            Text(
              text = product.unitPriceBasis,
              fontSize = 13.sp,
              color = Color.Gray
            )
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(
              text = "SKU: ${product.sku}",
              fontSize = 11.sp,
              color = Color.Gray
            )
            Text(
              text = "Barcode: ${product.barcode}",
              fontSize = 11.sp,
              color = Color.Gray
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .background(Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(4.dp)
        ) {
          IconButton(
            onClick = { if (quantity > 1) quantity-- },
            modifier = Modifier.size(36.dp)
          ) {
            Text("-", fontSize = 20.sp, fontWeight = FontWeight.Bold)
          }
          Text(
            text = "$quantity",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 12.dp)
          )
          IconButton(
            onClick = { quantity++ },
            modifier = Modifier.size(36.dp)
          ) {
            Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold)
          }
        }

        Button(
          onClick = { onAddToCart(product.id, quantity) },
          enabled = product.inStock,
          modifier = Modifier
            .weight(1f)
            .height(50.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = YellowAccent,
            contentColor = Color.Black
          ),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.ShoppingCart, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Add to Basket • £%.2f".format((product.sellingPricePence * quantity) / 100.0),
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(32.dp))

      if (relatedProducts.isNotEmpty()) {
        Text(
          text = "You might also like",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(12.dp))
        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          items(relatedProducts) { relProduct ->
            ProductCard(
              product = relProduct,
              onProductClick = { onProductClick(relProduct.id) },
              onAddClick = { onAddToCart(relProduct.id, 1) }
            )
          }
        }
      }
    }
  }
}
