package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderEntity
import com.example.ui.theme.TealPrimary
import com.example.ui.theme.YellowAccent

@Composable
fun OrderConfirmationScreen(
  orderId: String,
  orders: List<OrderEntity>,
  onViewStaffPortal: () -> Unit,
  onGoHome: () -> Unit
) {
  val order = orders.find { it.orderId == orderId }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(24.dp)
      .padding(bottom = 80.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(80.dp)
        .background(TealPrimary, CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        Icons.Default.Check,
        contentDescription = null,
        tint = YellowAccent,
        modifier = Modifier.size(48.dp)
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "Payment Successful!",
      fontSize = 24.sp,
      fontWeight = FontWeight.ExtraBold,
      color = TealPrimary
    )

    Spacer(modifier = Modifier.height(4.dp))

    Text(
      text = "Your order has been placed and stock reserved securely.",
      fontSize = 14.sp,
      color = Color.Gray,
      textAlign = TextAlign.Center
    )

    Spacer(modifier = Modifier.height(24.dp))

    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Order Reference:", color = Color.Gray)
          Text(orderId, fontWeight = FontWeight.Bold, color = TealPrimary)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Fulfilment:", color = Color.Gray)
          Text(order?.fulfilmentType ?: "Click & Collect", fontWeight = FontWeight.SemiBold)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Total Paid:", color = Color.Gray)
          Text(order?.let { "£%.2f".format(it.finalTotalPence / 100.0) } ?: "£0.00", fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Status:", color = Color.Gray)
          Text(order?.status ?: "Confirmed", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
        }
      }
    }

    Spacer(modifier = Modifier.height(32.dp))

    Button(
      onClick = onViewStaffPortal,
      modifier = Modifier
        .fillMaxWidth()
        .height(50.dp),
      colors = ButtonDefaults.buttonColors(containerColor = YellowAccent, contentColor = Color.Black),
      shape = RoundedCornerShape(12.dp)
    ) {
      Text("View Order in Staff Portal", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }

    Spacer(modifier = Modifier.height(12.dp))

    OutlinedButton(
      onClick = onGoHome,
      modifier = Modifier
        .fillMaxWidth()
        .height(50.dp),
      shape = RoundedCornerShape(12.dp)
    ) {
      Text("Return to Home", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
  }
}
