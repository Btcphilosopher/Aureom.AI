import Link from 'next/link';
import { ArrowLeft, ExternalLink, Info } from 'lucide-react';

export default async function SupplierReferralPage({
  params,
  searchParams,
}: {
  params: Promise<{ sellerSlug: string }>;
  searchParams: Promise<{ offerId?: string; ref?: string }>;
}) {
  const { sellerSlug } = await params;
  const sp = await searchParams;
  const sellerName = sellerSlug
    .split('-')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');

  return (
    <div className="bg-[#F4F7FA] min-h-[75vh] py-12">
      <div className="max-w-2xl mx-auto px-4 sm:px-6">
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 space-y-6">
          <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-5">
            <div>
              <p className="text-xs font-semibold text-[#0E5952] uppercase tracking-wider">
                Simulated Supplier Checkout Handoff
              </p>
              <h1 className="font-display text-2xl font-bold text-[#0D2038] mt-1">
                {sellerName}
              </h1>
            </div>
            <ExternalLink className="w-6 h-6 text-[#16C2AF] shrink-0" />
          </div>

          <div className="rounded-xl bg-slate-50 border border-slate-200 p-4 text-sm space-y-2">
            <p>
              <span className="text-slate-500">Referred Offer ID:</span>{' '}
              <strong className="font-mono text-slate-900">{sp.offerId ?? 'N/A'}</strong>
            </p>
            <p>
              <span className="text-slate-500">Provider Reference:</span>{' '}
              <strong className="font-mono text-slate-900">{sp.ref ?? 'N/A'}</strong>
            </p>
          </div>

          <div className="rounded-xl bg-amber-50 border border-amber-200 p-4 text-xs sm:text-sm text-amber-950 flex items-start gap-2.5">
            <Info className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Comparison-only handoff notice</p>
              <p className="mt-1 leading-relaxed">
                This simulated destination represents the external airline or travel-agency
                booking portal reached after clicking &ldquo;Continue to airline&rdquo; or
                &ldquo;Continue to seller.&rdquo; Clicking through does not create a reservation or
                issue an e-ticket on airunion.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Link
              href="/my-trips"
              className="px-4 py-2.5 rounded-xl bg-[#0D2038] text-white text-xs sm:text-sm font-semibold"
            >
              View handoff history in My trips
            </Link>
            <Link
              href="/search"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 text-xs sm:text-sm font-semibold hover:bg-slate-50"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Return to flight search</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
