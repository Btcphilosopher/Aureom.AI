import Link from 'next/link';
import { Armchair, Briefcase, RefreshCw, ShieldCheck } from 'lucide-react';

export default function HelpPage() {
  return (
    <div className="bg-[#F4F7FA] min-h-screen pb-16">
      <div className="bg-[#0D2038] text-white py-10 border-b border-white/10">
        <div className="max-w-[1000px] mx-auto px-4 sm:px-6">
          <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight">
            Fare transparency & provider disclosures
          </h1>
          <div className="w-16 h-[3px] bg-[#EB5E47] rounded-full mt-2.5 mb-3" />
          <p className="text-slate-300 text-sm sm:text-base max-w-2xl">
            How airunion compares baggage, seats, change terms, connection protection, decimal totals, and simulated flight-provider integrations.
          </p>
        </div>
      </div>

      <div className="max-w-[1000px] mx-auto px-4 sm:px-6 pt-8 space-y-6">
        <section id="carry-on-baggage" className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D9F3EE] flex items-center justify-center text-[#0F5A54]">
              <Briefcase className="w-5 h-5" />
            </div>
            <h2 className="font-display text-xl font-bold text-[#0D2038]">
              Personal items, carry-on bags & checked baggage
            </h2>
          </div>
          <p className="text-sm text-slate-700 leading-relaxed">
            airunion separates <strong>personal items</strong>, <strong>carry-on bags</strong>, and{' '}
            <strong>1st checked bags</strong> across every flight segment. When you select a baggage requirement,
            fares that exclude that bag are marked ineligible, fares that charge an explicit fee include that fee in the{' '}
            <strong>comparable total</strong>, and offers with missing provider data are labeled{' '}
            <strong>Incomplete comparison</strong> rather than assuming a bag is included.
          </p>
        </section>

        <section id="seat-selection" className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FDE7E3] flex items-center justify-center text-[#E05640]">
              <Armchair className="w-5 h-5" />
            </div>
            <h2 className="font-display text-xl font-bold text-[#0D2038]">
              Seat selection vs. assigned seats
            </h2>
          </div>
          <p className="text-sm text-slate-700 leading-relaxed">
            airunion distinguishes an <strong>assigned seat included at check-in</strong> from the{' '}
            <strong>right to select a specific seat in advance</strong> (either complimentary or for a known fee).
            Basic Economy or separate-ticket fares that assign seats only at check-in will not match an
            advance-seat-selection filter.
          </p>
        </section>

        <section id="change-conditions" className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D9F3EE] flex items-center justify-center text-[#0F5A54]">
              <RefreshCw className="w-5 h-5" />
            </div>
            <h2 className="font-display text-xl font-bold text-[#0D2038]">
              Change terms, refunds & connection protection
            </h2>
          </div>
          <p className="text-sm text-slate-700 leading-relaxed">
            Every offer displays change fees, refundability (cash refund vs airline trip credit vs non-refundable),
            mixed-cabin legs, airport changes, overnight connections, and whether connections are{' '}
            <strong>carrier-protected on a single ticket</strong> or{' '}
            <strong>self-transfer separate tickets</strong> with no missed-connection protection.
          </p>
        </section>

        <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-[#0D2038]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h2 className="font-display text-xl font-bold text-[#0D2038]">
              Provider integration & commercial access notes
            </h2>
          </div>
          <p className="text-sm text-slate-700 leading-relaxed">
            This release demonstrates comparison and supplier referral handoff using two deterministic simulated
            providers (<strong>SkyBridge GDS</strong> and <strong>AeroDirect NDC</strong>). Real production deployment
            requires accredited commercial agreements and server-only credentials:
          </p>
          <ul className="list-disc pl-5 text-sm text-slate-700 space-y-1">
            <li>
              <strong>GDS Adapters (e.g., SkyBridge GDS):</strong> Requires an accredited IATA/ARC travel agency
              agreement and server-side <code>SKYBRIDGE_API_KEY</code> / <code>SKYBRIDGE_API_SECRET</code> credentials.
            </li>
            <li>
              <strong>Airline NDC Adapters (e.g., AeroDirect NDC):</strong> Requires bilateral airline NDC onboarding
              or an authorized NDC aggregator contract with server-side <code>AERODIRECT_API_KEY</code> and partner ID.
            </li>
            <li>
              <strong>Referral handoffs:</strong> Clicking &ldquo;Continue to airline&rdquo; or &ldquo;Continue to
              seller&rdquo; routes to the validated seller URL and does not create a booking or issue a ticket on airunion.
            </li>
          </ul>
          <div className="pt-2">
            <Link
              href="/search"
              className="inline-flex px-4 py-2 rounded-xl bg-[#16C2AF] text-[#0D2038] text-xs font-bold"
            >
              Start comparing flights
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
