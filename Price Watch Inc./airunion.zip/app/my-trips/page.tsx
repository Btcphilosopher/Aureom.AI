import { MyTripsClient } from '@/components/MyTripsClient';

export default function MyTripsPage() {
  return <MyTripsClient />;
}
