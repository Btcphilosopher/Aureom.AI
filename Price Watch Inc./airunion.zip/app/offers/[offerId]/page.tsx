import { OfferDetailClient } from '@/components/OfferDetailClient';

export default async function OfferDetailPage({
  params,
}: {
  params: Promise<{ offerId: string }>;
}) {
  const { offerId } = await params;
  return <OfferDetailClient offerId={decodeURIComponent(offerId)} />;
}
