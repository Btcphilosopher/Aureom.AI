import { Suspense } from 'react';
import { SearchResultsClient } from '@/components/SearchResultsClient';

export default function SearchPage() {
  return (
    <Suspense
      fallback={
        <div className="max-w-[1220px] mx-auto px-4 sm:px-6 py-12 text-sm text-slate-500">
          Loading flight comparison results...
        </div>
      }
    >
      <SearchResultsClient />
    </Suspense>
  );
}
