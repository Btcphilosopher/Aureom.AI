import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getAuthenticatedUser, validateSafeReferralUrl } from '@/lib/server/auth';
import { appendAuditLog, readStore, updateStore } from '@/lib/server/store';

export async function POST(req: NextRequest) {
  let body: { offerId?: string; referralUrl?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload.' }, { status: 400 });
  }

  const offerId = String(body.offerId ?? '');
  const store = readStore();
  const offer = store.offersById[offerId];
  if (!offer) {
    return NextResponse.json({ error: 'Offer snapshot not found.' }, { status: 404 });
  }

  const candidateUrl = body.referralUrl ? String(body.referralUrl) : offer.referralUrl;
  const validated = validateSafeReferralUrl(candidateUrl);
  if (!validated.valid) {
    return NextResponse.json(
      { error: 'Referral destination rejected by URL safety policy.' },
      { status: 400 }
    );
  }

  const user = getAuthenticatedUser(req);
  const bounds = offer.journey.bounds;
  const firstOrigin = bounds[0]?.originAirport ?? '';
  const firstDest = bounds[0]?.destinationAirport ?? '';
  const routeSummary =
    bounds.length > 1 ? `${firstOrigin} ↔ ${firstDest}` : `${firstOrigin} → ${firstDest}`;

  const handoffId = `hnd_${crypto.randomUUID().slice(0, 10)}`;
  const now = new Date().toISOString();

  updateStore((s) => {
    if (user) {
      s.handoffEvents.unshift({
        handoffId,
        userId: user.userId,
        offerId: offer.offerId,
        sellerName: offer.seller.name,
        routeSummary,
        totalAtHandoff: offer.evaluation.comparableTotal,
        referralUrl: validated.safeUrl,
        createdAt: now,
      });
    }
    appendAuditLog(
      s,
      user?.userId ?? 'anonymous',
      user?.role ?? 'system',
      'SUPPLIER_HANDOFF',
      offer.offerId,
      `Referred to ${offer.seller.name} (${validated.safeUrl})`
    );
  });

  return NextResponse.json({
    handoffId,
    referralUrl: validated.safeUrl,
    sellerName: offer.seller.name,
    sellerKind: offer.seller.kind,
    affiliateDisclosed: offer.seller.affiliateDisclosed,
    notice:
      'Clicking through transfers you to the airline or seller to complete booking. airunion does not issue tickets or create reservations.',
  });
}
