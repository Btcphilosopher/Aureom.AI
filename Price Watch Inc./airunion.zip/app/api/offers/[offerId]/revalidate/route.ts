import { NextRequest, NextResponse } from 'next/server';
import type { ProviderHealthState } from '@/lib/domain/types';
import { revalidateOfferWithProvider } from '@/lib/providers/aggregator';
import { validateSafeReferralUrl } from '@/lib/server/auth';
import { maybeProxyToFastApi } from '@/lib/server/proxy';
import { appendAuditLog, readStore, updateStore } from '@/lib/server/store';

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ offerId: string }> }
) {
  const { offerId } = await context.params;
  const proxied = await maybeProxyToFastApi(
    req,
    `/api/v1/offers/${encodeURIComponent(offerId)}/revalidate`
  );
  if (proxied) return proxied;

  const store = readStore();
  const offer = store.offersById[offerId];
  if (!offer) {
    return NextResponse.json(
      { error: 'Offer not found in session cache. Please execute a fresh search.' },
      { status: 404 }
    );
  }

  const providerStates: Record<string, ProviderHealthState> = {};
  for (const cfg of store.providerConfigs) {
    providerStates[cfg.providerId] = cfg.healthState;
  }

  const allOffers = Object.values(store.offersById);
  const result = await revalidateOfferWithProvider({
    offer: {
      ...offer,
      isExpired: Date.parse(offer.observation.expiresAt) <= Date.now(),
    },
    allOffersForSearch: allOffers,
    providerStates,
  });

  if (result.referralUrl) {
    const validated = validateSafeReferralUrl(result.referralUrl);
    result.referralUrl = validated.safeUrl;
  }

  updateStore((s) => {
    const existing = s.offersById[offerId];
    if (existing) {
      existing.observation.revalidationStatus = result.status;
      if (result.status === 'price_changed') {
        existing.evaluation.comparableTotal = result.updatedTotal;
      }
    }
    appendAuditLog(
      s,
      'anonymous',
      'system',
      'OFFER_REVALIDATED',
      offerId,
      `Status: ${result.status} (${result.updatedTotal.amount} ${result.updatedTotal.currency})`
    );
  });

  return NextResponse.json(result);
}
