import { NextRequest, NextResponse } from 'next/server';
import { convertCurrency } from '@/lib/domain/money';
import type { CurrencyCode } from '@/lib/domain/types';
import { validateSafeReferralUrl } from '@/lib/server/auth';
import { maybeProxyToFastApi } from '@/lib/server/proxy';
import { readStore } from '@/lib/server/store';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ offerId: string }> }
) {
  const { offerId } = await context.params;
  const proxied = await maybeProxyToFastApi(req, `/api/v1/offers/${encodeURIComponent(offerId)}`);
  if (proxied) return proxied;

  const store = readStore();
  const offer = store.offersById[offerId];
  if (!offer) {
    return NextResponse.json(
      { error: 'Offer not found or expired from session snapshot. Run a fresh search to retrieve live offers.' },
      { status: 404 }
    );
  }

  const currencyParam = req.nextUrl.searchParams.get('currency') as CurrencyCode | null;
  const targetCurrency: CurrencyCode =
    currencyParam && ['USD', 'CAD', 'EUR', 'GBP'].includes(currencyParam)
      ? currencyParam
      : offer.evaluation.comparableTotal.currency;

  const fxDisclosure =
    targetCurrency !== offer.evaluation.comparableTotal.currency
      ? convertCurrency(offer.evaluation.comparableTotal, targetCurrency)
      : null;

  const { safeUrl } = validateSafeReferralUrl(offer.referralUrl);
  const isExpired = Date.parse(offer.observation.expiresAt) <= Date.now();

  return NextResponse.json({
    offer: {
      ...offer,
      referralUrl: safeUrl,
      isExpired,
      evaluation: {
        ...offer.evaluation,
        fxDisclosure,
      },
    },
  });
}
