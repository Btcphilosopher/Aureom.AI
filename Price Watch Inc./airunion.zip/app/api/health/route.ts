import { NextResponse } from 'next/server';
import { FX_RATE_SOURCE, FX_RATE_TIMESTAMP } from '@/lib/domain/money';
import { readStore } from '@/lib/server/store';

export async function GET() {
  const store = readStore();
  return NextResponse.json({
    status: 'ok',
    service: 'airunion-api',
    mode: process.env.FASTAPI_BACKEND_URL ? 'fastapi-proxy' : 'standalone-nextjs',
    fx: {
      source: FX_RATE_SOURCE,
      timestamp: FX_RATE_TIMESTAMP,
    },
    providers: store.providerConfigs.map((p) => ({
      providerId: p.providerId,
      providerName: p.providerName,
      healthState: p.healthState,
    })),
  });
}
