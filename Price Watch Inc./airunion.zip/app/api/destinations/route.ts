import { NextRequest, NextResponse } from 'next/server';
import { maybeProxyToFastApi } from '@/lib/server/proxy';
import { readStore } from '@/lib/server/store';

export async function GET(req: NextRequest) {
  const proxied = await maybeProxyToFastApi(req, '/api/v1/destinations');
  if (proxied) return proxied;

  const store = readStore();
  return NextResponse.json({ destinations: store.destinations });
}
