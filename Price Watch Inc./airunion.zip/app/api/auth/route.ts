import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import {
  getAuthenticatedUser,
  hashPassword,
  isAdminClaimed,
  isAdminConfiguredInEnv,
  issueSessionToken,
  verifyAdminPasscode,
  verifyPassword,
} from '@/lib/server/auth';
import { apiRateLimiter } from '@/lib/server/cache';
import {
  appendAuditLog,
  DEMO_TRAVELER_ID,
  readStore,
  sanitizeUser,
  updateStore,
} from '@/lib/server/store';

export async function GET(req: NextRequest) {
  const user = getAuthenticatedUser(req);
  return NextResponse.json({
    user,
    adminStatus: {
      configuredInEnv: isAdminConfiguredInEnv(),
      claimed: isAdminClaimed(),
    },
  });
}

export async function POST(req: NextRequest) {
  const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'local';
  const rate = apiRateLimiter.check(`auth:${clientIp}`);
  if (!rate.allowed) {
    return NextResponse.json({ error: 'Too many authentication attempts. Try again shortly.' }, { status: 429 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload.' }, { status: 400 });
  }

  const action = String(body.action ?? '');

  if (action === 'demo_traveler') {
    const store = readStore();
    const demoUser = store.users.find((u) => u.userId === DEMO_TRAVELER_ID);
    if (!demoUser) {
      return NextResponse.json({ error: 'Demo traveler profile unavailable.' }, { status: 404 });
    }
    const pub = sanitizeUser(demoUser);
    const token = issueSessionToken(pub);
    return NextResponse.json({ token, user: pub });
  }

  if (action === 'register') {
    const email = String(body.email ?? '').trim().toLowerCase();
    const name = String(body.name ?? '').trim();
    const password = String(body.password ?? '');

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Enter a valid email address.' }, { status: 400 });
    }
    if (name.length < 2 || name.length > 60) {
      return NextResponse.json({ error: 'Name must be between 2 and 60 characters.' }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: 'Password must be at least 8 characters.' }, { status: 400 });
    }

    const store = readStore();
    if (store.users.some((u) => u.email.toLowerCase() === email)) {
      return NextResponse.json({ error: 'An account with this email already exists.' }, { status: 409 });
    }

    const { hash, salt } = hashPassword(password);
    const newUserId = `usr_${crypto.randomUUID().slice(0, 12)}`;
    const now = new Date().toISOString();

    const created = updateStore((s) => {
      const rec = {
        userId: newUserId,
        email,
        name,
        role: 'traveler' as const,
        createdAt: now,
        passwordHash: hash,
        passwordSalt: salt,
      };
      s.users.push(rec);
      appendAuditLog(s, newUserId, 'traveler', 'USER_REGISTERED', email, 'New traveler account created');
      return sanitizeUser(rec);
    });

    const token = issueSessionToken(created);
    return NextResponse.json({ token, user: created }, { status: 201 });
  }

  if (action === 'login') {
    const email = String(body.email ?? '').trim().toLowerCase();
    const password = String(body.password ?? '');
    const store = readStore();
    const found = store.users.find((u) => u.email.toLowerCase() === email);
    if (!found || !found.passwordHash || !verifyPassword(password, found.passwordHash, found.passwordSalt)) {
      return NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 });
    }
    const pub = sanitizeUser(found);
    const token = issueSessionToken(pub);
    return NextResponse.json({ token, user: pub });
  }

  if (action === 'recover_request') {
    const email = String(body.email ?? '').trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Enter a valid email address.' }, { status: 400 });
    }
    updateStore((s) => {
      appendAuditLog(
        s,
        'anonymous',
        'system',
        'PASSWORD_RECOVERY_REQUESTED',
        email,
        'Account recovery workflow requested'
      );
    });
    return NextResponse.json({
      message:
        'If an account matches that email address, recovery instructions have been queued. Configure an email relay in production to deliver reset links.',
    });
  }

  if (action === 'admin_claim') {
    if (isAdminClaimed()) {
      return NextResponse.json(
        { error: 'Admin access has already been configured or claimed.' },
        { status: 403 }
      );
    }
    const passcode = String(body.passcode ?? '');
    if (passcode.length < 8) {
      return NextResponse.json(
        { error: 'Admin passcode must be at least 8 characters.' },
        { status: 400 }
      );
    }
    const { hash, salt } = hashPassword(passcode);
    updateStore((s) => {
      s.adminCredentialHash = hash;
      s.adminCredentialSalt = salt;
      appendAuditLog(s, 'usr_admin_console', 'admin', 'ADMIN_CLAIMED', 'admin', 'First-run admin credential claimed');
    });
    const adminUser = {
      userId: 'usr_admin_console',
      email: 'admin@airunion.local',
      name: 'Platform Administrator',
      role: 'admin' as const,
      createdAt: new Date().toISOString(),
    };
    const token = issueSessionToken(adminUser);
    return NextResponse.json({ token, user: adminUser });
  }

  if (action === 'admin_login') {
    const passcode = String(body.passcode ?? '');
    if (!isAdminClaimed()) {
      return NextResponse.json(
        { error: 'Admin passcode has not been claimed yet. Complete first-run setup.' },
        { status: 400 }
      );
    }
    if (!verifyAdminPasscode(passcode)) {
      return NextResponse.json({ error: 'Invalid administrator passcode.' }, { status: 401 });
    }
    const adminUser = {
      userId: 'usr_admin_console',
      email: 'admin@airunion.local',
      name: 'Platform Administrator',
      role: 'admin' as const,
      createdAt: new Date().toISOString(),
    };
    const token = issueSessionToken(adminUser);
    return NextResponse.json({ token, user: adminUser });
  }

  return NextResponse.json({ error: 'Unsupported auth action.' }, { status: 400 });
}
