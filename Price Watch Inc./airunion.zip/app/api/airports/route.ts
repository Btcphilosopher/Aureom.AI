import { NextRequest, NextResponse } from 'next/server';
import { searchLocations } from '@/lib/data/airports';
import { maybeProxyToFastApi } from '@/lib/server/proxy';
import { readStore } from '@/lib/server/store';

export async function GET(req: NextRequest) {
  const proxied = await maybeProxyToFastApi(req, '/api/v1/airports');
  if (proxied) return proxied;

  const q = req.nextUrl.searchParams.get('q') ?? '';
  const store = readStore();
  const matches = searchLocations(q, store.airports);
  return NextResponse.json({ locations: matches });
}
