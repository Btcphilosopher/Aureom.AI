import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import type { ProviderHealthState, SearchCriteria, SearchResponse } from '@/lib/domain/types';
import { runAggregatedSearch } from '@/lib/providers/aggregator';
import { apiRateLimiter, searchResultCache } from '@/lib/server/cache';
import { maybeProxyToFastApi } from '@/lib/server/proxy';
import { readStore, updateStore } from '@/lib/server/store';

function validateCriteria(body: unknown): { ok: true; criteria: SearchCriteria } | { ok: false; error: string } {
  if (!body || typeof body !== 'object') {
    return { ok: false, error: 'Request body must be a JSON object.' };
  }
  const raw = body as Partial<SearchCriteria>;
  const tripType = raw.tripType === 'one_way' ? 'one_way' : 'round_trip';
  const originCode = String(raw.originCode ?? '').trim().toUpperCase();
  const destinationCode = String(raw.destinationCode ?? '').trim().toUpperCase();

  if (!/^[A-Z]{3}$/.test(originCode) || !/^[A-Z]{3}$/.test(destinationCode)) {
    return { ok: false, error: 'Origin and destination must be valid 3-letter airport or metro codes.' };
  }
  if (originCode === destinationCode) {
    return { ok: false, error: 'Origin and destination cannot be identical.' };
  }

  const departDate = String(raw.departDate ?? '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(departDate)) {
    return { ok: false, error: 'Departure date must be formatted YYYY-MM-DD.' };
  }

  const returnDate = tripType === 'round_trip' ? String(raw.returnDate ?? '') : undefined;
  if (tripType === 'round_trip') {
    if (!returnDate || !/^\d{4}-\d{2}-\d{2}$/.test(returnDate)) {
      return { ok: false, error: 'Return date is required for round-trip searches.' };
    }
    if (returnDate < departDate) {
      return { ok: false, error: 'Return date must be on or after the departure date.' };
    }
  }

  const pax = raw.passengers ?? { adults: 1, children: 0, infants: 0 };
  const adults = Math.max(1, Math.min(8, Number(pax.adults ?? 1)));
  const children = Math.max(0, Math.min(6, Number(pax.children ?? 0)));
  const infants = Math.max(0, Math.min(adults, Number(pax.infants ?? 0)));

  const criteria: SearchCriteria = {
    tripType,
    originCode,
    destinationCode,
    includeNearbyOrigin: Boolean(raw.includeNearbyOrigin),
    includeNearbyDestination: Boolean(raw.includeNearbyDestination),
    departDate,
    returnDate,
    passengers: { adults, children, infants },
    cabin: ['economy', 'premium_economy', 'business', 'first'].includes(String(raw.cabin))
      ? (raw.cabin as SearchCriteria['cabin'])
      : 'economy',
    requiredBaggage: ['personal_only', 'carry_on', 'checked_1'].includes(String(raw.requiredBaggage))
      ? (raw.requiredBaggage as SearchCriteria['requiredBaggage'])
      : 'carry_on',
    seatPreference: ['any', 'advance_selection', 'assigned_included'].includes(String(raw.seatPreference))
      ? (raw.seatPreference as SearchCriteria['seatPreference'])
      : 'any',
    refundableOnly: Boolean(raw.refundableOnly),
    maxStops: typeof raw.maxStops === 'number' ? raw.maxStops : null,
    currency: ['USD', 'CAD', 'EUR', 'GBP'].includes(String(raw.currency))
      ? (raw.currency as SearchCriteria['currency'])
      : 'USD',
  };

  return { ok: true, criteria };
}

export async function POST(req: NextRequest) {
  const proxied = await maybeProxyToFastApi(req, '/api/v1/flights/search');
  if (proxied) return proxied;

  const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'local';
  const rate = apiRateLimiter.check(`search:${clientIp}`);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: 'Search rate limit exceeded. Please wait before retrying.' },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload.' }, { status: 400 });
  }

  const parsed = validateCriteria(body);
  if (!parsed.ok) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }

  const store = readStore();
  const providerStates: Record<string, ProviderHealthState> = {};
  for (const p of store.providerConfigs) {
    providerStates[p.providerId] = p.healthState;
  }

  const cacheKey = JSON.stringify({ criteria: parsed.criteria, providerStates });
  const cached = searchResultCache.get(cacheKey) as SearchResponse | null;
  if (cached) {
    return NextResponse.json({ ...cached, cacheHit: true });
  }

  const response = await runAggregatedSearch({
    criteria: parsed.criteria,
    providerStates,
    cacheHit: false,
  });

  // Persist offers for subsequent offer detail inspection & revalidation
  updateStore((s) => {
    for (const group of response.groups) {
      for (const offer of group.offers) {
        s.offersById[offer.offerId] = offer;
      }
    }
    const keys = Object.keys(s.offersById);
    if (keys.length > 300) {
      for (const k of keys.slice(0, keys.length - 300)) {
        delete s.offersById[k];
      }
    }
    if (response.searchStatus === 'failed' || response.searchStatus === 'partial') {
      s.failedSearches.unshift({
        id: `fsearch_${crypto.randomUUID().slice(0, 8)}`,
        criteria: parsed.criteria,
        reason: response.statusBanner ?? 'Provider error during search',
        providersInvolved: response.providers
          .filter((p) => p.status !== 'ok')
          .map((p) => p.providerId),
        createdAt: new Date().toISOString(),
      });
      if (s.failedSearches.length > 50) s.failedSearches.length = 50;
    }
  });

  if (response.searchStatus === 'complete') {
    searchResultCache.set(cacheKey, response, 120_000);
  }

  return NextResponse.json(response);
}
