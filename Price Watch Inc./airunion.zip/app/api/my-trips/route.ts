import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { moneyFromDecimalString } from '@/lib/domain/money';
import type { CurrencyCode, SearchCriteria } from '@/lib/domain/types';
import { evaluatePriceAlerts } from '@/lib/server/alerts';
import { getAuthenticatedUser } from '@/lib/server/auth';
import { appendAuditLog, readStore, updateStore } from '@/lib/server/store';

export async function GET(req: NextRequest) {
  const user = getAuthenticatedUser(req);
  if (!user) {
    return NextResponse.json({ error: 'Sign in required to access My trips.' }, { status: 401 });
  }

  const store = readStore();
  const savedSearches = store.savedSearches.filter((s) => s.userId === user.userId);
  const savedItineraries = store.savedItineraries.filter((i) => i.userId === user.userId);
  const priceAlerts = store.priceAlerts.filter((a) => a.userId === user.userId);
  const userAlertIds = new Set(priceAlerts.map((a) => a.alertId));
  const alertRunLogs = store.alertRunLogs.filter((l) => userAlertIds.has(l.alertId));
  const handoffEvents = store.handoffEvents.filter((h) => h.userId === user.userId);
  const manualBookings = store.manualBookings.filter((b) => b.userId === user.userId);

  return NextResponse.json({
    user,
    savedSearches,
    savedItineraries,
    priceAlerts,
    alertRunLogs,
    handoffEvents,
    manualBookings,
  });
}

export async function POST(req: NextRequest) {
  const user = getAuthenticatedUser(req);
  if (!user) {
    return NextResponse.json({ error: 'Sign in required.' }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload.' }, { status: 400 });
  }

  const kind = String(body.kind ?? '');
  const now = new Date().toISOString();

  if (kind === 'saved_search') {
    const criteria = body.criteria as SearchCriteria;
    if (!criteria || !criteria.originCode || !criteria.destinationCode || !criteria.departDate) {
      return NextResponse.json({ error: 'Valid search criteria required.' }, { status: 400 });
    }
    const label =
      String(body.label ?? '').trim() ||
      `${criteria.originCode} → ${criteria.destinationCode} (${criteria.departDate})`;

    const record = updateStore((s) => {
      const rec = {
        savedSearchId: `ss_${crypto.randomUUID().slice(0, 10)}`,
        userId: user.userId,
        label,
        criteria,
        createdAt: now,
      };
      s.savedSearches.unshift(rec);
      appendAuditLog(s, user.userId, user.role, 'SAVED_SEARCH_CREATED', rec.savedSearchId, label);
      return rec;
    });
    return NextResponse.json({ record }, { status: 201 });
  }

  if (kind === 'saved_itinerary') {
    const offerId = String(body.offerId ?? '');
    const notes = String(body.notes ?? '').slice(0, 240);
    const store = readStore();
    const offer = store.offersById[offerId];
    if (!offer) {
      return NextResponse.json({ error: 'Offer snapshot unavailable to save.' }, { status: 404 });
    }
    const record = updateStore((s) => {
      const rec = {
        savedItineraryId: `si_${crypto.randomUUID().slice(0, 10)}`,
        userId: user.userId,
        offerId,
        offerSnapshot: offer,
        notes,
        savedAt: now,
      };
      s.savedItineraries.unshift(rec);
      appendAuditLog(s, user.userId, user.role, 'SAVED_ITINERARY_CREATED', rec.savedItineraryId, offerId);
      return rec;
    });
    return NextResponse.json({ record }, { status: 201 });
  }

  if (kind === 'price_alert') {
    const criteria = body.criteria as SearchCriteria;
    const targetAmountStr = String(body.targetPriceAmount ?? '380.00');
    const currency = (['USD', 'CAD', 'EUR', 'GBP'].includes(String(body.currency))
      ? body.currency
      : 'USD') as CurrencyCode;
    const frequency = body.checkFrequency === 'daily' ? 'daily' : 'every_6_hours';

    if (!criteria || !criteria.originCode || !criteria.destinationCode) {
      return NextResponse.json({ error: 'Valid search criteria required for price alert.' }, { status: 400 });
    }

    let targetPrice;
    try {
      targetPrice = moneyFromDecimalString(targetAmountStr, currency);
    } catch {
      return NextResponse.json({ error: 'Target price must be a valid decimal amount.' }, { status: 400 });
    }

    const label =
      String(body.label ?? '').trim() ||
      `${criteria.originCode} → ${criteria.destinationCode} (${criteria.requiredBaggage.replace('_', ' ')})`;

    const created = updateStore((s) => {
      const rec = {
        alertId: `al_${crypto.randomUUID().slice(0, 10)}`,
        userId: user.userId,
        label,
        criteria,
        targetPrice,
        checkFrequency: frequency as 'every_6_hours' | 'daily',
        status: 'active' as const,
        lastNotificationStatus: 'none' as const,
        createdAt: now,
      };
      s.priceAlerts.unshift(rec);
      appendAuditLog(s, user.userId, user.role, 'PRICE_ALERT_CREATED', rec.alertId, label);
      return rec;
    });

    // Run initial evaluation immediately so user sees real check state
    const checked = await evaluatePriceAlerts(created.alertId, user.userId);
    return NextResponse.json({ record: checked[0] ?? created }, { status: 201 });
  }

  if (kind === 'manual_booking') {
    const confirmationCode = String(body.confirmationCode ?? '').trim().toUpperCase();
    const airlineOrSeller = String(body.airlineOrSeller ?? '').trim();
    const routeSummary = String(body.routeSummary ?? '').trim();
    const travelDate = String(body.travelDate ?? '').trim();
    const notes = String(body.notes ?? '').trim().slice(0, 300);

    if (confirmationCode.length < 4 || airlineOrSeller.length < 2 || routeSummary.length < 3) {
      return NextResponse.json(
        { error: 'Confirmation code, airline/seller, and route summary are required.' },
        { status: 400 }
      );
    }

    const record = updateStore((s) => {
      const rec = {
        bookingRecordId: `mb_${crypto.randomUUID().slice(0, 10)}`,
        userId: user.userId,
        confirmationCode,
        airlineOrSeller,
        routeSummary,
        travelDate,
        notes,
        verificationNote: 'User-entered reference only — not verified with airline reservation system.',
        createdAt: now,
      };
      s.manualBookings.unshift(rec);
      appendAuditLog(s, user.userId, user.role, 'MANUAL_BOOKING_RECORDED', rec.bookingRecordId, confirmationCode);
      return rec;
    });
    return NextResponse.json({ record }, { status: 201 });
  }

  return NextResponse.json({ error: 'Unsupported item kind.' }, { status: 400 });
}

export async function PATCH(req: NextRequest) {
  const user = getAuthenticatedUser(req);
  if (!user) {
    return NextResponse.json({ error: 'Sign in required.' }, { status: 401 });
  }

  let body: { action?: string; alertId?: string; status?: 'active' | 'paused' };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload.' }, { status: 400 });
  }

  const alertId = String(body.alertId ?? '');
  const store = readStore();
  const existing = store.priceAlerts.find((a) => a.alertId === alertId);
  if (!existing) {
    return NextResponse.json({ error: 'Price alert not found.' }, { status: 404 });
  }
  if (existing.userId !== user.userId) {
    return NextResponse.json({ error: 'Access denied: you do not own this alert.' }, { status: 403 });
  }

  if (body.action === 'run_check') {
    const updated = await evaluatePriceAlerts(alertId, user.userId);
    return NextResponse.json({ alert: updated[0] });
  }

  if (body.status === 'active' || body.status === 'paused') {
    const nextStatus = body.status;
    const updated = updateStore((s) => {
      const item = s.priceAlerts.find((a) => a.alertId === alertId && a.userId === user.userId);
      if (item) {
        item.status = nextStatus;
      }
      return item;
    });
    return NextResponse.json({ alert: updated });
  }

  return NextResponse.json({ error: 'Unsupported alert update action.' }, { status: 400 });
}

export async function DELETE(req: NextRequest) {
  const user = getAuthenticatedUser(req);
  if (!user) {
    return NextResponse.json({ error: 'Sign in required.' }, { status: 401 });
  }

  const kind = req.nextUrl.searchParams.get('kind') ?? '';
  const id = req.nextUrl.searchParams.get('id') ?? '';

  const removed = updateStore((s) => {
    if (kind === 'saved_search') {
      const target = s.savedSearches.find((x) => x.savedSearchId === id);
      if (!target) return { status: 404 as const };
      if (target.userId !== user.userId) return { status: 403 as const };
      s.savedSearches = s.savedSearches.filter((x) => x.savedSearchId !== id);
      return { status: 200 as const };
    }
    if (kind === 'saved_itinerary') {
      const target = s.savedItineraries.find((x) => x.savedItineraryId === id);
      if (!target) return { status: 404 as const };
      if (target.userId !== user.userId) return { status: 403 as const };
      s.savedItineraries = s.savedItineraries.filter((x) => x.savedItineraryId !== id);
      return { status: 200 as const };
    }
    if (kind === 'price_alert') {
      const target = s.priceAlerts.find((x) => x.alertId === id);
      if (!target) return { status: 404 as const };
      if (target.userId !== user.userId) return { status: 403 as const };
      s.priceAlerts = s.priceAlerts.filter((x) => x.alertId !== id);
      return { status: 200 as const };
    }
    if (kind === 'manual_booking') {
      const target = s.manualBookings.find((x) => x.bookingRecordId === id);
      if (!target) return { status: 404 as const };
      if (target.userId !== user.userId) return { status: 403 as const };
      s.manualBookings = s.manualBookings.filter((x) => x.bookingRecordId !== id);
      return { status: 200 as const };
    }
    return { status: 400 as const };
  });

  if (removed.status !== 200) {
    return NextResponse.json(
      {
        error:
          removed.status === 403
            ? 'Access denied: ownership verification failed.'
            : removed.status === 404
            ? 'Record not found.'
            : 'Invalid deletion kind.',
      },
      { status: removed.status }
    );
  }

  return NextResponse.json({ ok: true });
}
