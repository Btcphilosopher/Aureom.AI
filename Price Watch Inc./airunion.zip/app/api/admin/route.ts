import { NextRequest, NextResponse } from 'next/server';
import type { DestinationItem } from '@/lib/data/destinations';
import type { LocationOption, ProviderHealthState } from '@/lib/domain/types';
import { evaluatePriceAlerts } from '@/lib/server/alerts';
import { getAuthenticatedUser } from '@/lib/server/auth';
import { searchResultCache } from '@/lib/server/cache';
import { appendAuditLog, persistStore, readStore, updateStore, type StoreSchema } from '@/lib/server/store';

function requireAdmin(req: NextRequest) {
  const user = getAuthenticatedUser(req);
  if (!user || user.role !== 'admin') {
    return null;
  }
  return user;
}

export async function GET(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin) {
    return NextResponse.json({ error: 'Administrator authorization required.' }, { status: 403 });
  }

  const store = readStore();
  return NextResponse.json({
    providerConfigs: store.providerConfigs.map((cfg) => ({
      ...cfg,
      envConfigured: cfg.credentialEnvKeys.every((k) => Boolean(process.env[k]?.trim())),
    })),
    failedSearches: store.failedSearches,
    mappingErrors: store.mappingErrors,
    airports: store.airports,
    destinations: store.destinations,
    alertRunLogs: store.alertRunLogs,
    priceAlertsCount: store.priceAlerts.length,
    auditLogs: store.auditLogs,
    cacheSize: searchResultCache.size(),
  });
}

export async function POST(req: NextRequest) {
  const admin = requireAdmin(req);
  if (!admin) {
    return NextResponse.json({ error: 'Administrator authorization required.' }, { status: 403 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload.' }, { status: 400 });
  }

  const action = String(body.action ?? '');

  if (action === 'set_provider_health') {
    const providerId = String(body.providerId ?? '');
    const healthState = String(body.healthState ?? '') as ProviderHealthState;
    if (!['healthy', 'degraded', 'outage'].includes(healthState)) {
      return NextResponse.json({ error: 'Invalid healthState.' }, { status: 400 });
    }
    const updated = updateStore((s) => {
      const cfg = s.providerConfigs.find((p) => p.providerId === providerId);
      if (!cfg) return null;
      cfg.healthState = healthState;
      cfg.updatedAt = new Date().toISOString();
      appendAuditLog(
        s,
        admin.userId,
        'admin',
        'PROVIDER_HEALTH_CHANGED',
        providerId,
        `Set health state to ${healthState}`
      );
      return cfg;
    });
    if (!updated) {
      return NextResponse.json({ error: 'Provider not found.' }, { status: 404 });
    }
    searchResultCache.clear();
    return NextResponse.json({ provider: updated });
  }

  if (action === 'resolve_mapping_error') {
    const errorId = String(body.errorId ?? '');
    const resolved = updateStore((s) => {
      const err = s.mappingErrors.find((e) => e.id === errorId);
      if (!err) return null;
      err.resolved = true;
      appendAuditLog(s, admin.userId, 'admin', 'MAPPING_ERROR_RESOLVED', errorId, err.rawCode);
      return err;
    });
    if (!resolved) return NextResponse.json({ error: 'Mapping error not found.' }, { status: 404 });
    return NextResponse.json({ mappingError: resolved });
  }

  if (action === 'upsert_airport') {
    const loc = body.airport as LocationOption;
    if (!loc || !/^[A-Z]{3}$/.test(String(loc.code ?? '')) || !loc.timezone || !loc.name) {
      return NextResponse.json({ error: 'Valid airport code, name, and IANA timezone required.' }, { status: 400 });
    }
    updateStore((s) => {
      const idx = s.airports.findIndex((a) => a.code === loc.code);
      if (idx >= 0) {
        s.airports[idx] = loc;
      } else {
        s.airports.push(loc);
      }
      appendAuditLog(s, admin.userId, 'admin', 'AIRPORT_UPSERTED', loc.code, loc.name);
    });
    return NextResponse.json({ ok: true });
  }

  if (action === 'upsert_destination') {
    const dest = body.destination as DestinationItem;
    if (!dest || !dest.id || !dest.title || !dest.destinationCode) {
      return NextResponse.json({ error: 'Valid destination record required.' }, { status: 400 });
    }
    updateStore((s) => {
      const idx = s.destinations.findIndex((d) => d.id === dest.id);
      if (idx >= 0) {
        s.destinations[idx] = dest;
      } else {
        s.destinations.push(dest);
      }
      appendAuditLog(s, admin.userId, 'admin', 'DESTINATION_UPDATED', dest.id, dest.title);
    });
    return NextResponse.json({ ok: true });
  }

  if (action === 'run_all_alerts') {
    const results = await evaluatePriceAlerts(undefined, admin.userId);
    return NextResponse.json({ checkedCount: results.length, alerts: results });
  }

  if (action === 'export_backup') {
    const store = readStore();
    return NextResponse.json({
      exportedAt: new Date().toISOString(),
      snapshot: {
        ...store,
        adminCredentialHash: '[REDACTED]',
        adminCredentialSalt: '[REDACTED]',
        users: store.users.map((u) => ({
          ...u,
          passwordHash: '[REDACTED]',
          passwordSalt: '[REDACTED]',
        })),
      },
    });
  }

  if (action === 'restore_backup') {
    const snapshot = body.snapshot as Partial<StoreSchema>;
    if (!snapshot || !Array.isArray(snapshot.airports) || !Array.isArray(snapshot.providerConfigs)) {
      return NextResponse.json({ error: 'Invalid backup snapshot structure.' }, { status: 400 });
    }
    const current = readStore();
    const merged: StoreSchema = {
      ...current,
      providerConfigs: snapshot.providerConfigs,
      airports: snapshot.airports,
      destinations: Array.isArray(snapshot.destinations) ? snapshot.destinations : current.destinations,
    };
    appendAuditLog(merged, admin.userId, 'admin', 'BACKUP_RESTORED', 'store', 'Restored provider, airport, and destination configuration snapshot');
    persistStore(merged);
    searchResultCache.clear();
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: 'Unsupported admin action.' }, { status: 400 });
}
