import { AdminConsoleClient } from '@/components/AdminConsoleClient';

export default function AdminPage() {
  return <AdminConsoleClient />;
}
