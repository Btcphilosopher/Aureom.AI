import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight, MapPin } from 'lucide-react';
import { DEFAULT_DESTINATIONS } from '@/lib/data/destinations';
import { AIRUNION_MEDIA } from '@/lib/data/media';
import { getDefaultFutureDates } from '@/lib/domain/timezone';

export default function DestinationsPage() {
  const { departDate, returnDate } = getDefaultFutureDates();

  return (
    <div className="bg-[#F4F7FA] min-h-screen pb-14">
      <div className="bg-[#0D2038] text-white py-10 border-b border-white/10">
        <div className="max-w-[1220px] mx-auto px-4 sm:px-6">
          <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight">
            US destinations & route inspiration
          </h1>
          <div className="w-16 h-[3px] bg-[#EB5E47] rounded-full mt-2.5 mb-3" />
          <p className="text-slate-300 max-w-2xl text-sm sm:text-base">
            Every destination card opens a prefilled comparison search using upcoming dates ({departDate} to {returnDate}) and authentic commercial airport codes.
          </p>
        </div>
      </div>

      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 pt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {DEFAULT_DESTINATIONS.map((dest) => {
          const params = new URLSearchParams({
            tripType: 'round_trip',
            origin: dest.defaultOriginCode,
            dest: dest.destinationCode,
            depart: departDate,
            return: returnDate,
            adults: '1',
            children: '0',
            infants: '0',
            cabin: 'economy',
            bag: 'carry_on',
            seat: 'any',
            currency: 'USD',
          });
          return (
            <article
              key={dest.id}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden flex flex-col"
            >
              <div className="relative aspect-[16/10]">
                <Image
                  src={AIRUNION_MEDIA[dest.imageKey]}
                  alt={dest.title}
                  fill
                  referrerPolicy="no-referrer"
                  className="object-cover"
                />
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <h2 className="font-display text-xl font-bold text-[#0D2038]">
                      {dest.title}
                    </h2>
                    <span className="font-mono text-xs font-semibold text-[#0E5952]">
                      {dest.defaultOriginCode} → {dest.destinationCode}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 leading-relaxed">{dest.subtitle}</p>
                  <p className="mt-3 text-xs text-slate-500 flex items-start gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#EB5E47] shrink-0 mt-0.5" />
                    <span>{dest.airportDisclosure}</span>
                  </p>
                </div>

                <Link
                  href={`/search?${params.toString()}`}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#16C2AF] hover:bg-[#12AD9C] text-[#0D2038] font-bold text-xs sm:text-sm transition-colors"
                >
                  <span>Explore {dest.destinationLabel} flights</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
