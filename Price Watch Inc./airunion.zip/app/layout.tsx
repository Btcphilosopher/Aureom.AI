import type { Metadata } from 'next';
import { DM_Sans, JetBrains_Mono, Plus_Jakarta_Sans } from 'next/font/google';
import { AuthModal } from '@/components/AuthModal';
import { AuthProvider } from '@/components/AuthProvider';
import { Footer } from '@/components/Footer';
import { Header } from '@/components/Header';
import './globals.css';

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['500', '600', '700', '800'],
  variable: '--font-jakarta',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-dm-sans',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-jetbrains-mono',
});

export const metadata: Metadata = {
  title: 'airunion — Compare flights. Understand your fare. Fly your way.',
  description:
    'Independent US flight comparison platform with like-for-like fare, baggage, seat, and seller transparency.',
  openGraph: {
    title: 'airunion — Independent US Flight Comparison',
    description:
      'Compare flights across airlines and sellers with transparent baggage allowances, seat terms, and live fare revalidation.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'airunion — Independent US Flight Comparison',
    description:
      'Compare flights across airlines and sellers with transparent baggage allowances, seat terms, and live fare revalidation.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${plusJakarta.variable} ${dmSans.variable} ${jetbrainsMono.variable}`}
    >
      <body suppressHydrationWarning className="min-h-screen flex flex-col bg-white text-slate-900">
        <AuthProvider>
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <AuthModal />
        </AuthProvider>
      </body>
    </html>
  );
}
