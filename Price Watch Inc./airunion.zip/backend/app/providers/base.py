from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, List, Optional
from ..domain.models import Offer, SearchCriteria


@dataclass
class ProviderSearchResult:
    provider_id: str
    provider_name: str
    status: str  # ok | partial | failed
    latency_ms: int
    offers: List[Offer]
    error_message: Optional[str] = None


class FlightProviderAdapter(ABC):
    provider_id: str
    provider_name: str
    credential_env_keys: List[str]
    commercial_access_note: str

    @abstractmethod
    async def search(
        self,
        criteria: SearchCriteria,
        health_state: str = "healthy",
        now_iso: Optional[str] = None,
    ) -> ProviderSearchResult:
        raise NotImplementedError

    @abstractmethod
    async def revalidate_offer(
        self,
        offer: Offer,
        health_state: str = "healthy",
        now_iso: Optional[str] = None,
    ) -> Dict[str, object]:
        raise NotImplementedError
