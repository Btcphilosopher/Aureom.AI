from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional
from ..domain.comparison import build_canonical_key
from ..domain.models import (
    BaggageRule,
    CabinClass,
    CarrierInfo,
    FlightSegment,
    InclusionStatus,
    Journey,
    JourneyBound,
    Offer,
    PriceObservation,
    PricedExtraOption,
    FareProduct,
    SearchCriteria,
    SeatAssignmentStatus,
    SegmentBaggageAllowance,
    Seller,
)
from ..domain.pricing import add_money, calculate_passenger_pricing, make_money
from ..domain.timezone_utils import build_segment_times
from .base import FlightProviderAdapter, ProviderSearchResult


class SkyBridgeGdsAdapter(FlightProviderAdapter):
    provider_id = "skybridge_gds"
    provider_name = "SkyBridge GDS"
    credential_env_keys = ["SKYBRIDGE_API_KEY", "SKYBRIDGE_API_SECRET"]
    commercial_access_note = (
        "Simulated GDS fixture. Production GDS integration requires IATA/ARC accreditation and GDS credentials."
    )

    async def search(
        self,
        criteria: SearchCriteria,
        health_state: str = "healthy",
        now_iso: Optional[str] = None,
    ) -> ProviderSearchResult:
        if health_state == "outage":
            return ProviderSearchResult(
                provider_id=self.provider_id,
                provider_name=self.provider_name,
                status="failed",
                latency_ms=140,
                offers=[],
                error_message="SkyBridge GDS upstream 503 Service Unavailable.",
            )

        now_dt = datetime.fromisoformat(now_iso) if now_iso else datetime.now(timezone.utc)
        dep = criteria.depart_date
        ret = criteria.return_date or criteria.depart_date
        bounds_count = 2 if criteria.trip_type == "round_trip" else 1
        pax_bag_count = max(1, criteria.passengers.adults + criteria.passengers.children)

        dep_utc, arr_utc, dur, day_off, dst = build_segment_times(
            dep, "08:30", "America/New_York", dep, "11:45", "America/Los_Angeles"
        )
        out_seg = FlightSegment(
            segment_id="seg-aa117-out",
            flight_number="AA 117",
            marketing_carrier=CarrierInfo("AA", "American Airlines"),
            operating_carrier=CarrierInfo("AA", "American Airlines"),
            origin_airport="JFK",
            destination_airport="LAX",
            origin_timezone="America/New_York",
            destination_timezone="America/Los_Angeles",
            departure_utc=dep_utc.isoformat(),
            arrival_utc=arr_utc.isoformat(),
            duration_minutes=dur,
            cabin=criteria.cabin,
            day_offset=day_off,
            dst_transitioned=dst,
        )
        bounds = [
            JourneyBound(
                bound_id="bnd-aa117-out",
                direction="outbound",
                origin_airport="JFK",
                destination_airport="LAX",
                segments=[out_seg],
                connections=[],
                total_duration_minutes=dur,
                stops=0,
                has_mixed_cabins=False,
                has_overnight_arrival=day_off > 0,
                has_airport_change=False,
                has_self_transfer=False,
            )
        ]

        if criteria.trip_type == "round_trip":
            r_dep_utc, r_arr_utc, r_dur, r_day, r_dst = build_segment_times(
                ret, "13:15", "America/Los_Angeles", ret, "21:40", "America/New_York"
            )
            in_seg = FlightSegment(
                segment_id="seg-aa118-in",
                flight_number="AA 118",
                marketing_carrier=CarrierInfo("AA", "American Airlines"),
                operating_carrier=CarrierInfo("AA", "American Airlines"),
                origin_airport="LAX",
                destination_airport="JFK",
                origin_timezone="America/Los_Angeles",
                destination_timezone="America/New_York",
                departure_utc=r_dep_utc.isoformat(),
                arrival_utc=r_arr_utc.isoformat(),
                duration_minutes=r_dur,
                cabin=criteria.cabin,
                day_offset=r_day,
                dst_transitioned=r_dst,
            )
            bounds.append(
                JourneyBound(
                    bound_id="bnd-aa118-in",
                    direction="inbound",
                    origin_airport="LAX",
                    destination_airport="JFK",
                    segments=[in_seg],
                    connections=[],
                    total_duration_minutes=r_dur,
                    stops=0,
                    has_mixed_cabins=False,
                    has_overnight_arrival=r_day > 0,
                    has_airport_change=False,
                    has_self_transfer=False,
                )
            )

        journey = Journey(
            journey_id="jrn-aa117-jfk-lax",
            canonical_key="",
            bounds=bounds,
            total_duration_minutes=sum(b.total_duration_minutes for b in bounds),
            max_stops=0,
        )
        journey.canonical_key = build_canonical_key(journey)

        lines, base_total, tax_total = calculate_passenger_pricing(
            criteria.passengers,
            19600 if bounds_count == 2 else 10800,
            6200 if bounds_count == 2 else 3400,
        )
        checked_fee = make_money(6500 * bounds_count * pax_bag_count)
        bag_rules = [
            SegmentBaggageAllowance(
                segment_id=seg.segment_id,
                personal_item=BaggageRule(InclusionStatus.INCLUDED, pieces=1),
                carry_on=BaggageRule(InclusionStatus.INCLUDED, pieces=1, max_weight_lb=35),
                checked_bag=BaggageRule(
                    InclusionStatus.PAID_EXTRA, pieces=1, max_weight_lb=50, fee_if_extra=checked_fee
                ),
            )
            for b in bounds
            for seg in b.segments
        ]
        expires = (now_dt + timedelta(minutes=45)).isoformat()
        offer = Offer(
            offer_id=f"sb-cf-aa117-{criteria.trip_type}",
            journey=journey,
            seller=Seller("sel-clearfare", "clearfare-travel", "ClearFare Travel", "ota", True),
            fare_product=FareProduct(
                fare_family_name="Basic Economy",
                booking_class="B",
                is_basic_economy=True,
                is_separate_tickets=False,
                change_allowed=InclusionStatus.NOT_INCLUDED,
                refund_allowed=InclusionStatus.NOT_INCLUDED,
                seat_status=SeatAssignmentStatus.ADVANCE_SELECTION_PAID,
                baggage_per_segment=bag_rules,
            ),
            observation=PriceObservation(
                observation_id="obs-sb-cf-aa117",
                provider_id=self.provider_id,
                provider_name=self.provider_name,
                provider_offer_ref="SB-CF-AA117-BE",
                collected_at=now_dt.isoformat(),
                expires_at=expires,
                revalidation_status="unverified",
                passenger_lines=lines,
                base_fare_total=base_total,
                taxes_and_mandatory_total=tax_total,
                available_extras=[
                    PricedExtraOption("ext-checked-1", "checked_1", "1st Checked Bag", checked_fee)
                ],
            ),
            referral_url=f"/supplier/clearfare-travel?offerId=sb-cf-aa117-{criteria.trip_type}",
        )

        offers: List[Offer] = [offer]
        if health_state == "degraded":
            return ProviderSearchResult(
                provider_id=self.provider_id,
                provider_name=self.provider_name,
                status="partial",
                latency_ms=890,
                offers=offers,
                error_message="SkyBridge GDS degraded performance.",
            )

        return ProviderSearchResult(
            provider_id=self.provider_id,
            provider_name=self.provider_name,
            status="ok",
            latency_ms=175,
            offers=offers,
        )

    async def revalidate_offer(
        self,
        offer: Offer,
        health_state: str = "healthy",
        now_iso: Optional[str] = None,
    ) -> Dict[str, object]:
        now_dt = datetime.fromisoformat(now_iso) if now_iso else datetime.now(timezone.utc)
        base_plus_tax = add_money(
            offer.observation.base_fare_total, offer.observation.taxes_and_mandatory_total
        )
        if health_state == "outage":
            return {
                "offerId": offer.offer_id,
                "status": "unavailable",
                "checkedAt": now_dt.isoformat(),
                "previousTotal": base_plus_tax.to_dict(),
                "updatedTotal": base_plus_tax.to_dict(),
                "requiresFreshSelection": False,
                "message": "SkyBridge GDS outage during revalidation.",
            }
        if "pricechange" in offer.offer_id:
            updated = make_money(base_plus_tax.minor_units + 2400, base_plus_tax.currency)
            return {
                "offerId": offer.offer_id,
                "status": "price_changed",
                "checkedAt": now_dt.isoformat(),
                "previousTotal": base_plus_tax.to_dict(),
                "updatedTotal": updated.to_dict(),
                "requiresFreshSelection": True,
                "message": "Carrier repricing detected (+24.00 USD).",
                "referralUrl": offer.referral_url,
            }
        return {
            "offerId": offer.offer_id,
            "status": "confirmed",
            "checkedAt": now_dt.isoformat(),
            "previousTotal": base_plus_tax.to_dict(),
            "updatedTotal": base_plus_tax.to_dict(),
            "requiresFreshSelection": False,
            "message": "Offer confirmed.",
            "referralUrl": offer.referral_url,
        }
