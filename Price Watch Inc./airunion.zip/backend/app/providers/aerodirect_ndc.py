from datetime import datetime, timedelta, timezone
from typing import Dict, Optional
from ..domain.comparison import build_canonical_key
from ..domain.models import (
    BaggageRule,
    CarrierInfo,
    FareProduct,
    FlightSegment,
    InclusionStatus,
    Journey,
    JourneyBound,
    Offer,
    PriceObservation,
    SearchCriteria,
    SeatAssignmentStatus,
    SegmentBaggageAllowance,
    Seller,
)
from ..domain.pricing import add_money, calculate_passenger_pricing
from ..domain.timezone_utils import build_segment_times
from .base import FlightProviderAdapter, ProviderSearchResult


class AeroDirectNdcAdapter(FlightProviderAdapter):
    provider_id = "aerodirect_ndc"
    provider_name = "AeroDirect NDC"
    credential_env_keys = ["AERODIRECT_API_KEY", "AERODIRECT_PARTNER_ID"]
    commercial_access_note = (
        "Simulated NDC fixture. Live NDC integration requires airline bilateral onboarding."
    )

    async def search(
        self,
        criteria: SearchCriteria,
        health_state: str = "healthy",
        now_iso: Optional[str] = None,
    ) -> ProviderSearchResult:
        if health_state == "outage":
            return ProviderSearchResult(
                provider_id=self.provider_id,
                provider_name=self.provider_name,
                status="failed",
                latency_ms=95,
                offers=[],
                error_message="AeroDirect NDC 502 Bad Gateway.",
            )

        now_dt = datetime.fromisoformat(now_iso) if now_iso else datetime.now(timezone.utc)
        dep = criteria.depart_date
        ret = criteria.return_date or criteria.depart_date
        bounds_count = 2 if criteria.trip_type == "round_trip" else 1

        dep_utc, arr_utc, dur, day_off, dst = build_segment_times(
            dep, "08:30", "America/New_York", dep, "11:45", "America/Los_Angeles"
        )
        out_seg = FlightSegment(
            segment_id="seg-ad-aa117-out",
            flight_number="AA 117",
            marketing_carrier=CarrierInfo("AA", "American Airlines"),
            operating_carrier=CarrierInfo("AA", "American Airlines"),
            origin_airport="JFK",
            destination_airport="LAX",
            origin_timezone="America/New_York",
            destination_timezone="America/Los_Angeles",
            departure_utc=dep_utc.isoformat(),
            arrival_utc=arr_utc.isoformat(),
            duration_minutes=dur,
            cabin=criteria.cabin,
            day_offset=day_off,
            dst_transitioned=dst,
        )
        bounds = [
            JourneyBound(
                bound_id="bnd-ad-aa117-out",
                direction="outbound",
                origin_airport="JFK",
                destination_airport="LAX",
                segments=[out_seg],
                connections=[],
                total_duration_minutes=dur,
                stops=0,
                has_mixed_cabins=False,
                has_overnight_arrival=day_off > 0,
                has_airport_change=False,
                has_self_transfer=False,
            )
        ]

        if criteria.trip_type == "round_trip":
            r_dep_utc, r_arr_utc, r_dur, r_day, r_dst = build_segment_times(
                ret, "13:15", "America/Los_Angeles", ret, "21:40", "America/New_York"
            )
            in_seg = FlightSegment(
                segment_id="seg-ad-aa118-in",
                flight_number="AA 118",
                marketing_carrier=CarrierInfo("AA", "American Airlines"),
                operating_carrier=CarrierInfo("AA", "American Airlines"),
                origin_airport="LAX",
                destination_airport="JFK",
                origin_timezone="America/Los_Angeles",
                destination_timezone="America/New_York",
                departure_utc=r_dep_utc.isoformat(),
                arrival_utc=r_arr_utc.isoformat(),
                duration_minutes=r_dur,
                cabin=criteria.cabin,
                day_offset=r_day,
                dst_transitioned=r_dst,
            )
            bounds.append(
                JourneyBound(
                    bound_id="bnd-ad-aa118-in",
                    direction="inbound",
                    origin_airport="LAX",
                    destination_airport="JFK",
                    segments=[in_seg],
                    connections=[],
                    total_duration_minutes=r_dur,
                    stops=0,
                    has_mixed_cabins=False,
                    has_overnight_arrival=r_day > 0,
                    has_airport_change=False,
                    has_self_transfer=False,
                )
            )

        journey = Journey(
            journey_id="jrn-ad-aa117-jfk-lax",
            canonical_key="",
            bounds=bounds,
            total_duration_minutes=sum(b.total_duration_minutes for b in bounds),
            max_stops=0,
        )
        journey.canonical_key = build_canonical_key(journey)

        lines, base_total, tax_total = calculate_passenger_pricing(
            criteria.passengers,
            28200 if bounds_count == 2 else 15200,
            7200 if bounds_count == 2 else 3800,
        )
        bag_rules = [
            SegmentBaggageAllowance(
                segment_id=seg.segment_id,
                personal_item=BaggageRule(InclusionStatus.INCLUDED, pieces=1),
                carry_on=BaggageRule(InclusionStatus.INCLUDED, pieces=1, max_weight_lb=40),
                checked_bag=BaggageRule(InclusionStatus.INCLUDED, pieces=1, max_weight_lb=50),
            )
            for b in bounds
            for seg in b.segments
        ]
        expires = (now_dt + timedelta(minutes=75)).isoformat()
        offer = Offer(
            offer_id=f"ad-aa-aa117-plus-{criteria.trip_type}",
            journey=journey,
            seller=Seller(
                "sel-aa-ndc", "american-airlines-ndc", "American Airlines (NDC Direct)", "airline_direct", False
            ),
            fare_product=FareProduct(
                fare_family_name="Main Plus (1 Bag Included)",
                booking_class="N",
                is_basic_economy=False,
                is_separate_tickets=False,
                change_allowed=InclusionStatus.INCLUDED,
                refund_allowed=InclusionStatus.INCLUDED,
                seat_status=SeatAssignmentStatus.ADVANCE_SELECTION_INCLUDED,
                baggage_per_segment=bag_rules,
            ),
            observation=PriceObservation(
                observation_id="obs-ad-aa117-plus",
                provider_id=self.provider_id,
                provider_name=self.provider_name,
                provider_offer_ref="AD-AA117-MAINPLUS",
                collected_at=now_dt.isoformat(),
                expires_at=expires,
                revalidation_status="unverified",
                passenger_lines=lines,
                base_fare_total=base_total,
                taxes_and_mandatory_total=tax_total,
                available_extras=[],
            ),
            referral_url=f"/supplier/american-airlines-ndc?offerId=ad-aa-aa117-plus-{criteria.trip_type}",
        )

        return ProviderSearchResult(
            provider_id=self.provider_id,
            provider_name=self.provider_name,
            status="ok",
            latency_ms=135,
            offers=[offer],
        )

    async def revalidate_offer(
        self,
        offer: Offer,
        health_state: str = "healthy",
        now_iso: Optional[str] = None,
    ) -> Dict[str, object]:
        now_dt = datetime.fromisoformat(now_iso) if now_iso else datetime.now(timezone.utc)
        base_plus_tax = add_money(
            offer.observation.base_fare_total, offer.observation.taxes_and_mandatory_total
        )
        if health_state == "outage":
            return {
                "offerId": offer.offer_id,
                "status": "unavailable",
                "checkedAt": now_dt.isoformat(),
                "previousTotal": base_plus_tax.to_dict(),
                "updatedTotal": base_plus_tax.to_dict(),
                "requiresFreshSelection": False,
                "message": "AeroDirect NDC unreachable.",
            }
        expires_dt = datetime.fromisoformat(offer.observation.expires_at.replace("Z", "+00:00"))
        if expires_dt <= now_dt or "expired" in offer.offer_id:
            return {
                "offerId": offer.offer_id,
                "status": "expired",
                "checkedAt": now_dt.isoformat(),
                "previousTotal": base_plus_tax.to_dict(),
                "updatedTotal": base_plus_tax.to_dict(),
                "requiresFreshSelection": True,
                "message": "Offer snapshot expired before revalidation.",
            }
        return {
            "offerId": offer.offer_id,
            "status": "confirmed",
            "checkedAt": now_dt.isoformat(),
            "previousTotal": base_plus_tax.to_dict(),
            "updatedTotal": base_plus_tax.to_dict(),
            "requiresFreshSelection": False,
            "message": "NDC offer confirmed.",
            "referralUrl": offer.referral_url,
        }
