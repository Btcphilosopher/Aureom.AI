import asyncio
import logging
from datetime import datetime, timezone
from sqlalchemy import text
from .domain.comparison import evaluate_offer
from .domain.models import BaggageRequirement, CabinClass, PassengerComposition, SearchCriteria, SeatPreference
from .providers.aerodirect_ndc import AeroDirectNdcAdapter
from .providers.skybridge_gds import SkyBridgeGdsAdapter
from .services.db import SessionLocal

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("airunion.worker")

ADAPTERS = [SkyBridgeGdsAdapter(), AeroDirectNdcAdapter()]


async def run_periodic_alert_cycle() -> None:
    """Evaluates active price alerts periodically preserving baggage, cabin, and traveler requirements."""
    now_iso = datetime.now(timezone.utc).isoformat()
    async with SessionLocal() as session:
        rows = (
            await session.execute(
                text(
                    "SELECT alert_id, criteria, target_price_minor, target_currency "
                    "FROM price_alerts WHERE status != 'paused'"
                )
            )
        ).fetchall()

        for row in rows:
            c = row.criteria
            criteria = SearchCriteria(
                trip_type=c.get("tripType", "round_trip"),
                origin_code=c.get("originCode", "NYC"),
                destination_code=c.get("destinationCode", "LAX"),
                depart_date=c.get("departDate", "2026-12-15"),
                return_date=c.get("returnDate"),
                passengers=PassengerComposition(
                    adults=int(c.get("passengers", {}).get("adults", 1)),
                    children=int(c.get("passengers", {}).get("children", 0)),
                    infants=int(c.get("passengers", {}).get("infants", 0)),
                ),
                cabin=CabinClass(c.get("cabin", "economy")),
                required_baggage=BaggageRequirement(c.get("requiredBaggage", "carry_on")),
                seat_preference=SeatPreference(c.get("seatPreference", "any")),
                refundable_only=bool(c.get("refundableOnly", False)),
            )
            results = await asyncio.gather(*[a.search(criteria, "healthy", now_iso) for a in ADAPTERS])
            offers = [o for r in results for o in r.offers]
            eligible = []
            for offer in offers:
                ev = evaluate_offer(offer, criteria)
                if ev.eligibility == "eligible" and not offer.is_expired:
                    eligible.append(offer)

            eligible.sort(key=lambda o: o.evaluation.comparable_total.minor_units if o.evaluation else 9999999)
            best = eligible[0] if eligible else None
            if best and best.evaluation and best.evaluation.comparable_total.minor_units <= row.target_price_minor:
                outcome = "notified"
                observed = best.evaluation.comparable_total.minor_units
                msg = f"Eligible offer {best.offer_id} matched target ({observed} minor units)."
            else:
                outcome = "not_eligible_for_requirements"
                observed = best.evaluation.comparable_total.minor_units if (best and best.evaluation) else None
                msg = "No eligible offer meeting saved baggage/cabin requirements fell below target."

            await session.execute(
                text(
                    "UPDATE price_alerts SET last_checked_at = NOW(), "
                    "last_checked_price_minor = :obs, last_notification_status = :out, "
                    "last_notification_message = :msg WHERE alert_id = :aid"
                ),
                {"obs": observed, "out": outcome, "msg": msg, "aid": row.alert_id},
            )
        await session.commit()
    logger.info("Periodic alert cycle completed for %d alerts", len(rows))


async def worker_loop() -> None:
    while True:
        try:
            await run_periodic_alert_cycle()
        except Exception as exc:
            logger.warning("Alert cycle skipped: %s", exc)
        await asyncio.sleep(300)


if __name__ == "__main__":
    asyncio.run(worker_loop())
