from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List
from .models import (
    BaggageRequirement,
    CabinClass,
    InclusionStatus,
    Journey,
    Offer,
    OfferEvaluation,
    SearchCriteria,
    SeatAssignmentStatus,
    SeatPreference,
)
from .pricing import add_money, make_money

CABIN_RANK = {
    CabinClass.ECONOMY: 1,
    CabinClass.PREMIUM_ECONOMY: 2,
    CabinClass.BUSINESS: 3,
    CabinClass.FIRST: 4,
}


def build_canonical_key(journey: Journey) -> str:
    bound_keys: List[str] = []
    for bound in journey.bounds:
        seg_keys = [
            f"{s.operating_carrier.code}:{s.origin_airport}-{s.destination_airport}:{s.departure_utc[:16]}-{s.arrival_utc[:16]}"
            for s in bound.segments
        ]
        bound_keys.append(f"{bound.direction}[{'>'.join(seg_keys)}]")
    return "|".join(bound_keys)


def evaluate_offer(
    offer: Offer,
    criteria: SearchCriteria,
    now_utc: datetime | None = None,
) -> OfferEvaluation:
    now_dt = now_utc or datetime.now(timezone.utc)
    reasons: List[str] = []
    missing_fields: List[str] = []
    ineligible = False
    incomplete = False

    base_plus_tax = add_money(
        offer.observation.base_fare_total,
        offer.observation.taxes_and_mandatory_total,
    )
    extras_minor = 0

    req_cabin_rank = CABIN_RANK[criteria.cabin]
    for bound in offer.journey.bounds:
        for seg in bound.segments:
            if CABIN_RANK[seg.cabin] < req_cabin_rank:
                ineligible = True
                reasons.append(f"Segment {seg.flight_number} is {seg.cabin.value}")

    bag_list = offer.fare_product.baggage_per_segment
    if not bag_list:
        incomplete = True
        missing_fields.append("baggage_allowance")
        reasons.append("Baggage allowance missing")
    else:
        if any(b.personal_item.status == InclusionStatus.UNKNOWN for b in bag_list):
            incomplete = True
            missing_fields.append("personal_item")
            reasons.append("Personal item rule unknown")

        if criteria.required_baggage in (BaggageRequirement.CARRY_ON, BaggageRequirement.CHECKED_1):
            statuses = [b.carry_on.status for b in bag_list]
            if any(s == InclusionStatus.UNKNOWN for s in statuses):
                incomplete = True
                missing_fields.append("carry_on")
                reasons.append("Carry-on allowance unknown")
            elif any(s == InclusionStatus.NOT_INCLUDED for s in statuses):
                ineligible = True
                reasons.append("Carry-on not permitted")
            elif any(s == InclusionStatus.PAID_EXTRA for s in statuses):
                extra = next((e for e in offer.observation.available_extras if e.kind == "carry_on"), None)
                if extra:
                    extras_minor += extra.price_for_trip.minor_units
                else:
                    incomplete = True
                    missing_fields.append("carry_on_fee")

        if criteria.required_baggage == BaggageRequirement.CHECKED_1:
            statuses = [b.checked_bag.status for b in bag_list]
            if any(s == InclusionStatus.UNKNOWN for s in statuses):
                incomplete = True
                missing_fields.append("checked_bag")
                reasons.append("Checked bag allowance unknown")
            elif any(s == InclusionStatus.NOT_INCLUDED for s in statuses):
                ineligible = True
                reasons.append("Checked bag not permitted")
            elif any(s == InclusionStatus.PAID_EXTRA for s in statuses):
                extra = next((e for e in offer.observation.available_extras if e.kind == "checked_1"), None)
                if extra:
                    extras_minor += extra.price_for_trip.minor_units
                else:
                    incomplete = True
                    missing_fields.append("checked_bag_fee")

    if criteria.seat_preference == SeatPreference.ASSIGNED_INCLUDED:
        if offer.fare_product.seat_status == SeatAssignmentStatus.UNKNOWN:
            incomplete = True
            missing_fields.append("seat_assignment")
        elif offer.fare_product.seat_status not in (
            SeatAssignmentStatus.ASSIGNED_INCLUDED,
            SeatAssignmentStatus.ADVANCE_SELECTION_INCLUDED,
        ):
            ineligible = True
            reasons.append("Included seat assignment unavailable")
    elif criteria.seat_preference == SeatPreference.ADVANCE_SELECTION:
        if offer.fare_product.seat_status == SeatAssignmentStatus.UNKNOWN:
            incomplete = True
            missing_fields.append("seat_selection")
        elif offer.fare_product.seat_status == SeatAssignmentStatus.ASSIGNED_AT_CHECKIN:
            ineligible = True
            reasons.append("Advance seat selection unavailable")
        elif offer.fare_product.seat_status == SeatAssignmentStatus.ADVANCE_SELECTION_PAID:
            extra = next((e for e in offer.observation.available_extras if e.kind == "advance_seat"), None)
            if extra:
                extras_minor += extra.price_for_trip.minor_units
            else:
                incomplete = True
                missing_fields.append("advance_seat_fee")

    if criteria.refundable_only:
        if offer.fare_product.refund_allowed == InclusionStatus.UNKNOWN:
            incomplete = True
            missing_fields.append("refund_conditions")
        elif offer.fare_product.refund_allowed == InclusionStatus.NOT_INCLUDED:
            ineligible = True
            reasons.append("Non-refundable fare")

    required_extras = make_money(extras_minor, base_plus_tax.currency)
    comparable_total = add_money(base_plus_tax, required_extras)
    pax_count = max(1, criteria.passengers.total_count)
    per_person_minor = int(
        (Decimal(comparable_total.minor_units) / Decimal(pax_count)).quantize(
            Decimal("1"), rounding=ROUND_HALF_UP
        )
    )
    per_person = make_money(per_person_minor, comparable_total.currency)

    eligibility = "ineligible" if ineligible else "incomplete" if incomplete else "eligible"
    expires_dt = datetime.fromisoformat(offer.observation.expires_at.replace("Z", "+00:00"))
    offer.is_expired = expires_dt <= now_dt

    ev = OfferEvaluation(
        eligibility=eligibility,
        reasons=reasons,
        required_extras_total=required_extras,
        comparable_total=comparable_total,
        per_person_average=per_person,
        missing_data_fields=missing_fields,
    )
    offer.evaluation = ev
    return ev


def group_duplicate_itineraries(offers: List[Offer]) -> Dict[str, List[Offer]]:
    groups: Dict[str, List[Offer]] = {}
    for offer in offers:
        key = build_canonical_key(offer.journey)
        groups.setdefault(key, []).append(offer)
    return groups
