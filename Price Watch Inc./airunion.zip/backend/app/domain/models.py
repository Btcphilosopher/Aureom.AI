from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Dict, List, Optional


class CurrencyCode(str, Enum):
    USD = "USD"
    CAD = "CAD"
    EUR = "EUR"
    GBP = "GBP"


class CabinClass(str, Enum):
    ECONOMY = "economy"
    PREMIUM_ECONOMY = "premium_economy"
    BUSINESS = "business"
    FIRST = "first"


class InclusionStatus(str, Enum):
    INCLUDED = "included"
    PAID_EXTRA = "paid_extra"
    NOT_INCLUDED = "not_included"
    UNKNOWN = "unknown"


class BaggageRequirement(str, Enum):
    PERSONAL_ONLY = "personal_only"
    CARRY_ON = "carry_on"
    CHECKED_1 = "checked_1"


class SeatPreference(str, Enum):
    ANY = "any"
    ADVANCE_SELECTION = "advance_selection"
    ASSIGNED_INCLUDED = "assigned_included"


class SeatAssignmentStatus(str, Enum):
    ASSIGNED_INCLUDED = "assigned_included"
    ADVANCE_SELECTION_INCLUDED = "advance_selection_included"
    ADVANCE_SELECTION_PAID = "advance_selection_paid"
    ASSIGNED_AT_CHECKIN = "assigned_at_checkin"
    UNKNOWN = "unknown"


@dataclass
class DecimalMoney:
    minor_units: int
    currency: CurrencyCode

    @property
    def decimal_amount(self) -> Decimal:
        return (Decimal(self.minor_units) / Decimal(100)).quantize(Decimal("0.01"))

    def to_dict(self) -> Dict[str, object]:
        return {
            "minorUnits": self.minor_units,
            "currency": self.currency.value,
            "amount": f"{self.decimal_amount:.2f}",
        }


@dataclass
class PassengerComposition:
    adults: int = 1
    children: int = 0
    infants: int = 0

    @property
    def total_count(self) -> int:
        return self.adults + self.children + self.infants


@dataclass
class CarrierInfo:
    code: str
    name: str


@dataclass
class FlightSegment:
    segment_id: str
    flight_number: str
    marketing_carrier: CarrierInfo
    operating_carrier: CarrierInfo
    origin_airport: str
    destination_airport: str
    origin_timezone: str
    destination_timezone: str
    departure_utc: str
    arrival_utc: str
    duration_minutes: int
    cabin: CabinClass
    day_offset: int
    crosses_date_line: bool = False
    dst_transitioned: bool = False


@dataclass
class ConnectionDetail:
    after_segment_id: str
    at_airport: str
    to_airport: str
    duration_minutes: int
    is_airport_change: bool
    is_overnight: bool
    is_self_transfer: bool
    is_protected_connection: bool
    protection_note: str


@dataclass
class JourneyBound:
    bound_id: str
    direction: str
    origin_airport: str
    destination_airport: str
    segments: List[FlightSegment]
    connections: List[ConnectionDetail]
    total_duration_minutes: int
    stops: int
    has_mixed_cabins: bool
    has_overnight_arrival: bool
    has_airport_change: bool
    has_self_transfer: bool


@dataclass
class Journey:
    journey_id: str
    canonical_key: str
    bounds: List[JourneyBound]
    total_duration_minutes: int
    max_stops: int


@dataclass
class BaggageRule:
    status: InclusionStatus
    pieces: Optional[int] = None
    max_weight_lb: Optional[int] = None
    fee_if_extra: Optional[DecimalMoney] = None
    notes: str = ""


@dataclass
class SegmentBaggageAllowance:
    segment_id: str
    personal_item: BaggageRule
    carry_on: BaggageRule
    checked_bag: BaggageRule


@dataclass
class PassengerFareLine:
    passenger_type: str
    count: int
    base_fare_each: DecimalMoney
    taxes_each: DecimalMoney
    mandatory_charges_each: DecimalMoney
    subtotal: DecimalMoney
    pricing_basis: str


@dataclass
class PricedExtraOption:
    extra_id: str
    kind: str
    label: str
    price_for_trip: DecimalMoney


@dataclass
class Seller:
    seller_id: str
    slug: str
    name: str
    kind: str
    affiliate_disclosed: bool


@dataclass
class PriceObservation:
    observation_id: str
    provider_id: str
    provider_name: str
    provider_offer_ref: str
    collected_at: str
    expires_at: str
    revalidation_status: str
    passenger_lines: List[PassengerFareLine]
    base_fare_total: DecimalMoney
    taxes_and_mandatory_total: DecimalMoney
    available_extras: List[PricedExtraOption] = field(default_factory=list)


@dataclass
class FareProduct:
    fare_family_name: str
    booking_class: str
    is_basic_economy: bool
    is_separate_tickets: bool
    change_allowed: InclusionStatus
    refund_allowed: InclusionStatus
    seat_status: SeatAssignmentStatus
    baggage_per_segment: List[SegmentBaggageAllowance]


@dataclass
class SearchCriteria:
    trip_type: str
    origin_code: str
    destination_code: str
    depart_date: str
    return_date: Optional[str]
    passengers: PassengerComposition
    cabin: CabinClass = CabinClass.ECONOMY
    required_baggage: BaggageRequirement = BaggageRequirement.CARRY_ON
    seat_preference: SeatPreference = SeatPreference.ANY
    refundable_only: bool = False
    currency: CurrencyCode = CurrencyCode.USD


@dataclass
class OfferEvaluation:
    eligibility: str
    reasons: List[str]
    required_extras_total: DecimalMoney
    comparable_total: DecimalMoney
    per_person_average: DecimalMoney
    missing_data_fields: List[str]


@dataclass
class Offer:
    offer_id: str
    journey: Journey
    seller: Seller
    fare_product: FareProduct
    observation: PriceObservation
    referral_url: str
    evaluation: Optional[OfferEvaluation] = None
    recommended_score: float = 0.0
    is_expired: bool = False
