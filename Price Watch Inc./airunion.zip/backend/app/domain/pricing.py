from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List, Optional, Tuple
from .models import CurrencyCode, DecimalMoney, PassengerComposition, PassengerFareLine

FX_RATE_SOURCE = "Federal Reserve H.10 / ECB Reference Snapshot"
FX_RATE_TIMESTAMP = "2026-11-24T08:00:00Z"

USD_TO_CURRENCY_RATE: Dict[CurrencyCode, Decimal] = {
    CurrencyCode.USD: Decimal("1.0000"),
    CurrencyCode.CAD: Decimal("1.3850"),
    CurrencyCode.EUR: Decimal("0.9420"),
    CurrencyCode.GBP: Decimal("0.7910"),
}


def make_money(minor_units: int, currency: CurrencyCode = CurrencyCode.USD) -> DecimalMoney:
    return DecimalMoney(minor_units=int(minor_units), currency=currency)


def add_money(a: DecimalMoney, b: DecimalMoney) -> DecimalMoney:
    if a.currency != b.currency:
        raise ValueError(f"Currency mismatch: {a.currency} vs {b.currency}")
    return DecimalMoney(minor_units=a.minor_units + b.minor_units, currency=a.currency)


def convert_currency_with_disclosure(
    original: DecimalMoney, target: CurrencyCode
) -> Optional[Dict[str, object]]:
    if original.currency == target:
        return None
    from_rate = USD_TO_CURRENCY_RATE[original.currency]
    to_rate = USD_TO_CURRENCY_RATE[target]
    cross_rate = (to_rate / from_rate).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
    converted_decimal = (original.decimal_amount * to_rate / from_rate).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )
    converted_minor = int((converted_decimal * 100).to_integral_value(rounding=ROUND_HALF_UP))
    return {
        "original": original.to_dict(),
        "converted": DecimalMoney(converted_minor, target).to_dict(),
        "rate": f"1 {original.currency.value} = {cross_rate} {target.value}",
        "rateSource": FX_RATE_SOURCE,
        "rateTimestamp": FX_RATE_TIMESTAMP,
    }


def calculate_passenger_pricing(
    passengers: PassengerComposition,
    adult_base_minor: int,
    adult_tax_minor: int,
    child_pct: int = 82,
    infant_pct: int = 10,
) -> Tuple[List[PassengerFareLine], DecimalMoney, DecimalMoney]:
    lines: List[PassengerFareLine] = []
    base_total = 0
    tax_total = 0

    if passengers.adults > 0:
        sub = (adult_base_minor + adult_tax_minor) * passengers.adults
        lines.append(
            PassengerFareLine(
                passenger_type="adult",
                count=passengers.adults,
                base_fare_each=make_money(adult_base_minor),
                taxes_each=make_money(adult_tax_minor),
                mandatory_charges_each=make_money(0),
                subtotal=make_money(sub),
                pricing_basis="explicit_per_pax_type",
            )
        )
        base_total += adult_base_minor * passengers.adults
        tax_total += adult_tax_minor * passengers.adults

    if passengers.children > 0:
        child_base = int(
            (Decimal(adult_base_minor) * Decimal(child_pct) / Decimal(100)).quantize(
                Decimal("1"), rounding=ROUND_HALF_UP
            )
        )
        child_tax = max(2200, adult_tax_minor - 600)
        sub = (child_base + child_tax) * passengers.children
        lines.append(
            PassengerFareLine(
                passenger_type="child",
                count=passengers.children,
                base_fare_each=make_money(child_base),
                taxes_each=make_money(child_tax),
                mandatory_charges_each=make_money(0),
                subtotal=make_money(sub),
                pricing_basis="explicit_per_pax_type",
            )
        )
        base_total += child_base * passengers.children
        tax_total += child_tax * passengers.children

    if passengers.infants > 0:
        inf_base = int(
            (Decimal(adult_base_minor) * Decimal(infant_pct) / Decimal(100)).quantize(
                Decimal("1"), rounding=ROUND_HALF_UP
            )
        )
        inf_tax = 1400
        sub = (inf_base + inf_tax) * passengers.infants
        lines.append(
            PassengerFareLine(
                passenger_type="infant",
                count=passengers.infants,
                base_fare_each=make_money(inf_base),
                taxes_each=make_money(inf_tax),
                mandatory_charges_each=make_money(0),
                subtotal=make_money(sub),
                pricing_basis="explicit_per_pax_type",
            )
        )
        base_total += inf_base * passengers.infants
        tax_total += inf_tax * passengers.infants

    return lines, make_money(base_total), make_money(tax_total)
