from datetime import datetime, timezone
from typing import Tuple
from zoneinfo import ZoneInfo


def local_wall_time_to_utc(date_str: str, time_24: str, iana_tz: str) -> datetime:
    """Convert airport wall-clock date/time in an IANA timezone to aware UTC datetime."""
    dt_naive = datetime.strptime(f"{date_str} {time_24}", "%Y-%m-%d %H:%M")
    dt_local = dt_naive.replace(tzinfo=ZoneInfo(iana_tz))
    return dt_local.astimezone(timezone.utc)


def calculate_absolute_duration_minutes(dep_utc: datetime, arr_utc: datetime) -> int:
    diff_sec = (arr_utc - dep_utc).total_seconds()
    if diff_sec < 0:
        raise ValueError("Arrival timestamp precedes departure timestamp")
    return round(diff_sec / 60)


def calculate_local_day_offset(
    dep_utc: datetime,
    dep_tz: str,
    arr_utc: datetime,
    arr_tz: str,
) -> int:
    dep_local_date = dep_utc.astimezone(ZoneInfo(dep_tz)).date()
    arr_local_date = arr_utc.astimezone(ZoneInfo(arr_tz)).date()
    return (arr_local_date - dep_local_date).days


def detect_dst_transition(
    dep_utc: datetime,
    dep_tz: str,
    arr_utc: datetime,
    arr_tz: str,
) -> bool:
    z_dep = ZoneInfo(dep_tz)
    z_arr = ZoneInfo(arr_tz)
    return (
        dep_utc.astimezone(z_dep).utcoffset() != arr_utc.astimezone(z_dep).utcoffset()
        or dep_utc.astimezone(z_arr).utcoffset() != arr_utc.astimezone(z_arr).utcoffset()
    )


def build_segment_times(
    dep_date: str,
    dep_local: str,
    dep_tz: str,
    arr_date: str,
    arr_local: str,
    arr_tz: str,
) -> Tuple[datetime, datetime, int, int, bool]:
    dep_utc = local_wall_time_to_utc(dep_date, dep_local, dep_tz)
    arr_utc = local_wall_time_to_utc(arr_date, arr_local, arr_tz)
    duration = calculate_absolute_duration_minutes(dep_utc, arr_utc)
    day_offset = calculate_local_day_offset(dep_utc, dep_tz, arr_utc, arr_tz)
    dst_changed = detect_dst_transition(dep_utc, dep_tz, arr_utc, arr_tz)
    return dep_utc, arr_utc, duration, day_offset, dst_changed
