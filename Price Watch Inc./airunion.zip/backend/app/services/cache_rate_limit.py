import json
import time
from typing import Any, Optional
import redis.asyncio as aioredis


class RedisCacheAndRateLimiter:
    """Bounded Redis cache (TTL + key cap) and sliding-window rate limiter."""

    def __init__(self, redis_url: str, max_cache_keys: int = 500) -> None:
        self.redis = aioredis.from_url(redis_url, decode_responses=True)
        self.max_cache_keys = max_cache_keys

    async def get_cached_search(self, cache_key: str) -> Optional[Any]:
        raw = await self.redis.get(f"airunion:search:{cache_key}")
        if not raw:
            return None
        return json.loads(raw)

    async def set_cached_search(self, cache_key: str, payload: Any, ttl_seconds: int = 120) -> None:
        index_key = "airunion:search_keys"
        full_key = f"airunion:search:{cache_key}"
        now_score = time.time()
        await self.redis.setex(full_key, ttl_seconds, json.dumps(payload))
        await self.redis.zadd(index_key, {full_key: now_score})
        total = await self.redis.zcard(index_key)
        if total > self.max_cache_keys:
            evict = await self.redis.zrange(index_key, 0, total - self.max_cache_keys - 1)
            if evict:
                await self.redis.delete(*evict)
                await self.redis.zrem(index_key, *evict)

    async def check_rate_limit(self, bucket: str, limit: int = 120, window_sec: int = 60) -> bool:
        now = time.time()
        cutoff = now - window_sec
        key = f"airunion:rl:{bucket}"
        pipe = self.redis.pipeline()
        pipe.zremrangebyscore(key, 0, cutoff)
        pipe.zcard(key)
        pipe.zadd(key, {str(now): now})
        pipe.expire(key, window_sec + 5)
        _, current_count, _, _ = await pipe.execute()
        return int(current_count) < limit
