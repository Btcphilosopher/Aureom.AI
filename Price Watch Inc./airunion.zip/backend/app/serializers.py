from datetime import datetime
from typing import Dict, List, Optional
from zoneinfo import ZoneInfo

from .domain.models import (
    BaggageRule,
    CurrencyCode,
    FlightSegment,
    InclusionStatus,
    Journey,
    JourneyBound,
    Offer,
    SearchCriteria,
)
from .domain.pricing import convert_currency_with_disclosure


def _local_wall_string(utc_iso: str, tz_name: str) -> str:
    dt = datetime.fromisoformat(utc_iso.replace("Z", "+00:00"))
    return dt.astimezone(ZoneInfo(tz_name)).strftime("%Y-%m-%dT%H:%M")


def _serialize_baggage_rule(rule: BaggageRule) -> Dict[str, object]:
    return {
        "status": rule.status.value,
        "pieces": rule.pieces,
        "maxWeightLb": rule.max_weight_lb,
        "feeIfExtra": rule.fee_if_extra.to_dict() if rule.fee_if_extra else None,
        "notes": rule.notes or None,
    }


def _serialize_segment(seg: FlightSegment) -> Dict[str, object]:
    return {
        "segmentId": seg.segment_id,
        "flightNumber": seg.flight_number,
        "marketingCarrier": {"code": seg.marketing_carrier.code, "name": seg.marketing_carrier.name},
        "operatingCarrier": {"code": seg.operating_carrier.code, "name": seg.operating_carrier.name},
        "originAirport": seg.origin_airport,
        "originTimezone": seg.origin_timezone,
        "destinationAirport": seg.destination_airport,
        "destinationTimezone": seg.destination_timezone,
        "departureUtc": seg.departure_utc,
        "arrivalUtc": seg.arrival_utc,
        "departureLocal": _local_wall_string(seg.departure_utc, seg.origin_timezone),
        "arrivalLocal": _local_wall_string(seg.arrival_utc, seg.destination_timezone),
        "durationMinutes": seg.duration_minutes,
        "cabin": seg.cabin.value,
        "aircraft": "Narrowbody / Transcon Jet",
        "dayOffsetFromDeparture": seg.day_offset,
        "crossesDateLine": seg.crosses_date_line,
        "dstTransitioned": seg.dst_transitioned,
    }


def _serialize_bound(bound: JourneyBound) -> Dict[str, object]:
    return {
        "boundId": bound.bound_id,
        "direction": bound.direction,
        "originAirport": bound.origin_airport,
        "destinationAirport": bound.destination_airport,
        "segments": [_serialize_segment(s) for s in bound.segments],
        "connections": [
            {
                "afterSegmentId": c.after_segment_id,
                "atAirport": c.at_airport,
                "toAirport": c.to_airport,
                "durationMinutes": c.duration_minutes,
                "isAirportChange": c.is_airport_change,
                "isOvernight": c.is_overnight,
                "isSelfTransfer": c.is_self_transfer,
                "isProtectedConnection": c.is_protected_connection,
                "protectionNote": c.protection_note,
            }
            for c in bound.connections
        ],
        "totalDurationMinutes": bound.total_duration_minutes,
        "stops": bound.stops,
        "hasMixedCabins": bound.has_mixed_cabins,
        "hasOvernightArrival": bound.has_overnight_arrival,
        "hasAirportChange": bound.has_airport_change,
        "hasSelfTransfer": bound.has_self_transfer,
    }


def serialize_journey(journey: Journey) -> Dict[str, object]:
    return {
        "journeyId": journey.journey_id,
        "canonicalKey": journey.canonical_key,
        "bounds": [_serialize_bound(b) for b in journey.bounds],
        "totalDurationMinutes": journey.total_duration_minutes,
        "maxStops": journey.max_stops,
    }


def serialize_offer(offer: Offer, target_currency: CurrencyCode = CurrencyCode.USD) -> Dict[str, object]:
    ev = offer.evaluation
    fx = (
        convert_currency_with_disclosure(ev.comparable_total, target_currency)
        if ev and target_currency != CurrencyCode.USD
        else None
    )
    change_note = (
        "Changes permitted"
        if offer.fare_product.change_allowed == InclusionStatus.INCLUDED
        else "Changes not permitted"
        if offer.fare_product.change_allowed == InclusionStatus.NOT_INCLUDED
        else "Change rules unknown"
    )
    refund_note = (
        "Refundable / credit eligible"
        if offer.fare_product.refund_allowed == InclusionStatus.INCLUDED
        else "Non-refundable fare"
        if offer.fare_product.refund_allowed == InclusionStatus.NOT_INCLUDED
        else "Refund conditions unknown"
    )

    return {
        "offerId": offer.offer_id,
        "journey": serialize_journey(offer.journey),
        "seller": {
            "sellerId": offer.seller.seller_id,
            "slug": offer.seller.slug,
            "name": offer.seller.name,
            "kind": offer.seller.kind,
            "affiliateDisclosed": offer.seller.affiliate_disclosed,
            "supportNote": "Verify fare terms on the seller booking page before payment.",
        },
        "fareProduct": {
            "fareFamilyName": offer.fare_product.fare_family_name,
            "bookingClass": offer.fare_product.booking_class,
            "isBasicEconomy": offer.fare_product.is_basic_economy,
            "isSeparateTickets": offer.fare_product.is_separate_tickets,
            "conditions": {
                "changeAllowed": offer.fare_product.change_allowed.value,
                "changeNotes": change_note,
                "refundAllowed": offer.fare_product.refund_allowed.value,
                "refundNotes": refund_note,
                "seatAssignment": {
                    "status": offer.fare_product.seat_status.value,
                    "notes": f"Seat status: {offer.fare_product.seat_status.value}",
                },
            },
            "baggagePerSegment": [
                {
                    "segmentId": b.segment_id,
                    "personalItem": _serialize_baggage_rule(b.personal_item),
                    "carryOn": _serialize_baggage_rule(b.carry_on),
                    "checkedBag": _serialize_baggage_rule(b.checked_bag),
                }
                for b in offer.fare_product.baggage_per_segment
            ],
        },
        "observation": {
            "observationId": offer.observation.observation_id,
            "providerId": offer.observation.provider_id,
            "providerName": offer.observation.provider_name,
            "providerOfferRef": offer.observation.provider_offer_ref,
            "collectedAt": offer.observation.collected_at,
            "expiresAt": offer.observation.expires_at,
            "revalidationStatus": offer.observation.revalidation_status,
            "passengerLines": [
                {
                    "passengerType": line.passenger_type,
                    "count": line.count,
                    "baseFareEach": line.base_fare_each.to_dict(),
                    "taxesEach": line.taxes_each.to_dict(),
                    "mandatoryChargesEach": line.mandatory_charges_each.to_dict(),
                    "subtotal": line.subtotal.to_dict(),
                    "pricingBasis": line.pricing_basis,
                }
                for line in offer.observation.passenger_lines
            ],
            "baseFareTotal": offer.observation.base_fare_total.to_dict(),
            "taxesAndMandatoryTotal": offer.observation.taxes_and_mandatory_total.to_dict(),
            "availableExtras": [
                {
                    "extraId": ex.extra_id,
                    "kind": ex.kind,
                    "label": ex.label,
                    "description": ex.label,
                    "priceForTrip": ex.price_for_trip.to_dict(),
                    "perPassenger": False,
                }
                for ex in offer.observation.available_extras
            ],
        },
        "referralUrl": offer.referral_url,
        "evaluation": (
            {
                "eligibility": ev.eligibility,
                "reasons": ev.reasons,
                "requiredExtrasTotal": ev.required_extras_total.to_dict(),
                "comparableTotal": ev.comparable_total.to_dict(),
                "perPersonAverage": ev.per_person_average.to_dict(),
                "fxDisclosure": fx,
                "missingDataFields": ev.missing_data_fields,
            }
            if ev
            else None
        ),
        "recommendedScore": offer.recommended_score,
        "isExpired": offer.is_expired,
    }


def serialize_criteria(criteria: SearchCriteria) -> Dict[str, object]:
    return {
        "tripType": criteria.trip_type,
        "originCode": criteria.origin_code,
        "destinationCode": criteria.destination_code,
        "includeNearbyOrigin": True,
        "includeNearbyDestination": True,
        "departDate": criteria.depart_date,
        "returnDate": criteria.return_date,
        "passengers": {
            "adults": criteria.passengers.adults,
            "children": criteria.passengers.children,
            "infants": criteria.passengers.infants,
        },
        "cabin": criteria.cabin.value,
        "requiredBaggage": criteria.required_baggage.value,
        "seatPreference": criteria.seat_preference.value,
        "refundableOnly": criteria.refundable_only,
        "maxStops": None,
        "currency": criteria.currency.value,
    }
