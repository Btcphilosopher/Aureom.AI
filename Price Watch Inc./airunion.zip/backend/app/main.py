import asyncio
import uuid
from datetime import datetime, timezone
from typing import Dict, Optional
from fastapi import FastAPI, HTTPException, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import text

from .catalog_data import AIRPORT_CATALOG, DESTINATION_CATALOG
from .config import settings
from .domain.comparison import evaluate_offer, group_duplicate_itineraries
from .domain.models import (
    BaggageRequirement,
    CabinClass,
    CurrencyCode,
    Offer,
    PassengerComposition,
    SearchCriteria,
    SeatPreference,
)
from .domain.pricing import add_money
from .providers.aerodirect_ndc import AeroDirectNdcAdapter
from .providers.skybridge_gds import SkyBridgeGdsAdapter
from .serializers import serialize_criteria, serialize_journey, serialize_offer
from .services.cache_rate_limit import RedisCacheAndRateLimiter
from .services.db import engine

app = FastAPI(
    title="airunion Flight Comparison API",
    version="1.0.0",
    description="Independent US flight comparison backend with like-for-like baggage, seat, decimal pricing, and provider health handling.",
)

ADAPTERS = [SkyBridgeGdsAdapter(), AeroDirectNdcAdapter()]
OFFER_CACHE: Dict[str, Offer] = {}

RANKING_FORMULA_EXPLANATION = (
    "Recommended order = ComparableTotal(USD) + StopPenalty($55/stop) + "
    "DurationPenalty($0.12/min) + SelfTransferPenalty($110) + AirportChangePenalty($65) + "
    "UnknownTermsPenalty($45)."
)


class PassengersIn(BaseModel):
    adults: int = Field(default=1, ge=1, le=8)
    children: int = Field(default=0, ge=0, le=6)
    infants: int = Field(default=0, ge=0, le=8)


class SearchRequestIn(BaseModel):
    tripType: str = "round_trip"
    originCode: str = Field(min_length=3, max_length=3)
    destinationCode: str = Field(min_length=3, max_length=3)
    departDate: str
    returnDate: Optional[str] = None
    passengers: PassengersIn = Field(default_factory=PassengersIn)
    cabin: CabinClass = CabinClass.ECONOMY
    requiredBaggage: BaggageRequirement = BaggageRequirement.CARRY_ON
    seatPreference: SeatPreference = SeatPreference.ANY
    refundableOnly: bool = False
    currency: CurrencyCode = CurrencyCode.USD


@app.get("/health")
async def health():
    db_ok = False
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
            db_ok = True
    except Exception:
        db_ok = False
    return {"status": "ok", "postgres": db_ok, "providers": [a.provider_id for a in ADAPTERS]}


@app.get("/api/v1/airports")
async def get_airports(q: str = Query(default="")):
    needle = q.strip().lower()
    if not needle:
        defaults = {"NYC", "JFK", "LGA", "EWR", "LAX", "MIA", "CHI", "ORD", "SFO", "FAT", "HNL"}
        return {"locations": [item for item in AIRPORT_CATALOG if item["code"] in defaults]}
    matches = [
        item
        for item in AIRPORT_CATALOG
        if needle in str(item["code"]).lower()
        or needle in str(item["name"]).lower()
        or needle in str(item["city"]).lower()
        or needle in str(item["stateOrCountry"]).lower()
    ]
    return {"locations": matches[:10]}


@app.get("/api/v1/destinations")
async def get_destinations():
    return {"destinations": DESTINATION_CATALOG}


@app.post("/api/v1/flights/search")
async def search_flights(payload: SearchRequestIn, request: Request):
    if payload.originCode.upper() == payload.destinationCode.upper():
        raise HTTPException(status_code=400, detail="Origin and destination must differ.")
    if payload.tripType == "round_trip" and payload.returnDate and payload.returnDate < payload.departDate:
        raise HTTPException(status_code=400, detail="Return date must follow departure date.")

    cache_client: Optional[RedisCacheAndRateLimiter] = None
    try:
        cache_client = RedisCacheAndRateLimiter(settings.REDIS_URL)
        client_ip = request.client.host if request.client else "unknown"
        allowed = await cache_client.check_rate_limit(f"search:{client_ip}", settings.RATE_LIMIT_PER_MINUTE)
        if not allowed:
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
    except HTTPException:
        raise
    except Exception:
        cache_client = None

    criteria = SearchCriteria(
        trip_type=payload.tripType,
        origin_code=payload.originCode.upper(),
        destination_code=payload.destinationCode.upper(),
        depart_date=payload.departDate,
        return_date=payload.returnDate,
        passengers=PassengerComposition(
            adults=payload.passengers.adults,
            children=payload.passengers.children,
            infants=payload.passengers.infants,
        ),
        cabin=payload.cabin,
        required_baggage=payload.requiredBaggage,
        seat_preference=payload.seatPreference,
        refundable_only=payload.refundableOnly,
        currency=payload.currency,
    )

    now_iso = datetime.now(timezone.utc).isoformat()
    provider_results = await asyncio.gather(
        *[adapter.search(criteria, "healthy", now_iso) for adapter in ADAPTERS]
    )

    all_offers = []
    provider_reports = []
    for res in provider_results:
        provider_reports.append(
            {
                "providerId": res.provider_id,
                "providerName": res.provider_name,
                "status": res.status,
                "latencyMs": res.latency_ms,
                "offerCount": len(res.offers),
                "errorMessage": res.error_message,
            }
        )
        for offer in res.offers:
            ev = evaluate_offer(offer, criteria)
            offer.recommended_score = round(
                (ev.comparable_total.minor_units / 100.0)
                + (offer.journey.max_stops * 55)
                + (offer.journey.total_duration_minutes * 0.12)
                + (45 if ev.eligibility == "incomplete" else 0),
                2,
            )
            OFFER_CACHE[offer.offer_id] = offer
            all_offers.append(offer)

    grouped = group_duplicate_itineraries(all_offers)
    failed_count = sum(1 for r in provider_reports if r["status"] == "failed")
    search_status = (
        "failed"
        if failed_count == len(ADAPTERS)
        else "partial"
        if failed_count > 0
        else "no_matches"
        if not all_offers
        else "complete"
    )

    serialized_groups = []
    for key, group_offers in grouped.items():
        group_offers_sorted = sorted(
            group_offers,
            key=lambda o: o.evaluation.comparable_total.minor_units if o.evaluation else 99999999,
        )
        eligible = [
            o for o in group_offers_sorted if o.evaluation and o.evaluation.eligibility == "eligible"
        ]
        cheapest_eligible_id = eligible[0].offer_id if eligible else None
        cheapest_base_offer = min(
            group_offers_sorted,
            key=lambda o: (
                o.observation.base_fare_total.minor_units
                + o.observation.taxes_and_mandatory_total.minor_units
            ),
        )
        best_offer = eligible[0] if eligible else group_offers_sorted[0]
        serialized_groups.append(
            {
                "canonicalKey": key,
                "journey": serialize_journey(best_offer.journey),
                "offers": [serialize_offer(o, payload.currency) for o in group_offers_sorted],
                "cheapestEligibleOfferId": cheapest_eligible_id,
                "cheapestBaseOfferId": cheapest_base_offer.offer_id,
                "bestOffer": serialize_offer(best_offer, payload.currency),
            }
        )

    eligible_all = [o for o in all_offers if o.evaluation and o.evaluation.eligibility == "eligible"]
    cheapest_el_all = (
        min(eligible_all, key=lambda o: o.evaluation.comparable_total.minor_units)
        if eligible_all
        else None
    )
    cheapest_base_all = (
        min(
            all_offers,
            key=lambda o: (
                o.observation.base_fare_total.minor_units
                + o.observation.taxes_and_mandatory_total.minor_units
            ),
        )
        if all_offers
        else None
    )
    fastest_all = (
        min(all_offers, key=lambda o: o.journey.total_duration_minutes) if all_offers else None
    )

    return {
        "searchId": f"srch_{uuid.uuid4().hex[:12]}",
        "searchedAt": now_iso,
        "criteria": serialize_criteria(criteria),
        "cacheHit": False,
        "searchStatus": search_status,
        "providers": provider_reports,
        "groups": serialized_groups,
        "summary": {
            "totalOffers": len(all_offers),
            "totalUniqueItineraries": len(serialized_groups),
            "cheapestEligibleTotal": (
                cheapest_el_all.evaluation.comparable_total.to_dict()
                if cheapest_el_all and cheapest_el_all.evaluation
                else None
            ),
            "cheapestEligibleOfferId": cheapest_el_all.offer_id if cheapest_el_all else None,
            "cheapestBaseTotal": (
                add_money(
                    cheapest_base_all.observation.base_fare_total,
                    cheapest_base_all.observation.taxes_and_mandatory_total,
                ).to_dict()
                if cheapest_base_all
                else None
            ),
            "cheapestBaseOfferId": cheapest_base_all.offer_id if cheapest_base_all else None,
            "fastestDurationMinutes": fastest_all.journey.total_duration_minutes if fastest_all else None,
            "fastestOfferId": fastest_all.offer_id if fastest_all else None,
            "rankingFormulaExplanation": RANKING_FORMULA_EXPLANATION,
        },
    }


@app.get("/api/v1/offers/{offer_id}")
async def get_offer_detail(
    offer_id: str,
    currency: CurrencyCode = Query(default=CurrencyCode.USD),
):
    offer = OFFER_CACHE.get(offer_id)
    if offer is None:
        raise HTTPException(status_code=404, detail="Offer not found or expired from session cache")
    return {"offer": serialize_offer(offer, currency)}


@app.post("/api/v1/offers/{offer_id}/revalidate")
async def revalidate_offer(offer_id: str):
    offer = OFFER_CACHE.get(offer_id)
    if offer is None:
        raise HTTPException(status_code=404, detail="Offer not found")
    adapter = next((a for a in ADAPTERS if a.provider_id == offer.observation.provider_id), None)
    if adapter is None:
        raise HTTPException(status_code=404, detail="Provider adapter not found")
    return await adapter.revalidate_offer(offer)
