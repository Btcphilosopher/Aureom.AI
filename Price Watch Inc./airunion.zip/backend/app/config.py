import os


class Settings:
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql+asyncpg://airunion:airunion_dev@postgres:5432/airunion",
    )
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://redis:6379/0")
    AUTH_SECRET: str = os.getenv("AUTH_SECRET", "")
    ADMIN_PASSCODE: str = os.getenv("ADMIN_PASSCODE", "")
    SKYBRIDGE_API_KEY: str = os.getenv("SKYBRIDGE_API_KEY", "")
    AERODIRECT_API_KEY: str = os.getenv("AERODIRECT_API_KEY", "")
    CACHE_TTL_SECONDS: int = int(os.getenv("CACHE_TTL_SECONDS", "120"))
    RATE_LIMIT_PER_MINUTE: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "120"))


settings = Settings()
