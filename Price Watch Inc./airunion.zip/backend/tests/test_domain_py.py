import os
import sys
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.domain.comparison import evaluate_offer, group_duplicate_itineraries
from app.domain.models import (
    BaggageRequirement,
    CabinClass,
    CurrencyCode,
    PassengerComposition,
    SearchCriteria,
)
from app.domain.pricing import calculate_passenger_pricing, convert_currency_with_disclosure, make_money
from app.domain.timezone_utils import build_segment_times
from app.catalog_data import AIRPORT_CATALOG, DESTINATION_CATALOG
from app.providers.aerodirect_ndc import AeroDirectNdcAdapter
from app.providers.skybridge_gds import SkyBridgeGdsAdapter
from app.serializers import serialize_offer
import asyncio


class AirunionPythonDomainTests(unittest.TestCase):
    def test_timezone_dst_and_overnight(self):
        # Spring forward DST check in America/New_York (2026-03-08 02:00 jumps to 03:00)
        dep_utc, arr_utc, dur, day_off, dst = build_segment_times(
            "2026-03-07", "22:30", "America/Los_Angeles",
            "2026-03-08", "07:30", "America/New_York",
        )
        self.assertEqual(day_off, 1)
        self.assertTrue(dst)
        # LAX (UTC-8) 22:30 = 06:30 UTC; JFK (UTC-4 after 2am EDT) 07:30 = 11:30 UTC -> 300 mins
        self.assertEqual(dur, 300)

    def test_family_traveler_pricing_distinct_lines(self):
        pax = PassengerComposition(adults=2, children=1, infants=1)
        lines, base_total, tax_total = calculate_passenger_pricing(pax, 20000, 6000)
        self.assertEqual(len(lines), 3)
        self.assertEqual(lines[0].passenger_type, "adult")
        self.assertEqual(lines[1].passenger_type, "child")
        self.assertEqual(lines[2].passenger_type, "infant")
        # Child fare (82% of 20000 = 16400) != adult fare (20000)
        self.assertEqual(lines[1].base_fare_each.minor_units, 16400)
        self.assertEqual(lines[2].base_fare_each.minor_units, 2000)
        self.assertEqual(base_total.minor_units, 20000 * 2 + 16400 + 2000)

    def test_currency_conversion_half_up(self):
        orig = make_money(35400, CurrencyCode.USD)
        fx = convert_currency_with_disclosure(orig, CurrencyCode.EUR)
        self.assertIsNotNone(fx)
        self.assertEqual(fx["converted"]["currency"], "EUR")
        self.assertEqual(fx["converted"]["amount"], "333.47")

    def test_duplicate_grouping_baggage_flip_and_provider_outage(self):
        criteria = SearchCriteria(
            trip_type="round_trip",
            origin_code="NYC",
            destination_code="LAX",
            depart_date="2026-12-15",
            return_date="2026-12-22",
            passengers=PassengerComposition(adults=1, children=0, infants=0),
            cabin=CabinClass.ECONOMY,
            required_baggage=BaggageRequirement.CHECKED_1,
        )
        sb = SkyBridgeGdsAdapter()
        ad = AeroDirectNdcAdapter()
        res_sb = asyncio.run(sb.search(criteria, "healthy"))
        res_ad = asyncio.run(ad.search(criteria, "healthy"))
        offers = res_sb.offers + res_ad.offers
        for o in offers:
            evaluate_offer(o, criteria)
        grouped = group_duplicate_itineraries(offers)
        # Both AA 117/118 offers share one canonical key
        self.assertEqual(len(grouped), 1)
        # With checked_1 bag required, AeroDirect Main Plus ($354) beats ClearFare ($258 + $130 = $388)
        sorted_offers = sorted(offers, key=lambda o: o.evaluation.comparable_total.minor_units)
        self.assertEqual(sorted_offers[0].seller.slug, "american-airlines-ndc")
        self.assertEqual(sorted_offers[0].evaluation.comparable_total.minor_units, 35400)

        # Outage returns failed status with 0 offers
        outage_res = asyncio.run(sb.search(criteria, "outage"))
        self.assertEqual(outage_res.status, "failed")
        self.assertEqual(len(outage_res.offers), 0)

    def test_offer_expiry(self):
        criteria = SearchCriteria(
            trip_type="one_way",
            origin_code="NYC",
            destination_code="LAX",
            depart_date="2026-12-15",
            return_date=None,
            passengers=PassengerComposition(adults=1),
        )
        ad = AeroDirectNdcAdapter()
        past_iso = (datetime.now(timezone.utc) - timedelta(hours=3)).isoformat()
        res = asyncio.run(ad.search(criteria, "healthy", now_iso=past_iso))
        offer = res.offers[0]
        evaluate_offer(offer, criteria, now_utc=datetime.now(timezone.utc))
        self.assertTrue(offer.is_expired)

    def test_serializer_and_catalog_parity(self):
        self.assertTrue(any(a["code"] == "NYC" and a["kind"] == "metro" for a in AIRPORT_CATALOG))
        self.assertTrue(any(d["id"] == "insp-national-parks" for d in DESTINATION_CATALOG))
        criteria = SearchCriteria(
            trip_type="round_trip",
            origin_code="NYC",
            destination_code="LAX",
            depart_date="2026-12-15",
            return_date="2026-12-22",
            passengers=PassengerComposition(adults=1),
        )
        ad = AeroDirectNdcAdapter()
        res = asyncio.run(ad.search(criteria, "healthy"))
        offer = res.offers[0]
        evaluate_offer(offer, criteria)
        serialized = serialize_offer(offer, CurrencyCode.EUR)
        self.assertEqual(serialized["offerId"], offer.offer_id)
        self.assertEqual(serialized["evaluation"]["fxDisclosure"]["converted"]["currency"], "EUR")
        self.assertIn("comparableTotal", serialized["evaluation"])


if __name__ == "__main__":
    unittest.main()
