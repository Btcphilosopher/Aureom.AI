-- airunion PostgreSQL 16 Initial Schema
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('traveler', 'admin')),
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_credentials (
    id INTEGER PRIMARY KEY DEFAULT 1,
    passcode_hash TEXT NOT NULL,
    passcode_salt TEXT NOT NULL,
    claimed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS airports (
    code CHAR(3) PRIMARY KEY,
    kind TEXT NOT NULL CHECK (kind IN ('metro', 'airport')),
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    state_or_country TEXT NOT NULL,
    country_code CHAR(2) NOT NULL,
    iana_timezone TEXT NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    included_airports JSONB NOT NULL DEFAULT '[]'::jsonb,
    nearby_airports JSONB NOT NULL DEFAULT '[]'::jsonb,
    provenance TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS destinations (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    subtitle TEXT NOT NULL,
    category TEXT NOT NULL,
    default_origin_code CHAR(3) NOT NULL,
    destination_code CHAR(3) NOT NULL,
    destination_label TEXT NOT NULL,
    image_key TEXT NOT NULL,
    airport_disclosure TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS providers (
    provider_id TEXT PRIMARY KEY,
    provider_name TEXT NOT NULL,
    health_state TEXT NOT NULL CHECK (health_state IN ('healthy', 'degraded', 'outage')),
    rate_limit_per_minute INTEGER NOT NULL DEFAULT 120,
    credential_env_keys JSONB NOT NULL DEFAULT '[]'::jsonb,
    commercial_access_note TEXT NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS searches (
    search_id TEXT PRIMARY KEY,
    user_id TEXT REFERENCES users(user_id) ON DELETE SET NULL,
    criteria JSONB NOT NULL,
    search_status TEXT NOT NULL,
    provider_reports JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS itineraries (
    journey_id TEXT PRIMARY KEY,
    canonical_key TEXT NOT NULL,
    total_duration_minutes INTEGER NOT NULL,
    max_stops INTEGER NOT NULL,
    bounds JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_itineraries_canonical_key ON itineraries (canonical_key);

CREATE TABLE IF NOT EXISTS offers (
    offer_id TEXT PRIMARY KEY,
    search_id TEXT REFERENCES searches(search_id) ON DELETE CASCADE,
    journey_id TEXT REFERENCES itineraries(journey_id) ON DELETE CASCADE,
    provider_id TEXT NOT NULL,
    provider_offer_ref TEXT NOT NULL,
    seller JSONB NOT NULL,
    fare_product JSONB NOT NULL,
    price_observation JSONB NOT NULL,
    referral_url TEXT NOT NULL,
    collected_at TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    revalidation_status TEXT NOT NULL DEFAULT 'unverified'
);
CREATE INDEX IF NOT EXISTS idx_offers_search_id ON offers (search_id);

CREATE TABLE IF NOT EXISTS price_observations (
    observation_id TEXT PRIMARY KEY,
    offer_id TEXT NOT NULL REFERENCES offers(offer_id) ON DELETE CASCADE,
    provider_id TEXT NOT NULL,
    currency CHAR(3) NOT NULL,
    base_fare_minor BIGINT NOT NULL,
    taxes_mandatory_minor BIGINT NOT NULL,
    passenger_lines JSONB NOT NULL,
    collected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS saved_searches (
    saved_search_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    criteria JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_saved_searches_user ON saved_searches (user_id);

CREATE TABLE IF NOT EXISTS saved_itineraries (
    saved_itinerary_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    offer_id TEXT NOT NULL,
    offer_snapshot JSONB NOT NULL,
    notes TEXT NOT NULL DEFAULT '',
    saved_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_saved_itineraries_user ON saved_itineraries (user_id);

CREATE TABLE IF NOT EXISTS price_alerts (
    alert_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    criteria JSONB NOT NULL,
    target_price_minor BIGINT NOT NULL,
    target_currency CHAR(3) NOT NULL DEFAULT 'USD',
    check_frequency TEXT NOT NULL CHECK (check_frequency IN ('every_6_hours', 'daily')),
    status TEXT NOT NULL CHECK (status IN ('active', 'triggered', 'paused')),
    last_checked_at TIMESTAMPTZ,
    last_checked_offer_id TEXT,
    last_checked_price_minor BIGINT,
    last_price_basis TEXT,
    last_notification_status TEXT NOT NULL DEFAULT 'none',
    last_notification_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_price_alerts_user ON price_alerts (user_id);

CREATE TABLE IF NOT EXISTS alert_runs (
    id TEXT PRIMARY KEY,
    alert_id TEXT NOT NULL REFERENCES price_alerts(alert_id) ON DELETE CASCADE,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    outcome TEXT NOT NULL,
    observed_price TEXT,
    price_basis TEXT NOT NULL,
    message TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS handoff_events (
    handoff_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    offer_id TEXT NOT NULL,
    seller_name TEXT NOT NULL,
    route_summary TEXT NOT NULL,
    total_minor BIGINT NOT NULL,
    currency CHAR(3) NOT NULL,
    referral_url TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS manual_bookings (
    booking_record_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    confirmation_code TEXT NOT NULL,
    airline_or_seller TEXT NOT NULL,
    route_summary TEXT NOT NULL,
    travel_date TEXT NOT NULL,
    notes TEXT NOT NULL DEFAULT '',
    verification_note TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS failed_searches (
    id TEXT PRIMARY KEY,
    criteria JSONB NOT NULL,
    reason TEXT NOT NULL,
    providers_involved JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mapping_errors (
    id TEXT PRIMARY KEY,
    provider_id TEXT NOT NULL,
    raw_code TEXT NOT NULL,
    message TEXT NOT NULL,
    resolved BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    actor_id TEXT NOT NULL,
    actor_role TEXT NOT NULL,
    action TEXT NOT NULL,
    target TEXT NOT NULL,
    detail TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
