# airunion REST API Contracts

## `GET /api/airports?q=<query>`
Returns matching metropolitan areas (`NYC`, `CHI`, `TYO`) and individual airports (`JFK`, `LGA`, `EWR`, `LAX`, `MIA`, `ORD`, etc.) with coordinates, IANA timezones, included metro airports, nearby airports, and data provenance.

## `POST /api/flights/search`
Executes aggregated multi-provider search (`SkyBridge GDS` + `AeroDirect NDC`), normalizes itineraries, groups duplicates by canonical flight key, and evaluates like-for-like eligibility.
- **Validations**: `originCode !== destinationCode`, `returnDate >= departDate` for `round_trip`.
- **Response fields**: `searchStatus` (`complete | partial | failed | no_matches`), `providers[]`, `groups[]` (each containing grouped `offers[]`), and `summary` (`cheapestEligibleTotal`, `cheapestBaseTotal`, `fastestDurationMinutes`, `rankingFormulaExplanation`).

## `GET /api/offers/{offerId}?currency=USD|CAD|EUR|GBP`
Retrieves normalized offer details, segment baggage rules, decimal pricing, and optional FX conversion disclosure (`rate`, `rateSource`, `rateTimestamp`).

## `POST /api/offers/{offerId}/revalidate`
Checks live provider status for the offer:
- `confirmed`: price and availability verified; returns validated `referralUrl`.
- `price_changed`: returns `updatedTotal`, `priceDelta`, and `requiresFreshSelection: true`.
- `expired`: returns `refreshedAlternatives[]`.
- `unavailable`: returns provider outage explanation without inventing availability.

## `POST /api/handoffs`
Validates referral URL against allowlisted internal `/supplier/[slug]` paths or HTTPS airline/seller hosts, records handoff history if signed in, and returns affiliate/comparison-only notice.

## `GET/POST/PATCH/DELETE /api/my-trips`
Requires `Authorization: Bearer <token>`. Enforces `record.userId === session.userId` on all reads, alert evaluations, and deletions.

## `GET/POST /api/admin`
Requires administrator role (`ADMIN_PASSCODE` or claimed first-run credential). Supports toggling provider health (`healthy | degraded | outage`), resolving mapping errors, upserting airport records, running alert jobs, and exporting/restoring JSON backups.
