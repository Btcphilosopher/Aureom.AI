# airunion Architecture, Page Map & Domain Model

## 1. System Architecture
- **Frontend (`Next.js 15 App Router + React 19 + TypeScript + Tailwind CSS v4`)**:
  - Server and client components under `/app` and `/components`.
  - Optional server-side proxy (`FASTAPI_BACKEND_URL`) forwards API calls to the Python FastAPI service in Docker Compose deployments, while providing an identical deterministic TypeScript engine and persistent atomic store (`.airunion-data/store.json`) for standalone preview execution.
- **Backend (`Python 3.11 + FastAPI + SQLAlchemy Async + Pydantic`)**:
  - Service code under `/backend/app`.
  - Exposes REST endpoints for flight search, offer retrieval, revalidation, provider health, and periodic alert jobs.
- **Persistence (`PostgreSQL 16` + `Redis 7`)**:
  - `backend/migrations/001_initial.sql` defines relational tables for `users`, `airports`, `destinations`, `providers`, `searches`, `itineraries`, `offers`, `price_observations`, `saved_searches`, `saved_itineraries`, `price_alerts`, `alert_runs`, `handoff_events`, `manual_bookings`, `failed_searches`, `mapping_errors`, and `audit_logs`.
  - Redis provides bounded LRU-TTL search caching (`maxmemory-policy allkeys-lru`) and sliding-window rate limiting.
- **Background Worker (`backend/app/worker.py`)**:
  - Runs periodic price-alert evaluation loops strictly preserving the user's saved baggage, cabin, seat, and traveler requirements.

## 2. Page Map
- `/` — Homepage matching reference layout (hero search bar, featured US destinations, "Know what's included" fare links, traveler inspiration cards).
- `/search` — Flight search results, duplicate itinerary grouping, provider coverage banner, like-for-like comparison filters, and price alert creation.
- `/offers/[offerId]` — Detailed segment/carrier breakdown, segment baggage matrix, decimal price calculator with opt-in extras, live revalidation, and validated supplier handoff.
- `/supplier/[sellerSlug]` — Simulated external airline/seller referral landing page.
- `/destinations` — Curated US destination and national park gateway explorer.
- `/my-trips` — User-scoped saved searches, saved itineraries, periodic price alerts, supplier handoff history, and manually recorded booking references.
- `/help` — Fare transparency, baggage/seat definitions, connection rules, and provider commercial access notes.
- `/admin` — Administrator console (first-run setup/claim or passcode auth) for provider outage simulation, alert runner, failed searches, mapping errors, airport registry, audit logs, and backup/restore.

## 3. Domain Model Separation
- **Journey -> JourneyBound -> FlightSegment**: Separates outbound/inbound bounds and physical flight legs with marketing vs operating carriers, IANA timezones, and UTC timestamps.
- **PassengerComposition & PassengerFareLine**: Prices adults, children (2–11), and infants individually (`explicit_per_pax_type`).
- **FareProduct & SegmentBaggageAllowance**: Separates personal item, carry-on, and checked baggage per segment alongside seat assignment vs advance selection, change terms, and refundability.
- **Seller -> Offer -> PriceObservation**: Preserves provider reference, collection time, expiry, currency, taxes, mandatory fees, and revalidation status separately from the physical itinerary so duplicate itineraries group cleanly across sellers.
