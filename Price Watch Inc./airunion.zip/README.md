# airunion — Independent US Flight Comparison Platform

airunion is a full-stack flight comparison application built with **Next.js 15, React 19, TypeScript, Tailwind CSS v4**, paired with a **Python FastAPI + PostgreSQL 16 + Redis 7 + Background Worker** backend and Docker Compose orchestration.

## Local Development & Docker Compose

### Option 1: Full Docker Stack (PostgreSQL + Redis + FastAPI + Worker + Next.js)
```bash
cp .env.example .env
docker compose up --build
```
- Frontend: `http://localhost:3000`
- FastAPI OpenAPI docs: `http://localhost:8000/docs`

### Option 2: Standalone Next.js Preview Mode
```bash
npm install
npm run dev
```

## Verification & Test Suites
- TypeScript domain & comparison tests:
  `node --test --experimental-strip-types tests/domain.test.ts`
- Python domain & timezone tests:
  `python3 -m unittest discover -s backend/tests -p "test_domain_py.py"`
- Production build & lint:
  `npm run lint && npm run build`

## Reproducible 12-Step Demonstration
1. Open `/` and search **NYC → LAX** (Round trip, future dates).
2. Observe results aggregated from **SkyBridge GDS** and **AeroDirect NDC**.
3. Inspect the **AA 117 / AA 118** itinerary group showing **ClearFare Travel**, **American Airlines**, and **American Airlines (NDC Direct)** grouped on the same physical flights.
4. Change **Required baggage** to **1st Checked bag (50 lb)**.
5. Observe **Cheapest eligible total** shift from ClearFare Basic Economy ($258 base + $130 bag = $388) to **American Airlines (NDC Direct) Main Plus ($354 with bag included)**.
6. Inspect **UA 412/1904** for mixed-cabin disclosure and **NK 310 / F9 822** for self-transfer separate-ticket warnings.
7. Select **Delta DL 402/403** and click **Revalidate live fare**.
8. Observe the **+$24.00 price change** prompt requiring explicit acknowledgment.
9. Acknowledge the updated fare and click **Continue to airline** to land on the validated supplier page.
10. Click **Save search** (signing in with the Demo Traveler workspace or registering an account).
11. Open **My trips** and click **Run check now** on the saved price alert.
12. Open **Admin console** (`/admin`), claim or sign in as admin, toggle a provider to **outage**, and rerun a search to verify partial coverage / outage handling without invented availability.

## Simulated vs. Production Capabilities
- **Simulated**: `SkyBridge GDS` and `AeroDirect NDC` return deterministic US flight fixtures, controlled price-drift/expiry cases, and mock `/supplier/[slug]` handoff pages. Live production deployment requires accredited IATA/ARC GDS agreements and bilateral airline NDC API credentials configured via server environment variables.
