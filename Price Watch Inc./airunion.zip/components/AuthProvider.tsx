'use client';

import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { CurrencyCode, UserPublic } from '@/lib/domain/types';

interface AuthContextValue {
  user: UserPublic | null;
  token: string | null;
  currency: CurrencyCode;
  setCurrency: (c: CurrencyCode) => void;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  setSession: (token: string | null, user: UserPublic | null) => void;
  signOut: () => void;
  signInDemoTraveler: () => Promise<void>;
  authFetch: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // Token kept strictly in React memory (never persisted to localStorage/sessionStorage)
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<UserPublic | null>(null);
  const [currency, setCurrency] = useState<CurrencyCode>('USD');
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const setSession = useCallback((nextToken: string | null, nextUser: UserPublic | null) => {
    setToken(nextToken);
    setUser(nextUser);
  }, []);

  const signOut = useCallback(() => {
    setToken(null);
    setUser(null);
  }, []);

  const signInDemoTraveler = useCallback(async () => {
    const res = await fetch('/api/auth', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ action: 'demo_traveler' }),
    });
    if (res.ok) {
      const data = (await res.json()) as { token: string; user: UserPublic };
      setToken(data.token);
      setUser(data.user);
      setAuthModalOpen(false);
    }
  }, []);

  const authFetch = useCallback(
    async (input: RequestInfo | URL, init?: RequestInit) => {
      const headers = new Headers(init?.headers);
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      return fetch(input, { ...init, headers });
    },
    [token]
  );

  // Respect system preference or keep clean initial currency
  useEffect(() => {
    // No external side effects required
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        currency,
        setCurrency,
        authModalOpen,
        setAuthModalOpen,
        setSession,
        signOut,
        signInDemoTraveler,
        authFetch,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
