'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  Bookmark,
  ExternalLink,
  FileText,
  Play,
  Trash2,
  User,
} from 'lucide-react';
import { formatMoney } from '@/lib/domain/money';
import type {
  HandoffEventRecord,
  ManualBookingRecord,
  PriceAlertRecord,
  SavedItineraryRecord,
  SavedSearchRecord,
  SearchCriteria,
} from '@/lib/domain/types';
import { useAuth } from './AuthProvider';

interface MyTripsPayload {
  savedSearches: SavedSearchRecord[];
  savedItineraries: SavedItineraryRecord[];
  priceAlerts: PriceAlertRecord[];
  alertRunLogs: {
    id: string;
    alertId: string;
    checkedAt: string;
    outcome: string;
    observedPrice: string | null;
    priceBasis: string;
    message: string;
  }[];
  handoffEvents: HandoffEventRecord[];
  manualBookings: ManualBookingRecord[];
}

function criteriaToSearchUrl(c: SearchCriteria): string {
  const p = new URLSearchParams({
    tripType: c.tripType,
    origin: c.originCode,
    dest: c.destinationCode,
    nearbyOrigin: c.includeNearbyOrigin ? '1' : '0',
    nearbyDest: c.includeNearbyDestination ? '1' : '0',
    depart: c.departDate,
    adults: String(c.passengers.adults),
    children: String(c.passengers.children),
    infants: String(c.passengers.infants),
    cabin: c.cabin,
    bag: c.requiredBaggage,
    seat: c.seatPreference,
    refundable: c.refundableOnly ? '1' : '0',
    currency: c.currency,
  });
  if (c.returnDate) p.set('return', c.returnDate);
  return `/search?${p.toString()}`;
}

export function MyTripsClient() {
  const { user, authFetch, setAuthModalOpen, signInDemoTraveler } = useAuth();
  const [data, setData] = useState<MyTripsPayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [checkingAlertId, setCheckingAlertId] = useState<string | null>(null);

  // Manual booking form
  const [confCode, setConfCode] = useState('');
  const [airlineSeller, setAirlineSeller] = useState('');
  const [routeSummary, setRouteSummary] = useState('');
  const [travelDate, setTravelDate] = useState('');
  const [notes, setNotes] = useState('');

  const loadTrips = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const res = await authFetch('/api/my-trips');
      if (res.ok) {
        const json = (await res.json()) as MyTripsPayload;
        setData(json);
      }
    } finally {
      setLoading(false);
    }
  }, [user, authFetch]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    authFetch('/api/my-trips')
      .then(async (res) => {
        if (!res.ok) return;
        const json = (await res.json()) as MyTripsPayload;
        if (!cancelled) setData(json);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [user, authFetch]);

  async function handleRunAlertCheck(alertId: string) {
    setCheckingAlertId(alertId);
    setStatusMsg(null);
    try {
      const res = await authFetch('/api/my-trips', {
        method: 'PATCH',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action: 'run_check', alertId }),
      });
      if (res.ok) {
        setStatusMsg('Periodic alert evaluation completed using saved baggage and cabin requirements.');
        await loadTrips();
      }
    } finally {
      setCheckingAlertId(null);
    }
  }

  async function handleDelete(kind: string, id: string) {
    const res = await authFetch(
      `/api/my-trips?kind=${encodeURIComponent(kind)}&id=${encodeURIComponent(id)}`,
      { method: 'DELETE' }
    );
    if (res.ok) {
      await loadTrips();
    }
  }

  async function handleAddManualBooking(e: React.FormEvent) {
    e.preventDefault();
    setStatusMsg(null);
    const res = await authFetch('/api/my-trips', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        kind: 'manual_booking',
        confirmationCode: confCode,
        airlineOrSeller: airlineSeller,
        routeSummary,
        travelDate,
        notes,
      }),
    });
    if (res.ok) {
      setConfCode('');
      setAirlineSeller('');
      setRouteSummary('');
      setTravelDate('');
      setNotes('');
      setStatusMsg('Manual booking reference saved (marked as unverified user note).');
      await loadTrips();
    }
  }

  if (!user) {
    return (
      <div className="bg-[#F4F7FA] min-h-[75vh] py-14">
        <div className="max-w-xl mx-auto px-4 sm:px-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-4">
            <User className="w-10 h-10 text-[#0D2038] mx-auto" />
            <h1 className="font-display text-2xl font-bold text-[#0D2038]">
              Sign in to access My trips
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed">
              Manage your saved searches, saved itineraries, like-for-like price alerts, supplier referral history, and manually recorded booking references.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setAuthModalOpen(true)}
                className="px-5 py-2.5 rounded-xl bg-[#16C2AF] hover:bg-[#12AD9C] text-[#0D2038] font-bold text-sm cursor-pointer"
              >
                Sign in or register
              </button>
              <button
                type="button"
                onClick={() => void signInDemoTraveler()}
                className="px-5 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-semibold text-sm cursor-pointer"
              >
                Try Demo Traveler (Jordan Mercer)
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#F4F7FA] min-h-screen pb-16">
      <div className="bg-[#0D2038] text-white py-8 border-b border-white/10">
        <div className="max-w-[1220px] mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold">My trips</h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Workspace for {user.name} ({user.email})
            </p>
          </div>
          <Link
            href="/"
            className="px-4 py-2 rounded-xl bg-[#16C2AF] text-[#0D2038] text-xs sm:text-sm font-bold"
          >
            New flight search
          </Link>
        </div>
      </div>

      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 pt-6 space-y-8">
        {statusMsg && (
          <div className="px-4 py-3 rounded-xl bg-teal-50 border border-teal-200 text-sm text-teal-900">
            {statusMsg}
          </div>
        )}

        {loading && !data && (
          <p className="text-sm text-slate-500">Loading your saved trip records...</p>
        )}

        {data && (
          <>
            {/* Price Alerts */}
            <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="font-display text-xl font-bold text-[#0D2038] flex items-center gap-2">
                    <Bell className="w-5 h-5 text-[#EB5E47]" />
                    <span>Price alerts</span>
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Alerts evaluate periodic checks strictly against your saved baggage, cabin, and traveler requirements (not continuous live streaming).
                  </p>
                </div>
              </div>

              {data.priceAlerts.length === 0 ? (
                <p className="text-sm text-slate-500">
                  No price alerts yet. Run a search and click &ldquo;Create price alert&rdquo;.
                </p>
              ) : (
                <div className="space-y-3">
                  {data.priceAlerts.map((alert) => (
                    <div
                      key={alert.alertId}
                      className="rounded-xl border border-slate-200 p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-bold text-[#0D2038]">{alert.label}</span>
                          <span className="text-xs text-slate-400">·</span>
                          <span className="text-xs font-mono font-semibold text-[#0E5952]">
                            Target ≤ {formatMoney(alert.targetPrice)}
                          </span>
                          <span className="text-xs text-slate-400">·</span>
                          <span className="text-xs text-slate-500">
                            {alert.checkFrequency === 'every_6_hours'
                              ? 'Checked periodically every 6h'
                              : 'Checked periodically daily'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600">
                          Requirements: {alert.criteria.cabin.replace('_', ' ')} ·{' '}
                          <strong>{alert.criteria.requiredBaggage.replace('_', ' ')}</strong> ·{' '}
                          {alert.criteria.passengers.adults + alert.criteria.passengers.children + alert.criteria.passengers.infants}{' '}
                          traveler(s)
                        </p>
                        {alert.lastCheckedAt && (
                          <p className="text-xs text-slate-700">
                            Last checked {new Date(alert.lastCheckedAt).toLocaleString()} ·{' '}
                            {alert.lastCheckedPrice
                              ? `Observed ${formatMoney(alert.lastCheckedPrice)} (${alert.lastPriceBasis})`
                              : alert.lastPriceBasis}
                          </p>
                        )}
                        {alert.lastNotificationMessage && (
                          <p
                            className={`text-xs font-medium ${
                              alert.lastNotificationStatus === 'notified'
                                ? 'text-emerald-700'
                                : 'text-amber-800'
                            }`}
                          >
                            {alert.lastNotificationMessage}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          disabled={checkingAlertId === alert.alertId}
                          onClick={() => void handleRunAlertCheck(alert.alertId)}
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#0D2038] text-white text-xs font-semibold cursor-pointer disabled:opacity-60"
                        >
                          <Play className="w-3.5 h-3.5 text-[#16C2AF]" />
                          <span>
                            {checkingAlertId === alert.alertId ? 'Checking...' : 'Run check now'}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => void handleDelete('price_alert', alert.alertId)}
                          className="p-2 rounded-lg border border-slate-200 text-slate-500 hover:text-rose-700 cursor-pointer"
                          aria-label="Delete alert"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* Saved Searches & Saved Itineraries */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                <h2 className="font-display text-lg font-bold text-[#0D2038] flex items-center gap-2">
                  <Bookmark className="w-4 h-4 text-[#16C2AF]" />
                  <span>Saved searches</span>
                </h2>
                {data.savedSearches.length === 0 ? (
                  <p className="text-sm text-slate-500">No saved searches yet.</p>
                ) : (
                  <div className="space-y-3">
                    {data.savedSearches.map((s) => (
                      <div
                        key={s.savedSearchId}
                        className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#0D2038] truncate">{s.label}</p>
                          <p className="text-xs text-slate-500">
                            {s.criteria.departDate}
                            {s.criteria.returnDate ? ` → ${s.criteria.returnDate}` : ' (One way)'} ·{' '}
                            {s.criteria.requiredBaggage.replace('_', ' ')}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Link
                            href={criteriaToSearchUrl(s.criteria)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#16C2AF] text-[#0D2038] text-xs font-bold"
                          >
                            <span>Run</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </Link>
                          <button
                            type="button"
                            onClick={() => void handleDelete('saved_search', s.savedSearchId)}
                            className="p-1.5 text-slate-400 hover:text-rose-700 cursor-pointer"
                            aria-label="Delete saved search"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                <h2 className="font-display text-lg font-bold text-[#0D2038]">Saved itineraries</h2>
                {data.savedItineraries.length === 0 ? (
                  <p className="text-sm text-slate-500">
                    No saved itineraries yet. Click &ldquo;Save itinerary&rdquo; on any offer detail page.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {data.savedItineraries.map((item) => (
                      <div
                        key={item.savedItineraryId}
                        className="p-3.5 rounded-xl border border-slate-200 flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#0D2038] truncate">
                            {item.offerSnapshot.seller.name} · {item.offerSnapshot.fareProduct.fareFamilyName}
                          </p>
                          <p className="text-xs text-slate-500 tabular-nums">
                            Snapshot: {formatMoney(item.offerSnapshot.evaluation.comparableTotal)} · Saved{' '}
                            {new Date(item.savedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Link
                            href={`/offers/${encodeURIComponent(item.offerId)}`}
                            className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold hover:bg-slate-50"
                          >
                            Inspect
                          </Link>
                          <button
                            type="button"
                            onClick={() => void handleDelete('saved_itinerary', item.savedItineraryId)}
                            className="p-1.5 text-slate-400 hover:text-rose-700 cursor-pointer"
                            aria-label="Delete saved itinerary"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </div>

            {/* Supplier Handoff History & Manual Booking References */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                <h2 className="font-display text-lg font-bold text-[#0D2038] flex items-center gap-2">
                  <ExternalLink className="w-4 h-4 text-[#EB5E47]" />
                  <span>Supplier handoff history</span>
                </h2>
                {data.handoffEvents.length === 0 ? (
                  <p className="text-sm text-slate-500">
                    No referral clicks recorded yet. Continuing to an airline or seller logs your handoff here.
                  </p>
                ) : (
                  <div className="space-y-2.5 text-xs">
                    {data.handoffEvents.map((h) => (
                      <div
                        key={h.handoffId}
                        className="p-3 rounded-xl border border-slate-200 flex items-center justify-between gap-3"
                      >
                        <div>
                          <p className="font-semibold text-slate-900">
                            {h.sellerName} · {h.routeSummary}
                          </p>
                          <p className="text-slate-500">
                            {new Date(h.createdAt).toLocaleString()} · Referral only (not a confirmed ticket)
                          </p>
                        </div>
                        <span className="font-mono font-bold text-[#0D2038] tabular-nums">
                          {formatMoney(h.totalAtHandoff)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                <div>
                  <h2 className="font-display text-lg font-bold text-[#0D2038] flex items-center gap-2">
                    <FileText className="w-4 h-4 text-[#0E5952]" />
                    <span>Manual booking references</span>
                  </h2>
                  <p className="text-xs text-amber-800 mt-1 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>
                      Personal notes only — distinct from verified airline reservations.
                    </span>
                  </p>
                </div>

                <form onSubmit={handleAddManualBooking} className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                  <input
                    type="text"
                    required
                    value={confCode}
                    onChange={(e) => setConfCode(e.target.value)}
                    placeholder="Confirmation / PNR (e.g. ABC123)"
                    className="px-3 py-2 border border-slate-300 rounded-lg font-mono uppercase"
                  />
                  <input
                    type="text"
                    required
                    value={airlineSeller}
                    onChange={(e) => setAirlineSeller(e.target.value)}
                    placeholder="Airline or seller"
                    className="px-3 py-2 border border-slate-300 rounded-lg"
                  />
                  <input
                    type="text"
                    required
                    value={routeSummary}
                    onChange={(e) => setRouteSummary(e.target.value)}
                    placeholder="Route (e.g. JFK → LAX)"
                    className="px-3 py-2 border border-slate-300 rounded-lg"
                  />
                  <input
                    type="date"
                    value={travelDate}
                    onChange={(e) => setTravelDate(e.target.value)}
                    className="px-3 py-2 border border-slate-300 rounded-lg"
                  />
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Optional notes"
                    className="sm:col-span-2 px-3 py-2 border border-slate-300 rounded-lg"
                  />
                  <button
                    type="submit"
                    className="sm:col-span-2 py-2 rounded-lg bg-[#0D2038] text-white font-semibold cursor-pointer"
                  >
                    Record manual reference
                  </button>
                </form>

                <div className="space-y-2.5">
                  {data.manualBookings.map((mb) => (
                    <div
                      key={mb.bookingRecordId}
                      className="p-3 rounded-xl border border-slate-200 flex items-start justify-between gap-2 text-xs"
                    >
                      <div>
                        <p className="font-semibold text-slate-900">
                          <span className="font-mono">{mb.confirmationCode}</span> · {mb.airlineOrSeller} ·{' '}
                          {mb.routeSummary}
                        </p>
                        <p className="text-amber-800 mt-0.5">{mb.verificationNote}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => void handleDelete('manual_booking', mb.bookingRecordId)}
                        className="p-1 text-slate-400 hover:text-rose-700 cursor-pointer"
                        aria-label="Delete manual booking"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
