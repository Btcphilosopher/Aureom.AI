'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  AlertTriangle,
  ArrowLeft,
  Bookmark,
  CheckCircle2,
  Clock,
  ExternalLink,
  Plane,
  RefreshCw,
  ShieldAlert,
} from 'lucide-react';
import { addMoney, convertCurrency, formatMoney, makeMoney } from '@/lib/domain/money';
import { formatDurationMinutes, getLocalParts } from '@/lib/domain/timezone';
import type { Offer, RevalidationResult } from '@/lib/domain/types';
import { useAuth } from './AuthProvider';

export function OfferDetailClient({ offerId }: { offerId: string }) {
  const router = useRouter();
  const { user, currency, authFetch, setAuthModalOpen } = useAuth();

  const [offer, setOffer] = useState<Offer | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Opt-in extras state
  const [selectedExtraIds, setSelectedExtraIds] = useState<string[]>([]);

  // Revalidation state
  const [revalidating, setRevalidating] = useState(false);
  const [revalidation, setRevalidation] = useState<RevalidationResult | null>(null);
  const [acceptedPriceChange, setAcceptedPriceChange] = useState(false);
  const [handoffBusy, setHandoffBusy] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/offers/${encodeURIComponent(offerId)}?currency=${encodeURIComponent(currency)}`)
      .then(async (res) => {
        const data = (await res.json()) as { offer?: Offer; error?: string };
        if (!res.ok || !data.offer) {
          throw new Error(data.error ?? 'Offer unavailable');
        }
        if (!cancelled) {
          setOffer(data.offer);
          setError(null);
        }
      })
      .catch((err: Error) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [offerId, currency]);

  const totals = useMemo(() => {
    if (!offer) return null;
    const basePlusTaxes = addMoney(
      offer.observation.baseFareTotal,
      offer.observation.taxesAndMandatoryTotal
    );

    let optInMinor = 0;
    for (const extra of offer.observation.availableExtras) {
      if (selectedExtraIds.includes(extra.extraId)) {
        optInMinor += extra.priceForTrip.minorUnits;
      }
    }

    const optInMoney = makeMoney(optInMinor, basePlusTaxes.currency);
    const activeBasePlusUpdated =
      revalidation && revalidation.status === 'price_changed'
        ? revalidation.updatedTotal
        : basePlusTaxes;

    const grandTotal = addMoney(activeBasePlusUpdated, optInMoney);
    const fx =
      currency !== grandTotal.currency ? convertCurrency(grandTotal, currency) : null;

    return { basePlusTaxes, optInMoney, grandTotal, fx };
  }, [offer, selectedExtraIds, revalidation, currency]);

  async function handleRevalidate() {
    if (!offer) return;
    setRevalidating(true);
    setAcceptedPriceChange(false);
    try {
      const res = await fetch(`/api/offers/${encodeURIComponent(offer.offerId)}/revalidate`, {
        method: 'POST',
      });
      const json = (await res.json()) as RevalidationResult & { error?: string };
      if (!res.ok) {
        setError(json.error ?? 'Revalidation request failed.');
      } else {
        setRevalidation(json);
      }
    } catch {
      setError('Unable to reach provider revalidation endpoint.');
    } finally {
      setRevalidating(false);
    }
  }

  async function handleContinueToSupplier() {
    if (!offer || !revalidation?.referralUrl) return;
    setHandoffBusy(true);
    try {
      const res = await authFetch('/api/handoffs', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          offerId: offer.offerId,
          referralUrl: revalidation.referralUrl,
        }),
      });
      const data = (await res.json()) as { referralUrl?: string; error?: string };
      if (!res.ok || !data.referralUrl) {
        setError(data.error ?? 'Referral validation failed.');
        return;
      }
      router.push(data.referralUrl);
    } finally {
      setHandoffBusy(false);
    }
  }

  async function handleSaveItinerary() {
    if (!offer) return;
    if (!user) {
      setAuthModalOpen(true);
      return;
    }
    const res = await authFetch('/api/my-trips', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        kind: 'saved_itinerary',
        offerId: offer.offerId,
        notes: `${offer.seller.name} · ${offer.fareProduct.fareFamilyName}`,
      }),
    });
    if (res.ok) {
      setSaveMsg('Itinerary saved to My trips.');
    } else {
      const err = (await res.json()) as { error?: string };
      setSaveMsg(err.error ?? 'Could not save itinerary.');
    }
  }

  if (loading) {
    return (
      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 py-12">
        <div className="bg-white rounded-xl border border-slate-200 p-8 animate-pulse space-y-4">
          <div className="h-6 bg-slate-200 rounded w-1/3" />
          <div className="h-24 bg-slate-100 rounded w-full" />
        </div>
      </div>
    );
  }

  if (error || !offer || !totals) {
    return (
      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 py-12">
        <div className="bg-white rounded-xl border border-rose-200 p-8 space-y-4">
          <h1 className="font-display text-xl font-bold text-slate-900">Offer unavailable</h1>
          <p className="text-sm text-slate-600">{error ?? 'Offer could not be loaded.'}</p>
          <Link
            href="/search"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#0D2038] text-white text-xs font-semibold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to flight search</span>
          </Link>
        </div>
      </div>
    );
  }

  const supplierActionLabel =
    offer.seller.kind === 'airline_direct' ? 'Continue to airline' : 'Continue to seller';

  const canProceedToSupplier =
    revalidation &&
    (revalidation.status === 'confirmed' ||
      (revalidation.status === 'price_changed' && acceptedPriceChange));

  return (
    <div className="bg-[#F4F7FA] min-h-screen pb-14">
      <div className="bg-[#0D2038] text-white py-6 border-b border-white/10">
        <div className="max-w-[1100px] mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <Link
              href="/search"
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-300 hover:text-white mb-2"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to search results</span>
            </Link>
            <h1 className="font-display text-2xl sm:text-3xl font-bold">
              {offer.seller.name} · {offer.fareProduct.fareFamilyName}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Provider: {offer.observation.providerName} · Reference:{' '}
              <span className="font-mono">{offer.observation.providerOfferRef}</span> · Collected{' '}
              {new Date(offer.observation.collectedAt).toLocaleTimeString('en-US', {
                hour: 'numeric',
                minute: '2-digit',
              })}
            </p>
          </div>

          <button
            type="button"
            onClick={() => void handleSaveItinerary()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-white/25 hover:bg-white/10 text-xs sm:text-sm font-semibold cursor-pointer"
          >
            <Bookmark className="w-4 h-4 text-[#16C2AF]" />
            <span>Save itinerary</span>
          </button>
        </div>
      </div>

      <div className="max-w-[1100px] mx-auto px-4 sm:px-6 pt-6 space-y-6">
        {saveMsg && (
          <div className="px-4 py-3 rounded-xl bg-teal-50 border border-teal-200 text-sm text-teal-900 flex items-center justify-between">
            <span>{saveMsg}</span>
            <Link href="/my-trips" className="font-semibold underline">
              View in My trips →
            </Link>
          </div>
        )}

        {offer.isExpired && !revalidation && (
          <div className="px-4 py-3 rounded-xl bg-amber-50 border border-amber-200 text-sm text-amber-950 flex items-start gap-2.5">
            <Clock className="w-4 h-4 shrink-0 mt-0.5" />
            <span>
              This offer snapshot expired at {new Date(offer.observation.expiresAt).toLocaleString()}.
              Click <strong>Revalidate offer</strong> below to check live status or view refreshed alternatives.
            </span>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-[1.65fr_1fr] gap-6 items-start">
          {/* Left Column: Itinerary Segments + Baggage + Fare Rules */}
          <div className="space-y-6">
            {/* Itinerary Bounds */}
            <section className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
              <h2 className="font-display text-lg font-bold text-[#0D2038]">
                Itinerary & operating carriers
              </h2>

              {offer.journey.bounds.map((bound) => (
                <div key={bound.boundId} className="space-y-3 pt-3 border-t border-slate-100 first:border-t-0 first:pt-0">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="font-bold uppercase tracking-wide text-[#0D2038]">
                      {bound.direction} · {bound.originAirport} → {bound.destinationAirport}
                    </span>
                    <span className="font-mono text-slate-600 tabular-nums">
                      Total {formatDurationMinutes(bound.totalDurationMinutes)} · {bound.stops} stop(s)
                    </span>
                  </div>

                  {bound.hasMixedCabins && (
                    <div className="px-3 py-2 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900">
                      <strong>Mixed cabin notice:</strong> Segments in this bound operate in different cabins. Check each leg below.
                    </div>
                  )}

                  {bound.hasSelfTransfer && (
                    <div className="px-3 py-2 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-900">
                      <strong>Separate tickets / Self-transfer:</strong> These flights are not on a single protected airline ticket. No missed-connection protection applies.
                    </div>
                  )}

                  <div className="space-y-3">
                    {bound.segments.map((seg, idx) => {
                      const depLocal = getLocalParts(seg.departureUtc, seg.originTimezone);
                      const arrLocal = getLocalParts(seg.arrivalUtc, seg.destinationTimezone);
                      const conn = bound.connections[idx];
                      return (
                        <div key={seg.segmentId} className="space-y-2">
                          <div className="rounded-lg border border-slate-200 p-4 bg-slate-50/60">
                            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 mb-2">
                              <span className="font-semibold text-slate-900 flex items-center gap-1.5">
                                <Plane className="w-3.5 h-3.5 text-[#EB5E47]" />
                                {seg.flightNumber} · Marketing: {seg.marketingCarrier.name}
                              </span>
                              <span>
                                Operating: <strong>{seg.operatingCarrier.name}</strong> · {seg.aircraft}
                              </span>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
                              <div>
                                <p className="text-base font-bold text-[#0D2038] tabular-nums">
                                  {depLocal.displayTime}
                                </p>
                                <p className="text-xs text-slate-600">
                                  {depLocal.displayDate} ·{' '}
                                  <span className="font-mono">
                                    {seg.originAirport}
                                    {seg.originTerminal ? ` T${seg.originTerminal}` : ''}
                                  </span>{' '}
                                  ({seg.originTimezone})
                                </p>
                              </div>

                              <div className="text-xs text-slate-500 sm:text-center">
                                <p className="font-mono tabular-nums">
                                  {formatDurationMinutes(seg.durationMinutes)}
                                </p>
                                <p className="capitalize font-medium text-slate-700 mt-0.5">
                                  Cabin: {seg.cabin.replace('_', ' ')}
                                </p>
                              </div>

                              <div className="sm:text-right">
                                <p className="text-base font-bold text-[#0D2038] tabular-nums">
                                  {arrLocal.displayTime}
                                  {seg.dayOffsetFromDeparture > 0 && (
                                    <span className="ml-1 text-xs font-bold text-[#EB5E47]">
                                      +{seg.dayOffsetFromDeparture}d
                                    </span>
                                  )}
                                </p>
                                <p className="text-xs text-slate-600">
                                  {arrLocal.displayDate} ·{' '}
                                  <span className="font-mono">
                                    {seg.destinationAirport}
                                    {seg.destinationTerminal ? ` T${seg.destinationTerminal}` : ''}
                                  </span>{' '}
                                  ({seg.destinationTimezone})
                                </p>
                              </div>
                            </div>

                            {(seg.crossesDateLine || seg.dstTransitioned) && (
                              <p className="mt-2 text-[11px] text-slate-600">
                                {seg.crossesDateLine && 'Crosses International Date Line. '}
                                {seg.dstTransitioned && 'Spans a Daylight Saving Time transition; duration uses exact UTC timestamps.'}
                              </p>
                            )}
                          </div>

                          {conn && (
                            <div className="px-3.5 py-2 rounded-lg bg-slate-100 text-xs text-slate-700 flex flex-wrap items-center justify-between gap-2">
                              <span>
                                Layover at{' '}
                                <strong className="font-mono">
                                  {conn.atAirport}
                                  {conn.isAirportChange ? ` → ${conn.toAirport} (Airport change)` : ''}
                                </strong>{' '}
                                · {formatDurationMinutes(conn.durationMinutes)}
                                {conn.isOvernight ? ' · Overnight connection' : ''}
                              </span>
                              <span
                                className={
                                  conn.isProtectedConnection
                                    ? 'text-emerald-700 font-semibold'
                                    : 'text-rose-700 font-semibold'
                                }
                              >
                                {conn.protectionNote}
                              </span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </section>

            {/* Baggage Allowances by Segment */}
            <section className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
              <h2 className="font-display text-lg font-bold text-[#0D2038]">
                Baggage allowance per segment
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500">
                      <th className="py-2 pr-3 font-semibold">Segment</th>
                      <th className="py-2 pr-3 font-semibold">Personal item</th>
                      <th className="py-2 pr-3 font-semibold">Carry-on bag</th>
                      <th className="py-2 font-semibold">1st Checked bag</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {offer.journey.bounds
                      .flatMap((b) => b.segments)
                      .map((seg) => {
                        const bag = offer.fareProduct.baggagePerSegment.find(
                          (x) => x.segmentId === seg.segmentId
                        );
                        return (
                          <tr key={seg.segmentId}>
                            <td className="py-2.5 pr-3 font-mono font-semibold text-[#0D2038]">
                              {seg.originAirport}→{seg.destinationAirport}
                            </td>
                            <td className="py-2.5 pr-3">
                              {bag ? `${bag.personalItem.status.replace('_', ' ')}` : 'unknown'}
                            </td>
                            <td className="py-2.5 pr-3">
                              {bag
                                ? `${bag.carryOn.status.replace('_', ' ')}${
                                    bag.carryOn.maxWeightLb ? ` (${bag.carryOn.maxWeightLb} lb)` : ''
                                  }`
                                : 'unknown'}
                            </td>
                            <td className="py-2.5">
                              {bag
                                ? `${bag.checkedBag.status.replace('_', ' ')}${
                                    bag.checkedBag.maxWeightLb ? ` (${bag.checkedBag.maxWeightLb} lb)` : ''
                                  }${bag.checkedBag.notes ? ` · ${bag.checkedBag.notes}` : ''}`
                                : 'unknown'}
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Seat, Change & Refund Conditions */}
            <section className="bg-white rounded-xl border border-slate-200 p-6 space-y-3 text-xs sm:text-sm">
              <h2 className="font-display text-lg font-bold text-[#0D2038]">
                Seat, change & refund conditions
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
                <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                  <p className="text-xs font-semibold text-slate-500 mb-1">Seat policy</p>
                  <p className="font-bold text-[#0D2038] capitalize">
                    {offer.fareProduct.conditions.seatAssignment.status.replaceAll('_', ' ')}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    {offer.fareProduct.conditions.seatAssignment.notes}
                  </p>
                </div>
                <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                  <p className="text-xs font-semibold text-slate-500 mb-1">Changes</p>
                  <p className="font-bold text-[#0D2038] capitalize">
                    {offer.fareProduct.conditions.changeAllowed.replaceAll('_', ' ')}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    {offer.fareProduct.conditions.changeNotes}
                  </p>
                </div>
                <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                  <p className="text-xs font-semibold text-slate-500 mb-1">Refunds</p>
                  <p className="font-bold text-[#0D2038] capitalize">
                    {offer.fareProduct.conditions.refundAllowed.replaceAll('_', ' ')}
                  </p>
                  <p className="text-xs text-slate-600 mt-1">
                    {offer.fareProduct.conditions.refundNotes}
                  </p>
                </div>
              </div>
            </section>
          </div>

          {/* Right Column: Decimal Price Breakdown & Live Revalidation Handoff */}
          <aside className="bg-white rounded-xl border border-slate-200 p-6 space-y-5 lg:sticky lg:top-6">
            <div>
              <h2 className="font-display text-lg font-bold text-[#0D2038]">
                Price breakdown
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Passenger fares + taxes + mandatory fees + selected extras
              </p>
            </div>

            <div className="space-y-2 text-xs border-b border-slate-100 pb-4">
              {offer.observation.passengerLines.map((line) => (
                <div key={line.passengerType} className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold text-slate-800 capitalize">
                      {line.count} × {line.passengerType}
                    </p>
                    <p className="text-[11px] text-slate-500 tabular-nums">
                      Base {formatMoney(line.baseFareEach)} + Tax {formatMoney(line.taxesEach)} each
                    </p>
                  </div>
                  <span className="font-mono font-semibold text-slate-900 tabular-nums">
                    {formatMoney(line.subtotal)}
                  </span>
                </div>
              ))}
            </div>

            {/* Opt-in Priced Extras */}
            {offer.observation.availableExtras.length > 0 && (
              <div className="space-y-2 border-b border-slate-100 pb-4">
                <p className="text-xs font-semibold text-slate-800">Optional priced extras (opt-in)</p>
                {offer.observation.availableExtras.map((extra) => {
                  const checked = selectedExtraIds.includes(extra.extraId);
                  return (
                    <label
                      key={extra.extraId}
                      className="flex items-start justify-between gap-2 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer text-xs"
                    >
                      <div className="flex items-start gap-2">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={(e) => {
                            setSelectedExtraIds((prev) =>
                              e.target.checked
                                ? [...prev, extra.extraId]
                                : prev.filter((id) => id !== extra.extraId)
                            );
                          }}
                          className="mt-0.5"
                        />
                        <div>
                          <p className="font-semibold text-slate-900">{extra.label}</p>
                          <p className="text-[11px] text-slate-500">{extra.description}</p>
                        </div>
                      </div>
                      <span className="font-mono font-semibold text-slate-900 tabular-nums shrink-0">
                        +{formatMoney(extra.priceForTrip)}
                      </span>
                    </label>
                  );
                })}
              </div>
            )}

            {/* Total */}
            <div className="space-y-1.5">
              <div className="flex items-baseline justify-between">
                <span className="text-sm font-semibold text-slate-700">Payable comparable total</span>
                <span className="text-2xl font-bold text-[#0D2038] tabular-nums">
                  {formatMoney(totals.grandTotal)}
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Payable currency: {totals.grandTotal.currency} (collected at seller checkout).
              </p>
              {totals.fx && (
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-700 space-y-0.5">
                  <p className="font-semibold tabular-nums">
                    Estimated in {totals.fx.converted.currency}: {formatMoney(totals.fx.converted)}
                  </p>
                  <p>
                    Rate: {totals.fx.rate} · Source: {totals.fx.rateSource} ({totals.fx.rateTimestamp})
                  </p>
                </div>
              )}
            </div>

            {/* Revalidation Step */}
            <div className="pt-2 border-t border-slate-100 space-y-3">
              {!revalidation && (
                <button
                  type="button"
                  disabled={revalidating}
                  onClick={() => void handleRevalidate()}
                  className="w-full py-3 px-4 rounded-xl bg-[#0D2038] hover:bg-[#132B49] text-white font-bold text-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
                >
                  <RefreshCw className={`w-4 h-4 ${revalidating ? 'animate-spin' : ''}`} />
                  <span>{revalidating ? 'Revalidating with provider...' : 'Revalidate live fare'}</span>
                </button>
              )}

              {revalidation && (
                <div className="space-y-3">
                  <div
                    className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${
                      revalidation.status === 'confirmed'
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                        : revalidation.status === 'price_changed'
                        ? 'bg-amber-50 border-amber-200 text-amber-950'
                        : 'bg-rose-50 border-rose-200 text-rose-950'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold">
                      {revalidation.status === 'confirmed' ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                      ) : revalidation.status === 'price_changed' ? (
                        <AlertTriangle className="w-4 h-4 text-amber-700" />
                      ) : (
                        <ShieldAlert className="w-4 h-4 text-rose-700" />
                      )}
                      <span className="capitalize">
                        {revalidation.status.replace('_', ' ')}
                      </span>
                    </div>
                    <p>{revalidation.message}</p>
                  </div>

                  {revalidation.status === 'price_changed' && (
                    <label className="flex items-start gap-2 text-xs text-slate-800 cursor-pointer p-2.5 rounded-lg border border-amber-200 bg-amber-50/50">
                      <input
                        type="checkbox"
                        checked={acceptedPriceChange}
                        onChange={(e) => setAcceptedPriceChange(e.target.checked)}
                        className="mt-0.5"
                      />
                      <span>
                        I acknowledge the updated fare of{' '}
                        <strong className="tabular-nums">
                          {formatMoney(totals.grandTotal)}
                        </strong>{' '}
                        ({formatMoney(revalidation.priceDelta)} change).
                      </span>
                    </label>
                  )}

                  {canProceedToSupplier && (
                    <button
                      type="button"
                      disabled={handoffBusy}
                      onClick={() => void handleContinueToSupplier()}
                      className="w-full py-3 px-4 rounded-xl bg-[#16C2AF] hover:bg-[#12AD9C] text-[#0D2038] font-bold text-sm flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>{handoffBusy ? 'Preparing handoff...' : supplierActionLabel}</span>
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  )}

                  {revalidation.status === 'expired' &&
                    revalidation.refreshedAlternatives &&
                    revalidation.refreshedAlternatives.length > 0 && (
                      <div className="space-y-2 pt-2">
                        <p className="text-xs font-bold text-slate-800">
                          Refreshed comparable alternatives:
                        </p>
                        {revalidation.refreshedAlternatives.map((alt) => (
                          <Link
                            key={alt.offerId}
                            href={`/offers/${encodeURIComponent(alt.offerId)}`}
                            className="block p-3 rounded-lg border border-slate-200 hover:border-[#16C2AF] text-xs"
                          >
                            <div className="flex justify-between font-bold text-[#0D2038]">
                              <span>{alt.seller.name}</span>
                              <span className="tabular-nums">
                                {formatMoney(alt.evaluation.comparableTotal)}
                              </span>
                            </div>
                            <p className="text-slate-500 mt-0.5">{alt.fareProduct.fareFamilyName}</p>
                          </Link>
                        ))}
                      </div>
                    )}

                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    {revalidation.affiliateDisclosure}
                  </p>
                </div>
              )}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
