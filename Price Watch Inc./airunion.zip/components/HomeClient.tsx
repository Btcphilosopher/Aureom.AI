'use client';

import React, { useMemo } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import {
  Armchair,
  Briefcase,
  CalendarCheck,
  ChevronRight,
  Plane,
  RefreshCw,
} from 'lucide-react';
import { motion } from 'motion/react';
import { DEFAULT_DESTINATIONS, type DestinationItem } from '@/lib/data/destinations';
import { AIRUNION_MEDIA } from '@/lib/data/media';
import { getDefaultFutureDates } from '@/lib/domain/timezone';
import { useAuth } from './AuthProvider';
import { SearchForm } from './SearchForm';

export function HomeClient() {
  const { currency } = useAuth();
  const defaults = useMemo(() => getDefaultFutureDates(), []);

  const featuredDestinations = DEFAULT_DESTINATIONS.filter((d) => d.category === 'featured');
  const inspirationItems = DEFAULT_DESTINATIONS.filter((d) => d.category !== 'featured');

  function buildPrefilledSearchUrl(item: DestinationItem): string {
    const params = new URLSearchParams({
      tripType: 'round_trip',
      origin: item.defaultOriginCode,
      dest: item.destinationCode,
      nearbyOrigin: '0',
      nearbyDest: '0',
      depart: defaults.departDate,
      return: defaults.returnDate,
      adults: '1',
      children: '0',
      infants: '0',
      cabin: 'economy',
      bag: 'carry_on',
      seat: 'any',
      currency,
    });
    return `/search?${params.toString()}`;
  }

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-[#0D2038] overflow-visible">
        <div className="relative min-h-[450px] sm:min-h-[480px] flex flex-col justify-end">
          <Image
            src={AIRUNION_MEDIA.hero}
            alt="Commercial jetliner cruising above golden clouds at sunset"
            fill
            priority
            referrerPolicy="no-referrer"
            className="object-cover object-center"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-r from-[#0B1B30]/90 via-[#0D2038]/55 to-[#0D2038]/20"
          />
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-[#0D2038] via-transparent to-transparent"
          />

          <div className="relative z-10 max-w-[1220px] w-full mx-auto px-4 sm:px-6 pt-12 pb-10">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="max-w-2xl mb-7"
            >
              <h1 className="font-display text-3xl sm:text-[44px] font-bold text-white tracking-tight leading-[1.12] text-balance">
                Your next great trip starts here.
              </h1>
              <div className="w-24 h-[3px] bg-[#EB5E47] rounded-full mt-2.5 mb-3" />
              <p className="text-base sm:text-lg text-slate-100 font-normal">
                Compare flights. Understand your fare. Fly your way.
              </p>
            </motion.div>

            {/* Floating White Search Panel */}
            <SearchForm />
          </div>
        </div>

        {/* Navy Trust Strip */}
        <div className="bg-[#0D2038] border-t border-white/10">
          <div className="max-w-[1220px] mx-auto px-4 sm:px-6 py-4 grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-0 text-white text-sm font-medium">
            <div className="flex items-center justify-center gap-3 sm:border-r sm:border-white/15 px-3">
              <Plane className="w-5 h-5 text-[#EB5E47] shrink-0" />
              <span>Compare available flights</span>
            </div>
            <div className="flex items-center justify-center gap-3 sm:border-r sm:border-white/15 px-3">
              <Briefcase className="w-5 h-5 text-[#EB5E47] shrink-0" />
              <span>Baggage made clear</span>
            </div>
            <div className="flex items-center justify-center gap-3 px-3">
              <CalendarCheck className="w-5 h-5 text-[#EB5E47] shrink-0" />
              <span>Manage trips in one place</span>
            </div>
          </div>
        </div>
      </section>

      {/* Where will you fly next? + Know what's included */}
      <section className="max-w-[1220px] mx-auto px-4 sm:px-6 py-10 sm:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-[2.15fr_1fr] gap-8 items-start">
          {/* Left: Featured US Destinations */}
          <div>
            <h2 className="font-display text-2xl sm:text-[28px] font-bold text-[#0D2038] tracking-tight">
              Where will you fly next?
            </h2>
            <div className="w-16 h-[3px] bg-[#EB5E47] rounded-full mt-1.5 mb-5" />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {featuredDestinations.map((dest) => (
                <Link
                  key={dest.id}
                  href={buildPrefilledSearchUrl(dest)}
                  className="group relative aspect-[4/3] rounded-2xl overflow-hidden shadow-sm border border-slate-200 block focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#16C2AF]"
                >
                  <Image
                    src={AIRUNION_MEDIA[dest.imageKey]}
                    alt={`${dest.title} skyline and travel view`}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                  />
                  <div
                    aria-hidden="true"
                    className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"
                  />
                  <div className="absolute inset-x-0 bottom-0 p-4 flex flex-col items-start gap-2.5">
                    <h3 className="font-display text-xl font-bold text-white leading-tight">
                      {dest.title}
                    </h3>
                    <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white text-[#0D2038] text-xs font-semibold shadow-xs group-hover:bg-[#16C2AF] transition-colors whitespace-nowrap">
                      <span>Explore flights</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Right: Know what's included */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 sm:p-6">
            <h2 className="font-display text-[22px] font-bold text-[#0D2038] tracking-tight">
              Know what’s included
            </h2>
            <div className="w-12 h-[3px] bg-[#EB5E47] rounded-full mt-1.5 mb-5" />

            <div className="divide-y divide-slate-100">
              <Link
                href="/help#carry-on-baggage"
                className="group flex items-center justify-between py-3.5 first:pt-1 last:pb-1"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-[#D9F3EE] flex items-center justify-center text-[#0F5A54] shrink-0">
                    <Briefcase className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[15px] font-bold text-[#0D2038] group-hover:text-[#0E5952] transition-colors">
                      Carry-on baggage
                    </p>
                    <p className="text-xs text-slate-600">Compare by fare</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" />
              </Link>

              <Link
                href="/help#seat-selection"
                className="group flex items-center justify-between py-3.5"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-[#FDE7E3] flex items-center justify-center text-[#E05640] shrink-0">
                    <Armchair className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[15px] font-bold text-[#0D2038] group-hover:text-[#0E5952] transition-colors">
                      Seat selection
                    </p>
                    <p className="text-xs text-slate-600">Compare by fare</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" />
              </Link>

              <Link
                href="/help#change-conditions"
                className="group flex items-center justify-between py-3.5 last:pb-1"
              >
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-xl bg-[#D9F3EE] flex items-center justify-center text-[#0F5A54] shrink-0">
                    <RefreshCw className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[15px] font-bold text-[#0D2038] group-hover:text-[#0E5952] transition-colors">
                      Change conditions
                    </p>
                    <p className="text-xs text-slate-600">Compare by fare</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* A trip for every kind of traveler */}
      <section className="bg-[#F4F7FA] border-t border-slate-200/80 py-10 sm:py-12">
        <div className="max-w-[1220px] mx-auto px-4 sm:px-6 grid grid-cols-1 lg:grid-cols-[1fr_2.6fr] gap-8 items-center">
          <div>
            <h2 className="font-display text-2xl sm:text-[26px] font-bold text-[#0D2038] tracking-tight leading-snug text-balance">
              A trip for every kind of traveler
            </h2>
            <div className="w-14 h-[3px] bg-[#EB5E47] rounded-full mt-2 mb-3.5" />
            <p className="text-sm text-slate-600 leading-relaxed">
              Discover flight inspiration across iconic cities, relaxing beaches and America’s great
              national parks.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {inspirationItems.map((item) => (
              <Link
                key={item.id}
                href={buildPrefilledSearchUrl(item)}
                title={item.airportDisclosure}
                className="group relative aspect-[16/10] rounded-2xl overflow-hidden shadow-sm border border-slate-200 block focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#16C2AF]"
              >
                <Image
                  src={AIRUNION_MEDIA[item.imageKey]}
                  alt={item.title}
                  fill
                  referrerPolicy="no-referrer"
                  className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                />
                <div
                  aria-hidden="true"
                  className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/25 to-transparent"
                />
                <div className="absolute inset-x-0 bottom-0 p-4 flex items-center justify-between gap-2 text-white">
                  <div>
                    <h3 className="font-display text-base sm:text-[17px] font-bold leading-snug">
                      {item.title}
                    </h3>
                    <p className="text-[11px] text-slate-200 mt-0.5 line-clamp-1">
                      Flights to {item.destinationLabel}
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 shrink-0 text-white group-hover:translate-x-0.5 transition-transform" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
