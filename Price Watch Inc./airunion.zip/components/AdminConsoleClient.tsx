'use client';

import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Database,
  Download,
  Lock,
  Play,
  RefreshCw,
  Shield,
  Upload,
} from 'lucide-react';
import type { DestinationItem } from '@/lib/data/destinations';
import type { LocationOption, ProviderHealthState } from '@/lib/domain/types';
import { useAuth } from './AuthProvider';

interface AdminSnapshot {
  providerConfigs: {
    providerId: string;
    providerName: string;
    healthState: ProviderHealthState;
    rateLimitPerMinute: number;
    credentialEnvKeys: string[];
    envConfigured: boolean;
    commercialAccessNote: string;
    updatedAt: string;
  }[];
  failedSearches: {
    id: string;
    reason: string;
    providersInvolved: string[];
    createdAt: string;
  }[];
  mappingErrors: {
    id: string;
    providerId: string;
    rawCode: string;
    message: string;
    resolved: boolean;
    createdAt: string;
  }[];
  airports: LocationOption[];
  destinations: DestinationItem[];
  alertRunLogs: {
    id: string;
    alertId: string;
    checkedAt: string;
    outcome: string;
    observedPrice: string | null;
    message: string;
  }[];
  priceAlertsCount: number;
  auditLogs: {
    id: string;
    actorId: string;
    actorRole: string;
    action: string;
    target: string;
    detail: string;
    createdAt: string;
  }[];
  cacheSize: number;
}

export function AdminConsoleClient() {
  const { user, setSession, authFetch } = useAuth();
  const [adminStatus, setAdminStatus] = useState<{
    configuredInEnv: boolean;
    claimed: boolean;
  } | null>(null);
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  const [data, setData] = useState<AdminSnapshot | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Add airport form
  const [newCode, setNewCode] = useState('');
  const [newName, setNewName] = useState('');
  const [newCity, setNewCity] = useState('');
  const [newTz, setNewTz] = useState('America/Denver');

  // Restore snapshot JSON text
  const [restoreJson, setRestoreJson] = useState('');

  useEffect(() => {
    fetch('/api/auth')
      .then((r) => r.json())
      .then((d: { adminStatus?: { configuredInEnv: boolean; claimed: boolean } }) => {
        if (d.adminStatus) setAdminStatus(d.adminStatus);
      })
      .catch(() => {});
  }, []);

  const loadAdminData = useCallback(async () => {
    if (user?.role !== 'admin') return;
    const res = await authFetch('/api/admin');
    if (res.ok) {
      const json = (await res.json()) as AdminSnapshot;
      setData(json);
    }
  }, [user, authFetch]);

  useEffect(() => {
    if (user?.role !== 'admin') return;
    let cancelled = false;
    authFetch('/api/admin')
      .then(async (res) => {
        if (!res.ok) return;
        const json = (await res.json()) as AdminSnapshot;
        if (!cancelled) setData(json);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [user, authFetch]);

  async function handleAdminAuth(e: React.FormEvent) {
    e.preventDefault();
    setAuthError(null);
    setBusy(true);
    try {
      const action = adminStatus?.claimed ? 'admin_login' : 'admin_claim';
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action, passcode }),
      });
      const json = (await res.json()) as {
        token?: string;
        user?: { userId: string; email: string; name: string; role: 'admin'; createdAt: string };
        error?: string;
      };
      if (!res.ok || !json.token || !json.user) {
        setAuthError(json.error ?? 'Admin authentication failed.');
      } else {
        setSession(json.token, json.user);
        setPasscode('');
      }
    } finally {
      setBusy(false);
    }
  }

  async function postAdminAction(payload: Record<string, unknown>, message: string) {
    setFeedback(null);
    const res = await authFetch('/api/admin', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      setFeedback(message);
      await loadAdminData();
    } else {
      const err = (await res.json()) as { error?: string };
      setFeedback(err.error ?? 'Action failed.');
    }
  }

  async function handleExportBackup() {
    const res = await authFetch('/api/admin', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ action: 'export_backup' }),
    });
    if (res.ok) {
      const json = await res.json();
      setRestoreJson(JSON.stringify(json.snapshot, null, 2));
      setFeedback('Exported sanitized store snapshot below.');
    }
  }

  async function handleRestoreBackup() {
    try {
      const parsed = JSON.parse(restoreJson) as Record<string, unknown>;
      await postAdminAction(
        { action: 'restore_backup', snapshot: parsed },
        'Configuration snapshot restored and search cache cleared.'
      );
    } catch {
      setFeedback('Invalid JSON snapshot syntax.');
    }
  }

  if (user?.role !== 'admin') {
    return (
      <div className="bg-[#F4F7FA] min-h-[75vh] py-14">
        <div className="max-w-md mx-auto px-4 sm:px-6">
          <form
            onSubmit={handleAdminAuth}
            className="bg-white rounded-2xl border border-slate-200 shadow-sm p-7 space-y-4"
          >
            <div className="flex items-center gap-2.5 text-[#0D2038]">
              <Shield className="w-6 h-6 text-[#EB5E47]" />
              <h1 className="font-display text-xl font-bold">
                {adminStatus?.claimed
                  ? 'Administrator sign in'
                  : 'First-run administrator setup'}
              </h1>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              {adminStatus?.claimed
                ? 'Enter your configured administrator passcode to access provider outage controls, airport records, alert jobs, and audit logs.'
                : 'No ADMIN_PASSCODE environment secret is set yet. Choose an administrator passcode (min 8 chars) to lock and claim admin access.'}
            </p>

            {authError && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-800">
                {authError}
              </div>
            )}

            <div>
              <label htmlFor="admin-pass" className="block text-xs font-semibold text-slate-700 mb-1">
                Administrator passcode
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-pass"
                  type="password"
                  required
                  minLength={8}
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  placeholder="Minimum 8 characters"
                  className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={busy}
              className="w-full py-2.5 rounded-xl bg-[#0D2038] text-white text-sm font-bold cursor-pointer"
            >
              {busy
                ? 'Verifying...'
                : adminStatus?.claimed
                ? 'Unlock Admin Console'
                : 'Claim & Unlock Admin Console'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#F4F7FA] min-h-screen pb-16">
      <div className="bg-[#0D2038] text-white py-8 border-b border-white/10">
        <div className="max-w-[1220px] mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold">
              Operations & administration console
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              Provider health simulation, alert worker, airport provenance, failed searches, and backup/restore.
            </p>
          </div>
          <button
            type="button"
            onClick={() => void loadAdminData()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-white/25 text-xs font-semibold cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 pt-6 space-y-6">
        {feedback && (
          <div className="px-4 py-3 rounded-xl bg-teal-50 border border-teal-200 text-sm text-teal-900">
            {feedback}
          </div>
        )}

        {data && (
          <>
            {/* Provider Health & Outage Controls */}
            <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-bold text-[#0D2038] flex items-center gap-2">
                  <Activity className="w-5 h-5 text-[#EB5E47]" />
                  <span>Flight provider adapters</span>
                </h2>
                <span className="text-xs text-slate-500 tabular-nums">
                  Bounded search cache entries: {data.cacheSize}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {data.providerConfigs.map((cfg) => (
                  <div key={cfg.providerId} className="p-4 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-[#0D2038]">{cfg.providerName}</h3>
                        <p className="text-xs font-mono text-slate-500">{cfg.providerId}</p>
                      </div>
                      <span
                        className={`text-xs font-bold uppercase ${
                          cfg.healthState === 'healthy'
                            ? 'text-emerald-700'
                            : cfg.healthState === 'degraded'
                            ? 'text-amber-700'
                            : 'text-rose-700'
                        }`}
                      >
                        {cfg.healthState}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600">{cfg.commercialAccessNote}</p>
                    <p className="text-[11px] text-slate-500 font-mono">
                      Required server env vars: {cfg.credentialEnvKeys.join(', ')} (
                      {cfg.envConfigured ? 'configured' : 'fixture mode'})
                    </p>

                    <div className="flex flex-wrap gap-2 pt-1">
                      {(['healthy', 'degraded', 'outage'] as ProviderHealthState[]).map((state) => (
                        <button
                          key={state}
                          type="button"
                          onClick={() =>
                            void postAdminAction(
                              {
                                action: 'set_provider_health',
                                providerId: cfg.providerId,
                                healthState: state,
                              },
                              `${cfg.providerName} set to ${state} (search cache cleared).`
                            )
                          }
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize cursor-pointer ${
                            cfg.healthState === state
                              ? 'bg-[#0D2038] text-white'
                              : 'border border-slate-300 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          Simulate {state}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Alert Worker & Failed Searches */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-lg font-bold text-[#0D2038]">
                    Price alert jobs ({data.priceAlertsCount} active/saved)
                  </h2>
                  <button
                    type="button"
                    onClick={() =>
                      void postAdminAction(
                        { action: 'run_all_alerts' },
                        'Executed periodic alert evaluation across all active alerts.'
                      )
                    }
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#16C2AF] text-[#0D2038] text-xs font-bold cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Run alert worker now</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-64 overflow-y-auto text-xs">
                  {data.alertRunLogs.map((log) => (
                    <div key={log.id} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
                      <p className="font-semibold text-slate-900">
                        {log.alertId} · {log.outcome}
                      </p>
                      <p className="text-slate-600">{log.message}</p>
                    </div>
                  ))}
                </div>
              </section>

              <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                <h2 className="font-display text-lg font-bold text-[#0D2038] flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>Failed searches & mapping errors</span>
                </h2>

                <div className="space-y-2 max-h-64 overflow-y-auto text-xs">
                  {data.mappingErrors.map((err) => (
                    <div
                      key={err.id}
                      className="p-2.5 rounded-lg border border-slate-200 flex items-start justify-between gap-2"
                    >
                      <div>
                        <p className="font-semibold text-slate-900">
                          {err.providerId} · Raw code <span className="font-mono">{err.rawCode}</span>
                        </p>
                        <p className="text-slate-600">{err.message}</p>
                      </div>
                      {err.resolved ? (
                        <span className="text-emerald-700 font-semibold">Resolved</span>
                      ) : (
                        <button
                          type="button"
                          onClick={() =>
                            void postAdminAction(
                              { action: 'resolve_mapping_error', errorId: err.id },
                              `Marked mapping error ${err.rawCode} resolved.`
                            )
                          }
                          className="px-2.5 py-1 rounded bg-[#0D2038] text-white font-semibold cursor-pointer shrink-0"
                        >
                          Resolve
                        </button>
                      )}
                    </div>
                  ))}

                  {data.failedSearches.map((fs) => (
                    <div key={fs.id} className="p-2.5 rounded-lg bg-rose-50 border border-rose-200">
                      <p className="font-semibold text-rose-900">
                        {fs.providersInvolved.join(', ')} · {new Date(fs.createdAt).toLocaleTimeString()}
                      </p>
                      <p className="text-rose-800">{fs.reason}</p>
                    </div>
                  ))}
                </div>
              </section>
            </div>

            {/* Airport Registry & Backup/Restore */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                <h2 className="font-display text-lg font-bold text-[#0D2038]">
                  Airport registry ({data.airports.length} records)
                </h2>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    void postAdminAction(
                      {
                        action: 'upsert_airport',
                        airport: {
                          code: newCode.toUpperCase(),
                          kind: 'airport',
                          name: newName,
                          city: newCity,
                          stateOrCountry: 'US',
                          countryCode: 'US',
                          timezone: newTz,
                          latitude: 39.0,
                          longitude: -104.0,
                          provenance: 'Admin manual registry entry',
                        },
                      },
                      `Upserted airport ${newCode.toUpperCase()}.`
                    );
                    setNewCode('');
                    setNewName('');
                    setNewCity('');
                  }}
                  className="grid grid-cols-2 gap-2 text-xs"
                >
                  <input
                    required
                    maxLength={3}
                    value={newCode}
                    onChange={(e) => setNewCode(e.target.value)}
                    placeholder="IATA (e.g. SLC)"
                    className="px-3 py-2 border border-slate-300 rounded-lg font-mono uppercase"
                  />
                  <input
                    required
                    value={newCity}
                    onChange={(e) => setNewCity(e.target.value)}
                    placeholder="City"
                    className="px-3 py-2 border border-slate-300 rounded-lg"
                  />
                  <input
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="Airport name"
                    className="px-3 py-2 border border-slate-300 rounded-lg"
                  />
                  <input
                    required
                    value={newTz}
                    onChange={(e) => setNewTz(e.target.value)}
                    placeholder="IANA timezone"
                    className="px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                  <button
                    type="submit"
                    className="col-span-2 py-2 rounded-lg bg-[#0D2038] text-white font-semibold cursor-pointer"
                  >
                    Add / update airport record
                  </button>
                </form>
                <div className="max-h-48 overflow-y-auto divide-y divide-slate-100 text-xs">
                  {data.airports.slice(0, 12).map((a) => (
                    <div key={a.code} className="py-2 flex items-center justify-between gap-2">
                      <span>
                        <strong className="font-mono">{a.code}</strong> · {a.name}
                      </span>
                      <span className="font-mono text-slate-500">{a.timezone}</span>
                    </div>
                  ))}
                </div>
              </section>

              <section className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                <h2 className="font-display text-lg font-bold text-[#0D2038] flex items-center gap-2">
                  <Database className="w-4 h-4 text-[#0E5952]" />
                  <span>Backup, restoration & audit log</span>
                </h2>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => void handleExportBackup()}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 text-xs font-semibold cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export snapshot</span>
                  </button>
                  <button
                    type="button"
                    disabled={!restoreJson.trim()}
                    onClick={() => void handleRestoreBackup()}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#0D2038] text-white text-xs font-semibold cursor-pointer disabled:opacity-50"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Restore snapshot</span>
                  </button>
                </div>
                <textarea
                  rows={4}
                  value={restoreJson}
                  onChange={(e) => setRestoreJson(e.target.value)}
                  placeholder="Exported JSON configuration snapshot appears here for backup or restoration..."
                  className="w-full p-2.5 text-[11px] font-mono border border-slate-300 rounded-lg"
                />
                <div className="max-h-36 overflow-y-auto divide-y divide-slate-100 text-[11px] text-slate-600">
                  {data.auditLogs.slice(0, 10).map((log) => (
                    <div key={log.id} className="py-1.5">
                      <span className="font-mono font-semibold text-slate-900">{log.action}</span> ·{' '}
                      {log.detail}
                    </div>
                  ))}
                </div>
              </section>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
