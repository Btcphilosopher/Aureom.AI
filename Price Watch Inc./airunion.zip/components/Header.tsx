'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ChevronDown, LogOut, Menu, Shield, User, X } from 'lucide-react';
import type { CurrencyCode } from '@/lib/domain/types';
import { useAuth } from './AuthProvider';

const CURRENCIES: { code: CurrencyCode; label: string }[] = [
  { code: 'USD', label: 'USD $' },
  { code: 'CAD', label: 'CAD $' },
  { code: 'EUR', label: 'EUR €' },
  { code: 'GBP', label: 'GBP £' },
];

export function Header() {
  const pathname = usePathname();
  const { user, currency, setCurrency, setAuthModalOpen, signOut } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const navLinks = [
    { href: '/', label: 'Flights', active: pathname === '/' || pathname.startsWith('/search') || pathname.startsWith('/offers') },
    { href: '/destinations', label: 'Destinations', active: pathname.startsWith('/destinations') },
    { href: '/my-trips', label: 'My trips', active: pathname.startsWith('/my-trips') },
    { href: '/help', label: 'Help', active: pathname.startsWith('/help') },
  ];

  return (
    <header className="bg-[#0D2038] text-white border-b border-white/10">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
        {/* Zone 1: Brand Wing Emblem + lowercase airunion wordmark */}
        <div className="flex items-center gap-6 min-w-0">
          <Link
            href="/"
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#16C2AF] rounded"
            aria-label="airunion home"
          >
            <svg
              aria-hidden="true"
              width="34"
              height="20"
              viewBox="0 0 34 20"
              fill="none"
              className="shrink-0"
            >
              <path d="M1 3L31 6.5L27 9.8L6.5 6.8L1 3Z" fill="#EB5E47" />
              <path d="M5.5 8.5L26 11.2L22.5 14.3L10.2 12.1L5.5 8.5Z" fill="#EB5E47" />
              <path d="M11 13.8L22 15.6L19 18.5L14.5 17L11 13.8Z" fill="#EB5E47" />
            </svg>
            <span className="font-display text-[22px] font-bold tracking-tight text-white lowercase leading-none">
              airunion
            </span>
          </Link>

          <span className="hidden md:inline-block h-5 w-px bg-white/20 shrink-0" aria-hidden="true" />

          {/* Zone 2: Clean single-line navigation links */}
          <nav className="hidden md:flex items-center gap-7" aria-label="Primary navigation">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`relative py-1 text-[15px] font-medium whitespace-nowrap shrink-0 transition-colors focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#16C2AF] ${
                  link.active ? 'text-white' : 'text-slate-300 hover:text-white'
                }`}
              >
                {link.label}
                {link.active && (
                  <span
                    aria-hidden="true"
                    className="absolute left-0 right-0 -bottom-1.5 h-[3px] rounded-full bg-[#EB5E47]"
                  />
                )}
              </Link>
            ))}
          </nav>
        </div>

        {/* Zone 3: Currency selector + Sign in / Account */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="relative flex items-center">
            <label htmlFor="header-currency" className="sr-only">
              Display currency
            </label>
            <select
              id="header-currency"
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className="appearance-none bg-transparent text-sm font-medium text-white pl-2 pr-6 py-1.5 rounded-lg hover:bg-white/10 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#16C2AF]"
            >
              {CURRENCIES.map((c) => (
                <option key={c.code} value={c.code} className="bg-[#0D2038] text-white">
                  {c.label}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-300 pointer-events-none absolute right-1.5" />
          </div>

          {user ? (
            <div className="relative">
              <button
                type="button"
                onClick={() => setUserMenuOpen((prev) => !prev)}
                className="flex items-center gap-2 px-3.5 py-2 rounded-lg border border-white/25 bg-white/5 hover:bg-white/10 text-sm font-medium text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer"
              >
                <User className="w-4 h-4 text-[#16C2AF]" />
                <span className="max-w-[120px] truncate">{user.name}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-300" />
              </button>
              {userMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white text-slate-900 shadow-xl border border-slate-200 py-1.5 z-50">
                  <div className="px-3.5 py-2 border-b border-slate-100">
                    <p className="text-xs font-medium text-slate-500">Signed in as</p>
                    <p className="text-sm font-semibold truncate">{user.email}</p>
                  </div>
                  <Link
                    href="/my-trips"
                    onClick={() => setUserMenuOpen(false)}
                    className="flex items-center gap-2.5 px-3.5 py-2 text-sm hover:bg-slate-50"
                  >
                    <User className="w-4 h-4 text-slate-500" />
                    My trips & alerts
                  </Link>
                  <Link
                    href="/admin"
                    onClick={() => setUserMenuOpen(false)}
                    className="flex items-center gap-2.5 px-3.5 py-2 text-sm hover:bg-slate-50"
                  >
                    <Shield className="w-4 h-4 text-slate-500" />
                    Admin console
                  </Link>
                  <button
                    type="button"
                    onClick={() => {
                      signOut();
                      setUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-rose-700 hover:bg-rose-50 cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setAuthModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg border border-white/30 hover:bg-white/10 text-sm font-medium text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <User className="w-4 h-4 text-slate-200" />
              <span>Sign in</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            className="md:hidden p-2 rounded-lg hover:bg-white/10 text-white cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <nav className="md:hidden border-t border-white/10 px-4 py-3 space-y-1 bg-[#0A192D]" aria-label="Mobile navigation">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className={`block px-3 py-2.5 rounded-lg text-sm font-medium ${
                link.active ? 'bg-white/10 text-white' : 'text-slate-300 hover:bg-white/5'
              }`}
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/admin"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2.5 rounded-lg text-sm font-medium text-slate-300 hover:bg-white/5"
          >
            Admin console
          </Link>
        </nav>
      )}
    </header>
  );
}
