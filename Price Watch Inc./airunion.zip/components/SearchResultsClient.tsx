'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  Bookmark,
  CheckCircle2,
  Clock,
  Info,
  Luggage,
  Plane,
  RefreshCw,
  ShieldAlert,
  SlidersHorizontal,
} from 'lucide-react';
import { formatMoney } from '@/lib/domain/money';
import {
  formatDurationMinutes,
  getDefaultFutureDates,
  getLocalParts,
} from '@/lib/domain/timezone';
import type {
  BaggageRequirement,
  CabinClass,
  CurrencyCode,
  ItineraryGroup,
  Offer,
  SearchCriteria,
  SearchResponse,
  SeatPreference,
  SortMode,
} from '@/lib/domain/types';
import { useAuth } from './AuthProvider';
import { SearchForm } from './SearchForm';

function getWindowBucket(localIso: string): 'morning' | 'afternoon' | 'evening' {
  const hh = Number(localIso.slice(11, 13));
  if (hh >= 5 && hh < 12) return 'morning';
  if (hh >= 12 && hh < 18) return 'afternoon';
  return 'evening';
}

function inclusionLabel(status: string): string {
  if (status === 'included') return 'Included';
  if (status === 'paid_extra') return 'Paid extra';
  if (status === 'not_included') return 'Not permitted';
  return 'Unknown';
}

function seatLabel(status: string): string {
  switch (status) {
    case 'assigned_included':
      return 'Assigned seat included';
    case 'advance_selection_included':
      return 'Advance selection included';
    case 'advance_selection_paid':
      return 'Paid advance selection';
    case 'assigned_at_checkin':
      return 'Assigned at check-in';
    default:
      return 'Unknown seat terms';
  }
}

export function SearchResultsClient() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, currency, authFetch, setAuthModalOpen } = useAuth();
  const defaults = useMemo(() => getDefaultFutureDates(), []);

  const initialCriteria: SearchCriteria = useMemo(() => {
    const tripType = searchParams.get('tripType') === 'one_way' ? 'one_way' : 'round_trip';
    const originCode = (searchParams.get('origin') ?? 'NYC').toUpperCase();
    const destinationCode = (searchParams.get('dest') ?? 'LAX').toUpperCase();
    const departDate = searchParams.get('depart') ?? defaults.departDate;
    const returnDate =
      tripType === 'round_trip'
        ? searchParams.get('return') ?? defaults.returnDate
        : undefined;
    const adults = Math.max(1, Number(searchParams.get('adults') ?? 1));
    const children = Math.max(0, Number(searchParams.get('children') ?? 0));
    const infants = Math.max(0, Number(searchParams.get('infants') ?? 0));
    const cabin = (searchParams.get('cabin') ?? 'economy') as CabinClass;
    const requiredBaggage = (searchParams.get('bag') ?? 'carry_on') as BaggageRequirement;
    const seatPreference = (searchParams.get('seat') ?? 'any') as SeatPreference;
    const urlCurrency = (searchParams.get('currency') as CurrencyCode | null) ?? currency;

    return {
      tripType,
      originCode,
      destinationCode,
      includeNearbyOrigin: searchParams.get('nearbyOrigin') === '1',
      includeNearbyDestination: searchParams.get('nearbyDest') === '1',
      departDate,
      returnDate,
      passengers: { adults, children, infants },
      cabin,
      requiredBaggage,
      seatPreference,
      refundableOnly: searchParams.get('refundable') === '1',
      maxStops: null,
      currency: urlCurrency,
    };
  }, [searchParams, defaults, currency]);

  const [criteriaOverride, setCriteriaOverride] = useState<SearchCriteria | null>(null);
  const criteria = useMemo(
    () => criteriaOverride ?? initialCriteria,
    [criteriaOverride, initialCriteria]
  );
  const [data, setData] = useState<SearchResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters & sorting
  const [sortMode, setSortMode] = useState<SortMode>('recommended');
  const [stopsFilter, setStopsFilter] = useState<'any' | '0' | '1'>('any');
  const [depWindow, setDepWindow] = useState<'any' | 'morning' | 'afternoon' | 'evening'>('any');
  const [arrWindow, setArrWindow] = useState<'any' | 'morning' | 'afternoon' | 'evening'>('any');
  const [selectedAirlines, setSelectedAirlines] = useState<string[]>([]);
  const [selectedAirports, setSelectedAirports] = useState<string[]>([]);
  const [maxDurationHours, setMaxDurationHours] = useState<number>(36);
  const [excludeAirportChange, setExcludeAirportChange] = useState(false);
  const [excludeSelfTransfer, setExcludeSelfTransfer] = useState(false);
  const [excludeOvernight, setExcludeOvernight] = useState(false);
  const [showFormulaInfo, setShowFormulaInfo] = useState(false);
  const [showPerPerson, setShowPerPerson] = useState(true);

  // Save search / Price alert UI
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [alertModalOpen, setAlertModalOpen] = useState(false);
  const [alertTargetInput, setAlertTargetInput] = useState('365.00');
  const [alertFreq, setAlertFreq] = useState<'every_6_hours' | 'daily'>('every_6_hours');

  const executeSearch = useCallback(async (nextCriteria: SearchCriteria) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/flights/search', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(nextCriteria),
      });
      const json = (await res.json()) as SearchResponse & { error?: string };
      if (!res.ok) {
        setError(json.error ?? 'Search request failed.');
        setData(null);
      } else {
        setData(json);
      }
    } catch {
      setError('Unable to reach flight search service.');
      setData(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/flights/search', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(criteria),
    })
      .then(async (res) => {
        const json = (await res.json()) as SearchResponse & { error?: string };
        if (cancelled) return;
        if (!res.ok) {
          setError(json.error ?? 'Search request failed.');
          setData(null);
        } else {
          setError(null);
          setData(json);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setError('Unable to reach flight search service.');
          setData(null);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [criteria]);

  function updateCriteriaAndUrl(patch: Partial<SearchCriteria>) {
    const next = { ...criteria, ...patch };
    setCriteriaOverride(next);
    setLoading(true);
    const params = new URLSearchParams({
      tripType: next.tripType,
      origin: next.originCode,
      dest: next.destinationCode,
      nearbyOrigin: next.includeNearbyOrigin ? '1' : '0',
      nearbyDest: next.includeNearbyDestination ? '1' : '0',
      depart: next.departDate,
      adults: String(next.passengers.adults),
      children: String(next.passengers.children),
      infants: String(next.passengers.infants),
      cabin: next.cabin,
      bag: next.requiredBaggage,
      seat: next.seatPreference,
      refundable: next.refundableOnly ? '1' : '0',
      currency: next.currency,
    });
    if (next.returnDate) params.set('return', next.returnDate);
    router.replace(`/search?${params.toString()}`, { scroll: false });
  }

  // Extract available airlines & airports from returned groups
  const { availableAirlines, availableAirports } = useMemo(() => {
    const airlines = new Set<string>();
    const airports = new Set<string>();
    for (const g of data?.groups ?? []) {
      for (const b of g.journey.bounds) {
        airports.add(b.originAirport);
        airports.add(b.destinationAirport);
        for (const s of b.segments) {
          airlines.add(s.marketingCarrier.name);
        }
      }
    }
    return {
      availableAirlines: Array.from(airlines).sort(),
      availableAirports: Array.from(airports).sort(),
    };
  }, [data]);

  const filteredAndSortedGroups = useMemo(() => {
    if (!data) return [];
    const filtered = data.groups.filter((g) => {
      if (stopsFilter === '0' && g.journey.maxStops > 0) return false;
      if (stopsFilter === '1' && g.journey.maxStops > 1) return false;

      const outBound = g.journey.bounds[0];
      if (outBound) {
        const firstSeg = outBound.segments[0];
        const lastSeg = outBound.segments[outBound.segments.length - 1];
        if (depWindow !== 'any' && getWindowBucket(firstSeg.departureLocal) !== depWindow) {
          return false;
        }
        if (arrWindow !== 'any' && getWindowBucket(lastSeg.arrivalLocal) !== arrWindow) {
          return false;
        }
      }

      if (g.journey.totalDurationMinutes > maxDurationHours * 60) return false;
      if (excludeAirportChange && g.journey.bounds.some((b) => b.hasAirportChange)) return false;
      if (excludeSelfTransfer && g.journey.bounds.some((b) => b.hasSelfTransfer)) return false;
      if (excludeOvernight && g.journey.bounds.some((b) => b.hasOvernightArrival)) return false;

      if (selectedAirlines.length > 0) {
        const segAirlines = g.journey.bounds.flatMap((b) =>
          b.segments.map((s) => s.marketingCarrier.name)
        );
        if (!segAirlines.some((name) => selectedAirlines.includes(name))) return false;
      }

      if (selectedAirports.length > 0) {
        const boundAirports = g.journey.bounds.flatMap((b) => [
          b.originAirport,
          b.destinationAirport,
        ]);
        if (!boundAirports.some((code) => selectedAirports.includes(code))) return false;
      }

      return true;
    });

    const sorted = [...filtered].sort((a, b) => {
      if (sortMode === 'fastest') {
        return a.journey.totalDurationMinutes - b.journey.totalDurationMinutes;
      }
      if (sortMode === 'cheapest_base') {
        const aOffer = a.offers.find((o) => o.offerId === a.cheapestBaseOfferId) ?? a.bestOffer;
        const bOffer = b.offers.find((o) => o.offerId === b.cheapestBaseOfferId) ?? b.bestOffer;
        const aBase =
          aOffer.observation.baseFareTotal.minorUnits +
          aOffer.observation.taxesAndMandatoryTotal.minorUnits;
        const bBase =
          bOffer.observation.baseFareTotal.minorUnits +
          bOffer.observation.taxesAndMandatoryTotal.minorUnits;
        return aBase - bBase;
      }
      if (sortMode === 'cheapest_eligible') {
        const aElig = a.cheapestEligibleOfferId
          ? a.offers.find((o) => o.offerId === a.cheapestEligibleOfferId)
          : null;
        const bElig = b.cheapestEligibleOfferId
          ? b.offers.find((o) => o.offerId === b.cheapestEligibleOfferId)
          : null;
        if (aElig && !bElig) return -1;
        if (!aElig && bElig) return 1;
        if (aElig && bElig) {
          return (
            aElig.evaluation.comparableTotal.minorUnits -
            bElig.evaluation.comparableTotal.minorUnits
          );
        }
        return (
          a.bestOffer.evaluation.comparableTotal.minorUnits -
          b.bestOffer.evaluation.comparableTotal.minorUnits
        );
      }
      return a.bestOffer.recommendedScore - b.bestOffer.recommendedScore;
    });

    return sorted;
  }, [
    data,
    stopsFilter,
    depWindow,
    arrWindow,
    maxDurationHours,
    excludeAirportChange,
    excludeSelfTransfer,
    excludeOvernight,
    selectedAirlines,
    selectedAirports,
    sortMode,
  ]);

  async function handleSaveSearch() {
    if (!user) {
      setAuthModalOpen(true);
      return;
    }
    setSaveMessage(null);
    const res = await authFetch('/api/my-trips', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        kind: 'saved_search',
        label: `${criteria.originCode} → ${criteria.destinationCode} (${criteria.departDate}, ${criteria.requiredBaggage.replace('_', ' ')})`,
        criteria,
      }),
    });
    if (res.ok) {
      setSaveMessage('Search saved to My trips.');
    } else {
      const err = (await res.json()) as { error?: string };
      setSaveMessage(err.error ?? 'Could not save search.');
    }
  }

  async function handleCreateAlert(e: React.FormEvent) {
    e.preventDefault();
    if (!user) {
      setAuthModalOpen(true);
      return;
    }
    const res = await authFetch('/api/my-trips', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        kind: 'price_alert',
        label: `${criteria.originCode} → ${criteria.destinationCode} (${criteria.requiredBaggage.replace('_', ' ')})`,
        criteria,
        targetPriceAmount: alertTargetInput,
        currency: 'USD',
        checkFrequency: alertFreq,
      }),
    });
    if (res.ok) {
      setAlertModalOpen(false);
      setSaveMessage('Price alert created and initial periodic check recorded in My trips.');
    } else {
      const err = (await res.json()) as { error?: string };
      setSaveMessage(err.error ?? 'Could not create price alert.');
    }
  }

  const totalPax =
    criteria.passengers.adults + criteria.passengers.children + criteria.passengers.infants;

  return (
    <div className="bg-[#F4F7FA] min-h-screen pb-14">
      {/* Top Navy Search Header Bar */}
      <div className="bg-[#0D2038] pt-4 pb-6 border-b border-white/10">
        <div className="max-w-[1220px] mx-auto px-4 sm:px-6 space-y-4">
          <SearchForm
            compact
            initialCriteria={criteria}
            onSubmitSearch={(next) => updateCriteriaAndUrl(next)}
          />

          {/* Like-for-Like Requirement Controls */}
          <div className="bg-[#132945] border border-white/15 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-4 text-white text-xs sm:text-sm">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <Luggage className="w-4 h-4 text-[#16C2AF]" />
                <label htmlFor="req-bag" className="font-medium text-slate-200 whitespace-nowrap">
                  Required baggage:
                </label>
                <select
                  id="req-bag"
                  value={criteria.requiredBaggage}
                  onChange={(e) =>
                    updateCriteriaAndUrl({
                      requiredBaggage: e.target.value as BaggageRequirement,
                    })
                  }
                  className="bg-[#0D2038] border border-white/25 rounded-lg px-2.5 py-1.5 text-xs sm:text-sm text-white font-semibold cursor-pointer"
                >
                  <option value="personal_only">Personal item only</option>
                  <option value="carry_on">Carry-on bag</option>
                  <option value="checked_1">1st Checked bag (50 lb)</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <label htmlFor="req-seat" className="font-medium text-slate-200 whitespace-nowrap">
                  Seat preference:
                </label>
                <select
                  id="req-seat"
                  value={criteria.seatPreference}
                  onChange={(e) =>
                    updateCriteriaAndUrl({
                      seatPreference: e.target.value as SeatPreference,
                    })
                  }
                  className="bg-[#0D2038] border border-white/25 rounded-lg px-2.5 py-1.5 text-xs sm:text-sm text-white font-semibold cursor-pointer"
                >
                  <option value="any">Any seat</option>
                  <option value="advance_selection">Advance seat selection</option>
                  <option value="assigned_included">Assigned seat included</option>
                </select>
              </div>

              <label className="flex items-center gap-2 cursor-pointer whitespace-nowrap">
                <input
                  type="checkbox"
                  checked={criteria.refundableOnly}
                  onChange={(e) => updateCriteriaAndUrl({ refundableOnly: e.target.checked })}
                  className="rounded border-white/30"
                />
                <span className="text-slate-200 font-medium">Refundable only</span>
              </label>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() => void handleSaveSearch()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/25 hover:bg-white/10 text-xs font-semibold whitespace-nowrap cursor-pointer"
              >
                <Bookmark className="w-3.5 h-3.5 text-[#16C2AF]" />
                <span>Save search</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!user) {
                    setAuthModalOpen(true);
                  } else {
                    setAlertModalOpen(true);
                  }
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#EB5E47] hover:bg-[#D9503A] text-white text-xs font-semibold whitespace-nowrap cursor-pointer"
              >
                <Bell className="w-3.5 h-3.5" />
                <span>Create price alert</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 pt-6">
        {saveMessage && (
          <div className="mb-4 px-4 py-3 rounded-xl bg-teal-50 border border-teal-200 text-sm text-teal-900 flex items-center justify-between">
            <span>{saveMessage}</span>
            <Link href="/my-trips" className="font-semibold underline hover:text-teal-700">
              Open My trips →
            </Link>
          </div>
        )}

        {/* Provider Coverage & Outage Status */}
        {data && (
          <div className="mb-5 bg-white rounded-xl border border-slate-200 p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
                <span className="font-semibold text-slate-900">Provider coverage:</span>
                {data.providers.map((p) => (
                  <span key={p.providerId} className="inline-flex items-center gap-1.5">
                    {p.status === 'ok' ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    )}
                    <span className="font-medium text-slate-800">{p.providerName}</span>
                    <span className="text-slate-500">
                      ({p.status === 'ok' ? `${p.offerCount} offers · ${p.latencyMs}ms` : p.status})
                    </span>
                  </span>
                ))}
              </div>
              <div className="text-xs text-slate-500 tabular-nums">
                {data.summary.totalUniqueItineraries} unique itineraries · {data.summary.totalOffers} seller offers
                {data.cacheHit ? ' · cached snapshot' : ''}
              </div>
            </div>

            {data.statusBanner && (
              <div
                role="status"
                className={`mt-3 px-3.5 py-2.5 rounded-lg text-xs sm:text-sm flex items-start gap-2.5 ${
                  data.searchStatus === 'failed'
                    ? 'bg-rose-50 border border-rose-200 text-rose-900'
                    : 'bg-amber-50 border border-amber-200 text-amber-950'
                }`}
              >
                <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{data.statusBanner}</span>
              </div>
            )}
          </div>
        )}

        {/* Summary Comparison Strip */}
        {data && data.summary.totalOffers > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white rounded-xl border border-slate-200 p-4">
              <p className="text-xs font-medium text-slate-500">Cheapest eligible total</p>
              <p className="text-xl font-bold text-[#0D2038] tabular-nums mt-1">
                {data.summary.cheapestEligibleTotal
                  ? formatMoney(data.summary.cheapestEligibleTotal)
                  : 'None meeting criteria'}
              </p>
              <p className="text-xs text-slate-600 mt-1">
                Includes {criteria.requiredBaggage.replace('_', ' ')} &{' '}
                {criteria.seatPreference.replace('_', ' ')} for {totalPax} traveler(s).
              </p>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-4">
              <p className="text-xs font-medium text-slate-500">Cheapest base fare</p>
              <p className="text-xl font-bold text-slate-900 tabular-nums mt-1">
                {data.summary.cheapestBaseTotal
                  ? formatMoney(data.summary.cheapestBaseTotal)
                  : '—'}
              </p>
              <p className="text-xs text-slate-600 mt-1">
                {data.summary.cheapestEligibleOfferId &&
                data.summary.cheapestBaseOfferId !== data.summary.cheapestEligibleOfferId
                  ? 'Excludes required extras or fails criteria — compare comparable total before selecting.'
                  : 'Matches your baseline search criteria.'}
              </p>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-4">
              <p className="text-xs font-medium text-slate-500">Fastest itinerary</p>
              <p className="text-xl font-bold text-slate-900 tabular-nums mt-1">
                {data.summary.fastestDurationMinutes
                  ? formatDurationMinutes(data.summary.fastestDurationMinutes)
                  : '—'}
              </p>
              <p className="text-xs text-slate-600 mt-1">
                Calculated from absolute UTC departure and arrival timestamps.
              </p>
            </div>
          </div>
        )}

        {/* Main 2-column Filters + Results */}
        <div className="grid grid-cols-1 lg:grid-cols-[270px_1fr] gap-6 items-start">
          {/* Filters Sidebar */}
          <aside className="bg-white rounded-xl border border-slate-200 p-5 space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-bold text-[#0D2038] flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-[#EB5E47]" />
                <span>Filter results</span>
              </h2>
              <button
                type="button"
                onClick={() => {
                  setStopsFilter('any');
                  setDepWindow('any');
                  setArrWindow('any');
                  setSelectedAirlines([]);
                  setSelectedAirports([]);
                  setMaxDurationHours(36);
                  setExcludeAirportChange(false);
                  setExcludeSelfTransfer(false);
                  setExcludeOvernight(false);
                }}
                className="text-xs font-medium text-[#0E5952] hover:underline cursor-pointer"
              >
                Reset
              </button>
            </div>

            {/* Stops */}
            <div>
              <p className="text-xs font-semibold text-slate-800 mb-2">Stops</p>
              <div className="space-y-1.5 text-xs text-slate-700">
                {[
                  { val: 'any' as const, label: 'Any number of stops' },
                  { val: '0' as const, label: 'Nonstop only' },
                  { val: '1' as const, label: '1 stop or fewer' },
                ].map((opt) => (
                  <label key={opt.val} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="stopsFilter"
                      checked={stopsFilter === opt.val}
                      onChange={() => setStopsFilter(opt.val)}
                    />
                    <span>{opt.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Connection integrity */}
            <div className="pt-3 border-t border-slate-100">
              <p className="text-xs font-semibold text-slate-800 mb-2">Connection integrity</p>
              <div className="space-y-2 text-xs text-slate-700">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={excludeSelfTransfer}
                    onChange={(e) => setExcludeSelfTransfer(e.target.checked)}
                  />
                  <span>Hide self-transfer separate tickets</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={excludeAirportChange}
                    onChange={(e) => setExcludeAirportChange(e.target.checked)}
                  />
                  <span>Hide airport-change connections</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={excludeOvernight}
                    onChange={(e) => setExcludeOvernight(e.target.checked)}
                  />
                  <span>Hide overnight arrivals (+1d)</span>
                </label>
              </div>
            </div>

            {/* Departure & Arrival Time Windows */}
            <div className="pt-3 border-t border-slate-100 space-y-3">
              <div>
                <label htmlFor="dep-win" className="block text-xs font-semibold text-slate-800 mb-1">
                  Outbound departure window
                </label>
                <select
                  id="dep-win"
                  value={depWindow}
                  onChange={(e) => setDepWindow(e.target.value as typeof depWindow)}
                  className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs"
                >
                  <option value="any">Any time</option>
                  <option value="morning">Morning (05:00–11:59)</option>
                  <option value="afternoon">Afternoon (12:00–17:59)</option>
                  <option value="evening">Evening / Red-eye (18:00–04:59)</option>
                </select>
              </div>

              <div>
                <label htmlFor="arr-win" className="block text-xs font-semibold text-slate-800 mb-1">
                  Outbound arrival window
                </label>
                <select
                  id="arr-win"
                  value={arrWindow}
                  onChange={(e) => setArrWindow(e.target.value as typeof arrWindow)}
                  className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs"
                >
                  <option value="any">Any time</option>
                  <option value="morning">Morning (05:00–11:59)</option>
                  <option value="afternoon">Afternoon (12:00–17:59)</option>
                  <option value="evening">Evening (18:00–04:59)</option>
                </select>
              </div>
            </div>

            {/* Max Duration */}
            <div className="pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-slate-800">Max total trip time</span>
                <span className="font-mono text-slate-600 tabular-nums">{maxDurationHours}h</span>
              </div>
              <input
                type="range"
                min={4}
                max={36}
                value={maxDurationHours}
                onChange={(e) => setMaxDurationHours(Number(e.target.value))}
                className="w-full accent-[#16C2AF]"
              />
            </div>

            {/* Airlines */}
            {availableAirlines.length > 0 && (
              <div className="pt-3 border-t border-slate-100">
                <p className="text-xs font-semibold text-slate-800 mb-2">Airlines</p>
                <div className="space-y-1.5 text-xs text-slate-700">
                  {availableAirlines.map((name) => (
                    <label key={name} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedAirlines.includes(name)}
                        onChange={(e) => {
                          setSelectedAirlines((prev) =>
                            e.target.checked ? [...prev, name] : prev.filter((x) => x !== name)
                          );
                        }}
                      />
                      <span>{name}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Airports */}
            {availableAirports.length > 0 && (
              <div className="pt-3 border-t border-slate-100">
                <p className="text-xs font-semibold text-slate-800 mb-2">Airports</p>
                <div className="flex flex-wrap gap-2">
                  {availableAirports.map((code) => {
                    const active = selectedAirports.includes(code);
                    return (
                      <button
                        key={code}
                        type="button"
                        onClick={() =>
                          setSelectedAirports((prev) =>
                            active ? prev.filter((x) => x !== code) : [...prev, code]
                          )
                        }
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold border cursor-pointer ${
                          active
                            ? 'bg-[#0D2038] text-white border-[#0D2038]'
                            : 'bg-white text-slate-700 border-slate-200 hover:border-slate-400'
                        }`}
                      >
                        {code}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </aside>

          {/* Results Column */}
          <div className="space-y-4">
            {/* Sort Toolbar */}
            <div className="bg-white rounded-xl border border-slate-200 p-3.5 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1.5">
                {[
                  { key: 'recommended' as const, label: 'Recommended' },
                  { key: 'cheapest_eligible' as const, label: 'Cheapest eligible' },
                  { key: 'cheapest_base' as const, label: 'Cheapest base' },
                  { key: 'fastest' as const, label: 'Fastest' },
                ].map((tab) => (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => setSortMode(tab.key)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer transition-colors ${
                      sortMode === tab.key
                        ? 'bg-[#0D2038] text-white'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setShowFormulaInfo((p) => !p)}
                  className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-slate-800 ml-1 cursor-pointer"
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>Ranking formula</span>
                </button>
              </div>

              <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showPerPerson}
                  onChange={(e) => setShowPerPerson(e.target.checked)}
                />
                <span>Show per-person average</span>
              </label>
            </div>

            {showFormulaInfo && data && (
              <div className="bg-white rounded-xl border border-slate-200 px-4 py-3 text-xs text-slate-700">
                <strong>Recommended ranking:</strong> {data.summary.rankingFormulaExplanation}
              </div>
            )}

            {/* Loading / Error / Empty States */}
            {loading && (
              <div className="space-y-4">
                {[1, 2, 3].map((idx) => (
                  <div
                    key={idx}
                    className="bg-white rounded-xl border border-slate-200 p-6 animate-pulse space-y-3"
                  >
                    <div className="h-5 bg-slate-200 rounded w-1/3" />
                    <div className="h-12 bg-slate-100 rounded w-full" />
                  </div>
                ))}
              </div>
            )}

            {!loading && error && (
              <div className="bg-white rounded-xl border border-rose-200 p-6 text-sm text-rose-800">
                {error}
              </div>
            )}

            {!loading && !error && data?.searchStatus === 'failed' && (
              <div className="bg-white rounded-xl border border-rose-200 p-8 text-center space-y-3">
                <ShieldAlert className="w-8 h-8 text-rose-600 mx-auto" />
                <h3 className="font-display text-lg font-bold text-slate-900">
                  Search could not complete
                </h3>
                <p className="text-sm text-slate-600 max-w-lg mx-auto">
                  {data.statusBanner}
                </p>
                <button
                  type="button"
                  onClick={() => void executeSearch(criteria)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#0D2038] text-white text-xs font-semibold cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retry search</span>
                </button>
              </div>
            )}

            {!loading &&
              !error &&
              data &&
              data.searchStatus !== 'failed' &&
              filteredAndSortedGroups.length === 0 && (
                <div className="bg-white rounded-xl border border-slate-200 p-8 text-center space-y-2">
                  <Plane className="w-7 h-7 text-slate-400 mx-auto" />
                  <h3 className="font-display text-lg font-bold text-slate-900">
                    No matching itineraries
                  </h3>
                  <p className="text-sm text-slate-600">
                    {data.groups.length > 0
                      ? 'Your active sidebar filters excluded all returned flights. Reset filters to view all itineraries.'
                      : 'All providers responded cleanly, with zero matching flights for this route.'}
                  </p>
                </div>
              )}

            {/* Itinerary Group Cards */}
            {!loading &&
              !error &&
              data &&
              filteredAndSortedGroups.map((group) => (
                <ItineraryGroupCard
                  key={group.canonicalKey}
                  group={group}
                  totalPax={totalPax}
                  showPerPerson={showPerPerson}
                  searchedAt={data.searchedAt}
                />
              ))}
          </div>
        </div>
      </div>

      {/* Price Alert Modal */}
      {alertModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleCreateAlert}
            className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-md p-6 space-y-4"
          >
            <h3 className="font-display text-lg font-bold text-[#0D2038]">
              Create like-for-like price alert
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              This alert preserves your exact comparison requirements:{' '}
              <strong>
                {criteria.originCode} → {criteria.destinationCode}
              </strong>
              , {criteria.cabin.replace('_', ' ')},{' '}
              <strong>{criteria.requiredBaggage.replace('_', ' ')}</strong>, and{' '}
              {totalPax} traveler(s). Fares missing required baggage will NOT trigger this alert.
            </p>
            <div>
              <label htmlFor="alert-target" className="block text-xs font-semibold text-slate-700 mb-1">
                Target comparable total (USD)
              </label>
              <input
                id="alert-target"
                type="text"
                required
                pattern="^\d+(\.\d{1,2})?$"
                value={alertTargetInput}
                onChange={(e) => setAlertTargetInput(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg font-mono"
              />
            </div>
            <div>
              <label htmlFor="alert-freq" className="block text-xs font-semibold text-slate-700 mb-1">
                Periodic check schedule
              </label>
              <select
                id="alert-freq"
                value={alertFreq}
                onChange={(e) => setAlertFreq(e.target.value as 'every_6_hours' | 'daily')}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              >
                <option value="every_6_hours">Periodic check every 6 hours</option>
                <option value="daily">Daily periodic check</option>
              </select>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setAlertModalOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-[#16C2AF] text-[#0D2038] text-xs font-bold cursor-pointer"
              >
                Save alert
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

function ItineraryGroupCard({
  group,
  totalPax,
  showPerPerson,
  searchedAt,
}: {
  group: ItineraryGroup;
  totalPax: number;
  showPerPerson: boolean;
  searchedAt: string;
}) {
  const [expanded, setExpanded] = useState(group.offers.length > 1);

  return (
    <article className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      {/* Flight Bounds Header */}
      <div className="p-5 border-b border-slate-100">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3 text-xs text-slate-600">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-semibold text-[#0D2038]">
              {group.journey.bounds[0]?.segments[0]?.marketingCarrier.name}
            </span>
            <span aria-hidden="true">·</span>
            <span>
              {group.offers.length > 1
                ? `${group.offers.length} grouped offers for this identical itinerary`
                : '1 offer available'}
            </span>
          </div>
          {group.journey.bounds.some((b) => b.hasMixedCabins) && (
            <span className="text-amber-800 font-semibold">Mixed cabin itinerary</span>
          )}
        </div>

        <div className="space-y-4">
          {group.journey.bounds.map((bound) => {
            const first = bound.segments[0];
            const last = bound.segments[bound.segments.length - 1];
            const depLocal = getLocalParts(first.departureUtc, first.originTimezone);
            const arrLocal = getLocalParts(last.arrivalUtc, last.destinationTimezone);
            const operatingSet = Array.from(
              new Set(
                bound.segments.map((s) =>
                  s.operatingCarrier.name !== s.marketingCarrier.name
                    ? `${s.flightNumber} operated by ${s.operatingCarrier.name}`
                    : `${s.flightNumber} (${s.operatingCarrier.name})`
                )
              )
            );

            return (
              <div
                key={bound.boundId}
                className="grid grid-cols-1 sm:grid-cols-[90px_1fr_auto] gap-3 items-center"
              >
                <div className="text-xs text-slate-500">
                  <p className="font-semibold text-slate-700 capitalize">{bound.direction}</p>
                  <p>{depLocal.displayDate}</p>
                </div>

                <div className="flex items-center gap-4">
                  <div>
                    <p className="text-lg font-bold text-[#0D2038] tabular-nums">
                      {depLocal.displayTime}
                    </p>
                    <p className="text-xs font-mono text-slate-600">
                      {first.originAirport}
                      {first.originTerminal ? ` T${first.originTerminal}` : ''} · {depLocal.shortOffset}
                    </p>
                  </div>

                  <div className="flex-1 min-w-[110px] text-center">
                    <p className="text-xs font-medium text-slate-600 tabular-nums">
                      {formatDurationMinutes(bound.totalDurationMinutes)}
                    </p>
                    <div className="relative my-1.5 border-t border-slate-300" />
                    <p className="text-[11px] text-slate-500">
                      {bound.stops === 0
                        ? 'Nonstop'
                        : `${bound.stops} stop · ${bound.connections
                            .map((c) => `${c.atAirport} ${formatDurationMinutes(c.durationMinutes)}`)
                            .join(', ')}`}
                    </p>
                  </div>

                  <div>
                    <p className="text-lg font-bold text-[#0D2038] tabular-nums">
                      {arrLocal.displayTime}
                      {last.dayOffsetFromDeparture > 0 && (
                        <sup className="ml-1 text-[11px] font-bold text-[#EB5E47]">
                          +{last.dayOffsetFromDeparture}d
                        </sup>
                      )}
                    </p>
                    <p className="text-xs font-mono text-slate-600">
                      {last.destinationAirport}
                      {last.destinationTerminal ? ` T${last.destinationTerminal}` : ''} · {arrLocal.shortOffset}
                    </p>
                  </div>
                </div>

                <div className="text-xs text-slate-500 sm:text-right space-y-0.5">
                  <p>{operatingSet.join(' · ')}</p>
                  {bound.hasMixedCabins && (
                    <p className="text-amber-800 font-medium">
                      Cabins: {bound.segments.map((s) => `${s.originAirport}→${s.destinationAirport} (${s.cabin})`).join(', ')}
                    </p>
                  )}
                  {bound.hasSelfTransfer && (
                    <p className="text-rose-700 font-semibold">
                      Self-transfer (separate tickets, unprotected)
                    </p>
                  )}
                  {bound.hasAirportChange && (
                    <p className="text-amber-800 font-semibold">Airport change required</p>
                  )}
                  {last.crossesDateLine && (
                    <p className="text-slate-700 font-medium">Crosses International Date Line</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grouped Seller Offers Table */}
      <div className="divide-y divide-slate-100 bg-slate-50/50">
        {(expanded ? group.offers : [group.bestOffer]).map((offer) => (
          <SellerOfferRow
            key={offer.offerId}
            offer={offer}
            totalPax={totalPax}
            showPerPerson={showPerPerson}
            searchedAt={searchedAt}
          />
        ))}
      </div>

      {group.offers.length > 1 && (
        <div className="px-5 py-2.5 bg-slate-50 border-t border-slate-100 flex justify-between items-center text-xs">
          <span className="text-slate-500">
            Same itinerary compared across {group.offers.length} seller offers
          </span>
          <button
            type="button"
            onClick={() => setExpanded((p) => !p)}
            className="font-semibold text-[#0E5952] hover:underline cursor-pointer"
          >
            {expanded ? 'Collapse offers' : `Show all ${group.offers.length} offers`}
          </button>
        </div>
      )}
    </article>
  );
}

function SellerOfferRow({
  offer,
  totalPax,
  showPerPerson,
  searchedAt,
}: {
  offer: Offer;
  totalPax: number;
  showPerPerson: boolean;
  searchedAt: string;
}) {
  const firstBag = offer.fareProduct.baggagePerSegment[0];
  const expiryMinutes = Math.round(
    (Date.parse(offer.observation.expiresAt) - Date.parse(searchedAt)) / 60000
  );

  return (
    <div className="px-5 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div className="space-y-1.5 min-w-0">
        <div className="flex flex-wrap items-center gap-2 text-sm">
          <span className="font-bold text-[#0D2038]">{offer.seller.name}</span>
          <span className="text-slate-400">·</span>
          <span className="font-medium text-slate-700">{offer.fareProduct.fareFamilyName}</span>
          <span className="text-slate-400">·</span>
          <span className="text-xs text-slate-500">via {offer.observation.providerName}</span>
        </div>

        {/* Baggage & Seat & Refund summary */}
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
          <span>
            Personal item: <strong>{inclusionLabel(firstBag?.personalItem.status ?? 'unknown')}</strong>
          </span>
          <span>
            Carry-on: <strong>{inclusionLabel(firstBag?.carryOn.status ?? 'unknown')}</strong>
          </span>
          <span>
            1st Checked: <strong>{inclusionLabel(firstBag?.checkedBag.status ?? 'unknown')}</strong>
          </span>
          <span>
            Seats: <strong>{seatLabel(offer.fareProduct.conditions.seatAssignment.status)}</strong>
          </span>
          <span>
            Refund: <strong>{inclusionLabel(offer.fareProduct.conditions.refundAllowed)}</strong>
          </span>
        </div>

        {/* Eligibility / Incomplete / Freshness status */}
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
          {offer.evaluation.eligibility === 'eligible' && (
            <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Meets selected requirements
            </span>
          )}
          {offer.evaluation.eligibility === 'incomplete' && (
            <span className="inline-flex items-center gap-1 text-amber-800 font-semibold">
              <AlertTriangle className="w-3.5 h-3.5" />
              Incomplete comparison: {offer.evaluation.reasons[0] ?? 'missing fare terms'}
            </span>
          )}
          {offer.evaluation.eligibility === 'ineligible' && (
            <span className="inline-flex items-center gap-1 text-rose-700 font-semibold">
              <ShieldAlert className="w-3.5 h-3.5" />
              Does not meet requirements: {offer.evaluation.reasons[0]}
            </span>
          )}

          <span className="text-slate-400">·</span>
          <span className="inline-flex items-center gap-1 text-slate-500 tabular-nums">
            <Clock className="w-3 h-3" />
            {offer.isExpired || expiryMinutes <= 0
              ? 'Snapshot expired (revalidation required)'
              : `Valid ~${expiryMinutes}m`}
          </span>
        </div>
      </div>

      {/* Price & Action */}
      <div className="flex items-center justify-between md:justify-end gap-5 shrink-0">
        <div className="md:text-right">
          <div className="text-xl font-bold text-[#0D2038] tabular-nums">
            {formatMoney(offer.evaluation.comparableTotal)}
          </div>
          {offer.evaluation.requiredExtrasTotal.minorUnits > 0 && (
            <div className="text-[11px] text-slate-600 tabular-nums">
              Incl. +{formatMoney(offer.evaluation.requiredExtrasTotal)} required extras
            </div>
          )}
          {showPerPerson && totalPax > 1 && (
            <div className="text-[11px] text-slate-500 tabular-nums">
              ~{formatMoney(offer.evaluation.perPersonAverage)} / person ({totalPax} travelers)
            </div>
          )}
          {offer.evaluation.fxDisclosure && (
            <div className="text-[11px] text-slate-600 tabular-nums">
              Est. {formatMoney(offer.evaluation.fxDisclosure.converted)} ({offer.evaluation.fxDisclosure.rate})
            </div>
          )}
        </div>

        <Link
          href={`/offers/${encodeURIComponent(offer.offerId)}`}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#16C2AF] hover:bg-[#12AD9C] text-[#0D2038] font-bold text-xs sm:text-sm whitespace-nowrap transition-colors"
        >
          <span>Select</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
