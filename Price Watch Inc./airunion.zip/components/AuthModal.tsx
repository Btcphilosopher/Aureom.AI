'use client';

import React, { useState } from 'react';
import { Lock, Mail, User, X } from 'lucide-react';
import type { UserPublic } from '@/lib/domain/types';
import { useAuth } from './AuthProvider';

export function AuthModal() {
  const { authModalOpen, setAuthModalOpen, setSession, signInDemoTraveler } = useAuth();
  const [tab, setTab] = useState<'login' | 'register' | 'recover'>('login');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!authModalOpen) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setBusy(true);
    try {
      const action =
        tab === 'login' ? 'login' : tab === 'register' ? 'register' : 'recover_request';
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action, email, name, password }),
      });
      const data = (await res.json()) as {
        token?: string;
        user?: UserPublic;
        message?: string;
        error?: string;
      };
      if (!res.ok) {
        setError(data.error ?? 'Authentication request failed.');
      } else if (action === 'recover_request') {
        setInfo(data.message ?? 'Recovery request queued.');
      } else if (data.token && data.user) {
        setSession(data.token, data.user);
        setAuthModalOpen(false);
      }
    } catch {
      setError('Unable to connect to authentication service.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
        <div className="bg-[#0D2038] text-white px-6 py-4 flex items-center justify-between">
          <div>
            <h2 id="auth-modal-title" className="text-lg font-bold">
              {tab === 'login'
                ? 'Sign in to airunion'
                : tab === 'register'
                ? 'Create traveler account'
                : 'Recover account access'}
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Save searches, price alerts, and referral handoff records.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setAuthModalOpen(false)}
            className="p-1.5 rounded-lg hover:bg-white/10 text-slate-200 cursor-pointer"
            aria-label="Close sign in dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Segmented tabs */}
          <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-lg mb-5">
            <button
              type="button"
              onClick={() => {
                setTab('login');
                setError(null);
                setInfo(null);
              }}
              className={`py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                tab === 'login' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Sign in
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('register');
                setError(null);
                setInfo(null);
              }}
              className={`py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                tab === 'register' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Register
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('recover');
                setError(null);
                setInfo(null);
              }}
              className={`py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                tab === 'recover' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Recover
            </button>
          </div>

          {error && (
            <div className="mb-4 px-3.5 py-2.5 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-800">
              {error}
            </div>
          )}
          {info && (
            <div className="mb-4 px-3.5 py-2.5 rounded-lg bg-teal-50 border border-teal-200 text-xs text-teal-900">
              {info}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {tab === 'register' && (
              <div>
                <label htmlFor="auth-name" className="block text-xs font-medium text-slate-700 mb-1">
                  Display name (no passport or payment details needed)
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="auth-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Alex Taylor"
                    className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#0D2038]"
                  />
                </div>
              </div>
            )}

            <div>
              <label htmlFor="auth-email" className="block text-xs font-medium text-slate-700 mb-1">
                Email address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="auth-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#0D2038]"
                />
              </div>
            </div>

            {tab !== 'recover' && (
              <div>
                <label htmlFor="auth-password" className="block text-xs font-medium text-slate-700 mb-1">
                  Password (minimum 8 characters)
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    id="auth-password"
                    type="password"
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#0D2038]"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full py-2.5 px-4 rounded-lg bg-[#16C2AF] hover:bg-[#12AD9C] text-[#0D2038] font-semibold text-sm transition-colors cursor-pointer disabled:opacity-60"
            >
              {busy
                ? 'Processing...'
                : tab === 'login'
                ? 'Sign in'
                : tab === 'register'
                ? 'Create account'
                : 'Send recovery instructions'}
            </button>
          </form>

          <div className="mt-5 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={() => void signInDemoTraveler()}
              className="w-full py-2.5 px-4 rounded-lg border border-slate-300 hover:bg-slate-50 text-slate-800 text-xs font-semibold transition-colors cursor-pointer"
            >
              Continue with Demo Traveler workspace (Jordan Mercer)
            </button>
            <p className="text-[11px] text-slate-500 text-center mt-2">
              Minimal data policy: airunion never collects passports or payment cards.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
