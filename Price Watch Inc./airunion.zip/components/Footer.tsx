import Link from 'next/link';

export function Footer() {
  return (
    <footer className="bg-[#0D2038] text-slate-300 border-t border-white/10">
      <div className="max-w-[1220px] mx-auto px-4 sm:px-6 py-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
        <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5">
          <span className="font-display font-bold text-white lowercase text-sm">airunion</span>
          <span aria-hidden="true">·</span>
          <span>Independent flight-comparison platform</span>
          <span aria-hidden="true">·</span>
          <span>US airport & fare transparency</span>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-5">
          <Link href="/" className="hover:text-white transition-colors">
            Flights
          </Link>
          <Link href="/destinations" className="hover:text-white transition-colors">
            Destinations
          </Link>
          <Link href="/my-trips" className="hover:text-white transition-colors">
            My trips
          </Link>
          <Link href="/help" className="hover:text-white transition-colors">
            Fare & provider disclosure
          </Link>
          <Link href="/admin" className="hover:text-white transition-colors">
            Admin console
          </Link>
        </div>
      </div>
    </footer>
  );
}
