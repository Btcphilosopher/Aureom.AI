'use client';

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Armchair,
  ArrowLeftRight,
  Calendar,
  ChevronDown,
  MapPin,
  Minus,
  Plus,
  Search,
  User,
} from 'lucide-react';
import { DEFAULT_AIRPORT_CATALOG, getLocationByCode } from '@/lib/data/airports';
import { getDefaultFutureDates } from '@/lib/domain/timezone';
import type {
  BaggageRequirement,
  CabinClass,
  LocationOption,
  PassengerComposition,
  SearchCriteria,
  TripType,
} from '@/lib/domain/types';
import { useAuth } from './AuthProvider';

interface SearchFormProps {
  initialCriteria?: Partial<SearchCriteria>;
  compact?: boolean;
  onSubmitSearch?: (criteria: SearchCriteria) => void;
}

const CABIN_LABELS: Record<CabinClass, string> = {
  economy: 'Economy',
  premium_economy: 'Premium Economy',
  business: 'Business',
  first: 'First',
};

export function SearchForm({ initialCriteria, compact = false, onSubmitSearch }: SearchFormProps) {
  const router = useRouter();
  const { currency } = useAuth();
  const defaults = useMemo(() => getDefaultFutureDates(), []);

  const [tripType, setTripType] = useState<TripType>(initialCriteria?.tripType ?? 'round_trip');
  const [originCode, setOriginCode] = useState(initialCriteria?.originCode ?? 'NYC');
  const [destinationCode, setDestinationCode] = useState(
    initialCriteria?.destinationCode ?? 'LAX'
  );
  const [includeNearbyOrigin, setIncludeNearbyOrigin] = useState(
    initialCriteria?.includeNearbyOrigin ?? false
  );
  const [includeNearbyDestination, setIncludeNearbyDestination] = useState(
    initialCriteria?.includeNearbyDestination ?? false
  );
  const [departDate, setDepartDate] = useState(initialCriteria?.departDate ?? defaults.departDate);
  const [returnDate, setReturnDate] = useState(initialCriteria?.returnDate ?? defaults.returnDate);
  const [passengers, setPassengers] = useState<PassengerComposition>(
    initialCriteria?.passengers ?? { adults: 1, children: 0, infants: 0 }
  );
  const [cabin, setCabin] = useState<CabinClass>(initialCriteria?.cabin ?? 'economy');
  const [requiredBaggage] = useState<BaggageRequirement>(
    initialCriteria?.requiredBaggage ?? 'carry_on'
  );
  const [validationError, setValidationError] = useState<string | null>(null);

  // Dropdown states
  const [paxOpen, setPaxOpen] = useState(false);
  const [cabinOpen, setCabinOpen] = useState(false);
  const [activeField, setActiveField] = useState<'origin' | 'destination' | null>(null);
  const [originQuery, setOriginQuery] = useState('');
  const [destQuery, setDestQuery] = useState('');
  const [suggestions, setSuggestions] = useState<LocationOption[]>(DEFAULT_AIRPORT_CATALOG.slice(0, 8));

  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setPaxOpen(false);
        setCabinOpen(false);
        setActiveField(null);
      }
    }
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  useEffect(() => {
    if (!activeField) return;
    const q = activeField === 'origin' ? originQuery : destQuery;
    let cancelled = false;
    fetch(`/api/airports?q=${encodeURIComponent(q)}`)
      .then((r) => r.json())
      .then((d: { locations?: LocationOption[] }) => {
        if (!cancelled && d.locations) {
          setSuggestions(d.locations);
        }
      })
      .catch(() => {
        // Fallback to local catalog silently
      });
    return () => {
      cancelled = true;
    };
  }, [activeField, originQuery, destQuery]);

  const originMeta = getLocationByCode(originCode);
  const destMeta = getLocationByCode(destinationCode);

  const originDisplay = originMeta
    ? `${originMeta.city} · ${originMeta.code}`
    : originCode;
  const destDisplay = destMeta
    ? `${destMeta.city} · ${destMeta.code}`
    : destinationCode;

  const totalPax = passengers.adults + passengers.children + passengers.infants;
  const paxSummary =
    totalPax === 1
      ? '1 adult'
      : `${totalPax} travelers`;

  function handleSwap() {
    setOriginCode(destinationCode);
    setDestinationCode(originCode);
    setIncludeNearbyOrigin(includeNearbyDestination);
    setIncludeNearbyDestination(includeNearbyOrigin);
    setValidationError(null);
  }

  function handleDepartChange(nextDate: string) {
    setDepartDate(nextDate);
    if (tripType === 'round_trip' && returnDate < nextDate) {
      setReturnDate(nextDate);
    }
    setValidationError(null);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setValidationError(null);

    if (originCode === destinationCode) {
      setValidationError('Origin and destination must be different.');
      return;
    }
    if (departDate < defaults.minDate) {
      setValidationError('Departure date must be today or in the future.');
      return;
    }
    if (tripType === 'round_trip' && returnDate < departDate) {
      setValidationError('Return date must follow or match departure date.');
      return;
    }

    const criteria: SearchCriteria = {
      tripType,
      originCode,
      destinationCode,
      includeNearbyOrigin,
      includeNearbyDestination,
      departDate,
      returnDate: tripType === 'round_trip' ? returnDate : undefined,
      passengers,
      cabin,
      requiredBaggage,
      seatPreference: initialCriteria?.seatPreference ?? 'any',
      refundableOnly: initialCriteria?.refundableOnly ?? false,
      maxStops: initialCriteria?.maxStops ?? null,
      currency,
    };

    if (onSubmitSearch) {
      onSubmitSearch(criteria);
      return;
    }

    const params = new URLSearchParams({
      tripType: criteria.tripType,
      origin: criteria.originCode,
      dest: criteria.destinationCode,
      nearbyOrigin: criteria.includeNearbyOrigin ? '1' : '0',
      nearbyDest: criteria.includeNearbyDestination ? '1' : '0',
      depart: criteria.departDate,
      adults: String(criteria.passengers.adults),
      children: String(criteria.passengers.children),
      infants: String(criteria.passengers.infants),
      cabin: criteria.cabin,
      bag: criteria.requiredBaggage,
      seat: criteria.seatPreference,
      currency: criteria.currency,
    });
    if (criteria.returnDate) params.set('return', criteria.returnDate);

    router.push(`/search?${params.toString()}`);
  }

  return (
    <div
      ref={containerRef}
      className={`bg-white rounded-2xl shadow-xl border border-slate-200/80 text-slate-900 ${
        compact ? 'p-4' : 'p-5 sm:p-6'
      }`}
    >
      <form onSubmit={handleSubmit}>
        {/* Top Row: Trip Type | Passengers | Cabin */}
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <div className="inline-flex items-center p-1 bg-slate-100 rounded-full">
            <button
              type="button"
              onClick={() => setTripType('round_trip')}
              className={`px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                tripType === 'round_trip'
                  ? 'bg-[#D6F4EF] text-[#0E5952]'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Round trip
            </button>
            <button
              type="button"
              onClick={() => setTripType('one_way')}
              className={`px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                tripType === 'one_way'
                  ? 'bg-[#D6F4EF] text-[#0E5952]'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              One way
            </button>
          </div>

          <span className="hidden sm:inline-block h-5 w-px bg-slate-200" aria-hidden="true" />

          {/* Passenger selector */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setPaxOpen((prev) => !prev);
                setCabinOpen(false);
                setActiveField(null);
              }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 hover:border-slate-300 text-xs sm:text-sm font-medium text-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              aria-expanded={paxOpen}
            >
              <User className="w-4 h-4 text-slate-500" />
              <span>{paxSummary}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
            </button>

            {paxOpen && (
              <div className="absolute left-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 p-4 z-40 space-y-3">
                <p className="text-xs font-semibold text-slate-700">
                  Travelers (priced individually by age)
                </p>
                {[
                  { key: 'adults' as const, label: 'Adults', sub: 'Ages 12+', min: 1, max: 8 },
                  { key: 'children' as const, label: 'Children', sub: 'Ages 2–11', min: 0, max: 6 },
                  { key: 'infants' as const, label: 'Infants', sub: 'Under 2', min: 0, max: passengers.adults },
                ].map((row) => (
                  <div key={row.key} className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-slate-900">{row.label}</p>
                      <p className="text-xs text-slate-500">{row.sub}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={passengers[row.key] <= row.min}
                        onClick={() =>
                          setPassengers((prev) => {
                            const nextVal = Math.max(row.min, prev[row.key] - 1);
                            const next = { ...prev, [row.key]: nextVal };
                            if (next.infants > next.adults) next.infants = next.adults;
                            return next;
                          })
                        }
                        className="w-7 h-7 rounded-full border border-slate-300 flex items-center justify-center text-slate-700 disabled:opacity-35 cursor-pointer"
                        aria-label={`Decrease ${row.label}`}
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-5 text-center text-sm font-semibold tabular-nums">
                        {passengers[row.key]}
                      </span>
                      <button
                        type="button"
                        disabled={passengers[row.key] >= row.max}
                        onClick={() =>
                          setPassengers((prev) => ({
                            ...prev,
                            [row.key]: Math.min(row.max, prev[row.key] + 1),
                          }))
                        }
                        className="w-7 h-7 rounded-full border border-slate-300 flex items-center justify-center text-slate-700 disabled:opacity-35 cursor-pointer"
                        aria-label={`Increase ${row.label}`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setPaxOpen(false)}
                  className="w-full py-1.5 rounded-lg bg-[#0D2038] text-white text-xs font-semibold cursor-pointer"
                >
                  Apply travelers
                </button>
              </div>
            )}
          </div>

          {/* Cabin selector */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setCabinOpen((prev) => !prev);
                setPaxOpen(false);
                setActiveField(null);
              }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 hover:border-slate-300 text-xs sm:text-sm font-medium text-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              aria-expanded={cabinOpen}
            >
              <Armchair className="w-4 h-4 text-slate-500" />
              <span>{CABIN_LABELS[cabin]}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
            </button>
            {cabinOpen && (
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-40">
                {(Object.keys(CABIN_LABELS) as CabinClass[]).map((cKey) => (
                  <button
                    key={cKey}
                    type="button"
                    onClick={() => {
                      setCabin(cKey);
                      setCabinOpen(false);
                    }}
                    className={`w-full text-left px-3.5 py-2 text-sm cursor-pointer ${
                      cabin === cKey
                        ? 'bg-[#D6F4EF]/60 text-[#0E5952] font-semibold'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {CABIN_LABELS[cKey]}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Bottom Row: From | Swap | To | Depart | Return | Search flights */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto_1fr_auto_auto_auto] gap-2.5 items-stretch">
          {/* From field */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setActiveField(activeField === 'origin' ? null : 'origin');
                setOriginQuery('');
                setPaxOpen(false);
                setCabinOpen(false);
              }}
              className="w-full h-full min-h-[54px] flex items-center justify-between gap-2 px-3.5 py-2 rounded-xl border border-slate-200 hover:border-slate-400 bg-white text-left cursor-pointer"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <MapPin className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="min-w-0">
                  <div className="text-[11px] font-medium text-slate-500 leading-none mb-1">
                    From {includeNearbyOrigin ? '(+ nearby)' : ''}
                  </div>
                  <div className="text-sm sm:text-[15px] font-semibold text-slate-900 truncate">
                    {originDisplay}
                  </div>
                </div>
              </div>
              <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
            </button>

            {activeField === 'origin' && (
              <div className="absolute left-0 top-full mt-2 w-full sm:w-96 bg-white rounded-xl shadow-2xl border border-slate-200 p-3 z-50">
                <input
                  type="text"
                  autoFocus
                  value={originQuery}
                  onChange={(e) => setOriginQuery(e.target.value)}
                  placeholder="Search city or airport (e.g. NYC, JFK, LAX)..."
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#0D2038] mb-2.5"
                />
                {originMeta?.nearbyAirports && originMeta.nearbyAirports.length > 0 && (
                  <label className="flex items-center gap-2 px-2 py-1.5 mb-2 rounded-lg bg-slate-50 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeNearbyOrigin}
                      onChange={(e) => setIncludeNearbyOrigin(e.target.checked)}
                      className="rounded border-slate-300"
                    />
                    <span>
                      Expand nearby airports ({originMeta.nearbyAirports.join(', ')})
                    </span>
                  </label>
                )}
                <div className="max-h-60 overflow-y-auto divide-y divide-slate-100">
                  {suggestions.map((loc) => (
                    <button
                      key={loc.code}
                      type="button"
                      onClick={() => {
                        setOriginCode(loc.code);
                        setActiveField(null);
                      }}
                      className="w-full text-left px-2.5 py-2 hover:bg-slate-50 rounded-lg flex items-start justify-between gap-2 cursor-pointer"
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-900 truncate">
                          {loc.city} — {loc.name}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {loc.kind === 'metro'
                            ? `Metro area · includes ${loc.includedAirports?.join(', ')}`
                            : `Airport · ${loc.timezone}`}
                        </div>
                      </div>
                      <span className="font-mono text-xs font-semibold text-[#0D2038] bg-slate-100 px-2 py-0.5 rounded shrink-0">
                        {loc.code}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Swap button */}
          <div className="flex items-center justify-center">
            <button
              type="button"
              onClick={handleSwap}
              aria-label="Swap origin and destination"
              className="w-10 h-10 rounded-xl border border-slate-200 hover:border-slate-400 hover:bg-slate-50 flex items-center justify-center text-slate-600 transition-colors cursor-pointer shrink-0"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </button>
          </div>

          {/* To field */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setActiveField(activeField === 'destination' ? null : 'destination');
                setDestQuery('');
                setPaxOpen(false);
                setCabinOpen(false);
              }}
              className="w-full h-full min-h-[54px] flex items-center justify-between gap-2 px-3.5 py-2 rounded-xl border border-slate-200 hover:border-slate-400 bg-white text-left cursor-pointer"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <MapPin className="w-4 h-4 text-slate-500 shrink-0" />
                <div className="min-w-0">
                  <div className="text-[11px] font-medium text-slate-500 leading-none mb-1">
                    To {includeNearbyDestination ? '(+ nearby)' : ''}
                  </div>
                  <div className="text-sm sm:text-[15px] font-semibold text-slate-900 truncate">
                    {destDisplay}
                  </div>
                </div>
              </div>
              <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
            </button>

            {activeField === 'destination' && (
              <div className="absolute left-0 top-full mt-2 w-full sm:w-96 bg-white rounded-xl shadow-2xl border border-slate-200 p-3 z-50">
                <input
                  type="text"
                  autoFocus
                  value={destQuery}
                  onChange={(e) => setDestQuery(e.target.value)}
                  placeholder="Search destination city or airport..."
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#0D2038] mb-2.5"
                />
                {destMeta?.nearbyAirports && destMeta.nearbyAirports.length > 0 && (
                  <label className="flex items-center gap-2 px-2 py-1.5 mb-2 rounded-lg bg-slate-50 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeNearbyDestination}
                      onChange={(e) => setIncludeNearbyDestination(e.target.checked)}
                      className="rounded border-slate-300"
                    />
                    <span>
                      Expand nearby airports ({destMeta.nearbyAirports.join(', ')})
                    </span>
                  </label>
                )}
                <div className="max-h-60 overflow-y-auto divide-y divide-slate-100">
                  {suggestions.map((loc) => (
                    <button
                      key={loc.code}
                      type="button"
                      onClick={() => {
                        setDestinationCode(loc.code);
                        setActiveField(null);
                      }}
                      className="w-full text-left px-2.5 py-2 hover:bg-slate-50 rounded-lg flex items-start justify-between gap-2 cursor-pointer"
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-900 truncate">
                          {loc.city} — {loc.name}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {loc.kind === 'metro'
                            ? `Metro area · includes ${loc.includedAirports?.join(', ')}`
                            : `Airport · ${loc.timezone}`}
                        </div>
                      </div>
                      <span className="font-mono text-xs font-semibold text-[#0D2038] bg-slate-100 px-2 py-0.5 rounded shrink-0">
                        {loc.code}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Depart Date */}
          <label className="min-h-[54px] flex items-center gap-2.5 px-3.5 py-2 rounded-xl border border-slate-200 hover:border-slate-400 bg-white cursor-pointer">
            <Calendar className="w-4 h-4 text-slate-500 shrink-0" />
            <div>
              <div className="text-[11px] font-medium text-slate-500 leading-none mb-1">Depart</div>
              <input
                type="date"
                min={defaults.minDate}
                value={departDate}
                onChange={(e) => handleDepartChange(e.target.value)}
                className="text-sm font-semibold text-slate-900 bg-transparent focus:outline-none tabular-nums cursor-pointer"
              />
            </div>
          </label>

          {/* Return Date */}
          <label
            className={`min-h-[54px] flex items-center gap-2.5 px-3.5 py-2 rounded-xl border bg-white ${
              tripType === 'one_way'
                ? 'border-slate-100 bg-slate-50 opacity-50 cursor-not-allowed'
                : 'border-slate-200 hover:border-slate-400 cursor-pointer'
            }`}
          >
            <Calendar className="w-4 h-4 text-slate-500 shrink-0" />
            <div>
              <div className="text-[11px] font-medium text-slate-500 leading-none mb-1">Return</div>
              <input
                type="date"
                disabled={tripType === 'one_way'}
                min={departDate}
                value={tripType === 'one_way' ? '' : returnDate}
                onChange={(e) => {
                  setReturnDate(e.target.value);
                  setValidationError(null);
                }}
                className="text-sm font-semibold text-slate-900 bg-transparent focus:outline-none tabular-nums disabled:cursor-not-allowed cursor-pointer"
              />
            </div>
          </label>

          {/* Primary Search Button */}
          <button
            type="submit"
            className="min-h-[54px] px-6 py-3 rounded-xl bg-[#16C2AF] hover:bg-[#12AD9C] text-[#0D2038] font-bold text-[15px] flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-colors shadow-xs cursor-pointer"
          >
            <Search className="w-4 h-4 stroke-[2.5]" />
            <span>Search flights</span>
          </button>
        </div>

        {/* Metro / Nearby Clarification Line */}
        {(originMeta?.kind === 'metro' || destMeta?.kind === 'metro') && (
          <div className="mt-2.5 flex flex-wrap items-center gap-3 text-[11px] text-slate-500">
            {originMeta?.kind === 'metro' && (
              <span>
                Origin <strong className="font-mono text-slate-700">{originMeta.code}</strong> searches{' '}
                {originMeta.includedAirports?.join(', ')}
                {includeNearbyOrigin && originMeta.nearbyAirports?.length
                  ? ` + nearby ${originMeta.nearbyAirports.join(', ')}`
                  : ''}
              </span>
            )}
            {destMeta?.kind === 'metro' && (
              <span>
                Destination <strong className="font-mono text-slate-700">{destMeta.code}</strong> searches{' '}
                {destMeta.includedAirports?.join(', ')}
                {includeNearbyDestination && destMeta.nearbyAirports?.length
                  ? ` + nearby ${destMeta.nearbyAirports.join(', ')}`
                  : ''}
              </span>
            )}
          </div>
        )}

        {validationError && (
          <p className="mt-2.5 text-xs font-medium text-rose-700" role="alert">
            {validationError}
          </p>
        )}
      </form>
    </div>
  );
}
