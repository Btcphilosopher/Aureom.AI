/**
 * Bounded LRU-TTL cache and sliding-window rate limiter.
 * Mirrors the Redis bounded cache + rate limiter in standalone preview mode.
 */

interface CacheEntry<T> {
  value: T;
  expiresAtMs: number;
}

export class BoundedTtlCache<T> {
  private readonly store = new Map<string, CacheEntry<T>>();
  private readonly maxEntries: number;
  private readonly defaultTtlMs: number;

  constructor(maxEntries = 150, defaultTtlMs = 120_000) {
    this.maxEntries = maxEntries;
    this.defaultTtlMs = defaultTtlMs;
  }

  get(key: string): T | null {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAtMs) {
      this.store.delete(key);
      return null;
    }
    // Refresh LRU order
    this.store.delete(key);
    this.store.set(key, entry);
    return entry.value;
  }

  set(key: string, value: T, ttlMs: number = this.defaultTtlMs): void {
    if (this.store.has(key)) {
      this.store.delete(key);
    } else if (this.store.size >= this.maxEntries) {
      const oldestKey = this.store.keys().next().value;
      if (oldestKey !== undefined) {
        this.store.delete(oldestKey);
      }
    }
    this.store.set(key, {
      value,
      expiresAtMs: Date.now() + ttlMs,
    });
  }

  clear(): void {
    this.store.clear();
  }

  size(): number {
    return this.store.size;
  }
}

export class SlidingWindowRateLimiter {
  private readonly buckets = new Map<string, number[]>();
  private readonly maxRequests: number;
  private readonly windowMs: number;

  constructor(maxRequests = 60, windowMs = 60_000) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
  }

  check(key: string): { allowed: boolean; remaining: number; resetInMs: number } {
    const now = Date.now();
    const cutoff = now - this.windowMs;
    const timestamps = (this.buckets.get(key) ?? []).filter((t) => t > cutoff);

    if (timestamps.length >= this.maxRequests) {
      this.buckets.set(key, timestamps);
      const resetInMs = Math.max(0, timestamps[0] + this.windowMs - now);
      return { allowed: false, remaining: 0, resetInMs };
    }

    timestamps.push(now);
    this.buckets.set(key, timestamps);
    if (this.buckets.size > 1000) {
      const oldest = this.buckets.keys().next().value;
      if (oldest) this.buckets.delete(oldest);
    }

    return {
      allowed: true,
      remaining: Math.max(0, this.maxRequests - timestamps.length),
      resetInMs: this.windowMs,
    };
  }
}

export const searchResultCache = new BoundedTtlCache<unknown>(150, 120_000);
export const apiRateLimiter = new SlidingWindowRateLimiter(120, 60_000);
