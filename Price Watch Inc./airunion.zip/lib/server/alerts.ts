import crypto from 'node:crypto';
import { formatMoney } from '../domain/money.ts';
import type { PriceAlertRecord, ProviderHealthState } from '../domain/types.ts';
import { runAggregatedSearch } from '../providers/aggregator.ts';
import { appendAuditLog, updateStore } from './store.ts';

/**
 * Evaluates one or all active price alerts strictly against their saved
 * comparison requirements (baggage, cabin, seat preference, travelers).
 * An offer missing required baggage or exceeding comparable total does NOT trigger an alert.
 */
export async function evaluatePriceAlerts(
  targetAlertId?: string,
  actorId: string = 'worker'
): Promise<PriceAlertRecord[]> {
  const nowIso = new Date().toISOString();
  const updatedAlerts: PriceAlertRecord[] = [];

  const snapshot = updateStore((store) => {
    const providerStates: Record<string, ProviderHealthState> = {};
    for (const cfg of store.providerConfigs) {
      providerStates[cfg.providerId] = cfg.healthState;
    }
    const alerts = store.priceAlerts.filter((a) =>
      targetAlertId ? a.alertId === targetAlertId : a.status !== 'paused'
    );
    return { providerStates, alerts };
  });

  for (const alert of snapshot.alerts) {
    const searchRes = await runAggregatedSearch({
      criteria: alert.criteria,
      providerStates: snapshot.providerStates,
      nowIso,
    });

    const allOffers = searchRes.groups.flatMap((g) => g.offers);
    const eligibleOffers = allOffers
      .filter((o) => o.evaluation.eligibility === 'eligible' && !o.isExpired)
      .sort((a, b) => a.evaluation.comparableTotal.minorUnits - b.evaluation.comparableTotal.minorUnits);

    const cheapestBase = allOffers
      .filter((o) => !o.isExpired)
      .sort(
        (a, b) =>
          a.observation.baseFareTotal.minorUnits +
          a.observation.taxesAndMandatoryTotal.minorUnits -
          (b.observation.baseFareTotal.minorUnits + b.observation.taxesAndMandatoryTotal.minorUnits)
      )[0];

    const bestEligible = eligibleOffers[0] ?? null;

    updateStore((store) => {
      const target = store.priceAlerts.find((a) => a.alertId === alert.alertId);
      if (!target) return;

      target.lastCheckedAt = nowIso;

      if (!bestEligible) {
        if (cheapestBase) {
          const baseTotalMinor =
            cheapestBase.observation.baseFareTotal.minorUnits +
            cheapestBase.observation.taxesAndMandatoryTotal.minorUnits;
          target.lastCheckedOfferId = cheapestBase.offerId;
          target.lastCheckedPrice = cheapestBase.evaluation.comparableTotal;
          target.lastPriceBasis = `Excluded (${cheapestBase.evaluation.eligibility}): missing/ineligible for required ${target.criteria.requiredBaggage}`;
          target.lastNotificationStatus = 'not_eligible_for_requirements';
          target.lastNotificationMessage = `Cheapest base fare (${formatMoney({
            minorUnits: baseTotalMinor,
            currency: cheapestBase.observation.baseFareTotal.currency,
            amount: (baseTotalMinor / 100).toFixed(2),
          })}) did NOT trigger alert because it does not satisfy your saved requirements (${cheapestBase.evaluation.reasons[0] ?? 'ineligible'}).`;
        } else {
          target.lastCheckedOfferId = undefined;
          target.lastCheckedPrice = null;
          target.lastPriceBasis = 'No matching offers found';
          target.lastNotificationStatus = 'no_matching_offer';
          target.lastNotificationMessage = 'No matching offers returned on this periodic check.';
        }
      } else {
        target.lastCheckedOfferId = bestEligible.offerId;
        target.lastCheckedPrice = bestEligible.evaluation.comparableTotal;
        target.lastPriceBasis = `Comparable total (${target.criteria.requiredBaggage}, ${target.criteria.cabin})`;

        if (bestEligible.evaluation.comparableTotal.minorUnits <= target.targetPrice.minorUnits) {
          target.status = 'triggered';
          target.lastNotificationStatus = 'notified';
          const skippedCheap =
            cheapestBase &&
            cheapestBase.offerId !== bestEligible.offerId &&
            cheapestBase.evaluation.eligibility !== 'eligible'
              ? ` Cheaper base fare (${cheapestBase.seller.name}) was excluded for lacking required ${target.criteria.requiredBaggage.replace('_', ' ')}.`
              : '';
          target.lastNotificationMessage = `Target met! ${bestEligible.seller.name} (${bestEligible.fareProduct.fareFamilyName}) is ${formatMoney(bestEligible.evaluation.comparableTotal)} (target ${formatMoney(target.targetPrice)}).${skippedCheap}`;
        } else {
          target.status = 'active';
          target.lastNotificationStatus = 'not_eligible_for_requirements';
          target.lastNotificationMessage = `Lowest eligible comparable total is ${formatMoney(bestEligible.evaluation.comparableTotal)} via ${bestEligible.seller.name}, above your ${formatMoney(target.targetPrice)} target.`;
        }
      }

      store.alertRunLogs.unshift({
        id: `arl_${crypto.randomUUID().slice(0, 10)}`,
        alertId: target.alertId,
        checkedAt: nowIso,
        outcome: target.lastNotificationStatus,
        observedPrice: target.lastCheckedPrice
          ? `${target.lastCheckedPrice.amount} ${target.lastCheckedPrice.currency}`
          : null,
        priceBasis: target.lastPriceBasis ?? '',
        message: target.lastNotificationMessage ?? '',
      });
      if (store.alertRunLogs.length > 100) store.alertRunLogs.length = 100;

      appendAuditLog(
        store,
        actorId,
        actorId === 'worker' ? 'system' : 'traveler',
        'PRICE_ALERT_CHECKED',
        target.alertId,
        target.lastNotificationMessage ?? 'Checked alert'
      );

      updatedAlerts.push({ ...target });
    });
  }

  return updatedAlerts;
}
