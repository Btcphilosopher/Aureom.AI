import crypto from 'node:crypto';
import type { NextRequest } from 'next/server';
import type { UserPublic } from '../domain/types.ts';
import { readStore, sanitizeUser } from './store.ts';

// Ephemeral in-memory fallback signing key if AUTH_SECRET env var is unset
const EPHEMERAL_SIGNING_KEY = crypto.randomBytes(32).toString('hex');

function getSigningSecret(): string {
  const envSecret = process.env.AUTH_SECRET?.trim();
  return envSecret && envSecret.length >= 16 ? envSecret : EPHEMERAL_SIGNING_KEY;
}

export function hashPassword(password: string, existingSalt?: string): { hash: string; salt: string } {
  const salt = existingSalt ?? crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash: derived, salt };
}

export function verifyPassword(password: string, storedHash: string, salt: string): boolean {
  if (!storedHash || !salt) return false;
  const { hash } = hashPassword(password, salt);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(storedHash, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

interface SessionPayload {
  sub: string;
  role: 'traveler' | 'admin';
  email: string;
  name: string;
  exp: number;
}

export function issueSessionToken(user: UserPublic): string {
  const payload: SessionPayload = {
    sub: user.userId,
    role: user.role,
    email: user.email,
    name: user.name,
    exp: Date.now() + 1000 * 60 * 60 * 24, // 24h
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSigningSecret())
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(token: string): SessionPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', getSigningSecret())
    .update(encoded)
    .digest('base64url');

  const a = Buffer.from(sig);
  const b = Buffer.from(expectedSig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return null;
  }

  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SessionPayload;
    if (!payload.sub || Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

export function getAuthenticatedUser(req: NextRequest): UserPublic | null {
  const authHeader = req.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.slice(7).trim();
  const payload = verifySessionToken(token);
  if (!payload) return null;

  if (payload.role === 'admin' && payload.sub === 'usr_admin_console') {
    return {
      userId: payload.sub,
      email: payload.email,
      name: payload.name,
      role: 'admin',
      createdAt: new Date(0).toISOString(),
    };
  }

  const store = readStore();
  const found = store.users.find((u) => u.userId === payload.sub);
  return found ? sanitizeUser(found) : null;
}

export function isAdminConfiguredInEnv(): boolean {
  return Boolean(process.env.ADMIN_PASSCODE && process.env.ADMIN_PASSCODE.trim().length > 0);
}

export function isAdminClaimed(): boolean {
  const store = readStore();
  return isAdminConfiguredInEnv() || Boolean(store.adminCredentialHash && store.adminCredentialSalt);
}

export function verifyAdminPasscode(passcode: string): boolean {
  const envPass = process.env.ADMIN_PASSCODE?.trim();
  if (envPass && envPass.length > 0) {
    const a = Buffer.from(passcode);
    const b = Buffer.from(envPass);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
  const store = readStore();
  if (!store.adminCredentialHash || !store.adminCredentialSalt) {
    return false;
  }
  return verifyPassword(passcode, store.adminCredentialHash, store.adminCredentialSalt);
}

const ALLOWED_EXTERNAL_SELLER_HOSTS = new Set([
  'www.aa.com',
  'www.delta.com',
  'www.united.com',
  'www.jetblue.com',
  'clearfare.example',
  'skyhopper.example',
  'splitfly.example',
]);

/**
 * Validates referral destinations so only safe internal /supplier/[slug] paths
 * or allowlisted HTTPS airline/seller domains are ever permitted.
 */
export function validateSafeReferralUrl(rawUrl: string): { valid: boolean; safeUrl: string } {
  if (rawUrl.startsWith('/supplier/')) {
    const clean = rawUrl.replace(/[\r\n]/g, '');
    return { valid: true, safeUrl: clean };
  }
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:') {
      return { valid: false, safeUrl: '/supplier/invalid' };
    }
    if (!ALLOWED_EXTERNAL_SELLER_HOSTS.has(parsed.hostname.toLowerCase())) {
      return { valid: false, safeUrl: '/supplier/invalid' };
    }
    return { valid: true, safeUrl: parsed.toString() };
  } catch {
    return { valid: false, safeUrl: '/supplier/invalid' };
  }
}
