import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { DEFAULT_AIRPORT_CATALOG } from '../data/airports.ts';
import { DEFAULT_DESTINATIONS, type DestinationItem } from '../data/destinations.ts';
import { makeMoney } from '../domain/money.ts';
import { getDefaultFutureDates } from '../domain/timezone.ts';
import type {
  HandoffEventRecord,
  LocationOption,
  ManualBookingRecord,
  Offer,
  PriceAlertRecord,
  ProviderHealthState,
  SavedItineraryRecord,
  SavedSearchRecord,
  SearchCriteria,
  UserPublic,
} from '../domain/types.ts';

export interface StoredUser extends UserPublic {
  passwordHash: string;
  passwordSalt: string;
}

export interface ProviderConfigRecord {
  providerId: string;
  providerName: string;
  healthState: ProviderHealthState;
  rateLimitPerMinute: number;
  credentialEnvKeys: string[];
  commercialAccessNote: string;
  updatedAt: string;
}

export interface FailedSearchRecord {
  id: string;
  criteria: SearchCriteria;
  reason: string;
  providersInvolved: string[];
  createdAt: string;
}

export interface MappingErrorRecord {
  id: string;
  providerId: string;
  rawCode: string;
  message: string;
  resolved: boolean;
  createdAt: string;
}

export interface AuditLogRecord {
  id: string;
  actorId: string;
  actorRole: 'traveler' | 'admin' | 'system';
  action: string;
  target: string;
  detail: string;
  createdAt: string;
}

export interface AlertRunLogRecord {
  id: string;
  alertId: string;
  checkedAt: string;
  outcome: PriceAlertRecord['lastNotificationStatus'];
  observedPrice: string | null;
  priceBasis: string;
  message: string;
}

export interface StoreSchema {
  version: number;
  adminCredentialHash: string | null;
  adminCredentialSalt: string | null;
  users: StoredUser[];
  providerConfigs: ProviderConfigRecord[];
  airports: LocationOption[];
  destinations: DestinationItem[];
  offersById: Record<string, Offer>;
  savedSearches: SavedSearchRecord[];
  savedItineraries: SavedItineraryRecord[];
  priceAlerts: PriceAlertRecord[];
  alertRunLogs: AlertRunLogRecord[];
  handoffEvents: HandoffEventRecord[];
  manualBookings: ManualBookingRecord[];
  failedSearches: FailedSearchRecord[];
  mappingErrors: MappingErrorRecord[];
  auditLogs: AuditLogRecord[];
}

const DATA_DIR = path.join(process.cwd(), '.airunion-data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

export const DEMO_TRAVELER_ID = 'usr_demo_traveler';

function createInitialStore(): StoreSchema {
  const now = new Date().toISOString();
  const { departDate, returnDate } = getDefaultFutureDates();

  const defaultCriteria: SearchCriteria = {
    tripType: 'round_trip',
    originCode: 'NYC',
    destinationCode: 'LAX',
    includeNearbyOrigin: false,
    includeNearbyDestination: false,
    departDate,
    returnDate,
    passengers: { adults: 1, children: 0, infants: 0 },
    cabin: 'economy',
    requiredBaggage: 'checked_1',
    seatPreference: 'any',
    refundableOnly: false,
    maxStops: null,
    currency: 'USD',
  };

  return {
    version: 1,
    adminCredentialHash: null,
    adminCredentialSalt: null,
    users: [
      {
        userId: DEMO_TRAVELER_ID,
        email: 'traveler@airunion.example',
        name: 'Jordan Mercer',
        role: 'traveler',
        createdAt: now,
        passwordHash: '',
        passwordSalt: '',
      },
    ],
    providerConfigs: [
      {
        providerId: 'skybridge_gds',
        providerName: 'SkyBridge GDS',
        healthState: 'healthy',
        rateLimitPerMinute: 120,
        credentialEnvKeys: ['SKYBRIDGE_API_KEY', 'SKYBRIDGE_API_SECRET'],
        commercialAccessNote:
          'Simulated GDS fixture. Live deployment requires an accredited IATA/ARC agency contract.',
        updatedAt: now,
      },
      {
        providerId: 'aerodirect_ndc',
        providerName: 'AeroDirect NDC',
        healthState: 'healthy',
        rateLimitPerMinute: 120,
        credentialEnvKeys: ['AERODIRECT_API_KEY', 'AERODIRECT_PARTNER_ID'],
        commercialAccessNote:
          'Simulated NDC fixture. Live deployment requires direct airline bilateral NDC credentials.',
        updatedAt: now,
      },
    ],
    airports: DEFAULT_AIRPORT_CATALOG,
    destinations: DEFAULT_DESTINATIONS,
    offersById: {},
    savedSearches: [
      {
        savedSearchId: 'ss_demo_nyc_lax',
        userId: DEMO_TRAVELER_ID,
        label: 'NYC Metro to Los Angeles · 1 Checked Bag',
        criteria: defaultCriteria,
        createdAt: now,
      },
    ],
    savedItineraries: [],
    priceAlerts: [
      {
        alertId: 'al_demo_nyc_lax_bag',
        userId: DEMO_TRAVELER_ID,
        label: 'NYC → LAX (1 Checked Bag Included)',
        criteria: defaultCriteria,
        targetPrice: makeMoney(36000, 'USD'),
        checkFrequency: 'every_6_hours',
        status: 'active',
        lastCheckedAt: now,
        lastCheckedPrice: makeMoney(35400, 'USD'),
        lastPriceBasis: 'Comparable total incl. 1st checked bag (Main Plus)',
        lastNotificationStatus: 'notified',
        lastNotificationMessage:
          'Checked periodic snapshot: American Airlines (NDC Direct) matched $354.00 with 1st checked bag included (target $360.00). Basic Economy at $258.00 was excluded from triggering because adding a checked bag reaches $388.00.',
        createdAt: now,
      },
    ],
    alertRunLogs: [
      {
        id: 'arl_seed_1',
        alertId: 'al_demo_nyc_lax_bag',
        checkedAt: now,
        outcome: 'notified',
        observedPrice: '354.00 USD',
        priceBasis: 'Comparable total incl. 1st checked bag',
        message: 'Eligible offer AA 117/118 NDC Main Plus ($354.00) met $360.00 threshold.',
      },
    ],
    handoffEvents: [],
    manualBookings: [
      {
        bookingRecordId: 'mb_demo_1',
        userId: DEMO_TRAVELER_ID,
        confirmationCode: 'DEMO-8K4P2',
        airlineOrSeller: 'American Airlines',
        routeSummary: 'JFK → LAX (Round trip)',
        travelDate: departDate,
        notes: 'Manually entered confirmation note for trip planning.',
        verificationNote: 'User-entered reference only — not verified with airline reservation system.',
        createdAt: now,
      },
    ],
    failedSearches: [],
    mappingErrors: [
      {
        id: 'map_err_seed_1',
        providerId: 'aerodirect_ndc',
        rawCode: 'XQQ',
        message: 'Consolidator feed returned unmapped fare-basis qualifier XQQ; baggage defaulted to unknown.',
        resolved: false,
        createdAt: now,
      },
    ],
    auditLogs: [
      {
        id: `aud_${crypto.randomUUID().slice(0, 8)}`,
        actorId: 'system',
        actorRole: 'system',
        action: 'STORE_INITIALIZED',
        target: 'airunion-store',
        detail: 'Seeded deterministic US airport registry, provider configs, and demo traveler workspace.',
        createdAt: now,
      },
    ],
  };
}

let memoryStore: StoreSchema | null = null;

export function readStore(): StoreSchema {
  if (memoryStore) return memoryStore;
  try {
    if (fs.existsSync(STORE_PATH)) {
      const raw = fs.readFileSync(STORE_PATH, 'utf8');
      const parsed = JSON.parse(raw) as StoreSchema;
      memoryStore = parsed;
      return parsed;
    }
  } catch {
    // Fall back to fresh store if unreadable
  }
  memoryStore = createInitialStore();
  persistStore(memoryStore);
  return memoryStore;
}

export function persistStore(store: StoreSchema): void {
  memoryStore = store;
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tmpPath = `${STORE_PATH}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(store, null, 2), 'utf8');
    fs.renameSync(tmpPath, STORE_PATH);
  } catch {
    // In read-only serverless containers keep in memory safely
  }
}

export function updateStore<T>(fn: (store: StoreSchema) => T): T {
  const store = readStore();
  const result = fn(store);
  persistStore(store);
  return result;
}

export function appendAuditLog(
  store: StoreSchema,
  actorId: string,
  actorRole: AuditLogRecord['actorRole'],
  action: string,
  target: string,
  detail: string
): void {
  store.auditLogs.unshift({
    id: `aud_${crypto.randomUUID().slice(0, 10)}`,
    actorId,
    actorRole,
    action,
    target,
    detail,
    createdAt: new Date().toISOString(),
  });
  if (store.auditLogs.length > 250) {
    store.auditLogs.length = 250;
  }
}

export function sanitizeUser(user: StoredUser): UserPublic {
  return {
    userId: user.userId,
    email: user.email,
    name: user.name,
    role: user.role,
    createdAt: user.createdAt,
  };
}
