import { NextRequest, NextResponse } from 'next/server';

/**
 * Optional FastAPI proxy helper.
 * When FASTAPI_BACKEND_URL is configured (e.g. inside Docker Compose),
 * forwards API requests to the Python FastAPI service while keeping
 * credentials and headers server-side.
 */
export async function maybeProxyToFastApi(
  req: NextRequest,
  backendPath: string
): Promise<NextResponse | null> {
  const baseUrl = process.env.FASTAPI_BACKEND_URL?.trim();
  if (!baseUrl) return null;

  try {
    const targetUrl = new URL(backendPath, baseUrl);
    targetUrl.search = req.nextUrl.search;

    const headers = new Headers();
    const auth = req.headers.get('authorization');
    if (auth) headers.set('authorization', auth);
    const contentType = req.headers.get('content-type');
    if (contentType) headers.set('content-type', contentType);

    const hasBody = req.method !== 'GET' && req.method !== 'HEAD';
    const body = hasBody ? await req.text() : undefined;

    const res = await fetch(targetUrl.toString(), {
      method: req.method,
      headers,
      body,
      signal: AbortSignal.timeout(8000),
    });

    const responseText = await res.text();
    return new NextResponse(responseText, {
      status: res.status,
      headers: {
        'content-type': res.headers.get('content-type') ?? 'application/json',
        'x-airunion-engine': 'fastapi-proxy',
      },
    });
  } catch {
    // If FastAPI backend is unreachable in standalone dev, return null to use Next.js fallback
    return null;
  }
}
