import type {
  Offer,
  ProviderHealthState,
  RevalidationResult,
  SearchCriteria,
} from '../domain/types.ts';

export interface RawProviderOffer extends Omit<Offer, 'evaluation' | 'recommendedScore' | 'isExpired'> {}

export interface ProviderSearchOutput {
  providerId: string;
  providerName: string;
  status: 'ok' | 'partial' | 'failed';
  latencyMs: number;
  offers: RawProviderOffer[];
  errorMessage?: string;
}

export interface FlightProviderAdapter {
  readonly providerId: string;
  readonly providerName: string;
  readonly credentialEnvKeys: string[];
  readonly commercialAccessNote: string;

  search(
    criteria: SearchCriteria,
    healthState: ProviderHealthState,
    nowIso?: string
  ): Promise<ProviderSearchOutput>;

  revalidateOffer(
    offer: Offer,
    healthState: ProviderHealthState,
    nowIso?: string
  ): Promise<RevalidationResult>;
}
