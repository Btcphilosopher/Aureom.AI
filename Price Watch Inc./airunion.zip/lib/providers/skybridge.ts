import { resolveAirportList } from '../data/airports.ts';
import { addMoney, makeMoney } from '../domain/money.ts';
import type {
  Offer,
  ProviderHealthState,
  RevalidationResult,
  SearchCriteria,
  Seller,
} from '../domain/types.ts';
import {
  buildBaggageForSegments,
  buildBound,
  buildJourney,
  buildSegment,
  makeOfferRecord,
} from './builder.ts';
import type { FlightProviderAdapter, ProviderSearchOutput, RawProviderOffer } from './types.ts';

const SELLERS: Record<string, Seller> = {
  clearfare: {
    sellerId: 'sel-clearfare',
    slug: 'clearfare-travel',
    name: 'ClearFare Travel',
    kind: 'ota',
    affiliateDisclosed: true,
    supportNote: 'Online travel agency · affiliate commission applies on completed referral bookings.',
  },
  aa: {
    sellerId: 'sel-aa',
    slug: 'american-airlines',
    name: 'American Airlines',
    kind: 'airline_direct',
    affiliateDisclosed: false,
    supportNote: 'Direct airline website · ticketed and serviced by American Airlines.',
  },
  dl: {
    sellerId: 'sel-dl',
    slug: 'delta-air-lines',
    name: 'Delta Air Lines',
    kind: 'airline_direct',
    affiliateDisclosed: false,
    supportNote: 'Direct airline website · ticketed and serviced by Delta Air Lines.',
  },
  ua: {
    sellerId: 'sel-ua',
    slug: 'united-airlines',
    name: 'United Airlines',
    kind: 'airline_direct',
    affiliateDisclosed: false,
    supportNote: 'Direct airline website · ticketed and serviced by United Airlines.',
  },
};

export class SkyBridgeGdsAdapter implements FlightProviderAdapter {
  readonly providerId = 'skybridge_gds';
  readonly providerName = 'SkyBridge GDS';
  readonly credentialEnvKeys = ['SKYBRIDGE_API_KEY', 'SKYBRIDGE_API_SECRET'];
  readonly commercialAccessNote =
    'Simulated GDS fixture. Live GDS integration requires an accredited IATA/ARC agency agreement and GDS API credentials.';

  async search(
    criteria: SearchCriteria,
    healthState: ProviderHealthState,
    nowIso: string = new Date().toISOString()
  ): Promise<ProviderSearchOutput> {
    if (healthState === 'outage') {
      return {
        providerId: this.providerId,
        providerName: this.providerName,
        status: 'failed',
        latencyMs: 142,
        offers: [],
        errorMessage: 'SkyBridge GDS upstream timeout (503 Service Unavailable). No cached inventory substituted.',
      };
    }

    const origins = resolveAirportList(criteria.originCode, criteria.includeNearbyOrigin);
    const dests = resolveAirportList(criteria.destinationCode, criteria.includeNearbyDestination);
    const paxTotal = Math.max(1, criteria.passengers.adults + criteria.passengers.children);
    const boundsCount = criteria.tripType === 'round_trip' ? 2 : 1;

    const offers: RawProviderOffer[] = [];
    const dep = criteria.departDate;
    const ret = criteria.returnDate || criteria.departDate;

    // 1. Canonical AA 117 / AA 118 JFK <-> LAX (duplicates AeroDirectNDC's AA 117/118!)
    if (origins.includes('JFK') && dests.includes('LAX')) {
      const outSeg = buildSegment({
        segmentId: 'seg-aa117-out',
        flightNumber: 'AA 117',
        marketingCarrier: { code: 'AA', name: 'American Airlines' },
        operatingCarrier: { code: 'AA', name: 'American Airlines' },
        originAirport: 'JFK',
        originTerminal: '8',
        destinationAirport: 'LAX',
        destinationTerminal: '4',
        depDate: dep,
        depLocalTime: '08:30',
        arrDateOffsetDays: 0,
        arrLocalTime: '11:45',
        cabin: criteria.cabin,
        aircraft: 'Airbus A321T',
      });
      const bounds = [buildBound('bnd-aa117-out', 'outbound', [outSeg])];
      if (criteria.tripType === 'round_trip') {
        const inSeg = buildSegment({
          segmentId: 'seg-aa118-in',
          flightNumber: 'AA 118',
          marketingCarrier: { code: 'AA', name: 'American Airlines' },
          operatingCarrier: { code: 'AA', name: 'American Airlines' },
          originAirport: 'LAX',
          originTerminal: '4',
          destinationAirport: 'JFK',
          destinationTerminal: '8',
          depDate: ret,
          depLocalTime: '13:15',
          arrDateOffsetDays: 0,
          arrLocalTime: '21:40',
          cabin: criteria.cabin,
          aircraft: 'Airbus A321T',
        });
        bounds.push(buildBound('bnd-aa118-in', 'inbound', [inSeg]));
      }
      const journey = buildJourney('jrn-aa117-jfk-lax', bounds);

      // ClearFare OTA Basic Economy (cheaper base, expensive checked bag -> loses when checked bag added!)
      const checkedCostMinor = 6500 * boundsCount * paxTotal;
      const seatCostMinor = 2900 * boundsCount * paxTotal;
      offers.push(
        makeOfferRecord({
          offerId: `sb-cf-aa117-${criteria.tripType}`,
          providerId: this.providerId,
          providerName: this.providerName,
          providerOfferRef: 'SB-CF-AA117-BE',
          journey,
          seller: SELLERS.clearfare,
          fareFamilyName: 'Basic Economy',
          bookingClass: 'B',
          isBasicEconomy: true,
          isSeparateTickets: false,
          conditions: {
            changeAllowed: 'not_included',
            changeNotes: 'No changes permitted after 24h booking window.',
            refundAllowed: 'not_included',
            refundNotes: 'Non-refundable after 24h grace period.',
            seatAssignment: {
              status: 'advance_selection_paid',
              feeForTrip: makeMoney(seatCostMinor, 'USD'),
              notes: 'Random seat at check-in, or paid advance selection.',
            },
          },
          baggagePerSegment: buildBaggageForSegments(
            journey,
            { status: 'included', pieces: 1, notes: '1 personal item under seat' },
            { status: 'included', pieces: 1, maxWeightLb: 35, notes: '1 standard carry-on' },
            {
              status: 'paid_extra',
              pieces: 1,
              maxWeightLb: 50,
              feeIfExtra: makeMoney(checkedCostMinor, 'USD'),
              notes: '$65 per direction via ClearFare OTA',
            }
          ),
          passengers: criteria.passengers,
          adultBaseMinor: criteria.tripType === 'round_trip' ? 19600 : 10800,
          adultTaxMinor: criteria.tripType === 'round_trip' ? 6200 : 3400,
          cabin: criteria.cabin,
          availableExtras: [
            {
              extraId: 'ext-checked-1',
              kind: 'checked_1',
              label: '1st Checked Bag (up to 50 lb)',
              description: 'Covers outbound and return directions for travelers 2+ yrs',
              priceForTrip: makeMoney(checkedCostMinor, 'USD'),
              perPassenger: false,
            },
            {
              extraId: 'ext-seat-adv',
              kind: 'advance_seat',
              label: 'Advance Standard Seat Selection',
              description: 'Choose standard seats in advance across all segments',
              priceForTrip: makeMoney(seatCostMinor, 'USD'),
              perPassenger: false,
            },
          ],
          nowIso,
          expiresOffsetMinutes: 45,
        })
      );

      // American Airlines Direct Main Cabin
      const aaCheckedMinor = 3500 * boundsCount * paxTotal;
      offers.push(
        makeOfferRecord({
          offerId: `sb-aa-aa117-${criteria.tripType}`,
          providerId: this.providerId,
          providerName: this.providerName,
          providerOfferRef: 'SB-AA-AA117-MAIN',
          journey,
          seller: SELLERS.aa,
          fareFamilyName: 'Main Cabin',
          bookingClass: 'Q',
          isBasicEconomy: false,
          isSeparateTickets: false,
          conditions: {
            changeAllowed: 'included',
            changeFee: makeMoney(0, 'USD'),
            changeNotes: 'No change fee; fare difference may apply.',
            refundAllowed: 'paid_extra',
            refundNotes: 'Refundable to airline trip credit; cash refund requires Main Select.',
            seatAssignment: {
              status: 'advance_selection_included',
              notes: 'Complimentary standard seat selection at booking.',
            },
          },
          baggagePerSegment: buildBaggageForSegments(
            journey,
            { status: 'included', pieces: 1, notes: '1 personal item' },
            { status: 'included', pieces: 1, maxWeightLb: 40, notes: '1 carry-on bag included' },
            {
              status: 'paid_extra',
              pieces: 1,
              maxWeightLb: 50,
              feeIfExtra: makeMoney(aaCheckedMinor, 'USD'),
              notes: '$35 per direction at airline check-in',
            }
          ),
          passengers: criteria.passengers,
          adultBaseMinor: criteria.tripType === 'round_trip' ? 25600 : 13800,
          adultTaxMinor: criteria.tripType === 'round_trip' ? 7200 : 3800,
          cabin: criteria.cabin,
          availableExtras: [
            {
              extraId: 'ext-checked-1',
              kind: 'checked_1',
              label: '1st Checked Bag (50 lb)',
              description: '$35 each way per traveler',
              priceForTrip: makeMoney(aaCheckedMinor, 'USD'),
              perPassenger: false,
            },
          ],
          nowIso,
          expiresOffsetMinutes: 60,
        })
      );
    }

    // 2. Delta DL 402/403 JFK <-> LAX with Overnight Red-eye Return + Price Change on Revalidation!
    if (origins.includes('JFK') && dests.includes('LAX')) {
      const outSeg = buildSegment({
        segmentId: 'seg-dl402-out',
        flightNumber: 'DL 402',
        marketingCarrier: { code: 'DL', name: 'Delta Air Lines' },
        operatingCarrier: { code: 'DL', name: 'Delta Air Lines' },
        originAirport: 'JFK',
        originTerminal: '4',
        destinationAirport: 'LAX',
        destinationTerminal: '3',
        depDate: dep,
        depLocalTime: '11:10',
        arrDateOffsetDays: 0,
        arrLocalTime: '14:25',
        cabin: criteria.cabin,
        aircraft: 'Boeing 767-300ER',
      });
      const bounds = [buildBound('bnd-dl402-out', 'outbound', [outSeg])];
      if (criteria.tripType === 'round_trip') {
        const inSeg = buildSegment({
          segmentId: 'seg-dl403-in',
          flightNumber: 'DL 403',
          marketingCarrier: { code: 'DL', name: 'Delta Air Lines' },
          operatingCarrier: { code: 'DL', name: 'Delta Air Lines' },
          originAirport: 'LAX',
          originTerminal: '3',
          destinationAirport: 'JFK',
          destinationTerminal: '4',
          depDate: ret,
          depLocalTime: '22:45',
          arrDateOffsetDays: 1,
          arrLocalTime: '07:12',
          cabin: criteria.cabin,
          aircraft: 'Boeing 767-300ER',
        });
        bounds.push(buildBound('bnd-dl403-in', 'inbound', [inSeg]));
      }
      const journey = buildJourney('jrn-dl402-redeye', bounds);
      const dlChecked = 3500 * boundsCount * paxTotal;
      offers.push(
        makeOfferRecord({
          offerId: `sb-dl-jfk-lax-pricechange-${criteria.tripType}`,
          providerId: this.providerId,
          providerName: this.providerName,
          providerOfferRef: 'SB-DL-402-DRIFT',
          journey,
          seller: SELLERS.dl,
          fareFamilyName: 'Main Cabin (Red-Eye Return)',
          bookingClass: 'L',
          isBasicEconomy: false,
          isSeparateTickets: false,
          conditions: {
            changeAllowed: 'included',
            changeFee: makeMoney(0, 'USD'),
            changeNotes: 'No change fee for US domestic Main Cabin.',
            refundAllowed: 'included',
            refundFee: makeMoney(0, 'USD'),
            refundNotes: 'Refundable Main Cabin fare.',
            seatAssignment: {
              status: 'advance_selection_included',
              notes: 'Free advance seat selection.',
            },
          },
          baggagePerSegment: buildBaggageForSegments(
            journey,
            { status: 'included', pieces: 1, notes: '1 personal item' },
            { status: 'included', pieces: 1, maxWeightLb: 35, notes: '1 carry-on included' },
            {
              status: 'paid_extra',
              pieces: 1,
              maxWeightLb: 50,
              feeIfExtra: makeMoney(dlChecked, 'USD'),
              notes: '$35 each way',
            }
          ),
          passengers: criteria.passengers,
          adultBaseMinor: criteria.tripType === 'round_trip' ? 24400 : 13200,
          adultTaxMinor: criteria.tripType === 'round_trip' ? 6800 : 3500,
          cabin: criteria.cabin,
          availableExtras: [
            {
              extraId: 'ext-checked-1',
              kind: 'checked_1',
              label: '1st Checked Bag (50 lb)',
              description: '$35 per direction',
              priceForTrip: makeMoney(dlChecked, 'USD'),
              perPassenger: false,
            },
          ],
          nowIso,
          expiresOffsetMinutes: 50,
        })
      );
    }

    // 3. United Mixed-Cabin + 1-stop EWR -> ORD -> LAX
    if (origins.includes('EWR') && dests.includes('LAX')) {
      const seg1 = buildSegment({
        segmentId: 'seg-ua412-ewr-ord',
        flightNumber: 'UA 412',
        marketingCarrier: { code: 'UA', name: 'United Airlines' },
        operatingCarrier: { code: 'YX', name: 'Republic Airways dba United Express' },
        originAirport: 'EWR',
        originTerminal: 'C',
        destinationAirport: 'ORD',
        destinationTerminal: '1',
        depDate: dep,
        depLocalTime: '09:05',
        arrDateOffsetDays: 0,
        arrLocalTime: '10:35',
        cabin: 'economy',
        aircraft: 'Embraer E175',
      });
      const seg2 = buildSegment({
        segmentId: 'seg-ua1904-ord-lax',
        flightNumber: 'UA 1904',
        marketingCarrier: { code: 'UA', name: 'United Airlines' },
        operatingCarrier: { code: 'UA', name: 'United Airlines' },
        originAirport: 'ORD',
        originTerminal: '1',
        destinationAirport: 'LAX',
        destinationTerminal: '7',
        depDate: dep,
        depLocalTime: '12:00',
        arrDateOffsetDays: 0,
        arrLocalTime: '14:32',
        cabin: 'business',
        aircraft: 'Boeing 757-200',
      });
      const bounds = [buildBound('bnd-ua-ewr-lax-out', 'outbound', [seg1, seg2])];
      if (criteria.tripType === 'round_trip') {
        const retSeg = buildSegment({
          segmentId: 'seg-ua552-lax-ewr',
          flightNumber: 'UA 552',
          marketingCarrier: { code: 'UA', name: 'United Airlines' },
          operatingCarrier: { code: 'UA', name: 'United Airlines' },
          originAirport: 'LAX',
          originTerminal: '7',
          destinationAirport: 'EWR',
          destinationTerminal: 'C',
          depDate: ret,
          depLocalTime: '14:00',
          arrDateOffsetDays: 0,
          arrLocalTime: '22:18',
          cabin: criteria.cabin,
          aircraft: 'Boeing 787-9',
        });
        bounds.push(buildBound('bnd-ua-lax-ewr-in', 'inbound', [retSeg]));
      }
      const journey = buildJourney('jrn-ua-mixed-ewr-lax', bounds);
      offers.push(
        makeOfferRecord({
          offerId: `sb-ua-mixed-${criteria.tripType}`,
          providerId: this.providerId,
          providerName: this.providerName,
          providerOfferRef: 'SB-UA-MIXED-CABIN',
          journey,
          seller: SELLERS.ua,
          fareFamilyName: 'Mixed Cabin (Economy + Business)',
          bookingClass: 'Y/Z',
          isBasicEconomy: false,
          isSeparateTickets: false,
          conditions: {
            changeAllowed: 'included',
            changeFee: makeMoney(0, 'USD'),
            changeNotes: 'Free flight changes; fare difference applies.',
            refundAllowed: 'included',
            refundFee: makeMoney(0, 'USD'),
            refundNotes: 'Fully refundable fare.',
            seatAssignment: {
              status: 'assigned_included',
              notes: 'Confirmed seat assignment included on all segments.',
            },
          },
          baggagePerSegment: buildBaggageForSegments(
            journey,
            { status: 'included', pieces: 1, notes: '1 personal item' },
            { status: 'included', pieces: 1, maxWeightLb: 40, notes: '1 carry-on included' },
            { status: 'included', pieces: 2, maxWeightLb: 70, notes: '2 checked bags included via transcon Business segment' }
          ),
          passengers: criteria.passengers,
          adultBaseMinor: criteria.tripType === 'round_trip' ? 48500 : 26500,
          adultTaxMinor: criteria.tripType === 'round_trip' ? 8400 : 4400,
          cabin: criteria.cabin,
          availableExtras: [],
          nowIso,
          expiresOffsetMinutes: 90,
        })
      );
    }

    // 4. Generic US Corridor Generator for any other route (NYC->MIA, NYC->CHI, NYC->FAT, SFO->TYO, etc.)
    if (offers.length === 0 || (!origins.includes('JFK') || !dests.includes('LAX'))) {
      const o = origins[0];
      const d = dests[0];
      if (o && d && o !== d) {
        const directSegOut = buildSegment({
          segmentId: `seg-sb-gen-${o}-${d}-out`,
          flightNumber: 'AA 2410',
          marketingCarrier: { code: 'AA', name: 'American Airlines' },
          operatingCarrier: { code: 'AA', name: 'American Airlines' },
          originAirport: o,
          originTerminal: 'A',
          destinationAirport: d,
          destinationTerminal: '1',
          depDate: dep,
          depLocalTime: '09:15',
          arrDateOffsetDays: o === 'SFO' && d === 'HND' ? 1 : 0,
          arrLocalTime: o === 'SFO' && d === 'HND' ? '13:45' : '12:55',
          cabin: criteria.cabin,
          aircraft: 'Boeing 737 MAX 8',
        });
        const bounds = [buildBound(`bnd-sb-gen-${o}-${d}-out`, 'outbound', [directSegOut])];
        if (criteria.tripType === 'round_trip') {
          const directSegIn = buildSegment({
            segmentId: `seg-sb-gen-${d}-${o}-in`,
            flightNumber: 'AA 2415',
            marketingCarrier: { code: 'AA', name: 'American Airlines' },
            operatingCarrier: { code: 'AA', name: 'American Airlines' },
            originAirport: d,
            originTerminal: '1',
            destinationAirport: o,
            destinationTerminal: 'A',
            depDate: ret,
            depLocalTime: '15:20',
            arrDateOffsetDays: 0,
            arrLocalTime: '18:55',
            cabin: criteria.cabin,
            aircraft: 'Boeing 737 MAX 8',
          });
          bounds.push(buildBound(`bnd-sb-gen-${d}-${o}-in`, 'inbound', [directSegIn]));
        }
        const genJourney = buildJourney(`jrn-sb-${o}-${d}`, bounds);
        const genBagMinor = 3500 * boundsCount * paxTotal;
        offers.push(
          makeOfferRecord({
            offerId: `sb-aa-${o.toLowerCase()}-${d.toLowerCase()}-${criteria.tripType}`,
            providerId: this.providerId,
            providerName: this.providerName,
            providerOfferRef: `SB-AA-${o}-${d}`,
            journey: genJourney,
            seller: SELLERS.aa,
            fareFamilyName: 'Main Cabin',
            bookingClass: 'V',
            isBasicEconomy: false,
            isSeparateTickets: false,
            conditions: {
              changeAllowed: 'included',
              changeFee: makeMoney(0, 'USD'),
              changeNotes: 'No change fee.',
              refundAllowed: 'not_included',
              refundNotes: 'Non-refundable; credit for future travel.',
              seatAssignment: {
                status: 'advance_selection_included',
                notes: 'Standard seat selection included.',
              },
            },
            baggagePerSegment: buildBaggageForSegments(
              genJourney,
              { status: 'included', pieces: 1, notes: '1 personal item' },
              { status: 'included', pieces: 1, maxWeightLb: 35, notes: '1 carry-on included' },
              {
                status: 'paid_extra',
                pieces: 1,
                maxWeightLb: 50,
                feeIfExtra: makeMoney(genBagMinor, 'USD'),
                notes: '$35 per direction',
              }
            ),
            passengers: criteria.passengers,
            adultBaseMinor: criteria.tripType === 'round_trip' ? 19800 : 10900,
            adultTaxMinor: criteria.tripType === 'round_trip' ? 5400 : 2900,
            cabin: criteria.cabin,
            availableExtras: [
              {
                extraId: 'ext-checked-1',
                kind: 'checked_1',
                label: '1st Checked Bag (50 lb)',
                description: '$35 per direction',
                priceForTrip: makeMoney(genBagMinor, 'USD'),
                perPassenger: false,
              },
            ],
            nowIso,
            expiresOffsetMinutes: 60,
          })
        );
      }
    }

    if (healthState === 'degraded') {
      return {
        providerId: this.providerId,
        providerName: this.providerName,
        status: 'partial',
        latencyMs: 910,
        offers: offers.slice(0, Math.max(1, Math.floor(offers.length / 2))),
        errorMessage: 'SkyBridge GDS responded slowly; partial inventory returned.',
      };
    }

    return {
      providerId: this.providerId,
      providerName: this.providerName,
      status: 'ok',
      latencyMs: 185,
      offers,
    };
  }

  async revalidateOffer(
    offer: Offer,
    healthState: ProviderHealthState,
    nowIso: string = new Date().toISOString()
  ): Promise<RevalidationResult> {
    const affiliateDisclosure = offer.seller.affiliateDisclosed
      ? `Affiliate notice: airunion may earn a referral fee if you purchase after clicking through to ${offer.seller.name}. Clicking through does not create a reservation.`
      : `Direct referral: clicking through takes you to ${offer.seller.name} to complete booking. Clicking through does not create a reservation on airunion.`;

    if (healthState === 'outage') {
      return {
        offerId: offer.offerId,
        status: 'unavailable',
        checkedAt: nowIso,
        previousTotal: offer.evaluation.comparableTotal,
        updatedTotal: offer.evaluation.comparableTotal,
        priceDelta: makeMoney(0, offer.evaluation.comparableTotal.currency),
        requiresFreshSelection: false,
        message: 'SkyBridge GDS is currently experiencing an outage and cannot verify live inventory.',
        affiliateDisclosure,
      };
    }

    if (offer.isExpired) {
      return {
        offerId: offer.offerId,
        status: 'expired',
        checkedAt: nowIso,
        previousTotal: offer.evaluation.comparableTotal,
        updatedTotal: offer.evaluation.comparableTotal,
        priceDelta: makeMoney(0, offer.evaluation.comparableTotal.currency),
        requiresFreshSelection: true,
        message: 'This offer expired before revalidation. Select one of the refreshed alternatives below.',
        affiliateDisclosure,
      };
    }

    // Deterministic price change scenario for Delta DL 402/403
    if (offer.offerId.includes('pricechange')) {
      const delta = makeMoney(2400, offer.evaluation.comparableTotal.currency);
      const updatedTotal = addMoney(offer.evaluation.comparableTotal, delta);
      return {
        offerId: offer.offerId,
        status: 'price_changed',
        checkedAt: nowIso,
        previousTotal: offer.evaluation.comparableTotal,
        updatedTotal,
        priceDelta: delta,
        requiresFreshSelection: true,
        message: `Live fare revalidation detected a +$24.00 carrier repricing from ${offer.evaluation.comparableTotal.amount} to ${updatedTotal.amount} USD. Confirm the updated price before continuing.`,
        referralUrl: offer.referralUrl,
        affiliateDisclosure,
      };
    }

    return {
      offerId: offer.offerId,
      status: 'confirmed',
      checkedAt: nowIso,
      previousTotal: offer.evaluation.comparableTotal,
      updatedTotal: offer.evaluation.comparableTotal,
      priceDelta: makeMoney(0, offer.evaluation.comparableTotal.currency),
      requiresFreshSelection: false,
      message: `Fare and availability confirmed at ${offer.evaluation.comparableTotal.amount} ${offer.evaluation.comparableTotal.currency}.`,
      referralUrl: offer.referralUrl,
      affiliateDisclosure,
    };
  }
}
