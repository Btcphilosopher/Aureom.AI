import crypto from 'node:crypto';
import { RECOMMENDED_FORMULA_TEXT, scoreAndGroupOffers } from '../domain/comparison.ts';
import type {
  Offer,
  ProviderCoverageReport,
  ProviderHealthState,
  RevalidationResult,
  SearchCriteria,
  SearchResponse,
} from '../domain/types.ts';
import { AeroDirectNdcAdapter } from './aerodirect.ts';
import { SkyBridgeGdsAdapter } from './skybridge.ts';
import type { FlightProviderAdapter, RawProviderOffer } from './types.ts';

export const PROVIDER_ADAPTERS: FlightProviderAdapter[] = [
  new SkyBridgeGdsAdapter(),
  new AeroDirectNdcAdapter(),
];

export async function runAggregatedSearch(params: {
  criteria: SearchCriteria;
  providerStates: Record<string, ProviderHealthState>;
  cacheHit?: boolean;
  nowIso?: string;
}): Promise<SearchResponse> {
  const nowIso = params.nowIso ?? new Date().toISOString();
  const outputs = await Promise.all(
    PROVIDER_ADAPTERS.map((adapter) =>
      adapter.search(params.criteria, params.providerStates[adapter.providerId] ?? 'healthy', nowIso)
    )
  );

  const providers: ProviderCoverageReport[] = outputs.map((out) => ({
    providerId: out.providerId,
    providerName: out.providerName,
    status: out.status,
    latencyMs: out.latencyMs,
    offerCount: out.offers.length,
    errorMessage: out.errorMessage,
  }));

  const rawOffers: RawProviderOffer[] = outputs.flatMap((o) => o.offers);
  const { offers, groups } = scoreAndGroupOffers(rawOffers, params.criteria, nowIso);

  // Determine search completion state accurately
  const failedCount = providers.filter((p) => p.status === 'failed').length;
  const partialCount = providers.filter((p) => p.status === 'partial').length;

  let searchStatus: SearchResponse['searchStatus'] = 'complete';
  let statusBanner: string | undefined;

  if (failedCount === providers.length) {
    searchStatus = 'failed';
    statusBanner =
      'Search could not complete because all configured flight providers failed to respond. No fallback or invented availability is displayed.';
  } else if (failedCount > 0 || partialCount > 0) {
    searchStatus = offers.length === 0 ? 'failed' : 'partial';
    const affected = providers
      .filter((p) => p.status !== 'ok')
      .map((p) => `${p.providerName} (${p.errorMessage ?? p.status})`)
      .join('; ');
    statusBanner =
      offers.length === 0
        ? `Search could not complete: ${affected}.`
        : `Partial results shown — coverage is incomplete because ${affected}.`;
  } else if (offers.length === 0) {
    searchStatus = 'no_matches';
    statusBanner = 'All providers responded, but no flights matched this airport pair and date.';
  }

  // Sort groups by recommended score of bestOffer
  groups.sort((a, b) => a.bestOffer.recommendedScore - b.bestOffer.recommendedScore);

  const eligibleOffers = offers.filter((o) => o.evaluation.eligibility === 'eligible');
  const cheapestEligible = eligibleOffers.length
    ? eligibleOffers.reduce((best, cur) =>
        cur.evaluation.comparableTotal.minorUnits < best.evaluation.comparableTotal.minorUnits
          ? cur
          : best
      )
    : null;

  const cheapestBase = offers.length
    ? offers.reduce((best, cur) => {
        const bMin =
          best.observation.baseFareTotal.minorUnits +
          best.observation.taxesAndMandatoryTotal.minorUnits;
        const cMin =
          cur.observation.baseFareTotal.minorUnits +
          cur.observation.taxesAndMandatoryTotal.minorUnits;
        return cMin < bMin ? cur : best;
      })
    : null;

  const fastest = offers.length
    ? offers.reduce((best, cur) =>
        cur.journey.totalDurationMinutes < best.journey.totalDurationMinutes ? cur : best
      )
    : null;

  return {
    searchId: `srch_${crypto.randomUUID().slice(0, 12)}`,
    searchedAt: nowIso,
    criteria: params.criteria,
    cacheHit: Boolean(params.cacheHit),
    searchStatus,
    statusBanner,
    providers,
    groups,
    summary: {
      totalOffers: offers.length,
      totalUniqueItineraries: groups.length,
      cheapestEligibleTotal: cheapestEligible?.evaluation.comparableTotal ?? null,
      cheapestEligibleOfferId: cheapestEligible?.offerId ?? null,
      cheapestBaseTotal: cheapestBase
        ? {
            minorUnits:
              cheapestBase.observation.baseFareTotal.minorUnits +
              cheapestBase.observation.taxesAndMandatoryTotal.minorUnits,
            currency: cheapestBase.observation.baseFareTotal.currency,
            amount: (
              (cheapestBase.observation.baseFareTotal.minorUnits +
                cheapestBase.observation.taxesAndMandatoryTotal.minorUnits) /
              100
            ).toFixed(2),
          }
        : null,
      cheapestBaseOfferId: cheapestBase?.offerId ?? null,
      fastestDurationMinutes: fastest?.journey.totalDurationMinutes ?? null,
      fastestOfferId: fastest?.offerId ?? null,
      rankingFormulaExplanation: RECOMMENDED_FORMULA_TEXT,
    },
  };
}

export async function revalidateOfferWithProvider(params: {
  offer: Offer;
  allOffersForSearch?: Offer[];
  providerStates: Record<string, ProviderHealthState>;
  nowIso?: string;
}): Promise<RevalidationResult> {
  const nowIso = params.nowIso ?? new Date().toISOString();
  const adapter = PROVIDER_ADAPTERS.find(
    (a) => a.providerId === params.offer.observation.providerId
  );
  if (!adapter) {
    throw new Error(`Unknown provider: ${params.offer.observation.providerId}`);
  }
  const state = params.providerStates[adapter.providerId] ?? 'healthy';
  const result = await adapter.revalidateOffer(params.offer, state, nowIso);
  if (result.status === 'expired' && params.allOffersForSearch) {
    result.refreshedAlternatives = params.allOffersForSearch
      .filter((o) => !o.isExpired && o.offerId !== params.offer.offerId)
      .slice(0, 3);
  }
  return result;
}
