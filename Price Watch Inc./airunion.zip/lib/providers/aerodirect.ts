import { resolveAirportList } from '../data/airports.ts';
import { makeMoney } from '../domain/money.ts';
import type {
  Offer,
  ProviderHealthState,
  RevalidationResult,
  SearchCriteria,
  Seller,
} from '../domain/types.ts';
import {
  buildBaggageForSegments,
  buildBound,
  buildJourney,
  buildSegment,
  makeOfferRecord,
} from './builder.ts';
import type { FlightProviderAdapter, ProviderSearchOutput, RawProviderOffer } from './types.ts';

const SELLERS: Record<string, Seller> = {
  aaNdc: {
    sellerId: 'sel-aa-ndc',
    slug: 'american-airlines-ndc',
    name: 'American Airlines (NDC Direct)',
    kind: 'airline_direct',
    affiliateDisclosed: false,
    supportNote: 'Direct NDC airline offer · ticketed and serviced by American Airlines.',
  },
  jetblue: {
    sellerId: 'sel-b6',
    slug: 'jetblue',
    name: 'JetBlue',
    kind: 'airline_direct',
    affiliateDisclosed: false,
    supportNote: 'Direct airline website · ticketed and serviced by JetBlue Airways.',
  },
  skyhopper: {
    sellerId: 'sel-skyhopper',
    slug: 'skyhopper-fare',
    name: 'SkyHopper Fare',
    kind: 'ota',
    affiliateDisclosed: true,
    supportNote: 'Third-party consolidator · affiliate disclosure applies; verify baggage at airline site.',
  },
  splitfly: {
    sellerId: 'sel-splitfly',
    slug: 'splitfly-tickets',
    name: 'SplitFly Tickets',
    kind: 'ota',
    affiliateDisclosed: true,
    supportNote: 'Virtual interlining agent · issues separate tickets with no carrier protection.',
  },
};

export class AeroDirectNdcAdapter implements FlightProviderAdapter {
  readonly providerId = 'aerodirect_ndc';
  readonly providerName = 'AeroDirect NDC';
  readonly credentialEnvKeys = ['AERODIRECT_API_KEY', 'AERODIRECT_PARTNER_ID'];
  readonly commercialAccessNote =
    'Simulated NDC fixture. Live NDC access requires direct airline bilateral onboarding or an authorized NDC aggregator contract.';

  async search(
    criteria: SearchCriteria,
    healthState: ProviderHealthState,
    nowIso: string = new Date().toISOString()
  ): Promise<ProviderSearchOutput> {
    if (healthState === 'outage') {
      return {
        providerId: this.providerId,
        providerName: this.providerName,
        status: 'failed',
        latencyMs: 95,
        offers: [],
        errorMessage: 'AeroDirect NDC endpoint returned 502 Bad Gateway. Partial results shown from healthy providers only.',
      };
    }

    const origins = resolveAirportList(criteria.originCode, criteria.includeNearbyOrigin);
    const dests = resolveAirportList(criteria.destinationCode, criteria.includeNearbyDestination);
    const paxTotal = Math.max(1, criteria.passengers.adults + criteria.passengers.children);
    const boundsCount = criteria.tripType === 'round_trip' ? 2 : 1;

    const offers: RawProviderOffer[] = [];
    const dep = criteria.departDate;
    const ret = criteria.returnDate || criteria.departDate;

    // 1. Canonical DUPLICATE of AA 117 / AA 118 JFK <-> LAX (Main Plus includes 1st checked bag!)
    // Total is $354 vs ClearFare Basic Economy ($258 + $130 bag = $388), so adding checked bag flips cheapest eligible offer!
    if (origins.includes('JFK') && dests.includes('LAX')) {
      const outSeg = buildSegment({
        segmentId: 'seg-ad-aa117-out',
        flightNumber: 'AA 117',
        marketingCarrier: { code: 'AA', name: 'American Airlines' },
        operatingCarrier: { code: 'AA', name: 'American Airlines' },
        originAirport: 'JFK',
        originTerminal: '8',
        destinationAirport: 'LAX',
        destinationTerminal: '4',
        depDate: dep,
        depLocalTime: '08:30',
        arrDateOffsetDays: 0,
        arrLocalTime: '11:45',
        cabin: criteria.cabin,
        aircraft: 'Airbus A321T',
      });
      const bounds = [buildBound('bnd-ad-aa117-out', 'outbound', [outSeg])];
      if (criteria.tripType === 'round_trip') {
        const inSeg = buildSegment({
          segmentId: 'seg-ad-aa118-in',
          flightNumber: 'AA 118',
          marketingCarrier: { code: 'AA', name: 'American Airlines' },
          operatingCarrier: { code: 'AA', name: 'American Airlines' },
          originAirport: 'LAX',
          originTerminal: '4',
          destinationAirport: 'JFK',
          destinationTerminal: '8',
          depDate: ret,
          depLocalTime: '13:15',
          arrDateOffsetDays: 0,
          arrLocalTime: '21:40',
          cabin: criteria.cabin,
          aircraft: 'Airbus A321T',
        });
        bounds.push(buildBound('bnd-ad-aa118-in', 'inbound', [inSeg]));
      }
      const journey = buildJourney('jrn-ad-aa117-jfk-lax', bounds);
      offers.push(
        makeOfferRecord({
          offerId: `ad-aa-aa117-plus-${criteria.tripType}`,
          providerId: this.providerId,
          providerName: this.providerName,
          providerOfferRef: 'AD-AA117-MAINPLUS',
          journey,
          seller: SELLERS.aaNdc,
          fareFamilyName: 'Main Plus (1 Bag Included)',
          bookingClass: 'N',
          isBasicEconomy: false,
          isSeparateTickets: false,
          conditions: {
            changeAllowed: 'included',
            changeFee: makeMoney(0, 'USD'),
            changeNotes: 'Free changes; fare difference applies.',
            refundAllowed: 'included',
            refundFee: makeMoney(0, 'USD'),
            refundNotes: 'Refundable Main Plus bundle.',
            seatAssignment: {
              status: 'advance_selection_included',
              notes: 'Preferred seat selection included via NDC bundle.',
            },
          },
          baggagePerSegment: buildBaggageForSegments(
            journey,
            { status: 'included', pieces: 1, notes: '1 personal item' },
            { status: 'included', pieces: 1, maxWeightLb: 40, notes: '1 carry-on bag included' },
            { status: 'included', pieces: 1, maxWeightLb: 50, notes: '1st checked bag included (50 lb)' }
          ),
          passengers: criteria.passengers,
          adultBaseMinor: criteria.tripType === 'round_trip' ? 28200 : 15200,
          adultTaxMinor: criteria.tripType === 'round_trip' ? 7200 : 3800,
          cabin: criteria.cabin,
          availableExtras: [],
          nowIso,
          expiresOffsetMinutes: 75,
        })
      );
    }

    // 2. Self-Transfer Separate Tickets + Airport Change (LGA -> ORD, ORD -> LAX, return LAX -> JFK)
    if (origins.includes('LGA') && dests.includes('LAX')) {
      const seg1 = buildSegment({
        segmentId: 'seg-nk310-lga-ord',
        flightNumber: 'NK 310',
        marketingCarrier: { code: 'NK', name: 'Spirit Airlines' },
        operatingCarrier: { code: 'NK', name: 'Spirit Airlines' },
        originAirport: 'LGA',
        originTerminal: 'A',
        destinationAirport: 'ORD',
        destinationTerminal: '3',
        depDate: dep,
        depLocalTime: '06:45',
        arrDateOffsetDays: 0,
        arrLocalTime: '08:25',
        cabin: criteria.cabin,
        aircraft: 'Airbus A320neo',
      });
      const seg2 = buildSegment({
        segmentId: 'seg-f9822-ord-lax',
        flightNumber: 'F9 822',
        marketingCarrier: { code: 'F9', name: 'Frontier Airlines' },
        operatingCarrier: { code: 'F9', name: 'Frontier Airlines' },
        originAirport: 'ORD',
        originTerminal: '5',
        destinationAirport: 'LAX',
        destinationTerminal: '1',
        depDate: dep,
        depLocalTime: '11:30',
        arrDateOffsetDays: 0,
        arrLocalTime: '14:10',
        cabin: criteria.cabin,
        aircraft: 'Airbus A321neo',
      });
      const bounds = [
        buildBound('bnd-split-out', 'outbound', [seg1, seg2], {
          isSelfTransfer: true,
          protectionNote:
            'Self-transfer on separate NK + F9 tickets. Missed connections are NOT protected by either airline.',
        }),
      ];
      if (criteria.tripType === 'round_trip') {
        const ret1 = buildSegment({
          segmentId: 'seg-f9825-lax-ord',
          flightNumber: 'F9 825',
          marketingCarrier: { code: 'F9', name: 'Frontier Airlines' },
          operatingCarrier: { code: 'F9', name: 'Frontier Airlines' },
          originAirport: 'LAX',
          originTerminal: '1',
          destinationAirport: 'ORD',
          destinationTerminal: '5',
          depDate: ret,
          depLocalTime: '13:00',
          arrDateOffsetDays: 0,
          arrLocalTime: '19:05',
          cabin: criteria.cabin,
          aircraft: 'Airbus A321neo',
        });
        const ret2 = buildSegment({
          segmentId: 'seg-nk315-ord-ewr',
          flightNumber: 'NK 315',
          marketingCarrier: { code: 'NK', name: 'Spirit Airlines' },
          operatingCarrier: { code: 'NK', name: 'Spirit Airlines' },
          originAirport: 'ORD',
          originTerminal: '3',
          destinationAirport: 'EWR',
          destinationTerminal: 'B',
          depDate: ret,
          depLocalTime: '21:10',
          arrDateOffsetDays: 1,
          arrLocalTime: '00:25',
          cabin: criteria.cabin,
          aircraft: 'Airbus A320neo',
        });
        bounds.push(
          buildBound('bnd-split-in', 'inbound', [ret1, ret2], {
            isSelfTransfer: true,
            protectionNote:
              'Self-transfer on separate tickets + returns to EWR (different NYC airport from LGA outbound).',
          })
        );
      }
      const journey = buildJourney('jrn-ad-self-transfer-nyc-lax', bounds);
      const carryFee = 4800 * boundsCount * paxTotal;
      const checkedFee = 5800 * boundsCount * paxTotal;
      offers.push(
        makeOfferRecord({
          offerId: `ad-split-selftransfer-${criteria.tripType}`,
          providerId: this.providerId,
          providerName: this.providerName,
          providerOfferRef: 'AD-SPLIT-NK-F9',
          journey,
          seller: SELLERS.splitfly,
          fareFamilyName: 'Separate Tickets Self-Transfer',
          bookingClass: 'O',
          isBasicEconomy: true,
          isSeparateTickets: true,
          conditions: {
            changeAllowed: 'not_included',
            changeNotes: 'Each ticket governed by separate carrier change penalties.',
            refundAllowed: 'not_included',
            refundNotes: 'Non-refundable separate tickets.',
            seatAssignment: {
              status: 'assigned_at_checkin',
              notes: 'Assigned at check-in; advance selection unavailable on this bundle.',
            },
          },
          baggagePerSegment: buildBaggageForSegments(
            journey,
            { status: 'included', pieces: 1, notes: '1 personal item only (18x14x8 in)' },
            { status: 'paid_extra', pieces: 1, feeIfExtra: makeMoney(carryFee, 'USD'), notes: '$48 per direction' },
            { status: 'paid_extra', pieces: 1, maxWeightLb: 40, feeIfExtra: makeMoney(checkedFee, 'USD'), notes: '$58 per direction (40 lb limit)' }
          ),
          passengers: criteria.passengers,
          adultBaseMinor: criteria.tripType === 'round_trip' ? 14800 : 7900,
          adultTaxMinor: criteria.tripType === 'round_trip' ? 5400 : 2800,
          cabin: criteria.cabin,
          availableExtras: [
            {
              extraId: 'ext-carry-on',
              kind: 'carry_on',
              label: 'Carry-on Bag',
              description: 'Required across both separate tickets',
              priceForTrip: makeMoney(carryFee, 'USD'),
              perPassenger: false,
            },
            {
              extraId: 'ext-checked-1',
              kind: 'checked_1',
              label: '1st Checked Bag (40 lb)',
              description: 'Paid per direction on separate carriers',
              priceForTrip: makeMoney(checkedFee, 'USD'),
              perPassenger: false,
            },
          ],
          nowIso,
          expiresOffsetMinutes: 40,
        })
      );
    }

    // 3. Missing Baggage Info Offer (SkyHopper Fare - flagged "incomplete_comparison"!)
    if (origins.includes('JFK') && dests.includes('LAX')) {
      const segOut = buildSegment({
        segmentId: 'seg-b623-out',
        flightNumber: 'B6 23',
        marketingCarrier: { code: 'B6', name: 'JetBlue' },
        operatingCarrier: { code: 'B6', name: 'JetBlue' },
        originAirport: 'JFK',
        originTerminal: '5',
        destinationAirport: 'LAX',
        destinationTerminal: '5',
        depDate: dep,
        depLocalTime: '14:20',
        arrDateOffsetDays: 0,
        arrLocalTime: '17:44',
        cabin: criteria.cabin,
        aircraft: 'Airbus A321 Mint/Core',
      });
      const bounds = [buildBound('bnd-b623-out', 'outbound', [segOut])];
      if (criteria.tripType === 'round_trip') {
        const segIn = buildSegment({
          segmentId: 'seg-b624-in',
          flightNumber: 'B6 24',
          marketingCarrier: { code: 'B6', name: 'JetBlue' },
          operatingCarrier: { code: 'B6', name: 'JetBlue' },
          originAirport: 'LAX',
          originTerminal: '5',
          destinationAirport: 'JFK',
          destinationTerminal: '5',
          depDate: ret,
          depLocalTime: '19:15',
          arrDateOffsetDays: 1,
          arrLocalTime: '03:38',
          cabin: criteria.cabin,
          aircraft: 'Airbus A321',
        });
        bounds.push(buildBound('bnd-b624-in', 'inbound', [segIn]));
      }
      const journey = buildJourney('jrn-ad-b6-missingbag', bounds);
      offers.push(
        makeOfferRecord({
          offerId: `ad-skyhopper-missingbag-${criteria.tripType}`,
          providerId: this.providerId,
          providerName: this.providerName,
          providerOfferRef: 'AD-SH-B6-UNKNOWN',
          journey,
          seller: SELLERS.skyhopper,
          fareFamilyName: 'Consolidator Unverified Fare',
          bookingClass: 'U',
          isBasicEconomy: true,
          isSeparateTickets: false,
          conditions: {
            changeAllowed: 'unknown',
            changeNotes: 'Change terms were not transmitted by consolidator feed.',
            refundAllowed: 'unknown',
            refundNotes: 'Refund conditions unavailable.',
            seatAssignment: {
              status: 'unknown',
              notes: 'Seat policy not returned by seller.',
            },
          },
          baggagePerSegment: buildBaggageForSegments(
            journey,
            { status: 'included', pieces: 1, notes: '1 personal item' },
            { status: 'unknown', notes: 'Carry-on eligibility not reported by consolidator' },
            { status: 'unknown', notes: 'Checked baggage fee unavailable from feed' }
          ),
          passengers: criteria.passengers,
          adultBaseMinor: criteria.tripType === 'round_trip' ? 18900 : 10200,
          adultTaxMinor: criteria.tripType === 'round_trip' ? 6200 : 3100,
          cabin: criteria.cabin,
          availableExtras: [],
          nowIso,
          expiresOffsetMinutes: 35,
        })
      );

      // 4. Expired Offer (already past expiry -> triggers refreshed alternatives on revalidation!)
      const expOut = buildSegment({
        segmentId: 'seg-b6523-out',
        flightNumber: 'B6 523',
        marketingCarrier: { code: 'B6', name: 'JetBlue' },
        operatingCarrier: { code: 'B6', name: 'JetBlue' },
        originAirport: 'JFK',
        originTerminal: '5',
        destinationAirport: 'LAX',
        destinationTerminal: '5',
        depDate: dep,
        depLocalTime: '17:05',
        arrDateOffsetDays: 0,
        arrLocalTime: '20:28',
        cabin: criteria.cabin,
        aircraft: 'Airbus A321',
      });
      const expBounds = [buildBound('bnd-b6523-out', 'outbound', [expOut])];
      if (criteria.tripType === 'round_trip') {
        const expIn = buildSegment({
          segmentId: 'seg-b6524-in',
          flightNumber: 'B6 524',
          marketingCarrier: { code: 'B6', name: 'JetBlue' },
          operatingCarrier: { code: 'B6', name: 'JetBlue' },
          originAirport: 'LAX',
          originTerminal: '5',
          destinationAirport: 'JFK',
          destinationTerminal: '5',
          depDate: ret,
          depLocalTime: '09:40',
          arrDateOffsetDays: 0,
          arrLocalTime: '18:05',
          cabin: criteria.cabin,
          aircraft: 'Airbus A321',
        });
        expBounds.push(buildBound('bnd-b6524-in', 'inbound', [expIn]));
      }
      const expJourney = buildJourney('jrn-ad-b6-expired', expBounds);
      offers.push(
        makeOfferRecord({
          offerId: `ad-b6-jfk-lax-expired-${criteria.tripType}`,
          providerId: this.providerId,
          providerName: this.providerName,
          providerOfferRef: 'AD-B6-523-EXPIRED',
          journey: expJourney,
          seller: SELLERS.jetblue,
          fareFamilyName: 'Blue (Stale Snapshot)',
          bookingClass: 'K',
          isBasicEconomy: false,
          isSeparateTickets: false,
          conditions: {
            changeAllowed: 'included',
            changeFee: makeMoney(0, 'USD'),
            changeNotes: 'No change fee.',
            refundAllowed: 'not_included',
            refundNotes: 'Travel bank credit only.',
            seatAssignment: {
              status: 'advance_selection_included',
              notes: 'Advance seat selection included.',
            },
          },
          baggagePerSegment: buildBaggageForSegments(
            expJourney,
            { status: 'included', pieces: 1, notes: '1 personal item' },
            { status: 'included', pieces: 1, maxWeightLb: 35, notes: '1 carry-on included' },
            {
              status: 'paid_extra',
              pieces: 1,
              maxWeightLb: 50,
              feeIfExtra: makeMoney(3500 * boundsCount * paxTotal, 'USD'),
              notes: '$35 per direction',
            }
          ),
          passengers: criteria.passengers,
          adultBaseMinor: criteria.tripType === 'round_trip' ? 23600 : 12600,
          adultTaxMinor: criteria.tripType === 'round_trip' ? 6800 : 3400,
          cabin: criteria.cabin,
          availableExtras: [
            {
              extraId: 'ext-checked-1',
              kind: 'checked_1',
              label: '1st Checked Bag (50 lb)',
              description: '$35 each way',
              priceForTrip: makeMoney(3500 * boundsCount * paxTotal, 'USD'),
              perPassenger: false,
            },
          ],
          nowIso,
          expiresOffsetMinutes: -12, // Already expired!
        })
      );
    }

    // 5. Generic NDC Direct Route Generator for MIA, CHI, FAT, BOS, TYO, etc.
    if (offers.length === 0 || (!origins.includes('JFK') || !dests.includes('LAX'))) {
      const o = origins[0];
      const d = dests[0];
      if (o && d && o !== d) {
        const directSegOut = buildSegment({
          segmentId: `seg-ad-gen-${o}-${d}-out`,
          flightNumber: 'AA 2410',
          marketingCarrier: { code: 'AA', name: 'American Airlines' },
          operatingCarrier: { code: 'AA', name: 'American Airlines' },
          originAirport: o,
          originTerminal: 'A',
          destinationAirport: d,
          destinationTerminal: '1',
          depDate: dep,
          depLocalTime: '09:15',
          arrDateOffsetDays: o === 'SFO' && d === 'HND' ? 1 : 0,
          arrLocalTime: o === 'SFO' && d === 'HND' ? '13:45' : '12:55',
          cabin: criteria.cabin,
          aircraft: 'Boeing 737 MAX 8',
        });
        const bounds = [buildBound(`bnd-ad-gen-${o}-${d}-out`, 'outbound', [directSegOut])];
        if (criteria.tripType === 'round_trip') {
          const directSegIn = buildSegment({
            segmentId: `seg-ad-gen-${d}-${o}-in`,
            flightNumber: 'AA 2415',
            marketingCarrier: { code: 'AA', name: 'American Airlines' },
            operatingCarrier: { code: 'AA', name: 'American Airlines' },
            originAirport: d,
            originTerminal: '1',
            destinationAirport: o,
            destinationTerminal: 'A',
            depDate: ret,
            depLocalTime: '15:20',
            arrDateOffsetDays: 0,
            arrLocalTime: '18:55',
            cabin: criteria.cabin,
            aircraft: 'Boeing 737 MAX 8',
          });
          bounds.push(buildBound(`bnd-ad-gen-${d}-${o}-in`, 'inbound', [directSegIn]));
        }
        const genJourney = buildJourney(`jrn-ad-${o}-${d}`, bounds);
        offers.push(
          makeOfferRecord({
            offerId: `ad-ndc-plus-${o.toLowerCase()}-${d.toLowerCase()}-${criteria.tripType}`,
            providerId: this.providerId,
            providerName: this.providerName,
            providerOfferRef: `AD-NDC-${o}-${d}`,
            journey: genJourney,
            seller: SELLERS.aaNdc,
            fareFamilyName: 'Main Plus (1 Checked Bag Included)',
            bookingClass: 'N',
            isBasicEconomy: false,
            isSeparateTickets: false,
            conditions: {
              changeAllowed: 'included',
              changeFee: makeMoney(0, 'USD'),
              changeNotes: 'No change fee.',
              refundAllowed: 'included',
              refundFee: makeMoney(0, 'USD'),
              refundNotes: 'Refundable Main Plus fare.',
              seatAssignment: {
                status: 'advance_selection_included',
                notes: 'Advance seat selection included.',
              },
            },
            baggagePerSegment: buildBaggageForSegments(
              genJourney,
              { status: 'included', pieces: 1, notes: '1 personal item' },
              { status: 'included', pieces: 1, maxWeightLb: 40, notes: '1 carry-on included' },
              { status: 'included', pieces: 1, maxWeightLb: 50, notes: '1st checked bag included' }
            ),
            passengers: criteria.passengers,
            adultBaseMinor: criteria.tripType === 'round_trip' ? 23400 : 12900,
            adultTaxMinor: criteria.tripType === 'round_trip' ? 5400 : 2900,
            cabin: criteria.cabin,
            availableExtras: [],
            nowIso,
            expiresOffsetMinutes: 75,
          })
        );
      }
    }

    if (healthState === 'degraded') {
      return {
        providerId: this.providerId,
        providerName: this.providerName,
        status: 'partial',
        latencyMs: 840,
        offers: offers.slice(0, 1),
        errorMessage: 'AeroDirect NDC rate-limited secondary fares; partial offers returned.',
      };
    }

    return {
      providerId: this.providerId,
      providerName: this.providerName,
      status: 'ok',
      latencyMs: 140,
      offers,
    };
  }

  async revalidateOffer(
    offer: Offer,
    healthState: ProviderHealthState,
    nowIso: string = new Date().toISOString()
  ): Promise<RevalidationResult> {
    const affiliateDisclosure = offer.seller.affiliateDisclosed
      ? `Affiliate notice: airunion may earn a referral fee if you purchase after clicking through to ${offer.seller.name}. Clicking through does not create a reservation.`
      : `Direct referral: clicking through takes you to ${offer.seller.name} to complete booking. Clicking through does not create a reservation on airunion.`;

    if (healthState === 'outage') {
      return {
        offerId: offer.offerId,
        status: 'unavailable',
        checkedAt: nowIso,
        previousTotal: offer.evaluation.comparableTotal,
        updatedTotal: offer.evaluation.comparableTotal,
        priceDelta: makeMoney(0, offer.evaluation.comparableTotal.currency),
        requiresFreshSelection: false,
        message: 'AeroDirect NDC is currently unreachable.',
        affiliateDisclosure,
      };
    }

    if (offer.isExpired || offer.offerId.includes('expired')) {
      return {
        offerId: offer.offerId,
        status: 'expired',
        checkedAt: nowIso,
        previousTotal: offer.evaluation.comparableTotal,
        updatedTotal: offer.evaluation.comparableTotal,
        priceDelta: makeMoney(0, offer.evaluation.comparableTotal.currency),
        requiresFreshSelection: true,
        message: 'This fare snapshot expired. Review refreshed comparable offers below before continuing.',
        affiliateDisclosure,
      };
    }

    return {
      offerId: offer.offerId,
      status: 'confirmed',
      checkedAt: nowIso,
      previousTotal: offer.evaluation.comparableTotal,
      updatedTotal: offer.evaluation.comparableTotal,
      priceDelta: makeMoney(0, offer.evaluation.comparableTotal.currency),
      requiresFreshSelection: false,
      message: `NDC live offer revalidated at ${offer.evaluation.comparableTotal.amount} ${offer.evaluation.comparableTotal.currency}.`,
      referralUrl: offer.referralUrl,
      affiliateDisclosure,
    };
  }
}
