import { getLocationByCode } from '../data/airports.ts';
import { buildCanonicalJourneyKey } from '../domain/comparison.ts';
import { addMoney, makeMoney, multiplyMoney, roundHalfUp } from '../domain/money.ts';
import {
  calculateAbsoluteDurationMinutes,
  calculateLocalDayOffset,
  detectDstTransition,
  getLocalParts,
} from '../domain/timezone.ts';
import type {
  BaggageRule,
  CabinClass,
  CarrierInfo,
  ConnectionDetail,
  FareConditions,
  FlightSegment,
  Journey,
  JourneyBound,
  PassengerComposition,
  PassengerFareLine,
  PricedExtraOption,
  SegmentBaggageAllowance,
  Seller,
} from '../domain/types.ts';
import type { RawProviderOffer } from './types.ts';

/**
 * Convert local wall-clock date/time in an IANA timezone to a UTC ISO timestamp.
 */
export function localWallTimeToUtcIso(
  dateStr: string,
  time24: string,
  ianaTimezone: string
): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const [hh, mm] = time24.split(':').map(Number);
  const naiveUtcMs = Date.UTC(y, m - 1, d, hh, mm, 0);

  const computeOffsetMs = (utcMs: number) => {
    const dt = new Date(utcMs);
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: ianaTimezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).formatToParts(dt);
    const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0);
    const localAsUtc = Date.UTC(
      get('year'),
      get('month') - 1,
      get('day'),
      get('hour') === 24 ? 0 : get('hour'),
      get('minute'),
      get('second')
    );
    return localAsUtc - utcMs;
  };

  const firstOffset = computeOffsetMs(naiveUtcMs);
  const candidate = naiveUtcMs - firstOffset;
  const refinedOffset = computeOffsetMs(candidate);
  return new Date(naiveUtcMs - refinedOffset).toISOString();
}

export interface SegmentBlueprint {
  segmentId: string;
  flightNumber: string;
  marketingCarrier: CarrierInfo;
  operatingCarrier: CarrierInfo;
  originAirport: string;
  originTerminal?: string;
  destinationAirport: string;
  destinationTerminal?: string;
  depDate: string;
  depLocalTime: string;
  arrDateOffsetDays: number;
  arrLocalTime: string;
  cabin: CabinClass;
  aircraft: string;
}

export function buildSegment(bp: SegmentBlueprint): FlightSegment {
  const origMeta = getLocationByCode(bp.originAirport);
  const destMeta = getLocationByCode(bp.destinationAirport);
  const originTimezone = origMeta?.timezone ?? 'America/New_York';
  const destinationTimezone = destMeta?.timezone ?? 'America/Los_Angeles';

  const depUtc = localWallTimeToUtcIso(bp.depDate, bp.depLocalTime, originTimezone);
  const arrDateMs = Date.parse(`${bp.depDate}T12:00:00Z`) + bp.arrDateOffsetDays * 86400000;
  const arrDateStr = new Date(arrDateMs).toISOString().slice(0, 10);
  const arrUtc = localWallTimeToUtcIso(arrDateStr, bp.arrLocalTime, destinationTimezone);

  const durationMinutes = calculateAbsoluteDurationMinutes(depUtc, arrUtc);
  const dayOffsetFromDeparture = calculateLocalDayOffset(
    depUtc,
    originTimezone,
    arrUtc,
    destinationTimezone
  );
  const depParts = getLocalParts(depUtc, originTimezone);
  const arrParts = getLocalParts(arrUtc, destinationTimezone);

  const crossesDateLine =
    (origMeta?.countryCode === 'US' && destMeta?.countryCode === 'JP') ||
    (origMeta?.countryCode === 'JP' && destMeta?.countryCode === 'US');

  return {
    segmentId: bp.segmentId,
    flightNumber: bp.flightNumber,
    marketingCarrier: bp.marketingCarrier,
    operatingCarrier: bp.operatingCarrier,
    originAirport: bp.originAirport,
    originTerminal: bp.originTerminal,
    originTimezone,
    destinationAirport: bp.destinationAirport,
    destinationTerminal: bp.destinationTerminal,
    destinationTimezone,
    departureUtc: depUtc,
    arrivalUtc: arrUtc,
    departureLocal: `${depParts.dateStr}T${depParts.timeStr}`,
    arrivalLocal: `${arrParts.dateStr}T${arrParts.timeStr}`,
    durationMinutes,
    cabin: bp.cabin,
    aircraft: bp.aircraft,
    dayOffsetFromDeparture,
    crossesDateLine,
    dstTransitioned: detectDstTransition(depUtc, originTimezone, arrUtc, destinationTimezone),
  };
}

export function buildBound(
  boundId: string,
  direction: 'outbound' | 'inbound',
  segments: FlightSegment[],
  options?: {
    isSelfTransfer?: boolean;
    protectionNote?: string;
  }
): JourneyBound {
  const connections: ConnectionDetail[] = [];
  for (let i = 0; i < segments.length - 1; i++) {
    const prev = segments[i];
    const next = segments[i + 1];
    const layoverMin = calculateAbsoluteDurationMinutes(prev.arrivalUtc, next.departureUtc);
    const isAirportChange = prev.destinationAirport !== next.originAirport;
    const prevArrDate = prev.arrivalLocal.slice(0, 10);
    const nextDepDate = next.departureLocal.slice(0, 10);
    const isOvernight = prevArrDate !== nextDepDate;
    const isSelfTransfer = Boolean(options?.isSelfTransfer);

    connections.push({
      afterSegmentId: prev.segmentId,
      atAirport: prev.destinationAirport,
      toAirport: next.originAirport,
      durationMinutes: layoverMin,
      isAirportChange,
      isOvernight,
      isSelfTransfer,
      isProtectedConnection: !isSelfTransfer,
      protectionNote: isSelfTransfer
        ? options?.protectionNote ??
          'Separate tickets: no missed-connection protection. You must collect and re-check baggage.'
        : options?.protectionNote ??
          'Single-ticket protected connection covered by carrier rebooking rules.',
    });
  }

  const totalDurationMinutes = calculateAbsoluteDurationMinutes(
    segments[0].departureUtc,
    segments[segments.length - 1].arrivalUtc
  );

  const cabinSet = new Set(segments.map((s) => s.cabin));
  const hasMixedCabins = cabinSet.size > 1;
  const hasOvernightArrival = segments.some((s) => s.dayOffsetFromDeparture > 0);
  const hasAirportChange = connections.some((c) => c.isAirportChange);
  const hasSelfTransfer = connections.some((c) => c.isSelfTransfer);

  return {
    boundId,
    direction,
    originAirport: segments[0].originAirport,
    destinationAirport: segments[segments.length - 1].destinationAirport,
    segments,
    connections,
    totalDurationMinutes,
    stops: Math.max(0, segments.length - 1),
    hasMixedCabins,
    hasOvernightArrival,
    hasAirportChange,
    hasSelfTransfer,
  };
}

export function buildJourney(journeyId: string, bounds: JourneyBound[]): Journey {
  const totalDurationMinutes = bounds.reduce((sum, b) => sum + b.totalDurationMinutes, 0);
  const maxStops = Math.max(...bounds.map((b) => b.stops));
  const partial: Journey = {
    journeyId,
    canonicalKey: '',
    bounds,
    totalDurationMinutes,
    maxStops,
  };
  partial.canonicalKey = buildCanonicalJourneyKey(partial);
  return partial;
}

export function buildPassengerPricing(
  passengers: PassengerComposition,
  adultBaseMinor: number,
  adultTaxMinor: number,
  cabin: CabinClass,
  options?: {
    childDiscountPct?: number; // e.g. 85 means child base is 85% of adult base
    infantFarePct?: number;    // e.g. 10 means lap infant is 10% of adult base
    explicitSeparateChildPricing?: boolean;
  }
): {
  passengerLines: PassengerFareLine[];
  baseFareTotal: ReturnType<typeof makeMoney>;
  taxesAndMandatoryTotal: ReturnType<typeof makeMoney>;
} {
  const cabinMultiplier =
    cabin === 'first'
      ? 245
      : cabin === 'business'
      ? 185
      : cabin === 'premium_economy'
      ? 135
      : 100;

  const adjAdultBase = roundHalfUp(adultBaseMinor * cabinMultiplier, 100);
  const adjAdultTax = adultTaxMinor + (cabinMultiplier > 100 ? 1800 : 0);

  const lines: PassengerFareLine[] = [];
  let baseTotal = makeMoney(0, 'USD');
  let taxTotal = makeMoney(0, 'USD');

  if (passengers.adults > 0) {
    const baseEach = makeMoney(adjAdultBase, 'USD');
    const taxEach = makeMoney(adjAdultTax, 'USD');
    const mandatoryEach = makeMoney(0, 'USD');
    const subEach = addMoney(baseEach, taxEach);
    lines.push({
      passengerType: 'adult',
      count: passengers.adults,
      baseFareEach: baseEach,
      taxesEach: taxEach,
      mandatoryChargesEach: mandatoryEach,
      subtotal: multiplyMoney(subEach, passengers.adults),
      pricingBasis: 'explicit_per_pax_type',
    });
    baseTotal = addMoney(baseTotal, multiplyMoney(baseEach, passengers.adults));
    taxTotal = addMoney(taxTotal, multiplyMoney(taxEach, passengers.adults));
  }

  if (passengers.children > 0) {
    const pct = options?.childDiscountPct ?? 82;
    const childBase = roundHalfUp(adjAdultBase * pct, 100);
    const childTax = Math.max(2200, adjAdultTax - 600);
    const baseEach = makeMoney(childBase, 'USD');
    const taxEach = makeMoney(childTax, 'USD');
    const subEach = addMoney(baseEach, taxEach);
    lines.push({
      passengerType: 'child',
      count: passengers.children,
      baseFareEach: baseEach,
      taxesEach: taxEach,
      mandatoryChargesEach: makeMoney(0, 'USD'),
      subtotal: multiplyMoney(subEach, passengers.children),
      pricingBasis: options?.explicitSeparateChildPricing === false ? 'uniform_adult_derived' : 'explicit_per_pax_type',
    });
    baseTotal = addMoney(baseTotal, multiplyMoney(baseEach, passengers.children));
    taxTotal = addMoney(taxTotal, multiplyMoney(taxEach, passengers.children));
  }

  if (passengers.infants > 0) {
    const infPct = options?.infantFarePct ?? 10;
    const infBase = roundHalfUp(adjAdultBase * infPct, 100);
    const infTax = 1400; // Lap infant security/airport facility fee
    const baseEach = makeMoney(infBase, 'USD');
    const taxEach = makeMoney(infTax, 'USD');
    const subEach = addMoney(baseEach, taxEach);
    lines.push({
      passengerType: 'infant',
      count: passengers.infants,
      baseFareEach: baseEach,
      taxesEach: taxEach,
      mandatoryChargesEach: makeMoney(0, 'USD'),
      subtotal: multiplyMoney(subEach, passengers.infants),
      pricingBasis: 'explicit_per_pax_type',
    });
    baseTotal = addMoney(baseTotal, multiplyMoney(baseEach, passengers.infants));
    taxTotal = addMoney(taxTotal, multiplyMoney(taxEach, passengers.infants));
  }

  return { passengerLines: lines, baseFareTotal: baseTotal, taxesAndMandatoryTotal: taxTotal };
}

export function buildBaggageForSegments(
  journey: Journey,
  personalItem: BaggageRule,
  carryOn: BaggageRule,
  checkedBag: BaggageRule
): SegmentBaggageAllowance[] {
  const result: SegmentBaggageAllowance[] = [];
  for (const bound of journey.bounds) {
    for (const seg of bound.segments) {
      result.push({
        segmentId: seg.segmentId,
        personalItem,
        carryOn,
        checkedBag,
      });
    }
  }
  return result;
}

export function makeOfferRecord(params: {
  offerId: string;
  providerId: string;
  providerName: string;
  providerOfferRef: string;
  journey: Journey;
  seller: Seller;
  fareFamilyName: string;
  bookingClass: string;
  isBasicEconomy: boolean;
  isSeparateTickets: boolean;
  conditions: FareConditions;
  baggagePerSegment: SegmentBaggageAllowance[];
  passengers: PassengerComposition;
  adultBaseMinor: number;
  adultTaxMinor: number;
  cabin: CabinClass;
  availableExtras: PricedExtraOption[];
  nowIso: string;
  expiresOffsetMinutes: number;
  childDiscountPct?: number;
}): RawProviderOffer {
  const { passengerLines, baseFareTotal, taxesAndMandatoryTotal } = buildPassengerPricing(
    params.passengers,
    params.adultBaseMinor,
    params.adultTaxMinor,
    params.cabin,
    { childDiscountPct: params.childDiscountPct }
  );

  const collectedMs = Date.parse(params.nowIso);
  const expiresIso = new Date(collectedMs + params.expiresOffsetMinutes * 60000).toISOString();

  return {
    offerId: params.offerId,
    journey: params.journey,
    seller: params.seller,
    fareProduct: {
      fareFamilyName: params.fareFamilyName,
      bookingClass: params.bookingClass,
      isBasicEconomy: params.isBasicEconomy,
      isSeparateTickets: params.isSeparateTickets,
      conditions: params.conditions,
      baggagePerSegment: params.baggagePerSegment,
    },
    observation: {
      observationId: `obs-${params.offerId}`,
      providerId: params.providerId,
      providerName: params.providerName,
      providerOfferRef: params.providerOfferRef,
      collectedAt: params.nowIso,
      expiresAt: expiresIso,
      revalidationStatus: 'unverified',
      passengerLines,
      baseFareTotal,
      taxesAndMandatoryTotal,
      availableExtras: params.availableExtras,
    },
    referralUrl: `/supplier/${params.seller.slug}?offerId=${encodeURIComponent(params.offerId)}&ref=${encodeURIComponent(params.providerOfferRef)}`,
  };
}
