import destChicago from '@/src/assets/images/dest_chicago_1795514892913.jpg';
import destLosAngeles from '@/src/assets/images/dest_los_angeles_1795514891828.jpg';
import destMiami from '@/src/assets/images/dest_miami_1795514893092.jpg';
import heroAirplaneSky from '@/src/assets/images/hero_airplane_sky_1795514892462.jpg';
import inspBeachEscapes from '@/src/assets/images/insp_beach_escapes_1795514894103.jpg';
import inspCityWeekends from '@/src/assets/images/insp_city_weekends_1795514893539.jpg';
import inspNationalParks from '@/src/assets/images/insp_national_parks_1795514893789.jpg';

export const AIRUNION_MEDIA = {
  hero: heroAirplaneSky,
  la: destLosAngeles,
  miami: destMiami,
  chicago: destChicago,
  city_weekends: inspCityWeekends,
  beach_escapes: inspBeachEscapes,
  national_parks: inspNationalParks,
} as const;
