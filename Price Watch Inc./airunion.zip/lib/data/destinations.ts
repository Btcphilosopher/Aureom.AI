export interface DestinationItem {
  id: string;
  title: string;
  subtitle: string;
  category: 'featured' | 'city_weekends' | 'beach_escapes' | 'national_parks';
  defaultOriginCode: string;
  destinationCode: string;
  destinationLabel: string;
  imageKey: 'la' | 'miami' | 'chicago' | 'city_weekends' | 'beach_escapes' | 'national_parks';
  /** Honest disclosure — especially for national parks where airfare ends at commercial airports */
  airportDisclosure: string;
}

export const DEFAULT_DESTINATIONS: DestinationItem[] = [
  {
    id: 'dest-los-angeles',
    title: 'Los Angeles',
    subtitle: 'Nonstop and 1-stop transcontinental fares into LAX or nearby Southern California hubs.',
    category: 'featured',
    defaultOriginCode: 'NYC',
    destinationCode: 'LAX',
    destinationLabel: 'Los Angeles (LAX)',
    imageKey: 'la',
    airportDisclosure: 'Flights terminate at Los Angeles International Airport (LAX), with optional nearby BUR/LGB expansion.',
  },
  {
    id: 'dest-miami',
    title: 'Miami',
    subtitle: 'East Coast flights into Miami International (MIA) with transparent carry-on and seat comparison.',
    category: 'featured',
    defaultOriginCode: 'NYC',
    destinationCode: 'MIA',
    destinationLabel: 'Miami (MIA)',
    imageKey: 'miami',
    airportDisclosure: 'Flights terminate at Miami International Airport (MIA), with optional nearby Fort Lauderdale (FLL) expansion.',
  },
  {
    id: 'dest-chicago',
    title: 'Chicago',
    subtitle: "Compare flights across both O'Hare (ORD) and Midway (MDW) with clear baggage rules.",
    category: 'featured',
    defaultOriginCode: 'NYC',
    destinationCode: 'CHI',
    destinationLabel: 'Chicago (CHI)',
    imageKey: 'chicago',
    airportDisclosure: "Metro code CHI searches both O'Hare (ORD) and Midway (MDW).",
  },
  {
    id: 'insp-city-weekends',
    title: 'City weekends',
    subtitle: 'Compare Friday-to-Monday itineraries across major US metropolitan airports.',
    category: 'city_weekends',
    defaultOriginCode: 'LAX',
    destinationCode: 'NYC',
    destinationLabel: 'New York (NYC)',
    imageKey: 'city_weekends',
    airportDisclosure: 'Metro code NYC includes JFK, LGA, and EWR. Check airport selection before booking.',
  },
  {
    id: 'insp-beach-escapes',
    title: 'Beach escapes',
    subtitle: 'Coastal routes to Miami and Honolulu with side-by-side checked bag and seat fees.',
    category: 'beach_escapes',
    defaultOriginCode: 'NYC',
    destinationCode: 'MIA',
    destinationLabel: 'Miami (MIA)',
    imageKey: 'beach_escapes',
    airportDisclosure: 'Commercial flights land at MIA (or HNL for Oahu searches). Local ground transport is arranged separately.',
  },
  {
    id: 'insp-national-parks',
    title: 'National park adventures',
    subtitle: 'Search commercial flights to regional airports such as Fresno (FAT) or Bozeman (BZN).',
    category: 'national_parks',
    defaultOriginCode: 'NYC',
    destinationCode: 'FAT',
    destinationLabel: 'Fresno (FAT)',
    imageKey: 'national_parks',
    airportDisclosure:
      'airunion compares commercial airfare only to commercial airports (such as FAT or BZN). Park entry, driving times, and ground transfers are separate and not included.',
  },
];
