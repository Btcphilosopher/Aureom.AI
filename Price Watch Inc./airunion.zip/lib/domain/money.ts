import type { CurrencyCode, DecimalMoney, FxConversionDisclosure } from './types.ts';

export const FX_RATE_SOURCE = 'Federal Reserve H.10 / ECB Reference Snapshot';
export const FX_RATE_TIMESTAMP = '2026-11-24T08:00:00Z';

/**
 * Exchange rates relative to 1 USD expressed as scaled integer per 10,000 units
 * so all currency conversions stay deterministic without IEEE-754 float drift.
 */
const USD_TO_CURRENCY_SCALED: Record<CurrencyCode, { scaled: number; display: string }> = {
  USD: { scaled: 10000, display: '1.0000' },
  CAD: { scaled: 13850, display: '1.3850' },
  EUR: { scaled: 9420, display: '0.9420' },
  GBP: { scaled: 7910, display: '0.7910' },
};

const CURRENCY_SYMBOLS: Record<CurrencyCode, string> = {
  USD: '$',
  CAD: 'CA$',
  EUR: '€',
  GBP: '£',
};

export function roundHalfUp(numerator: number, denominator: number): number {
  if (denominator <= 0) throw new Error('Denominator must be positive');
  const sign = numerator < 0 ? -1 : 1;
  const absNum = Math.abs(numerator);
  const quotient = Math.floor((absNum * 2 + denominator) / (2 * denominator));
  return sign * quotient;
}

export function makeMoney(minorUnits: number, currency: CurrencyCode = 'USD'): DecimalMoney {
  const safeMinor = Math.round(minorUnits);
  const sign = safeMinor < 0 ? '-' : '';
  const absMinor = Math.abs(safeMinor);
  const whole = Math.floor(absMinor / 100);
  const cents = String(absMinor % 100).padStart(2, '0');
  return {
    minorUnits: safeMinor,
    currency,
    amount: `${sign}${whole}.${cents}`,
  };
}

export function moneyFromDecimalString(decimalStr: string, currency: CurrencyCode = 'USD'): DecimalMoney {
  const cleaned = decimalStr.trim();
  if (!/^-?\d+(\.\d{1,2})?$/.test(cleaned)) {
    throw new Error(`Invalid decimal money string: ${decimalStr}`);
  }
  const negative = cleaned.startsWith('-');
  const unsigned = negative ? cleaned.slice(1) : cleaned;
  const [wholePart, fracPart = ''] = unsigned.split('.');
  const cents = Number(wholePart) * 100 + Number(fracPart.padEnd(2, '0'));
  return makeMoney(negative ? -cents : cents, currency);
}

export function addMoney(a: DecimalMoney, b: DecimalMoney): DecimalMoney {
  if (a.currency !== b.currency) {
    throw new Error(`Cannot add different currencies directly: ${a.currency} vs ${b.currency}`);
  }
  return makeMoney(a.minorUnits + b.minorUnits, a.currency);
}

export function subtractMoney(a: DecimalMoney, b: DecimalMoney): DecimalMoney {
  if (a.currency !== b.currency) {
    throw new Error(`Cannot subtract different currencies directly: ${a.currency} vs ${b.currency}`);
  }
  return makeMoney(a.minorUnits - b.minorUnits, a.currency);
}

export function multiplyMoney(m: DecimalMoney, factor: number): DecimalMoney {
  if (!Number.isInteger(factor) || factor < 0) {
    throw new Error(`Factor must be a non-negative integer, got ${factor}`);
  }
  return makeMoney(m.minorUnits * factor, m.currency);
}

export function convertCurrency(
  original: DecimalMoney,
  targetCurrency: CurrencyCode
): FxConversionDisclosure | null {
  if (original.currency === targetCurrency) {
    return null;
  }
  const fromScale = USD_TO_CURRENCY_SCALED[original.currency].scaled;
  const toScale = USD_TO_CURRENCY_SCALED[targetCurrency].scaled;
  const convertedMinor = roundHalfUp(original.minorUnits * toScale, fromScale);
  const rateNumber = toScale / fromScale;
  return {
    original,
    converted: makeMoney(convertedMinor, targetCurrency),
    rate: `1 ${original.currency} = ${rateNumber.toFixed(4)} ${targetCurrency}`,
    rateSource: FX_RATE_SOURCE,
    rateTimestamp: FX_RATE_TIMESTAMP,
  };
}

export function formatMoney(money: DecimalMoney, opts?: { hideZeroCents?: boolean }): string {
  const symbol = CURRENCY_SYMBOLS[money.currency];
  const negative = money.minorUnits < 0;
  const absMinor = Math.abs(money.minorUnits);
  const whole = Math.floor(absMinor / 100).toLocaleString('en-US');
  const cents = absMinor % 100;
  if (opts?.hideZeroCents && cents === 0) {
    return `${negative ? '-' : ''}${symbol}${whole}`;
  }
  return `${negative ? '-' : ''}${symbol}${whole}.${String(cents).padStart(2, '0')}`;
}
