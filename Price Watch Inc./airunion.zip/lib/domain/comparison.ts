import { addMoney, convertCurrency, makeMoney, roundHalfUp } from './money.ts';
import type {
  BaggageRequirement,
  CabinClass,
  ComparisonEvaluation,
  CurrencyCode,
  ItineraryGroup,
  Journey,
  Offer,
  PricedExtraOption,
  SearchCriteria,
  SeatPreference,
} from './types.ts';

const CABIN_RANK: Record<CabinClass, number> = {
  economy: 1,
  premium_economy: 2,
  business: 3,
  first: 4,
};

export const RECOMMENDED_FORMULA_TEXT =
  'Recommended score = 0.55 × normalized comparable total + 0.25 × normalized duration + 0.12 × stops penalty + 0.08 × fare completeness penalty. Eligible offers always rank ahead of incomplete or ineligible offers.';

export function buildCanonicalJourneyKey(journey: Journey): string {
  const boundKeys = journey.bounds.map((bound) => {
    const segKeys = bound.segments.map((seg) => {
      const depMinute = seg.departureUtc.slice(0, 16);
      const arrMinute = seg.arrivalUtc.slice(0, 16);
      return `${seg.operatingCarrier.code}:${seg.originAirport}-${seg.destinationAirport}:${depMinute}-${arrMinute}`;
    });
    return `${bound.direction}[${segKeys.join('>')}]`;
  });
  return boundKeys.join('|');
}

function findMatchingExtra(
  extras: PricedExtraOption[],
  kind: PricedExtraOption['kind']
): PricedExtraOption | undefined {
  return extras.find((e) => e.kind === kind);
}

export function evaluateOfferForCriteria(
  offer: Omit<Offer, 'evaluation' | 'recommendedScore' | 'isExpired'>,
  criteria: SearchCriteria,
  nowIso: string = new Date().toISOString()
): { evaluation: ComparisonEvaluation; isExpired: boolean } {
  const reasons: string[] = [];
  const missingDataFields: string[] = [];
  let ineligible = false;
  let incomplete = false;

  const basePlusMandatory = addMoney(
    offer.observation.baseFareTotal,
    offer.observation.taxesAndMandatoryTotal
  );
  const baseCurrency = basePlusMandatory.currency;
  let requiredExtrasTotal = makeMoney(0, baseCurrency);

  // 1. Check cabin compatibility across every segment
  const requestedCabinRank = CABIN_RANK[criteria.cabin];
  for (const bound of offer.journey.bounds) {
    for (const seg of bound.segments) {
      if (CABIN_RANK[seg.cabin] < requestedCabinRank) {
        ineligible = true;
        reasons.push(
          `Segment ${seg.originAirport}→${seg.destinationAirport} (${seg.flightNumber}) is ${seg.cabin.replace('_', ' ')} rather than requested ${criteria.cabin.replace('_', ' ')}`
        );
      }
    }
  }

  // 2. Check baggage requirement across EVERY segment individually
  const reqBag: BaggageRequirement = criteria.requiredBaggage;
  const baggageList = offer.fareProduct.baggagePerSegment;
  if (!baggageList || baggageList.length === 0) {
    incomplete = true;
    missingDataFields.push('baggage_allowance');
    reasons.push('Baggage rules are not supplied by this provider');
  } else {
    // Personal item check (always required for baseline comparison)
    const anyUnknownPersonal = baggageList.some((b) => b.personalItem.status === 'unknown');
    if (anyUnknownPersonal) {
      incomplete = true;
      missingDataFields.push('personal_item');
      reasons.push('Personal item policy is unknown');
    }

    if (reqBag === 'carry_on' || reqBag === 'checked_1') {
      const carryStatuses = baggageList.map((b) => b.carryOn.status);
      if (carryStatuses.some((s) => s === 'unknown')) {
        incomplete = true;
        missingDataFields.push('carry_on');
        reasons.push('Carry-on baggage allowance is missing for one or more segments');
      } else if (carryStatuses.some((s) => s === 'not_included')) {
        ineligible = true;
        reasons.push('Carry-on bag is not permitted on this fare');
      } else if (carryStatuses.some((s) => s === 'paid_extra')) {
        const extraCarry = findMatchingExtra(offer.observation.availableExtras, 'carry_on');
        if (extraCarry) {
          requiredExtrasTotal = addMoney(requiredExtrasTotal, extraCarry.priceForTrip);
          reasons.push(`Carry-on requires paid add-on (${extraCarry.priceForTrip.amount} ${extraCarry.priceForTrip.currency})`);
        } else {
          incomplete = true;
          missingDataFields.push('carry_on_fee');
          reasons.push('Carry-on fee amount is unavailable');
        }
      }
    }

    if (reqBag === 'checked_1') {
      const checkedStatuses = baggageList.map((b) => b.checkedBag.status);
      if (checkedStatuses.some((s) => s === 'unknown')) {
        incomplete = true;
        missingDataFields.push('checked_bag');
        reasons.push('Checked baggage allowance is missing for one or more segments');
      } else if (checkedStatuses.some((s) => s === 'not_included')) {
        ineligible = true;
        reasons.push('Checked baggage is not permitted on this fare');
      } else if (checkedStatuses.some((s) => s === 'paid_extra')) {
        const extraChecked = findMatchingExtra(offer.observation.availableExtras, 'checked_1');
        if (extraChecked) {
          requiredExtrasTotal = addMoney(requiredExtrasTotal, extraChecked.priceForTrip);
          reasons.push(`1st checked bag added (${extraChecked.priceForTrip.amount} ${extraChecked.priceForTrip.currency})`);
        } else {
          incomplete = true;
          missingDataFields.push('checked_bag_fee');
          reasons.push('Checked baggage fee amount is unavailable');
        }
      }
    }
  }

  // 3. Check seat preference
  const seatPref: SeatPreference = criteria.seatPreference;
  const seatInfo = offer.fareProduct.conditions.seatAssignment;
  if (seatPref === 'assigned_included') {
    if (seatInfo.status === 'unknown') {
      incomplete = true;
      missingDataFields.push('seat_assignment');
      reasons.push('Seat assignment terms are unknown');
    } else if (seatInfo.status !== 'assigned_included' && seatInfo.status !== 'advance_selection_included') {
      ineligible = true;
      reasons.push('Included seat assignment is not guaranteed on this fare');
    }
  } else if (seatPref === 'advance_selection') {
    if (seatInfo.status === 'unknown') {
      incomplete = true;
      missingDataFields.push('seat_selection');
      reasons.push('Advance seat selection rules are unknown');
    } else if (seatInfo.status === 'assigned_at_checkin') {
      ineligible = true;
      reasons.push('Advance seat selection is not available; seats are assigned at check-in');
    } else if (seatInfo.status === 'advance_selection_paid') {
      const extraSeat = findMatchingExtra(offer.observation.availableExtras, 'advance_seat');
      if (extraSeat) {
        requiredExtrasTotal = addMoney(requiredExtrasTotal, extraSeat.priceForTrip);
        reasons.push(`Advance seat selection added (${extraSeat.priceForTrip.amount} ${extraSeat.priceForTrip.currency})`);
      } else {
        incomplete = true;
        missingDataFields.push('advance_seat_fee');
        reasons.push('Advance seat selection fee is unavailable');
      }
    }
  }

  // 4. Refundability requirement
  if (criteria.refundableOnly) {
    const refStatus = offer.fareProduct.conditions.refundAllowed;
    if (refStatus === 'unknown') {
      incomplete = true;
      missingDataFields.push('refund_conditions');
      reasons.push('Refundability terms are unknown');
    } else if (refStatus === 'not_included') {
      ineligible = true;
      reasons.push('Fare is non-refundable');
    }
  }

  // 5. Stops constraint
  if (typeof criteria.maxStops === 'number' && offer.journey.maxStops > criteria.maxStops) {
    ineligible = true;
    reasons.push(`Exceeds maximum stops (${offer.journey.maxStops} > ${criteria.maxStops})`);
  }

  const comparableTotal = addMoney(basePlusMandatory, requiredExtrasTotal);
  const totalPassengers =
    criteria.passengers.adults + criteria.passengers.children + criteria.passengers.infants;
  const safePaxCount = Math.max(1, totalPassengers);
  const perPersonAverage = makeMoney(
    roundHalfUp(comparableTotal.minorUnits, safePaxCount),
    comparableTotal.currency
  );

  const fxDisclosure =
    criteria.currency !== comparableTotal.currency
      ? convertCurrency(comparableTotal, criteria.currency as CurrencyCode)
      : null;

  const eligibility: ComparisonEvaluation['eligibility'] = ineligible
    ? 'ineligible'
    : incomplete
    ? 'incomplete'
    : 'eligible';

  const isExpired = Date.parse(offer.observation.expiresAt) <= Date.parse(nowIso);

  return {
    evaluation: {
      eligibility,
      reasons,
      requiredExtrasTotal,
      comparableTotal,
      perPersonAverage,
      fxDisclosure,
      missingDataFields,
    },
    isExpired,
  };
}

export function scoreAndGroupOffers(
  rawOffers: Omit<Offer, 'evaluation' | 'recommendedScore' | 'isExpired'>[],
  criteria: SearchCriteria,
  nowIso: string = new Date().toISOString()
): { offers: Offer[]; groups: ItineraryGroup[] } {
  const evaluated: Offer[] = rawOffers.map((raw) => {
    const { evaluation, isExpired } = evaluateOfferForCriteria(raw, criteria, nowIso);
    return {
      ...raw,
      evaluation,
      recommendedScore: 0,
      isExpired,
    };
  });

  const prices = evaluated.map((o) => o.evaluation.comparableTotal.minorUnits);
  const durations = evaluated.map((o) => o.journey.totalDurationMinutes);
  const minPrice = prices.length ? Math.min(...prices) : 0;
  const maxPrice = prices.length ? Math.max(...prices) : 1;
  const minDur = durations.length ? Math.min(...durations) : 0;
  const maxDur = durations.length ? Math.max(...durations) : 1;

  for (const offer of evaluated) {
    const normPrice =
      maxPrice === minPrice
        ? 0
        : (offer.evaluation.comparableTotal.minorUnits - minPrice) / (maxPrice - minPrice);
    const normDuration =
      maxDur === minDur
        ? 0
        : (offer.journey.totalDurationMinutes - minDur) / (maxDur - minDur);
    const stopPenalty = Math.min(1, offer.journey.maxStops * 0.5);
    const completenessPenalty =
      offer.evaluation.eligibility === 'eligible'
        ? 0
        : offer.evaluation.eligibility === 'incomplete'
        ? 0.5
        : 1.0;

    // Lower score is better; add +10 tier offset for incomplete and +20 for ineligible
    const tierOffset =
      offer.evaluation.eligibility === 'eligible'
        ? 0
        : offer.evaluation.eligibility === 'incomplete'
        ? 10
        : 20;

    offer.recommendedScore = Number(
      (
        tierOffset +
        0.55 * normPrice +
        0.25 * normDuration +
        0.12 * stopPenalty +
        0.08 * completenessPenalty
      ).toFixed(4)
    );
  }

  // Group duplicate itineraries by canonicalKey
  const byKey = new Map<string, Offer[]>();
  for (const offer of evaluated) {
    const list = byKey.get(offer.journey.canonicalKey) ?? [];
    list.push(offer);
    byKey.set(offer.journey.canonicalKey, list);
  }

  const groups: ItineraryGroup[] = [];
  for (const [canonicalKey, groupOffers] of byKey.entries()) {
    groupOffers.sort((a, b) => {
      if (a.recommendedScore !== b.recommendedScore) {
        return a.recommendedScore - b.recommendedScore;
      }
      return a.evaluation.comparableTotal.minorUnits - b.evaluation.comparableTotal.minorUnits;
    });

    const eligibleOffers = groupOffers.filter((o) => o.evaluation.eligibility === 'eligible');
    const cheapestEligible = eligibleOffers.length
      ? eligibleOffers.reduce((best, cur) =>
          cur.evaluation.comparableTotal.minorUnits < best.evaluation.comparableTotal.minorUnits
            ? cur
            : best
        )
      : null;

    const cheapestBase = groupOffers.reduce((best, cur) => {
      const bestBase =
        best.observation.baseFareTotal.minorUnits +
        best.observation.taxesAndMandatoryTotal.minorUnits;
      const curBase =
        cur.observation.baseFareTotal.minorUnits +
        cur.observation.taxesAndMandatoryTotal.minorUnits;
      return curBase < bestBase ? cur : best;
    });

    groups.push({
      canonicalKey,
      journey: groupOffers[0].journey,
      offers: groupOffers,
      cheapestEligibleOfferId: cheapestEligible?.offerId ?? null,
      cheapestBaseOfferId: cheapestBase.offerId,
      bestOffer: cheapestEligible ?? groupOffers[0],
    });
  }

  return { offers: evaluated, groups };
}
