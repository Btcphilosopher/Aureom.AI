export type CurrencyCode = 'USD' | 'CAD' | 'EUR' | 'GBP';

export type TripType = 'round_trip' | 'one_way';

export type CabinClass = 'economy' | 'premium_economy' | 'business' | 'first';

export type BaggageRequirement = 'personal_only' | 'carry_on' | 'checked_1';

export type SeatPreference = 'any' | 'advance_selection' | 'assigned_included';

export type InclusionStatus = 'included' | 'paid_extra' | 'not_included' | 'unknown';

export type SortMode = 'recommended' | 'cheapest_eligible' | 'cheapest_base' | 'fastest';

export type ProviderHealthState = 'healthy' | 'degraded' | 'outage';

export type RevalidationStatus =
  | 'unverified'
  | 'confirmed'
  | 'price_changed'
  | 'expired'
  | 'unavailable';

export interface DecimalMoney {
  /** Integer minor units (cents, 100 = $1.00). Never use raw floats for totals. */
  minorUnits: number;
  currency: CurrencyCode;
  /** Formatted string e.g. "348.50" */
  amount: string;
}

export interface FxConversionDisclosure {
  original: DecimalMoney;
  converted: DecimalMoney;
  rate: string;
  rateSource: string;
  rateTimestamp: string;
}

export interface LocationOption {
  code: string;
  kind: 'metro' | 'airport';
  name: string;
  city: string;
  stateOrCountry: string;
  countryCode: string;
  timezone: string;
  latitude: number;
  longitude: number;
  includedAirports?: string[];
  nearbyAirports?: string[];
  provenance: string;
}

export interface PassengerComposition {
  adults: number;
  children: number; // ages 2-11
  infants: number;  // under 2 (lap/seat)
}

export interface SearchCriteria {
  tripType: TripType;
  originCode: string;
  destinationCode: string;
  includeNearbyOrigin: boolean;
  includeNearbyDestination: boolean;
  departDate: string; // YYYY-MM-DD
  returnDate?: string; // YYYY-MM-DD
  passengers: PassengerComposition;
  cabin: CabinClass;
  requiredBaggage: BaggageRequirement;
  seatPreference: SeatPreference;
  refundableOnly: boolean;
  maxStops?: number | null;
  currency: CurrencyCode;
}

export interface CarrierInfo {
  code: string;
  name: string;
}

export interface BaggageRule {
  status: InclusionStatus;
  pieces?: number;
  maxWeightKg?: number;
  maxWeightLb?: number;
  feeIfExtra?: DecimalMoney | null;
  notes?: string;
}

export interface SegmentBaggageAllowance {
  segmentId: string;
  personalItem: BaggageRule;
  carryOn: BaggageRule;
  checkedBag: BaggageRule;
}

export interface FlightSegment {
  segmentId: string;
  flightNumber: string;
  marketingCarrier: CarrierInfo;
  operatingCarrier: CarrierInfo;
  originAirport: string;
  originTerminal?: string;
  originTimezone: string;
  destinationAirport: string;
  destinationTerminal?: string;
  destinationTimezone: string;
  departureUtc: string; // ISO UTC
  arrivalUtc: string;   // ISO UTC
  departureLocal: string; // YYYY-MM-DDTHH:mm
  arrivalLocal: string;   // YYYY-MM-DDTHH:mm
  durationMinutes: number;
  cabin: CabinClass;
  aircraft: string;
  dayOffsetFromDeparture: number; // 0, +1, -1
  crossesDateLine: boolean;
  dstTransitioned: boolean;
}

export interface ConnectionDetail {
  afterSegmentId: string;
  atAirport: string;
  toAirport: string;
  durationMinutes: number;
  isAirportChange: boolean;
  isOvernight: boolean;
  isSelfTransfer: boolean;
  isProtectedConnection: boolean;
  protectionNote: string;
}

export interface JourneyBound {
  boundId: string;
  direction: 'outbound' | 'inbound';
  originAirport: string;
  destinationAirport: string;
  segments: FlightSegment[];
  connections: ConnectionDetail[];
  totalDurationMinutes: number;
  stops: number;
  hasMixedCabins: boolean;
  hasOvernightArrival: boolean;
  hasAirportChange: boolean;
  hasSelfTransfer: boolean;
}

export interface Journey {
  journeyId: string;
  /** Canonical deduplication key across providers and sellers */
  canonicalKey: string;
  bounds: JourneyBound[];
  totalDurationMinutes: number;
  maxStops: number;
}

export interface PassengerFareLine {
  passengerType: 'adult' | 'child' | 'infant';
  count: number;
  baseFareEach: DecimalMoney;
  taxesEach: DecimalMoney;
  mandatoryChargesEach: DecimalMoney;
  subtotal: DecimalMoney;
  pricingBasis: 'explicit_per_pax_type' | 'uniform_adult_derived';
}

export interface PricedExtraOption {
  extraId: string;
  kind: 'carry_on' | 'checked_1' | 'advance_seat';
  label: string;
  description: string;
  priceForTrip: DecimalMoney;
  perPassenger: boolean;
}

export interface FareConditions {
  changeAllowed: InclusionStatus;
  changeFee?: DecimalMoney | null;
  changeNotes: string;
  refundAllowed: InclusionStatus;
  refundFee?: DecimalMoney | null;
  refundNotes: string;
  seatAssignment: {
    status: 'assigned_included' | 'advance_selection_included' | 'advance_selection_paid' | 'assigned_at_checkin' | 'unknown';
    feeForTrip?: DecimalMoney | null;
    notes: string;
  };
}

export interface FareProduct {
  fareFamilyName: string;
  bookingClass: string;
  isBasicEconomy: boolean;
  isSeparateTickets: boolean;
  conditions: FareConditions;
  baggagePerSegment: SegmentBaggageAllowance[];
}

export interface Seller {
  sellerId: string;
  slug: string;
  name: string;
  kind: 'airline_direct' | 'ota';
  affiliateDisclosed: boolean;
  supportNote: string;
}

export interface PriceObservation {
  observationId: string;
  providerId: string;
  providerName: string;
  providerOfferRef: string;
  collectedAt: string;
  expiresAt: string;
  revalidationStatus: RevalidationStatus;
  passengerLines: PassengerFareLine[];
  baseFareTotal: DecimalMoney;
  taxesAndMandatoryTotal: DecimalMoney;
  availableExtras: PricedExtraOption[];
}

export interface ComparisonEvaluation {
  eligibility: 'eligible' | 'ineligible' | 'incomplete';
  reasons: string[];
  requiredExtrasTotal: DecimalMoney;
  comparableTotal: DecimalMoney;
  perPersonAverage: DecimalMoney;
  fxDisclosure?: FxConversionDisclosure | null;
  missingDataFields: string[];
}

export interface Offer {
  offerId: string;
  journey: Journey;
  seller: Seller;
  fareProduct: FareProduct;
  observation: PriceObservation;
  referralUrl: string;
  evaluation: ComparisonEvaluation;
  recommendedScore: number;
  isExpired: boolean;
}

export interface ItineraryGroup {
  canonicalKey: string;
  journey: Journey;
  offers: Offer[];
  cheapestEligibleOfferId: string | null;
  cheapestBaseOfferId: string;
  bestOffer: Offer;
}

export interface ProviderCoverageReport {
  providerId: string;
  providerName: string;
  status: 'ok' | 'partial' | 'failed' | 'rate_limited';
  latencyMs: number;
  offerCount: number;
  errorMessage?: string;
}

export interface SearchResponse {
  searchId: string;
  searchedAt: string;
  criteria: SearchCriteria;
  cacheHit: boolean;
  searchStatus: 'complete' | 'partial' | 'failed' | 'no_matches';
  statusBanner?: string;
  providers: ProviderCoverageReport[];
  groups: ItineraryGroup[];
  summary: {
    totalOffers: number;
    totalUniqueItineraries: number;
    cheapestEligibleTotal: DecimalMoney | null;
    cheapestEligibleOfferId: string | null;
    cheapestBaseTotal: DecimalMoney | null;
    cheapestBaseOfferId: string | null;
    fastestDurationMinutes: number | null;
    fastestOfferId: string | null;
    rankingFormulaExplanation: string;
  };
}

export interface RevalidationResult {
  offerId: string;
  status: RevalidationStatus;
  checkedAt: string;
  previousTotal: DecimalMoney;
  updatedTotal: DecimalMoney;
  priceDelta: DecimalMoney;
  requiresFreshSelection: boolean;
  message: string;
  referralUrl?: string;
  affiliateDisclosure: string;
  refreshedAlternatives?: Offer[];
}

export interface UserPublic {
  userId: string;
  email: string;
  name: string;
  role: 'traveler' | 'admin';
  createdAt: string;
}

export interface SavedSearchRecord {
  savedSearchId: string;
  userId: string;
  label: string;
  criteria: SearchCriteria;
  createdAt: string;
}

export interface SavedItineraryRecord {
  savedItineraryId: string;
  userId: string;
  offerId: string;
  offerSnapshot: Offer;
  notes: string;
  savedAt: string;
}

export interface PriceAlertRecord {
  alertId: string;
  userId: string;
  label: string;
  criteria: SearchCriteria;
  targetPrice: DecimalMoney;
  checkFrequency: 'every_6_hours' | 'daily';
  status: 'active' | 'triggered' | 'paused';
  lastCheckedAt?: string;
  lastCheckedOfferId?: string;
  lastCheckedPrice?: DecimalMoney | null;
  lastPriceBasis?: string;
  lastNotificationStatus: 'none' | 'notified' | 'not_eligible_for_requirements' | 'no_matching_offer';
  lastNotificationMessage?: string;
  createdAt: string;
}

export interface HandoffEventRecord {
  handoffId: string;
  userId: string;
  offerId: string;
  sellerName: string;
  routeSummary: string;
  totalAtHandoff: DecimalMoney;
  referralUrl: string;
  createdAt: string;
}

export interface ManualBookingRecord {
  bookingRecordId: string;
  userId: string;
  confirmationCode: string;
  airlineOrSeller: string;
  routeSummary: string;
  travelDate: string;
  notes: string;
  verificationNote: string;
  createdAt: string;
}
