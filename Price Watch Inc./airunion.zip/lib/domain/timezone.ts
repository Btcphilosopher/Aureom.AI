/**
 * Timezone-aware date/time utilities using standard IANA timezones.
 * All flight durations are calculated strictly from UTC timestamps,
 * while display dates and times use the airport's local IANA timezone.
 */

export function getLocalParts(isoUtc: string, ianaTimezone: string): {
  dateStr: string;   // YYYY-MM-DD
  timeStr: string;   // HH:mm
  displayTime: string; // e.g. 8:15 AM
  displayDate: string; // e.g. Tue, Dec 15
  shortOffset: string; // e.g. EST, PST
} {
  const dt = new Date(isoUtc);
  if (Number.isNaN(dt.getTime())) {
    throw new Error(`Invalid UTC timestamp: ${isoUtc}`);
  }

  const dateFmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: ianaTimezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });
  const time24Fmt = new Intl.DateTimeFormat('en-GB', {
    timeZone: ianaTimezone,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
  const displayTimeFmt = new Intl.DateTimeFormat('en-US', {
    timeZone: ianaTimezone,
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
  const displayDateFmt = new Intl.DateTimeFormat('en-US', {
    timeZone: ianaTimezone,
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
  const tzNameFmt = new Intl.DateTimeFormat('en-US', {
    timeZone: ianaTimezone,
    timeZoneName: 'short',
  });

  const tzParts = tzNameFmt.formatToParts(dt);
  const shortOffset = tzParts.find((p) => p.type === 'timeZoneName')?.value ?? '';

  return {
    dateStr: dateFmt.format(dt),
    timeStr: time24Fmt.format(dt),
    displayTime: displayTimeFmt.format(dt),
    displayDate: displayDateFmt.format(dt),
    shortOffset,
  };
}

export function calculateAbsoluteDurationMinutes(startUtc: string, endUtc: string): number {
  const startMs = Date.parse(startUtc);
  const endMs = Date.parse(endUtc);
  if (Number.isNaN(startMs) || Number.isNaN(endMs)) {
    throw new Error(`Invalid timestamps for duration: ${startUtc} -> ${endUtc}`);
  }
  const diffMin = Math.round((endMs - startMs) / 60000);
  if (diffMin < 0) {
    throw new Error(`Arrival timestamp ${endUtc} precedes departure ${startUtc}`);
  }
  return diffMin;
}

export function calculateLocalDayOffset(
  departureUtc: string,
  departureTimezone: string,
  arrivalUtc: string,
  arrivalTimezone: string
): number {
  const depDate = getLocalParts(departureUtc, departureTimezone).dateStr;
  const arrDate = getLocalParts(arrivalUtc, arrivalTimezone).dateStr;
  const depMs = Date.parse(`${depDate}T00:00:00Z`);
  const arrMs = Date.parse(`${arrDate}T00:00:00Z`);
  return Math.round((arrMs - depMs) / 86400000);
}

export function getTimezoneOffsetMinutes(isoUtc: string, ianaTimezone: string): number {
  const dt = new Date(isoUtc);
  const utcStr = dt.toLocaleString('en-US', { timeZone: 'UTC' });
  const localStr = dt.toLocaleString('en-US', { timeZone: ianaTimezone });
  return Math.round((Date.parse(localStr) - Date.parse(utcStr)) / 60000);
}

export function detectDstTransition(
  departureUtc: string,
  departureTimezone: string,
  arrivalUtc: string,
  arrivalTimezone: string
): boolean {
  const depOffsetStart = getTimezoneOffsetMinutes(departureUtc, departureTimezone);
  const depOffsetEnd = getTimezoneOffsetMinutes(arrivalUtc, departureTimezone);
  const arrOffsetStart = getTimezoneOffsetMinutes(departureUtc, arrivalTimezone);
  const arrOffsetEnd = getTimezoneOffsetMinutes(arrivalUtc, arrivalTimezone);
  return depOffsetStart !== depOffsetEnd || arrOffsetStart !== arrOffsetEnd;
}

export function formatDurationMinutes(minutes: number): string {
  const hrs = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hrs}h ${String(mins).padStart(2, '0')}m`;
}

export function addDaysToDateString(dateStr: string, days: number): string {
  const ms = Date.parse(`${dateStr}T12:00:00Z`) + days * 86400000;
  return new Date(ms).toISOString().slice(0, 10);
}

export function getDefaultFutureDates(referenceNow: Date = new Date()): {
  departDate: string;
  returnDate: string;
  minDate: string;
} {
  const todayUtc = new Date(
    Date.UTC(referenceNow.getUTCFullYear(), referenceNow.getUTCMonth(), referenceNow.getUTCDate(), 12, 0, 0)
  );
  const minDate = todayUtc.toISOString().slice(0, 10);
  const departDate = new Date(todayUtc.getTime() + 21 * 86400000).toISOString().slice(0, 10);
  const returnDate = new Date(todayUtc.getTime() + 28 * 86400000).toISOString().slice(0, 10);
  return { departDate, returnDate, minDate };
}
