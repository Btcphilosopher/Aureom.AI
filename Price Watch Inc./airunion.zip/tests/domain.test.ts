import assert from 'node:assert/strict';
import test from 'node:test';
import { convertCurrency, makeMoney } from '../lib/domain/money.ts';
import {
  calculateAbsoluteDurationMinutes,
  calculateLocalDayOffset,
  detectDstTransition,
} from '../lib/domain/timezone.ts';
import type { SearchCriteria } from '../lib/domain/types.ts';
import { revalidateOfferWithProvider, runAggregatedSearch } from '../lib/providers/aggregator.ts';
import { localWallTimeToUtcIso } from '../lib/providers/builder.ts';
import { validateSafeReferralUrl } from '../lib/server/auth.ts';
import { evaluatePriceAlerts } from '../lib/server/alerts.ts';
import { DEMO_TRAVELER_ID, readStore } from '../lib/server/store.ts';

function baseCriteria(overrides: Partial<SearchCriteria> = {}): SearchCriteria {
  return {
    tripType: 'round_trip',
    originCode: 'NYC',
    destinationCode: 'LAX',
    includeNearbyOrigin: false,
    includeNearbyDestination: false,
    departDate: '2026-12-15',
    returnDate: '2026-12-22',
    passengers: { adults: 1, children: 0, infants: 0 },
    cabin: 'economy',
    requiredBaggage: 'carry_on',
    seatPreference: 'any',
    refundableOnly: false,
    maxStops: null,
    currency: 'USD',
    ...overrides,
  };
}

test('Timezone handling: DST transition & international date line calculations', () => {
  const depUtc = localWallTimeToUtcIso('2026-03-07', '22:30', 'America/Los_Angeles');
  const arrUtc = localWallTimeToUtcIso('2026-03-08', '07:30', 'America/New_York');
  const duration = calculateAbsoluteDurationMinutes(depUtc, arrUtc);
  const offset = calculateLocalDayOffset(depUtc, 'America/Los_Angeles', arrUtc, 'America/New_York');
  const dst = detectDstTransition(depUtc, 'America/Los_Angeles', arrUtc, 'America/New_York');

  assert.equal(duration, 300);
  assert.equal(offset, 1);
  assert.equal(dst, true);
});

test('Traveler pricing: family composition prices adults, children, and infants distinctly', async () => {
  const res = await runAggregatedSearch({
    criteria: baseCriteria({ passengers: { adults: 2, children: 1, infants: 1 } }),
    providerStates: { skybridge_gds: 'healthy', aerodirect_ndc: 'healthy' },
  });

  const offer = res.groups[0].offers[0];
  assert.equal(offer.observation.passengerLines.length, 3);
  const [adultLine, childLine, infantLine] = offer.observation.passengerLines;
  assert.notEqual(adultLine.baseFareEach.minorUnits, childLine.baseFareEach.minorUnits);
  assert.notEqual(adultLine.baseFareEach.minorUnits, infantLine.baseFareEach.minorUnits);
  assert.equal(adultLine.pricingBasis, 'explicit_per_pax_type');
});

test('Duplicate itinerary grouping & baggage matching shifts cheapest eligible offer', async () => {
  const carryOnlyRes = await runAggregatedSearch({
    criteria: baseCriteria({ requiredBaggage: 'carry_on' }),
    providerStates: { skybridge_gds: 'healthy', aerodirect_ndc: 'healthy' },
  });

  // AA 117/118 is grouped across ClearFare ($258), AA Direct ($328), and AA NDC Main Plus ($354)
  const aaGroup = carryOnlyRes.groups.find((g) => g.offers.length === 3);
  assert.ok(aaGroup, 'Expected 3 grouped offers on AA 117/118');
  assert.equal(carryOnlyRes.summary.cheapestEligibleTotal?.minorUnits, 25800);

  // Now add checked_1 requirement -> ClearFare rises to $258 + $130 = $388, so AA NDC Main Plus ($354) wins!
  const checkedRes = await runAggregatedSearch({
    criteria: baseCriteria({ requiredBaggage: 'checked_1' }),
    providerStates: { skybridge_gds: 'healthy', aerodirect_ndc: 'healthy' },
  });
  assert.equal(checkedRes.summary.cheapestEligibleTotal?.minorUnits, 35400);

  // Missing baggage offer must remain incomplete (never labeled eligible)
  const missingBagOffer = checkedRes.groups
    .flatMap((g) => g.offers)
    .find((o) => o.offerId.includes('missingbag'));
  assert.ok(missingBagOffer);
  assert.equal(missingBagOffer.evaluation.eligibility, 'incomplete');
});

test('Offer expiry, refreshed alternatives, and price change revalidation', async () => {
  const res = await runAggregatedSearch({
    criteria: baseCriteria(),
    providerStates: { skybridge_gds: 'healthy', aerodirect_ndc: 'healthy' },
  });
  const allOffers = res.groups.flatMap((g) => g.offers);

  const expiredOffer = allOffers.find((o) => o.offerId.includes('expired'));
  assert.ok(expiredOffer);
  assert.equal(expiredOffer.isExpired, true);
  const expReval = await revalidateOfferWithProvider({
    offer: expiredOffer,
    allOffersForSearch: allOffers,
    providerStates: { skybridge_gds: 'healthy', aerodirect_ndc: 'healthy' },
  });
  assert.equal(expReval.status, 'expired');
  assert.ok((expReval.refreshedAlternatives?.length ?? 0) > 0);

  const driftOffer = allOffers.find((o) => o.offerId.includes('pricechange'));
  assert.ok(driftOffer);
  const driftReval = await revalidateOfferWithProvider({
    offer: driftOffer,
    allOffersForSearch: allOffers,
    providerStates: { skybridge_gds: 'healthy', aerodirect_ndc: 'healthy' },
  });
  assert.equal(driftReval.status, 'price_changed');
  assert.equal(driftReval.priceDelta.minorUnits, 2400);
  assert.equal(driftReval.requiresFreshSelection, true);
});

test('Provider outage returns partial or failed status without invented availability', async () => {
  const partialRes = await runAggregatedSearch({
    criteria: baseCriteria(),
    providerStates: { skybridge_gds: 'outage', aerodirect_ndc: 'healthy' },
  });
  assert.equal(partialRes.searchStatus, 'partial');
  assert.ok(partialRes.statusBanner?.includes('SkyBridge GDS'));

  const fullOutageRes = await runAggregatedSearch({
    criteria: baseCriteria(),
    providerStates: { skybridge_gds: 'outage', aerodirect_ndc: 'outage' },
  });
  assert.equal(fullOutageRes.searchStatus, 'failed');
  assert.equal(fullOutageRes.groups.length, 0);
});

test('Currency conversion disclosure & referral URL safety validation', () => {
  const usd = makeMoney(35400, 'USD');
  const fx = convertCurrency(usd, 'EUR');
  assert.ok(fx);
  assert.equal(fx.converted.currency, 'EUR');
  assert.equal(fx.converted.amount, '333.47');
  assert.ok(fx.rateSource.includes('Federal Reserve'));

  assert.equal(validateSafeReferralUrl('/supplier/american-airlines?offerId=1').valid, true);
  assert.equal(validateSafeReferralUrl('javascript:alert(1)').valid, false);
  assert.equal(validateSafeReferralUrl('http://127.0.0.1:8080/steal').valid, false);
});

test('Price alert evaluation respects baggage requirements and user isolation', async () => {
  const store = readStore();
  const demoAlerts = store.priceAlerts.filter((a) => a.userId === DEMO_TRAVELER_ID);
  assert.ok(demoAlerts.length > 0);
  const evaluated = await evaluatePriceAlerts(demoAlerts[0].alertId, DEMO_TRAVELER_ID);
  assert.equal(evaluated.length, 1);
  assert.equal(evaluated[0].lastCheckedPrice?.minorUnits, 35400);
  assert.equal(evaluated[0].lastNotificationStatus, 'notified');
});
