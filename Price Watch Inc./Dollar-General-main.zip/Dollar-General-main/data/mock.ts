export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  category: string;
  brand: string;
  badge?: string;
  description: string;
  inStock: boolean;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  slug: string;
}

export const categories: Category[] = [
  { id: '1', name: 'Household Essentials', icon: 'Home', slug: 'household-essentials' },
  { id: '2', name: 'Food & Beverages', icon: 'ShoppingCart', slug: 'food-and-beverages' },
  { id: '3', name: 'Health & Personal Care', icon: 'Heart', slug: 'health-and-personal-care' },
  { id: '4', name: 'Cleaning Supplies', icon: 'Sparkles', slug: 'cleaning-supplies' },
  { id: '5', name: 'Paper & Disposables', icon: 'FileText', slug: 'paper-disposables' },
  { id: '6', name: 'Baby', icon: 'Baby', slug: 'baby' },
  { id: '7', name: 'Pet Supplies', icon: 'PawPrint', slug: 'pet-supplies' },
  { id: '8', name: 'Seasonal', icon: 'Sun', slug: 'seasonal' },
  { id: '9', name: 'Toys & Games', icon: 'Gamepad2', slug: 'toys-and-games' },
];

export const products: Product[] = [
  {
    id: 'p1',
    name: 'DG Home Multi-Purpose Cleaner, 32 oz',
    price: 2.50,
    rating: 4.5,
    reviewCount: 128,
    image: 'https://picsum.photos/seed/cleaner/400/400',
    category: 'Cleaning Supplies',
    brand: 'DG Home',
    badge: 'Everyday Low Price',
    description: 'Keep your home sparkling clean with our multi-purpose cleaner. Tough on grease and grime.',
    inStock: true,
  },
  {
    id: 'p2',
    name: 'Clover Valley Bottled Water, 24 pk',
    price: 3.95,
    originalPrice: 4.50,
    rating: 4.8,
    reviewCount: 842,
    image: 'https://picsum.photos/seed/water/400/400',
    category: 'Food & Beverages',
    brand: 'Clover Valley',
    badge: 'Sale',
    description: 'Purified drinking water. 24 pack of 16.9 oz bottles.',
    inStock: true,
  },
  {
    id: 'p3',
    name: 'Nature\'s Menu Dog Treats, Beef Flavor 24oz',
    price: 5.00,
    rating: 4.6,
    reviewCount: 315,
    image: 'https://picsum.photos/seed/dogtreats/400/400',
    category: 'Pet Supplies',
    brand: 'Nature\'s Menu',
    description: 'Delicious beef flavor treats your dog will love. Made with real beef.',
    inStock: true,
  },
  {
    id: 'p4',
    name: 'TrueLiving Paper Towels, 6 Double Rolls',
    price: 6.50,
    rating: 4.2,
    reviewCount: 412,
    image: 'https://picsum.photos/seed/papertowels/400/400',
    category: 'Paper & Disposables',
    brand: 'TrueLiving',
    description: 'Strong and absorbent paper towels. 6 double rolls equals 12 regular rolls.',
    inStock: true,
  },
  {
    id: 'p5',
    name: 'DG Health Hand Soap, Lavender 12oz',
    price: 1.50,
    rating: 4.7,
    reviewCount: 89,
    image: 'https://picsum.photos/seed/handsoap/400/400',
    category: 'Health & Personal Care',
    brand: 'DG Health',
    description: 'Gentle hand soap with a soothing lavender scent. Washes away bacteria.',
    inStock: true,
  },
  {
    id: 'p6',
    name: 'Sweet Smiles Gummy Bears, 10oz',
    price: 1.25,
    rating: 4.9,
    reviewCount: 521,
    image: 'https://picsum.photos/seed/gummybears/400/400',
    category: 'Food & Beverages',
    brand: 'Sweet Smiles',
    badge: 'New',
    description: 'Fruity and chewy gummy bears in assorted flavors.',
    inStock: true,
  },
  {
    id: 'p7',
    name: 'Office Essentials 1-Subject Notebook',
    price: 1.00,
    rating: 4.4,
    reviewCount: 230,
    image: 'https://picsum.photos/seed/notebook/400/400',
    category: 'Household Essentials',
    brand: 'Office Essentials',
    description: 'Wide ruled, 70 sheets. Assorted colors.',
    inStock: true,
  },
  {
    id: 'p8',
    name: 'Gentle Steps Baby Wipes, 3-Pack',
    price: 4.50,
    originalPrice: 5.50,
    rating: 4.8,
    reviewCount: 654,
    image: 'https://picsum.photos/seed/babywipes/400/400',
    category: 'Baby',
    brand: 'Gentle Steps',
    badge: 'Sale',
    description: 'Unscented, hypoallergenic baby wipes. 3 packs of 72 wipes.',
    inStock: true,
  },
];

export interface Coupon {
  id: string;
  brand: string;
  description: string;
  discount: string;
  expiresAt: string;
  image: string;
  isClipped: boolean;
}

export const coupons: Coupon[] = [
  {
    id: 'c1',
    brand: 'Tide',
    description: 'Save on ONE Tide Pods Laundry Detergent 32 ct or larger.',
    discount: '$3.00 OFF',
    expiresAt: 'Exp. 10/15',
    image: 'https://picsum.photos/seed/tide/100/100',
    isClipped: false,
  },
  {
    id: 'c2',
    brand: 'Crest',
    description: 'Save on ONE Crest Toothpaste 3 oz or more.',
    discount: '$1.50 OFF',
    expiresAt: 'Exp. 10/20',
    image: 'https://picsum.photos/seed/crest/100/100',
    isClipped: true,
  },
  {
    id: 'c3',
    brand: 'Coca-Cola',
    description: 'Save on TWO Coca-Cola 12-pack cans.',
    discount: '$2.00 OFF',
    expiresAt: 'Exp. 10/10',
    image: 'https://picsum.photos/seed/coke/100/100',
    isClipped: false,
  },
  {
    id: 'c4',
    brand: 'Gain',
    description: 'Save on ONE Gain Flings 14 ct or larger.',
    discount: '$2.00 OFF',
    expiresAt: 'Exp. 10/25',
    image: 'https://picsum.photos/seed/gain/100/100',
    isClipped: false,
  }
];
