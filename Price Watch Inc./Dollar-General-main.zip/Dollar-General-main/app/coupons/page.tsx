'use client';

import { useState } from 'react';
import Image from 'next/image';
import { Check, Plus } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { coupons as initialCoupons } from '@/data/mock';
import { Button } from '@/components/ui/Button';

export default function CouponsPage() {
  const [coupons, setCoupons] = useState(initialCoupons);

  const toggleClip = (id: string) => {
    setCoupons(coupons.map(c => c.id === id ? { ...c, isClipped: !c.isClipped } : c));
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-black font-sans">
      <Header />
      
      <main className="flex-1 flex flex-col max-w-7xl mx-auto w-full px-4 md:px-8 py-8 md:py-12">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 border-b border-neutral-200 pb-8">
          <div>
             <h1 className="text-3xl md:text-5xl font-black uppercase tracking-tight mb-2">Digital Coupons</h1>
             <p className="text-neutral-600">Clip coupons and save automatically at checkout.</p>
          </div>
          <div className="flex items-center gap-4 bg-neutral-50 px-4 py-3 rounded-lg border border-neutral-200">
             <div className="flex flex-col">
               <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">Your Clipped Value</span>
               <span className="text-2xl font-black text-green-600">$4.50</span>
             </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-8">
          {['All Coupons', 'Clipped', 'For You', 'Grocery', 'Household', 'Personal Care'].map((filter, i) => (
             <button 
               key={filter}
               className={`px-4 py-2 rounded-full text-sm font-semibold border ${i === 0 ? 'bg-black text-white border-black' : 'bg-white text-black border-neutral-300 hover:border-black'}`}
             >
               {filter}
             </button>
          ))}
        </div>

        {/* Coupons Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {coupons.map(coupon => (
            <div key={coupon.id} className="border border-neutral-200 rounded-xl overflow-hidden flex flex-col hover:shadow-lg transition-shadow bg-white">
              <div className="p-6 flex gap-4">
                 <div className="w-20 h-20 shrink-0 border border-neutral-100 rounded-md p-1 bg-white flex items-center justify-center">
                    <Image 
                      src={coupon.image} 
                      alt={coupon.brand} 
                      width={70} 
                      height={70}
                      className="object-contain mix-blend-multiply"
                    />
                 </div>
                 <div className="flex flex-col">
                    <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider mb-1">{coupon.brand}</span>
                    <span className="font-black text-xl md:text-2xl text-red-600 tracking-tight leading-none mb-2">{coupon.discount}</span>
                    <p className="text-sm text-neutral-700 leading-tight mb-2 line-clamp-2">{coupon.description}</p>
                    <span className="text-xs font-semibold text-neutral-400 mt-auto">{coupon.expiresAt}</span>
                 </div>
              </div>
              <div className="mt-auto bg-neutral-50 p-4 border-t border-neutral-100">
                <button 
                  onClick={() => toggleClip(coupon.id)}
                  className={`w-full h-10 rounded-md font-bold flex items-center justify-center gap-2 transition-all ${coupon.isClipped ? 'bg-green-100 text-green-800 hover:bg-green-200' : 'bg-black text-white hover:bg-[#FFD200] hover:text-black'}`}
                >
                  {coupon.isClipped ? (
                    <>
                      <Check size={18} /> Clipped
                    </>
                  ) : (
                    <>
                      <Plus size={18} /> Clip Coupon
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>

      </main>
      <Footer />
    </div>
  );
}
