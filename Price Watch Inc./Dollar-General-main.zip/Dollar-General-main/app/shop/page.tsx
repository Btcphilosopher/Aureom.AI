import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Filters } from '@/components/shop/Filters';
import { ProductCard } from '@/components/ui/ProductCard';
import { products } from '@/data/mock';
import { ChevronDown, SlidersHorizontal } from 'lucide-react';

export default function Shop() {
  return (
    <div className="min-h-screen flex flex-col bg-white text-black font-sans">
      <Header />
      
      <main className="flex-1 flex flex-col max-w-7xl mx-auto w-full px-4 md:px-8 py-8">
        
        {/* Breadcrumb & Title */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-xs text-neutral-500 mb-2">
            <span>Home</span>
            <span>/</span>
            <span className="text-black font-semibold">Shop All Products</span>
          </div>
          <h1 className="text-3xl font-black uppercase tracking-tight">Shop All Products</h1>
        </div>

        {/* Top Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between py-4 border-y border-neutral-200 mb-8 gap-4">
          <div className="text-sm font-semibold text-neutral-500">
            Showing 1-{products.length} of {products.length} Results
          </div>
          <div className="flex items-center gap-4">
            <button className="md:hidden flex items-center gap-2 text-sm font-semibold border border-neutral-300 px-4 py-2 rounded-md">
              <SlidersHorizontal size={16} /> Filters
            </button>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold hidden sm:block">Sort by:</span>
              <div className="relative border border-neutral-300 rounded-md px-3 py-2 flex items-center gap-2 cursor-pointer hover:border-black transition-colors bg-white">
                <span className="text-sm">Relevance</span>
                <ChevronDown size={16} />
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-8 relative items-start">
          {/* Sidebar */}
          <aside className="hidden md:block w-64 shrink-0 sticky top-24">
            <Filters />
          </aside>

          {/* Product Grid */}
          <div className="flex-1">
            <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
              {products.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
              {/* Duplicate for demo volume */}
              {products.map(product => (
                <ProductCard key={`${product.id}-dup`} product={{...product, id: `${product.id}-dup`}} />
              ))}
            </div>

            {/* Pagination Placeholder */}
            <div className="flex justify-center mt-12 mb-8">
              <button className="border-2 border-black px-8 py-3 rounded-md font-bold text-sm hover:bg-black hover:text-white transition-colors">
                Load More
              </button>
            </div>
          </div>
        </div>

      </main>

      <Footer />
    </div>
  );
}
