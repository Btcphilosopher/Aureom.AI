import Image from 'next/image';
import Link from 'next/link';
import { Star, Heart, Share2, MapPin, Truck, Store, Plus, Minus, ChevronRight } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { products } from '@/data/mock';
import { Button } from '@/components/ui/Button';
import { notFound } from 'next/navigation';

export default async function ProductPage(props: { params: Promise<{ id: string }> }) {
  const params = await props.params;
  
  // In a real app, we'd fetch the product based on params.id
  // Using the first product for demo if ID isn't matched
  const product = products.find(p => p.id === params.id) || products[0];

  if (!product) {
    notFound();
  }

  return (
    <div className="min-h-screen flex flex-col bg-white text-black font-sans">
      <Header />
      
      <main className="flex-1 flex flex-col max-w-7xl mx-auto w-full px-4 md:px-8 py-8">
        
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-neutral-500 mb-6">
          <Link href="/" className="hover:underline">Home</Link>
          <ChevronRight size={12} />
          <Link href="/shop" className="hover:underline">Shop</Link>
          <ChevronRight size={12} />
          <Link href={`/category/${product.category.toLowerCase().replace(/\s+/g, '-')}`} className="hover:underline">{product.category}</Link>
          <ChevronRight size={12} />
          <span className="text-black font-semibold truncate max-w-[200px]">{product.name}</span>
        </div>

        <div className="flex flex-col lg:flex-row gap-12">
          
          {/* Images */}
          <div className="w-full lg:w-1/2 flex flex-col-reverse lg:flex-row gap-4">
            <div className="flex lg:flex-col gap-2 overflow-x-auto lg:overflow-visible">
               {[1,2,3,4].map(i => (
                 <button key={i} className={`w-20 h-20 border rounded-md overflow-hidden shrink-0 ${i === 1 ? 'border-black' : 'border-neutral-200 hover:border-black/50'}`}>
                   <Image 
                      src={product.image} 
                      alt="Thumbnail" 
                      width={80} 
                      height={80} 
                      className="object-contain w-full h-full mix-blend-multiply"
                    />
                 </button>
               ))}
            </div>
            <div className="flex-1 relative aspect-square border border-neutral-200 rounded-lg overflow-hidden bg-neutral-50 flex items-center justify-center p-8">
              {product.badge && (
                <span className="absolute top-4 left-4 z-10 bg-[#FFD200] text-black text-xs font-bold px-3 py-1 uppercase tracking-wider rounded-sm shadow-sm">
                  {product.badge}
                </span>
              )}
              <Image 
                src={product.image} 
                alt={product.name} 
                fill
                className="object-contain mix-blend-multiply p-8"
              />
            </div>
          </div>

          {/* Details */}
          <div className="w-full lg:w-1/2 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-neutral-500">{product.brand}</span>
              <div className="flex gap-2">
                <button className="p-2 hover:bg-neutral-100 rounded-full transition-colors">
                  <Share2 size={20} />
                </button>
                <button className="p-2 hover:bg-neutral-100 rounded-full transition-colors hover:text-red-500">
                  <Heart size={20} />
                </button>
              </div>
            </div>
            
            <h1 className="text-3xl md:text-4xl font-black leading-tight mb-4">
              {product.name}
            </h1>

            <div className="flex items-center gap-2 mb-6">
              <div className="flex text-[#FFD200]">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star 
                    key={star} 
                    size={16} 
                    className={star <= Math.round(product.rating) ? 'fill-[#FFD200]' : 'text-neutral-300'} 
                  />
                ))}
              </div>
              <span className="text-sm font-semibold underline cursor-pointer">{product.rating} ({product.reviewCount} Reviews)</span>
            </div>

            <div className="flex items-end gap-3 mb-6">
              <span className="text-4xl font-black tracking-tight">${product.price.toFixed(2)}</span>
              {product.originalPrice && (
                <span className="text-lg text-neutral-500 line-through mb-1">${product.originalPrice.toFixed(2)}</span>
              )}
            </div>

            <p className="text-neutral-600 mb-8 pb-8 border-b border-neutral-200 text-sm leading-relaxed">
              {product.description}
            </p>

            {/* Add to Cart Area */}
            <div className="flex flex-col gap-4 mb-8">
               <div className="flex items-center gap-4">
                  <div className="flex items-center border border-black rounded-md h-12 w-32">
                    <button className="flex-1 flex items-center justify-center hover:bg-neutral-100 transition-colors h-full"><Minus size={18} /></button>
                    <span className="font-bold w-8 text-center">1</span>
                    <button className="flex-1 flex items-center justify-center hover:bg-neutral-100 transition-colors h-full"><Plus size={18} /></button>
                  </div>
                  <Button size="lg" className="flex-1 h-12 text-lg">
                    Add to Cart
                  </Button>
               </div>
            </div>

            {/* Availability */}
            <div className="flex flex-col gap-3 bg-neutral-50 p-6 rounded-lg border border-neutral-200">
              <h3 className="font-bold mb-2">How to get it</h3>
              
              <div className="flex items-start gap-3">
                <Store size={20} className="mt-0.5 text-neutral-600" />
                <div className="flex-1">
                   <div className="font-bold text-sm">Pickup in Store</div>
                   <div className="text-xs text-neutral-500 mb-1">Available today at <span className="font-semibold underline cursor-pointer">Main St. Store</span></div>
                </div>
                <div className="w-4 h-4 rounded-full border-4 border-black bg-white shrink-0 mt-0.5"></div>
              </div>
              
              <div className="border-t border-neutral-200 my-2"></div>

              <div className="flex items-start gap-3 opacity-50">
                <Truck size={20} className="mt-0.5" />
                <div className="flex-1">
                   <div className="font-bold text-sm">Shipping</div>
                   <div className="text-xs">Currently unavailable for this item.</div>
                </div>
                <div className="w-4 h-4 rounded-full border-2 border-neutral-300 shrink-0 mt-0.5"></div>
              </div>
            </div>

          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
