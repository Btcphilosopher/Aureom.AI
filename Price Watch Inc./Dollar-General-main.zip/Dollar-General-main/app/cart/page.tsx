import Link from 'next/link';
import Image from 'next/image';
import { Trash2, Plus, Minus, ArrowRight, ShieldCheck } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { products } from '@/data/mock';
import { Button } from '@/components/ui/Button';

export default function CartPage() {
  // Mock cart items using the first two products
  const cartItems = [
    { product: products[0], quantity: 2 },
    { product: products[1], quantity: 1 },
  ];

  const subtotal = cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
  const estimatedTax = subtotal * 0.08;
  const total = subtotal + estimatedTax;

  return (
    <div className="min-h-screen flex flex-col bg-white text-black font-sans">
      <Header />
      
      <main className="flex-1 flex flex-col max-w-7xl mx-auto w-full px-4 md:px-8 py-8 md:py-12">
        <h1 className="text-3xl md:text-4xl font-black uppercase tracking-tight mb-8">Shopping Cart ({cartItems.length})</h1>

        <div className="flex flex-col lg:flex-row gap-12 items-start">
          
          {/* Cart Items List */}
          <div className="w-full lg:w-2/3 flex flex-col gap-6">
            <div className="hidden md:grid grid-cols-12 gap-4 pb-4 border-b border-black text-sm font-bold uppercase tracking-wider text-neutral-500">
              <div className="col-span-6">Product</div>
              <div className="col-span-3 text-center">Quantity</div>
              <div className="col-span-3 text-right">Total</div>
            </div>

            {cartItems.map((item) => (
              <div key={item.product.id} className="flex flex-col md:grid md:grid-cols-12 gap-4 py-6 border-b border-neutral-200">
                {/* Product Info */}
                <div className="col-span-6 flex gap-4">
                  <div className="w-24 h-24 shrink-0 bg-neutral-50 rounded-md border border-neutral-200 p-2">
                    <Image 
                      src={item.product.image} 
                      alt={item.product.name} 
                      width={80} 
                      height={80}
                      className="w-full h-full object-contain mix-blend-multiply"
                    />
                  </div>
                  <div className="flex flex-col justify-between py-1">
                    <div>
                      <h3 className="font-bold text-sm md:text-base leading-tight mb-1">{item.product.name}</h3>
                      <p className="text-xs text-neutral-500 mb-2">{item.product.brand}</p>
                    </div>
                    <div className="md:hidden font-black text-lg">${item.product.price.toFixed(2)}</div>
                    <button className="text-xs font-semibold text-neutral-500 hover:text-red-500 flex items-center gap-1 transition-colors w-max">
                      <Trash2 size={14} /> Remove
                    </button>
                  </div>
                </div>

                {/* Quantity */}
                <div className="col-span-3 flex items-center md:justify-center mt-4 md:mt-0">
                  <div className="flex items-center border border-black rounded-md h-10 w-28">
                    <button className="flex-1 flex items-center justify-center hover:bg-neutral-100 transition-colors h-full"><Minus size={16} /></button>
                    <span className="font-bold w-8 text-center text-sm">{item.quantity}</span>
                    <button className="flex-1 flex items-center justify-center hover:bg-neutral-100 transition-colors h-full"><Plus size={16} /></button>
                  </div>
                </div>

                {/* Total */}
                <div className="col-span-3 hidden md:flex items-center justify-end font-black text-xl">
                  ${(item.product.price * item.quantity).toFixed(2)}
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="w-full lg:w-1/3 bg-neutral-50 border border-neutral-200 rounded-xl p-6 sticky top-24">
            <h2 className="font-black text-xl mb-6">Order Summary</h2>
            
            <div className="flex flex-col gap-3 text-sm border-b border-neutral-200 pb-6 mb-6">
              <div className="flex justify-between">
                <span className="text-neutral-600">Subtotal</span>
                <span className="font-semibold">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Estimated Shipping</span>
                <span className="font-semibold">Calculated at checkout</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-600">Estimated Tax</span>
                <span className="font-semibold">${estimatedTax.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-between items-end mb-8">
              <span className="font-bold text-lg">Total</span>
              <span className="font-black text-3xl tracking-tight">${total.toFixed(2)}</span>
            </div>

            <div className="flex flex-col gap-3">
              <Button size="lg" className="w-full h-14 text-lg">
                Proceed to Checkout
              </Button>
              <Link href="/shop" className="w-full">
                <Button variant="outline" size="lg" className="w-full h-14">
                  Continue Shopping
                </Button>
              </Link>
            </div>

            <div className="mt-6 flex items-center justify-center gap-2 text-xs text-neutral-500">
               <ShieldCheck size={16} /> Secure Checkout
            </div>
          </div>
        </div>

      </main>
      <Footer />
    </div>
  );
}
