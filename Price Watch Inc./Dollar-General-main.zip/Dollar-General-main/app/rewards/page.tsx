import Image from 'next/image';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/Button';
import { ChevronRight, Gift, ReceiptText, MapPin } from 'lucide-react';

export default function RewardsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 text-black font-sans">
      <Header />
      
      <main className="flex-1 flex flex-col max-w-5xl mx-auto w-full px-4 md:px-8 py-8 md:py-12">
        
        {/* Dashboard Header */}
        <div className="bg-black rounded-2xl p-8 md:p-12 text-white relative overflow-hidden mb-8">
           <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
             <div className="flex flex-col text-center md:text-left">
                <span className="text-[#FFD200] font-black text-sm uppercase tracking-widest mb-2">$DG Digital Rewards</span>
                <h1 className="text-3xl md:text-5xl font-black mb-2">Welcome back, Sarah!</h1>
                <p className="text-neutral-400">You&apos;re 150 points away from your next $5 reward.</p>
             </div>
             
             <div className="bg-white/10 border border-white/20 p-6 rounded-xl flex flex-col items-center justify-center min-w-[240px] backdrop-blur-sm">
                <span className="text-xs font-bold text-neutral-300 uppercase tracking-widest mb-1">Available Balance</span>
                <div className="flex items-end gap-1 mb-2">
                  <span className="text-5xl font-black text-[#FFD200] tracking-tighter leading-none">850</span>
                  <span className="font-bold text-neutral-300 pb-1">pts</span>
                </div>
                {/* Progress bar */}
                <div className="w-full bg-white/20 h-2 rounded-full mt-4 mb-2 overflow-hidden">
                  <div className="bg-[#FFD200] h-full rounded-full" style={{ width: '85%' }}></div>
                </div>
                <span className="text-[10px] text-neutral-400 font-medium">1000 pts = $5 Reward</span>
             </div>
           </div>
           
           {/* Decorative Background Elements */}
           <div className="absolute -right-20 -bottom-20 w-80 h-80 border-[40px] border-white/5 rounded-full pointer-events-none"></div>
           <div className="absolute top-10 left-10 w-4 h-4 bg-[#FFD200] rounded-full opacity-20 pointer-events-none"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Quick Actions */}
          <div className="md:col-span-2 flex flex-col gap-6">
            <h2 className="font-black text-2xl uppercase tracking-tight">Your Rewards</h2>
            
            <div className="grid sm:grid-cols-2 gap-4">
               {/* Available Reward */}
               <div className="bg-white border border-neutral-200 rounded-xl p-6 flex flex-col justify-between hover:border-black transition-colors group cursor-pointer shadow-sm">
                 <div className="flex justify-between items-start mb-6">
                    <div className="bg-green-100 text-green-700 w-12 h-12 rounded-full flex items-center justify-center">
                      <Gift size={24} />
                    </div>
                    <span className="bg-green-100 text-green-700 text-xs font-bold px-2 py-1 rounded-sm uppercase">Available</span>
                 </div>
                 <div>
                    <h3 className="font-black text-3xl mb-1 text-green-700">$5 Off</h3>
                    <p className="text-sm font-semibold text-neutral-600 mb-4">Any purchase of $5.01 or more.</p>
                    <button className="text-sm font-bold flex items-center gap-1 group-hover:text-[#FFD200] transition-colors">
                      Redeem in store <ChevronRight size={16} />
                    </button>
                 </div>
               </div>

               {/* Upcoming Reward */}
               <div className="bg-white border border-neutral-200 rounded-xl p-6 flex flex-col justify-between opacity-70">
                 <div className="flex justify-between items-start mb-6">
                    <div className="bg-neutral-100 text-neutral-400 w-12 h-12 rounded-full flex items-center justify-center">
                      <Gift size={24} />
                    </div>
                    <span className="bg-neutral-100 text-neutral-500 text-xs font-bold px-2 py-1 rounded-sm uppercase">150 pts away</span>
                 </div>
                 <div>
                    <h3 className="font-black text-3xl mb-1 text-neutral-400">$5 Off</h3>
                    <p className="text-sm font-semibold text-neutral-500 mb-4">Any purchase of $5.01 or more.</p>
                    <div className="w-full bg-neutral-100 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-black h-full rounded-full" style={{ width: '85%' }}></div>
                    </div>
                 </div>
               </div>
            </div>

            <div className="mt-4 bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-sm">
              <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
                 <h3 className="font-bold text-lg">Recent Transactions</h3>
                 <button className="text-sm font-semibold underline text-neutral-500 hover:text-black">View All</button>
              </div>
              <div className="flex flex-col">
                 {[
                   { store: 'Main St. Store', date: 'Aug 24, 2026', pts: '+45' },
                   { store: 'Online Order', date: 'Aug 18, 2026', pts: '+120' },
                   { store: 'Westside Store', date: 'Aug 02, 2026', pts: '+30' }
                 ].map((t, i) => (
                   <div key={i} className="flex items-center justify-between p-4 px-6 border-b border-neutral-100 last:border-0 hover:bg-neutral-50 transition-colors">
                      <div className="flex items-center gap-4">
                         <div className="bg-neutral-100 p-2 rounded-md">
                           {t.store.includes('Online') ? <ReceiptText size={20} className="text-neutral-600" /> : <MapPin size={20} className="text-neutral-600" />}
                         </div>
                         <div className="flex flex-col">
                            <span className="font-semibold">{t.store}</span>
                            <span className="text-xs text-neutral-500">{t.date}</span>
                         </div>
                      </div>
                      <span className="font-black text-green-600">{t.pts} pts</span>
                   </div>
                 ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="flex flex-col gap-6">
            <div className="bg-[#FFD200] rounded-xl p-6 relative overflow-hidden shadow-sm">
              <div className="relative z-10">
                <h3 className="font-black text-xl leading-tight mb-2 uppercase">Scan to earn</h3>
                <p className="font-medium text-sm mb-6">Show this barcode at checkout to earn points.</p>
                <div className="bg-white p-4 rounded-md flex items-center justify-center mb-4 border border-black/10">
                   {/* Fake Barcode */}
                   <div className="flex h-12 w-full gap-[2px] items-end justify-between px-2">
                     {[...Array(30)].map((_, i) => (
                       <div key={i} className={`bg-black h-full ${i % 3 === 0 ? 'w-1' : i % 5 === 0 ? 'w-1.5' : 'w-0.5'}`}></div>
                     ))}
                   </div>
                </div>
                <div className="text-center font-bold font-mono tracking-widest text-sm">4902 1045 2841 9901</div>
              </div>
            </div>
            
            <div className="bg-white border border-neutral-200 rounded-xl p-6 shadow-sm">
               <h3 className="font-bold text-lg mb-4">Member Benefits</h3>
               <ul className="flex flex-col gap-4">
                 <li className="flex items-start gap-3">
                   <div className="bg-[#FFD200]/20 text-black p-1.5 rounded-full mt-0.5"><Check size={14} strokeWidth={3} /></div>
                   <div className="flex-1">
                     <span className="font-bold text-sm block mb-0.5">Exclusive Coupons</span>
                     <span className="text-xs text-neutral-500">Access to member-only digital coupons.</span>
                   </div>
                 </li>
                 <li className="flex items-start gap-3">
                   <div className="bg-[#FFD200]/20 text-black p-1.5 rounded-full mt-0.5"><Check size={14} strokeWidth={3} /></div>
                   <div className="flex-1">
                     <span className="font-bold text-sm block mb-0.5">Birthday Gift</span>
                     <span className="text-xs text-neutral-500">A special surprise on your big day.</span>
                   </div>
                 </li>
               </ul>
            </div>
          </div>

        </div>

      </main>
      <Footer />
    </div>
  );
}

// Temporary Check icon since we didn't import it at the top level
function Check({ size, strokeWidth, className }: any) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" className={className}>
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  );
}
