import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Hero } from '@/components/home/Hero';
import { PromoGrid } from '@/components/home/PromoGrid';
import { CategoryNav } from '@/components/home/CategoryNav';
import { FeaturedProducts } from '@/components/home/FeaturedProducts';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white text-black font-sans">
      <Header />
      
      <main className="flex-1 flex flex-col">
        <Hero />
        <PromoGrid />
        <CategoryNav />
        <FeaturedProducts />
        
        {/* Secondary banner */}
        <section className="w-full bg-[#FFD200] py-16 mt-12">
          <div className="max-w-7xl mx-auto px-4 md:px-8 text-center flex flex-col items-center">
            <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tight mb-4 text-black">Get More With The DG App</h2>
            <p className="text-lg md:text-xl font-medium mb-8 max-w-2xl text-black">
              Download our app to access digital coupons, track your rewards, and skip the line with DG GO!
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-black text-white px-8 py-3 rounded-md font-bold text-lg hover:bg-neutral-800 transition-colors">
                Download for iOS
              </button>
              <button className="bg-black text-white px-8 py-3 rounded-md font-bold text-lg hover:bg-neutral-800 transition-colors">
                Download for Android
              </button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
