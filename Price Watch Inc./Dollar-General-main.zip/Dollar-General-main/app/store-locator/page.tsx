'use client';

import { useState } from 'react';
import { Search, MapPin, Clock, Phone, Navigation } from 'lucide-react';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/Button';

export default function StoreLocatorPage() {
  const [stores, setStores] = useState([
    {
      id: '1',
      name: 'Dollar General #1452',
      address: '123 Main St, Springfield, IL 62701',
      distance: '0.8 miles',
      hours: '8:00 AM - 10:00 PM',
      phone: '(555) 123-4567',
      services: ['DG GO!', 'Western Union', 'FedEx Dropoff', 'Fresh Produce']
    },
    {
      id: '2',
      name: 'Dollar General #8993',
      address: '456 Oak Ave, Springfield, IL 62702',
      distance: '2.4 miles',
      hours: '8:00 AM - 9:00 PM',
      phone: '(555) 987-6543',
      services: ['Western Union', 'Propane Exchange']
    },
    {
      id: '3',
      name: 'Dollar General Market #1024',
      address: '789 Pine Blvd, Springfield, IL 62703',
      distance: '3.1 miles',
      hours: '7:00 AM - 10:00 PM',
      phone: '(555) 456-7890',
      services: ['Fresh Produce', 'Meat & Dairy', 'DG GO!', 'Western Union']
    }
  ]);

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 text-black font-sans">
      <Header />
      
      <main className="flex-1 flex flex-col md:flex-row h-full">
        
        {/* Sidebar / List */}
        <div className="w-full md:w-[400px] lg:w-[480px] bg-white flex flex-col border-r border-neutral-200 h-[calc(100vh-112px)] overflow-y-auto">
           <div className="p-6 border-b border-neutral-200 sticky top-0 bg-white z-10 shadow-sm">
              <h1 className="text-2xl font-black mb-4">Find a Store</h1>
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Enter ZIP code or City, State" 
                  className="w-full h-12 pl-4 pr-12 border border-neutral-300 rounded-md focus:outline-none focus:border-black focus:ring-1 focus:ring-black"
                  defaultValue="62701"
                />
                <button className="absolute right-0 top-0 h-12 w-12 flex items-center justify-center text-black hover:bg-neutral-100 transition-colors rounded-r-md">
                  <Search size={20} />
                </button>
              </div>
              <button className="mt-3 flex items-center gap-2 text-sm font-semibold text-blue-600 hover:underline">
                <MapPin size={16} /> Use my current location
              </button>
           </div>
           
           <div className="flex flex-col">
              {stores.map((store, i) => (
                <div key={store.id} className={`p-6 border-b border-neutral-200 hover:bg-neutral-50 cursor-pointer transition-colors ${i === 0 ? 'bg-neutral-50' : ''}`}>
                   <div className="flex justify-between items-start mb-2">
                     <h3 className="font-bold text-lg">{store.name}</h3>
                     <span className="text-sm font-semibold text-neutral-500">{store.distance}</span>
                   </div>
                   <p className="text-sm text-neutral-600 mb-4">{store.address}</p>
                   
                   <div className="flex flex-col gap-2 mb-4">
                     <div className="flex items-center gap-2 text-sm">
                       <Clock size={16} className="text-green-600" />
                       <span className="font-semibold text-green-600">Open until 10:00 PM</span>
                       <span className="text-neutral-500 text-xs">({store.hours})</span>
                     </div>
                     <div className="flex items-center gap-2 text-sm text-neutral-600">
                       <Phone size={16} />
                       {store.phone}
                     </div>
                   </div>

                   <div className="flex flex-wrap gap-1 mb-4">
                     {store.services.map(service => (
                       <span key={service} className="bg-neutral-100 text-neutral-600 text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-sm">
                         {service}
                       </span>
                     ))}
                   </div>

                   <div className="flex gap-2 mt-4">
                     <Button className="flex-1" size="sm">Make My Store</Button>
                     <Button variant="outline" className="flex-1" size="sm">
                       <Navigation size={16} className="mr-2" /> Directions
                     </Button>
                   </div>
                </div>
              ))}
           </div>
        </div>

        {/* Map Area */}
        <div className="flex-1 bg-neutral-200 relative min-h-[400px] md:min-h-0 hidden md:block">
           {/* Abstract Map Background */}
           <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cartographer.png')] opacity-30 mix-blend-overlay pointer-events-none"></div>
           
           {/* Fake Map Markers */}
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
             <div className="bg-black text-white px-3 py-1 font-bold text-sm rounded-md shadow-lg mb-1 whitespace-nowrap">
               Dollar General #1452
             </div>
             <div className="text-black bg-[#FFD200] w-10 h-10 rounded-full flex items-center justify-center shadow-xl border-4 border-white cursor-pointer hover:scale-110 transition-transform z-10">
               <span className="font-black text-sm tracking-tighter leading-none">$DG</span>
             </div>
             <div className="w-1 h-6 bg-black"></div>
           </div>

           <div className="absolute top-1/4 left-1/3 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center opacity-70 hover:opacity-100 transition-opacity cursor-pointer">
             <div className="text-black bg-white w-8 h-8 rounded-full flex items-center justify-center shadow-lg border-2 border-black">
               <span className="font-black text-xs tracking-tighter leading-none">$DG</span>
             </div>
           </div>
           
           <div className="absolute bottom-1/3 right-1/4 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center opacity-70 hover:opacity-100 transition-opacity cursor-pointer">
             <div className="text-black bg-white w-8 h-8 rounded-full flex items-center justify-center shadow-lg border-2 border-black">
               <span className="font-black text-xs tracking-tighter leading-none">$DG</span>
             </div>
           </div>

           {/* Zoom Controls */}
           <div className="absolute bottom-6 right-6 flex flex-col bg-white rounded-md shadow-md overflow-hidden border border-neutral-200">
             <button className="w-10 h-10 flex items-center justify-center hover:bg-neutral-100 border-b border-neutral-200">
               <Plus size={20} />
             </button>
             <button className="w-10 h-10 flex items-center justify-center hover:bg-neutral-100">
               <Minus size={20} />
             </button>
           </div>
        </div>

      </main>
      {/* We usually don't put a huge footer on full height map layouts, but we can keep it hidden on md for full experience */}
      <div className="block md:hidden">
         <Footer />
      </div>
    </div>
  );
}

// Quick placeholder icons
function Plus({ size, className }: any) {
  return <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
}
function Minus({ size, className }: any) {
  return <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><line x1="5" y1="12" x2="19" y2="12"></line></svg>
}
