import type {Metadata} from 'next';
import { Outfit, DM_Sans } from 'next/font/google';
import './globals.css';
import { MobileBottomNav } from '@/components/layout/MobileBottomNav';

const outfit = Outfit({ 
  subsets: ['latin'],
  variable: '--font-outfit',
  display: 'swap',
});

const dmSans = DM_Sans({ 
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Dollar General Concept',
  description: 'Next-generation ecommerce platform concept for Dollar General.',
  openGraph: {
    title: 'Dollar General Concept',
    description: 'Next-generation ecommerce platform concept for Dollar General.',
    type: 'website',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${outfit.variable} ${dmSans.variable}`}>
      <body className="font-sans antialiased text-base pb-16 md:pb-0" suppressHydrationWarning>
        {children}
        <MobileBottomNav />
      </body>
    </html>
  );
}
