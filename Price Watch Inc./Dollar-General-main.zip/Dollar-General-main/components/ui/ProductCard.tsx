import Link from 'next/link';
import Image from 'next/image';
import { Heart, Star, Plus } from 'lucide-react';
import { Product } from '@/data/mock';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <div className="group relative flex flex-col bg-white border-2 border-black overflow-hidden transition-all duration-300 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1">
      
      {/* Badges & Actions */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
        {product.badge && (
          <span className="bg-[#FFD200] border border-black text-black text-[10px] font-black px-2 py-1 uppercase tracking-wider shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
            {product.badge}
          </span>
        )}
      </div>
      <button className="absolute top-3 right-3 z-10 p-2 bg-white border-2 border-black text-neutral-400 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:text-red-500 hover:bg-neutral-50 transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100">
        <Heart size={20} />
      </button>

      {/* Image Area */}
      <Link href={`/product/${product.id}`} className="relative aspect-square w-full bg-white border-b-2 border-black overflow-hidden flex items-center justify-center p-6">
        <Image 
          src={product.image}
          alt={product.name}
          width={400}
          height={400}
          className="object-contain w-full h-full mix-blend-multiply transition-transform duration-500 group-hover:scale-105"
          referrerPolicy="no-referrer"
        />
      </Link>

      {/* Details */}
      <div className="p-4 flex flex-col flex-1 bg-white">
        <div className="flex items-center gap-1 mb-2">
          <div className="flex text-[#FFD200]">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star 
                key={star} 
                size={14} 
                className={star <= Math.round(product.rating) ? 'fill-[#FFD200]' : 'text-neutral-300'} 
              />
            ))}
          </div>
          <span className="text-xs font-bold text-neutral-500">({product.reviewCount})</span>
        </div>

        <Link href={`/product/${product.id}`} className="flex-1">
          <h3 className="font-black text-base leading-tight text-black group-hover:underline decoration-2 underline-offset-2 mb-1 line-clamp-2 uppercase">
            {product.name}
          </h3>
          <p className="text-xs font-bold text-neutral-500 mb-3 uppercase">{product.brand}</p>
        </Link>

        <div className="mt-auto flex items-end justify-between pt-2">
          <div className="flex flex-col">
            {product.originalPrice && (
              <span className="text-xs font-bold text-neutral-500 line-through">${product.originalPrice.toFixed(2)}</span>
            )}
            <span className="font-black text-2xl leading-none">${product.price.toFixed(2)}</span>
          </div>
          
          <button className="h-10 w-10 bg-black border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] text-white flex items-center justify-center hover:bg-[#FFD200] hover:text-black transition-colors focus:outline-none hover:shadow-none hover:translate-x-[2px] hover:translate-y-[2px]">
            <Plus size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
