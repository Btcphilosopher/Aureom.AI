'use client';

import { useState } from 'react';
import { ChevronDown, Check } from 'lucide-react';
import { categories } from '@/data/mock';

export function Filters() {
  const [openSection, setOpenSection] = useState<string | null>('category');

  const toggleSection = (section: string) => {
    setOpenSection(openSection === section ? null : section);
  };

  return (
    <div className="w-full flex flex-col gap-1 pr-6">
      <h3 className="font-bold text-lg mb-4">Filters</h3>

      {/* Categories Filter */}
      <div className="border-b border-neutral-200 py-3">
        <button 
          className="w-full flex items-center justify-between font-semibold"
          onClick={() => toggleSection('category')}
        >
          <span>Category</span>
          <ChevronDown size={18} className={`transition-transform ${openSection === 'category' ? 'rotate-180' : ''}`} />
        </button>
        {openSection === 'category' && (
          <div className="pt-3 flex flex-col gap-2">
            {categories.map(cat => (
              <label key={cat.id} className="flex items-center gap-2 cursor-pointer group">
                <div className="w-5 h-5 border border-neutral-300 rounded-sm flex items-center justify-center group-hover:border-black transition-colors">
                   {/* Mock checkbox state */}
                   <Check size={14} className="text-white" />
                </div>
                <span className="text-sm text-neutral-600 group-hover:text-black transition-colors">{cat.name}</span>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* Price Filter */}
      <div className="border-b border-neutral-200 py-3">
        <button 
          className="w-full flex items-center justify-between font-semibold"
          onClick={() => toggleSection('price')}
        >
          <span>Price</span>
          <ChevronDown size={18} className={`transition-transform ${openSection === 'price' ? 'rotate-180' : ''}`} />
        </button>
        {openSection === 'price' && (
          <div className="pt-3 flex flex-col gap-2">
            {['Under $5', '$5 to $10', '$10 to $20', 'Over $20'].map((price, i) => (
              <label key={i} className="flex items-center gap-2 cursor-pointer group">
                <div className="w-5 h-5 border border-neutral-300 rounded-sm flex items-center justify-center group-hover:border-black transition-colors"></div>
                <span className="text-sm text-neutral-600 group-hover:text-black transition-colors">{price}</span>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* Brand Filter */}
      <div className="border-b border-neutral-200 py-3">
        <button 
          className="w-full flex items-center justify-between font-semibold"
          onClick={() => toggleSection('brand')}
        >
          <span>Brand</span>
          <ChevronDown size={18} className={`transition-transform ${openSection === 'brand' ? 'rotate-180' : ''}`} />
        </button>
        {openSection === 'brand' && (
          <div className="pt-3 flex flex-col gap-2">
            {['DG Home', 'Clover Valley', 'TrueLiving', 'DG Health'].map((brand, i) => (
              <label key={i} className="flex items-center gap-2 cursor-pointer group">
                <div className="w-5 h-5 border border-neutral-300 rounded-sm flex items-center justify-center group-hover:border-black transition-colors"></div>
                <span className="text-sm text-neutral-600 group-hover:text-black transition-colors">{brand}</span>
              </label>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
