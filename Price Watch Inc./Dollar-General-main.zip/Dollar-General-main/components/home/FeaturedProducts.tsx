import Link from 'next/link';
import { ProductCard } from '@/components/ui/ProductCard';
import { products } from '@/data/mock';

export function FeaturedProducts() {
  // Take first 4 for featured
  const featuredProducts = products.slice(0, 4);

  return (
    <section className="w-full max-w-7xl mx-auto px-4 md:px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-black uppercase tracking-tight">Everyday Low Prices</h2>
        <Link href="/shop" className="text-sm font-semibold underline hover:text-[#FFD200]">
          Shop All
        </Link>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
        {featuredProducts.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
}
