import Link from 'next/link';
import { Button } from '@/components/ui/Button';

export function Hero() {
  return (
    <section className="relative w-full bg-white text-black min-h-[600px] md:min-h-[500px] flex items-center overflow-hidden border-b-2 border-black">
      
      {/* Background Image Setup (Split Layout on Desktop) */}
      <div className="absolute inset-0 z-0 flex flex-col md:flex-row">
        {/* Left Side - Solid White */}
        <div className="w-full md:w-1/2 h-full bg-white z-10" />
        
        {/* Right Side - Image */}
        <div 
          className="absolute inset-0 md:inset-auto md:right-0 md:w-1/2 h-full bg-cover bg-center z-0 opacity-40 md:opacity-100"
          style={{ 
            backgroundImage: "linear-gradient(to right, white, transparent 30%), url('https://picsum.photos/seed/dgstore/1920/1080')", 
            backgroundPosition: "center right"
          }}
        >
        </div>
      </div>

      {/* Content */}
      <div className="relative z-20 w-full max-w-7xl mx-auto px-4 md:px-8 py-12 flex flex-col justify-center">
        <div className="max-w-2xl">
          <div className="mb-6 flex gap-2">
            <span className="bg-black text-[#FFD200] px-2 py-1 text-[10px] font-black uppercase tracking-widest">Next Gen Ecommerce</span>
            <span className="bg-neutral-100 text-black px-2 py-1 text-[10px] font-bold uppercase tracking-widest">Enterprise Scale</span>
          </div>
          <h1 className="text-6xl md:text-[88px] font-black tracking-tighter leading-[0.85] mb-6 uppercase">
            <span className="block">Save time.</span>
            <span className="block">Save money.</span>
            <span className="block text-[#FFD200] stroke-black" style={{ WebkitTextStroke: '2px black' }}>Every day!</span>
          </h1>
          <p className="text-xl text-neutral-600 mb-8 max-w-md font-medium">
            We&apos;re here for the moments that matter most with delivery, pickup, and thousands of new digital coupons.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="text-sm px-10">
              Shop Now
            </Button>
            <Button size="lg" variant="outline" className="text-sm px-10 border-black text-black hover:bg-neutral-50 hover:text-black">
              Find a Store
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
