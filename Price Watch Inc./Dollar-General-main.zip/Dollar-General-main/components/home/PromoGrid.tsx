import Link from 'next/link';
import { Button } from '@/components/ui/Button';

export function PromoGrid() {
  return (
    <section className="w-full max-w-7xl mx-auto px-4 md:px-8 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Card 1: Digital Coupons */}
        <div className="bg-[#FFD200] border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] p-6 relative overflow-hidden group flex flex-col justify-between min-h-[220px]">
          <div className="relative z-10 w-2/3">
            <h3 className="font-black text-xl leading-tight mb-2 uppercase">Save More With Digital Coupons</h3>
            <p className="font-medium text-sm mb-6">Add coupons in our app.</p>
            <Button variant="secondary" size="sm" className="w-max">View Coupons</Button>
          </div>
          {/* Abstract Phone/Coupon Graphic */}
          <div className="absolute -right-4 -bottom-4 w-32 h-40 border-4 border-black bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] z-0 rotate-12 transition-transform group-hover:rotate-6 flex items-center justify-center">
            <div className="bg-black text-white font-black text-center p-2 leading-none w-20">DG<br/><span className="text-[10px]">DIGITAL<br/>COUPONS</span></div>
          </div>
        </div>

        {/* Card 2: Weekly Ad */}
        <div className="bg-black text-white border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] p-6 relative overflow-hidden group flex flex-col justify-between min-h-[220px]">
          <div className="relative z-10 w-1/2">
            <h3 className="font-black text-xl leading-tight mb-2 uppercase">Weekly Ad</h3>
            <p className="font-medium text-sm text-neutral-300 mb-6">Check out this week&apos;s deals.</p>
            <Button variant="outline" size="sm" className="w-max border-[#FFD200] text-[#FFD200] hover:bg-[#FFD200] hover:text-black">View Ad</Button>
          </div>
          {/* Abstract Ad Graphic */}
          <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-white/10 border-l-2 border-white/20 z-0 p-2 overflow-hidden flex flex-col">
            <div className="bg-[#FFD200] text-black font-black text-xs p-1 text-center mb-2 uppercase">Dollar General</div>
            <div className="bg-black text-white text-[10px] font-bold text-center mb-2">LOW PRICES. EVERY DAY.</div>
            <div className="grid grid-cols-2 gap-2 flex-1">
               <div className="bg-white border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"></div>
               <div className="bg-white border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"></div>
               <div className="bg-white border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"></div>
               <div className="bg-white border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"></div>
            </div>
          </div>
        </div>

        {/* Card 3: $DG Digital Rewards */}
        <div className="bg-[#FFD200] border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] p-6 relative overflow-hidden group flex flex-col justify-between min-h-[220px]">
          <div className="relative z-10 w-2/3">
            <h3 className="font-black text-xl leading-tight mb-2 uppercase">$DG Digital Rewards</h3>
            <p className="font-medium text-sm mb-6">Earn points. Get rewards. Save more.</p>
            <Button variant="secondary" size="sm" className="w-max">Join Now</Button>
          </div>
          {/* Circular Rewards Graphic */}
          <div className="absolute -right-6 -bottom-6 w-32 h-32 rounded-full border-4 border-black bg-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex items-center justify-center transition-transform group-hover:scale-110">
             <div className="text-[#FFD200] font-black text-center leading-none text-2xl tracking-tighter">
                $DG<br/><span className="text-[8px] tracking-normal text-white">DIGITAL<br/>REWARDS</span>
             </div>
          </div>
        </div>

        {/* Card 4: Careers */}
        <div className="bg-white border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] p-6 relative overflow-hidden group flex flex-col justify-between min-h-[220px]">
          <div className="relative z-10 w-2/3">
            <h3 className="font-black text-xl leading-tight mb-2 uppercase text-black">Careers</h3>
            <p className="font-medium text-sm mb-6 text-neutral-600">Join our team and make a difference.</p>
            <Button variant="secondary" size="sm" className="w-max">Learn More</Button>
          </div>
          {/* Abstract Badge Graphic */}
          <div className="absolute -right-2 bottom-4 w-20 h-28 bg-[#FFD200] border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] rotate-12 transition-transform group-hover:rotate-6 flex flex-col">
             <div className="h-4 w-8 bg-black mx-auto -mt-2"></div>
             <div className="flex-1 flex items-center justify-center">
                <div className="w-8 h-8 rounded-full border-2 border-black bg-black relative overflow-hidden">
                   <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-4 bg-white/20 rounded-t-full"></div>
                   <div className="absolute top-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-white/20 rounded-full"></div>
                </div>
             </div>
          </div>
        </div>

      </div>
    </section>
  );
}
