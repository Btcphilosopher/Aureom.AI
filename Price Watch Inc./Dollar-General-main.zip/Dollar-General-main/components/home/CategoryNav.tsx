import Link from 'next/link';
import { categories } from '@/data/mock';
import * as LucideIcons from 'lucide-react';

export function CategoryNav() {
  return (
    <section className="w-full max-w-7xl mx-auto px-4 md:px-8 py-8 border-b border-neutral-100">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-xl font-bold">Shop by Category</h2>
        <Link href="/categories" className="text-sm font-semibold underline hover:text-[#FFD200]">
          View All Categories
        </Link>
      </div>
      
      <div className="flex overflow-x-auto pb-6 -mx-4 px-4 md:mx-0 md:px-0 gap-6 md:gap-8 justify-between no-scrollbar">
        {categories.map((category) => {
          // Dynamically grab the icon component
          const IconComponent = (LucideIcons as any)[category.icon] || LucideIcons.HelpCircle;
          
          return (
            <Link 
              key={category.id} 
              href={`/category/${category.slug}`}
              className="flex flex-col items-center gap-4 group min-w-[80px]"
            >
              <div className="w-16 h-16 rounded-full bg-neutral-100 flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:bg-[#FFD200] group-hover:shadow-md border border-transparent group-hover:border-black/5">
                <IconComponent className="w-8 h-8 text-black transition-transform group-hover:scale-110" strokeWidth={1.5} />
              </div>
              <span className="text-xs font-semibold text-center leading-tight">
                {category.name.split(' ').map((word, i) => (
                  <span key={i} className="block">{word}</span>
                ))}
              </span>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
