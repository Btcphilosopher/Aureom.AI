'use client';

import { useState, useRef, useEffect } from 'react';
import { Search, X, Clock, TrendingUp } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { products } from '@/data/mock';

export function SearchBar() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const recentSearches = ['paper towels', 'dog food', 'laundry detergent'];
  const trending = ['Halloween Candy', 'Back to School', 'Cleaning Supplies'];
  const suggestedProducts = products.slice(0, 3);

  return (
    <div className="flex flex-1 w-full relative" ref={wrapperRef}>
      <Search className="w-5 h-5 absolute left-4 top-3 text-neutral-400" />
      <input 
        type="text" 
        placeholder="Search for products, categories, & more" 
        className="w-full bg-neutral-100 border-none rounded-full py-3 px-12 text-sm focus:outline-none focus:ring-2 focus:ring-[#FFD200] text-black"
        onFocus={() => setIsOpen(true)}
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      
      {query && (
        <button 
          className="absolute right-4 top-3 h-5 w-5 flex items-center justify-center text-neutral-400 hover:text-black"
          onClick={() => setQuery('')}
        >
          <X size={16} />
        </button>
      )}

      {/* Dropdown */}
      {isOpen && (
        <div className="absolute top-full mt-2 left-0 w-full bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] border-2 border-black overflow-hidden z-50 text-black">
          {!query ? (
            <div className="p-4 grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-xs uppercase tracking-wider text-neutral-500 mb-3">Recent Searches</h4>
                <ul className="flex flex-col gap-2">
                  {recentSearches.map(s => (
                    <li key={s}>
                      <button className="flex items-center gap-2 text-sm hover:text-[#FFD200] transition-colors w-full text-left font-bold">
                        <Clock size={14} className="text-neutral-400" /> {s}
                      </button>
                    </li>
                  ))}
                </ul>

                <h4 className="font-bold text-xs uppercase tracking-wider text-neutral-500 mb-3 mt-6">Trending Now</h4>
                <ul className="flex flex-col gap-2">
                  {trending.map(s => (
                    <li key={s}>
                      <button className="flex items-center gap-2 text-sm hover:text-[#FFD200] transition-colors w-full text-left font-bold">
                        <TrendingUp size={14} className="text-neutral-400" /> {s}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="border-l border-neutral-200 pl-6">
                 <h4 className="font-bold text-xs uppercase tracking-wider text-neutral-500 mb-3">Popular Products</h4>
                 <div className="flex flex-col gap-3">
                   {suggestedProducts.map(p => (
                     <Link key={p.id} href={`/product/${p.id}`} className="flex items-center gap-3 group">
                       <div className="w-10 h-10 bg-neutral-50 border border-neutral-200 p-1">
                         <Image src={p.image} alt={p.name} width={32} height={32} className="w-full h-full object-contain mix-blend-multiply" />
                       </div>
                       <div className="flex flex-col">
                         <span className="text-sm font-bold group-hover:underline line-clamp-1">{p.name}</span>
                         <span className="text-xs font-black text-neutral-500">${p.price.toFixed(2)}</span>
                       </div>
                     </Link>
                   ))}
                 </div>
              </div>
            </div>
          ) : (
            <div className="p-4">
               <h4 className="font-bold text-xs uppercase tracking-wider text-neutral-500 mb-3">Search Results for &quot;{query}&quot;</h4>
               <div className="flex flex-col gap-3">
                 {suggestedProducts.map(p => (
                   <Link key={p.id} href={`/product/${p.id}`} className="flex items-center gap-3 group hover:bg-neutral-50 p-2 -mx-2">
                     <div className="w-12 h-12 bg-white border border-neutral-200 p-1">
                       <Image src={p.image} alt={p.name} width={40} height={40} className="w-full h-full object-contain mix-blend-multiply" />
                     </div>
                     <div className="flex flex-col flex-1">
                       <span className="text-sm font-bold group-hover:underline">{p.name}</span>
                       <span className="text-xs font-semibold text-neutral-500">{p.category}</span>
                     </div>
                     <span className="font-black">${p.price.toFixed(2)}</span>
                   </Link>
                 ))}
                 <Link href="/shop" className="text-sm font-black uppercase text-center pt-2 text-black hover:underline">
                   See all results
                 </Link>
               </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
