'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Search, MapPin, User, ShoppingCart, Menu, X, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { ShopMenu } from './ShopMenu';
import { SearchBar } from './SearchBar';

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(3); // Mock cart count

  return (
    <div className="sticky top-0 z-50 w-full flex flex-col font-sans text-black bg-white">
      {/* Top Nav (Yellow) */}
      <nav className="w-full bg-[#FFD200] px-4 md:px-6 py-2 flex justify-between items-center border-b border-black text-[11px] font-bold tracking-tight">
        <div className="flex gap-4 md:gap-6 items-center">
          <button 
            className="lg:hidden text-black"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          
          <Link href="/store-locator" className="hidden md:flex items-center gap-1 hover:underline">
            <MapPin size={12} fill="currentColor" /> Find a Store: <span className="underline">Nashville, TN 37203</span>
          </Link>
          <Link href="/weekly-ad" className="hidden md:inline hover:underline">Weekly Ad</Link>
          <Link href="/coupons" className="hidden md:inline hover:underline">Digital Coupons</Link>
        </div>
        <div className="flex gap-4 md:gap-6 uppercase items-center">
          <Link href="/login" className="hidden md:inline hover:underline">Sign In / Register</Link>
          <Link href="/cart" className="flex items-center gap-2 hover:underline">
            <ShoppingCart size={16} />
            Cart ({cartCount})
          </Link>
        </div>
      </nav>

      {/* Main Header */}
      <header className="px-4 md:px-6 py-4 flex items-center justify-between gap-4 md:gap-10 border-b border-neutral-100 bg-white">
        <Link href="/" className="flex-shrink-0 bg-black p-1">
          <div className="bg-[#FFD200] px-3 py-1 text-black font-black italic text-xl md:text-2xl tracking-tighter uppercase">DOLLAR GENERAL</div>
        </Link>
        
        <div className="hidden lg:flex flex-1 relative max-w-2xl">
          <SearchBar />
        </div>

        <div className="hidden lg:flex gap-8 font-bold text-sm items-center h-full">
          <div className="h-full flex items-center border-b-2 border-black">
             <ShopMenu />
          </div>
          <Link href="/shop" className="hover:text-[#FFD200] transition-colors">Deals</Link>
          <Link href="/rewards" className="hover:text-[#FFD200] transition-colors">$DG Rewards</Link>
        </div>
      </header>

      {/* Mobile Search - Visible only on mobile */}
      <div className="lg:hidden p-3 border-b border-neutral-100 bg-white">
        <div className="relative w-full">
           <SearchBar />
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 w-full h-[calc(100vh-120px)] bg-white text-black overflow-y-auto flex flex-col z-40 border-t border-black">
          <div className="p-4 flex flex-col gap-4">
            <Button variant="outline" className="w-full justify-start gap-2 border-2 border-black font-black uppercase rounded-none">
              <User size={18} /> Sign In / Register
            </Button>
            <Button variant="outline" className="w-full justify-start gap-2 border-2 border-black font-black uppercase rounded-none">
              <MapPin size={18} /> Find a Store
            </Button>
          </div>
          <div className="border-t border-black"></div>
          <nav className="flex flex-col p-2">
            {['Shop by Category', 'Deals', 'Digital Coupons', 'Weekly Ads', '$DG Digital Rewards', 'Careers'].map((item) => (
              <Link 
                key={item} 
                href="#" 
                className="p-4 font-black uppercase text-lg border-b border-neutral-100 flex items-center justify-between"
              >
                {item}
                <ChevronDown size={20} className="-rotate-90 text-black" />
              </Link>
            ))}
          </nav>
        </div>
      )}
    </div>
  );
}
