import Link from 'next/link';
import { Home, Search, LayoutGrid, ShoppingCart, User } from 'lucide-react';

export function MobileBottomNav() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-neutral-200 md:hidden pb-safe">
      <nav className="flex items-center justify-around h-16 px-2">
        <Link href="/" className="flex flex-col items-center justify-center w-full h-full text-black">
          <Home size={24} />
          <span className="text-[10px] font-semibold mt-1">Home</span>
        </Link>
        <Link href="/shop" className="flex flex-col items-center justify-center w-full h-full text-neutral-500 hover:text-black">
          <Search size={24} />
          <span className="text-[10px] font-semibold mt-1">Search</span>
        </Link>
        <Link href="/shop" className="flex flex-col items-center justify-center w-full h-full text-neutral-500 hover:text-black">
          <LayoutGrid size={24} />
          <span className="text-[10px] font-semibold mt-1">Shop</span>
        </Link>
        <Link href="/cart" className="flex flex-col items-center justify-center w-full h-full text-neutral-500 hover:text-black relative">
          <ShoppingCart size={24} />
          <span className="absolute top-2 right-4 bg-[#FFD200] text-black text-[8px] font-bold h-3 w-3 rounded-full flex items-center justify-center">
            3
          </span>
          <span className="text-[10px] font-semibold mt-1">Cart</span>
        </Link>
        <Link href="/rewards" className="flex flex-col items-center justify-center w-full h-full text-neutral-500 hover:text-black">
          <User size={24} />
          <span className="text-[10px] font-semibold mt-1">Account</span>
        </Link>
      </nav>
    </div>
  );
}
