'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Menu, ChevronDown, ChevronRight } from 'lucide-react';
import { categories } from '@/data/mock';

export function ShopMenu() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div 
      className="relative flex items-center h-full"
      onMouseEnter={() => setIsOpen(true)}
      onMouseLeave={() => setIsOpen(false)}
    >
      <button className="flex items-center gap-2 hover:text-[#FFD200] transition-colors group h-full">
        <Menu size={18} />
        <span>Shop by Category</span>
        <ChevronDown size={16} className={`transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Mega Menu Dropdown */}
      {isOpen && (
        <div className="absolute top-full left-0 w-[800px] bg-white text-black shadow-2xl rounded-b-lg border border-neutral-200 flex overflow-hidden z-50 animate-in fade-in slide-in-from-top-4 duration-200">
          
          {/* Main Categories */}
          <div className="w-1/3 bg-neutral-50 py-4 border-r border-neutral-200">
            {categories.map((cat) => (
              <Link 
                key={cat.id} 
                href={`/category/${cat.slug}`}
                className="flex items-center justify-between px-6 py-3 hover:bg-white hover:font-bold group transition-all"
              >
                <span className="text-sm">{cat.name}</span>
                <ChevronRight size={16} className="text-neutral-400 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all" />
              </Link>
            ))}
          </div>
          
          {/* Subcategories (Hardcoded for demo) */}
          <div className="w-2/3 p-8 flex flex-col">
            <h3 className="font-black text-xl mb-6 uppercase tracking-tight">Featured & Popular</h3>
            <div className="grid grid-cols-2 gap-8">
              <div>
                <h4 className="font-bold mb-3 border-b border-neutral-200 pb-2">Top Picks</h4>
                <ul className="flex flex-col gap-2 text-sm text-neutral-600">
                  <li><Link href="/shop" className="hover:text-black hover:underline">New Arrivals</Link></li>
                  <li><Link href="/shop" className="hover:text-black hover:underline">Clearance</Link></li>
                  <li><Link href="/shop" className="hover:text-black hover:underline">Dollar Deals</Link></li>
                  <li><Link href="/shop" className="hover:text-black hover:underline">Everyday Low Prices</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-3 border-b border-neutral-200 pb-2">Brands</h4>
                <ul className="flex flex-col gap-2 text-sm text-neutral-600">
                  <li><Link href="/shop" className="hover:text-black hover:underline">Clover Valley</Link></li>
                  <li><Link href="/shop" className="hover:text-black hover:underline">TrueLiving</Link></li>
                  <li><Link href="/shop" className="hover:text-black hover:underline">DG Home</Link></li>
                  <li><Link href="/shop" className="hover:text-black hover:underline">Office Essentials</Link></li>
                </ul>
              </div>
            </div>
            
            {/* Promo block in mega menu */}
            <div className="mt-8 bg-[#FFD200] rounded-lg p-6 flex items-center justify-between">
              <div>
                <div className="font-black uppercase leading-tight mb-1">Save $5 on your next purchase</div>
                <div className="text-sm">When you download the DG App</div>
              </div>
              <button className="bg-black text-white px-4 py-2 text-xs font-bold rounded-md hover:bg-neutral-800 transition-colors">
                Learn More
              </button>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
