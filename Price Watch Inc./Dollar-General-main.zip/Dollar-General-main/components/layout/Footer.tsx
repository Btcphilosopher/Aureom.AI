import Link from 'next/link';
import { MapPin, Smartphone, Mail, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export function Footer() {
  return (
    <footer className="w-full bg-black text-white p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 min-h-[200px] mt-16 font-sans">
      <div className="lg:border-r border-white/20 px-4 pb-6 lg:pb-0 border-b lg:border-b-0">
        <div className="text-[#FFD200] font-black text-xs uppercase mb-3 tracking-widest">Digital Coupons</div>
        <div className="text-2xl font-black mb-1 tracking-tighter">$2,400+</div>
        <div className="text-neutral-400 text-xs font-bold">Available in weekly savings. Clip and save instantly in-app.</div>
        <Link href="/coupons" className="mt-4 block text-[#FFD200] text-[10px] font-black uppercase underline hover:text-white transition-colors">View All Coupons</Link>
      </div>
      <div className="lg:border-r border-white/20 px-4 pb-6 lg:pb-0 border-b lg:border-b-0">
        <div className="text-[#FFD200] font-black text-xs uppercase mb-3 tracking-widest">Weekly Ad</div>
        <div className="flex gap-2 items-center mb-2">
          <div className="w-12 h-16 bg-neutral-800 rounded-sm border border-white/10 flex items-center justify-center font-black text-[8px] text-neutral-500 uppercase tracking-widest text-center leading-tight p-1">Weekly Ad</div>
          <div>
            <div className="font-black text-sm uppercase tracking-tighter">New Deals!</div>
            <div className="text-neutral-400 text-[10px] font-bold">Valid Oct 22 - Oct 28</div>
          </div>
        </div>
        <Link href="/weekly-ad" className="mt-2 block text-[#FFD200] text-[10px] font-black uppercase underline hover:text-white transition-colors">Browse Ad</Link>
      </div>
      <div className="lg:border-r border-white/20 px-4 pb-6 sm:pb-0 border-b sm:border-b-0">
        <div className="text-[#FFD200] font-black text-xs uppercase mb-3 tracking-widest">$DG Rewards</div>
        <div className="text-2xl font-black mb-1 tracking-tighter uppercase">Member Perks</div>
        <div className="text-neutral-400 text-xs font-bold">Earn points every time you shop. Unlock exclusive member items.</div>
        <Link href="/rewards" className="mt-4 block text-[#FFD200] text-[10px] font-black uppercase underline hover:text-white transition-colors">Join Now</Link>
      </div>
      <div className="px-4">
        <div className="text-[#FFD200] font-black text-xs uppercase mb-3 tracking-widest">Careers</div>
        <div className="text-2xl font-black mb-1 tracking-tighter uppercase">Join the Team</div>
        <div className="text-neutral-400 text-xs font-bold">Help us serve our neighbors. Over 19,000 stores nationwide.</div>
        <Link href="/careers" className="mt-4 block text-[#FFD200] text-[10px] font-black uppercase underline hover:text-white transition-colors">Apply Today</Link>
      </div>
    </footer>
  );
}
