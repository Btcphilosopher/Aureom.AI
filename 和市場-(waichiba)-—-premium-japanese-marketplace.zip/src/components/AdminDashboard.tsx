import React, { useState } from 'react';
import {
  TrendingUp,
  Package,
  Users,
  Award,
  Plus,
  Edit2,
  Check,
  X,
  MapPin,
  Sparkles
} from 'lucide-react';
import { Product, Artisan, Language, Order } from '../types';

interface AdminDashboardProps {
  products: Product[];
  artisans: Artisan[];
  language: Language;
  onUpdateProductStock: (id: string, newStock: number) => void;
  onAddProduct: (newProd: Partial<Product>) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  products,
  artisans,
  language,
  onUpdateProductStock,
  onAddProduct,
}) => {
  const isJa = language === 'ja';
  const [activeTab, setActiveTab] = useState<'analytics' | 'inventory' | 'orders' | 'vendors'>('analytics');

  // New product form state
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdNameJa, setNewProdNameJa] = useState('');
  const [newProdPrice, setNewProdPrice] = useState(25000);
  const [newProdPrefecture, setNewProdPrefecture] = useState('Kyoto');
  const [newProdPrefectureJa, setNewProdPrefectureJa] = useState('京都府');
  const [newProdCategory, setNewProdCategory] = useState('crafts');

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName || !newProdNameJa) return;

    onAddProduct({
      id: `prod-${Date.now()}`,
      name: newProdName,
      nameJa: newProdNameJa,
      priceJpy: Number(newProdPrice),
      category: newProdCategory,
      categoryJa: newProdCategory === 'crafts' ? '伝統工芸' : '包丁・台所道具',
      prefecture: newProdPrefecture,
      prefectureJa: newProdPrefectureJa,
      image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=800&q=80',
      rating: 5.0,
      reviewCount: 1,
      inStock: true,
      stockCount: 10,
      description: 'Handcrafted premium Japanese craft item created with traditional techniques.',
      descriptionJa: '伝統の技法で丁寧に作られた至高の工芸品。',
      specifications: { Material: 'Authentic Ceramic / Steel' },
      materials: ['Japanese Wood'],
      materialsJa: ['和木材'],
      origin: 'Japan',
      originJa: '日本',
      manufacturer: 'WaIchiba Certified Studio',
      shippingInfo: 'Ships in paulownia box.',
      shippingInfoJa: '桐箱入りでお届け。'
    });

    setShowAddModal(false);
    setNewProdName('');
    setNewProdNameJa('');
  };

  return (
    <div className="py-12 bg-[#FAF9F5] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E5E5E1] pb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 bg-[#1A1A1A] text-white text-xs font-bold px-3 py-1 rounded-full mb-2">
              <Sparkles className="w-3.5 h-3.5 text-[#D4A373]" />
              <span>{isJa ? '和市場 管理ポータル' : 'WaIchiba Admin Console'}</span>
            </div>
            <h1 className="font-serif text-3xl font-bold text-[#1A1A1A]">
              {isJa ? '店舗運営・在庫 & 売上アナリティクス' : 'E-Commerce Management & Analytics'}
            </h1>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="bg-[#C84B31] hover:bg-[#1A1A1A] text-white px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer shadow-md"
          >
            <Plus className="w-4 h-4" />
            <span>{isJa ? '新規工芸品を登録' : 'Register New Craft'}</span>
          </button>
        </div>

        {/* Analytics Top Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-5 rounded-2xl shadow-xs space-y-2">
            <span className="text-[10px] text-[#8E8D8A] font-bold uppercase tracking-wider">
              {isJa ? '今月の総売上' : 'Monthly Sales'}
            </span>
            <p className="font-serif text-2xl font-bold text-[#1A1A1A]">¥14,850,000</p>
            <span className="text-[11px] text-[#2D4A3E] font-semibold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>+18.4% vs last month</span>
            </span>
          </div>

          <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-5 rounded-2xl shadow-xs space-y-2">
            <span className="text-[10px] text-[#8E8D8A] font-bold uppercase tracking-wider">
              {isJa ? '総受注件数' : 'Total Orders'}
            </span>
            <p className="font-serif text-2xl font-bold text-[#1A1A1A]">412 件</p>
            <span className="text-[11px] text-[#2D4A3E] font-semibold">98.5% Fulfilled</span>
          </div>

          <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-5 rounded-2xl shadow-xs space-y-2">
            <span className="text-[10px] text-[#8E8D8A] font-bold uppercase tracking-wider">
              {isJa ? '提携 伝統工芸士' : 'Master Artisans'}
            </span>
            <p className="font-serif text-2xl font-bold text-[#D4A373]">{artisans.length} 名</p>
            <span className="text-[11px] text-[#8E8D8A]"> across 12 Prefectures</span>
          </div>

          <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-5 rounded-2xl shadow-xs space-y-2">
            <span className="text-[10px] text-[#8E8D8A] font-bold uppercase tracking-wider">
              {isJa ? '平均客単価' : 'Average Order Value'}
            </span>
            <p className="font-serif text-2xl font-bold text-[#1A1A1A]">¥36,043</p>
            <span className="text-[11px] text-[#C84B31] font-semibold">High Luxury Range</span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#E5E5E1] text-xs font-bold gap-6">
          <button
            onClick={() => setActiveTab('analytics')}
            className={`pb-3 transition-colors cursor-pointer ${
              activeTab === 'analytics' ? 'text-[#C84B31] border-b-2 border-[#C84B31]' : 'text-[#8E8D8A]'
            }`}
          >
            {isJa ? '売上 & 地域別需要' : 'Sales Analytics'}
          </button>
          <button
            onClick={() => setActiveTab('inventory')}
            className={`pb-3 transition-colors cursor-pointer ${
              activeTab === 'inventory' ? 'text-[#C84B31] border-b-2 border-[#C84B31]' : 'text-[#8E8D8A]'
            }`}
          >
            {isJa ? '在庫 & 出品管理' : 'Inventory Management'}
          </button>
        </div>

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-6 rounded-2xl space-y-6">
            <h3 className="font-serif font-bold text-lg text-[#1A1A1A]">
              {isJa ? '都道府県別 需要 & 人気カテゴリー' : 'Regional Demand & Category Insights'}
            </h3>

            {/* Regional Performance Visualizer */}
            <div className="space-y-4 text-xs">
              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span>1. 福井県 (越前打刃物・和紙)</span>
                  <span className="font-mono">¥4,200,000 (35%)</span>
                </div>
                <div className="w-full bg-[#FAF9F5] h-3 rounded-full overflow-hidden border">
                  <div className="bg-[#C84B31] h-full w-[35%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span>2. 京都府 (清水焼・宇治茶)</span>
                  <span className="font-mono">¥3,600,000 (30%)</span>
                </div>
                <div className="w-full bg-[#FAF9F5] h-3 rounded-full overflow-hidden border">
                  <div className="bg-[#D4A373] h-full w-[30%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-bold mb-1">
                  <span>3. 岐阜県 (木曽檜風呂道具)</span>
                  <span className="font-mono">¥2,400,000 (20%)</span>
                </div>
                <div className="w-full bg-[#FAF9F5] h-3 rounded-full overflow-hidden border">
                  <div className="bg-[#2D4A3E] h-full w-[20%]" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Inventory Tab */}
        {activeTab === 'inventory' && (
          <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-6 rounded-2xl space-y-4">
            <h3 className="font-serif font-bold text-lg text-[#1A1A1A]">
              {isJa ? '出品工芸品 一覧 & 在庫数調整' : 'Inventory Master List'}
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left text-[#1A1A1A]">
                <thead className="bg-[#FAF9F5] border-b border-[#E5E5E1] text-[#8E8D8A] uppercase font-bold">
                  <tr>
                    <th className="p-3">工芸品名</th>
                    <th className="p-3">産地</th>
                    <th className="p-3">価格 (JPY)</th>
                    <th className="p-3">在庫数</th>
                    <th className="p-3">操作</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E5E1]">
                  {products.map((p) => (
                    <tr key={p.id} className="hover:bg-[#FAF9F5]">
                      <td className="p-3 font-semibold flex items-center gap-2">
                        <img src={p.image} alt={p.name} className="w-8 h-8 rounded object-cover" referrerPolicy="no-referrer" />
                        <span>{isJa ? p.nameJa : p.name}</span>
                      </td>
                      <td className="p-3">{p.prefectureJa}</td>
                      <td className="p-3 font-mono font-bold">¥{p.priceJpy.toLocaleString()}</td>
                      <td className="p-3 font-mono font-bold text-[#2D4A3E]">{p.stockCount} 点</td>
                      <td className="p-3">
                        <button
                          onClick={() => onUpdateProductStock(p.id, p.stockCount + 5)}
                          className="bg-[#1A1A1A] text-white px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer hover:bg-[#C84B31]"
                        >
                          +5 在庫補充
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* New Product Registration Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-[#FAF9F5] border border-[#E5E5E1] rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl relative">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 right-4 w-8 h-8 bg-[#1A1A1A] text-white rounded-full flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="font-serif font-bold text-xl text-[#1A1A1A]">
              {isJa ? '新規 伝統工芸品の登録' : 'Register New Craft Product'}
            </h3>

            <form onSubmit={handleCreateProduct} className="space-y-3 text-xs">
              <div>
                <label className="font-bold block mb-1">商品名 (日本語)</label>
                <input
                  type="text"
                  required
                  value={newProdNameJa}
                  onChange={(e) => setNewProdNameJa(e.target.value)}
                  placeholder="例: 京都 清水焼 抹茶碗"
                  className="w-full bg-white border border-[#E5E5E1] rounded p-2"
                />
              </div>

              <div>
                <label className="font-bold block mb-1">Product Name (English)</label>
                <input
                  type="text"
                  required
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="e.g. Kyoto Kiyomizu Matcha Bowl"
                  className="w-full bg-white border border-[#E5E5E1] rounded p-2"
                />
              </div>

              <div>
                <label className="font-bold block mb-1">価格 (JPY ¥)</label>
                <input
                  type="number"
                  required
                  value={newProdPrice}
                  onChange={(e) => setNewProdPrice(Number(e.target.value))}
                  className="w-full bg-white border border-[#E5E5E1] rounded p-2"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#1A1A1A] hover:bg-[#C84B31] text-white py-3 rounded-xl font-bold cursor-pointer"
              >
                {isJa ? '工芸品を出品登録する' : 'Register Product'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
