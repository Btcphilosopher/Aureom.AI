import React, { useState } from 'react';
import {
  Search,
  ShoppingBag,
  Heart,
  User,
  Globe,
  Crown,
  LayoutDashboard,
  Menu,
  X,
  Sparkles,
  MapPin,
  ChevronRight
} from 'lucide-react';
import { Language, CartItem, UserProfile } from '../types';

interface NavbarProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  currency: 'JPY' | 'USD';
  setCurrency: (curr: 'JPY' | 'USD') => void;
  cartItems: CartItem[];
  wishlistCount: number;
  user: UserProfile;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  setIsCartOpen: (open: boolean) => void;
  setIsAccountOpen: (open: boolean) => void;
  onSearch: (query: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  searchSuggestions: { suggestions: string[]; products: any[] };
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  setLanguage,
  currency,
  setCurrency,
  cartItems,
  wishlistCount,
  user,
  activeTab,
  setActiveTab,
  setIsCartOpen,
  setIsAccountOpen,
  onSearch,
  searchQuery,
  setSearchQuery,
  searchSuggestions,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const isJa = language === 'ja';

  return (
    <header className="sticky top-0 z-40 bg-[#F9F8F4]/95 backdrop-blur-md border-b border-[#1A1A1A]/10">
      {/* Top Banner */}
      <div className="bg-[#1A1A1A] text-[#F9F8F4] text-xs py-2 px-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2 text-[11px] tracking-wider">
            <span className="bg-[#A64B4B] text-white px-2 py-0.5 text-[9px] font-bold tracking-[0.2em] uppercase">
              01 / ARTISAN
            </span>
            <span className="font-light">
              {isJa
                ? '全品 桐箱・和紙包装対応 | 3万円以上のご購入で送料無料'
                : 'Complimentary Paulownia Box Wrapping | Free Shipping over ¥30,000'}
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs font-medium">
            {/* Language Switcher */}
            <button
              onClick={() => setLanguage(language === 'ja' ? 'en' : 'ja')}
              className="border border-[#F9F8F4]/30 hover:border-[#F9F8F4] px-2 py-0.5 text-[10px] tracking-widest transition-all cursor-pointer flex items-center gap-1"
              title="Toggle Language"
            >
              <Globe className="w-3 h-3" />
              <span>{isJa ? 'EN' : 'JP'}</span>
            </button>

            <span className="text-white/20">|</span>

            {/* Currency Switcher */}
            <button
              onClick={() => setCurrency(currency === 'JPY' ? 'USD' : 'JPY')}
              className="hover:text-[#D8C3A5] transition-colors cursor-pointer text-[10px] tracking-widest"
            >
              {currency === 'JPY' ? 'JPY (¥)' : 'USD ($)'}
            </button>

            <span className="text-white/20">|</span>

            {/* Admin Toggle */}
            <button
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-1 cursor-pointer transition-colors text-[10px] tracking-widest uppercase ${
                activeTab === 'admin' ? 'text-[#D8C3A5] font-bold' : 'hover:text-[#D8C3A5]'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>{isJa ? '管理' : 'Admin'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('home')}>
          <div className="w-10 h-10 bg-[#1A1A1A] text-[#F9F8F4] flex items-center justify-center font-serif text-xl shadow-xs hover:bg-[#A64B4B] transition-colors">
            和
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-serif text-2xl font-bold tracking-tight text-[#1A1A1A]">
                和市場
              </span>
              <span className="text-xs uppercase tracking-[0.2em] text-[#8E8D8A] font-semibold">
                WaIchiba
              </span>
            </div>
            <p className="text-[10px] text-[#8E8D8A] tracking-wider hidden sm:block">
              {isJa ? '美しい暮らしを、すべてここで。' : 'Everything for a beautiful life'}
            </p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative flex-1 max-w-md hidden md:block">
          <div className="relative flex items-center">
            <input
              type="text"
              placeholder={isJa ? '包丁、抹茶、伝統工芸、職人を検索...' : 'Search knives, matcha, crafts, artisans...'}
              value={searchQuery}
              onChange={(e) => onSearch(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
              className="w-full bg-[#F2F0EB] border border-[#1A1A1A]/10 py-2 pl-10 pr-4 text-xs text-[#1A1A1A] placeholder-[#8E8D8A] focus:outline-none focus:border-[#1A1A1A] transition-all"
            />
            <Search className="w-4 h-4 text-[#8E8D8A] absolute left-3.5 pointer-events-none" />
          </div>

          {/* Autocomplete Popup */}
          {isSearchFocused && (searchSuggestions.suggestions.length > 0 || searchSuggestions.products.length > 0) && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-[#F9F8F4] border border-[#1A1A1A]/10 shadow-xl p-3 z-50 text-xs">
              {searchSuggestions.suggestions.length > 0 && (
                <div className="mb-3">
                  <div className="text-[10px] uppercase font-bold text-[#8E8D8A] mb-1 tracking-wider">
                    {isJa ? '関連カテゴリー & 検索候補' : 'Categories & Keywords'}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {searchSuggestions.suggestions.map((s, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setSearchQuery(s.replace(/職人: /g, '').replace(/\(.*\)/g, '').trim());
                          setActiveTab('catalog');
                        }}
                        className="bg-[#F2F0EB] hover:bg-[#EAE7E1] text-[#1A1A1A] px-2.5 py-1 text-[11px] cursor-pointer transition-colors border border-[#1A1A1A]/5"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {searchSuggestions.products.length > 0 && (
                <div>
                  <div className="text-[10px] uppercase font-bold text-[#8E8D8A] mb-1 tracking-wider">
                    {isJa ? '商品候補' : 'Suggested Products'}
                  </div>
                  <div className="space-y-1">
                    {searchSuggestions.products.map((prod) => (
                      <div
                        key={prod.id}
                        onClick={() => {
                          setSearchQuery(prod.nameJa);
                          setActiveTab('catalog');
                        }}
                        className="flex items-center gap-2 p-1.5 hover:bg-[#F2F0EB] cursor-pointer transition-colors"
                      >
                        <img
                          src={prod.image}
                          alt={prod.name}
                          className="w-8 h-8 object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate text-[#1A1A1A]">
                            {isJa ? prod.nameJa : prod.name}
                          </p>
                          <p className="text-[10px] text-[#8E8D8A]">
                            ¥{prod.priceJpy.toLocaleString()} • {prod.prefectureJa}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-4 sm:gap-6">
          {/* WaClub Loyalty Badge */}
          <button
            onClick={() => setActiveTab('loyalty')}
            className="hidden sm:flex items-center gap-1.5 bg-[#F2F0EB] border border-[#1A1A1A]/10 hover:border-[#1A1A1A] text-[#1A1A1A] px-3 py-1.5 text-xs font-medium cursor-pointer transition-all"
          >
            <Crown className="w-3.5 h-3.5 text-[#D8C3A5]" />
            <span className="text-[11px] tracking-wider uppercase">{isJa ? '和クラブ' : 'WaClub'}</span>
            <span className="bg-[#1A1A1A] text-[#F9F8F4] text-[9px] px-1.5 py-0.2 font-bold tracking-widest uppercase">
              {user.membershipTier}
            </span>
          </button>

          {/* Account Modal */}
          <button
            onClick={() => setIsAccountOpen(true)}
            className="p-2 text-[#1A1A1A] hover:text-[#A64B4B] transition-colors relative cursor-pointer"
            title={isJa ? 'マイページ' : 'Account'}
          >
            <User className="w-5 h-5" />
          </button>

          {/* Wishlist */}
          <button
            onClick={() => setActiveTab('wishlist')}
            className="p-2 text-[#1A1A1A] hover:text-[#A64B4B] transition-colors relative cursor-pointer"
            title={isJa ? 'お気に入り' : 'Wishlist'}
          >
            <Heart className="w-5 h-5" />
            {wishlistCount > 0 && (
              <span className="absolute top-1 right-1 bg-[#A64B4B] text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Shopping Cart Drawer Trigger */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-2 bg-[#1A1A1A] hover:bg-[#2B2B2B] text-[#F9F8F4] px-4 py-2 text-xs font-medium cursor-pointer transition-all shadow-xs"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden sm:inline text-[11px] uppercase tracking-wider">{isJa ? '買い物かご' : 'Cart'}</span>
            <span className="bg-[#A64B4B] text-white text-[9px] font-bold px-1.5 py-0.2">
              {totalCartCount}
            </span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 md:hidden text-[#1A1A1A] cursor-pointer"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Navigation Links Bar */}
      <nav className="border-t border-[#1A1A1A]/10 bg-[#F9F8F4]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between text-xs font-medium py-2.5 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-6 sm:gap-8 min-w-max">
            <button
              onClick={() => setActiveTab('home')}
              className={`hover:text-[#A64B4B] tracking-[0.2em] uppercase text-[11px] transition-colors cursor-pointer ${
                activeTab === 'home' ? 'text-[#A64B4B] font-bold border-b-2 border-[#A64B4B] pb-0.5' : 'text-[#1A1A1A]'
              }`}
            >
              {isJa ? 'ホーム' : 'Home'}
            </button>

            <button
              onClick={() => setActiveTab('catalog')}
              className={`hover:text-[#A64B4B] tracking-[0.2em] uppercase text-[11px] transition-colors cursor-pointer ${
                activeTab === 'catalog' ? 'text-[#A64B4B] font-bold border-b-2 border-[#A64B4B] pb-0.5' : 'text-[#1A1A1A]'
              }`}
            >
              {isJa ? '全商品カタログ' : 'Catalog'}
            </button>

            <button
              onClick={() => setActiveTab('artisan')}
              className={`hover:text-[#A64B4B] tracking-[0.2em] uppercase text-[11px] transition-colors cursor-pointer flex items-center gap-1 ${
                activeTab === 'artisan' ? 'text-[#A64B4B] font-bold border-b-2 border-[#A64B4B] pb-0.5' : 'text-[#1A1A1A]'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D8C3A5]" />
              <span>{isJa ? '職人市場' : 'Artisans'}</span>
            </button>

            <button
              onClick={() => setActiveTab('stores')}
              className={`hover:text-[#A64B4B] tracking-[0.2em] uppercase text-[11px] transition-colors cursor-pointer flex items-center gap-1 ${
                activeTab === 'stores' ? 'text-[#A64B4B] font-bold border-b-2 border-[#A64B4B] pb-0.5' : 'text-[#1A1A1A]'
              }`}
            >
              <MapPin className="w-3.5 h-3.5 text-[#8E8D8A]" />
              <span>{isJa ? '直営店舗・実店舗' : 'Stores'}</span>
            </button>

            <button
              onClick={() => setActiveTab('loyalty')}
              className={`hover:text-[#A64B4B] tracking-[0.2em] uppercase text-[11px] transition-colors cursor-pointer ${
                activeTab === 'loyalty' ? 'text-[#A64B4B] font-bold border-b-2 border-[#A64B4B] pb-0.5' : 'text-[#1A1A1A]'
              }`}
            >
              {isJa ? '和クラブ会員特典' : 'Loyalty'}
            </button>
          </div>

          <div className="hidden lg:flex items-center gap-2 text-[#8E8D8A] text-[10px] uppercase tracking-[0.2em]">
            <span>{isJa ? '京都・東京・福岡 8店舗展開中' : 'Flagship Stores in Tokyo, Kyoto, Osaka & Fukuoka'}</span>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-[#FFFDF9] border-b border-[#E5E5E1] p-4 space-y-3">
          <div className="relative mb-3">
            <input
              type="text"
              placeholder={isJa ? '商品を検索...' : 'Search items...'}
              value={searchQuery}
              onChange={(e) => onSearch(e.target.value)}
              className="w-full bg-[#FAF9F5] border border-[#E5E5E1] rounded-lg py-2 pl-9 pr-3 text-xs"
            />
            <Search className="w-4 h-4 text-[#8E8D8A] absolute left-2.5 top-2.5" />
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-medium pt-1">
            <button
              onClick={() => { setActiveTab('home'); setIsMobileMenuOpen(false); }}
              className="p-2.5 bg-[#FAF9F5] rounded-md text-left flex justify-between items-center"
            >
              <span>{isJa ? 'ホーム' : 'Home'}</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#8E8D8A]" />
            </button>

            <button
              onClick={() => { setActiveTab('catalog'); setIsMobileMenuOpen(false); }}
              className="p-2.5 bg-[#FAF9F5] rounded-md text-left flex justify-between items-center"
            >
              <span>{isJa ? 'カタログ' : 'Catalog'}</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#8E8D8A]" />
            </button>

            <button
              onClick={() => { setActiveTab('artisan'); setIsMobileMenuOpen(false); }}
              className="p-2.5 bg-[#FAF9F5] rounded-md text-left flex justify-between items-center"
            >
              <span>{isJa ? '職人市場' : 'Artisans'}</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#8E8D8A]" />
            </button>

            <button
              onClick={() => { setActiveTab('stores'); setIsMobileMenuOpen(false); }}
              className="p-2.5 bg-[#FAF9F5] rounded-md text-left flex justify-between items-center"
            >
              <span>{isJa ? '店舗案内' : 'Stores'}</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#8E8D8A]" />
            </button>

            <button
              onClick={() => { setActiveTab('loyalty'); setIsMobileMenuOpen(false); }}
              className="p-2.5 bg-[#FAF9F5] rounded-md text-left flex justify-between items-center"
            >
              <span>{isJa ? '和クラブ' : 'WaClub'}</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#8E8D8A]" />
            </button>

            <button
              onClick={() => { setActiveTab('admin'); setIsMobileMenuOpen(false); }}
              className="p-2.5 bg-[#FAF9F5] rounded-md text-left flex justify-between items-center"
            >
              <span>{isJa ? '管理画面' : 'Admin'}</span>
              <ChevronRight className="w-3.5 h-3.5 text-[#8E8D8A]" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
