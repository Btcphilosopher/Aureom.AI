import React, { useState } from 'react';
import { MapPin, Clock, Phone, Calendar, Sparkles, Navigation, Globe } from 'lucide-react';
import { StoreLocation, Language } from '../types';

interface StoreLocatorProps {
  stores: StoreLocation[];
  language: Language;
}

export const StoreLocator: React.FC<StoreLocatorProps> = ({ stores, language }) => {
  const isJa = language === 'ja';
  const [selectedStore, setSelectedStore] = useState<StoreLocation>(stores[0]);

  return (
    <div className="py-12 bg-[#FAF9F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 bg-[#2D4A3E]/10 text-[#2D4A3E] text-xs font-semibold px-3 py-1 rounded-full mb-2">
            <MapPin className="w-3.5 h-3.5" />
            <span>{isJa ? '和市場 直営店舗・実店舗' : 'Flagship Stores & Ateliers'}</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#1A1A1A]">
            {isJa ? '静寂と美意識が響き合う空間へ' : 'Experience Omotenashi In Person'}
          </h2>
          <p className="text-xs sm:text-sm text-[#8E8D8A] mt-2">
            {isJa
              ? '東京・京都・大阪・福岡。実際の作品を手にとり、職人の手仕事と静かな空間をご体験いただけます。'
              : 'Visit our sanctuary flagship boutiques in Tokyo Ginza, Kyoto Gion, Osaka Shinsaibashi, and Fukuoka Tenjin.'}
          </p>
        </div>

        {/* Store Tabs & Interactive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Store List Column */}
          <div className="lg:col-span-5 space-y-3">
            {stores.map((store) => (
              <div
                key={store.id}
                onClick={() => setSelectedStore(store)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                  selectedStore.id === store.id
                    ? 'bg-[#1A1A1A] text-[#FAF9F5] border-[#1A1A1A] shadow-lg'
                    : 'bg-[#FFFDF9] text-[#1A1A1A] border-[#E5E5E1] hover:border-[#1A1A1A]'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        selectedStore.id === store.id ? 'bg-[#C84B31] text-white' : 'bg-[#E5E5E1] text-[#1A1A1A]'
                      }`}
                    >
                      {isJa ? store.cityJa : store.city}
                    </span>
                    <h3 className="font-serif font-bold text-sm sm:text-base">
                      {isJa ? store.nameJa : store.name}
                    </h3>
                  </div>
                  <p className={`text-xs ${selectedStore.id === store.id ? 'text-[#E5E5E1]' : 'text-[#8E8D8A]'}`}>
                    {isJa ? store.addressJa : store.address}
                  </p>
                </div>
                <Navigation className={`w-5 h-5 ${selectedStore.id === store.id ? 'text-[#D4A373]' : 'text-[#8E8D8A]'}`} />
              </div>
            ))}

            {/* Interactive Japan Map Visualizer */}
            <div className="bg-[#FFFDF9] border border-[#E5E5E1] rounded-xl p-4 text-center space-y-2">
              <p className="text-xs font-bold text-[#1A1A1A] flex items-center justify-center gap-1">
                <Globe className="w-4 h-4 text-[#C84B31]" />
                <span>{isJa ? '日本全国 8店舗インタラクティブマップ' : 'Interactive Map Pinpoints'}</span>
              </p>
              <div className="relative w-full h-36 bg-[#2D4A3E]/10 rounded-lg flex items-center justify-center overflow-hidden border border-[#2D4A3E]/20">
                {/* SVG Japan Outline Pins */}
                <div className="text-[10px] text-[#2D4A3E] font-mono font-bold flex flex-wrap gap-3 justify-center p-2">
                  <span className="bg-white/80 px-2 py-1 rounded shadow-xs border border-[#2D4A3E]/30">📍 TOKYO (35.67°N)</span>
                  <span className="bg-white/80 px-2 py-1 rounded shadow-xs border border-[#2D4A3E]/30">📍 KYOTO (35.00°N)</span>
                  <span className="bg-white/80 px-2 py-1 rounded shadow-xs border border-[#2D4A3E]/30">📍 OSAKA (34.67°N)</span>
                  <span className="bg-white/80 px-2 py-1 rounded shadow-xs border border-[#2D4A3E]/30">📍 FUKUOKA (33.59°N)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Selected Store Detailed Card Column */}
          <div className="lg:col-span-7 bg-[#FFFDF9] border border-[#E5E5E1] rounded-2xl overflow-hidden shadow-xl">
            <div className="relative h-64 overflow-hidden">
              <img
                src={selectedStore.image}
                alt={selectedStore.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-6 text-white space-y-1">
                <span className="bg-[#C84B31] text-white text-[10px] font-bold px-2 py-0.5 rounded tracking-widest">
                  {isJa ? selectedStore.cityJa : selectedStore.city}
                </span>
                <h3 className="font-serif text-2xl font-bold">
                  {isJa ? selectedStore.nameJa : selectedStore.name}
                </h3>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Info Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-[#C84B31] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#8E8D8A] block">{isJa ? '所在地' : 'Address'}</span>
                    <span className="text-[#1A1A1A] font-medium">{isJa ? selectedStore.addressJa : selectedStore.address}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <Clock className="w-4 h-4 text-[#D4A373] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#8E8D8A] block">{isJa ? '営業時間' : 'Hours'}</span>
                    <span className="text-[#1A1A1A] font-medium">{isJa ? selectedStore.hoursJa : selectedStore.hours}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <Phone className="w-4 h-4 text-[#2D4A3E] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#8E8D8A] block">{isJa ? '電話番号' : 'Phone'}</span>
                    <span className="text-[#1A1A1A] font-mono font-medium">{selectedStore.phone}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-[#D4A373] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#8E8D8A] block">{isJa ? 'サービス・バリアフリー' : 'Facilities'}</span>
                    <span className="text-[#1A1A1A]">{isJa ? selectedStore.accessibilityJa : selectedStore.accessibility}</span>
                  </div>
                </div>
              </div>

              {/* Special Events Section */}
              {selectedStore.events && selectedStore.events.length > 0 && (
                <div className="pt-4 border-t border-[#E5E5E1]">
                  <h4 className="font-serif font-bold text-sm text-[#1A1A1A] mb-3 flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-[#C84B31]" />
                    <span>{isJa ? '開催予定のイベント・実演会' : 'Upcoming Store Events'}</span>
                  </h4>

                  <div className="space-y-3">
                    {selectedStore.events.map((evt, idx) => (
                      <div key={idx} className="bg-[#FAF9F5] p-3 rounded-lg border border-[#E5E5E1] text-xs space-y-1">
                        <div className="flex items-center justify-between font-bold text-[#1A1A1A]">
                          <span>{isJa ? evt.titleJa : evt.title}</span>
                          <span className="text-[10px] text-[#C84B31] bg-[#C84B31]/10 px-2 py-0.5 rounded">
                            {evt.date}
                          </span>
                        </div>
                        <p className="text-[#8E8D8A]">{isJa ? evt.descriptionJa : evt.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
