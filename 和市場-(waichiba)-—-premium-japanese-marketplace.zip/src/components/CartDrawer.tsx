import React, { useState } from 'react';
import { X, Trash2, Gift, ShoppingBag, ArrowRight, ShieldCheck, Tag } from 'lucide-react';
import { CartItem, Language } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  language: Language;
  currency: 'JPY' | 'USD';
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onProceedToCheckout: (giftWrap: boolean, coupon: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  language,
  currency,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
}) => {
  if (!isOpen) return null;

  const isJa = language === 'ja';
  const [isGiftWrap, setIsGiftWrap] = useState(true);
  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string>('');

  const subtotal = items.reduce((sum, item) => sum + item.product.priceJpy * item.quantity, 0);

  let discount = 0;
  if (appliedCoupon === 'WAICHIBAVIP') {
    discount = Math.floor(subtotal * 0.15);
  } else if (appliedCoupon === 'OMOTENASHI') {
    discount = 2000;
  }

  const giftWrapFee = isGiftWrap ? 500 : 0;
  const taxableSubtotal = Math.max(0, subtotal - discount + giftWrapFee);
  const tax = Math.floor(taxableSubtotal * 0.10);
  const shipping = subtotal >= 30000 ? 0 : 800;
  const total = taxableSubtotal + tax + shipping;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponInput.toUpperCase() === 'WAICHIBAVIP' || couponInput.toUpperCase() === 'OMOTENASHI') {
      setAppliedCoupon(couponInput.toUpperCase());
    } else {
      alert(isJa ? '無効なクーポンコードです。 (例: WAICHIBAVIP または OMOTENASHI)' : 'Invalid coupon. Try WAICHIBAVIP or OMOTENASHI');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="bg-[#FAF9F5] w-full max-w-md h-full flex flex-col justify-between shadow-2xl relative border-l border-[#E5E5E1] animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-[#E5E5E1] flex items-center justify-between bg-[#FFFDF9]">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#C84B31]" />
            <h2 className="font-serif font-bold text-lg text-[#1A1A1A]">
              {isJa ? '買い物かご' : 'Shopping Cart'}
            </h2>
            <span className="bg-[#1A1A1A] text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
              {items.reduce((acc, item) => acc + item.quantity, 0)}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#8E8D8A] hover:text-[#1A1A1A] transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Items List */}
        <div className="p-4 sm:p-6 flex-1 overflow-y-auto space-y-4">
          {items.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <ShoppingBag className="w-12 h-12 text-[#8E8D8A] mx-auto opacity-50" />
              <p className="font-serif font-bold text-[#1A1A1A]">
                {isJa ? '買い物かごは空です' : 'Your cart is empty'}
              </p>
              <p className="text-xs text-[#8E8D8A]">
                {isJa ? '職人の逸品を探しに出かけましょう。' : 'Explore our collections to find masterwork crafts.'}
              </p>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.product.id}
                className="bg-[#FFFDF9] border border-[#E5E5E1] p-3 rounded-xl flex gap-3 relative group"
              >
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-20 h-20 object-cover rounded-lg bg-[#FAF9F5]"
                  referrerPolicy="no-referrer"
                />

                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-serif font-semibold text-xs text-[#1A1A1A] line-clamp-1">
                      {isJa ? item.product.nameJa : item.product.name}
                    </h3>
                    <p className="text-[10px] text-[#8E8D8A]">
                      {isJa ? item.product.prefectureJa : item.product.prefecture} • {item.selectedSize || 'Standard'}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    {/* Quantity controls */}
                    <div className="flex items-center border border-[#E5E5E1] rounded-md bg-white text-xs">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                        className="px-2 py-0.5 font-bold hover:bg-[#FAF9F5]"
                      >
                        -
                      </button>
                      <span className="px-2.5 font-mono font-bold">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                        className="px-2 py-0.5 font-bold hover:bg-[#FAF9F5]"
                      >
                        +
                      </button>
                    </div>

                    <span className="font-serif font-bold text-xs text-[#1A1A1A]">
                      ¥{(item.product.priceJpy * item.quantity).toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Remove button */}
                <button
                  onClick={() => onRemoveItem(item.product.id)}
                  className="text-[#8E8D8A] hover:text-[#C84B31] p-1 transition-colors cursor-pointer"
                  title="Remove"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}

          {/* Gift Wrapping Toggle */}
          {items.length > 0 && (
            <div className="bg-[#FFFDF9] border border-[#D4A373]/40 p-3.5 rounded-xl space-y-2">
              <label className="flex items-center justify-between cursor-pointer">
                <div className="flex items-center gap-2 text-xs font-semibold text-[#1A1A1A]">
                  <Gift className="w-4 h-4 text-[#D4A373]" />
                  <span>{isJa ? '伝統 桐箱・風呂敷贈答包装 (+¥500)' : 'Paulownia & Furoshiki Gift Wrapping (+¥500)'}</span>
                </div>
                <input
                  type="checkbox"
                  checked={isGiftWrap}
                  onChange={(e) => setIsGiftWrap(e.target.checked)}
                  className="accent-[#C84B31] w-4 h-4 rounded cursor-pointer"
                />
              </label>
              <p className="text-[10px] text-[#8E8D8A]">
                {isJa
                  ? '越前和紙の金銀水引と桐箱、風呂敷で上品にお包みしてお届けします。'
                  : 'Wrapped with authentic Echizen Washi paper, gold Mizuhiki knots, and cedar wood box.'}
              </p>
            </div>
          )}

          {/* Coupon Code Input */}
          {items.length > 0 && (
            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <input
                type="text"
                placeholder={isJa ? 'クーポンコード (例: WAICHIBAVIP)' : 'Coupon Code (e.g. WAICHIBAVIP)'}
                value={couponInput}
                onChange={(e) => setCouponInput(e.target.value)}
                className="flex-1 bg-white border border-[#E5E5E1] rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-[#1A1A1A]"
              />
              <button
                type="submit"
                className="bg-[#1A1A1A] text-white px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer"
              >
                {isJa ? '適用' : 'Apply'}
              </button>
            </form>
          )}

          {appliedCoupon && (
            <div className="text-[11px] text-[#2D4A3E] bg-[#2D4A3E]/10 p-2 rounded-lg font-semibold flex items-center gap-1">
              <Tag className="w-3.5 h-3.5" />
              <span>{isJa ? `クーポン [${appliedCoupon}] 適用中` : `Coupon [${appliedCoupon}] Applied`}</span>
            </div>
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {items.length > 0 && (
          <div className="p-4 sm:p-6 border-t border-[#E5E5E1] bg-[#FFFDF9] space-y-3">
            <div className="space-y-1.5 text-xs text-[#8E8D8A]">
              <div className="flex justify-between">
                <span>{isJa ? '小計' : 'Subtotal'}</span>
                <span className="text-[#1A1A1A] font-mono font-medium">¥{subtotal.toLocaleString()}</span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-[#C84B31] font-semibold">
                  <span>{isJa ? '割引' : 'Discount'}</span>
                  <span className="font-mono">-¥{discount.toLocaleString()}</span>
                </div>
              )}

              {isGiftWrap && (
                <div className="flex justify-between">
                  <span>{isJa ? '贈答包装費' : 'Gift Wrap'}</span>
                  <span className="text-[#1A1A1A] font-mono">¥500</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>{isJa ? '消費税 (10%)' : 'Japanese Tax (10%)'}</span>
                <span className="text-[#1A1A1A] font-mono">¥{tax.toLocaleString()}</span>
              </div>

              <div className="flex justify-between">
                <span>{isJa ? '送料' : 'Shipping'}</span>
                <span className="text-[#2D4A3E] font-semibold">
                  {shipping === 0 ? (isJa ? '無料 (3万円以上特典)' : 'Free') : `¥${shipping}`}
                </span>
              </div>

              <div className="flex justify-between text-base font-bold text-[#1A1A1A] pt-2 border-t border-[#E5E5E1]">
                <span className="font-serif">{isJa ? '合計 (税込)' : 'Total (Incl. Tax)'}</span>
                <span className="font-serif text-xl text-[#C84B31]">¥{total.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => onProceedToCheckout(isGiftWrap, appliedCoupon)}
              className="w-full bg-[#1A1A1A] hover:bg-[#C84B31] text-[#FAF9F5] py-3.5 rounded-xl font-semibold text-xs sm:text-sm tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg"
            >
              <span>{isJa ? '注文手続きへ進む' : 'Proceed to Checkout'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
