import React from 'react';
import { Heart, ShoppingBag, Star, Sparkles, MapPin } from 'lucide-react';
import { Product, Language } from '../types';

interface ProductCardProps {
  product: Product;
  language: Language;
  currency: 'JPY' | 'USD';
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  language,
  currency,
  onSelectProduct,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
}) => {
  const isJa = language === 'ja';

  const formattedPriceJpy = `¥${product.priceJpy.toLocaleString()}`;
  const usdPriceEst = `$${Math.round(product.priceJpy / 150)}`;

  return (
    <div className="group bg-[#FFFDF9] border border-[#1A1A1A]/10 overflow-hidden hover:border-[#1A1A1A]/30 transition-all duration-300 flex flex-col justify-between relative shadow-2xs">
      {/* Top Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 items-start">
        {product.isNew && (
          <span className="bg-[#1A1A1A] text-[#F9F8F4] text-[9px] font-bold px-2 py-0.5 tracking-[0.2em] uppercase">
            {isJa ? '新作' : 'New'}
          </span>
        )}
        {product.isBestseller && (
          <span className="bg-[#A64B4B] text-white text-[9px] font-bold px-2 py-0.5 tracking-[0.2em] uppercase">
            {isJa ? '名品' : 'Bestseller'}
          </span>
        )}
        {product.isArtisan && (
          <span className="bg-[#D8C3A5] text-[#1A1A1A] text-[9px] font-bold px-2 py-0.5 tracking-[0.2em] uppercase flex items-center gap-1 shadow-xs border border-[#1A1A1A]/10">
            <Sparkles className="w-2.5 h-2.5" />
            <span>{isJa ? '職人手仕事' : 'Handmade'}</span>
          </span>
        )}
      </div>

      {/* Wishlist Heart Button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onToggleWishlist(product);
        }}
        className={`absolute top-3 right-3 z-10 w-8 h-8 flex items-center justify-center transition-colors cursor-pointer border ${
          isWishlisted
            ? 'bg-[#A64B4B] text-white border-[#A64B4B]'
            : 'bg-[#F9F8F4]/90 text-[#1A1A1A] border-[#1A1A1A]/10 hover:border-[#1A1A1A]'
        }`}
        title={isWishlisted ? (isJa ? 'お気に入りから削除' : 'Remove Wishlist') : (isJa ? 'お気に入りに追加' : 'Add Wishlist')}
      >
        <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
      </button>

      {/* Image Gallery Thumbnail with Zoom Effect */}
      <div
        onClick={() => onSelectProduct(product)}
        className="relative w-full aspect-4/3 bg-[#F2F0EB] overflow-hidden cursor-pointer"
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-300" />
      </div>

      {/* Details Area */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Origin & Prefecture Tag */}
          <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-[#8E8D8A] mb-1 font-medium">
            <MapPin className="w-3 h-3 text-[#A64B4B]" />
            <span>{isJa ? product.prefectureJa : product.prefecture}</span>
            <span>•</span>
            <span>{isJa ? product.categoryJa : product.category}</span>
          </div>

          {/* Product Title */}
          <h3
            onClick={() => onSelectProduct(product)}
            className="font-serif font-semibold text-sm sm:text-base text-[#1A1A1A] group-hover:text-[#A64B4B] transition-colors cursor-pointer line-clamp-2 leading-snug"
          >
            {isJa ? product.nameJa : product.name}
          </h3>

          {/* Artisan Name if available */}
          {product.artisanNameJa && (
            <p className="text-[11px] text-[#8E8D8A] font-medium mt-1 tracking-wider">
              {isJa ? `作: ${product.artisanNameJa}` : `Crafted by ${product.artisanName}`}
            </p>
          )}
        </div>

        {/* Rating and Price */}
        <div className="pt-2 border-t border-[#1A1A1A]/10 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1 text-xs">
              <div className="flex text-[#D8C3A5]">
                <Star className="w-3.5 h-3.5 fill-current" />
              </div>
              <span className="font-semibold text-[#1A1A1A]">{product.rating}</span>
              <span className="text-[#8E8D8A] text-[10px]">({product.reviewCount})</span>
            </div>

            <div className="mt-1">
              <span className="font-serif text-base font-bold text-[#1A1A1A]">
                {currency === 'JPY' ? formattedPriceJpy : usdPriceEst}
              </span>
              {currency === 'JPY' && (
                <span className="text-[10px] text-[#8E8D8A] ml-1.5 font-normal">
                  (~{usdPriceEst} USD)
                </span>
              )}
            </div>
          </div>

          {/* Quick Add to Cart Button */}
          <button
            onClick={() => onAddToCart(product)}
            className="bg-[#1A1A1A] hover:bg-[#A64B4B] text-[#F9F8F4] p-2.5 transition-colors cursor-pointer shadow-xs flex items-center justify-center"
            title={isJa ? '買い物かごに追加' : 'Add to Cart'}
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
