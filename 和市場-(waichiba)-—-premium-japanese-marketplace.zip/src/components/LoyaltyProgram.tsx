import React from 'react';
import { Crown, Gift, Sparkles, Award, CheckCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { UserProfile, Language } from '../types';

interface LoyaltyProgramProps {
  user: UserProfile;
  language: Language;
}

const TIERS = [
  {
    name: 'Standard',
    nameJa: '一般会員',
    pointsReq: '0 pts',
    pointsBack: '3%',
    color: '#8E8D8A',
    perksJa: ['商品購入で3%ポイント還元', '限定メルマガ受信'],
    perksEn: ['3% Points Earned on All Purchases', 'Seasonal Member Newsletter'],
  },
  {
    name: 'Kyoto',
    nameJa: '京都会員',
    pointsReq: '10,000 pts',
    pointsBack: '5%',
    color: '#D4A373',
    perksJa: ['5%ポイント還元', '全品無料桐箱・風呂敷贈答包装', '誕生日特製オリジナル手拭いプレゼント'],
    perksEn: ['5% Points Back', 'Free Paulownia Box Gift Wrapping', 'Birthday Tenugui Gift'],
  },
  {
    name: 'Edo',
    nameJa: '江戸会員',
    pointsReq: '30,000 pts',
    pointsBack: '8%',
    color: '#1D2A44',
    perksJa: ['8%ポイント還元', '優先発送（翌日配送）', '新作・限定コレクション先行予約権', '年1回 職人特製小鉢贈呈'],
    perksEn: ['8% Points Back', 'Priority Next-Day Dispatch', 'Early Access to Limited Drops', 'Annual Artisan Ceramic Bowl Gift'],
  },
  {
    name: 'Imperial',
    nameJa: '帝 (みかど) 会員',
    pointsReq: '100,000 pts',
    pointsBack: '12%',
    color: '#C84B31',
    perksJa: ['12%ポイント還元', '工房訪問・特別個室対面鑑賞招待', '専任おもてなしコンシェルジュ', '限定カスタムオーダー枠'],
    perksEn: ['12% Points Back', 'Private Workshop Studio Visits', 'Dedicated Omotenashi Concierge', 'Bespoke Custom Orders'],
  },
];

export const LoyaltyProgram: React.FC<LoyaltyProgramProps> = ({ user, language }) => {
  const isJa = language === 'ja';

  return (
    <div className="py-12 bg-[#FAF9F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Header Hero */}
        <div className="bg-[#1A1A1A] text-[#FAF9F5] rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-2xl">
          <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-20 pointer-events-none hidden md:block">
            <div className="writing-vertical-rl font-serif text-8xl font-bold tracking-widest text-[#D4A373]">
              和クラブ
            </div>
          </div>

          <div className="relative z-10 max-w-2xl space-y-6">
            <div className="inline-flex items-center gap-1.5 bg-[#D4A373]/20 border border-[#D4A373]/40 text-[#D4A373] text-xs font-bold px-3 py-1.5 rounded-full">
              <Crown className="w-4 h-4" />
              <span>{isJa ? '和市場 メンバーシッププログラム' : 'WaClub Membership'}</span>
            </div>

            <h1 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight">
              {isJa ? '和クラブ (WaClub)' : 'WaClub Royalty & Heritage'}
            </h1>
            <p className="text-xs sm:text-sm text-[#E5E5E1] leading-relaxed">
              {isJa
                ? '美意識を共有するお客様への感謝を込めて。ポイント還元、限定コレクション先行アクセス、職人工房へのご案内など特別な体験をお届けします。'
                : 'A patronage program dedicated to connoisseurs of Japanese craft. Earn points, unlock private studio invitations, and receive complimentary bespoke wrapping.'}
            </p>

            {/* Active User Card */}
            <div className="bg-[#FAF9F5]/10 backdrop-blur-md border border-[#FAF9F5]/20 p-6 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-[10px] text-[#8E8D8A] uppercase font-bold tracking-wider">
                  {isJa ? '現在の会員ステータス' : 'Active Tier Status'}
                </span>
                <div className="flex items-center gap-3 mt-1">
                  <span className="font-serif text-2xl font-bold text-[#D4A373]">
                    {user.membershipTier} Member
                  </span>
                  <span className="bg-[#C84B31] text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                    {isJa ? '優待資格保有' : 'Verified Patron'}
                  </span>
                </div>
                <p className="text-xs text-[#E5E5E1] mt-1">{user.name}</p>
              </div>

              <div className="text-right sm:border-l sm:border-white/20 sm:pl-6">
                <span className="text-[10px] text-[#8E8D8A] uppercase font-bold tracking-wider">
                  {isJa ? '保有可能ポイント' : 'Available Points'}
                </span>
                <div className="font-mono text-3xl font-bold text-[#FAF9F5] mt-1">
                  {user.points.toLocaleString()} <span className="text-sm font-sans">pts</span>
                </div>
                <p className="text-[11px] text-[#D4A373] mt-0.5">
                  (~¥{user.points.toLocaleString()} {isJa ? '相当のお買い物に利用可能' : 'JPY Value'})
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Membership Tiers Comparison */}
        <div>
          <div className="text-center max-w-xl mx-auto mb-8">
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#1A1A1A]">
              {isJa ? '会員ランクと優待一覧' : 'Membership Tiers & Exclusive Benefits'}
            </h2>
            <p className="text-xs text-[#8E8D8A] mt-1">
              {isJa ? '年間ご購入額に応じてランクがアップいたします。' : 'Tiers ascend based on cumulative annual craft patronage.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {TIERS.map((tier) => {
              const isCurrent = user.membershipTier === tier.name;

              return (
                <div
                  key={tier.name}
                  className={`bg-[#FFFDF9] border rounded-2xl p-6 flex flex-col justify-between relative shadow-sm transition-all ${
                    isCurrent ? 'border-2 border-[#C84B31] ring-2 ring-[#C84B31]/20 shadow-xl' : 'border-[#E5E5E1]'
                  }`}
                >
                  {isCurrent && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#C84B31] text-white text-[10px] font-bold px-3 py-0.5 rounded-full uppercase tracking-wider">
                      {isJa ? '現在のランク' : 'Your Tier'}
                    </span>
                  )}

                  <div className="space-y-4">
                    <div className="flex items-center justify-between border-b border-[#E5E5E1] pb-3">
                      <div>
                        <h3 className="font-serif font-bold text-lg text-[#1A1A1A]">
                          {isJa ? tier.nameJa : tier.name}
                        </h3>
                        <span className="text-[11px] text-[#8E8D8A]">
                          {isJa ? `条件: ${tier.pointsReq}` : `Req: ${tier.pointsReq}`}
                        </span>
                      </div>
                      <span
                        className="font-mono font-bold text-xl px-2.5 py-1 rounded-lg text-white"
                        style={{ backgroundColor: tier.color }}
                      >
                        {tier.pointsBack}
                      </span>
                    </div>

                    {/* Perks List */}
                    <ul className="space-y-2 text-xs text-[#1A1A1A]">
                      {(isJa ? tier.perksJa : tier.perksEn).map((perk, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <CheckCircle className="w-3.5 h-3.5 text-[#2D4A3E] shrink-0 mt-0.5" />
                          <span>{perk}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-6 mt-4 border-t border-[#E5E5E1]">
                    <button
                      className={`w-full py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                        isCurrent
                          ? 'bg-[#1A1A1A] text-white cursor-default'
                          : 'bg-[#FAF9F5] hover:bg-[#E5E5E1] text-[#1A1A1A] border border-[#E5E5E1]'
                      }`}
                    >
                      {isCurrent ? (isJa ? '適用中' : 'Active Tier') : (isJa ? '詳細を見る' : 'View Requirements')}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
