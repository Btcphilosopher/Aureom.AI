import React from 'react';
import { X, User, MapPin, Package, Gift, Crown, FileText, ChevronRight } from 'lucide-react';
import { UserProfile, Language } from '../types';

interface UserAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  language: Language;
}

export const UserAccountModal: React.FC<UserAccountModalProps> = ({
  isOpen,
  onClose,
  user,
  language,
}) => {
  if (!isOpen) return null;

  const isJa = language === 'ja';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-[#FAF9F5] border border-[#E5E5E1] rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative p-6 sm:p-8 space-y-6">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-8 h-8 bg-[#1A1A1A] text-white rounded-full flex items-center justify-center hover:bg-[#C84B31] transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Profile Card */}
        <div className="bg-[#1A1A1A] text-[#FAF9F5] p-6 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-[#D4A373] text-white rounded-full flex items-center justify-center font-serif text-2xl font-bold">
              {user.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-serif font-bold text-xl">{user.name}</h2>
                <span className="bg-[#C84B31] text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                  {user.membershipTier}
                </span>
              </div>
              <p className="text-xs text-[#8E8D8A]">{user.email}</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-[#8E8D8A] uppercase font-bold">
              {isJa ? '保有ポイント' : 'WaClub Points'}
            </span>
            <p className="font-mono text-2xl font-bold text-[#D4A373]">
              {user.points.toLocaleString()} <span className="text-xs text-white">pts</span>
            </p>
          </div>
        </div>

        {/* Saved Delivery Address */}
        <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-4 rounded-xl space-y-2">
          <h3 className="font-serif font-bold text-sm text-[#1A1A1A] flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-[#C84B31]" />
            <span>{isJa ? '登録済みお届け先住所' : 'Saved Delivery Addresses'}</span>
          </h3>

          {user.savedAddresses.map((addr) => (
            <div key={addr.id} className="text-xs text-[#1A1A1A] bg-[#FAF9F5] p-3 rounded-lg border border-[#E5E5E1] space-y-0.5">
              <p className="font-bold">{addr.fullName} • {addr.phone}</p>
              <p className="text-[#8E8D8A]">〒{addr.postalCode} {addr.prefecture} {addr.cityAddress}</p>
            </div>
          ))}
        </div>

        {/* Order History */}
        <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-4 rounded-xl space-y-3">
          <h3 className="font-serif font-bold text-sm text-[#1A1A1A] flex items-center gap-1.5">
            <Package className="w-4 h-4 text-[#2D4A3E]" />
            <span>{isJa ? 'ご注文履歴 & 追跡' : 'Order History & Tracking'}</span>
          </h3>

          {user.orders.map((ord) => (
            <div key={ord.id} className="bg-[#FAF9F5] border border-[#E5E5E1] p-3 rounded-lg space-y-2 text-xs">
              <div className="flex items-center justify-between font-bold">
                <span className="font-serif text-[#C84B31]">{ord.id}</span>
                <span className="bg-[#2D4A3E] text-white text-[10px] px-2 py-0.5 rounded">
                  {ord.status} ({ord.trackingNumber})
                </span>
              </div>
              <p className="text-[#8E8D8A]">{ord.date} • {ord.items.length} {isJa ? '点' : 'items'} • 合計: ¥{ord.totalJpy.toLocaleString()}</p>
            </div>
          ))}
        </div>

        {/* Gift Cards */}
        <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-4 rounded-xl space-y-2">
          <h3 className="font-serif font-bold text-sm text-[#1A1A1A] flex items-center gap-1.5">
            <Gift className="w-4 h-4 text-[#D4A373]" />
            <span>{isJa ? 'ギフトカード残高' : 'Gift Card Balance'}</span>
          </h3>

          {user.giftCards.map((gc) => (
            <div key={gc.code} className="bg-[#FAF9F5] border border-[#E5E5E1] p-3 rounded-lg flex items-center justify-between text-xs">
              <div>
                <p className="font-mono font-bold">{gc.code}</p>
                <p className="text-[10px] text-[#8E8D8A]">{isJa ? '有効期限: ' : 'Expires: '}{gc.expiresAt}</p>
              </div>
              <span className="font-serif font-bold text-[#C84B31] text-sm">
                ¥{gc.balanceJpy.toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
