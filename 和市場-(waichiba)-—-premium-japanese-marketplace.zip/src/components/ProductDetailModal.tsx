import React, { useState } from 'react';
import {
  X,
  Star,
  ShoppingBag,
  Heart,
  ShieldCheck,
  Rotate3d,
  Truck,
  Sparkles,
  MapPin,
  MessageSquare,
  HelpCircle,
  Bot
} from 'lucide-react';
import { Product, Language, Review, ProductQnA } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  relatedProducts: Product[];
  reviews: Review[];
  qna: ProductQnA[];
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  currency: 'JPY' | 'USD';
  onAddToCart: (product: Product, quantity: number, options?: Record<string, string>) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
  onSelectProduct: (p: Product) => void;
  onAskAI: (prompt: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  relatedProducts,
  reviews,
  qna,
  isOpen,
  onClose,
  language,
  currency,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
  onSelectProduct,
  onAskAI,
}) => {
  if (!isOpen || !product) return null;

  const isJa = language === 'ja';
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [activeTab, setActiveTab] = useState<'details' | 'specs' | 'reviews' | 'qna' | 'ai'>('details');
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState<string>(
    product.options?.sizes ? product.options.sizes[0] : ''
  );
  const [selectedColor, setSelectedColor] = useState<string>(
    product.options?.colors ? product.options.colors[0].nameJa : ''
  );
  const [is360Mode, setIs360Mode] = useState(false);
  const [rotationDegree, setRotationDegree] = useState(0);

  // New review form state
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewComment, setNewReviewComment] = useState('');
  const [submittedReviews, setSubmittedReviews] = useState<Review[]>(reviews);

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewComment.trim()) return;
    const rev: Review = {
      id: `rev-${Date.now()}`,
      productId: product.id,
      userName: isJa ? '匿名のお客様' : 'Valued Customer',
      rating: newReviewRating,
      comment: newReviewComment,
      commentJa: newReviewComment,
      date: new Date().toISOString().split('T')[0],
      verifiedPurchase: true,
      helpfulCount: 1,
    };
    setSubmittedReviews([rev, ...submittedReviews]);
    setNewReviewComment('');
  };

  const images = product.gallery && product.gallery.length > 0 ? product.gallery : [product.image];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-[#FAF9F5] border border-[#E5E5E1] rounded-2xl max-w-5xl w-full max-h-[92vh] overflow-y-auto shadow-2xl relative my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 bg-[#1A1A1A] text-white rounded-full flex items-center justify-center hover:bg-[#C84B31] transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-4 sm:p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column: Image Gallery & 360 View */}
          <div className="space-y-4">
            <div className="relative aspect-square bg-[#FFFDF9] rounded-xl overflow-hidden border border-[#E5E5E1] shadow-inner group">
              {!is360Mode ? (
                <img
                  src={images[selectedImageIndex] || product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
              ) : (
                /* Simulated 360° Rotating View */
                <div className="w-full h-full flex flex-col items-center justify-center p-6 bg-[#FAF9F5] relative">
                  <div
                    className="w-full h-full transition-transform duration-100 flex items-center justify-center"
                    style={{ transform: `rotateY(${rotationDegree}deg)` }}
                  >
                    <img
                      src={images[0]}
                      alt="360 view"
                      className="max-h-full object-contain filter drop-shadow-xl"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-md p-3 rounded-xl border border-[#E5E5E1] flex items-center gap-3">
                    <Rotate3d className="w-5 h-5 text-[#C84B31] animate-spin" />
                    <input
                      type="range"
                      min="0"
                      max="360"
                      value={rotationDegree}
                      onChange={(e) => setRotationDegree(Number(e.target.value))}
                      className="w-full accent-[#C84B31]"
                    />
                    <span className="text-xs font-mono font-bold text-[#1A1A1A]">{rotationDegree}°</span>
                  </div>
                </div>
              )}

              {/* 360 Toggle Button */}
              <button
                onClick={() => setIs360Mode(!is360Mode)}
                className="absolute top-3 left-3 bg-[#1A1A1A]/90 hover:bg-[#1A1A1A] text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5 cursor-pointer backdrop-blur-md transition-all"
              >
                <Rotate3d className="w-3.5 h-3.5 text-[#D4A373]" />
                <span>{is360Mode ? (isJa ? '通常写真に戻る' : '2D View') : (isJa ? '360°立体表示' : '360° Interactive')}</span>
              </button>
            </div>

            {/* Gallery Thumbnails */}
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSelectedImageIndex(idx);
                    setIs360Mode(false);
                  }}
                  className={`w-16 h-16 rounded-lg overflow-hidden border-2 cursor-pointer shrink-0 transition-all ${
                    selectedImageIndex === idx && !is360Mode ? 'border-[#C84B31]' : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="thumb" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>

            {/* Artisan Card Embed */}
            {product.artisanNameJa && (
              <div className="bg-[#FFFDF9] border border-[#D4A373]/40 rounded-xl p-4 flex items-center gap-4">
                <div className="w-12 h-12 bg-[#D4A373]/20 rounded-full flex items-center justify-center font-serif text-lg font-bold text-[#D4A373] shrink-0">
                  匠
                </div>
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-[#D4A373] font-semibold">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isJa ? '伝統工芸士 作品' : 'Master Artisan Work'}</span>
                  </div>
                  <h4 className="font-serif font-bold text-sm text-[#1A1A1A]">
                    {isJa ? product.artisanNameJa : product.artisanName}
                  </h4>
                  <p className="text-[11px] text-[#8E8D8A]">
                    {isJa ? `産地: ${product.originJa}` : `Origin: ${product.origin}`}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Information, Price, Actions */}
          <div className="flex flex-col justify-between space-y-6">
            <div>
              {/* Category & Prefecture */}
              <div className="flex items-center gap-2 text-xs text-[#8E8D8A] font-medium mb-1">
                <MapPin className="w-3.5 h-3.5 text-[#C84B31]" />
                <span>{isJa ? product.prefectureJa : product.prefecture}</span>
                <span>•</span>
                <span>{isJa ? product.categoryJa : product.category}</span>
              </div>

              {/* Title */}
              <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#1A1A1A] leading-tight">
                {isJa ? product.nameJa : product.name}
              </h1>

              {/* Rating */}
              <div className="flex items-center gap-2 mt-2 text-xs">
                <div className="flex text-[#D4AF37]">
                  <Star className="w-4 h-4 fill-current" />
                </div>
                <span className="font-bold text-[#1A1A1A] text-sm">{product.rating}</span>
                <span className="text-[#8E8D8A]">({submittedReviews.length} {isJa ? '件のレビュー' : 'reviews'})</span>
              </div>

              {/* Price */}
              <div className="mt-4 pt-4 border-t border-[#E5E5E1] flex items-baseline gap-3">
                <span className="font-serif text-3xl font-bold text-[#1A1A1A]">
                  ¥{product.priceJpy.toLocaleString()}
                </span>
                <span className="text-xs text-[#8E8D8A]">
                  (~${Math.round(product.priceJpy / 150)} USD / {isJa ? '消費税10%込' : 'Tax Included'})
                </span>
              </div>

              {/* Options selection if available */}
              {product.options?.sizes && (
                <div className="mt-4">
                  <label className="text-xs font-semibold text-[#1A1A1A] block mb-2">
                    {isJa ? 'サイズ・仕様を選択:' : 'Select Size:'}
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {product.options.sizes.map((s) => (
                      <button
                        key={s}
                        onClick={() => setSelectedSize(s)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer transition-all ${
                          selectedSize === s
                            ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]'
                            : 'bg-white border-[#E5E5E1] text-[#1A1A1A] hover:border-[#1A1A1A]'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quantity Selector */}
              <div className="mt-4 flex items-center gap-4">
                <label className="text-xs font-semibold text-[#1A1A1A]">
                  {isJa ? '数量:' : 'Quantity:'}
                </label>
                <div className="flex items-center border border-[#E5E5E1] rounded-lg bg-white overflow-hidden">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 text-sm font-bold text-[#1A1A1A] hover:bg-[#FAF9F5] cursor-pointer"
                  >
                    -
                  </button>
                  <span className="px-4 py-1 text-xs font-mono font-bold text-[#1A1A1A]">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 text-sm font-bold text-[#1A1A1A] hover:bg-[#FAF9F5] cursor-pointer"
                  >
                    +
                  </button>
                </div>

                <span className="text-xs text-[#2D4A3E] font-semibold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#2D4A3E] animate-pulse" />
                  {isJa ? `在庫あり (残り${product.stockCount}点)` : `In Stock (${product.stockCount} left)`}
                </span>
              </div>

              {/* Main Action Buttons */}
              <div className="mt-6 flex items-center gap-3">
                <button
                  onClick={() => {
                    onAddToCart(product, quantity, {
                      ...(selectedSize ? { size: selectedSize } : {}),
                      ...(selectedColor ? { color: selectedColor } : {}),
                    });
                    onClose();
                  }}
                  className="flex-1 bg-[#1A1A1A] hover:bg-[#C84B31] text-[#FAF9F5] py-3.5 rounded-xl font-semibold text-xs sm:text-sm tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{isJa ? '買い物かごに追加' : 'Add to Cart'}</span>
                </button>

                <button
                  onClick={() => onToggleWishlist(product)}
                  className={`p-3.5 rounded-xl border transition-colors cursor-pointer ${
                    isWishlisted
                      ? 'bg-[#C84B31] text-white border-[#C84B31]'
                      : 'bg-white border-[#E5E5E1] text-[#1A1A1A] hover:border-[#C84B31]'
                  }`}
                  title={isJa ? 'お気に入り' : 'Wishlist'}
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Guarantees */}
              <div className="mt-6 bg-[#FFFDF9] border border-[#E5E5E1] rounded-xl p-3 grid grid-cols-2 gap-3 text-[11px] text-[#8E8D8A]">
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-[#D4A373]" />
                  <span>{isJa ? '桐箱・風呂敷贈答対応' : 'Paulownia Gift Box'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#D4A373]" />
                  <span>{isJa ? '正規職人直売・本物保証' : '100% Certified Authentic'}</span>
                </div>
              </div>
            </div>

            {/* Tabbed Navigation inside detail modal */}
            <div className="pt-4 border-t border-[#E5E5E1]">
              <div className="flex border-b border-[#E5E5E1] text-xs font-semibold gap-4">
                <button
                  onClick={() => setActiveTab('details')}
                  className={`pb-2 transition-colors cursor-pointer ${
                    activeTab === 'details' ? 'text-[#C84B31] border-b-2 border-[#C84B31]' : 'text-[#8E8D8A]'
                  }`}
                >
                  {isJa ? '商品説明' : 'Description'}
                </button>
                <button
                  onClick={() => setActiveTab('specs')}
                  className={`pb-2 transition-colors cursor-pointer ${
                    activeTab === 'specs' ? 'text-[#C84B31] border-b-2 border-[#C84B31]' : 'text-[#8E8D8A]'
                  }`}
                >
                  {isJa ? '仕様・素材' : 'Specs'}
                </button>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className={`pb-2 transition-colors cursor-pointer flex items-center gap-1 ${
                    activeTab === 'reviews' ? 'text-[#C84B31] border-b-2 border-[#C84B31]' : 'text-[#8E8D8A]'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>{isJa ? 'レビュー' : 'Reviews'}</span>
                </button>
                <button
                  onClick={() => setActiveTab('qna')}
                  className={`pb-2 transition-colors cursor-pointer flex items-center gap-1 ${
                    activeTab === 'qna' ? 'text-[#C84B31] border-b-2 border-[#C84B31]' : 'text-[#8E8D8A]'
                  }`}
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>{isJa ? 'Q&A' : 'Q&A'}</span>
                </button>
                <button
                  onClick={() => setActiveTab('ai')}
                  className={`pb-2 transition-colors cursor-pointer flex items-center gap-1 ${
                    activeTab === 'ai' ? 'text-[#C84B31] border-b-2 border-[#C84B31]' : 'text-[#8E8D8A]'
                  }`}
                >
                  <Bot className="w-3.5 h-3.5 text-[#D4A373]" />
                  <span>{isJa ? 'AI職人ガイド' : 'AI Advisor'}</span>
                </button>
              </div>

              {/* Tab Content */}
              <div className="py-4 text-xs text-[#1A1A1A] leading-relaxed">
                {activeTab === 'details' && (
                  <p>{isJa ? product.descriptionJa : product.description}</p>
                )}

                {activeTab === 'specs' && (
                  <div className="space-y-2">
                    {Object.entries(product.specifications).map(([key, val]) => (
                      <div key={key} className="flex justify-between border-b border-[#E5E5E1] pb-1">
                        <span className="font-semibold text-[#8E8D8A]">{key}:</span>
                        <span>{val}</span>
                      </div>
                    ))}
                    <div className="flex justify-between border-b border-[#E5E5E1] pb-1">
                      <span className="font-semibold text-[#8E8D8A]">{isJa ? '原産国:' : 'Origin:'}</span>
                      <span>{isJa ? product.originJa : product.origin}</span>
                    </div>
                  </div>
                )}

                {activeTab === 'reviews' && (
                  <div className="space-y-4">
                    {submittedReviews.map((rev) => (
                      <div key={rev.id} className="bg-white p-3 rounded-lg border border-[#E5E5E1]">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold">{rev.userName}</span>
                          <span className="text-[10px] text-[#8E8D8A]">{rev.date}</span>
                        </div>
                        <div className="flex text-[#D4AF37] mb-1">
                          {Array.from({ length: rev.rating }).map((_, i) => (
                            <Star key={i} className="w-3 h-3 fill-current" />
                          ))}
                        </div>
                        <p>{isJa ? rev.commentJa || rev.comment : rev.comment}</p>
                      </div>
                    ))}

                    {/* Submit Review */}
                    <form onSubmit={handleAddReview} className="bg-[#FFFDF9] p-3 rounded-lg border border-[#E5E5E1] space-y-2">
                      <p className="font-bold">{isJa ? 'レビューを書く' : 'Write a Review'}</p>
                      <div className="flex gap-1 text-[#D4AF37]">
                        {[1, 2, 3, 4, 5].map((st) => (
                          <Star
                            key={st}
                            onClick={() => setNewReviewRating(st)}
                            className={`w-4 h-4 cursor-pointer ${st <= newReviewRating ? 'fill-current' : 'text-slate-300'}`}
                          />
                        ))}
                      </div>
                      <textarea
                        value={newReviewComment}
                        onChange={(e) => setNewReviewComment(e.target.value)}
                        placeholder={isJa ? '使い心地や感想をご記入ください...' : 'Write your feedback here...'}
                        className="w-full bg-white border border-[#E5E5E1] rounded p-2 text-xs"
                        rows={2}
                      />
                      <button
                        type="submit"
                        className="bg-[#1A1A1A] text-white px-3 py-1.5 rounded text-xs cursor-pointer font-semibold"
                      >
                        {isJa ? '投稿する' : 'Submit Review'}
                      </button>
                    </form>
                  </div>
                )}

                {activeTab === 'qna' && (
                  <div className="space-y-3">
                    {qna.length > 0 ? (
                      qna.map((q) => (
                        <div key={q.id} className="bg-white p-3 rounded-lg border border-[#E5E5E1] space-y-1">
                          <p className="font-bold text-[#C84B31]">Q: {isJa ? q.questionJa || q.question : q.question}</p>
                          <p className="text-[#1A1A1A]">A: {isJa ? q.answerJa || q.answer : q.answer}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-[#8E8D8A]">{isJa ? '質問はまだありません。' : 'No questions asked yet.'}</p>
                    )}
                  </div>
                )}

                {activeTab === 'ai' && (
                  <div className="space-y-3 bg-[#FFFDF9] p-3 rounded-xl border border-[#D4A373]/30">
                    <p className="font-bold text-[#1A1A1A] flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-[#D4A373]" />
                      <span>{isJa ? 'おもてなし AI ガイドに質問' : 'Ask AI Concierge About This Item'}</span>
                    </p>
                    <p className="text-[#8E8D8A]">
                      {isJa
                        ? 'お手入れ方法、歴史的背景、おすすめのギフトの贈り方などAIが丁寧にお答えします。'
                        : 'Ask about care instructions, cultural heritage, or ideal occasion pairings.'}
                    </p>
                    <button
                      onClick={() => {
                        onAskAI(
                          isJa
                            ? `「${product.nameJa}」の手入れ方法と歴史的背景について詳しく教えてください。`
                            : `Tell me about the craftsmanship and care instructions for ${product.name}`
                        );
                        onClose();
                      }}
                      className="bg-[#D4A373] text-white px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer shadow-xs hover:bg-[#C29B38] transition-colors"
                    >
                      {isJa ? 'AIガイドに質問する' : 'Ask AI Guide Now'}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Related Products Section */}
        {relatedProducts.length > 0 && (
          <div className="p-6 bg-[#FAF9F5] border-t border-[#E5E5E1]">
            <h3 className="font-serif font-bold text-lg text-[#1A1A1A] mb-4">
              {isJa ? 'あわせておすすめの逸品' : 'Related Products You May Love'}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {relatedProducts.map((rel) => (
                <div
                  key={rel.id}
                  onClick={() => {
                    onSelectProduct(rel);
                    setSelectedImageIndex(0);
                  }}
                  className="bg-white border border-[#E5E5E1] rounded-lg p-2.5 cursor-pointer hover:border-[#C84B31] transition-all"
                >
                  <img src={rel.image} alt={rel.name} className="w-full aspect-square object-cover rounded mb-2" referrerPolicy="no-referrer" />
                  <p className="font-bold text-xs truncate">{isJa ? rel.nameJa : rel.name}</p>
                  <p className="text-[11px] text-[#8E8D8A]">¥{rel.priceJpy.toLocaleString()}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
