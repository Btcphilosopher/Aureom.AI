import React, { useState, useEffect } from 'react';
import { ArrowRight, Sparkles, ShieldCheck, Award } from 'lucide-react';
import { Language } from '../types';

interface HeroBannerProps {
  language: Language;
  onExploreProducts: () => void;
  onExploreCollections: () => void;
  onExploreArtisans: () => void;
}

const HERO_SLIDES = [
  {
    id: 'slide-1',
    image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=1920&q=80',
    titleJa: '静寂と研ぎ澄まされた美。',
    titleEn: 'Serenity & Refined Japanese Masterpieces',
    subtitleJa: '京都・清水焼と伝統の茶道具。時を越えて愛される至高の手仕事。',
    subtitleEn: 'Handcrafted Kiyomizu Ceramics & Tea Utensils from the Ancient Capital.',
    badgeJa: '京都伝統工芸士 特集',
    badgeEn: 'Kyoto Artisan Heritage',
    accentColor: '#D4A373',
  },
  {
    id: 'slide-2',
    image: 'https://images.unsplash.com/photo-1593618998160-e34014e67546?auto=format&fit=crop&w=1920&q=80',
    titleJa: '七百年継承される刃の魂。',
    titleEn: 'Seven Centuries of Blade Swordsmithing',
    subtitleJa: '越前打刃物・服部健二郎氏が鍛錬する最高峰ダマスカス鋼包丁。',
    subtitleEn: 'Sumi-Forged Damascus Kitchen Knives Masterforged in Fukui.',
    badgeJa: '越前鍛造包丁',
    badgeEn: 'Echizen Blades',
    accentColor: '#C84B31',
  },
  {
    id: 'slide-3',
    image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1920&q=80',
    titleJa: '自然の温もりが息づく暮らし。',
    titleEn: 'Minimalist Harmony Born of Wood & Stone',
    subtitleJa: '樹齢三百年 木曽檜と飛騨指物技術が生み出す現代の生活道具。',
    subtitleEn: 'Kiso Hinoki Cypress & Hida Joinery for Mindful Everyday Living.',
    badgeJa: '和のミニマリズム',
    badgeEn: 'Japanese Minimal Living',
    accentColor: '#2D4A3E',
  },
];

export const HeroBanner: React.FC<HeroBannerProps> = ({
  language,
  onExploreProducts,
  onExploreCollections,
  onExploreArtisans,
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const isJa = language === 'ja';

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const slide = HERO_SLIDES[currentSlideIndex];

  return (
    <section className="relative bg-[#1A1A1A] text-[#F9F8F4] overflow-hidden min-h-[520px] sm:min-h-[600px] flex items-center border-b border-[#1A1A1A]/10">
      {/* Background Image Slider with Smooth Crossfade */}
      {HERO_SLIDES.map((s, idx) => (
        <div
          key={s.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            idx === currentSlideIndex ? 'opacity-35' : 'opacity-0'
          }`}
        >
          <img
            src={s.image}
            alt={s.titleEn}
            className="w-full h-full object-cover scale-105 transition-transform duration-10000"
            referrerPolicy="no-referrer"
          />
        </div>
      ))}

      {/* Subtle Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#1A1A1A] via-[#1A1A1A]/85 to-transparent z-10" />

      {/* Content Container */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 w-full flex flex-col md:flex-row items-start justify-between gap-8">
        <div className="max-w-2xl space-y-6">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-[#F9F8F4]/10 backdrop-blur-md border border-[#F9F8F4]/20 px-3.5 py-1 text-[10px] uppercase font-bold tracking-[0.2em] text-[#D8C3A5]">
            <Sparkles className="w-3.5 h-3.5" style={{ color: slide.accentColor }} />
            <span>{isJa ? slide.badgeJa : slide.badgeEn}</span>
          </div>

          {/* Title */}
          <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-tight text-[#F9F8F4]">
            {isJa ? slide.titleJa : slide.titleEn}
          </h1>

          {/* Subtitle */}
          <p className="text-sm sm:text-base text-[#F2F0EB]/90 font-light max-w-xl leading-relaxed tracking-wide">
            {isJa ? slide.subtitleJa : slide.subtitleEn}
          </p>

          {/* Primary Action Buttons */}
          <div className="pt-4 flex flex-wrap items-center gap-3 sm:gap-4">
            <button
              onClick={onExploreProducts}
              className="bg-[#F9F8F4] hover:bg-[#F2F0EB] text-[#1A1A1A] px-8 py-3.5 text-[10px] font-bold tracking-[0.3em] uppercase flex items-center gap-2 transition-all cursor-pointer shadow-xs hover:translate-x-0.5"
            >
              <span>{isJa ? '商品を見る' : 'Explore Catalog'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onExploreCollections}
              className="bg-transparent hover:bg-[#F9F8F4]/10 text-[#F9F8F4] border border-[#F9F8F4]/40 hover:border-[#F9F8F4] px-8 py-3.5 text-[10px] font-bold tracking-[0.3em] uppercase transition-all cursor-pointer"
            >
              <span>{isJa ? '特集を見る' : 'Featured Collections'}</span>
            </button>

            <button
              onClick={onExploreArtisans}
              className="bg-transparent hover:bg-[#D8C3A5]/20 text-[#D8C3A5] border border-[#D8C3A5]/50 px-6 py-3.5 text-[10px] font-bold tracking-[0.3em] uppercase transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Award className="w-4 h-4" />
              <span>{isJa ? '職人一覧' : 'Meet Artisans'}</span>
            </button>
          </div>

          {/* Omotenashi Guarantees Bar */}
          <div className="pt-8 border-t border-[#F9F8F4]/10 grid grid-cols-3 gap-4 text-[11px] text-[#8E8D8A] tracking-wider uppercase">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#D8C3A5]" />
              <span>{isJa ? '全品100% 本物保証' : '100% Authentic Guarantee'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#D8C3A5]" />
              <span>{isJa ? '桐箱・風呂敷贈答包装' : 'Gift Wrapping Available'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-[#D8C3A5]" />
              <span>{isJa ? '伝統工芸士 直送' : 'Direct from Artisan Studios'}</span>
            </div>
          </div>
        </div>

        {/* Decorative Japanese Vertical Text Accent */}
        <div className="hidden lg:flex flex-col items-center gap-6 self-center border-l border-[#F9F8F4]/20 pl-8">
          <div className="writing-vertical-rl font-serif text-2xl tracking-[0.3em] text-[#F2F0EB]/80 select-none">
            伝統と革新の和市場
          </div>
          <div className="w-1 h-12 bg-gradient-to-b from-[#D8C3A5] to-transparent" />
        </div>
      </div>

      {/* Slider Indicator Dots */}
      <div className="absolute bottom-6 right-6 z-30 flex items-center gap-2">
        {HERO_SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlideIndex(idx)}
            className={`h-1 transition-all cursor-pointer ${
              idx === currentSlideIndex ? 'w-8 bg-[#D8C3A5]' : 'w-2 bg-[#F9F8F4]/40 hover:bg-[#F9F8F4]/70'
            }`}
          />
        ))}
      </div>
    </section>
  );
};
