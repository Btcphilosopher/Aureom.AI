import React from 'react';
import { Mail, ArrowRight, ShieldCheck, Award, Heart } from 'lucide-react';
import { Language } from '../types';

interface FooterProps {
  language: Language;
  onNavigateTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ language, onNavigateTab }) => {
  const isJa = language === 'ja';

  return (
    <footer className="bg-[#1A1A1A] text-[#FAF9F5] pt-16 pb-12 border-t border-[#FAF9F5]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Top Newsletter & Brand Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-12 border-b border-[#FAF9F5]/10">
          <div className="lg:col-span-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#C84B31] text-white flex items-center justify-center font-serif text-xl font-bold rounded-sm">
                和
              </div>
              <div>
                <span className="font-serif text-2xl font-bold tracking-tight">和市場</span>
                <span className="text-xs uppercase tracking-widest text-[#8E8D8A] ml-2">WaIchiba</span>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-[#E5E5E1] max-w-md font-light leading-relaxed">
              {isJa
                ? '美しい暮らしを、すべてここで。日本の卓越した職人技、伝統工芸、そして現代のミニマルデザインが融合するプレミアムオンラインマーケットプレイス。'
                : 'Everything for a beautiful life. A curated online marketplace combining Japanese craftsmanship with modern digital commerce.'}
            </p>
          </div>

          {/* Newsletter Signup */}
          <div className="lg:col-span-6 bg-[#FAF9F5]/5 p-6 rounded-2xl border border-[#FAF9F5]/10 space-y-3">
            <h4 className="font-serif font-bold text-sm text-[#FAF9F5]">
              {isJa ? '季節の便りと新作カタログをご案内' : 'Subscribe to Seasonal Craft Catalogues'}
            </h4>
            <p className="text-xs text-[#8E8D8A]">
              {isJa
                ? '京都の茶会情報や新作打刃物の先行入荷情報を定期的にお届けします。'
                : 'Receive exclusive invitations to artisan workshops and priority access to limited collections.'}
            </p>
            <form onSubmit={(e) => { e.preventDefault(); alert(isJa ? 'ご登録ありがとうございます。' : 'Subscribed successfully!'); }} className="flex gap-2">
              <input
                type="email"
                required
                placeholder={isJa ? 'メールアドレスを入力...' : 'Enter your email...'}
                className="flex-1 bg-[#1A1A1A] border border-[#FAF9F5]/20 rounded-xl px-4 py-2.5 text-xs text-white placeholder-[#8E8D8A] focus:outline-none focus:border-[#D4A373]"
              />
              <button
                type="submit"
                className="bg-[#D4A373] hover:bg-[#C29B38] text-[#1A1A1A] px-5 py-2.5 rounded-xl font-bold text-xs cursor-pointer transition-colors"
              >
                {isJa ? '登録する' : 'Subscribe'}
              </button>
            </form>
          </div>
        </div>

        {/* Links Column Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-xs text-[#E5E5E1]">
          <div className="space-y-3">
            <h4 className="font-serif font-bold text-sm text-[#FAF9F5]">
              {isJa ? 'カテゴリー' : 'Categories'}
            </h4>
            <ul className="space-y-2 text-[#8E8D8A]">
              <li><button onClick={() => onNavigateTab('catalog')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '包丁・台所道具' : 'Kitchen & Knives'}</button></li>
              <li><button onClick={() => onNavigateTab('catalog')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '清水焼・伝統工芸' : 'Kiyomizu Ceramics'}</button></li>
              <li><button onClick={() => onNavigateTab('catalog')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '宇治抹茶・茶道具' : 'Uji Matcha & Tea'}</button></li>
              <li><button onClick={() => onNavigateTab('catalog')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '木曽檜・生活雑貨' : 'Hinoki Home Essentials'}</button></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-serif font-bold text-sm text-[#FAF9F5]">
              {isJa ? '特集 & 職人' : 'Collections & Artisans'}
            </h4>
            <ul className="space-y-2 text-[#8E8D8A]">
              <li><button onClick={() => onNavigateTab('artisan')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '伝統工芸士 服部健二郎' : 'Master Kenjiro Hattori'}</button></li>
              <li><button onClick={() => onNavigateTab('artisan')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '清水焼 陶芸家 高田芳子' : 'Yoshiko Takada Ceramics'}</button></li>
              <li><button onClick={() => onNavigateTab('stores')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '銀座・祇園 直営店舗案内' : 'Ginza & Gion Boutiques'}</button></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-serif font-bold text-sm text-[#FAF9F5]">
              {isJa ? '和クラブ & 特典' : 'WaClub Loyalty'}
            </h4>
            <ul className="space-y-2 text-[#8E8D8A]">
              <li><button onClick={() => onNavigateTab('loyalty')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '会員ランク制度・ポイント' : 'Member Tiers & Points'}</button></li>
              <li><button onClick={() => onNavigateTab('loyalty')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '桐箱・風呂敷 贈答包装' : 'Gift Wrapping Service'}</button></li>
              <li><button onClick={() => onNavigateTab('loyalty')} className="hover:text-white transition-colors cursor-pointer">{isJa ? '適格請求書・領収書発行' : 'Official Tax Invoices'}</button></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-serif font-bold text-sm text-[#FAF9F5]">
              {isJa ? 'お問い合わせ' : 'Customer Support'}
            </h4>
            <p className="text-[#8E8D8A] leading-relaxed">
              {isJa
                ? '和市場 サポートデスク (10:00 - 18:00)\nEmail: support@waichiba.jp\nTel: +81 (0)3-5555-0192'
                : 'WaIchiba Concierge Desk\nEmail: support@waichiba.jp\nTel: +81 (0)3-5555-0192'}
            </p>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div className="pt-8 border-t border-[#FAF9F5]/10 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#8E8D8A] gap-4">
          <p>© 2026 和市場 (WaIchiba) 株式会社 / WaIchiba Inc. All Rights Reserved.</p>
          <div className="flex gap-4">
            <span className="hover:text-white cursor-pointer">{isJa ? '特定商取引法に基づく表記' : 'Commercial Code'}</span>
            <span className="hover:text-white cursor-pointer">{isJa ? 'プライバシーポリシー' : 'Privacy Policy'}</span>
            <span className="hover:text-white cursor-pointer">{isJa ? '適格請求書発行事業者登録番号 T1234567890123' : 'Tax Reg. T1234567890123'}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
