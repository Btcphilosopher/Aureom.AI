import React, { useState } from 'react';
import { Sparkles, Award, MapPin, ChevronRight, X } from 'lucide-react';
import { Artisan, Product, Language } from '../types';

interface ArtisanSectionProps {
  artisans: Artisan[];
  products: Product[];
  language: Language;
  onSelectProduct: (p: Product) => void;
}

export const ArtisanSection: React.FC<ArtisanSectionProps> = ({
  artisans,
  products,
  language,
  onSelectProduct,
}) => {
  const isJa = language === 'ja';
  const [selectedArtisan, setSelectedArtisan] = useState<Artisan | null>(null);

  return (
    <section className="py-16 bg-[#F9F8F4] border-y border-[#1A1A1A]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 bg-[#A64B4B] text-white text-[10px] font-bold px-2.5 py-1 uppercase tracking-[0.2em] mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isJa ? '01 / 匠の技' : '01 / ARTISANS'}</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#1A1A1A] tracking-tight">
              {isJa ? '日本全国の伝統工芸士・職人たち' : 'Craftsmen & Master Artisans of Japan'}
            </h2>
            <p className="text-sm text-[#8E8D8A] mt-2 max-w-xl font-light">
              {isJa
                ? '数百年の技を受け継ぎ、手仕事のぬくもりと究極の美を追求する職人の工房から直接お届けいたします。'
                : 'Directly connecting discerning patrons with centuries-old workshops across Japan’s 47 prefectures.'}
            </p>
          </div>
        </div>

        {/* Artisans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {artisans.map((artisan) => {
            const artisanProducts = products.filter((p) => p.artisanId === artisan.id);

            return (
              <div
                key={artisan.id}
                onClick={() => setSelectedArtisan(artisan)}
                className="group bg-[#FFFDF9] border border-[#1A1A1A]/10 overflow-hidden hover:border-[#1A1A1A]/40 transition-all duration-300 flex flex-col justify-between cursor-pointer"
              >
                {/* Workshop Banner */}
                <div className="relative h-40 overflow-hidden bg-[#1A1A1A]">
                  <img
                    src={artisan.workshopImage}
                    alt={artisan.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-75"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

                  {/* Experience Badge */}
                  <div className="absolute top-3 right-3 bg-[#1A1A1A]/90 text-[#F9F8F4] text-[10px] uppercase tracking-widest font-bold px-2.5 py-1 border border-white/20 flex items-center gap-1">
                    <Award className="w-3 h-3 text-[#D8C3A5]" />
                    <span>{isJa ? `歴${artisan.yearsOfExperience}年` : `${artisan.yearsOfExperience} Yrs Exp`}</span>
                  </div>

                  {/* Avatar Overlay */}
                  <div className="absolute -bottom-5 left-4 w-14 h-14 border-2 border-[#F9F8F4] overflow-hidden bg-white shadow-xs">
                    <img
                      src={artisan.avatar}
                      alt={artisan.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>

                {/* Artisan Info */}
                <div className="p-5 pt-8 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <div className="flex items-center gap-1 text-[10px] uppercase tracking-[0.2em] text-[#8E8D8A] font-medium mb-1">
                      <MapPin className="w-3 h-3 text-[#A64B4B]" />
                      <span>{isJa ? artisan.prefectureJa : artisan.prefecture}</span>
                    </div>

                    <h3 className="font-serif font-bold text-lg text-[#1A1A1A] group-hover:text-[#A64B4B] transition-colors">
                      {isJa ? artisan.nameJa : artisan.name}
                    </h3>
                    <p className="text-xs text-[#8E8D8A] font-medium mt-0.5 tracking-wider">
                      {isJa ? artisan.craftJa : artisan.craft}
                    </p>

                    <blockquote className="text-xs text-[#8E8D8A] italic mt-3 line-clamp-2 border-l-2 border-[#D8C3A5] pl-2.5">
                      "{isJa ? artisan.philosophyJa : artisan.philosophy}"
                    </blockquote>
                  </div>

                  {/* Featured Item Preview */}
                  {artisanProducts.length > 0 && (
                    <div className="pt-3 border-t border-[#1A1A1A]/10 flex items-center justify-between text-xs text-[#1A1A1A]">
                      <span className="text-[#8E8D8A] text-[10px] uppercase tracking-wider">
                        {isJa ? `代表作 (${artisanProducts.length}点)` : `Work (${artisanProducts.length})`}
                      </span>
                      <span className="font-bold flex items-center gap-1 text-[#A64B4B] text-[11px] tracking-wider uppercase">
                        <span>{isJa ? '作品を見る' : 'View Works'}</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Artisan Detail Modal */}
      {selectedArtisan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-[#FAF9F5] border border-[#E5E5E1] rounded-2xl max-w-3xl w-full p-6 sm:p-8 relative shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedArtisan(null)}
              className="absolute top-4 right-4 w-9 h-9 bg-[#1A1A1A] text-white rounded-full flex items-center justify-center hover:bg-[#C84B31] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 pt-2">
              <img
                src={selectedArtisan.avatar}
                alt={selectedArtisan.name}
                className="w-24 h-24 rounded-full object-cover border-2 border-[#D4A373]"
                referrerPolicy="no-referrer"
              />
              <div className="space-y-1 text-center sm:text-left">
                <div className="inline-flex items-center gap-1 text-xs text-[#D4A373] font-bold">
                  <Award className="w-4 h-4" />
                  <span>{isJa ? `伝統工芸士 (歴${selectedArtisan.yearsOfExperience}年)` : `Licensed Master Artisan (${selectedArtisan.yearsOfExperience} years)`}</span>
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#1A1A1A]">
                  {isJa ? selectedArtisan.nameJa : selectedArtisan.name}
                </h3>
                <p className="text-xs text-[#8E8D8A] font-semibold">
                  {isJa ? selectedArtisan.craftJa : selectedArtisan.craft} • {isJa ? selectedArtisan.prefectureJa : selectedArtisan.prefecture}
                </p>
              </div>
            </div>

            {/* Biography */}
            <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-4 rounded-xl space-y-2 text-xs leading-relaxed text-[#1A1A1A]">
              <p className="font-serif font-bold text-sm text-[#D4A373]">
                {isJa ? '【 匠の哲学 】' : '【 Artisan Philosophy 】'}
              </p>
              <blockquote className="italic font-serif text-sm border-l-2 border-[#D4A373] pl-3 py-1">
                "{isJa ? selectedArtisan.philosophyJa : selectedArtisan.philosophy}"
              </blockquote>
              <p className="pt-2">{isJa ? selectedArtisan.bioJa : selectedArtisan.bio}</p>
            </div>

            {/* Signature Works Grid */}
            <div>
              <h4 className="font-serif font-bold text-base text-[#1A1A1A] mb-3">
                {isJa ? '代表作品一覧' : 'Signature Masterworks'}
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {products
                  .filter((p) => p.artisanId === selectedArtisan.id)
                  .map((p) => (
                    <div
                      key={p.id}
                      onClick={() => {
                        onSelectProduct(p);
                        setSelectedArtisan(null);
                      }}
                      className="bg-white border border-[#E5E5E1] p-2.5 rounded-lg cursor-pointer hover:border-[#C84B31] transition-all"
                    >
                      <img src={p.image} alt={p.name} className="w-full aspect-square object-cover rounded mb-2" referrerPolicy="no-referrer" />
                      <p className="font-bold text-xs truncate">{isJa ? p.nameJa : p.name}</p>
                      <p className="text-[11px] text-[#C84B31] font-mono">¥{p.priceJpy.toLocaleString()}</p>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
