import React, { useState } from 'react';
import {
  X,
  CreditCard,
  Building,
  CheckCircle2,
  FileText,
  Download,
  Gift,
  ShieldCheck,
  Printer
} from 'lucide-react';
import { CartItem, Language, Order } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  giftWrapped: boolean;
  couponCode: string;
  language: Language;
  onOrderCompleted: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  giftWrapped,
  couponCode,
  language,
  onOrderCompleted,
}) => {
  if (!isOpen) return null;

  const isJa = language === 'ja';
  const [step, setStep] = useState<'form' | 'receipt'>('form');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypay' | 'konbini' | 'bank'>('card');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<any>(null);

  // Form fields
  const [fullName, setFullName] = useState('山田 太郎 (Taro Yamada)');
  const [postalCode, setPostalCode] = useState('104-0061');
  const [prefecture, setPrefecture] = useState('東京都 (Tokyo)');
  const [cityAddress, setCityAddress] = useState('中央区銀座 3-5-1 和市場ビル 1202号室');
  const [phone, setPhone] = useState('090-1234-5678');

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items,
          giftWrapped,
          couponCode,
          paymentMethod: paymentMethod.toUpperCase(),
          shippingAddress: {
            fullName,
            postalCode,
            prefecture,
            cityAddress,
            phone,
          }
        })
      });

      const orderData = await response.json();
      setCompletedOrder(orderData);
      onOrderCompleted(orderData);
      setStep('receipt');
    } catch (err) {
      console.error(err);
      alert('Order failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-[#FAF9F5] border border-[#E5E5E1] rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl relative p-6 sm:p-8">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-8 h-8 bg-[#1A1A1A] text-white rounded-full flex items-center justify-center hover:bg-[#C84B31] transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {step === 'form' ? (
          <form onSubmit={handleSubmitOrder} className="space-y-6">
            <div>
              <div className="inline-flex items-center gap-1.5 bg-[#C84B31]/10 text-[#C84B31] text-xs font-bold px-3 py-1 rounded-full mb-2">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{isJa ? '暗号化 セキュアチェックアウト' : 'Encrypted Checkout'}</span>
              </div>
              <h2 className="font-serif text-2xl font-bold text-[#1A1A1A]">
                {isJa ? 'ご注文手続き・お届け先指定' : 'Delivery & Checkout'}
              </h2>
            </div>

            {/* Delivery Address Section */}
            <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-4 rounded-xl space-y-3">
              <h3 className="font-serif font-bold text-sm text-[#1A1A1A] border-b border-[#E5E5E1] pb-2">
                {isJa ? '1. お届け先住所' : '1. Shipping Address'}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="font-semibold block mb-1">{isJa ? 'お名前 (氏名)' : 'Full Name'}</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-white border border-[#E5E5E1] rounded p-2 focus:outline-none focus:border-[#1A1A1A]"
                  />
                </div>

                <div>
                  <label className="font-semibold block mb-1">{isJa ? '郵便番号' : 'Postal Code'}</label>
                  <input
                    type="text"
                    required
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    className="w-full bg-white border border-[#E5E5E1] rounded p-2 focus:outline-none focus:border-[#1A1A1A]"
                  />
                </div>

                <div>
                  <label className="font-semibold block mb-1">{isJa ? '都道府県' : 'Prefecture'}</label>
                  <input
                    type="text"
                    required
                    value={prefecture}
                    onChange={(e) => setPrefecture(e.target.value)}
                    className="w-full bg-white border border-[#E5E5E1] rounded p-2 focus:outline-none focus:border-[#1A1A1A]"
                  />
                </div>

                <div>
                  <label className="font-semibold block mb-1">{isJa ? '電話番号' : 'Phone'}</label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-white border border-[#E5E5E1] rounded p-2 focus:outline-none focus:border-[#1A1A1A]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="font-semibold block mb-1">{isJa ? '市区町村・番地・建物名' : 'City, Street & Building'}</label>
                  <input
                    type="text"
                    required
                    value={cityAddress}
                    onChange={(e) => setCityAddress(e.target.value)}
                    className="w-full bg-white border border-[#E5E5E1] rounded p-2 focus:outline-none focus:border-[#1A1A1A]"
                  />
                </div>
              </div>
            </div>

            {/* Payment Selection */}
            <div className="bg-[#FFFDF9] border border-[#E5E5E1] p-4 rounded-xl space-y-3">
              <h3 className="font-serif font-bold text-sm text-[#1A1A1A] border-b border-[#E5E5E1] pb-2">
                {isJa ? '2. お支払い方法を選択' : '2. Select Payment Method'}
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-lg border flex flex-col items-center gap-1.5 cursor-pointer font-semibold ${
                    paymentMethod === 'card' ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]' : 'bg-white border-[#E5E5E1]'
                  }`}
                >
                  <CreditCard className="w-5 h-5" />
                  <span>{isJa ? 'クレジットカード' : 'Credit Card'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('paypay')}
                  className={`p-3 rounded-lg border flex flex-col items-center gap-1.5 cursor-pointer font-semibold ${
                    paymentMethod === 'paypay' ? 'bg-[#C84B31] text-white border-[#C84B31]' : 'bg-white border-[#E5E5E1]'
                  }`}
                >
                  <span className="font-bold font-serif text-sm">PayPay</span>
                  <span>{isJa ? 'スマホ決済' : 'PayPay'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('konbini')}
                  className={`p-3 rounded-lg border flex flex-col items-center gap-1.5 cursor-pointer font-semibold ${
                    paymentMethod === 'konbini' ? 'bg-[#2D4A3E] text-white border-[#2D4A3E]' : 'bg-white border-[#E5E5E1]'
                  }`}
                >
                  <Building className="w-5 h-5" />
                  <span>{isJa ? 'コンビニ決済' : 'Konbini Pay'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank')}
                  className={`p-3 rounded-lg border flex flex-col items-center gap-1.5 cursor-pointer font-semibold ${
                    paymentMethod === 'bank' ? 'bg-[#1D2A44] text-white border-[#1D2A44]' : 'bg-white border-[#E5E5E1]'
                  }`}
                >
                  <Building className="w-5 h-5" />
                  <span>{isJa ? '銀行振込' : 'Bank Transfer'}</span>
                </button>
              </div>
            </div>

            {/* Submit Order Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#1A1A1A] hover:bg-[#C84B31] text-white py-4 rounded-xl font-bold text-sm tracking-wider cursor-pointer shadow-lg transition-colors flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <span>{isJa ? '注文処理中...' : 'Processing Order...'}</span>
              ) : (
                <>
                  <CheckCircle2 className="w-5 h-5 text-[#D4A373]" />
                  <span>{isJa ? '注文を確定し適格請求書を発行' : 'Confirm Order & Issue Official Invoice'}</span>
                </>
              )}
            </button>
          </form>
        ) : (
          /* Japanese Tax Invoice & Receipt Modal View */
          <div className="space-y-6">
            <div className="text-center space-y-2 border-b border-[#E5E5E1] pb-4">
              <CheckCircle2 className="w-12 h-12 text-[#2D4A3E] mx-auto animate-bounce" />
              <h2 className="font-serif text-2xl font-bold text-[#1A1A1A]">
                {isJa ? 'ご注文が完了いたしました' : 'Order Placed Successfully'}
              </h2>
              <p className="text-xs text-[#8E8D8A]">
                {isJa
                  ? '和市場をご利用いただき誠にありがとうございます。職人の手仕事で丁寧にお包みいたします。'
                  : 'Thank you for supporting authentic Japanese craftsmanship.'}
              </p>
            </div>

            {/* Official Tax Invoice Container */}
            <div className="bg-white border border-[#1A1A1A] p-6 rounded-xl font-mono text-xs space-y-4 shadow-sm relative">
              <div className="flex justify-between items-start border-b border-dashed border-slate-300 pb-3">
                <div>
                  <span className="font-serif font-bold text-base text-[#1A1A1A] block">
                    適格請求書・領収書 (Qualified Tax Invoice)
                  </span>
                  <p className="text-[10px] text-[#8E8D8A]">{completedOrder?.issuer}</p>
                  <p className="text-[10px] text-[#8E8D8A]">登録番号: {completedOrder?.registrationNumber}</p>
                </div>
                <div className="text-right">
                  <span className="font-bold text-[#C84B31]">{completedOrder?.id}</span>
                  <p className="text-[10px] text-[#8E8D8A]">日付: {completedOrder?.date}</p>
                  <p className="text-[10px] text-[#8E8D8A]">領収番号: {completedOrder?.receiptNumber}</p>
                </div>
              </div>

              {/* Items Breakdown Table */}
              <div className="space-y-1.5">
                <div className="flex justify-between font-bold border-b pb-1 text-[#8E8D8A]">
                  <span>商品名</span>
                  <span>数量 x 単価</span>
                  <span>金額</span>
                </div>
                {completedOrder?.items?.map((it: any, i: number) => (
                  <div key={i} className="flex justify-between">
                    <span className="truncate max-w-[200px] font-sans font-medium">{it.product.nameJa}</span>
                    <span>{it.quantity} x ¥{it.product.priceJpy.toLocaleString()}</span>
                    <span>¥{(it.product.priceJpy * it.quantity).toLocaleString()}</span>
                  </div>
                ))}
              </div>

              {/* Tax Calculations */}
              <div className="pt-3 border-t border-dashed border-slate-300 space-y-1 text-right">
                <p>小計: ¥{completedOrder?.subtotalJpy.toLocaleString()}</p>
                {completedOrder?.discountJpy > 0 && <p className="text-[#C84B31]">割引: -¥{completedOrder?.discountJpy.toLocaleString()}</p>}
                <p>内消費税 (10%対象): ¥{completedOrder?.taxJpy.toLocaleString()}</p>
                <p>送料: ¥{completedOrder?.shippingJpy.toLocaleString()}</p>
                <p className="font-bold text-base text-[#1A1A1A] pt-1">
                  合計領収金額: ¥{completedOrder?.totalJpy.toLocaleString()}
                </p>
                <p className="text-[#2D4A3E] font-bold text-[11px] pt-1">
                  ★ 今回獲得ポイント: +{completedOrder?.pointsEarned} pts (和クラブ)
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <button
                onClick={() => window.print()}
                className="flex-1 bg-white border border-[#1A1A1A] hover:bg-[#FAF9F5] text-[#1A1A1A] py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>{isJa ? '領収書を印刷' : 'Print Tax Invoice'}</span>
              </button>

              <button
                onClick={onClose}
                className="flex-1 bg-[#1A1A1A] text-white py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer hover:bg-[#C84B31]"
              >
                <span>{isJa ? 'お買い物を続ける' : 'Back to Shopping'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
