import React, { useState } from 'react';
import { Bot, Send, X, Sparkles, ShoppingBag, ArrowRight } from 'lucide-react';
import { Product, Language } from '../types';

interface OmotenashiConciergeProps {
  language: Language;
  onSelectProduct: (p: Product) => void;
  externalPrompt?: string;
  onClearExternalPrompt?: () => void;
}

export const OmotenashiConcierge: React.FC<OmotenashiConciergeProps> = ({
  language,
  onSelectProduct,
  externalPrompt,
  onClearExternalPrompt,
}) => {
  const isJa = language === 'ja';
  const [isOpen, setIsOpen] = useState(false);
  const [inputPrompt, setInputPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{
    sender: 'user' | 'concierge';
    text: string;
    products?: Product[];
  }>>([
    {
      sender: 'concierge',
      text: isJa
        ? 'いらっしゃいませ。和市場の「おもてなし AI コンシェルジュ」でございます。大切な方へのご贈答品選び、越前包丁やお茶道具のお手入れ方法など、何なりとお気軽にご相談ください。'
        : 'Welcome to WaIchiba. I am your Omotenashi AI Concierge. How may I guide your journey through authentic Japanese craft today?',
    }
  ]);

  // Handle external prompt if triggered from product detail
  React.useEffect(() => {
    if (externalPrompt) {
      setIsOpen(true);
      handleSendMessage(externalPrompt);
      if (onClearExternalPrompt) onClearExternalPrompt();
    }
  }, [externalPrompt]);

  const handleSendMessage = async (promptText: string) => {
    if (!promptText.trim() || loading) return;

    const userMsg = { sender: 'user' as const, text: promptText };
    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai/concierge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptText,
          language,
        })
      });

      const data = await response.json();
      setMessages((prev) => [
        ...prev,
        {
          sender: 'concierge',
          text: data.response,
          products: data.recommendedProducts
        }
      ]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          sender: 'concierge',
          text: isJa
            ? '大変申し訳ございません。通信状況によりAI応答に遅延が生じております。'
            : 'Apologies, our concierge connection experienced a brief pause.'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const PROMPT_CHIPS = isJa
    ? [
        '結婚祝いに最適な高級伝統工芸品',
        '越前ダマスカス包丁の研ぎ方と手入れ',
        '宇治抹茶の正しい点て方とおすすめ茶器',
        '新築祝いに喜ばれる檜の生活道具'
      ]
    : [
        'Best artisan wedding gift recommendations',
        'How to maintain Echizen Damascus steel knives',
        'Ceremonial matcha brewing & tea bowls',
        'Hinoki cypress housewarming gifts'
      ];

  return (
    <>
      {/* Floating Concierge Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-40 bg-[#1A1A1A] hover:bg-[#C84B31] text-[#FAF9F5] p-3.5 sm:px-5 sm:py-3.5 rounded-full shadow-2xl flex items-center gap-2.5 transition-all duration-300 cursor-pointer border border-[#D4A373]/50 group"
      >
        <div className="w-8 h-8 rounded-full bg-[#D4A373] text-white flex items-center justify-center shrink-0">
          <Bot className="w-4 h-4 animate-pulse" />
        </div>
        <div className="text-left hidden sm:block">
          <span className="text-[10px] text-[#D4A373] font-bold block leading-none">
            {isJa ? 'おもてなし AI' : 'OMOTENASHI AI'}
          </span>
          <span className="text-xs font-serif font-bold">
            {isJa ? 'AI コンシェルジュ' : 'Craft Concierge'}
          </span>
        </div>
      </button>

      {/* Floating Chat Drawer Window */}
      {isOpen && (
        <div className="fixed bottom-20 right-4 sm:right-6 z-50 w-[92vw] sm:w-[420px] max-h-[580px] h-[80vh] bg-[#FAF9F5] border border-[#E5E5E1] rounded-2xl shadow-2xl flex flex-col justify-between overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-300">
          {/* Header */}
          <div className="bg-[#1A1A1A] text-[#FAF9F5] p-4 flex items-center justify-between border-b border-[#D4A373]/30">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-[#D4A373] text-white rounded-full flex items-center justify-center font-bold">
                和
              </div>
              <div>
                <h3 className="font-serif font-bold text-sm">
                  {isJa ? 'おもてなし AI コンシェルジュ' : 'Omotenashi AI Concierge'}
                </h3>
                <p className="text-[10px] text-[#D4A373]">
                  {isJa ? '日本の伝統工芸 & ギフトのご相談' : 'Japanese Heritage & Gift Advisor'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="text-[#8E8D8A] hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Body */}
          <div className="p-4 flex-1 overflow-y-auto space-y-4 text-xs">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex flex-col ${
                  msg.sender === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`p-3.5 rounded-2xl max-w-[85%] leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-[#1A1A1A] text-white rounded-br-none font-medium'
                      : 'bg-[#FFFDF9] text-[#1A1A1A] border border-[#E5E5E1] rounded-bl-none shadow-xs'
                  }`}
                >
                  <p>{msg.text}</p>
                </div>

                {/* Recommended Product Cards inside Chat */}
                {msg.products && msg.products.length > 0 && (
                  <div className="mt-2.5 w-full space-y-2">
                    <p className="text-[10px] font-bold text-[#8E8D8A] uppercase tracking-wider flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-[#D4A373]" />
                      <span>{isJa ? 'コンシェルジュ推薦商品' : 'Recommended Items'}</span>
                    </p>
                    <div className="grid grid-cols-1 gap-2">
                      {msg.products.map((p) => (
                        <div
                          key={p.id}
                          onClick={() => {
                            onSelectProduct(p);
                            setIsOpen(false);
                          }}
                          className="bg-white border border-[#E5E5E1] hover:border-[#C84B31] p-2 rounded-xl flex items-center gap-3 cursor-pointer transition-all shadow-2xs"
                        >
                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-12 h-12 object-cover rounded-lg"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="font-serif font-bold truncate text-[#1A1A1A]">
                              {isJa ? p.nameJa : p.name}
                            </p>
                            <p className="text-[10px] text-[#C84B31] font-mono font-bold">
                              ¥{p.priceJpy.toLocaleString()} • {p.prefectureJa}
                            </p>
                          </div>
                          <ArrowRight className="w-4 h-4 text-[#8E8D8A] shrink-0" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex items-center gap-2 text-[#8E8D8A] italic">
                <Bot className="w-4 h-4 animate-spin text-[#D4A373]" />
                <span>{isJa ? 'お答えを準備しております...' : 'Thinking with Omotenashi...'}</span>
              </div>
            )}
          </div>

          {/* Quick Prompt Chips */}
          <div className="p-2.5 bg-[#FAF9F5] border-t border-[#E5E5E1] overflow-x-auto no-scrollbar flex gap-1.5">
            {PROMPT_CHIPS.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(chip)}
                className="bg-white hover:bg-[#E5E5E1] text-[#1A1A1A] border border-[#E5E5E1] px-2.5 py-1 rounded-full text-[11px] whitespace-nowrap cursor-pointer transition-colors shrink-0"
              >
                {chip}
              </button>
            ))}
          </div>

          {/* Input Footer */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputPrompt);
            }}
            className="p-3 bg-[#FFFDF9] border-t border-[#E5E5E1] flex gap-2"
          >
            <input
              type="text"
              placeholder={isJa ? '伝統工芸やギフトについて尋ねる...' : 'Ask about crafts or gifts...'}
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              className="flex-1 bg-white border border-[#E5E5E1] rounded-full px-4 py-2 text-xs focus:outline-none focus:border-[#1A1A1A]"
            />
            <button
              type="submit"
              disabled={loading || !inputPrompt.trim()}
              className="bg-[#1A1A1A] hover:bg-[#C84B31] text-white p-2 rounded-full cursor-pointer transition-colors shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
