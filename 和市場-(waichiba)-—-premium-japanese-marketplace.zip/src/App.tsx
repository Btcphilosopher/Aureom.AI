import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ArtisanSection } from './components/ArtisanSection';
import { StoreLocator } from './components/StoreLocator';
import { LoyaltyProgram } from './components/LoyaltyProgram';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { UserAccountModal } from './components/UserAccountModal';
import { AdminDashboard } from './components/AdminDashboard';
import { OmotenashiConcierge } from './components/OmotenashiConcierge';
import { Footer } from './components/Footer';

import {
  MOCK_PRODUCTS,
  MOCK_CATEGORIES,
  MOCK_COLLECTIONS,
  MOCK_ARTISANS,
  MOCK_STORES,
  MOCK_USER,
  MOCK_REVIEWS,
  MOCK_QNA
} from './data/mockData';

import { Language, Product, CartItem, UserProfile, Order } from './types';
import { Sparkles, ArrowRight, Filter, ChevronRight, Heart, Award, MapPin } from 'lucide-react';

export default function App() {
  const [language, setLanguage] = useState<Language>('ja');
  const [currency, setCurrency] = useState<'JPY' | 'USD'>('JPY');
  const [activeTab, setActiveTab] = useState<string>('home');

  // Products and data
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [artisans, setArtisans] = useState(MOCK_ARTISANS);
  const [stores, setStores] = useState(MOCK_STORES);
  const [user, setUser] = useState<UserProfile>(MOCK_USER);

  // Cart & Wishlist
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      product: MOCK_PRODUCTS[0],
      quantity: 1,
      selectedSize: '180mm',
    }
  ]);
  const [wishlist, setWishlist] = useState<Product[]>([MOCK_PRODUCTS[1]]);

  // Modals & Drawers
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [productReviews, setProductReviews] = useState(MOCK_REVIEWS);
  const [productQna, setProductQna] = useState(MOCK_QNA);

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);

  // Checkout arguments
  const [checkoutGiftWrap, setCheckoutGiftWrap] = useState(true);
  const [checkoutCoupon, setCheckoutCoupon] = useState('');

  // Filtering
  const [searchQuery, setSearchQuery] = useState('');
  const [searchSuggestions, setSearchSuggestions] = useState<{ suggestions: string[]; products: any[] }>({
    suggestions: [],
    products: []
  });
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [collectionFilter, setCollectionFilter] = useState<string>('');
  const [prefectureFilter, setPrefectureFilter] = useState<string>('');
  const [sortOption, setSortOption] = useState<string>('featured');

  // AI External Prompt
  const [aiExternalPrompt, setAiExternalPrompt] = useState<string>('');

  const isJa = language === 'ja';

  // Fetch product suggestions from API on query change
  useEffect(() => {
    if (searchQuery.trim().length > 0) {
      fetch('/api/search/suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery }),
      })
        .then((res) => res.json())
        .then((data) => setSearchSuggestions(data))
        .catch((err) => console.error(err));
    } else {
      setSearchSuggestions({ suggestions: [], products: [] });
    }
  }, [searchQuery]);

  // Open Product Detail
  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    const rel = products.filter(
      (p) => p.id !== product.id && (p.category === product.category || p.collectionId === product.collectionId)
    ).slice(0, 4);
    setRelatedProducts(rel);
    setProductReviews(MOCK_REVIEWS.filter((r) => r.productId === product.id));
    setProductQna(MOCK_QNA.filter((q) => q.productId === product.id));
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1, options?: Record<string, string>) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { product, quantity, selectedSize: options?.size, selectedColor: options?.color }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveCartItem(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Wishlist toggle
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) return prev.filter((p) => p.id !== product.id);
      return [...prev, product];
    });
  };

  // Order Completed
  const handleOrderCompleted = (newOrder: Order) => {
    setUser((prev) => ({
      ...prev,
      points: prev.points + ((newOrder as any).pointsEarned || 0),
      orders: [newOrder, ...prev.orders],
    }));
    setCartItems([]);
  };

  // Admin Actions
  const handleUpdateStock = (productId: string, newStock: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, stockCount: newStock, inStock: newStock > 0 } : p))
    );
  };

  const handleAddProduct = (newProd: Partial<Product>) => {
    setProducts((prev) => [newProd as Product, ...prev]);
  };

  // Filtered Products
  const displayedProducts = products.filter((p) => {
    if (categoryFilter && p.category !== categoryFilter) return false;
    if (collectionFilter && p.collectionId !== collectionFilter) return false;
    if (prefectureFilter && !p.prefectureJa.includes(prefectureFilter) && !p.prefecture.includes(prefectureFilter)) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const match =
        p.name.toLowerCase().includes(q) ||
        p.nameJa.includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.descriptionJa.includes(q) ||
        p.prefecture.toLowerCase().includes(q) ||
        p.prefectureJa.includes(q) ||
        (p.artisanName && p.artisanName.toLowerCase().includes(q)) ||
        (p.artisanNameJa && p.artisanNameJa.includes(q));
      if (!match) return false;
    }
    return true;
  }).sort((a, b) => {
    if (sortOption === 'price-low') return a.priceJpy - b.priceJpy;
    if (sortOption === 'price-high') return b.priceJpy - a.priceJpy;
    if (sortOption === 'rating') return b.rating - a.rating;
    return 0;
  });

  return (
    <div className="min-h-screen bg-[#FAF9F5] text-[#1A1A1A] flex flex-col justify-between font-sans selection:bg-[#D4A373]/30">
      {/* Primary Sticky Header Navigation */}
      <Navbar
        language={language}
        setLanguage={setLanguage}
        currency={currency}
        setCurrency={setCurrency}
        cartItems={cartItems}
        wishlistCount={wishlist.length}
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        setIsCartOpen={setIsCartOpen}
        setIsAccountOpen={setIsAccountOpen}
        onSearch={(q) => {
          setSearchQuery(q);
          if (q.trim()) setActiveTab('catalog');
        }}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        searchSuggestions={searchSuggestions}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {/* VIEW 1: HOME */}
        {activeTab === 'home' && (
          <div className="space-y-16 pb-16">
            {/* Cinematic Hero Slider */}
            <HeroBanner
              language={language}
              onExploreProducts={() => setActiveTab('catalog')}
              onExploreCollections={() => setActiveTab('catalog')}
              onExploreArtisans={() => setActiveTab('artisan')}
            />

            {/* Featured Product Categories Carousel */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-end justify-between mb-8">
                <div>
                  <span className="text-xs uppercase font-bold text-[#D4A373] tracking-widest block mb-1">
                    {isJa ? '厳選カテゴリー' : 'Product Categories'}
                  </span>
                  <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#1A1A1A]">
                    {isJa ? '道具から生まれる美しい暮らし' : 'Crafted Essentials for Daily Living'}
                  </h2>
                </div>
                <button
                  onClick={() => setActiveTab('catalog')}
                  className="text-xs font-bold text-[#C84B31] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>{isJa ? '全カテゴリーを見る' : 'All Categories'}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
                {MOCK_CATEGORIES.map((cat) => (
                  <div
                    key={cat.id}
                    onClick={() => {
                      setCategoryFilter(cat.id);
                      setActiveTab('catalog');
                    }}
                    className="group bg-[#FFFDF9] border border-[#E5E5E1] hover:border-[#1A1A1A] rounded-xl p-3 text-center cursor-pointer transition-all duration-300 hover:shadow-md flex flex-col items-center justify-center space-y-2"
                  >
                    <div className="w-10 h-10 rounded-full bg-[#FAF9F5] border border-[#E5E5E1] group-hover:bg-[#1A1A1A] group-hover:text-white flex items-center justify-center transition-colors">
                      <Sparkles className="w-4 h-4 text-[#D4A373]" />
                    </div>
                    <p className="font-serif font-semibold text-xs text-[#1A1A1A] group-hover:text-[#C84B31] transition-colors line-clamp-1">
                      {isJa ? cat.nameJa : cat.name}
                    </p>
                    <span className="text-[10px] text-[#8E8D8A] font-mono">{cat.count} items</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Featured Collections Showcase Cards */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-xl mx-auto mb-10">
                <span className="text-xs uppercase font-bold text-[#C84B31] tracking-widest">
                  {isJa ? '特別企画・特集' : 'Featured Collections'}
                </span>
                <h2 className="font-serif text-3xl font-bold text-[#1A1A1A] mt-1">
                  {isJa ? 'ストーリーで巡る日本の手仕事' : 'Curated Stories & Heritage'}
                </h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {MOCK_COLLECTIONS.slice(0, 3).map((col) => (
                  <div
                    key={col.id}
                    onClick={() => {
                      setCollectionFilter(col.id);
                      setActiveTab('catalog');
                    }}
                    className="group relative h-80 rounded-2xl overflow-hidden cursor-pointer shadow-md"
                  >
                    <img
                      src={col.bannerImage}
                      alt={col.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />

                    <div className="absolute bottom-6 left-6 right-6 text-white space-y-2">
                      <span className="bg-[#D4A373] text-white text-[10px] font-bold px-2.5 py-0.5 rounded uppercase tracking-wider">
                        {col.tag}
                      </span>
                      <h3 className="font-serif font-bold text-xl leading-tight">
                        {isJa ? col.nameJa : col.name}
                      </h3>
                      <p className="text-xs text-[#E5E5E1] line-clamp-2 font-light">
                        {isJa ? col.descriptionJa : col.description}
                      </p>
                      <div className="pt-2 flex items-center gap-1 text-xs font-bold text-[#D4A373] group-hover:translate-x-1 transition-transform">
                        <span>{isJa ? 'コレクションを見る' : 'Explore Collection'}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Curated Bestsellers Product Grid */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex items-end justify-between mb-8">
                <div>
                  <span className="text-xs uppercase font-bold text-[#C84B31] tracking-widest block mb-1">
                    {isJa ? '名品・ベストセラー' : 'Masterpiece Bestsellers'}
                  </span>
                  <h2 className="font-serif text-3xl font-bold text-[#1A1A1A]">
                    {isJa ? '長年愛され続ける至高の逸品' : 'Timeless Favorites & Icons'}
                  </h2>
                </div>
                <button
                  onClick={() => setActiveTab('catalog')}
                  className="text-xs font-bold text-[#C84B31] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>{isJa ? 'すべての商品を見る' : 'View Full Catalog'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {products.slice(0, 4).map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    language={language}
                    currency={currency}
                    onSelectProduct={handleSelectProduct}
                    onAddToCart={handleAddToCart}
                    onToggleWishlist={handleToggleWishlist}
                    isWishlisted={wishlist.some((w) => w.id === product.id)}
                  />
                ))}
              </div>
            </section>

            {/* Master Artisan Marketplace Teaser */}
            <ArtisanSection
              artisans={artisans}
              products={products}
              language={language}
              onSelectProduct={handleSelectProduct}
            />

            {/* Store Locator Section */}
            <StoreLocator stores={stores} language={language} />
          </div>
        )}

        {/* VIEW 2: FULL CATALOG VIEW */}
        {activeTab === 'catalog' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
            {/* Catalog Filter Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#E5E5E1] pb-6">
              <div>
                <h1 className="font-serif text-3xl font-bold text-[#1A1A1A]">
                  {isJa ? '全商品カタログ' : 'WaIchiba Craft Catalog'}
                </h1>
                <p className="text-xs text-[#8E8D8A] mt-1">
                  {isJa
                    ? `該当商品: ${displayedProducts.length} 点 (47都道府県の伝統工芸品)`
                    : `Showing ${displayedProducts.length} items directly sourced from Japanese workshops`}
                </p>
              </div>

              {/* Filters Bar */}
              <div className="flex flex-wrap items-center gap-3 text-xs">
                {/* Category Dropdown */}
                <select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="bg-white border border-[#E5E5E1] rounded-lg px-3 py-2 font-medium focus:outline-none"
                >
                  <option value="">{isJa ? '全カテゴリー' : 'All Categories'}</option>
                  {MOCK_CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>
                      {isJa ? c.nameJa : c.name}
                    </option>
                  ))}
                </select>

                {/* Collection Dropdown */}
                <select
                  value={collectionFilter}
                  onChange={(e) => setCollectionFilter(e.target.value)}
                  className="bg-white border border-[#E5E5E1] rounded-lg px-3 py-2 font-medium focus:outline-none"
                >
                  <option value="">{isJa ? '全特集コレクション' : 'All Collections'}</option>
                  {MOCK_COLLECTIONS.map((col) => (
                    <option key={col.id} value={col.id}>
                      {isJa ? col.nameJa : col.name}
                    </option>
                  ))}
                </select>

                {/* Sort Option */}
                <select
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value)}
                  className="bg-white border border-[#E5E5E1] rounded-lg px-3 py-2 font-medium focus:outline-none"
                >
                  <option value="featured">{isJa ? 'おすすめ順' : 'Featured'}</option>
                  <option value="price-low">{isJa ? '価格の安い順' : 'Price: Low to High'}</option>
                  <option value="price-high">{isJa ? '価格の高い順' : 'Price: High to Low'}</option>
                  <option value="rating">{isJa ? '評価の高い順' : 'Highest Rated'}</option>
                </select>

                {/* Clear Filters */}
                {(categoryFilter || collectionFilter || prefectureFilter || searchQuery) && (
                  <button
                    onClick={() => {
                      setCategoryFilter('');
                      setCollectionFilter('');
                      setPrefectureFilter('');
                      setSearchQuery('');
                    }}
                    className="bg-[#C84B31]/10 text-[#C84B31] px-3 py-2 rounded-lg font-bold hover:bg-[#C84B31] hover:text-white transition-colors cursor-pointer"
                  >
                    {isJa ? '条件解除' : 'Clear Filters'}
                  </button>
                )}
              </div>
            </div>

            {/* Catalog Grid */}
            {displayedProducts.length === 0 ? (
              <div className="text-center py-20 space-y-3 bg-[#FFFDF9] rounded-2xl border border-[#E5E5E1]">
                <Filter className="w-10 h-10 text-[#8E8D8A] mx-auto opacity-50" />
                <h3 className="font-serif font-bold text-lg text-[#1A1A1A]">
                  {isJa ? '該当する商品が見つかりませんでした' : 'No products matched your filter criteria'}
                </h3>
                <p className="text-xs text-[#8E8D8A]">
                  {isJa ? '検索条件を変更して再度お試しください。' : 'Try clearing your filters or search for another item.'}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {displayedProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    language={language}
                    currency={currency}
                    onSelectProduct={handleSelectProduct}
                    onAddToCart={handleAddToCart}
                    onToggleWishlist={handleToggleWishlist}
                    isWishlisted={wishlist.some((w) => w.id === product.id)}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* VIEW 3: ARTISAN MARKETPLACE */}
        {activeTab === 'artisan' && (
          <div className="py-6">
            <ArtisanSection
              artisans={artisans}
              products={products}
              language={language}
              onSelectProduct={handleSelectProduct}
            />
          </div>
        )}

        {/* VIEW 4: STORE LOCATOR */}
        {activeTab === 'stores' && <StoreLocator stores={stores} language={language} />}

        {/* VIEW 5: WACLUB LOYALTY */}
        {activeTab === 'loyalty' && <LoyaltyProgram user={user} language={language} />}

        {/* VIEW 6: WISHLIST */}
        {activeTab === 'wishlist' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
            <div className="border-b border-[#E5E5E1] pb-6">
              <h1 className="font-serif text-3xl font-bold text-[#1A1A1A] flex items-center gap-2">
                <Heart className="w-7 h-7 text-[#C84B31] fill-current" />
                <span>{isJa ? 'お気に入り・保存された逸品' : 'Your Saved Wishlist'}</span>
              </h1>
            </div>

            {wishlist.length === 0 ? (
              <div className="text-center py-20 bg-[#FFFDF9] rounded-2xl border border-[#E5E5E1] space-y-3">
                <Heart className="w-12 h-12 text-[#8E8D8A] mx-auto opacity-40" />
                <h3 className="font-serif font-bold text-lg text-[#1A1A1A]">
                  {isJa ? 'お気に入りはまだありません' : 'Your wishlist is empty'}
                </h3>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {wishlist.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    language={language}
                    currency={currency}
                    onSelectProduct={handleSelectProduct}
                    onAddToCart={handleAddToCart}
                    onToggleWishlist={handleToggleWishlist}
                    isWishlisted={true}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* VIEW 7: ADMIN DASHBOARD */}
        {activeTab === 'admin' && (
          <AdminDashboard
            products={products}
            artisans={artisans}
            language={language}
            onUpdateProductStock={handleUpdateStock}
            onAddProduct={handleAddProduct}
          />
        )}
      </main>

      {/* Floating Japanese AI Concierge */}
      <OmotenashiConcierge
        language={language}
        onSelectProduct={handleSelectProduct}
        externalPrompt={aiExternalPrompt}
        onClearExternalPrompt={() => setAiExternalPrompt('')}
      />

      {/* Footer */}
      <Footer language={language} onNavigateTab={setActiveTab} />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        relatedProducts={relatedProducts}
        reviews={productReviews}
        qna={productQna}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
        language={language}
        currency={currency}
        onAddToCart={handleAddToCart}
        onToggleWishlist={handleToggleWishlist}
        isWishlisted={selectedProduct ? wishlist.some((w) => w.id === selectedProduct.id) : false}
        onSelectProduct={handleSelectProduct}
        onAskAI={(prompt) => setAiExternalPrompt(prompt)}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        language={language}
        currency={currency}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveCartItem}
        onProceedToCheckout={(wrap, coupon) => {
          setCheckoutGiftWrap(wrap);
          setCheckoutCoupon(coupon);
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      {/* Checkout Modal with Japanese Tax Invoice */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cartItems}
        giftWrapped={checkoutGiftWrap}
        couponCode={checkoutCoupon}
        language={language}
        onOrderCompleted={handleOrderCompleted}
      />

      {/* User Account Modal */}
      <UserAccountModal
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
        user={user}
        language={language}
      />
    </div>
  );
}
