export type Language = 'ja' | 'en';

export interface Product {
  id: string;
  name: string;
  nameJa: string;
  category: string;
  categoryJa: string;
  collectionId: string;
  priceJpy: number;
  rating: number;
  reviewCount: number;
  image: string;
  gallery: string[];
  isNew?: boolean;
  isBestseller?: boolean;
  isArtisan?: boolean;
  artisanId?: string;
  artisanName?: string;
  artisanNameJa?: string;
  prefecture: string;
  prefectureJa: string;
  description: string;
  descriptionJa: string;
  specifications: Record<string, string>;
  materials: string[];
  materialsJa: string[];
  origin: string;
  originJa: string;
  manufacturer: string;
  inStock: boolean;
  stockCount: number;
  shippingInfo: string;
  shippingInfoJa: string;
  options?: {
    colors?: { name: string; nameJa: string; hex: string }[];
    sizes?: string[];
    variants?: string[];
  };
}

export interface Category {
  id: string;
  name: string;
  nameJa: string;
  icon: string;
  count: number;
  description: string;
  descriptionJa: string;
  bannerImage: string;
}

export interface Collection {
  id: string;
  name: string;
  nameJa: string;
  subtitle: string;
  subtitleJa: string;
  description: string;
  descriptionJa: string;
  bannerImage: string;
  tag: string;
}

export interface Artisan {
  id: string;
  name: string;
  nameJa: string;
  craft: string;
  craftJa: string;
  prefecture: string;
  prefectureJa: string;
  yearsOfExperience: number;
  bio: string;
  bioJa: string;
  avatar: string;
  workshopImage: string;
  philosophy: string;
  philosophyJa: string;
  featuredProducts: string[]; // product IDs
}

export interface StoreLocation {
  id: string;
  city: string;
  cityJa: string;
  name: string;
  nameJa: string;
  address: string;
  addressJa: string;
  hours: string;
  hoursJa: string;
  phone: string;
  image: string;
  coordinates: { lat: number; lng: number };
  accessibility: string;
  accessibilityJa: string;
  events: {
    title: string;
    titleJa: string;
    date: string;
    description: string;
    descriptionJa: string;
  }[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
  selectedVariant?: string;
}

export interface WishlistItem {
  product: Product;
  addedAt: string;
}

export interface Order {
  id: string;
  date: string;
  status: 'Processing' | 'Shipped' | 'Delivered' | 'Returned';
  items: CartItem[];
  subtotalJpy: number;
  taxJpy: number;
  shippingJpy: number;
  discountJpy: number;
  totalJpy: number;
  giftWrapped: boolean;
  paymentMethod: string;
  trackingNumber: string;
  shippingAddress: {
    fullName: string;
    postalCode: string;
    prefecture: string;
    cityAddress: string;
    phone: string;
  };
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  membershipTier: 'Standard' | 'Kyoto' | 'Edo' | 'Imperial';
  points: number;
  savedAddresses: {
    id: string;
    fullName: string;
    postalCode: string;
    prefecture: string;
    cityAddress: string;
    phone: string;
    isDefault: boolean;
  }[];
  orders: Order[];
  giftCards: {
    code: string;
    balanceJpy: number;
    expiresAt: string;
  }[];
}

export interface Review {
  id: string;
  productId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  commentJa?: string;
  date: string;
  verifiedPurchase: boolean;
  helpfulCount: number;
}

export interface ProductQnA {
  id: string;
  productId: string;
  question: string;
  questionJa?: string;
  answer: string;
  answerJa?: string;
  date: string;
  askedBy: string;
}
