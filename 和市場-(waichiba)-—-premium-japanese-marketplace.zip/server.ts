import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import {
  MOCK_PRODUCTS,
  MOCK_CATEGORIES,
  MOCK_COLLECTIONS,
  MOCK_ARTISANS,
  MOCK_STORES,
  MOCK_REVIEWS,
  MOCK_QNA,
  MOCK_USER
} from './src/data/mockData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Lazy initialization of Gemini API
  const getAI = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return null;
    return new GoogleGenAI({ apiKey });
  };

  // --- API ROUTES ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', app: 'WaIchiba 和市場' });
  });

  // Get categories
  app.get('/api/categories', (req, res) => {
    res.json(MOCK_CATEGORIES);
  });

  // Get collections
  app.get('/api/collections', (req, res) => {
    res.json(MOCK_COLLECTIONS);
  });

  // Get products with query filters
  app.get('/api/products', (req, res) => {
    let {
      category,
      collection,
      artisanId,
      prefecture,
      q,
      minPrice,
      maxPrice,
      sort,
      isArtisan,
      isBestseller,
      isNew
    } = req.query;

    let filtered = [...MOCK_PRODUCTS];

    if (category) {
      filtered = filtered.filter(p => p.category === category);
    }
    if (collection) {
      filtered = filtered.filter(p => p.collectionId === collection);
    }
    if (artisanId) {
      filtered = filtered.filter(p => p.artisanId === artisanId);
    }
    if (prefecture) {
      filtered = filtered.filter(p =>
        p.prefecture.toLowerCase().includes(String(prefecture).toLowerCase()) ||
        p.prefectureJa.includes(String(prefecture))
      );
    }
    if (isArtisan === 'true') {
      filtered = filtered.filter(p => p.isArtisan);
    }
    if (isBestseller === 'true') {
      filtered = filtered.filter(p => p.isBestseller);
    }
    if (isNew === 'true') {
      filtered = filtered.filter(p => p.isNew);
    }
    if (minPrice) {
      filtered = filtered.filter(p => p.priceJpy >= Number(minPrice));
    }
    if (maxPrice) {
      filtered = filtered.filter(p => p.priceJpy <= Number(maxPrice));
    }
    if (q) {
      const queryStr = String(q).toLowerCase();
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(queryStr) ||
        p.nameJa.includes(queryStr) ||
        p.description.toLowerCase().includes(queryStr) ||
        p.descriptionJa.includes(queryStr) ||
        p.origin.toLowerCase().includes(queryStr) ||
        p.originJa.includes(queryStr) ||
        (p.artisanName && p.artisanName.toLowerCase().includes(queryStr)) ||
        (p.artisanNameJa && p.artisanNameJa.includes(queryStr))
      );
    }

    // Sorting
    if (sort === 'price-asc') {
      filtered.sort((a, b) => a.priceJpy - b.priceJpy);
    } else if (sort === 'price-desc') {
      filtered.sort((a, b) => b.priceJpy - a.priceJpy);
    } else if (sort === 'rating') {
      filtered.sort((a, b) => b.rating - a.rating);
    } else if (sort === 'newest') {
      filtered.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    }

    res.json(filtered);
  });

  // Product details
  app.get('/api/products/:id', (req, res) => {
    const product = MOCK_PRODUCTS.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const related = MOCK_PRODUCTS.filter(
      p => p.id !== product.id && (p.category === product.category || p.collectionId === product.collectionId)
    ).slice(0, 4);

    const reviews = MOCK_REVIEWS.filter(r => r.productId === product.id);
    const qna = MOCK_QNA.filter(q => q.productId === product.id);

    res.json({
      product,
      related,
      reviews,
      qna
    });
  });

  // Artisans
  app.get('/api/artisans', (req, res) => {
    res.json(MOCK_ARTISANS);
  });

  app.get('/api/artisans/:id', (req, res) => {
    const artisan = MOCK_ARTISANS.find(a => a.id === req.params.id);
    if (!artisan) return res.status(404).json({ error: 'Artisan not found' });
    const products = MOCK_PRODUCTS.filter(p => p.artisanId === artisan.id);
    res.json({ artisan, products });
  });

  // Store locations
  app.get('/api/stores', (req, res) => {
    res.json(MOCK_STORES);
  });

  // Autocomplete and predictive search suggestions
  app.post('/api/search/suggestions', (req, res) => {
    const { query } = req.body;
    if (!query || typeof query !== 'string') {
      return res.json({ suggestions: [], products: [] });
    }
    const qLower = query.toLowerCase();
    const matchingProducts = MOCK_PRODUCTS.filter(p =>
      p.name.toLowerCase().includes(qLower) || p.nameJa.includes(qLower)
    ).slice(0, 5);

    const suggestionsSet = new Set<string>();
    MOCK_CATEGORIES.forEach(c => {
      if (c.name.toLowerCase().includes(qLower) || c.nameJa.includes(qLower)) {
        suggestionsSet.add(c.nameJa + ' (' + c.name + ')');
      }
    });
    MOCK_COLLECTIONS.forEach(col => {
      if (col.name.toLowerCase().includes(qLower) || col.nameJa.includes(qLower)) {
        suggestionsSet.add(col.nameJa);
      }
    });
    MOCK_ARTISANS.forEach(a => {
      if (a.name.toLowerCase().includes(qLower) || a.nameJa.includes(qLower)) {
        suggestionsSet.add('職人: ' + a.nameJa);
      }
    });

    res.json({
      suggestions: Array.from(suggestionsSet),
      products: matchingProducts
    });
  });

  // Order Placement
  app.post('/api/orders', (req, res) => {
    const { items, shippingAddress, giftWrapped, paymentMethod, couponCode } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Cart is empty' });
    }

    let subtotal = 0;
    items.forEach((item: any) => {
      subtotal += item.product.priceJpy * item.quantity;
    });

    let discount = 0;
    if (couponCode === 'WAICHIBAVIP') {
      discount = Math.floor(subtotal * 0.15); // 15% VIP discount
    } else if (couponCode === 'OMOTENASHI') {
      discount = 2000;
    }

    const giftWrapFee = giftWrapped ? 500 : 0;
    const taxableSubtotal = Math.max(0, subtotal - discount + giftWrapFee);
    const tax = Math.floor(taxableSubtotal * 0.10); // Japanese 10% consumption tax
    const shipping = subtotal >= 30000 ? 0 : 800; // Free shipping over ¥30,000
    const total = taxableSubtotal + tax + shipping;

    const pointsEarned = Math.floor(total * 0.05); // 5% points for WaClub members

    const newOrder = {
      id: `WA-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString().split('T')[0],
      status: 'Processing' as const,
      items,
      subtotalJpy: subtotal,
      taxJpy: tax,
      shippingJpy: shipping,
      discountJpy: discount,
      totalJpy: total,
      giftWrapped: !!giftWrapped,
      paymentMethod: paymentMethod || 'Credit Card',
      trackingNumber: `JP-${Math.floor(1000000000 + Math.random() * 9000000000)}-S`,
      shippingAddress: shippingAddress || MOCK_USER.savedAddresses[0],
      pointsEarned,
      receiptNumber: `REC-${Date.now().toString().slice(-8)}`,
      issuer: '和市場 (WaIchiba) 株式会社 / WaIchiba Japan Inc.',
      registrationNumber: 'T1234567890123' // Registered Japanese Tax Invoice ID format
    };

    res.json(newOrder);
  });

  // AI Concierge Endpoint using @google/genai (Gemini 3.6 Flash)
  app.post('/api/ai/concierge', async (req, res) => {
    const { prompt, language = 'ja', userPreferences } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getAI();
    if (!ai) {
      return res.json({
        response: language === 'ja'
          ? '和市場の「おもてなし AI コンシェルジュ」へようこそ。どのような逸品をお探しでしょうか？茶道具、越前包丁、和紙、または季節のギフトについてお気軽にお尋ねください。'
          : 'Welcome to WaIchiba’s Omotenashi AI Concierge. How may I assist your journey through Japanese craftsmanship today? Feel free to ask about tea ceremony sets, Echizen kitchen blades, Washi paper, or bespoke gift suggestions.',
        recommendedProducts: MOCK_PRODUCTS.slice(0, 3)
      });
    }

    try {
      const catalogContext = MOCK_PRODUCTS.map(p =>
        `- ID: ${p.id} | ${p.nameJa} (${p.name}) | Price: ¥${p.priceJpy.toLocaleString()} | Category: ${p.categoryJa} | Prefecture: ${p.prefectureJa} | Artisan: ${p.artisanNameJa || 'N/A'} | Desc: ${p.descriptionJa}`
      ).join('\n');

      const systemInstruction = `
You are the master concierge of "和市場" (WaIchiba), a ultra-luxurious Japanese marketplace celebrating authentic craftsmanship, quiet luxury, Muji/Apple/Kyoto aesthetic, and Omotenashi hospitality.

Catalog Context:
${catalogContext}

Instructions:
1. Answer the customer's question with warm, gracious, polite Japanese hospitality (Omotenashi style).
2. If language is 'ja', answer in natural, elegant Japanese with respectful keigo (丁寧語/敬語).
3. If language is 'en', answer in polite, clear, refined English explaining the cultural heritage of Japanese crafts.
4. Recommend 1 to 3 specific products from the catalog context if relevant, citing their exact ID in your response text like [RECOMMEND:prod-id].
5. Keep the response under 180 words, elegant and inspiring.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      const text = response.text || '';

      // Extract recommended product IDs
      const matches = text.match(/\[RECOMMEND:([a-zA-Z0-9-]+)\]/g) || [];
      const recommendedIds = matches.map(m => m.replace('[RECOMMEND:', '').replace(']', ''));
      const recommendedProducts = MOCK_PRODUCTS.filter(p => recommendedIds.includes(p.id));

      // Clean up text tags
      const cleanText = text.replace(/\[RECOMMEND:[a-zA-Z0-9-]+\]/g, '').trim();

      res.json({
        response: cleanText,
        recommendedProducts: recommendedProducts.length > 0 ? recommendedProducts : MOCK_PRODUCTS.slice(0, 2)
      });
    } catch (err: any) {
      console.error('Gemini API Error:', err);
      res.json({
        response: language === 'ja'
          ? '申し訳ございません。一時的にAI応答に不具合が生じておりますが、日本の素晴らしい職人技を自信を持ってお届けいたします。'
          : 'Forgive us, our AI Concierge service is temporarily taking a brief pause. Please explore our curated collections above.',
        recommendedProducts: MOCK_PRODUCTS.slice(0, 2)
      });
    }
  });

  // --- VITE / STATIC SERVING ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`WaIchiba 和市場 Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
