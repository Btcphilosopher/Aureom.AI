'use client';

import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { InventoryItem, AuditLog, UserProfile, StockStatus } from '@/types/inventory';
import { WALMART_ITEMS, WALMART_USERS } from '@/lib/mockData';
import { soundFX } from '@/lib/audio';
import { 
  db, 
  auth, 
  googleProvider, 
  handleFirestoreError, 
  OperationType,
  testFirestoreConnection
} from '@/lib/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  limit,
  writeBatch
} from 'firebase/firestore';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';

interface InventoryContextType {
  items: InventoryItem[];
  auditLogs: AuditLog[];
  currentUser: UserProfile;
  firebaseUser: User | null;
  isOnline: boolean;
  isFirestoreSyncing: boolean;
  lastSyncTime: Date;
  // Item CRUD
  addItem: (item: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt' | 'status'>) => Promise<InventoryItem>;
  updateItem: (id: string, updates: Partial<InventoryItem>) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
  adjustStock: (id: string, changeQty: number, reason: string) => Promise<boolean>;
  // Lookups
  findItemByBarcode: (barcodeOrSku: string) => InventoryItem | undefined;
  // User Management
  setCurrentUser: (user: UserProfile) => void;
  availableUsers: UserProfile[];
  signInWithGoogle: () => Promise<void>;
  signOutFirebase: () => Promise<void>;
  // Utilities
  resetToDefault: () => Promise<void>;
  exportCsv: () => void;
  exportJson: () => void;
  importJson: (jsonData: string) => Promise<boolean>;
}

const InventoryContext = createContext<InventoryContextType | null>(null);

const STORAGE_KEY_ITEMS = 'walmart_inventory_items_v3';
const STORAGE_KEY_LOGS = 'walmart_inventory_logs_v3';
const STORAGE_KEY_USER = 'walmart_active_user_v3';

export function InventoryProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile>(WALMART_USERS[0]);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [isFirestoreSyncing, setIsFirestoreSyncing] = useState<boolean>(true);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  
  const hasSeededRef = useRef(false);

  // Status helper
  const computeStatus = (qty: number, minThreshold: number): StockStatus => {
    if (qty <= 0) return 'out_of_stock';
    if (qty <= minThreshold) return 'low_stock';
    return 'in_stock';
  };

  // Google Sign-In via Firebase Auth
  const signInWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        setFirebaseUser(result.user);
        const mappedUser: UserProfile = {
          id: result.user.uid,
          name: result.user.displayName || 'Walmart Associate',
          email: result.user.email || 'associate@walmart.com',
          role: 'inventory_manager',
          avatar: result.user.photoURL || WALMART_USERS[0].avatar,
          department: 'Supercenter Operations',
          storeNumber: 'Store #1001 (Bentonville, AR)',
        };
        setCurrentUser(mappedUser);
        localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(mappedUser));
        soundFX.playScanSuccess();
      }
    } catch (error) {
      console.warn('Google sign-in popup error/cancelled:', error);
    }
  };

  const signOutFirebase = async () => {
    try {
      await signOut(auth);
      setFirebaseUser(null);
      setCurrentUser(WALMART_USERS[0]);
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(WALMART_USERS[0]));
    } catch (e) {
      console.warn('Sign-out error:', e);
    }
  };

  // Auth state listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      if (user) {
        const mappedUser: UserProfile = {
          id: user.uid,
          name: user.displayName || 'Walmart Associate',
          email: user.email || 'associate@walmart.com',
          role: 'inventory_manager',
          avatar: user.photoURL || WALMART_USERS[0].avatar,
          department: 'Supercenter Operations',
          storeNumber: 'Store #1001 (Bentonville, AR)',
        };
        setCurrentUser(mappedUser);
      }
    });
    return () => unsubscribe();
  }, []);

  // Seed Firestore if empty
  const seedFirestoreIfEmpty = useCallback(async (currentCount: number) => {
    if (currentCount > 0 || hasSeededRef.current) return;
    hasSeededRef.current = true;
    try {
      const batch = writeBatch(db);
      for (const item of WALMART_ITEMS) {
        const itemRef = doc(db, 'inventory', item.id);
        batch.set(itemRef, item);
      }
      await batch.commit();
      console.log('Seeded Walmart initial catalog into Firestore');
    } catch (err) {
      console.warn('Seeding skipped or fallback:', err);
    }
  }, []);

  // Listen to Firestore real-time snapshots
  useEffect(() => {
    // 1. Inventory Collection Listener
    const invCol = collection(db, 'inventory');
    const unsubInventory = onSnapshot(
      invCol,
      (snapshot) => {
        if (!snapshot.empty) {
          const loaded: InventoryItem[] = [];
          snapshot.forEach((docSnap) => {
            loaded.push(docSnap.data() as InventoryItem);
          });
          setItems(loaded);
          setIsFirestoreSyncing(false);
          setLastSyncTime(new Date());
          try {
            localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(loaded));
          } catch {
            // ignore
          }
        } else {
          // If Firestore is empty, seed it
          seedFirestoreIfEmpty(0);
          // Load default items in the meantime
          setItems(WALMART_ITEMS);
          setIsFirestoreSyncing(false);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'inventory');
        setIsFirestoreSyncing(false);
        // Fallback to local storage if network blocked
        const local = localStorage.getItem(STORAGE_KEY_ITEMS);
        if (local) {
          setItems(JSON.parse(local));
        } else {
          setItems(WALMART_ITEMS);
        }
      }
    );

    // 2. Audit Logs Listener
    const logsCol = collection(db, 'audit_logs');
    const logsQuery = query(logsCol, orderBy('timestamp', 'desc'), limit(100));
    const unsubLogs = onSnapshot(
      logsQuery,
      (snapshot) => {
        const loaded: AuditLog[] = [];
        snapshot.forEach((docSnap) => {
          loaded.push(docSnap.data() as AuditLog);
        });
        if (loaded.length > 0) {
          setAuditLogs(loaded);
        } else {
          // Initial demo logs
          const initLogs: AuditLog[] = [
            {
              id: 'log_wm_01',
              itemId: 'wm_001',
              itemName: 'Great Value Whole Milk (1 Gallon)',
              sku: 'WIN-55102001',
              barcode: '078742351890',
              action: 'stock_in',
              quantityChanged: 60,
              previousQty: 124,
              newQty: 184,
              userId: WALMART_USERS[2].id,
              userName: WALMART_USERS[2].name,
              userRole: WALMART_USERS[2].role,
              reason: 'DC Delivery Truck #TR-8812 Received at Bay 04',
              timestamp: new Date(Date.now() - 3600000 * 1.5).toISOString(),
            },
            {
              id: 'log_wm_02',
              itemId: 'wm_007',
              itemName: 'onn. Wireless ANC Headphones',
              sku: 'WIN-57849921',
              barcode: '681131310949',
              action: 'stock_out',
              quantityChanged: -15,
              previousQty: 15,
              newQty: 0,
              userId: WALMART_USERS[1].id,
              userName: WALMART_USERS[1].name,
              userRole: WALMART_USERS[1].role,
              reason: 'Customer Rollback Weekend Clearance Sales',
              timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
            },
          ];
          setAuditLogs(initLogs);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'audit_logs');
      }
    );

    // Online/Offline tracking
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial check
    testFirestoreConnection();

    return () => {
      unsubInventory();
      unsubLogs();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [seedFirestoreIfEmpty]);

  // Handle Switch active user
  const handleSetCurrentUser = (user: UserProfile) => {
    setCurrentUser(user);
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
    }
  };

  // Add Item to Firestore
  const addItem = async (
    itemData: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt' | 'status'>
  ): Promise<InventoryItem> => {
    const now = new Date().toISOString();
    const id = `wm_${Date.now()}`;
    const newItem: InventoryItem = {
      ...itemData,
      id,
      status: computeStatus(itemData.quantity, itemData.minStockThreshold),
      createdAt: now,
      updatedAt: now,
    };

    // Optimistic UI update
    setItems((prev) => [newItem, ...prev.filter((i) => i.id !== id)]);

    const log: AuditLog = {
      id: `log_${Date.now()}`,
      itemId: newItem.id,
      itemName: newItem.name,
      sku: newItem.sku,
      barcode: newItem.barcode,
      action: 'created',
      quantityChanged: newItem.quantity,
      previousQty: 0,
      newQty: newItem.quantity,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      reason: 'New Walmart Modular Asset WIN Registered',
      timestamp: now,
    };
    setAuditLogs((prev) => [log, ...prev]);

    // Firestore Sync
    try {
      await setDoc(doc(db, 'inventory', id), newItem);
      await setDoc(doc(db, 'audit_logs', log.id), log);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `inventory/${id}`);
    }

    soundFX.playStockUpdate();
    return newItem;
  };

  // Update Item in Firestore
  const updateItem = async (id: string, updates: Partial<InventoryItem>) => {
    const now = new Date().toISOString();
    const existing = items.find((i) => i.id === id);
    if (!existing) return;

    const newQty = updates.quantity !== undefined ? updates.quantity : existing.quantity;
    const newMin = updates.minStockThreshold !== undefined ? updates.minStockThreshold : existing.minStockThreshold;

    const updatedItem: InventoryItem = {
      ...existing,
      ...updates,
      status: computeStatus(newQty, newMin),
      updatedAt: now,
    };

    // Optimistic update
    setItems((prev) => prev.map((i) => (i.id === id ? updatedItem : i)));

    const diff = updates.quantity !== undefined ? updates.quantity - existing.quantity : 0;
    const log: AuditLog = {
      id: `log_${Date.now()}`,
      itemId: id,
      itemName: updatedItem.name,
      sku: updatedItem.sku,
      barcode: updatedItem.barcode,
      action: diff > 0 ? 'stock_in' : diff < 0 ? 'stock_out' : 'updated',
      quantityChanged: diff,
      previousQty: existing.quantity,
      newQty,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      reason: diff !== 0 ? 'Modular Stock Quantity Adjusted' : 'Walmart Asset Specs Updated',
      timestamp: now,
    };
    setAuditLogs((prev) => [log, ...prev]);

    // Firestore Sync
    try {
      await setDoc(doc(db, 'inventory', id), updatedItem);
      await setDoc(doc(db, 'audit_logs', log.id), log);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `inventory/${id}`);
    }

    soundFX.playStockUpdate();
  };

  // Delete Item from Firestore
  const deleteItem = async (id: string) => {
    const target = items.find((i) => i.id === id);
    if (!target) return;

    // Optimistic
    setItems((prev) => prev.filter((i) => i.id !== id));

    const log: AuditLog = {
      id: `log_${Date.now()}`,
      itemId: target.id,
      itemName: target.name,
      sku: target.sku,
      barcode: target.barcode,
      action: 'deleted',
      quantityChanged: -target.quantity,
      previousQty: target.quantity,
      newQty: 0,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      reason: 'Asset Delisted / Written off Claims',
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [log, ...prev]);

    // Firestore
    try {
      await deleteDoc(doc(db, 'inventory', id));
      await setDoc(doc(db, 'audit_logs', log.id), log);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `inventory/${id}`);
    }
  };

  // Adjust stock count (+ or - count)
  const adjustStock = async (id: string, changeQty: number, reason: string): Promise<boolean> => {
    const target = items.find((i) => i.id === id);
    if (!target) return false;

    const previousQty = target.quantity;
    const newQty = Math.max(0, previousQty + changeQty);
    const now = new Date().toISOString();

    const updated: InventoryItem = {
      ...target,
      quantity: newQty,
      status: computeStatus(newQty, target.minStockThreshold),
      updatedAt: now,
    };

    // Optimistic
    setItems((prev) => prev.map((i) => (i.id === id ? updated : i)));

    const log: AuditLog = {
      id: `log_${Date.now()}`,
      itemId: target.id,
      itemName: target.name,
      sku: target.sku,
      barcode: target.barcode,
      action: changeQty > 0 ? 'stock_in' : changeQty < 0 ? 'stock_out' : 'adjust',
      quantityChanged: changeQty,
      previousQty,
      newQty,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      reason: reason || (changeQty > 0 ? 'Store Topstock Replenishment' : 'POS Checkout Deduction'),
      timestamp: now,
    };
    setAuditLogs((prev) => [log, ...prev]);

    // Firestore
    try {
      await setDoc(doc(db, 'inventory', id), updated);
      await setDoc(doc(db, 'audit_logs', log.id), log);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `inventory/${id}`);
    }

    soundFX.playStockUpdate();
    return true;
  };

  // Barcode / SKU lookup
  const findItemByBarcode = (query: string): InventoryItem | undefined => {
    if (!query) return undefined;
    const clean = query.trim().toLowerCase();
    return items.find(
      (item) =>
        item.barcode.toLowerCase() === clean ||
        item.sku.toLowerCase() === clean ||
        item.id.toLowerCase() === clean
    );
  };

  // Reset to Walmart default catalog
  const resetToDefault = async () => {
    try {
      const batch = writeBatch(db);
      for (const item of WALMART_ITEMS) {
        const itemRef = doc(db, 'inventory', item.id);
        batch.set(itemRef, item);
      }
      await batch.commit();
      setItems(WALMART_ITEMS);
      soundFX.playScanSuccess();
    } catch (err) {
      console.warn('Reset to default fallback:', err);
      setItems(WALMART_ITEMS);
    }
  };

  // Export CSV
  const exportCsv = () => {
    if (!items.length) return;
    const headers = [
      'WIN_SKU',
      'UPC_Barcode',
      'Item_Name',
      'Brand',
      'Department',
      'Category',
      'Quantity',
      'Min_Threshold',
      'Cost_Price',
      'Selling_Price',
      'Rollback',
      'Unit_Price',
      'Modular_Location',
      'Status',
    ];
    const rows = items.map((i) => [
      i.sku,
      i.barcode,
      `"${i.name.replace(/"/g, '""')}"`,
      i.brand || '',
      i.departmentNumber || '',
      i.category,
      i.quantity,
      i.minStockThreshold,
      i.costPrice,
      i.sellingPrice,
      i.isRollback ? 'YES' : 'NO',
      `"${i.unitPriceDescription || ''}"`,
      `"${i.location}"`,
      i.status,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `Walmart_Store1001_Inventory_${new Date().toISOString().split('T')[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export JSON
  const exportJson = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(items, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `Walmart_Store1001_Dump_${new Date().toISOString().split('T')[0]}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Import JSON
  const importJson = async (jsonString: string): Promise<boolean> => {
    try {
      const parsed = JSON.parse(jsonString);
      if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].sku && parsed[0].name) {
        setItems(parsed);
        const batch = writeBatch(db);
        for (const item of parsed) {
          const itemRef = doc(db, 'inventory', item.id || `wm_${Date.now()}`);
          batch.set(itemRef, item);
        }
        await batch.commit();
        soundFX.playScanSuccess();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  return (
    <InventoryContext.Provider
      value={{
        items,
        auditLogs,
        currentUser,
        firebaseUser,
        isOnline,
        isFirestoreSyncing,
        lastSyncTime,
        addItem,
        updateItem,
        deleteItem,
        adjustStock,
        findItemByBarcode,
        setCurrentUser: handleSetCurrentUser,
        availableUsers: WALMART_USERS,
        signInWithGoogle,
        signOutFirebase,
        resetToDefault,
        exportCsv,
        exportJson,
        importJson,
      }}
    >
      {children}
    </InventoryContext.Provider>
  );
}

export function useInventory() {
  const context = useContext(InventoryContext);
  if (!context) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
}
