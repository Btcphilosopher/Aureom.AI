import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Walmart Inventory & Asset Control | Store #1001',
  description: 'Walmart Supercenter real-time inventory management dashboard with live Firebase Firestore sync, barcode & UPC scanner, modular asset tracking, and audit logging.',
  openGraph: {
    title: 'Walmart Inventory & Asset Control | Store #1001',
    description: 'Walmart Supercenter real-time inventory management dashboard with live Firebase Firestore sync, barcode & UPC scanner, modular asset tracking, and audit logging.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Walmart Inventory & Asset Control | Store #1001',
    description: 'Walmart Supercenter real-time inventory management dashboard with live Firebase Firestore sync, barcode & UPC scanner, modular asset tracking, and audit logging.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
