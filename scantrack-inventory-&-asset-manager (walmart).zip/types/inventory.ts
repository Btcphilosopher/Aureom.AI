export type StockStatus = 'in_stock' | 'low_stock' | 'out_of_stock' | 'reserved';

export interface InventoryItem {
  id: string;
  name: string;
  sku: string; // WIN (Walmart Item Number)
  barcode: string; // 12-digit standard UPC
  departmentNumber: string; // e.g. "Dept 95 - Grocery", "Dept 72 - Electronics"
  category: string;
  brand: string; // e.g. "Great Value", "onn.", "Mainstays", "Equate", "Hyper Tough"
  quantity: number;
  minStockThreshold: number;
  costPrice: number;
  sellingPrice: number;
  isRollback?: boolean;
  unitPriceDescription?: string; // e.g. "$0.14/oz" for shelf tag
  location: string; // e.g. "Aisle G12-04 • Mod 02"
  status: StockStatus;
  batchNumber: string;
  expiryDate?: string;
  imageUrl?: string;
  supplier?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type AuditAction = 
  | 'stock_in' 
  | 'stock_out' 
  | 'adjust' 
  | 'created' 
  | 'updated' 
  | 'deleted' 
  | 'scanned'
  | 'rollback_applied';

export interface AuditLog {
  id: string;
  itemId: string;
  itemName: string;
  sku: string;
  barcode: string;
  action: AuditAction;
  quantityChanged: number;
  previousQty: number;
  newQty: number;
  userId: string;
  userName: string;
  userRole: string;
  reason: string;
  timestamp: string;
}

export type UserRole = 'admin' | 'inventory_manager' | 'warehouse_scanner' | 'auditor';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  department: string;
  storeNumber: string;
}

export type ScanAction = 'view' | 'stock_in_one' | 'stock_out_one' | 'custom_adjust';
