'use client';

import React from 'react';
import { InventoryItem } from '@/types/inventory';
import { useInventory } from '@/context/InventoryContext';
import { BarcodeGenerator } from './BarcodeGenerator';
import { WalmartSparkLogo } from './WalmartSparkLogo';
import { 
  X, 
  MapPin, 
  Tag, 
  Layers, 
  Clock, 
  Printer, 
  Edit3, 
  ArrowRightLeft, 
  History,
  Truck
} from 'lucide-react';

interface AssetDetailModalProps {
  item: InventoryItem | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (item: InventoryItem) => void;
  onMovement: (item: InventoryItem) => void;
  onPrintTag: (item: InventoryItem) => void;
}

export function AssetDetailModal({
  item,
  isOpen,
  onClose,
  onEdit,
  onMovement,
  onPrintTag,
}: AssetDetailModalProps) {
  const { auditLogs } = useInventory();

  if (!isOpen || !item) return null;

  const itemLogs = auditLogs.filter((l) => l.itemId === item.id).slice(0, 5);
  const profitMargin =
    item.sellingPrice > 0
      ? (((item.sellingPrice - item.costPrice) / item.sellingPrice) * 100).toFixed(1)
      : '0.0';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-blue-600 bg-[#0071DC] text-white">
          <div className="flex items-center gap-3">
            <WalmartSparkLogo size={22} />
            <span className="px-2.5 py-0.5 rounded text-[11px] font-black uppercase tracking-wider bg-white/20 text-white">
              {item.departmentNumber || 'Dept 95'}
            </span>
            <span className="text-xs font-mono text-blue-100 font-bold">WIN: {item.sku}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-blue-200 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Top section: Photo + Barcode + Primary specs */}
          <div className="flex flex-col sm:flex-row gap-5 items-start">
            <div className="w-full sm:w-48 h-48 rounded-xl bg-neutral-100 border border-neutral-200 overflow-hidden shrink-0 flex items-center justify-center relative">
              {item.imageUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
              ) : (
                <Layers className="w-10 h-10 text-neutral-400" />
              )}
              {item.isRollback && (
                <div className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-black uppercase px-2 py-0.5 rounded shadow-sm">
                  Rollback
                </div>
              )}
            </div>

            <div className="flex-1 space-y-3 w-full">
              <div>
                <h3 className="font-black text-neutral-900 text-lg leading-snug">
                  {item.name}
                </h3>
                <p className="text-xs text-neutral-500 mt-1 flex items-center gap-1.5 font-medium">
                  <MapPin className="w-3.5 h-3.5 text-[#0071DC]" />
                  Modular Location: <strong className="text-neutral-900">{item.location}</strong>
                </p>
              </div>

              {/* Barcode Widget */}
              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 flex flex-col items-center">
                <BarcodeGenerator
                  value={item.barcode}
                  width={220}
                  height={48}
                  showText={true}
                  className="bg-transparent border-none shadow-none p-0"
                />
              </div>

              {/* Stock KPI Pills */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
                  <span className="text-[#0071DC] font-extrabold block text-[11px]">
                    Available Floor Stock
                  </span>
                  <p className="text-xl font-black text-neutral-900 mt-0.5">
                    {item.quantity}{' '}
                    <span className="text-xs font-normal text-neutral-600">units</span>
                  </p>
                  <span className="text-[10px] text-blue-700 font-semibold">
                    Shelf capacity: {item.minStockThreshold}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-neutral-50 border border-neutral-200">
                  <span className="text-neutral-500 font-bold block text-[11px]">
                    Everyday Low Price
                  </span>
                  <p className="text-xl font-black text-neutral-900 mt-0.5">
                    ${item.sellingPrice.toFixed(2)}
                  </p>
                  <span className="text-[10px] text-emerald-600 font-bold">
                    Margin: {profitMargin}% (Cost: ${item.costPrice.toFixed(2)})
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Asset Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-neutral-50 rounded-xl border border-neutral-200">
            <div>
              <span className="text-neutral-400 block text-[10px] uppercase font-bold">Brand</span>
              <p className="font-extrabold text-neutral-900 mt-0.5">{item.brand || 'Walmart Brand'}</p>
            </div>
            <div>
              <span className="text-neutral-400 block text-[10px] uppercase font-bold">Unit Price</span>
              <p className="font-bold text-neutral-800 mt-0.5">{item.unitPriceDescription || 'N/A'}</p>
            </div>
            <div>
              <span className="text-neutral-400 block text-[10px] uppercase font-bold">Distribution Center</span>
              <p className="font-semibold text-neutral-800 mt-0.5 truncate">{item.supplier || 'Walmart DC'}</p>
            </div>
            <div>
              <span className="text-neutral-400 block text-[10px] uppercase font-bold">
                Total Modular Value
              </span>
              <p className="font-black text-[#0071DC] mt-0.5">
                ${(item.quantity * item.sellingPrice).toFixed(2)}
              </p>
            </div>
          </div>

          {/* Notes */}
          {item.notes && (
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900">
              <span className="font-bold block text-[11px] mb-0.5">Associate Handling Notes:</span>
              <p className="text-xs leading-relaxed">{item.notes}</p>
            </div>
          )}

          {/* Movement History */}
          <div>
            <h4 className="font-extrabold text-neutral-800 text-sm mb-2 flex items-center gap-1.5">
              <History className="w-4 h-4 text-[#0071DC]" />
              Store Movement & Audit History (Live Firestore)
            </h4>
            {itemLogs.length === 0 ? (
              <p className="text-neutral-400 italic py-2">No transaction history recorded yet.</p>
            ) : (
              <div className="divide-y divide-neutral-100 rounded-lg border border-neutral-200 overflow-hidden">
                {itemLogs.map((log) => (
                  <div key={log.id} className="p-2.5 bg-white flex items-center justify-between text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold capitalize text-neutral-900">
                          {log.action.replace('_', ' ')}
                        </span>
                        <span className="font-mono text-[11px] text-neutral-500">
                          {log.previousQty} → {log.newQty}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-500 mt-0.5">
                        {log.reason} • by {log.userName}
                      </p>
                    </div>
                    <span className="text-[11px] text-neutral-400 font-mono">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Actions */}
        <div className="px-6 py-4 bg-neutral-50 border-t border-neutral-200 flex flex-wrap items-center justify-between gap-2">
          <button
            onClick={() => onPrintTag(item)}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-white border border-neutral-300 hover:bg-neutral-100 text-neutral-800 rounded-lg text-xs font-bold transition-colors shadow-2xs"
          >
            <Printer className="w-4 h-4" />
            Print Modular Shelf Tag
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onEdit(item);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-neutral-200 hover:bg-neutral-300 text-neutral-800 rounded-lg text-xs font-bold transition-colors"
            >
              <Edit3 className="w-4 h-4" />
              Edit Specs
            </button>
            <button
              onClick={() => {
                onClose();
                onMovement(item);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0071DC] hover:bg-[#005bb5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors"
            >
              <ArrowRightLeft className="w-4 h-4" />
              Stock Movement
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
