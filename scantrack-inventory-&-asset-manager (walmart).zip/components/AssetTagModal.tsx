'use client';

import React, { useRef } from 'react';
import { InventoryItem } from '@/types/inventory';
import { BarcodeGenerator } from './BarcodeGenerator';
import { WalmartSparkLogo } from './WalmartSparkLogo';
import { X, Printer, MapPin, Tag, Calendar, Layers, Sparkles } from 'lucide-react';

interface AssetTagModalProps {
  item: InventoryItem | null;
  isOpen: boolean;
  onClose: () => void;
}

export function AssetTagModal({ item, isOpen, onClose }: AssetTagModalProps) {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !item) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 bg-[#0071DC] text-white">
          <div className="flex items-center gap-2.5">
            <WalmartSparkLogo size={24} />
            <div>
              <h3 className="font-bold text-base">Walmart Modular Shelf Tag</h3>
              <p className="text-xs text-blue-100">Standard Supercenter shelf strip format (3 &times; 1.5 inch)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-blue-200 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Label Preview */}
        <div className="p-6 bg-neutral-100 flex flex-col items-center">
          <div
            ref={printRef}
            className="w-full max-w-md bg-white p-5 rounded-lg border-2 border-neutral-900 shadow-md flex flex-col justify-between print:m-0 print:border-none print:shadow-none"
          >
            {/* Top Bar with Walmart Spark, Department, and Rollback if active */}
            <div className="flex items-center justify-between border-b-2 border-neutral-900 pb-2 mb-2">
              <div className="flex items-center gap-1.5">
                <WalmartSparkLogo size={20} />
                <span className="font-extrabold text-xs tracking-tight text-[#0071DC]">Walmart</span>
                <span className="text-[10px] font-bold text-neutral-600 bg-neutral-100 px-1.5 py-0.2 rounded ml-1">
                  {item.departmentNumber || 'Dept 95'}
                </span>
              </div>
              {item.isRollback ? (
                <div className="bg-[#E60000] text-white text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded">
                  ROLLBACK
                </div>
              ) : (
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-500">
                  EVERYDAY LOW PRICE
                </span>
              )}
            </div>

            {/* Price and Unit Price Row */}
            <div className="flex items-baseline justify-between my-1">
              <div>
                <span className="text-3xl sm:text-4xl font-black text-neutral-950 tracking-tight">
                  ${item.sellingPrice.toFixed(2)}
                </span>
              </div>
              <div className="text-right">
                <div className="text-xs font-bold text-neutral-800 bg-amber-50 border border-amber-200 px-2 py-1 rounded">
                  {item.unitPriceDescription || `$${item.sellingPrice.toFixed(2)} / EA`}
                </div>
                <span className="text-[9px] text-neutral-400 uppercase font-semibold">Unit Price</span>
              </div>
            </div>

            {/* Description */}
            <div className="my-1.5">
              <h4 className="font-bold text-neutral-900 text-xs uppercase leading-snug line-clamp-2">
                {item.name}
              </h4>
              <p className="text-[10px] text-neutral-500 font-medium">Brand: {item.brand || 'Walmart Brand'}</p>
            </div>

            {/* Central Barcode */}
            <div className="flex flex-col items-center justify-center py-1 bg-neutral-50 rounded border border-neutral-200 my-1">
              <BarcodeGenerator
                value={item.barcode}
                width={220}
                height={42}
                showText={true}
                className="bg-transparent border-none shadow-none p-0"
              />
            </div>

            {/* Bottom shelf coordinates */}
            <div className="grid grid-cols-3 gap-1 text-[10px] pt-2 border-t border-neutral-300 font-mono text-neutral-700">
              <div>
                <span className="text-neutral-400 block text-[9px] uppercase">Modular Loc</span>
                <strong className="text-neutral-900">{item.location}</strong>
              </div>
              <div>
                <span className="text-neutral-400 block text-[9px] uppercase">WIN #</span>
                <strong className="text-neutral-900">{item.sku}</strong>
              </div>
              <div className="text-right">
                <span className="text-neutral-400 block text-[9px] uppercase">Cap / Facing</span>
                <strong className="text-neutral-900">Cap: {item.minStockThreshold}</strong>
              </div>
            </div>
          </div>

          <p className="text-[11px] text-neutral-500 mt-3 text-center">
            Standard Walmart modular shelf tag with aisle coordinates and scannable UPC.
          </p>
        </div>

        {/* Modal Actions */}
        <div className="px-6 py-4 bg-white border-t border-neutral-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg text-xs font-semibold hover:bg-neutral-50 transition-colors"
          >
            Close
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#0071DC] hover:bg-[#005bb5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              Print Shelf Tag
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
