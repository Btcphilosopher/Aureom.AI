'use client';

import React, { useState } from 'react';
import { useInventory } from '@/context/InventoryContext';
import { UserProfile, UserRole } from '@/types/inventory';
import { WalmartSparkLogo } from './WalmartSparkLogo';
import { X, Shield, CheckCircle2, LogIn, LogOut, Key, UserCheck } from 'lucide-react';

interface UserSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function UserSwitcherModal({ isOpen, onClose }: UserSwitcherModalProps) {
  const { 
    currentUser, 
    setCurrentUser, 
    availableUsers, 
    firebaseUser, 
    signInWithGoogle, 
    signOutFirebase 
  } = useInventory();

  const [customName, setCustomName] = useState('');
  const [customEmail, setCustomEmail] = useState('');
  const [customRole, setCustomRole] = useState<UserRole>('inventory_manager');
  const [isCreatingCustom, setIsCreatingCustom] = useState(false);

  if (!isOpen) return null;

  const handleSelectUser = (user: UserProfile) => {
    setCurrentUser(user);
    onClose();
  };

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim() || !customEmail.trim()) return;

    const newUser: UserProfile = {
      id: `usr_wm_${Date.now()}`,
      name: customName.trim(),
      email: customEmail.trim(),
      role: customRole,
      avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`,
      department: customRole === 'admin' ? 'Store Operations' : 'Department Team',
      storeNumber: 'Store #1001 (Bentonville, AR)',
    };

    setCurrentUser(newUser);
    onClose();
  };

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'admin':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-purple-100 text-purple-800">
            Store Lead (Admin)
          </span>
        );
      case 'inventory_manager':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-blue-100 text-[#0071DC]">
            Dept Team Lead
          </span>
        );
      case 'warehouse_scanner':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-amber-100 text-amber-800">
            Backroom Associate
          </span>
        );
      case 'auditor':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800">
            Asset Protection
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-blue-600 bg-[#0071DC] text-white">
          <div className="flex items-center gap-2.5">
            <WalmartSparkLogo size={22} />
            <div>
              <h3 className="font-black text-base">Walmart Associate Authentication</h3>
              <p className="text-xs text-blue-100">Store #1001 • Role-based Firestore audit logging</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-blue-200 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Real Google Firebase Sign In / Out */}
          <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#0071DC]" />
              <div className="text-xs">
                <span className="font-bold text-neutral-900 block">Firebase Authentication</span>
                <span className="text-[11px] text-neutral-500">
                  {firebaseUser ? `Signed in as ${firebaseUser.email}` : 'Google OAuth available'}
                </span>
              </div>
            </div>

            {firebaseUser ? (
              <button
                onClick={signOutFirebase}
                className="px-3 py-1.5 bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-xs font-bold rounded-lg transition-colors flex items-center gap-1"
              >
                <LogOut className="w-3.5 h-3.5" />
                Sign Out
              </button>
            ) : (
              <button
                onClick={signInWithGoogle}
                className="px-3 py-1.5 bg-[#0071DC] hover:bg-[#005bb5] text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
              >
                <LogIn className="w-3.5 h-3.5" />
                Google Sign-In
              </button>
            )}
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-extrabold text-neutral-700">
              Select Store Associate Profile:
            </label>
            {availableUsers.map((user) => {
              const isSelected = user.id === currentUser.id;
              return (
                <div
                  key={user.id}
                  onClick={() => handleSelectUser(user)}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                    isSelected
                      ? 'border-[#0071DC] bg-blue-50/80 ring-2 ring-blue-500/20'
                      : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-10 h-10 rounded-full object-cover border border-neutral-200"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-neutral-900 text-sm">{user.name}</span>
                        {getRoleBadge(user.role)}
                      </div>
                      <p className="text-xs text-neutral-500 font-medium">
                        {user.department} • {user.email}
                      </p>
                    </div>
                  </div>
                  {isSelected && <CheckCircle2 className="w-5 h-5 text-[#0071DC] shrink-0" />}
                </div>
              );
            })}
          </div>

          {/* Toggle Custom Associate Sign In */}
          {!isCreatingCustom ? (
            <button
              onClick={() => setIsCreatingCustom(true)}
              className="w-full py-2.5 px-3 border border-dashed border-neutral-300 hover:border-[#0071DC] hover:bg-blue-50/30 rounded-xl text-xs font-bold text-neutral-700 flex items-center justify-center gap-2 transition-colors"
            >
              <UserCheck className="w-4 h-4 text-[#0071DC]" />
              Enter Custom Associate ID
            </button>
          ) : (
            <form onSubmit={handleCreateCustom} className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-neutral-800">Custom Associate Sign-In</span>
                <button
                  type="button"
                  onClick={() => setIsCreatingCustom(false)}
                  className="text-[11px] text-neutral-500 hover:text-neutral-800"
                >
                  Cancel
                </button>
              </div>

              <div>
                <label className="block text-neutral-600 mb-1 font-semibold">Associate Name</label>
                <input
                  type="text"
                  required
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="e.g. David Miller"
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0071DC]"
                />
              </div>

              <div>
                <label className="block text-neutral-600 mb-1 font-semibold">Walmart Email</label>
                <input
                  type="email"
                  required
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  placeholder="d.miller@walmart.com"
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0071DC]"
                />
              </div>

              <div>
                <label className="block text-neutral-600 mb-1 font-semibold">Department Role</label>
                <select
                  value={customRole}
                  onChange={(e) => setCustomRole(e.target.value as UserRole)}
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0071DC]"
                >
                  <option value="admin">Store Lead (Full Admin)</option>
                  <option value="inventory_manager">Department Team Lead (Stock & Pricing)</option>
                  <option value="warehouse_scanner">Backroom Associate (Scan & Receiving)</option>
                  <option value="auditor">Asset Protection (Cycle Audit)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-[#0071DC] hover:bg-[#005bb5] text-white font-bold rounded-lg transition-colors mt-2"
              >
                Sign In Associate
              </button>
            </form>
          )}
        </div>

        <div className="px-6 py-3 bg-neutral-50 border-t border-neutral-200 text-center text-[11px] text-neutral-500">
          Associate ID is recorded on all live Firebase transactions.
        </div>
      </div>
    </div>
  );
}
