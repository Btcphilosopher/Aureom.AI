'use client';

import React, { useState } from 'react';
import { InventoryItem } from '@/types/inventory';
import { useInventory } from '@/context/InventoryContext';
import { WalmartSparkLogo } from './WalmartSparkLogo';
import { X, ArrowDownRight, ArrowUpRight, Scale, CheckCircle2, Truck } from 'lucide-react';

interface StockMovementModalProps {
  item: InventoryItem | null;
  isOpen: boolean;
  onClose: () => void;
  defaultType?: 'in' | 'out' | 'adjust';
}

export function StockMovementModal({
  item,
  isOpen,
  onClose,
  defaultType = 'in',
}: StockMovementModalProps) {
  const { adjustStock } = useInventory();
  const [movementType, setMovementType] = useState<'in' | 'out' | 'adjust'>(defaultType);
  const [quantity, setQuantity] = useState<number>(12);
  const [reason, setReason] = useState<string>('');
  const [targetCount, setTargetCount] = useState<number>(item?.quantity || 0);

  if (!isOpen || !item) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    let changeQty = 0;

    if (movementType === 'in') {
      changeQty = Math.abs(quantity);
    } else if (movementType === 'out') {
      changeQty = -Math.abs(quantity);
    } else {
      changeQty = targetCount - item.quantity;
    }

    const defaultReason =
      movementType === 'in'
        ? `DC Truck Delivery Received (${quantity} units)`
        : movementType === 'out'
        ? `Floor Pick / Online Grocery Order (${quantity} units)`
        : `Physical Modular Cycle Count Audit`;

    await adjustStock(item.id, changeQty, reason.trim() || defaultReason);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-blue-600 bg-[#0071DC] text-white">
          <div className="flex items-center gap-2.5">
            <WalmartSparkLogo size={22} />
            <div>
              <h3 className="font-black text-base leading-tight">Record Store Stock Movement</h3>
              <p className="text-xs text-blue-100">Live Firebase sync • {item.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-blue-200 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Info */}
        <div className="px-6 py-3 bg-neutral-50 border-b border-neutral-200 flex items-center justify-between text-xs">
          <div>
            <span className="text-neutral-500 font-semibold">WIN #:</span>{' '}
            <strong className="font-mono text-neutral-900">{item.sku}</strong>
          </div>
          <div>
            <span className="text-neutral-500 font-semibold">Current Shelf Stock:</span>{' '}
            <strong className="text-[#0071DC] text-sm font-black">{item.quantity} units</strong>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Movement Type Toggle */}
          <div>
            <label className="block font-bold text-neutral-800 mb-1.5">Action Type</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setMovementType('in')}
                className={`py-2 px-2.5 rounded-lg border font-bold flex flex-col items-center gap-1 transition-all ${
                  movementType === 'in'
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-500/20'
                    : 'border-neutral-200 hover:bg-neutral-50 text-neutral-600'
                }`}
              >
                <ArrowDownRight className="w-4 h-4 text-emerald-600" />
                <span>DC Inbound (+)</span>
              </button>

              <button
                type="button"
                onClick={() => setMovementType('out')}
                className={`py-2 px-2.5 rounded-lg border font-bold flex flex-col items-center gap-1 transition-all ${
                  movementType === 'out'
                    ? 'border-amber-500 bg-amber-50 text-amber-800 ring-2 ring-amber-500/20'
                    : 'border-neutral-200 hover:bg-neutral-50 text-neutral-600'
                }`}
              >
                <ArrowUpRight className="w-4 h-4 text-amber-600" />
                <span>Floor Pick (-)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMovementType('adjust');
                  setTargetCount(item.quantity);
                }}
                className={`py-2 px-2.5 rounded-lg border font-bold flex flex-col items-center gap-1 transition-all ${
                  movementType === 'adjust'
                    ? 'border-[#0071DC] bg-blue-50 text-blue-800 ring-2 ring-blue-500/20'
                    : 'border-neutral-200 hover:bg-neutral-50 text-neutral-600'
                }`}
              >
                <Scale className="w-4 h-4 text-[#0071DC]" />
                <span>Cycle Audit</span>
              </button>
            </div>
          </div>

          {/* Quantity Input */}
          {movementType === 'adjust' ? (
            <div>
              <label className="block font-bold text-neutral-800 mb-1">
                New Counted Physical Quantity
              </label>
              <input
                type="number"
                min="0"
                value={targetCount}
                onChange={(e) => setTargetCount(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 text-base font-black text-neutral-900 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC] focus:bg-white"
              />
              <p className="text-[11px] text-neutral-500 mt-1">
                Stock changes from <strong>{item.quantity}</strong> to{' '}
                <strong>{targetCount}</strong> ({targetCount - item.quantity >= 0 ? '+' : ''}
                {targetCount - item.quantity} delta)
              </p>
            </div>
          ) : (
            <div>
              <label className="block font-bold text-neutral-800 mb-1">
                {movementType === 'in' ? 'Units to Add (DC Inbound Truck)' : 'Units to Deduct (Store Sales / Pick)'}
              </label>
              <input
                type="number"
                min="1"
                max={movementType === 'out' ? item.quantity : 99999}
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2 text-base font-black text-neutral-900 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC] focus:bg-white"
              />
              <p className="text-[11px] text-neutral-500 mt-1">
                Resulting stock on hand:{' '}
                <strong>
                  {movementType === 'in' ? item.quantity + quantity : Math.max(0, item.quantity - quantity)}{' '}
                  units
                </strong>
              </p>
            </div>
          )}

          {/* Reason / PO Reference */}
          <div>
            <label className="block font-bold text-neutral-800 mb-1">
              Store Reference / Truck Manifest # / PO #
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder={
                movementType === 'in'
                  ? 'e.g. DC #6012 Delivery Truck #TR-8812'
                  : movementType === 'out'
                  ? 'e.g. OGP (Online Grocery Pickup) Batch Order #4421'
                  : 'e.g. Weekly department modular cycle count'
              }
              className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC] focus:bg-white"
            />
          </div>

          {/* Quick preset chips */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] text-neutral-500 font-semibold">Case Presets:</span>
            {[6, 12, 24, 48, 100].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => setQuantity(n)}
                className="px-2 py-0.5 rounded bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-bold text-[11px] transition-colors"
              >
                +{n} (Case)
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg text-sm font-semibold hover:bg-neutral-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2 bg-[#0071DC] hover:bg-[#005bb5] text-white rounded-lg text-sm font-bold shadow-xs transition-colors"
            >
              <CheckCircle2 className="w-4 h-4" />
              Commit to Firebase
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
