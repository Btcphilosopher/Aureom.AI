'use client';

import React from 'react';
import { useInventory } from '@/context/InventoryContext';
import { WalmartSparkLogo } from './WalmartSparkLogo';
import { 
  Package, 
  AlertTriangle, 
  XCircle, 
  DollarSign, 
  TrendingUp, 
  Camera, 
  Plus, 
  FileSpreadsheet, 
  ArrowUpRight,
  ShieldCheck,
  CheckCircle,
  Truck,
  Sparkles,
  Tag
} from 'lucide-react';
import { InventoryItem } from '@/types/inventory';

interface InventoryOverviewProps {
  onOpenScanner: () => void;
  onOpenCreateModal: () => void;
  onSelectItem: (item: InventoryItem) => void;
  onNavigateToCatalog: () => void;
}

export function InventoryOverview({
  onOpenScanner,
  onOpenCreateModal,
  onSelectItem,
  onNavigateToCatalog,
}: InventoryOverviewProps) {
  const { items, exportCsv } = useInventory();

  // Metrics computation
  const totalUnits = items.reduce((acc, i) => acc + i.quantity, 0);
  const totalRetailValue = items.reduce((acc, i) => acc + i.quantity * i.sellingPrice, 0);
  const totalCostValue = items.reduce((acc, i) => acc + i.quantity * i.costPrice, 0);
  const rollbackItems = items.filter((i) => i.isRollback);

  const lowStockItems = items.filter((i) => i.quantity > 0 && i.quantity <= i.minStockThreshold);
  const outOfStockItems = items.filter((i) => i.quantity === 0);
  const inStockItems = items.filter((i) => i.quantity > i.minStockThreshold);

  // On-Shelf Availability (OSA) %
  const osaScore = items.length > 0 ? Math.round(((items.length - outOfStockItems.length) / items.length) * 100) : 100;

  // Department distribution
  const departmentStats = items.reduce((acc: Record<string, { count: number; units: number }>, item) => {
    const dept = item.departmentNumber || 'Other';
    if (!acc[dept]) {
      acc[dept] = { count: 0, units: 0 };
    }
    acc[dept].count += 1;
    acc[dept].units += item.quantity;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {/* Walmart Supercenter Operations Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#0071DC] via-[#005bb5] to-[#002244] text-white p-6 sm:p-8 shadow-lg">
        {/* Decorative Spark glow */}
        <div className="absolute right-4 -bottom-10 opacity-15 pointer-events-none">
          <WalmartSparkLogo size={240} />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FFC220] text-neutral-900 text-xs font-black mb-3 shadow-xs">
              <WalmartSparkLogo size={16} />
              <span>SUPERCENTER STORE #1001 • INVENTORY CONTROL</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Modular Asset & Floor Stock Management
            </h2>
            <p className="text-sm text-blue-100/90 mt-2 leading-relaxed">
              Track On-Shelf Availability (OSA), audit modular shelf locations, scan UPC barcodes, receive distribution center trucks, and verify Rollback pricing.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={onOpenScanner}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#FFC220] hover:bg-[#ffcd38] text-neutral-900 font-black rounded-xl text-sm shadow-md transition-all transform hover:-translate-y-0.5"
            >
              <Camera className="w-4 h-4 text-neutral-900" />
              Scan Barcode / Mod
            </button>
            <button
              onClick={onOpenCreateModal}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-white/15 hover:bg-white/25 text-white font-bold rounded-xl text-sm border border-white/30 shadow-xs transition-all"
            >
              <Plus className="w-4 h-4" />
              New Modular WIN
            </button>
            <button
              onClick={exportCsv}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 bg-black/30 hover:bg-black/50 text-blue-100 font-semibold rounded-xl text-sm border border-blue-400/30 transition-all"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Export Store CSV
            </button>
          </div>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Valuation */}
        <div className="p-5 bg-white rounded-xl border border-neutral-200 shadow-xs hover:border-neutral-300 transition-all">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-neutral-600">
              Store Stock Valuation
            </span>
            <div className="p-2 rounded-lg bg-blue-50 text-[#0071DC]">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-neutral-900">
            ${totalRetailValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-neutral-500 font-medium">
            <span className="text-emerald-600 font-bold">
              ${(totalRetailValue - totalCostValue).toFixed(2)}
            </span>
            <span>est. floor margin</span>
          </div>
        </div>

        {/* Metric 2: Total Units & SKUs */}
        <div className="p-5 bg-white rounded-xl border border-neutral-200 shadow-xs hover:border-neutral-300 transition-all">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-neutral-600">
              Total Units On Hand
            </span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-700">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-neutral-900">
            {totalUnits.toLocaleString()}{' '}
            <span className="text-sm font-medium text-neutral-500">units</span>
          </p>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-neutral-500 font-medium">
            <span className="font-bold text-neutral-800">{items.length}</span>
            <span>active WIN catalog items</span>
          </div>
        </div>

        {/* Metric 3: Rollback Items */}
        <div className="p-5 bg-white rounded-xl border border-neutral-200 shadow-xs hover:border-neutral-300 transition-all">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-neutral-600">
              Active Rollbacks
            </span>
            <div className="p-2 rounded-lg bg-rose-50 text-rose-600">
              <Tag className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-rose-600">
            {rollbackItems.length}{' '}
            <span className="text-sm font-medium text-neutral-500">promos</span>
          </p>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-rose-600 font-semibold">
            <span>Customer Everyday Low Price deals</span>
          </div>
        </div>

        {/* Metric 4: On-Shelf Availability (OSA) */}
        <div className="p-5 bg-white rounded-xl border border-neutral-200 shadow-xs hover:border-neutral-300 transition-all">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-neutral-600">
              On-Shelf Availability (OSA)
            </span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-600">
            {osaScore}%
          </p>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-neutral-500 font-medium">
            <span>Target: 95%+ • Out of stock: {outOfStockItems.length}</span>
          </div>
        </div>
      </div>

      {/* Grid: Depletion Alerts & Department Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Urgent Attention / Action Needed List */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-neutral-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-neutral-900 text-base">Topstock & Shelf Replenishment Alerts</h3>
              <p className="text-xs text-neutral-500">Items below minimum shelf facing capacity</p>
            </div>
            <button
              onClick={onNavigateToCatalog}
              className="text-xs font-bold text-[#0071DC] hover:text-[#005bb5] flex items-center gap-1"
            >
              View All Mod Items <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {[...outOfStockItems, ...lowStockItems].length === 0 ? (
              <div className="p-8 text-center bg-emerald-50 rounded-xl border border-emerald-100 text-emerald-800">
                <CheckCircle className="w-8 h-8 mx-auto mb-2 text-emerald-600" />
                <p className="font-bold text-sm">Supercenter Shelves Fully Stocked!</p>
                <p className="text-xs text-emerald-600 mt-0.5">
                  No modular assets are currently under safety capacity.
                </p>
              </div>
            ) : (
              [...outOfStockItems, ...lowStockItems].map((item) => (
                <div
                  key={item.id}
                  onClick={() => onSelectItem(item)}
                  className="flex items-center justify-between p-3.5 rounded-xl border border-neutral-200 hover:border-blue-400 hover:bg-neutral-50/80 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-lg bg-neutral-100 overflow-hidden shrink-0 border border-neutral-200 flex items-center justify-center">
                      {item.imageUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                      ) : (
                        <Package className="w-5 h-5 text-neutral-400" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-xs text-neutral-900 group-hover:text-[#0071DC] transition-colors">
                          {item.name}
                        </span>
                        {item.isRollback && (
                          <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-red-600 text-white">
                            Rollback
                          </span>
                        )}
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-100 text-neutral-600 font-bold">
                          {item.sku}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-500 mt-0.5">
                        Modular: <strong>{item.location}</strong> • Dept: {item.departmentNumber} • Cap: {item.minStockThreshold}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-black ${
                          item.quantity === 0
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {item.quantity === 0 ? 'Stockout (0)' : `${item.quantity} on shelf`}
                      </span>
                      <p className="text-[10px] text-neutral-400 mt-0.5 font-mono">
                        UPC: {item.barcode}
                      </p>
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-neutral-400 group-hover:text-[#0071DC] transition-transform group-hover:translate-x-0.5" />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Department Breakdown & Health Index */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-extrabold text-neutral-900 text-sm">Store Shelf Health</h3>
              <span className="text-xs font-bold text-[#0071DC]">{osaScore}% Score</span>
            </div>
            <p className="text-xs text-neutral-500 mb-3">Modular availability and replenishment buffer</p>

            <div className="w-full bg-neutral-100 rounded-full h-2.5 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  osaScore >= 90 ? 'bg-emerald-500' : osaScore >= 70 ? 'bg-amber-500' : 'bg-rose-500'
                }`}
                style={{ width: `${osaScore}%` }}
              />
            </div>

            <div className="mt-4 pt-3 border-t border-neutral-100 space-y-2 text-xs">
              <div className="flex justify-between text-neutral-600">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" /> Healthy stock ({inStockItems.length})
                </span>
                <span className="font-bold">{Math.round((inStockItems.length / (items.length || 1)) * 100)}%</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500" /> Low shelf stock ({lowStockItems.length})
                </span>
                <span className="font-bold">{Math.round((lowStockItems.length / (items.length || 1)) * 100)}%</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500" /> Zero stock ({outOfStockItems.length})
                </span>
                <span className="font-bold">{Math.round((outOfStockItems.length / (items.length || 1)) * 100)}%</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-xs">
            <h3 className="font-extrabold text-neutral-900 text-sm mb-3">Units By Department</h3>
            <div className="space-y-3">
              {Object.entries(departmentStats).map(([dept, stat]) => {
                const pct = totalUnits > 0 ? Math.round((stat.units / totalUnits) * 100) : 0;
                return (
                  <div key={dept} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-bold text-neutral-800 truncate pr-2">{dept}</span>
                      <span className="font-bold text-neutral-600 shrink-0">{stat.units} units ({pct}%)</span>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="h-full bg-[#0071DC] rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
