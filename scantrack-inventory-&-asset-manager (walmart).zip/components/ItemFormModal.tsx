'use client';

import React, { useState, useEffect } from 'react';
import { InventoryItem } from '@/types/inventory';
import { useInventory } from '@/context/InventoryContext';
import { WALMART_DEPARTMENTS, WALMART_BRANDS } from '@/lib/mockData';
import { WalmartSparkLogo } from './WalmartSparkLogo';
import { X, Sparkles, Package, Barcode, DollarSign, MapPin, Layers, Save, Tag } from 'lucide-react';

interface ItemFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialItem?: InventoryItem | null;
}

export function ItemFormModal({ isOpen, onClose, initialItem }: ItemFormModalProps) {
  const { addItem, updateItem } = useInventory();

  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [barcode, setBarcode] = useState('');
  const [departmentNumber, setDepartmentNumber] = useState('Dept 95 - Grocery');
  const [category, setCategory] = useState('Grocery & Fresh');
  const [brand, setBrand] = useState('Great Value');
  const [quantity, setQuantity] = useState(24);
  const [minStockThreshold, setMinStockThreshold] = useState(12);
  const [costPrice, setCostPrice] = useState(2.50);
  const [sellingPrice, setSellingPrice] = useState(4.28);
  const [isRollback, setIsRollback] = useState(false);
  const [unitPriceDescription, setUnitPriceDescription] = useState('$0.14/oz');
  const [location, setLocation] = useState('Aisle G04-02 • Shelf 03');
  const [batchNumber, setBatchNumber] = useState('LOT-2026-');
  const [expiryDate, setExpiryDate] = useState('2028-12-31');
  const [supplier, setSupplier] = useState('Walmart Grocery DC #6012');
  const [imageUrl, setImageUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const generateRandomWIN = () => {
    const randNum = Math.floor(55000000 + Math.random() * 44000000);
    setSku(`WIN-${randNum}`);
  };

  const generateRandomUPC = () => {
    // 12-digit standard UPC format
    let code = '078';
    for (let i = 0; i < 9; i++) {
      code += Math.floor(Math.random() * 10).toString();
    }
    setBarcode(code);
  };

  useEffect(() => {
    if (initialItem) {
      setName(initialItem.name);
      setSku(initialItem.sku);
      setBarcode(initialItem.barcode);
      setDepartmentNumber(initialItem.departmentNumber || 'Dept 95 - Grocery');
      setCategory(initialItem.category);
      setBrand(initialItem.brand || 'Great Value');
      setQuantity(initialItem.quantity);
      setMinStockThreshold(initialItem.minStockThreshold);
      setCostPrice(initialItem.costPrice);
      setSellingPrice(initialItem.sellingPrice);
      setIsRollback(initialItem.isRollback || false);
      setUnitPriceDescription(initialItem.unitPriceDescription || '');
      setLocation(initialItem.location);
      setBatchNumber(initialItem.batchNumber || '');
      setExpiryDate(initialItem.expiryDate || '');
      setSupplier(initialItem.supplier || '');
      setImageUrl(initialItem.imageUrl || '');
      setNotes(initialItem.notes || '');
    } else {
      setName('');
      generateRandomWIN();
      generateRandomUPC();
      setDepartmentNumber('Dept 95 - Grocery');
      setCategory('Grocery & Fresh');
      setBrand('Great Value');
      setQuantity(48);
      setMinStockThreshold(15);
      setCostPrice(2.50);
      setSellingPrice(4.28);
      setIsRollback(false);
      setUnitPriceDescription('$0.18/oz');
      setLocation('Aisle G06-01 • Shelf 02');
      setBatchNumber(`LOT-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`);
      setExpiryDate('2028-12-31');
      setSupplier('Walmart Central DC');
      setImageUrl('https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400&auto=format&fit=crop&q=80');
      setNotes('');
    }
    setErrors({});
  }, [initialItem, isOpen]);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = 'Item description is required';
    if (!sku.trim()) errs.sku = 'WIN (Walmart Item Number) is required';
    if (!barcode.trim()) errs.barcode = '12-digit UPC barcode is required';
    if (quantity < 0) errs.quantity = 'Quantity cannot be negative';
    if (minStockThreshold < 0) errs.minStockThreshold = 'Facing capacity cannot be negative';
    if (costPrice < 0) errs.costPrice = 'Cost cannot be negative';
    if (sellingPrice < 0) errs.sellingPrice = 'Retail price cannot be negative';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    if (initialItem) {
      await updateItem(initialItem.id, {
        name,
        sku,
        barcode,
        departmentNumber,
        category,
        brand,
        quantity,
        minStockThreshold,
        costPrice,
        sellingPrice,
        isRollback,
        unitPriceDescription,
        location,
        batchNumber,
        expiryDate,
        supplier,
        imageUrl,
        notes,
      });
    } else {
      await addItem({
        name,
        sku,
        barcode,
        departmentNumber,
        category,
        brand,
        quantity,
        minStockThreshold,
        costPrice,
        sellingPrice,
        isRollback,
        unitPriceDescription,
        location,
        batchNumber,
        expiryDate,
        supplier,
        imageUrl,
        notes,
      });
    }

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-blue-600 bg-[#0071DC] text-white">
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-white/10 rounded-lg">
              <WalmartSparkLogo size={24} />
            </div>
            <div>
              <h3 className="font-black text-lg leading-tight">
                {initialItem ? 'Edit Modular Shelf Asset' : 'Register New Walmart Modular WIN'}
              </h3>
              <p className="text-xs text-blue-100">Synchronized live with Store #1001 Firebase Firestore</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-blue-200 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          {/* Item Name */}
          <div>
            <label className="block font-bold text-neutral-800 mb-1">
              Product Description / Item Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Great Value Whole Milk (1 Gallon, 128 fl oz)"
              className={`w-full px-3 py-2 text-sm bg-neutral-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC] focus:bg-white ${
                errors.name ? 'border-red-500' : 'border-neutral-300'
              }`}
            />
            {errors.name && <p className="text-red-500 text-[11px] mt-1">{errors.name}</p>}
          </div>

          {/* Brand & Department */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-neutral-800 mb-1">Brand</label>
              <select
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
              >
                {WALMART_BRANDS.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-neutral-800 mb-1">Supercenter Department</label>
              <select
                value={departmentNumber}
                onChange={(e) => {
                  setDepartmentNumber(e.target.value);
                  // match category
                  if (e.target.value.includes('Grocery')) setCategory('Grocery & Fresh');
                  else if (e.target.value.includes('Electronics')) setCategory('Electronics & Tech');
                  else if (e.target.value.includes('Home')) setCategory('Home & Kitchen');
                  else if (e.target.value.includes('Pharmacy')) setCategory('Pharmacy & Health');
                  else if (e.target.value.includes('Beauty')) setCategory('Beauty & Personal Care');
                  else if (e.target.value.includes('Hardware')) setCategory('Hardware & Tools');
                }}
                className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
              >
                {WALMART_DEPARTMENTS.filter((d) => d !== 'All Departments').map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* WIN & UPC Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-bold text-neutral-800">
                  WIN (Walmart Item #) <span className="text-red-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={generateRandomWIN}
                  className="text-[11px] text-[#0071DC] hover:text-[#005bb5] font-bold flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" /> Auto WIN
                </button>
              </div>
              <div className="relative">
                <Layers className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={sku}
                  onChange={(e) => setSku(e.target.value)}
                  placeholder="WIN-55102001"
                  className={`w-full pl-9 pr-3 py-2 text-sm font-mono font-bold bg-neutral-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC] focus:bg-white ${
                    errors.sku ? 'border-red-500' : 'border-neutral-300'
                  }`}
                />
              </div>
              {errors.sku && <p className="text-red-500 text-[11px] mt-1">{errors.sku}</p>}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-bold text-neutral-800">
                  12-Digit UPC Barcode <span className="text-red-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={generateRandomUPC}
                  className="text-[11px] text-[#0071DC] hover:text-[#005bb5] font-bold flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" /> Auto UPC
                </button>
              </div>
              <div className="relative">
                <Barcode className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  placeholder="078742351890"
                  className={`w-full pl-9 pr-3 py-2 text-sm font-mono font-bold bg-neutral-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC] focus:bg-white ${
                    errors.barcode ? 'border-red-500' : 'border-neutral-300'
                  }`}
                />
              </div>
              {errors.barcode && <p className="text-red-500 text-[11px] mt-1">{errors.barcode}</p>}
            </div>
          </div>

          {/* Modular Location & Unit Price string */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-neutral-800 mb-1">Modular Shelf Coordinate</label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Aisle G01-02 • Mod 04"
                  className="w-full pl-9 pr-3 py-2 text-sm font-medium bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-neutral-800 mb-1">Unit Price Display (For Shelf Tag)</label>
              <input
                type="text"
                value={unitPriceDescription}
                onChange={(e) => setUnitPriceDescription(e.target.value)}
                placeholder="e.g. $0.03/fl oz or $1.98/ea"
                className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
              />
            </div>
          </div>

          {/* Pricing & Rollback */}
          <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-neutral-800 mb-1">Everyday Low Retail Price ($)</label>
                <div className="relative">
                  <DollarSign className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(parseFloat(e.target.value) || 0)}
                    className="w-full pl-9 pr-3 py-2 text-sm font-black text-neutral-900 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-neutral-800 mb-1">Wholesale Cost ($)</label>
                <div className="relative">
                  <DollarSign className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={costPrice}
                    onChange={(e) => setCostPrice(parseFloat(e.target.value) || 0)}
                    className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
                  />
                </div>
              </div>
            </div>

            {/* Rollback Switch */}
            <label className="flex items-center gap-2 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={isRollback}
                onChange={(e) => setIsRollback(e.target.checked)}
                className="w-4 h-4 text-red-600 rounded border-neutral-300 focus:ring-red-500"
              />
              <span className="font-bold text-xs text-neutral-800 flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-red-600" />
                Mark as Active Rollback Promotion (Displays Rollback Tag)
              </span>
            </label>
          </div>

          {/* Quantity & Threshold */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-neutral-800 mb-1">Shelf Inventory Count</label>
              <input
                type="number"
                min="0"
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 text-sm font-black text-neutral-900 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
              />
            </div>

            <div>
              <label className="block font-bold text-neutral-800 mb-1">Shelf Capacity / Min Threshold</label>
              <input
                type="number"
                min="1"
                value={minStockThreshold}
                onChange={(e) => setMinStockThreshold(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 text-sm font-black text-neutral-900 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
              />
            </div>
          </div>

          {/* Supplier & Photo URL */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-neutral-800 mb-1">DC / Supplier</label>
              <input
                type="text"
                value={supplier}
                onChange={(e) => setSupplier(e.target.value)}
                placeholder="Walmart Central DC #6012"
                className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
              />
            </div>

            <div>
              <label className="block font-bold text-neutral-800 mb-1">Product Photo URL</label>
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://images.unsplash.com/photo-..."
                className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC]"
              />
            </div>
          </div>

          {/* Submit Actions */}
          <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg text-sm font-semibold hover:bg-neutral-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2 bg-[#0071DC] hover:bg-[#005bb5] text-white rounded-lg text-sm font-bold shadow-xs transition-colors"
            >
              <Save className="w-4 h-4" />
              {initialItem ? 'Update Modular Asset' : 'Save New WIN'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
