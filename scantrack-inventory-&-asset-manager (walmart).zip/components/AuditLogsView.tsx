'use client';

import React, { useState } from 'react';
import { useInventory } from '@/context/InventoryContext';
import { 
  History, 
  ArrowDownRight, 
  ArrowUpRight, 
  Scale, 
  PlusCircle, 
  Trash2, 
  Edit3, 
  Search, 
  Filter,
  User,
  Clock,
  Barcode
} from 'lucide-react';

export function AuditLogsView() {
  const { auditLogs } = useInventory();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAction, setFilterAction] = useState<string>('all');

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.barcode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.reason.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesAction = filterAction === 'all' || log.action === filterAction;
    return matchesSearch && matchesAction;
  });

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'stock_in':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
            <ArrowDownRight className="w-3.5 h-3.5" /> Stock In
          </span>
        );
      case 'stock_out':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">
            <ArrowUpRight className="w-3.5 h-3.5" /> Stock Out
          </span>
        );
      case 'adjust':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
            <Scale className="w-3.5 h-3.5" /> Count Adjust
          </span>
        );
      case 'created':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-purple-100 text-purple-800">
            <PlusCircle className="w-3.5 h-3.5" /> Asset Created
          </span>
        );
      case 'deleted':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-800">
            <Trash2 className="w-3.5 h-3.5" /> Asset Deleted
          </span>
        );
      case 'updated':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-neutral-100 text-neutral-800">
            <Edit3 className="w-3.5 h-3.5" /> Info Updated
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-neutral-100 text-neutral-800">
            {action}
          </span>
        );
    }
  };

  const formatTimestamp = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return iso;
    }
  };

  return (
    <div className="space-y-4">
      {/* Header and filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-neutral-200 shadow-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by SKU, item, barcode, operator, or reason..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-neutral-400 shrink-0" />
          <select
            value={filterAction}
            onChange={(e) => setFilterAction(e.target.value)}
            className="px-3 py-2 text-xs bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium"
          >
            <option value="all">All Movement Actions</option>
            <option value="stock_in">Stock In</option>
            <option value="stock_out">Stock Out</option>
            <option value="adjust">Audit Adjust</option>
            <option value="created">Created</option>
            <option value="updated">Updated</option>
            <option value="deleted">Deleted</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-neutral-50 border-b border-neutral-200 text-neutral-600 uppercase tracking-wider text-[11px] font-semibold">
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Asset & SKU</th>
                <th className="py-3 px-4">Delta Qty</th>
                <th className="py-3 px-4">Previous → New</th>
                <th className="py-3 px-4">Operator</th>
                <th className="py-3 px-4">Reason / Reference</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-neutral-400">
                    <History className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    No audit records match your search criteria.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-neutral-50/70 transition-colors">
                    <td className="py-3 px-4 text-neutral-500 font-medium whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                        <span>{formatTimestamp(log.timestamp)}</span>
                      </div>
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">{getActionBadge(log.action)}</td>

                    <td className="py-3 px-4">
                      <div className="font-semibold text-neutral-900 line-clamp-1">
                        {log.itemName}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5 text-[11px] font-mono text-neutral-500">
                        <span>{log.sku}</span>
                        <span>•</span>
                        <span className="flex items-center gap-0.5">
                          <Barcode className="w-3 h-3 text-neutral-400" />
                          {log.barcode}
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap font-bold">
                      {log.quantityChanged > 0 ? (
                        <span className="text-emerald-600">+{log.quantityChanged}</span>
                      ) : log.quantityChanged < 0 ? (
                        <span className="text-amber-600">{log.quantityChanged}</span>
                      ) : (
                        <span className="text-neutral-400">0</span>
                      )}
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap text-neutral-600 font-mono">
                      {log.previousQty} → <strong className="text-neutral-900">{log.newQty}</strong>
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <div className="w-5 h-5 rounded-full bg-blue-100 text-[#0071DC] flex items-center justify-center font-bold text-[10px]">
                          {log.userName.charAt(0)}
                        </div>
                        <span className="font-medium text-neutral-800">{log.userName}</span>
                      </div>
                    </td>

                    <td className="py-3 px-4 text-neutral-600 max-w-xs">
                      <p className="truncate" title={log.reason}>
                        {log.reason}
                      </p>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-neutral-50 border-t border-neutral-200 text-xs text-neutral-500 flex items-center justify-between">
          <span>Showing {filteredLogs.length} audit transaction entries</span>
          <span className="font-bold text-[#0071DC]">Live Firebase Firestore Ledger Active</span>
        </div>
      </div>
    </div>
  );
}
