'use client';

import React, { useState, useMemo } from 'react';
import { InventoryItem } from '@/types/inventory';
import { useInventory } from '@/context/InventoryContext';
import { WALMART_DEPARTMENTS } from '@/lib/mockData';
import { BarcodeGenerator } from './BarcodeGenerator';
import { 
  Search, 
  Filter, 
  Plus, 
  Minus, 
  Printer, 
  Edit3, 
  Trash2, 
  LayoutGrid, 
  List, 
  ArrowUpDown, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  MapPin, 
  Barcode as BarcodeIcon,
  Layers,
  ArrowRightLeft,
  Tag
} from 'lucide-react';

interface InventoryCatalogProps {
  onSelectItem: (item: InventoryItem) => void;
  onEditItem: (item: InventoryItem) => void;
  onOpenMovement: (item: InventoryItem, type: 'in' | 'out' | 'adjust') => void;
  onPrintTag: (item: InventoryItem) => void;
  onOpenCreate: () => void;
}

export function InventoryCatalog({
  onSelectItem,
  onEditItem,
  onOpenMovement,
  onPrintTag,
  onOpenCreate,
}: InventoryCatalogProps) {
  const { items, deleteItem, adjustStock } = useInventory();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('All Departments');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [onlyRollback, setOnlyRollback] = useState(false);
  const [sortBy, setSortBy] = useState<'name' | 'quantity' | 'price' | 'location'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [itemToDelete, setItemToDelete] = useState<InventoryItem | null>(null);

  // Filter and sort items
  const filteredItems = useMemo(() => {
    return items
      .filter((item) => {
        const matchesSearch =
          item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.barcode.includes(searchTerm) ||
          item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (item.brand && item.brand.toLowerCase().includes(searchTerm.toLowerCase())) ||
          item.batchNumber.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesDept =
          selectedDept === 'All Departments' || item.departmentNumber === selectedDept;

        const matchesStatus =
          selectedStatus === 'all' ||
          (selectedStatus === 'in_stock' && item.quantity > item.minStockThreshold) ||
          (selectedStatus === 'low_stock' && item.quantity > 0 && item.quantity <= item.minStockThreshold) ||
          (selectedStatus === 'out_of_stock' && item.quantity === 0);

        const matchesRollback = !onlyRollback || item.isRollback === true;

        return matchesSearch && matchesDept && matchesStatus && matchesRollback;
      })
      .sort((a, b) => {
        let valA: string | number;
        let valB: string | number;
        if (sortBy === 'price') {
          valA = a.sellingPrice;
          valB = b.sellingPrice;
        } else {
          valA = a[sortBy];
          valB = b[sortBy];
        }
        if (typeof valA === 'string' && typeof valB === 'string') {
          return sortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
        }
        if (typeof valA === 'number' && typeof valB === 'number') {
          return sortOrder === 'asc' ? valA - valB : valB - valA;
        }
        return 0;
      });
  }, [items, searchTerm, selectedDept, selectedStatus, onlyRollback, sortBy, sortOrder]);

  const toggleSort = (field: 'name' | 'quantity' | 'price' | 'location') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  const getStatusBadge = (item: InventoryItem) => {
    if (item.quantity === 0) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-rose-100 text-rose-800 border border-rose-200">
          <XCircle className="w-3 h-3" /> Out of Stock
        </span>
      );
    }
    if (item.quantity <= item.minStockThreshold) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-amber-100 text-amber-800 border border-amber-200">
          <AlertTriangle className="w-3 h-3" /> Low Stock ({item.quantity})
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200">
        <CheckCircle2 className="w-3 h-3" /> In Stock ({item.quantity})
      </span>
    );
  };

  return (
    <div className="space-y-4">
      {/* Search & Filter Controls Bar */}
      <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by WIN, UPC, Item name, Brand (Great Value, onn...), or Aisle..."
              className="w-full pl-9 pr-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC] focus:bg-white"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-neutral-400 hover:text-neutral-600"
              >
                Clear
              </button>
            )}
          </div>

          {/* Rollback checkbox, view mode toggle & Add */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setOnlyRollback(!onlyRollback)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 border ${
                onlyRollback
                  ? 'bg-red-600 text-white border-red-700 shadow-xs'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200 border-neutral-200'
              }`}
            >
              <Tag className="w-3.5 h-3.5" />
              Rollbacks Only
            </button>

            <div className="flex items-center bg-neutral-100 p-1 rounded-lg border border-neutral-200">
              <button
                onClick={() => setViewMode('table')}
                title="Table List View"
                className={`p-1.5 rounded-md transition-colors ${
                  viewMode === 'table' ? 'bg-white shadow-2xs text-[#0071DC] font-bold' : 'text-neutral-500 hover:text-neutral-900'
                }`}
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('cards')}
                title="Visual Barcode Grid View"
                className={`p-1.5 rounded-md transition-colors ${
                  viewMode === 'cards' ? 'bg-white shadow-2xs text-[#0071DC] font-bold' : 'text-neutral-500 hover:text-neutral-900'
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={onOpenCreate}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#0071DC] hover:bg-[#005bb5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Modular Asset
            </button>
          </div>
        </div>

        {/* Filter Chips by Department & Status */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-neutral-100 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-neutral-500 font-semibold flex items-center gap-1 mr-1">
              <Filter className="w-3.5 h-3.5 text-[#0071DC]" /> Department:
            </span>
            {WALMART_DEPARTMENTS.map((dept) => (
              <button
                key={dept}
                onClick={() => setSelectedDept(dept)}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  selectedDept === dept
                    ? 'bg-[#0071DC] text-white font-black shadow-2xs'
                    : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200 font-medium'
                }`}
              >
                {dept}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-2.5 py-1 text-xs bg-neutral-50 border border-neutral-300 rounded-md font-semibold text-neutral-700 focus:outline-none"
            >
              <option value="all">All Inventory Statuses</option>
              <option value="in_stock">In Stock (Healthy)</option>
              <option value="low_stock">Low Stock Alerts</option>
              <option value="out_of_stock">Out of Stock</option>
            </select>
          </div>
        </div>
      </div>

      {/* Item View (Table vs Cards) */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-neutral-50 border-b border-neutral-200 text-neutral-600 uppercase tracking-wider text-[11px] font-bold">
                  <th
                    onClick={() => toggleSort('name')}
                    className="py-3 px-4 cursor-pointer hover:bg-neutral-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Item / Brand</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="py-3 px-4">WIN & UPC Barcode</th>
                  <th className="py-3 px-4">Department</th>
                  <th
                    onClick={() => toggleSort('location')}
                    className="py-3 px-4 cursor-pointer hover:bg-neutral-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Modular Aisle</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('quantity')}
                    className="py-3 px-4 cursor-pointer hover:bg-neutral-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Stock Qty</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('price')}
                    className="py-3 px-4 cursor-pointer hover:bg-neutral-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Price ($)</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="py-3 px-4">Shelf Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-neutral-400">
                      No modular items found matching the selected criteria.
                    </td>
                  </tr>
                ) : (
                  filteredItems.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-neutral-50/80 transition-colors group cursor-pointer"
                      onClick={() => onSelectItem(item)}
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-neutral-100 border border-neutral-200 overflow-hidden shrink-0 flex items-center justify-center">
                            {item.imageUrl ? (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                            ) : (
                              <Layers className="w-4 h-4 text-neutral-400" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-extrabold text-neutral-900 group-hover:text-[#0071DC] transition-colors line-clamp-1">
                                {item.name}
                              </span>
                              {item.isRollback && (
                                <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-red-600 text-white shrink-0">
                                  Rollback
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-neutral-500 font-medium">
                              Brand: {item.brand || 'Walmart'} • {item.unitPriceDescription}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-mono">
                        <div className="font-bold text-neutral-800">{item.sku}</div>
                        <div className="text-[11px] text-neutral-500 flex items-center gap-1">
                          <BarcodeIcon className="w-3 h-3 text-neutral-400" />
                          {item.barcode}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="inline-block px-2 py-0.5 rounded bg-blue-50 text-blue-800 font-bold text-[11px]">
                          {item.departmentNumber || 'Dept 95'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-neutral-700 font-medium">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                          <span>{item.location}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => adjustStock(item.id, -1, 'Shelf Dispense -1')}
                            disabled={item.quantity <= 0}
                            className="p-1 rounded bg-neutral-100 hover:bg-amber-100 hover:text-amber-800 text-neutral-600 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                            title="Quick Stock -1"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="font-black text-neutral-900 w-8 text-center text-sm">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => adjustStock(item.id, 1, 'Topstock Restock +1')}
                            className="p-1 rounded bg-neutral-100 hover:bg-emerald-100 hover:text-emerald-800 text-neutral-600 transition-colors"
                            title="Quick Stock +1"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-black text-neutral-900 text-sm">
                          ${item.sellingPrice.toFixed(2)}
                        </div>
                        <div className="text-[10px] text-neutral-400">Cost: ${item.costPrice.toFixed(2)}</div>
                      </td>

                      <td className="py-3.5 px-4">{getStatusBadge(item)}</td>

                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onOpenMovement(item, 'in')}
                            title="DC Truck Receiving / Stock Movement"
                            className="p-1.5 text-neutral-500 hover:text-[#0071DC] hover:bg-blue-50 rounded-lg transition-colors"
                          >
                            <ArrowRightLeft className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onPrintTag(item)}
                            title="Print Walmart Shelf Tag"
                            className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onEditItem(item)}
                            title="Edit Item Details"
                            className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setItemToDelete(item)}
                            title="Delete / Delist Item"
                            className="p-1.5 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Visual Card Grid with scannable barcodes right on the card */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectItem(item)}
              className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs hover:border-[#0071DC] hover:shadow-md transition-all flex flex-col justify-between group cursor-pointer"
            >
              <div>
                {/* Image and badges */}
                <div className="relative h-44 bg-neutral-100 overflow-hidden">
                  {item.imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-neutral-400">
                      <Layers className="w-8 h-8" />
                    </div>
                  )}
                  <div className="absolute top-2.5 left-2.5 flex flex-col gap-1">
                    <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-neutral-900/80 backdrop-blur-xs text-white">
                      {item.departmentNumber || 'Dept 95'}
                    </span>
                    {item.isRollback && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-red-600 text-white shadow-xs">
                        Rollback
                      </span>
                    )}
                  </div>
                  <div className="absolute top-2.5 right-2.5">{getStatusBadge(item)}</div>
                </div>

                {/* Card Info */}
                <div className="p-4 space-y-3">
                  <div>
                    <h4 className="font-extrabold text-neutral-900 text-sm line-clamp-1 group-hover:text-[#0071DC] transition-colors">
                      {item.name}
                    </h4>
                    <p className="text-xs text-neutral-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-neutral-400" />
                      {item.location}
                    </p>
                  </div>

                  {/* Scannable Barcode Preview */}
                  <div className="py-2 px-1 bg-neutral-50 rounded-lg flex flex-col items-center border border-neutral-100">
                    <BarcodeGenerator
                      value={item.barcode}
                      width={180}
                      height={40}
                      showText={true}
                      className="bg-transparent border-none shadow-none p-0"
                    />
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 border-t border-neutral-100">
                    <div>
                      <span className="text-neutral-500 text-[11px]">Shelf Count</span>
                      <p className="font-black text-neutral-900 text-base leading-tight">
                        {item.quantity}{' '}
                        <span className="text-xs font-normal text-neutral-500">units</span>
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-neutral-500 text-[11px]">Everyday Low Price</span>
                      <p className="font-black text-[#0071DC] text-lg leading-tight">
                        ${item.sellingPrice.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action buttons footer */}
              <div
                className="px-4 py-2.5 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => adjustStock(item.id, -1, 'Card Quick -1')}
                    disabled={item.quantity <= 0}
                    className="p-1 rounded bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 disabled:opacity-30"
                    title="Stock -1"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => adjustStock(item.id, 1, 'Card Quick +1')}
                    className="p-1 rounded bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700"
                    title="Stock +1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onOpenMovement(item, 'in')}
                    className="p-1.5 text-neutral-600 hover:text-[#0071DC] rounded hover:bg-neutral-200"
                    title="Stock Movement / DC Receiving"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onPrintTag(item)}
                    className="p-1.5 text-neutral-600 hover:text-neutral-900 rounded hover:bg-neutral-200"
                    title="Print shelf tag"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onEditItem(item)}
                    className="p-1.5 text-neutral-600 hover:text-neutral-900 rounded hover:bg-neutral-200"
                    title="Edit item"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-5 border border-neutral-200 animate-scale-in">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mb-3">
              <Trash2 className="w-5 h-5" />
            </div>
            <h3 className="font-extrabold text-neutral-900 text-base">Delist Asset from Modular?</h3>
            <p className="text-xs text-neutral-600 mt-1">
              Are you sure you want to remove <strong>{itemToDelete.name}</strong> ({itemToDelete.sku}) from Supercenter active inventory? This will be recorded in the live Firebase audit log.
            </p>
            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                onClick={() => setItemToDelete(null)}
                className="px-3.5 py-1.5 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  deleteItem(itemToDelete.id);
                  setItemToDelete(null);
                }}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors shadow-2xs"
              >
                Confirm Delist
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
