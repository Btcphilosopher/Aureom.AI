'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { soundFX } from '@/lib/audio';
import { useInventory } from '@/context/InventoryContext';
import { InventoryItem, ScanAction } from '@/types/inventory';
import { WalmartSparkLogo } from './WalmartSparkLogo';
import { 
  Camera, 
  X, 
  Zap, 
  Plus, 
  Minus, 
  Search, 
  Upload, 
  AlertCircle, 
  CheckCircle2, 
  Volume2, 
  RefreshCw,
  Barcode as BarcodeIcon,
  Package,
  Tag
} from 'lucide-react';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onItemSelect?: (item: InventoryItem) => void;
  defaultAction?: ScanAction;
}

export function BarcodeScannerModal({
  isOpen,
  onClose,
  onItemSelect,
  defaultAction = 'view',
}: BarcodeScannerModalProps) {
  const { items, findItemByBarcode, adjustStock } = useInventory();
  const [scanAction, setScanAction] = useState<ScanAction>(defaultAction);
  const [manualCode, setManualCode] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [lastScannedItem, setLastScannedItem] = useState<InventoryItem | null>(null);
  const [scanSuccessFeedback, setScanSuccessFeedback] = useState<string | null>(null);
  const [continuousCount, setContinuousCount] = useState(0);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const readerElementId = 'walmart-camera-viewport';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const manualInputRef = useRef<HTMLInputElement>(null);

  // Process detected barcode or WIN
  const handleBarcodeDetected = useCallback(
    async (code: string) => {
      const cleanCode = code.trim();
      if (!cleanCode) return;

      const item = findItemByBarcode(cleanCode);

      if (item) {
        soundFX.playScanSuccess();
        setLastScannedItem(item);

        if (scanAction === 'stock_in_one') {
          await adjustStock(item.id, 1, 'Me@Walmart Scanner Restock (+1)');
          setScanSuccessFeedback(`Restocked +1 to ${item.name} (New Shelf Count: ${item.quantity + 1})`);
          setContinuousCount((prev) => prev + 1);
        } else if (scanAction === 'stock_out_one') {
          if (item.quantity > 0) {
            await adjustStock(item.id, -1, 'Me@Walmart Customer Pick (-1)');
            setScanSuccessFeedback(`Dispensed -1 from ${item.name} (New Shelf Count: ${item.quantity - 1})`);
            setContinuousCount((prev) => prev + 1);
          } else {
            soundFX.playScanError();
            setScanSuccessFeedback(`Item is already at 0 stock!`);
          }
        } else {
          setScanSuccessFeedback(`Found: ${item.name} [${item.sku}]`);
          if (onItemSelect) {
            onItemSelect(item);
          }
        }
      } else {
        soundFX.playScanError();
        setLastScannedItem(null);
        setScanSuccessFeedback(`UPC "${cleanCode}" not in Store #1001 modular.`);
      }

      setTimeout(() => {
        setScanSuccessFeedback(null);
      }, 3500);
    },
    [findItemByBarcode, adjustStock, scanAction, onItemSelect]
  );

  // Start Camera
  const startCamera = useCallback(async () => {
    setCameraError(null);
    try {
      if (scannerRef.current) {
        try {
          await scannerRef.current.stop();
        } catch {
          // ignore
        }
      }

      const html5QrCode = new Html5Qrcode(readerElementId, {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.QR_CODE,
        ],
        verbose: false,
      });
      scannerRef.current = html5QrCode;

      const config = {
        fps: 15,
        qrbox: { width: 280, height: 180 },
        aspectRatio: 1.333,
      };

      await html5QrCode.start(
        { facingMode: 'environment' },
        config,
        (decodedText) => {
          handleBarcodeDetected(decodedText);
        },
        () => {}
      );

      setCameraActive(true);
    } catch (err: unknown) {
      console.warn('Camera failed:', err);
      setCameraActive(false);
      setCameraError('Camera access unavailable or sandboxed. Use the instant test UPC barcodes or photo upload below.');
    }
  }, [handleBarcodeDetected]);

  // Stop Camera
  const stopCamera = useCallback(async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
      } catch {
        // ignore
      }
      scannerRef.current = null;
    }
    setCameraActive(false);
  }, []);

  useEffect(() => {
    if (isOpen) {
      const t = setTimeout(() => {
        startCamera();
        if (manualInputRef.current) {
          manualInputRef.current.focus();
        }
      }, 300);
      return () => clearTimeout(t);
    } else {
      stopCamera();
    }
  }, [isOpen, startCamera, stopCamera]);

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  // Image file upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const html5QrCode = new Html5Qrcode('temp-walmart-file-scanner');
      const result = await html5QrCode.scanFile(file, true);
      handleBarcodeDetected(result);
    } catch {
      soundFX.playScanError();
      setScanSuccessFeedback('Could not detect a clear barcode in this photo.');
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    handleBarcodeDetected(manualCode.trim());
    setManualCode('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div id="temp-walmart-file-scanner" className="hidden" />

      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-blue-600 bg-[#0071DC] text-white">
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-white/10 rounded-lg">
              <WalmartSparkLogo size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-lg leading-tight">Me@Walmart Asset Scanner</h3>
                <span className="px-2 py-0.5 text-[10px] font-black tracking-wider uppercase rounded-full bg-[#FFC220] text-neutral-900">
                  Store #1001
                </span>
              </div>
              <p className="text-xs text-blue-100">Live barcode reader for shelf audit, topstock, and price verify</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-blue-200 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Mode Selector Bar */}
        <div className="px-6 py-3 bg-neutral-50 border-b border-neutral-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <span className="font-bold text-neutral-700 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-[#0071DC]" />
            Scan Action:
          </span>
          <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-neutral-200 shadow-2xs">
            <button
              onClick={() => setScanAction('view')}
              className={`px-3 py-1.5 rounded-md font-bold transition-colors flex items-center gap-1.5 ${
                scanAction === 'view'
                  ? 'bg-[#0071DC] text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              Price Check & Mod
            </button>
            <button
              onClick={() => setScanAction('stock_in_one')}
              className={`px-3 py-1.5 rounded-md font-bold transition-colors flex items-center gap-1.5 ${
                scanAction === 'stock_in_one'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              Topstock Restock (+1)
            </button>
            <button
              onClick={() => setScanAction('stock_out_one')}
              className={`px-3 py-1.5 rounded-md font-bold transition-colors flex items-center gap-1.5 ${
                scanAction === 'stock_out_one'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Minus className="w-3.5 h-3.5" />
              Shelf Pick (-1)
            </button>
          </div>
          {continuousCount > 0 && (
            <span className="text-emerald-800 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Scanned count: {continuousCount}
            </span>
          )}
        </div>

        {/* Feedback Alert */}
        {scanSuccessFeedback && (
          <div className="px-6 py-2.5 bg-blue-50 border-b border-blue-100 flex items-center justify-between text-xs text-blue-900 animate-fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#0071DC] shrink-0" />
              <span className="font-bold">{scanSuccessFeedback}</span>
            </div>
            <Volume2 className="w-3.5 h-3.5 text-[#0071DC] animate-pulse" />
          </div>
        )}

        {/* Viewport & Controls */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          <div className="relative rounded-xl overflow-hidden bg-neutral-950 border-2 border-neutral-800 shadow-inner min-h-[230px] flex flex-col items-center justify-center">
            <div
              id={readerElementId}
              className={`w-full max-w-md ${cameraActive ? 'block' : 'hidden'}`}
            />

            {!cameraActive && (
              <div className="p-6 text-center text-neutral-300 max-w-sm">
                <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-400">
                  <Camera className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-white mb-1">
                  Camera Standby / Sandbox Environment
                </h4>
                <p className="text-xs text-neutral-400 mb-4">
                  {cameraError || 'Point camera at any UPC barcode, or click the sample Walmart items below.'}
                </p>
                <div className="flex items-center justify-center gap-2">
                  <button
                    onClick={startCamera}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#0071DC] hover:bg-[#005bb5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Retry Camera
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-bold border border-neutral-700 transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Upload Image
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
              </div>
            )}

            {cameraActive && (
              <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
                <div className="w-64 h-36 border-2 border-[#FFC220] rounded-xl relative shadow-[0_0_20px_rgba(255,194,32,0.4)]">
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-white -mt-0.5 -ml-0.5" />
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-white -mt-0.5 -mr-0.5" />
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-white -mb-0.5 -ml-0.5" />
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-white -mb-0.5 -mr-0.5" />
                  <div className="absolute inset-x-0 top-1/2 h-0.5 bg-red-500/80 shadow-[0_0_8px_red] animate-pulse" />
                </div>
                <span className="text-[11px] text-yellow-300 font-bold mt-3 bg-neutral-900/90 px-2 py-0.5 rounded-full">
                  Align UPC Barcode
                </span>
              </div>
            )}
          </div>

          {/* Last Scanned Item Card Preview */}
          {lastScannedItem && (
            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/70 flex items-center justify-between gap-4 animate-scale-in">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-white border border-blue-200 overflow-hidden shrink-0 flex items-center justify-center">
                  {lastScannedItem.imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={lastScannedItem.imageUrl}
                      alt={lastScannedItem.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Package className="w-6 h-6 text-[#0071DC]" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h5 className="font-extrabold text-neutral-900 text-sm">{lastScannedItem.name}</h5>
                    {lastScannedItem.isRollback && (
                      <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-red-600 text-white">
                        Rollback
                      </span>
                    )}
                    <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-neutral-200 text-neutral-700 font-bold">
                      {lastScannedItem.sku}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-600 mt-0.5">
                    Mod Location: <strong className="text-neutral-900">{lastScannedItem.location}</strong> • Stock:{' '}
                    <strong className="text-[#0071DC]">{lastScannedItem.quantity} units</strong> • Price: ${lastScannedItem.sellingPrice.toFixed(2)}
                  </p>
                </div>
              </div>

              {onItemSelect && (
                <button
                  onClick={() => {
                    onItemSelect(lastScannedItem);
                    onClose();
                  }}
                  className="px-3.5 py-1.5 bg-[#0071DC] hover:bg-[#005bb5] text-white rounded-lg text-xs font-bold transition-colors shrink-0 shadow-2xs"
                >
                  Open Item
                </button>
              )}
            </div>
          )}

          {/* Manual Input or Handheld Laser Scanner Wedge */}
          <form onSubmit={handleManualSubmit} className="space-y-1.5">
            <label className="block text-xs font-bold text-neutral-700">
              Manual Barcode / Zebra Scanner Wedge Input (Press Enter):
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <BarcodeIcon className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  ref={manualInputRef}
                  type="text"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder="e.g. 078742351890 or WIN-55102001"
                  className="w-full pl-9 pr-4 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0071DC] focus:bg-white font-mono font-bold"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold transition-colors"
              >
                Scan Code
              </button>
            </div>
          </form>

          {/* Instant Click-to-Test Barcode Palette for Walmart Products */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-extrabold text-neutral-700 flex items-center gap-1.5">
                <BarcodeIcon className="w-3.5 h-3.5 text-[#0071DC]" />
                Walmart Shelf Items (Click any sample to test scan):
              </span>
              <span className="text-[11px] text-neutral-500 font-medium">Store #1001 Catalog</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {items.slice(0, 8).map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleBarcodeDetected(item.barcode)}
                  className="p-2 text-left bg-neutral-50 hover:bg-blue-50/80 hover:border-blue-300 border border-neutral-200 rounded-lg transition-all group"
                >
                  <p className="text-[11px] font-bold text-neutral-900 truncate group-hover:text-[#0071DC]">
                    {item.name}
                  </p>
                  <p className="text-[10px] font-mono text-neutral-500 truncate mt-0.5">
                    {item.barcode}
                  </p>
                  <div className="flex items-center justify-between mt-1 text-[9px]">
                    <span className="font-extrabold text-[#0071DC]">${item.sellingPrice.toFixed(2)}</span>
                    <span className="text-neutral-500">Qty: {item.quantity}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between text-xs text-neutral-500">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span className="font-medium">Decodes UPC-A, UPC-E, EAN-13, Code-128</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-neutral-300 hover:bg-neutral-100 rounded-lg text-neutral-700 font-semibold transition-colors"
          >
            Done Scanning
          </button>
        </div>
      </div>
    </div>
  );
}
