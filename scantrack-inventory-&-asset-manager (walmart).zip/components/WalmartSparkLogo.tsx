'use client';

import React from 'react';

interface WalmartSparkLogoProps {
  className?: string;
  size?: number;
}

export function WalmartSparkLogo({ className = '', size = 28 }: WalmartSparkLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Walmart Spark"
    >
      {/* 6 radial spark petals rotated at 60deg intervals */}
      <g fill="#FFC220">
        {/* Top (0 deg) */}
        <path d="M50 8C47.2 8 45 10.2 45 13V33C45 35.8 47.2 38 50 38C52.8 38 55 35.8 55 33V13C55 10.2 52.8 8 50 8Z" rx="5" />
        {/* 60 deg */}
        <g transform="rotate(60 50 50)">
          <path d="M50 8C47.2 8 45 10.2 45 13V33C45 35.8 47.2 38 50 38C52.8 38 55 35.8 55 33V13C55 10.2 52.8 8 50 8Z" rx="5" />
        </g>
        {/* 120 deg */}
        <g transform="rotate(120 50 50)">
          <path d="M50 8C47.2 8 45 10.2 45 13V33C45 35.8 47.2 38 50 38C52.8 38 55 35.8 55 33V13C55 10.2 52.8 8 50 8Z" rx="5" />
        </g>
        {/* 180 deg */}
        <g transform="rotate(180 50 50)">
          <path d="M50 8C47.2 8 45 10.2 45 13V33C45 35.8 47.2 38 50 38C52.8 38 55 35.8 55 33V13C55 10.2 52.8 8 50 8Z" rx="5" />
        </g>
        {/* 240 deg */}
        <g transform="rotate(240 50 50)">
          <path d="M50 8C47.2 8 45 10.2 45 13V33C45 35.8 47.2 38 50 38C52.8 38 55 35.8 55 33V13C55 10.2 52.8 8 50 8Z" rx="5" />
        </g>
        {/* 300 deg */}
        <g transform="rotate(300 50 50)">
          <path d="M50 8C47.2 8 45 10.2 45 13V33C45 35.8 47.2 38 50 38C52.8 38 55 35.8 55 33V13C55 10.2 52.8 8 50 8Z" rx="5" />
        </g>
      </g>
    </svg>
  );
}
