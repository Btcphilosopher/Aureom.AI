'use client';

import React from 'react';
import { useInventory } from '@/context/InventoryContext';
import { WalmartSparkLogo } from './WalmartSparkLogo';
import { 
  Camera, 
  Package, 
  BarChart3, 
  History, 
  MapPin,
  Database,
  LogIn,
  LogOut,
  Sparkles
} from 'lucide-react';

interface NavbarProps {
  activeTab: 'overview' | 'catalog' | 'audit';
  setActiveTab: (tab: 'overview' | 'catalog' | 'audit') => void;
  onOpenScanner: () => void;
  onOpenUserModal: () => void;
}

export function Navbar({
  activeTab,
  setActiveTab,
  onOpenScanner,
  onOpenUserModal,
}: NavbarProps) {
  const { currentUser, firebaseUser, signInWithGoogle, isFirestoreSyncing } = useInventory();

  return (
    <header className="sticky top-0 z-40 bg-[#0071DC] text-white shadow-md border-b border-[#005bb5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand Logo & Store Info */}
          <div className="flex items-center gap-5">
            <div
              onClick={() => setActiveTab('overview')}
              className="flex items-center gap-2 cursor-pointer group"
            >
              <div className="p-1 rounded-lg group-hover:scale-105 transition-transform">
                <WalmartSparkLogo size={32} />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-xl tracking-tight text-white font-sans">
                    Walmart
                  </span>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider px-1.5 py-0.5 rounded bg-[#FFC220] text-neutral-900">
                    Store #1001
                  </span>
                </div>
                <p className="text-[10px] text-blue-100 font-medium -mt-0.5 flex items-center gap-1">
                  <MapPin className="w-2.5 h-2.5 text-[#FFC220]" />
                  Bentonville Supercenter • Inventory Control
                </p>
              </div>
            </div>

            {/* Main Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1 bg-[#005bb5]/80 p-1 rounded-xl border border-blue-400/30">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'overview'
                    ? 'bg-white text-[#0071DC] shadow-xs'
                    : 'text-blue-100 hover:text-white hover:bg-white/10'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                Store Overview
              </button>

              <button
                onClick={() => setActiveTab('catalog')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'catalog'
                    ? 'bg-white text-[#0071DC] shadow-xs'
                    : 'text-blue-100 hover:text-white hover:bg-white/10'
                }`}
              >
                <Package className="w-3.5 h-3.5" />
                Modular Catalog
              </button>

              <button
                onClick={() => setActiveTab('audit')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'audit'
                    ? 'bg-white text-[#0071DC] shadow-xs'
                    : 'text-blue-100 hover:text-white hover:bg-white/10'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                Audit Trail
              </button>
            </nav>
          </div>

          {/* Right Action Utilities */}
          <div className="flex items-center gap-2.5">
            {/* Live Firebase Firestore Status Pill */}
            <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-300/30 text-emerald-100 text-[11px] font-semibold">
              <span className={`w-2 h-2 rounded-full ${isFirestoreSyncing ? 'bg-amber-400 animate-spin' : 'bg-emerald-400 animate-pulse'}`} />
              <span>Firebase Firestore Live</span>
            </div>

            {/* Quick Barcode Scanner Button ("Me@Walmart Scan") */}
            <button
              onClick={onOpenScanner}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-[#FFC220] hover:bg-[#ffcd38] text-neutral-900 rounded-xl text-xs font-black shadow-xs transition-all transform active:scale-95"
            >
              <Camera className="w-4 h-4 text-neutral-900" />
              <span className="hidden sm:inline">Me@Walmart Scan</span>
            </button>

            {/* User Profile / Google Sign-In Switcher */}
            <button
              onClick={onOpenUserModal}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 transition-all text-left"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-7 h-7 rounded-full object-cover border border-white/40"
              />
              <div className="hidden sm:block text-left">
                <span className="font-bold text-xs text-white block leading-tight">
                  {currentUser.name}
                </span>
                <span className="text-[10px] text-blue-200 font-medium block truncate max-w-[130px]">
                  {currentUser.department}
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Tab bar */}
        <div className="md:hidden flex items-center justify-between py-2 border-t border-blue-400/30 text-xs">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex-1 py-1 text-center font-bold ${
              activeTab === 'overview' ? 'text-white border-b-2 border-[#FFC220]' : 'text-blue-200'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('catalog')}
            className={`flex-1 py-1 text-center font-bold ${
              activeTab === 'catalog' ? 'text-white border-b-2 border-[#FFC220]' : 'text-blue-200'
            }`}
          >
            Catalog
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`flex-1 py-1 text-center font-bold ${
              activeTab === 'audit' ? 'text-white border-b-2 border-[#FFC220]' : 'text-blue-200'
            }`}
          >
            Audit Trail
          </button>
        </div>
      </div>
    </header>
  );
}
