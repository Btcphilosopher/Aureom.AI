package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AssistMode
import com.example.core.EBikeCoreEngine
import com.example.core.RegenLevel
import com.example.core.RideScenario
import com.example.core.VehicleState
import com.example.data.AppDatabase
import com.example.data.TripEntity
import com.example.data.TripRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EBikeViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = TripRepository(database.tripDao())

    val engine = EBikeCoreEngine(application, repository)
    val vehicleState: StateFlow<VehicleState> = engine.vehicleState

    // Trip logs from Database
    val tripHistory: StateFlow<List<TripEntity>> = repository.allTrips
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val canLogs: StateFlow<List<String>> = engine.canLog

    init {
        // Start automatic trip log tracking on boot
        engine.startTrip()
    }

    fun selectAssistMode(mode: AssistMode) {
        engine.activeAssistMode = mode
    }

    fun selectRegenLevel(level: RegenLevel) {
        engine.activeRegenLevel = level
    }

    fun updateRiderInputs(cadence: Double, torque: Double) {
        engine.riderTargetCadenceRpm = cadence
        engine.riderTargetTorqueNm = torque
    }

    fun updateBrakePressure(pressure: Double) {
        engine.simulatedBrakePressurePercent = pressure
    }

    fun updateGradient(gradient: Double) {
        engine.targetGradientPercent = gradient
    }

    fun applyRideScenario(scenario: RideScenario) {
        engine.applyRideScenario(scenario)
    }

    fun injectFault(fault: String) {
        engine.injectFault(fault)
    }

    fun clearFault(fault: String) {
        engine.clearFault(fault)
    }

    fun clearAllFaults() {
        engine.clearAllFaults()
    }

    fun triggerTripSave() {
        engine.endTrip()
        engine.startTrip() // start new trip immediately
    }

    fun deleteTrip(id: Int) {
        viewModelScope.launch {
            repository.deleteTrip(id)
        }
    }

    fun clearAllTrips() {
        viewModelScope.launch {
            repository.clearAllTrips()
        }
    }

    override fun onCleared() {
        super.onCleared()
        engine.endTrip()
    }


}
