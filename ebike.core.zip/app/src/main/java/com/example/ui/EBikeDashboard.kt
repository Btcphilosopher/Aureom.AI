package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsBike
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.*
import com.example.data.TripEntity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EBikeDashboardApp(viewModel: EBikeViewModel) {
    val state by viewModel.vehicleState.collectAsStateWithLifecycle()
    val tripHistory by viewModel.tripHistory.collectAsStateWithLifecycle()
    val canLogs by viewModel.canLogs.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(DashboardTab.RIDING) }
    var showSimulatorConfig by remember { mutableStateOf(true) }
    var showQuickControls by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize().testTag("dashboard_scaffold"),
        topBar = {
            DashboardHeader(
                state = state,
                activeTab = activeTab,
                onTabSelected = { activeTab = it },
                onQuickControlsToggle = { showQuickControls = !showQuickControls }
            )
        },
        bottomBar = {
            if (showSimulatorConfig) {
                SimulatorControlPanel(
                    viewModel = viewModel,
                    state = state,
                    onCollapseToggle = { showSimulatorConfig = false }
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NearBlack)
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    contentAlignment = Alignment.CenterEnd
                ) {
                    Button(
                        onClick = { showSimulatorConfig = true },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkGrey),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp).testTag("expand_simulator")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Show Simulator",
                            tint = WarmWhite,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "DEVELOPER SIMULATOR", 
                            color = WarmWhite, 
                            fontSize = 11.sp, 
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        },
        containerColor = NearBlack
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Screen content switching based on Tab
            AnimatedContent(
                targetState = activeTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "screen_transition"
            ) { tab ->
                when (tab) {
                    DashboardTab.RIDING -> HomeRidingScreen(state)
                    DashboardTab.RIDE_MODES -> RideModeScreen(state, viewModel)
                    DashboardTab.ENERGY -> EnergyScreen(state, viewModel)
                    DashboardTab.BMS -> BmsScreen(state)
                    DashboardTab.DIAGNOSTICS -> DiagnosticsScreen(state, canLogs, viewModel)
                    DashboardTab.NAVIGATION -> NavigationScreen(state)
                    DashboardTab.TRIPS -> TripHistoryScreen(tripHistory, viewModel)
                }
            }

            // Quick Settings Overlay Dropdown (Swipe-Down alternative)
            if (showQuickControls) {
                QuickControlsOverlay(
                    state = state,
                    viewModel = viewModel,
                    onDismiss = { showQuickControls = false }
                )
            }
        }
    }
}

enum class DashboardTab(val label: String, val icon: ImageVector) {
    RIDING("HOME", Icons.Default.Speed),
    RIDE_MODES("ASSIST", Icons.Default.ElectricBike),
    ENERGY("REGEN", Icons.Default.SwapCalls),
    BMS("BATTERY", Icons.Default.BatteryChargingFull),
    DIAGNOSTICS("DIAG", Icons.Default.DeveloperMode),
    NAVIGATION("NAV", Icons.Default.Navigation),
    TRIPS("TRIPS", Icons.Default.History)
}

// ==========================================
// COMPONENT: HEADER / NAVIGATION BAR
// ==========================================
@Composable
fun DashboardHeader(
    state: VehicleState,
    activeTab: DashboardTab,
    onTabSelected: (DashboardTab) -> Unit,
    onQuickControlsToggle: () -> Unit
) {
    Surface(
        color = Graphite,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = DarkGrey)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand Logo & System Status Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "EBIKE.CORE",
                    color = WarmWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.5.sp
                )

                // Safety Status LED
                val statusColor = when (state.safetyState) {
                    SafetyState.NORMAL -> EngineeringGreen
                    SafetyState.DEGRADED -> EngineeringAmber
                    SafetyState.LIMITED -> EngineeringAmber
                    SafetyState.FAULT -> EngineeringRed
                    SafetyState.SAFE -> EngineeringRed
                }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(statusColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                        .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(statusColor)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        state.safetyState.name,
                        color = statusColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Central Tab Navigation
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.Center
            ) {
                DashboardTab.values().forEach { tab ->
                    val isSelected = activeTab == tab
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) DarkGrey else Color.Transparent)
                            .clickable { onTabSelected(tab) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("tab_${tab.name.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                tint = if (isSelected) InstrumentAmber else RestrainedGrey,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                tab.label,
                                color = if (isSelected) WarmWhite else RestrainedGrey,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Quick Control Trigger (battery + clock)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Heartbeat simulation indicator
                Text(
                    "CAN: OK",
                    color = EngineeringGreen,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(DarkGrey)
                        .clickable { onQuickControlsToggle() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("quick_controls_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "BMS State",
                        tint = InstrumentAmber,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        "${state.batterySocPercent.toInt()}%",
                        color = WarmWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: PRIMARY HOME RIDING SCREEN
// ==========================================
@Composable
fun HomeRidingScreen(state: VehicleState) {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // LEFT COLUMN: Massive Speedometer readouts
        Box(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(12.dp))
                .background(Graphite)
                .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header (Mode and status)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.DirectionsBike,
                            contentDescription = "Drive Engine",
                            tint = RestrainedGrey,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            "DRIVE SYSTEM",
                            color = RestrainedGrey,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }

                    val modeColor = when (state.assistMode) {
                        AssistMode.OFF -> RestrainedGrey
                        AssistMode.ECO -> EngineeringGreen
                        AssistMode.TOUR -> InstrumentAmber
                        AssistMode.SPORT -> Color(0xFFF97316)
                        AssistMode.BOOST -> EngineeringRed
                        AssistMode.CUSTOM -> Color(0xFFA855F7)
                    }
                    Text(
                        state.assistMode.name,
                        color = modeColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .background(modeColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .border(1.dp, modeColor.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                // Speed display
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = String.format(Locale.US, "%.1f", state.speedKmh),
                        color = WarmWhite,
                        fontSize = 90.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = (-2).sp,
                        modifier = Modifier.testTag("speedometer_value")
                    )
                    Text(
                        "KM/H",
                        color = RestrainedGrey,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 3.sp
                    )
                }

                // Traction slip status message
                Box(
                    modifier = Modifier.fillMaxWidth().height(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (state.tractionControlActive) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .background(EngineeringAmber.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = "Slip", tint = EngineeringAmber, modifier = Modifier.size(10.dp))
                            Text(
                                "TRACTION CONTROL ACTIVE (-70% TORQUE SLIP REDUCTION)", 
                                color = EngineeringAmber, 
                                fontSize = 8.sp, 
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.fillMaxSize())
                    }
                }

                // Bottom strip of speed subdata
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SubValueDisplay("CADENCE", "${state.cadenceRpm.toInt()} RPM")
                    SubValueDisplay("GRADIENT", "${String.format("%.1f", state.roadGradientPercent)}%")
                    SubValueDisplay("RANGE", "${state.estimatedRangeMinKm.toInt()}-${state.estimatedRangeMaxKm.toInt()} KM")
                }
            }
        }

        // RIGHT COLUMN: Range and Power balances
        Column(
            modifier = Modifier
                .weight(0.7f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Battery Status Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Graphite),
                modifier = Modifier
                    .weight(1.0f)
                    .fillMaxWidth()
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "BATTERY ENERGY",
                            color = RestrainedGrey,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(
                            imageVector = Icons.Default.Thermostat,
                            contentDescription = "Temperature",
                            tint = if (state.batteryTempC > 45.0) EngineeringRed else RestrainedGrey,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            "${state.batterySocPercent.toInt()}",
                            color = WarmWhite,
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "%",
                            color = RestrainedGrey,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }

                    // Progress Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(DarkGrey)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(fraction = (state.batterySocPercent.toFloat() / 100f).coerceIn(0f, 1f))
                                .background(if (state.batterySocPercent < 20.0) EngineeringRed else EngineeringGreen)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("TEMP", color = RestrainedGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("${state.batteryTempC.toInt()}°C", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("VOLTS", color = RestrainedGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("${String.format("%.1f", state.batteryVoltageVolts)}V", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            // Realtime Power balance Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Graphite),
                modifier = Modifier
                    .weight(1.0f)
                    .fillMaxWidth()
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "POWER BALANCE",
                        color = RestrainedGrey,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    // Vertical bars representing Rider Power vs Motor Power
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(0.3f)
                                    .background(DarkGrey, RoundedCornerShape(2.dp)),
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight((state.riderPowerW / 400.0).toFloat().coerceIn(0f, 1f))
                                        .background(WarmWhite, RoundedCornerShape(2.dp))
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("RIDER", color = RestrainedGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("${state.riderPowerW.toInt()}W", color = WarmWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }

                        Column(
                            modifier = Modifier.weight(1f),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(0.3f)
                                    .background(DarkGrey, RoundedCornerShape(2.dp)),
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                val barColor = if (state.isRegenerating) EngineeringGreen else InstrumentAmber
                                val fillFraction = if (state.isRegenerating) {
                                    (state.regenPowerW / 400.0).toFloat().coerceIn(0f, 1f)
                                } else {
                                    (abs(state.motorPowerElectricalW) / 750.0).toFloat().coerceIn(0f, 1f)
                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight(fillFraction)
                                        .background(barColor, RoundedCornerShape(2.dp))
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(if (state.isRegenerating) "REGEN" else "MOTOR", color = RestrainedGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                if (state.isRegenerating) "${state.regenPowerW.toInt()}W" else "${abs(state.motorPowerElectricalW).toInt()}W",
                                color = if (state.isRegenerating) EngineeringGreen else InstrumentAmber,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("EFFICIENCY", color = RestrainedGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        Text("${state.motorEfficiencyPercent.toInt()}%", color = EngineeringGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
fun SubValueDisplay(label: String, value: String) {
    Column {
        Text(
            label,
            color = RestrainedGrey,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            value,
            color = WarmWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

// ==========================================
// COMPONENT: RIDE MODE SELECTION / CONFIG
// ==========================================
@Composable
fun RideModeScreen(state: VehicleState, viewModel: EBikeViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "PEDAL-ASSIST & PROPULSION ENGINE",
            color = WarmWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Column: Active list
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistMode.values().forEach { mode ->
                    val isSelected = state.assistMode == mode
                    val modeColor = when (mode) {
                        AssistMode.OFF -> RestrainedGrey
                        AssistMode.ECO -> EngineeringGreen
                        AssistMode.TOUR -> InstrumentAmber
                        AssistMode.SPORT -> Color(0xFFF97316)
                        AssistMode.BOOST -> EngineeringRed
                        AssistMode.CUSTOM -> Color(0xFFA855F7)
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) DarkGrey else Graphite),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectAssistMode(mode) }
                            .border(
                                width = 1.dp,
                                color = if (isSelected) modeColor else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .testTag("mode_${mode.name.lowercase()}"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(modeColor)
                                )
                                Column {
                                    Text(
                                        mode.name,
                                        color = WarmWhite,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    val desc = when (mode) {
                                        AssistMode.OFF -> "0% support, full mechanical drive"
                                        AssistMode.ECO -> "75% support, maximum battery range"
                                        AssistMode.TOUR -> "150% support, daily utility blend"
                                        AssistMode.SPORT -> "250% support, responsive acceleration"
                                        AssistMode.BOOST -> "400% support, maximum electric torque"
                                        AssistMode.CUSTOM -> "Configurable torque & assist multiplier"
                                    }
                                    Text(desc, color = RestrainedGrey, fontSize = 10.sp)
                                }
                            }
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = "Active", tint = modeColor, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            // Right Column: Power Curve Visualizer
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "TORQUE DELIVERY PROFILE",
                        color = RestrainedGrey,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    // Live delivery curves mapping canvas
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 12.dp)
                    ) {
                        val w = size.width
                        val h = size.height

                        // Grid Lines
                        drawRect(color = DarkGrey, size = size, style = Stroke(1f))
                        for (i in 1..4) {
                            val x = w * i / 5f
                            val y = h * i / 5f
                            drawLine(color = DarkGrey.copy(alpha = 0.5f), start = Offset(x, 0f), end = Offset(x, h), strokeWidth = 1f)
                            drawLine(color = DarkGrey.copy(alpha = 0.5f), start = Offset(0f, y), end = Offset(w, y), strokeWidth = 1f)
                        }

                        // Plot curve based on selected mode
                        val path = Path()
                        path.moveTo(0f, h)

                        val exponent = when (state.assistMode) {
                            AssistMode.OFF -> 1.0
                            AssistMode.ECO -> 1.5 // gentle exponential
                            AssistMode.TOUR -> 1.2
                            AssistMode.SPORT -> 1.0 // linear
                            AssistMode.BOOST -> 0.7 // instant aggressive ramp
                            AssistMode.CUSTOM -> 1.1
                        }

                        val maxTorquePercent = when (state.assistMode) {
                            AssistMode.OFF -> 0f
                            AssistMode.ECO -> 0.25f
                            AssistMode.TOUR -> 0.45f
                            AssistMode.SPORT -> 0.70f
                            AssistMode.BOOST -> 1.0f
                            AssistMode.CUSTOM -> 0.60f
                        }

                        for (x in 0..w.toInt() step 5) {
                            val fraction = (x / w).toDouble()
                            val yFraction = (fraction.pow(exponent) * maxTorquePercent).toFloat()
                            val plotY = h - (yFraction * h)
                            path.lineTo(x.toFloat(), plotY)
                        }

                        val strokeColor = when (state.assistMode) {
                            AssistMode.OFF -> RestrainedGrey
                            AssistMode.ECO -> EngineeringGreen
                            AssistMode.TOUR -> InstrumentAmber
                            AssistMode.SPORT -> Color(0xFFF97316)
                            AssistMode.BOOST -> EngineeringRed
                            AssistMode.CUSTOM -> Color(0xFFA855F7)
                        }

                        drawPath(
                            path = path,
                            color = strokeColor,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Max Target Torque", color = RestrainedGrey, fontSize = 10.sp)
                            val tq = when (state.assistMode) {
                                AssistMode.OFF -> 0
                                AssistMode.ECO -> 20
                                AssistMode.TOUR -> 40
                                AssistMode.SPORT -> 60
                                AssistMode.BOOST -> 85
                                AssistMode.CUSTOM -> 50
                            }
                            Text("$tq Nm", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Acceleration Ramp", color = RestrainedGrey, fontSize = 10.sp)
                            val rmp = when (state.assistMode) {
                                AssistMode.OFF -> "0%"
                                AssistMode.ECO -> "Smooth (Linear)"
                                AssistMode.TOUR -> "Balanced"
                                AssistMode.SPORT -> "Progressive"
                                AssistMode.BOOST -> "Instantaneous (Max Surge)"
                                AssistMode.CUSTOM -> "Medium"
                            }
                            Text(rmp, color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: REGENERATIVE BRAKING & ENERGY FLOW
// ==========================================
@Composable
fun EnergyScreen(state: VehicleState, viewModel: EBikeViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "REGENERATIVE ENERGY HARVESTING",
            color = WarmWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // LEFT COLUMN: Energy Flow Animate & State
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "ACTIVE KINETIC TRANSFER PATHWAY",
                        color = RestrainedGrey,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    // Kinetic Transfer Animate Diagram
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            
                            // Draws nodes (Wheel, Motor, Battery)
                            val wheelX = w * 0.15f
                            val motorX = w * 0.50f
                            val battX = w * 0.85f
                            val centerY = h * 0.5f
                            val radius = 25.dp.toPx()

                            // Link lines
                            drawLine(
                                color = if (state.isRegenerating) EngineeringGreen else DarkGrey,
                                start = Offset(wheelX, centerY),
                                end = Offset(motorX, centerY),
                                strokeWidth = 3.dp.toPx()
                            )
                            drawLine(
                                color = if (state.isRegenerating) EngineeringGreen else if (state.motorTorqueNm > 0f) InstrumentAmber else DarkGrey,
                                start = Offset(motorX, centerY),
                                end = Offset(battX, centerY),
                                strokeWidth = 3.dp.toPx()
                            )

                            // Nodes
                            drawCircle(color = Graphite, radius = radius, center = Offset(wheelX, centerY))
                            drawCircle(color = DarkGrey, radius = radius, center = Offset(motorX, centerY), style = Stroke(2f))
                            drawCircle(color = Graphite, radius = radius, center = Offset(battX, centerY))

                            drawCircle(color = WarmWhite, radius = radius - 8f, center = Offset(wheelX, centerY), style = Stroke(3f))
                            drawCircle(color = if (state.isRegenerating) EngineeringGreen else InstrumentAmber, radius = radius - 8f, center = Offset(motorX, centerY))
                            drawCircle(color = if (state.batterySocPercent < 20) EngineeringRed else EngineeringGreen, radius = radius - 8f, center = Offset(battX, centerY))
                        }
                        
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("WHEEL", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.width(60.dp), textAlign = TextAlign.Center)
                            Text("MOTOR/GEN", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.width(80.dp), textAlign = TextAlign.Center)
                            Text("BATTERY", color = WarmWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.width(60.dp), textAlign = TextAlign.Center)
                        }
                    }

                    // Bottom info stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("RECOVERED TODAY", color = RestrainedGrey, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("${String.format("%.3f", state.regeneratedEnergyWh)} Wh", color = EngineeringGreen, fontSize = 16.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ACTIVE REGEN", color = RestrainedGrey, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("${String.format("%.1f", state.regenPowerW / 1000.0)} kW", color = if (state.isRegenerating) EngineeringGreen else RestrainedGrey, fontSize = 16.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            // RIGHT COLUMN: Configuration Levels
            Box(
                modifier = Modifier
                    .weight(0.8f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "REGEN SUSPENSION RESPONSE",
                        color = RestrainedGrey,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        RegenLevel.values().forEach { level ->
                            val isSelected = state.regenLevel == level
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) DarkGrey else Color.Transparent)
                                    .clickable { viewModel.selectRegenLevel(level) }
                                    .border(1.dp, if (isSelected) EngineeringGreen else Color.Transparent, RoundedCornerShape(6.dp))
                                    .padding(10.dp)
                                    .testTag("regen_${level.name.lowercase()}")
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        level.name,
                                        color = if (isSelected) WarmWhite else RestrainedGrey,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    if (isSelected) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(EngineeringGreen)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Charge Limits Warn Message
                    val statusText = when {
                        state.batterySocPercent >= 95.0 -> "REGEN UNAVAILABLE: BATTERY AT CAPACITY LIMIT"
                        state.batteryTempC > 45.0 -> "REGEN REDUCED: THERMAL LIMITS PROTECTING CELLS"
                        state.batteryTempC < 2.0 -> "REGEN LOCKED: COLD LITHIUM PLATING PROTECTION"
                        else -> "REGEN FULLY FUNCTIONAL AND ACTIVE"
                    }
                    val statColor = if (state.batterySocPercent >= 95.0 || state.batteryTempC < 2.0) EngineeringRed else if (state.batteryTempC > 45.0) EngineeringAmber else EngineeringGreen

                    Text(
                        statusText,
                        color = statColor,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(statColor.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                            .border(1.dp, statColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    )
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: BMS / BATTERY MANAGEMENT SYSTEM
// ==========================================
@Composable
fun BmsScreen(state: VehicleState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "BATTERY MANAGEMENT SYSTEM (BMS) TELEMETRY",
            color = WarmWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // LEFT COLUMN: Individual 14 Cells Voltages
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "14S PACK CELL-LEVEL EQUALIZATION",
                            color = RestrainedGrey,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        if (state.isBalancing) {
                            Text(
                                "ACTIVE BALANCING",
                                color = EngineeringGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier
                                    .background(EngineeringGreen.copy(alpha = 0.1f), RoundedCornerShape(2.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Display grid of 14 cell bars
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        state.cellVoltages.forEachIndexed { idx, volts ->
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth()
                                        .background(DarkGrey, RoundedCornerShape(2.dp)),
                                    contentAlignment = Alignment.BottomCenter
                                ) {
                                    val cellFraction = ((volts - 3.0) / 1.25).coerceIn(0.0, 1.0)
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .fillMaxHeight(cellFraction.toFloat())
                                            .background(if (volts < 3.2) EngineeringRed else if (volts > 4.15) EngineeringGreen else InstrumentAmber, RoundedCornerShape(2.dp))
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("C${idx+1}", color = RestrainedGrey, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
                                Text("${String.format("%.2f", volts)}", color = WarmWhite, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    // Details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SubValueDisplay("SOH (HEALTH)", "${state.batterySohPercent.toInt()}%")
                        SubValueDisplay("DISCHARGE POWER LIMIT", "${state.batteryMaxDischargePowerW.toInt()} W")
                        SubValueDisplay("CHARGE REGEN LIMIT", "${state.batteryMaxRegenPowerW.toInt()} W")
                    }
                }
            }

            // RIGHT COLUMN: Pack stats
            Box(
                modifier = Modifier
                    .weight(0.8f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "INTELLIGENT ENERGY SUMMARY",
                        color = RestrainedGrey,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        BmsDetailRow("Pack Voltage", "${String.format("%.2f", state.batteryVoltageVolts)} V")
                        BmsDetailRow("Pack Net Current", "${String.format("%.1f", state.batteryCurrentAmps)} A")
                        BmsDetailRow("Charge Remaining", "${state.batteryRemainingEnergyWh.toInt()} Wh")
                        BmsDetailRow("Total Cycles", "114")
                        BmsDetailRow("Balance Delta", "${String.format("%.3f", (state.cellVoltages.maxOrNull() ?: 0.0) - (state.cellVoltages.minOrNull() ?: 0.0))} V")
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkGrey, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text("BMS THERMAL CRITICAL STATE", color = RestrainedGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                if (state.batteryTempC > 45.0) "DEGRADED ACTIVE DERATING" else "HEALTHY NOMINAL STEADY",
                                color = if (state.batteryTempC > 45.0) EngineeringRed else EngineeringGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BmsDetailRow(label: String, valStr: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = RestrainedGrey, fontSize = 11.sp)
        Text(valStr, color = WarmWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

// ==========================================
// COMPONENT: DIAGNOSTICS & FAULT LAB
// ==========================================
@Composable
fun DiagnosticsScreen(state: VehicleState, logs: List<String>, viewModel: EBikeViewModel) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = CAN Log, 1 = Fault Lab

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "VEHICLE BUS DIAGNOSTICS & TESTING",
                color = WarmWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )

            // Selector
            Row {
                Button(
                    onClick = { selectedTab = 0 },
                    colors = ButtonDefaults.buttonColors(containerColor = if (selectedTab == 0) DarkGrey else Color.Transparent),
                    shape = RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) {
                    Text("CAN LOGGER", color = if (selectedTab == 0) WarmWhite else RestrainedGrey, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
                Button(
                    onClick = { selectedTab = 1 },
                    colors = ButtonDefaults.buttonColors(containerColor = if (selectedTab == 1) DarkGrey else Color.Transparent),
                    shape = RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    modifier = Modifier.testTag("tab_fault_lab")
                ) {
                    Text("FAULT INJECTION LAB", color = if (selectedTab == 1) WarmWhite else RestrainedGrey, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // LEFT BOX: Logs / Lab Switcher
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                if (selectedTab == 0) {
                    // CAN LOG VIEW
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("CAN FD REAL-TIME BUS STREAM", color = RestrainedGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text("VERSION v2.0.4", color = RestrainedGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                        
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .background(NearBlack)
                                .border(1.dp, DarkGrey)
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            items(logs.reversed()) { log ->
                                Text(
                                    text = log,
                                    color = if (log.contains("FAULT") || log.contains("FAIL")) EngineeringRed else if (log.contains("Trip")) EngineeringGreen else RestrainedGrey,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                } else {
                    // FAULT LAB VIEW
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("DEVELOPMENT FAULT INJECTION HUB", color = RestrainedGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)

                        Row(
                            modifier = Modifier.fillMaxWidth().weight(1f).padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                FaultInjectionButton("Torque Sensor Failure", "TORQUE_SENSOR_FAILURE", state.activeFaults, viewModel)
                                FaultInjectionButton("Cadence Sensor Failure", "CADENCE_SENSOR_FAILURE", state.activeFaults, viewModel)
                                FaultInjectionButton("Wheel Sensor Failure", "WHEEL_SENSOR_FAILURE", state.activeFaults, viewModel)
                                FaultInjectionButton("Brake Stuck Fault", "BRAKE_SENSOR_STUCK", state.activeFaults, viewModel)
                            }
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                FaultInjectionButton("Motor Temp Fault", "MOTOR_OVERHEATING", state.activeFaults, viewModel)
                                FaultInjectionButton("Battery Temp Fault", "BATTERY_TEMPERATURE_FAULT", state.activeFaults, viewModel)
                                FaultInjectionButton("Inverter Overcurrent", "OVERCURRENT", state.activeFaults, viewModel)
                                FaultInjectionButton("Dashboard Comm Loss", "COMMUNICATION_LOSS", state.activeFaults, viewModel)
                            }
                        }

                        Button(
                            onClick = { viewModel.clearAllFaults() },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkGrey),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("CLEAR ALL FAULTS (RESET SAFETY OVERRIDE)", color = WarmWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            // RIGHT BOX: Performance Telemetry
            Box(
                modifier = Modifier
                    .weight(0.7f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "CONTROLLER PERFORMANCE",
                        color = RestrainedGrey,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        BmsDetailRow("Loop Rate", "${state.loopFrequencyHz} Hz")
                        BmsDetailRow("Loop Jitter", "${String.format("%.2f", state.loopJitterUs)} µs")
                        BmsDetailRow("CPU Usage", "${String.format("%.1f", state.cpuUsagePercent)}%")
                        BmsDetailRow("RAM Footprint", "${String.format("%.1f", state.ramUsageMb)} MB")
                        BmsDetailRow("Sensor Latency", "${String.format("%.1f", state.sensorLatencyMs)} ms")
                        BmsDetailRow("Dropped CAN Frames", "${state.droppedMessagesCount}")
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkGrey, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text("DETERMINISTIC BENCHMARK", color = RestrainedGrey, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("STATUS: RE_TIME PASS", color = EngineeringGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FaultInjectionButton(label: String, faultCode: String, activeFaults: Set<String>, viewModel: EBikeViewModel) {
    val isFaultActive = activeFaults.contains(faultCode) || 
                       (faultCode == "TORQUE_SENSOR_FAILURE" && activeFaults.contains("TORQUE_SENSOR_FAIL")) ||
                       (faultCode == "CADENCE_SENSOR_FAILURE" && activeFaults.contains("CADENCE_SENSOR_FAIL")) ||
                       (faultCode == "WHEEL_SENSOR_FAILURE" && activeFaults.contains("WHEEL_SENSOR_FAIL")) ||
                       (faultCode == "MOTOR_OVERHEATING" && activeFaults.contains("MOTOR_OVERHEAT")) ||
                       (faultCode == "BATTERY_TEMPERATURE_FAULT" && activeFaults.contains("BATTERY_OVERHEAT"))
    
    val btnColor = if (isFaultActive) EngineeringRed else DarkGrey
    
    Button(
        onClick = {
            if (isFaultActive) {
                viewModel.clearFault(faultCode)
            } else {
                viewModel.injectFault(faultCode)
            }
        },
        colors = ButtonDefaults.buttonColors(containerColor = btnColor),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth().height(36.dp).testTag("inject_${faultCode.lowercase()}"),
        contentPadding = PaddingValues(horizontal = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                label,
                color = WarmWhite,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (isFaultActive) {
                Icon(Icons.Default.Error, contentDescription = "Active", tint = WarmWhite, modifier = Modifier.size(12.dp))
            }
        }
    }
}

// ==========================================
// COMPONENT: NAVIGATION PANEL
// ==========================================
@Composable
fun NavigationScreen(state: VehicleState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "GPS SATELLITE NAVIGATION & ELEVATION PROFILE",
            color = WarmWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Box: Map Mock/Banner
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "BATTERY-AWARE NAVIGATION RANGE ENVELOPE",
                        color = RestrainedGrey,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    // Draw elevation plot
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 12.dp)
                    ) {
                        val w = size.width
                        val h = size.height

                        // Grid Lines
                        drawRect(color = DarkGrey, size = size, style = Stroke(1f))
                        
                        val path = Path()
                        path.moveTo(0f, h * 0.7f)
                        path.quadraticTo(w * 0.3f, h * 0.4f, w * 0.5f, h * 0.8f)
                        path.quadraticTo(w * 0.7f, h * 0.9f, w * 1.0f, h * 0.2f)

                        drawPath(
                            path = path,
                            color = InstrumentAmber,
                            style = Stroke(width = 2.dp.toPx())
                        )

                        // Current Position marker
                        drawCircle(color = EngineeringGreen, radius = 6f, center = Offset(w * 0.4f, h * 0.65f))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SubValueDisplay("DESTINATION", "Marlborough Pass")
                        SubValueDisplay("ROUTE GRADE", "+410 m Elevation")
                        SubValueDisplay("EST. BATT ON ARRIVAL", "31%")
                    }
                }
            }

            // Right Box: Navigation Stats
            Box(
                modifier = Modifier
                    .weight(0.8f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Graphite)
                    .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "ROUTE METRICS",
                        color = RestrainedGrey,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        BmsDetailRow("Distance Left", "34.2 km")
                        BmsDetailRow("Estimated Duration", "1 hr 18 min")
                        BmsDetailRow("Altitude", "${state.altitudeMeters.toInt()} m")
                        BmsDetailRow("Safety Margin", "+12 km")
                        BmsDetailRow("Connected Phone", "iPhone-T14 (BLE)")
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkGrey, RoundedCornerShape(4.dp))
                            .padding(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Navigation, contentDescription = "Active Route", tint = EngineeringGreen, modifier = Modifier.size(12.dp))
                            Text("NAVIGATION ACTIVE", color = EngineeringGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: TRIP HISTORY SCREEN (ROOM)
// ==========================================
@Composable
fun TripHistoryScreen(trips: List<TripEntity>, viewModel: EBikeViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "SAVED TELEMETRY TRIP HISTORY (LOCAL ROOM STORE)",
                color = WarmWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { viewModel.triggerTripSave() },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkGrey),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("SAVE ACTIVE TRIP", color = WarmWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }

                Button(
                    onClick = { viewModel.clearAllTrips() },
                    colors = ButtonDefaults.buttonColors(containerColor = EngineeringRed.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("clear_trips_button")
                ) {
                    Text("CLEAR ALL", color = EngineeringRed, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(12.dp))
                .background(Graphite)
                .border(1.dp, DarkGrey, RoundedCornerShape(12.dp))
                .padding(16.dp)
        ) {
            if (trips.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "No trips",
                        tint = RestrainedGrey,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "NO TRIPS RECORDED YET",
                        color = WarmWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        "Click 'Save Active Trip' or simulate physical speed and stop to store records.",
                        color = RestrainedGrey,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(trips) { trip ->
                        val dateStr = remember(trip.timestamp) {
                            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(trip.timestamp))
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(DarkGrey)
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(dateStr, color = RestrainedGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                        Text("Dist: ${String.format("%.2f", trip.distanceKm)} km", color = WarmWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        Text("Avg: ${String.format("%.1f", trip.avgSpeedKmh)} km/h", color = WarmWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        Text("Max: ${String.format("%.1f", trip.maxSpeedKmh)} km/h", color = WarmWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("Rider: ${trip.riderEnergyWh.toInt()} Wh", color = RestrainedGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text("Motor: ${trip.motorEnergyWh.toInt()} Wh", color = RestrainedGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text("Regen: ${trip.regeneratedEnergyWh.toInt()} Wh", color = EngineeringGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }

                                IconButton(
                                    onClick = { viewModel.deleteTrip(trip.id) },
                                    modifier = Modifier.testTag("delete_trip_${trip.id}")
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = EngineeringRed, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: DEVELOPER SIMULATOR BAR (BOTTOM)
// ==========================================
@Composable
fun SimulatorControlPanel(
    viewModel: EBikeViewModel,
    state: VehicleState,
    onCollapseToggle: () -> Unit
) {
    Surface(
        color = Graphite,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = DarkGrey)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Title & Scenarios Panel
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.Tune, contentDescription = "Simulator Settings", tint = InstrumentAmber, modifier = Modifier.size(18.dp))
                    Text(
                        "CLOSED-LOOP HARDWARE ENVIRONMENT SIMULATOR (HIL LAB)",
                        color = WarmWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Scenario Presets Group
                    RideScenario.values().forEach { scenario ->
                        val isSelected = viewModel.engine.activeScenario == scenario
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) InstrumentAmber else DarkGrey)
                                .clickable { viewModel.applyRideScenario(scenario) }
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                                .testTag("scenario_${scenario.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                scenario.name.replace("_", " "),
                                color = if (isSelected) NearBlack else WarmWhite,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    IconButton(
                        onClick = onCollapseToggle,
                        modifier = Modifier.size(24.dp).testTag("collapse_simulator")
                    ) {
                        Icon(Icons.Default.ExpandMore, contentDescription = "Collapse Settings", tint = RestrainedGrey)
                    }
                }
            }

            // Sliders Row: Rider Effort & Physical Variables
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Col 1: Rider Pedaling Effort
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Rider Input Cadence", color = RestrainedGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("${viewModel.engine.riderTargetCadenceRpm.toInt()} RPM", color = WarmWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = viewModel.engine.riderTargetCadenceRpm.toFloat(),
                        onValueChange = { viewModel.updateRiderInputs(it.toDouble(), viewModel.engine.riderTargetTorqueNm) },
                        valueRange = 0f..120f,
                        colors = SliderDefaults.colors(thumbColor = WarmWhite, activeTrackColor = InstrumentAmber, inactiveTrackColor = DarkGrey),
                        modifier = Modifier.height(20.dp).testTag("cadence_slider")
                    )
                }

                // Col 2: Rider Input Torque
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Rider Pedal Torque", color = RestrainedGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("${viewModel.engine.riderTargetTorqueNm.toInt()} Nm", color = WarmWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = viewModel.engine.riderTargetTorqueNm.toFloat(),
                        onValueChange = { viewModel.updateRiderInputs(viewModel.engine.riderTargetCadenceRpm, it.toDouble()) },
                        valueRange = 0f..60f,
                        colors = SliderDefaults.colors(thumbColor = WarmWhite, activeTrackColor = InstrumentAmber, inactiveTrackColor = DarkGrey),
                        modifier = Modifier.height(20.dp).testTag("torque_slider")
                    )
                }

                // Col 3: Brake Lever Pressure
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Simulated Brake Lever Pressure", color = RestrainedGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("${viewModel.engine.simulatedBrakePressurePercent.toInt()}%", color = if (state.isRegenerating) EngineeringGreen else EngineeringRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = viewModel.engine.simulatedBrakePressurePercent.toFloat(),
                        onValueChange = { viewModel.updateBrakePressure(it.toDouble()) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = WarmWhite, activeTrackColor = if (state.isRegenerating) EngineeringGreen else EngineeringRed, inactiveTrackColor = DarkGrey),
                        modifier = Modifier.height(20.dp).testTag("brake_slider")
                    )
                }

                // Col 4: Road Gradient
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Simulated Slope Grade", color = RestrainedGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("${viewModel.engine.targetGradientPercent.toInt()}%", color = WarmWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = viewModel.engine.targetGradientPercent.toFloat(),
                        onValueChange = { viewModel.updateGradient(it.toDouble()) },
                        valueRange = -20f..20f,
                        colors = SliderDefaults.colors(thumbColor = WarmWhite, activeTrackColor = InstrumentAmber, inactiveTrackColor = DarkGrey),
                        modifier = Modifier.height(20.dp).testTag("gradient_slider")
                    )
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: QUICK SETTINGS OVERLAY
// ==========================================
@Composable
fun QuickControlsOverlay(
    state: VehicleState,
    viewModel: EBikeViewModel,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable { onDismiss() }
            .background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.TopCenter
    ) {
        Surface(
            color = Graphite,
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = false) { }
                .border(1.dp, DarkGrey)
                .padding(20.dp),
            shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "QUICK OVERVIEW PANEL",
                    color = RestrainedGrey,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Left Column: Core variables
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SubValueDisplay("TOTAL MILEAGE", "${String.format("%.1f", state.totalDistanceKm)} KM")
                        SubValueDisplay("MOVING TIME", "${state.movingTimeSeconds / 60} min")
                        SubValueDisplay("CALORIES BURNT", "${state.caloriesBurnt} kcal")
                    }
                    // Right Column: System info
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SubValueDisplay("AMBIENT TEMP", "${state.ambientTempC.toInt()}°C")
                        SubValueDisplay("MOTOR TEMP", "${state.motorTempC.toInt()}°C")
                        SubValueDisplay("CONTROLLER TEMP", "${state.controllerTempC.toInt()}°C")
                    }
                }

                Button(
                    onClick = {
                        // Perform zero-calibration
                        viewModel.engine.riderTargetTorqueNm = 0.0
                        viewModel.engine.riderTargetCadenceRpm = 0.0
                        viewModel.clearAllFaults()
                        viewModel.engine.startTrip()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkGrey),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("CALIBRATE TORQUE SENSOR (ZERO-OFFSET OFFSET)", color = WarmWhite, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
