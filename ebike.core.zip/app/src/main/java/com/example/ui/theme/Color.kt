package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// British engineering x Scandinavian industrial design Palette
val NearBlack = Color(0xFF090A0C)       // Deep physical base background
val Graphite = Color(0xFF141619)        // Rich dark card/module background
val DarkGrey = Color(0xFF22252A)        // Lighter accent surface
val RestrainedGrey = Color(0xFF888C94)  // Secondary text, lines, borders
val WarmWhite = Color(0xFFF3F4F6)       // Primary typography, prominent values

// Functional status lights (restrained and precise, no neon)
val EngineeringGreen = Color(0xFF10B981) // Normal / healthy
val EngineeringAmber = Color(0xFFF59E0B) // Warn / degraded
val EngineeringRed = Color(0xFFEF4444)   // Fault / safe shutdown

// Accent color (restrained mechanical detail - subtle brass/gold or electric amber)
val InstrumentAmber = Color(0xFFF59E0B)  // High-contrast readouts
val CarbonNeutral = Color(0xFF374151)
