package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

// For a physical dashboard, we want high outdoor readability,
// so our "light" scheme is also a high-contrast premium dark-mode-first style!
private val DashboardColorScheme = darkColorScheme(
    primary = WarmWhite,
    secondary = RestrainedGrey,
    tertiary = InstrumentAmber,
    background = NearBlack,
    surface = Graphite,
    surfaceVariant = DarkGrey,
    onPrimary = NearBlack,
    onSecondary = WarmWhite,
    onTertiary = NearBlack,
    onBackground = WarmWhite,
    onSurface = WarmWhite,
    onSurfaceVariant = WarmWhite,
    error = EngineeringRed
)

@Composable
fun EBikeTheme(
    darkTheme: Boolean = true, // Force dashboard to high-contrast dark for physical display look
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DashboardColorScheme,
        typography = Typography,
        content = content
    )
}
