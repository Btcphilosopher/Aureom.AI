package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.EBikeDashboardApp
import com.example.ui.EBikeViewModel
import com.example.ui.theme.EBikeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Instantiate our vehicle ViewModel
        val viewModel = ViewModelProvider(this)[EBikeViewModel::class.java]
        
        setContent {
            EBikeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = com.example.ui.theme.NearBlack
                ) {
                    EBikeDashboardApp(viewModel = viewModel)
                }
            }
        }
    }
}
