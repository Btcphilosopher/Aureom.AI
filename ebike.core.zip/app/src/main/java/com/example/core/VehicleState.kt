package com.example.core

import java.io.Serializable

enum class AssistMode {
    OFF, ECO, TOUR, SPORT, BOOST, CUSTOM
}

enum class RegenLevel {
    OFF, LOW, MEDIUM, HIGH, ADAPTIVE
}

enum class SafetyState {
    NORMAL, DEGRADED, LIMITED, FAULT, SAFE
}

enum class RideScenario {
    FLAT_ROAD, CITY, HILL, MOUNTAIN, DESCENT, STOP_START, LONG_TOUR
}

data class VehicleState(
    // Motion
    val speedKmh: Double = 0.0,
    val wheelSpeedRpm: Double = 0.0,
    val frontWheelSpeedKmh: Double = 0.0,
    val rearWheelSpeedKmh: Double = 0.0,
    val tractionControlActive: Boolean = false,
    val tractionControlLevel: Double = 0.8, // Slip reduction threshold
    val wheelSlipPercent: Double = 0.0,
    
    // Rider
    val cadenceRpm: Double = 0.0,
    val pedalTorqueNm: Double = 0.0,
    val riderPowerW: Double = 0.0,
    val rawTorqueSensorVal: Double = 0.0,
    val torqueSensorDrift: Double = 0.0,
    val isPedaling: Boolean = false,
    
    // Motor
    val motorTorqueNm: Double = 0.0,
    val motorRpm: Double = 0.0,
    val motorPowerElectricalW: Double = 0.0,
    val motorPowerMechanicalW: Double = 0.0,
    val motorEfficiencyPercent: Double = 85.0,
    val motorCurrentAmps: Double = 0.0,
    val motorVoltageVolts: Double = 48.0,
    
    // Battery (BMS)
    val batteryVoltageVolts: Double = 48.0,
    val batteryCurrentAmps: Double = 0.0,
    val batterySocPercent: Double = 74.0,
    val batterySohPercent: Double = 96.0,
    val cellVoltages: List<Double> = List(14) { 3.7 }, // 14S lithium pack
    val batteryRemainingEnergyWh: Double = 370.0, // e.g. 500 Wh full pack
    val batteryMaxDischargePowerW: Double = 1000.0,
    val batteryMaxRegenPowerW: Double = 400.0,
    val isBalancing: Boolean = false,
    
    // Thermals
    val ambientTempC: Double = 22.0,
    val batteryTempC: Double = 28.0,
    val motorTempC: Double = 35.0,
    val controllerTempC: Double = 32.0,
    val thermalDeratingActive: Boolean = false,
    val thermalDeratingPercent: Double = 100.0, // 100% means full power, 0% means shutdown
    
    // Deceleration & Regen
    val brakeLeverPressurePercent: Double = 0.0, // Left or right lever brake intensity
    val frictionBrakingTorqueNm: Double = 0.0,
    val regenBrakingTorqueNm: Double = 0.0,
    val isBraking: Boolean = false,
    val isRegenerating: Boolean = false,
    val regenPowerW: Double = 0.0,
    val regeneratedEnergyWh: Double = 0.42,
    
    // Controller Configuration / Mode
    val assistMode: AssistMode = AssistMode.SPORT,
    val regenLevel: RegenLevel = RegenLevel.MEDIUM,
    val targetMotorTorqueRequestNm: Double = 0.0,
    
    // Estimation
    val estimatedRangeMinKm: Double = 48.0,
    val estimatedRangeMaxKm: Double = 72.0,
    val roadGradientPercent: Double = 0.0,
    val altitudeMeters: Double = 120.0,
    
    // Trip Computer
    val tripDistanceKm: Double = 12.4,
    val totalDistanceKm: Double = 1420.0,
    val movingTimeSeconds: Long = 1800,
    val averageSpeedKmh: Double = 24.8,
    val maxSpeedKmh: Double = 42.1,
    val riderEnergyWh: Double = 45.0,
    val motorEnergyWh: Double = 180.0,
    val netBatteryEnergyWh: Double = 135.0,
    val caloriesBurnt: Int = 220,
    
    // Safety & System
    val safetyState: SafetyState = SafetyState.NORMAL,
    val activeFaults: Set<String> = emptySet(),
    val connectionState: Boolean = true, // Dashboard connection
    
    // HIL / Performance Diagnostics
    val loopFrequencyHz: Int = 1000,
    val loopJitterUs: Double = 3.2,
    val cpuUsagePercent: Double = 4.1,
    val ramUsageMb: Double = 18.2,
    val sensorLatencyMs: Double = 1.1,
    val comLatencyMs: Double = 0.8,
    val droppedMessagesCount: Int = 0
) : Serializable
