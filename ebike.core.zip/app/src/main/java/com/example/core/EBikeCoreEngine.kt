package com.example.core

import android.content.Context
import android.util.Log
import com.example.data.TripEntity
import com.example.data.TripRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.*
import kotlin.random.Random

class EBikeCoreEngine(
    private val context: Context,
    private val tripRepository: TripRepository? = null
) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val _vehicleState = MutableStateFlow(VehicleState())
    val vehicleState: StateFlow<VehicleState> = _vehicleState.asStateFlow()

    // Configurable Physics Parameters
    var riderMassKg = 80.0
    var bikeMassKg = 22.0
    var wheelRadiusMeters = 0.35 // 28" wheel approximately
    var motorMaxPowerW = 750.0
    var batteryCapacityWh = 500.0
    var dragCoefficientCdA = 0.32
    var rollingResistanceCrr = 0.005
    var windSpeedKmh = 0.0
    var activeScenario = RideScenario.FLAT_ROAD
    var activeAssistMode = AssistMode.SPORT
    var activeRegenLevel = RegenLevel.MEDIUM

    // Controller inputs controlled by user / rider simulation
    var riderTargetCadenceRpm = 0.0
    var riderTargetTorqueNm = 0.0
    var simulatedBrakePressurePercent = 0.0
    var targetGradientPercent = 0.0

    // Control Loop telemetry
    private var lastLoopTimeNs = System.nanoTime()
    private var loopCount = 0
    private var totalJitterUs = 0.0
    
    // Trip accumulation helpers
    private var tripStartTimestamp = System.currentTimeMillis()
    private var isTripActive = false
    private var accumulatedRiderEnergyWh = 0.0
    private var accumulatedMotorEnergyWh = 0.0
    private var accumulatedRegenEnergyWh = 0.0
    private var tripMaxSpeedKmh = 0.0
    private var peakRiderPowerW = 0.0
    private var movingTimeMs = 0L

    // For CAN Bus simulation / log
    private val _canLog = MutableStateFlow<List<String>>(emptyList())
    val canLog: StateFlow<List<String>> = _canLog.asStateFlow()

    // Torque filter memory
    private val torqueFilterBuffer = DoubleArray(10)
    private var torqueBufferIndex = 0

    // Active faults (for fault injection)
    private val activeFaults = mutableSetOf<String>()

    init {
        startControlLoop()
    }

    fun startTrip() {
        if (!isTripActive) {
            tripStartTimestamp = System.currentTimeMillis()
            isTripActive = true
            accumulatedRiderEnergyWh = 0.0
            accumulatedMotorEnergyWh = 0.0
            accumulatedRegenEnergyWh = 0.0
            tripMaxSpeedKmh = 0.0
            peakRiderPowerW = 0.0
            movingTimeMs = 0L
            _vehicleState.update { it.copy(tripDistanceKm = 0.0) }
            logCanMessage("SYS", "Trip Computer initialized.")
        }
    }

    fun endTrip() {
        if (isTripActive) {
            isTripActive = false
            val state = _vehicleState.value
            val durationSecs = movingTimeMs / 1000
            val avgSpeed = if (durationSecs > 0) (state.tripDistanceKm / (durationSecs / 3600.0)) else 0.0
            
            // Build Entity
            val trip = TripEntity(
                durationSeconds = durationSecs,
                distanceKm = state.tripDistanceKm,
                avgSpeedKmh = if (avgSpeed.isNaN()) 0.0 else avgSpeed,
                maxSpeedKmh = tripMaxSpeedKmh,
                riderEnergyWh = accumulatedRiderEnergyWh,
                motorEnergyWh = accumulatedMotorEnergyWh,
                regeneratedEnergyWh = accumulatedRegenEnergyWh,
                peakPowerW = peakRiderPowerW,
                averagePowerW = if (durationSecs > 0) (accumulatedRiderEnergyWh * 3600.0 / durationSecs) else 0.0,
                calories = (accumulatedRiderEnergyWh * 3.6).toInt(), // Approximation
                netEnergyWh = accumulatedMotorEnergyWh - accumulatedRegenEnergyWh
            )

            scope.launch {
                tripRepository?.insertTrip(trip)
            }
            logCanMessage("SYS", "Trip saved: ${String.format("%.2f", state.tripDistanceKm)} km")
        }
    }

    fun injectFault(fault: String) {
        activeFaults.add(fault)
        logCanMessage("FAULT_INJECT", "CRITICAL FAULT INSTALLED: $fault")
    }

    fun clearFault(fault: String) {
        activeFaults.remove(fault)
        logCanMessage("FAULT_INJECT", "FAULT REMOVED: $fault")
    }

    fun clearAllFaults() {
        activeFaults.clear()
        logCanMessage("FAULT_INJECT", "All faults cleared.")
    }

    private fun logCanMessage(node: String, text: String) {
        val timestamp = System.currentTimeMillis() % 1000000
        val message = "[CAN] [$timestamp] $node: $text"
        _canLog.update { (it + message).takeLast(40) }
    }

    private fun startControlLoop() {
        scope.launch {
            // Update loop runs at 50Hz (20ms step) for smoother real-time display and robust integrations.
            // Under the hood, we simulate 20 high-frequency deterministic controller updates of 1ms each per cycle
            // to perfectly model loop jitter, CAN frequency, and numerical physical integration.
            val intervalMs = 20L
            while (isActive) {
                val startNs = System.nanoTime()
                
                // Deterministic execution of 20 control ticks representing 1ms internal vehicle cycles
                for (step in 1..20) {
                    executeDeterministicControlTick(0.001)
                }

                val elapsedNs = System.nanoTime() - startNs
                val elapsedMs = elapsedNs / 1_000_000.0
                
                // Track Loop Jitter
                val idealNs = intervalMs * 1_000_000.0
                val jitterUs = abs(elapsedNs - idealNs) / 1000.0
                totalJitterUs = (totalJitterUs * 0.95) + (jitterUs * 0.05)
                
                // Update diagnostic stats
                _vehicleState.update { state ->
                    state.copy(
                        loopFrequencyHz = 1000,
                        loopJitterUs = totalJitterUs.coerceIn(0.2, 8.5),
                        cpuUsagePercent = (3.0 + Random.nextDouble(0.0, 1.5)).coerceIn(1.0, 15.0),
                        ramUsageMb = 18.2 + (loopCount % 100) * 0.005,
                        sensorLatencyMs = 0.8 + Random.nextDouble(0.0, 0.4),
                        comLatencyMs = 0.5 + Random.nextDouble(0.0, 0.3)
                    )
                }

                loopCount++
                delay(intervalMs)
            }
        }
    }

    private fun executeDeterministicControlTick(dt: Double) {
        // 1. SENSOR READINGS AND PRE-PROCESSING
        val state = _vehicleState.value

        // Torque Sensor & Filtering
        var rawTorque = riderTargetTorqueNm
        if (activeFaults.contains("TORQUE_SENSOR_FAILURE")) {
            rawTorque = if (Random.nextBoolean()) 999.9 else -50.0 // Implausible / broken values
        } else {
            // Add slight sensor noise & simulated drift
            val noise = (Random.nextDouble() - 0.5) * 0.4
            val drift = sin(System.currentTimeMillis() / 60000.0) * 0.1
            rawTorque += noise + drift
        }

        // Apply moving average filter
        torqueFilterBuffer[torqueBufferIndex] = rawTorque
        torqueBufferIndex = (torqueBufferIndex + 1) % torqueFilterBuffer.size
        val filteredTorque = torqueFilterBuffer.average()

        // Plausibility Check
        val torqueSensorFault = filteredTorque > 150.0 || filteredTorque < -10.0

        // Cadence Processing
        var rawCadence = riderTargetCadenceRpm
        if (activeFaults.contains("CADENCE_SENSOR_FAILURE")) {
            rawCadence = 0.0 // Appears dead
        }
        val isPedaling = rawCadence > 5.0 && filteredTorque > 1.0

        // Speed Sensors & Slip Detection (Traction Control)
        var rearSpeedKmh = state.speedKmh
        var frontSpeedKmh = state.speedKmh
        var tractionActive = false
        var slipPercent = 0.0

        if (activeFaults.contains("WHEEL_SENSOR_FAILURE")) {
            rearSpeedKmh = 0.0 // dead speed sensor
        } else {
            // Simulated slip in slippery scenario (e.g. wet city / hill boost)
            if (activeAssistMode == AssistMode.BOOST && state.roadGradientPercent > 10.0 && state.motorTorqueNm > 40.0) {
                // Induce subtle wheel spin
                rearSpeedKmh = state.speedKmh * 1.25
                slipPercent = 25.0
            }
        }

        if (slipPercent > 10.0 && !activeFaults.contains("WHEEL_SENSOR_FAILURE")) {
            tractionActive = true
        }

        // 2. SAFETY SUPERVISOR STATE MACHINE
        val activeFaultSet = mutableSetOf<String>()
        if (torqueSensorFault) activeFaultSet.add("TORQUE_SENSOR_FAIL")
        if (activeFaults.contains("CADENCE_SENSOR_FAILURE")) activeFaultSet.add("CADENCE_SENSOR_FAIL")
        if (activeFaults.contains("WHEEL_SENSOR_FAILURE")) activeFaultSet.add("WHEEL_SENSOR_FAIL")
        if (state.motorTempC > 95.0 || activeFaults.contains("MOTOR_OVERHEATING")) activeFaultSet.add("MOTOR_OVERHEAT")
        if (state.batteryTempC > 58.0 || activeFaults.contains("BATTERY_TEMPERATURE_FAULT")) activeFaultSet.add("BATTERY_OVERHEAT")
        if (activeFaults.contains("OVERCURRENT")) activeFaultSet.add("OVERCURRENT")
        if (activeFaults.contains("COMMUNICATION_LOSS")) activeFaultSet.add("COMM_LOSS")
        if (activeFaults.contains("BRAKE_SENSOR_STUCK")) activeFaultSet.add("BRAKE_STUCK")

        val safetyState = when {
            activeFaultSet.contains("MOTOR_OVERHEAT") || activeFaultSet.contains("BATTERY_OVERHEAT") || activeFaultSet.contains("OVERCURRENT") -> SafetyState.SAFE // Complete cutout
            activeFaultSet.contains("COMM_LOSS") || activeFaultSet.contains("BRAKE_STUCK") -> SafetyState.FAULT // Trip brake override or shut off
            activeFaultSet.contains("TORQUE_SENSOR_FAIL") || activeFaultSet.contains("CADENCE_SENSOR_FAIL") -> SafetyState.DEGRADED // Limp home on throttle or basic RPM assist
            activeFaultSet.isNotEmpty() -> SafetyState.LIMITED
            else -> SafetyState.NORMAL
        }

        if (safetyState != state.safetyState) {
            logCanMessage("SAFETY", "State Transition: ${state.safetyState} -> $safetyState. Active Faults: $activeFaultSet")
        }

        // 3. THERMAL MANAGEMENT & POWER DERATING
        // Model heating effects based on motor/battery current
        val motorHeatRate = (state.motorPowerElectricalW / 1000.0).pow(2) * 0.05 - (state.motorTempC - state.ambientTempC) * 0.005
        val batteryHeatRate = (state.batteryCurrentAmps).pow(2) * 0.01 - (state.batteryTempC - state.ambientTempC) * 0.003
        val controllerHeatRate = (state.batteryCurrentAmps).pow(2) * 0.005 - (state.controllerTempC - state.ambientTempC) * 0.006

        val newMotorTemp = (state.motorTempC + motorHeatRate * dt).coerceIn(-10.0, 110.0)
        val newBatteryTemp = (state.batteryTempC + batteryHeatRate * dt).coerceIn(-10.0, 70.0)
        val newControllerTemp = (state.controllerTempC + controllerHeatRate * dt).coerceIn(-10.0, 95.0)

        // Derating factor computation (1.0 = full power, 0.0 = zero power)
        val motorDerating = when {
            newMotorTemp < 75.0 -> 1.0
            newMotorTemp > 95.0 -> 0.0
            else -> 1.0 - (newMotorTemp - 75.0) / 20.0
        }
        val batteryDerating = when {
            newBatteryTemp < 45.0 -> 1.0
            newBatteryTemp > 58.0 -> 0.0
            else -> 1.0 - (newBatteryTemp - 45.0) / 13.0
        }
        val controllerDerating = when {
            newControllerTemp < 70.0 -> 1.0
            newControllerTemp > 85.0 -> 0.0
            else -> 1.0 - (newControllerTemp - 70.0) / 15.0
        }
        val thermalDeratingPercent = minOf(motorDerating, batteryDerating, controllerDerating) * 100.0
        val isThermalDerating = thermalDeratingPercent < 98.0

        // 4. PEDAL-ASSIST CONTROL LOOP (Propulsion Strategy)
        val rawRiderPower = filteredTorque * (rawCadence * 2.0 * Math.PI / 60.0)
        val riderPowerW = if (rawRiderPower > 0.0 && isPedaling) rawRiderPower else 0.0

        var targetMotorTorque = 0.0
        val brakePressure = simulatedBrakePressurePercent / 100.0

        // Only assist if pedaling and safety state allows it
        if (isPedaling && safetyState != SafetyState.SAFE && safetyState != SafetyState.FAULT && brakePressure < 0.1) {
            val assistFactor = when (activeAssistMode) {
                AssistMode.OFF -> 0.0
                AssistMode.ECO -> 0.75   // 75% assist
                AssistMode.TOUR -> 1.50  // 150% assist
                AssistMode.SPORT -> 2.50 // 250% assist
                AssistMode.BOOST -> 4.00 // 400% assist
                AssistMode.CUSTOM -> 2.0 // Custom default
            }

            val torqueCeiling = when (activeAssistMode) {
                AssistMode.OFF -> 0.0
                AssistMode.ECO -> 20.0
                AssistMode.TOUR -> 40.0
                AssistMode.SPORT -> 60.0
                AssistMode.BOOST -> 85.0
                AssistMode.CUSTOM -> 50.0
            }

            // Torque request proportional to rider input
            targetMotorTorque = filteredTorque * assistFactor
            
            // Constrain by assistance level and system limits
            targetMotorTorque = targetMotorTorque.coerceAtMost(torqueCeiling)

            // Traction Control reduction if rear wheel is slipping
            if (tractionActive) {
                targetMotorTorque *= 0.3 // Cut torque by 70% to regain traction
            }

            // Apply Thermal Derating
            targetMotorTorque *= (thermalDeratingPercent / 100.0)

            // Apply Battery Discharge Power Limits
            // Voltage-based power constraints
            val maxAvailablePower = state.batteryMaxDischargePowerW
            val motorMechanicalLimitW = maxAvailablePower * 0.85 // efficiency factor
            val wheelRps = state.wheelSpeedRpm / 60.0
            val wheelAngVel = wheelRps * 2.0 * Math.PI
            
            if (wheelAngVel > 0.1) {
                val torqueLimitByPower = motorMechanicalLimitW / wheelAngVel
                targetMotorTorque = targetMotorTorque.coerceAtMost(torqueLimitByPower)
            }
        }

        // Emergency Brake Override
        if (brakePressure > 0.1) {
            targetMotorTorque = 0.0 // Cut motor output immediately
        }

        // 5. REGENERATIVE BRAKING & CLOSED-LOOP DECELERATION
        var regenTorqueNm = 0.0
        var frictionTorqueNm = 0.0
        var isRegenerating = false
        var regenPowerW = 0.0

        if (brakePressure > 0.02 && state.speedKmh > 5.0) {
            // Total requested braking deceleration torque
            val totalBrakingTorqueRequested = brakePressure * 120.0 // e.g. Max 120Nm brake torque

            // Regeneration eligibility check
            val canRegen = when {
                state.batterySocPercent >= 95.0 -> false // Battery full
                newBatteryTemp < 0.0 -> false // Cold lithium protection
                newBatteryTemp > 48.0 -> false // High temperature protection
                activeRegenLevel == RegenLevel.OFF -> false
                safetyState == SafetyState.SAFE -> false
                else -> true
            }

            if (canRegen) {
                isRegenerating = true
                // Map regen capacity based on regen level selection
                val maxRegenFraction = when (activeRegenLevel) {
                    RegenLevel.OFF -> 0.0
                    RegenLevel.LOW -> 0.2
                    RegenLevel.MEDIUM -> 0.5
                    RegenLevel.HIGH -> 0.8
                    RegenLevel.ADAPTIVE -> {
                        // More brake pressure = higher regen up to limit
                        (brakePressure * 1.5).coerceIn(0.2, 0.9)
                    }
                }

                val possibleRegenTorque = totalBrakingTorqueRequested * maxRegenFraction
                
                // Convert torque to electric power to ensure BMS limits are respected
                val wheelRps = state.wheelSpeedRpm / 60.0
                val wheelAngVel = wheelRps * 2.0 * Math.PI
                val generatedMechanicalPowerW = possibleRegenTorque * wheelAngVel
                val generatedElectricalPowerW = generatedMechanicalPowerW * 0.75 // generator efficiency

                if (generatedElectricalPowerW <= state.batteryMaxRegenPowerW) {
                    regenTorqueNm = possibleRegenTorque
                    regenPowerW = generatedElectricalPowerW
                } else {
                    // Cap regen to max charging acceptance power
                    val cappedRegenTorque = state.batteryMaxRegenPowerW / (wheelAngVel * 0.75 + 0.01)
                    regenTorqueNm = cappedRegenTorque.coerceAtMost(possibleRegenTorque)
                    regenPowerW = state.batteryMaxRegenPowerW
                }

                // Excess braking handled by mechanical disc brakes (friction)
                frictionTorqueNm = totalBrakingTorqueRequested - regenTorqueNm
            } else {
                // No regen available - 100% mechanical friction braking
                frictionTorqueNm = totalBrakingTorqueRequested
            }
        }

        // 6. DETAILED BMS STATE UPDATE
        var batteryCurrentAmps = 0.0
        var batteryPowerW = 0.0

        if (targetMotorTorque > 0.0) {
            // Motor is drawing power from battery
            val wheelRps = state.wheelSpeedRpm / 60.0
            val wheelAngVel = wheelRps * 2.0 * Math.PI
            val motorMechanicalPowerW = targetMotorTorque * wheelAngVel
            
            // Efficiency mapping: simpler polynomial representing RPM x Torque -> Efficiency
            val speedRatio = (state.speedKmh / 45.0).coerceIn(0.0, 1.0)
            val loadRatio = (targetMotorTorque / 85.0).coerceIn(0.0, 1.0)
            // Efficiency peaks at mid-RPM, mid-torque
            val computedEfficiency = 0.60 + 0.32 * sin(speedRatio * Math.PI) * sin(loadRatio * Math.PI)
            val motorEfficiency = computedEfficiency.coerceIn(0.50, 0.92)

            val electricalPowerW = motorMechanicalPowerW / motorEfficiency
            batteryPowerW = electricalPowerW
            batteryCurrentAmps = electricalPowerW / state.batteryVoltageVolts
        } else if (isRegenerating && regenPowerW > 0.0) {
            // Regeneration charging battery
            batteryPowerW = -regenPowerW
            batteryCurrentAmps = -regenPowerW / state.batteryVoltageVolts
        }

        // Update BMS Voltages & SOC
        val internalResistance = 0.15 // ohms
        val nominalOcv = 51.8 // 14S * 3.7V
        // Calculate loaded pack voltage
        val loadedVoltage = nominalOcv - (batteryCurrentAmps * internalResistance)
        
        // Energy consumption integration
        val dtHours = dt / 3600.0
        val energyDeltaWh = batteryPowerW * dtHours
        val remainingEnergy = (state.batteryRemainingEnergyWh - energyDeltaWh).coerceIn(0.0, batteryCapacityWh)
        val soc = (remainingEnergy / batteryCapacityWh) * 100.0

        // Cell balancing simulation: balance cells if charging / stationary and connected
        val cells = state.cellVoltages.toMutableList()
        val baseCellVoltage = 3.0 + (soc / 100.0) * 1.2 // 3.0V to 4.2V linear approximation
        var isBalancing = false
        for (i in cells.indices) {
            // Add tiny voltage discrepancies to simulate imbalance
            val discrepancy = sin((System.currentTimeMillis() / 1000.0) + i) * 0.015
            cells[i] = (baseCellVoltage + discrepancy).coerceIn(3.0, 4.25)
            
            // If any cell exceeds 4.15V, balance it (draw down slightly)
            if (cells[i] > 4.18 && batteryCurrentAmps < 0.1) {
                cells[i] -= 0.001
                isBalancing = true
            }
        }

        // Dynamic BMS Power limits based on cells and temperature
        val maxDischargePowerW = when {
            newBatteryTemp < 5.0 -> 350.0  // Cold battery output limits
            newBatteryTemp > 50.0 -> 200.0 // Hot battery protection limits
            soc < 15.0 -> 250.0            // Low charge safety limits
            else -> 1000.0                 // Standard full output
        }
        val maxRegenPowerW = when {
            newBatteryTemp < 2.0 -> 0.0    // Do not charge cold cells
            newBatteryTemp > 45.0 -> 100.0 // Reduced charge acceptance when hot
            soc > 90.0 -> 100.0 * (100.0 - soc) / 10.0 // Taper down as battery fills
            else -> 400.0                  // Standard regenerative charging capacity
        }

        // 7. PHYSICS INTEGRATION ENGINE (Closed-loop vehicle model)
        // Forces acting on the bike
        val massTotal = riderMassKg + bikeMassKg
        val theta = atan(targetGradientPercent / 100.0)

        // Forces in Newtons
        val gravityForce = massTotal * 9.81 * sin(theta)
        
        // Wind speed conversion from kmh to m/s
        val windMs = windSpeedKmh / 3.6
        val speedMs = state.speedKmh / 3.6
        val relativeAirSpeedMs = speedMs + windMs
        val dragForce = 0.5 * 1.2 * dragCoefficientCdA * relativeAirSpeedMs * abs(relativeAirSpeedMs)
        
        val rollingForce = massTotal * 9.81 * rollingResistanceCrr * cos(theta)

        // Propelling force (Mechanical force from Motor + Rider)
        val wheelRadius = wheelRadiusMeters
        val motorForce = (targetMotorTorque) / wheelRadius
        val riderForce = (filteredTorque) / wheelRadius

        // Braking Forces (Negative forces)
        val brakingForceRegen = (regenTorqueNm) / wheelRadius
        val brakingForceFriction = (frictionTorqueNm) / wheelRadius

        // Sum of physical forces
        val netForce = (motorForce + riderForce) - (dragForce + rollingForce + gravityForce) - (brakingForceRegen + brakingForceFriction)

        val accelerationMs2 = netForce / massTotal
        val nextSpeedMs = (speedMs + accelerationMs2 * dt).coerceAtLeast(0.0)
        val speedKmh = nextSpeedMs * 3.6

        val wheelRps = nextSpeedMs / (2.0 * Math.PI * wheelRadius)
        val wheelSpeedRpm = wheelRps * 60.0
        val motorRpm = wheelSpeedRpm * 1.0 // direct drive model or gear ratio 1:1

        // 8. RANGE ESTIMATION
        // Expected range with uncertainty bounds based on real efficiency
        val energyUsageRateWhPerKm = if (speedKmh > 2.0) {
            val powerDraw = max(0.0, batteryPowerW)
            powerDraw / speedKmh // Wh/km
        } else 15.0 // default fallback
        
        // Base range remaining
        val rangeBase = (remainingEnergy / energyUsageRateWhPerKm.coerceIn(5.0, 45.0))
        val rangeMin = (rangeBase * 0.85).coerceIn(0.0, 150.0)
        val rangeMax = (rangeBase * 1.15).coerceIn(0.0, 180.0)

        // 9. TRIP COMPUTER ACCUMULATION
        var tripDist = state.tripDistanceKm
        var totalDist = state.totalDistanceKm
        var movingSecs = state.movingTimeSeconds
        var calories = state.caloriesBurnt

        if (speedKmh > 0.5) {
            val distStep = (speedKmh * dt / 3600.0)
            tripDist += distStep
            totalDist += distStep
            movingTimeMs += (dt * 1000).toLong()
            movingSecs = movingTimeMs / 1000

            // Accumulate energy usage
            if (targetMotorTorque > 0.0) {
                accumulatedMotorEnergyWh += (batteryPowerW * dtHours)
            }
            if (isRegenerating && regenPowerW > 0.0) {
                accumulatedRegenEnergyWh += (regenPowerW * dtHours)
            }
            if (riderPowerW > 0.0) {
                accumulatedRiderEnergyWh += (riderPowerW * dtHours)
                if (riderPowerW > peakRiderPowerW) {
                    peakRiderPowerW = riderPowerW
                }
            }

            if (speedKmh > tripMaxSpeedKmh) {
                tripMaxSpeedKmh = speedKmh
            }

            calories = (accumulatedRiderEnergyWh * 3.6).toInt() // Rider energy to calories burnt
        }

        // Save state changes
        _vehicleState.update { current ->
            current.copy(
                speedKmh = speedKmh,
                wheelSpeedRpm = wheelSpeedRpm,
                frontWheelSpeedKmh = speedKmh,
                rearWheelSpeedKmh = rearSpeedKmh,
                tractionControlActive = tractionActive,
                wheelSlipPercent = slipPercent,
                
                cadenceRpm = rawCadence,
                pedalTorqueNm = filteredTorque,
                riderPowerW = riderPowerW,
                rawTorqueSensorVal = rawTorque,
                torqueSensorDrift = rawTorque - filteredTorque,
                isPedaling = isPedaling,
                
                motorTorqueNm = targetMotorTorque,
                motorRpm = motorRpm,
                motorPowerElectricalW = if (targetMotorTorque > 0.0) batteryPowerW else 0.0,
                motorPowerMechanicalW = if (targetMotorTorque > 0.0) targetMotorTorque * (wheelSpeedRpm / 60.0 * 2.0 * Math.PI) else 0.0,
                motorEfficiencyPercent = if (targetMotorTorque > 0.0) (100.0 * (targetMotorTorque * (wheelSpeedRpm / 60.0 * 2.0 * Math.PI)) / (batteryPowerW + 0.1)).coerceIn(50.0, 95.0) else 85.0,
                motorCurrentAmps = if (targetMotorTorque > 0.0) batteryCurrentAmps else 0.0,
                motorVoltageVolts = loadedVoltage,
                
                batteryVoltageVolts = loadedVoltage,
                batteryCurrentAmps = batteryCurrentAmps,
                batterySocPercent = soc,
                cellVoltages = cells,
                batteryRemainingEnergyWh = remainingEnergy,
                batteryMaxDischargePowerW = maxDischargePowerW,
                batteryMaxRegenPowerW = maxRegenPowerW,
                isBalancing = isBalancing,
                
                ambientTempC = state.ambientTempC,
                batteryTempC = newBatteryTemp,
                motorTempC = newMotorTemp,
                controllerTempC = newControllerTemp,
                thermalDeratingActive = isThermalDerating,
                thermalDeratingPercent = thermalDeratingPercent,
                
                brakeLeverPressurePercent = simulatedBrakePressurePercent,
                frictionBrakingTorqueNm = frictionTorqueNm,
                regenBrakingTorqueNm = regenTorqueNm,
                isBraking = brakePressure > 0.02,
                isRegenerating = isRegenerating,
                regenPowerW = regenPowerW,
                regeneratedEnergyWh = accumulatedRegenEnergyWh,
                
                targetMotorTorqueRequestNm = targetMotorTorque,
                
                estimatedRangeMinKm = rangeMin,
                estimatedRangeMaxKm = rangeMax,
                roadGradientPercent = targetGradientPercent,
                
                tripDistanceKm = tripDist,
                totalDistanceKm = totalDist,
                movingTimeSeconds = movingSecs,
                averageSpeedKmh = if (movingSecs > 0) (tripDist / (movingSecs / 3600.0)) else 0.0,
                maxSpeedKmh = tripMaxSpeedKmh,
                riderEnergyWh = accumulatedRiderEnergyWh,
                motorEnergyWh = accumulatedMotorEnergyWh,
                netBatteryEnergyWh = accumulatedMotorEnergyWh - accumulatedRegenEnergyWh,
                caloriesBurnt = calories,
                
                assistMode = activeAssistMode,
                regenLevel = activeRegenLevel,
                safetyState = safetyState,
                activeFaults = activeFaultSet
            )
        }
    }

    fun applyRideScenario(scenario: RideScenario) {
        activeScenario = scenario
        when (scenario) {
            RideScenario.FLAT_ROAD -> {
                targetGradientPercent = 0.0
                riderTargetCadenceRpm = 80.0
                riderTargetTorqueNm = 12.0
                simulatedBrakePressurePercent = 0.0
                logCanMessage("SIM", "Loaded FLAT ROAD. Ideal cruising scenario.")
            }
            RideScenario.CITY -> {
                targetGradientPercent = 1.0
                riderTargetCadenceRpm = 65.0
                riderTargetTorqueNm = 15.0
                simulatedBrakePressurePercent = 0.0
                logCanMessage("SIM", "Loaded CITY. Frequent starts and stops.")
            }
            RideScenario.HILL -> {
                targetGradientPercent = 8.0
                riderTargetCadenceRpm = 70.0
                riderTargetTorqueNm = 25.0
                simulatedBrakePressurePercent = 0.0
                logCanMessage("SIM", "Loaded HILL. Uphill heavy load.")
            }
            RideScenario.MOUNTAIN -> {
                targetGradientPercent = 14.0
                riderTargetCadenceRpm = 60.0
                riderTargetTorqueNm = 35.0
                simulatedBrakePressurePercent = 0.0
                logCanMessage("SIM", "Loaded MOUNTAIN. Near-maximum thermal strain.")
            }
            RideScenario.DESCENT -> {
                targetGradientPercent = -6.0
                riderTargetCadenceRpm = 10.0
                riderTargetTorqueNm = 0.0
                simulatedBrakePressurePercent = 25.0 // Constant braking for regen demo!
                logCanMessage("SIM", "Loaded DESCENT. Continuous braking / energy recovery.")
            }
            RideScenario.STOP_START -> {
                targetGradientPercent = 0.0
                riderTargetCadenceRpm = 0.0
                riderTargetTorqueNm = 0.0
                simulatedBrakePressurePercent = 80.0
                logCanMessage("SIM", "Loaded STOP-START. Stationary, brake held.")
            }
            RideScenario.LONG_TOUR -> {
                targetGradientPercent = 2.0
                riderTargetCadenceRpm = 75.0
                riderTargetTorqueNm = 10.0
                simulatedBrakePressurePercent = 0.0
                logCanMessage("SIM", "Loaded LONG TOUR. Maximum range optimization.")
            }
        }
    }
}
