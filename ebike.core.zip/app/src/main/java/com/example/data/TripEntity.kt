package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Long,
    val distanceKm: Double,
    val avgSpeedKmh: Double,
    val maxSpeedKmh: Double,
    val riderEnergyWh: Double,
    val motorEnergyWh: Double,
    val regeneratedEnergyWh: Double,
    val peakPowerW: Double,
    val averagePowerW: Double,
    val calories: Int,
    val netEnergyWh: Double
)
