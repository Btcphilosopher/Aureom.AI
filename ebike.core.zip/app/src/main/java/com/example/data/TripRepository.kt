package com.example.data

import kotlinx.coroutines.flow.Flow

class TripRepository(private val tripDao: TripDao) {
    val allTrips: Flow<List<TripEntity>> = tripDao.getAllTrips()

    suspend fun insertTrip(trip: TripEntity) {
        tripDao.insertTrip(trip)
    }

    suspend fun deleteTrip(id: Int) {
        tripDao.deleteTrip(id)
    }

    suspend fun clearAllTrips() {
        tripDao.clearAllTrips()
    }
}
