#![no_std]
#![allow(dead_code)]

//! EBIKE.CORE - Embedded Vehicle-Control Core
//! Safety-critical, deterministic core for bare-metal MCU environments.

pub mod types {
    #[derive(Copy, Clone, Debug, PartialEq)]
    pub enum AssistMode {
        Off,
        Eco,
        Tour,
        Sport,
        Boost,
        Custom,
    }

    #[derive(Copy, Clone, Debug, PartialEq)]
    pub enum SafetyState {
        Normal,
        Degraded,
        Limited,
        Fault,
        Safe,
    }

    #[derive(Copy, Clone, Debug, Default)]
    pub struct VehicleState {
        pub speed_kmh: f32,
        pub cadence_rpm: f32,
        pub pedal_torque_nm: f32,
        pub motor_torque_nm: f32,
        pub battery_voltage: f32,
        pub battery_current: f32,
        pub battery_soc: f32,
        pub motor_temp: f32,
        pub battery_temp: f32,
        pub controller_temp: f32,
        pub brake_lever_pressure: f32,
        pub safety_state: SafetyState,
    }
}

pub struct VehicleController {
    state: types::VehicleState,
    watchdog_ticks: u32,
}

impl Default for VehicleState {
    fn default() -> Self {
        types::VehicleState {
            speed_kmh: 0.0,
            cadence_rpm: 0.0,
            pedal_torque_nm: 0.0,
            motor_torque_nm: 0.0,
            battery_voltage: 48.0,
            battery_current: 0.0,
            battery_soc: 100.0,
            motor_temp: 25.0,
            battery_temp: 25.0,
            controller_temp: 25.0,
            brake_lever_pressure: 0.0,
            safety_state: types::SafetyState::Normal,
        }
    }
}

impl VehicleController {
    pub fn new() -> Self {
        VehicleController {
            state: types::VehicleState::default(),
            watchdog_ticks: 0,
        }
    }

    /// Primary deterministic control loop step. Runs exactly every 1ms.
    pub fn step(&mut self, sensors: &SensorPayload) -> MotorCommand {
        self.watchdog_ticks = self.watchdog_ticks.wrapping_add(1);
        
        // 1. Evaluate safety constraints first
        let safety = self.evaluate_safety_supervisor(sensors);
        self.state.safety_state = safety;

        // 2. Process brake override
        if sensors.brake_lever_pressure > 0.1 || safety == types::SafetyState::Safe {
            self.state.motor_torque_nm = 0.0;
            return MotorCommand {
                target_torque_nm: 0.0,
                regenerative_torque_nm: self.calculate_regen_torque(sensors),
                shutdown_propulsion: safety == types::SafetyState::Safe,
            };
        }

        // 3. Compute pedal assistance torque (deterministic closed-loop)
        let assist_ratio = match sensors.assist_mode {
            types::AssistMode::Off => 0.0,
            types::AssistMode::Eco => 0.75,
            types::AssistMode::Tour => 1.5,
            types::AssistMode::Sport => 2.5,
            types::AssistMode::Boost => 4.0,
            types::AssistMode::Custom => 2.0,
        };

        let mut target_torque = sensors.filtered_pedal_torque * assist_ratio;

        // Apply thermal derating constraints
        let thermal_derating = self.calculate_thermal_derating(sensors);
        target_torque *= thermal_derating;

        // Apply battery-discharge limit constraints
        let battery_discharge_limit = self.calculate_battery_limit(sensors);
        if target_torque > battery_discharge_limit {
            target_torque = battery_discharge_limit;
        }

        self.state.motor_torque_nm = target_torque;

        MotorCommand {
            target_torque_nm: target_torque,
            regenerative_torque_nm: 0.0,
            shutdown_propulsion: false,
        }
    }

    fn evaluate_safety_supervisor(&self, sensors: &SensorPayload) -> types::SafetyState {
        // Redundant checks for sensor plausibility
        if sensors.raw_pedal_torque > 150.0 || sensors.raw_pedal_torque < -10.0 {
            return types::SafetyState::Safe; // Torque sensor failure -> immediate shutdown
        }
        if sensors.motor_temp > 95.0 || sensors.battery_temp > 60.0 {
            return types::SafetyState::Safe; // Thermal overload -> shutdown
        }
        if sensors.battery_voltage < 36.0 {
            return types::SafetyState::Limited; // Under-voltage protection -> limp home
        }
        types::SafetyState::Normal
    }

    fn calculate_thermal_derating(&self, sensors: &SensorPayload) -> f32 {
        if sensors.motor_temp > 80.0 {
            let over_temp = (sensors.motor_temp - 80.0) / 15.0; // Derate linearly up to 95C
            (1.0 - over_temp).clamp(0.0, 1.0)
        } else {
            1.0
        }
    }

    fn calculate_battery_limit(&self, _sensors: &SensorPayload) -> f32 {
        // Simple maximum current scaling mapping
        85.0 // Maximum motor torque limit
    }

    fn calculate_regen_torque(&self, sensors: &SensorPayload) -> f32 {
        if sensors.battery_soc >= 95.0 || sensors.battery_temp < 2.0 || sensors.battery_temp > 48.0 {
            return 0.0; // Battery state cannot accept charge safely
        }
        // Regen level map
        sensors.brake_lever_pressure * 45.0 // Max 45 Nm of braking generation
    }
}

pub struct SensorPayload {
    pub raw_pedal_torque: f32,
    pub filtered_pedal_torque: f32,
    pub cadence_rpm: f32,
    pub speed_kmh: f32,
    pub motor_temp: f32,
    pub battery_temp: f32,
    pub controller_temp: f32,
    pub battery_voltage: f32,
    pub battery_soc: f32,
    pub brake_lever_pressure: f32,
    pub assist_mode: types::AssistMode,
}

pub struct MotorCommand {
    pub target_torque_nm: f32,
    pub regenerative_torque_nm: f32,
    pub shutdown_propulsion: bool,
}
