#![no_std]

//! EBIKE.CORE Safety Supervisor Module
//! Handles deterministic fault trees, overcurrent verification, 
//! and transitions between safe/degraded operational modes.

#[derive(Copy, Clone, Debug, PartialEq)]
pub enum FaultCode {
    TorqueSensorImplausible = 0x01,
    CadenceSensorDead = 0x02,
    WheelSpeedMismatch = 0x03,
    MotorOverTemperature = 0x04,
    BatteryOverTemperature = 0x05,
    InverterOverCurrent = 0x06,
    BrakeSensorStuck = 0x07,
    CanBusFault = 0x08,
}

#[derive(Copy, Clone, Debug, PartialEq)]
pub enum SystemMode {
    Normal,
    DegradedPedalOnly,
    LimitedPower,
    SafeShutdown,
}

pub struct SafetySupervisor {
    fault_mask: u16,
    overcurrent_ticks: u8,
    can_timeout_ticks: u16,
}

impl SafetySupervisor {
    pub const fn new() -> Self {
        SafetySupervisor {
            fault_mask: 0,
            overcurrent_ticks: 0,
            can_timeout_ticks: 0,
        }
    }

    /// Update the safety supervisor with the current system telemetry.
    /// Returns the target system mode and writes active fault flags to CAN.
    pub fn update(
        &mut self,
        raw_current_amps: f32,
        motor_temp_c: f32,
        battery_temp_c: f32,
        can_alive: bool,
    ) -> SystemMode {
        // 1. Overcurrent verification (integrate current over time to prevent nuisance trips)
        if raw_current_amps > 35.0 {
            self.overcurrent_ticks = self.overcurrent_ticks.saturating_add(1);
        } else {
            self.overcurrent_ticks = self.overcurrent_ticks.saturating_sub(1);
        }

        if self.overcurrent_ticks > 15 {
            self.fault_mask |= 1 << (FaultCode::InverterOverCurrent as u8);
        }

        // 2. Thermal threshold monitoring
        if motor_temp_c > 98.0 {
            self.fault_mask |= 1 << (FaultCode::MotorOverTemperature as u8);
        }
        if battery_temp_c > 58.0 {
            self.fault_mask |= 1 << (FaultCode::BatteryOverTemperature as u8);
        }

        // 3. CAN watchdog
        if !can_alive {
            self.can_timeout_ticks = self.can_timeout_ticks.saturating_add(1);
            if self.can_timeout_ticks > 500 { // 500ms loss of dashboard heartbeat
                self.fault_mask |= 1 << (FaultCode::CanBusFault as u8);
            }
        } else {
            self.can_timeout_ticks = 0;
        }

        // 4. Mode determination state machine
        if self.is_fault_active(FaultCode::InverterOverCurrent) 
            || self.is_fault_active(FaultCode::BatteryOverTemperature) 
        {
            SystemMode::SafeShutdown // Force motor current to 0, open safety relays
        } else if self.is_fault_active(FaultCode::MotorOverTemperature) {
            SystemMode::LimitedPower // Restrict power to 150W max
        } else if self.is_fault_active(FaultCode::CanBusFault) {
            SystemMode::DegradedPedalOnly // Dashboard dead, but keep pedaling safe
        } else {
            SystemMode::Normal
        }
    }

    pub fn reset_fault(&mut self, fault: FaultCode) {
        self.fault_mask &= !(1 << (fault as u8));
        if fault == FaultCode::InverterOverCurrent {
            self.overcurrent_ticks = 0;
        }
    }

    pub fn is_fault_active(&self, fault: FaultCode) -> bool {
        (self.fault_mask & (1 << (fault as u8))) != 0
    }

    pub fn get_fault_mask(&self) -> u16 {
        self.fault_mask
    }
}
