# EBIKE.CORE CONTROL ARCHITECTURE

This document describes the vehicle control loop and physical equations implemented within the deterministic Rust vehicle-control core and mirrored within the interactive Kotlin emulator.

## Core Closed-Loop Flow

```
RIDER → TORQUE/CADENCE → FILTER → VEHICLE STATE → PROPULSION STRATEGY → MOTOR COMMAND → PHYSICAL MODEL
                                                                               ↓
PHYSICAL MODEL FEEDBACK ← SENSORS ← CLOSED-LOOP ENERGY STATE ← REGEN CONTROL ← BRAKING FORCE
```

## System Equations

### 1. Dynamics and Propulsion
The vehicle acceleration is determined by sum of physical tractive forces:

$$\Sigma F = F_{\text{motor}} + F_{\text{rider}} - F_{\text{drag}} - F_{\text{roll}} - F_{\text{gravity}} - F_{\text{brakes}}$$

Where:
- $F_{\text{motor}} = \frac{T_{\text{motor}} \cdot G}{r_{\text{wheel}}}$
- $F_{\text{rider}} = \frac{T_{\text{rider}}}{r_{\text{wheel}}}$
- $F_{\text{drag}} = \frac{1}{2} C_d A \cdot \rho \cdot (v_{\text{bike}} + v_{\text{wind}})^2$
- $F_{\text{roll}} = m_{\text{total}} \cdot g \cdot C_{\text{rr}} \cdot \cos(\theta)$
- $F_{\text{gravity}} = m_{\text{total}} \cdot g \cdot \sin(\theta)$

The resulting acceleration is integrated to update velocity:
$$a = \frac{\Sigma F}{m_{\text{total}}}$$
$$v_{t+1} = v_t + a \cdot dt$$

### 2. Closed-loop Thermal Derating
To protect components, maximum target torque is governed by thermal limits:

$$T_{\text{max}} = T_{\text{mode}} \cdot \min(f_{\text{motor\_derate}}(T_{\text{motor}}), f_{\text{battery\_derate}}(T_{\text{battery}}), f_{\text{controller\_derate}}(T_{\text{controller}}))$$

### 3. Energy Recovery (Regenerative Braking)
During deceleration, the braking torque is split between regenerative braking and mechanical disc brakes:

$$T_{\text{brake\_total}} = P_{\text{brake\_pressure}} \cdot K_{\text{caliper}}$$
$$T_{\text{regen}} = T_{\text{brake\_total}} \cdot f_{\text{regen\_level}} \cdot \Phi_{\text{BMS\_charge\_acceptance}}(SOC, T_{\text{battery}})$$
$$T_{\text{friction}} = T_{\text{brake\_total}} - T_{\text{regen}}$$

## Real-Time Constraints
The embedded Rust loop runs on a hardware interrupt at exactly **1000 Hz** (1ms tick interval). Any loop jitter exceeding **50 µs** is flagged as a real-time diagnostics exception on the vehicle CAN bus.
