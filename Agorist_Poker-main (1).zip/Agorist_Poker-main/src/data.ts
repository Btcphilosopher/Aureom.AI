/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PokerTable, Player, LeaderboardEntry, Tournament } from './types';

export const INITIAL_TABLES: PokerTable[] = [
  // Cash Games
  {
    id: 'table-1',
    name: 'Satoshi VIP Lounge',
    type: 'highroller',
    blinds: '0.005 / 0.010 BTC',
    buyIn: '1.0 BTC Min',
    playersCount: 5,
    maxPlayers: 6,
    avgPot: 0.854,
    avgStack: 3.421,
    handsPerHour: 72,
    observerCount: 421,
    latencyMs: 14,
    connectionHealth: 'optimal'
  },
  {
    id: 'table-2',
    name: 'Hal Finney Memorial',
    type: 'highroller',
    blinds: '0.002 / 0.004 BTC',
    buyIn: '0.5 BTC Min',
    playersCount: 4,
    maxPlayers: 6,
    avgPot: 0.312,
    avgStack: 1.847,
    handsPerHour: 68,
    observerCount: 189,
    latencyMs: 18,
    connectionHealth: 'optimal'
  },
  {
    id: 'table-3',
    name: 'Genesis Block Arena',
    type: 'cash',
    blinds: '0.0005 / 0.0010 BTC',
    buyIn: '0.1 BTC Min',
    playersCount: 6,
    maxPlayers: 6,
    avgPot: 0.048,
    avgStack: 0.294,
    handsPerHour: 80,
    observerCount: 94,
    latencyMs: 22,
    connectionHealth: 'stable'
  },
  {
    id: 'table-4',
    name: 'Lightning Fast-Fold',
    type: 'lightning',
    blinds: '5,000 / 10,000 Sat',
    buyIn: '1,000,000 Sat',
    playersCount: 18,
    maxPlayers: 50,
    avgPot: 0.0018,
    avgStack: 0.0125,
    handsPerHour: 220,
    observerCount: 143,
    latencyMs: 8,
    connectionHealth: 'optimal'
  },
  {
    id: 'table-5',
    name: 'Cypherpunk Sanctum',
    type: 'cash',
    blinds: '0.0001 / 0.0002 BTC',
    buyIn: '0.02 BTC',
    playersCount: 3,
    maxPlayers: 6,
    avgPot: 0.0075,
    avgStack: 0.0412,
    handsPerHour: 75,
    observerCount: 38,
    latencyMs: 31,
    connectionHealth: 'stable'
  },
  {
    id: 'table-6',
    name: 'Monaco Sky Villa',
    type: 'highroller',
    blinds: '0.01 / 0.02 BTC',
    buyIn: '2.0 BTC Min',
    playersCount: 2,
    maxPlayers: 6,
    avgPot: 1.452,
    avgStack: 5.812,
    handsPerHour: 64,
    observerCount: 512,
    latencyMs: 12,
    connectionHealth: 'optimal'
  },
  // Tournaments
  {
    id: 'table-7',
    name: 'Tokyo Midnight Hyper',
    type: 'tournament',
    blinds: '50,000 / 100,000 Sat',
    buyIn: '0.05 BTC',
    playersCount: 84,
    maxPlayers: 200,
    avgPot: 4.21, // Accumulated pool
    avgStack: 0.154,
    handsPerHour: 95,
    observerCount: 231,
    latencyMs: 16,
    connectionHealth: 'optimal'
  },
  {
    id: 'table-8',
    name: 'The Agorist Cup',
    type: 'tournament',
    blinds: '1,000 / 2,000 Sat',
    buyIn: '0.1 BTC',
    playersCount: 124,
    maxPlayers: 500,
    avgPot: 12.4, // prize pool
    avgStack: 0.108,
    handsPerHour: 88,
    observerCount: 742,
    latencyMs: 20,
    connectionHealth: 'optimal'
  },
  {
    id: 'table-9',
    name: 'Decentralized Duel (S&G)',
    type: 'sitgo',
    blinds: '100 / 200 Sat',
    buyIn: '0.01 BTC',
    playersCount: 2,
    maxPlayers: 2,
    avgPot: 0.0196,
    avgStack: 0.01,
    handsPerHour: 110,
    observerCount: 19,
    latencyMs: 15,
    connectionHealth: 'optimal'
  }
];

export const OPPONENTS: Player[] = [
  {
    id: 'opp-1',
    name: 'Satoshi_99',
    country: 'Switzerland',
    countryCode: 'CH',
    winRate: 64.2,
    handsPlayed: 12405,
    currentStack: 1.452,
    recentAction: 'Thinking...',
    connectionQuality: 99,
    badge: 'Genesis Node',
    avatarSeed: 'p1'
  },
  {
    id: 'opp-2',
    name: 'ColdVault',
    country: 'Japan',
    countryCode: 'JP',
    winRate: 58.7,
    handsPlayed: 8520,
    currentStack: 0.894,
    recentAction: 'Called 0.01 BTC',
    connectionQuality: 98,
    badge: 'Validator',
    avatarSeed: 'p2'
  },
  {
    id: 'opp-3',
    name: 'GTO_Bot_Null',
    country: 'Germany',
    countryCode: 'DE',
    winRate: 61.1,
    handsPlayed: 32091,
    currentStack: 2.114,
    recentAction: 'Checked',
    connectionQuality: 100,
    badge: 'Satoshi Club',
    avatarSeed: 'p3'
  },
  {
    id: 'opp-4',
    name: 'Xverse_Pro',
    country: 'United States',
    countryCode: 'US',
    winRate: 52.4,
    handsPlayed: 4120,
    currentStack: 0.354,
    recentAction: 'Folded',
    connectionQuality: 94,
    badge: 'HODLer',
    avatarSeed: 'p4'
  },
  {
    id: 'opp-5',
    name: 'Hal_Acolyte',
    country: 'Singapore',
    countryCode: 'SG',
    winRate: 59.5,
    handsPlayed: 14920,
    currentStack: 1.182,
    recentAction: 'Raised 0.03 BTC',
    connectionQuality: 97,
    badge: 'Genesis Node',
    avatarSeed: 'p5'
  }
];

export const LEADERBOARD_DATA: LeaderboardEntry[] = [
  { rank: 1, name: 'Satoshi_99', country: 'Switzerland', countryCode: 'CH', bitcoinWon: 142.854, handsPlayed: 12405, winRate: 64.2, tier: 'Diamond' },
  { rank: 2, name: 'GTO_Bot_Null', country: 'Germany', countryCode: 'DE', bitcoinWon: 98.412, handsPlayed: 32091, winRate: 61.1, tier: 'Diamond' },
  { rank: 3, name: 'Hal_Acolyte', country: 'Singapore', countryCode: 'SG', bitcoinWon: 74.195, handsPlayed: 14920, winRate: 59.5, tier: 'Titanium' },
  { rank: 4, name: 'ColdVault', country: 'Japan', countryCode: 'JP', bitcoinWon: 56.894, handsPlayed: 8520, winRate: 58.7, tier: 'Titanium' },
  { rank: 5, name: 'Block9_Miner', country: 'Iceland', countryCode: 'IS', bitcoinWon: 41.205, handsPlayed: 9410, winRate: 55.4, tier: 'Gold' },
  { rank: 6, name: 'Taproot_Wizard', country: 'Austria', countryCode: 'AT', bitcoinWon: 38.452, handsPlayed: 11040, winRate: 54.1, tier: 'Gold' },
  { rank: 7, name: 'Nostr_Whale', country: 'Brazil', countryCode: 'BR', bitcoinWon: 29.845, handsPlayed: 6310, winRate: 53.8, tier: 'Gold' },
  { rank: 8, name: 'Leather_User_1', country: 'United Kingdom', countryCode: 'GB', bitcoinWon: 22.412, handsPlayed: 7450, winRate: 51.9, tier: 'Gold' }
];

export const ACTIVE_TOURNAMENTS: Tournament[] = [
  {
    id: 't-1',
    title: 'THE AGORIST CLASSIC',
    prizePool: '10.0 BTC Guaranteed',
    entrants: 312,
    maxEntrants: 500,
    buyIn: '0.05 BTC',
    timeLeftSeconds: 5210,
    blindTimerSeconds: 420,
    currentLevel: 8,
    status: 'active'
  },
  {
    id: 't-2',
    title: 'HIGH ROLLER NO-LIMIT DUEL',
    prizePool: '15.0 BTC Guaranteed',
    entrants: 18,
    maxEntrants: 32,
    buyIn: '1.0 BTC',
    timeLeftSeconds: 0,
    blindTimerSeconds: 600,
    currentLevel: 1,
    status: 'registering'
  },
  {
    id: 't-3',
    title: 'HAL FINNEY MEMORIAL BOUNTY',
    prizePool: '5.0 BTC Guaranteed',
    entrants: 412,
    maxEntrants: 1000,
    buyIn: '0.01 BTC',
    timeLeftSeconds: 12400,
    blindTimerSeconds: 300,
    currentLevel: 4,
    status: 'active'
  }
];

export const SUPPORTED_WALLETS = [
  { id: 'alby', name: 'Alby (Lightning)', icon: '⚡' },
  { id: 'xverse', name: 'Xverse (Ordinals/On-Chain)', icon: '🟠' },
  { id: 'leather', name: 'Leather', icon: '💀' },
  { id: 'unisat', name: 'Unisat Wallet', icon: '🪙' },
  { id: 'nostr', name: 'Nostr Signer', icon: '💜' },
  { id: 'passkeys', name: 'Passkeys Secure Enclave', icon: '🔑' }
];
