/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Cpu, ShieldCheck, Wallet, ChevronRight } from 'lucide-react';

interface HeaderProps {
  currentView: string;
  setView: (view: string) => void;
  walletAddress: string | null;
  onConnectWallet: () => void;
  onDisconnectWallet: () => void;
}

export default function Header({
  currentView,
  setView,
  walletAddress,
  onConnectWallet,
  onDisconnectWallet,
}: HeaderProps) {
  const [latency, setLatency] = useState(12);

  // Simulate network latency fluctuations for Tokyo luxury server node
  useEffect(() => {
    const interval = setInterval(() => {
      setLatency(prev => {
        const delta = Math.floor(Math.random() * 5) - 2;
        const next = prev + delta;
        return next < 5 ? 6 : next > 25 ? 20 : next;
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/[0.06] bg-[#060606]/95 backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 lg:px-8">
        
        {/* Logo / Insignia - Sophisticated styling */}
        <div 
          onClick={() => setView('home')} 
          className="flex cursor-pointer items-center space-x-3 group"
          id="header-logo"
        >
          <div className="relative flex h-9 w-9 items-center justify-center rounded-none bg-transparent border border-white/[0.1] group-hover:border-[#F2A900] transition-colors duration-300">
            {/* Custom abstract geometric gold Agorist insignia (Minimal Triangle letter A with sharp styling) */}
            <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[12px] border-b-[#F2A900] relative group-hover:scale-110 transition-transform duration-300">
              <div className="absolute top-[4px] left-[-2px] w-0 h-0 border-l-[2px] border-l-transparent border-r-[2px] border-r-transparent border-b-[4px] border-b-[#060606]" />
            </div>
          </div>
          <span className="font-display text-lg font-bold tracking-[0.2em] uppercase text-[#F7F7F7]">
            Agorist <span className="text-[#F2A900]">Poker</span>
          </span>
        </div>

        {/* Editorial Swiss Navigation */}
        <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 font-sans text-[11px] uppercase tracking-widest font-medium text-[#B7B7B7]">
          {[
            { id: 'lobby', label: 'Poker Lobby' },
            { id: 'table', label: 'Live Table' },
            { id: 'fairness', label: 'Provably Fair' },
            { id: 'leaderboard', label: 'Leaderboards' },
            { id: 'security', label: 'Treasury' },
          ].map(item => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setView(item.id)}
                className={`relative px-4 py-2 rounded-none transition-colors duration-200 hover:text-[#F2A900] ${
                  isActive ? 'text-[#F2A900] bg-white/[0.03]' : ''
                }`}
                id={`nav-${item.id}`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-4 right-4 h-[1px] bg-[#F2A900]" />
                )}
              </button>
            );
          })}
        </nav>

        {/* System telemetry & Authentication */}
        <div className="flex items-center space-x-6">
          
          {/* Network Liquidity Stat Display from Sophisticated Dark design */}
          <div className="hidden lg:flex flex-col items-end text-right">
            <span className="text-[10px] text-[#6E6E6E] uppercase tracking-wider font-mono">Network Liquidity</span>
            <span className="text-xs font-mono text-[#4ADE80] font-bold">1,248.42 BTC</span>
          </div>

          {/* Cryptographic Auth Button */}
          {walletAddress ? (
            <div className="flex items-center space-x-3 bg-white/[0.02] border border-white/[0.08] px-4 py-2.5 rounded-none font-mono text-xs text-[#F7F7F7]" id="user-wallet-pill">
              <div className="w-1.5 h-1.5 rounded-full bg-[#4ADE80] shadow-[0_0_8px_#4ADE80]"></div>
              <span className="text-[#B7B7B7]">
                {walletAddress.substring(0, 6)}...{walletAddress.substring(walletAddress.length - 4)}
              </span>
              <button
                onClick={onDisconnectWallet}
                className="ml-2 pl-2 border-l border-white/[0.08] text-[#FF5A5A] hover:text-white transition-colors text-[10px]"
                title="Disconnect Cryptographic Session"
                id="btn-disconnect-wallet"
              >
                EXIT
              </button>
            </div>
          ) : (
            <button
              onClick={onConnectWallet}
              className="px-6 py-2.5 bg-transparent border border-white/[0.1] rounded-none hover:bg-white/5 transition-all text-[11px] font-bold uppercase tracking-widest flex items-center gap-3 text-[#F7F7F7]"
              id="btn-sign-in-nav"
            >
              <span>Authenticate</span>
              <div className="w-1.5 h-1.5 rounded-full bg-[#F2A900] shadow-[0_0_8px_#F2A900]"></div>
            </button>
          )}

        </div>
      </div>
    </header>
  );
}
