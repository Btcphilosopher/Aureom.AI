/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, Users, Eye, ArrowUpRight, ShieldCheck, HeartPulse, Sparkles } from 'lucide-react';
import { PokerTable, TableType } from '../types';
import { INITIAL_TABLES, OPPONENTS } from '../data';

interface LobbyProps {
  setView: (view: string) => void;
  onSelectTable: (tableId: string) => void;
}

export default function Lobby({ setView, onSelectTable }: LobbyProps) {
  const [tables, setTables] = useState<PokerTable[]>(INITIAL_TABLES);
  const [filterType, setFilterType] = useState<TableType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [hoveredTableId, setHoveredTableId] = useState<string | null>(null);

  // Real-time updates: simulate live card-room traffic fluctuations (very Bloomberg)
  useEffect(() => {
    const timer = setInterval(() => {
      setTables(prevTables =>
        prevTables.map(table => {
          // Occasional tiny flux in players, avg pots, and observers
          const shouldUpdate = Math.random() > 0.6;
          if (!shouldUpdate) return table;

          // fluctuate players count within normal bounds
          let nextPlayers = table.playersCount;
          if (Math.random() > 0.85) {
            const delta = Math.random() > 0.5 ? 1 : -1;
            nextPlayers = Math.max(1, Math.min(table.maxPlayers, table.playersCount + delta));
          }

          // fluctuate average pot slightly (e.g. +-5%)
          const potFlux = 1 + (Math.random() * 0.1 - 0.05);
          const nextPot = Number((table.avgPot * potFlux).toFixed(4));

          // fluctuate observer count
          const obsFlux = Math.floor(Math.random() * 11) - 5;
          const nextObs = Math.max(0, table.observerCount + obsFlux);

          return {
            ...table,
            playersCount: nextPlayers,
            avgPot: nextPot,
            observerCount: nextObs,
          };
        })
      );
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  // Filter & Search Logic
  const filteredTables = tables.filter(table => {
    const matchesFilter = filterType === 'all' || table.type === filterType;
    const matchesSearch = table.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          table.blinds.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getBadgeColor = (type: TableType) => {
    switch (type) {
      case 'highroller': return 'text-[#F2A900] bg-[#F2A900]/10 border-[#F2A900]/20';
      case 'lightning': return 'text-[#4FA8FF] bg-[#4FA8FF]/10 border-[#4FA8FF]/20';
      case 'tournament': return 'text-[#4ADE80] bg-[#4ADE80]/10 border-[#4ADE80]/20';
      default: return 'text-[#B7B7B7] bg-white/[0.02] border-white/[0.08]';
    }
  };

  const handleSeatClick = (tableId: string) => {
    onSelectTable(tableId);
    setView('table');
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10 lg:px-8 bg-[#060606]">
      
      {/* 1. Header with live stats banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/[0.06] pb-6 gap-4">
        <div>
          <h2 className="font-display text-xl font-extrabold text-[#F7F7F7] uppercase tracking-widest">
            Cryptographic Poker Lobby
          </h2>
          <p className="text-xs text-[#B7B7B7] mt-1 font-sans">
            Real-time server nodes. Peer-to-peer liquidity verification.
          </p>
        </div>

        {/* Real-time system feed status */}
        <div className="flex items-center space-x-4 bg-white/[0.02] border border-white/[0.08] rounded-none px-4 py-2.5 font-mono text-[10px] text-[#6E6E6E]">
          <div className="flex items-center space-x-1.5">
            <span className="h-2 w-2 rounded-full bg-[#4ADE80]" />
            <span className="text-[#B7B7B7]">LIQUIDITY FEED: ACTIVE</span>
          </div>
          <span className="text-white/[0.1]">|</span>
          <div>
            <span>GLOBAL ESCROW: </span>
            <span className="text-[#F2A900] font-bold">1,842.105 BTC</span>
          </div>
        </div>
      </div>

      {/* 2. Search, filter bar, and category list */}
      <div className="mt-6 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        
        {/* Category filters */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 xl:pb-0 scrollbar-none font-sans text-[11px] uppercase tracking-wider font-semibold">
          {[
            { id: 'all', label: 'All Tables' },
            { id: 'highroller', label: 'High Roller' },
            { id: 'cash', label: 'Cash Games' },
            { id: 'lightning', label: 'Lightning Tables' },
            { id: 'tournament', label: 'Tournaments' },
            { id: 'sitgo', label: 'Sit & Go' }
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => setFilterType(cat.id as TableType | 'all')}
              className={`px-4 py-2 rounded-none border transition-all shrink-0 cursor-pointer ${
                filterType === cat.id
                  ? 'bg-[#F2A900]/10 border-[#F2A900] text-[#F2A900]'
                  : 'bg-white/[0.02] border-white/[0.08] text-[#B7B7B7] hover:text-[#F2A900] hover:bg-white/5'
              }`}
              id={`filter-btn-${cat.id}`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search input bar */}
        <div className="flex items-center space-x-3 w-full xl:w-80 shrink-0">
          <div className="relative w-full">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6E6E6E]" />
            <input
              type="text"
              placeholder="Search Table, Stakes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-none border border-white/[0.08] bg-[#111111] py-2.5 pl-10 pr-4 text-xs text-[#F7F7F7] placeholder-[#6E6E6E] outline-none focus:border-[#F2A900]/50 transition-colors font-sans"
              id="lobby-search-input"
            />
          </div>
        </div>
      </div>

      {/* 3. Terminal High-Density Table List Grid */}
      <div className="mt-8 grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        
        {/* Main table listings */}
        <div className="xl:col-span-8 space-y-3">
          {filteredTables.length === 0 ? (
            <div className="rounded-none border border-white/[0.08] bg-[#111111] p-12 text-center font-sans text-xs text-[#6E6E6E]">
              No active poker nodes matching current configuration filter.
            </div>
          ) : (
            filteredTables.map((table) => {
              const isHovered = hoveredTableId === table.id;
              return (
                <div
                  key={table.id}
                  onMouseEnter={() => setHoveredTableId(table.id)}
                  onMouseLeave={() => setHoveredTableId(null)}
                  className={`group relative rounded-none border p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all duration-300 bg-gradient-to-r ${
                    isHovered 
                      ? 'border-[#F2A900]/40 from-[#161616] to-[#111111] translate-x-1 shadow-lg' 
                      : 'border-white/[0.08] from-[#111111] to-[#0d0d0d]'
                  }`}
                  id={`lobby-table-row-${table.id}`}
                >
                  {/* Left Column: Table details */}
                  <div className="flex items-start space-x-4">
                    {/* Status lights & Icon */}
                    <div className="mt-1 relative flex h-7 w-7 items-center justify-center rounded-none bg-white/[0.02] border border-white/[0.08] text-xs font-mono text-[#F2A900]">
                      <span>♠</span>
                      <span className="absolute bottom-0 right-0 h-1.5 w-1.5 rounded-none bg-[#4ADE80]" />
                    </div>
                    
                    <div className="space-y-1 text-left">
                      <div className="flex items-center space-x-2">
                        <span className="font-display text-sm font-bold text-[#F7F7F7]">
                          {table.name}
                        </span>
                        <span className={`text-[8px] font-mono border rounded-none px-2 py-0.5 uppercase ${getBadgeColor(table.type)}`}>
                          {table.type}
                        </span>
                      </div>
                      
                      {/* Sub values */}
                      <div className="flex items-center space-x-3 text-[10px] font-mono text-[#B7B7B7]">
                        <span>Blinds: <strong className="text-[#F7F7F7]">{table.blinds}</strong></span>
                        <span className="text-white/[0.08]">•</span>
                        <span>Min Buy-In: <strong className="text-[#F2A900]">{table.buyIn}</strong></span>
                      </div>
                    </div>
                  </div>

                  {/* Middle Column: Player capacity & statistics */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-1 text-left font-mono text-[11px] border-t sm:border-t-0 border-white/[0.04] pt-3 sm:pt-0 w-full sm:w-auto">
                    
                    {/* Seated capacity */}
                    <div className="space-y-0.5">
                      <span className="text-[#6E6E6E] text-[9px] uppercase tracking-wider block">Players</span>
                      <div className="flex items-center space-x-1 text-[#F7F7F7]">
                        <Users className="h-3 w-3 text-[#B7B7B7]" />
                        <span>{table.playersCount} / {table.maxPlayers}</span>
                      </div>
                    </div>

                    {/* Avg Pot in SAT / BTC */}
                    <div className="space-y-0.5">
                      <span className="text-[#6E6E6E] text-[9px] uppercase tracking-wider block">Avg Pot</span>
                      <span className="text-[#F2A900] font-bold">{table.avgPot} BTC</span>
                    </div>

                    {/* Latency and quality */}
                    <div className="space-y-0.5 hidden sm:block">
                      <span className="text-[#6E6E6E] text-[9px] uppercase tracking-wider block">Latency</span>
                      <span className="text-[#4ADE80] font-sans">{table.latencyMs}ms</span>
                    </div>

                  </div>

                  {/* Right Column: CTA Actions */}
                  <div className="flex items-center space-x-2 w-full sm:w-auto mt-2 sm:mt-0">
                    <button
                      onClick={() => handleSeatClick(table.id)}
                      className="flex-1 sm:flex-none inline-flex h-9 items-center justify-center rounded-none bg-[#F2A900] px-5 font-sans text-[11px] font-bold uppercase tracking-widest text-[#060606] hover:bg-[#FFBD14] transition-all cursor-pointer"
                      id={`btn-table-play-${table.id}`}
                    >
                      Play
                    </button>
                    <button
                      onClick={() => handleSeatClick(table.id)}
                      className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-none border border-white/[0.08] bg-transparent hover:bg-white/5 text-[#B7B7B7] hover:text-[#F7F7F7] transition-colors cursor-pointer"
                      title="Spectate"
                      id={`btn-table-watch-${table.id}`}
                    >
                      <Eye className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* RIGHT COLUMN: Highly visual live game dashboard preview */}
        <div className="xl:col-span-4 rounded-none border border-white/[0.08] bg-[#111111] p-5 shadow-2xl space-y-5 text-left sticky top-28">
          
          <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
            <h3 className="font-display text-xs font-bold text-[#F7F7F7] uppercase tracking-widest flex items-center space-x-2">
              <Sparkles className="h-3.5 w-3.5 text-[#F2A900]" />
              <span>Table Analyzer</span>
            </h3>
            <span className="text-[9px] font-mono text-[#6E6E6E]">PREVIEW ENGINE</span>
          </div>

          {/* Render detail view of hovered table */}
          {hoveredTableId ? (
            (() => {
              const activeTable = tables.find(t => t.id === hoveredTableId);
              if (!activeTable) return null;
              
              return (
                <div className="space-y-4" id="table-hover-panel">
                  {/* Table title card info */}
                  <div className="bg-[#0d0d0d] border border-white/[0.06] rounded-none p-3">
                    <div className="font-display text-sm font-bold text-[#F2A900] uppercase tracking-wider">
                      {activeTable.name}
                    </div>
                    <div className="grid grid-cols-2 gap-3 mt-3 text-[10px] font-mono text-[#B7B7B7]">
                      <div>
                        <span className="text-[#6E6E6E] block text-[8px] uppercase">Averge Stack</span>
                        <strong className="text-white">{activeTable.avgStack} BTC</strong>
                      </div>
                      <div>
                        <span className="text-[#6E6E6E] block text-[8px] uppercase">Hands/Hour</span>
                        <strong className="text-white">{activeTable.handsPerHour} H/hr</strong>
                      </div>
                      <div>
                        <span className="text-[#6E6E6E] block text-[8px] uppercase">Observers</span>
                        <strong className="text-white">{activeTable.observerCount}</strong>
                      </div>
                      <div>
                        <span className="text-[#6E6E6E] block text-[8px] uppercase">Node Status</span>
                        <strong className="text-[#4ADE80]">OPTIMAL</strong>
                      </div>
                    </div>
                  </div>

                  {/* Simulated seated player list (direct mapping request) */}
                  <div className="space-y-2">
                    <span className="text-[8px] font-mono text-[#6E6E6E] uppercase tracking-widest block">
                      Seated Players ({activeTable.playersCount} Seated)
                    </span>
                    
                    <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-1">
                      {OPPONENTS.slice(0, activeTable.playersCount).map((player, idx) => (
                        <div key={idx} className="flex items-center justify-between p-2 rounded-none bg-[#0a0a0a] border border-white/[0.04] text-[10px] font-mono">
                          <div className="flex items-center space-x-2">
                            {/* Player country code flag indicator */}
                            <span className="text-xs">{player.countryCode === 'CH' ? '🇨🇭' : player.countryCode === 'JP' ? '🇯🇵' : player.countryCode === 'DE' ? '🇩🇪' : player.countryCode === 'US' ? '🇺🇸' : '🇸🇬'}</span>
                            <span className="text-white font-bold">{player.name}</span>
                            <span className="text-[8px] bg-white/[0.03] border border-white/[0.08] text-[#6E6E6E] px-1 rounded-none">
                              {player.badge.split(' ')[0]}
                            </span>
                          </div>
                          <div className="text-right">
                            <span className="text-[#F2A900] font-bold">{player.currentStack.toFixed(3)} BTC</span>
                            <span className="text-[#6E6E6E] block text-[8px]">Win Rate: {player.winRate}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="text-[9px] font-mono text-[#6E6E6E] bg-[#0a0a0a] border border-white/[0.04] rounded-none p-2.5 leading-relaxed text-left">
                    🔍 <em>Security Audit: All seated players possess verified hardware signatures. Zero escrow risk.</em>
                  </div>
                </div>
              );
            })()
          ) : (
            <div className="py-12 text-center text-[#6E6E6E] font-sans text-xs">
              Hover over any active table node in the list to reveal micro player profiles, seat structures, and GTO metrics.
            </div>
          )}

        </div>
      </div>

    </div>
  );
}
