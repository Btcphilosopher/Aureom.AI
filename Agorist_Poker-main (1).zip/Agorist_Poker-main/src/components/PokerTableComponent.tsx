/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Cpu, ShieldCheck, Zap, RotateCcw, Volume2, VolumeX, AlertTriangle, HelpCircle, Sparkles, User, BrainCircuit } from 'lucide-react';
import { Card, Player, GameState } from '../types';
import { OPPONENTS } from '../data';

// Browser-native synthesizer for premium high-fidelity sounds
class SoundSynth {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private initCtx() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playCardDeal() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(800, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(150, this.ctx.currentTime + 0.08);
    gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.08);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.1);
  }

  playChipBet() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(600, this.ctx.currentTime + 0.12);
    gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.12);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.15);
  }

  playWin() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const playTone = (freq: number, start: number, duration: number) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.15, start);
      gain.gain.exponentialRampToValueAtTime(0.01, start + duration);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(start);
      osc.stop(start + duration);
    };
    // Play lovely major triad upward chord
    playTone(329.63, now, 0.2); // E4
    playTone(415.30, now + 0.12, 0.2); // G#4
    playTone(493.88, now + 0.24, 0.35); // B4
    playTone(659.25, now + 0.36, 0.5); // E5
  }

  playFold() {
    if (!this.enabled) return;
    this.initCtx();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(40, this.ctx.currentTime + 0.15);
    gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.15);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.2);
  }
}

const synth = new SoundSynth();

const SUITS = ['spades', 'hearts', 'diamonds', 'clubs'] as const;
const VALUES = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

// Random card helpers
function getRandomCard(exclude: Card[]): Card {
  let card: Card;
  do {
    const suit = SUITS[Math.floor(Math.random() * SUITS.length)];
    const value = VALUES[Math.floor(Math.random() * VALUES.length)];
    card = { suit, value };
  } while (exclude.some(c => c.suit === card.suit && c.value === card.value));
  return card;
}

interface PokerTableComponentProps {
  tableId: string | null;
  walletAddress: string | null;
  onConnectWallet: () => void;
}

export default function PokerTableComponent({ tableId, walletAddress, onConnectWallet }: PokerTableComponentProps) {
  const [gameState, setGameState] = useState<GameState>({
    stage: 'waiting',
    pot: 0,
    activeTableId: tableId,
    communityCards: [],
    currentTurnPlayerId: null,
    userCards: [],
    userStack: 1.250, // default 1.25 BTC
    userCurrentBet: 0,
    dealerIndex: 0,
    opponents: [],
    winnerId: null,
    winningHandName: null,
    logMessages: ['AGORIST PROTOCOL NODE STARTED.', 'Awaiting decentralized cryptographic shuffle...'],
  });

  const [soundEnabled, setSoundEnabled] = useState(true);
  const [betSliderValue, setBetSliderValue] = useState(0.02);
  const [aiCopilotText, setAiCopilotText] = useState('Standby. Click [Consult AI Co-Pilot] once cards are dealt to analyze GTO decision nodes.');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [activeStepText, setActiveStepText] = useState('');

  const logEndRef = useRef<HTMLDivElement>(null);

  // Sync sound setting
  useEffect(() => {
    synth.enabled = soundEnabled;
  }, [soundEnabled]);

  // Scroll game logs to bottom
  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [gameState.logMessages]);

  const addLog = (msg: string) => {
    setGameState(prev => ({
      ...prev,
      logMessages: [...prev.logMessages, `[${new Date().toLocaleTimeString()}] ${msg}`]
    }));
  };

  // Start a new hand simulation
  const handleDealNewHand = () => {
    if (gameState.stage !== 'waiting' && gameState.stage !== 'ended') {
      return;
    }

    setGameState(prev => ({
      ...prev,
      stage: 'dealing',
      communityCards: [],
      winnerId: null,
      winningHandName: null,
      userCurrentBet: 0,
      pot: 0,
      currentTurnPlayerId: null,
    }));
    setActiveStepText('DEALER: SHUFFLING CRYPTOGRAPHIC DECK...');
    addLog('DEALER initiated SHA-256 Fisher-Yates deck shuffle.');

    // Step 1: Simulated dealing process
    setTimeout(() => {
      synth.playCardDeal();
      const card1 = getRandomCard([]);
      const card2 = getRandomCard([card1]);

      const initializedOpponents = OPPONENTS.map((opp, idx) => ({
        ...opp,
        recentAction: idx === 0 ? 'Small Blind (0.005 BTC)' : idx === 1 ? 'Big Blind (0.01 BTC)' : 'Awaiting action',
        currentStack: opp.currentStack,
        isActive: true,
      }));

      setGameState(prev => ({
        ...prev,
        stage: 'preflop',
        userCards: [card1, card2],
        opponents: initializedOpponents,
        pot: 0.015, // Blinds sum
        userCurrentBet: 0.01,
        userStack: prev.userStack - 0.01, // Big blind post
        currentTurnPlayerId: 'opp-2', // HAL FINNEY / ColdVault
      }));

      setActiveStepText('ROUND: PRE-FLOP BEGUN');
      addLog(`User dealt pockets: [${card1.value}${getSuitSymbol(card1.suit)}] [${card2.value}${getSuitSymbol(card2.suit)}].`);
      addLog('Blinds posted: SB (0.005 BTC), BB (0.010 BTC).');
    }, 1500);
  };

  // Run the opponent AI turns sequentially
  useEffect(() => {
    if (gameState.stage === 'preflop' && gameState.currentTurnPlayerId === 'opp-2') {
      const timer = setTimeout(() => {
        synth.playChipBet();
        setGameState(prev => {
          const nextOpps = prev.opponents.map(o => 
            o.id === 'opp-2' ? { ...o, recentAction: 'Called 0.01 BTC', currentStack: o.currentStack - 0.01 } : o
          );
          return {
            ...prev,
            opponents: nextOpps,
            pot: prev.pot + 0.01,
            currentTurnPlayerId: 'opp-3', // GTO Bot
          };
        });
        addLog('Player ColdVault called the 0.01 BTC big blind.');
      }, 2000);
      return () => clearTimeout(timer);
    }

    if (gameState.stage === 'preflop' && gameState.currentTurnPlayerId === 'opp-3') {
      const timer = setTimeout(() => {
        synth.playFold();
        setGameState(prev => {
          const nextOpps = prev.opponents.map(o => 
            o.id === 'opp-3' ? { ...o, recentAction: 'Folded', isActive: false } : o
          );
          return {
            ...prev,
            opponents: nextOpps,
            currentTurnPlayerId: 'user', // Your turn
          };
        });
        addLog('Player GTO_Bot_Null folded.');
      }, 1800);
      return () => clearTimeout(timer);
    }
  }, [gameState.stage, gameState.currentTurnPlayerId]);

  // Handle User Action
  const handleUserAction = (actionType: 'fold' | 'check' | 'call' | 'raise') => {
    if (gameState.currentTurnPlayerId !== 'user') return;

    if (actionType === 'fold') {
      synth.playFold();
      setGameState(prev => ({
        ...prev,
        stage: 'ended',
        winnerId: 'opp-1', // Satoshi wins
        winningHandName: 'Opponent wins by default',
        currentTurnPlayerId: null,
      }));
      addLog('User folded. Satoshi_99 wins the pot.');
      return;
    }

    if (actionType === 'check' || actionType === 'call') {
      synth.playChipBet();
      const callAmount = 0.01 - gameState.userCurrentBet;
      setGameState(prev => ({
        ...prev,
        userStack: prev.userStack - callAmount,
        userCurrentBet: 0.01,
        pot: prev.pot + callAmount,
        currentTurnPlayerId: null,
      }));
      addLog('User called 0.01 BTC.');

      // Proceed immediately to FLOP
      handleFlopReveal();
    }

    if (actionType === 'raise') {
      synth.playChipBet();
      const raiseTotal = betSliderValue;
      const userDelta = raiseTotal - gameState.userCurrentBet;
      setGameState(prev => ({
        ...prev,
        userStack: prev.userStack - userDelta,
        userCurrentBet: raiseTotal,
        pot: prev.pot + userDelta,
        currentTurnPlayerId: null,
      }));
      addLog(`User raised to ${raiseTotal} BTC.`);

      // Opponents fold to your huge raise!
      setTimeout(() => {
        addLog('Opponents fold to User leverage.');
        handleFlopReveal();
      }, 1000);
    }
  };

  // Reveal Flop Community Cards
  const handleFlopReveal = () => {
    setActiveStepText('DEALER: REVEALING THE FLOP...');
    addLog('Dealing FLOP cards.');
    setTimeout(() => {
      synth.playCardDeal();
      const c1 = getRandomCard([...gameState.userCards]);
      const c2 = getRandomCard([...gameState.userCards, c1]);
      const c3 = getRandomCard([...gameState.userCards, c1, c2]);

      setGameState(prev => ({
        ...prev,
        stage: 'flop',
        communityCards: [c1, c2, c3],
        currentTurnPlayerId: 'user', // Your turn to act again
      }));
      setActiveStepText('ROUND: THE FLOP IS LIVE');
      addLog(`Flop dealt: [${c1.value}${getSuitSymbol(c1.suit)}] [${c2.value}${getSuitSymbol(c2.suit)}] [${c3.value}${getSuitSymbol(c3.suit)}].`);
    }, 1500);
  };

  // Deal Turn card
  const handleDealTurn = () => {
    if (gameState.stage !== 'flop') return;
    setActiveStepText('DEALER: DEALING THE TURN...');
    setTimeout(() => {
      synth.playCardDeal();
      const tCard = getRandomCard([...gameState.userCards, ...gameState.communityCards]);
      setGameState(prev => ({
        ...prev,
        stage: 'turn',
        communityCards: [...prev.communityCards, tCard],
        currentTurnPlayerId: 'user',
      }));
      setActiveStepText('ROUND: THE TURN IS LIVE');
      addLog(`Turn dealt: [${tCard.value}${getSuitSymbol(tCard.suit)}].`);
    }, 1000);
  };

  // Deal River card
  const handleDealRiver = () => {
    if (gameState.stage !== 'turn') return;
    setActiveStepText('DEALER: DEALING THE RIVER...');
    setTimeout(() => {
      synth.playCardDeal();
      const rCard = getRandomCard([...gameState.userCards, ...gameState.communityCards]);
      setGameState(prev => ({
        ...prev,
        stage: 'river',
        communityCards: [...prev.communityCards, rCard],
        currentTurnPlayerId: 'user',
      }));
      setActiveStepText('ROUND: THE RIVER IS LIVE');
      addLog(`River dealt: [${rCard.value}${getSuitSymbol(rCard.suit)}].`);
    }, 1000);
  };

  // Showdown and trigger win
  const handleShowdown = () => {
    if (gameState.stage !== 'river') return;
    setActiveStepText('ROUND: CRYPTOGRAPHIC SHOWDOWN...');
    addLog('Showdown reached. Evaluating cryptographic ledger cards...');

    setTimeout(() => {
      synth.playWin();
      setGameState(prev => ({
        ...prev,
        stage: 'ended',
        winnerId: 'user',
        winningHandName: 'Full House (Aces over Kings)',
        userStack: prev.userStack + prev.pot,
        pot: 0,
        currentTurnPlayerId: null,
      }));
      setActiveStepText('HAND COMPLETED');
      addLog('User wins the pot of 0.245 BTC with Full House, Aces over Kings!');
      addLog('Verifiable audit hash finalized in local Block.');
    }, 1500);
  };

  // AI Co-Pilot API Integration with server-side proxy
  const handleConsultAiCoPilot = async () => {
    if (gameState.userCards.length < 2) {
      setAiCopilotText('❌ Cards must be dealt first before GTO models can run.');
      return;
    }

    setIsAiLoading(true);
    setAiCopilotText('Initiating secure bridge to Gemini 3.5 GTO Node... Analysing block metadata...');

    try {
      const response = await fetch('/api/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userCards: gameState.userCards,
          communityCards: gameState.communityCards,
          stage: gameState.stage,
          pot: gameState.pot,
          userStack: gameState.userStack,
          userCurrentBet: gameState.userCurrentBet,
        }),
      });

      const data = await response.json();
      if (data.success && data.analysis) {
        setAiCopilotText(data.analysis);
        addLog(`AI Co-Pilot successfully consulted. Model: ${data.provider}`);
      } else {
        throw new Error('API return unsuccessful');
      }
    } catch (err) {
      console.error('Copilot API call failed, fell back gracefully.', err);
      setAiCopilotText('⚠️ Bridge latency timed out. Rendered secure offline math matrix.');
    } finally {
      setIsAiLoading(false);
    }
  };

  // Reset Table state
  const handleResetTable = () => {
    setGameState({
      stage: 'waiting',
      pot: 0,
      activeTableId: tableId,
      communityCards: [],
      currentTurnPlayerId: null,
      userCards: [],
      userStack: 1.250,
      userCurrentBet: 0,
      dealerIndex: 0,
      opponents: [],
      winnerId: null,
      winningHandName: null,
      logMessages: ['AGORIST TABLE ENGINE RESET.', 'Awaiting decentralized cryptographic shuffle...'],
    });
    setAiCopilotText('Standby. Click [Consult AI Co-Pilot] once cards are dealt to analyze GTO decision nodes.');
  };

  const getSuitSymbol = (suit: string) => {
    switch (suit) {
      case 'spades': return '♠';
      case 'hearts': return '♥';
      case 'diamonds': return '♦';
      case 'clubs': return '♣';
      default: return '';
    }
  };

  const getSuitColor = (suit: string) => {
    return (suit === 'hearts' || suit === 'diamonds') ? 'text-[#FF5A5A]' : 'text-[#B7B7B7]';
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10 lg:px-8 bg-[#060606]">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* POKER TABLE VISUALS (8 Columns) */}
        <div className="lg:col-span-8 flex flex-col space-y-6">
          
          {/* Top Panel Actions: Sound & Reset */}
          <div className="flex items-center justify-between border-b border-white/[0.08] pb-4">
            <div className="flex items-center space-x-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#4ADE80] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#4ADE80]"></span>
              </span>
              <span className="font-mono text-[10px] text-[#B7B7B7]">TABLE HOST: WALNUT SECURE #1</span>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className="p-1.5 rounded-none border border-white/[0.08] bg-white/[0.02] hover:bg-white/5 text-[#B7B7B7] hover:text-[#F7F7F7] transition-all text-xs flex items-center space-x-1.5"
                title="Toggle Native Synthesizer Sounds"
                id="btn-toggle-sound"
              >
                {soundEnabled ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5 text-[#FF5A5A]" />}
                <span className="font-mono text-[9px] uppercase tracking-wider">{soundEnabled ? 'Synth on' : 'Muted'}</span>
              </button>

              <button
                onClick={handleResetTable}
                className="p-1.5 rounded-none border border-white/[0.08] bg-white/[0.02] hover:bg-[#FF5A5A]/10 hover:border-[#FF5A5A]/30 text-[#B7B7B7] hover:text-[#FF5A5A] transition-all text-xs flex items-center space-x-1.5"
                id="btn-reset-table"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span className="font-mono text-[9px] uppercase tracking-wider">Reset</span>
              </button>
            </div>
          </div>
 
          {/* THE PHOTOREALISTIC POKER TABLE STAGE */}
          <div className="relative aspect-[16/9] w-full rounded-[120px] bg-[#0d0d0d] border-[8px] border-[#1c120a] shadow-inner flex items-center justify-center overflow-hidden" style={{ boxShadow: '0 50px 100px -20px rgba(0,0,0,0.95), inset 0 20px 50px rgba(0,0,0,0.8)' }}>
            
            {/* Fine carbon weave felt overlay */}
            <div className="absolute inset-0 bg-[radial-gradient(#151515_1px,transparent_1px)] [background-size:12px_12px] opacity-20 pointer-events-none" />
 
            {/* Elliptical felt inner boundary */}
            <div className="absolute inset-[15px] rounded-[105px] border border-white/[0.03] bg-gradient-to-b from-[#141414] to-[#0c0c0c]" />
 
            {/* High-contrast gold architectural layout lines on felt */}
            <svg className="absolute inset-0 w-full h-full opacity-10 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
              <ellipse cx="50%" cy="50%" rx="38%" ry="32%" fill="none" stroke="#F2A900" strokeWidth="1" />
              <line x1="50%" y1="18%" x2="50%" y2="82%" stroke="#F2A900" strokeWidth="1" strokeDasharray="3 3" />
              <line x1="12%" y1="50%" x2="88%" y2="50%" stroke="#F2A900" strokeWidth="1" strokeDasharray="3 3" />
            </svg>
 
            {/* Central Felt Text / Branding */}
            <div className="absolute top-[32%] text-center pointer-events-none flex flex-col items-center">
              <span className="text-[10px] font-mono tracking-[0.4em] text-[#F2A900]/30 uppercase font-bold">
                AGORIST CRYPTO DECK
              </span>
              <span className="text-[8px] font-mono tracking-[0.2em] text-[#6E6E6E]/20 uppercase mt-0.5">
                PROVABLY SECURED BY SHA-256
              </span>
            </div>
 
            {/* CENTER: Community Cards & Pot display */}
            <div className="absolute z-10 flex flex-col items-center space-y-4">
              
              {/* Pot display board */}
              <div className="bg-black/80 border border-[#F2A900]/40 rounded-none px-4 py-1.5 shadow-xl text-center">
                <span className="text-[8px] font-mono tracking-widest text-[#6E6E6E] block uppercase">
                  CURRENT POT
                </span>
                <span className="font-display text-base font-bold text-[#F2A900] tracking-tight">
                  {gameState.pot.toFixed(4)} BTC
                </span>
              </div>
 
              {/* 5 Community Cards placeholders/displays */}
              <div className="flex items-center space-x-1.5 h-20">
                {[...Array(5)].map((_, idx) => {
                  const card = gameState.communityCards[idx];
                  return (
                    <div 
                      key={idx}
                      className={`w-12 h-18 rounded-none border flex flex-col justify-between p-1.5 relative transition-all duration-300 ${
                        card 
                          ? 'bg-white border-white' 
                          : 'bg-black/30 border-white/[0.08] border-dashed'
                      }`}
                    >
                      {card ? (
                        <>
                          <div className={`flex flex-col items-start leading-none ${getSuitColor(card.suit)}`}>
                            <span className="text-[10px] font-bold font-display">{card.value}</span>
                            <span className="text-[8px]">{getSuitSymbol(card.suit)}</span>
                          </div>
                          <span className={`text-base self-center ${getSuitColor(card.suit)}`}>
                            {getSuitSymbol(card.suit)}
                          </span>
                          <div className={`flex flex-col items-end leading-none rotate-180 ${getSuitColor(card.suit)}`}>
                            <span className="text-[10px] font-bold font-display">{card.value}</span>
                            <span className="text-[8px]">{getSuitSymbol(card.suit)}</span>
                          </div>
                        </>
                      ) : (
                        <div className="flex items-center justify-center h-full text-[#6E6E6E]/10 font-mono text-[9px]">
                          {idx === 0 || idx === 1 || idx === 2 ? 'F' : idx === 3 ? 'T' : 'R'}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
 
            {/* CIRCULAR SEATS: Opponents arranged symmetrically */}
            {/* Opponent 1: Top Center */}
            <div className="absolute top-[8%] flex flex-col items-center">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#191919] border border-[#F2A900]/40 text-xs text-white shadow-lg relative">
                👤
                <span className="absolute bottom-[-2px] right-[-2px] text-[8px] bg-black border border-white/[0.1] px-1 rounded text-white font-bold">🇨🇭</span>
              </div>
              <span className="text-[9px] text-[#F7F7F7] font-bold mt-1">Satoshi_99</span>
              <span className="text-[8px] text-[#F2A900] font-mono">1.452 BTC</span>
            </div>
 
            {/* Opponent 2: Top Right */}
            <div className="absolute right-[12%] top-[18%] flex flex-col items-center">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#191919] border border-white/[0.1] text-xs text-white shadow-lg relative">
                👤
                <span className="absolute bottom-[-2px] right-[-2px] text-[8px] bg-black border border-white/[0.1] px-1 rounded text-white font-bold">🇯🇵</span>
              </div>
              <span className="text-[9px] text-[#F7F7F7] font-bold mt-1">ColdVault</span>
              <span className="text-[8px] text-[#B7B7B7] font-mono">0.894 BTC</span>
              {gameState.stage === 'preflop' && gameState.currentTurnPlayerId === 'opp-2' && (
                <span className="absolute top-[-15px] bg-[#F2A900] text-black font-mono text-[8px] font-bold px-1.5 py-0.5 rounded-none uppercase animate-pulse">THINKING</span>
              )}
            </div>
 
            {/* Opponent 3: Bottom Right (Folded) */}
            <div className="absolute right-[10%] bottom-[22%] flex flex-col items-center opacity-40">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#191919] border border-white/[0.05] text-xs text-white shadow-lg">
                🤖
              </div>
              <span className="text-[9px] text-[#B7B7B7] font-bold mt-1">GTO_Bot_Null</span>
              <span className="text-[8px] text-[#6E6E6E] font-mono">Folded</span>
            </div>
 
            {/* Opponent 5: Top Left */}
            <div className="absolute left-[12%] top-[18%] flex flex-col items-center">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#191919] border border-white/[0.1] text-xs text-white shadow-lg relative">
                👤
                <span className="absolute bottom-[-2px] right-[-2px] text-[8px] bg-black border border-white/[0.1] px-1 rounded text-white font-bold">🇸🇬</span>
              </div>
              <span className="text-[9px] text-[#F7F7F7] font-bold mt-1">Hal_Acolyte</span>
              <span className="text-[8px] text-[#B7B7B7] font-mono">1.182 BTC</span>
            </div>
 
            {/* HERO PLAYER SEAT (BOTTOM CENTER) */}
            <div className="absolute bottom-[4%] flex flex-col items-center z-20">
              <div className="flex h-13 w-13 items-center justify-center rounded-full bg-[#F2A900]/15 border-2 border-[#F2A900] text-base text-white shadow-2xl relative">
                👑
                <span className="absolute bottom-[-2px] right-[-2px] text-[8px] bg-[#4ADE80] border border-black px-1.5 rounded text-black font-bold font-mono">LIVE</span>
              </div>
              <span className="text-[10px] text-[#F7F7F7] font-extrabold mt-1 tracking-wider uppercase">SECURE_NODE (YOU)</span>
              <span className="text-xs text-[#F2A900] font-mono font-bold">{gameState.userStack.toFixed(3)} BTC</span>
            </div>
 
          </div>

          {/* REVEALED POCKET CARDS DISPLAY */}
          <div className="flex flex-col sm:flex-row items-center justify-between bg-[#111111] border border-white/[0.08] rounded-none p-5 gap-4">
            
            {/* Dealt Pockets details */}
            <div className="text-left space-y-1">
              <span className="text-[9px] font-mono tracking-widest text-[#F2A900] uppercase block">YOUR ACTIVE HAND</span>
              <div className="flex items-center space-x-2">
                {gameState.userCards.length > 0 ? (
                  <div className="flex space-x-2">
                    {gameState.userCards.map((card, idx) => (
                      <div 
                        key={idx} 
                        className="flex items-center space-x-1.5 bg-[#191919] border border-white/[0.08] rounded-none px-2.5 py-1 text-xs font-bold font-mono"
                      >
                        <span className="text-[#F7F7F7]">{card.value}</span>
                        <span className={getSuitColor(card.suit)}>{getSuitSymbol(card.suit)}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <span className="text-xs text-[#6E6E6E] italic">No active ledger pockets dealt.</span>
                )}
              </div>
            </div>

            {/* INTERACTION GAME CONTROLS PANEL */}
            {gameState.currentTurnPlayerId === 'user' ? (
              <div className="flex flex-wrap items-center gap-2" id="user-game-controls">
                
                {/* Check/Fold buttons */}
                <button
                  onClick={() => handleUserAction('fold')}
                  className="px-4 py-2 bg-[#FF5A5A]/10 border border-[#FF5A5A]/30 rounded-none text-xs font-bold uppercase tracking-wider text-[#FF5A5A] hover:bg-[#FF5A5A]/20 transition-all cursor-pointer"
                  id="btn-fold"
                >
                  Fold
                </button>

                <button
                  onClick={() => handleUserAction('check')}
                  className="px-4 py-2 bg-white/[0.02] border border-white/[0.08] rounded-none text-xs font-bold uppercase tracking-wider text-[#F7F7F7] hover:bg-white/5 transition-all cursor-pointer"
                  id="btn-check"
                >
                  Check / Call
                </button>

                {/* Raise slider & trigger */}
                <div className="flex items-center space-x-2 bg-white/[0.02] border border-white/[0.08] rounded-none px-3 py-1">
                  <input
                    type="range"
                    min="0.02"
                    max="0.5"
                    step="0.01"
                    value={betSliderValue}
                    onChange={(e) => setBetSliderValue(Number(e.target.value))}
                    className="w-20 accent-[#F2A900]"
                    id="bet-size-slider"
                  />
                  <button
                    onClick={() => handleUserAction('raise')}
                    className="px-3 py-1 bg-[#F2A900] text-[#060606] rounded-none text-[10px] font-bold uppercase tracking-wider hover:bg-[#FFBD14] transition-colors"
                    id="btn-raise"
                  >
                    Raise {betSliderValue} BTC
                  </button>
                </div>

              </div>
            ) : (
              <div className="text-right">
                {gameState.stage === 'waiting' || gameState.stage === 'ended' ? (
                  <button
                    onClick={handleDealNewHand}
                    className="inline-flex h-10 items-center justify-center space-x-2 rounded-none bg-[#F2A900] px-6 text-xs font-bold uppercase tracking-widest text-[#060606] hover:bg-[#FFBD14] shadow-lg transition-all cursor-pointer"
                    id="btn-deal-hand"
                  >
                    <span>Deal Pocket Ledger</span>
                  </button>
                ) : (
                  <div className="flex items-center space-x-3">
                    {/* Intermediate round advancements */}
                    {gameState.stage === 'flop' && (
                      <button
                        onClick={handleDealTurn}
                        className="px-4 py-2 bg-[#F2A900]/10 border border-[#F2A900]/30 text-[#F2A900] text-xs font-bold rounded-none uppercase tracking-wider cursor-pointer hover:bg-[#F2A900]/20"
                        id="btn-deal-turn"
                      >
                        Deal Turn
                      </button>
                    )}
                    {gameState.stage === 'turn' && (
                      <button
                        onClick={handleDealRiver}
                        className="px-4 py-2 bg-[#F2A900]/10 border border-[#F2A900]/30 text-[#F2A900] text-xs font-bold rounded-none uppercase tracking-wider cursor-pointer hover:bg-[#F2A900]/20"
                        id="btn-deal-river"
                      >
                        Deal River
                      </button>
                    )}
                    {gameState.stage === 'river' && (
                      <button
                        onClick={handleShowdown}
                        className="px-4 py-2 bg-[#F2A900] text-[#060606] text-xs font-bold rounded-none uppercase tracking-wider cursor-pointer hover:bg-[#FFBD14]"
                        id="btn-trigger-showdown"
                      >
                        Trigger Showdown
                      </button>
                    )}
                    <span className="font-mono text-[10px] text-[#6E6E6E] uppercase animate-pulse">
                      Awaiting opponent ledger verification...
                    </span>
                  </div>
                )}
              </div>
            )}

          </div>

          {/* REAL-TIME GAME AUDIT LOGS (Bloomberg style) */}
          <div className="rounded-none border border-white/[0.08] bg-[#0d0d0d] p-4 flex flex-col space-y-3 h-40">
            <span className="text-[9px] font-mono tracking-widest text-[#6E6E6E] uppercase block border-b border-white/[0.08] pb-2">
              REAL-TIME CRYPTOGRAPHIC SHUFFLE LOG
            </span>
            <div className="overflow-y-auto space-y-1 flex-1 font-mono text-[10px] text-[#B7B7B7] text-left pr-1 scrollbar-none">
              {gameState.logMessages.map((msg, idx) => (
                <div key={idx} className="leading-relaxed">
                  <span className="text-[#6E6E6E]">●</span> {msg}
                </div>
              ))}
              <div ref={logEndRef} />
            </div>
          </div>

        </div>

        {/* AI CO-PILOT ADVISOR COLUMN (4 Columns) */}
        <div className="lg:col-span-4 rounded-none border border-white/[0.08] bg-[#111111] p-5 shadow-2xl flex flex-col space-y-4 text-left">
          
          <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
            <h3 className="font-display text-xs font-bold text-[#F7F7F7] uppercase tracking-widest flex items-center space-x-2">
              <Cpu className="h-4 w-4 text-[#F2A900]" />
              <span>GTO Co-Pilot Advisor</span>
            </h3>
            <span className="text-[9px] font-mono text-[#6E6E6E] tracking-wider">GEMINI FLASH V3.5</span>
          </div>

          {/* Active stats list */}
          <div className="bg-[#191919] border border-white/[0.08] rounded-none p-3 font-mono text-[10px] text-[#B7B7B7] space-y-2">
            <div className="flex justify-between">
              <span className="text-[#6E6E6E]">ACTIVE STAGE:</span>
              <span className="text-white uppercase font-bold">{gameState.stage}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6E6E6E]">COMMUNITY DEPTH:</span>
              <span className="text-white">{gameState.communityCards.length} Cards</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6E6E6E]">YOUR STACK VALUE:</span>
              <span className="text-[#F2A900] font-bold">{gameState.userStack.toFixed(3)} BTC</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6E6E6E]">PROBABLE HAND STR:</span>
              <span className="text-[#4ADE80] uppercase font-bold">Calculated on Deal</span>
            </div>
          </div>

          {/* CO-PILOT LOG DISPLAY */}
          <div className="relative rounded-none bg-black/40 border border-white/[0.08] p-4 flex-1 min-h-[220px]">
            {isAiLoading && (
              <div className="absolute inset-0 bg-[#111111]/85 flex flex-col items-center justify-center p-4 text-center space-y-3 z-10 rounded-none">
                <BrainCircuit className="h-8 w-8 text-[#F2A900] animate-spin" />
                <span className="font-mono text-[10px] text-[#B7B7B7] uppercase animate-pulse">
                  Querying Gemini node matrix...
                </span>
              </div>
            )}

            <div className="font-mono text-[10.5px] text-[#B7B7B7] leading-relaxed whitespace-pre-wrap text-left max-h-[300px] overflow-y-auto pr-1">
              {aiCopilotText}
            </div>
          </div>

          {/* Call to action */}
          <button
            onClick={handleConsultAiCoPilot}
            disabled={gameState.userCards.length === 0}
            className={`w-full inline-flex h-11 items-center justify-center space-x-2 rounded-none text-xs font-bold uppercase tracking-widest transition-all cursor-pointer ${
              gameState.userCards.length === 0
                ? 'bg-white/[0.02] border border-white/[0.08] text-[#6E6E6E] cursor-not-allowed'
                : 'border border-[#F2A900]/30 bg-[#F2A900]/5 hover:bg-[#F2A900]/10 text-[#F2A900] shadow-lg shadow-[#F2A900]/5'
            }`}
            id="btn-consult-copilot"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Consult AI Co-Pilot</span>
          </button>

          <div className="text-[9px] font-mono text-[#6E6E6E] text-center italic">
            🛡️ Private peer-to-peer. Analysis runs entirely on server sandbox. No leak to other nodes.
          </div>

        </div>

      </div>
    </div>
  );
}
