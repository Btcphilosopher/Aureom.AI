/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import crypto from 'crypto';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with telemetry header if key is available
let ai: GoogleGenAI | null = null;
const apiKey = process.env.GEMINI_API_KEY;

if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    console.log('Gemini AI initialized successfully.');
  } catch (err) {
    console.error('Failed to initialize Gemini AI client:', err);
  }
} else {
  console.log('No GEMINI_API_KEY detected in environment. Running with local high-fidelity rules engine fallback.');
}

// -------------------------------------------------------------
// API Endpoints
// -------------------------------------------------------------

// 1. Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    aiEngine: ai ? 'gemini-3.5-flash' : 'local-rule-engine',
  });
});

// Helper: Simple deterministic SHA-256 shuffle for Provably Fair demo
function getDeterministicRandom(seed: string): () => number {
  let count = 0;
  return () => {
    const hash = crypto.createHash('sha256').update(`${seed}-${count++}`).digest('hex');
    const intVal = parseInt(hash.substring(0, 8), 16);
    return intVal / 0xffffffff;
  };
}

// 2. Cryptographic Deck Shuffle Generator (Provably Fair)
app.post('/api/shuffle', (req, res) => {
  try {
    const { clientSeed, userNonce } = req.body;
    
    // Generate secure Server Seed
    const serverSeed = crypto.randomBytes(32).toString('hex');
    const serverHash = crypto.createHash('sha256').update(serverSeed).digest('hex');
    
    const finalClientSeed = clientSeed || 'AgoristSeed_' + crypto.randomBytes(8).toString('hex');
    const nonce = typeof userNonce === 'number' ? userNonce : 0;
    
    // Create combined cryptographic key
    const combinedSeed = `${serverSeed}:${finalClientSeed}:${nonce}`;
    const combinedHash = crypto.createHash('sha512').update(combinedSeed).digest('hex');
    
    // Create a deck of 52 cards
    const suits = ['spades', 'hearts', 'diamonds', 'clubs'] as const;
    const values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    
    const deck: { id: number; suit: string; value: string }[] = [];
    let id = 1;
    for (const suit of suits) {
      for (const value of values) {
        deck.push({ id: id++, suit, value });
      }
    }
    
    // Deterministic Fisher-Yates shuffle using combined cryptographic hash as entropy source
    const rng = getDeterministicRandom(combinedSeed);
    const shuffledDeck = [...deck];
    for (let i = shuffledDeck.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      const temp = shuffledDeck[i];
      shuffledDeck[i] = shuffledDeck[j];
      shuffledDeck[j] = temp;
    }
    
    res.json({
      serverSeed,
      serverHash,
      clientSeed: finalClientSeed,
      nonce,
      combinedSeed,
      combinedHash,
      shuffledDeck: shuffledDeck.map(c => ({ suit: c.suit, value: c.value })),
    });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed to generate cryptographic deck.', message: error.message });
  }
});

// Helper function to evaluate card hand strength (local engine fallback)
function evaluateLocalHand(userCards: any[], communityCards: any[]): { rankName: string; score: number } {
  const allCards = [...userCards, ...communityCards];
  if (allCards.length === 0) return { rankName: 'No Cards', score: 0 };
  
  // Quick value ranking map
  const valueMap: Record<string, number> = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
    'J': 11, 'Q': 12, 'K': 13, 'A': 14
  };
  
  // Simple check for pairs/trips/quads for realistic text
  const counts: Record<string, number> = {};
  const suits: Record<string, number> = {};
  
  allCards.forEach(c => {
    if (c && c.value) {
      counts[c.value] = (counts[c.value] || 0) + 1;
    }
    if (c && c.suit) {
      suits[c.suit] = (suits[c.suit] || 0) + 1;
    }
  });
  
  const values = Object.values(counts);
  const maxDup = Math.max(...values, 0);
  const pairCount = values.filter(v => v === 2).length;
  const isFlush = Object.values(suits).some(s => s >= 5);
  
  if (isFlush) return { rankName: 'Flush Draw / Solid Flush', score: 6 };
  if (maxDup === 4) return { rankName: 'Four of a Kind', score: 8 };
  if (maxDup === 3 && pairCount >= 1) return { rankName: 'Full House', score: 7 };
  if (maxDup === 3) return { rankName: 'Three of a Kind', score: 4 };
  if (pairCount >= 2) return { rankName: 'Two Pair', score: 3 };
  if (pairCount === 1) return { rankName: 'One Pair', score: 2 };
  
  // High Card
  const highVal = Math.max(...allCards.map(c => valueMap[c?.value] || 0), 0);
  const highName = Object.keys(valueMap).find(k => valueMap[k] === highVal) || 'Ace';
  return { rankName: `High Card ${highName}`, score: 1 };
}

// 3. AI Co-Pilot High-Stakes analysis using server-side Gemini Pro or local fallback
app.post('/api/copilot', async (req, res) => {
  const { userCards, communityCards, stage, pot, userStack, userCurrentBet } = req.body;
  
  if (!userCards || !Array.isArray(userCards) || userCards.length < 2) {
    return res.status(400).json({ error: 'User cards must be provided as an array of 2 cards.' });
  }
  
  const formattedUserCards = userCards.map(c => `${c.value} of ${c.suit}`).join(', ');
  const formattedCommunity = (communityCards && Array.isArray(communityCards) && communityCards.length > 0)
    ? communityCards.map(c => `${c.value} of ${c.suit}`).join(', ')
    : 'None (Pre-flop)';
    
  const localEval = evaluateLocalHand(userCards, communityCards || []);
  
  // If Gemini is available, use it!
  if (ai) {
    try {
      const prompt = `You are a legendary high-stakes professional poker strategist, GTO (Game Theory Optimal) node theorist, and veteran psychological reader at Agorist Poker.
Analyze this high-roller Bitcoin Poker table scenario with mathematical cold precision:
- User cards (Pocket): ${formattedUserCards}
- Community cards (Board): ${formattedCommunity}
- Current round stage: ${stage}
- Current pot: ${pot} BTC
- User stack remaining: ${userStack} BTC
- User current round bet: ${userCurrentBet} BTC

Provide a structured, beautifully formatted analysis containing EXACTLY these sections with NO markdown headings, just capital letters and clean lines:
1. THEORETICAL HAND EVALUATION & BOARD TEXTURE
(Analyze hand strength, blocker value, outs, and direct equity against a balanced GTO opponent range)
2. OPTIMAL STRATEGY RECOMMENDATION (GTO VS EXPLOTATIVE)
(Give a clear decision: Check, Fold, Call, or Raise, with exact size and mathematical reasoning, detailing fold equity and pot odds)
3. CRYPTOGRAPHIC PSYCHOLOGICAL MOTTO
(Provide an elite, cold, intellectual quote or wisdom on player psychology and HODLer patience in decentralized environments)

Remember: Keep the style ultra-clean, minimal, premium, Swiss-style, editorial, intellectual. Avoid any marketing hype, greeting sentences, or emojis.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          temperature: 0.2,
          topP: 0.95,
        },
      });

      const text = response.text;
      if (text) {
        return res.json({
          success: true,
          provider: 'gemini-3.5-flash',
          analysis: text,
        });
      }
    } catch (error: any) {
      console.error('Gemini call failed, utilizing local fallback engine:', error);
      // Fallback seamlessly below
    }
  }

  // High-fidelity fallback response if Gemini is unavailable or failed
  const cardVals = userCards.map(c => c.value);
  const isPocketPair = cardVals[0] === cardVals[1];
  
  let action = 'Check';
  let sizing = 'No Bet';
  let reasoning = '';
  let motto = '';

  if (stage === 'preflop') {
    if (isPocketPair) {
      const highRank = ['A', 'K', 'Q', 'J', '10'].includes(cardVals[0]);
      action = highRank ? 'Raise' : 'Call / Open-limp';
      sizing = highRank ? '0.045 BTC' : '0.015 BTC';
      reasoning = highRank 
        ? `Premium pocket pair (${cardVals[0]}s). GTO dictates opening with a 3x standard open-raise to extract value from wide defending ranges, block key straight vectors, and construct a high-frequency range-cap.`
        : `Medium pocket pair (${cardVals[0]}s). Maintain table coverage. Call the standard blind to set-mine on the flop while preserving stack depth (implied odds are highly favorable).`;
    } else {
      const isSuited = userCards[0].suit === userCards[1].suit;
      const highCards = cardVals.some(v => ['A', 'K', 'Q', 'J'].includes(v));
      if (highCards && isSuited) {
        action = 'Raise';
        sizing = '0.03 BTC';
        reasoning = `Suited connector with broadway coverage. Strong equity retention post-flop. Initiate standard GTO open-raise to apply immediate leverage on middle-position players and secure fold-equity.`;
      } else if (highCards) {
        action = 'Call / Check';
        sizing = '0.01 BTC';
        reasoning = `Offsuit Broadway cards. Favorable blocker configurations. Standard action is to call the current blind to see the flop while minimizing high-stakes variance.`;
      } else {
        action = 'Fold';
        sizing = '0.00 BTC';
        reasoning = `Unsuited low value connectors. Insufficient raw equity or range blockers. Fold to conserve capital and protect your cryptographic treasury.`;
      }
    }
    motto = "Agorist Poker Protocol: Wealth flows from the impatient node to the patient node. Restraint is the ultimate technology.";
  } else {
    // Post flop
    const score = localEval.score;
    if (score >= 4) {
      action = 'Raise';
      sizing = `${(pot * 0.65).toFixed(4)} BTC`;
      reasoning = `Detected high-equity holding (${localEval.rankName}). Extract value immediately on this board texture. Set standard sizing of 65% pot to punish drawing hands and target top-pair ranges.`;
    } else if (score >= 2) {
      action = 'Call / Check';
      sizing = '0.02 BTC';
      reasoning = `Constructed average range hand (${localEval.rankName}). Check-call to control the size of the pot. Maintain range protection while monitoring opponents' multi-street sizing patterns.`;
    } else {
      action = 'Check / Fold';
      sizing = '0.00 BTC';
      reasoning = `Low-equity range distribution (${localEval.rankName}). Fold immediately under active betting pressure. Avoid speculative post-flop calls with poor mathematical leverage.`;
    }
    motto = "Cryptographic integrity is absolute. The cards have no memory, and the decentralized ledger remembers everything.";
  }

  const simulatedAnalysis = `THEORETICAL HAND EVALUATION & BOARD TEXTURE
Holding: ${formattedUserCards} on a board showing ${formattedCommunity}.
Hand Classification: ${localEval.rankName}.
Board Texture: Standard balanced distribution. Range advantages are stabilized. Blocker strength is evaluated at moderate to high efficiency.

OPTIMAL STRATEGY RECOMMENDATION (GTO VS EXPLOTATIVE)
Recommended action: ${action.toUpperCase()} ${sizing !== 'No Bet' ? `(Sizing: ${sizing})` : ''}.
Mathematical reasoning: ${reasoning} Pot odds are optimized at current stack depths.

CRYPTOGRAPHIC PSYCHOLOGICAL MOTTO
"${motto}"`;

  res.json({
    success: true,
    provider: 'local-rule-engine',
    analysis: simulatedAnalysis,
  });
});

// -------------------------------------------------------------
// Serve Static Frontend Assets & Handle Routing
// -------------------------------------------------------------

async function initializeViteAndListen() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('Vite middleware mounted (Development Mode).');
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('Serving static production files from dist/.');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Agorist Server] running on http://localhost:${PORT}`);
  });
}

initializeViteAndListen().catch(err => {
  console.error('Failed to start Agorist Poker server:', err);
});
