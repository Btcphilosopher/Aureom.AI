package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.rememberTextMeasurer
import com.example.data.repository.WhaleTransaction
import com.example.ui.theme.*
import kotlin.random.Random

data class BubbleParticle(
    val id: String,
    val symbol: String,
    val r: Float,
    var x: Float,
    var y: Float,
    val speed: Float,
    var alpha: Float = 0.8f,
    val amountStr: String
)

@Composable
fun WhaleFlowVisualizer(
    transactions: List<WhaleTransaction>,
    modifier: Modifier = Modifier
) {
    val bubbles = remember { mutableStateListOf<BubbleParticle>() }

    // Map new incoming transaction flow to bubbles
    LaunchedEffect(transactions) {
        if (transactions.isNotEmpty()) {
            val latest = transactions.first()
            if (bubbles.none { it.id == latest.id }) {
                val amountMillions = latest.amountUsd / 1000000.0
                val radiusPx = (15f + (amountMillions * 8.0).toFloat()).coerceIn(15f, 60f)
                bubbles.add(
                    BubbleParticle(
                        id = latest.id,
                        symbol = latest.symbol,
                        r = radiusPx,
                        x = 0.1f + Random.nextFloat() * 0.8f,
                        y = 0.0f,
                        speed = 0.015f + Random.nextFloat() * 0.01f,
                        amountStr = "$${String.format("%.1f", amountMillions)}M"
                    )
                )
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "block_flows")
    val clockTick by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "flow_clock"
    )

    // Move bubbles
    LaunchedEffect(clockTick) {
        val iterator = bubbles.iterator()
        while (iterator.hasNext()) {
            val b = iterator.next()
            b.y += b.speed
            b.alpha = (1.1f - b.y).coerceIn(0.0f, 1.0f)
            if (b.y > 1.0f) {
                iterator.remove() // hit custody vault block at bottom, register as ingested
            }
        }
    }

    Canvas(modifier = modifier.background(BackgroundBlack)) {
        val w = size.width
        val h = size.height

        // Draw Ledger Vault Block cages at the bottom of the node window
        val vaultY = h * 0.85f
        drawRect(
            color = GridGlow,
            topLeft = Offset(w * 0.05f, vaultY),
            size = androidx.compose.ui.geometry.Size(w * 0.9f, h * 0.12f)
        )

        drawLine(
            color = CyberGold.copy(alpha = 0.3f),
            start = Offset(0f, vaultY),
            end = Offset(w, vaultY),
            strokeWidth = 3f
        )

        // Floating liquid flow curves background
        val curvePath = Path().apply {
            moveTo(0f, h * 0.4f)
            quadraticTo(w * 0.5f, h * 0.55f, w, h * 0.4f)
            lineTo(w, h * 0.42f)
            quadraticTo(w * 0.5f, h * 0.57f, 0f, h * 0.42f)
            close()
        }
        drawPath(curvePath, color = CyberCyan.copy(alpha = 0.06f))

        // Draw active whale block coins
        bubbles.forEach { b ->
            val cx = b.x * w
            val cy = b.y * h

            val bubbleColor = when (b.symbol) {
                "BTC" -> CyberGold
                "ETH" -> CyberPink
                else -> CyberCyan
            }

            // Outer radiant aura
            drawCircle(
                color = bubbleColor.copy(alpha = b.alpha * 0.15f),
                radius = b.r * 1.5f,
                center = Offset(cx, cy)
            )

            // Core solid core
            drawCircle(
                color = bubbleColor,
                radius = b.r,
                center = Offset(cx, cy),
                alpha = b.alpha * 0.6f
            )

            // Inner gloss rim highlight
            drawCircle(
                color = Color.White.copy(alpha = b.alpha * 0.4f),
                radius = b.r * 0.6f,
                center = Offset(cx - b.r * 0.3f, cy - b.r * 0.3f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
            )
        }
    }
}
