package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profile_table")
data class ProfileEntity(
    @PrimaryKey val id: Int = 0,
    val balance: Double = 100000.0,
    val learnedSectors: String = "TECH,FINANCE,ENERGY", // Comma-separated weights / preferred sectors
    val panicScore: Float = 0.0f,
    val euphoriaScore: Float = 0.0f,
    val tradesCount: Int = 0
)

@Entity(tableName = "holdings_table")
data class HoldingEntity(
    @PrimaryKey val symbol: String,
    val name: String,
    val category: String,
    val sector: String,
    val quantity: Double,
    val avgPurchasePrice: Double
)

@Entity(tableName = "watchlist_table")
data class WatchlistEntity(
    @PrimaryKey val symbol: String
)

@Entity(tableName = "alerts_table")
data class AlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val symbol: String,
    val targetPrice: Double,
    val isTriggered: Boolean = false,
    val isAbove: Boolean = true // Alert when price crosses above (true) or below (false)
)

@Entity(tableName = "transaction_table")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val symbol: String,
    val quantity: Double,
    val price: Double,
    val isBuy: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
