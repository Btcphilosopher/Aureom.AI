package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberGold
import kotlin.random.Random

data class DigitalParticle(
    var x: Float,
    var y: Float,
    val speed: Float,
    val size: Float,
    val color: Color,
    var alpha: Float = 0.5f
)

@Composable
fun BackgroundAmbientParticles() {
    val particles = remember {
        mutableStateListOf<DigitalParticle>().apply {
            repeat(30) {
                add(
                    DigitalParticle(
                        x = Random.nextFloat(),
                        y = Random.nextFloat(),
                        speed = 0.005f + Random.nextFloat() * 0.015f,
                        size = 3f + Random.nextFloat() * 7f,
                        color = if (Random.nextBoolean()) CyberGold else CyberCyan
                    )
                )
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "particles")
    val ticker by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "tick"
    )

    // Side effect to update positions slightly on animations ticks
    LaunchedEffect(ticker) {
        particles.forEach { p ->
            p.y -= p.speed
            p.alpha = (p.y * 1.5f).coerceIn(0.0f, 0.7f)
            if (p.y < 0) {
                p.y = 1.0f
                p.x = Random.nextFloat()
            }
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        particles.forEach { p ->
            drawCircle(
                color = p.color,
                radius = p.size,
                center = Offset(p.x * w, p.y * h),
                alpha = p.alpha
            )
        }
    }
}
