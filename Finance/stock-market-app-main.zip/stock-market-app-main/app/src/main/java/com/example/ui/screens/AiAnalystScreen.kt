package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketViewModel

@Composable
fun AiAnalystScreen(
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    val critique by viewModel.aiAnalystCritique.collectAsState()
    val profState by viewModel.profile.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "terminal_cursor")
    val showCursor by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursor"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Broadcaster title
        Text(
            text = "AI QUANT ANALYST INTELLIGENCE SUITE",
            color = CyberGold,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 4.dp)
        )

        // Simulated AI Terminal Log viewport
        Card(
            colors = CardDefaults.cardColors(containerColor = TonalGlass),
            border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CORE TELEMETRY: SECTOR-9 INTEL SYSTEM",
                        color = CyberCyan,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(CyberCyan, RoundedCornerShape(50))
                    )
                }

                Divider(
                    color = CyberCyan.copy(alpha = 0.2f),
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                Row {
                    Text(
                        text = "> ",
                        color = CyberGold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    
                    // Display text critique in classic glowing phosphor monospace
                    Text(
                        text = critique,
                        color = Color(0xFFE0F7FA),
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )

                    if (showCursor > 0.5f) {
                        Text(
                            text = "█",
                            color = CyberGold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Metrics index visuals (Euphoria index vs Risk index)
        val panicVal = profState?.panicScore ?: 0.0f
        val euphoriaVal = profState?.euphoriaScore ?: 0.0f

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = "BEHAVIORAL RISK VECTOR GRIDS",
                color = CyberGold,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            // Euphoria Metric Indicator
            MetricBarVisual(
                label = "RETAIL EUPHORIA COEFFICIENT (MEME WEIGHT)",
                value = euphoriaVal,
                glowingColor = CyberCyan,
                dimColor = CyberCyan.copy(alpha = 0.15f)
            )

            // Panic Liquidations Metric Indicator
            MetricBarVisual(
                label = "PANIC LIQUIDATIONS STOCHASTIC FACTOR",
                value = panicVal,
                glowingColor = CyberPink,
                dimColor = CyberPink.copy(alpha = 0.15f)
            )
        }

        // Analytical vector curves representation
        Card(
            colors = CardDefaults.cardColors(containerColor = TonalGlass),
            border = BorderStroke(1.dp, GridGlow),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    text = "NEURAL PROBABILITY MATRIX INDEX",
                    color = Color.Gray,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(6.dp))

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Draw grid meshes
                    repeat(5) { i ->
                        val x = (w / 5) * i
                        drawLine(GridGlow, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
                        val y = (h / 5) * i
                        drawLine(GridGlow, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
                    }

                    // Render custom holographic wave paths representating quants neural metrics
                    val wavePath1 = Path().apply {
                        moveTo(0f, h * 0.7f)
                        quadraticTo(w * 0.25f, h * 0.3f, w * 0.5f, h * 0.8f)
                        quadraticTo(w * 0.75f, h * 0.9f, w, h * 0.2f)
                    }

                    val wavePath2 = Path().apply {
                        moveTo(0f, h * 0.4f)
                        quadraticTo(w * 0.3f, h * 0.8f, w * 0.6f, h * 0.2f)
                        quadraticTo(w * 0.8f, h * 0.1f, w, h * 0.6f)
                    }

                    drawPath(
                        path = wavePath1,
                        color = CyberCyan.copy(alpha = 0.5f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(
                            width = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    )

                    drawPath(
                        path = wavePath2,
                        color = CyberGold.copy(alpha = 0.4f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(
                            width = 1.5.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    )
                }
            }
        }

        // Historial decisions log
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "RECENT LEDGER DECISIONS FEED",
                color = CyberGold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            if (transactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GridGlow)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "NO RECENT TRANSACTION LOGS RECORDED.",
                        color = Color.Gray,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                transactions.take(5).forEach { tx ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GridGlow)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(if (tx.isBuy) NeonGreen else NeonRed, RoundedCornerShape(50))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${if (tx.isBuy) "BUY" else "SELL"} ${tx.symbol}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = "${tx.quantity} units @ $${String.format("%,.2f", tx.price)}",
                            color = Color.Gray,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MetricBarVisual(
    label: String,
    value: Float, // 0.0 to 1.0
    glowingColor: Color,
    dimColor: Color
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                color = Color.White,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = String.format("%.1f%%", value * 100f),
                color = glowingColor,
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(dimColor)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(value.coerceIn(0.01f, 1.0f))
                    .background(glowingColor)
            )
        }
    }
}
