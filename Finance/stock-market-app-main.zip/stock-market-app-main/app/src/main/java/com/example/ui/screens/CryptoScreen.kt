package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Asset
import com.example.data.model.AssetCategory
import com.example.ui.components.WhaleFlowVisualizer
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketViewModel

@Composable
fun CryptoScreen(
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    val liveAssets by viewModel.assets.collectAsState()
    val whaleTxs by viewModel.whaleTransactions.collectAsState()

    val cryptos = remember(liveAssets) {
        liveAssets.filter { it.category == AssetCategory.CRYPTO }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CYPHER DECENTRALIZED CORES",
                color = CyberGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Box(
                modifier = Modifier
                    .background(CyberCyan.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                    .border(1.dp, CyberCyan, RoundedCornerShape(2.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "LQD BLOCKCHAIN // ONLINE",
                    color = CyberCyan,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Crypto asset cards grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            cryptos.take(3).forEach { coin ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = TonalGlass),
                    border = BorderStroke(1.dp, GridGlow),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("crypto_card_${coin.symbol}")
                        .clickable { viewModel.selectAsset(coin) }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = coin.symbol,
                            color = CyberGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        val rate = String.format("%,.2f", coin.currentPrice)
                        Text(
                            text = "$$rate",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = String.format("%+.2f%%", coin.changePercent),
                            color = if (coin.isPositive) NeonGreen else NeonRed,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Whale Stream blockchain tracker layout
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "LIVE BLOCKCHAIN WHALE TRANSFERS STREAM",
                color = CyberGold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            // Canvas flow visualizer window
            Card(
                colors = CardDefaults.cardColors(containerColor = BackgroundBlack),
                border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    WhaleFlowVisualizer(
                        transactions = whaleTxs,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay label HUD stats
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("WHALE NODE INPUT FEED", color = Color.White, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        Text("CUSTODY VAULT (CAGE-9)", color = CyberGold, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Active node network indicators
        Card(
            colors = CardDefaults.cardColors(containerColor = TonalGlass),
            border = BorderStroke(1.dp, GridGlow),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "COMPUTATIONAL COMPUTE GRID STATUS",
                    color = CyberCyan,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    CryptoStatVisual("ACTIVE LEDGER NODES", "485,290 Units")
                    CryptoStatVisual("AVERAGE GAS/SEC RATIO", "12 gwei // CRITICAL")
                    CryptoStatVisual("MINING PRESSURE INDEX", "88.5% CAP")
                }
            }
        }

        // Ledger transfers text log items
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "BLOCKCHAIN TRANSFERS ARCHIVE",
                color = CyberGold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            if (whaleTxs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GridGlow)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Telemetry linking... standing by for massive block transfers.", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            } else {
                whaleTxs.take(4).forEach { tx ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GridGlow)
                            .background(Color(0xFF07090C))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val coinColor = if (tx.symbol == "BTC") CyberGold else if (tx.symbol == "ETH") CyberPink else CyberCyan
                                Box(modifier = Modifier.size(6.dp).background(coinColor, RoundedCornerShape(50)))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${String.format("%,.2f", tx.quantity)} ${tx.symbol}",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "From ${tx.fromAddress} ➔ To ${tx.toAddress}",
                                color = Color.Gray,
                                fontSize = 8.sp,
                                maxLines = 1,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = "$${String.format("%,.1f", tx.amountUsd / 1000000.0)}M USD",
                            color = NeonGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CryptoStatVisual(label: String, value: String) {
    Column {
        Text(text = label, color = Color.Gray, fontSize = 7.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
    }
}
