package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class AssetCategory {
    STOCK, CRYPTO, COMMODITY, FOREX, INDEX, BOND
}

enum class Sector {
    TECH, FINANCE, ENERGY, HEAVY_INDUSTRY, BIO_GEN, MEME, GOVT
}

data class PriceBar(
    val timestamp: Long,
    val open: Float,
    val close: Float,
    val high: Float,
    val low: Float,
    val volume: Float
) {
    val isBullish: Boolean get() = close >= open
}

data class Asset(
    val symbol: String,
    val name: String,
    val category: AssetCategory,
    val sector: Sector,
    val currentPrice: Double,
    val prevPrice: Double,
    val dayHigh: Double,
    val dayLow: Double,
    val basePrice: Double,
    val volume: Double,
    val liquidityScore: Int, // 1 - 100
    val instActivity: Double, // % institutional flow
    val history: List<PriceBar> = emptyList(),
    val aiSentiment: Float = 0.5f // 0 = panic, 1 = euphoria
) {
    val changePrice: Double get() = currentPrice - prevPrice
    val changePercent: Double get() = if (prevPrice > 0) (changePrice / prevPrice) * 100.0 else 0.0
    val isPositive: Boolean get() = changePrice >= 0
}
