package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.NewsArticle
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketViewModel

@Composable
fun MediaScreen(
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    val newsArticles by viewModel.news.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "broadcast")
    val bannerPulse by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Highlight newest headline as Breaking News
    val breakingNews = remember(newsArticles) {
        newsArticles.firstOrNull() ?: NewsArticle(
            headline = "FEDERAL CREDIT CHANNELS CONVERGE",
            content = "Global clearing protocols reporting major structural changes.",
            source = "Sovereign Bureau",
            author = "Clara Frost",
            opinionVibe = "Macro Strategist Expert",
            impactRating = 5
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundBlack)
    ) {
        // Glowing Breaking News alert header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF210000))
                .border(2.dp, NeonRed.copy(alpha = bannerPulse))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(NeonRed, RoundedCornerShape(50))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "CYBER-CNBC BREAKING SPECIAL BULLETINS",
                            color = NeonRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = "LIVE // GRID LOCK",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = breakingNews.headline,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )

                Text(
                    text = breakingNews.content,
                    color = Color(0xFFFFCDD2),
                    fontSize = 10.sp,
                    lineHeight = 14.sp,
                    fontWeight = FontWeight.Normal,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Content layout list
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Commentary anchor avatars profiles
            item {
                Text(
                    text = "DEDICATED WALL-STREET COMMENTATOR CHANNELS",
                    color = CyberGold,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CommentatorAvatarFrame("Arthur Sterling", "Veteran Advisor", CyberGold)
                    CommentatorAvatarFrame("Jim Flashpoint", "Scream Quant", CyberPink)
                    CommentatorAvatarFrame("Clara Frost", "Macro Oracle", CyberCyan)
                    CommentatorAvatarFrame("Sigma-9", "Autonomous Bot", Color.White)
                    CommentatorAvatarFrame("Gideon Slate", "Fed Criticizer", NeonRed)
                }
            }

            item {
                Divider(color = GridGlow, modifier = Modifier.padding(vertical = 4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PROCEDURAL BROADCAST TERMINAL ARCHIVES",
                        color = CyberGold,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "AUDIO SYNCED // 22,050Hz",
                        color = CyberCyan.copy(alpha = 0.5f),
                        fontSize = 7.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // News bulletin logs
            items(newsArticles.drop(1), key = { it.id }) { article ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = TonalGlass),
                    border = BorderStroke(1.dp, GridGlow),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(if (article.impactRating >= 4) NeonRed else CyberGold, RoundedCornerShape(50))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = article.source,
                                    color = CyberCyan,
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                repeat(article.impactRating) {
                                    Text("⚡", fontSize = 7.sp) // Custom electrical bolt rating indicators
                                }
                            }
                        }

                        Text(
                            text = article.headline,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = article.content,
                            color = Color.LightGray,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )

                        Divider(color = GridGlow.copy(alpha = 0.5f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PERSPECTIVE: ${article.author} // ${article.opinionVibe}",
                                color = CyberGold.copy(alpha = 0.8f),
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontStyle = FontStyle.Italic
                            )
                            Text(
                                text = "CYPHER SYSTEM TRANSMISSION CONFIRMED",
                                color = Color.Gray,
                                fontSize = 7.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CommentatorAvatarFrame(
    name: String,
    role: String,
    accent: Color
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1217)),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier
            .width(105.dp)
            .height(72.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(accent.copy(alpha = 0.15f))
                    .border(1.dp, accent, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = name.take(1) + (name.split(" ").getOrNull(1)?.take(1) ?: ""),
                    color = accent,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = name,
                color = Color.White,
                fontSize = 8.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = role,
                color = Color.Gray,
                fontSize = 7.sp,
                maxLines = 1,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
