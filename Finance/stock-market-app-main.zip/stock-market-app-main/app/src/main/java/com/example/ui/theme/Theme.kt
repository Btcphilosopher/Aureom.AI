package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val TerminalColorScheme = darkColorScheme(
    primary = CyberGold,
    secondary = CyberCyan,
    tertiary = CyberPink,
    background = BackgroundBlack,
    surface = SurfaceGray,
    onPrimary = BackgroundBlack,
    onSecondary = BackgroundBlack,
    onTertiary = BackgroundBlack,
    onBackground = Color(0xFFECEFF1),
    onSurface = Color(0xFFECEFF1),
    surfaceVariant = GridGlow
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark Theme for Cyber Terminal aesthetics
    dynamicColor: Boolean = false, // Disable dynamic colors to keep pure premium custom styling
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
