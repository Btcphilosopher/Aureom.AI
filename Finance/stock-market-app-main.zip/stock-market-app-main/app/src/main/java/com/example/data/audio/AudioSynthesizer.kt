package com.example.data.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.sin

object AudioSynthesizer {
    private const val SAMPLE_RATE = 22050
    var isMuted = false

    fun playTick() {
        if (isMuted) return
        playTone(frequency = 2500.0, durationMs = 12, volume = 0.08f)
    }

    fun playAlert() {
        if (isMuted) return
        playToneSequence(
            listOf(
                Pair(1000.0, 100),
                Pair(1400.0, 100),
                Pair(1000.0, 100),
                Pair(1400.0, 200)
            ),
            volume = 0.25f
        )
    }

    fun playBuy() {
        if (isMuted) return
        playSweep(startFreq = 300.0, endFreq = 900.0, durationMs = 150, volume = 0.2f)
    }

    fun playSell() {
        if (isMuted) return
        playSweep(startFreq = 800.0, endFreq = 300.0, durationMs = 150, volume = 0.2f)
    }

    fun playBell() {
        if (isMuted) return
        playMetallicTone(frequency = 440.0, durationMs = 800, volume = 0.3f) // A4 resonance
    }

    private fun playTone(frequency: Double, durationMs: Int, volume: Float) {
        Thread {
            try {
                val numSamples = (SAMPLE_RATE * (durationMs / 1000.0)).toInt()
                if (numSamples <= 0) return@Thread
                val samples = FloatArray(numSamples)
                for (i in 0 until numSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    val envelope = if (i < numSamples * 0.1) {
                        (i / (numSamples * 0.1)).toFloat()
                    } else if (i > numSamples * 0.8) {
                        (1.0 - (i - numSamples * 0.8) / (numSamples * 0.2)).toFloat()
                    } else {
                        1.0f
                    }
                    samples[i] = (sin(2 * Math.PI * frequency * t) * volume * envelope).toFloat()
                }

                writeAndPlay(samples)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun playSweep(startFreq: Double, endFreq: Double, durationMs: Int, volume: Float) {
        Thread {
            try {
                val numSamples = (SAMPLE_RATE * (durationMs / 1000.0)).toInt()
                if (numSamples <= 0) return@Thread
                val samples = FloatArray(numSamples)
                for (i in 0 until numSamples) {
                    val fraction = i.toDouble() / numSamples
                    val currentFreq = startFreq + (endFreq - startFreq) * fraction
                    val phase = 2 * Math.PI * currentFreq * (i.toDouble() / SAMPLE_RATE)
                    val envelope = if (i < numSamples * 0.15) {
                        (i / (numSamples * 0.15)).toFloat()
                    } else if (i > numSamples * 0.85) {
                        (1.0 - (i - numSamples * 0.85) / (numSamples * 0.15)).toFloat()
                    } else {
                        1.0f
                    }
                    samples[i] = (sin(phase) * volume * envelope).toFloat()
                }
                writeAndPlay(samples)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun playToneSequence(tones: List<Pair<Double, Int>>, volume: Float) {
        Thread {
            try {
                for (tone in tones) {
                    val numSamples = (SAMPLE_RATE * (tone.second / 1000.0)).toInt()
                    if (numSamples <= 0) continue
                    val samples = FloatArray(numSamples)
                    for (i in 0 until numSamples) {
                        val t = i.toDouble() / SAMPLE_RATE
                        val envelope = if (i < numSamples * 0.05) {
                            (i / (numSamples * 0.05)).toFloat()
                        } else if (i > numSamples * 0.9) {
                            (1.0 - (i - numSamples * 0.9) / (numSamples * 0.1)).toFloat()
                        } else {
                            1.0f
                        }
                        samples[i] = (sin(2 * Math.PI * tone.first * t) * volume * envelope).toFloat()
                    }
                    writeAndPlaySynchronous(samples)
                    Thread.sleep(15)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun playMetallicTone(frequency: Double, durationMs: Int, volume: Float) {
        Thread {
            try {
                val numSamples = (SAMPLE_RATE * (durationMs / 1000.0)).toInt()
                if (numSamples <= 0) return@Thread
                val samples = FloatArray(numSamples)
                for (i in 0 until numSamples) {
                    val t = i.toDouble() / SAMPLE_RATE
                    val sine1 = sin(2 * Math.PI * frequency * t)
                    val sine2 = sin(2 * Math.PI * (frequency * 1.5) * t) * 0.35
                    val sine3 = sin(2 * Math.PI * (frequency * 2.15) * t) * 0.2
                    val sine4 = sin(2 * Math.PI * (frequency * 3.42) * t) * 0.1
                    
                    val decay = Math.exp(-3.5 * (i.toDouble() / numSamples)).toFloat()
                    samples[i] = ((sine1 + sine2 + sine3 + sine4) * volume * decay).toFloat()
                }
                writeAndPlay(samples)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun writeAndPlay(samples: FloatArray) {
        try {
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(samples.size * 4)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
            audioTrack.play()
            
            Thread {
                try {
                    Thread.sleep((samples.size.toDouble() / SAMPLE_RATE * 1000).toLong() + 200)
                    audioTrack.stop()
                    audioTrack.release()
                } catch (e: Exception) { }
            }.start()
        } catch (e: Exception) { }
    }

    private fun writeAndPlaySynchronous(samples: FloatArray) {
        try {
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(samples.size * 4)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
            audioTrack.play()
            try {
                Thread.sleep((samples.size.toDouble() / SAMPLE_RATE * 1000).toLong() + 50)
                audioTrack.stop()
                audioTrack.release()
            } catch (e: Exception) { }
        } catch (e: Exception) { }
    }
}
