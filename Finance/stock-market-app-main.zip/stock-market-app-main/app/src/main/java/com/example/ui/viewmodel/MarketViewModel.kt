package com.example.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.HoldingEntity
import com.example.data.database.ProfileEntity
import com.example.data.model.Asset
import com.example.data.model.AssetCategory
import com.example.data.model.Sector
import com.example.data.repository.MacroRegime
import com.example.data.repository.MarketRepository
import com.example.data.repository.NewsArticle
import com.example.data.repository.WhaleTransaction
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MarketViewModel(
    application: Application,
    private val repository: MarketRepository
) : AndroidViewModel(application) {

    // --- Core Market States from Repo ---
    val assets: StateFlow<List<Asset>> = repository.assets
    val macroRegime: StateFlow<MacroRegime> = repository.macroRegime
    val news: StateFlow<List<NewsArticle>> = repository.news
    val whaleTransactions: StateFlow<List<WhaleTransaction>> = repository.whaleTransactions
    
    val profile: StateFlow<ProfileEntity?> = repository.profileFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
        
    val holdings: StateFlow<List<HoldingEntity>> = repository.holdingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val watchlist: StateFlow<List<String>> = repository.watchlistFlow
        .map { list -> list.map { it.symbol } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val alerts = repository.alertsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val transactions = repository.transactionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val eventCountdown: StateFlow<Int> = repository.eventCountdown
    val activeMacroEvent: StateFlow<String> = repository.activeMacroEvent

    // --- Technical Indicator Settings ---
    val showRsi = MutableStateFlow(false)
    val showMacd = MutableStateFlow(false)
    val showEma = MutableStateFlow(true)
    val showBollinger = MutableStateFlow(false)
    val showVwap = MutableStateFlow(false)
    val showVolumeProfile = MutableStateFlow(false)

    // --- Search & Filters ---
    val searchQuery = MutableStateFlow("")
    val selectedCategoryFilter = MutableStateFlow<AssetCategory?>(null)

    // Active Asset for Chart/Detail
    private val _selectedAsset = MutableStateFlow<Asset?>(null)
    val selectedAsset: StateFlow<Asset?> = combine(_selectedAsset, assets) { selected, latestList ->
        if (selected == null && latestList.isNotEmpty()) {
            latestList.first { it.symbol == "BTC" } // Default to Bitcoin is a neat terminal layout
        } else {
            latestList.firstOrNull { it.symbol == selected?.symbol } ?: latestList.firstOrNull()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- AI Adaptive Layout Focus Heuristics ---
    // Learns what categories active user clicks on. Adapt layout prioritizing those categories!
    private val _userFocusedCategory = MutableStateFlow<AssetCategory?>(null)
    val userFocusedCategory: StateFlow<AssetCategory?> = _userFocusedCategory.asStateFlow()

    fun registerScreenFocus(category: AssetCategory) {
        _userFocusedCategory.value = category
    }

    // Filtered Assets list
    val filteredAssets: StateFlow<List<Asset>> = combine(assets, searchQuery, selectedCategoryFilter, userFocusedCategory) { list, query, catFilter, focusCat ->
        var result = list
        if (query.isNotEmpty()) {
            result = result.filter { it.symbol.contains(query, ignoreCase = true) || it.name.contains(query, ignoreCase = true) }
        }
        if (catFilter != null) {
            result = result.filter { it.category == catFilter }
        } else if (focusCat != null) {
            // Adaptive layout prioritization - bring user prioritized category to top of the neutral list!
            result = result.sortedBy { if (it.category == focusCat) 0 else 1 }
        }
        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- AI Analyst Intelligence Core ---
    // Evaluates portfolio details, trades history, and macro cycle to formulate cyber comments
    val aiAnalystCritique: StateFlow<String> = combine(profile, holdings, assets, macroRegime) { prof, hList, aList, regime ->
        val totalAssetsValue = hList.sumOf { h ->
            val price = aList.firstOrNull { it.symbol == h.symbol }?.currentPrice ?: h.avgPurchasePrice
            price * h.quantity
        }
        val cash = prof?.balance ?: 100000.0
        val portfolioTotal = cash + totalAssetsValue

        // Under 5 trades
        if ((prof?.tradesCount ?: 0) < 2) {
            return@combine "AI ANALYST CORE UNIT ONLINE: System active. Standing by for transaction triggers. Your core liquidity is $${String.format("%,.2f", cash)}. Load watchlists or purchase assets to feed neural networks."
        }

        // Sector concentration evaluation
        val sectorExposure = hList.groupBy { it.sector }.mapValues { entry ->
            val sectorVal = entry.value.sumOf { h ->
                val price = aList.firstOrNull { it.symbol == h.symbol }?.currentPrice ?: h.avgPurchasePrice
                price * h.quantity
            }
            if (portfolioTotal > 0) (sectorVal / portfolioTotal) * 100.0 else 0.0
        }

        val highExposureSector = sectorExposure.entries.firstOrNull { it.value > 45.0 }

        if (highExposureSector != null) {
            return@combine "AI WARNING: High Concentration Detected in **${highExposureSector.key}** equities representing ${String.format("%.1f", highExposureSector.value)}% of net portfolio worth. " +
                    "A sudden macro contraction in the semiconductor lattice or energy pipeline will inflict catastrophic drawdowns. Rotate capital into sovereign yields (US10Y) or physical Gold (GLD) reserves immediately."
        }

        // Extreme Panic evaluations
        if ((prof?.panicScore ?: 0.0f) > 0.45f) {
            return@combine "BEHAVIORAL WARNING: Panic-Selling Signals Detected. You have repeatedly liquidated assets at steep discounts during a negative ${regime.name} regime cycle. " +
                    "Algorithms identify emotional bias in capital management. Recommend locking liquid reserves in sovereign yields or index baskets to enforce system discipline."
        }

        // Extreme Euphoria MEME evaluations
        if ((prof?.euphoriaScore ?: 0.0f) > 0.40f) {
            return@combine "SPECULATION CRITIQUE: Bubble Overload. Capital heavily rotated toward high-variance digital vectors like **PEPE** and **WIF**. " +
                    "Euphoric momentum is unsustainable in tight interbank rate periods (+${regime.name}). Institutional models anticipate automated liquidation sweeps. Transition into BTC or ETH compute lattices."
        }

        // Standard commentary based on Macro Regimes
        when (regime) {
            MacroRegime.BOOM -> "AI INTEL: Financial lattices register heavy retail euphoria. Macro indicators show structural capital expansion. Growth stocks (NVDA, TSLA) are backed by institutional inflows. Yield spreads remain narrow."
            MacroRegime.RECESSION -> "AI INTEL: Systemwide capital flight into defensive bullion and commodities. Volatility grids (VIX) are saturated. Recommended hedge position: 35% Gold sovereign bullion, 20% high-grade sovereign bonds."
            MacroRegime.RATE_SHOCK -> "AI INTEL: Extreme yield curve convulsions following macro-interest rate adjustments. Bond yields (US10Y) present historic entry premiums. High lending coefficients are depressing technology growth multiples."
            MacroRegime.TECH_REVOLUTION -> "AI INTEL: Quantum neural computing breakthroughs logged. Dramatic productivity multipliers Surge in TECH and BIOGEN pipelines. Highly recommend focusing capital in hardware chipsets (NVDA) and quantum lattice protocols."
            MacroRegime.LIQUIDITY_CRISIS -> "AI WARNING: Systemwide liquidity matrix destabilized. High-frequency arbitrage clearing thresholds broken, leading to cascading liquidations. Standby in cash positions until liquidity index stabilizes."
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Awaiting telemetry signals...")

    // Portfolio metrics computation (Sharpe, Beta, Sector weights)
    val portfolioMetrics: StateFlow<PortfolioMetrics> = combine(holdings, assets, profile) { hList, aList, prof ->
        val cash = prof?.balance ?: 100000.0
        val holdingsVal = hList.sumOf { h ->
            val asset = aList.firstOrNull { it.symbol == h.symbol }
            val price = asset?.currentPrice ?: h.avgPurchasePrice
            price * h.quantity
        }
        val totalWorth = cash + holdingsVal

        // Simple mock calculations for portfolio beta and Sharpe ratio based on holding weights
        var weightedBeta = 0.0
        hList.forEach { h ->
            val weight = if (totalWorth > 0) ((h.quantity * (aList.firstOrNull { it.symbol == h.symbol }?.currentPrice ?: h.avgPurchasePrice)) / totalWorth) else 0.0
            val assetBeta = when (h.category) {
                AssetCategory.CRYPTO.name -> if (h.sector == Sector.MEME.name) 3.2 else 1.8
                AssetCategory.STOCK.name -> if (h.sector == Sector.TECH.name) 1.4 else 0.9
                AssetCategory.INDEX.name -> 1.0
                AssetCategory.COMMODITY.name -> 0.3
                AssetCategory.FOREX.name -> 0.15
                AssetCategory.BOND.name -> -0.1
                else -> 1.0
            }
            weightedBeta += weight * assetBeta
        }
        if (hList.isEmpty()) weightedBeta = 1.0 // Market beta fallback

        val sharpeRatio = if (weightedBeta > 0) (1.2 / weightedBeta) + (0.5 * (prof?.tradesCount ?: 0)) / 10.0 else 1.8

        val exposures = hList.map { h ->
            val valUsd = (aList.firstOrNull { it.symbol == h.symbol }?.currentPrice ?: h.avgPurchasePrice) * h.quantity
            SectorExposure(h.symbol, h.sector, valUsd, if (totalWorth > 0) (valUsd / totalWorth) * 100 else 0.0)
        }

        PortfolioMetrics(
            totalWorth = totalWorth,
            holdingsValue = holdingsVal,
            cash = cash,
            beta = weightedBeta,
            sharpeRatio = sharpeRatio,
            exposures = exposures
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PortfolioMetrics())

    // --- Action Handlers ---

    fun selectAsset(asset: Asset) {
        _selectedAsset.value = asset
    }

    fun buyAsset(symbol: String, qty: Double, onFinished: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = repository.buyAsset(symbol, qty)
            onFinished(result)
        }
    }

    fun sellAsset(symbol: String, qty: Double, onFinished: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = repository.sellAsset(symbol, qty)
            onFinished(result)
        }
    }

    fun toggleWatchlist(symbol: String) {
        viewModelScope.launch {
            repository.toggleWatchlist(symbol)
        }
    }

    fun addAlert(symbol: String, targetPrice: Double, isAbove: Boolean) {
        viewModelScope.launch {
            repository.setAlert(symbol, targetPrice, isAbove)
        }
    }

    fun deleteAlert(id: Int) {
        viewModelScope.launch {
            repository.removeAlert(id)
        }
    }
}

data class SectorExposure(
    val symbol: String,
    val sectorName: String,
    val valueUsd: Double,
    val percent: Double
)

data class PortfolioMetrics(
    val totalWorth: Double = 100000.0,
    val holdingsValue: Double = 0.0,
    val cash: Double = 100000.0,
    val beta: Double = 1.0,
    val sharpeRatio: Double = 1.4,
    val exposures: List<SectorExposure> = emptyList()
)

class MarketViewModelFactory(
    private val application: Application,
    private val repository: MarketRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MarketViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MarketViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
