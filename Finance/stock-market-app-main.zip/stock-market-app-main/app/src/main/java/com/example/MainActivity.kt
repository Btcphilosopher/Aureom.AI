package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.audio.AudioSynthesizer
import com.example.data.database.AppDatabase
import com.example.data.repository.MarketRepository
import com.example.ui.components.BackgroundAmbientParticles
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketViewModel
import com.example.ui.viewmodel.MarketViewModelFactory

enum class TerminalTab {
    MARKETS, CRYPTO, AI_ANALYST, MEDIA, PORTFOLIO, ECONOMIC_CALENDAR
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        enableEdgeToEdge()
        
        // Play the pristine institutional market bell at boottime
        AudioSynthesizer.playBell()

        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val database = remember { AppDatabase.getInstance(context) }
                val repository = remember { MarketRepository(context, database) }
                
                val viewModel: MarketViewModel = viewModel(
                    factory = MarketViewModelFactory(
                        context.applicationContext as Application,
                        repository
                    )
                )

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = BackgroundBlack
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Ambient slow-drift particles behind all terminal units
                        BackgroundAmbientParticles()

                        MainTerminalShell(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTerminalShell(viewModel: MarketViewModel) {
    var activeTab by remember { mutableStateOf(TerminalTab.MARKETS) }
    var soundMuted by remember { mutableStateOf(AudioSynthesizer.isMuted) }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideLayout = maxWidth > 720.dp

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Black.copy(alpha = 0.85f),
                        titleContentColor = Color.White
                    ),
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "FUTURIST MARKETS",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = CyberGold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(CyberCyan.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                                    .border(1.dp, CyberCyan, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "v1.0-SECURED",
                                    color = CyberCyan,
                                    fontSize = 7.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            modifier = Modifier.testTag("audio_mute_toggle"),
                            onClick = {
                                soundMuted = !soundMuted
                                AudioSynthesizer.isMuted = soundMuted
                                AudioSynthesizer.playTick()
                            }
                        ) {
                            Icon(
                                imageVector = if (soundMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                contentDescription = "Toggle Synth Mute",
                                tint = CyberGold,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                )
            },
            bottomBar = {
                // High-performance HUD navigation bar on compact mobile devices
                if (!isWideLayout) {
                    NavigationBar(
                        containerColor = Color.Black.copy(alpha = 0.9f),
                        tonalElevation = 1.dp,
                        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        TerminalTab.values().forEach { tab ->
                            val selected = activeTab == tab
                            NavigationBarItem(
                                modifier = Modifier.testTag("tab_btn_${tab.name}"),
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.label,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                },
                                selected = selected,
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = CyberGold,
                                    unselectedIconColor = Color.Gray,
                                    unselectedTextColor = Color.Gray,
                                    indicatorColor = CyberGold
                                ),
                                onClick = {
                                    activeTab = tab
                                    AudioSynthesizer.playTick()
                                }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Responsive side docking rail if loaded in wide landscape/tablet/DeX platforms
                if (isWideLayout) {
                    NavigationRail(
                        containerColor = Color.Black.copy(alpha = 0.9f),
                        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                        header = {
                            Box(modifier = Modifier.padding(vertical = 12.dp)) {
                                Icon(
                                    imageVector = Icons.Default.TrendingUp,
                                    contentDescription = "Core",
                                    tint = CyberGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    ) {
                        TerminalTab.values().forEach { tab ->
                            val selected = activeTab == tab
                            NavigationRailItem(
                                modifier = Modifier.testTag("rail_tab_${tab.name}"),
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.label,
                                        tint = if (selected) Color.Black else Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (selected) CyberGold else Color.Gray
                                    )
                                },
                                selected = selected,
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    indicatorColor = CyberGold
                                ),
                                onClick = {
                                    activeTab = tab
                                    AudioSynthesizer.playTick()
                                }
                            )
                        }
                    }
                }

                // Primary Workspace Layout Content Panel
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Crossfade(
                        targetState = activeTab,
                        label = "screen_trans"
                    ) { tab ->
                        when (tab) {
                            TerminalTab.MARKETS -> DashboardScreen(
                                viewModel = viewModel,
                                onNavigateToPortfolio = { activeTab = TerminalTab.PORTFOLIO }
                            )
                            TerminalTab.CRYPTO -> CryptoScreen(viewModel = viewModel)
                            TerminalTab.AI_ANALYST -> AiAnalystScreen(viewModel = viewModel)
                            TerminalTab.MEDIA -> MediaScreen(viewModel = viewModel)
                            TerminalTab.PORTFOLIO -> PortfolioScreen(viewModel = viewModel)
                            TerminalTab.ECONOMIC_CALENDAR -> MacroScreen(viewModel = viewModel)
                        }
                    }
                }

                // Tablet responsive right-side supporting pane displaying real-time AI analyst telemetry
                if (isWideLayout) {
                    Box(
                        modifier = Modifier
                            .width(280.dp)
                            .fillMaxHeight()
                            .background(Color(0xFF07090C))
                            .border(BorderStroke(1.dp, GridGlow))
                    ) {
                        // Display continuous intelligence feeds dynamically beside our charts!
                        AiAnalystScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

val TerminalTab.icon: ImageVector
    get() = when (this) {
        TerminalTab.MARKETS -> Icons.Default.CellTower
        TerminalTab.CRYPTO -> Icons.Default.CurrencyBitcoin
        TerminalTab.AI_ANALYST -> Icons.Default.Memory
        TerminalTab.MEDIA -> Icons.Default.Newspaper
        TerminalTab.PORTFOLIO -> Icons.Default.Wallet
        TerminalTab.ECONOMIC_CALENDAR -> Icons.Default.CalendarMonth
    }

val TerminalTab.label: String
    get() = when (this) {
        TerminalTab.MARKETS -> "MARKETS"
        TerminalTab.CRYPTO -> "CRYPTO"
        TerminalTab.AI_ANALYST -> "ANALYST"
        TerminalTab.MEDIA -> "MEDIA"
        TerminalTab.PORTFOLIO -> "PORTFOLIO"
        TerminalTab.ECONOMIC_CALENDAR -> "MACRO"
    }
