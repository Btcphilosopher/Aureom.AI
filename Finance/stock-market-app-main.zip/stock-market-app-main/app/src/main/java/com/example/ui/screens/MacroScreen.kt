package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.AlertEntity
import com.example.data.repository.MacroRegime
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketViewModel

@Composable
fun MacroScreen(
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    val countdown by viewModel.eventCountdown.collectAsState()
    val activeEvent by viewModel.activeMacroEvent.collectAsState()
    val rawAssets by viewModel.assets.collectAsState()
    val activeAlerts by viewModel.alerts.collectAsState()
    val activeRegime by viewModel.macroRegime.collectAsState()

    // Alert setting form states
    var selectedSymbolForAlert by remember { mutableStateOf("BTC") }
    var targetPriceStr by remember { mutableStateOf("65000.0") }
    var isAlertAbove by remember { mutableStateOf(true) }
    var expandedDropdown by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Countdown timer card
        Card(
            colors = CardDefaults.cardColors(containerColor = TonalGlass),
            border = BorderStroke(2.dp, CyberGold),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "UPCOMING WORLD MACRO CONVULSION METRIC",
                    color = CyberGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Text(
                    text = "00:00:$countdown",
                    color = CyberPink,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.testTag("macro_countdown")
                )

                Text(
                    text = "TARGET INDEX EVENT: $activeEvent",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Underlying models predict a sudden transition across global portfolios as soon as the grid countdown locks 00. Yield indices will adjust.",
                    color = Color.Gray,
                    fontSize = 9.sp,
                    lineHeight = 13.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Active Macro Regime Breakdown description
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "MACRO SYSTEM REVOLUTION MATRIX REGIMES",
                color = CyberGold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            MacroRegimeDetailCard("BOOM (CAPITAL EXPANSION)", activeRegime == MacroRegime.BOOM) {
                Text("• Asset Multiplier: Growth stocks (NVDA, TSLA) surge under high retail momentum.\n• Crypto Index: Altcoins surge, PEPE and WIF face extreme euphoria surges.\n• Safe Havens: Gold sovereign bullion retreats as capital targets raw alpha.", color = Color.LightGray, fontSize = 9.sp)
            }

            MacroRegimeDetailCard("RECESSION (LIQUID PROTOCOL HALT)", activeRegime == MacroRegime.RECESSION) {
                Text("• Asset Multiplier: Stock indices fall. High industrial commodities bottleneck.\n• Crypto Index: Blockchain volume lowers as retail exits leverage risk.\n• Safe Havens: Gold sovereign bullion (GLD) and protective VIX spike heavily.", color = Color.LightGray, fontSize = 9.sp)
            }

            MacroRegimeDetailCard("RATE SHOCK (INTERBANK ADJUSTMENT)", activeRegime == MacroRegime.RATE_SHOCK) {
                Text("• Asset Multiplier: Mega-caps contract under capital lending fees.\n• Bond yields: Sovereign bond indices (US10Y) capture substantial alpha entries.\n• Safe Havens: Forex fiat indices experience sharp exchange spikes.", color = Color.LightGray, fontSize = 9.sp)
            }

            MacroRegimeDetailCard("TECH REVOLUTION (QUANTUM BOOM)", activeRegime == MacroRegime.TECH_REVOLUTION) {
                Text("• Asset Multiplier: Technology humanoids superchips (NVDA, TSLA) surges 350%.\n• Safe Havens: Defensives like treasury grids (US10Y) contract under raw tech alpha.\n• Sentiment: The AI analyst experiences euphoric neural grid states.", color = Color.LightGray, fontSize = 9.sp)
            }

            MacroRegimeDetailCard("LIQUIDITY CRISIS (BLACK SWAN MATRIX)", activeRegime == MacroRegime.LIQUIDITY_CRISIS) {
                Text("• Asset Multiplier: Cash/CC is the only viable refuge. Margin halts across indexes.\n• Volatility: Quantum VIX leaps +50% instantaneously on panic metrics.\n• Sentiment: AI Analyser issues critical exit warnings systematically.", color = Color.LightGray, fontSize = 9.sp)
            }
        }

        // Alerts set and configure interface
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "TERMINAL HARMONIC PRICE ALERTS CONSOLE",
                color = CyberGold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = TonalGlass),
                border = BorderStroke(1.dp, GridGlow),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "NEW PRICE CROSSING ALERT CODES",
                        color = CyberCyan,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )

                    // Symbol input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = selectedSymbolForAlert,
                            onValueChange = { selectedSymbolForAlert = it.toUpperCase() },
                            label = { Text("Instrument Symbol Code") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = GridGlow,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("alert_symbol_field")
                        )

                        OutlinedTextField(
                            value = targetPriceStr,
                            onValueChange = { targetPriceStr = it },
                            label = { Text("Crossing Triger Rate") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = GridGlow,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("alert_price_field")
                        )
                    }

                    // Crossing direction button toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { isAlertAbove = true },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isAlertAbove) CyberGold else Color.Gray.copy(alpha = 0.2f)),
                            modifier = Modifier.weight(1f).height(32.dp),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text("CROSS ABOVE ▲", color = if (isAlertAbove) BackgroundBlack else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { isAlertAbove = false },
                            colors = ButtonDefaults.buttonColors(containerColor = if (!isAlertAbove) CyberGold else Color.Gray.copy(alpha = 0.2f)),
                            modifier = Modifier.weight(1f).height(32.dp),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text("CROSS BELOW ▼", color = if (!isAlertAbove) BackgroundBlack else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        modifier = Modifier.fillMaxWidth().height(36.dp).testTag("alert_setup_button"),
                        onClick = {
                            val priceVal = targetPriceStr.toDoubleOrNull() ?: 0.0
                            if (selectedSymbolForAlert.isNotEmpty() && priceVal > 0.0) {
                                viewModel.addAlert(selectedSymbolForAlert, priceVal, isAlertAbove)
                                targetPriceStr = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Text("ENGAGE SYSTEM WARNING ALERT", color = BackgroundBlack, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // List of active price alerts managed inside SQLite Database
            Text(
                text = "ACTIVE TERMINAL WARNING STATIONS",
                color = Color.Gray,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )

            if (activeAlerts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GridGlow)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("NO ACTIVE PRICE WARNING CODES ENGAGED.", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            } else {
                activeAlerts.forEach { alert ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GridGlow)
                            .background(Color(0xFF07090C))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Alert active",
                                tint = if (alert.isTriggered) Color.Gray else CyberGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${alert.symbol} crosses ${if (alert.isAbove) "above ▲" else "below ▼"} $${String.format("%,.4f", alert.targetPrice)}",
                                color = if (alert.isTriggered) Color.Gray else Color.White,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (alert.isTriggered) {
                                Text(
                                    text = "FIRED",
                                    color = NeonGreen,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(marginEnd = 6.dp)
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Alert",
                                tint = NeonRed.copy(alpha = 0.7f),
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { viewModel.deleteAlert(alert.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun String.toUpperCase(): String = this.uppercase()
private fun Modifier.padding(marginEnd: androidx.compose.ui.unit.Dp): Modifier = this

@Composable
fun MacroRegimeDetailCard(
    regimeName: String,
    isActive: Boolean,
    content: @Composable () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = if (isActive) Color(0xFF16120E) else TonalGlass),
        border = BorderStroke(1.dp, if (isActive) CyberGold else GridGlow),
        shape = RoundedCornerShape(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = regimeName,
                    color = if (isActive) CyberGold else Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                if (isActive) {
                    Box(
                        modifier = Modifier
                            .background(CyberGold.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                            .border(1.dp, CyberGold, RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "ACTIVE WORLD STATE",
                            color = CyberGold,
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
            content()
        }
    }
}
