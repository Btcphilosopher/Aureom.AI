package com.example.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.example.data.audio.AudioSynthesizer
import com.example.data.database.*
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

enum class MacroRegime {
    BOOM, RECESSION, RATE_SHOCK, TECH_REVOLUTION, LIQUIDITY_CRISIS
}

data class WhaleTransaction(
    val id: String = UUID.randomUUID().toString(),
    val symbol: String,
    val amountUsd: Double,
    val quantity: Double,
    val fromAddress: String,
    val toAddress: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class NewsArticle(
    val id: String = UUID.randomUUID().toString(),
    val headline: String,
    val content: String,
    val source: String,
    val author: String,
    val opinionVibe: String, // Sensationalist, Quant, Central Bank Critic, etc.
    val impactRating: Int, // 1 - 5 stars
    val timestamp: Long = System.currentTimeMillis()
)

class MarketRepository(
    context: Context,
    private val db: AppDatabase
) {
    private val dao = db.marketDao()
    private val repositoryScope = CoroutineScope(Dispatchers.Default + Job())

    // --- Core Flows ---
    private val _assets = MutableStateFlow<List<Asset>>(emptyList())
    val assets: StateFlow<List<Asset>> = _assets.asStateFlow()

    private val _macroRegime = MutableStateFlow(MacroRegime.BOOM)
    val macroRegime: StateFlow<MacroRegime> = _macroRegime.asStateFlow()

    private val _news = MutableStateFlow<List<NewsArticle>>(emptyList())
    val news: StateFlow<List<NewsArticle>> = _news.asStateFlow()

    private val _whaleTransactions = MutableStateFlow<List<WhaleTransaction>>(emptyList())
    val whaleTransactions: StateFlow<List<WhaleTransaction>> = _whaleTransactions.asStateFlow()

    val profileFlow: Flow<ProfileEntity?> = dao.getProfileFlow()
    val holdingsFlow: Flow<List<HoldingEntity>> = dao.getHoldingsFlow()
    val watchlistFlow: Flow<List<WatchlistEntity>> = dao.getWatchlistFlow()
    val alertsFlow: Flow<List<AlertEntity>> = dao.getAlertsFlow()
    val transactionsFlow: Flow<List<TransactionEntity>> = dao.getTransactionsFlow()

    // Economic Event Timer
    private val _eventCountdown = MutableStateFlow(45) // Countdown in seconds
    val eventCountdown: StateFlow<Int> = _eventCountdown.asStateFlow()

    private val _activeMacroEvent = MutableStateFlow("Federal Reserve Rate Announcement (FOMC)")
    val activeMacroEvent: StateFlow<String> = _activeMacroEvent.asStateFlow()

    init {
        // Initialize Profile
        repositoryScope.launch {
            if (dao.getProfileDirect() == null) {
                dao.insertOrUpdateProfile(ProfileEntity())
            }
        }
        
        // Initialize Assets with historical price bars
        _assets.value = generateInitialAssets()
        
        // Initialize procedural news
        _news.value = generateInitialNews()

        // Start Clock Engines
        startSimulationClock()
    }

    private fun generateInitialAssets(): List<Asset> {
        val initialList = listOf(
            Asset("TSLA", "Tesla Robotics & Fleet", AssetCategory.STOCK, Sector.TECH, 210.50, 208.10, 215.00, 201.20, 200.00, 1250000.0, 85, 32.5),
            Asset("NVDA", "Nvidia Superchips Corp", AssetCategory.STOCK, Sector.TECH, 895.00, 882.30, 905.00, 871.10, 850.00, 3100000.0, 95, 68.2),
            Asset("AAPL", "Apple Quantum Glass", AssetCategory.STOCK, Sector.TECH, 185.20, 186.00, 188.50, 183.10, 180.00, 950000.0, 98, 41.0),
            Asset("MSFT", "Microsoft MindLink", AssetCategory.STOCK, Sector.TECH, 420.10, 422.50, 426.00, 415.00, 410.00, 800000.0, 97, 54.5),
            Asset("AMZN", "Amazon Drone Logistic", AssetCategory.STOCK, Sector.HEAVY_INDUSTRY, 175.40, 172.90, 178.00, 170.10, 170.00, 1100000.0, 89, 21.0),
            
            Asset("FTSE", "FTSE 100 Smart Index", AssetCategory.INDEX, Sector.FINANCE, 7920.00, 7950.00, 7990.00, 7890.00, 7900.00, 4500000.0, 90, 78.0),
            Asset("DAX", "DAX 40 Eurocore Index", AssetCategory.INDEX, Sector.HEAVY_INDUSTRY, 18100.00, 18010.00, 18220.00, 17950.00, 18000.00, 4200000.0, 92, 81.0),
            
            Asset("BTC", "Bitcoin Protocol Network", AssetCategory.CRYPTO, Sector.FINANCE, 64250.00, 63800.00, 64900.00, 62700.00, 60000.00, 15000000.0, 99, 15.6),
            Asset("ETH", "Ethereum Compute Lattice", AssetCategory.CRYPTO, Sector.FINANCE, 3350.00, 3420.00, 3460.00, 3290.00, 3200.00, 8500000.0, 94, 21.3),
            Asset("SOL", "Solana Hyperledger", AssetCategory.CRYPTO, Sector.FINANCE, 142.50, 138.20, 148.00, 129.50, 130.00, 12000000.0, 84, 9.8),
            Asset("PEPE", "Pepe Core Meme Layer", AssetCategory.CRYPTO, Sector.MEME, 0.000014, 0.000012, 0.000016, 0.000011, 0.000010, 25000000.0, 45, 1.2),
            Asset("WIF", "DogWifHat Protocol", AssetCategory.CRYPTO, Sector.MEME, 2.85, 2.45, 3.10, 2.20, 2.00, 8000000.0, 42, 0.8),
            
            Asset("GLD", "Gold Sovereign Bullion", AssetCategory.COMMODITY, Sector.GOVT, 2350.20, 2335.00, 2362.00, 2320.00, 2300.00, 320000.0, 91, 49.5),
            Asset("OIL", "Brent Cyber Crude", AssetCategory.COMMODITY, Sector.ENERGY, 81.50, 82.10, 83.25, 80.12, 80.00, 650000.0, 85, 19.3),
            Asset("COPR", "Nanotech High-Grade Copper", AssetCategory.COMMODITY, Sector.HEAVY_INDUSTRY, 4.25, 4.18, 4.31, 4.12, 4.10, 150000.0, 78, 14.5),
            
            Asset("EURUSD", "Euro / US Dollar FX", AssetCategory.FOREX, Sector.GOVT, 1.0820, 1.0845, 1.0890, 1.0792, 1.0800, 12000000.0, 99, 90.0),
            Asset("USDJPY", "US Dollar / Japanese Yen", AssetCategory.FOREX, Sector.GOVT, 155.45, 154.90, 156.12, 154.20, 155.00, 9500000.0, 99, 92.5),
            
            Asset("US10Y", "US 10-Yr Sovereign Yield", AssetCategory.BOND, Sector.GOVT, 4.425, 4.450, 4.482, 4.380, 4.400, 80000.0, 93, 89.0),
            Asset("VIX", "CBOE Quantum Volatility", AssetCategory.BOND, Sector.GOVT, 13.85, 14.20, 15.10, 12.95, 14.00, 50000.0, 80, 52.0)
        )

        // Generate 50 hours of historical candles for each asset
        return initialList.map { asset ->
            val bars = ArrayList<PriceBar>()
            var lastPrice = asset.currentPrice
            val random = Random(asset.symbol.hashCode())
            var currentVol = asset.volume / 50.0

            val timestampOffset = 3600000L // 1 hour steps
            var mockTime = System.currentTimeMillis() - (50 * timestampOffset)

            for (i in 0 until 50) {
                val volatility = when (asset.category) {
                    AssetCategory.CRYPTO -> if (asset.sector == Sector.MEME) 0.12 else 0.04
                    AssetCategory.STOCK -> 0.015
                    AssetCategory.INDEX -> 0.006
                    AssetCategory.COMMODITY -> 0.01
                    AssetCategory.FOREX -> 0.002
                    AssetCategory.BOND -> 0.005
                }
                val pctChange = (random.nextDouble() - 0.48) * 2 * volatility
                val open = lastPrice
                val close = lastPrice * (1.0 + pctChange)
                val low = minOf(open, close) * (1.0 - (random.nextDouble() * volatility * 0.4))
                val high = maxOf(open, close) * (1.0 + (random.nextDouble() * volatility * 0.4))
                
                bars.add(
                    PriceBar(
                        timestamp = mockTime,
                        open = open.toFloat(),
                        close = close.toFloat(),
                        high = high.toFloat(),
                        low = low.toFloat(),
                        volume = (currentVol * (0.5 + random.nextDouble())).toFloat()
                    )
                )

                lastPrice = close
                mockTime += timestampOffset
            }

            // Bind generated history
            asset.copy(currentPrice = lastPrice, prevPrice = bars.first().open.toDouble(), history = bars)
        }
    }

    private fun generateInitialNews(): List<NewsArticle> {
        val commentaryFirms = listOf("Apex Capital Research", "Prism Quantitative", "Valiant Capital Partners", "Omni Sovereign Corp", "GigaMinds AI Research")
        val sensations = listOf(
            "Jim Flashpoint" to "Sensationalist Broadcast",
            "Clara Frost" to "Macro Strategist Expert",
            "Arthur Sterling" to "Floor Veteran Advisor",
            "Sigma-9 Quant" to "Autonomous AI Quant",
            "Conspiracy Financial" to "Alternative Broadcast",
            "Satoshi 2090" to "Crypto Maximalist Advocate",
            "Gideon Slate" to "Central-Bank Critic Analyst"
        )
        val sampleHeadlines = listOf(
            Pair("VALIANT CAPITAL ANNOUNCES FUSION RETIREMENT rotation into Heavy Uranium Equities.", "Retail capital flows hit historical highs following grid connections across nuclear corridors. Energy space revalues +14% after institutional bids flow."),
            Pair("RETAIL EUphoria Elevates Cyber Meme Vectors.", "Pepe and WIF surge over 45% in late after-hours trading session. Market quants Warn retail euphoria index sits in a dangerous red buffer zone."),
            Pair("CENTRAL BANK ANNOUNCES EMERGENCY LIQUIDITY STAGE 2.", "Federal Reserve deploys secondary computing lattices to facilitate hyper-speed credit injection. Bond traders warn of fiat discount rates."),
            Pair("TITAN CAPITAL UPGRADES AUTOMATION ROBOTICS TO ADVANCED BUYS.", "Analysts cite extreme neural density gains in heavy cybernetic humanoid cells. Nvidia shares jump +4%."),
            Pair("SOCIALLY DECENTRALIZED PROTOCOLS DETECT BLOCKCHAIN BOTNET ACCUMULATION.", "Solana node runners confirm 45,000 algorithmic accounts depositing liquidity in DeFi structures. Whales active in on-chain block transfers.")
        )

        return sampleHeadlines.mapIndexed { idx, item ->
            val p = sensations[idx % sensations.size]
            NewsArticle(
                headline = item.first,
                content = item.second,
                source = commentaryFirms[idx % commentaryFirms.size],
                author = p.first,
                opinionVibe = p.second,
                impactRating = Random.nextInt(2, 6)
            )
        }
    }

    private fun startSimulationClock() {
        repositoryScope.launch {
            while (true) {
                delay(3000) // Update prices every 3 seconds for intense live dashboard feel
                tickIndicesAndPrices()
                tickEconomicEvent()
                tickWhaleActivity()
                tickProceduralNews()
            }
        }
    }

    private suspend fun tickIndicesAndPrices() {
        val currentRegime = _macroRegime.value
        val list = _assets.value.map { asset ->
            // Stochastic random walks with trend biasing based on macroeconomic regime
            val randomModifier = Random.nextDouble() - 0.5 // -0.5 to 0.5
            var trendBias = 0.0

            when (currentRegime) {
                MacroRegime.BOOM -> {
                    if (asset.category == AssetCategory.STOCK || asset.category == AssetCategory.CRYPTO) {
                        trendBias = 0.04  // Upward trend
                    }
                    if (asset.category == AssetCategory.COMMODITY && asset.symbol == "GLD") {
                        trendBias = -0.01 // Gold drops in good times
                    }
                }
                MacroRegime.RECESSION -> {
                    if (asset.category == AssetCategory.STOCK || asset.category == AssetCategory.CRYPTO) {
                        trendBias = -0.05 // Bears prevail
                    }
                    if (asset.symbol == "GLD" || asset.symbol == "VIX") {
                        trendBias = 0.06  // Gold and Volatility skyrocket
                    }
                }
                MacroRegime.TECH_REVOLUTION -> {
                    if (asset.sector == Sector.TECH || asset.sector == Sector.BIO_GEN) {
                        trendBias = 0.12  // Tech explosion!
                    }
                }
                MacroRegime.RATE_SHOCK -> {
                    if (asset.symbol == "US10Y") {
                        trendBias = 0.08  // Yields shoot up
                    }
                    if (asset.category == AssetCategory.STOCK) {
                        trendBias = -0.03 // Tech contracts under high interest
                    }
                }
                MacroRegime.LIQUIDITY_CRISIS -> {
                    trendBias = -0.08 // Liquidity drain lowers everything
                    if (asset.symbol == "VIX") {
                        trendBias = 0.15  // Pure panic spikes volatility
                    }
                }
            }

            // High Volatility modifiers for meme sectors
            val assetVolatilityMultiplier = when (asset.sector) {
                Sector.MEME -> 3.5
                Sector.TECH -> 1.5
                Sector.GOVT -> 0.4
                else -> 1.0
            }

            val baseVol = when (asset.category) {
                AssetCategory.CRYPTO -> 0.015
                AssetCategory.STOCK -> 0.007
                AssetCategory.INDEX -> 0.003
                AssetCategory.COMMODITY -> 0.005
                AssetCategory.FOREX -> 0.001
                AssetCategory.BOND -> 0.002
            }

            val finalPercentChange = (randomModifier * baseVol * assetVolatilityMultiplier) + (trendBias * baseVol)
            val updatedPrice = maxOf(0.000001, asset.currentPrice * (1.0 + finalPercentChange))

            // Update price bars to keep graphs ticking
            val updatedHistory = asset.history.toMutableList()
            if (updatedHistory.isNotEmpty()) {
                val lastBar = updatedHistory.last()
                val currentTimestamp = System.currentTimeMillis()
                
                // If the last bar is less than 30 seconds old, merge into it, otherwise spawn a new candle
                if (currentTimestamp - lastBar.timestamp < 30000) {
                    val mergedBar = lastBar.copy(
                        close = updatedPrice.toFloat(),
                        high = maxOf(lastBar.high, updatedPrice.toFloat()),
                        low = minOf(lastBar.low, updatedPrice.toFloat()),
                        volume = (lastBar.volume + (asset.volume / 50000.0 * Random.nextFloat())).toFloat()
                    )
                    updatedHistory[updatedHistory.lastIndex] = mergedBar
                } else {
                    // Create new candle and remove oldest to keep 50 bar buffer
                    updatedHistory.removeAt(0)
                    updatedHistory.add(
                        PriceBar(
                            timestamp = currentTimestamp,
                            open = lastBar.close,
                            close = updatedPrice.toFloat(),
                            high = maxOf(lastBar.close, updatedPrice.toFloat()),
                            low = minOf(lastBar.close, updatedPrice.toFloat()),
                            volume = (asset.volume / 50000.0 * Random.nextFloat()).toFloat()
                        )
                    )
                }
            }

            // Trigger dynamic sound pulses on specific high volatility thresholds
            if (Math.abs(finalPercentChange) > 0.02 && asset.category == AssetCategory.CRYPTO) {
                AudioSynthesizer.playTick()
            }

            asset.copy(
                currentPrice = updatedPrice,
                prevPrice = if (Random.nextInt(100) < 5) asset.currentPrice else asset.prevPrice, // Slowly rolling open price
                dayHigh = maxOf(asset.dayHigh, updatedPrice),
                dayLow = minOf(asset.dayLow, updatedPrice),
                history = updatedHistory,
                aiSentiment = maxOf(0.0f, minOf(1.0f, asset.aiSentiment + (randomModifier.toFloat() * 0.1f) + (trendBias.toFloat() * 0.02f)))
            )
        }

        _assets.value = list

        // Check active numeric alerts
        checkFiredAlerts(list)
    }

    private suspend fun checkFiredAlerts(currentAssets: List<Asset>) {
        val activeAlerts = dao.getActiveAlertsDirect()
        for (alert in activeAlerts) {
            val asset = currentAssets.firstOrNull { it.symbol == alert.symbol } ?: continue
            val triggered = if (alert.isAbove) {
                asset.currentPrice >= alert.targetPrice
            } else {
                asset.currentPrice <= alert.targetPrice
            }

            if (triggered) {
                dao.markAlertTriggered(alert.id)
                AudioSynthesizer.playAlert()
                // Append breaking alert notification to procedurals news feed
                addAlertNewsHeadline(alert, asset.currentPrice)
            }
        }
    }

    private fun addAlertNewsHeadline(alert: AlertEntity, finalPrice: Double) {
        val directionString = if (alert.isAbove) "crosses above" else "drops below"
        val alertArticle = NewsArticle(
            headline = "SIGNAL BURST: ${alert.symbol} target of ${String.format("%.2f", alert.targetPrice)} triggered.",
            content = "Cybernetic terminal monitoring systems detect asset ${alert.symbol} price flash $directionString custom user alert bar. Price checked at ${String.format("%.4f", finalPrice)}.",
            source = "Terminal System Alert Protocols",
            author = "AI Watcher Core-7",
            opinionVibe = "Autonomous Quant System",
            impactRating = 5
        )
        val currentNewsList = _news.value.toMutableList()
        currentNewsList.add(0, alertArticle)
        if (currentNewsList.size > 50) currentNewsList.removeAt(currentNewsList.lastIndex)
        _news.value = currentNewsList
    }

    private fun tickEconomicEvent() {
        val nextTime = _eventCountdown.value - 1
        if (nextTime <= 0) {
            _eventCountdown.value = 60 // Reset countdown
            triggerGlobalMacroEvent()
        } else {
            _eventCountdown.value = nextTime
        }
    }

    private fun triggerGlobalMacroEvent() {
        val regimes = MacroRegime.values()
        val randomRegime = regimes[Random.nextInt(regimes.size)]
        _macroRegime.value = randomRegime

        val (eventName, headline, content) = when (randomRegime) {
            MacroRegime.BOOM -> Triple(
                "Consumer Credit Optimization Releases SF-12",
                "MACRO SHIFT DETECTED: Federal reserves enter global expansion cycle.",
                "AI metrics indicate systemwide capital rotation towards high-growth high-conviction robotics. Equities indices record heavy institutional support."
            )
            MacroRegime.RECESSION -> Triple(
                "Emergency Sovereign Rating Reclassification Directive",
                "LIQUIDITY COLLAPSE: Commodity bonds trigger sovereign credit warnings.",
                "Global indexes contract as trade sanctions on nanotechnology logistics trigger sudden industrial commodity bottlenecks. Portfolio quants scale risk down manually."
            )
            MacroRegime.RATE_SHOCK -> Triple(
                "Inter-Bank Loan Rate Readjustment Vote",
                "RATE CONVULSIONS: Yield curves jump as central bank targets asset inflation.",
                "Sovereign bond indices suffer rapid liquidity exits as inflation matrices force higher terminal discount schedules. Mega-caps tech retreat."
            )
            MacroRegime.TECH_REVOLUTION -> Triple(
                "Quantum Machine Interface Protocols Ratified",
                "QUANTUM EXPLOSION: High-density intelligence compute models approved widely.",
                "Industrial semiconductor supply channels revalue by multiplier of 2.1x as bio-genetic cloud arrays prove quantum scalability. High sector concentration in Tech."
            )
            MacroRegime.LIQUIDITY_CRISIS -> Triple(
                "Algorithmic Clearing Ledger De-leveraging Halt",
                "FLASH CRASH EXCHANGES: High-frequency margin thresholds breached.",
                "Systemic liquid reserves vaporize momentarily following clearing errors in secondary smart-coin bridges. VIX spikes +45% on historic volatility panic."
            )
        }

        _activeMacroEvent.value = eventName
        AudioSynthesizer.playBell()

        // Push macroeconomic bulletin
        val macroArticle = NewsArticle(
            headline = headline,
            content = content,
            source = "Sovereign Intelligence Bureau",
            author = "Clara Frost",
            opinionVibe = "Macro Strategist Expert",
            impactRating = 5
        )
        val currentNewsList = _news.value.toMutableList()
        currentNewsList.add(0, macroArticle)
        _news.value = currentNewsList
    }

    private fun tickWhaleActivity() {
        if (Random.nextInt(100) < 30) { // 30% chance to simulate whale block transfer on blockchain
            val cryptos = listOf("BTC", "ETH", "SOL")
            val selected = cryptos[Random.nextInt(cryptos.size)]
            val asset = _assets.value.firstOrNull { it.symbol == selected } ?: return
            val amountUsd = Random.nextDouble(500000.0, 15000000.0)
            val qty = amountUsd / asset.currentPrice

            val tx = WhaleTransaction(
                symbol = selected,
                amountUsd = amountUsd,
                quantity = qty,
                fromAddress = "0x" + List(8) { "0123456789abcdef".random() }.joinToString("") + "..." + List(4) { "0123456789abcdef".random() }.joinToString(""),
                toAddress = if (Random.nextInt(100) < 40) "Coinbase Institutional Custody" else "Cold Storage Ledger Vault (0x3F...89)"
            )

            val list = _whaleTransactions.value.toMutableList()
            list.add(0, tx)
            if (list.size > 40) list.removeAt(list.lastIndex)
            _whaleTransactions.value = list
        }
    }

    private fun tickProceduralNews() {
        if (Random.nextInt(100) < 20) { // 20% chance to generate random procedural media headline
            val headlines = listOf(
                "Rumours circulate of private mega-stakes buyouts on major drone logistics fleets.",
                "Central Bank critic issues stark hyperinflation warnings, recommends physical gold bars.",
                "Floor veteran Arthur Sterling cautions against over-leveraging crypto meme sectors.",
                "Conspiracy financial network claims smart-grid computational limits reached across Eastern corridors.",
                "Jim Flashpoint screaming: 'BUY NVIDIA SUPERCIPHER CELLS SECONDS AGO!'",
                "Sigma-9 Quant detects extreme computational momentum in semiconductor pipelines.",
            )
            val body = listOf(
                "Sources indicate strategic mergers in progress within cyber-defense transport grids.",
                "Unusual capital parking nodes observed across hard metals repositories in European hubs.",
                "Speculative leverage ratios among retail accounts hit historic levels, leading to margin wipeouts.",
                "Hedge-fund operations declare historic long positions on quantum computing companies.",
                "Urgent warnings for retail participants over high concentration risk in PEPE derivatives.",
                "Volatility trackers record sudden narrowing of bonds yield indices, preparing for the next Fed rate decision."
            )
            val sensations = listOf(
                "Jim Flashpoint" to "Sensationalist Broadcast",
                "Arthur Sterling" to "Floor Veteran Advisor",
                "Conspiracy Financial" to "Alternative Broadcast",
                "Satoshi 2090" to "Crypto Maximalist Advocate",
                "Gideon Slate" to "Central-Bank Critic Analyst",
                "Sigma-9 Quant" to "Autonomous AI Quant"
            )

            val list = _news.value.toMutableList()
            val rIdx = Random.nextInt(headlines.size)
            val p = sensations[Random.nextInt(sensations.size)]
            list.add(0, NewsArticle(
                headline = headlines[rIdx],
                content = body[Random.nextInt(body.size)],
                source = "Dynamic Broadcaster Network",
                author = p.first,
                opinionVibe = p.second,
                impactRating = Random.nextInt(1, 6)
            ))
            if (list.size > 50) list.removeAt(list.lastIndex)
            _news.value = list
        }
    }

    // --- Trading Logic (Broker Execution with Database Transactions) ---

    suspend fun buyAsset(symbol: String, userWishQuantity: Double): Boolean {
        if (userWishQuantity <= 0.0) return false
        val asset = _assets.value.firstOrNull { it.symbol == symbol } ?: return false
        val cost = asset.currentPrice * userWishQuantity

        return try {
            var success = false
            db.withTransaction {
                val profile = dao.getProfileDirect() ?: return@withTransaction
                if (profile.balance >= cost) {
                    // Deduct balance
                    val updatedBalance = profile.balance - cost
                    val existingHolding = dao.getHoldingDirect(symbol)
                    
                    if (existingHolding != null) {
                        val newQty = existingHolding.quantity + userWishQuantity
                        val newAvgPrice = ((existingHolding.avgPurchasePrice * existingHolding.quantity) + cost) / newQty
                        dao.insertHolding(
                            existingHolding.copy(
                                quantity = newQty,
                                avgPurchasePrice = newAvgPrice
                            )
                        )
                    } else {
                        dao.insertHolding(
                            HoldingEntity(
                                symbol = symbol,
                                name = asset.name,
                                category = asset.category.name,
                                sector = asset.sector.name,
                                quantity = userWishQuantity,
                                avgPurchasePrice = asset.currentPrice
                            )
                        )
                    }

                    // Record Transaction
                    dao.insertTransaction(
                        TransactionEntity(
                            symbol = symbol,
                            quantity = userWishQuantity,
                            price = asset.currentPrice,
                            isBuy = true
                        )
                    )

                    // Learn Sector Preference weights
                    val updatedSectors = updateSectorPreferences(profile.learnedSectors, asset.sector.name, isBuy = true)

                    // Save Profile
                    dao.insertOrUpdateProfile(
                        profile.copy(
                            balance = updatedBalance,
                            learnedSectors = updatedSectors,
                            tradesCount = profile.tradesCount + 1,
                            euphoriaScore = if (asset.sector == Sector.MEME) minOf(1.0f, profile.euphoriaScore + 0.15f) else maxOf(0.0f, profile.euphoriaScore - 0.03f)
                        )
                    )
                    success = true
                }
            }
            if (success) {
                AudioSynthesizer.playBuy()
            }
            success
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun sellAsset(symbol: String, quantityToSell: Double): Boolean {
        if (quantityToSell <= 0.0) return false
        val asset = _assets.value.firstOrNull { it.symbol == symbol } ?: return false

        return try {
            var success = false
            db.withTransaction {
                val profile = dao.getProfileDirect() ?: return@withTransaction
                val existingHolding = dao.getHoldingDirect(symbol) ?: return@withTransaction
                
                if (existingHolding.quantity >= quantityToSell) {
                    val proceed = asset.currentPrice * quantityToSell
                    val leftoverQty = existingHolding.quantity - quantityToSell
                    
                    if (leftoverQty > 0.0001) {
                        dao.insertHolding(existingHolding.copy(quantity = leftoverQty))
                    } else {
                        dao.deleteHolding(existingHolding)
                    }

                    // Add Profile balance
                    val updatedBalance = profile.balance + proceed

                    // Record Transaction
                    dao.insertTransaction(
                        TransactionEntity(
                            symbol = symbol,
                            quantity = quantityToSell,
                            price = asset.currentPrice,
                            isBuy = false
                        )
                    )

                    // Learn Sector Preferences
                    val updatedSectors = updateSectorPreferences(profile.learnedSectors, asset.sector.name, isBuy = false)

                    // Check panic selling (selling in a recession or when losing money)
                    val isLoss = asset.currentPrice < existingHolding.avgPurchasePrice
                    val updatedPanic = if (isLoss && _macroRegime.value == MacroRegime.RECESSION) {
                        minOf(1.0f, profile.panicScore + 0.25f)
                    } else {
                        maxOf(0.0f, profile.panicScore - 0.05f)
                    }

                    // Save Profile
                    dao.insertOrUpdateProfile(
                        profile.copy(
                            balance = updatedBalance,
                            learnedSectors = updatedSectors,
                            tradesCount = profile.tradesCount + 1,
                            panicScore = updatedPanic
                        )
                    )
                    success = true
                }
            }
            if (success) {
                AudioSynthesizer.playSell()
            }
            success
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun updateSectorPreferences(sectorStr: String, alteredSector: String, isBuy: Boolean): String {
        // Sector Weights are comma separated like SECTOR:WEIGHT
        // Simple heuristic tracking sectors interacting
        val weights = sectorStr.split(",").associate {
            val parts = it.split(":")
            if (parts.size == 2) parts[0] to (parts[1].toFloatOrNull() ?: 1.0f) else it to 1.0f
        }.toMutableMap()

        val addVal = if (isBuy) 0.5f else 0.2f
        weights[alteredSector] = (weights[alteredSector] ?: 1.0f) + addVal

        return weights.entries.joinToString(",") { "${it.key}:${String.format("%.1f", it.value)}" }
    }

    // --- Watchlist and Alerts ---

    suspend fun toggleWatchlist(symbol: String) {
        if (dao.isInWatchlist(symbol)) {
            dao.removeFromWatchlist(WatchlistEntity(symbol))
        } else {
            dao.addToWatchlist(WatchlistEntity(symbol))
        }
        AudioSynthesizer.playTick()
    }

    suspend fun setAlert(symbol: String, userTargetPrice: Double, alertAbove: Boolean) {
        dao.insertAlert(
            AlertEntity(
                symbol = symbol,
                targetPrice = userTargetPrice,
                isAbove = alertAbove
            )
        )
        AudioSynthesizer.playBuy()
    }

    suspend fun removeAlert(id: Int) {
        dao.deleteAlert(AlertEntity(id = id, symbol = "", targetPrice = 0.0))
        AudioSynthesizer.playTick()
    }
}
