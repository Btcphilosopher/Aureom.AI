package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberGold = Color(0xFFD4AF37)
val CyberCyan = Color(0xFF00E5FF)
val CyberPink = Color(0xFFFF2E93)
val BackgroundBlack = Color(0xFF050505)
val SurfaceGray = Color(0xFF0C0C0D)
val GridGlow = Color(0xFF14171C)
val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF1744)
val TonalGlass = Color(0x660F1115)
