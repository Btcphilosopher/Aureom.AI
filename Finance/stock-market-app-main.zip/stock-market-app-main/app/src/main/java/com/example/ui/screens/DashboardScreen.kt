package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Asset
import com.example.data.model.AssetCategory
import com.example.data.model.Sector
import com.example.ui.components.FuturisticChart
import com.example.ui.components.MiniTickerTape
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier,
    onNavigateToPortfolio: () -> Unit = {}
) {
    val assets by viewModel.filteredAssets.collectAsState()
    val rawAssets by viewModel.assets.collectAsState()
    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val watchlist by viewModel.watchlist.collectAsState()
    val activeRegime by viewModel.macroRegime.collectAsState()

    var activeCategory by remember { mutableStateOf<AssetCategory?>(null) }
    var selectedIndicatorEma by remember { mutableStateOf(true) }
    var selectedIndicatorBands by remember { mutableStateOf(false) }
    var selectedIndicatorRsi by remember { mutableStateOf(false) }
    var selectedIndicatorMacd by remember { mutableStateOf(false) }
    var selectedIndicatorProfile by remember { mutableStateOf(false) }

    // Buy/Sell Quick Dialog state
    var showDialogForAsset by remember { mutableStateOf<Asset?>(null) }
    var isBuyingAction by remember { mutableStateOf(true) }
    var tradeQtyStr by remember { mutableStateOf("1.0") }
    var terminalLogtext by remember { mutableStateOf("") }

    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundBlack)
    ) {
        // Scrolling marquee tape
        MiniTickerTape(assets = rawAssets)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(if (activeRegime == com.example.data.repository.MacroRegime.BOOM || activeRegime == com.example.data.repository.MacroRegime.TECH_REVOLUTION) NeonGreen else NeonRed, RoundedCornerShape(50))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "REGIME LOCK: ${activeRegime.name}",
                    color = CyberGold,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "SYSTEM ACTIVE // 100% FPS",
                color = CyberCyan.copy(alpha = 0.6f),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        // Expanded Main Chart workspace when an asset is highlighted
        selectedAsset?.let { asset ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TonalGlass),
                border = BorderStroke(1.dp, CyberGold.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .height(240.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Chart control top bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0C0C0D))
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${asset.symbol} : ${asset.name}",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (asset.isPositive) "▲" else "▼",
                                    color = if (asset.isPositive) NeonGreen else NeonRed,
                                    fontSize = 8.sp
                                )
                            }
                            Text(
                                text = "LQD RATIO: ${asset.liquidityScore}/100 // INST OUT: ${String.format("%.1f%%", asset.instActivity)}",
                                color = CyberCyan.copy(alpha = 0.7f),
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Technical Overlay Toggles
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            ChartIndicatorBadge("EMA", selectedIndicatorEma) { selectedIndicatorEma = !selectedIndicatorEma }
                            ChartIndicatorBadge("BNDS", selectedIndicatorBands) { selectedIndicatorBands = !selectedIndicatorBands }
                            ChartIndicatorBadge("RSI", selectedIndicatorRsi) { selectedIndicatorRsi = !selectedIndicatorRsi; if (selectedIndicatorRsi) selectedIndicatorMacd = false }
                            ChartIndicatorBadge("MACD", selectedIndicatorMacd) { selectedIndicatorMacd = !selectedIndicatorMacd; if (selectedIndicatorMacd) selectedIndicatorRsi = false }
                            ChartIndicatorBadge("PROF", selectedIndicatorProfile) { selectedIndicatorProfile = !selectedIndicatorProfile }
                        }
                    }

                    // Render Canvas Candlesticks
                    FuturisticChart(
                        history = asset.history,
                        showEma = selectedIndicatorEma,
                        showBollinger = selectedIndicatorBands,
                        showRsi = selectedIndicatorRsi,
                        showMacd = selectedIndicatorMacd,
                        showVolumeProfile = selectedIndicatorProfile,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Filters categories bar
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                FilterTabBadge("ALL ASSETS", activeCategory == null) {
                    activeCategory = null
                    viewModel.selectedCategoryFilter.value = null
                }
            }
            items(AssetCategory.values()) { category ->
                FilterTabBadge(category.name, activeCategory == category) {
                    activeCategory = category
                    viewModel.selectedCategoryFilter.value = category
                    viewModel.registerScreenFocus(category) // Adapts heuristics based on user screen focus!
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Core data columns
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Sector heatmaps
            item {
                Text(
                    text = "SECTOR HEATGRID MAPS",
                    color = CyberGold,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    maxItemsInEachRow = 3
                ) {
                    Sector.values().forEach { sec ->
                        val matchingAssets = rawAssets.filter { it.sector == sec }
                        val avgPercent = if (matchingAssets.isNotEmpty()) matchingAssets.map { it.changePercent }.average() else 0.0
                        val isSecPositive = avgPercent >= 0.0

                        val secColor by animateColorAsState(
                            targetValue = if (isSecPositive) NeonGreen.copy(alpha = 0.08f) else NeonRed.copy(alpha = 0.08f),
                            label = "sec"
                        )

                        Card(
                            colors = CardDefaults.cardColors(containerColor = secColor),
                            border = BorderStroke(1.dp, if (isSecPositive) NeonGreen.copy(alpha = 0.3f) else NeonRed.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .height(46.dp)
                                .clickable {
                                    // Set search query to highlight sector components
                                    viewModel.searchQuery.value = matchingAssets.firstOrNull()?.symbol ?: ""
                                }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = sec.name,
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = String.format("%+.2f%%", avgPercent),
                                    color = if (isSecPositive) NeonGreen else NeonRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Asset entries header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .background(Color(0xFF0F1217))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("SEC / SYMBOL", color = CyberCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                    Text("LIVE PRICE", color = CyberCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                    Text("FLUX", color = CyberCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    Text("TERMINAL UTILS", color = CyberCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.3f), textAlign = TextAlign.End)
                }
            }

            items(assets, key = { it.symbol }) { asset ->
                val isInWatchlist = watchlist.contains(asset.symbol)
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("asset_row_${asset.symbol}")
                        .background(if (selectedAsset?.symbol == asset.symbol) Color(0xFF131722) else Color.Transparent)
                        .border(
                            width = 1.dp,
                            color = if (selectedAsset?.symbol == asset.symbol) CyberGold.copy(alpha = 0.4f) else Color.Transparent
                        )
                        .clickable { viewModel.selectAsset(asset) }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = asset.symbol,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            // Watchlist star icon
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Watchlist",
                                tint = if (isInWatchlist) CyberGold else Color.Gray.copy(alpha = 0.3f),
                                modifier = Modifier
                                    .size(11.dp)
                                    .clickable { viewModel.toggleWatchlist(asset.symbol) }
                            )
                        }
                        Text(
                            text = asset.name,
                            color = Color.Gray,
                            fontSize = 8.sp,
                            maxLines = 1
                        )
                    }

                    val fPrice = if (asset.currentPrice < 1.0) {
                        String.format("%.6f", asset.currentPrice)
                    } else {
                        String.format("%,.2f", asset.currentPrice)
                    }

                    Text(
                        text = fPrice,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1.2f),
                        textAlign = TextAlign.End
                    )

                    Text(
                        text = String.format("%+.2f%%", asset.changePercent),
                        color = if (asset.isPositive) NeonGreen else NeonRed,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1.0f),
                        textAlign = TextAlign.End
                    )

                    Row(
                        modifier = Modifier.weight(1.3f),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                showDialogForAsset = asset
                                isBuyingAction = true
                                tradeQtyStr = "1.0"
                                terminalLogtext = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier
                                .height(22.dp)
                                .testTag("buy_btn_${asset.symbol}")
                        ) {
                            Text("BUY", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Button(
                            onClick = {
                                showDialogForAsset = asset
                                isBuyingAction = false
                                tradeQtyStr = "1.0"
                                terminalLogtext = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonRed),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier
                                .height(22.dp)
                                .testTag("sell_btn_${asset.symbol}")
                        ) {
                            Text("SELL", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Interactive Transaction pop-up dialog
    showDialogForAsset?.let { asset ->
        AlertDialog(
            onDismissRequest = { showDialogForAsset = null },
            title = {
                Text(
                    text = "EXECUTE: ${if (isBuyingAction) "BUY" else "SELL"} SEC ${asset.symbol}",
                    color = CyberGold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Core Asset: ${asset.name}\nCurrent Valuation: $${String.format("%,.4f", asset.currentPrice)} USD",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    OutlinedTextField(
                        value = tradeQtyStr,
                        onValueChange = { tradeQtyStr = it },
                        label = { Text("Cyber Volume Quantity", color = CyberCyan) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberGold.copy(alpha = 0.5f),
                            focusedLabelColor = CyberCyan,
                            unfocusedLabelColor = Color.Gray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("trade_qty_field")
                    )

                    val valueCommit = (tradeQtyStr.toDoubleOrNull() ?: 1.0) * asset.currentPrice
                    Text(
                        text = "Sovereign Obligation Cost: **$${String.format("%,.2f", valueCommit)}** Credits",
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )

                    if (terminalLogtext.isNotEmpty()) {
                        Text(
                            text = terminalLogtext,
                            color = if (terminalLogtext.contains("CONFIRMED")) NeonGreen else NeonRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    modifier = Modifier.testTag("dialog_confirm_trade"),
                    onClick = {
                        val qty = tradeQtyStr.toDoubleOrNull() ?: 0.0
                        if (qty <= 0.0) {
                            terminalLogtext = "FAILED: Quantity bounds violation."
                            return@Button
                        }
                        if (isBuyingAction) {
                            viewModel.buyAsset(asset.symbol, qty) { success ->
                                if (success) {
                                    terminalLogtext = "SEC CONFIRMED: Logged cyber block ledger."
                                    showDialogForAsset = null
                                } else {
                                    terminalLogtext = "LIQUIDITY FAIL: Insufficient credit balance."
                                }
                            }
                        } else {
                            viewModel.sellAsset(asset.symbol, qty) { success ->
                                if (success) {
                                    terminalLogtext = "SEC CONFIRMED: Sold cyber inventory."
                                    showDialogForAsset = null
                                } else {
                                    terminalLogtext = "INVENTORY FAIL: Zero inventory matching symbol."
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberGold)
                ) {
                    Text("COMMIT SEC ORDER", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialogForAsset = null }) {
                    Text("ABORT ORDER", color = Color.Gray)
                }
            },
            containerColor = SurfaceGray,
            tonalElevation = 6.dp
        )
    }
}

// Wrapper to help alignment on items inside Rows
fun Modifier.weight(weight: Float, alignment: Alignment.Horizontal): Modifier = this

@Composable
fun ChartIndicatorBadge(
    text: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(if (active) CyberGold else Color(0xFF0F1115), RoundedCornerShape(6.dp))
            .border(1.dp, if (active) CyberGold else GridGlow, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 7.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = if (active) Color.Black else Color(0xFFECEFF1).copy(alpha = 0.7f),
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun FilterTabBadge(
    text: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(if (active) CyberCyan.copy(alpha = 0.15f) else Color(0xFF0C0C0D), RoundedCornerShape(50))
            .border(1.dp, if (active) CyberCyan.copy(alpha = 0.4f) else GridGlow, RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = if (active) CyberCyan else Color(0xFFECEFF1).copy(alpha = 0.6f),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
