package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.HoldingEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketViewModel

@Composable
fun PortfolioScreen(
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    val profileState by viewModel.profile.collectAsState()
    val holdingsList by viewModel.holdings.collectAsState()
    val liveAssets by viewModel.assets.collectAsState()
    val metrics by viewModel.portfolioMetrics.collectAsState()

    // Dialog state for fast transaction adjustments directly on portfolio screen
    var showQuickAdjustHolding by remember { mutableStateOf<HoldingEntity?>(null) }
    var adjustQtyStr by remember { mutableStateOf("1.0") }
    var isBuyingActionInPortfolio by remember { mutableStateOf(false) }
    var terminalStatusLog by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Master credit balance header
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = "PORTFOLIO LAB OPERATIONS COMMAND",
                color = CyberGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            
            Text(
                text = "NET ASSET VALUE LIQUID LIMITS",
                color = Color.Gray,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )

            Text(
                text = "$${String.format("%,.2f", metrics.totalWorth)} CC",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.testTag("portfolio_net_worth")
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIQUID CASH: $${String.format("%,.2f", metrics.cash)} CC",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "SECURITIES VALUE: $${String.format("%,.2f", metrics.holdingsValue)} CC",
                    color = CyberGold.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Risk indices (Beta and Sharpe)
        Card(
            colors = CardDefaults.cardColors(containerColor = TonalGlass),
            border = BorderStroke(1.dp, GridGlow),
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Beta coefficient
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("PORTFOLIO BETA", color = Color.Gray, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = String.format("%.2f", metrics.beta),
                        color = if (metrics.beta > 1.5) NeonRed else if (metrics.beta < 0.5) CyberCyan else CyberGold,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (metrics.beta > 1.5) "SPECULATIVE" else if (metrics.beta < 0.5) "DEFENSIVE" else "BALANCED",
                        color = Color.Gray,
                        fontSize = 7.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Divider(
                    color = GridGlow,
                    modifier = Modifier
                        .height(40.dp)
                        .width(1.dp)
                        .align(Alignment.CenterVertically)
                )

                // Sharpe quotient efficiency
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SHARPE COEFFICIENT", color = Color.Gray, fontSize = 7.5.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = String.format("%.2f", metrics.sharpeRatio),
                        color = if (metrics.sharpeRatio >= 1.5) NeonGreen else CyberGold,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (metrics.sharpeRatio >= 1.5) "OPTIMIZED" else "SUB-OPTIMAL",
                        color = Color.Gray,
                        fontSize = 7.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Active inventory stocks list
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "HELD SEC SECURITY INVENTORIES",
                color = CyberGold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            if (holdingsList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GridGlow)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ZERO ACTIVE SECURITIES LOGGED IN SQLITE LEDGER.", color = Color.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Initiate BUY orders inside Dashboard mode to acquire inventories.", color = CyberCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            } else {
                holdingsList.forEach { holding ->
                    val assetPrice = liveAssets.firstOrNull { it.symbol == holding.symbol }?.currentPrice ?: holding.avgPurchasePrice
                    val totalVal = assetPrice * holding.quantity
                    val totalCost = holding.avgPurchasePrice * holding.quantity
                    val profitLoss = totalVal - totalCost
                    val pPercent = if (totalCost > 0) (profitLoss / totalCost) * 100.0 else 0.0

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, GridGlow)
                            .testTag("portfolio_row_${holding.symbol}")
                            .background(Color(0xFF07090C))
                            .clickable {
                                showQuickAdjustHolding = holding
                                adjustQtyStr = "1.0"
                                terminalStatusLog = ""
                            }
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = holding.symbol,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = holding.sector,
                                    color = CyberCyan,
                                    fontSize = 7.5.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "Qty: ${holding.quantity} // Avg: $${String.format("%.2f", holding.avgPurchasePrice)}",
                                color = Color.Gray,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "$${String.format("%,.2f", totalVal)}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = String.format("%+.2f%%", pPercent),
                                color = if (profitLoss >= 0) NeonGreen else NeonRed,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Dynamic Sector Weights Distribution Visualizer
        if (metrics.exposures.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "SECTOR VALUE EXPOSURE ALLOCATIONS",
                    color = CyberGold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = TonalGlass),
                    border = BorderStroke(1.dp, GridGlow),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        metrics.exposures.forEach { exp ->
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "${exp.symbol} [${exp.sectorName}]", color = Color.White, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                    Text(text = String.format("%.1f%%", exp.percent), color = CyberCyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(1.dp))
                                        .background(Color.Gray.copy(alpha = 0.15f))
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .fillMaxWidth((exp.percent / 100f).toFloat().coerceIn(0f, 1f))
                                            .background(CyberCyan)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Direct Adjusted order drawer dialog
    showQuickAdjustHolding?.let { item ->
        AlertDialog(
            onDismissRequest = { showQuickAdjustHolding = null },
            title = {
                Text(
                    text = "INVENTORY ADJUSTMENT: ${item.symbol}",
                    color = CyberGold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Current On-Hand Balance:", color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("${item.quantity} Units", color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    OutlinedTextField(
                        value = adjustQtyStr,
                        onValueChange = { adjustQtyStr = it },
                        label = { Text("Cyber Volume Quantity", color = CyberCyan) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberGold.copy(alpha = 0.5f),
                            focusedLabelColor = CyberCyan,
                            unfocusedTextColor = Color.White,
                            focusedTextColor = Color.White
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("adjust_qty_field")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { isBuyingActionInPortfolio = true },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isBuyingActionInPortfolio) NeonGreen else Color.Gray.copy(alpha = 0.3f)),
                            modifier = Modifier.weight(1f).height(32.dp),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text("BUY MODE", color = if (isBuyingActionInPortfolio) Color.Black else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { isBuyingActionInPortfolio = false },
                            colors = ButtonDefaults.buttonColors(containerColor = if (!isBuyingActionInPortfolio) NeonRed else Color.Gray.copy(alpha = 0.3f)),
                            modifier = Modifier.weight(1f).height(32.dp),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text("SELL MODE", color = if (!isBuyingActionInPortfolio) Color.Black else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (terminalStatusLog.isNotEmpty()) {
                        Text(
                            text = terminalStatusLog,
                            color = if (terminalStatusLog.contains("CONFIRMED")) NeonGreen else NeonRed,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    modifier = Modifier.testTag("portfolio_modal_confirm"),
                    onClick = {
                        val qty = adjustQtyStr.toDoubleOrNull() ?: 0.0
                        if (qty <= 0.0) {
                            terminalStatusLog = "FAILED: Quantity bounds violation."
                            return@Button
                        }
                        if (isBuyingActionInPortfolio) {
                            viewModel.buyAsset(item.symbol, qty) { success ->
                                if (success) {
                                    terminalStatusLog = "SEC CONFIRMED: Logged cyber block ledger."
                                    showQuickAdjustHolding = null
                                } else {
                                    terminalStatusLog = "LIQUIDITY FAIL: Insufficient credit balance."
                                }
                            }
                        } else {
                            viewModel.sellAsset(item.symbol, qty) { success ->
                                if (success) {
                                    terminalStatusLog = "SEC CONFIRMED: Sold cyber inventory."
                                    showQuickAdjustHolding = null
                                } else {
                                    terminalStatusLog = "INVENTORY FAIL: Sell bounds exceed hand holdings."
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberGold)
                ) {
                    Text("EXECUTE ADJUSTMENT", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickAdjustHolding = null }) {
                    Text("ABORT ADJUSTMENT", color = Color.Gray)
                }
            },
            containerColor = SurfaceGray,
            tonalElevation = 6.dp
        )
    }
}
