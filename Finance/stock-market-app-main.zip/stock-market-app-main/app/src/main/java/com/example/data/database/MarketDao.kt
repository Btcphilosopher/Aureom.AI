package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MarketDao {

    // --- Profile Operations ---
    @Query("SELECT * FROM profile_table WHERE id = 0")
    fun getProfileFlow(): Flow<ProfileEntity?>

    @Query("SELECT * FROM profile_table WHERE id = 0")
    suspend fun getProfileDirect(): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: ProfileEntity)

    // --- Asset Holdings ---
    @Query("SELECT * FROM holdings_table")
    fun getHoldingsFlow(): Flow<List<HoldingEntity>>

    @Query("SELECT * FROM holdings_table WHERE symbol = :symbol")
    suspend fun getHoldingDirect(symbol: String): HoldingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHolding(holding: HoldingEntity)

    @Delete
    suspend fun deleteHolding(holding: HoldingEntity)

    @Query("DELETE FROM holdings_table WHERE symbol = :symbol")
    suspend fun deleteHoldingBySymbol(symbol: String)

    // --- Watchlist ---
    @Query("SELECT * FROM watchlist_table")
    fun getWatchlistFlow(): Flow<List<WatchlistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToWatchlist(item: WatchlistEntity)

    @Delete
    suspend fun removeFromWatchlist(item: WatchlistEntity)

    @Query("SELECT EXISTS(SELECT 1 FROM watchlist_table WHERE symbol = :symbol)")
    suspend fun isInWatchlist(symbol: String): Boolean

    // --- Alerts ---
    @Query("SELECT * FROM alerts_table ORDER BY id DESC")
    fun getAlertsFlow(): Flow<List<AlertEntity>>

    @Query("SELECT * FROM alerts_table WHERE isTriggered = 0")
    suspend fun getActiveAlertsDirect(): List<AlertEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: AlertEntity)

    @Query("UPDATE alerts_table SET isTriggered = 1 WHERE id = :alertId")
    suspend fun markAlertTriggered(alertId: Int)

    @Delete
    suspend fun deleteAlert(alert: AlertEntity)

    // --- Transactions ---
    @Query("SELECT * FROM transaction_table ORDER BY timestamp DESC LIMIT 100")
    fun getTransactionsFlow(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)
}
