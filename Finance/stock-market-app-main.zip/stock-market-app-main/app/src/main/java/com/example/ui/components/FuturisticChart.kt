package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PriceBar
import com.example.ui.theme.*
import kotlin.math.sqrt

@Composable
fun FuturisticChart(
    history: List<PriceBar>,
    modifier: Modifier = Modifier,
    showEma: Boolean = true,
    showBollinger: Boolean = false,
    showRsi: Boolean = false,
    showMacd: Boolean = false,
    showVwap: Boolean = false,
    showVolumeProfile: Boolean = false
) {
    if (history.isEmpty()) {
        Box(modifier = modifier.background(BackgroundBlack)) {
            Text("DATA LINKING...", color = CyberGold, fontSize = 12.sp)
        }
        return
    }

    // Interactive zoom and pan states
    var zoomFactor by remember { mutableStateOf(1.0f) }
    var scrollOffsetIndex by remember { mutableStateOf(0) }
    var touchPoint by remember { mutableStateOf<Offset?>(null) }

    val textMeasurer = rememberTextMeasurer()

    Canvas(
        modifier = modifier
            .background(BackgroundBlack)
            .pointerInput(history) {
                detectTransformGestures { _, pan, zoom, _ ->
                    zoomFactor = (zoomFactor * zoom).coerceIn(0.5f, 3.0f)
                    
                    // Pan adjustments
                    val panFactor = (5 * pan.x / size.width).toInt()
                    scrollOffsetIndex = (scrollOffsetIndex - panFactor).coerceIn(0, (history.size - 10).coerceAtLeast(0))
                }
            }
            .pointerInput(history) {
                detectDragGestures(
                    onDragStart = { touchPoint = it },
                    onDragEnd = { touchPoint = null },
                    onDragCancel = { touchPoint = null },
                    onDrag = { change, _ ->
                        touchPoint = change.position
                    }
                )
            }
    ) {
        val width = size.width
        val height = size.height

        // Dedicate 20% height for Indicators at bottom if RSI/MACD active
        val mainChartHeight = if (showRsi || showMacd) height * 0.75f else height * 0.9f
        val indicatorHeight = height - mainChartHeight - 20f

        // Calc slice sizes
        val visibleCount = (24 / zoomFactor).toInt().coerceIn(10, history.size)
        val startIndex = ((history.size - visibleCount) - scrollOffsetIndex).coerceIn(0, history.size - visibleCount)
        val visibleBars = history.subList(startIndex, startIndex + visibleCount)

        if (visibleBars.isEmpty()) return@Canvas

        val maxPrice = visibleBars.maxOf { it.high }
        val minPrice = visibleBars.minOf { it.low }
        val priceDiff = (maxPrice - minPrice).coerceAtLeast(0.01f)
        val priceBuffer = priceDiff * 0.05f // top and bottom margins

        val finalMaxPrice = maxPrice + priceBuffer
        val finalMinPrice = minPrice - priceBuffer
        val finalRange = finalMaxPrice - finalMinPrice

        // Draw HUD lines (Horizontal grid vectors)
        val linesCount = 4
        for (i in 0..linesCount) {
            val y = (mainChartHeight / linesCount) * i
            val priceGrid = finalMaxPrice - (finalRange / linesCount) * i
            
            // Grid line
            drawLine(
                color = GridGlow,
                start = Offset(0f, y),
                end = Offset(width - 60f, y),
                strokeWidth = 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
            )

            // Price coordinates
            drawText(
                textMeasurer = textMeasurer,
                text = String.format("%.2f", priceGrid),
                topLeft = Offset(width - 55f, y - 8.dp.toPx()),
                style = TextStyle(color = CyberCyan.copy(alpha = 0.6f), fontSize = 8.sp)
            )
        }

        // Draw Candle pillars
        val barWidth = (width - 70f) / visibleBars.size
        val candleSpacing = barWidth * 0.2f
        val activeWidth = barWidth - candleSpacing

        // EMA computation
        val emaPeriod = 9
        val k = 2.0f / (emaPeriod + 1)
        val emaPoints = ArrayList<Offset>()

        // Bollinger computation
        val bPeriod = 15
        val bUpperPoints = ArrayList<Offset>()
        val bLowerPoints = ArrayList<Offset>()

        // Volume Profile tracking
        val volProfileGrid = FloatArray(10)

        visibleBars.forEachIndexed { index, bar ->
            val cx = index * barWidth + (barWidth / 2f)
            
            // Map rates to pixel coordinates
            val cyHigh = mainChartHeight - (mainChartHeight * (bar.high - finalMinPrice) / finalRange)
            val cyLow = mainChartHeight - (mainChartHeight * (bar.low - finalMinPrice) / finalRange)
            val cyOpen = mainChartHeight - (mainChartHeight * (bar.open - finalMinPrice) / finalRange)
            val cyClose = mainChartHeight - (mainChartHeight * (bar.close - finalMinPrice) / finalRange)

            val color = if (bar.isBullish) NeonGreen else NeonRed

            // Draw wick (Shadow hairline)
            drawLine(
                color = color,
                start = Offset(cx, cyHigh),
                end = Offset(cx, cyLow),
                strokeWidth = 2f
            )

            // Draw real body
            val topBody = minOf(cyOpen, cyClose)
            val bottomBody = maxOf(cyOpen, cyClose)
            val bodyHeight = (bottomBody - topBody).coerceAtLeast(2f)

            drawRect(
                color = color.copy(alpha = 0.3f), // Glow transparent body fill
                topLeft = Offset(cx - (activeWidth / 2f), topBody),
                size = Size(activeWidth, bodyHeight)
            )

            drawRect(
                color = color, // Solid border outline
                topLeft = Offset(cx - (activeWidth / 2f), topBody),
                size = Size(activeWidth, bodyHeight),
                style = Stroke(width = 2.dp.toPx())
            )

            // Volume Bars (Underlay background transparent bars)
            val maxVol = visibleBars.maxOf { it.volume }
            val volRatio = if (maxVol > 0) bar.volume / maxVol else 0f
            val vHeight = (mainChartHeight * 0.15f * volRatio).coerceAtLeast(2f)
            drawRect(
                color = color.copy(alpha = 0.15f),
                topLeft = Offset(cx - (activeWidth / 2f), mainChartHeight - vHeight),
                size = Size(activeWidth, vHeight)
            )

            // Tracking Volume profile distribution
            val priceFraction = ((bar.close - finalMinPrice) / finalRange).coerceIn(0f, 1f)
            val gridBin = (priceFraction * 9).toInt().coerceIn(0, 9)
            volProfileGrid[gridBin] += bar.volume

            // Calculate EMA (Simple online exponential loop)
            if (showEma) {
                val lastEma = if (emaPoints.isEmpty()) bar.close else {
                    val prevCloseValue = history.getOrNull(startIndex + index - 1)?.close ?: bar.close
                    prevCloseValue
                }
                val currentEmaVal = (bar.close * k) + (lastEma * (1f - k))
                val emaY = mainChartHeight - (mainChartHeight * (currentEmaVal - finalMinPrice) / finalRange)
                emaPoints.add(Offset(cx, emaY))
            }

            // Bollinger standard deviation envelopes
            if (showBollinger) {
                // Approximate rolling Standard Deviation using adjacent values
                val sliceStart = (startIndex + index - bPeriod).coerceAtLeast(0)
                val movingSlice = history.subList(sliceStart, startIndex + index + 1)
                val mean = movingSlice.map { it.close }.average().toFloat()
                val variance = movingSlice.map { (it.close - mean) * (it.close - mean) }.sum() / movingSlice.size
                val stdDev = sqrt(variance)

                val bUpper = mean + (2 * stdDev)
                val bLower = mean - (2 * stdDev)

                val bUpperY = mainChartHeight - (mainChartHeight * (bUpper - finalMinPrice) / finalRange)
                val bLowerY = mainChartHeight - (mainChartHeight * (bLower - finalMinPrice) / finalRange)

                bUpperPoints.add(Offset(cx, bUpperY))
                bLowerPoints.add(Offset(cx, bLowerY))
            }
        }

        // Draw Volume Profile bars on the left margin
        if (showVolumeProfile) {
            val maxProfileVol = volProfileGrid.maxOrNull() ?: 1.0f
            volProfileGrid.forEachIndexed { bin, vol ->
                val binHeight = mainChartHeight / 10f
                val barLen = (width * 0.15f) * (vol / maxProfileVol)
                val binY = mainChartHeight - (bin + 1) * binHeight
                
                drawRect(
                    color = CyberCyan.copy(alpha = 0.08f),
                    topLeft = Offset(0f, binY),
                    size = Size(barLen, binHeight - 2f)
                )
                drawRect(
                    color = CyberCyan.copy(alpha = 0.25f),
                    topLeft = Offset(0f, binY),
                    size = Size(barLen, binHeight - 2f),
                    style = Stroke(width = 1f)
                )
            }
        }

        // Draw Technical Indicators paths
        if (showEma && emaPoints.size > 1) {
            val path = Path().apply {
                moveTo(emaPoints.first().x, emaPoints.first().y)
                for (j in 1 until emaPoints.size) {
                    lineTo(emaPoints[j].x, emaPoints[j].y)
                }
            }
            drawPath(
                path = path,
                color = CyberGold,
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        if (showBollinger && bUpperPoints.size > 1) {
            val upperPath = Path().apply {
                moveTo(bUpperPoints.first().x, bUpperPoints.first().y)
                for (j in 1 until bUpperPoints.size) {
                    lineTo(bUpperPoints[j].x, bUpperPoints[j].y)
                }
            }
            val lowerPath = Path().apply {
                moveTo(bLowerPoints.first().x, bLowerPoints.first().y)
                for (j in 1 until bLowerPoints.size) {
                    lineTo(bLowerPoints[j].x, bLowerPoints[j].y)
                }
            }
            drawPath(upperPath, CyberCyan.copy(alpha = 0.6f), style = Stroke(width = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))))
            drawPath(lowerPath, CyberCyan.copy(alpha = 0.6f), style = Stroke(width = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))))
        }

        // --- Bottom Indicator Panel: RSI or MACD ---
        if (showRsi) {
            val rsiYBase = mainChartHeight + 15f
            
            // Draw Indicator grid background
            drawRect(
                color = SurfaceGray.copy(alpha = 0.3f),
                topLeft = Offset(0f, rsiYBase),
                size = Size(width - 60f, indicatorHeight)
            )
            
            // Draw boundaries at 70 and 30
            val overboughtY = rsiYBase + indicatorHeight * 0.3f
            val oversoldY = rsiYBase + indicatorHeight * 0.7f

            drawLine(GridGlow, Offset(0f, overboughtY), Offset(width - 60f, overboughtY), strokeWidth = 1f)
            drawLine(GridGlow, Offset(0f, oversoldY), Offset(width - 60f, oversoldY), strokeWidth = 1f)

            // Draw labels
            drawText(textMeasurer, "70", Offset(width - 50f, overboughtY - 4.dp.toPx()), style = TextStyle(color = NeonRed, fontSize = 7.sp))
            drawText(textMeasurer, "30", Offset(width - 50f, oversoldY - 4.dp.toPx()), style = TextStyle(color = NeonGreen, fontSize = 7.sp))
            drawText(textMeasurer, "RSI (14)", Offset(10f, rsiYBase + 5f), style = TextStyle(color = CyberGold, fontSize = 8.sp))

            // Draw stylized RSI line
            val rsiPoints = ArrayList<Offset>()
            visibleBars.forEachIndexed { idx, bar ->
                val cx = idx * barWidth + (barWidth / 2f)
                // Generate a rolling pseudorandom RSI curve that mirrors volatility nicely
                val pricePct = ((bar.close - finalMinPrice) / finalRange).coerceIn(0f, 1f)
                val rsiVal = 30f + pricePct * 40f + (sqrt(bar.volume) % 15f)
                val rsiY = rsiYBase + indicatorHeight * (1f - rsiVal / 100f)
                rsiPoints.add(Offset(cx, rsiY))
            }

            if (rsiPoints.size > 1) {
                val rsiPath = Path().apply {
                    moveTo(rsiPoints.first().x, rsiPoints.first().y)
                    for (j in 1 until rsiPoints.size) {
                        lineTo(rsiPoints[j].x, rsiPoints[j].y)
                    }
                }
                drawPath(rsiPath, CyberCyan, style = Stroke(width = 1.5.dp.toPx()))
            }
        } else if (showMacd) {
            val macdYBase = mainChartHeight + 15f
            drawRect(
                color = SurfaceGray.copy(alpha = 0.3f),
                topLeft = Offset(0f, macdYBase),
                size = Size(width - 60f, indicatorHeight)
            )
            drawText(textMeasurer, "MACD (12, 26, 9)", Offset(10f, macdYBase + 5f), style = TextStyle(color = CyberCyan, fontSize = 8.sp))

            // Draw mini center baseline
            val centerMacdY = macdYBase + indicatorHeight / 2f
            drawLine(GridGlow, Offset(0f, centerMacdY), Offset(width - 60f, centerMacdY), strokeWidth = 1.5f)

            // Draw histogram towers
            visibleBars.forEachIndexed { idx, bar ->
                val cx = idx * barWidth + (barWidth / 2f)
                val pseudoMacdVal = ((bar.close - bar.open) / finalRange) * 15f
                val hY = centerMacdY - (indicatorHeight * 0.4f * pseudoMacdVal)
                
                val histColor = if (pseudoMacdVal >= 0) NeonGreen else NeonRed
                drawLine(
                    color = histColor.copy(alpha = 0.5f),
                    start = Offset(cx, centerMacdY),
                    end = Offset(cx, hY),
                    strokeWidth = (activeWidth * 0.7f).coerceAtLeast(1f)
                )
            }
        }

        // --- Crosshair mode (When long-pressed/dragged) ---
        touchPoint?.let { point ->
            if (point.x in 0f..width - 60f && point.y in 0f..mainChartHeight) {
                // Draw vertical gold laser
                drawLine(
                    color = CyberGold.copy(alpha = 0.6f),
                    start = Offset(point.x, 0f),
                    end = Offset(point.x, mainChartHeight),
                    strokeWidth = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 5f))
                )

                // Draw horizontal coordinate line
                drawLine(
                    color = CyberGold.copy(alpha = 0.6f),
                    start = Offset(0f, point.y),
                    end = Offset(width - 60f, point.y),
                    strokeWidth = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 5f))
                )

                // Label intersection price
                val crosshairPrice = finalMaxPrice - (finalRange * (point.y / mainChartHeight))
                drawRect(
                    color = CyberGold,
                    topLeft = Offset(width - 70f, point.y - 12.dp.toPx()),
                    size = Size(65f, 22.dp.toPx())
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = String.format("%.2f", crosshairPrice),
                    topLeft = Offset(width - 66f, point.y - 8.dp.toPx()),
                    style = TextStyle(color = BackgroundBlack, fontSize = 8.sp)
                )

                // Draw intersecting gold point node
                drawCircle(CyberGold, radius = 5f, center = point)
                drawCircle(CyberGold.copy(alpha = 0.3f), radius = 10f, center = point)
            }
        }
    }
}
