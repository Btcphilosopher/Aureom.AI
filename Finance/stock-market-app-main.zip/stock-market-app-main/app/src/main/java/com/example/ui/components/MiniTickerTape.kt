package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Asset
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun MiniTickerTape(
    assets: List<Asset>,
    modifier: Modifier = Modifier
) {
    if (assets.isEmpty()) return

    val listState = rememberLazyListState()

    // Smooth continuous auto-scroll loop
    LaunchedEffect(key1 = assets) {
        while (true) {
            delay(30)
            try {
                listState.scrollBy(2.2f)
            } catch (e: Exception) {
                // Ignore layout drift interruptions
            }
            
            // Seamless wrap support
            val firstVisibleIndex = listState.firstVisibleItemIndex
            if (firstVisibleIndex >= assets.size * 5) {
                try {
                    listState.scrollToItem(0, 0)
                } catch (e: Exception) {}
            }
        }
    }

    // Tenfold repetitions of assets list produces seamless wrapping boundaries
    val loopedAssets = List(12) { assets }.flatten()

    LazyRow(
        state = listState,
        userScrollEnabled = false,
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .background(BackgroundBlack),
        contentPadding = PaddingValues(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items(loopedAssets) { asset ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = asset.symbol,
                    color = CyberGold,
                    fontSize = 10.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                )
                
                val displayRate = if (asset.currentPrice < 1.0) {
                    String.format("%.6f", asset.currentPrice)
                } else {
                    String.format("%,.2f", asset.currentPrice)
                }
                
                Text(
                    text = displayRate,
                    color = if (asset.isPositive) NeonGreen else NeonRed,
                    fontSize = 11.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                )

                Text(
                    text = if (asset.isPositive) "▲" else "▼",
                    color = if (asset.isPositive) NeonGreen else NeonRed,
                    fontSize = 8.sp
                )

                Text(
                    text = String.format("%.2f%%", asset.changePercent),
                    color = if (asset.isPositive) NeonGreen else NeonRed,
                    fontSize = 10.sp,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                )
            }
        }
    }
}
