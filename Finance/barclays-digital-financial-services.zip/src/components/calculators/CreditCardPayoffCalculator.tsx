import React, { useState, useId } from 'react';
import { CreditCard, AlertCircle, ArrowRight } from 'lucide-react';

export const CreditCardPayoffCalculator: React.FC = () => {
  const [balance, setBalance] = useState<number>(3000);
  const [interestRate, setInterestRate] = useState<number>(24.9);
  const [fixedPayment, setFixedPayment] = useState<number>(150);

  const balanceInputId = useId();
  const rateInputId = useId();
  const paymentInputId = useId();

  // Model comparison: Fixed payment vs Standard Minimum payment (e.g. 2.5% or £10 min)
  const monthlyRate = interestRate / 100 / 12;

  // 1. Fixed payment simulation
  let fixedMonths = 0;
  let fixedTotalInterest = 0;
  let remainingFixed = balance;
  const maxIterations = 360;

  if (fixedPayment > balance * monthlyRate) {
    while (remainingFixed > 0 && fixedMonths < maxIterations) {
      fixedMonths++;
      const interest = remainingFixed * monthlyRate;
      fixedTotalInterest += interest;
      remainingFixed = remainingFixed + interest - fixedPayment;
    }
  }

  // 2. Minimum payment simulation (approx 2.5% of balance + interest or £10 minimum)
  let minMonths = 0;
  let minTotalInterest = 0;
  let remainingMin = balance;
  while (remainingMin > 5 && minMonths < maxIterations) {
    minMonths++;
    const interest = remainingMin * monthlyRate;
    minTotalInterest += interest;
    const minPay = Math.max(10, remainingMin * 0.025 + interest);
    remainingMin = remainingMin + interest - minPay;
  }

  const interestSaved = Math.max(0, minTotalInterest - fixedTotalInterest);
  const monthsSaved = Math.max(0, minMonths - fixedMonths);

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
      <div className="bg-[#00395d] text-white p-6 sm:p-8">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#00aeef] uppercase tracking-wider mb-2">
          <CreditCard className="w-4 h-4" />
          <span>Barclaycard Repayment Strategy Model</span>
        </div>
        <h3 className="text-xl sm:text-2xl font-bold tracking-tight">
          Credit Card Payoff & Interest Reduction Tool
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
          Discover how much money and time you can save by paying a fixed monthly amount instead of only making the minimum payment.
        </p>
      </div>

      <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-6 space-y-5">
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor={balanceInputId} className="text-xs font-semibold text-slate-700">Current Credit Card Balance</label>
              <span className="text-sm font-bold text-slate-900 font-mono">
                £{balance.toLocaleString('en-GB')}
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">£</span>
              <input
                id={balanceInputId}
                type="number"
                min="100"
                max="25000"
                step="100"
                value={balance}
                onChange={(e) => setBalance(Math.max(100, Number(e.target.value)))}
                className="w-full pl-8 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
              />
            </div>
            <input
              type="range"
              min="200"
              max="15000"
              step="100"
              value={balance}
              onChange={(e) => setBalance(Number(e.target.value))}
              className="w-full mt-2 accent-[#00395d]"
              aria-label="Credit Card Balance Slider"
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor={rateInputId} className="text-xs font-semibold text-slate-700">Standard Interest Rate (% APR)</label>
              <span className="text-sm font-bold text-slate-900 font-mono">{interestRate}%</span>
            </div>
            <input
              id={rateInputId}
              type="number"
              min="5"
              max="45"
              step="0.5"
              value={interestRate}
              onChange={(e) => setInterestRate(Math.max(1, Number(e.target.value)))}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
            />
            <div className="flex gap-2 mt-2">
              <button
                type="button"
                onClick={() => setInterestRate(24.9)}
                className="text-[11px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700"
              >
                24.9% (Platinum)
              </button>
              <button
                type="button"
                onClick={() => setInterestRate(28.9)}
                className="text-[11px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700"
              >
                28.9% (Rewards)
              </button>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor={paymentInputId} className="text-xs font-semibold text-slate-700">Proposed Fixed Monthly Payment</label>
              <span className="text-sm font-bold text-slate-900 font-mono">
                £{fixedPayment.toLocaleString('en-GB')} / mo
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">£</span>
              <input
                id={paymentInputId}
                type="number"
                min="20"
                max="2000"
                step="10"
                value={fixedPayment}
                onChange={(e) => setFixedPayment(Math.max(20, Number(e.target.value)))}
                className="w-full pl-8 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
              />
            </div>
            <input
              type="range"
              min="30"
              max="800"
              step="10"
              value={fixedPayment}
              onChange={(e) => setFixedPayment(Number(e.target.value))}
              className="w-full mt-2 accent-[#00395d]"
              aria-label="Fixed Monthly Payment Slider"
            />
          </div>
        </div>

        {/* Results Comparison Grid */}
        <div className="lg:col-span-6 bg-[#f2f7fa] rounded-xl p-6 border border-slate-200/80 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Strategy Comparison
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Option 1: Minimum Only */}
              <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-xs">
                <div className="text-[11px] font-semibold text-slate-500">Only Minimum Payment</div>
                <div className="text-lg font-bold text-slate-900 mt-1 font-mono">
                  {minMonths >= maxIterations ? '25+ Years' : `${Math.floor(minMonths / 12)}y ${minMonths % 12}m`}
                </div>
                <div className="text-xs text-red-600 font-semibold mt-2 font-mono">
                  £{minTotalInterest.toFixed(0)} interest
                </div>
              </div>

              {/* Option 2: Fixed Payment */}
              <div className="bg-emerald-50/60 p-4 rounded-lg border border-emerald-200 shadow-xs">
                <div className="text-[11px] font-semibold text-emerald-800">Fixed £{fixedPayment}/mo</div>
                <div className="text-lg font-bold text-emerald-950 mt-1 font-mono">
                  {Math.floor(fixedMonths / 12)}y {fixedMonths % 12}m
                </div>
                <div className="text-xs text-emerald-700 font-semibold mt-2 font-mono">
                  £{fixedTotalInterest.toFixed(0)} interest
                </div>
              </div>
            </div>

            {/* Savings Highlight */}
            <div className="p-4 bg-white rounded-lg border border-slate-200">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 mb-1">
                <span>Total Potential Savings:</span>
              </div>
              <div className="text-2xl font-extrabold text-emerald-700 font-mono">
                £{interestSaved.toFixed(0)} saved in interest
              </div>
              <p className="text-xs text-slate-600 mt-1">
                By maintaining a fixed £{fixedPayment} payment, you clear the card{' '}
                <strong className="text-slate-900">{monthsSaved} months faster</strong>.
              </p>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200 text-[11px] text-slate-500 flex items-start gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
            <span>
              Assumes no additional spending on the card during the repayment period and an unchanged interest rate.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
