import React, { useState, useId } from 'react';
import { Home, Percent, Calendar, PoundSterling, Info, ChevronDown, ChevronUp } from 'lucide-react';

export const MortgageCalculator: React.FC = () => {
  const [propertyPrice, setPropertyPrice] = useState<number>(350000);
  const [deposit, setDeposit] = useState<number>(70000);
  const [termYears, setTermYears] = useState<number>(25);
  const [interestRate, setInterestRate] = useState<number>(4.49);
  const [repaymentType, setRepaymentType] = useState<'repayment' | 'interestOnly'>('repayment');
  const [showAmortization, setShowAmortization] = useState<boolean>(false);

  const priceInputId = useId();
  const depositInputId = useId();
  const termInputId = useId();
  const rateInputId = useId();

  // Financial Mathematics
  const loanAmount = Math.max(0, propertyPrice - deposit);
  const ltvRatio = propertyPrice > 0 ? ((loanAmount / propertyPrice) * 100).toFixed(1) : '0';

  const monthlyRate = interestRate / 100 / 12;
  const totalMonths = termYears * 12;

  let monthlyPayment = 0;
  let totalRepayment = 0;
  let totalInterest = 0;

  if (loanAmount > 0 && totalMonths > 0) {
    if (repaymentType === 'repayment') {
      if (monthlyRate === 0) {
        monthlyPayment = loanAmount / totalMonths;
      } else {
        monthlyPayment =
          (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, totalMonths))) /
          (Math.pow(1 + monthlyRate, totalMonths) - 1);
      }
      totalRepayment = monthlyPayment * totalMonths;
      totalInterest = totalRepayment - loanAmount;
    } else {
      // Interest-only
      monthlyPayment = loanAmount * monthlyRate;
      totalInterest = monthlyPayment * totalMonths;
      totalRepayment = totalInterest + loanAmount;
    }
  }

  // Generate Year-by-Year breakdown for first 5 years and 5-year milestones
  const amortizationSchedule = [];
  let remainingBalance = loanAmount;
  for (let year = 1; year <= termYears; year++) {
    let yearInterest = 0;
    let yearPrincipal = 0;
    for (let m = 0; m < 12; m++) {
      const interestForMonth = remainingBalance * monthlyRate;
      let principalForMonth = 0;
      if (repaymentType === 'repayment') {
        principalForMonth = monthlyPayment - interestForMonth;
        remainingBalance = Math.max(0, remainingBalance - principalForMonth);
      }
      yearInterest += interestForMonth;
      yearPrincipal += principalForMonth;
    }
    if (year <= 5 || year % 5 === 0 || year === termYears) {
      amortizationSchedule.push({
        year,
        annualPayment: (yearInterest + yearPrincipal).toFixed(0),
        interestPaid: yearInterest.toFixed(0),
        principalPaid: yearPrincipal.toFixed(0),
        remainingBalance: remainingBalance.toFixed(0),
      });
    }
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
      <div className="bg-[#00395d] text-white p-6 sm:p-8">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#00aeef] uppercase tracking-wider mb-2">
          <Home className="w-4 h-4" />
          <span>Barclays Mortgage Repayment Model</span>
        </div>
        <h3 className="text-xl sm:text-2xl font-bold tracking-tight">
          Mortgage Repayment Calculator
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
          Model your monthly repayments, loan-to-value (LTV) ratio, and total interest payable using standard UK mortgage amortization.
        </p>
      </div>

      <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Controls Column */}
        <div className="lg:col-span-7 space-y-6">
          {/* Property Price */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor={priceInputId} className="text-xs font-semibold text-slate-700">Property Price</label>
              <span className="text-sm font-bold text-slate-900 font-mono">
                £{propertyPrice.toLocaleString('en-GB')}
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">£</span>
              <input
                id={priceInputId}
                type="number"
                min="50000"
                max="3000000"
                step="5000"
                value={propertyPrice}
                onChange={(e) => setPropertyPrice(Math.max(0, Number(e.target.value)))}
                className="w-full pl-8 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
              />
            </div>
            <input
              type="range"
              min="50000"
              max="1500000"
              step="5000"
              value={propertyPrice}
              onChange={(e) => setPropertyPrice(Number(e.target.value))}
              className="w-full mt-2 accent-[#00395d]"
              aria-label="Property Price Slider"
            />
          </div>

          {/* Deposit */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor={depositInputId} className="text-xs font-semibold text-slate-700">Cash Deposit</label>
              <span className="text-sm font-bold text-slate-900 font-mono">
                £{deposit.toLocaleString('en-GB')} (
                {propertyPrice > 0 ? ((deposit / propertyPrice) * 100).toFixed(0) : 0}%)
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">£</span>
              <input
                id={depositInputId}
                type="number"
                min="5000"
                max={propertyPrice}
                step="2500"
                value={deposit}
                onChange={(e) => setDeposit(Math.min(propertyPrice, Math.max(0, Number(e.target.value))))}
                className="w-full pl-8 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
              />
            </div>
            <input
              type="range"
              min="5000"
              max={propertyPrice * 0.9}
              step="2500"
              value={deposit}
              onChange={(e) => setDeposit(Number(e.target.value))}
              className="w-full mt-2 accent-[#00395d]"
              aria-label="Deposit Slider"
            />
          </div>

          {/* Term & Interest Rate Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor={termInputId} className="text-xs font-semibold text-slate-700 block mb-1.5">
                Mortgage Term (Years)
              </label>
              <div className="relative">
                <input
                  id={termInputId}
                  type="number"
                  min="5"
                  max="40"
                  value={termYears}
                  onChange={(e) => setTermYears(Math.max(5, Math.min(40, Number(e.target.value))))}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-400">Years</span>
              </div>
              <input
                type="range"
                min="5"
                max="40"
                value={termYears}
                onChange={(e) => setTermYears(Number(e.target.value))}
                className="w-full mt-2 accent-[#00395d]"
                aria-label="Mortgage Term Slider"
              />
            </div>

            <div>
              <label htmlFor={rateInputId} className="text-xs font-semibold text-slate-700 block mb-1.5">
                Interest Rate (% AER)
              </label>
              <div className="relative">
                <input
                  id={rateInputId}
                  type="number"
                  min="0.5"
                  max="15"
                  step="0.05"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Math.max(0.1, Number(e.target.value)))}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-400">%</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="9.0"
                step="0.05"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="w-full mt-2 accent-[#00395d]"
                aria-label="Interest Rate Slider"
              />
            </div>
          </div>

          {/* Repayment Type Toggle */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-2">Repayment Strategy</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setRepaymentType('repayment')}
                className={`py-2 px-3 text-xs font-semibold rounded-lg border text-center transition-colors ${
                  repaymentType === 'repayment'
                    ? 'bg-[#00395d] text-white border-[#00395d] shadow-sm'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                Capital & Interest (Standard)
              </button>
              <button
                type="button"
                onClick={() => setRepaymentType('interestOnly')}
                className={`py-2 px-3 text-xs font-semibold rounded-lg border text-center transition-colors ${
                  repaymentType === 'interestOnly'
                    ? 'bg-[#00395d] text-white border-[#00395d] shadow-sm'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                Interest-Only
              </button>
            </div>
          </div>
        </div>

        {/* Results Column */}
        <div className="lg:col-span-5 bg-[#f2f7fa] rounded-xl p-6 border border-slate-200/80 flex flex-col justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Modelled Monthly Repayment
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-[#00395d] mt-2 font-mono">
              £{monthlyPayment.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              <span className="text-xs font-normal text-slate-500 ml-1">/ month</span>
            </div>

            {/* Metrics Breakdown */}
            <div className="mt-6 space-y-3 pt-6 border-t border-slate-200 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Borrowing Amount (Principal):</span>
                <span className="font-semibold text-slate-900 font-mono">
                  £{loanAmount.toLocaleString('en-GB')}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Loan-to-Value (LTV):</span>
                <span className="font-semibold text-slate-900 font-mono">{ltvRatio}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Total Interest Payable:</span>
                <span className="font-semibold text-slate-900 font-mono">
                  £{totalInterest.toLocaleString('en-GB', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Total Scheduled Repayment:</span>
                <span className="font-bold text-[#00395d] font-mono">
                  £{totalRepayment.toLocaleString('en-GB', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                </span>
              </div>
            </div>

            {repaymentType === 'interestOnly' && (
              <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-[11px] leading-tight">
                <strong>Important:</strong> With an interest-only mortgage, your monthly payments only cover the interest. You will still owe the full principal amount of £{loanAmount.toLocaleString('en-GB')} at the end of the term.
              </div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setShowAmortization(!showAmortization)}
              className="w-full flex items-center justify-between text-xs font-semibold text-[#00395d] hover:text-[#00aeef] transition-colors py-1"
            >
              <span>{showAmortization ? 'Hide' : 'Show'} Illustrative Amortization Schedule</span>
              {showAmortization ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Amortization Table */}
      {showAmortization && (
        <div className="border-t border-slate-200 bg-slate-50 p-6 overflow-x-auto">
          <div className="text-xs font-semibold text-slate-700 mb-3">
            Year-by-Year Capital & Interest Milestones
          </div>
          <table className="w-full text-left text-xs text-slate-600">
            <thead>
              <tr className="border-b border-slate-200 text-slate-800 font-semibold">
                <th className="py-2 pr-4">Year</th>
                <th className="py-2 pr-4">Annual Payment</th>
                <th className="py-2 pr-4">Principal Paid</th>
                <th className="py-2 pr-4">Interest Paid</th>
                <th className="py-2">Remaining Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200/70 font-mono">
              {amortizationSchedule.map((row) => (
                <tr key={row.year} className="hover:bg-white/80">
                  <td className="py-2 pr-4 font-sans font-semibold text-slate-900">Year {row.year}</td>
                  <td className="py-2 pr-4">£{Number(row.annualPayment).toLocaleString()}</td>
                  <td className="py-2 pr-4 text-emerald-700">£{Number(row.principalPaid).toLocaleString()}</td>
                  <td className="py-2 pr-4 text-slate-500">£{Number(row.interestPaid).toLocaleString()}</td>
                  <td className="py-2 font-semibold text-slate-900">
                    £{Number(row.remainingBalance).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Exclusions and Legal Note */}
      <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-start gap-2 text-[11px] text-slate-500">
        <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <span>
          This calculation provides an illustrative example based on monthly compounding. It does not constitute a mortgage offer, agreement in principle, or credit check. Actual rates depend on your credit history, property valuation, survey and product fees. Your home may be repossessed if you do not keep up repayments on your mortgage.
        </span>
      </div>
    </div>
  );
};
