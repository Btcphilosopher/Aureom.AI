import React, { useState, useId } from 'react';
import { PiggyBank, TrendingUp, Info } from 'lucide-react';

export const SavingsCalculator: React.FC = () => {
  const [initialDeposit, setInitialDeposit] = useState<number>(2500);
  const [monthlyContribution, setMonthlyContribution] = useState<number>(250);
  const [interestRate, setInterestRate] = useState<number>(5.12); // default Blue Rewards Rainy Day Saver rate
  const [durationYears, setDurationYears] = useState<number>(3);
  const [compoundFrequency, setCompoundFrequency] = useState<'monthly' | 'annually'>('monthly');

  const initialDepositId = useId();
  const monthlyContributionId = useId();
  const interestRateId = useId();
  const durationYearsId = useId();

  // Financial Mathematics
  const totalMonths = durationYears * 12;
  const monthlyRate = interestRate / 100 / 12;

  let currentBalance = initialDeposit;
  let totalDeposited = initialDeposit;

  for (let m = 1; m <= totalMonths; m++) {
    if (compoundFrequency === 'monthly') {
      currentBalance = (currentBalance + monthlyContribution) * (1 + monthlyRate);
    } else {
      // Annual compounding approximation
      currentBalance = currentBalance + monthlyContribution;
      if (m % 12 === 0) {
        currentBalance = currentBalance * (1 + interestRate / 100);
      }
    }
    totalDeposited += monthlyContribution;
  }

  const totalInterestEarned = Math.max(0, currentBalance - totalDeposited);

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
      <div className="bg-[#00395d] text-white p-6 sm:p-8">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#00aeef] uppercase tracking-wider mb-2">
          <PiggyBank className="w-4 h-4" />
          <span>Barclays Savings Growth Model</span>
        </div>
        <h3 className="text-xl sm:text-2xl font-bold tracking-tight">
          Savings Interest & Compound Growth Calculator
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
          See how regular deposits and compound interest accelerate your wealth over time.
        </p>
      </div>

      <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Controls Column */}
        <div className="lg:col-span-7 space-y-6">
          {/* Initial Deposit */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor={initialDepositId} className="text-xs font-semibold text-slate-700">Initial Lump Sum</label>
              <span className="text-sm font-bold text-slate-900 font-mono">
                £{initialDeposit.toLocaleString('en-GB')}
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">£</span>
              <input
                id={initialDepositId}
                type="number"
                min="0"
                max="250000"
                step="250"
                value={initialDeposit}
                onChange={(e) => setInitialDeposit(Math.max(0, Number(e.target.value)))}
                className="w-full pl-8 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
              />
            </div>
            <input
              type="range"
              min="0"
              max="50000"
              step="250"
              value={initialDeposit}
              onChange={(e) => setInitialDeposit(Number(e.target.value))}
              className="w-full mt-2 accent-[#00395d]"
              aria-label="Initial Lump Sum Slider"
            />
          </div>

          {/* Monthly Contribution */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor={monthlyContributionId} className="text-xs font-semibold text-slate-700">Monthly Deposit</label>
              <span className="text-sm font-bold text-slate-900 font-mono">
                £{monthlyContribution.toLocaleString('en-GB')} / month
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">£</span>
              <input
                id={monthlyContributionId}
                type="number"
                min="0"
                max="5000"
                step="50"
                value={monthlyContribution}
                onChange={(e) => setMonthlyContribution(Math.max(0, Number(e.target.value)))}
                className="w-full pl-8 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
              />
            </div>
            <input
              type="range"
              min="0"
              max="2000"
              step="25"
              value={monthlyContribution}
              onChange={(e) => setMonthlyContribution(Number(e.target.value))}
              className="w-full mt-2 accent-[#00395d]"
              aria-label="Monthly Deposit Slider"
            />
          </div>

          {/* Rate and Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor={interestRateId} className="text-xs font-semibold text-slate-700 block mb-1.5">
                Interest Rate (% AER)
              </label>
              <div className="relative">
                <input
                  id={interestRateId}
                  type="number"
                  min="0.1"
                  max="12"
                  step="0.05"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Math.max(0.01, Number(e.target.value)))}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-400">% AER</span>
              </div>
              <div className="flex gap-1.5 mt-2">
                <button
                  type="button"
                  onClick={() => setInterestRate(5.12)}
                  className="text-[11px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700"
                >
                  5.12% (Rainy Day)
                </button>
                <button
                  type="button"
                  onClick={() => setInterestRate(4.4)}
                  className="text-[11px] px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-700"
                >
                  4.40% (ISA)
                </button>
              </div>
            </div>

            <div>
              <label htmlFor={durationYearsId} className="text-xs font-semibold text-slate-700 block mb-1.5">
                Duration (Years)
              </label>
              <div className="relative">
                <input
                  id={durationYearsId}
                  type="number"
                  min="1"
                  max="30"
                  value={durationYears}
                  onChange={(e) => setDurationYears(Math.max(1, Math.min(30, Number(e.target.value))))}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-400">Years</span>
              </div>
              <input
                type="range"
                min="1"
                max="25"
                value={durationYears}
                onChange={(e) => setDurationYears(Number(e.target.value))}
                className="w-full mt-2 accent-[#00395d]"
                aria-label="Duration Slider"
              />
            </div>
          </div>

          {/* Compounding Frequency */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-2">Compounding Frequency</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setCompoundFrequency('monthly')}
                className={`py-2 px-3 text-xs font-semibold rounded-lg border text-center transition-colors ${
                  compoundFrequency === 'monthly'
                    ? 'bg-[#00395d] text-white border-[#00395d] shadow-sm'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                Monthly Compounding (Standard)
              </button>
              <button
                type="button"
                onClick={() => setCompoundFrequency('annually')}
                className={`py-2 px-3 text-xs font-semibold rounded-lg border text-center transition-colors ${
                  compoundFrequency === 'annually'
                    ? 'bg-[#00395d] text-white border-[#00395d] shadow-sm'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                Annual Compounding
              </button>
            </div>
          </div>
        </div>

        {/* Results Column */}
        <div className="lg:col-span-5 bg-[#f2f7fa] rounded-xl p-6 border border-slate-200/80 flex flex-col justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Projected Final Savings Balance
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-[#00395d] mt-2 font-mono">
              £{currentBalance.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>

            {/* Visual ratio bar */}
            <div className="mt-6">
              <div className="flex justify-between text-xs text-slate-500 mb-1.5">
                <span>Total Principal: {((totalDeposited / currentBalance) * 100).toFixed(0)}%</span>
                <span>Interest: {((totalInterestEarned / currentBalance) * 100).toFixed(0)}%</span>
              </div>
              <div className="h-3 w-full bg-slate-200 rounded-full overflow-hidden flex">
                <div
                  className="bg-[#00395d] h-full"
                  style={{ width: `${Math.min(100, (totalDeposited / currentBalance) * 100)}%` }}
                />
                <div
                  className="bg-[#00aeef] h-full"
                  style={{ width: `${Math.max(0, (totalInterestEarned / currentBalance) * 100)}%` }}
                />
              </div>
            </div>

            {/* Breakdown */}
            <div className="mt-6 space-y-3 pt-6 border-t border-slate-200 text-xs">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#00395d]" />
                  <span className="text-slate-600">Total Capital Contributed:</span>
                </div>
                <span className="font-semibold text-slate-900 font-mono">
                  £{totalDeposited.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#00aeef]" />
                  <span className="text-slate-600">Total Interest Earned:</span>
                </div>
                <span className="font-bold text-emerald-700 font-mono">
                  +£{totalInterestEarned.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                <span className="text-slate-600">Total Modelled Duration:</span>
                <span className="font-semibold text-slate-900">{durationYears} years ({totalMonths} months)</span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200 text-[11px] text-slate-500 flex items-start gap-2">
            <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <span>
              AER (Annual Equivalent Rate) illustrates what the interest rate would be if interest was paid and compounded each year. Tax treatment depends on individual circumstances and may be subject to future change.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
