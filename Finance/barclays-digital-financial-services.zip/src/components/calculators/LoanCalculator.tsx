import React, { useState, useId } from 'react';
import { Percent, Info, CheckCircle2 } from 'lucide-react';

export const LoanCalculator: React.FC = () => {
  const [loanAmount, setLoanAmount] = useState<number>(10000);
  const [termMonths, setTermMonths] = useState<number>(36);

  const loanAmountInputId = useId();

  // Tiered representative APR based on Barclays UK lending guidelines
  let representativeApr = 6.1;
  if (loanAmount < 7500) {
    representativeApr = 12.9;
  } else if (loanAmount <= 15000) {
    representativeApr = 6.1; // Marquee representative rate
  } else if (loanAmount <= 25000) {
    representativeApr = 6.8;
  } else {
    representativeApr = 7.9;
  }

  const monthlyRate = representativeApr / 100 / 12;
  const monthlyPayment =
    (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, termMonths))) /
    (Math.pow(1 + monthlyRate, termMonths) - 1);
  const totalRepayable = monthlyPayment * termMonths;
  const totalCostOfCredit = totalRepayable - loanAmount;

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
      <div className="bg-[#00395d] text-white p-6 sm:p-8">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#00aeef] uppercase tracking-wider mb-2">
          <Percent className="w-4 h-4" />
          <span>Barclays Personal Borrowing Model</span>
        </div>
        <h3 className="text-xl sm:text-2xl font-bold tracking-tight">
          Personal Loan Repayment Calculator
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
          Representative 6.1% APR on loans between £7,500 and £15,000 over 2 to 5 years. Fixed monthly repayments with zero early settlement penalties.
        </p>
      </div>

      <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-6">
          {/* Loan Amount Slider */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor={loanAmountInputId} className="text-xs font-semibold text-slate-700">How much would you like to borrow?</label>
              <span className="text-sm font-bold text-slate-900 font-mono">
                £{loanAmount.toLocaleString('en-GB')}
              </span>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">£</span>
              <input
                id={loanAmountInputId}
                type="number"
                min="1000"
                max="50000"
                step="500"
                value={loanAmount}
                onChange={(e) => setLoanAmount(Math.max(1000, Math.min(50000, Number(e.target.value))))}
                className="w-full pl-8 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
              />
            </div>
            <input
              type="range"
              min="1000"
              max="35000"
              step="500"
              value={loanAmount}
              onChange={(e) => setLoanAmount(Number(e.target.value))}
              className="w-full mt-2 accent-[#00395d]"
              aria-label="Loan Amount Slider"
            />
            <div className="flex justify-between text-[11px] text-slate-400 mt-1">
              <span>£1,000 min</span>
              <span className="text-emerald-700 font-semibold">£7.5k - £15k Best Rate (6.1% APR)</span>
              <span>£50,000 max</span>
            </div>
          </div>

          {/* Repayment Term */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-2">
              Repayment Duration: {termMonths} Months ({termMonths / 12} Years)
            </label>
            <div className="grid grid-cols-5 gap-2">
              {[12, 24, 36, 48, 60].map((months) => (
                <button
                  key={months}
                  type="button"
                  onClick={() => setTermMonths(months)}
                  className={`py-2 px-1 text-xs font-semibold rounded-lg border text-center transition-colors ${
                    termMonths === months
                      ? 'bg-[#00395d] text-white border-[#00395d] shadow-sm'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {months / 12} {months === 12 ? 'Year' : 'Years'}
                </button>
              ))}
            </div>
          </div>

          {/* Feature highlights */}
          <div className="pt-4 border-t border-slate-200 space-y-2 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Fixed monthly payments that never increase during the term</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Instant funds transfer into your Barclays account upon approval</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Check eligibility online with no impact on your credit score</span>
            </div>
          </div>
        </div>

        {/* Results column */}
        <div className="lg:col-span-5 bg-[#f2f7fa] rounded-xl p-6 border border-slate-200/80 flex flex-col justify-between">
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Fixed Monthly Repayment
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-[#00395d] mt-2 font-mono">
              £{monthlyPayment.toFixed(2)}
              <span className="text-xs font-normal text-slate-500 ml-1">/ month</span>
            </div>

            <div className="mt-6 space-y-3 pt-6 border-t border-slate-200 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Borrowing Amount:</span>
                <span className="font-semibold text-slate-900 font-mono">
                  £{loanAmount.toLocaleString('en-GB')}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Representative APR:</span>
                <span className="font-semibold text-slate-900 font-mono">{representativeApr}% APR</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Rate of Interest (Fixed):</span>
                <span className="font-semibold text-slate-900 font-mono">{representativeApr}% p.a.</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Total Interest Payable:</span>
                <span className="font-semibold text-slate-900 font-mono">
                  £{totalCostOfCredit.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                <span className="text-slate-600 font-semibold">Total Scheduled Repayment:</span>
                <span className="font-bold text-[#00395d] font-mono">
                  £{totalRepayable.toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200 text-[11px] text-slate-500 flex items-start gap-2">
            <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <span>
              Representative Example: Borrowing £10,000 over 36 months at 6.1% APR representative. Monthly payment £294.67. Total repayable £10,608.12. Rates are subject to status and may vary depending on loan amount and credit profile.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
