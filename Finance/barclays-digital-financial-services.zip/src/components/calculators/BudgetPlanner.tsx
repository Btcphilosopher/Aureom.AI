import React, { useState, useId } from 'react';
import { Wallet, CheckCircle, AlertTriangle } from 'lucide-react';

export const BudgetPlanner: React.FC = () => {
  const [netIncome, setNetIncome] = useState<number>(3200);
  const [housing, setHousing] = useState<number>(1100);
  const [utilities, setUtilities] = useState<number>(240);
  const [groceries, setGroceries] = useState<number>(350);
  const [transport, setTransport] = useState<number>(180);
  const [lifestyle, setLifestyle] = useState<number>(450);
  const [savingsTarget, setSavingsTarget] = useState<number>(500);

  const netIncomeId = useId();
  const housingId = useId();
  const utilitiesId = useId();
  const groceriesId = useId();
  const transportId = useId();
  const lifestyleId = useId();
  const savingsTargetId = useId();

  // 50/30/20 Rule Analysis:
  // Needs: Housing + Utilities + Groceries + Transport
  const needsTotal = housing + utilities + groceries + transport;
  // Wants: Lifestyle / Dining / Entertainment
  const wantsTotal = lifestyle;
  // Savings: savings target
  const savingsTotal = savingsTarget;

  const totalExpenses = needsTotal + wantsTotal + savingsTotal;
  const netRemaining = netIncome - totalExpenses;

  const needsPercent = netIncome > 0 ? ((needsTotal / netIncome) * 100).toFixed(0) : 0;
  const wantsPercent = netIncome > 0 ? ((wantsTotal / netIncome) * 100).toFixed(0) : 0;
  const savingsPercent = netIncome > 0 ? ((savingsTotal / netIncome) * 100).toFixed(0) : 0;

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
      <div className="bg-[#00395d] text-white p-6 sm:p-8">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#00aeef] uppercase tracking-wider mb-2">
          <Wallet className="w-4 h-4" />
          <span>Barclays Financial Wellbeing Model</span>
        </div>
        <h3 className="text-xl sm:text-2xl font-bold tracking-tight">
          Monthly Budget & Cashflow Planner
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
          Evaluate your household expenditure against the British 50/30/20 rule (50% Essential Needs, 30% Discretionary Wants, 20% Savings & Debt Reduction).
        </p>
      </div>

      <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 space-y-4">
          <div>
            <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
              <label htmlFor={netIncomeId}>Total Monthly Take-Home Pay (After Tax)</label>
              <span className="font-mono text-slate-900 font-bold">£{netIncome.toLocaleString()}</span>
            </div>
            <input
              id={netIncomeId}
              type="number"
              min="500"
              max="25000"
              step="100"
              value={netIncome}
              onChange={(e) => setNetIncome(Math.max(0, Number(e.target.value)))}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
            />
          </div>

          <div className="pt-2 border-t border-slate-100">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block mb-2">
              Essential Outgoings (Needs)
            </span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor={housingId} className="text-[11px] text-slate-500 block mb-1">Rent or Mortgage</label>
                <input
                  id={housingId}
                  type="number"
                  min="0"
                  step="50"
                  value={housing}
                  onChange={(e) => setHousing(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
              <div>
                <label htmlFor={utilitiesId} className="text-[11px] text-slate-500 block mb-1">Utilities & Council Tax</label>
                <input
                  id={utilitiesId}
                  type="number"
                  min="0"
                  step="20"
                  value={utilities}
                  onChange={(e) => setUtilities(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
              <div>
                <label htmlFor={groceriesId} className="text-[11px] text-slate-500 block mb-1">Food & Groceries</label>
                <input
                  id={groceriesId}
                  type="number"
                  min="0"
                  step="25"
                  value={groceries}
                  onChange={(e) => setGroceries(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
              <div>
                <label htmlFor={transportId} className="text-[11px] text-slate-500 block mb-1">Transport & Fuel</label>
                <input
                  id={transportId}
                  type="number"
                  min="0"
                  step="20"
                  value={transport}
                  onChange={(e) => setTransport(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100">
            <span className="text-xs font-bold text-slate-900 uppercase tracking-wider block mb-2">
              Discretionary & Future
            </span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor={lifestyleId} className="text-[11px] text-slate-500 block mb-1">Lifestyle & Leisure</label>
                <input
                  id={lifestyleId}
                  type="number"
                  min="0"
                  step="25"
                  value={lifestyle}
                  onChange={(e) => setLifestyle(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
              <div>
                <label htmlFor={savingsTargetId} className="text-[11px] text-slate-500 block mb-1">Monthly Savings Goal</label>
                <input
                  id={savingsTargetId}
                  type="number"
                  min="0"
                  step="50"
                  value={savingsTarget}
                  onChange={(e) => setSavingsTarget(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Breakdown Column */}
        <div className="lg:col-span-5 bg-[#f2f7fa] rounded-xl p-6 border border-slate-200/80 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Cashflow Summary
            </div>

            <div className="flex justify-between items-baseline">
              <span className="text-xs text-slate-600">Net Monthly Buffer:</span>
              <span
                className={`text-2xl font-bold font-mono ${
                  netRemaining >= 0 ? 'text-emerald-700' : 'text-rose-600'
                }`}
              >
                {netRemaining >= 0 ? '+' : ''}£{netRemaining.toLocaleString('en-GB')}
              </span>
            </div>

            {/* Proportion Bars */}
            <div className="space-y-2 pt-2 text-xs">
              <div>
                <div className="flex justify-between text-[11px] text-slate-600 mb-1">
                  <span>Essential Needs ({needsPercent}% of income)</span>
                  <span className="font-semibold text-slate-800">Target: ~50%</span>
                </div>
                <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-[#00395d] h-full"
                    style={{ width: `${Math.min(100, Number(needsPercent))}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-600 mb-1">
                  <span>Discretionary Wants ({wantsPercent}% of income)</span>
                  <span className="font-semibold text-slate-800">Target: ~30%</span>
                </div>
                <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-[#00aeef] h-full"
                    style={{ width: `${Math.min(100, Number(wantsPercent))}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-600 mb-1">
                  <span>Savings & Investments ({savingsPercent}% of income)</span>
                  <span className="font-semibold text-slate-800">Target: ~20%</span>
                </div>
                <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full"
                    style={{ width: `${Math.min(100, Number(savingsPercent))}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 text-xs text-slate-600">
              {netRemaining >= 0 ? (
                <div className="flex items-center gap-2 text-emerald-800 bg-emerald-50 p-2.5 rounded-lg border border-emerald-200">
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  <span>Healthy surplus! Consider channelling your £{netRemaining} buffer into a high-yield Cash ISA or Rainy Day Saver.</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-amber-900 bg-amber-50 p-2.5 rounded-lg border border-amber-200">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>Monthly deficit of £{Math.abs(netRemaining)}. Review discretionary subscriptions or utility tariffs to balance outgoings.</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
