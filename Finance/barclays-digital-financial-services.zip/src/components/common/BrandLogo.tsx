import React from 'react';

interface BrandLogoProps {
  className?: string;
  variant?: 'light' | 'dark' | 'cyan';
  showTagline?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = 'h-7',
  variant = 'cyan',
}) => {
  const eagleColor = variant === 'light' ? '#ffffff' : '#00aeef';
  const textColor = variant === 'light' ? 'text-white' : variant === 'dark' ? 'text-[#00395d]' : 'text-[#00aeef]';

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Authentic Spread-Wing Barclays Eagle Emblem SVG */}
      <svg
        className="w-7 h-7 shrink-0 transition-transform duration-200 group-hover:scale-105"
        viewBox="0 0 40 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        <path
          d="M20 2.5C10.335 2.5 2.5 10.335 2.5 20C2.5 29.665 10.335 37.5 20 37.5C29.665 37.5 37.5 29.665 37.5 20C37.5 10.335 29.665 2.5 20 2.5Z"
          fill={eagleColor}
          fillOpacity="0.1"
        />
        <path
          d="M20 5C11.716 5 5 11.716 5 20C5 28.284 11.716 35 20 35C28.284 35 35 28.284 35 20C35 11.716 28.284 5 20 5ZM21.4 31C18.2 31.3 15 29.9 13.1 27.4C15 26.9 17.2 26.5 18.7 25.2C17.6 24.7 16.5 24 15.8 23C17 22.9 18.3 22.6 19.1 21.8C17.9 21.3 17.1 20.2 16.7 19C17.8 19 18.8 18.7 19.6 18.2C18.1 17.3 17.3 15.8 17.4 14.1C19 14.9 20.9 15.3 22.7 15.4C23.8 13.7 25.6 12.5 27.8 12.2C29.4 13.9 29.8 16.4 28.7 18.4C30.2 18.3 31.6 17.9 32.9 17.4C32 18.9 30.5 19.9 28.9 20.4C30.1 20.7 31.4 20.7 32.5 20.3C31.3 21.8 29.8 22.7 28.1 23.2C29 23.7 30.1 24.1 31.1 24.2C29.5 25.3 27.6 25.9 25.7 26.1C24.8 28.6 23.2 30.2 21.4 31Z"
          fill={eagleColor}
        />
      </svg>
      <span
        className={`font-display font-extrabold tracking-[0.06em] text-xl sm:text-2xl uppercase ${textColor}`}
      >
        BARCLAYS
      </span>
    </div>
  );
};
