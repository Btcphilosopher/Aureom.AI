import React, { useState } from 'react';
import {
  Search,
  Lock,
  ChevronDown,
  Menu,
  X,
  CreditCard,
  Landmark,
  PiggyBank,
  Home,
  Percent,
  Briefcase,
  TrendingUp,
  Calculator,
  ShieldCheck,
  UserCheck,
  LogOut,
} from 'lucide-react';
import { BrandLogo } from '../common/BrandLogo';
import { useBanking } from '../../context/BankingContext';
import { RoutePath } from '../../types/banking';

export const Header: React.FC = () => {
  const {
    currentRoute,
    navigate,
    isLoggedIn,
    user,
    logout,
    setIsSearchOpen,
    activeSegment,
    setActiveSegment,
  } = useBanking();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const handleNavClick = (path: RoutePath) => {
    navigate(path);
    setActiveDropdown(null);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-slate-200">
      {/* 1. Top Institutional Segment Bar */}
      <div className="bg-[#00263e] text-slate-300 text-xs px-4 sm:px-8 border-b border-white/10 hidden md:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between h-9">
          {/* Segment Switchers */}
          <div className="flex items-center gap-6">
            <button
              onClick={() => {
                setActiveSegment('personal');
                handleNavClick('/personal');
              }}
              className={`py-1.5 transition-colors font-medium border-b-2 ${
                activeSegment === 'personal'
                  ? 'text-white border-[#00aeef]'
                  : 'text-slate-400 border-transparent hover:text-white'
              }`}
            >
              Personal Banking
            </button>
            <button
              onClick={() => {
                setActiveSegment('wealth');
                handleNavClick('/wealth');
              }}
              className={`py-1.5 transition-colors font-medium border-b-2 ${
                activeSegment === 'wealth'
                  ? 'text-white border-[#00aeef]'
                  : 'text-slate-400 border-transparent hover:text-white'
              }`}
            >
              Wealth & Investing
            </button>
            <button
              onClick={() => {
                setActiveSegment('business');
                handleNavClick('/business');
              }}
              className={`py-1.5 transition-colors font-medium border-b-2 ${
                activeSegment === 'business'
                  ? 'text-white border-[#00aeef]'
                  : 'text-slate-400 border-transparent hover:text-white'
              }`}
            >
              Business Banking
            </button>
          </div>

          {/* Utility Right Links */}
          <div className="flex items-center gap-5 text-slate-300">
            <button
              onClick={() => handleNavClick('/about')}
              className="hover:text-white transition-colors"
            >
              About Barclays
            </button>
            <button
              onClick={() => handleNavClick('/careers')}
              className="hover:text-white transition-colors"
            >
              Careers
            </button>
            <button
              onClick={() => handleNavClick('/security')}
              className="flex items-center gap-1 hover:text-white transition-colors"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#00aeef]" />
              Security Hub
            </button>
            <span className="text-slate-500">|</span>
            <span className="text-slate-300 font-mono text-[11px]">UK (GBP £)</span>
          </div>
        </div>
      </div>

      {/* 2. Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          {/* Brand Logo */}
          <button
            onClick={() => handleNavClick('/')}
            className="flex items-center py-2 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00aeef]"
            aria-label="Barclays Home"
          >
            <BrandLogo />
          </button>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {/* Personal Banking Mega Menu Trigger */}
            <div
              className="relative"
              onMouseEnter={() => setActiveDropdown('products')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button
                onClick={() => handleNavClick('/personal')}
                className={`flex items-center gap-1 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  currentRoute.startsWith('/personal') ||
                  currentRoute === '/current-accounts' ||
                  currentRoute === '/savings' ||
                  currentRoute === '/mortgages' ||
                  currentRoute === '/loans' ||
                  currentRoute === '/credit-cards'
                    ? 'text-[#00395d] font-semibold bg-slate-100/60'
                    : 'text-slate-700 hover:text-[#00395d] hover:bg-slate-50'
                }`}
              >
                Products
                <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-slate-700" />
              </button>

              {/* Mega Menu Dropdown */}
              {activeDropdown === 'products' && (
                <div className="absolute top-full left-0 w-[580px] bg-white rounded-xl shadow-xl border border-slate-200 p-5 mt-1 grid grid-cols-2 gap-4 animate-in fade-in duration-150">
                  <button
                    onClick={() => handleNavClick('/current-accounts')}
                    className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-[#f2f7fa] text-left transition-colors group"
                  >
                    <div className="p-2 rounded-md bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors">
                      <Landmark className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-900 group-hover:text-[#00395d]">
                        Current Accounts
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Premier, Everyday & Student accounts with £175 switch offer.
                      </p>
                    </div>
                  </button>

                  <button
                    onClick={() => handleNavClick('/savings')}
                    className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-[#f2f7fa] text-left transition-colors group"
                  >
                    <div className="p-2 rounded-md bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors">
                      <PiggyBank className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-900 group-hover:text-[#00395d]">
                        Savings & ISAs
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        5.12% AER Rainy Day Saver and 1-Year Fixed Cash ISAs.
                      </p>
                    </div>
                  </button>

                  <button
                    onClick={() => handleNavClick('/mortgages')}
                    className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-[#f2f7fa] text-left transition-colors group"
                  >
                    <div className="p-2 rounded-md bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors">
                      <Home className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-900 group-hover:text-[#00395d]">
                        Mortgages
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        First-time buyers, remortgaging & repayment calculators.
                      </p>
                    </div>
                  </button>

                  <button
                    onClick={() => handleNavClick('/loans')}
                    className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-[#f2f7fa] text-left transition-colors group"
                  >
                    <div className="p-2 rounded-md bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors">
                      <Percent className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-900 group-hover:text-[#00395d]">
                        Personal Loans
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Borrow £1k–£50k with 6.1% APR Representative.
                      </p>
                    </div>
                  </button>

                  <button
                    onClick={() => handleNavClick('/credit-cards')}
                    className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-[#f2f7fa] text-left transition-colors group"
                  >
                    <div className="p-2 rounded-md bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors">
                      <CreditCard className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-900 group-hover:text-[#00395d]">
                        Credit Cards
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Barclaycard Platinum 0% balance transfer & Rewards.
                      </p>
                    </div>
                  </button>

                  <button
                    onClick={() => handleNavClick('/international')}
                    className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-[#f2f7fa] text-left transition-colors group"
                  >
                    <div className="p-2 rounded-md bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-900 group-hover:text-[#00395d]">
                        International Banking
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Global payments, FX transfers and multi-currency accounts.
                      </p>
                    </div>
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => handleNavClick('/wealth')}
              className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                currentRoute === '/wealth'
                  ? 'text-[#00395d] font-semibold bg-slate-100/60'
                  : 'text-slate-700 hover:text-[#00395d] hover:bg-slate-50'
              }`}
            >
              Wealth
            </button>

            <button
              onClick={() => handleNavClick('/business')}
              className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                currentRoute === '/business'
                  ? 'text-[#00395d] font-semibold bg-slate-100/60'
                  : 'text-slate-700 hover:text-[#00395d] hover:bg-slate-50'
              }`}
            >
              Business
            </button>

            <button
              onClick={() => handleNavClick('/calculators')}
              className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                currentRoute === '/calculators'
                  ? 'text-[#00395d] font-semibold bg-slate-100/60'
                  : 'text-slate-700 hover:text-[#00395d] hover:bg-slate-50'
              }`}
            >
              <Calculator className="w-4 h-4 text-[#00aeef]" />
              Calculators
            </button>

            <button
              onClick={() => handleNavClick('/help')}
              className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                currentRoute === '/help'
                  ? 'text-[#00395d] font-semibold bg-slate-100/60'
                  : 'text-slate-700 hover:text-[#00395d] hover:bg-slate-50'
              }`}
            >
              Help & Support
            </button>
          </nav>

          {/* Right Action Zone */}
          <div className="flex items-center gap-3">
            {/* Search Trigger */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="p-2.5 text-slate-600 hover:text-[#00395d] hover:bg-slate-100 rounded-lg transition-colors"
              title="Search banking products and help (Esc)"
              aria-label="Open search dialog"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Online Banking Sign In Button */}
            {isLoggedIn ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleNavClick('/dashboard')}
                  className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-[#00395d] hover:bg-[#00263e] rounded-lg transition-all shadow-sm"
                >
                  <UserCheck className="w-4 h-4 text-[#00aeef]" />
                  <span>Dr. Finch</span>
                </button>
                <button
                  onClick={logout}
                  className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  title="Sign out of demonstration banking"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleNavClick('/login')}
                className="flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] active:bg-[#0086bc] rounded-lg transition-all shadow-sm hover:shadow"
              >
                <Lock className="w-4 h-4" />
                <span>Log In</span>
              </button>
            )}

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 lg:hidden text-slate-700 hover:text-slate-900 rounded-lg focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-6 max-h-[85vh] overflow-y-auto space-y-4 animate-in slide-in-from-top-2 duration-200">
          <div className="space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 px-3 py-1">
              Personal Banking
            </div>
            <button
              onClick={() => handleNavClick('/current-accounts')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <Landmark className="w-4 h-4 text-[#00aeef]" /> Current Accounts
            </button>
            <button
              onClick={() => handleNavClick('/savings')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <PiggyBank className="w-4 h-4 text-[#00aeef]" /> Savings & ISAs
            </button>
            <button
              onClick={() => handleNavClick('/mortgages')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <Home className="w-4 h-4 text-[#00aeef]" /> Mortgages
            </button>
            <button
              onClick={() => handleNavClick('/loans')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <Percent className="w-4 h-4 text-[#00aeef]" /> Personal Loans
            </button>
            <button
              onClick={() => handleNavClick('/credit-cards')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <CreditCard className="w-4 h-4 text-[#00aeef]" /> Credit Cards
            </button>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 px-3 py-1">
              Institutions & Enterprise
            </div>
            <button
              onClick={() => handleNavClick('/wealth')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <TrendingUp className="w-4 h-4 text-[#00aeef]" /> Wealth & Investing
            </button>
            <button
              onClick={() => handleNavClick('/business')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <Briefcase className="w-4 h-4 text-[#00aeef]" /> Business Banking
            </button>
            <button
              onClick={() => handleNavClick('/international')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <TrendingUp className="w-4 h-4 text-[#00aeef]" /> International FX & Accounts
            </button>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-1">
            <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 px-3 py-1">
              Tools & Guidance
            </div>
            <button
              onClick={() => handleNavClick('/calculators')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <Calculator className="w-4 h-4 text-[#00aeef]" /> Financial Calculators
            </button>
            <button
              onClick={() => handleNavClick('/help')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <Landmark className="w-4 h-4 text-[#00aeef]" /> Support & FAQs
            </button>
            <button
              onClick={() => handleNavClick('/security')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              <ShieldCheck className="w-4 h-4 text-[#00aeef]" /> Security & Scam Prevention
            </button>
            <button
              onClick={() => handleNavClick('/about')}
              className="w-full text-left px-3 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 rounded-lg flex items-center gap-2.5"
            >
              About Barclays
            </button>
          </div>

          <div className="pt-4 border-t border-slate-200">
            {isLoggedIn ? (
              <div className="space-y-2">
                <button
                  onClick={() => handleNavClick('/dashboard')}
                  className="w-full py-2.5 text-center font-semibold text-white bg-[#00395d] rounded-lg"
                >
                  Go to Online Banking Dashboard
                </button>
                <button
                  onClick={logout}
                  className="w-full py-2 text-center text-xs text-red-600 font-medium"
                >
                  Log Out
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleNavClick('/login')}
                className="w-full py-2.5 text-center font-semibold text-white bg-[#00aeef] rounded-lg"
              >
                Sign In to Online Banking
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
