import React from 'react';
import { BrandLogo } from '../common/BrandLogo';
import { useBanking } from '../../context/BankingContext';
import { RoutePath } from '../../types/banking';
import { ShieldCheck, PhoneCall, HelpCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  const { navigate } = useBanking();

  const handleNav = (path: RoutePath) => {
    navigate(path);
  };

  return (
    <footer className="bg-[#001726] text-slate-300 border-t border-slate-800">
      {/* Upper reassurance banner */}
      <div className="bg-[#002238] border-b border-white/5 py-6 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#00aeef]/10 text-[#00aeef] rounded-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="font-semibold text-white block text-sm">
                FSCS Protected up to £85,000
              </span>
              <span className="text-slate-400">
                Eligible deposits with Barclays UK are protected by the Financial Services Compensation Scheme.
              </span>
            </div>
          </div>

          <div className="flex items-center gap-6 text-slate-300">
            <button
              onClick={() => handleNav('/security')}
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <ShieldCheck className="w-4 h-4 text-[#00aeef]" />
              <span>Fraud Helpline 159</span>
            </button>
            <button
              onClick={() => handleNav('/help')}
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <HelpCircle className="w-4 h-4 text-[#00aeef]" />
              <span>24/7 Support</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main sitemap grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-12">
          {/* Col 1: Personal Banking */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Personal Banking
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => handleNav('/current-accounts')}
                  className="hover:text-white transition-colors"
                >
                  Current Accounts
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/current-accounts')}
                  className="hover:text-white transition-colors"
                >
                  Premier Banking
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/savings')}
                  className="hover:text-white transition-colors"
                >
                  Savings & ISAs
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/mortgages')}
                  className="hover:text-white transition-colors"
                >
                  Mortgages
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/loans')}
                  className="hover:text-white transition-colors"
                >
                  Personal Loans
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/credit-cards')}
                  className="hover:text-white transition-colors"
                >
                  Credit Cards
                </button>
              </li>
            </ul>
          </div>

          {/* Col 2: Wealth & Business */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Wealth & Business
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => handleNav('/wealth')}
                  className="hover:text-white transition-colors"
                >
                  Wealth Management
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/wealth')}
                  className="hover:text-white transition-colors"
                >
                  Smart Investor
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/business')}
                  className="hover:text-white transition-colors"
                >
                  Business Accounts
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/business')}
                  className="hover:text-white transition-colors"
                >
                  Commercial Lending
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/international')}
                  className="hover:text-white transition-colors"
                >
                  International Payments
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Financial Calculators */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Calculators & Tools
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => handleNav('/calculators')}
                  className="hover:text-white transition-colors"
                >
                  Mortgage Calculator
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/calculators')}
                  className="hover:text-white transition-colors"
                >
                  Savings Compound Tool
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/calculators')}
                  className="hover:text-white transition-colors"
                >
                  Loan Repayment Model
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/calculators')}
                  className="hover:text-white transition-colors"
                >
                  Credit Card Payoff Tool
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/calculators')}
                  className="hover:text-white transition-colors"
                >
                  Monthly Budget Planner
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Support & Security */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Help & Security
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => handleNav('/help')}
                  className="hover:text-white transition-colors"
                >
                  Help Centre & FAQs
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/security')}
                  className="hover:text-white transition-colors"
                >
                  Fraud & Scam Alerts
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/security')}
                  className="hover:text-white transition-colors"
                >
                  Confirmation of Payee
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/help')}
                  className="hover:text-white transition-colors"
                >
                  Branch & ATM Finder
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/accessibility')}
                  className="hover:text-white transition-colors"
                >
                  Accessibility Statement
                </button>
              </li>
            </ul>
          </div>

          {/* Col 5: About Barclays */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              The Institution
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button
                  onClick={() => handleNav('/about')}
                  className="hover:text-white transition-colors"
                >
                  About Barclays PLC
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/about')}
                  className="hover:text-white transition-colors"
                >
                  History since 1690
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/careers')}
                  className="hover:text-white transition-colors"
                >
                  Careers & Early Talent
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('/privacy')}
                  className="hover:text-white transition-colors"
                >
                  Privacy & Data Policy
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Regulatory Disclosure Block */}
        <div className="pt-8 border-t border-slate-800/80 text-[11px] text-slate-500 leading-relaxed space-y-3">
          <p>
            Barclays Bank UK PLC and Barclays Bank PLC are each authorised by the Prudential Regulation
            Authority and regulated by the Financial Conduct Authority and the Prudential Regulation
            Authority (Financial Services Register Nos. 759676 and 122702). Registered in England.
            Registered No. 9740322 and 1026167. Registered Office: 1 Churchill Place, London E14 5HP.
          </p>
          <p>
            This website is a production-grade digital financial experience crafted as a modern British
            banking implementation. Demonstration online banking services use strictly synthetic
            accounts and fictional balances. Do not enter real banking credentials or live payment details.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-between pt-4 border-t border-slate-800/50 gap-4">
            <BrandLogo variant="light" className="h-6" />
            <div className="flex flex-wrap items-center gap-4 text-slate-400 text-xs">
              <button onClick={() => handleNav('/privacy')} className="hover:text-white transition-colors">
                Privacy Notice
              </button>
              <span>·</span>
              <button onClick={() => handleNav('/accessibility')} className="hover:text-white transition-colors">
                Accessibility (WCAG 2.2 AA)
              </button>
              <span>·</span>
              <button onClick={() => handleNav('/security')} className="hover:text-white transition-colors">
                Security Principles
              </button>
              <span>·</span>
              <button onClick={() => handleNav('/login')} className="hover:text-white transition-colors">
                Demonstration Portal
              </button>
            </div>
            <div className="text-slate-500 text-[11px]">
              &copy; {new Date().getFullYear()} Barclays Digital Financial Services
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
