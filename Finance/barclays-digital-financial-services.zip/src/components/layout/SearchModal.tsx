import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight, Calculator, FileText, HelpCircle, Shield, CreditCard, Landmark } from 'lucide-react';
import { useBanking } from '../../context/BankingContext';
import { RoutePath } from '../../types/banking';

interface SearchResult {
  title: string;
  category: string;
  path: RoutePath;
  icon: React.ReactNode;
  description: string;
}

const SEARCH_INDEX: SearchResult[] = [
  {
    title: 'Mortgage Repayment Calculator',
    category: 'Calculators',
    path: '/calculators',
    icon: <Calculator className="w-4 h-4 text-[#00aeef]" />,
    description: 'Calculate monthly repayments, LTV, total interest and amortization schedule.',
  },
  {
    title: 'Premier Current Account',
    category: 'Current Accounts',
    path: '/current-accounts',
    icon: <Landmark className="w-4 h-4 text-[#00aeef]" />,
    description: 'Exclusive black card, dedicated 24/7 relationship team, fee-free spending abroad.',
  },
  {
    title: 'Blue Rewards Rainy Day Saver (5.12% AER)',
    category: 'Savings',
    path: '/savings',
    icon: <FileText className="w-4 h-4 text-[#00aeef]" />,
    description: 'High-yield instant access savings account up to £5,000 for Blue Rewards members.',
  },
  {
    title: 'Personal Loan Calculator (6.1% APR Rep)',
    category: 'Borrowing',
    path: '/loans',
    icon: <Calculator className="w-4 h-4 text-[#00aeef]" />,
    description: 'Borrow between £1,000 and £50,000 with flexible terms from 1 to 5 years.',
  },
  {
    title: 'Barclaycard Rewards Credit Card',
    category: 'Credit Cards',
    path: '/credit-cards',
    icon: <CreditCard className="w-4 h-4 text-[#00aeef]" />,
    description: '0.25% cashback, zero foreign transaction fees, no annual maintenance fee.',
  },
  {
    title: 'Wealth Management & Private Advisory',
    category: 'Wealth',
    path: '/wealth',
    icon: <Landmark className="w-4 h-4 text-[#00aeef]" />,
    description: 'Discretionary portfolios, financial planning and Barclays Smart Investor.',
  },
  {
    title: 'Business Banking & Commercial Lending',
    category: 'Business',
    path: '/business',
    icon: <Landmark className="w-4 h-4 text-[#00aeef]" />,
    description: 'Start-up accounts with 12 months free banking, merchant services and trade finance.',
  },
  {
    title: 'Confirmation of Payee & Scam Defense',
    category: 'Security',
    path: '/security',
    icon: <Shield className="w-4 h-4 text-[#00aeef]" />,
    description: 'Learn how to detect fraudulent requests, impersonation scams and phishing SMS.',
  },
  {
    title: 'Customer Support & Help Centre',
    category: 'Support',
    path: '/help',
    icon: <HelpCircle className="w-4 h-4 text-[#00aeef]" />,
    description: 'Browse answers on card freezes, Direct Debits, switching and bereavement support.',
  },
  {
    title: 'Secure Online Banking Sign In',
    category: 'Access',
    path: '/login',
    icon: <Shield className="w-4 h-4 text-[#00aeef]" />,
    description: 'Sign in to access your synthetic demonstration account and manage transfers.',
  },
];

export const SearchModal: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen, navigate } = useBanking();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          setIsSearchOpen(false);
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isSearchOpen, setIsSearchOpen]);

  if (!isSearchOpen) return null;

  const filtered = SEARCH_INDEX.filter(
    (item) =>
      item.title.toLowerCase().includes(query.toLowerCase()) ||
      item.description.toLowerCase().includes(query.toLowerCase()) ||
      item.category.toLowerCase().includes(query.toLowerCase())
  );

  const handleSelect = (path: RoutePath) => {
    setIsSearchOpen(false);
    setQuery('');
    navigate(path);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={() => setIsSearchOpen(false)}
    >
      <div
        className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-100 bg-slate-50/50">
          <Search className="w-5 h-5 text-slate-400 mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search accounts, mortgages, calculators, security, help..."
            className="w-full bg-transparent border-none text-slate-900 text-base focus:outline-none placeholder:text-slate-400"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-md"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setIsSearchOpen(false)}
            className="ml-2 text-xs font-medium text-slate-500 bg-slate-200/80 hover:bg-slate-300 px-2 py-1 rounded transition-colors"
          >
            ESC
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-2 divide-y divide-slate-100">
          {filtered.length > 0 ? (
            filtered.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSelect(item.path)}
                className="w-full text-left p-3.5 rounded-lg hover:bg-[#f2f7fa] transition-colors flex items-center justify-between group"
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-slate-100 group-hover:bg-white text-slate-700 transition-colors shrink-0 mt-0.5">
                    {item.icon}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-900 group-hover:text-[#00395d]">
                        {item.title}
                      </span>
                      <span className="text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                        {item.category}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-1">{item.description}</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#00aeef] transition-colors shrink-0 ml-3" />
              </button>
            ))
          ) : (
            <div className="py-12 text-center text-slate-500 text-sm">
              No results found for &ldquo;{query}&rdquo;. Try &ldquo;mortgage&rdquo;, &ldquo;savings&rdquo; or &ldquo;login&rdquo;.
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Barclays Fast Search</span>
          <span className="hidden sm:inline">Press Esc to close · Click result to navigate</span>
        </div>
      </div>
    </div>
  );
};
