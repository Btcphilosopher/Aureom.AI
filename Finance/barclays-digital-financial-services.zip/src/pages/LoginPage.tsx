import React, { useState } from 'react';
import { Lock, ShieldAlert, ArrowRight, CheckCircle2, UserCheck, KeyRound, AlertCircle } from 'lucide-react';
import { useBanking } from '../context/BankingContext';
import { BrandLogo } from '../components/common/BrandLogo';

export const LoginPage: React.FC = () => {
  const { loginAsDemoUser, navigate } = useBanking();

  const [step, setStep] = useState<1 | 2>(1);
  const [membershipNumber, setMembershipNumber] = useState('2094 8192 01');
  const [surname, setSurname] = useState('Finch');
  const [passcode, setPasscode] = useState('•••••');
  const [memorableWordChar, setMemorableWordChar] = useState('A');

  const handleSubmitStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  const handleSubmitStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    loginAsDemoUser();
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-between py-12 px-4 sm:px-6">
      <div className="max-w-md w-full mx-auto">
        {/* Demonstration Disclaimer Warning Banner */}
        <div className="mb-6 p-4 bg-amber-50 border border-amber-300 rounded-xl text-xs text-amber-900 flex items-start gap-3 shadow-xs">
          <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong>Demonstration Online Banking Sandbox</strong>
            <p className="text-[11px] leading-relaxed">
              This environment uses synthetic demo accounts only. Never enter real banking credentials, passwords, card numbers, or one-time passcodes.
            </p>
          </div>
        </div>

        {/* Login Box */}
        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
          <div className="bg-[#00395d] p-6 text-white text-center">
            <BrandLogo variant="light" className="justify-center mb-2" />
            <h1 className="text-lg font-bold">Secure Online Banking</h1>
            <p className="text-xs text-slate-300 mt-1">Step {step} of 2: Verification</p>
          </div>

          <div className="p-6 sm:p-8">
            {step === 1 ? (
              <form onSubmit={handleSubmitStep1} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                    Membership number or 16-digit Debit Card number
                  </label>
                  <input
                    type="text"
                    value={membershipNumber}
                    onChange={(e) => setMembershipNumber(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none font-mono"
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Demo account pre-filled for testing
                  </span>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                    Last name / Surname
                  </label>
                  <input
                    type="text"
                    value={surname}
                    onChange={(e) => setSurname(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-[#00aeef] hover:bg-[#0098d3] active:bg-[#0086bc] text-white font-semibold text-sm rounded-lg transition-all shadow-sm flex items-center justify-center gap-2"
                  >
                    <span>Continue to Step 2</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleSubmitStep2} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                    5-Digit Security Passcode
                  </label>
                  <input
                    type="password"
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1.5">
                    Memorable Word Verification (Character 3)
                  </label>
                  <input
                    type="text"
                    maxLength={1}
                    value={memorableWordChar}
                    onChange={(e) => setMemorableWordChar(e.target.value)}
                    required
                    className="w-14 text-center px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none font-mono uppercase"
                  />
                </div>

                <div className="pt-2 space-y-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-[#00395d] hover:bg-[#00263e] text-white font-semibold text-sm rounded-lg transition-all shadow-sm flex items-center justify-center gap-2"
                  >
                    <Lock className="w-4 h-4 text-[#00aeef]" />
                    <span>Log In to Online Banking</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="w-full text-center text-xs text-slate-500 hover:text-slate-800 py-1"
                  >
                    &larr; Back to Step 1
                  </button>
                </div>
              </form>
            )}

            {/* Quick 1-Click Demo Login Bypass */}
            <div className="mt-6 pt-6 border-t border-slate-100 text-center">
              <span className="text-xs text-slate-400 block mb-3 font-medium">
                Want to evaluate the platform immediately?
              </span>
              <button
                type="button"
                onClick={loginAsDemoUser}
                className="w-full py-2 px-4 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-2"
              >
                <UserCheck className="w-4 h-4 text-emerald-600" />
                <span>Instant 1-Click Demo Login (Dr. Alistair Finch)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Security reminders */}
        <div className="mt-8 text-center text-xs text-slate-500 space-y-2">
          <p>Confirmation of Payee & Biometric Protection Enabled</p>
          <div className="flex justify-center gap-4 text-[11px] text-slate-400">
            <button onClick={() => navigate('/security')} className="hover:underline">
              How we protect you
            </button>
            <span>·</span>
            <button onClick={() => navigate('/help')} className="hover:underline">
              Sign in assistance
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
