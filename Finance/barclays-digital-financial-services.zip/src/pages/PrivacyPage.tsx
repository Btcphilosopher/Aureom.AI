import React from 'react';
import { ShieldCheck, Lock, FileText, CheckCircle2 } from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 py-16 px-4 sm:px-8">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl border border-slate-200 p-8 sm:p-12 shadow-xs space-y-8">
        <div>
          <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
            Governance & Privacy
          </span>
          <h1 className="text-3xl font-extrabold text-[#00395d] mt-1">Privacy Notice & Data Protection</h1>
          <p className="text-xs text-slate-500 mt-2">
            Last updated: October 2026 · Compliant with UK General Data Protection Regulation (UK GDPR)
          </p>
        </div>

        <div className="space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">1. Our Commitment to Your Privacy</h2>
            <p>
              Barclays Bank UK PLC and its subsidiaries are committed to protecting your personal information. When you use our digital banking platforms, mobile apps, or branch services, we process personal data strictly in accordance with UK data privacy law.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">2. How We Use Financial and Personal Data</h2>
            <ul className="list-disc pl-5 space-y-1">
              <li>To provide, manage and administer your current accounts, savings pots, loans and cards.</li>
              <li>To perform mandatory fraud deterrence, identity verification and Confirmation of Payee checks.</li>
              <li>To meet regulatory obligations enforced by the Financial Conduct Authority (FCA) and Prudential Regulation Authority (PRA).</li>
              <li>To deliver real-time spending categorisation and budgeting insights directly in your app.</li>
            </ul>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">3. Demonstration Environment Boundaries</h2>
            <p>
              This website is an independent demonstration of British banking design and financial services engineering. The demonstration online banking portal processes strictly synthetic client accounts and fictional transaction records. We do not store or transmit real banking passwords, card numbers, or live identity documents.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">4. Your Statutory Rights</h2>
            <p>
              Under UK GDPR, you have the right to request access to your personal information, request erasure of records where legally permissible, object to direct marketing, and request data portability.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
