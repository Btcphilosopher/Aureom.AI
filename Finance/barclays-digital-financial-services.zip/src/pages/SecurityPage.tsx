import React, { useState } from 'react';
import { ShieldCheck, AlertTriangle, Lock, PhoneCall, CheckCircle2, HelpCircle, XCircle } from 'lucide-react';

interface ScamQuizQuestion {
  id: number;
  scenario: string;
  options: { label: string; isScam: boolean; explanation: string }[];
}

const SCAM_QUESTIONS: ScamQuizQuestion[] = [
  {
    id: 1,
    scenario:
      'You receive an urgent SMS: "BARCLAYS ALERT: A new device accessed your account. To prevent a £480 transfer, click here immediately: https://barclays-auth-verify.co.uk"',
    options: [
      {
        label: 'Click the link immediately to cancel the payment',
        isScam: true,
        explanation:
          'SCAM. Barclays will never send you a link asking you to log in or cancel a payment. Fraudulent domains often imitate bank names.',
      },
      {
        label: 'Ignore the link and check your account via the official app',
        isScam: false,
        explanation:
          'CORRECT. Never click links in unexpected text messages. Always open your verified Barclays app or dial 159.',
      },
    ],
  },
  {
    id: 2,
    scenario:
      'A caller claiming to be from the Barclays Fraud Team says: "Your account is under threat from an internal rogue employee. You must immediately move your savings to this new protected Safe Account."',
    options: [
      {
        label: 'Follow the caller\'s instructions to protect your money',
        isScam: true,
        explanation:
          'DANGEROUS SCAM. Banks and police will NEVER ask you to transfer money to a "safe account" or "holding account". Safe accounts do not exist.',
      },
      {
        label: 'Hang up and dial 159 from another line',
        isScam: false,
        explanation:
          'CORRECT. This is an impersonation scam. Hanging up immediately and dialling 159 safely reconnects you directly with your bank.',
      },
    ],
  },
];

export const SecurityPage: React.FC = () => {
  const [quizAnswers, setQuizAnswers] = useState<{ [key: number]: number | null }>({});

  const handleAnswer = (questionId: number, optionIndex: number) => {
    setQuizAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-[#002238] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Security & Fraud Prevention Hub</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              Protecting your money and identity.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              We employ sophisticated fraud surveillance, Confirmation of Payee verification, and two-factor authentication to keep your assets secure.
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-16">
        {/* Take Five to Stop Fraud British Golden Rules */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
            National UK Campaign
          </span>
          <h2 className="text-2xl font-bold text-[#00395d] mt-1 mb-6">
            Take Five to Stop Fraud: The Three Golden Rules
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-[#f2f7fa] border border-slate-200/80">
              <div className="text-lg font-bold text-[#00395d] mb-1">1. Stop</div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Taking a moment to stop and think before parting with your money or information can keep you safe. Never rush or panic when pressured.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-[#f2f7fa] border border-slate-200/80">
              <div className="text-lg font-bold text-[#00395d] mb-1">2. Challenge</div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Could it be fake? It&apos;s okay to reject, refuse or ignore any requests. Only criminals will try to rush or panic you.
              </p>
            </div>

            <div className="p-5 rounded-xl bg-[#f2f7fa] border border-slate-200/80">
              <div className="text-lg font-bold text-[#00395d] mb-1">3. Protect</div>
              <p className="text-xs text-slate-600 leading-relaxed">
                If you believe you have fallen for a scam, contact your bank immediately by dialling 159 and report the incident to Action Fraud.
              </p>
            </div>
          </div>
        </div>

        {/* Spot the Scam Interactive Quiz */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          <div className="mb-6">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Interactive Assessment
            </span>
            <h2 className="text-2xl font-bold text-[#00395d] mt-1">Spot the Scam: Test Your Vigilance</h2>
            <p className="text-xs text-slate-600">
              Read each realistic scenario and choose how you would respond.
            </p>
          </div>

          <div className="space-y-8">
            {SCAM_QUESTIONS.map((q) => {
              const selectedIdx = quizAnswers[q.id];
              return (
                <div key={q.id} className="p-5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
                    Scenario {q.id}
                  </span>
                  <p className="text-sm font-semibold text-slate-900 mb-4">{q.scenario}</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {q.options.map((opt, oIdx) => {
                      const isSelected = selectedIdx === oIdx;
                      return (
                        <button
                          key={oIdx}
                          onClick={() => handleAnswer(q.id, oIdx)}
                          className={`p-3 text-xs text-left font-medium rounded-lg border transition-all ${
                            isSelected
                              ? 'border-[#00395d] bg-white text-slate-900 shadow-xs'
                              : 'border-slate-300 bg-white hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          {opt.label}
                        </button>
                      );
                    })}
                  </div>

                  {selectedIdx !== undefined && selectedIdx !== null && (
                    <div
                      className={`mt-4 p-3.5 rounded-lg text-xs leading-relaxed ${
                        q.options[selectedIdx].isScam
                          ? 'bg-rose-50 border border-rose-200 text-rose-900'
                          : 'bg-emerald-50 border border-emerald-200 text-emerald-900'
                      }`}
                    >
                      <div className="font-bold mb-1">
                        {q.options[selectedIdx].isScam ? 'Scam Alert:' : 'Well Done:'}
                      </div>
                      {q.options[selectedIdx].explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Emergency Fraud Phone Box */}
        <div className="bg-[#00263e] text-white p-6 sm:p-8 rounded-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Emergency UK Banking Assistance
            </span>
            <h3 className="text-xl font-bold">Dial 159 to stop fraud in its tracks.</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              159 is a memorable, secure phone line that connects you directly with your bank if you believe you are being targeted by fraudsters. Call it immediately if anyone contacts you asking for security credentials.
            </p>
          </div>
          <div className="p-4 bg-white/10 rounded-xl text-center border border-white/20 shrink-0">
            <PhoneCall className="w-6 h-6 text-[#00aeef] mx-auto mb-1" />
            <span className="text-2xl font-extrabold font-mono text-white block">159</span>
            <span className="text-[10px] text-slate-300">Toll-free from UK phones</span>
          </div>
        </div>
      </div>
    </div>
  );
};
