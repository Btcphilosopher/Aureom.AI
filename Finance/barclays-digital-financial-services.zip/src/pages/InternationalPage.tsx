import React, { useState } from 'react';
import { Globe, ArrowRight, CheckCircle2, RefreshCw, Send, DollarSign, Euro, ShieldCheck } from 'lucide-react';
import { useBanking } from '../context/BankingContext';

export const InternationalPage: React.FC = () => {
  const { navigate } = useBanking();
  const [sendAmount, setSendAmount] = useState<number>(1000);
  const [targetCurrency, setTargetCurrency] = useState<'EUR' | 'USD' | 'AUD' | 'CAD'>('EUR');

  const exchangeRates = {
    EUR: 1.1515,
    USD: 1.2473,
    AUD: 1.8842,
    CAD: 1.7214,
  };

  const convertedAmount = sendAmount * exchangeRates[targetCurrency];
  const transferFee = 0.0; // fee-free transfers on premier

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-[#00395d] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              International Banking & FX
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              Move money worldwide with complete clarity.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              Send fast international payments to over 150 countries, hold balances across major world currencies, and access competitive wholesale FX rates.
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-16">
        {/* Live FX Transfer Calculator */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          <div className="max-w-2xl mb-6">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Live Currency Converter
            </span>
            <h2 className="text-2xl font-bold text-[#00395d] mt-1">International Transfer Estimator</h2>
            <p className="text-xs text-slate-600">
              Calculate indicative conversion rates for personal and business cross-border payments.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1.5">You send (GBP £)</label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400 font-bold">£</span>
                  <input
                    type="number"
                    min="50"
                    step="50"
                    value={sendAmount}
                    onChange={(e) => setSendAmount(Math.max(1, Number(e.target.value)))}
                    className="w-full pl-8 pr-4 py-2.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#00aeef] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1.5">Recipient receives</label>
                <div className="flex gap-2">
                  <select
                    value={targetCurrency}
                    onChange={(e) => setTargetCurrency(e.target.value as any)}
                    className="px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#00aeef]"
                  >
                    <option value="EUR">EUR (€)</option>
                    <option value="USD">USD ($)</option>
                    <option value="AUD">AUD (A$)</option>
                    <option value="CAD">CAD (C$)</option>
                  </select>
                  <div className="flex-1 px-4 py-2.5 bg-slate-100 rounded-lg text-sm font-mono font-bold text-slate-900 flex items-center">
                    {convertedAmount.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {targetCurrency}
                  </div>
                </div>
              </div>

              <div className="text-xs text-slate-500 pt-2 flex items-center gap-2">
                <RefreshCw className="w-3.5 h-3.5 text-[#00aeef]" />
                <span>Indicative interbank rate: 1 GBP = {exchangeRates[targetCurrency]} {targetCurrency}</span>
              </div>
            </div>

            <div className="bg-[#f2f7fa] p-6 rounded-xl border border-slate-200 space-y-4 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Barclays Transfer Fee:</span>
                <span className="font-bold text-emerald-700 font-mono">£0.00 (Premier & Online)</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Delivery Speed:</span>
                <span className="font-semibold text-slate-800">Same day or next working day</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Network Routing:</span>
                <span className="font-semibold text-slate-800">SEPA Instant / SWIFT GPI</span>
              </div>

              <div className="pt-4 border-t border-slate-200">
                <button
                  onClick={() => navigate('/login')}
                  className="w-full py-2.5 bg-[#00aeef] hover:bg-[#0098d3] text-white font-semibold rounded-lg text-xs transition-colors flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send International Payment</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Global Banking Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <Globe className="w-8 h-8 text-[#00395d] mb-4" />
            <h3 className="text-base font-bold text-slate-900">Multi-Currency Accounts</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Hold, convert and receive funds in over 15 major currencies with dedicated local IBANs and account numbers.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <ShieldCheck className="w-8 h-8 text-[#00395d] mb-4" />
            <h3 className="text-base font-bold text-slate-900">SWIFT GPI Tracking</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Track cross-border wire transfers in real time end-to-end with full transparency on intermediary bank routing.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <CheckCircle2 className="w-8 h-8 text-[#00395d] mb-4" />
            <h3 className="text-base font-bold text-slate-900">Expat & Overseas Banking</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Dedicated UK banking support for international residents, global professionals, and overseas property owners.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
