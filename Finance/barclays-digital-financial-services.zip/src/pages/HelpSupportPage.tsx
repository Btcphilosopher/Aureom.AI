import React, { useState } from 'react';
import { Search, ChevronDown, ChevronUp, HelpCircle, PhoneCall, ShieldAlert, MessageSquare, MapPin } from 'lucide-react';
import { FAQ_DATA } from '../data/mockBankingData';
import { useBanking } from '../context/BankingContext';

export const HelpSupportPage: React.FC = () => {
  const { navigate } = useBanking();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>('faq-1');

  const categories = ['All', 'Accounts', 'Payments', 'Cards', 'Mortgages', 'Security & Fraud', 'Digital Banking'];

  const filteredFaqs = FAQ_DATA.filter((faq) => {
    const matchesCategory = selectedCategory === 'All' || faq.category === selectedCategory;
    const matchesSearch =
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleFaq = (id: string) => {
    setExpandedFaqId(expandedFaqId === id ? null : id);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Banner */}
      <section className="bg-[#00395d] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Help & Support Centre
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              How can we assist you today?
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              Search verified banking answers, find self-service solutions, or learn how to report lost cards and suspicious communications.
            </p>

            {/* Search Box */}
            <div className="relative pt-4 max-w-xl">
              <Search className="absolute left-4 top-7 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search questions (e.g. switch, card freeze, 159, statement)..."
                className="w-full pl-12 pr-4 py-3 bg-white text-slate-900 rounded-xl shadow-md text-sm placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#00aeef]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-12">
        {/* Contact Pathways Box */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="p-3 bg-red-50 text-red-600 rounded-lg w-fit mb-3">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Emergency Fraud Helpline: 159</h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              If you receive a suspicious call or believe your account has been compromised, dial 159 directly from any UK landline or mobile to connect safely with your bank.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="p-3 bg-[#e8f2f8] text-[#00395d] rounded-lg w-fit mb-3">
              <MessageSquare className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Digital Support in the App</h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              Log in to the Barclays app to chat securely with a verified customer specialist with zero telephone wait times.
            </p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="p-3 bg-[#e8f2f8] text-[#00395d] rounded-lg w-fit mb-3">
              <MapPin className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">Branch & Banking Hubs</h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              Access over 200 shared British Banking Hubs and Barclays Local sites in libraries and community centres across the UK.
            </p>
          </div>
        </div>

        {/* FAQs Section */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4 mb-6">
            <h2 className="text-xl font-bold text-slate-900">Frequently Asked Questions</h2>

            {/* Filter pills */}
            <div className="flex flex-wrap gap-1.5">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                    selectedCategory === cat
                      ? 'bg-[#00395d] text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {filteredFaqs.length > 0 ? (
              filteredFaqs.map((faq) => {
                const isExpanded = expandedFaqId === faq.id;
                return (
                  <div key={faq.id} className="py-4">
                    <button
                      type="button"
                      onClick={() => toggleFaq(faq.id)}
                      className="w-full text-left flex items-center justify-between gap-4 group focus:outline-none"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-semibold text-slate-400 font-mono">[{faq.category}]</span>
                        <span className="text-sm font-semibold text-slate-900 group-hover:text-[#00aeef] transition-colors">
                          {faq.question}
                        </span>
                      </div>
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                    </button>

                    {isExpanded && (
                      <div className="mt-3 pl-12 pr-4 text-xs text-slate-600 leading-relaxed animate-in fade-in duration-150">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })
            ) : (
              <div className="py-12 text-center text-slate-500 text-xs">
                No matching answers found for &ldquo;{searchQuery}&rdquo;.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
