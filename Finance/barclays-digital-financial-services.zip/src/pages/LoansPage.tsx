import React from 'react';
import { Percent, CheckCircle2, ArrowRight, ShieldCheck, HelpCircle, FileText } from 'lucide-react';
import { LoanCalculator } from '../components/calculators/LoanCalculator';
import { useBanking } from '../context/BankingContext';

export const LoansPage: React.FC = () => {
  const { navigate } = useBanking();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header Banner */}
      <section className="bg-[#00395d] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Personal Borrowing
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              Personal loans with fixed repayments.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              Fund home renovations, consolidate existing commitments, or finance a vehicle with our competitive 6.1% APR representative rate on borrowing between £7,500 and £15,000.
            </p>

            <div className="pt-2 flex flex-wrap gap-4 text-xs text-slate-200">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#00aeef]" /> Soft search: check eligibility without credit score impact
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#00aeef]" /> No early settlement fees or charges
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-16">
        {/* 1. Interactive Loan Calculator */}
        <div>
          <div className="mb-6">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Interactive Repayment Model
            </span>
            <h2 className="text-2xl font-bold text-[#00395d] mt-1">Loan Repayment Calculator</h2>
            <p className="text-xs text-slate-600">
              Select your borrowing amount and repayment term to see illustrative monthly costs and total payable figures.
            </p>
          </div>
          <LoanCalculator />
        </div>

        {/* 2. Key Benefits Grid */}
        <div>
          <h2 className="text-2xl font-bold text-[#00395d] mb-6">Why Choose a Barclays Personal Loan?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
              <div className="p-3 bg-[#e8f2f8] text-[#00395d] rounded-lg w-fit mb-4">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Fixed Monthly Payments</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Your interest rate and monthly repayment amount remain fixed for the full lifetime of your loan, guaranteeing clear predictability.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
              <div className="p-3 bg-[#e8f2f8] text-[#00395d] rounded-lg w-fit mb-4">
                <Percent className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Zero Early Settlement Penalty</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Pay off your loan in part or in full at any time without punitive termination fees, reducing the total interest you pay.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
              <div className="p-3 bg-[#e8f2f8] text-[#00395d] rounded-lg w-fit mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Fast Funds Disbursement</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Existing Barclays current account customers approved online can receive funds transferred directly into their account in minutes.
              </p>
            </div>
          </div>
        </div>

        {/* 3. Representative Example Box */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 space-y-3 text-xs text-slate-600">
          <h4 className="font-bold text-slate-900 text-sm">Representative Example</h4>
          <p>
            Borrowing <strong>£10,000</strong> over <strong>36 months</strong> at an interest rate of <strong>6.1% p.a. (fixed)</strong> with a representative <strong>6.1% APR</strong>.
          </p>
          <p>
            Monthly repayment: <strong>£304.14</strong>. Total interest payable: <strong>£949.04</strong>. Total amount repayable: <strong>£10,949.04</strong>.
          </p>
          <p className="text-[11px] text-slate-400 pt-2 border-t border-slate-100">
            Credit is subject to status and affordability. The rate offered may differ based on loan amount, duration and your personal credit history.
          </p>
        </div>
      </div>
    </div>
  );
};
