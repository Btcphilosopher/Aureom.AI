import React, { useState } from 'react';
import {
  ArrowRight,
  Shield,
  Lock,
  Eye,
  EyeOff,
  CheckCircle2,
  TrendingUp,
  Landmark,
  PiggyBank,
  Home,
  Percent,
  CreditCard,
  Briefcase,
  Layers,
  Sparkles,
  Globe,
  ChevronRight,
  ShieldCheck,
  Building2,
  Leaf,
} from 'lucide-react';
import { useBanking } from '../context/BankingContext';
import { MARKET_DATA_QUOTES, INSIGHT_ARTICLES } from '../data/mockBankingData';
import { RoutePath } from '../types/banking';

export const HomePage: React.FC = () => {
  const { navigate, loginAsDemoUser, isLoggedIn } = useBanking();

  // Login widget on hero state
  const [loginSegment, setLoginSegment] = useState<'personal' | 'business' | 'wealth'>('personal');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Market data tab state
  const [marketTab, setMarketTab] = useState<'FX' | 'Rates' | 'Commodities' | 'Equities'>('FX');

  const filteredQuotes = MARKET_DATA_QUOTES.filter((q) => q.category === marketTab);

  const handleQuickDemoLogin = (e: React.FormEvent) => {
    e.preventDefault();
    loginAsDemoUser();
  };

  return (
    <div className="min-h-screen bg-white">
      {/* 1. Flagship Hero Section */}
      <section className="relative bg-[#001726] text-white overflow-hidden">
        {/* Background photo overlay */}
        <div className="absolute inset-0 z-0 opacity-40">
          <img
            src="/assets/aistudio/60fecf47-d824-474d-bd76-c72f6c684e5e_e89d0343.png"
            alt="London Financial District Skyline at Twilight"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#001726] via-[#001726]/85 to-[#001726]/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-8 py-16 sm:py-24 lg:py-28">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content Column */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-bold tracking-[0.15em] text-[#00aeef] uppercase">
                <span className="w-6 h-[2px] bg-[#00aeef]" />
                <span>BRITISH BANKING & INFRASTRUCTURE</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.08] text-balance">
                Powering the UK’s financial infrastructure.
              </h1>

              <p className="text-base sm:text-lg text-slate-300 max-w-2xl font-light leading-relaxed">
                Barclays provides secure, scalable and innovative financial services designed around your needs — from everyday personal banking and mortgages to enterprise treasury and wealth management.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-4">
                <button
                  onClick={() => navigate('/personal')}
                  className="px-6 py-3.5 text-sm font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] active:bg-[#0086bc] rounded-lg transition-all shadow-md hover:shadow-lg flex items-center gap-2 group"
                >
                  <span>Explore banking</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>

                <button
                  onClick={() => navigate('/calculators')}
                  className="px-6 py-3.5 text-sm font-semibold text-slate-200 hover:text-white bg-white/10 hover:bg-white/15 border border-white/20 rounded-lg transition-all backdrop-blur-xs flex items-center gap-2"
                >
                  <span>Financial calculators</span>
                </button>
              </div>

              {/* Regulatory assurance teaser */}
              <div className="pt-6 flex flex-wrap items-center gap-6 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#00aeef]" />
                  <span>Authorised PRA & Regulated FCA</span>
                </div>
                <span>·</span>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#00aeef]" />
                  <span>FSCS Protected to £85,000</span>
                </div>
              </div>
            </div>

            {/* Right Hero: Authentic Client Login Card (Directly inspired by screenshot) */}
            <div className="lg:col-span-5">
              <div className="bg-[#001b30]/90 backdrop-blur-md rounded-2xl border border-white/15 p-6 sm:p-7 shadow-2xl text-slate-100">
                <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-5">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-[#00aeef]/10 text-[#00aeef]">
                      <Lock className="w-4 h-4" />
                    </div>
                    <div>
                      <h2 className="text-base font-bold text-white tracking-tight">Secure Sign In</h2>
                      <span className="text-[11px] text-slate-400">Barclays Online Services</span>
                    </div>
                  </div>
                  <span className="text-[10px] uppercase font-mono tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Live Demo
                  </span>
                </div>

                {/* Segment Tabs */}
                <div className="grid grid-cols-3 gap-1 p-1 bg-white/5 rounded-lg mb-5 border border-white/10">
                  <button
                    type="button"
                    onClick={() => setLoginSegment('personal')}
                    className={`py-1.5 text-xs font-semibold rounded transition-colors ${
                      loginSegment === 'personal'
                        ? 'bg-[#00aeef] text-white shadow-sm'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    Personal
                  </button>
                  <button
                    type="button"
                    onClick={() => setLoginSegment('business')}
                    className={`py-1.5 text-xs font-semibold rounded transition-colors ${
                      loginSegment === 'business'
                        ? 'bg-[#00aeef] text-white shadow-sm'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    Business
                  </button>
                  <button
                    type="button"
                    onClick={() => setLoginSegment('wealth')}
                    className={`py-1.5 text-xs font-semibold rounded transition-colors ${
                      loginSegment === 'wealth'
                        ? 'bg-[#00aeef] text-white shadow-sm'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    Wealth
                  </button>
                </div>

                <form onSubmit={handleQuickDemoLogin} className="space-y-4">
                  <div>
                    <label className="text-xs font-medium text-slate-300 block mb-1.5">
                      Membership number or Card number
                    </label>
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="e.g. 2094 8192 01"
                      className="w-full px-3.5 py-2.5 bg-black/30 border border-white/20 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-[#00aeef] focus:ring-1 focus:ring-[#00aeef]"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-medium text-slate-300 block mb-1.5">
                      Passcode or PINsentry key
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter 5-digit passcode"
                        className="w-full px-3.5 py-2.5 bg-black/30 border border-white/20 rounded-lg text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-[#00aeef] focus:ring-1 focus:ring-[#00aeef]"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#00aeef] hover:bg-[#0098d3] active:bg-[#0086bc] text-white font-semibold text-sm rounded-lg transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    <span>Launch Demonstration Banking</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>

                {/* Sub links */}
                <div className="flex items-center justify-between pt-4 mt-4 border-t border-white/10 text-xs text-slate-400">
                  <button
                    onClick={() => navigate('/login')}
                    className="hover:text-white transition-colors underline-offset-4 hover:underline"
                  >
                    Forgotten details?
                  </button>
                  <button
                    onClick={() => navigate('/help')}
                    className="hover:text-white transition-colors"
                  >
                    Help & sign in support &rsaquo;
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Capability Cards Row (Matches Screenshot layout) */}
      <section className="bg-white border-b border-slate-200 py-10 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {/* Card 1 */}
            <div
              onClick={() => navigate('/personal')}
              className="p-6 rounded-xl border border-slate-200/80 hover:border-[#00aeef] bg-white hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-4">
                  <Layers className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 group-hover:text-[#00395d]">
                  Payments & Collections
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Move money across the UK and globally securely, in real time.
                </p>
              </div>
              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center gap-1 text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Learn more</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>

            {/* Card 2 */}
            <div
              onClick={() => navigate('/loans')}
              className="p-6 rounded-xl border border-slate-200/80 hover:border-[#00aeef] bg-white hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-4">
                  <Building2 className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 group-hover:text-[#00395d]">
                  Lending & Credit
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Flexible financing solutions for growth and working capital.
                </p>
              </div>
              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center gap-1 text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Learn more</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>

            {/* Card 3 */}
            <div
              onClick={() => navigate('/wealth')}
              className="p-6 rounded-xl border border-slate-200/80 hover:border-[#00aeef] bg-white hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-4">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 group-hover:text-[#00395d]">
                  Treasury & Markets
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Institutional expertise, currency hedging and macro liquidity.
                </p>
              </div>
              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center gap-1 text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Learn more</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>

            {/* Card 4 */}
            <div
              onClick={() => navigate('/dashboard')}
              className="p-6 rounded-xl border border-slate-200/80 hover:border-[#00aeef] bg-white hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-4">
                  <Globe className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 group-hover:text-[#00395d]">
                  Digital Banking Platform
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Open banking APIs, instant transfers and biometric controls.
                </p>
              </div>
              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center gap-1 text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Launch demo</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>

            {/* Card 5 */}
            <div
              onClick={() => navigate('/about')}
              className="p-6 rounded-xl border border-slate-200/80 hover:border-[#00aeef] bg-white hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-4">
                  <Leaf className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 group-hover:text-[#00395d]">
                  Sustainable Finance
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Financing the transition to a net zero economy across the UK.
                </p>
              </div>
              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center gap-1 text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Learn more</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Markets At A Glance & Latest Insights (Matches Screenshot) */}
      <section className="bg-[#001726] text-white py-12 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left: Markets at a glance */}
            <div className="lg:col-span-5 bg-[#001f35] rounded-xl p-6 border border-white/10">
              <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Markets at a Glance
                </span>
                <div className="flex items-center gap-2">
                  {(['FX', 'Rates', 'Commodities', 'Equities'] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setMarketTab(tab)}
                      className={`text-xs px-2.5 py-1 rounded transition-colors ${
                        marketTab === tab
                          ? 'bg-[#00aeef] text-white font-semibold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>

              <div className="divide-y divide-white/5 font-mono text-xs">
                {filteredQuotes.map((quote) => (
                  <div key={quote.symbol} className="py-2.5 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-white block">{quote.symbol}</span>
                      <span className="text-[11px] text-slate-400 font-sans">{quote.name}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-white font-medium block">{quote.price}</span>
                      <span
                        className={`text-[11px] font-semibold ${
                          quote.isPositive ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {quote.change} ({quote.percentChange})
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 mt-3 border-t border-white/10 flex justify-between items-center text-xs">
                <button
                  onClick={() => navigate('/wealth')}
                  className="text-[#00aeef] hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>View all market data</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <span className="text-slate-500 text-[10px]">Indicative UK Pricing</span>
              </div>
            </div>

            {/* Center: Latest Insights */}
            <div className="lg:col-span-4 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Latest Insights
                </span>
                <button
                  onClick={() => navigate('/about')}
                  className="text-xs text-[#00aeef] hover:underline flex items-center gap-1"
                >
                  <span>View all</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <div className="space-y-3">
                {INSIGHT_ARTICLES.map((article) => (
                  <div
                    key={article.id}
                    onClick={() => navigate('/about')}
                    className="p-3.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 transition-all cursor-pointer group"
                  >
                    <div className="flex items-center gap-2 text-[11px] text-[#00aeef] mb-1 font-medium">
                      <span>{article.category}</span>
                      <span className="text-slate-500">·</span>
                      <span className="text-slate-400">{article.date}</span>
                    </div>
                    <h4 className="text-xs sm:text-sm font-semibold text-white group-hover:text-[#00aeef] transition-colors line-clamp-2">
                      {article.title}
                    </h4>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Architectural Purpose Spotlight (Matches Screenshot) */}
            <div className="lg:col-span-3 relative rounded-xl overflow-hidden border border-white/10 flex flex-col justify-end p-6 min-h-[260px] group">
              <img
                src="/src/assets/images/london_canary_wharf_hq_1792488155793.jpg"
                alt="One Churchill Place Headquarters Canary Wharf"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#001726] via-[#001726]/70 to-transparent" />

              <div className="relative z-10 space-y-2">
                <span className="text-[10px] font-bold tracking-widest text-[#00aeef] uppercase">
                  FOR A STRONGER TOMORROW
                </span>
                <h4 className="text-lg font-bold text-white leading-tight">
                  Innovation. Expertise. Partnership.
                </h4>
                <p className="text-xs text-slate-300 leading-snug">
                  We combine deep sector knowledge with cutting-edge technology to help our clients build lasting value.
                </p>
                <button
                  onClick={() => navigate('/about')}
                  className="pt-2 text-xs font-semibold text-[#00aeef] hover:underline flex items-center gap-1.5"
                >
                  <span>Our purpose</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Product Discovery Grid */}
      <section className="py-16 sm:py-24 px-4 sm:px-8 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
            <span className="text-xs font-bold text-[#00aeef] tracking-wider uppercase">
              Financial Solutions
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#00395d] mt-2 tracking-tight">
              Comprehensive banking, engineered for every stage.
            </h2>
            <p className="text-sm text-slate-600 mt-3">
              Explore our transparent product suites with market-leading digital tools, clear terms and verified rates.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Current Accounts */}
            <div
              onClick={() => navigate('/current-accounts')}
              className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-5">
                  <Landmark className="w-6 h-6" />
                </div>
                <div className="text-xs font-semibold text-emerald-700 bg-emerald-50 inline-block px-2 py-0.5 rounded mb-2">
                  £175 Switch Guarantee Available
                </div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-[#00395d]">
                  Current Accounts
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  Premier, Everyday and Student accounts with contactless debit cards, zero monthly account fees and 24/7 UK app controls.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Compare accounts</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Savings & ISAs */}
            <div
              onClick={() => navigate('/savings')}
              className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-5">
                  <PiggyBank className="w-6 h-6" />
                </div>
                <div className="text-xs font-semibold text-[#00395d] bg-[#e8f2f8] inline-block px-2 py-0.5 rounded mb-2">
                  Up to 5.12% AER (Variable)
                </div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-[#00395d]">
                  Savings & ISAs
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  Earn competitive returns on balances with the Blue Rewards Rainy Day Saver, 1-Year Fixed Cash ISAs, and instant access pots.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Explore savings rates</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Mortgages */}
            <div
              onClick={() => navigate('/mortgages')}
              className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-5">
                  <Home className="w-6 h-6" />
                </div>
                <div className="text-xs font-semibold text-[#00395d] bg-slate-100 inline-block px-2 py-0.5 rounded mb-2">
                  First-Time Buyers & Movers
                </div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-[#00395d]">
                  Mortgages
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  Fixed and tracker rate mortgages tailored for first homes, remortgaging and green home energy efficiency discounts.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Calculate repayments</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Personal Loans */}
            <div
              onClick={() => navigate('/loans')}
              className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-5">
                  <Percent className="w-6 h-6" />
                </div>
                <div className="text-xs font-semibold text-emerald-700 bg-emerald-50 inline-block px-2 py-0.5 rounded mb-2">
                  6.1% APR Representative
                </div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-[#00395d]">
                  Personal Loans
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  Borrow from £1,000 to £50,000 with fixed monthly repayments, instant credit decisioning and zero early repayment charges.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Loan calculator</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Barclaycard Credit Cards */}
            <div
              onClick={() => navigate('/credit-cards')}
              className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-5">
                  <CreditCard className="w-6 h-6" />
                </div>
                <div className="text-xs font-semibold text-[#00395d] bg-[#e8f2f8] inline-block px-2 py-0.5 rounded mb-2">
                  0% Balance Transfer & Rewards
                </div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-[#00395d]">
                  Barclaycard Credit Cards
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  Spread major balances interest-free, earn Avios flight rewards, or benefit from zero transaction fees abroad.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Find my card</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Wealth Management */}
            <div
              onClick={() => navigate('/wealth')}
              className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors flex items-center justify-center mb-5">
                  <Briefcase className="w-6 h-6" />
                </div>
                <div className="text-xs font-semibold text-amber-800 bg-amber-50 inline-block px-2 py-0.5 rounded mb-2">
                  Private Advisory & Smart Investor
                </div>
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-[#00395d]">
                  Wealth & Investing
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
                  Tailored discretionary management, Stocks & Shares ISAs, and institutional custody for high-net-worth individuals and families.
                </p>
              </div>
              <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
                <span>Discover wealth services</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Everyday Banking Feature Showcase */}
      <section className="py-16 sm:py-24 px-4 sm:px-8 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-6 space-y-6">
              <span className="text-xs font-bold text-[#00aeef] tracking-wider uppercase">
                Everyday Money Management
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#00395d] tracking-tight">
                Control your finances with precision in real time.
              </h2>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                Whether you are checking balances on the train, splitting bills with friends, freezing a misplaced card, or reviewing itemised PDF statements, the Barclays digital experience is built for total peace of mind.
              </p>

              <div className="space-y-4 pt-2">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-[#e8f2f8] text-[#00395d] shrink-0 mt-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Instant Card Controls</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Freeze cards instantly, adjust contactless transaction limits, or disable online purchases with one tap.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-[#e8f2f8] text-[#00395d] shrink-0 mt-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Confirmation of Payee</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      UK bank-grade name verification before every transfer ensures your money reaches exactly who you intend.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-[#e8f2f8] text-[#00395d] shrink-0 mt-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Categorised Spending Insights</h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Real-time breakdown of groceries, transport, bills and subscriptions to help you budget effortlessly.
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex gap-4">
                <button
                  onClick={() => navigate('/dashboard')}
                  className="px-6 py-3 text-sm font-semibold text-white bg-[#00395d] hover:bg-[#00263e] rounded-lg transition-colors flex items-center gap-2"
                >
                  <span>Try Online Banking Demo</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Right: Mock UI Showcase preview */}
            <div className="lg:col-span-6 bg-[#f2f7fa] rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-inner">
              <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
                <div className="bg-[#00395d] text-white p-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                    <span className="text-xs font-semibold">Premier Account · 20-00-00 84920145</span>
                  </div>
                  <span className="text-xs font-mono text-[#00aeef] font-semibold">Active</span>
                </div>
                <div className="p-5">
                  <div className="text-xs text-slate-500 font-medium">Available Balance</div>
                  <div className="text-3xl font-extrabold text-[#00395d] font-mono mt-1">
                    £4,820.45
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    Includes £500 interest-free arranged overdraft buffer
                  </div>

                  <div className="mt-5 pt-4 border-t border-slate-100 space-y-2.5">
                    <div className="text-[11px] font-bold uppercase text-slate-400">
                      Recent Verified Transactions
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <div>
                        <span className="font-semibold text-slate-900 block">Waitrose & Partners Canary Wharf</span>
                        <span className="text-[11px] text-slate-400">19 Oct · Groceries</span>
                      </div>
                      <span className="font-mono font-semibold text-slate-900">-£64.20</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                      <div>
                        <span className="font-semibold text-slate-900 block">Monthly Salary - BioPharma Labs Ltd</span>
                        <span className="text-[11px] text-slate-400">16 Oct · BACS Transfer</span>
                      </div>
                      <span className="font-mono font-semibold text-emerald-700">+£3,850.00</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Security Principles Section */}
      <section className="bg-[#001726] text-white py-16 sm:py-20 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-2xl mb-12">
            <span className="text-xs font-bold text-[#00aeef] tracking-wider uppercase">
              Trust & Security Architecture
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 tracking-tight">
              Bank-grade protection around the clock.
            </h2>
            <p className="text-sm text-slate-300 mt-2">
              Learn the standards we maintain to keep your accounts, payments, and private financial records safe.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#002238] p-6 rounded-xl border border-white/10">
              <div className="p-3 bg-[#00aeef]/10 text-[#00aeef] rounded-lg w-fit mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Barclays Fraud Guarantee</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                If you are a victim of fraud on your account that isn&apos;t your fault, we will reimburse the stolen money in full.
              </p>
            </div>

            <div className="bg-[#002238] p-6 rounded-xl border border-white/10">
              <div className="p-3 bg-[#00aeef]/10 text-[#00aeef] rounded-lg w-fit mb-4">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">PINsentry & Biometrics</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Two-factor authentication with hardware card readers and device biometrics ensures only you can authorise payments.
              </p>
            </div>

            <div className="bg-[#002238] p-6 rounded-xl border border-white/10">
              <div className="p-3 bg-[#00aeef]/10 text-[#00aeef] rounded-lg w-fit mb-4">
                <Shield className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">UK 159 Emergency Fraud Line</h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                Dial 159 from any UK telephone to connect directly with your bank if anyone contacts you claiming to be the police or fraud department.
              </p>
            </div>
          </div>

          <div className="mt-8 text-center">
            <button
              onClick={() => navigate('/security')}
              className="px-6 py-3 text-xs font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/20 rounded-lg transition-colors inline-flex items-center gap-2"
            >
              <span>Visit Fraud Prevention & Security Hub</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* 7. Final Call to Action */}
      <section className="bg-gradient-to-br from-[#00395d] to-[#002238] text-white py-16 sm:py-20 px-4 sm:px-8">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Ready to explore British banking built for what comes next?
          </h2>
          <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto">
            Switch your current account in 7 working days, model your next mortgage, or try our interactive demonstration online banking portal.
          </p>
          <div className="flex flex-wrap justify-center gap-4 pt-2">
            <button
              onClick={() => navigate('/current-accounts')}
              className="px-6 py-3 text-sm font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded-lg transition-all shadow-md"
            >
              Compare Current Accounts
            </button>
            <button
              onClick={() => navigate('/login')}
              className="px-6 py-3 text-sm font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/20 rounded-lg transition-all"
            >
              Sign In to Demonstration
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
