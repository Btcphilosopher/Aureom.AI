import React, { useState } from 'react';
import {
  Landmark,
  PiggyBank,
  CreditCard,
  ArrowUpRight,
  ArrowDownLeft,
  Send,
  Lock,
  Unlock,
  Sliders,
  FileText,
  Search,
  Filter,
  LogOut,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  X,
  Printer,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useBanking } from '../context/BankingContext';
import { BankAccount, Transaction } from '../types/banking';

export const DashboardDemoPage: React.FC = () => {
  const {
    user,
    accounts,
    transactions,
    logout,
    transferFunds,
    toggleCardFreeze,
    updateContactlessLimit,
    toggleOnlineTransactions,
  } = useBanking();

  // Selected account for deep view
  const [selectedAccountId, setSelectedAccountId] = useState<string>(accounts[0]?.id || 'acc-1');
  const [txSearch, setTxSearch] = useState('');
  const [txCategoryFilter, setTxCategoryFilter] = useState<string>('All');

  // Modals state
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isStatementModalOpen, setIsStatementModalOpen] = useState(false);

  // Transfer form state
  const [transferSource, setTransferSource] = useState<string>(accounts[0]?.id || 'acc-1');
  const [transferType, setTransferType] = useState<'internal' | 'external'>('internal');
  const [transferDestAcc, setTransferDestAcc] = useState<string>(accounts[1]?.id || 'acc-2');
  const [payeeName, setPayeeName] = useState('');
  const [payeeSortCode, setPayeeSortCode] = useState('20-00-00');
  const [payeeAccountNumber, setPayeeAccountNumber] = useState('');
  const [transferAmount, setTransferAmount] = useState<string>('150.00');
  const [transferReference, setTransferReference] = useState('Demo Transfer');
  const [transferFeedback, setTransferFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const selectedAccount = accounts.find((a) => a.id === selectedAccountId) || accounts[0];

  // Filtered transactions
  const accountTransactions = transactions.filter((tx) => {
    const matchesAccount = tx.accountId === selectedAccountId;
    const matchesCategory = txCategoryFilter === 'All' || tx.category === txCategoryFilter;
    const matchesSearch =
      tx.description.toLowerCase().includes(txSearch.toLowerCase()) ||
      (tx.reference && tx.reference.toLowerCase().includes(txSearch.toLowerCase()));
    return matchesAccount && matchesCategory && matchesSearch;
  });

  const handleExecuteTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(transferAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      setTransferFeedback({ type: 'error', message: 'Please enter a valid transfer amount.' });
      return;
    }

    const result = transferFunds({
      fromAccountId: transferSource,
      toType: transferType,
      toAccountId: transferType === 'internal' ? transferDestAcc : undefined,
      payeeName: transferType === 'external' ? payeeName : undefined,
      sortCode: transferType === 'external' ? payeeSortCode : undefined,
      accountNumber: transferType === 'external' ? payeeAccountNumber : undefined,
      amount: amountNum,
      reference: transferReference,
    });

    if (result.success) {
      setTransferFeedback({ type: 'success', message: result.message });
      setTimeout(() => {
        setIsTransferModalOpen(false);
        setTransferFeedback(null);
      }, 1800);
    } else {
      setTransferFeedback({ type: 'error', message: result.message });
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 pb-16">
      {/* Top Demo Notification Strip */}
      <div className="bg-[#002238] text-white px-4 py-2.5 text-xs border-b border-white/10">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-[#00aeef]">Demonstration Banking Sandbox:</span>
            <span className="text-slate-300">Logged in as {user?.name || 'Dr. Alistair Finch'} (Membership: {user?.membershipNumber || '2094 8192 01'})</span>
          </div>
          <button
            onClick={logout}
            className="flex items-center gap-1 text-slate-300 hover:text-white transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-8">
        {/* Welcome and Action Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div>
            <h1 className="text-2xl font-bold text-[#00395d]">Good morning, {user?.title || 'Dr.'} Finch</h1>
            <p className="text-xs text-slate-500 mt-1">
              Last authenticated: {user?.lastLogin || 'Today, 09:14 GMT'} · All transactions reconciled
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setTransferFeedback(null);
                setIsTransferModalOpen(true);
              }}
              className="px-4 py-2.5 bg-[#00aeef] hover:bg-[#0098d3] active:bg-[#0086bc] text-white font-semibold text-xs rounded-xl transition-all shadow-xs flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Make a Payment / Transfer</span>
            </button>
            <button
              onClick={() => setIsStatementModalOpen(true)}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-xl transition-colors flex items-center gap-2"
            >
              <FileText className="w-4 h-4" />
              <span>Generate Statement</span>
            </button>
          </div>
        </div>

        {/* Account Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {accounts.map((acc) => {
            const isSelected = acc.id === selectedAccountId;
            return (
              <div
                key={acc.id}
                onClick={() => setSelectedAccountId(acc.id)}
                className={`p-6 rounded-2xl border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                  isSelected
                    ? 'bg-white border-[#00395d] ring-2 ring-[#00aeef]/30 shadow-md'
                    : 'bg-white/80 border-slate-200 hover:border-slate-300 hover:bg-white'
                }`}
              >
                {acc.isFrozen && (
                  <div className="absolute top-3 right-3 bg-red-100 text-red-700 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    <span>CARD FROZEN</span>
                  </div>
                )}

                <div>
                  <div className="flex items-center gap-2.5 mb-3">
                    <div className="p-2 rounded-lg bg-[#e8f2f8] text-[#00395d]">
                      {acc.type === 'current' ? (
                        <Landmark className="w-5 h-5" />
                      ) : acc.type === 'savings' ? (
                        <PiggyBank className="w-5 h-5" />
                      ) : (
                        <CreditCard className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 leading-tight">{acc.name}</h3>
                      <span className="text-[11px] text-slate-500 font-mono">
                        {acc.sortCode} · {acc.accountNumber}
                      </span>
                    </div>
                  </div>

                  <div className="mt-4">
                    <span className="text-[11px] text-slate-500 font-medium block">
                      {acc.type === 'credit' ? 'Current Balance Owed' : 'Available Balance'}
                    </span>
                    <div
                      className={`text-2xl font-extrabold font-mono mt-0.5 ${
                        acc.balance < 0 ? 'text-slate-800' : 'text-[#00395d]'
                      }`}
                    >
                      £{Math.abs(acc.balance).toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                      {acc.balance < 0 && <span className="text-xs text-slate-500 font-normal ml-1">DR</span>}
                    </div>
                    {acc.interestRate && (
                      <span className="text-[11px] text-emerald-700 font-semibold block mt-1">
                        {acc.interestRate}
                      </span>
                    )}
                  </div>
                </div>

                <div className="pt-4 mt-5 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500">
                    {acc.type === 'credit'
                      ? 'Limit: £5,000.00'
                      : `Cleared: £${acc.balance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}`}
                  </span>
                  <span
                    className={`font-semibold ${
                      isSelected ? 'text-[#00aeef]' : 'text-slate-400'
                    }`}
                  >
                    {isSelected ? 'Viewing' : 'Select'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Account Deep Dive: Transactions & Card Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left: Transactions History Table */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  {selectedAccount.name} Activity
                </h3>
                <span className="text-xs text-slate-500 font-mono">
                  Sort Code: {selectedAccount.sortCode} · Account: {selectedAccount.accountNumber}
                </span>
              </div>

              {/* Filters */}
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    value={txSearch}
                    onChange={(e) => setTxSearch(e.target.value)}
                    placeholder="Search payees..."
                    className="pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#00aeef]"
                  />
                </div>
                <select
                  value={txCategoryFilter}
                  onChange={(e) => setTxCategoryFilter(e.target.value)}
                  className="px-2.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none"
                >
                  <option value="All">All Categories</option>
                  <option value="Groceries">Groceries</option>
                  <option value="Transport">Transport</option>
                  <option value="Bills & Utilities">Bills & Utilities</option>
                  <option value="Dining">Dining</option>
                  <option value="Income">Income</option>
                  <option value="Transfers">Transfers</option>
                </select>
              </div>
            </div>

            {/* Transactions List */}
            <div className="divide-y divide-slate-100 max-h-[480px] overflow-y-auto">
              {accountTransactions.length > 0 ? (
                accountTransactions.map((tx) => (
                  <div key={tx.id} className="py-3.5 flex items-center justify-between hover:bg-slate-50 px-2 rounded-lg transition-colors">
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-2 rounded-lg ${
                          tx.type === 'credit'
                            ? 'bg-emerald-50 text-emerald-700'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {tx.type === 'credit' ? (
                          <ArrowDownLeft className="w-4 h-4" />
                        ) : (
                          <ArrowUpRight className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <span className="text-xs sm:text-sm font-semibold text-slate-900 block">
                          {tx.description}
                        </span>
                        <div className="flex items-center gap-2 text-[11px] text-slate-500">
                          <span>{tx.date}</span>
                          <span>·</span>
                          <span className="bg-slate-100 px-1.5 py-0.5 rounded text-[10px] font-medium text-slate-600">
                            {tx.category}
                          </span>
                          {tx.reference && (
                            <>
                              <span>·</span>
                              <span className="font-mono text-[10px]">{tx.reference}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <span
                        className={`text-sm font-bold font-mono block ${
                          tx.type === 'credit' ? 'text-emerald-700' : 'text-slate-900'
                        }`}
                      >
                        {tx.type === 'credit' ? '+' : ''}£{Math.abs(tx.amount).toFixed(2)}
                      </span>
                      <span className="text-[10px] text-slate-400 capitalize">{tx.status}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="py-12 text-center text-xs text-slate-500">
                  No transactions found matching your criteria.
                </div>
              )}
            </div>
          </div>

          {/* Right: Security & Card Controls Panel */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
              <div className="flex items-center gap-2 text-xs font-bold text-[#00395d] uppercase tracking-wider">
                <Sliders className="w-4 h-4 text-[#00aeef]" />
                <span>Card Controls ({selectedAccount.name})</span>
              </div>

              {/* Freeze Card Switch */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    {selectedAccount.isFrozen ? (
                      <Lock className="w-4 h-4 text-red-600" />
                    ) : (
                      <Unlock className="w-4 h-4 text-emerald-600" />
                    )}
                    <span>Card Freeze</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {selectedAccount.isFrozen
                      ? 'Card is locked against purchases'
                      : 'Card is active for taps & ATMs'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => toggleCardFreeze(selectedAccount.id)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                    selectedAccount.isFrozen
                      ? 'bg-red-600 text-white'
                      : 'bg-slate-200 text-slate-800 hover:bg-slate-300'
                  }`}
                >
                  {selectedAccount.isFrozen ? 'Unfreeze' : 'Freeze'}
                </button>
              </div>

              {/* Contactless Limit */}
              {selectedAccount.contactlessLimit !== undefined && (
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-semibold text-slate-700">
                    <span>Contactless Spend Limit</span>
                    <span className="font-mono text-slate-900">£{selectedAccount.contactlessLimit}</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    step="10"
                    value={selectedAccount.contactlessLimit}
                    onChange={(e) => updateContactlessLimit(selectedAccount.id, Number(e.target.value))}
                    className="w-full accent-[#00395d]"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>£10</span>
                    <span>£100 (UK Maximum)</span>
                  </div>
                </div>
              )}

              {/* Online Transactions */}
              {selectedAccount.allowOnlineTransactions !== undefined && (
                <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                  <div>
                    <span className="text-xs font-semibold text-slate-900 block">Online & App Purchases</span>
                    <span className="text-[11px] text-slate-500">Allow e-commerce transactions</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => toggleOnlineTransactions(selectedAccount.id)}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                      selectedAccount.allowOnlineTransactions
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {selectedAccount.allowOnlineTransactions ? 'Enabled' : 'Disabled'}
                  </button>
                </div>
              )}
            </div>

            {/* Monthly Spending Breakdown by Category */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Monthly Spending Insight
              </h4>
              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-slate-600 mb-1">
                    <span>Groceries & Supermarkets</span>
                    <span className="font-mono font-semibold">£64.20 (21%)</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div className="bg-[#00395d] h-full" style={{ width: '21%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-slate-600 mb-1">
                    <span>Bills & Utilities</span>
                    <span className="font-mono font-semibold">£128.50 (42%)</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div className="bg-[#00aeef] h-full" style={{ width: '42%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-slate-600 mb-1">
                    <span>Dining & Hospitality</span>
                    <span className="font-mono font-semibold">£89.40 (29%)</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full" style={{ width: '29%' }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL 1: Live Transfer Funds Dialog */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="bg-[#00395d] text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Send className="w-4 h-4 text-[#00aeef]" />
                <h3 className="text-sm font-bold">Simulated Move Money & Transfer</h3>
              </div>
              <button
                onClick={() => setIsTransferModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExecuteTransfer} className="p-6 space-y-4">
              {transferFeedback && (
                <div
                  className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
                    transferFeedback.type === 'success'
                      ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                      : 'bg-rose-50 border border-rose-200 text-rose-800'
                  }`}
                >
                  {transferFeedback.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  )}
                  <span>{transferFeedback.message}</span>
                </div>
              )}

              {/* Source Account */}
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">From Account</label>
                <select
                  value={transferSource}
                  onChange={(e) => setTransferSource(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-[#00aeef]"
                >
                  {accounts.map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name} — £{acc.balance.toFixed(2)} (Available: £{acc.availableBalance.toFixed(2)})
                    </option>
                  ))}
                </select>
              </div>

              {/* Type Switcher */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setTransferType('internal')}
                  className={`py-1.5 text-xs font-semibold rounded-md transition-colors ${
                    transferType === 'internal'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Between Own Accounts
                </button>
                <button
                  type="button"
                  onClick={() => setTransferType('external')}
                  className={`py-1.5 text-xs font-semibold rounded-md transition-colors ${
                    transferType === 'external'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Pay Someone New (UK)
                </button>
              </div>

              {/* Destination Account / Payee */}
              {transferType === 'internal' ? (
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">To Account</label>
                  <select
                    value={transferDestAcc}
                    onChange={(e) => setTransferDestAcc(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none"
                  >
                    {accounts
                      .filter((a) => a.id !== transferSource)
                      .map((acc) => (
                        <option key={acc.id} value={acc.id}>
                          {acc.name} — £{acc.balance.toFixed(2)}
                        </option>
                      ))}
                  </select>
                </div>
              ) : (
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Payee Legal Name</label>
                    <input
                      type="text"
                      value={payeeName}
                      onChange={(e) => setPayeeName(e.target.value)}
                      placeholder="e.g. Eleanor Vance"
                      required
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#00aeef]"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">Sort Code</label>
                      <input
                        type="text"
                        value={payeeSortCode}
                        onChange={(e) => setPayeeSortCode(e.target.value)}
                        placeholder="20-00-00"
                        required
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">Account Number</label>
                      <input
                        type="text"
                        value={payeeAccountNumber}
                        onChange={(e) => setPayeeAccountNumber(e.target.value)}
                        placeholder="12345678"
                        required
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg font-mono focus:outline-none"
                      />
                    </div>
                  </div>
                  <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Confirmation of Payee will verify recipient account name</span>
                  </div>
                </div>
              )}

              {/* Amount and Reference */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Amount (£)</label>
                  <div className="relative">
                    <span className="absolute left-2.5 top-2 text-slate-400 font-bold text-xs">£</span>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={transferAmount}
                      onChange={(e) => setTransferAmount(e.target.value)}
                      required
                      className="w-full pl-6 pr-3 py-2 text-xs border border-slate-300 rounded-lg font-mono font-bold focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Payment Reference</label>
                  <input
                    type="text"
                    value={transferReference}
                    onChange={(e) => setTransferReference(e.target.value)}
                    placeholder="e.g. Dinner share"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsTransferModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#00aeef] hover:bg-[#0098d3] text-white font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Execute Simulated Payment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Formal Bank Statement Generator */}
      {isStatementModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="bg-[#00395d] text-white p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2 text-xs font-semibold">
                <FileText className="w-4 h-4 text-[#00aeef]" />
                <span>Synthetic Bank Statement Preview</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="p-1.5 bg-white/10 hover:bg-white/20 rounded-md text-xs flex items-center gap-1"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setIsStatementModalOpen(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Statement Printable Body */}
            <div className="p-8 overflow-y-auto space-y-6 text-slate-900 font-sans text-xs">
              <div className="flex justify-between items-start border-b border-slate-200 pb-6">
                <div>
                  <div className="font-display font-extrabold text-xl text-[#00aeef] tracking-wider uppercase mb-1">
                    BARCLAYS
                  </div>
                  <div className="text-[11px] text-slate-500 leading-tight">
                    Barclays Bank UK PLC<br />
                    Canary Wharf Branch<br />
                    1 Churchill Place, London E14 5HP
                  </div>
                </div>
                <div className="text-right text-[11px] space-y-0.5">
                  <div className="font-bold text-slate-900 text-sm">STATEMENT OF ACCOUNT</div>
                  <div className="text-slate-500">Statement Date: 20 October 2026</div>
                  <div className="font-mono">Sort Code: {selectedAccount.sortCode}</div>
                  <div className="font-mono">Account Number: {selectedAccount.accountNumber}</div>
                </div>
              </div>

              {/* Customer details */}
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 text-xs flex justify-between">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Account Holder:</span>
                  <span className="font-bold text-slate-900">Dr. Alistair Finch</span>
                  <div className="text-slate-500 text-[11px]">Flat 4B, 18 West India Quay, London E14 4AL</div>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Closing Balance:</span>
                  <span className="text-base font-extrabold font-mono text-[#00395d]">
                    £{selectedAccount.balance.toLocaleString('en-GB', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              {/* Itemized Entries */}
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-300 text-slate-700 font-bold bg-slate-100">
                    <th className="py-2 px-3">Date</th>
                    <th className="py-2 px-3">Description</th>
                    <th className="py-2 px-3 text-right">In (£)</th>
                    <th className="py-2 px-3 text-right">Out (£)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                  {accountTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-slate-600">{tx.date}</td>
                      <td className="py-2 px-3 font-sans font-medium text-slate-900">{tx.description}</td>
                      <td className="py-2 px-3 text-right text-emerald-700">
                        {tx.type === 'credit' ? tx.amount.toFixed(2) : '-'}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-900">
                        {tx.type === 'debit' ? Math.abs(tx.amount).toFixed(2) : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="pt-4 border-t border-slate-200 text-[10px] text-slate-400 text-center">
                This is a synthetic demonstration statement generated for software verification purposes. Eligible deposits are protected up to £85,000 by the Financial Services Compensation Scheme.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
