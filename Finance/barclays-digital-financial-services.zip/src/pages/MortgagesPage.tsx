import React from 'react';
import { Home, CheckCircle2, ArrowRight, ShieldCheck, Leaf, Info, HelpCircle } from 'lucide-react';
import { MortgageCalculator } from '../components/calculators/MortgageCalculator';
import { useBanking } from '../context/BankingContext';

export const MortgagesPage: React.FC = () => {
  const { navigate } = useBanking();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero Banner with Editorial British Home Photography */}
      <section className="relative bg-[#002238] text-white overflow-hidden py-16 sm:py-20 px-4 sm:px-8">
        <div className="absolute inset-0 z-0 opacity-30">
          <img
            src="/src/assets/images/british_family_home_mortgage_1792488156883.jpg"
            alt="Contemporary British Home Architecture"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#002238] via-[#002238]/85 to-[#002238]/50" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="max-w-2xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Mortgages & Home Ownership
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              A mortgage designed around the home you want.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              From competitive fixed rates for first-time buyers to flexible remortgages and our Green Home Mortgage discounts — let our mortgage experts guide your journey.
            </p>

            <div className="pt-2 flex flex-wrap gap-4 text-xs text-slate-300">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#00aeef]" /> Agreement in Principle in 15 minutes
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#00aeef]" /> Lock in a rate up to 6 months in advance
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-16">
        {/* 1. Calculator Section */}
        <div>
          <div className="mb-6">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Financial Modelling
            </span>
            <h2 className="text-2xl font-bold text-[#00395d] mt-1">Calculate Your Mortgage Repayments</h2>
            <p className="text-xs text-slate-600">
              Adjust purchase price, cash deposit, interest rate and duration to view exact monthly repayments and loan-to-value (LTV).
            </p>
          </div>
          <MortgageCalculator />
        </div>

        {/* 2. Customer Journeys */}
        <div>
          <h2 className="text-2xl font-bold text-[#00395d] mb-8">Mortgage Solutions for Every Stage</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* First-Time Buyers */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs hover:border-[#00aeef] transition-all flex flex-col justify-between">
              <div>
                <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded">
                  From 5% Deposit
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-3">First-Time Buyers</h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Step onto the UK property ladder with 95% LTV mortgage options, dedicated first-time buyer specialists, and fee-free standard property valuations.
                </p>
                <ul className="mt-4 space-y-1.5 text-xs text-slate-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Family Springboard options available</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Agreement in Principle without credit score damage</span>
                  </li>
                </ul>
              </div>
              <div className="pt-4 mt-6 border-t border-slate-100">
                <button
                  onClick={() => navigate('/login')}
                  className="w-full py-2 text-xs font-semibold text-[#00395d] bg-[#f2f7fa] hover:bg-[#e8f2f8] rounded-lg transition-colors flex items-center justify-center gap-1"
                >
                  <span>First-time buyer guide</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Remortgaging */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs hover:border-[#00aeef] transition-all flex flex-col justify-between">
              <div>
                <span className="text-[11px] font-semibold text-[#00395d] bg-[#e8f2f8] px-2.5 py-0.5 rounded">
                  Lock Up to 180 Days Early
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-3">Remortgage to Barclays</h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Moving your existing mortgage to Barclays is straightforward. Secure your new fixed rate up to 6 months before your current deal expires with zero remortgage legal fees.
                </p>
                <ul className="mt-4 space-y-1.5 text-xs text-slate-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Free standard legal work on qualifying transfers</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Switch deals online with zero broker charges</span>
                  </li>
                </ul>
              </div>
              <div className="pt-4 mt-6 border-t border-slate-100">
                <button
                  onClick={() => navigate('/login')}
                  className="w-full py-2 text-xs font-semibold text-[#00395d] bg-[#f2f7fa] hover:bg-[#e8f2f8] rounded-lg transition-colors flex items-center justify-center gap-1"
                >
                  <span>Remortgage options</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Green Home Mortgage */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs hover:border-[#00aeef] transition-all flex flex-col justify-between">
              <div>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded flex items-center gap-1 w-fit">
                  <Leaf className="w-3 h-3 text-emerald-600" />
                  <span>Green Living Perk</span>
                </span>
                <h3 className="text-lg font-bold text-slate-900 mt-3">Green Home Mortgages</h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Buy an energy-efficient home (EPC rating A or B) and receive a preferential discounted interest rate for the duration of your initial fixed period.
                </p>
                <ul className="mt-4 space-y-1.5 text-xs text-slate-600">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>0.10% discount on fixed-rate deals</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Available on new-build and qualifying existing homes</span>
                  </li>
                </ul>
              </div>
              <div className="pt-4 mt-6 border-t border-slate-100">
                <button
                  onClick={() => navigate('/login')}
                  className="w-full py-2 text-xs font-semibold text-[#00395d] bg-[#f2f7fa] hover:bg-[#e8f2f8] rounded-lg transition-colors flex items-center justify-center gap-1"
                >
                  <span>Explore Green Mortgages</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 3. LTV & Terminology Guide */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 space-y-4">
          <h3 className="text-lg font-bold text-slate-900">Understanding Loan-to-Value (LTV)</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Loan-to-Value (LTV) is the percentage of your property’s value that you borrow as a mortgage. For example, if you purchase a home valued at £300,000 with a £60,000 deposit (20%), your loan is £240,000, which equals an 80% LTV.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
            <div className="p-3 bg-slate-50 rounded-lg text-center">
              <span className="text-xs font-mono font-bold text-[#00395d] block">60% LTV</span>
              <span className="text-[11px] text-slate-500">Lowest interest rates</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg text-center">
              <span className="text-xs font-mono font-bold text-[#00395d] block">75% LTV</span>
              <span className="text-[11px] text-slate-500">Competitive mainstream</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg text-center">
              <span className="text-xs font-mono font-bold text-[#00395d] block">85% LTV</span>
              <span className="text-[11px] text-slate-500">Moderate deposit</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg text-center">
              <span className="text-xs font-mono font-bold text-[#00395d] block">95% LTV</span>
              <span className="text-[11px] text-slate-500">First-time buyers (5% deposit)</span>
            </div>
          </div>
        </div>

        {/* Warning Callout */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 text-xs text-amber-900 flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong>YOUR HOME MAY BE REPOSSESSED IF YOU DO NOT KEEP UP REPAYMENTS ON YOUR MORTGAGE.</strong>
            <p>
              Barclays Bank UK PLC is authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority. All applications are subject to status, property valuation and financial underwriting.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
