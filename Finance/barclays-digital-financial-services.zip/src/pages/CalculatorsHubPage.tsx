import React, { useState } from 'react';
import { Home, PiggyBank, Percent, CreditCard, Wallet, Calculator } from 'lucide-react';
import { MortgageCalculator } from '../components/calculators/MortgageCalculator';
import { SavingsCalculator } from '../components/calculators/SavingsCalculator';
import { LoanCalculator } from '../components/calculators/LoanCalculator';
import { CreditCardPayoffCalculator } from '../components/calculators/CreditCardPayoffCalculator';
import { BudgetPlanner } from '../components/calculators/BudgetPlanner';

export const CalculatorsHubPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'mortgage' | 'savings' | 'loan' | 'creditCard' | 'budget'>('mortgage');

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Banner */}
      <section className="bg-[#00395d] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              <Calculator className="w-4 h-4" />
              <span>Financial Tools & Analytics</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              Central Financial Calculator Suite
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              Empower your financial decisions with validated calculations. Model mortgages, compound savings growth, personal borrowing, credit card payoffs and household cash flow.
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-8">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2 p-1.5 bg-white rounded-xl border border-slate-200 shadow-xs">
          <button
            onClick={() => setActiveTab('mortgage')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'mortgage'
                ? 'bg-[#00395d] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Home className="w-4 h-4 text-[#00aeef]" />
            <span>Mortgage Repayments</span>
          </button>

          <button
            onClick={() => setActiveTab('savings')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'savings'
                ? 'bg-[#00395d] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <PiggyBank className="w-4 h-4 text-[#00aeef]" />
            <span>Savings & Compounding</span>
          </button>

          <button
            onClick={() => setActiveTab('loan')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'loan'
                ? 'bg-[#00395d] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Percent className="w-4 h-4 text-[#00aeef]" />
            <span>Personal Loan</span>
          </button>

          <button
            onClick={() => setActiveTab('creditCard')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'creditCard'
                ? 'bg-[#00395d] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <CreditCard className="w-4 h-4 text-[#00aeef]" />
            <span>Credit Card Payoff</span>
          </button>

          <button
            onClick={() => setActiveTab('budget')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'budget'
                ? 'bg-[#00395d] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Wallet className="w-4 h-4 text-[#00aeef]" />
            <span>50/30/20 Budget Planner</span>
          </button>
        </div>

        {/* Selected Calculator Container */}
        <div>
          {activeTab === 'mortgage' && <MortgageCalculator />}
          {activeTab === 'savings' && <SavingsCalculator />}
          {activeTab === 'loan' && <LoanCalculator />}
          {activeTab === 'creditCard' && <CreditCardPayoffCalculator />}
          {activeTab === 'budget' && <BudgetPlanner />}
        </div>
      </div>
    </div>
  );
};
