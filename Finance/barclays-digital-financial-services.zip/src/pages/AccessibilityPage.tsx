import React from 'react';
import { CheckCircle2, ShieldCheck } from 'lucide-react';

export const AccessibilityPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 py-16 px-4 sm:px-8">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl border border-slate-200 p-8 sm:p-12 shadow-xs space-y-8">
        <div>
          <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
            Digital Inclusion
          </span>
          <h1 className="text-3xl font-extrabold text-[#00395d] mt-1">Accessibility Statement</h1>
          <p className="text-xs text-slate-500 mt-2">
            Targeting Web Content Accessibility Guidelines (WCAG) 2.2 Level AA compliance
          </p>
        </div>

        <div className="space-y-6 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">1. Our Accessibility Principles</h2>
            <p>
              Barclays is committed to making digital banking accessible to everyone, including people who rely on screen readers, keyboard-only navigation, speech recognition software, or high-contrast display modes.
            </p>
          </section>

          <section className="space-y-3">
            <h2 className="text-base font-bold text-slate-900">2. Technical Measures Implemented</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex items-center gap-2 font-semibold text-slate-900 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Semantic HTML5 Elements</span>
                </div>
                <p className="text-xs text-slate-600">
                  Landmarks (&lt;header&gt;, &lt;nav&gt;, &lt;main&gt;, &lt;footer&gt;) ensure intuitive assistive navigation.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex items-center gap-2 font-semibold text-slate-900 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Visible Focus Indicators</span>
                </div>
                <p className="text-xs text-slate-600">
                  All interactive controls provide high-contrast visible focus rings for keyboard users.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex items-center gap-2 font-semibold text-slate-900 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Color Contrast (4.5:1+)</span>
                </div>
                <p className="text-xs text-slate-600">
                  Text colors rigorously meet WCAG AA contrast standards against backgrounds.
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex items-center gap-2 font-semibold text-slate-900 mb-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Touch Targets (&ge;44px)</span>
                </div>
                <p className="text-xs text-slate-600">
                  Buttons and mobile controls adhere to minimum touch target sizing standards.
                </p>
              </div>
            </div>
          </section>

          <section className="space-y-2">
            <h2 className="text-base font-bold text-slate-900">3. Continuous Improvement & Feedback</h2>
            <p>
              We continuously test our web experiences with assistive technologies. If you encounter any barriers accessing information on this site, our dedicated accessibility team welcomes your feedback.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
