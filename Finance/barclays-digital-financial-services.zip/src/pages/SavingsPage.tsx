import React, { useState } from 'react';
import { PiggyBank, CheckCircle2, ShieldCheck, ArrowRight, AlertCircle, Percent } from 'lucide-react';
import { SAVINGS_PRODUCTS_DATA } from '../data/mockBankingData';
import { SavingsCalculator } from '../components/calculators/SavingsCalculator';
import { useBanking } from '../context/BankingContext';

export const SavingsPage: React.FC = () => {
  const { navigate } = useBanking();
  const [filterType, setFilterType] = useState<'All' | 'Instant Access' | 'Fixed Term'>('All');

  const filteredProducts = SAVINGS_PRODUCTS_DATA.filter((p) =>
    filterType === 'All' ? true : p.accessType === filterType
  );

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header Banner */}
      <section className="bg-[#00395d] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Savings & ISAs
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              Transparent savings with rewarding rates.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              Whether you are establishing a rainy-day reserve, saving for a home deposit, or seeking tax-free growth with a flexible Cash ISA, explore our range of instant-access and fixed-rate products.
            </p>

            <div className="pt-2 flex flex-wrap gap-4 text-xs text-slate-200">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#00aeef]" /> FSCS Protected up to £85,000 per claimant
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#00aeef]" /> Flexible ISA rules apply
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-16">
        {/* 1. Interactive Savings Interest Calculator */}
        <div>
          <div className="mb-6">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Model Your Growth
            </span>
            <h2 className="text-2xl font-bold text-[#00395d] mt-1">Savings Growth Calculator</h2>
            <p className="text-xs text-slate-600">
              Enter an initial deposit and optional monthly contributions to calculate illustrative compounding returns.
            </p>
          </div>
          <SavingsCalculator />
        </div>

        {/* 2. Product Explorer */}
        <div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4 mb-8">
            <div>
              <h2 className="text-2xl font-bold text-[#00395d]">Explore Savings Accounts</h2>
              <p className="text-xs text-slate-500">Compare rates, access rules and deposit thresholds</p>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-1 p-1 bg-white rounded-lg border border-slate-200">
              {(['All', 'Instant Access', 'Fixed Term'] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilterType(cat)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    filterType === cat
                      ? 'bg-[#00395d] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredProducts.map((prod) => (
              <div
                key={prod.id}
                className="bg-white rounded-xl border border-slate-200 p-6 sm:p-7 shadow-xs hover:border-[#00aeef] transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start gap-4 mb-4">
                    <div>
                      <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                        {prod.accessType} · {prod.rateType} Rate
                      </span>
                      <h3 className="text-xl font-bold text-slate-900 mt-2">{prod.name}</h3>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-extrabold text-[#00395d] font-mono">
                        {prod.aerRate}% <span className="text-xs font-normal">AER</span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        {prod.grossRate}% gross
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 mb-5 leading-relaxed">{prod.summary}</p>

                  <div className="space-y-4 pt-4 border-t border-slate-100">
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-slate-400 block text-[11px]">Opening Deposit:</span>
                        <span className="font-semibold text-slate-800 font-mono">
                          £{prod.minDeposit.toLocaleString()}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Maximum Balance:</span>
                        <span className="font-semibold text-slate-800 font-mono">
                          £{prod.maxDeposit.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
                        Key Conditions
                      </span>
                      <ul className="space-y-1.5 text-xs text-slate-600">
                        {prod.keyConditions.map((cond, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                            <span>{cond}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => navigate('/login')}
                    className="w-full py-2.5 text-xs font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>Open in Online Banking Demo</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3. Interest Rates Definitions & Disclosures */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 space-y-3 text-xs text-slate-600">
          <h4 className="font-bold text-slate-900 text-sm">Understanding British Savings Rates</h4>
          <p>
            <strong>AER (Annual Equivalent Rate):</strong> Illustrates what the interest rate would be if interest was paid and compounded each year. It allows savers to easily compare the return on different savings accounts with different payment frequencies.
          </p>
          <p>
            <strong>Gross Rate:</strong> The contractual rate of interest payable before the deduction of any applicable income tax. Since April 2016, UK banks pay interest gross without deducting basic rate tax.
          </p>
          <p>
            <strong>Cash ISA Allowance:</strong> For the 2026/27 tax year, the annual ISA subscription limit is £20,000. Interest earned within a Cash ISA is completely exempt from UK income tax and capital gains tax.
          </p>
        </div>
      </div>
    </div>
  );
};
