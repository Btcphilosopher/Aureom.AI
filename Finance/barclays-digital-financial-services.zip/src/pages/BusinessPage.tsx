import React from 'react';
import { Briefcase, CheckCircle2, ArrowRight, Building2, CreditCard, Globe, Sparkles } from 'lucide-react';
import { useBanking } from '../context/BankingContext';

export const BusinessPage: React.FC = () => {
  const { navigate } = useBanking();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero Banner with Bristol Clean Energy Workshop Photo */}
      <section className="relative bg-[#001726] text-white overflow-hidden py-16 sm:py-24 px-4 sm:px-8">
        <div className="absolute inset-0 z-0 opacity-35">
          <img
            src="/src/assets/images/modern_british_business_innovator_1792488157630.jpg"
            alt="British Clean Engineering and Innovation Business Workshop"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#001726] via-[#001726]/85 to-[#001726]/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="max-w-2xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Business Banking
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Backing British enterprise and innovation.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              From day one start-ups to established mid-market leaders. Access 12 months fee-free day-to-day banking, seamless merchant payment gateways, and commercial growth capital.
            </p>

            <div className="pt-4 flex flex-wrap gap-4">
              <button
                onClick={() => navigate('/login')}
                className="px-6 py-3 text-xs sm:text-sm font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded-lg transition-colors flex items-center gap-2"
              >
                <span>Open Business Account</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-16">
        {/* Solutions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 sm:p-7 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="p-3 bg-[#e8f2f8] text-[#00395d] rounded-lg w-fit mb-4">
                <Briefcase className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded">
                12 Months Free Banking
              </span>
              <h3 className="text-lg font-bold text-slate-900 mt-2">Start-Up Business Accounts</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Launch your company with 12 months free day-to-day UK banking, automated accounting integrations (Xero, QuickBooks), and an Eagle Lab mentor network.
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-slate-100">
              <button
                onClick={() => navigate('/login')}
                className="w-full py-2 text-xs font-semibold text-[#00395d] bg-[#f2f7fa] hover:bg-[#e8f2f8] rounded-lg transition-colors flex items-center justify-center gap-1"
              >
                <span>Start-up criteria</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="bg-white p-6 sm:p-7 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="p-3 bg-[#e8f2f8] text-[#00395d] rounded-lg w-fit mb-4">
                <CreditCard className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-semibold text-[#00395d] bg-[#e8f2f8] px-2.5 py-0.5 rounded">
                Barclaycard Payments
              </span>
              <h3 className="text-lg font-bold text-slate-900 mt-2">Merchant & POS Services</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Accept card payments anywhere with contactless SmartPOS terminals, next-day settlement, and seamless online checkout APIs.
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-slate-100">
              <button
                onClick={() => navigate('/login')}
                className="w-full py-2 text-xs font-semibold text-[#00395d] bg-[#f2f7fa] hover:bg-[#e8f2f8] rounded-lg transition-colors flex items-center justify-center gap-1"
              >
                <span>Merchant solutions</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="bg-white p-6 sm:p-7 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="p-3 bg-[#e8f2f8] text-[#00395d] rounded-lg w-fit mb-4">
                <Building2 className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-semibold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded">
                Flexible Capital
              </span>
              <h3 className="text-lg font-bold text-slate-900 mt-2">Commercial Loans & Asset Finance</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Fund equipment acquisition, commercial premises, or supply chain expansion with tailored business loans up to £250,000+.
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-slate-100">
              <button
                onClick={() => navigate('/login')}
                className="w-full py-2 text-xs font-semibold text-[#00395d] bg-[#f2f7fa] hover:bg-[#e8f2f8] rounded-lg transition-colors flex items-center justify-center gap-1"
              >
                <span>Commercial lending</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
