import React, { useState } from 'react';
import { CreditCard, CheckCircle2, ArrowRight, ShieldCheck, HelpCircle, Sparkles, Plane, Percent } from 'lucide-react';
import { CREDIT_CARDS_DATA } from '../data/mockBankingData';
import { CreditCardPayoffCalculator } from '../components/calculators/CreditCardPayoffCalculator';
import { useBanking } from '../context/BankingContext';

export const CreditCardsPage: React.FC = () => {
  const { navigate } = useBanking();
  const [selectedCardFilter, setSelectedCardFilter] = useState<'All' | 'Cashback & Travel' | '0% Balance Transfer' | 'Credit Builder'>('All');

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header Banner */}
      <section className="bg-[#00395d] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Barclaycard Credit Cards
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              A Barclaycard tailored for the way you spend.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              From fee-free spending abroad and everyday cashback rewards to long 0% balance transfer windows that help you reduce interest debt.
            </p>

            <div className="pt-2 flex flex-wrap gap-4 text-xs text-slate-200">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#00aeef]" /> Section 75 purchase protection on transactions £100–£30,000
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#00aeef]" /> Check eligibility online with no credit score penalty
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-16">
        {/* 1. Credit Cards Comparison Grid */}
        <div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4 mb-8">
            <div>
              <h2 className="text-2xl font-bold text-[#00395d]">Choose Your Barclaycard</h2>
              <p className="text-xs text-slate-500">Compare representative APRs, introductory offers and perks</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {CREDIT_CARDS_DATA.map((card) => (
              <div
                key={card.id}
                className="bg-white rounded-xl border border-slate-200 p-6 sm:p-7 shadow-xs hover:border-[#00aeef] transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                        {card.bestFor}
                      </span>
                      <h3 className="text-xl font-bold text-slate-900 mt-2">{card.name}</h3>
                    </div>
                    <span className="text-xs font-semibold text-slate-900 font-mono bg-slate-100 px-2.5 py-1 rounded">
                      {card.annualFee}
                    </span>
                  </div>

                  <div className="my-4 p-3 bg-[#f2f7fa] rounded-lg border border-slate-200 text-xs">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-slate-600">Representative APR:</span>
                      <span className="font-bold text-[#00395d] font-mono">{card.representativeApr}</span>
                    </div>
                    {card.balanceTransferOffer !== 'N/A' && (
                      <div className="flex justify-between items-center text-emerald-800 font-semibold pt-1 border-t border-slate-200">
                        <span>Balance Transfer:</span>
                        <span>{card.balanceTransferOffer}</span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 mt-4">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
                      Card Benefits
                    </span>
                    <ul className="space-y-1.5 text-xs text-slate-700">
                      {card.keyBenefits.map((benefit, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-100">
                  <button
                    onClick={() => navigate('/login')}
                    className="w-full py-2.5 text-xs font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>Check Eligibility & Apply</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Interactive Credit Card Payoff & Interest Calculator */}
        <div>
          <div className="mb-6">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Smart Borrowing Advice
            </span>
            <h2 className="text-2xl font-bold text-[#00395d] mt-1">Credit Card Payoff Tool</h2>
            <p className="text-xs text-slate-600">
              Calculate how paying more than the minimum monthly balance reduces debt duration and interest.
            </p>
          </div>
          <CreditCardPayoffCalculator />
        </div>
      </div>
    </div>
  );
};
