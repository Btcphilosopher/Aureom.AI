import React, { useState } from 'react';
import {
  Landmark,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight,
  ShieldCheck,
  CreditCard,
  Percent,
  Sliders,
} from 'lucide-react';
import { CURRENT_ACCOUNTS_DATA } from '../data/mockBankingData';
import { useBanking } from '../context/BankingContext';
import { CurrentAccountProduct } from '../types/banking';

export const CurrentAccountsPage: React.FC = () => {
  const { navigate } = useBanking();
  const [selectedProduct, setSelectedProduct] = useState<CurrentAccountProduct>(CURRENT_ACCOUNTS_DATA[0]);
  const [comparisonMode, setComparisonMode] = useState<boolean>(false);

  // Overdraft cost simulator state
  const [odAmount, setOdAmount] = useState<number>(300);
  const [odDays, setOdDays] = useState<number>(14);

  // Calculate indicative overdraft cost:
  // For Premier, first £500 is 0%; for standard account, 35.0% APR
  const standardDailyRate = 0.35 / 365;
  const standardCost = odAmount * standardDailyRate * odDays;
  const premierCost = odAmount <= 500 ? 0 : (odAmount - 500) * standardDailyRate * odDays;

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header Banner */}
      <section className="bg-[#00395d] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Current Accounts
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              Compare UK Current Accounts
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              Choose the account that matches your financial life — from our everyday fee-free current account to our prestigious Premier tier with dedicated relationship management and zero fees abroad.
            </p>

            <div className="pt-2 flex flex-wrap gap-4 text-xs">
              <span className="flex items-center gap-1.5 text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-[#00aeef]" /> 7-day Current Account Switch Guarantee
              </span>
              <span className="flex items-center gap-1.5 text-slate-200">
                <CheckCircle2 className="w-4 h-4 text-[#00aeef]" /> Instant digital card in Apple Pay / Google Wallet
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-12">
        {/* View toggle */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Available Current Accounts</h2>
            <p className="text-xs text-slate-500">All accounts include contactless Visa debit card & mobile app access</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setComparisonMode(false)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                !comparisonMode ? 'bg-[#00395d] text-white' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              Detailed Cards
            </button>
            <button
              onClick={() => setComparisonMode(true)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                comparisonMode ? 'bg-[#00395d] text-white' : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              Side-by-Side Comparison
            </button>
          </div>
        </div>

        {/* 1. Detailed Cards View */}
        {!comparisonMode ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {CURRENT_ACCOUNTS_DATA.map((acc) => (
              <div
                key={acc.id}
                className="bg-white rounded-xl border border-slate-200 shadow-xs hover:border-[#00aeef] transition-all p-6 sm:p-7 flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      {acc.badge && (
                        <span className="text-[11px] font-semibold text-[#00395d] bg-[#e8f2f8] px-2.5 py-0.5 rounded-sm inline-block mb-2">
                          {acc.badge}
                        </span>
                      )}
                      <h3 className="text-xl font-bold text-slate-900">{acc.name}</h3>
                    </div>
                    <span className="text-sm font-bold text-slate-900 font-mono bg-slate-100 px-2.5 py-1 rounded">
                      {acc.monthlyFee}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 mb-5">{acc.tagline}</p>

                  <div className="space-y-4">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
                        Key Features
                      </span>
                      <ul className="space-y-2 text-xs text-slate-700">
                        {acc.features.map((feat, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-3 border-t border-slate-100">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">
                        Eligibility
                      </span>
                      <ul className="text-xs text-slate-600 space-y-1">
                        {acc.eligibility.map((elig, idx) => (
                          <li key={idx} className="flex items-start gap-1.5">
                            <span className="text-slate-400">·</span>
                            <span>{elig}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-3 border-t border-slate-100 text-xs">
                      <span className="text-slate-500">Overdraft Terms: </span>
                      <span className="font-semibold text-slate-800">{acc.overdraftApr}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => navigate('/login')}
                    className="w-full py-2.5 text-xs font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>Apply / Open in Demo</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* 2. Side-by-Side Comparison Matrix */
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="p-4 font-semibold text-slate-500 w-1/4">Account Tier</th>
                  {CURRENT_ACCOUNTS_DATA.map((acc) => (
                    <th key={acc.id} className="p-4 font-bold text-slate-900 w-1/4">
                      <div>{acc.name}</div>
                      <div className="text-[11px] font-normal text-slate-500 font-mono mt-0.5">{acc.monthlyFee}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">Monthly Maintenance Fee</td>
                  {CURRENT_ACCOUNTS_DATA.map((acc) => (
                    <td key={acc.id} className="p-4 font-semibold text-slate-900 font-mono">
                      {acc.monthlyFee}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">Overdraft Rate</td>
                  {CURRENT_ACCOUNTS_DATA.map((acc) => (
                    <td key={acc.id} className="p-4 text-slate-700">
                      {acc.overdraftApr}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">Card Spending Abroad</td>
                  <td className="p-4 text-emerald-700 font-semibold">Fee-Free Worldwide</td>
                  <td className="p-4 text-slate-600">Standard 2.99% FX Fee</td>
                  <td className="p-4 text-emerald-700 font-semibold">Fee-Free Worldwide</td>
                  <td className="p-4 text-slate-600">Standard 2.99% FX Fee</td>
                </tr>
                <tr>
                  <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">Blue Rewards Eligibility</td>
                  <td className="p-4 text-emerald-600 font-semibold">Included</td>
                  <td className="p-4 text-emerald-600 font-semibold">Eligible (£5/mo fee waived with qualifying accounts)</td>
                  <td className="p-4 text-slate-400">Optional</td>
                  <td className="p-4 text-slate-400">Not included</td>
                </tr>
                <tr>
                  <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">Dedicated Relationship Team</td>
                  <td className="p-4 text-emerald-600 font-semibold">Yes (24/7 UK Premier Team)</td>
                  <td className="p-4 text-slate-400">Standard Support</td>
                  <td className="p-4 text-slate-400">Standard Support</td>
                  <td className="p-4 text-slate-400">Student Support Team</td>
                </tr>
                <tr>
                  <td className="p-4 font-semibold text-slate-700 bg-slate-50/50">Action</td>
                  {CURRENT_ACCOUNTS_DATA.map((acc) => (
                    <td key={acc.id} className="p-4">
                      <button
                        onClick={() => navigate('/login')}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded transition-colors"
                      >
                        Apply Now
                      </button>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}

        {/* 3. Interactive Overdraft Cost Simulator */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#00aeef] uppercase tracking-wider mb-2">
            <Sliders className="w-4 h-4" />
            <span>Borrowing Transparency</span>
          </div>
          <h3 className="text-xl font-bold text-slate-900">Arranged Overdraft Cost Simulator</h3>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Model how much an arranged overdraft would cost if you dipped into borrowing for a specific number of days.
          </p>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1.5">
                <span>Overdraft Borrowing:</span>
                <span className="font-mono text-slate-900 font-bold">£{odAmount}</span>
              </div>
              <input
                type="range"
                min="50"
                max="2000"
                step="50"
                value={odAmount}
                onChange={(e) => setOdAmount(Number(e.target.value))}
                className="w-full accent-[#00395d]"
              />
              <div className="flex justify-between text-[11px] text-slate-400 mt-1">
                <span>£50</span>
                <span>£2,000</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1.5">
                <span>Duration in Overdraft:</span>
                <span className="font-mono text-slate-900 font-bold">{odDays} days</span>
              </div>
              <input
                type="range"
                min="1"
                max="30"
                value={odDays}
                onChange={(e) => setOdDays(Number(e.target.value))}
                className="w-full accent-[#00395d]"
              />
              <div className="flex justify-between text-[11px] text-slate-400 mt-1">
                <span>1 day</span>
                <span>30 days</span>
              </div>
            </div>

            <div className="bg-[#f2f7fa] p-4 rounded-xl border border-slate-200 text-xs">
              <div className="flex justify-between items-center mb-1">
                <span className="text-slate-600">Standard Account (35.0% APR):</span>
                <span className="font-mono font-bold text-slate-900">£{standardCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-slate-200">
                <span className="text-[#00395d] font-semibold">Premier Account (£500 0% buffer):</span>
                <span className="font-mono font-bold text-emerald-700">£{premierCost.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* 4. Current Account Switch Service (CASS) Guarantee */}
        <div className="bg-[#00263e] text-white rounded-xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#00aeef]">
              CASS Switch Guarantee
            </span>
            <h3 className="text-xl font-bold">Switching to Barclays takes exactly 7 working days.</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              The Current Account Switch Service is completely free, secure, and backed by a full guarantee. We automatically transfer your existing balances, payments (standing orders and Direct Debits), and redirect any future salary payments.
            </p>
          </div>
          <button
            onClick={() => navigate('/login')}
            className="px-6 py-3 text-xs font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded-lg transition-colors whitespace-nowrap"
          >
            Start Account Application
          </button>
        </div>
      </div>
    </div>
  );
};
