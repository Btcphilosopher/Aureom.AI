import React from 'react';
import {
  Landmark,
  PiggyBank,
  Home,
  Percent,
  CreditCard,
  ArrowRight,
  CheckCircle2,
  ShieldCheck,
  Smartphone,
  Repeat,
  Sparkles,
} from 'lucide-react';
import { useBanking } from '../context/BankingContext';

export const PersonalPage: React.FC = () => {
  const { navigate } = useBanking();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Banner */}
      <section className="bg-[#00395d] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-2xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Personal Banking
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              Banking designed for real everyday life.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              From fee-free current accounts and high-yield savings to market-leading mortgages and digital security controls — manage your money with confidence.
            </p>
          </div>
        </div>
      </section>

      {/* Switch Guarantee Highlight */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8 -mt-6">
        <div className="bg-white rounded-xl p-6 sm:p-8 shadow-sm border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl shrink-0">
              <Repeat className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded">
                  7-Day Switch Service
                </span>
                <span className="text-xs text-slate-500">· Backed by CASS Guarantee</span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 mt-1">
                Switch to Barclays and enjoy £175 switch bonus
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
                Open a Barclays Bank Account or Premier Account, switch with the Current Account Switch Service, and set up two active Direct Debits.
              </p>
            </div>
          </div>
          <button
            onClick={() => navigate('/current-accounts')}
            className="px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            Switch to Barclays
          </button>
        </div>
      </section>

      {/* Product Pathways */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8 py-16">
        <h2 className="text-2xl font-bold text-[#00395d] mb-8">Personal Banking Products</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div
            onClick={() => navigate('/current-accounts')}
            className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="p-3 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors w-fit mb-4">
                <Landmark className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-[#00395d]">
                Current Accounts
              </h3>
              <p className="text-xs text-slate-600 mt-2">
                Premier Banking, standard fee-free accounts, and student finance with interest-free arranged overdrafts.
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
              <span>Explore accounts</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          <div
            onClick={() => navigate('/savings')}
            className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="p-3 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors w-fit mb-4">
                <PiggyBank className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-[#00395d]">
                Savings & ISAs
              </h3>
              <p className="text-xs text-slate-600 mt-2">
                Grow your money with our 5.12% AER Rainy Day Saver, Cash ISAs, and fixed-rate savings bonds.
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
              <span>View savings rates</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          <div
            onClick={() => navigate('/mortgages')}
            className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="p-3 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors w-fit mb-4">
                <Home className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-[#00395d]">
                Mortgages & Home
              </h3>
              <p className="text-xs text-slate-600 mt-2">
                First-time buyer options, remortgage rate locks, and repayment calculators with clear LTV guidance.
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
              <span>Calculate mortgage</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          <div
            onClick={() => navigate('/loans')}
            className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="p-3 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors w-fit mb-4">
                <Percent className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-[#00395d]">
                Personal Loans
              </h3>
              <p className="text-xs text-slate-600 mt-2">
                Fixed monthly borrowing from £1,000 to £50,000 with 6.1% APR representative on £7.5k–£15k.
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
              <span>Calculate loan</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          <div
            onClick={() => navigate('/credit-cards')}
            className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="p-3 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors w-fit mb-4">
                <CreditCard className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-[#00395d]">
                Barclaycard
              </h3>
              <p className="text-xs text-slate-600 mt-2">
                0% balance transfer cards, 0.25% cashback on everyday spend, and zero FX transaction fees abroad.
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
              <span>Compare cards</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>

          <div
            onClick={() => navigate('/calculators')}
            className="bg-white p-6 rounded-xl border border-slate-200 hover:border-[#00aeef] hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="p-3 rounded-lg bg-[#e8f2f8] text-[#00395d] group-hover:bg-[#00aeef] group-hover:text-white transition-colors w-fit mb-4">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-[#00395d]">
                Financial Calculator Hub
              </h3>
              <p className="text-xs text-slate-600 mt-2">
                Model mortgages, compound savings growth, loan payments and household budget plans in one place.
              </p>
            </div>
            <div className="pt-4 mt-6 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-[#00395d] group-hover:text-[#00aeef]">
              <span>Open calculators</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </section>

      {/* App & Digital Banking Benefits */}
      <section className="bg-white py-16 px-4 sm:px-8 border-t border-slate-200">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-6 bg-[#f2f7fa] rounded-xl border border-slate-200/80">
            <Smartphone className="w-8 h-8 text-[#00395d] mb-4" />
            <h3 className="text-base font-bold text-slate-900">Award-winning Mobile App</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Check balances instantly, make UK Faster Payments, and manage Direct Debits from your phone with biometric face ID login.
            </p>
          </div>

          <div className="p-6 bg-[#f2f7fa] rounded-xl border border-slate-200/80">
            <ShieldCheck className="w-8 h-8 text-[#00395d] mb-4" />
            <h3 className="text-base font-bold text-slate-900">Confirmation of Payee</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Name verification checks protect you against Authorised Push Payment (APP) fraud by ensuring account names match bank records.
            </p>
          </div>

          <div className="p-6 bg-[#f2f7fa] rounded-xl border border-slate-200/80">
            <CheckCircle2 className="w-8 h-8 text-[#00395d] mb-4" />
            <h3 className="text-base font-bold text-slate-900">FSCS Deposit Protection</h3>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Your eligible savings deposits are protected by the Financial Services Compensation Scheme up to £85,000.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
