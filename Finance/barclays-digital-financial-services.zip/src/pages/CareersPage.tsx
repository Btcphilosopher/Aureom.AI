import React, { useState } from 'react';
import { Briefcase, MapPin, Search, ArrowRight, CheckCircle2, GraduationCap } from 'lucide-react';
import { useBanking } from '../context/BankingContext';

interface JobOpening {
  id: string;
  title: string;
  department: string;
  location: string;
  type: string;
}

const SAMPLE_JOBS: JobOpening[] = [
  { id: 'job-1', title: 'VP, Cloud Infrastructure & Resiliency', department: 'Technology', location: 'London (1 Churchill Place)', type: 'Full-time' },
  { id: 'job-2', title: 'Senior Quantitative Analyst - Macro Fixed Income', department: 'Investment Bank', location: 'London (Canary Wharf)', type: 'Full-time' },
  { id: 'job-3', title: 'Lead Full-Stack TypeScript Engineer - Digital Retail Banking', department: 'Technology', location: 'Northampton / Hybrid', type: 'Full-time' },
  { id: 'job-4', title: 'Graduate Banking & FinTech Analyst Programme 2027', department: 'Early Careers', location: 'Glasgow / London / Radbroke', type: 'Graduate Scheme' },
  { id: 'job-5', title: 'Senior Fraud Intelligence & AML Investigator', department: 'Compliance & Risk', location: 'Knutsford (Radbroke Hall)', type: 'Full-time' },
];

export const CareersPage: React.FC = () => {
  const { navigate } = useBanking();
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [jobSearch, setJobSearch] = useState('');

  const filteredJobs = SAMPLE_JOBS.filter((job) => {
    const matchesDept = departmentFilter === 'All' || job.department === departmentFilter;
    const matchesQuery = job.title.toLowerCase().includes(jobSearch.toLowerCase()) || job.location.toLowerCase().includes(jobSearch.toLowerCase());
    return matchesDept && matchesQuery;
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-[#00395d] text-white py-16 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Careers at Barclays
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
              Build the future of British and global finance.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              Join over 85,000 colleagues worldwide working across engineering, quantitative analytics, sustainable capital, and private wealth.
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-12">
        {/* Early careers banner */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-[#e8f2f8] text-[#00395d] rounded-xl shrink-0">
              <GraduationCap className="w-8 h-8" />
            </div>
            <div>
              <span className="text-xs font-semibold text-[#00aeef] uppercase tracking-wider">
                Graduate & Apprentice Schemes
              </span>
              <h3 className="text-lg font-bold text-slate-900 mt-1">
                Barclays Early Careers Programmes
              </h3>
              <p className="text-xs text-slate-600 mt-1 max-w-xl">
                Rotational development in Software Engineering, Capital Markets, Commercial Banking, and Wealth Management across London, Knutsford, and Glasgow campuses.
              </p>
            </div>
          </div>
          <button
            onClick={() => alert('Applications for the 2026/2027 graduate schemes open through the Barclays Early Careers portal.')}
            className="px-5 py-2.5 text-xs font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            Explore Early Careers
          </button>
        </div>

        {/* Job Openings Simulator */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h2 className="text-xl font-bold text-slate-900">Current Opportunities</h2>
            <div className="flex items-center gap-3">
              <input
                type="text"
                value={jobSearch}
                onChange={(e) => setJobSearch(e.target.value)}
                placeholder="Search job title or city..."
                className="px-3.5 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00aeef]"
              />
              <select
                value={departmentFilter}
                onChange={(e) => setDepartmentFilter(e.target.value)}
                className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#00aeef]"
              >
                <option value="All">All Departments</option>
                <option value="Technology">Technology</option>
                <option value="Investment Bank">Investment Bank</option>
                <option value="Early Careers">Early Careers</option>
                <option value="Compliance & Risk">Compliance & Risk</option>
              </select>
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {filteredJobs.map((job) => (
              <div key={job.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 group">
                <div>
                  <h4 className="text-sm font-semibold text-slate-900 group-hover:text-[#00aeef] transition-colors">
                    {job.title}
                  </h4>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                    <span>{job.department}</span>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {job.location}
                    </span>
                    <span>·</span>
                    <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px] font-mono">{job.type}</span>
                  </div>
                </div>
                <button
                  onClick={() => alert(`Application pathway for: ${job.title}. This demonstration routes to synthetic candidate registration.`)}
                  className="px-4 py-2 text-xs font-semibold text-[#00395d] bg-slate-100 hover:bg-[#e8f2f8] rounded-lg transition-colors whitespace-nowrap"
                >
                  Apply Online
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
