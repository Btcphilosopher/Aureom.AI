import React from 'react';
import { Building2, Award, Globe, Leaf, ArrowRight, ShieldCheck } from 'lucide-react';
import { useBanking } from '../context/BankingContext';

export const AboutPage: React.FC = () => {
  const { navigate } = useBanking();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero Banner with Headquarters Photo */}
      <section className="relative bg-[#001726] text-white overflow-hidden py-16 sm:py-24 px-4 sm:px-8">
        <div className="absolute inset-0 z-0 opacity-30">
          <img
            src="/src/assets/images/london_canary_wharf_hq_1792488155793.jpg"
            alt="One Churchill Place Headquarters Canary Wharf London"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#001726] via-[#001726]/85 to-[#001726]/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="max-w-2xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              The Institution
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Three centuries of British financial stewardship.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              Founded in 1690 on Lombard Street in the City of London, Barclays has shaped global commerce, introduced the world’s first ATM cash machine, and continues to finance innovation across the UK and beyond.
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-16">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 text-center shadow-xs">
            <span className="text-3xl sm:text-4xl font-extrabold text-[#00395d] font-mono block">1690</span>
            <span className="text-xs text-slate-500 mt-1 block">Founded on Lombard Street</span>
          </div>
          <div className="bg-white p-6 rounded-xl border border-slate-200 text-center shadow-xs">
            <span className="text-3xl sm:text-4xl font-extrabold text-[#00395d] font-mono block">48M+</span>
            <span className="text-xs text-slate-500 mt-1 block">Customers Worldwide</span>
          </div>
          <div className="bg-white p-6 rounded-xl border border-slate-200 text-center shadow-xs">
            <span className="text-3xl sm:text-4xl font-extrabold text-[#00395d] font-mono block">1967</span>
            <span className="text-xs text-slate-500 mt-1 block">World&apos;s First Automated Cash Machine (Enfield)</span>
          </div>
          <div className="bg-white p-6 rounded-xl border border-slate-200 text-center shadow-xs">
            <span className="text-3xl sm:text-4xl font-extrabold text-[#00395d] font-mono block">£85k</span>
            <span className="text-xs text-slate-500 mt-1 block">FSCS Deposit Protection</span>
          </div>
        </div>

        {/* Heritage & Values */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <h2 className="text-2xl font-bold text-[#00395d]">Our Purpose and Values</h2>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Our purpose is simple: <strong>Working together for a better financial future.</strong> We help people and businesses manage their money, plan for what comes next, and navigate major economic transitions with confidence.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
            <div className="p-4 bg-slate-50 rounded-lg">
              <h4 className="font-bold text-slate-900 text-sm mb-1">Respect & Integrity</h4>
              <p className="text-xs text-slate-600">
                Operating with transparent pricing, clear regulatory compliance, and fair customer outcomes across every product.
              </p>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg">
              <h4 className="font-bold text-slate-900 text-sm mb-1">Service & Innovation</h4>
              <p className="text-xs text-slate-600">
                Pioneering modern digital banking platforms, Confirmation of Payee safeguards, and real-time open APIs.
              </p>
            </div>
            <div className="p-4 bg-slate-50 rounded-lg">
              <h4 className="font-bold text-slate-900 text-sm mb-1">Sustainability & Net Zero</h4>
              <p className="text-xs text-slate-600">
                Targeting net zero carbon emissions across our own operations and financing green transition infrastructure for UK clients.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
