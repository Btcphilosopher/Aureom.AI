import React, { useState } from 'react';
import { TrendingUp, ShieldAlert, CheckCircle2, ArrowRight, PieChart, ShieldCheck, Award } from 'lucide-react';
import { useBanking } from '../context/BankingContext';

export const WealthPage: React.FC = () => {
  const { navigate } = useBanking();
  const [selectedRisk, setSelectedRisk] = useState<'Cautious' | 'Balanced' | 'Growth' | 'Adventurous'>('Balanced');

  const riskProfiles = {
    Cautious: {
      bonds: 60,
      equities: 25,
      cash: 15,
      volatility: 'Low',
      timeHorizon: '3+ Years',
      description: 'Prioritises capital preservation with modest exposure to developed equities to counter inflation.',
    },
    Balanced: {
      bonds: 40,
      equities: 50,
      cash: 10,
      volatility: 'Medium',
      timeHorizon: '5+ Years',
      description: 'A diversified multi-asset portfolio balancing income generation with long-term global equity growth.',
    },
    Growth: {
      bonds: 20,
      equities: 75,
      cash: 5,
      volatility: 'Higher',
      timeHorizon: '7+ Years',
      description: 'Focused on capital appreciation through global equities, tech innovators and developed market stocks.',
    },
    Adventurous: {
      bonds: 5,
      equities: 90,
      cash: 5,
      volatility: 'High',
      timeHorizon: '10+ Years',
      description: 'Maximises exposure to high-growth global equities, emerging markets and thematic tech transitions.',
    },
  };

  const currentRisk = riskProfiles[selectedRisk];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Hero with High-End Private Wealth Advisory Photo */}
      <section className="relative bg-[#001726] text-white overflow-hidden py-16 sm:py-24 px-4 sm:px-8">
        <div className="absolute inset-0 z-0 opacity-35">
          <img
            src="/src/assets/images/wealth_investment_advisory_1792488157417.jpg"
            alt="Barclays Private Wealth Advisory Consultation Room London"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#001726] via-[#001726]/85 to-[#001726]/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="max-w-2xl space-y-4">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Wealth Management & Smart Investor
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Institutional rigor. Tailored wealth strategies.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-light">
              Over three centuries of financial stewardship. We provide bespoke discretionary portfolios, tax-efficient ISAs and SIPPs, and direct access to global capital markets.
            </p>

            <div className="pt-4 flex flex-wrap gap-4">
              <button
                onClick={() => navigate('/login')}
                className="px-6 py-3 text-xs sm:text-sm font-semibold text-white bg-[#00aeef] hover:bg-[#0098d3] rounded-lg transition-colors flex items-center gap-2"
              >
                <span>Barclays Smart Investor Demo</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-12 space-y-16">
        {/* 1. Interactive Asset Allocation & Risk Profile Explorer */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          <div className="max-w-2xl mb-8">
            <span className="text-xs font-bold text-[#00aeef] uppercase tracking-wider">
              Portfolio Construction
            </span>
            <h2 className="text-2xl font-bold text-[#00395d] mt-1">Multi-Asset Allocation Profiles</h2>
            <p className="text-xs text-slate-600 mt-1">
              Select a risk tier to explore the underlying asset mix engineered by our chief investment office.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Risk Selector */}
            <div className="lg:col-span-5 space-y-3">
              {(['Cautious', 'Balanced', 'Growth', 'Adventurous'] as const).map((tier) => (
                <button
                  key={tier}
                  onClick={() => setSelectedRisk(tier)}
                  className={`w-full text-left p-4 rounded-xl border transition-all ${
                    selectedRisk === tier
                      ? 'border-[#00395d] bg-[#f2f7fa] shadow-xs'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-bold text-slate-900">{tier} Profile</span>
                    <span className="text-xs font-mono text-slate-500">
                      {riskProfiles[tier].volatility} Volatility
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{riskProfiles[tier].description}</p>
                </button>
              ))}
            </div>

            {/* Asset Allocation Visualizer */}
            <div className="lg:col-span-7 bg-slate-50 rounded-xl p-6 border border-slate-200 space-y-6">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-500 uppercase">
                  Asset Mix: {selectedRisk}
                </span>
                <span className="text-xs font-semibold text-[#00395d]">
                  Suggested Horizon: {currentRisk.timeHorizon}
                </span>
              </div>

              {/* Stacked bar */}
              <div className="h-4 w-full bg-slate-200 rounded-full overflow-hidden flex shadow-inner">
                <div
                  className="bg-[#00395d] h-full transition-all duration-300"
                  style={{ width: `${currentRisk.equities}%` }}
                  title={`Equities: ${currentRisk.equities}%`}
                />
                <div
                  className="bg-[#00aeef] h-full transition-all duration-300"
                  style={{ width: `${currentRisk.bonds}%` }}
                  title={`Fixed Income & Bonds: ${currentRisk.bonds}%`}
                />
                <div
                  className="bg-emerald-600 h-full transition-all duration-300"
                  style={{ width: `${currentRisk.cash}%` }}
                  title={`Cash & Liquidity: ${currentRisk.cash}%`}
                />
              </div>

              {/* Legend & Breakdown */}
              <div className="grid grid-cols-3 gap-4 text-xs pt-2">
                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#00395d]" />
                    <span className="text-slate-600 font-medium">Equities:</span>
                  </div>
                  <span className="text-xl font-bold text-slate-900 font-mono">
                    {currentRisk.equities}%
                  </span>
                </div>

                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#00aeef]" />
                    <span className="text-slate-600 font-medium">Fixed Income:</span>
                  </div>
                  <span className="text-xl font-bold text-slate-900 font-mono">
                    {currentRisk.bonds}%
                  </span>
                </div>

                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                    <span className="text-slate-600 font-medium">Cash / Reserves:</span>
                  </div>
                  <span className="text-xl font-bold text-slate-900 font-mono">
                    {currentRisk.cash}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 2. Regulatory Risk Warning Banner */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 text-xs text-amber-900 flex items-start gap-4">
          <ShieldAlert className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-2">
            <h4 className="font-bold text-sm uppercase">Regulatory Warning: Capital At Risk</h4>
            <p>
              The value of investments and the income derived from them can fall as well as rise. You may get back less than you invested. Past performance is not a reliable indicator of future returns.
            </p>
            <p>
              Tax treatment depends on your individual circumstances and rules may change in the future. Barclays does not provide personal tax or legal advice.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
