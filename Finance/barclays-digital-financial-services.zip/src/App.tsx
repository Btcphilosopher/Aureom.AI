import React from 'react';
import { BankingProvider, useBanking } from './context/BankingContext';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { SearchModal } from './components/layout/SearchModal';

// Pages
import { HomePage } from './pages/HomePage';
import { PersonalPage } from './pages/PersonalPage';
import { CurrentAccountsPage } from './pages/CurrentAccountsPage';
import { SavingsPage } from './pages/SavingsPage';
import { MortgagesPage } from './pages/MortgagesPage';
import { LoansPage } from './pages/LoansPage';
import { CreditCardsPage } from './pages/CreditCardsPage';
import { WealthPage } from './pages/WealthPage';
import { BusinessPage } from './pages/BusinessPage';
import { InternationalPage } from './pages/InternationalPage';
import { CalculatorsHubPage } from './pages/CalculatorsHubPage';
import { HelpSupportPage } from './pages/HelpSupportPage';
import { SecurityPage } from './pages/SecurityPage';
import { AboutPage } from './pages/AboutPage';
import { CareersPage } from './pages/CareersPage';
import { LoginPage } from './pages/LoginPage';
import { DashboardDemoPage } from './pages/DashboardDemoPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { AccessibilityPage } from './pages/AccessibilityPage';

const AppContent: React.FC = () => {
  const { currentRoute } = useBanking();

  const renderCurrentPage = () => {
    switch (currentRoute) {
      case '/':
        return <HomePage />;
      case '/personal':
        return <PersonalPage />;
      case '/current-accounts':
        return <CurrentAccountsPage />;
      case '/savings':
        return <SavingsPage />;
      case '/mortgages':
        return <MortgagesPage />;
      case '/loans':
        return <LoansPage />;
      case '/credit-cards':
        return <CreditCardsPage />;
      case '/wealth':
        return <WealthPage />;
      case '/business':
        return <BusinessPage />;
      case '/international':
        return <InternationalPage />;
      case '/calculators':
        return <CalculatorsHubPage />;
      case '/help':
        return <HelpSupportPage />;
      case '/security':
        return <SecurityPage />;
      case '/about':
        return <AboutPage />;
      case '/careers':
        return <CareersPage />;
      case '/login':
        return <LoginPage />;
      case '/dashboard':
        return <DashboardDemoPage />;
      case '/privacy':
        return <PrivacyPage />;
      case '/accessibility':
        return <AccessibilityPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-white">
      <Header />
      <main className="flex-1">{renderCurrentPage()}</main>
      <Footer />
      <SearchModal />
    </div>
  );
};

export default function App() {
  return (
    <BankingProvider>
      <AppContent />
    </BankingProvider>
  );
}
