export type RoutePath =
  | '/'
  | '/personal'
  | '/current-accounts'
  | '/savings'
  | '/mortgages'
  | '/loans'
  | '/credit-cards'
  | '/wealth'
  | '/business'
  | '/international'
  | '/calculators'
  | '/help'
  | '/security'
  | '/about'
  | '/careers'
  | '/login'
  | '/dashboard'
  | '/privacy'
  | '/accessibility';

export interface BankAccount {
  id: string;
  name: string;
  type: 'current' | 'savings' | 'credit';
  accountNumber: string;
  sortCode: string;
  balance: number;
  availableBalance: number;
  currency: string;
  interestRate?: string;
  cardLast4?: string;
  isFrozen?: boolean;
  contactlessLimit?: number;
  allowOnlineTransactions?: boolean;
}

export interface Transaction {
  id: string;
  accountId: string;
  date: string;
  description: string;
  amount: number;
  type: 'debit' | 'credit';
  category: 'Groceries' | 'Dining' | 'Transport' | 'Bills & Utilities' | 'Income' | 'Transfers' | 'Shopping' | 'Entertainment';
  status: 'completed' | 'pending';
  reference?: string;
}

export interface CurrentAccountProduct {
  id: string;
  name: string;
  tagline: string;
  monthlyFee: string;
  interestRate: string;
  overdraftApr: string;
  highlight: string;
  features: string[];
  eligibility: string[];
  perks: string[];
  badge?: string;
}

export interface SavingsProduct {
  id: string;
  name: string;
  aerRate: number;
  grossRate: number;
  rateType: 'Fixed' | 'Variable';
  accessType: 'Instant Access' | 'Notice' | 'Fixed Term';
  minDeposit: number;
  maxDeposit: number;
  termMonths?: number;
  summary: string;
  keyConditions: string[];
}

export interface CreditCardProduct {
  id: string;
  name: string;
  representativeApr: string;
  purchaseRate: string;
  balanceTransferOffer: string;
  purchaseOffer: string;
  annualFee: string;
  bestFor: string;
  keyBenefits: string[];
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'Accounts' | 'Payments' | 'Cards' | 'Mortgages' | 'Security & Fraud' | 'Digital Banking';
}

export interface MarketQuote {
  symbol: string;
  name: string;
  price: string;
  change: string;
  percentChange: string;
  isPositive: boolean;
  category: 'FX' | 'Rates' | 'Commodities' | 'Equities';
}

export interface InsightArticle {
  id: string;
  title: string;
  date: string;
  category: string;
  readTime: string;
  summary: string;
  imageUrl?: string;
}
