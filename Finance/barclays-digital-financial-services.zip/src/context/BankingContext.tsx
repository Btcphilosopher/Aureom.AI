import React, { createContext, useContext, useState, useEffect } from 'react';
import { BankAccount, Transaction, RoutePath } from '../types/banking';
import { INITIAL_ACCOUNTS, INITIAL_TRANSACTIONS } from '../data/mockBankingData';

interface DemoUser {
  name: string;
  title: string;
  membershipNumber: string;
  email: string;
  lastLogin: string;
}

interface TransferPayload {
  fromAccountId: string;
  toType: 'internal' | 'external';
  toAccountId?: string;
  payeeName?: string;
  sortCode?: string;
  accountNumber?: string;
  amount: number;
  reference: string;
}

interface BankingContextType {
  currentRoute: RoutePath;
  navigate: (path: RoutePath) => void;
  isLoggedIn: boolean;
  user: DemoUser | null;
  accounts: BankAccount[];
  transactions: Transaction[];
  loginAsDemoUser: () => void;
  logout: () => void;
  transferFunds: (payload: TransferPayload) => { success: boolean; message: string };
  toggleCardFreeze: (accountId: string) => void;
  updateContactlessLimit: (accountId: string, limit: number) => void;
  toggleOnlineTransactions: (accountId: string) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  activeSegment: 'personal' | 'business' | 'wealth';
  setActiveSegment: (segment: 'personal' | 'business' | 'wealth') => void;
}

const BankingContext = createContext<BankingContextType | undefined>(undefined);

export const BankingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentRoute, setCurrentRoute] = useState<RoutePath>(() => {
    const path = window.location.pathname as RoutePath;
    const validPaths: RoutePath[] = [
      '/',
      '/personal',
      '/current-accounts',
      '/savings',
      '/mortgages',
      '/loans',
      '/credit-cards',
      '/wealth',
      '/business',
      '/international',
      '/calculators',
      '/help',
      '/security',
      '/about',
      '/careers',
      '/login',
      '/dashboard',
      '/privacy',
      '/accessibility',
    ];
    return validPaths.includes(path) ? path : '/';
  });

  const [activeSegment, setActiveSegment] = useState<'personal' | 'business' | 'wealth'>('personal');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<DemoUser | null>(null);
  const [accounts, setAccounts] = useState<BankAccount[]>(INITIAL_ACCOUNTS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);

  // Sync browser back/forward buttons
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname as RoutePath;
      setCurrentRoute(path || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: RoutePath) => {
    setCurrentRoute(path);
    window.history.pushState({}, '', path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const loginAsDemoUser = () => {
    setIsLoggedIn(true);
    setUser({
      name: 'Dr. Alistair Finch',
      title: 'Dr.',
      membershipNumber: '2094 8192 01',
      email: 'alistair.finch@oxon.alumni.uk',
      lastLogin: 'Today, 09:14 GMT (Mobile App PINsentry)',
    });
    navigate('/dashboard');
  };

  const logout = () => {
    setIsLoggedIn(false);
    setUser(null);
    navigate('/');
  };

  const transferFunds = (payload: TransferPayload): { success: boolean; message: string } => {
    const sourceAcc = accounts.find((a) => a.id === payload.fromAccountId);
    if (!sourceAcc) {
      return { success: false, message: 'Source account not found.' };
    }

    if (sourceAcc.isFrozen) {
      return { success: false, message: 'Source account card is frozen. Unfreeze it to perform payments.' };
    }

    if (payload.amount <= 0) {
      return { success: false, message: 'Transfer amount must be greater than £0.00.' };
    }

    if (payload.amount > sourceAcc.availableBalance) {
      return {
        success: false,
        message: `Insufficient funds. Available balance: £${sourceAcc.availableBalance.toLocaleString('en-GB', {
          minimumFractionDigits: 2,
        })}`,
      };
    }

    const todayStr = new Date().toISOString().split('T')[0];
    const newTxId = 'tx-' + Date.now();

    if (payload.toType === 'internal' && payload.toAccountId) {
      const destAcc = accounts.find((a) => a.id === payload.toAccountId);
      if (!destAcc) {
        return { success: false, message: 'Destination account not found.' };
      }

      // Reconcile balances
      setAccounts((prev) =>
        prev.map((acc) => {
          if (acc.id === sourceAcc.id) {
            return {
              ...acc,
              balance: Number((acc.balance - payload.amount).toFixed(2)),
              availableBalance: Number((acc.availableBalance - payload.amount).toFixed(2)),
            };
          }
          if (acc.id === destAcc.id) {
            return {
              ...acc,
              balance: Number((acc.balance + payload.amount).toFixed(2)),
              availableBalance: Number((acc.availableBalance + payload.amount).toFixed(2)),
            };
          }
          return acc;
        })
      );

      // Add double-entry synthetic transactions
      const debitTx: Transaction = {
        id: newTxId + '-deb',
        accountId: sourceAcc.id,
        date: todayStr,
        description: `Transfer to ${destAcc.name}`,
        amount: -payload.amount,
        type: 'debit',
        category: 'Transfers',
        status: 'completed',
        reference: payload.reference || 'INTERNAL TRANSFER',
      };

      const creditTx: Transaction = {
        id: newTxId + '-crd',
        accountId: destAcc.id,
        date: todayStr,
        description: `Transfer from ${sourceAcc.name}`,
        amount: payload.amount,
        type: 'credit',
        category: 'Transfers',
        status: 'completed',
        reference: payload.reference || 'INTERNAL TRANSFER',
      };

      setTransactions((prev) => [debitTx, creditTx, ...prev]);
      return {
        success: true,
        message: `Successfully transferred £${payload.amount.toFixed(2)} to ${destAcc.name}.`,
      };
    } else {
      // External UK Faster Payment
      setAccounts((prev) =>
        prev.map((acc) => {
          if (acc.id === sourceAcc.id) {
            return {
              ...acc,
              balance: Number((acc.balance - payload.amount).toFixed(2)),
              availableBalance: Number((acc.availableBalance - payload.amount).toFixed(2)),
            };
          }
          return acc;
        })
      );

      const debitTx: Transaction = {
        id: newTxId,
        accountId: sourceAcc.id,
        date: todayStr,
        description: `UK Faster Payment to ${payload.payeeName || 'External Payee'}`,
        amount: -payload.amount,
        type: 'debit',
        category: 'Transfers',
        status: 'completed',
        reference: payload.reference || 'FASTER PAYMENT',
      };

      setTransactions((prev) => [debitTx, ...prev]);
      return {
        success: true,
        message: `Faster Payment of £${payload.amount.toFixed(2)} sent to ${payload.payeeName || 'recipient'}. Funds verified via Confirmation of Payee.`,
      };
    }
  };

  const toggleCardFreeze = (accountId: string) => {
    setAccounts((prev) =>
      prev.map((acc) => (acc.id === accountId ? { ...acc, isFrozen: !acc.isFrozen } : acc))
    );
  };

  const updateContactlessLimit = (accountId: string, limit: number) => {
    setAccounts((prev) =>
      prev.map((acc) => (acc.id === accountId ? { ...acc, contactlessLimit: limit } : acc))
    );
  };

  const toggleOnlineTransactions = (accountId: string) => {
    setAccounts((prev) =>
      prev.map((acc) =>
        acc.id === accountId ? { ...acc, allowOnlineTransactions: !acc.allowOnlineTransactions } : acc
      )
    );
  };

  return (
    <BankingContext.Provider
      value={{
        currentRoute,
        navigate,
        isLoggedIn,
        user,
        accounts,
        transactions,
        loginAsDemoUser,
        logout,
        transferFunds,
        toggleCardFreeze,
        updateContactlessLimit,
        toggleOnlineTransactions,
        isSearchOpen,
        setIsSearchOpen,
        activeSegment,
        setActiveSegment,
      }}
    >
      {children}
    </BankingContext.Provider>
  );
};

export const useBanking = () => {
  const context = useContext(BankingContext);
  if (!context) {
    throw new Error('useBanking must be used within a BankingProvider');
  }
  return context;
};
