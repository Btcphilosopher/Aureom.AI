package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.TerminalTab
import com.example.ui.TerminalUiState
import com.example.ui.components.FinancialStatCard
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.YieldCurveCanvas
import com.example.ui.theme.*

@Composable
fun RatesOverviewScreen(
    state: TerminalUiState,
    onSelectFixing: (Tenor) -> Unit,
    onNavigateTab: (TerminalTab) -> Unit,
    onApplyScenario: (ScenarioShock) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] High-level Institutional Rates Cards
        item {
            val hibor3m = state.hiborFixings.find { it.tenor == Tenor.M3 }?.rate ?: 3.26875
            val hibor3mChg = state.hiborFixings.find { it.tenor == Tenor.M3 }?.changeBp ?: 2.37
            val honiaRate = state.honiaFixing.overnightRate
            val honiaChg = state.honiaFixing.changeBp

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FinancialStatCard(
                    title = "HIBOR 3M Fixing",
                    value = "${String.format("%.5f", hibor3m)}%",
                    deltaText = "${if (hibor3mChg >= 0) "+" else ""}${String.format("%.2f", hibor3mChg)} bp",
                    isPositiveDelta = hibor3mChg >= 0,
                    badge = { ProvenanceBadge(DataStatus.OFFICIAL) },
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            onSelectFixing(Tenor.M3)
                            onNavigateTab(TerminalTab.FIXING_ENGINE)
                        }
                        .testTag("card_hibor_3m")
                )

                FinancialStatCard(
                    title = "HONIA Overnight",
                    value = "${String.format("%.4f", honiaRate)}%",
                    deltaText = "${if (honiaChg >= 0) "+" else ""}${String.format("%.2f", honiaChg)} bp",
                    subtitle = "Vol: HK$${state.honiaFixing.transactionVolumeHkdBn}B",
                    isPositiveDelta = honiaChg >= 0,
                    badge = { ProvenanceBadge(DataStatus.OFFICIAL) },
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateTab(TerminalTab.BASIS_DESK) }
                        .testTag("card_honia_overnight")
                )
            }
        }

        // [2] HIBOR Benchmark Fixing Grid
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "HIBOR TERM FIXINGS",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "11:15 HKT",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextDim)
                            )
                        }

                        TextButton(
                            onClick = { onNavigateTab(TerminalTab.FIXING_ENGINE) },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("AUDIT QUOTES →", style = MaterialTheme.typography.labelSmall.copy(color = TerminalBlue))
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalCardAlt, RoundedCornerShape(3.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TENOR", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1f))
                        Text("RATE (%)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.3f))
                        Text("PREV (%)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.3f))
                        Text("CHG (bp)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.1f))
                        Text("DISPERSION", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.3f))
                    }

                    // Table Rows
                    state.hiborFixings.forEach { fixing ->
                        val isUp = fixing.changeBp >= 0
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectFixing(fixing.tenor)
                                    onNavigateTab(TerminalTab.FIXING_ENGINE)
                                }
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = fixing.tenor.code,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (fixing.tenor == Tenor.M3) TerminalGold else TextWhite
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = String.format("%.5f", fixing.rate),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextWhite
                                ),
                                modifier = Modifier.weight(1.3f)
                            )
                            Text(
                                text = String.format("%.5f", fixing.previousRate),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = TextDim
                                ),
                                modifier = Modifier.weight(1.3f)
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1.1f)
                            ) {
                                Text(
                                    text = "${if (isUp) "+" else ""}${String.format("%.2f", fixing.changeBp)}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isUp) TerminalEmerald else TerminalRose
                                    )
                                )
                            }
                            Text(
                                text = fixing.qualityMetrics?.dispersionStatus?.take(9) ?: "NORMAL",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (fixing.qualityMetrics?.dispersionStatus?.contains("HIGH") == true) TerminalRose else TerminalCyan,
                                    fontSize = 9.sp
                                ),
                                modifier = Modifier.weight(1.3f)
                            )
                        }
                    }
                }
            }
        }

        // [3] Live Yield Curve Preview
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "HKD YIELD CURVE",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        )
                        TextButton(
                            onClick = { onNavigateTab(TerminalTab.YIELD_CURVE) },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("ANALYZE CURVE →", style = MaterialTheme.typography.labelSmall.copy(color = TerminalBlue))
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    state.calibratedCurve?.nodes?.let { nodes ->
                        YieldCurveCanvas(nodes = nodes, curveColor = TerminalBlue)
                    }
                }
            }
        }

        // [4] HIBOR / HONIA Basis Summary
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "HIBOR / HONIA BASIS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        )
                        TextButton(
                            onClick = { onNavigateTab(TerminalTab.BASIS_DESK) },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("BASIS DESK →", style = MaterialTheme.typography.labelSmall.copy(color = TerminalPurple))
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        state.basisMetrics.take(4).forEach { b ->
                            Surface(
                                color = TerminalCardAlt,
                                shape = RoundedCornerShape(4.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(vertical = 2.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp)) {
                                    Text(
                                        text = "${b.tenor.code} BASIS",
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "+${String.format("%.1f", b.basisBp)}bp",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = TerminalPurple
                                        )
                                    )
                                    Text(
                                        text = b.regime.label,
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 8.sp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // [5] Portfolio Risk & Quick Stress Test Shocks
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PORTFOLIO RISK & SCENARIOS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        )
                        TextButton(
                            onClick = { onNavigateTab(TerminalTab.PORTFOLIO_RISK) },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.height(24.dp)
                        ) {
                            Text("RISK BLOTTER →", style = MaterialTheme.typography.labelSmall.copy(color = TerminalEmerald))
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    val r = state.portfolioRisk
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("TOTAL DV01", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text(
                                text = "HK$ ${String.format("%,.0f", r?.totalDv01Hkd ?: 184200.0)}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                        }
                        Column {
                            Text("HIBOR EXP.", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text(
                                text = "+HK$ ${String.format("%.1f", (r?.hiborExposureHkd ?: 92400000.0) / 1000000.0)}M",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalBlue
                                )
                            )
                        }
                        Column {
                            Text("HONIA EXP.", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text(
                                text = "-HK$ ${String.format("%.1f", kotlin.math.abs(r?.honiaExposureHkd ?: 38200000.0) / 1000000.0)}M",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalRose
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Scenario Buttons
                    Text("QUICK STRESS TEST:", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp))
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            ScenarioQuickButton(label = "+25bp", onClick = {
                                onApplyScenario(ScenarioShock("SCEN_25", "HIBOR +25bp", "Parallel shift +25bp", 25.0))
                            })
                        }
                        item {
                            ScenarioQuickButton(label = "+50bp", onClick = {
                                onApplyScenario(ScenarioShock("SCEN_50", "HIBOR +50bp", "Parallel shift +50bp", 50.0))
                            })
                        }
                        item {
                            ScenarioQuickButton(label = "+100bp", onClick = {
                                onApplyScenario(ScenarioShock("SCEN_100", "HIBOR +100bp", "Parallel shift +100bp", 100.0))
                            })
                        }
                        item {
                            ScenarioQuickButton(label = "Steepener", onClick = {
                                onApplyScenario(ScenarioShock("SCEN_STP", "2s10s Steepener", "Steepener shock", 0.0, CurveShockType.STEEPENER_2S10S))
                            })
                        }
                        item {
                            ScenarioQuickButton(label = "Liq. Crunch", onClick = {
                                onApplyScenario(ScenarioShock("SCEN_LIQ", "Liquidity Crunch", "Liquidity drain", 0.0, CurveShockType.LIQUIDITY_CRUNCH))
                            })
                        }
                    }

                    // Display active scenario impact if present
                    state.scenarioResult?.let { res ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            color = TerminalBg,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = res.scenarioName,
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextWhite, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "P&L: ${if (res.portfolioPnlHkd >= 0) "+" else ""}HK$ ${String.format("%,.0f", res.portfolioPnlHkd)}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (res.portfolioPnlHkd >= 0) TerminalEmerald else TerminalRose
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScenarioQuickButton(label: String, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = TerminalCardAlt,
            contentColor = TerminalBlue
        ),
        shape = RoundedCornerShape(4.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
        modifier = Modifier.height(26.dp)
    ) {
        Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(12.dp))
        Spacer(modifier = Modifier.width(3.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp))
    }
}
