package com.example.engine

import com.example.data.model.*

object ReplayEngine {

    val REPLAY_DATES = listOf(
        "2026-10-05" to "Current Market Regime (Moderating rates, 44.8B Agg Bal)",
        "2024-09-10" to "Pre-Fed Easing Peak (3M HIBOR 4.12%, Tight Liquidity)",
        "2022-03-15" to "Early US Tightening Cycle (3M HIBOR 0.48%, 337B Agg Bal)",
        "2020-01-02" to "Pre-Pandemic Baseline (3M HIBOR 2.43%, 54B Agg Bal)"
    )

    fun reconstructHistoricalState(date: String): HistoricalReplayState {
        return when (date) {
            "2024-09-10" -> {
                val fixings = listOf(
                    createHistoricalFixing(date, Tenor.ON, 3.85421, 3.82100),
                    createHistoricalFixing(date, Tenor.W1, 3.91245, 3.89100),
                    createHistoricalFixing(date, Tenor.W2, 3.94560, 3.92100),
                    createHistoricalFixing(date, Tenor.M1, 4.02150, 3.98500),
                    createHistoricalFixing(date, Tenor.M2, 4.08920, 4.05400),
                    createHistoricalFixing(date, Tenor.M3, 4.12450, 4.10120),
                    createHistoricalFixing(date, Tenor.M6, 4.25680, 4.23100),
                    createHistoricalFixing(date, Tenor.M12, 4.38920, 4.36500)
                )
                val honia = HONIAFixing(date, 3.7845, 3.7520, 3.25, 18.5, dataStatus = DataStatus.OBSERVED)
                val macro = MacroEnvironment(date, 7.7985, 45.2, 5.75, 5.33, 5.30, -32.5, -450.0, DataStatus.OBSERVED)
                val dummyCurve = CurveEngine.calibrateCurve(CurveType.HIBOR_PROJECTION, date, mapOf(Tenor.M3 to 4.1245))
                val risk = RiskEngine.calculatePortfolioRisk(emptyList(), emptyList(), emptyList(), dummyCurve)
                HistoricalReplayState(date, fixings, honia, macro, risk, true)
            }
            "2022-03-15" -> {
                val fixings = listOf(
                    createHistoricalFixing(date, Tenor.ON, 0.05214, 0.05100),
                    createHistoricalFixing(date, Tenor.W1, 0.08450, 0.08100),
                    createHistoricalFixing(date, Tenor.W2, 0.12500, 0.12000),
                    createHistoricalFixing(date, Tenor.M1, 0.25410, 0.24100),
                    createHistoricalFixing(date, Tenor.M2, 0.38400, 0.37000),
                    createHistoricalFixing(date, Tenor.M3, 0.48520, 0.46500),
                    createHistoricalFixing(date, Tenor.M6, 0.85400, 0.82100),
                    createHistoricalFixing(date, Tenor.M12, 1.45200, 1.41000)
                )
                val honia = HONIAFixing(date, 0.0485, 0.0450, 0.35, 24.2, dataStatus = DataStatus.OBSERVED)
                val macro = MacroEnvironment(date, 7.8240, 337.5, 0.75, 0.08, 0.05, -5.2, -45.0, DataStatus.OBSERVED)
                val dummyCurve = CurveEngine.calibrateCurve(CurveType.HIBOR_PROJECTION, date, mapOf(Tenor.M3 to 0.4852))
                val risk = RiskEngine.calculatePortfolioRisk(emptyList(), emptyList(), emptyList(), dummyCurve)
                HistoricalReplayState(date, fixings, honia, macro, risk, true)
            }
            "2020-01-02" -> {
                val fixings = listOf(
                    createHistoricalFixing(date, Tenor.ON, 1.85420, 1.84100),
                    createHistoricalFixing(date, Tenor.W1, 2.05120, 2.03500),
                    createHistoricalFixing(date, Tenor.W2, 2.18400, 2.16500),
                    createHistoricalFixing(date, Tenor.M1, 2.38500, 2.37000),
                    createHistoricalFixing(date, Tenor.M2, 2.41200, 2.40100),
                    createHistoricalFixing(date, Tenor.M3, 2.43500, 2.42100),
                    createHistoricalFixing(date, Tenor.M6, 2.45800, 2.44500),
                    createHistoricalFixing(date, Tenor.M12, 2.49200, 2.48100)
                )
                val honia = HONIAFixing(date, 1.8210, 1.8100, 1.10, 15.6, dataStatus = DataStatus.OBSERVED)
                val macro = MacroEnvironment(date, 7.7865, 54.1, 2.00, 1.55, 1.52, -12.4, -120.0, DataStatus.OBSERVED)
                val dummyCurve = CurveEngine.calibrateCurve(CurveType.HIBOR_PROJECTION, date, mapOf(Tenor.M3 to 2.435))
                val risk = RiskEngine.calculatePortfolioRisk(emptyList(), emptyList(), emptyList(), dummyCurve)
                HistoricalReplayState(date, fixings, honia, macro, risk, true)
            }
            else -> {
                // 2026-10-05 Current baseline
                val fixings = listOf(
                    createHistoricalFixing("2026-10-05", Tenor.ON, 2.72393, 2.70500),
                    createHistoricalFixing("2026-10-05", Tenor.W1, 2.75738, 2.74100),
                    createHistoricalFixing("2026-10-05", Tenor.W2, 2.77726, 2.76200),
                    createHistoricalFixing("2026-10-05", Tenor.M1, 2.94220, 2.92800),
                    createHistoricalFixing("2026-10-05", Tenor.M2, 3.11327, 3.09500),
                    createHistoricalFixing("2026-10-05", Tenor.M3, 3.26875, 3.24500),
                    createHistoricalFixing("2026-10-05", Tenor.M6, 3.52964, 3.51200),
                    createHistoricalFixing("2026-10-05", Tenor.M12, 4.01351, 3.99800)
                )
                val honia = HONIAFixing("2026-10-05", 2.7050, 2.6840, 2.10, 21.4, dataStatus = DataStatus.OFFICIAL)
                val macro = MacroEnvironment("2026-10-05", 7.7785, 44.8, 4.75, 4.50, 4.38, -18.4, -245.0, DataStatus.OFFICIAL)
                val dummyCurve = CurveEngine.calibrateCurve(CurveType.HIBOR_PROJECTION, "2026-10-05", mapOf(Tenor.M3 to 3.26875))
                val risk = RiskEngine.calculatePortfolioRisk(emptyList(), emptyList(), emptyList(), dummyCurve)
                HistoricalReplayState("2026-10-05", fixings, honia, macro, risk, false)
            }
        }
    }

    fun getBacktestStrategies(): List<BacktestStrategy> {
        return listOf(
            BacktestStrategy(
                id = "STRAT_STEEPENER_2S10S",
                name = "HKD 2s10s Curve Steepener",
                description = "Pay fixed 10Y HKD IRS vs Receive fixed 2Y HKD IRS on rate cutting cycle anticipation",
                totalReturnPct = 14.8,
                annualizedSharpe = 1.62,
                maxDrawdownPct = -4.2,
                winRatePct = 68.4,
                tradesCount = 142
            ),
            BacktestStrategy(
                id = "STRAT_BASIS_ARB",
                name = "HIBOR-HONIA 3M Basis Reversion",
                description = "Long HONIA OIS vs Short HIBOR 3M IRS when basis z-score exceeds +2.0 sigma",
                totalReturnPct = 9.4,
                annualizedSharpe = 2.15,
                maxDrawdownPct = -1.8,
                winRatePct = 76.2,
                tradesCount = 88
            ),
            BacktestStrategy(
                id = "STRAT_CARRY_ROLL",
                name = "5Y HKD Swap Positive Carry & Roll",
                description = "Receive fixed 5Y swap rolling down the steepest portion of the HKD curve",
                totalReturnPct = 11.2,
                annualizedSharpe = 1.44,
                maxDrawdownPct = -5.6,
                winRatePct = 62.8,
                tradesCount = 64
            )
        )
    }

    private fun createHistoricalFixing(date: String, tenor: Tenor, rate: Double, prev: Double): HIBORFixing {
        return HIBORFixing(
            fixingDate = date,
            publicationTimestamp = "$date 11:15:00 HKT",
            tenor = tenor,
            rate = rate,
            previousRate = prev,
            changeBp = FixingEngine.roundToPrecision((rate - prev) * 100.0, 2),
            dataStatus = DataStatus.OBSERVED
        )
    }
}
