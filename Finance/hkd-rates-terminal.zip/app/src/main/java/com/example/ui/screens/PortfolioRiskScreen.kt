package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.TerminalUiState
import com.example.ui.components.FinancialStatCard
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun PortfolioRiskScreen(
    state: TerminalUiState,
    onApplyScenario: (ScenarioShock) -> Unit,
    modifier: Modifier = Modifier
) {
    val r = state.portfolioRisk

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] Portfolio Key Risk Overview
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "PORTFOLIO RISK PROFILE",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                            Text(
                                text = "Institutional Multi-Asset Book  •  Currency: HKD",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextDim)
                            )
                        }
                        ProvenanceBadge(status = DataStatus.VERIFIED)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("NET MARKET VALUE (PV)", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text(
                                text = "HK$ ${String.format("%,.0f", r?.totalPvHkd ?: 0.0)}",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("TOTAL DV01", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text(
                                text = "HK$ ${String.format("%,.0f", r?.totalDv01Hkd ?: 0.0)} / bp",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalEmerald
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("HIBOR Exp: +HK$ ${String.format("%.1f", (r?.hiborExposureHkd ?: 0.0) / 1000000.0)}M", style = MaterialTheme.typography.bodySmall.copy(color = TerminalBlue))
                        Text("HONIA Exp: -HK$ ${String.format("%.1f", kotlin.math.abs(r?.honiaExposureHkd ?: 0.0) / 1000000.0)}M", style = MaterialTheme.typography.bodySmall.copy(color = TerminalRose))
                        Text("Convexity: ${r?.totalConvexity}", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted))
                    }
                }
            }
        }

        // [2] Key-Rate DV01 Bucket Ladder
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "KEY-RATE DV01 RISK LADDER (BY MATURITY BUCKET)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    r?.keyRateLadder?.forEach { kr ->
                        val maxDv01 = 60000.0
                        val barRatio = (kotlin.math.abs(kr.dv01Hkd) / maxDv01).coerceIn(0.05, 1.0).toFloat()
                        val isPositive = kr.dv01Hkd >= 0

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = kr.bucket.code,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                ),
                                modifier = Modifier.width(36.dp)
                            )

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(14.dp)
                                    .background(TerminalCardAlt, RoundedCornerShape(2.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(barRatio)
                                        .background(if (isPositive) TerminalEmerald else TerminalRose, RoundedCornerShape(2.dp))
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "HK$ ${String.format("%,.0f", kr.dv01Hkd)}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextWhite,
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.width(80.dp)
                            )
                        }
                    }
                }
            }
        }

        // [3] P&L Attribution Breakdown
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "DAILY P&L ATTRIBUTION WATERFALL",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val attr = r?.plAttribution
                    if (attr != null) {
                        AttributionRow(label = "TOTAL P&L", value = attr.totalPnlHkd, isTotal = true)
                        AttributionRow(label = "Curve Shift", value = attr.curveShiftPnlHkd)
                        AttributionRow(label = "Carry / Roll-Down", value = attr.carryPnlHkd)
                        AttributionRow(label = "Fixing Move", value = attr.fixingPnlHkd)
                        AttributionRow(label = "Basis Move", value = attr.basisPnlHkd)
                        AttributionRow(label = "FX Component", value = attr.fxPnlHkd)
                    }
                }
            }
        }

        // [4] Active Position Blotter
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "TRADING BOOK POSITIONS (${state.portfolioPositions.size})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalCardAlt, RoundedCornerShape(3.dp))
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("INST", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp), modifier = Modifier.weight(1f))
                        Text("NOTIONAL", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp), modifier = Modifier.weight(1.2f))
                        Text("PV (HKD)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp), modifier = Modifier.weight(1.3f))
                        Text("DV01", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp), modifier = Modifier.weight(1f))
                    }

                    state.portfolioPositions.forEach { pos ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(pos.instrumentType, style = MaterialTheme.typography.bodySmall.copy(color = TextWhite, fontWeight = FontWeight.SemiBold), modifier = Modifier.weight(1f))
                            Text("${(pos.notionalHkd / 1000000).toInt()}M", style = MaterialTheme.typography.bodySmall.copy(color = TextDim), modifier = Modifier.weight(1.2f))
                            Text(String.format("%,.0f", pos.pvHkd), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TextWhite), modifier = Modifier.weight(1.3f))
                            Text(String.format("%,.0f", pos.dv01Hkd), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalEmerald), modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AttributionRow(label: String, value: Double, isTotal: Boolean = false) {
    val isPositive = value >= 0
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = if (isTotal) 4.dp else 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = if (isTotal) MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextWhite)
            else MaterialTheme.typography.bodySmall.copy(color = TextMuted)
        )
        Text(
            text = "${if (isPositive) "+" else ""}HK$ ${String.format("%,.0f", value)}",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isTotal) FontWeight.Bold else FontWeight.Normal,
                color = if (isPositive) TerminalEmerald else TerminalRose
            )
        )
    }
}
