package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Terminal Institutional Color Palette
val TerminalBg = Color(0xFF0A0E17)
val TerminalCardBg = Color(0xFF111827)
val TerminalCardAlt = Color(0xFF162032)
val TerminalBorder = Color(0xFF1E293B)
val TerminalBorderBright = Color(0xFF334155)

// Accent and Benchmark Colors
val TerminalBlue = Color(0xFF38BDF8) // Primary Cyan/Blue
val TerminalNavy = Color(0xFF0F172A)
val TerminalRedHK = Color(0xFFE63946) // Hong Kong Crimson
val TerminalGold = Color(0xFFFBBF24) // Fixing gold
val TerminalEmerald = Color(0xFF10B981) // Up / Positive
val TerminalRose = Color(0xFFF43F5E) // Down / Negative
val TerminalPurple = Color(0xFFA78BFA) // Analytics / OIS
val TerminalCyan = Color(0xFF06B6D4) // Forward Curve

// Neutral Monospace Text
val TextWhite = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
val TextDim = Color(0xFF64748B)
val TextHighlight = Color(0xFF38BDF8)

// Status & Provenance
val BadgeOfficial = Color(0xFF059669)
val BadgeObserved = Color(0xFF0284C7)
val BadgeDerived = Color(0xFF7C3AED)
val BadgeSynthetic = Color(0xFFD97706)
val BadgeWarning = Color(0xFFDC2626)
