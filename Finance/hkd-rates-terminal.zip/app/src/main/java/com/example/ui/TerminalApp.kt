package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.CommandPaletteDialog
import com.example.ui.components.TerminalHeader
import com.example.ui.screens.*
import com.example.ui.theme.*

@Composable
fun TerminalApp(
    viewModel: TerminalViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var isCliOpen by remember { mutableStateOf(false) }

    // BackHandler to return to Overview screen if on another tab
    if (state.activeTab != TerminalTab.RATES_OVERVIEW) {
        BackHandler {
            viewModel.selectTab(TerminalTab.RATES_OVERVIEW)
        }
    }

    Scaffold(
        topBar = {
            TerminalHeader(
                macro = state.macro,
                selectedDate = state.selectedDate,
                isLiveFeedActive = state.isLiveFeedActive,
                isReplayMode = state.isReplayMode,
                onToggleLive = { viewModel.toggleLiveFeed() },
                onOpenCli = { isCliOpen = true }
            )
        },
        bottomBar = {
            // Horizontal Terminal Navigation Switcher
            Surface(
                color = TerminalCardBg,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TerminalBorder, RoundedCornerShape(0.dp))
            ) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(TerminalTab.entries) { tab ->
                        val isSelected = tab == state.activeTab
                        Surface(
                            color = if (isSelected) TerminalBlue else TerminalCardAlt,
                            shape = RoundedCornerShape(3.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) TerminalBlue else TerminalBorder
                            ),
                            modifier = Modifier
                                .clickable { viewModel.selectTab(tab) }
                                .testTag("nav_tab_${tab.name}")
                        ) {
                            Text(
                                text = tab.label.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) TerminalBg else TextWhite,
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        },
        containerColor = TerminalBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (state.activeTab) {
                TerminalTab.RATES_OVERVIEW -> RatesOverviewScreen(
                    state = state,
                    onSelectFixing = { viewModel.selectFixingTenor(it) },
                    onNavigateTab = { viewModel.selectTab(it) },
                    onApplyScenario = { viewModel.applyScenario(it) }
                )
                TerminalTab.FIXING_ENGINE -> FixingEngineScreen(
                    state = state,
                    onSelectTenor = { viewModel.selectFixingTenor(it) }
                )
                TerminalTab.YIELD_CURVE -> CurveScreen(
                    state = state,
                    onSelectCurveType = { viewModel.setCurveType(it) },
                    onSelectInterpolation = { viewModel.setInterpolationMethod(it) }
                )
                TerminalTab.BASIS_DESK -> BasisScreen(
                    state = state
                )
                TerminalTab.PRICING_LAB -> PricingScreen(
                    state = state,
                    onUpdateSwap = { notional, mat, fix, payerRec ->
                        viewModel.updateSwapParameters(notional, mat, fix, payerRec)
                    },
                    onUpdateFra = { name, strike, notional ->
                        viewModel.updateFraParameters(name, strike, notional)
                    }
                )
                TerminalTab.PORTFOLIO_RISK -> PortfolioRiskScreen(
                    state = state,
                    onApplyScenario = { viewModel.applyScenario(it) }
                )
                TerminalTab.TREASURY_DESK -> TreasuryScreen(
                    state = state
                )
                TerminalTab.FORECAST_LAB -> ForecastingScreen(
                    state = state,
                    onSelectModel = { model, tenor -> viewModel.selectForecastModel(model, tenor) }
                )
                TerminalTab.DIGITAL_TWIN -> DigitalTwinScreen(
                    state = state,
                    onUpdateShocks = { us, liq, peg -> viewModel.updateDigitalTwinShocks(us, liq, peg) }
                )
                TerminalTab.REPLAY_BACKTEST -> ReplayBacktestScreen(
                    state = state,
                    onSelectReplayDate = { viewModel.setReplayDate(it) }
                )
                TerminalTab.AUDIT_REPORTS -> AuditReportScreen(
                    state = state
                )
            }
        }

        // Command Palette Dialog
        CommandPaletteDialog(
            isOpen = isCliOpen,
            cliInput = state.cliInput,
            cliOutput = state.cliOutput,
            onInputChange = { viewModel.updateCliInput(it) },
            onExecuteCommand = { viewModel.executeCliCommand(it) },
            onDismiss = { isCliOpen = false }
        )
    }
}
