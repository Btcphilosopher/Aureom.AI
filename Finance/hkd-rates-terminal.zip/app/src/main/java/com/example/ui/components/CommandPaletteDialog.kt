package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.*

@Composable
fun CommandPaletteDialog(
    isOpen: Boolean,
    cliInput: String,
    cliOutput: String,
    onInputChange: (String) -> Unit,
    onExecuteCommand: (String) -> Unit,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val sampleCommands = listOf(
        "hibor 3M",
        "honia",
        "curve hkd",
        "forward 3M 6M",
        "basis",
        "risk",
        "scenario +50bp",
        "scenario steepener",
        "replay 2024-09-10",
        "report"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBlue),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.75f)
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "HKD RATES CLI WORKSTATION",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = TerminalBlue,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close CLI",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick command pills
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(sampleCommands) { cmd ->
                        Surface(
                            color = TerminalCardAlt,
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                            modifier = Modifier.clickable {
                                onInputChange(cmd)
                                onExecuteCommand(cmd)
                            }
                        ) {
                            Text(
                                text = cmd,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TerminalCyan,
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Terminal Output Area
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(TerminalBg, RoundedCornerShape(4.dp))
                        .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        item {
                            Text(
                                text = cliOutput.ifEmpty { "HKD RATES COMMAND PALETTE INITIALIZED." },
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = TextWhite,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = cliInput,
                        onValueChange = onInputChange,
                        placeholder = { Text("e.g. hibor 3M, curve, basis, risk...", style = MaterialTheme.typography.bodySmall.copy(color = TextDim)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TerminalBlue,
                            unfocusedBorderColor = TerminalBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            cursorColor = TerminalBlue
                        ),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cli_command_input")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { onExecuteCommand(cliInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalBlue),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .height(52.dp)
                            .testTag("execute_cli_command_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Run",
                            tint = TerminalBg,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
