package com.example.engine

import com.example.data.model.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.round

object PricingEngine {

    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

    fun priceSwap(
        swap: SwapTrade,
        discountCurve: CalibratedCurve,
        projectionCurve: CalibratedCurve
    ): SwapValuation {
        val startDate = try {
            LocalDate.parse(swap.effectiveDate, dateFormatter)
        } catch (e: Exception) {
            LocalDate.now()
        }

        val totalPeriods = (swap.maturityYears * (12 / swap.paymentFrequencyMonths)).toInt().coerceAtLeast(1)
        val periodMonths = swap.paymentFrequencyMonths.toLong()
        val fixedCashflows = mutableListOf<SwapCashflow>()
        val floatCashflows = mutableListOf<SwapCashflow>()

        var currentStart = startDate
        var fixedLegPv = 0.0
        var floatLegPv = 0.0
        var annuity = 0.0

        for (i in 1..totalPeriods) {
            val currentEnd = currentStart.plusMonths(periodMonths)
            val paymentDate = DayCountEngine.adjustDate(currentEnd, BusinessDayConvention.MODIFIED_FOLLOWING)
            val fixingDate = DayCountEngine.addBusinessDays(currentStart, -2)

            val startYears = DayCountEngine.calculateDayFraction(startDate, currentStart, DayCountConvention.ACT_365F)
            val endYears = DayCountEngine.calculateDayFraction(startDate, currentEnd, DayCountConvention.ACT_365F)
            val tau = DayCountEngine.calculateDayFraction(currentStart, currentEnd, swap.dayCount)

            val df = CurveEngine.getDiscountFactor(endYears, discountCurve)
            annuity += tau * df

            // Fixed Leg Cashflow
            val fixedInterest = swap.notionalHkd * (swap.fixedRatePct / 100.0) * tau
            val fixedPv = fixedInterest * df
            fixedLegPv += fixedPv

            fixedCashflows.add(
                SwapCashflow(
                    periodIndex = i,
                    periodStart = currentStart.format(dateFormatter),
                    periodEnd = currentEnd.format(dateFormatter),
                    paymentDate = paymentDate.format(dateFormatter),
                    fixingDate = fixingDate.format(dateFormatter),
                    notional = swap.notionalHkd,
                    ratePct = swap.fixedRatePct,
                    dayFraction = tau,
                    interestAmountHkd = round(fixedInterest * 100.0) / 100.0,
                    discountFactor = FixingEngine.roundToPrecision(df, 6),
                    presentValueHkd = round(fixedPv * 100.0) / 100.0,
                    isFixedLeg = true
                )
            )

            // Floating Leg Cashflow
            val fwdRate = CurveEngine.calculateForwardRate(startYears, endYears, projectionCurve)
            val effectiveFloatRate = fwdRate + (swap.floatingSpreadBp / 100.0)
            val floatInterest = swap.notionalHkd * (effectiveFloatRate / 100.0) * tau
            val floatPv = floatInterest * df
            floatLegPv += floatPv

            floatCashflows.add(
                SwapCashflow(
                    periodIndex = i,
                    periodStart = currentStart.format(dateFormatter),
                    periodEnd = currentEnd.format(dateFormatter),
                    paymentDate = paymentDate.format(dateFormatter),
                    fixingDate = fixingDate.format(dateFormatter),
                    notional = swap.notionalHkd,
                    ratePct = effectiveFloatRate,
                    dayFraction = tau,
                    interestAmountHkd = round(floatInterest * 100.0) / 100.0,
                    discountFactor = FixingEngine.roundToPrecision(df, 6),
                    presentValueHkd = round(floatPv * 100.0) / 100.0,
                    isFixedLeg = false
                )
            )

            currentStart = currentEnd
        }

        val netPv = when (swap.payerReceiver) {
            PayerReceiver.PAY_FIXED -> floatLegPv - fixedLegPv
            PayerReceiver.RECEIVE_FIXED -> fixedLegPv - floatLegPv
        }

        val fairRate = if (annuity > 0.0) (floatLegPv / (swap.notionalHkd * annuity)) * 100.0 else swap.fixedRatePct
        val pv01 = swap.notionalHkd * annuity * 0.0001
        val dv01 = if (swap.payerReceiver == PayerReceiver.PAY_FIXED) pv01 else -pv01
        val modDuration = if (swap.fixedRatePct > 0.0) annuity / (1.0 + swap.fixedRatePct / 100.0) else swap.maturityYears
        val convexity = (swap.maturityYears.pow(2) + swap.maturityYears) / 2.0

        val combinedCashflows = fixedCashflows + floatCashflows

        return SwapValuation(
            tradeId = swap.tradeId,
            fixedLegPvHkd = round(fixedLegPv * 100.0) / 100.0,
            floatingLegPvHkd = round(floatLegPv * 100.0) / 100.0,
            netPvHkd = round(netPv * 100.0) / 100.0,
            fairSwapRatePct = FixingEngine.roundToPrecision(fairRate, 4),
            dv01Hkd = round(dv01 * 100.0) / 100.0,
            pv01Hkd = round(pv01 * 100.0) / 100.0,
            modifiedDuration = FixingEngine.roundToPrecision(modDuration, 2),
            convexity = FixingEngine.roundToPrecision(convexity, 2),
            cashflows = combinedCashflows
        )
    }

    fun priceFRA(fra: FRATrade, curve: CalibratedCurve): FRAValuation {
        val startYears = fra.fraName.startMonths / 12.0
        val endYears = fra.fraName.endMonths / 12.0
        val tau = endYears - startYears
        val impliedFwd = CurveEngine.calculateForwardRate(startYears, endYears, curve)

        val l = impliedFwd / 100.0
        val k = fra.strikeRatePct / 100.0
        val rateDiff = if (fra.isPayFixed) (l - k) else (k - l)

        // Standard FRA settlement formula: [(L - K) * tau / (1 + L * tau)] * Notional
        val settlement = (rateDiff * tau / (1.0 + l * tau)) * fra.notionalHkd
        val df = CurveEngine.getDiscountFactor(startYears, curve)
        val pv = settlement * df

        val dv01 = (fra.notionalHkd * tau / (1.0 + l * tau)) * 0.0001 * (if (fra.isPayFixed) 1.0 else -1.0)
        val pnlBp = (impliedFwd - fra.strikeRatePct) * 100.0 * (if (fra.isPayFixed) 1.0 else -1.0)

        return FRAValuation(
            tradeId = fra.tradeId,
            impliedForwardRatePct = FixingEngine.roundToPrecision(impliedFwd, 4),
            settlementAmountHkd = round(settlement * 100.0) / 100.0,
            presentValueHkd = round(pv * 100.0) / 100.0,
            dv01Hkd = round(dv01 * 100.0) / 100.0,
            pnlBp = round(pnlBp * 100.0) / 100.0
        )
    }

    fun priceFRN(frn: FRNTrade, currentBenchmarkRate: Double, discountCurve: CalibratedCurve): BondValuation {
        val couponPct = currentBenchmarkRate + (frn.spreadBp / 100.0)
        val totalPeriods = (frn.maturityYears * (12 / frn.couponFrequencyMonths)).toInt().coerceAtLeast(1)
        val tau = frn.couponFrequencyMonths / 12.0

        var pv = 0.0
        for (i in 1..totalPeriods) {
            val t = i * tau
            val df = CurveEngine.getDiscountFactor(t, discountCurve)
            val coupon = 100.0 * (couponPct / 100.0) * tau
            pv += coupon * df
        }
        val principalDf = CurveEngine.getDiscountFactor(frn.maturityYears, discountCurve)
        val dirtyPrice = pv + 100.0 * principalDf
        val cleanPrice = dirtyPrice - (couponPct * 0.25 * (30.0 / 365.0)) // approx accrued interest

        val ytm = couponPct + (100.0 - cleanPrice) / frn.maturityYears
        val dv01 = (frn.notionalHkd / 100.0) * frn.maturityYears * 0.01 * 0.1

        return BondValuation(
            tradeId = frn.tradeId,
            currentCouponPct = FixingEngine.roundToPrecision(couponPct, 4),
            cleanPricePct = FixingEngine.roundToPrecision(cleanPrice, 3),
            dirtyPricePct = FixingEngine.roundToPrecision(dirtyPrice, 3),
            yieldToMaturityPct = FixingEngine.roundToPrecision(ytm, 3),
            discountMarginBp = frn.spreadBp,
            dv01Hkd = round(dv01 * 100.0) / 100.0,
            modifiedDuration = FixingEngine.roundToPrecision(tau, 2)
        )
    }

    fun priceCorporateLoan(loan: LoanFacility, currentHibor3m: Double): LoanPricingResult {
        val totalSpreadBp = loan.creditSpreadBp + loan.liquiditySpreadBp + loan.capitalChargeBp + loan.facilityFeeBp
        val allInRatePct = currentHibor3m + (totalSpreadBp / 100.0)

        val annualInterest = loan.principalHkd * (allInRatePct / 100.0)
        val monthlyInterest = annualInterest / 12.0
        val sens25bp = loan.principalHkd * 0.0025

        // Break-even fixed hedge rate: current HIBOR + anticipated term premium
        val breakEvenHedge = currentHibor3m + 0.35 + (totalSpreadBp / 100.0)

        return LoanPricingResult(
            facilityId = loan.facilityId,
            baseHiborRatePct = currentHibor3m,
            totalSpreadBp = totalSpreadBp,
            allInRatePct = FixingEngine.roundToPrecision(allInRatePct, 4),
            annualInterestHkd = round(annualInterest * 100.0) / 100.0,
            monthlyInterestHkd = round(monthlyInterest * 100.0) / 100.0,
            interestSensitivityPer25bpHkd = round(sens25bp * 100.0) / 100.0,
            breakEvenHedgeRatePct = FixingEngine.roundToPrecision(breakEvenHedge, 4)
        )
    }
}
