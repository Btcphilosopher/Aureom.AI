package com.example.engine

import com.example.data.model.Tenor
import kotlin.math.round

data class BankBalanceSheet(
    val totalAssetsHkdBn: Double = 850.0,
    val loansHkdBn: Double = 520.0, // Floating HIBOR linked
    val securitiesHkdBn: Double = 210.0, // Fixed/Floating EFBs
    val placementsHkdBn: Double = 120.0, // Interbank
    val totalLiabilitiesHkdBn: Double = 770.0,
    val casaDepositsHkdBn: Double = 340.0, // Low-cost sticky
    val timeDepositsHkdBn: Double = 320.0, // Rate sensitive
    val wholesaleFundingHkdBn: Double = 110.0,
    val equityHkdBn: Double = 80.0
)

data class TreasurySensitivityResult(
    val baseNiiHkdM: Double,
    val baseNimPct: Double,
    val shockedNiiHkdM: Double,
    val shockedNimPct: Double,
    val niiDeltaHkdM: Double,
    val nimDeltaBp: Double,
    val repricingGap1MHkdBn: Double,
    val repricingGap3MHkdBn: Double,
    val durationGapYears: Double
)

data class CorporateHedgeComparison(
    val unhedgedTotalInterestHkdM: Double,
    val hedgedTotalInterestHkdM: Double,
    val hedgeSavingsHkdM: Double,
    val effectiveFixedRatePct: Double,
    val floatingRateStressPeakPct: Double
)

object TreasuryEngine {

    fun calculateBankTreasury(
        balanceSheet: BankBalanceSheet = BankBalanceSheet(),
        hibor3mPct: Double,
        shockBp: Double = 0.0
    ): TreasurySensitivityResult {
        val effectiveHibor = hibor3mPct + (shockBp / 100.0)

        // Asset yields
        val loanYield = effectiveHibor + 1.65 // Margin over HIBOR
        val securitiesYield = effectiveHibor - 0.15
        val placementYield = effectiveHibor - 0.05
        val totalInterestIncomeBn = (balanceSheet.loansHkdBn * (loanYield / 100.0)) +
                (balanceSheet.securitiesHkdBn * (securitiesYield / 100.0)) +
                (balanceSheet.placementsHkdBn * (placementYield / 100.0))

        // Liability costs (CASA beta is lower ~35%, Time Deposit beta is ~85%)
        val casaCost = (effectiveHibor * 0.35).coerceAtLeast(0.12)
        val timeDepositCost = (effectiveHibor * 0.88)
        val wholesaleCost = effectiveHibor + 0.10
        val totalInterestExpenseBn = (balanceSheet.casaDepositsHkdBn * (casaCost / 100.0)) +
                (balanceSheet.timeDepositsHkdBn * (timeDepositCost / 100.0)) +
                (balanceSheet.wholesaleFundingHkdBn * (wholesaleCost / 100.0))

        val niiBn = totalInterestIncomeBn - totalInterestExpenseBn
        val niiM = niiBn * 1000.0
        val nimPct = (niiBn / balanceSheet.totalAssetsHkdBn) * 100.0

        // Calculate baseline without shock
        val baseLoanYield = hibor3mPct + 1.65
        val baseSecuritiesYield = hibor3mPct - 0.15
        val basePlacementYield = hibor3mPct - 0.05
        val baseIncomeBn = (balanceSheet.loansHkdBn * (baseLoanYield / 100.0)) +
                (balanceSheet.securitiesHkdBn * (baseSecuritiesYield / 100.0)) +
                (balanceSheet.placementsHkdBn * (basePlacementYield / 100.0))

        val baseCasaCost = (hibor3mPct * 0.35).coerceAtLeast(0.12)
        val baseTdCost = (hibor3mPct * 0.88)
        val baseWsCost = hibor3mPct + 0.10
        val baseExpenseBn = (balanceSheet.casaDepositsHkdBn * (baseCasaCost / 100.0)) +
                (balanceSheet.timeDepositsHkdBn * (baseTdCost / 100.0)) +
                (balanceSheet.wholesaleFundingHkdBn * (baseWsCost / 100.0))

        val baseNiiM = (baseIncomeBn - baseExpenseBn) * 1000.0
        val baseNimPct = ((baseIncomeBn - baseExpenseBn) / balanceSheet.totalAssetsHkdBn) * 100.0

        val repricingGap1M = (balanceSheet.loansHkdBn * 0.70) - (balanceSheet.timeDepositsHkdBn * 0.45 + balanceSheet.wholesaleFundingHkdBn * 0.80)
        val repricingGap3M = (balanceSheet.loansHkdBn * 0.90) - (balanceSheet.timeDepositsHkdBn * 0.75 + balanceSheet.wholesaleFundingHkdBn)

        return TreasurySensitivityResult(
            baseNiiHkdM = round(baseNiiM * 10.0) / 10.0,
            baseNimPct = FixingEngine.roundToPrecision(baseNimPct, 3),
            shockedNiiHkdM = round(niiM * 10.0) / 10.0,
            shockedNimPct = FixingEngine.roundToPrecision(nimPct, 3),
            niiDeltaHkdM = round((niiM - baseNiiM) * 10.0) / 10.0,
            nimDeltaBp = round((nimPct - baseNimPct) * 10000.0) / 100.0,
            repricingGap1MHkdBn = round(repricingGap1M * 10.0) / 10.0,
            repricingGap3MHkdBn = round(repricingGap3M * 10.0) / 10.0,
            durationGapYears = 1.45
        )
    }

    fun optimizeCorporateHedge(
        loanPrincipalHkdM: Double = 500.0,
        spreadBp: Double = 120.0,
        baseHiborPct: Double = 3.26875,
        swapFixedRatePct: Double = 3.4500,
        anticipatedShockBp: Double = 75.0,
        tenorYears: Double = 5.0
    ): CorporateHedgeComparison {
        val totalSpreadPct = spreadBp / 100.0
        val unhedgedFloatingAvg = baseHiborPct + (anticipatedShockBp / 200.0) + totalSpreadPct
        val unhedgedTotal = loanPrincipalHkdM * (unhedgedFloatingAvg / 100.0) * tenorYears

        val hedgedFixedAvg = swapFixedRatePct + totalSpreadPct
        val hedgedTotal = loanPrincipalHkdM * (hedgedFixedAvg / 100.0) * tenorYears

        val savings = unhedgedTotal - hedgedTotal

        return CorporateHedgeComparison(
            unhedgedTotalInterestHkdM = round(unhedgedTotal * 10.0) / 10.0,
            hedgedTotalInterestHkdM = round(hedgedTotal * 10.0) / 10.0,
            hedgeSavingsHkdM = round(savings * 10.0) / 10.0,
            effectiveFixedRatePct = FixingEngine.roundToPrecision(hedgedFixedAvg, 3),
            floatingRateStressPeakPct = FixingEngine.roundToPrecision(baseHiborPct + (anticipatedShockBp / 100.0) + totalSpreadPct, 3)
        )
    }
}
