package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.engine.FixingEngine
import com.example.ui.theme.*

@Composable
fun TerminalHeader(
    macro: MacroEnvironment,
    selectedDate: String,
    isLiveFeedActive: Boolean,
    isReplayMode: Boolean,
    onToggleLive: () -> Unit,
    onOpenCli: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = TerminalCardBg,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, TerminalBorder, RoundedCornerShape(0.dp))
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            // Top branding row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(if (isLiveFeedActive) TerminalEmerald else if (isReplayMode) TerminalGold else TerminalBlue)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "HKD RATES TERMINAL",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "TMA/HKAB",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TerminalRedHK,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isReplayMode) {
                        Surface(
                            color = TerminalGold.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalGold)
                        ) {
                            Text(
                                text = "REPLAY: $selectedDate",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TerminalGold,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    // Live toggle
                    FilledTonalButton(
                        onClick = onToggleLive,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (isLiveFeedActive) TerminalEmerald.copy(alpha = 0.2f) else TerminalCardAlt,
                            contentColor = if (isLiveFeedActive) TerminalEmerald else TextMuted
                        ),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(28.dp)
                            .testTag("toggle_live_feed_button")
                    ) {
                        Icon(
                            imageVector = if (isLiveFeedActive) Icons.Default.Sensors else Icons.Default.SensorsOff,
                            contentDescription = "Live feed toggle",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isLiveFeedActive) "LIVE" else "PAUSED", style = MaterialTheme.typography.labelSmall)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = onOpenCli,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("open_command_palette_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = "Command terminal",
                            tint = TerminalBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Macro Telemetry Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalBg, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MacroTickerItem(label = "USD/HKD", value = String.format("%.4f", macro.usdHkdSpot), isHighlight = true)
                MacroTickerItem(label = "AGG BAL", value = "HK$${FixingEngine.roundToPrecision(macro.hkmaAggregateBalanceBn, 1)}B")
                MacroTickerItem(label = "BASE RATE", value = "${macro.hkmaBaseRatePct}%")
                MacroTickerItem(label = "US SOFR", value = "${macro.usSofrPct}%")
                MacroTickerItem(label = "CIP BASIS", value = "${macro.cipBasisBp}bp")
            }
        }
    }
}

@Composable
private fun MacroTickerItem(label: String, value: String, isHighlight: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "$label:",
            style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                color = if (isHighlight) TerminalGold else TextWhite,
                fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp
            )
        )
    }
}

@Composable
fun ProvenanceBadge(status: DataStatus, modifier: Modifier = Modifier) {
    val color = Color(status.badgeColorHex)
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(3.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.6f)),
        modifier = modifier
    ) {
        Text(
            text = status.name,
            style = MaterialTheme.typography.labelSmall.copy(
                color = color,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            ),
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
        )
    }
}

@Composable
fun FinancialStatCard(
    title: String,
    value: String,
    subtitle: String? = null,
    deltaText: String? = null,
    isPositiveDelta: Boolean = true,
    badge: @Composable (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp)
                )
                badge?.invoke()
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite,
                    fontSize = 17.sp
                )
            )
            if (subtitle != null || deltaText != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (deltaText != null) {
                        Text(
                            text = deltaText,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isPositiveDelta) TerminalEmerald else TerminalRose,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 10.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    if (subtitle != null) {
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall.copy(color = TextDim, fontSize = 10.sp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun YieldCurveCanvas(
    nodes: List<CurveNode>,
    curveColor: Color = TerminalBlue,
    overlayNodes: List<CurveNode>? = null,
    overlayColor: Color = TerminalPurple,
    modifier: Modifier = Modifier
) {
    if (nodes.isEmpty()) return

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
            .background(TerminalBg, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        val minRate = (nodes.minOfOrNull { it.zeroRate } ?: 2.0) - 0.3
        val maxRate = (nodes.maxOfOrNull { it.zeroRate } ?: 5.0) + 0.3
        val rateRange = maxOf(0.5, maxRate - minRate)

        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val paddingLeft = 32f
            val paddingBottom = 20f
            val graphW = w - paddingLeft
            val graphH = h - paddingBottom

            // Draw horizontal grid lines
            val steps = 4
            for (i in 0..steps) {
                val yVal = minRate + (rateRange / steps) * i
                val y = graphH - (i.toFloat() / steps) * graphH
                drawLine(
                    color = TerminalBorderBright,
                    start = Offset(paddingLeft, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
            }

            // Draw Curve Path
            fun computePoint(index: Int, count: Int, rate: Double): Offset {
                val x = paddingLeft + (index.toFloat() / maxOf(1, count - 1)) * graphW
                val normalizedY = ((rate - minRate) / rateRange).coerceIn(0.0, 1.0)
                val y = graphH - (normalizedY.toFloat() * graphH)
                return Offset(x, y)
            }

            // Draw Overlay curve if present
            overlayNodes?.let { oNodes ->
                val oPath = Path()
                oNodes.forEachIndexed { idx, node ->
                    val pt = computePoint(idx, oNodes.size, node.zeroRate)
                    if (idx == 0) oPath.moveTo(pt.x, pt.y) else oPath.lineTo(pt.x, pt.y)
                }
                drawPath(path = oPath, color = overlayColor.copy(alpha = 0.7f), style = Stroke(width = 2f))
            }

            // Draw Primary Curve
            val path = Path()
            nodes.forEachIndexed { idx, node ->
                val pt = computePoint(idx, nodes.size, node.zeroRate)
                if (idx == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
            }
            drawPath(path = path, color = curveColor, style = Stroke(width = 3f))

            // Draw Points
            nodes.forEachIndexed { idx, node ->
                val pt = computePoint(idx, nodes.size, node.zeroRate)
                drawCircle(color = TerminalCardBg, radius = 5f, center = pt)
                drawCircle(color = curveColor, radius = 3.5f, center = pt)
            }
        }

        // Axis labels overlay
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomEnd)
                .padding(start = 32.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            nodes.forEach { node ->
                Text(
                    text = node.tenor.code,
                    style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp)
                )
            }
        }
    }
}
