package com.example.engine

import com.example.data.model.BusinessDayConvention
import com.example.data.model.DayCountConvention
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs

object DayCountEngine {

    // Hong Kong Fixed & Floating Public Holiday approximations for financial simulation
    private val hkFixedHolidays = setOf(
        "01-01", // New Year's Day
        "05-01", // Labour Day
        "07-01", // HKSAR Establishment Day
        "10-01", // National Day
        "12-25", // Christmas Day
        "12-26"  // Boxing Day
    )

    fun isHoliday(date: LocalDate): Boolean {
        if (date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY) return true
        val mmdd = String.format("%02d-%02d", date.monthValue, date.dayOfMonth)
        return mmdd in hkFixedHolidays
    }

    fun isBusinessDay(date: LocalDate): Boolean = !isHoliday(date)

    fun adjustDate(date: LocalDate, convention: BusinessDayConvention): LocalDate {
        if (isBusinessDay(date)) return date
        return when (convention) {
            BusinessDayConvention.FOLLOWING -> {
                var d = date
                while (!isBusinessDay(d)) d = d.plusDays(1)
                d
            }
            BusinessDayConvention.MODIFIED_FOLLOWING -> {
                var d = date
                while (!isBusinessDay(d)) d = d.plusDays(1)
                if (d.monthValue != date.monthValue) {
                    d = date
                    while (!isBusinessDay(d)) d = d.minusDays(1)
                }
                d
            }
            BusinessDayConvention.PRECEDING -> {
                var d = date
                while (!isBusinessDay(d)) d = d.minusDays(1)
                d
            }
            BusinessDayConvention.MODIFIED_PRECEDING -> {
                var d = date
                while (!isBusinessDay(d)) d = d.minusDays(1)
                if (d.monthValue != date.monthValue) {
                    d = date
                    while (!isBusinessDay(d)) d = d.plusDays(1)
                }
                d
            }
        }
    }

    fun addBusinessDays(date: LocalDate, days: Int): LocalDate {
        var d = date
        var count = 0
        val step = if (days >= 0) 1L else -1L
        val target = abs(days)
        while (count < target) {
            d = d.plusDays(step)
            if (isBusinessDay(d)) count++
        }
        return d
    }

    fun calculateDayFraction(
        startDate: LocalDate,
        endDate: LocalDate,
        convention: DayCountConvention
    ): Double {
        if (endDate.isBefore(startDate)) return 0.0
        val daysBetween = ChronoUnit.DAYS.between(startDate, endDate).toDouble()
        return when (convention) {
            DayCountConvention.ACT_365F -> daysBetween / 365.0
            DayCountConvention.ACT_360 -> daysBetween / 360.0
            DayCountConvention.THIRTY_360 -> {
                val d1 = startDate.dayOfMonth.coerceAtMost(30)
                val d2 = if (d1 == 30) endDate.dayOfMonth.coerceAtMost(30) else endDate.dayOfMonth
                val m1 = startDate.monthValue
                val m2 = endDate.monthValue
                val y1 = startDate.year
                val y2 = endDate.year
                val days360 = (y2 - y1) * 360 + (m2 - m1) * 30 + (d2 - d1)
                days360 / 360.0
            }
            DayCountConvention.ACT_ACT -> {
                val yearLength = if (startDate.isLeapYear || endDate.isLeapYear) 366.0 else 365.0
                daysBetween / yearLength
            }
        }
    }
}
