package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.TerminalUiState
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun FixingEngineScreen(
    state: TerminalUiState,
    onSelectTenor: (Tenor) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentTenor = state.selectedFixingTenor
    val fixing = state.hiborFixings.find { it.tenor == currentTenor } ?: state.hiborFixings.firstOrNull()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] Tenor Selector Pills
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(Tenor.fixingTenors) { tenor ->
                    val isSelected = tenor == currentTenor
                    Surface(
                        color = if (isSelected) TerminalBlue else TerminalCardBg,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) TerminalBlue else TerminalBorder
                        ),
                        modifier = Modifier
                            .clickable { onSelectTenor(tenor) }
                            .testTag("fixing_tenor_pill_${tenor.code}")
                    ) {
                        Text(
                            text = tenor.code,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) TerminalBg else TextWhite,
                                fontSize = 11.sp
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }

        if (fixing != null) {
            // [2] Fixing Benchmark Header Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "HIBOR ${fixing.tenor.label.uppercase()} FIXING",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite
                                    )
                                )
                                Text(
                                    text = "Administered by TMA / HKAB  •  Methodology: ${fixing.methodologyVersion}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextDim)
                                )
                            }
                            ProvenanceBadge(status = fixing.dataStatus)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text("OFFICIAL FIXING RATE", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                                Text(
                                    text = "${String.format("%.5f", fixing.rate)}%",
                                    style = MaterialTheme.typography.headlineLarge.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = TerminalGold,
                                        fontSize = 26.sp
                                    )
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("PREVIOUS / CHANGE", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${String.format("%.5f", fixing.previousRate)}%  ",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = TextDim)
                                    )
                                    Text(
                                        text = "${if (fixing.changeBp >= 0) "+" else ""}${String.format("%.2f", fixing.changeBp)} bp",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = if (fixing.changeBp >= 0) TerminalEmerald else TerminalRose
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Audit Signature
                        Surface(
                            color = TerminalBg,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = TerminalBlue, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("SHA-256 REPRODUCIBLE HASH:", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp))
                                }
                                Text(
                                    text = fixing.calculationAuditHash.ifEmpty { "E8A42F09C81B47D2" },
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        color = TerminalCyan,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // [3] Quality & Dispersion Engine Metrics
            item {
                fixing.qualityMetrics?.let { qm ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "FIXING QUALITY & STATISTICAL DISPERSION",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                MetricColumn(title = "SUBMISSIONS", value = "${qm.quoteCount} Banks")
                                MetricColumn(title = "TRIMMED MEAN", value = "${String.format("%.5f", qm.trimmedMean)}%")
                                MetricColumn(title = "MEDIAN", value = "${String.format("%.5f", qm.median)}%")
                                MetricColumn(title = "STD DEV", value = "${String.format("%.4f", qm.standardDeviation)}%")
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                MetricColumn(title = "HIGH-LOW RANGE", value = "${String.format("%.2f", qm.highLowRangeBp)} bp")
                                MetricColumn(title = "IQR RANGE", value = "${String.format("%.2f", qm.interquartileRangeBp)} bp")
                                MetricColumn(
                                    title = "DISPERSION REGIME",
                                    value = qm.dispersionStatus,
                                    valueColor = if (qm.dispersionStatus.contains("HIGH")) TerminalRose else TerminalEmerald
                                )
                            }

                            if (qm.anomalyFlags.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = TerminalGold, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "ANOMALY FLAGS: ${qm.anomalyFlags.joinToString(", ")}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TerminalGold, fontSize = 10.sp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // [4] Panel Bank Quotes Blotter with High/Low Exclusion
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "CONTRIBUTOR PANEL SUBMISSIONS (${fixing.contributingQuotes.size})",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                            Text(
                                text = "TRIM: Top 3 High / Bottom 3 Low Excluded",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Table Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TerminalCardAlt, RoundedCornerShape(3.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("BANK", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.5f))
                            Text("QUOTE (%)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.2f))
                            Text("DEV (bp)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1f))
                            Text("STATUS", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.4f))
                        }

                        fixing.contributingQuotes.forEach { quote ->
                            val statusColor = when (quote.status) {
                                QuoteStatus.INCLUDED -> TerminalEmerald
                                QuoteStatus.EXCLUDED_HIGH -> TerminalRose
                                QuoteStatus.EXCLUDED_LOW -> TerminalGold
                                else -> TextMuted
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = quote.bankName,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite),
                                    modifier = Modifier.weight(1.5f)
                                )
                                Text(
                                    text = String.format("%.5f", quote.quote),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (quote.status == QuoteStatus.INCLUDED) TextWhite else TextDim
                                    ),
                                    modifier = Modifier.weight(1.2f)
                                )
                                Text(
                                    text = "${if (quote.deviationFromFixingBp >= 0) "+" else ""}${String.format("%.2f", quote.deviationFromFixingBp)}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        color = TextDim
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = quote.status.name,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = statusColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp
                                    ),
                                    modifier = Modifier.weight(1.4f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricColumn(title: String, value: String, valueColor: Color = TextWhite) {
    Column {
        Text(text = title, style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = valueColor,
                fontSize = 11.sp
            )
        )
    }
}
