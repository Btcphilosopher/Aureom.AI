package com.example.engine

import com.example.data.model.*
import kotlin.math.round

object RiskEngine {

    fun calculatePortfolioRisk(
        positions: List<PortfolioPosition>,
        swaps: List<SwapTrade>,
        fras: List<FRATrade>,
        curve: CalibratedCurve,
        basisSpread3m: Double = 32.5
    ): PortfolioRiskResult {
        var totalPv = 0.0
        var totalPnl = 0.0
        var totalDv01 = 0.0

        positions.forEach { p ->
            totalPv += p.pvHkd
            totalPnl += p.pnlTodayHkd
            totalDv01 += p.dv01Hkd
        }

        // Key-rate DV01 distribution across institutional buckets
        val bucketMap = mutableMapOf<Tenor, Double>()
        Tenor.curveTenors.forEach { bucketMap[it] = 0.0 }

        bucketMap[Tenor.ON] = totalDv01 * 0.05
        bucketMap[Tenor.W1] = totalDv01 * 0.08
        bucketMap[Tenor.M1] = totalDv01 * 0.12
        bucketMap[Tenor.M3] = totalDv01 * 0.28
        bucketMap[Tenor.M6] = totalDv01 * 0.18
        bucketMap[Tenor.M12] = totalDv01 * 0.15
        bucketMap[Tenor.Y2] = totalDv01 * 0.08
        bucketMap[Tenor.Y3] = totalDv01 * 0.04
        bucketMap[Tenor.Y5] = totalDv01 * 0.02
        bucketMap[Tenor.Y10] = totalDv01 * -0.00

        val ladder = Tenor.curveTenors.map { t ->
            KeyRateDV01(bucket = t, dv01Hkd = round((bucketMap[t] ?: 0.0) * 100.0) / 100.0)
        }

        val hiborExposure = totalPv * 0.65
        val honiaExposure = -totalPv * 0.25
        val basisExposure = totalDv01 * basisSpread3m * 10.0

        val plAttribution = PLAttribution(
            totalPnlHkd = totalPnl,
            curveShiftPnlHkd = totalPnl * 0.45,
            carryPnlHkd = totalPnl * 0.22,
            fixingPnlHkd = totalPnl * 0.16,
            basisPnlHkd = totalPnl * 0.11,
            fxPnlHkd = totalPnl * 0.04,
            newTradePnlHkd = totalPnl * 0.02
        )

        return PortfolioRiskResult(
            portfolioId = "PORT_HKD_RATES_MAIN",
            name = "Institutional HKD Trading & Treasury Book",
            totalPvHkd = round(totalPv * 100.0) / 100.0,
            totalPnlHkd = round(totalPnl * 100.0) / 100.0,
            totalDv01Hkd = round(totalDv01 * 100.0) / 100.0,
            totalPv01Hkd = round(kotlin.math.abs(totalDv01) * 100.0) / 100.0,
            totalConvexity = 14.8,
            totalCs01Hkd = round(totalDv01 * 0.35 * 100.0) / 100.0,
            hiborExposureHkd = round(hiborExposure * 100.0) / 100.0,
            honiaExposureHkd = round(honiaExposure * 100.0) / 100.0,
            basisExposureHkd = round(basisExposure * 100.0) / 100.0,
            keyRateLadder = ladder,
            plAttribution = plAttribution
        )
    }

    fun evaluateScenario(
        scenario: ScenarioShock,
        baseRisk: PortfolioRiskResult,
        baseHibor3m: Double,
        baseHonia: Double
    ): ScenarioResult {
        val totalShiftBp = scenario.parallelShiftBp
        var curvePnl = scenario.parallelShiftBp * baseRisk.totalDv01Hkd

        when (scenario.curveShape) {
            CurveShockType.STEEPENER_2S10S -> curvePnl += 420000.0
            CurveShockType.FLATTENER_2S10S -> curvePnl -= 380000.0
            CurveShockType.BUTTERFLY_1M3M6M -> curvePnl += 150000.0
            CurveShockType.LIQUIDITY_CRUNCH -> curvePnl -= 1250000.0
            CurveShockType.NONE -> {}
        }

        val postShockPv = baseRisk.totalPvHkd + curvePnl
        val postHibor = baseHibor3m + (totalShiftBp / 100.0)
        val postHonia = baseHonia + (totalShiftBp / 100.0) * 0.95

        val bankNimDelta = (totalShiftBp * 0.12) // Bank NIM expands ~12bp per 100bp rate hike
        val corpBorrowingDelta = 500_000_000.0 * (totalShiftBp / 10000.0) // 500M loan interest sensitivity

        return ScenarioResult(
            scenarioName = scenario.name,
            portfolioPnlHkd = round(curvePnl * 100.0) / 100.0,
            postShockPvHkd = round(postShockPv * 100.0) / 100.0,
            postShockDv01Hkd = baseRisk.totalDv01Hkd,
            postShockHibor3mPct = FixingEngine.roundToPrecision(postHibor, 4),
            postShockHoniaPct = FixingEngine.roundToPrecision(postHonia, 4),
            bankNimDeltaBp = round(bankNimDelta * 100.0) / 100.0,
            corporateBorrowingCostDeltaHkd = round(corpBorrowingDelta * 100.0) / 100.0
        )
    }
}
