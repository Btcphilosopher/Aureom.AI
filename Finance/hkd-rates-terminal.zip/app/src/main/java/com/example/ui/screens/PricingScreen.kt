package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.TerminalUiState
import com.example.ui.components.FinancialStatCard
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

enum class PricingInstrumentTab(val label: String) {
    IRS("Interest Rate Swap"),
    FRA("FRA"),
    FRN("FRN / Bonds"),
    LOAN("Corporate Loan")
}

@Composable
fun PricingScreen(
    state: TerminalUiState,
    onUpdateSwap: (Double?, Double?, Double?, PayerReceiver?) -> Unit,
    onUpdateFra: (FRAName?, Double?, Double?) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeInstrument by remember { mutableStateOf(PricingInstrumentTab.IRS) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] Instrument Tab Selector
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(PricingInstrumentTab.entries) { tab ->
                    val isSelected = tab == activeInstrument
                    Surface(
                        color = if (isSelected) TerminalBlue else TerminalCardBg,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TerminalBlue else TerminalBorder),
                        modifier = Modifier
                            .clickable { activeInstrument = tab }
                            .testTag("pricing_tab_${tab.name}")
                    ) {
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) TerminalBg else TextWhite,
                                fontSize = 11.sp
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }

        when (activeInstrument) {
            PricingInstrumentTab.IRS -> {
                // Swap Parameters & Valuation
                item {
                    val swap = state.activeSwapTrade
                    val valn = state.swapValuation

                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "HKD INTEREST RATE SWAP (IRS)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite
                                    )
                                )
                                ProvenanceBadge(status = DataStatus.DERIVED)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Parameters Grid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("NOTIONAL (HKD)", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                    Text("100,000,000", style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("MATURITY", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                    Text("${swap.maturityYears.toInt()} Years (5Y)", style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("FIXED RATE", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                    Text("${swap.fixedRatePct}%", style = MaterialTheme.typography.bodyMedium.copy(color = TerminalBlue, fontWeight = FontWeight.Bold))
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = {
                                        val next = if (swap.payerReceiver == PayerReceiver.PAY_FIXED) PayerReceiver.RECEIVE_FIXED else PayerReceiver.PAY_FIXED
                                        onUpdateSwap(null, null, null, next)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = TerminalCardAlt),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text(
                                        text = swap.payerReceiver.label,
                                        style = MaterialTheme.typography.labelSmall.copy(color = TerminalCyan)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Valuation Results
                            if (valn != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("NET PRESENT VALUE", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                        Text(
                                            text = "${if (valn.netPvHkd >= 0) "+" else ""}HK$ ${String.format("%,.0f", valn.netPvHkd)}",
                                            style = MaterialTheme.typography.headlineLarge.copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = if (valn.netPvHkd >= 0) TerminalEmerald else TerminalRose,
                                                fontSize = 20.sp
                                            )
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("FAIR SWAP RATE", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                        Text(
                                            text = "${String.format("%.4f", valn.fairSwapRatePct)}%",
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = TerminalGold
                                            )
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("DV01: HK$ ${String.format("%,.0f", valn.dv01Hkd)}/bp", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TextWhite))
                                    Text("Duration: ${valn.modifiedDuration} yrs", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TextMuted))
                                    Text("Convexity: ${valn.convexity}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TextDim))
                                }
                            }
                        }
                    }
                }

                // Swap Cashflow Schedule
                item {
                    val valn = state.swapValuation
                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "EXACT CASHFLOW SCHEDULE (FIXED & FLOATING LEGS)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold
                                )
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(TerminalCardAlt, RoundedCornerShape(3.dp))
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("LEG", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp), modifier = Modifier.weight(0.9f))
                                Text("PAY DATE", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp), modifier = Modifier.weight(1.3f))
                                Text("RATE (%)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp), modifier = Modifier.weight(1.1f))
                                Text("INT (HKD)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp), modifier = Modifier.weight(1.3f))
                                Text("PV (HKD)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp), modifier = Modifier.weight(1.3f))
                            }

                            valn?.cashflows?.take(8)?.forEach { cf ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (cf.isFixedLeg) "FIX ${cf.periodIndex}" else "FLT ${cf.periodIndex}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (cf.isFixedLeg) TerminalBlue else TerminalCyan,
                                            fontSize = 9.sp
                                        ),
                                        modifier = Modifier.weight(0.9f)
                                    )
                                    Text(cf.paymentDate, style = MaterialTheme.typography.bodySmall.copy(color = TextDim, fontSize = 9.sp), modifier = Modifier.weight(1.3f))
                                    Text(String.format("%.3f", cf.ratePct), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TextWhite), modifier = Modifier.weight(1.1f))
                                    Text(String.format("%,.0f", cf.interestAmountHkd), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TextMuted), modifier = Modifier.weight(1.3f))
                                    Text(String.format("%,.0f", cf.presentValueHkd), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TextWhite, fontWeight = FontWeight.SemiBold), modifier = Modifier.weight(1.3f))
                                }
                            }
                        }
                    }
                }
            }

            PricingInstrumentTab.FRA -> {
                item {
                    val fra = state.activeFraTrade
                    val fraVal = state.fraValuation

                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "FORWARD RATE AGREEMENT (FRA)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // FRA selector
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(FRAName.entries) { fName ->
                                    val isSel = fName == fra.fraName
                                    Surface(
                                        color = if (isSel) TerminalBlue else TerminalCardAlt,
                                        shape = RoundedCornerShape(3.dp),
                                        modifier = Modifier.clickable { onUpdateFra(fName, null, null) }
                                    ) {
                                        Text(
                                            text = fName.label,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = if (isSel) TerminalBg else TextWhite,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            if (fraVal != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("IMPLIED FORWARD RATE", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                        Text("${String.format("%.4f", fraVal.impliedForwardRatePct)}%", style = MaterialTheme.typography.titleLarge.copy(color = TerminalCyan, fontWeight = FontWeight.Bold))
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("SETTLEMENT AMOUNT", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                        Text("HK$ ${String.format("%,.0f", fraVal.settlementAmountHkd)}", style = MaterialTheme.typography.titleLarge.copy(color = TerminalEmerald, fontWeight = FontWeight.Bold))
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text("DV01: HK$ ${String.format("%,.0f", fraVal.dv01Hkd)}  •  P&L: ${fraVal.pnlBp} bp", style = MaterialTheme.typography.bodySmall.copy(color = TextMuted))
                            }
                        }
                    }
                }
            }

            PricingInstrumentTab.FRN -> {
                item {
                    val frn = state.activeFrnTrade
                    val frnVal = state.frnValuation

                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "HKD FLOATING RATE NOTE (FRN)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            if (frnVal != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("CLEAN PRICE", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                        Text("${frnVal.cleanPricePct}%", style = MaterialTheme.typography.titleLarge.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                                    }
                                    Column {
                                        Text("CURRENT COUPON", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                        Text("${frnVal.currentCouponPct}%", style = MaterialTheme.typography.titleLarge.copy(color = TerminalGold, fontWeight = FontWeight.Bold))
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("DISCOUNT MARGIN", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                        Text("+${frnVal.discountMarginBp} bp", style = MaterialTheme.typography.titleLarge.copy(color = TerminalBlue, fontWeight = FontWeight.Bold))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            PricingInstrumentTab.LOAN -> {
                item {
                    val loan = state.activeLoanFacility
                    val pricing = state.loanPricing

                    Card(
                        colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "CORPORATE LOAN ALL-IN PRICING",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                            Text("Facility: HK$ 500M (${loan.borrower})", style = MaterialTheme.typography.bodySmall.copy(color = TextDim))

                            Spacer(modifier = Modifier.height(8.dp))

                            if (pricing != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("ALL-IN BORROWING RATE", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                        Text("${String.format("%.4f", pricing.allInRatePct)}%", style = MaterialTheme.typography.titleLarge.copy(color = TerminalGold, fontWeight = FontWeight.Bold))
                                        Text("Base HIBOR: ${pricing.baseHiborRatePct}% + Spread: ${pricing.totalSpreadBp}bp", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("ANNUAL INTEREST", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                        Text("HK$ ${String.format("%,.0f", pricing.annualInterestHkd)}", style = MaterialTheme.typography.titleMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                                        Text("HK$ ${String.format("%,.0f", pricing.monthlyInterestHkd)} / mo", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Surface(
                                    color = TerminalCardAlt,
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Break-Even Hedge Rate: ${pricing.breakEvenHedgeRatePct}%", style = MaterialTheme.typography.labelSmall.copy(color = TerminalCyan))
                                        Text("+25bp Shock: +HK$ ${String.format("%,.0f", pricing.interestSensitivityPer25bpHkd)}", style = MaterialTheme.typography.labelSmall.copy(color = TerminalRose))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
