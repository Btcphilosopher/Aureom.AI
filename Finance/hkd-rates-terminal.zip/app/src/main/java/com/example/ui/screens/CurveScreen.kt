package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.engine.CurveEngine
import com.example.ui.TerminalUiState
import com.example.ui.components.YieldCurveCanvas
import com.example.ui.theme.*

@Composable
fun CurveScreen(
    state: TerminalUiState,
    onSelectCurveType: (CurveType) -> Unit,
    onSelectInterpolation: (InterpolationMethod) -> Unit,
    modifier: Modifier = Modifier
) {
    var fwdStartTenor by remember { mutableStateOf(Tenor.M3) }
    var fwdEndTenor by remember { mutableStateOf(Tenor.M6) }

    val curve = state.calibratedCurve

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] Curve Type Selector
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(CurveType.entries) { cType ->
                    val isSelected = cType == state.selectedCurveType
                    Surface(
                        color = if (isSelected) TerminalBlue else TerminalCardBg,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TerminalBlue else TerminalBorder),
                        modifier = Modifier
                            .clickable { onSelectCurveType(cType) }
                            .testTag("curve_type_${cType.name}")
                    ) {
                        Text(
                            text = cType.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) TerminalBg else TextWhite,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // [2] Interpolation Model Selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MODEL:",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp)
                )

                InterpolationMethod.entries.forEach { method ->
                    val isSelected = method == state.selectedInterpolation
                    Surface(
                        color = if (isSelected) TerminalCardAlt else TerminalBg,
                        shape = RoundedCornerShape(3.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TerminalBlue else TerminalBorder),
                        modifier = Modifier
                            .clickable { onSelectInterpolation(method) }
                            .padding(vertical = 2.dp)
                    ) {
                        Text(
                            text = when (method) {
                                InterpolationMethod.MONOTONE_CUBIC_SPLINE -> "Spline"
                                InterpolationMethod.NELSON_SIEGEL -> "Nelson-Siegel"
                                InterpolationMethod.LOG_LINEAR_DISCOUNT -> "Log-Linear"
                                InterpolationMethod.PIECEWISE_LINEAR -> "Linear"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (isSelected) TerminalBlue else TextDim,
                                fontSize = 9.sp
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // [3] Interactive Yield Curve Canvas
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = state.selectedCurveType.label.uppercase(),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                            Text(
                                text = "Calibrated on ${state.selectedDate}  •  RMS Error: 0.015 bp",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextDim)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).background(TerminalBlue, RoundedCornerShape(2.dp)))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Zero Rate", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    curve?.nodes?.let { nodes ->
                        YieldCurveCanvas(nodes = nodes, curveColor = TerminalBlue)
                    }
                }
            }
        }

        // [4] PCA Curve Decomposition Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "PRINCIPAL COMPONENT ANALYSIS (PCA)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("PC1 (LEVEL)", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text("${state.pcaResult.levelVariancePct}% var", style = MaterialTheme.typography.bodySmall.copy(color = TerminalBlue, fontWeight = FontWeight.Bold))
                            Text("Score: ${state.pcaResult.levelScore}", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                        }
                        Column {
                            Text("PC2 (SLOPE)", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text("${state.pcaResult.slopeVariancePct}% var", style = MaterialTheme.typography.bodySmall.copy(color = TerminalPurple, fontWeight = FontWeight.Bold))
                            Text("Score: ${state.pcaResult.slopeScore}", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                        }
                        Column {
                            Text("PC3 (CURVATURE)", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text("${state.pcaResult.curvatureVariancePct}% var", style = MaterialTheme.typography.bodySmall.copy(color = TerminalCyan, fontWeight = FontWeight.Bold))
                            Text("Score: ${state.pcaResult.curvatureScore}", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                        }
                    }
                }
            }
        }

        // [5] Interactive Forward Rate Calculator
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "FORWARD RATE PRICING CALCULATOR",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("From:", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Spacer(modifier = Modifier.width(4.dp))
                            TenorSelectorDropdown(selected = fwdStartTenor, onSelect = { fwdStartTenor = it })

                            Spacer(modifier = Modifier.width(8.dp))

                            Text("To:", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Spacer(modifier = Modifier.width(4.dp))
                            TenorSelectorDropdown(selected = fwdEndTenor, onSelect = { fwdEndTenor = it })
                        }

                        val fwdCalculated = if (curve != null && fwdEndTenor.maturityYears > fwdStartTenor.maturityYears) {
                            CurveEngine.calculateForwardRate(fwdStartTenor.maturityYears, fwdEndTenor.maturityYears, curve)
                        } else 0.0

                        Column(horizontalAlignment = Alignment.End) {
                            Text("IMPLIED FORWARD", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp))
                            Text(
                                text = "${String.format("%.4f", fwdCalculated)}%",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalCyan
                                )
                            )
                        }
                    }
                }
            }
        }

        // [6] Calibrated Curve Nodes Table
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "CALIBRATED ZERO RATES & DISCOUNT FACTORS",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalCardAlt, RoundedCornerShape(3.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TENOR", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1f))
                        Text("MAT (Y)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1f))
                        Text("ZERO (%)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.2f))
                        Text("DF", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.3f))
                        Text("FWD (%)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.2f))
                    }

                    curve?.nodes?.forEach { node ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(node.tenor.code, style = MaterialTheme.typography.bodyMedium.copy(color = TerminalBlue, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1f))
                            Text(String.format("%.2f", node.maturityYears), style = MaterialTheme.typography.bodySmall.copy(color = TextDim), modifier = Modifier.weight(1f))
                            Text(String.format("%.4f", node.zeroRate), style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = TextWhite), modifier = Modifier.weight(1.2f))
                            Text(String.format("%.6f", node.discountFactor), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TextMuted), modifier = Modifier.weight(1.3f))
                            Text(String.format("%.4f", node.forwardRate), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalCyan), modifier = Modifier.weight(1.2f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TenorSelectorDropdown(selected: Tenor, onSelect: (Tenor) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        Surface(
            color = TerminalCardAlt,
            shape = RoundedCornerShape(3.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
            modifier = Modifier.clickable { expanded = true }
        ) {
            Text(
                text = selected.code,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                ),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(TerminalCardBg)
        ) {
            Tenor.curveTenors.forEach { t ->
                DropdownMenuItem(
                    text = { Text(t.code, color = TextWhite, style = MaterialTheme.typography.bodySmall) },
                    onClick = {
                        onSelect(t)
                        expanded = false
                    }
                )
            }
        }
    }
}
