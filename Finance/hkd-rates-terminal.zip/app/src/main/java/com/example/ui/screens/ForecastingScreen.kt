package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.TerminalUiState
import com.example.ui.components.FinancialStatCard
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun ForecastingScreen(
    state: TerminalUiState,
    onSelectModel: (ForecastModelType, Tenor) -> Unit,
    modifier: Modifier = Modifier
) {
    val result = state.forecastResult

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] Model Selector Pills
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(ForecastModelType.entries) { mType ->
                    val isSelected = mType == state.forecastModelType
                    Surface(
                        color = if (isSelected) TerminalBlue else TerminalCardBg,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TerminalBlue else TerminalBorder),
                        modifier = Modifier
                            .clickable { onSelectModel(mType, state.forecastTargetTenor) }
                            .testTag("forecast_model_${mType.name}")
                    ) {
                        Text(
                            text = mType.label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) TerminalBg else TextWhite,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // [2] Target Tenor Selector
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("TARGET TENOR:", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                listOf(Tenor.M1, Tenor.M3, Tenor.M6, Tenor.M12).forEach { t ->
                    val isSel = t == state.forecastTargetTenor
                    Surface(
                        color = if (isSel) TerminalCardAlt else TerminalBg,
                        shape = RoundedCornerShape(3.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) TerminalBlue else TerminalBorder),
                        modifier = Modifier.clickable { onSelectModel(state.forecastModelType, t) }
                    ) {
                        Text(
                            text = t.code,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) TerminalBlue else TextDim,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }

        // [3] Model Forecast Result Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "HIBOR ${state.forecastTargetTenor.code} 30-DAY FORECAST",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                            Text(
                                text = state.forecastModelType.method,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextDim)
                            )
                        }
                        ProvenanceBadge(status = DataStatus.MODELLED)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (result != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("PREDICTED RATE (30D)", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                Text(
                                    text = "${String.format("%.4f", result.predictedRatePct)}%",
                                    style = MaterialTheme.typography.headlineLarge.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = TerminalCyan,
                                        fontSize = 24.sp
                                    )
                                )
                                Text(
                                    text = "Current: ${String.format("%.4f", result.currentRatePct)}%",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp)
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("95% CONFIDENCE INTERVAL", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                Text(
                                    text = "[${String.format("%.4f", result.lower95Pct)}% - ${String.format("%.4f", result.upper95Pct)}%]",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = TerminalGold
                                    )
                                )
                                Text(
                                    text = "Dir. Accuracy: ${result.directionalAccuracyPct}%",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TerminalEmerald, fontSize = 10.sp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Error Metrics
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TerminalCardAlt, RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("MAE: ${result.mae}%", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                            Text("RMSE: ${result.rmse}%", style = MaterialTheme.typography.bodySmall.copy(color = TextWhite))
                            Text("Horizon: ${result.horizonDays} Days", style = MaterialTheme.typography.bodySmall.copy(color = TextDim))
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("OBSERVABLE MACRO VARIABLES USED:", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp))
                        Spacer(modifier = Modifier.height(3.dp))
                        result.factorsUsed.forEach { factor ->
                            Text(
                                text = "• $factor",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 10.sp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Assumptions: ${result.assumptions}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextDim, fontSize = 9.sp, lineHeight = 13.sp)
                        )
                    }
                }
            }
        }
    }
}
