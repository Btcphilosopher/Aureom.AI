package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DataStatus
import com.example.engine.TreasuryEngine
import com.example.ui.TerminalUiState
import com.example.ui.components.FinancialStatCard
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun TreasuryScreen(
    state: TerminalUiState,
    modifier: Modifier = Modifier
) {
    var rateShockBp by remember { mutableStateOf(50.0) }
    val hibor3m = state.hiborFixings.find { it.tenor == com.example.data.model.Tenor.M3 }?.rate ?: 3.26875
    val treasuryResult = TreasuryEngine.calculateBankTreasury(state.bankBalanceSheet, hibor3m, rateShockBp)
    val corpComparison = TreasuryEngine.optimizeCorporateHedge(baseHiborPct = hibor3m, anticipatedShockBp = rateShockBp)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] Bank Treasury Command Center Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "BANK TREASURY & BALANCE SHEET",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                            Text(
                                text = "Total Assets: HK$ 850B  •  Total Liabilities: HK$ 770B",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextDim)
                            )
                        }
                        ProvenanceBadge(status = DataStatus.MODELLED)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("NET INTEREST INCOME (NII)", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text(
                                text = "HK$ ${String.format("%,.0f", treasuryResult.shockedNiiHkdM)}M",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalEmerald
                                )
                            )
                            Text(
                                text = "Base: HK$ ${String.format("%,.0f", treasuryResult.baseNiiHkdM)}M (${if (treasuryResult.niiDeltaHkdM >= 0) "+" else ""}${treasuryResult.niiDeltaHkdM}M)",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("NET INTEREST MARGIN (NIM)", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text(
                                text = "${String.format("%.3f", treasuryResult.shockedNimPct)}%",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalBlue
                                )
                            )
                            Text(
                                text = "NIM Delta: ${if (treasuryResult.nimDeltaBp >= 0) "+" else ""}${treasuryResult.nimDeltaBp} bp",
                                style = MaterialTheme.typography.labelSmall.copy(color = TerminalGold, fontSize = 9.sp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Rate shock slider
                    Text("SIMULATED RATE SHOCK: ${rateShockBp.toInt()} bp", style = MaterialTheme.typography.labelSmall.copy(color = TextWhite))
                    Slider(
                        value = rateShockBp.toFloat(),
                        onValueChange = { rateShockBp = it.toDouble() },
                        valueRange = -100f..150f,
                        steps = 9,
                        colors = SliderDefaults.colors(thumbColor = TerminalBlue, activeTrackColor = TerminalBlue)
                    )
                }
            }
        }

        // [2] Asset-Liability Repricing Gap & Liquidity
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "ALM REPRICING GAP & DURATION SENSITIVITY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("1M REPRICING GAP", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text("+HK$ ${treasuryResult.repricingGap1MHkdBn}B", style = MaterialTheme.typography.bodyMedium.copy(color = TerminalEmerald, fontWeight = FontWeight.Bold))
                        }
                        Column {
                            Text("3M REPRICING GAP", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text("+HK$ ${treasuryResult.repricingGap3MHkdBn}B", style = MaterialTheme.typography.bodyMedium.copy(color = TerminalEmerald, fontWeight = FontWeight.Bold))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("DURATION GAP", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text("${treasuryResult.durationGapYears} Years", style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // [3] Corporate Debt Hedging Optimization
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "CORPORATE DEBT HEDGING OPTIMIZER (HK$ 500M 5Y FACILITY)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("UNHEDGED FLOATING DEBT", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text("HK$ ${corpComparison.unhedgedTotalInterestHkdM}M", style = MaterialTheme.typography.titleMedium.copy(color = TerminalRose, fontWeight = FontWeight.Bold))
                            Text("Peak Rate: ${corpComparison.floatingRateStressPeakPct}%", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("HEDGED WITH IRS (3.45% FIXED)", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                            Text("HK$ ${corpComparison.hedgedTotalInterestHkdM}M", style = MaterialTheme.typography.titleMedium.copy(color = TerminalEmerald, fontWeight = FontWeight.Bold))
                            Text("All-In Rate: ${corpComparison.effectiveFixedRatePct}%", style = MaterialTheme.typography.labelSmall.copy(color = TerminalCyan, fontSize = 9.sp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = TerminalEmerald.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalEmerald.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "HEDGE BENEFIT: Saving of HK$ ${corpComparison.hedgeSavingsHkdM}M over 5-year facility horizon against rate volatility.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TerminalEmerald,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            ),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}
