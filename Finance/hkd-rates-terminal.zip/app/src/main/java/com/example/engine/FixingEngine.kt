package com.example.engine

import com.example.data.model.*
import java.security.MessageDigest
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sqrt

object FixingEngine {

    val PANEL_BANKS = listOf(
        ContributorBank("HSBC_HK", "The Hongkong and Shanghai Banking Corporation Limited", "HSBC", "Note-Issuing / Tier 1"),
        ContributorBank("SCB_HK", "Standard Chartered Bank (Hong Kong) Limited", "StanChart", "Note-Issuing / Tier 1"),
        ContributorBank("BOCHK", "Bank of China (Hong Kong) Limited", "BOCHK", "Note-Issuing / Tier 1"),
        ContributorBank("HASE_HK", "Hang Seng Bank Limited", "Hang Seng", "Domestic Commercial Major"),
        ContributorBank("CITI_HK", "Citibank (Hong Kong) Limited / Citibank N.A.", "Citibank", "Global Bulge Bracket"),
        ContributorBank("DBS_HK", "DBS Bank (Hong Kong) Limited", "DBS", "Regional Major"),
        ContributorBank("ICBC_ASIA", "Industrial and Commercial Bank of China (Asia) Limited", "ICBC Asia", "Major Chinese Commercial"),
        ContributorBank("CCB_ASIA", "China Construction Bank (Asia) Corporation Limited", "CCB Asia", "Major Chinese Commercial"),
        ContributorBank("BEA_HK", "The Bank of East Asia, Limited", "BEA", "Domestic Commercial Major"),
        ContributorBank("MIZUHO_HK", "Mizuho Bank, Ltd. Hong Kong Branch", "Mizuho", "Global Japanese Major"),
        ContributorBank("MUFG_HK", "MUFG Bank, Ltd. Hong Kong Branch", "MUFG", "Global Japanese Major"),
        ContributorBank("SMBC_HK", "Sumitomo Mitsui Banking Corporation Hong Kong Branch", "SMBC", "Global Japanese Major"),
        ContributorBank("BNP_HK", "BNP Paribas Hong Kong Branch", "BNP Paribas", "European Bulge Bracket"),
        ContributorBank("SOCGEN_HK", "Société Générale Hong Kong Branch", "SocGen", "European Bulge Bracket"),
        ContributorBank("CRAG_HK", "Crédit Agricole Corporate and Investment Bank HK", "Crédit Agricole", "European Major"),
        ContributorBank("UBS_HK", "UBS AG Hong Kong Branch", "UBS", "Swiss Global Major"),
        ContributorBank("DB_HK", "Deutsche Bank AG Hong Kong Branch", "Deutsche Bank", "European Bulge Bracket"),
        ContributorBank("OCBC_HK", "OCBC Bank (Hong Kong) Limited", "OCBC", "Regional Major"),
        ContributorBank("UOB_HK", "United Overseas Bank Limited Hong Kong Branch", "UOB", "Regional Major"),
        ContributorBank("BNYM_HK", "The Bank of New York Mellon Hong Kong Branch", "BNY Mellon", "Global Custody & Treasury")
    )

    fun calculateFixing(
        fixingDate: String,
        tenor: Tenor,
        rawQuotes: List<ContributorQuote>,
        methodology: BenchmarkMethodology = BenchmarkMethodology(),
        previousRate: Double = 0.0,
        dataStatus: DataStatus = DataStatus.OFFICIAL
    ): HIBORFixing {
        require(rawQuotes.isNotEmpty()) { "Quote list cannot be empty for fixing calculation" }

        // Sort ascending by quote value
        val sortedQuotes = rawQuotes.sortedBy { it.quote }
        val n = sortedQuotes.size
        val trimHigh = methodology.trimHighCount.coerceAtMost((n - 1) / 2)
        val trimLow = methodology.trimLowCount.coerceAtMost((n - 1) / 2)

        val processedQuotes = sortedQuotes.mapIndexed { index, q ->
            val status = when {
                index < trimLow -> QuoteStatus.EXCLUDED_LOW
                index >= n - trimHigh -> QuoteStatus.EXCLUDED_HIGH
                else -> QuoteStatus.INCLUDED
            }
            q.copy(status = status)
        }

        val includedQuotes = processedQuotes.filter { it.status == QuoteStatus.INCLUDED }
        val middleAverageRaw = if (includedQuotes.isNotEmpty()) {
            includedQuotes.map { it.quote }.average()
        } else {
            sortedQuotes.map { it.quote }.average()
        }

        val roundedRate = roundToPrecision(middleAverageRaw, methodology.precisionDecimals)
        val changeBp = if (previousRate > 0.0) round((roundedRate - previousRate) * 10000.0) / 100.0 else 0.0

        val annotatedQuotes = processedQuotes.map { q ->
            val devBp = (q.quote - roundedRate) * 100.0
            q.copy(deviationFromFixingBp = round(devBp * 100.0) / 100.0)
        }

        val qualityMetrics = computeQualityMetrics(annotatedQuotes, roundedRate)
        val auditHash = generateAuditHash(fixingDate, tenor.code, roundedRate, annotatedQuotes, methodology.version)

        return HIBORFixing(
            fixingDate = fixingDate,
            publicationTimestamp = "${fixingDate} ${methodology.publicationTimeHKT}",
            tenor = tenor,
            rate = roundedRate,
            previousRate = previousRate,
            changeBp = changeBp,
            contributingQuotes = annotatedQuotes,
            quoteCount = n,
            highQuotesExcluded = trimHigh,
            lowQuotesExcluded = trimLow,
            middleQuoteAverage = middleAverageRaw,
            revisionStatus = "FINAL",
            source = "HKAB / TMA Benchmark System",
            sourceTimestamp = "${fixingDate} 11:15:00 HKT",
            methodologyVersion = methodology.version,
            dataStatus = dataStatus,
            qualityMetrics = qualityMetrics,
            calculationAuditHash = auditHash
        )
    }

    private fun computeQualityMetrics(quotes: List<ContributorQuote>, fixingRate: Double): FixingQualityMetrics {
        val values = quotes.map { it.quote }.sorted()
        val n = values.size
        val mean = values.average()
        val median = if (n % 2 == 1) values[n / 2] else (values[n / 2 - 1] + values[n / 2]) / 2.0

        val variance = values.map { (it - mean).pow(2) }.average()
        val stdDev = sqrt(variance)

        val q1 = values[(n * 0.25).toInt().coerceIn(0, n - 1)]
        val q3 = values[(n * 0.75).toInt().coerceIn(0, n - 1)]
        val iqrBp = (q3 - q1) * 100.0
        val highLowBp = (values.last() - values.first()) * 100.0

        val anomalies = mutableListOf<String>()
        if (highLowBp > 15.0) anomalies.add("HIGH_DISPERSION")
        if (stdDev > 0.05) anomalies.add("ELEVATED_VOLATILITY")

        val outliers = quotes.filter { abs(it.quote - mean) > 2.5 * stdDev }
        if (outliers.isNotEmpty()) {
            anomalies.add("OUTLIER_QUOTES_DETECTED (${outliers.size})")
        }

        val dispersionStatus = when {
            highLowBp < 4.0 -> "NARROW_CONSENSUS"
            highLowBp <= 12.0 -> "NORMAL_LIQUIDITY"
            highLowBp <= 25.0 -> "ELEVATED_DISPERSION"
            else -> "HIGH_STRESS_DISPERSION"
        }

        return FixingQualityMetrics(
            quoteCount = n,
            mean = mean,
            median = median,
            trimmedMean = fixingRate,
            standardDeviation = stdDev,
            highLowRangeBp = round(highLowBp * 100.0) / 100.0,
            interquartileRangeBp = round(iqrBp * 100.0) / 100.0,
            dispersionStatus = dispersionStatus,
            anomalyFlags = anomalies
        )
    }

    fun roundToPrecision(value: Double, decimals: Int): Double {
        val factor = 10.0.pow(decimals)
        return round(value * factor) / factor
    }

    private fun generateAuditHash(
        date: String,
        tenor: String,
        rate: Double,
        quotes: List<ContributorQuote>,
        methodology: String
    ): String {
        val raw = StringBuilder("$date|$tenor|$rate|$methodology|")
        quotes.forEach { q ->
            raw.append("${q.bankId}:${q.quote}:${q.status};")
        }
        val bytes = MessageDigest.getInstance("SHA-256").digest(raw.toString().toByteArray())
        return bytes.take(8).joinToString("") { "%02x".format(it) }.uppercase()
    }
}
