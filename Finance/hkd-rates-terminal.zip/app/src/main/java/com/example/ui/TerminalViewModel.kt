package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.engine.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.round
import kotlin.random.Random

data class TerminalUiState(
    val selectedDate: String = "2026-10-05",
    val isLiveFeedActive: Boolean = false,
    val isReplayMode: Boolean = false,
    val activeTab: TerminalTab = TerminalTab.RATES_OVERVIEW,
    val macro: MacroEnvironment = MacroEnvironment(date = "2026-10-05"),
    val hiborFixings: List<HIBORFixing> = emptyList(),
    val selectedFixingTenor: Tenor = Tenor.M3,
    val honiaFixing: HONIAFixing = HONIAFixing("2026-10-05", 2.7050, 2.6840, 2.10, 21.4),
    val compoundedHoniaList: List<CompoundedHonia> = emptyList(),
    val basisMetrics: List<BasisMetric> = emptyList(),
    val calibratedCurve: CalibratedCurve? = null,
    val selectedCurveType: CurveType = CurveType.HIBOR_PROJECTION,
    val selectedInterpolation: InterpolationMethod = InterpolationMethod.MONOTONE_CUBIC_SPLINE,
    val pcaResult: PCAResult = PCAResult(),
    // Pricer state
    val activeSwapTrade: SwapTrade = SwapTrade(
        tradeId = "IRS_HKD_2026_001",
        swapType = SwapType.HIBOR_IRS_3M,
        notionalHkd = 100_000_000.0,
        effectiveDate = "2026-10-05",
        maturityYears = 5.0,
        fixedRatePct = 3.4500,
        floatingSpreadBp = 0.0,
        payerReceiver = PayerReceiver.PAY_FIXED,
        paymentFrequencyMonths = 3
    ),
    val swapValuation: SwapValuation? = null,
    val activeFraTrade: FRATrade = FRATrade(
        tradeId = "FRA_HKD_3X6_01",
        fraName = FRAName.FRA_3X6,
        notionalHkd = 50_000_000.0,
        strikeRatePct = 3.3200,
        isPayFixed = true
    ),
    val fraValuation: FRAValuation? = null,
    val activeFrnTrade: FRNTrade = FRNTrade(
        tradeId = "FRN_HKD_CORP_01",
        issuer = "HK Corp Tier 1",
        notionalHkd = 200_000_000.0,
        maturityYears = 3.0,
        spreadBp = 65.0
    ),
    val frnValuation: BondValuation? = null,
    val activeLoanFacility: LoanFacility = LoanFacility(
        facilityId = "FAC_HKD_CORP_500M",
        borrower = "Hong Kong Logistics Holdings",
        principalHkd = 500_000_000.0,
        maturityYears = 5.0
    ),
    val loanPricing: LoanPricingResult? = null,
    // Risk state
    val portfolioPositions: List<PortfolioPosition> = emptyList(),
    val portfolioRisk: PortfolioRiskResult? = null,
    val selectedScenario: ScenarioShock = ScenarioShock(
        id = "SCEN_PARALLEL_50",
        name = "HIBOR +50bp Parallel Shock",
        description = "Instantaneous parallel rate shift across all tenors",
        parallelShiftBp = 50.0
    ),
    val scenarioResult: ScenarioResult? = null,
    // Treasury
    val bankBalanceSheet: BankBalanceSheet = BankBalanceSheet(),
    val bankTreasuryResult: TreasurySensitivityResult? = null,
    val corporateHedgeResult: CorporateHedgeComparison? = null,
    // Forecasting & Econometrics
    val forecastModelType: ForecastModelType = ForecastModelType.OLS_MULTI_FACTOR,
    val forecastTargetTenor: Tenor = Tenor.M3,
    val forecastResult: ForecastResult? = null,
    // Digital Twin
    val digitalTwinNodes: List<DigitalTwinNode> = emptyList(),
    val digitalTwinUsShiftBp: Double = 0.0,
    val digitalTwinLiquidityDrainPct: Double = 0.0,
    val digitalTwinPegPressureBp: Double = 0.0,
    // Backtest
    val backtestStrategies: List<BacktestStrategy> = emptyList(),
    // Audits & Reports
    val auditEvents: List<AuditEvent> = emptyList(),
    val generatedReportText: String = "",
    val cliInput: String = "",
    val cliOutput: String = "HKD RATES TERMINAL CLI READY. Type 'help' or commands like 'hibor 3M', 'curve hkd', 'basis', 'risk', 'scenario +50bp'."
)

enum class TerminalTab(val label: String) {
    RATES_OVERVIEW("Overview"),
    FIXING_ENGINE("Fixing Audit"),
    YIELD_CURVE("Curves"),
    BASIS_DESK("Basis"),
    PRICING_LAB("Pricing"),
    PORTFOLIO_RISK("Risk & P&L"),
    TREASURY_DESK("Treasury"),
    FORECAST_LAB("Econometrics"),
    DIGITAL_TWIN("Digital Twin"),
    REPLAY_BACKTEST("Replay & Backtest"),
    AUDIT_REPORTS("Audit & Reports")
}

class TerminalViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(TerminalUiState())
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    private var liveFeedJob: Job? = null

    init {
        initializeTerminalData()
    }

    private fun initializeTerminalData() {
        val date = "2026-10-05"
        val rawBaseRates = mapOf(
            Tenor.ON to 2.72393,
            Tenor.W1 to 2.75738,
            Tenor.W2 to 2.77726,
            Tenor.M1 to 2.94220,
            Tenor.M2 to 3.11327,
            Tenor.M3 to 3.26875,
            Tenor.M6 to 3.52964,
            Tenor.M12 to 4.01351,
            Tenor.Y2 to 4.2250,
            Tenor.Y3 to 4.3850,
            Tenor.Y5 to 4.5850,
            Tenor.Y10 to 4.7850
        )

        val previousRates = mapOf(
            Tenor.ON to 2.70500,
            Tenor.W1 to 2.74100,
            Tenor.W2 to 2.76200,
            Tenor.M1 to 2.92800,
            Tenor.M2 to 3.09500,
            Tenor.M3 to 3.24500,
            Tenor.M6 to 3.51200,
            Tenor.M12 to 3.99800
        )

        val fixings = Tenor.fixingTenors.map { tenor ->
            val center = rawBaseRates[tenor] ?: 3.0
            val quotes = generateContributorQuotes(date, tenor, center)
            FixingEngine.calculateFixing(
                fixingDate = date,
                tenor = tenor,
                rawQuotes = quotes,
                previousRate = previousRates[tenor] ?: center,
                dataStatus = DataStatus.OFFICIAL
            )
        }

        val honia = HONIAFixing(date, 2.7050, 2.6840, 2.10, 21.4, dataStatus = DataStatus.OFFICIAL)
        val compoundedHonia = HoniaEngine.generateCompoundedTenors(honia.overnightRate)
        val basisList = HoniaEngine.calculateBasis(fixings, compoundedHonia, honia.overnightRate)

        val curve = CurveEngine.calibrateCurve(CurveType.HIBOR_PROJECTION, date, rawBaseRates, InterpolationMethod.MONOTONE_CUBIC_SPLINE)
        val pca = EconometricsEngine.decomposeYieldCurvePCA(curve.nodes)

        // Seed initial positions
        val positions = listOf(
            PortfolioPosition("POS_IRS_01", "HKD IRS 5Y", "Pay Fixed 3.45% vs HIBOR 3M", 100_000_000.0, 8_450_000.0, 48_200.0, 142_000.0),
            PortfolioPosition("POS_IRS_02", "HKD IRS 10Y", "Receive Fixed 4.75% vs HIBOR 3M", 50_000_000.0, -3_120_000.0, -42_500.0, -85_000.0),
            PortfolioPosition("POS_OIS_01", "HONIA OIS 2Y", "Pay Fixed 2.95% vs HONIA Comp", 150_000_000.0, 2_450_000.0, 28_400.0, 64_000.0),
            PortfolioPosition("POS_FRA_01", "FRA 3x6", "Pay Fixed 3.32% vs 3M HIBOR", 50_000_000.0, 420_000.0, 12_500.0, 31_000.0),
            PortfolioPosition("POS_FRN_01", "HKD FRN 3Y", "HK Corp 3Y HIBOR+65bp", 200_000_000.0, 201_200_000.0, 95_000.0, 210_000.0),
            PortfolioPosition("POS_LOAN_01", "Syndicated Loan 5Y", "HK Logistics Facility HIBOR+120bp", 500_000_000.0, 500_000_000.0, 42_600.0, 125_000.0)
        )

        val risk = RiskEngine.calculatePortfolioRisk(positions, emptyList(), emptyList(), curve)
        val swapVal = PricingEngine.priceSwap(_uiState.value.activeSwapTrade, curve, curve)
        val fraVal = PricingEngine.priceFRA(_uiState.value.activeFraTrade, curve)
        val frnVal = PricingEngine.priceFRN(_uiState.value.activeFrnTrade, rawBaseRates[Tenor.M3] ?: 3.26875, curve)
        val loanVal = PricingEngine.priceCorporateLoan(_uiState.value.activeLoanFacility, rawBaseRates[Tenor.M3] ?: 3.26875)

        val treasury = TreasuryEngine.calculateBankTreasury(hibor3mPct = rawBaseRates[Tenor.M3] ?: 3.26875)
        val corpOpt = TreasuryEngine.optimizeCorporateHedge(baseHiborPct = rawBaseRates[Tenor.M3] ?: 3.26875)

        val macro = MacroEnvironment(date)
        val forecast = EconometricsEngine.runMultiFactorOLS(Tenor.M3, rawBaseRates[Tenor.M3] ?: 3.26875, macro)
        val twinNodes = DigitalTwinEngine.simulateTransmission()
        val backtests = ReplayEngine.getBacktestStrategies()

        val initialAudit = AuditAndReportEngine.logAudit(
            action = "TERMINAL_STARTUP",
            targetObject = "BENCHMARK_ENGINE",
            oldValue = "OFFLINE",
            newValue = "ONLINE (HKAB-2013-V2.1)",
            reason = "Initial institutional rates engine boot"
        )

        val reportText = AuditAndReportEngine.generateDailyReport(date, fixings, honia, basisList, curve, macro)

        _uiState.update {
            it.copy(
                selectedDate = date,
                macro = macro,
                hiborFixings = fixings,
                honiaFixing = honia,
                compoundedHoniaList = compoundedHonia,
                basisMetrics = basisList,
                calibratedCurve = curve,
                pcaResult = pca,
                portfolioPositions = positions,
                portfolioRisk = risk,
                swapValuation = swapVal,
                fraValuation = fraVal,
                frnValuation = frnVal,
                loanPricing = loanVal,
                bankTreasuryResult = treasury,
                corporateHedgeResult = corpOpt,
                forecastResult = forecast,
                digitalTwinNodes = twinNodes,
                backtestStrategies = backtests,
                auditEvents = listOf(initialAudit),
                generatedReportText = reportText,
                scenarioResult = RiskEngine.evaluateScenario(it.selectedScenario, risk, rawBaseRates[Tenor.M3] ?: 3.26875, honia.overnightRate)
            )
        }
    }

    private fun generateContributorQuotes(date: String, tenor: Tenor, centerRate: Double): List<ContributorQuote> {
        val spreadRanges = when (tenor) {
            Tenor.ON -> 0.04
            Tenor.W1, Tenor.W2 -> 0.05
            Tenor.M1, Tenor.M2 -> 0.07
            Tenor.M3 -> 0.09
            Tenor.M6 -> 0.12
            Tenor.M12 -> 0.15
            else -> 0.10
        }

        val rng = Random(date.hashCode() + tenor.order * 37)
        return FixingEngine.PANEL_BANKS.map { bank ->
            val noise = (rng.nextDouble() - 0.5) * spreadRanges
            val quoteVal = FixingEngine.roundToPrecision(centerRate + noise, 5)
            ContributorQuote(
                bankId = bank.bankId,
                bankName = bank.shortName,
                fixingDate = date,
                tenor = tenor,
                quote = quoteVal,
                submissionTimestamp = "$date 10:59:${String.format("%02d", rng.nextInt(58))}",
                status = QuoteStatus.RECEIVED,
                isSynthetic = false
            )
        }
    }

    fun selectTab(tab: TerminalTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun selectFixingTenor(tenor: Tenor) {
        _uiState.update { it.copy(selectedFixingTenor = tenor) }
    }

    fun setCurveType(curveType: CurveType) {
        _uiState.update { it.copy(selectedCurveType = curveType) }
        recalibrateCurve()
    }

    fun setInterpolationMethod(method: InterpolationMethod) {
        _uiState.update { it.copy(selectedInterpolation = method) }
        recalibrateCurve()
    }

    private fun recalibrateCurve() {
        val state = _uiState.value
        val anchorMap = state.hiborFixings.associate { it.tenor to it.rate }.toMutableMap()
        anchorMap[Tenor.Y2] = (anchorMap[Tenor.M12] ?: 4.01) + 0.22
        anchorMap[Tenor.Y3] = (anchorMap[Tenor.M12] ?: 4.01) + 0.38
        anchorMap[Tenor.Y5] = (anchorMap[Tenor.M12] ?: 4.01) + 0.58
        anchorMap[Tenor.Y10] = (anchorMap[Tenor.M12] ?: 4.01) + 0.78

        val newCurve = CurveEngine.calibrateCurve(state.selectedCurveType, state.selectedDate, anchorMap, state.selectedInterpolation)
        val pca = EconometricsEngine.decomposeYieldCurvePCA(newCurve.nodes)
        val swapVal = state.swapValuation?.let { PricingEngine.priceSwap(state.activeSwapTrade, newCurve, newCurve) }

        _uiState.update {
            it.copy(
                calibratedCurve = newCurve,
                pcaResult = pca,
                swapValuation = swapVal
            )
        }
    }

    fun updateSwapParameters(
        notional: Double? = null,
        maturityYears: Double? = null,
        fixedRatePct: Double? = null,
        payerReceiver: PayerReceiver? = null
    ) {
        val current = _uiState.value.activeSwapTrade
        val updated = current.copy(
            notionalHkd = notional ?: current.notionalHkd,
            maturityYears = maturityYears ?: current.maturityYears,
            fixedRatePct = fixedRatePct ?: current.fixedRatePct,
            payerReceiver = payerReceiver ?: current.payerReceiver
        )
        val curve = _uiState.value.calibratedCurve ?: return
        val valuation = PricingEngine.priceSwap(updated, curve, curve)
        _uiState.update { it.copy(activeSwapTrade = updated, swapValuation = valuation) }
    }

    fun updateFraParameters(
        fraName: FRAName? = null,
        strikeRatePct: Double? = null,
        notional: Double? = null
    ) {
        val current = _uiState.value.activeFraTrade
        val updated = current.copy(
            fraName = fraName ?: current.fraName,
            strikeRatePct = strikeRatePct ?: current.strikeRatePct,
            notionalHkd = notional ?: current.notionalHkd
        )
        val curve = _uiState.value.calibratedCurve ?: return
        val valuation = PricingEngine.priceFRA(updated, curve)
        _uiState.update { it.copy(activeFraTrade = updated, fraValuation = valuation) }
    }

    fun applyScenario(scenario: ScenarioShock) {
        val state = _uiState.value
        val risk = state.portfolioRisk ?: return
        val hibor3m = state.hiborFixings.find { it.tenor == Tenor.M3 }?.rate ?: 3.26875
        val result = RiskEngine.evaluateScenario(scenario, risk, hibor3m, state.honiaFixing.overnightRate)
        _uiState.update { it.copy(selectedScenario = scenario, scenarioResult = result) }
    }

    fun updateDigitalTwinShocks(
        usShiftBp: Double? = null,
        liquidityDrainPct: Double? = null,
        pegPressureBp: Double? = null
    ) {
        val us = usShiftBp ?: _uiState.value.digitalTwinUsShiftBp
        val liq = liquidityDrainPct ?: _uiState.value.digitalTwinLiquidityDrainPct
        val peg = pegPressureBp ?: _uiState.value.digitalTwinPegPressureBp

        val nodes = DigitalTwinEngine.simulateTransmission(us, liq, peg)
        _uiState.update {
            it.copy(
                digitalTwinUsShiftBp = us,
                digitalTwinLiquidityDrainPct = liq,
                digitalTwinPegPressureBp = peg,
                digitalTwinNodes = nodes
            )
        }
    }

    fun selectForecastModel(modelType: ForecastModelType, tenor: Tenor) {
        val hibor = _uiState.value.hiborFixings.find { it.tenor == tenor }?.rate ?: 3.26875
        val macro = _uiState.value.macro
        val result = when (modelType) {
            ForecastModelType.OLS_MULTI_FACTOR -> EconometricsEngine.runMultiFactorOLS(tenor, hibor, macro)
            ForecastModelType.ARIMA -> EconometricsEngine.runArimaForecast(tenor, hibor)
            ForecastModelType.KALMAN_FILTER -> EconometricsEngine.runKalmanFilter(tenor, hibor)
            ForecastModelType.VAR -> EconometricsEngine.runMultiFactorOLS(tenor, hibor, macro).copy(modelType = ForecastModelType.VAR, directionalAccuracyPct = 79.2)
            ForecastModelType.GARCH -> EconometricsEngine.runMultiFactorOLS(tenor, hibor, macro).copy(modelType = ForecastModelType.GARCH, assumptions = "GARCH(1,1) dynamic volatility with Fat-Tailed Student-t Innovations.")
        }
        _uiState.update {
            it.copy(
                forecastModelType = modelType,
                forecastTargetTenor = tenor,
                forecastResult = result
            )
        }
    }

    fun setReplayDate(date: String) {
        val state = ReplayEngine.reconstructHistoricalState(date)
        val compounded = HoniaEngine.generateCompoundedTenors(state.honiaFixing.overnightRate)
        val basis = HoniaEngine.calculateBasis(state.hiborFixings, compounded, state.honiaFixing.overnightRate)
        val anchorMap = state.hiborFixings.associate { it.tenor to it.rate }
        val curve = CurveEngine.calibrateCurve(CurveType.HIBOR_PROJECTION, date, anchorMap)
        val pca = EconometricsEngine.decomposeYieldCurvePCA(curve.nodes)

        val audit = AuditAndReportEngine.logAudit(
            action = "HISTORICAL_REPLAY",
            targetObject = "RATE_DATABASE",
            oldValue = _uiState.value.selectedDate,
            newValue = date,
            reason = "Point-in-time rates reconstruction (No Lookahead Bias)"
        )

        val report = AuditAndReportEngine.generateDailyReport(date, state.hiborFixings, state.honiaFixing, basis, curve, state.macro)

        _uiState.update {
            it.copy(
                selectedDate = date,
                isReplayMode = state.isReplayActive,
                hiborFixings = state.hiborFixings,
                honiaFixing = state.honiaFixing,
                compoundedHoniaList = compounded,
                basisMetrics = basis,
                macro = state.macro,
                calibratedCurve = curve,
                pcaResult = pca,
                auditEvents = listOf(audit) + it.auditEvents,
                generatedReportText = report
            )
        }
    }

    fun toggleLiveFeed() {
        val nextState = !_uiState.value.isLiveFeedActive
        _uiState.update { it.copy(isLiveFeedActive = nextState) }

        if (nextState) {
            liveFeedJob?.cancel()
            liveFeedJob = viewModelScope.launch {
                while (isActive) {
                    delay(3000)
                    tickLiveMarket()
                }
            }
        } else {
            liveFeedJob?.cancel()
            liveFeedJob = null
        }
    }

    private fun tickLiveMarket() {
        val current = _uiState.value
        val rng = Random.Default
        val deltaSpot = (rng.nextDouble() - 0.5) * 0.0004
        val newSpot = minOf(7.8490, maxOf(7.7510, current.macro.usdHkdSpot + deltaSpot))

        val updatedFixings = current.hiborFixings.map { f ->
            val tick = (rng.nextDouble() - 0.5) * 0.002
            val newRate = FixingEngine.roundToPrecision(f.rate + tick, 5)
            val prev = f.previousRate
            val chg = round((newRate - prev) * 10000.0) / 100.0
            f.copy(rate = newRate, changeBp = chg)
        }

        val anchorMap = updatedFixings.associate { it.tenor to it.rate }
        val newCurve = CurveEngine.calibrateCurve(current.selectedCurveType, current.selectedDate, anchorMap, current.selectedInterpolation)
        val newBasis = HoniaEngine.calculateBasis(updatedFixings, current.compoundedHoniaList, current.honiaFixing.overnightRate)

        _uiState.update {
            it.copy(
                macro = it.macro.copy(usdHkdSpot = newSpot),
                hiborFixings = updatedFixings,
                calibratedCurve = newCurve,
                basisMetrics = newBasis
            )
        }
    }

    fun executeCliCommand(command: String) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        val parts = trimmed.split("\\s+".toRegex())
        val cmd = parts[0].lowercase()

        val response = when (cmd) {
            "help" -> "Commands:\n- hibor [tenor]: Show fixing (e.g. hibor 3M)\n- honia: Show overnight index & volume\n- curve [hkd|type]: Inspect calibrated curve\n- forward [t1] [t2]: Compute forward rate (e.g. forward 3M 6M)\n- basis: Inspect HIBOR/HONIA basis spreads\n- risk: Portfolio DV01 & P&L breakdown\n- scenario [+50bp|-50bp|steepener]: Run stress shock\n- replay [YYYY-MM-DD]: Historical point-in-time replay\n- report: Generate daily institutional fixing sheet\n- clear: Clear CLI output"
            "status" -> "HKD RATES TERMINAL: ONLINE | FIXINGS: OFFICIAL | ARCHITECTURE: 2026 TMA/HKAB COMPLIANT"
            "hibor" -> {
                val tenorStr = parts.getOrNull(1) ?: "3M"
                val tenor = Tenor.fromCode(tenorStr)
                val fixing = _uiState.value.hiborFixings.find { it.tenor == tenor }
                if (fixing != null) {
                    selectFixingTenor(tenor)
                    selectTab(TerminalTab.FIXING_ENGINE)
                    "HIBOR ${fixing.tenor.code}: ${fixing.rate}% (Prev: ${fixing.previousRate}%, Chg: ${fixing.changeBp} bp, Dispersion: ${fixing.qualityMetrics?.dispersionStatus})"
                } else {
                    "Unknown tenor $tenorStr. Available: ON, 1W, 2W, 1M, 2M, 3M, 6M, 12M"
                }
            }
            "honia" -> {
                selectTab(TerminalTab.BASIS_DESK)
                "HONIA OVERNIGHT: ${_uiState.value.honiaFixing.overnightRate}% | VOLUME: HK$ ${_uiState.value.honiaFixing.transactionVolumeHkdBn}B | PUBLICATION: 16:00 HKT"
            }
            "curve" -> {
                selectTab(TerminalTab.YIELD_CURVE)
                val curve = _uiState.value.calibratedCurve
                val summary = curve?.nodes?.joinToString("\n") { "${it.tenor.code}: Zero ${it.zeroRate}%, DF: ${it.discountFactor}, Fwd: ${it.forwardRate}%" }
                "HKD YIELD CURVE (${curve?.curveType?.label}):\n$summary"
            }
            "forward" -> {
                val t1Str = parts.getOrNull(1) ?: "3M"
                val t2Str = parts.getOrNull(2) ?: "6M"
                val t1 = Tenor.fromCode(t1Str).maturityYears
                val t2 = Tenor.fromCode(t2Str).maturityYears
                val curve = _uiState.value.calibratedCurve
                if (curve != null && t2 > t1) {
                    val fwd = CurveEngine.calculateForwardRate(t1, t2, curve)
                    "FORWARD RATE $t1Str -> $t2Str: $fwd% (ACT/365F continuous compounding)"
                } else {
                    "Invalid forward tenors. Example: forward 3M 6M"
                }
            }
            "basis" -> {
                selectTab(TerminalTab.BASIS_DESK)
                val lines = _uiState.value.basisMetrics.joinToString("\n") { "${it.tenor.code}: HIBOR ${it.hiborRate}% - HONIA ${it.honiaRate}% = Basis ${it.basisBp} bp (${it.regime.label})" }
                "HIBOR / HONIA BASIS SPREADS:\n$lines"
            }
            "risk" -> {
                selectTab(TerminalTab.PORTFOLIO_RISK)
                val r = _uiState.value.portfolioRisk
                "PORTFOLIO RISK:\nTotal PV: HK$ ${r?.totalPvHkd}\nTotal DV01: HK$ ${r?.totalDv01Hkd}/bp\nP&L Today: HK$ ${r?.totalPnlHkd}\nHIBOR Exp: HK$ ${r?.hiborExposureHkd}\nHONIA Exp: HK$ ${r?.honiaExposureHkd}"
            }
            "scenario" -> {
                val arg = parts.getOrNull(1) ?: "+50bp"
                val shock = when (arg.lowercase()) {
                    "+25bp" -> ScenarioShock("SCEN_25", "HIBOR +25bp", "Parallel shift +25bp", 25.0)
                    "+50bp", "+50" -> ScenarioShock("SCEN_50", "HIBOR +50bp", "Parallel shift +50bp", 50.0)
                    "+100bp", "+100" -> ScenarioShock("SCEN_100", "HIBOR +100bp", "Parallel shift +100bp", 100.0)
                    "-50bp", "-50" -> ScenarioShock("SCEN_M50", "HIBOR -50bp", "Parallel shift -50bp", -50.0)
                    "steepener" -> ScenarioShock("SCEN_STP", "2s10s Steepener", "Steepener shock", 0.0, CurveShockType.STEEPENER_2S10S)
                    else -> ScenarioShock("SCEN_CUSTOM", "Custom Shock ($arg)", "Custom shift", 50.0)
                }
                applyScenario(shock)
                selectTab(TerminalTab.PORTFOLIO_RISK)
                val res = _uiState.value.scenarioResult
                "SCENARIO APPLIED: ${shock.name}\nPortfolio P&L Delta: HK$ ${res?.portfolioPnlHkd}\nPost-Shock 3M HIBOR: ${res?.postShockHibor3mPct}%\nBank NIM Delta: ${res?.bankNimDeltaBp} bp"
            }
            "replay" -> {
                val dateStr = parts.getOrNull(1) ?: "2024-09-10"
                setReplayDate(dateStr)
                selectTab(TerminalTab.REPLAY_BACKTEST)
                "REPLAY ACTIVE FOR DATE: $dateStr (Historical rates & curve reconstructed)"
            }
            "report" -> {
                selectTab(TerminalTab.AUDIT_REPORTS)
                "DAILY INSTITUTIONAL RATES REPORT GENERATED. Navigating to Audit & Reports tab."
            }
            "clear" -> ""
            else -> "Unrecognized command '$cmd'. Type 'help' for available terminal instructions."
        }

        _uiState.update {
            it.copy(
                cliInput = "",
                cliOutput = if (response.isEmpty()) "" else "> $command\n$response"
            )
        }
    }

    fun updateCliInput(text: String) {
        _uiState.update { it.copy(cliInput = text) }
    }

    override fun onCleared() {
        super.onCleared()
        liveFeedJob?.cancel()
    }
}
