package com.example.data.model

import java.time.LocalDate
import java.time.format.DateTimeFormatter

enum class Tenor(val code: String, val label: String, val maturityYears: Double, val days: Int, val order: Int) {
    ON("ON", "Overnight", 1.0 / 365.0, 1, 1),
    W1("1W", "1 Week", 7.0 / 365.0, 7, 2),
    W2("2W", "2 Weeks", 14.0 / 365.0, 14, 3),
    M1("1M", "1 Month", 1.0 / 12.0, 30, 4),
    M2("2M", "2 Months", 2.0 / 12.0, 60, 5),
    M3("3M", "3 Months", 0.25, 90, 6),
    M6("6M", "6 Months", 0.5, 180, 7),
    M12("12M", "12 Months", 1.0, 365, 8),
    Y2("2Y", "2 Years", 2.0, 730, 9),
    Y3("3Y", "3 Years", 3.0, 1095, 10),
    Y5("5Y", "5 Years", 5.0, 1825, 11),
    Y10("10Y", "10 Years", 10.0, 3650, 12);

    companion object {
        fun fromCode(code: String): Tenor = entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: M3
        val fixingTenors = listOf(ON, W1, W2, M1, M2, M3, M6, M12)
        val curveTenors = listOf(ON, W1, M1, M3, M6, M12, Y2, Y3, Y5, Y10)
    }
}

enum class DataStatus(val label: String, val badgeColorHex: Long) {
    OFFICIAL("OFFICIAL", 0xFF059669),
    LICENSED("LICENSED", 0xFF0284C7),
    VERIFIED("VERIFIED", 0xFF0D9488),
    OBSERVED("OBSERVED", 0xFF2563EB),
    DERIVED("DERIVED", 0xFF7C3AED),
    MODELLED("MODELLED", 0xFF9333EA),
    SIMULATED("SIMULATED", 0xFFD97706),
    SYNTHETIC("SYNTHETIC", 0xFFE11D48),
    UNKNOWN("UNKNOWN", 0xFF64748B)
}

enum class QuoteStatus {
    RECEIVED, VALIDATED, REJECTED, INCLUDED, EXCLUDED_HIGH, EXCLUDED_LOW, REVISED
}

enum class DayCountConvention(val label: String, val basisDenominator: Double) {
    ACT_365F("ACT/365F", 365.0),
    ACT_360("ACT/360", 360.0),
    THIRTY_360("30/360", 360.0),
    ACT_ACT("ACT/ACT", 365.25)
}

enum class BusinessDayConvention(val label: String) {
    FOLLOWING("Following"),
    MODIFIED_FOLLOWING("Modified Following"),
    PRECEDING("Preceding"),
    MODIFIED_PRECEDING("Modified Preceding")
}

data class BenchmarkMethodology(
    val version: String = "HKAB-2013-V2.1",
    val benchmarkName: String = "HKD HIBOR",
    val administrator: String = "TMA (Treasury Markets Association) / HKAB",
    val totalContributors: Int = 20,
    val trimHighCount: Int = 3,
    val trimLowCount: Int = 3,
    val precisionDecimals: Int = 5,
    val fixingTimeHKT: String = "11:00 HKT",
    val publicationTimeHKT: String = "11:15 HKT",
    val primaryDayCount: DayCountConvention = DayCountConvention.ACT_365F,
    val businessDayConvention: BusinessDayConvention = BusinessDayConvention.MODIFIED_FOLLOWING,
    val revisionAllowedUntilHKT: String = "12:00 HKT"
)

data class ContributorBank(
    val bankId: String,
    val legalName: String,
    val shortName: String,
    val marketCategory: String, // Tier 1 Note-Issuing, Global Bulge Bracket, Regional Major
    val active: Boolean = true
)

data class ContributorQuote(
    val bankId: String,
    val bankName: String,
    val fixingDate: String,
    val tenor: Tenor,
    val quote: Double,
    val submissionTimestamp: String,
    val status: QuoteStatus,
    val isSynthetic: Boolean = false,
    val deviationFromFixingBp: Double = 0.0
)

data class FixingQualityMetrics(
    val quoteCount: Int,
    val mean: Double,
    val median: Double,
    val trimmedMean: Double,
    val standardDeviation: Double,
    val highLowRangeBp: Double,
    val interquartileRangeBp: Double,
    val dispersionStatus: String, // NORMAL, NARROW, ELEVATED, EXTREME
    val anomalyFlags: List<String> = emptyList()
)

data class HIBORFixing(
    val fixingDate: String,
    val publicationTimestamp: String,
    val tenor: Tenor,
    val rate: Double,
    val previousRate: Double,
    val changeBp: Double,
    val currency: String = "HKD",
    val contributingQuotes: List<ContributorQuote> = emptyList(),
    val quoteCount: Int = 20,
    val highQuotesExcluded: Int = 3,
    val lowQuotesExcluded: Int = 3,
    val middleQuoteAverage: Double = rate,
    val revisionStatus: String = "FINAL",
    val source: String = "HKAB / TMA Official",
    val sourceTimestamp: String = "11:15:02 HKT",
    val methodologyVersion: String = "HKAB-2013-V2.1",
    val dataStatus: DataStatus = DataStatus.OFFICIAL,
    val qualityMetrics: FixingQualityMetrics? = null,
    val calculationAuditHash: String = ""
)

data class HONIAFixing(
    val date: String,
    val overnightRate: Double,
    val previousRate: Double,
    val changeBp: Double,
    val transactionVolumeHkdBn: Double,
    val source: String = "TMA (Treasury Markets Association)",
    val publicationTime: String = "16:00 HKT",
    val methodologyVersion: String = "TMA-HONIA-2019-V1",
    val dataStatus: DataStatus = DataStatus.OFFICIAL
)

data class CompoundedHonia(
    val periodLabel: String,
    val tenorDays: Int,
    val compoundedRate: Double,
    val simpleAverageRate: Double,
    val lookbackDays: Int = 5,
    val paymentLagDays: Int = 2,
    val dataStatus: DataStatus = DataStatus.DERIVED
)

enum class BasisRegime(val label: String, val description: String) {
    NORMAL("Normal", "Typical term liquidity spread (15-30bp)"),
    FUNDING_PRESSURE("Funding Stress", "Elevated term premium and balance sheet cost"),
    LIQUIDITY_SURPLUS("Liquidity Surplus", "HONIA close to Base Rate, compressed basis"),
    YEAR_END_TURN("Year-End Turn", "Acute cross-period structural premium"),
    IPO_LOCKUP("IPO / Retail Lockup", "Temporary interbank clearing drain")
}

data class BasisMetric(
    val tenor: Tenor,
    val hiborRate: Double,
    val honiaRate: Double,
    val basisBp: Double, // HIBOR - HONIA in basis points
    val change1dBp: Double,
    val percentile5y: Double, // 0.0 to 100.0
    val zscore1y: Double,
    val rollingVolAnnualized: Double,
    val regime: BasisRegime
)

enum class CurveType(val label: String) {
    HIBOR_PROJECTION("HIBOR 3M Projection"),
    HONIA_OIS("HONIA OIS Curve"),
    HKD_DISCOUNT("HKD Risk-Free Discount"),
    FORWARD_CURVE("HKD Forward Curve"),
    FUNDING_CURVE("Bank Commercial Funding")
}

enum class InterpolationMethod(val label: String) {
    MONOTONE_CUBIC_SPLINE("Monotone Cubic Spline"),
    NELSON_SIEGEL("Nelson-Siegel Model"),
    LOG_LINEAR_DISCOUNT("Log-Linear Discount Factors"),
    PIECEWISE_LINEAR("Piecewise Linear")
}

data class NelsonSiegelParams(
    val beta0: Double, // Long-term level
    val beta1: Double, // Short-term component (Slope)
    val beta2: Double, // Medium-term component (Curvature)
    val lambda: Double // Decay parameter
)

data class CurveNode(
    val tenor: Tenor,
    val maturityYears: Double,
    val zeroRate: Double,
    val discountFactor: Double,
    val forwardRate: Double,
    val instantaneousFwd: Double,
    val changeBp: Double = 0.0,
    val percentile: Double = 50.0
)

data class CalibratedCurve(
    val curveType: CurveType,
    val asOfDate: String,
    val nodes: List<CurveNode>,
    val interpolationMethod: InterpolationMethod = InterpolationMethod.MONOTONE_CUBIC_SPLINE,
    val calibrationErrorBp: Double = 0.02,
    val nelsonSiegelParams: NelsonSiegelParams? = null,
    val dataStatus: DataStatus = DataStatus.DERIVED
)

enum class SwapType(val label: String) {
    HIBOR_IRS_3M("HKD HIBOR 3M IRS"),
    HIBOR_IRS_1M("HKD HIBOR 1M IRS"),
    HONIA_OIS("HKD HONIA OIS"),
    BASIS_SWAP_3M("HIBOR 3M vs HONIA Basis Swap")
}

enum class PayerReceiver(val label: String) {
    PAY_FIXED("Pay Fixed / Receive Float"),
    RECEIVE_FIXED("Receive Fixed / Pay Float")
}

data class SwapTrade(
    val tradeId: String,
    val swapType: SwapType,
    val notionalHkd: Double,
    val effectiveDate: String,
    val maturityYears: Double,
    val fixedRatePct: Double,
    val floatingSpreadBp: Double = 0.0,
    val payerReceiver: PayerReceiver = PayerReceiver.PAY_FIXED,
    val paymentFrequencyMonths: Int = 3,
    val dayCount: DayCountConvention = DayCountConvention.ACT_365F
)

data class SwapCashflow(
    val periodIndex: Int,
    val periodStart: String,
    val periodEnd: String,
    val paymentDate: String,
    val fixingDate: String,
    val notional: Double,
    val ratePct: Double,
    val dayFraction: Double,
    val interestAmountHkd: Double,
    val discountFactor: Double,
    val presentValueHkd: Double,
    val isFixedLeg: Boolean
)

data class SwapValuation(
    val tradeId: String,
    val fixedLegPvHkd: Double,
    val floatingLegPvHkd: Double,
    val netPvHkd: Double,
    val fairSwapRatePct: Double,
    val dv01Hkd: Double,
    val pv01Hkd: Double,
    val modifiedDuration: Double,
    val convexity: Double,
    val cashflows: List<SwapCashflow>
)

enum class FRAName(val label: String, val startMonths: Int, val endMonths: Int, val tenorLabel: String) {
    FRA_1X4("FRA 1x4", 1, 4, "3M HIBOR in 1M"),
    FRA_3X6("FRA 3x6", 3, 6, "3M HIBOR in 3M"),
    FRA_6X9("FRA 6x9", 6, 9, "3M HIBOR in 6M"),
    FRA_9X12("FRA 9x12", 9, 12, "3M HIBOR in 9M")
}

data class FRATrade(
    val tradeId: String,
    val fraName: FRAName,
    val notionalHkd: Double,
    val strikeRatePct: Double,
    val isPayFixed: Boolean = true
)

data class FRAValuation(
    val tradeId: String,
    val impliedForwardRatePct: Double,
    val settlementAmountHkd: Double,
    val presentValueHkd: Double,
    val dv01Hkd: Double,
    val pnlBp: Double
)

data class FRNTrade(
    val tradeId: String,
    val issuer: String,
    val notionalHkd: Double,
    val maturityYears: Double,
    val benchmarkTenor: Tenor = Tenor.M3,
    val spreadBp: Double = 65.0,
    val couponFrequencyMonths: Int = 3
)

data class BondValuation(
    val tradeId: String,
    val currentCouponPct: Double,
    val cleanPricePct: Double,
    val dirtyPricePct: Double,
    val yieldToMaturityPct: Double,
    val discountMarginBp: Double,
    val dv01Hkd: Double,
    val modifiedDuration: Double
)

data class LoanFacility(
    val facilityId: String,
    val borrower: String,
    val principalHkd: Double,
    val baseBenchmark: Tenor = Tenor.M3,
    val creditSpreadBp: Double = 120.0,
    val liquiditySpreadBp: Double = 25.0,
    val capitalChargeBp: Double = 15.0,
    val facilityFeeBp: Double = 10.0,
    val maturityYears: Double = 5.0
)

data class LoanPricingResult(
    val facilityId: String,
    val baseHiborRatePct: Double,
    val totalSpreadBp: Double,
    val allInRatePct: Double,
    val annualInterestHkd: Double,
    val monthlyInterestHkd: Double,
    val interestSensitivityPer25bpHkd: Double,
    val breakEvenHedgeRatePct: Double
)

data class PortfolioPosition(
    val positionId: String,
    val instrumentType: String,
    val description: String,
    val notionalHkd: Double,
    val pvHkd: Double,
    val dv01Hkd: Double,
    val pnlTodayHkd: Double,
    val currency: String = "HKD"
)

data class KeyRateDV01(
    val bucket: Tenor,
    val dv01Hkd: Double
)

data class PLAttribution(
    val totalPnlHkd: Double,
    val curveShiftPnlHkd: Double,
    val carryPnlHkd: Double,
    val fixingPnlHkd: Double,
    val basisPnlHkd: Double,
    val fxPnlHkd: Double,
    val newTradePnlHkd: Double
)

data class PortfolioRiskResult(
    val portfolioId: String,
    val name: String,
    val totalPvHkd: Double,
    val totalPnlHkd: Double,
    val totalDv01Hkd: Double,
    val totalPv01Hkd: Double,
    val totalConvexity: Double,
    val totalCs01Hkd: Double,
    val hiborExposureHkd: Double,
    val honiaExposureHkd: Double,
    val basisExposureHkd: Double,
    val keyRateLadder: List<KeyRateDV01>,
    val plAttribution: PLAttribution
)

enum class CurveShockType(val label: String) {
    NONE("Parallel Only"),
    STEEPENER_2S10S("2s10s Steepener (+20bp 10Y, -10bp 2Y)"),
    FLATTENER_2S10S("2s10s Flattener (-20bp 10Y, +10bp 2Y)"),
    BUTTERFLY_1M3M6M("1m3m6m Body Hump (+15bp 3M)"),
    LIQUIDITY_CRUNCH("Interbank Liquidity Drain (Short-end +60bp)")
}

data class ScenarioShock(
    val id: String,
    val name: String,
    val description: String,
    val parallelShiftBp: Double,
    val curveShape: CurveShockType = CurveShockType.NONE,
    val tenorShocksBp: Map<Tenor, Double> = emptyMap(),
    val liquidityShockPct: Double = 0.0,
    val usdHkdShift: Double = 0.0
)

data class ScenarioResult(
    val scenarioName: String,
    val portfolioPnlHkd: Double,
    val postShockPvHkd: Double,
    val postShockDv01Hkd: Double,
    val postShockHibor3mPct: Double,
    val postShockHoniaPct: Double,
    val bankNimDeltaBp: Double,
    val corporateBorrowingCostDeltaHkd: Double
)

data class MacroEnvironment(
    val date: String,
    val usdHkdSpot: Double = 7.7785,
    val hkmaAggregateBalanceBn: Double = 44.8, // HKD Billion
    val hkmaBaseRatePct: Double = 4.75,
    val usFedFundsRatePct: Double = 4.50,
    val usSofrPct: Double = 4.38,
    val cipBasisBp: Double = -18.4,
    val forwardPoints12m: Double = -245.0,
    val dataStatus: DataStatus = DataStatus.OBSERVED
)

data class DigitalTwinNode(
    val id: String,
    val label: String,
    val category: String, // MONETARY, INTERBANK, TREASURY, CORPORATE, ASSET
    val baseValue: String,
    val shockedValue: String,
    val deltaText: String,
    val isStressed: Boolean = false
)

enum class ForecastModelType(val label: String, val method: String) {
    ARIMA("ARIMA (2,1,2)", "Autoregressive Integrated Moving Average with drift"),
    VAR("Vector Autoregression (VAR)", "Multi-factor VAR including SOFR, Aggregate Balance, Spot"),
    KALMAN_FILTER("State-Space Kalman Filter", "Dynamic latent rate trend and transient noise extraction"),
    GARCH("GARCH(1,1)", "Conditional Heteroskedasticity Volatility & Tail Bounds"),
    OLS_MULTI_FACTOR("Econometric Multi-Factor OLS", "Stepwise Macro Driver Decomposition")
}

data class ForecastResult(
    val modelType: ForecastModelType,
    val targetTenor: Tenor,
    val currentRatePct: Double,
    val horizonDays: Int,
    val predictedRatePct: Double,
    val lower95Pct: Double,
    val upper95Pct: Double,
    val mae: Double,
    val rmse: Double,
    val directionalAccuracyPct: Double,
    val factorsUsed: List<String>,
    val assumptions: String
)

data class PCAResult(
    val levelVariancePct: Double = 84.5,
    val slopeVariancePct: Double = 11.8,
    val curvatureVariancePct: Double = 3.2,
    val levelScore: Double = 0.42,
    val slopeScore: Double = -0.18,
    val curvatureScore: Double = 0.05
)

data class AuditEvent(
    val eventId: String,
    val timestamp: String,
    val user: String,
    val role: String,
    val action: String,
    val targetObject: String,
    val oldValue: String,
    val newValue: String,
    val reason: String,
    val dataStatus: DataStatus,
    val auditHash: String
)

data class HistoricalReplayState(
    val replayDate: String,
    val hiborFixings: List<HIBORFixing>,
    val honiaFixing: HONIAFixing,
    val macro: MacroEnvironment,
    val portfolioRisk: PortfolioRiskResult,
    val isReplayActive: Boolean = false
)

data class BacktestStrategy(
    val id: String,
    val name: String,
    val description: String,
    val totalReturnPct: Double,
    val annualizedSharpe: Double,
    val maxDrawdownPct: Double,
    val winRatePct: Double,
    val tradesCount: Int
)
