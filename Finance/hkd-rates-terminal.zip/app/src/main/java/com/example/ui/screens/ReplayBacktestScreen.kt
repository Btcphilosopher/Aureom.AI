package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BacktestStrategy
import com.example.data.model.DataStatus
import com.example.engine.ReplayEngine
import com.example.ui.TerminalUiState
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun ReplayBacktestScreen(
    state: TerminalUiState,
    onSelectReplayDate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] Historical Replay Date Selector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.History, contentDescription = null, tint = TerminalGold, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "HISTORICAL POINT-IN-TIME REPLAY",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                        }
                        ProvenanceBadge(status = DataStatus.OBSERVED)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Reconstruct the entire HKD money-market and yield curve environment as of historical dates with zero lookahead bias.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextDim)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    ReplayEngine.REPLAY_DATES.forEach { (date, desc) ->
                        val isSelected = date == state.selectedDate
                        Surface(
                            color = if (isSelected) TerminalGold.copy(alpha = 0.15f) else TerminalCardAlt,
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) TerminalGold else TerminalBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable { onSelectReplayDate(date) }
                                .testTag("replay_date_$date")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = date,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) TerminalGold else TextWhite
                                        )
                                    )
                                    Text(
                                        text = desc,
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextDim, fontSize = 10.sp)
                                    )
                                }

                                if (isSelected) {
                                    Surface(
                                        color = TerminalGold,
                                        shape = RoundedCornerShape(3.dp)
                                    ) {
                                        Text(
                                            text = "ACTIVE",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = TerminalBg,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp
                                            ),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // [2] Quantitative Rates Strategy Backtesting
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "QUANTITATIVE RATES STRATEGIES BACKTEST",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    state.backtestStrategies.forEach { strat ->
                        Surface(
                            color = TerminalCardAlt,
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = strat.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextWhite
                                        )
                                    )
                                    Text(
                                        text = "+${strat.totalReturnPct}% Return",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            color = TerminalEmerald
                                        )
                                    )
                                }

                                Spacer(modifier = Modifier.height(2.dp))
                                Text(strat.description, style = MaterialTheme.typography.bodySmall.copy(color = TextDim, fontSize = 10.sp))

                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Sharpe: ${strat.annualizedSharpe}", style = MaterialTheme.typography.labelSmall.copy(color = TerminalCyan))
                                    Text("Max DD: ${strat.maxDrawdownPct}%", style = MaterialTheme.typography.labelSmall.copy(color = TerminalRose))
                                    Text("Win Rate: ${strat.winRatePct}%", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                                    Text("Trades: ${strat.tradesCount}", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
