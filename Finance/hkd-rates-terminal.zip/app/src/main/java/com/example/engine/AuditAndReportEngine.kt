package com.example.engine

import com.example.data.model.*
import java.security.MessageDigest
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object AuditAndReportEngine {

    private val timeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

    fun logAudit(
        user: String = "DESK_QUANT_01",
        role: String = "RATES_TRADER",
        action: String,
        targetObject: String,
        oldValue: String,
        newValue: String,
        reason: String,
        dataStatus: DataStatus = DataStatus.VERIFIED
    ): AuditEvent {
        val now = LocalDateTime.now().format(timeFormatter)
        val raw = "$now|$user|$role|$action|$targetObject|$oldValue|$newValue"
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(raw.toByteArray())
            .take(6)
            .joinToString("") { "%02x".format(it) }
            .uppercase()

        return AuditEvent(
            eventId = "AUD_${System.currentTimeMillis() % 1000000}",
            timestamp = now,
            user = user,
            role = role,
            action = action,
            targetObject = targetObject,
            oldValue = oldValue,
            newValue = newValue,
            reason = reason,
            dataStatus = dataStatus,
            auditHash = hash
        )
    }

    fun generateDailyReport(
        date: String,
        hiborFixings: List<HIBORFixing>,
        honiaFixing: HONIAFixing,
        basisMetrics: List<BasisMetric>,
        curve: CalibratedCurve,
        macro: MacroEnvironment
    ): String {
        val sb = StringBuilder()
        sb.append("================================================================================\n")
        sb.append("                 HKD RATES TERMINAL — DAILY INSTITUTIONAL FIXING REPORT         \n")
        sb.append("                      ADMINISTERED BY TMA / HKAB BENCHMARK ENGINE               \n")
        sb.append("================================================================================\n")
        sb.append("Date: $date  |  Publication Time: 11:15 HKT  |  Methodology: HKAB-2013-V2.1\n")
        sb.append("Data Status: OFFICIAL / VERIFIED  |  Calendar: Hong Kong Public (ACT/365F)\n\n")

        sb.append("--- [1] HIBOR OFFICIAL FIXINGS ---\n")
        sb.append(String.format("%-6s | %-10s | %-10s | %-8s | %-12s | %-8s\n", "TENOR", "RATE (%)", "PREV (%)", "CHG (bp)", "DISPERSION", "STATUS"))
        sb.append("--------------------------------------------------------------------------------\n")
        hiborFixings.forEach { f ->
            val disp = f.qualityMetrics?.dispersionStatus ?: "NORMAL"
            sb.append(String.format("%-6s | %-10.5f | %-10.5f | %-+8.2f | %-12s | %-8s\n", f.tenor.code, f.rate, f.previousRate, f.changeBp, disp, f.dataStatus.name))
        }

        sb.append("\n--- [2] HONIA (HONG KONG DOLLAR OVERNIGHT INDEX AVERAGE) ---\n")
        sb.append(String.format("HONIA Overnight Rate : %.4f%%\n", honiaFixing.overnightRate))
        sb.append(String.format("Transaction Volume   : HK$ %.2f Billion\n", honiaFixing.transactionVolumeHkdBn))
        sb.append(String.format("Publication Time     : %s\n", honiaFixing.publicationTime))

        sb.append("\n--- [3] HIBOR vs HONIA BASIS SPREADS ---\n")
        sb.append(String.format("%-6s | %-10s | %-10s | %-10s | %-8s | %-14s\n", "TENOR", "HIBOR (%)", "HONIA (%)", "BASIS (bp)", "Z-SCORE", "REGIME"))
        sb.append("--------------------------------------------------------------------------------\n")
        basisMetrics.forEach { b ->
            sb.append(String.format("%-6s | %-10.5f | %-10.5f | %-+10.2f | %-+8.2f | %-14s\n", b.tenor.code, b.hiborRate, b.honiaRate, b.basisBp, b.zscore1y, b.regime.label))
        }

        sb.append("\n--- [4] MONETARY ENVIRONMENT & HKMA LIQUIDITY ---\n")
        sb.append(String.format("USD/HKD Spot Rate       : %.4f (LERS Band: 7.7500 - 7.8500)\n", macro.usdHkdSpot))
        sb.append(String.format("HKMA Aggregate Balance  : HK$ %.1f Billion\n", macro.hkmaAggregateBalanceBn))
        sb.append(String.format("HKMA Base Rate          : %.2f%%\n", macro.hkmaBaseRatePct))
        sb.append(String.format("US SOFR Benchmark       : %.2f%%\n", macro.usSofrPct))
        sb.append(String.format("Covered Int. Parity Diff: %+.2f bp\n", macro.cipBasisBp))

        sb.append("\n================================================================================\n")
        sb.append("END OF REPORT — HONG KONG RATES MONETARY DESK INFRASTRUCTURE\n")
        return sb.toString()
    }
}
