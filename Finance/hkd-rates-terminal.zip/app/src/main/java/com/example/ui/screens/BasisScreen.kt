package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.TerminalUiState
import com.example.ui.components.FinancialStatCard
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun BasisScreen(
    state: TerminalUiState,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] HONIA Benchmark Overview Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "HONIA (HKD OVERNIGHT INDEX AVERAGE)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                            Text(
                                text = "Administered by TMA  •  Transaction-Based Overnight Rate",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextDim)
                            )
                        }
                        ProvenanceBadge(status = state.honiaFixing.dataStatus)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("HONIA OVERNIGHT", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                            Text(
                                text = "${String.format("%.4f", state.honiaFixing.overnightRate)}%",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalPurple,
                                    fontSize = 24.sp
                                )
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("DAILY VOLUME", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                            Text(
                                text = "HK$ ${state.honiaFixing.transactionVolumeHkdBn}B",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                        }
                    }
                }
            }
        }

        // [2] Compounded HONIA Indices
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "COMPOUNDED HONIA TENORS (BACKWARD-LOOKING RFR)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    state.compoundedHoniaList.forEach { comp ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(comp.periodLabel, style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${String.format("%.5f", comp.compoundedRate)}%",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = TerminalPurple
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "(${comp.tenorDays}D)",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // [3] HIBOR / HONIA Term Basis Spread Matrix
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "HIBOR / HONIA BASIS SPREADS",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    )
                    Text(
                        text = "Term Funding & Interbank Liquidity Premium (HIBOR - Compounded HONIA)",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextDim)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalCardAlt, RoundedCornerShape(3.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TENOR", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1f))
                        Text("HIBOR", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.2f))
                        Text("HONIA", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.2f))
                        Text("BASIS (bp)", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.3f))
                        Text("Z-SCORE", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp), modifier = Modifier.weight(1.1f))
                    }

                    state.basisMetrics.forEach { b ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(b.tenor.code, style = MaterialTheme.typography.bodyMedium.copy(color = TextWhite, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1f))
                            Text(String.format("%.4f", b.hiborRate), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TextWhite), modifier = Modifier.weight(1.2f))
                            Text(String.format("%.4f", b.honiaRate), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = TerminalPurple), modifier = Modifier.weight(1.2f))
                            Text(
                                text = "+${String.format("%.1f", b.basisBp)}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalGold
                                ),
                                modifier = Modifier.weight(1.3f)
                            )
                            Text(
                                text = "${if (b.zscore1y >= 0) "+" else ""}${String.format("%.2f", b.zscore1y)}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = if (b.zscore1y > 1.0) TerminalRose else TerminalCyan
                                ),
                                modifier = Modifier.weight(1.1f)
                            )
                        }
                    }
                }
            }
        }

        // [4] Basis Regime Insights
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "MONEY MARKET REGIME ANALYSIS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "• 3M Basis (+32.5 bp): Sits at 68.5th percentile of historical 5-year distribution.\n• Term Premium Driver: Stable HKMA Aggregate Balance (HK$44.8B) maintaining moderate interbank liquidity.\n• Year-End Turn / Turn Premium: Modest curve steepening at 1M-3M reflecting commercial paper demand.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, lineHeight = 16.sp)
                    )
                }
            }
        }
    }
}
