package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DataStatus
import com.example.ui.TerminalUiState
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun DigitalTwinScreen(
    state: TerminalUiState,
    onUpdateShocks: (Double?, Double?, Double?) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // [1] Digital Twin Header & Interactive Controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Hub, contentDescription = null, tint = TerminalBlue, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "HKD RATES DIGITAL TWIN",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            )
                        }
                        ProvenanceBadge(status = DataStatus.SIMULATED)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Computational transmission simulator modeling the Linked Exchange Rate System (LERS), aggregate balance drain, interbank clearing, and corporate debt impacts.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextDim, lineHeight = 15.sp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Slider 1: US Rates Shift
                    Text(
                        text = "US Fed Funds / SOFR Shift: ${if (state.digitalTwinUsShiftBp >= 0) "+" else ""}${state.digitalTwinUsShiftBp.toInt()} bp",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextWhite)
                    )
                    Slider(
                        value = state.digitalTwinUsShiftBp.toFloat(),
                        onValueChange = { onUpdateShocks(it.toDouble(), null, null) },
                        valueRange = -100f..200f,
                        steps = 11,
                        colors = SliderDefaults.colors(thumbColor = TerminalBlue, activeTrackColor = TerminalBlue)
                    )

                    // Slider 2: HKMA Liquidity Drain
                    Text(
                        text = "HKMA Aggregate Balance Drain: ${state.digitalTwinLiquidityDrainPct.toInt()}%",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextWhite)
                    )
                    Slider(
                        value = state.digitalTwinLiquidityDrainPct.toFloat(),
                        onValueChange = { onUpdateShocks(null, it.toDouble(), null) },
                        valueRange = 0f..75f,
                        steps = 14,
                        colors = SliderDefaults.colors(thumbColor = TerminalRose, activeTrackColor = TerminalRose)
                    )
                }
            }
        }

        // [2] Node Flow Graph Cards
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalCardBg),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "MONETARY & INTERBANK TRANSMISSION CHAIN",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    state.digitalTwinNodes.forEach { node ->
                        Surface(
                            color = if (node.isStressed) TerminalRose.copy(alpha = 0.12f) else TerminalCardAlt,
                            shape = RoundedCornerShape(4.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (node.isStressed) TerminalRose.copy(alpha = 0.5f) else TerminalBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.5f)) {
                                    Text(
                                        text = node.label,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = TextWhite
                                        )
                                    )
                                    Text(
                                        text = "Category: ${node.category}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 9.sp)
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1.2f),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = node.shockedValue,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = if (node.isStressed) TerminalRose else TerminalEmerald
                                            )
                                        )
                                        Text(
                                            text = "Δ ${node.deltaText} (Base: ${node.baseValue})",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = TextMuted,
                                                fontSize = 9.sp
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
