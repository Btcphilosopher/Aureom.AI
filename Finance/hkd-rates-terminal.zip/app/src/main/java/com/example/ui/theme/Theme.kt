package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TerminalColorScheme = darkColorScheme(
    primary = TerminalBlue,
    onPrimary = Color.Black,
    primaryContainer = TerminalCardAlt,
    onPrimaryContainer = TerminalBlue,
    secondary = TerminalPurple,
    onSecondary = Color.Black,
    secondaryContainer = TerminalCardBg,
    onSecondaryContainer = TerminalPurple,
    tertiary = TerminalEmerald,
    onTertiary = Color.Black,
    tertiaryContainer = TerminalCardBg,
    onTertiaryContainer = TerminalEmerald,
    background = TerminalBg,
    onBackground = TextWhite,
    surface = TerminalCardBg,
    onSurface = TextWhite,
    surfaceVariant = TerminalCardAlt,
    onSurfaceVariant = TextMuted,
    outline = TerminalBorderBright,
    outlineVariant = TerminalBorder,
    error = TerminalRose,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Preserve high-contrast institutional dark theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
