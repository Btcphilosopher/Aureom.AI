package com.example.engine

import com.example.data.model.DigitalTwinNode
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

object DigitalTwinEngine {

    fun simulateTransmission(
        usRateShiftBp: Double = 0.0,
        hkmaLiquidityDrainPct: Double = 0.0,
        usdHkdPegPressureBp: Double = 0.0
    ): List<DigitalTwinNode> {
        // Base values
        val baseUsSofr = 4.38
        val baseUsdHkd = 7.7785
        val baseAggBalBn = 44.8
        val baseHonia = 2.7050
        val baseHibor3m = 3.26875
        val baseBankNim = 1.78
        val baseCorpDebtInterestM = 22.34
        val baseSwapPvM = 8.45

        // Transmission math
        val shockedUsSofr = baseUsSofr + (usRateShiftBp / 100.0)

        // If US rates rise, capital flows to USD, USD/HKD pushes towards weak side 7.85
        val spotDelta = (usRateShiftBp * 0.0002) + (usdHkdPegPressureBp * 0.0001)
        val shockedUsdHkd = min(7.8500, max(7.7500, baseUsdHkd + spotDelta))

        // When USD/HKD hits or nears 7.8500, HKMA buys HKD / sells USD, draining aggregate balance
        val drainFromFx = if (shockedUsdHkd > 7.8200) (shockedUsdHkd - 7.8200) * 800.0 else 0.0
        val shockedAggBal = max(15.0, baseAggBalBn * (1.0 - hkmaLiquidityDrainPct / 100.0) - drainFromFx)

        // Lower aggregate balance directly drives up HONIA and short HIBOR
        val aggBalTighteningBp = (baseAggBalBn - shockedAggBal) * 1.8
        val shockedHonia = baseHonia + (usRateShiftBp * 0.85 / 100.0) + (aggBalTighteningBp / 10000.0)
        val shockedHibor3m = baseHibor3m + (usRateShiftBp * 0.95 / 100.0) + (aggBalTighteningBp * 1.25 / 10000.0)

        // Bank NIM changes with HIBOR elasticity
        val nimDelta = ((shockedHibor3m - baseHibor3m) * 0.12)
        val shockedBankNim = baseBankNim + nimDelta

        // Corporate debt expense (500M floating facility at HIBOR + 120bp)
        val allInBorrowing = (shockedHibor3m + 1.20) / 100.0
        val shockedCorpDebtInterestM = (500.0 * allInBorrowing)

        // Swap PV move on DV01 ~ 184,200 HKD/bp
        val hiborDeltaBp = (shockedHibor3m - baseHibor3m) * 100.0
        val shockedSwapPvM = baseSwapPvM + (hiborDeltaBp * 0.1842)

        return listOf(
            DigitalTwinNode(
                id = "NODE_US_RATES",
                label = "US Fed Funds / SOFR",
                category = "MONETARY",
                baseValue = "${FixingEngine.roundToPrecision(baseUsSofr, 2)}%",
                shockedValue = "${FixingEngine.roundToPrecision(shockedUsSofr, 2)}%",
                deltaText = "${if (usRateShiftBp >= 0) "+" else ""}${usRateShiftBp.toInt()} bp",
                isStressed = usRateShiftBp != 0.0
            ),
            DigitalTwinNode(
                id = "NODE_USD_HKD",
                label = "USD/HKD Spot (LERS Band 7.75-7.85)",
                category = "MONETARY",
                baseValue = String.format("%.4f", baseUsdHkd),
                shockedValue = String.format("%.4f", shockedUsdHkd),
                deltaText = "${if (spotDelta >= 0) "+" else ""}${String.format("%.4f", spotDelta)}",
                isStressed = shockedUsdHkd >= 7.8400
            ),
            DigitalTwinNode(
                id = "NODE_HKMA_BAL",
                label = "HKMA Aggregate Balance",
                category = "INTERBANK",
                baseValue = "HK$ ${FixingEngine.roundToPrecision(baseAggBalBn, 1)}B",
                shockedValue = "HK$ ${FixingEngine.roundToPrecision(shockedAggBal, 1)}B",
                deltaText = "${FixingEngine.roundToPrecision(shockedAggBal - baseAggBalBn, 1)}B",
                isStressed = shockedAggBal < 30.0
            ),
            DigitalTwinNode(
                id = "NODE_HONIA",
                label = "HONIA Overnight Index",
                category = "INTERBANK",
                baseValue = "${FixingEngine.roundToPrecision(baseHonia, 4)}%",
                shockedValue = "${FixingEngine.roundToPrecision(shockedHonia, 4)}%",
                deltaText = "${if (shockedHonia >= baseHonia) "+" else ""}${round((shockedHonia - baseHonia) * 10000.0) / 100.0} bp",
                isStressed = (shockedHonia - baseHonia) > 0.4
            ),
            DigitalTwinNode(
                id = "NODE_HIBOR_3M",
                label = "HKD HIBOR 3M Fixing",
                category = "INTERBANK",
                baseValue = "${FixingEngine.roundToPrecision(baseHibor3m, 5)}%",
                shockedValue = "${FixingEngine.roundToPrecision(shockedHibor3m, 5)}%",
                deltaText = "${if (shockedHibor3m >= baseHibor3m) "+" else ""}${round((shockedHibor3m - baseHibor3m) * 10000.0) / 100.0} bp",
                isStressed = (shockedHibor3m - baseHibor3m) > 0.5
            ),
            DigitalTwinNode(
                id = "NODE_BANK_NIM",
                label = "Hong Kong Bank NIM",
                category = "TREASURY",
                baseValue = "${FixingEngine.roundToPrecision(baseBankNim, 2)}%",
                shockedValue = "${FixingEngine.roundToPrecision(shockedBankNim, 2)}%",
                deltaText = "${if (nimDelta >= 0) "+" else ""}${round(nimDelta * 100.0)} bp",
                isStressed = false
            ),
            DigitalTwinNode(
                id = "NODE_CORP_DEBT",
                label = "Corporate Debt Service (500M Facility)",
                category = "CORPORATE",
                baseValue = "HK$ ${FixingEngine.roundToPrecision(baseCorpDebtInterestM, 2)}M/yr",
                shockedValue = "HK$ ${FixingEngine.roundToPrecision(shockedCorpDebtInterestM, 2)}M/yr",
                deltaText = "${if (shockedCorpDebtInterestM >= baseCorpDebtInterestM) "+" else ""}${FixingEngine.roundToPrecision(shockedCorpDebtInterestM - baseCorpDebtInterestM, 2)}M",
                isStressed = (shockedCorpDebtInterestM - baseCorpDebtInterestM) > 2.0
            ),
            DigitalTwinNode(
                id = "NODE_DERIV_PV",
                label = "HKD Swap & Rate Portfolio PV",
                category = "ASSET",
                baseValue = "HK$ ${FixingEngine.roundToPrecision(baseSwapPvM, 2)}M",
                shockedValue = "HK$ ${FixingEngine.roundToPrecision(shockedSwapPvM, 2)}M",
                deltaText = "${if (shockedSwapPvM >= baseSwapPvM) "+" else ""}${FixingEngine.roundToPrecision(shockedSwapPvM - baseSwapPvM, 2)}M",
                isStressed = false
            )
        )
    }
}
