package com.example.engine

import com.example.data.model.*
import kotlin.math.pow
import kotlin.math.round

object HoniaEngine {

    fun calculateCompoundedRate(
        dailyRates: List<Double>, // daily rates in percent, e.g. 2.70 for 2.70%
        daysPerPeriod: List<Int> = List(dailyRates.size) { 1 }
    ): Double {
        if (dailyRates.isEmpty()) return 0.0
        var compoundedProduct = 1.0
        var totalDays = 0

        for (i in dailyRates.indices) {
            val r = dailyRates[i] / 100.0
            val d = daysPerPeriod[i]
            compoundedProduct *= (1.0 + r * (d.toDouble() / 365.0))
            totalDays += d
        }

        if (totalDays == 0) return 0.0
        val annualized = (compoundedProduct - 1.0) * (365.0 / totalDays.toDouble()) * 100.0
        return FixingEngine.roundToPrecision(annualized, 5)
    }

    fun generateCompoundedTenors(baseHoniaOvernight: Double): List<CompoundedHonia> {
        // Daily rate series simulation for standard institutional tenors
        return listOf(
            CompoundedHonia(
                periodLabel = "HONIA 1W (7D Comp)",
                tenorDays = 7,
                compoundedRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.015, 5),
                simpleAverageRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.014, 5)
            ),
            CompoundedHonia(
                periodLabel = "HONIA 1M (30D Comp)",
                tenorDays = 30,
                compoundedRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.045, 5),
                simpleAverageRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.043, 5)
            ),
            CompoundedHonia(
                periodLabel = "HONIA 3M (90D Comp)",
                tenorDays = 90,
                compoundedRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.125, 5),
                simpleAverageRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.120, 5)
            ),
            CompoundedHonia(
                periodLabel = "HONIA 6M (180D Comp)",
                tenorDays = 180,
                compoundedRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.285, 5),
                simpleAverageRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.278, 5)
            ),
            CompoundedHonia(
                periodLabel = "HONIA 12M (365D Comp)",
                tenorDays = 365,
                compoundedRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.540, 5),
                simpleAverageRate = FixingEngine.roundToPrecision(baseHoniaOvernight + 0.525, 5)
            )
        )
    }

    fun calculateBasis(
        hiborFixings: List<HIBORFixing>,
        compoundedHoniaList: List<CompoundedHonia>,
        overnightHonia: Double
    ): List<BasisMetric> {
        val basisMetrics = mutableListOf<BasisMetric>()

        val tenorMap = mapOf(
            Tenor.ON to overnightHonia,
            Tenor.M1 to (compoundedHoniaList.find { it.tenorDays == 30 }?.compoundedRate ?: (overnightHonia + 0.045)),
            Tenor.M3 to (compoundedHoniaList.find { it.tenorDays == 90 }?.compoundedRate ?: (overnightHonia + 0.125)),
            Tenor.M6 to (compoundedHoniaList.find { it.tenorDays == 180 }?.compoundedRate ?: (overnightHonia + 0.285)),
            Tenor.M12 to (compoundedHoniaList.find { it.tenorDays == 365 }?.compoundedRate ?: (overnightHonia + 0.540))
        )

        for (tenor in listOf(Tenor.ON, Tenor.M1, Tenor.M3, Tenor.M6, Tenor.M12)) {
            val hibor = hiborFixings.find { it.tenor == tenor }?.rate ?: (overnightHonia + 0.2)
            val honiaComp = tenorMap[tenor] ?: overnightHonia
            val spreadBp = round((hibor - honiaComp) * 10000.0) / 100.0

            val regime = when {
                spreadBp > 55.0 -> BasisRegime.FUNDING_PRESSURE
                spreadBp < 10.0 -> BasisRegime.LIQUIDITY_SURPLUS
                spreadBp in 15.0..40.0 -> BasisRegime.NORMAL
                else -> BasisRegime.NORMAL
            }

            val percentile = when (tenor) {
                Tenor.ON -> 42.0
                Tenor.M1 -> 58.0
                Tenor.M3 -> 68.5
                Tenor.M6 -> 74.0
                Tenor.M12 -> 81.2
                else -> 50.0
            }

            val zscore = when (tenor) {
                Tenor.ON -> -0.22
                Tenor.M1 -> 0.45
                Tenor.M3 -> 0.95
                Tenor.M6 -> 1.15
                Tenor.M12 -> 1.48
                else -> 0.0
            }

            basisMetrics.add(
                BasisMetric(
                    tenor = tenor,
                    hiborRate = hibor,
                    honiaRate = honiaComp,
                    basisBp = spreadBp,
                    change1dBp = 0.8,
                    percentile5y = percentile,
                    zscore1y = zscore,
                    rollingVolAnnualized = 8.5,
                    regime = regime
                )
            )
        }

        return basisMetrics
    }
}
