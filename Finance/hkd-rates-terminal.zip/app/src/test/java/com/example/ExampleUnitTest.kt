package com.example

import com.example.data.model.*
import com.example.engine.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class ExampleUnitTest {

    @Test
    fun testDayCountCalculations() {
        val d1 = LocalDate.of(2026, 1, 1)
        val d2 = LocalDate.of(2026, 4, 1) // 90 days
        val tau365 = DayCountEngine.calculateDayFraction(d1, d2, DayCountConvention.ACT_365F)
        val tau360 = DayCountEngine.calculateDayFraction(d1, d2, DayCountConvention.ACT_360)

        assertEquals(90.0 / 365.0, tau365, 0.0001)
        assertEquals(90.0 / 360.0, tau360, 0.0001)
    }

    @Test
    fun testHiborFixingCalculationAndTrimming() {
        val quotes = listOf(
            2.50, 2.55, 2.60, // Low 3
            3.00, 3.05, 3.10, 3.15, 3.20, 3.25, 3.30, 3.35, 3.40, 3.45, 3.50, 3.55, 3.60, 3.65, // 14 middle
            4.10, 4.20, 4.30  // High 3
        ).mapIndexed { idx, q ->
            ContributorQuote(
                bankId = "BANK_$idx",
                bankName = "Bank $idx",
                fixingDate = "2026-10-05",
                tenor = Tenor.M3,
                quote = q,
                submissionTimestamp = "2026-10-05 10:59:00",
                status = QuoteStatus.RECEIVED
            )
        }

        val fixing = FixingEngine.calculateFixing(
            fixingDate = "2026-10-05",
            tenor = Tenor.M3,
            rawQuotes = quotes,
            previousRate = 3.30000
        )

        assertEquals(20, fixing.quoteCount)
        assertEquals(3, fixing.highQuotesExcluded)
        assertEquals(3, fixing.lowQuotesExcluded)

        // Middle 14 average: sum(3.00..3.65) = 46.55 / 14 = 3.32500
        assertEquals(3.32500, fixing.rate, 0.00001)
        assertTrue(fixing.calculationAuditHash.isNotEmpty())
    }

    @Test
    fun testCompoundedHoniaCalculation() {
        val dailyRates = listOf(2.70, 2.72, 2.71, 2.70, 2.73, 2.71, 2.72)
        val compRate = HoniaEngine.calculateCompoundedRate(dailyRates)
        assertTrue(compRate > 2.70 && compRate < 2.74)
    }

    @Test
    fun testCurveCalibrationAndForwardRate() {
        val anchorRates = mapOf(
            Tenor.ON to 2.72393,
            Tenor.M1 to 2.94220,
            Tenor.M3 to 3.26875,
            Tenor.M6 to 3.52964,
            Tenor.M12 to 4.01351,
            Tenor.Y2 to 4.2250,
            Tenor.Y5 to 4.5850
        )

        val curve = CurveEngine.calibrateCurve(CurveType.HIBOR_PROJECTION, "2026-10-05", anchorRates)
        assertNotNull(curve)
        assertEquals(10, curve.nodes.size)

        val fwd3m6m = CurveEngine.calculateForwardRate(0.25, 0.5, curve)
        assertTrue("Forward rate should be positive", fwd3m6m > 3.0)
    }

    @Test
    fun testSwapValuationAndDv01() {
        val curve = CurveEngine.calibrateCurve(CurveType.HIBOR_PROJECTION, "2026-10-05", mapOf(Tenor.M3 to 3.26875))
        val swap = SwapTrade(
            tradeId = "TEST_SWAP",
            swapType = SwapType.HIBOR_IRS_3M,
            notionalHkd = 100_000_000.0,
            effectiveDate = "2026-10-05",
            maturityYears = 5.0,
            fixedRatePct = 3.45,
            payerReceiver = PayerReceiver.PAY_FIXED
        )

        val valn = PricingEngine.priceSwap(swap, curve, curve)
        assertNotNull(valn)
        assertTrue("DV01 must be greater than 0 for Pay Fixed", valn.dv01Hkd > 0)
        assertEquals(20 * 2, valn.cashflows.size) // 20 fixed + 20 float periods
    }
}
