package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.BankRepository
import com.example.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class TransferTabUiState(
    val selectedTab: Int = 0, // 0 = Internal, 1 = Bill Pay, 2 = Redwood Pay (P2P)
    
    // Internal Transfer Form
    val fromAccountId: String = "acc_checking",
    val toAccountId: String = "acc_savings",
    val transferAmountText: String = "",
    val transferMemo: String = "",
    val transferTiming: String = "Immediate", // Immediate vs Scheduled
    
    // Bill Pay Form
    val selectedPayeeId: String = "p_01",
    val billSourceAccountId: String = "acc_checking",
    val billAmountText: String = "",
    val billDueDateText: String = "",
    
    // P2P Form
    val p2pRecipientName: String = "",
    val p2pRecipientContact: String = "",
    val p2pSourceAccountId: String = "acc_checking",
    val p2pAmountText: String = "",
    val p2pMemo: String = "",
    
    val isExecuting: Boolean = false,
    val errorMessage: String? = null,
    val successReference: String? = null
)

class TransfersViewModel(
    private val repository: BankRepository
) : ViewModel() {

    val accounts: StateFlow<List<Account>> = repository.getAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payees: StateFlow<List<Payee>> = repository.getPayees()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scheduledBills: StateFlow<List<ScheduledBill>> = repository.getScheduledBills()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(TransferTabUiState())
    val uiState: StateFlow<TransferTabUiState> = _uiState.asStateFlow()

    fun selectTab(tabIndex: Int) {
        _uiState.update { it.copy(selectedTab = tabIndex, errorMessage = null, successReference = null) }
    }

    // Internal Transfer handlers
    fun setFromAccount(id: String) { _uiState.update { it.copy(fromAccountId = id) } }
    fun setToAccount(id: String) { _uiState.update { it.copy(toAccountId = id) } }
    fun setTransferAmount(amount: String) { _uiState.update { it.copy(transferAmountText = amount) } }
    fun setTransferMemo(memo: String) { _uiState.update { it.copy(transferMemo = memo) } }

    fun submitInternalTransfer() {
        val state = _uiState.value
        val amount = state.transferAmountText.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid transfer amount.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isExecuting = true, errorMessage = null) }
            val result = repository.executeInternalTransfer(
                fromAccountId = state.fromAccountId,
                toAccountId = state.toAccountId,
                amount = amount,
                memo = state.transferMemo
            )

            result.onSuccess { ref ->
                _uiState.update {
                    it.copy(
                        isExecuting = false,
                        successReference = ref,
                        transferAmountText = "",
                        transferMemo = ""
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isExecuting = false, errorMessage = err.message ?: "Transfer failed") }
            }
        }
    }

    // Bill Pay handlers
    fun setSelectedPayee(payeeId: String) {
        val payee = payees.value.find { it.id == payeeId }
        _uiState.update { 
            it.copy(
                selectedPayeeId = payeeId,
                billAmountText = payee?.defaultAmount?.toString() ?: ""
            ) 
        }
    }

    fun setBillSourceAccount(id: String) { _uiState.update { it.copy(billSourceAccountId = id) } }
    fun setBillAmount(amount: String) { _uiState.update { it.copy(billAmountText = amount) } }

    fun submitBillPayment() {
        val state = _uiState.value
        val amount = state.billAmountText.toDoubleOrNull()
        val payee = payees.value.find { it.id == state.selectedPayeeId }

        if (amount == null || amount <= 0 || payee == null) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid amount and payee.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isExecuting = true, errorMessage = null) }
            val result = repository.executeBillPayment(
                payeeId = payee.id,
                payeeName = payee.name,
                sourceAccountId = state.billSourceAccountId,
                amount = amount,
                dueDate = "Today"
            )

            result.onSuccess { ref ->
                _uiState.update {
                    it.copy(
                        isExecuting = false,
                        successReference = ref,
                        billAmountText = ""
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isExecuting = false, errorMessage = err.message ?: "Bill payment failed") }
            }
        }
    }

    // P2P Pay handlers
    fun setP2pRecipientName(name: String) { _uiState.update { it.copy(p2pRecipientName = name) } }
    fun setP2pRecipientContact(contact: String) { _uiState.update { it.copy(p2pRecipientContact = contact) } }
    fun setP2pSourceAccount(id: String) { _uiState.update { it.copy(p2pSourceAccountId = id) } }
    fun setP2pAmount(amount: String) { _uiState.update { it.copy(p2pAmountText = amount) } }
    fun setP2pMemo(memo: String) { _uiState.update { it.copy(p2pMemo = memo) } }

    fun submitP2PPayment() {
        val state = _uiState.value
        val amount = state.p2pAmountText.toDoubleOrNull()

        if (state.p2pRecipientName.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter a recipient name.") }
            return
        }
        if (amount == null || amount <= 0) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid amount.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isExecuting = true, errorMessage = null) }
            val result = repository.executeP2PPayment(
                recipientName = state.p2pRecipientName,
                recipientContact = state.p2pRecipientContact,
                sourceAccountId = state.p2pSourceAccountId,
                amount = amount,
                memo = state.p2pMemo
            )

            result.onSuccess { ref ->
                _uiState.update {
                    it.copy(
                        isExecuting = false,
                        successReference = ref,
                        p2pAmountText = "",
                        p2pMemo = "",
                        p2pRecipientName = "",
                        p2pRecipientContact = ""
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isExecuting = false, errorMessage = err.message ?: "Payment failed") }
            }
        }
    }

    fun clearConfirmation() {
        _uiState.update { it.copy(successReference = null, errorMessage = null) }
    }
}
