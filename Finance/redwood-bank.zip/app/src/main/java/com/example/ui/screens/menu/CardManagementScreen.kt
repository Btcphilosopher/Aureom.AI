package com.example.ui.screens.menu

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Card
import com.example.domain.model.CardType
import com.example.ui.theme.*
import com.example.ui.viewmodel.CardsUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardManagementScreen(
    cards: List<Card>,
    state: CardsUiState,
    onBack: () -> Unit,
    onToggleLock: (String) -> Unit,
    onUpdateControls: (Card, Boolean, Boolean, Boolean, Double) -> Unit,
    onRequestReplacement: (String) -> Unit,
    onShowReplacementDialog: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Card Management") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(cards) { card ->
                var online by remember(card) { mutableStateOf(card.onlineTransactionsEnabled) }
                var international by remember(card) { mutableStateOf(card.internationalTransactionsEnabled) }
                var contactless by remember(card) { mutableStateOf(card.contactlessEnabled) }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Card Graphic Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (card.cardType == CardType.CREDIT) RedwoodSecondary
                                    else RedwoodPrimary
                                )
                                .padding(16.dp)
                        ) {
                            Column(
                                verticalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "REDWOOD BANK",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            letterSpacing = 1.sp
                                        )
                                    )
                                    Text(
                                        text = card.cardType.name,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = RedwoodGold
                                        )
                                    )
                                }

                                Text(
                                    text = card.cardNumberMasked,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 2.sp,
                                        color = Color.White
                                    )
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("CARDHOLDER", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                                        Text(card.cardHolderName, style = MaterialTheme.typography.bodySmall, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("EXPIRES", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                                        Text(card.expirationDate, style = MaterialTheme.typography.bodySmall, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Lock Toggle Button
                        Button(
                            onClick = { onToggleLock(card.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (card.isLocked) RedwoodPositiveGreen else RedwoodErrorRed
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("lock_card_button_${card.id}")
                        ) {
                            Icon(
                                imageVector = if (card.isLocked) Icons.Outlined.LockOpen else Icons.Outlined.Lock,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (card.isLocked) "Unlock Card" else "Lock Card Instantly",
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Card Usage Controls", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Online Purchases")
                            Switch(
                                checked = online,
                                onCheckedChange = {
                                    online = it
                                    onUpdateControls(card, online, international, contactless, card.dailyLimit)
                                }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("International Transactions")
                            Switch(
                                checked = international,
                                onCheckedChange = {
                                    international = it
                                    onUpdateControls(card, online, international, contactless, card.dailyLimit)
                                }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Contactless Tap & Pay")
                            Switch(
                                checked = contactless,
                                onCheckedChange = {
                                    contactless = it
                                    onUpdateControls(card, online, international, contactless, card.dailyLimit)
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = { onShowReplacementDialog(true) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Outlined.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Request Replacement Card")
                        }
                    }
                }
            }
        }
    }

    if (state.showReplacementDialog) {
        AlertDialog(
            onDismissRequest = { onShowReplacementDialog(false) },
            title = { Text("Request Replacement Card") },
            text = { Text("Confirm request for a new physical card sent to your primary address on file. Your current card will remain active until the new card is activated.") },
            confirmButton = {
                Button(
                    onClick = { onRequestReplacement("card_debit_01") },
                    colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary)
                ) {
                    Text("Confirm Request")
                }
            },
            dismissButton = {
                TextButton(onClick = { onShowReplacementDialog(false) }) {
                    Text("Cancel")
                }
            }
        )
    }
}
