package com.example.data.seed

import com.example.data.local.dao.BankDao
import com.example.data.local.entity.*
import com.example.domain.model.*

object DemoDataInitializer {

    suspend fun populateInitialData(dao: BankDao) {
        val now = System.currentTimeMillis()
        val dayMs = 86400000L

        // Accounts
        val accounts = listOf(
            AccountEntity(
                id = "acc_checking",
                name = "Everyday Checking",
                accountNumberMasked = "...4821",
                type = AccountType.CHECKING.name,
                currentBalance = 5120.50,
                availableBalance = 4850.25,
                status = AccountStatus.ACTIVE.name,
                apyOrApr = 0.05,
                creditLimit = null,
                minimumPayment = null,
                paymentDueDate = null,
                statementBalance = null
            ),
            AccountEntity(
                id = "acc_savings",
                name = "High-Yield Savings",
                accountNumberMasked = "...9012",
                type = AccountType.SAVINGS.name,
                currentBalance = 18420.00,
                availableBalance = 18420.00,
                status = AccountStatus.ACTIVE.name,
                apyOrApr = 4.25,
                creditLimit = null,
                minimumPayment = null,
                paymentDueDate = null,
                statementBalance = null
            ),
            AccountEntity(
                id = "acc_emergency",
                name = "Emergency Reserve",
                accountNumberMasked = "...3391",
                type = AccountType.SAVINGS.name,
                currentBalance = 8500.00,
                availableBalance = 8500.00,
                status = AccountStatus.ACTIVE.name,
                apyOrApr = 4.25,
                creditLimit = null,
                minimumPayment = null,
                paymentDueDate = null,
                statementBalance = null
            ),
            AccountEntity(
                id = "acc_credit",
                name = "Redwood Cash Back Visa",
                accountNumberMasked = "...9102",
                type = AccountType.CREDIT_CARD.name,
                currentBalance = 1240.80,
                availableBalance = 8759.20,
                status = AccountStatus.ACTIVE.name,
                apyOrApr = 19.99,
                creditLimit = 10000.00,
                minimumPayment = 35.00,
                paymentDueDate = "Nov 15, 2026",
                statementBalance = 1150.00
            ),
            AccountEntity(
                id = "acc_loan",
                name = "Redwood Auto Loan",
                accountNumberMasked = "...7742",
                type = AccountType.LOAN.name,
                currentBalance = 14250.00,
                availableBalance = 0.0,
                status = AccountStatus.ACTIVE.name,
                apyOrApr = 5.49,
                creditLimit = null,
                minimumPayment = 385.00,
                paymentDueDate = "Nov 01, 2026",
                statementBalance = null
            )
        )
        dao.insertAccounts(accounts)

        // Transactions
        val transactions = listOf(
            TransactionEntity(
                id = "tx_01",
                accountId = "acc_checking",
                title = "Acme Corp Payroll",
                subtitle = "Direct Deposit - Electronic Credit",
                category = TransactionCategory.INCOME.name,
                amount = 3250.00,
                timestamp = now - dayMs * 1,
                dateString = "Oct 25, 2026",
                status = TransactionStatus.POSTED.name,
                merchantName = "Acme Corp",
                referenceNumber = "REF-8839201"
            ),
            TransactionEntity(
                id = "tx_02",
                accountId = "acc_checking",
                title = "Trader Joe's #402",
                subtitle = "Groceries & Supplies",
                category = TransactionCategory.GROCERIES.name,
                amount = -124.50,
                timestamp = now - dayMs * 2,
                dateString = "Oct 24, 2026",
                status = TransactionStatus.POSTED.name,
                merchantName = "Trader Joe's",
                referenceNumber = "REF-7718293"
            ),
            TransactionEntity(
                id = "tx_03",
                accountId = "acc_checking",
                title = "Pacific Gas & Electric",
                subtitle = "Utility Bill Payment",
                category = TransactionCategory.UTILITIES.name,
                amount = -145.00,
                timestamp = now - dayMs * 3,
                dateString = "Oct 23, 2026",
                status = TransactionStatus.POSTED.name,
                merchantName = "PG&E",
                referenceNumber = "REF-5520194"
            ),
            TransactionEntity(
                id = "tx_04",
                accountId = "acc_checking",
                title = "Starbucks Reserve",
                subtitle = "Coffee & Food",
                category = TransactionCategory.DINING.name,
                amount = -6.75,
                timestamp = now - dayMs * 3,
                dateString = "Oct 23, 2026",
                status = TransactionStatus.POSTED.name,
                merchantName = "Starbucks",
                referenceNumber = "REF-1120934"
            ),
            TransactionEntity(
                id = "tx_05",
                accountId = "acc_checking",
                title = "Redwood Pay to Sarah J.",
                subtitle = "Dinner Split",
                category = TransactionCategory.P2P.name,
                amount = -45.00,
                timestamp = now - dayMs * 4,
                dateString = "Oct 22, 2026",
                status = TransactionStatus.POSTED.name,
                merchantName = "Sarah Jenkins",
                referenceNumber = "P2P-99201"
            ),
            TransactionEntity(
                id = "tx_06",
                accountId = "acc_checking",
                title = "Shell Oil Station",
                subtitle = "Gasoline Purchase",
                category = TransactionCategory.TRANSPORT.name,
                amount = -42.15,
                timestamp = now - dayMs * 0,
                dateString = "Oct 26, 2026",
                status = TransactionStatus.PENDING.name,
                merchantName = "Shell Oil",
                referenceNumber = "REF-PEND-01"
            ),
            TransactionEntity(
                id = "tx_07",
                accountId = "acc_checking",
                title = "Whole Foods Market",
                subtitle = "Pending Card Charge",
                category = TransactionCategory.GROCERIES.name,
                amount = -89.20,
                timestamp = now - dayMs * 0,
                dateString = "Oct 26, 2026",
                status = TransactionStatus.PENDING.name,
                merchantName = "Whole Foods Market",
                referenceNumber = "REF-PEND-02"
            ),
            TransactionEntity(
                id = "tx_08",
                accountId = "acc_savings",
                title = "Transfer from Checking",
                subtitle = "Monthly Savings Allocation",
                category = TransactionCategory.TRANSFER.name,
                amount = 500.00,
                timestamp = now - dayMs * 5,
                dateString = "Oct 21, 2026",
                status = TransactionStatus.POSTED.name,
                merchantName = "Internal Transfer",
                referenceNumber = "TRF-00129"
            ),
            TransactionEntity(
                id = "tx_09",
                accountId = "acc_savings",
                title = "Interest Credit",
                subtitle = "4.25% APY Monthly Interest",
                category = TransactionCategory.INCOME.name,
                amount = 62.15,
                timestamp = now - dayMs * 15,
                dateString = "Oct 11, 2026",
                status = TransactionStatus.POSTED.name,
                merchantName = "Redwood National Bank",
                referenceNumber = "INT-202610"
            ),
            TransactionEntity(
                id = "tx_10",
                accountId = "acc_credit",
                title = "Apple Store Online",
                subtitle = "Electronics & Apps",
                category = TransactionCategory.SHOPPING.name,
                amount = -129.99,
                timestamp = now - dayMs * 2,
                dateString = "Oct 24, 2026",
                status = TransactionStatus.POSTED.name,
                merchantName = "Apple Inc.",
                referenceNumber = "REF-APL-882"
            ),
            TransactionEntity(
                id = "tx_11",
                accountId = "acc_credit",
                title = "Target Department Store",
                subtitle = "Home & Goods",
                category = TransactionCategory.SHOPPING.name,
                amount = -64.99,
                timestamp = now - dayMs * 6,
                dateString = "Oct 20, 2026",
                status = TransactionStatus.POSTED.name,
                merchantName = "Target",
                referenceNumber = "REF-TGT-102"
            )
        )
        dao.insertTransactions(transactions)

        // Payees
        val payees = listOf(
            PayeeEntity("p_01", "Pacific Gas & Electric", "1009283741", "Utilities", 145.00),
            PayeeEntity("p_02", "Comcast Cable & Internet", "88291023", "Utilities", 85.00),
            PayeeEntity("p_03", "State Farm Auto Insurance", "SF-991029", "Insurance", 120.00),
            PayeeEntity("p_04", "City Water & Sanitation", "CW-402910", "Utilities", 42.00),
            PayeeEntity("p_05", "Redwood Credit Card Services", "CC-9102", "Credit Card", 150.00)
        )
        dao.insertPayees(payees)

        // Scheduled Bills
        val bills = listOf(
            ScheduledBillEntity("b_01", "p_01", "Pacific Gas & Electric", 145.00, "Nov 05, 2026", "acc_checking", "Monthly", isAutoPay = true, status = "SCHEDULED"),
            ScheduledBillEntity("b_02", "p_02", "Comcast Cable & Internet", 85.00, "Nov 12, 2026", "acc_checking", "Monthly", isAutoPay = false, status = "SCHEDULED"),
            ScheduledBillEntity("b_03", "p_03", "State Farm Auto Insurance", 120.00, "Nov 18, 2026", "acc_checking", "Monthly", isAutoPay = true, status = "SCHEDULED")
        )
        dao.insertScheduledBills(bills)

        // Check Deposits
        val deposits = listOf(
            CheckDepositEntity(
                id = "dep_01",
                accountId = "acc_checking",
                amount = 500.00,
                frontImageUri = null,
                backImageUri = null,
                timestamp = now - dayMs * 10,
                dateString = "Oct 16, 2026",
                referenceNumber = "DEP-99210",
                status = DepositStatus.COMPLETED_DEMO.name
            )
        )
        dao.insertCheckDeposits(deposits)

        // Cards
        val cards = listOf(
            CardEntity(
                id = "card_debit_01",
                accountId = "acc_checking",
                cardType = CardType.DEBIT.name,
                cardHolderName = "Johnathan R. Doe",
                cardNumberMasked = "4532 •••• •••• 4821",
                expirationDate = "09/29",
                cvvMasked = "•••",
                isLocked = false,
                dailyLimit = 2500.0,
                onlineTransactionsEnabled = true,
                internationalTransactionsEnabled = false,
                contactlessEnabled = true
            ),
            CardEntity(
                id = "card_credit_01",
                accountId = "acc_credit",
                cardType = CardType.CREDIT.name,
                cardHolderName = "Johnathan R. Doe",
                cardNumberMasked = "4102 •••• •••• 9102",
                expirationDate = "11/28",
                cvvMasked = "•••",
                isLocked = false,
                dailyLimit = 5000.0,
                onlineTransactionsEnabled = true,
                internationalTransactionsEnabled = true,
                contactlessEnabled = true
            )
        )
        dao.insertCards(cards)

        // Savings Goals
        val goals = listOf(
            SavingsGoalEntity("g_01", "Emergency Fund", 10000.0, 8500.0, "Dec 2026", "EMERGENCY"),
            SavingsGoalEntity("g_02", "Hawaii Summer Trip", 5000.0, 2800.0, "Jun 2027", "VACATION"),
            SavingsGoalEntity("g_03", "Home Down Payment", 40000.0, 15000.0, "Dec 2028", "HOME")
        )
        dao.insertSavingsGoals(goals)

        // Budgets
        val budgets = listOf(
            BudgetEntity("bg_01", TransactionCategory.GROCERIES.name, 600.0, 213.70),
            BudgetEntity("bg_02", TransactionCategory.DINING.name, 300.0, 32.65),
            BudgetEntity("bg_03", TransactionCategory.UTILITIES.name, 300.0, 272.00),
            BudgetEntity("bg_04", TransactionCategory.SHOPPING.name, 400.0, 194.98),
            BudgetEntity("bg_05", TransactionCategory.TRANSPORT.name, 250.0, 42.15)
        )
        dao.insertBudgets(budgets)

        // Notifications
        val notifications = listOf(
            NotificationEntity(
                id = "n_01",
                title = "Direct Deposit Posted",
                message = "Your payroll deposit of $3,250.00 from Acme Corp is now available in Everyday Checking.",
                timestamp = now - dayMs * 1,
                dateString = "Oct 25, 2026",
                category = "DEPOSIT",
                isRead = false,
                targetScreen = "ACCOUNTS"
            ),
            NotificationEntity(
                id = "n_02",
                title = "Upcoming Bill Reminder",
                message = "Pacific Gas & Electric bill ($145.00) is scheduled to be paid on Nov 05, 2026.",
                timestamp = now - dayMs * 2,
                dateString = "Oct 24, 2026",
                category = "BILL",
                isRead = false,
                targetScreen = "TRANSFERS"
            ),
            NotificationEntity(
                id = "n_03",
                title = "Card Transaction Alert",
                message = "An online purchase of $129.99 at Apple Store Online was approved on your Redwood Visa.",
                timestamp = now - dayMs * 2,
                dateString = "Oct 24, 2026",
                category = "SECURITY",
                isRead = true,
                targetScreen = "CARDS"
            )
        )
        dao.insertNotifications(notifications)

        // Statements
        val statements = listOf(
            StatementEntity("st_01", "acc_checking", "Everyday Checking", "September 2026", "", 4810.00, 5120.50, 4200.00, 3889.50),
            StatementEntity("st_02", "acc_checking", "Everyday Checking", "August 2026", "", 4500.00, 4810.00, 4100.00, 3790.00),
            StatementEntity("st_03", "acc_savings", "High-Yield Savings", "September 2026", "", 17920.00, 18420.00, 500.00, 0.0),
            StatementEntity("st_04", "acc_credit", "Redwood Cash Back Visa", "September 2026", "", 1150.00, 1240.80, 850.00, 940.80)
        )
        dao.insertStatements(statements)
    }

    suspend fun resetAllData(dao: BankDao) {
        dao.deleteAllAccounts()
        dao.deleteAllTransactions()
        dao.deleteAllPayees()
        dao.deleteAllScheduledBills()
        dao.deleteAllCheckDeposits()
        dao.deleteAllCards()
        dao.deleteAllSavingsGoals()
        dao.deleteAllBudgets()
        dao.deleteAllNotifications()
        dao.deleteAllStatements()

        populateInitialData(dao)
    }
}
