package com.example.data.repository

import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow

interface BankRepository {
    fun getAccounts(): Flow<List<Account>>
    suspend fun getAccountById(id: String): Account?
    
    fun getTransactions(): Flow<List<Transaction>>
    fun getTransactionsForAccount(accountId: String): Flow<List<Transaction>>
    
    fun getPayees(): Flow<List<Payee>>
    fun getScheduledBills(): Flow<List<ScheduledBill>>
    fun getCheckDeposits(): Flow<List<CheckDeposit>>
    fun getCards(): Flow<List<Card>>
    fun getSavingsGoals(): Flow<List<SavingsGoal>>
    fun getBudgets(): Flow<List<Budget>>
    fun getNotifications(): Flow<List<NotificationItem>>
    fun getStatements(): Flow<List<BankStatement>>

    suspend fun executeInternalTransfer(
        fromAccountId: String,
        toAccountId: String,
        amount: Double,
        memo: String
    ): Result<String>

    suspend fun executeBillPayment(
        payeeId: String,
        payeeName: String,
        sourceAccountId: String,
        amount: Double,
        dueDate: String
    ): Result<String>

    suspend fun executeP2PPayment(
        recipientName: String,
        recipientContact: String,
        sourceAccountId: String,
        amount: Double,
        memo: String
    ): Result<String>

    suspend fun executeCheckDeposit(
        accountId: String,
        amount: Double,
        frontImageUri: String?,
        backImageUri: String?
    ): Result<CheckDeposit>

    suspend fun toggleCardLock(cardId: String): Result<Boolean>
    
    suspend fun updateCardSettings(
        cardId: String,
        online: Boolean,
        international: Boolean,
        contactless: Boolean,
        limit: Double
    ): Result<Unit>

    suspend fun contributeToSavingsGoal(
        goalId: String,
        amount: Double,
        sourceAccountId: String
    ): Result<Unit>

    suspend fun createSavingsGoal(
        title: String,
        targetAmount: Double,
        targetDate: String,
        categoryIcon: String
    ): Result<Unit>

    suspend fun createOrUpdateBudget(
        category: TransactionCategory,
        monthlyLimit: Double
    ): Result<Unit>

    suspend fun markNotificationAsRead(id: String)
    suspend fun markAllNotificationsAsRead()

    suspend fun resetDemoData(): Result<Unit>
}
