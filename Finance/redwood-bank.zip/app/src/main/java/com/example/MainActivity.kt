package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.NavDestination
import com.example.ui.components.RedwoodBottomNav
import com.example.ui.components.RedwoodTopAppBar
import com.example.ui.screens.accounts.AccountsOverviewScreen
import com.example.ui.screens.auth.SignInScreen
import com.example.ui.screens.deposit.MobileDepositScreen
import com.example.ui.screens.menu.*
import com.example.ui.screens.plan.PlanningScreen
import com.example.ui.screens.transfers.TransferAndPayScreen
import com.example.ui.theme.RedwoodBankTheme
import com.example.ui.viewmodel.*

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val mainUiState by mainViewModel.uiState.collectAsStateWithLifecycle()

            // ViewModels
            val repository = mainViewModel.repository
            val accountsViewModel: AccountsViewModel = viewModel(factory = SimpleViewModelFactory { AccountsViewModel(repository) })
            val transfersViewModel: TransfersViewModel = viewModel(factory = SimpleViewModelFactory { TransfersViewModel(repository) })
            val depositViewModel: DepositViewModel = viewModel(factory = SimpleViewModelFactory { DepositViewModel(repository) })
            val planningViewModel: PlanningViewModel = viewModel(factory = SimpleViewModelFactory { PlanningViewModel(repository) })
            val cardsViewModel: CardsViewModel = viewModel(factory = SimpleViewModelFactory { CardsViewModel(repository) })
            val supportChatViewModel: SupportChatViewModel = viewModel()

            // Observe Toast Messages
            LaunchedEffect(mainUiState.toastMessage) {
                mainUiState.toastMessage?.let { msg ->
                    Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
                    mainViewModel.clearToast()
                }
            }

            RedwoodBankTheme(darkTheme = mainUiState.isDarkTheme) {
                if (!mainUiState.isAuthenticated) {
                    SignInScreen(
                        onSignInSuccess = { username ->
                            mainViewModel.signIn(username)
                        }
                    )
                } else {
                    var currentRoute by remember { mutableStateOf(NavDestination.Accounts.route) }
                    var activeSubScreen by remember { mutableStateOf<String?>(null) }

                    // Handle Back Press for sub-screens
                    if (activeSubScreen != null) {
                        BackHandler {
                            activeSubScreen = null
                        }
                    }

                    val accountsState by accountsViewModel.uiState.collectAsStateWithLifecycle()
                    val transfersState by transfersViewModel.uiState.collectAsStateWithLifecycle()
                    val depositState by depositViewModel.uiState.collectAsStateWithLifecycle()
                    val planningState by planningViewModel.uiState.collectAsStateWithLifecycle()
                    val cardsState by cardsViewModel.uiState.collectAsStateWithLifecycle()
                    val supportChatState by supportChatViewModel.uiState.collectAsStateWithLifecycle()

                    val notificationsList by mainViewModel.notifications.collectAsStateWithLifecycle()
                    val scheduledBillsList by transfersViewModel.scheduledBills.collectAsStateWithLifecycle()
                    val checkDepositsList by depositViewModel.checkDeposits.collectAsStateWithLifecycle()
                    val savingsGoalsList by planningViewModel.savingsGoals.collectAsStateWithLifecycle()
                    val budgetsList by planningViewModel.budgets.collectAsStateWithLifecycle()
                    val cardsList by cardsViewModel.cards.collectAsStateWithLifecycle()

                    Scaffold(
                        topBar = {
                            if (activeSubScreen == null) {
                                RedwoodTopAppBar(
                                    isMasked = mainUiState.isBalanceMasked,
                                    unreadNotifications = mainUiState.unreadNotificationCount,
                                    isDarkTheme = mainUiState.isDarkTheme,
                                    onToggleMasking = { mainViewModel.toggleBalanceMasking() },
                                    onNotificationClick = { activeSubScreen = "notifications" },
                                    onProfileClick = { activeSubScreen = "profile" },
                                    onToggleTheme = { mainViewModel.toggleTheme() }
                                )
                            }
                        },
                        bottomBar = {
                            if (activeSubScreen == null) {
                                RedwoodBottomNav(
                                    currentRoute = currentRoute,
                                    onNavigate = { route -> currentRoute = route }
                                )
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    ) { innerPadding ->
                        val screenModifier = Modifier.padding(innerPadding)

                        if (activeSubScreen != null) {
                            when (activeSubScreen) {
                                "cards" -> CardManagementScreen(
                                    cards = cardsList,
                                    state = cardsState,
                                    onBack = { activeSubScreen = null },
                                    onToggleLock = { cardsViewModel.toggleCardLock(it) },
                                    onUpdateControls = { card, online, intl, contactless, limit ->
                                        cardsViewModel.updateCardControls(card, online, intl, contactless, limit)
                                    },
                                    onRequestReplacement = { cardsViewModel.requestReplacementCard(it) },
                                    onShowReplacementDialog = { cardsViewModel.setReplacementDialogVisible(it) },
                                    modifier = screenModifier
                                )
                                "statements" -> StatementsScreen(
                                    statements = emptyList(), // or from viewmodel
                                    isMasked = mainUiState.isBalanceMasked,
                                    onBack = { activeSubScreen = null },
                                    modifier = screenModifier
                                )
                                "notifications" -> NotificationsScreen(
                                    notifications = notificationsList,
                                    onBack = { activeSubScreen = null },
                                    onMarkAsRead = { mainViewModel.markNotificationAsRead(it) },
                                    onMarkAllRead = { mainViewModel.markAllNotificationsAsRead() },
                                    modifier = screenModifier
                                )
                                "profile" -> ProfileScreen(
                                    userProfile = mainUiState.userProfile,
                                    onBack = { activeSubScreen = null },
                                    modifier = screenModifier
                                )
                                "support" -> SupportChatScreen(
                                    state = supportChatState,
                                    onBack = { activeSubScreen = null },
                                    onInputChange = { supportChatViewModel.setInputText(it) },
                                    onSendMessage = { supportChatViewModel.sendMessage(it) },
                                    modifier = screenModifier
                                )
                                "security" -> SecuritySettingsScreen(
                                    onBack = { activeSubScreen = null },
                                    modifier = screenModifier
                                )
                            }
                        } else {
                            when (currentRoute) {
                                NavDestination.Accounts.route -> AccountsOverviewScreen(
                                    state = accountsState,
                                    isMasked = mainUiState.isBalanceMasked,
                                    onResetData = { mainViewModel.resetDemoData() },
                                    onQuickActionClick = { action ->
                                        when (action) {
                                            "TRANSFER" -> {
                                                transfersViewModel.selectTab(0)
                                                currentRoute = NavDestination.Transfers.route
                                            }
                                            "BILL_PAY" -> {
                                                transfersViewModel.selectTab(1)
                                                currentRoute = NavDestination.Transfers.route
                                            }
                                            "DEPOSIT" -> currentRoute = NavDestination.Deposit.route
                                            "P2P" -> {
                                                transfersViewModel.selectTab(2)
                                                currentRoute = NavDestination.Transfers.route
                                            }
                                            "CARDS" -> activeSubScreen = "cards"
                                        }
                                    },
                                    onSearchQueryChange = { accountsViewModel.updateSearchQuery(it) },
                                    onCategorySelect = { accountsViewModel.selectCategoryFilter(it) },
                                    onAccountSelect = { accountsViewModel.selectAccount(it) },
                                    onTransactionSelect = { accountsViewModel.selectTransaction(it) },
                                    modifier = screenModifier
                                )

                                NavDestination.Transfers.route -> TransferAndPayScreen(
                                    state = transfersState,
                                    accounts = accountsState.accounts,
                                    payees = transfersViewModel.payees.collectAsStateWithLifecycle().value,
                                    scheduledBills = scheduledBillsList,
                                    isMasked = mainUiState.isBalanceMasked,
                                    onTabSelect = { transfersViewModel.selectTab(it) },
                                    onFromAccountChange = { transfersViewModel.setFromAccount(it) },
                                    onToAccountChange = { transfersViewModel.setToAccount(it) },
                                    onTransferAmountChange = { transfersViewModel.setTransferAmount(it) },
                                    onTransferMemoChange = { transfersViewModel.setTransferMemo(it) },
                                    onSubmitInternalTransfer = { transfersViewModel.submitInternalTransfer() },
                                    onSelectPayee = { transfersViewModel.setSelectedPayee(it) },
                                    onBillSourceAccountChange = { transfersViewModel.setBillSourceAccount(it) },
                                    onBillAmountChange = { transfersViewModel.setBillAmount(it) },
                                    onSubmitBillPayment = { transfersViewModel.submitBillPayment() },
                                    onP2pNameChange = { transfersViewModel.setP2pRecipientName(it) },
                                    onP2pContactChange = { transfersViewModel.setP2pRecipientContact(it) },
                                    onP2pSourceAccountChange = { transfersViewModel.setP2pSourceAccount(it) },
                                    onP2pAmountChange = { transfersViewModel.setP2pAmount(it) },
                                    onP2pMemoChange = { transfersViewModel.setP2pMemo(it) },
                                    onSubmitP2P = { transfersViewModel.submitP2PPayment() },
                                    onClearConfirmation = { transfersViewModel.clearConfirmation() },
                                    modifier = screenModifier
                                )

                                NavDestination.Deposit.route -> MobileDepositScreen(
                                    state = depositState,
                                    accounts = accountsState.accounts,
                                    deposits = checkDepositsList,
                                    isMasked = mainUiState.isBalanceMasked,
                                    onAccountSelect = { depositViewModel.setSelectedAccount(it) },
                                    onAmountChange = { depositViewModel.setAmount(it) },
                                    onCaptureFront = { depositViewModel.captureFrontCheck() },
                                    onCaptureBack = { depositViewModel.captureBackCheck() },
                                    onProceedToReview = { depositViewModel.proceedToReview() },
                                    onSubmitDeposit = { depositViewModel.submitDeposit() },
                                    onResetFlow = { depositViewModel.resetFlow() },
                                    modifier = screenModifier
                                )

                                NavDestination.Plan.route -> PlanningScreen(
                                    state = planningState,
                                    savingsGoals = savingsGoalsList,
                                    budgets = budgetsList,
                                    accounts = accountsState.accounts,
                                    isMasked = mainUiState.isBalanceMasked,
                                    onTabSelect = { planningViewModel.selectTab(it) },
                                    onOpenAddGoal = { planningViewModel.openAddGoalDialog(it) },
                                    onCreateGoal = { title, target, date, icon ->
                                        planningViewModel.createSavingsGoal(title, target, date, icon)
                                    },
                                    onContributeToGoal = { goalId, amt, sourceAcc ->
                                        planningViewModel.contributeToGoal(goalId, amt, sourceAcc)
                                    },
                                    modifier = screenModifier
                                )

                                NavDestination.Menu.route -> MenuScreen(
                                    userProfile = mainUiState.userProfile,
                                    unreadNotifications = mainUiState.unreadNotificationCount,
                                    onNavigateSubScreen = { activeSubScreen = it },
                                    onResetData = { mainViewModel.resetDemoData() },
                                    onSignOut = { mainViewModel.signOut() },
                                    modifier = screenModifier
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Simple Factory for ViewModels with BankRepository parameter
class SimpleViewModelFactory<T : androidx.lifecycle.ViewModel>(
    private val creator: () -> T
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <VM : androidx.lifecycle.ViewModel> create(modelClass: Class<VM>): VM {
        return creator() as VM
    }
}
