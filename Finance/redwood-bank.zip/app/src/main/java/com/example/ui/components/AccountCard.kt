package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Savings
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Account
import com.example.domain.model.AccountType
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun AccountCard(
    account: Account,
    isMasked: Boolean,
    onAccountClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val icon = when (account.type) {
        AccountType.CHECKING -> Icons.Outlined.AccountBalance
        AccountType.SAVINGS -> Icons.Outlined.Savings
        AccountType.CREDIT_CARD -> Icons.Outlined.CreditCard
        AccountType.LOAN -> Icons.Outlined.DirectionsCar
    }

    val formatCurrency = { amount: Double ->
        if (isMasked) "$••••••" else String.format(Locale.US, "$%,.2f", amount)
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, RedwoodBorder.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .clickable { onAccountClick(account.id) }
            .testTag("account_card_${account.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (account.type == AccountType.CREDIT_CARD) RedwoodPrimary.copy(alpha = 0.1f)
                                else RedwoodSurfaceVariant
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = account.name,
                            tint = if (account.type == AccountType.CREDIT_CARD) RedwoodPrimary else RedwoodTextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = account.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Account ${account.accountNumberMasked}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    account.apyOrApr?.let { rate ->
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (account.type == AccountType.SAVINGS) RedwoodPositiveGreen.copy(alpha = 0.1f) else RedwoodSurfaceVariant,
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Text(
                                text = if (account.type == AccountType.SAVINGS) "$rate% APY" else "$rate% APR",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (account.type == AccountType.SAVINGS) RedwoodPositiveGreen else RedwoodTextSecondary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Filled.ChevronRight,
                        contentDescription = "View Details",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = RedwoodBorder.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(12.dp))

            // Balance Display
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = when (account.type) {
                            AccountType.CREDIT_CARD -> "Current Balance"
                            AccountType.LOAN -> "Remaining Principal"
                            else -> "Available Balance"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatCurrency(
                            if (account.type == AccountType.CREDIT_CARD) account.currentBalance
                            else account.availableBalance
                        ),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 22.sp
                        ),
                        color = if (account.type == AccountType.CREDIT_CARD) RedwoodPrimary else MaterialTheme.colorScheme.onSurface
                    )
                }

                // Show Current Balance if different from Available Balance
                if (account.type == AccountType.CHECKING && account.currentBalance != account.availableBalance) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Current Balance",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = formatCurrency(account.currentBalance),
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else if (account.type == AccountType.CREDIT_CARD) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Available Credit",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = formatCurrency(account.availableBalance),
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = RedwoodPositiveGreen
                        )
                    }
                }
            }

            // Payment Due info for Credit Card / Loan
            if (account.type == AccountType.CREDIT_CARD || account.type == AccountType.LOAN) {
                account.paymentDueDate?.let { dueDate ->
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RedwoodSurfaceVariant, RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Min Payment: ${formatCurrency(account.minimumPayment ?: 0.0)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Due: $dueDate",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = RedwoodPrimary
                        )
                    }
                }
            }
        }
    }
}
