package com.example.ui.screens.menu

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.BankStatement
import com.example.ui.theme.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatementsScreen(
    statements: List<BankStatement>,
    isMasked: Boolean,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var downloadedDocId by remember { mutableStateOf<String?>(null) }

    val formatCurrency = { amount: Double ->
        if (isMasked) "$••••••" else String.format(Locale.US, "$%,.2f", amount)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Statements & Documents") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "Monthly Statements (PDF)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            items(statements) { doc ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(RedwoodPrimary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.Description, contentDescription = null, tint = RedwoodPrimary)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(doc.accountName, fontWeight = FontWeight.Bold)
                            Text(doc.statementPeriod, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Closing Balance: ${formatCurrency(doc.closingBalance)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        IconButton(onClick = { downloadedDocId = doc.id }) {
                            Icon(Icons.Outlined.Download, contentDescription = "Download Statement", tint = RedwoodPrimary)
                        }
                    }
                }
            }
        }
    }

    downloadedDocId?.let { docId ->
        AlertDialog(
            onDismissRequest = { downloadedDocId = null },
            title = { Text("Statement Downloaded") },
            text = { Text("Simulated PDF statement downloaded to device storage.") },
            confirmButton = {
                Button(
                    onClick = { downloadedDocId = null },
                    colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary)
                ) {
                    Text("OK")
                }
            }
        )
    }
}
