package com.example.ui.screens.plan

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Account
import com.example.domain.model.Budget
import com.example.domain.model.SavingsGoal
import com.example.domain.model.TransactionCategory
import com.example.ui.theme.*
import com.example.ui.viewmodel.CategorySpendItem
import com.example.ui.viewmodel.PlanningUiState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanningScreen(
    state: PlanningUiState,
    savingsGoals: List<SavingsGoal>,
    budgets: List<Budget>,
    accounts: List<Account>,
    isMasked: Boolean,
    onTabSelect: (Int) -> Unit,
    onOpenAddGoal: (Boolean) -> Unit,
    onCreateGoal: (String, Double, String, String) -> Unit,
    onContributeToGoal: (String, Double, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val formatCurrency = { amount: Double ->
        if (isMasked) "$••••••" else String.format(Locale.US, "$%,.2f", amount)
    }

    var selectedGoalForContrib by remember { mutableStateOf<SavingsGoal?>(null) }
    var contribAmountText by remember { mutableStateOf("100.00") }
    var contribSourceAccId by remember { mutableStateOf("acc_checking") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Tab Row
        ScrollableTabRow(
            selectedTabIndex = state.selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = RedwoodPrimary,
            edgePadding = 16.dp
        ) {
            Tab(
                selected = state.selectedTab == 0,
                onClick = { onTabSelect(0) },
                text = { Text("Spending & Cash Flow") },
                modifier = Modifier.testTag("plan_tab_spending")
            )
            Tab(
                selected = state.selectedTab == 1,
                onClick = { onTabSelect(1) },
                text = { Text("Budgets") },
                modifier = Modifier.testTag("plan_tab_budgets")
            )
            Tab(
                selected = state.selectedTab == 2,
                onClick = { onTabSelect(2) },
                text = { Text("Savings Goals") },
                modifier = Modifier.testTag("plan_tab_goals")
            )
            Tab(
                selected = state.selectedTab == 3,
                onClick = { onTabSelect(3) },
                text = { Text("Credit Score Insights") },
                modifier = Modifier.testTag("plan_tab_credit")
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (state.selectedTab) {
                0 -> {
                    // Spending & Cash Flow Tab
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Monthly Cash Flow", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Income", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(formatCurrency(state.monthlyIncome), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = RedwoodPositiveGreen)
                                    }
                                    Column {
                                        Text("Expenses", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(formatCurrency(state.monthlyExpenses), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = RedwoodPrimary)
                                    }
                                    Column {
                                        Text("Net Flow", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        val net = state.monthlyIncome - state.monthlyExpenses
                                        Text(formatCurrency(net), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = if (net >= 0) RedwoodPositiveGreen else RedwoodPrimary)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Text("Category Breakdown", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    items(state.categorySpends) { catItem ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = catItem.category.name.lowercase().replaceFirstChar { it.titlecase() },
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = formatCurrency(catItem.totalAmount),
                                        fontWeight = FontWeight.Bold,
                                        color = RedwoodTextPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { catItem.percentageOfTotal },
                                    color = RedwoodPrimary,
                                    trackColor = RedwoodSurfaceVariant,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = String.format(Locale.US, "%.1f%% of total monthly expenditure", catItem.percentageOfTotal * 100),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                1 -> {
                    // Budgets Tab
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Monthly Category Budgets", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    items(budgets) { budget ->
                        val ratio = (budget.currentSpend / budget.monthlyLimit).toFloat().coerceIn(0f, 1f)
                        val isOver = budget.currentSpend > budget.monthlyLimit

                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = budget.category.name.lowercase().replaceFirstChar { it.titlecase() },
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${formatCurrency(budget.currentSpend)} / ${formatCurrency(budget.monthlyLimit)}",
                                        fontWeight = FontWeight.Bold,
                                        color = if (isOver) RedwoodErrorRed else RedwoodTextPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = { ratio },
                                    color = if (isOver) RedwoodErrorRed else if (ratio > 0.85f) RedwoodWarningAmber else RedwoodPositiveGreen,
                                    trackColor = RedwoodSurfaceVariant,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(5.dp))
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (isOver) "Over limit by ${formatCurrency(budget.currentSpend - budget.monthlyLimit)}"
                                    else "Remaining: ${formatCurrency(budget.monthlyLimit - budget.currentSpend)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isOver) RedwoodErrorRed else RedwoodPositiveGreen
                                )
                            }
                        }
                    }
                }

                2 -> {
                    // Savings Goals Tab
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Your Savings Goals", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Button(
                                onClick = { onOpenAddGoal(true) },
                                colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Goal")
                            }
                        }
                    }

                    items(savingsGoals) { goal ->
                        val ratio = (goal.currentAmount / goal.targetAmount).toFloat().coerceIn(0f, 1f)

                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(RedwoodPrimary.copy(alpha = 0.1f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = when (goal.categoryIcon) {
                                                    "VACATION" -> Icons.Outlined.Flight
                                                    "HOME" -> Icons.Outlined.Home
                                                    else -> Icons.Outlined.Savings
                                                },
                                                contentDescription = null,
                                                tint = RedwoodPrimary
                                            )
                                        }

                                        Column {
                                            Text(goal.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                            Text("Target Date: ${goal.targetDate}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }

                                    Button(
                                        onClick = { selectedGoalForContrib = goal },
                                        colors = ButtonDefaults.buttonColors(containerColor = RedwoodSurfaceVariant, contentColor = RedwoodPrimary),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text("Deposit", fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Progress (${String.format(Locale.US, "%.0f%%", ratio * 100)})", style = MaterialTheme.typography.labelMedium)
                                    Text("${formatCurrency(goal.currentAmount)} / ${formatCurrency(goal.targetAmount)}", fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { ratio },
                                    color = RedwoodPrimary,
                                    trackColor = RedwoodSurfaceVariant,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(5.dp))
                                )
                            }
                        }
                    }
                }

                3 -> {
                    // Credit Score Insights Tab
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(20.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = RedwoodGold.copy(alpha = 0.2f),
                                    modifier = Modifier.padding(bottom = 8.dp)
                                ) {
                                    Text(
                                        text = "FICTIONAL DEMO CREDIT PROFILE",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                        color = RedwoodSecondary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }

                                Text(
                                    text = "${state.creditProfile.score}",
                                    style = MaterialTheme.typography.headlineLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 48.sp
                                    ),
                                    color = RedwoodPositiveGreen
                                )
                                Text(
                                    text = state.creditProfile.rating,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = RedwoodPositiveGreen
                                )
                                Text(
                                    text = "+${state.creditProfile.scoreChange} pts since last month",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(16.dp))
                                HorizontalDivider()
                                Spacer(modifier = Modifier.height(16.dp))

                                CreditFactorRow("Payment History", "${state.creditProfile.paymentHistoryPercent}% On Time", RedwoodPositiveGreen)
                                CreditFactorRow("Credit Utilization", "${state.creditProfile.creditUtilizationPercent}% (12/100)", RedwoodPositiveGreen)
                                CreditFactorRow("Average Account Age", "${state.creditProfile.averageAccountAgeYears} Years", RedwoodTextPrimary)
                                CreditFactorRow("Hard Inquiries", "${state.creditProfile.hardInquiries} Inquiry", RedwoodPositiveGreen)
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Educational Credit Tips", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    "• Keep revolving credit utilization below 30% to maintain a strong credit profile.\n" +
                                    "• On-time payments are the largest factor influencing your overall score.\n" +
                                    "• Fictional credit reporting provided for educational purposes within Redwood National Bank.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal to Deposit into Goal
    selectedGoalForContrib?.let { goal ->
        AlertDialog(
            onDismissRequest = { selectedGoalForContrib = null },
            title = { Text("Contribute to ${goal.title}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select Funding Account:")
                    AccountSelectorSimple(
                        selectedAccountId = contribSourceAccId,
                        accounts = accounts,
                        onSelect = { contribSourceAccId = it }
                    )

                    OutlinedTextField(
                        value = contribAmountText,
                        onValueChange = { contribAmountText = it },
                        label = { Text("Contribution Amount (\$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = contribAmountText.toDoubleOrNull() ?: 0.0
                        onContributeToGoal(goal.id, amt, contribSourceAccId)
                        selectedGoalForContrib = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary)
                ) {
                    Text("Deposit Funds")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedGoalForContrib = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // New Goal Dialog
    if (state.showAddGoalDialog) {
        var goalTitle by remember { mutableStateOf("") }
        var goalTarget by remember { mutableStateOf("2500.00") }
        var goalDate by remember { mutableStateOf("Dec 2027") }

        AlertDialog(
            onDismissRequest = { onOpenAddGoal(false) },
            title = { Text("Create New Savings Goal") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = goalTitle,
                        onValueChange = { goalTitle = it },
                        label = { Text("Goal Title (e.g. New Car)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = goalTarget,
                        onValueChange = { goalTarget = it },
                        label = { Text("Target Amount (\$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = goalDate,
                        onValueChange = { goalDate = it },
                        label = { Text("Target Date") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = goalTarget.toDoubleOrNull() ?: 0.0
                        onCreateGoal(goalTitle, target, goalDate, "SAVINGS")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary)
                ) {
                    Text("Create Goal")
                }
            },
            dismissButton = {
                TextButton(onClick = { onOpenAddGoal(false) }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun CreditFactorRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = valueColor)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccountSelectorSimple(
    selectedAccountId: String,
    accounts: List<Account>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedAcc = accounts.find { it.id == selectedAccountId }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selectedAcc?.let { "${it.name} (${it.accountNumberMasked})" } ?: "Select Account",
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            accounts.filter { it.type == com.example.domain.model.AccountType.CHECKING || it.type == com.example.domain.model.AccountType.SAVINGS }
                .forEach { acc ->
                    DropdownMenuItem(
                        text = { Text("${acc.name} (${acc.accountNumberMasked})") },
                        onClick = {
                            onSelect(acc.id)
                            expanded = false
                        }
                    )
                }
        }
    }
}
