package com.example.domain.model

enum class AccountType {
    CHECKING,
    SAVINGS,
    CREDIT_CARD,
    LOAN
}

enum class AccountStatus {
    ACTIVE,
    LOCKED,
    RESTRICTED
}

data class Account(
    val id: String,
    val name: String,
    val accountNumberMasked: String, // e.g. "...4821"
    val type: AccountType,
    val currentBalance: Double,
    val availableBalance: Double,
    val status: AccountStatus = AccountStatus.ACTIVE,
    val apyOrApr: Double? = null, // e.g. 4.25 for savings APY or 18.99 for credit APR
    val creditLimit: Double? = null,
    val minimumPayment: Double? = null,
    val paymentDueDate: String? = null,
    val statementBalance: Double? = null
)

enum class TransactionCategory {
    GROCERIES,
    DINING,
    HOUSING,
    UTILITIES,
    SHOPPING,
    TRANSPORT,
    HEALTHCARE,
    TRAVEL,
    ENTERTAINMENT,
    INCOME,
    TRANSFER,
    P2P,
    OTHER
}

enum class TransactionStatus {
    PENDING,
    POSTED,
    FAILED,
    CANCELLED,
    REVERSED
}

data class Transaction(
    val id: String,
    val accountId: String,
    val title: String,
    val subtitle: String? = null,
    val category: TransactionCategory,
    val amount: Double, // negative for expense, positive for income/credit
    val timestamp: Long, // Epoch ms
    val dateString: String, // e.g. "Oct 24, 2026"
    val status: TransactionStatus = TransactionStatus.POSTED,
    val merchantName: String? = null,
    val referenceNumber: String = ""
)

data class Payee(
    val id: String,
    val name: String,
    val accountNumber: String,
    val category: String,
    val defaultAmount: Double? = null
)

data class ScheduledBill(
    val id: String,
    val payeeId: String,
    val payeeName: String,
    val amount: Double,
    val dueDate: String,
    val sourceAccountId: String,
    val recurringFrequency: String, // e.g. "Monthly"
    val isAutoPay: Boolean = false,
    val status: String = "SCHEDULED" // SCHEDULED, PAID, CANCELLED
)

enum class DepositStatus {
    SUBMITTED_DEMO,
    PROCESSING_DEMO,
    COMPLETED_DEMO,
    REJECTED_DEMO
}

data class CheckDeposit(
    val id: String,
    val accountId: String,
    val amount: Double,
    val frontImageUri: String?,
    val backImageUri: String?,
    val timestamp: Long,
    val dateString: String,
    val referenceNumber: String,
    val status: DepositStatus = DepositStatus.COMPLETED_DEMO
)

enum class CardType {
    DEBIT,
    CREDIT
}

data class Card(
    val id: String,
    val accountId: String,
    val cardType: CardType,
    val cardHolderName: String,
    val cardNumberMasked: String, // e.g. "**** **** **** 9102"
    val expirationDate: String, // e.g. "08/29"
    val cvvMasked: String = "***",
    val isLocked: Boolean = false,
    val dailyLimit: Double = 2500.0,
    val onlineTransactionsEnabled: Boolean = true,
    val internationalTransactionsEnabled: Boolean = false,
    val contactlessEnabled: Boolean = true
)

data class SavingsGoal(
    val id: String,
    val title: String,
    val targetAmount: Double,
    val currentAmount: Double,
    val targetDate: String,
    val categoryIcon: String = "EMERGENCY" // EMERGENCY, VACATION, HOME, CAR
)

data class Budget(
    val id: String,
    val category: TransactionCategory,
    val monthlyLimit: Double,
    val currentSpend: Double
)

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val dateString: String,
    val category: String, // e.g. "SECURITY", "TRANSFER", "DEPOSIT", "BILL"
    val isRead: Boolean = false,
    val targetScreen: String? = null
)

data class BankStatement(
    val id: String,
    val accountId: String,
    val accountName: String,
    val statementPeriod: String, // e.g. "September 2026"
    val documentUrl: String = "",
    val openingBalance: Double,
    val closingBalance: Double,
    val totalDeposits: Double,
    val totalWithdrawals: Double
)

data class CreditProfile(
    val score: Int = 765, // Fico simulation score
    val rating: String = "Excellent",
    val scoreChange: Int = 12,
    val paymentHistoryPercent: Int = 100,
    val creditUtilizationPercent: Int = 12,
    val averageAccountAgeYears: Double = 6.4,
    val totalAccounts: Int = 5,
    val hardInquiries: Int = 1
)

data class UserProfile(
    val name: String = "Johnathan R. Doe",
    val email: String = "j.doe@example.com",
    val phone: String = "+1 (555) 234-5678",
    val address: String = "123 Redwood Forest Ave, San Francisco, CA 94102",
    val memberSince: String = "2018",
    val preferredBranch: String = "Financial District Branch #402"
)
