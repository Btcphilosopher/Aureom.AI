package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.BankRepository
import com.example.domain.model.Account
import com.example.domain.model.CheckDeposit
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DepositUiState(
    val selectedAccountId: String = "acc_checking",
    val amountText: String = "500.00",
    val frontImageCaptured: Boolean = false,
    val backImageCaptured: Boolean = false,
    val currentStep: Int = 1, // 1 = Select & Capture, 2 = Review, 3 = Confirmation
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
    val lastDepositReceipt: CheckDeposit? = null
)

class DepositViewModel(
    private val repository: BankRepository
) : ViewModel() {

    val accounts: StateFlow<List<Account>> = repository.getAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val checkDeposits: StateFlow<List<CheckDeposit>> = repository.getCheckDeposits()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(DepositUiState())
    val uiState: StateFlow<DepositUiState> = _uiState.asStateFlow()

    fun setSelectedAccount(id: String) { _uiState.update { it.copy(selectedAccountId = id) } }
    fun setAmount(amount: String) { _uiState.update { it.copy(amountText = amount) } }

    fun captureFrontCheck() {
        _uiState.update { it.copy(frontImageCaptured = true) }
    }

    fun captureBackCheck() {
        _uiState.update { it.copy(backImageCaptured = true) }
    }

    fun proceedToReview() {
        val state = _uiState.value
        val amount = state.amountText.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid check amount.") }
            return
        }
        if (!state.frontImageCaptured || !state.backImageCaptured) {
            _uiState.update { it.copy(errorMessage = "Please capture or select both front and back check images.") }
            return
        }

        _uiState.update { it.copy(currentStep = 2, errorMessage = null) }
    }

    fun submitDeposit() {
        val state = _uiState.value
        val amount = state.amountText.toDoubleOrNull() ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(isSubmitting = true, errorMessage = null) }

            val result = repository.executeCheckDeposit(
                accountId = state.selectedAccountId,
                amount = amount,
                frontImageUri = "sample_check_front",
                backImageUri = "sample_check_back"
            )

            result.onSuccess { deposit ->
                _uiState.update {
                    it.copy(
                        isSubmitting = false,
                        currentStep = 3,
                        lastDepositReceipt = deposit,
                        frontImageCaptured = false,
                        backImageCaptured = false,
                        amountText = ""
                    )
                }
            }.onFailure { err ->
                _uiState.update { it.copy(isSubmitting = false, errorMessage = err.message ?: "Deposit failed.") }
            }
        }
    }

    fun resetFlow() {
        _uiState.update {
            DepositUiState(
                selectedAccountId = it.selectedAccountId,
                amountText = "500.00"
            )
        }
    }
}
