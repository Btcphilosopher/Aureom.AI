package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.BankRepository
import com.example.domain.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class CategorySpendItem(
    val category: TransactionCategory,
    val totalAmount: Double,
    val percentageOfTotal: Float
)

data class PlanningUiState(
    val selectedTab: Int = 0, // 0 = Spending & Cash Flow, 1 = Budgets, 2 = Savings Goals, 3 = Credit Insights
    val monthlyIncome: Double = 3250.00,
    val monthlyExpenses: Double = 1240.50,
    val categorySpends: List<CategorySpendItem> = emptyList(),
    val creditProfile: CreditProfile = CreditProfile(),
    val showAddGoalDialog: Boolean = false,
    val showAddBudgetDialog: Boolean = false,
    val toastMessage: String? = null
)

class PlanningViewModel(
    private val repository: BankRepository
) : ViewModel() {

    val transactions: StateFlow<List<Transaction>> = repository.getTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savingsGoals: StateFlow<List<SavingsGoal>> = repository.getSavingsGoals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val budgets: StateFlow<List<Budget>> = repository.getBudgets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val accounts: StateFlow<List<Account>> = repository.getAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(PlanningUiState())
    val uiState: StateFlow<PlanningUiState> = combine(
        transactions,
        _uiState
    ) { txs, state ->
        val expensesList = txs.filter { it.amount < 0 && it.category != TransactionCategory.TRANSFER }
        val totalExp = expensesList.sumOf { kotlin.math.abs(it.amount) }

        val categoryGrouped = expensesList.groupBy { it.category }.map { (cat, list) ->
            val catTotal = list.sumOf { kotlin.math.abs(it.amount) }
            CategorySpendItem(
                category = cat,
                totalAmount = catTotal,
                percentageOfTotal = if (totalExp > 0) (catTotal / totalExp).toFloat() else 0f
            )
        }.sortedByDescending { it.totalAmount }

        state.copy(
            monthlyExpenses = totalExp,
            categorySpends = categoryGrouped
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PlanningUiState())

    fun selectTab(tabIndex: Int) {
        _uiState.update { it.copy(selectedTab = tabIndex) }
    }

    fun openAddGoalDialog(show: Boolean) {
        _uiState.update { it.copy(showAddGoalDialog = show) }
    }

    fun createSavingsGoal(title: String, targetAmount: Double, targetDate: String, icon: String) {
        viewModelScope.launch {
            repository.createSavingsGoal(title, targetAmount, targetDate, icon)
            _uiState.update { it.copy(showAddGoalDialog = false, toastMessage = "Savings goal created!") }
        }
    }

    fun contributeToGoal(goalId: String, amount: Double, sourceAccountId: String) {
        viewModelScope.launch {
            val result = repository.contributeToSavingsGoal(goalId, amount, sourceAccountId)
            result.onSuccess {
                _uiState.update { it.copy(toastMessage = "Contribution added successfully!") }
            }.onFailure { err ->
                _uiState.update { it.copy(toastMessage = err.message ?: "Contribution failed.") }
            }
        }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}
