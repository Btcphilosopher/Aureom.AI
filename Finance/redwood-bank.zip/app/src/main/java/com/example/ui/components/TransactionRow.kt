package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.Transaction
import com.example.domain.model.TransactionCategory
import com.example.domain.model.TransactionStatus
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun TransactionRow(
    transaction: Transaction,
    isMasked: Boolean,
    onTransactionClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val categoryIcon = when (transaction.category) {
        TransactionCategory.GROCERIES -> Icons.Outlined.ShoppingCart
        TransactionCategory.DINING -> Icons.Outlined.Restaurant
        TransactionCategory.HOUSING -> Icons.Outlined.Home
        TransactionCategory.UTILITIES -> Icons.Outlined.Bolt
        TransactionCategory.SHOPPING -> Icons.Outlined.ShoppingBag
        TransactionCategory.TRANSPORT -> Icons.Outlined.DirectionsCar
        TransactionCategory.HEALTHCARE -> Icons.Outlined.LocalHospital
        TransactionCategory.TRAVEL -> Icons.Outlined.Flight
        TransactionCategory.ENTERTAINMENT -> Icons.Outlined.Movie
        TransactionCategory.INCOME -> Icons.Outlined.AttachMoney
        TransactionCategory.TRANSFER -> Icons.Outlined.SwapHoriz
        TransactionCategory.P2P -> Icons.Outlined.Send
        TransactionCategory.OTHER -> Icons.Outlined.Receipt
    }

    val isCredit = transaction.amount > 0
    val formatAmount = { amt: Double ->
        if (isMasked) "$••••••"
        else {
            val formatted = String.format(Locale.US, "$%,.2f", kotlin.math.abs(amt))
            if (isCredit) "+$formatted" else "-$formatted"
        }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = modifier
            .fillMaxWidth()
            .clickable { onTransactionClick(transaction.id) }
            .padding(vertical = 10.dp, horizontal = 12.dp)
            .testTag("tx_row_${transaction.id}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(
                        if (isCredit) RedwoodPositiveGreen.copy(alpha = 0.12f)
                        else RedwoodSurfaceVariant
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = categoryIcon,
                    contentDescription = transaction.category.name,
                    tint = if (isCredit) RedwoodPositiveGreen else RedwoodTextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = transaction.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (transaction.status == TransactionStatus.PENDING) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = RedwoodWarningAmber.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Pending",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = RedwoodWarningAmber,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                Text(
                    text = "${transaction.dateString} • ${transaction.category.name.lowercase().replaceFirstChar { it.titlecase() }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Text(
            text = formatAmount(transaction.amount),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = if (isCredit) RedwoodPositiveGreen else MaterialTheme.colorScheme.onSurface
        )
    }
}
