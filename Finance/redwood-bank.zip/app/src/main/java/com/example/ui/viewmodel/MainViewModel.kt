package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BankDatabase
import com.example.data.repository.BankRepository
import com.example.data.repository.BankRepositoryImpl
import com.example.data.seed.DemoDataInitializer
import com.example.domain.model.NotificationItem
import com.example.domain.model.UserProfile
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class MainUiState(
    val isAuthenticated: Boolean = true, // Logged in for instant experience
    val usernameInput: String = "john.doe",
    val isBalanceMasked: Boolean = false,
    val unreadNotificationCount: Int = 0,
    val isDarkTheme: Boolean = false,
    val userProfile: UserProfile = UserProfile(),
    val isResettingData: Boolean = false,
    val toastMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = BankDatabase.getInstance(application)
    val repository: BankRepository = BankRepositoryImpl(db.bankDao())

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    val notifications: StateFlow<List<NotificationItem>> = repository.getNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Initialize fixture database if empty
        viewModelScope.launch {
            if (db.bankDao().getAccountById("acc_checking") == null) {
                DemoDataInitializer.populateInitialData(db.bankDao())
            }
        }

        // Observe notifications for unread count
        notifications.onEach { list ->
            _uiState.update { it.copy(unreadNotificationCount = list.count { n -> !n.isRead }) }
        }.launchIn(viewModelScope)
    }

    fun toggleBalanceMasking() {
        _uiState.update { it.copy(isBalanceMasked = !it.isBalanceMasked) }
    }

    fun toggleTheme() {
        _uiState.update { it.copy(isDarkTheme = !it.isDarkTheme) }
    }

    fun signIn(username: String) {
        _uiState.update { it.copy(isAuthenticated = true, usernameInput = username) }
    }

    fun signOut() {
        _uiState.update { it.copy(isAuthenticated = false) }
    }

    fun resetDemoData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isResettingData = true) }
            repository.resetDemoData()
            _uiState.update { 
                it.copy(
                    isResettingData = false, 
                    toastMessage = "Demonstration state reset to default."
                ) 
            }
        }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
        }
    }
}
