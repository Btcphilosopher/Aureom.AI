package com.example.ui.screens.deposit

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.Account
import com.example.domain.model.CheckDeposit
import com.example.domain.model.DepositStatus
import com.example.ui.theme.*
import com.example.ui.viewmodel.DepositUiState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MobileDepositScreen(
    state: DepositUiState,
    accounts: List<Account>,
    deposits: List<CheckDeposit>,
    isMasked: Boolean,
    onAccountSelect: (String) -> Unit,
    onAmountChange: (String) -> Unit,
    onCaptureFront: () -> Unit,
    onCaptureBack: () -> Unit,
    onProceedToReview: () -> Unit,
    onSubmitDeposit: () -> Unit,
    onResetFlow: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formatCurrency = { amount: Double ->
        if (isMasked) "$••••••" else String.format(Locale.US, "$%,.2f", amount)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Mobile Check Deposit",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Deposit checks safely anytime with your camera",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        state.errorMessage?.let { err ->
            item {
                Surface(
                    color = RedwoodErrorRed.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.Error, contentDescription = null, tint = RedwoodErrorRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(err, color = RedwoodErrorRed)
                    }
                }
            }
        }

        if (state.currentStep == 1 || state.currentStep == 2) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("1. Deposit Details", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("Deposit To Account", style = MaterialTheme.typography.labelMedium)
                        var expanded by remember { mutableStateOf(false) }
                        val selectedAcc = accounts.find { it.id == state.selectedAccountId }

                        ExposedDropdownMenuBox(
                            expanded = expanded,
                            onExpandedChange = { expanded = !expanded }
                        ) {
                            OutlinedTextField(
                                value = selectedAcc?.let { "${it.name} (${it.accountNumberMasked})" } ?: "Select Account",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth()
                            )

                            ExposedDropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                accounts.filter { it.type == com.example.domain.model.AccountType.CHECKING || it.type == com.example.domain.model.AccountType.SAVINGS }
                                    .forEach { acc ->
                                        DropdownMenuItem(
                                            text = { Text("${acc.name} (${acc.accountNumberMasked})") },
                                            onClick = {
                                                onAccountSelect(acc.id)
                                                expanded = false
                                            }
                                        )
                                    }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = state.amountText,
                            onValueChange = onAmountChange,
                            label = { Text("Check Amount (\$)") },
                            leadingIcon = { Text("\$", style = MaterialTheme.typography.titleMedium) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("deposit_amount_input")
                        )

                        Spacer(modifier = Modifier.height(20.dp))
                        Text("2. Check Photos", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text(
                            text = "Ensure check is laid flat on a dark background.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Front Photo Frame
                        CheckPhotoFrame(
                            title = "Front of Check",
                            isCaptured = state.frontImageCaptured,
                            imageRes = R.drawable.sample_check_front_1793011030327,
                            onCapture = onCaptureFront,
                            testTag = "capture_front_check"
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Back Photo Frame
                        CheckPhotoFrame(
                            title = "Back of Check (Endorsed)",
                            subtitle = "Must write: 'FOR MOBILE DEPOSIT ONLY AT REDWOOD NATIONAL BANK'",
                            isCaptured = state.backImageCaptured,
                            imageRes = R.drawable.sample_check_back_1793011040896,
                            onCapture = onCaptureBack,
                            testTag = "capture_back_check"
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        if (state.currentStep == 1) {
                            Button(
                                onClick = onProceedToReview,
                                colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("proceed_deposit_button")
                            ) {
                                Text("Review Deposit", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            // Step 2 Review & Submit
                            Surface(
                                color = RedwoodSurfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Confirm Deposit Details:", fontWeight = FontWeight.Bold)
                                    Text("Amount: \$${state.amountText}")
                                    Text("Account: ${selectedAcc?.name}")
                                    Text("Status: SUBMITTED — DEMO")
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = onSubmitDeposit,
                                enabled = !state.isSubmitting,
                                colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("submit_deposit_button")
                            ) {
                                if (state.isSubmitting) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                } else {
                                    Text("Confirm & Submit Deposit", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        } else if (state.currentStep == 3) {
            // Receipt Screen
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CheckCircle,
                            contentDescription = null,
                            tint = RedwoodPositiveGreen,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Check Deposit Received!",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Demo Check Processing Completed",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(16.dp))

                        state.lastDepositReceipt?.let { dep ->
                            Text("Deposit Reference: ${dep.referenceNumber}", style = MaterialTheme.typography.labelMedium)
                            Text("Amount: ${formatCurrency(dep.amount)}", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = RedwoodPrimary))
                            Text("Date: ${dep.dateString}")
                            Text("Status: COMPLETED — DEMO", color = RedwoodPositiveGreen, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = onResetFlow,
                            colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Make Another Deposit")
                        }
                    }
                }
            }
        }

        // Deposit History Section
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text("Deposit History", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        if (deposits.isEmpty()) {
            item {
                Text("No previous mobile deposits.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            items(deposits) { dep ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Mobile Check Deposit", fontWeight = FontWeight.Bold)
                            Text("${dep.dateString} • Ref: ${dep.referenceNumber}", style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatCurrency(dep.amount), fontWeight = FontWeight.Bold, color = RedwoodPositiveGreen)
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = RedwoodPositiveGreen.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = dep.status.name.replace("_", " "),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RedwoodPositiveGreen,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CheckPhotoFrame(
    title: String,
    subtitle: String? = null,
    isCaptured: Boolean,
    imageRes: Int,
    onCapture: () -> Unit,
    testTag: String
) {
    Column {
        Text(title, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
        subtitle?.let {
            Text(it, style = MaterialTheme.typography.labelSmall, color = RedwoodPrimary)
        }
        Spacer(modifier = Modifier.height(6.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isCaptured) Color.Transparent else RedwoodSurfaceVariant)
                .border(2.dp, if (isCaptured) RedwoodPositiveGreen else RedwoodBorder, RoundedCornerShape(8.dp))
                .clickable { onCapture() }
                .testTag(testTag),
            contentAlignment = Alignment.Center
        ) {
            if (isCaptured) {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.TopEnd
                ) {
                    Surface(
                        color = RedwoodPositiveGreen,
                        shape = RoundedCornerShape(bottomStart = 8.dp),
                        modifier = Modifier.padding(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Captured", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.CameraAlt, contentDescription = null, tint = RedwoodPrimary, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Tap to capture / select sample check", style = MaterialTheme.typography.labelMedium, color = RedwoodPrimary)
                }
            }
        }
    }
}
