package com.example.ui.screens.accounts

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*
import com.example.ui.components.AccountCard
import com.example.ui.components.DemoModeBanner
import com.example.ui.components.TransactionRow
import com.example.ui.theme.*
import com.example.ui.viewmodel.AccountsUiState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsOverviewScreen(
    state: AccountsUiState,
    isMasked: Boolean,
    onResetData: () -> Unit,
    onQuickActionClick: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onCategorySelect: (TransactionCategory?) -> Unit,
    onAccountSelect: (String?) -> Unit,
    onTransactionSelect: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val formatCurrency = { amount: Double ->
        if (isMasked) "$••••••" else String.format(Locale.US, "$%,.2f", amount)
    }

    val selectedAccount = state.accounts.find { it.id == state.selectedAccountId }
    val selectedTx = state.transactions.find { it.id == state.selectedTransactionId }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Top Demo Mode Banner
        item {
            DemoModeBanner(
                onResetClick = onResetData,
                modifier = Modifier.padding(16.dp)
            )
        }

        // Welcome Header
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                Text(
                    text = "Welcome back, Johnathan",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Here is your Redwood financial overview",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Total Deposits & Liabilities Summary Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Total Deposit Accounts",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatCurrency(state.totalDepositBalance),
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 30.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Includes Everyday Checking, High-Yield Savings & Emergency Reserve",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = RedwoodBorder.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Credit Card Balance",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = formatCurrency(state.totalCreditDebt),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = RedwoodPrimary
                            )
                        }

                        Text(
                            text = "Debts excluded from deposit total",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Quick Actions Shortcuts Bar
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "Quick Actions",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuickActionItem(
                        icon = Icons.Outlined.SwapHoriz,
                        label = "Transfer",
                        onClick = { onQuickActionClick("TRANSFER") }
                    )
                    QuickActionItem(
                        icon = Icons.Outlined.ReceiptLong,
                        label = "Pay Bills",
                        onClick = { onQuickActionClick("BILL_PAY") }
                    )
                    QuickActionItem(
                        icon = Icons.Outlined.CameraAlt,
                        label = "Deposit",
                        onClick = { onQuickActionClick("DEPOSIT") }
                    )
                    QuickActionItem(
                        icon = Icons.Outlined.Send,
                        label = "Send P2P",
                        onClick = { onQuickActionClick("P2P") }
                    )
                    QuickActionItem(
                        icon = Icons.Outlined.CreditCard,
                        label = "Cards",
                        onClick = { onQuickActionClick("CARDS") }
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Accounts List Section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Your Accounts (${state.accounts.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(state.accounts) { account ->
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                AccountCard(
                    account = account,
                    isMasked = isMasked,
                    onAccountClick = { onAccountSelect(it) }
                )
            }
        }

        // Recent Transactions Section Header
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Text(
                    text = "Recent Activity",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Transaction Search Bar
                OutlinedTextField(
                    value = state.searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("Search transactions, merchants, categories...") },
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (state.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(Icons.Outlined.Clear, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tx_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category Filter Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    item {
                        FilterChip(
                            selected = state.selectedCategory == null,
                            onClick = { onCategorySelect(null) },
                            label = { Text("All") }
                        )
                    }
                    items(TransactionCategory.values()) { category ->
                        FilterChip(
                            selected = state.selectedCategory == category,
                            onClick = { onCategorySelect(if (state.selectedCategory == category) null else category) },
                            label = { Text(category.name.lowercase().replaceFirstChar { it.titlecase() }) }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Transactions Feed Items
        if (state.filteredTransactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No transactions found.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(state.filteredTransactions) { transaction ->
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    TransactionRow(
                        transaction = transaction,
                        isMasked = isMasked,
                        onTransactionClick = { onTransactionSelect(it) }
                    )
                    HorizontalDivider(color = RedwoodBorder.copy(alpha = 0.3f))
                }
            }
        }
    }

    // Modal / BottomSheet for Account Detail
    if (selectedAccount != null) {
        AlertDialog(
            onDismissRequest = { onAccountSelect(null) },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.AccountBalance, contentDescription = null, tint = RedwoodPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(selectedAccount.name)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Account Number: ${selectedAccount.accountNumberMasked}")
                    Text("Type: ${selectedAccount.type.name}")
                    Text("Available Balance: ${formatCurrency(selectedAccount.availableBalance)}")
                    Text("Current Balance: ${formatCurrency(selectedAccount.currentBalance)}")
                    selectedAccount.creditLimit?.let { limit ->
                        Text("Credit Limit: ${formatCurrency(limit)}")
                    }
                    selectedAccount.paymentDueDate?.let { due ->
                        Text("Payment Due Date: $due")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = RedwoodSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Direct Deposit Routing: 121000358\nAccount #: 9812482109",
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { onAccountSelect(null) },
                    colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary)
                ) {
                    Text("Close")
                }
            }
        )
    }

    // Modal for Transaction Detail
    if (selectedTx != null) {
        AlertDialog(
            onDismissRequest = { onTransactionSelect(null) },
            title = { Text("Transaction Details") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = selectedTx.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text("Amount: ${formatCurrency(selectedTx.amount)}")
                    Text("Date: ${selectedTx.dateString}")
                    Text("Category: ${selectedTx.category.name}")
                    Text("Status: ${selectedTx.status.name}")
                    Text("Reference #: ${selectedTx.referenceNumber}")
                    selectedTx.merchantName?.let { merchant ->
                        Text("Merchant: $merchant")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { onTransactionSelect(null) }) {
                    Text("Done")
                }
            }
        )
    }
}

@Composable
private fun QuickActionItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(RedwoodPrimary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = RedwoodPrimary,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
