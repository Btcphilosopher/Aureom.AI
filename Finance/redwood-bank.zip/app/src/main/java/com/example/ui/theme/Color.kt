package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val RedwoodPrimary = Color(0xFFC62828)
val RedwoodPrimaryDark = Color(0xFF981B1E)
val RedwoodSecondary = Color(0xFF292929)
val RedwoodBackground = Color(0xFFF8F8F6)
val RedwoodSurface = Color(0xFFFFFFFF)
val RedwoodSurfaceVariant = Color(0xFFF4F4F2)
val RedwoodBorder = Color(0xFFDADDE1)
val RedwoodTextPrimary = Color(0xFF292929)
val RedwoodTextSecondary = Color(0xFF626A73)
val RedwoodPositiveGreen = Color(0xFF2E7D32)
val RedwoodWarningAmber = Color(0xFFF57F17)
val RedwoodErrorRed = Color(0xFFB71C1C)
val RedwoodGold = Color(0xFFC5A059)

// Dark Theme Colors
val RedwoodDarkBackground = Color(0xFF181818)
val RedwoodDarkSurface = Color(0xFF242424)
val RedwoodDarkSurfaceVariant = Color(0xFF2C2C2C)
val RedwoodDarkTextPrimary = Color(0xFFECECEC)
val RedwoodDarkTextSecondary = Color(0xFFA0A0A0)
val RedwoodDarkBorder = Color(0xFF383838)
