package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = RedwoodPrimary,
    onPrimary = RedwoodSurface,
    primaryContainer = RedwoodSurfaceVariant,
    onPrimaryContainer = RedwoodPrimaryDark,
    secondary = RedwoodSecondary,
    onSecondary = RedwoodSurface,
    background = RedwoodBackground,
    onBackground = RedwoodTextPrimary,
    surface = RedwoodSurface,
    onSurface = RedwoodTextPrimary,
    surfaceVariant = RedwoodSurfaceVariant,
    onSurfaceVariant = RedwoodTextSecondary,
    outline = RedwoodBorder,
    error = RedwoodErrorRed,
    onError = RedwoodSurface
)

private val DarkColorScheme = darkColorScheme(
    primary = RedwoodPrimary,
    onPrimary = RedwoodDarkTextPrimary,
    primaryContainer = RedwoodDarkSurfaceVariant,
    onPrimaryContainer = RedwoodDarkTextPrimary,
    secondary = RedwoodGold,
    onSecondary = RedwoodDarkBackground,
    background = RedwoodDarkBackground,
    onBackground = RedwoodDarkTextPrimary,
    surface = RedwoodDarkSurface,
    onSurface = RedwoodDarkTextPrimary,
    surfaceVariant = RedwoodDarkSurfaceVariant,
    onSurfaceVariant = RedwoodDarkTextSecondary,
    outline = RedwoodDarkBorder,
    error = RedwoodErrorRed,
    onError = RedwoodDarkTextPrimary
)

@Composable
fun RedwoodBankTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
