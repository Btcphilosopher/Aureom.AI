package com.example.ui.screens.menu

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.model.UserProfile
import com.example.ui.theme.*

@Composable
fun MenuScreen(
    userProfile: UserProfile,
    unreadNotifications: Int,
    onNavigateSubScreen: (String) -> Unit,
    onResetData: () -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // User Profile Header Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateSubScreen("profile") }
                    .testTag("menu_profile_item")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(RedwoodPrimary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = null,
                            tint = RedwoodPrimary,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = userProfile.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = userProfile.email,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Member since ${userProfile.memberSince}",
                            style = MaterialTheme.typography.labelSmall,
                            color = RedwoodPrimary
                        )
                    }

                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // Section 1: Services
        item {
            Text("Banking Services", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    MenuItemRow(
                        icon = Icons.Outlined.CreditCard,
                        title = "Debit & Credit Card Management",
                        subtitle = "Lock/unlock cards, set spending limits, replace card",
                        onClick = { onNavigateSubScreen("cards") },
                        testTag = "menu_cards_item"
                    )
                    HorizontalDivider(color = RedwoodBorder.copy(alpha = 0.3f))

                    MenuItemRow(
                        icon = Icons.Outlined.Description,
                        title = "Statements & Documents",
                        subtitle = "View and download monthly PDF statements",
                        onClick = { onNavigateSubScreen("statements") },
                        testTag = "menu_statements_item"
                    )
                    HorizontalDivider(color = RedwoodBorder.copy(alpha = 0.3f))

                    MenuItemRow(
                        icon = Icons.Outlined.Notifications,
                        title = "Notifications & Alerts",
                        subtitle = "Security alerts, deposit updates, bill reminders",
                        badgeCount = unreadNotifications,
                        onClick = { onNavigateSubScreen("notifications") },
                        testTag = "menu_notifications_item"
                    )
                }
            }
        }

        // Section 2: Security & Support
        item {
            Text("Security & Assistance", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    MenuItemRow(
                        icon = Icons.Outlined.SupportAgent,
                        title = "Support & Digital Assistant",
                        subtitle = "Ask questions, branch locations, FAQ, live assistant",
                        onClick = { onNavigateSubScreen("support") },
                        testTag = "menu_support_item"
                    )
                    HorizontalDivider(color = RedwoodBorder.copy(alpha = 0.3f))

                    MenuItemRow(
                        icon = Icons.Outlined.Security,
                        title = "Security & Biometrics",
                        subtitle = "Touch ID / Face ID, password & session controls",
                        onClick = { onNavigateSubScreen("security") },
                        testTag = "menu_security_item"
                    )
                }
            }
        }

        // Section 3: Prototype Controls
        item {
            Text("Demonstration Controls", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    MenuItemRow(
                        icon = Icons.Outlined.Restore,
                        title = "Reset Demonstration State",
                        subtitle = "Restore all accounts, balances, and history to fixture state",
                        iconColor = RedwoodWarningAmber,
                        onClick = onResetData,
                        testTag = "menu_reset_data_item"
                    )
                    HorizontalDivider(color = RedwoodBorder.copy(alpha = 0.3f))

                    MenuItemRow(
                        icon = Icons.Outlined.ExitToApp,
                        title = "Sign Out",
                        subtitle = "End current demonstration session",
                        iconColor = RedwoodErrorRed,
                        onClick = onSignOut,
                        testTag = "menu_sign_out_item"
                    )
                }
            }
        }
    }
}

@Composable
private fun MenuItemRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    iconColor: Color = RedwoodPrimary,
    badgeCount: Int = 0,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(iconColor.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = iconColor, modifier = Modifier.size(20.dp))
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (badgeCount > 0) {
            Surface(
                shape = CircleShape,
                color = RedwoodGold,
                contentColor = RedwoodSecondary
            ) {
                Text(
                    text = "$badgeCount",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }

        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
