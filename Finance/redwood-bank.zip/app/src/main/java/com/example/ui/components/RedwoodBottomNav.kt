package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.RedwoodPrimary

sealed class NavDestination(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    object Accounts : NavDestination("accounts", "Accounts", Icons.Filled.AccountBalance, Icons.Outlined.AccountBalance, "nav_accounts")
    object Transfers : NavDestination("transfers", "Transfer & Pay", Icons.Filled.SwapHoriz, Icons.Outlined.SwapHoriz, "nav_transfers")
    object Deposit : NavDestination("deposit", "Deposit", Icons.Filled.CameraAlt, Icons.Outlined.CameraAlt, "nav_deposit")
    object Plan : NavDestination("plan", "Plan", Icons.Filled.PieChart, Icons.Outlined.PieChart, "nav_plan")
    object Menu : NavDestination("menu", "Menu", Icons.Filled.Menu, Icons.Outlined.Menu, "nav_menu")
}

@Composable
fun RedwoodBottomNav(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        NavDestination.Accounts,
        NavDestination.Transfers,
        NavDestination.Deposit,
        NavDestination.Plan,
        NavDestination.Menu
    )

    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        tonalElevation = 8.dp,
        modifier = modifier
    ) {
        items.forEach { item ->
            val isSelected = currentRoute == item.route
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(item.route) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.title
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.labelSmall
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = RedwoodPrimary,
                    selectedTextColor = RedwoodPrimary,
                    indicatorColor = RedwoodPrimary.copy(alpha = 0.12f),
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.testTag(item.testTag)
            )
        }
    }
}
