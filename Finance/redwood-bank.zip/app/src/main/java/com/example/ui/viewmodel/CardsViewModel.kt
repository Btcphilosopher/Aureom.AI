package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.BankRepository
import com.example.domain.model.Account
import com.example.domain.model.Card
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class CardsUiState(
    val selectedCardId: String? = null,
    val showReplacementDialog: Boolean = false,
    val toastMessage: String? = null
)

class CardsViewModel(
    private val repository: BankRepository
) : ViewModel() {

    val cards: StateFlow<List<Card>> = repository.getCards()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val accounts: StateFlow<List<Account>> = repository.getAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(CardsUiState())
    val uiState: StateFlow<CardsUiState> = _uiState.asStateFlow()

    fun selectCard(cardId: String) {
        _uiState.update { it.copy(selectedCardId = cardId) }
    }

    fun toggleCardLock(cardId: String) {
        viewModelScope.launch {
            val result = repository.toggleCardLock(cardId)
            result.onSuccess { isLocked ->
                _uiState.update { 
                    it.copy(toastMessage = if (isLocked) "Card is now locked." else "Card is unlocked.") 
                }
            }
        }
    }

    fun updateCardControls(
        card: Card,
        online: Boolean,
        international: Boolean,
        contactless: Boolean,
        limit: Double
    ) {
        viewModelScope.launch {
            repository.updateCardSettings(card.id, online, international, contactless, limit)
            _uiState.update { it.copy(toastMessage = "Card preferences updated.") }
        }
    }

    fun requestReplacementCard(cardId: String) {
        viewModelScope.launch {
            _uiState.update { 
                it.copy(
                    showReplacementDialog = false,
                    toastMessage = "Replacement card request submitted. Expected in 3-5 business days."
                ) 
            }
        }
    }

    fun setReplacementDialogVisible(visible: Boolean) {
        _uiState.update { it.copy(showReplacementDialog = visible) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}
