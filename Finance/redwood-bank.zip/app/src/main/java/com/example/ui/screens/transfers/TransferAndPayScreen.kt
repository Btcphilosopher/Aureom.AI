package com.example.ui.screens.transfers

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.domain.model.Account
import com.example.domain.model.Payee
import com.example.domain.model.ScheduledBill
import com.example.ui.theme.*
import com.example.ui.viewmodel.TransferTabUiState
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferAndPayScreen(
    state: TransferTabUiState,
    accounts: List<Account>,
    payees: List<Payee>,
    scheduledBills: List<ScheduledBill>,
    isMasked: Boolean,
    onTabSelect: (Int) -> Unit,
    onFromAccountChange: (String) -> Unit,
    onToAccountChange: (String) -> Unit,
    onTransferAmountChange: (String) -> Unit,
    onTransferMemoChange: (String) -> Unit,
    onSubmitInternalTransfer: () -> Unit,
    onSelectPayee: (String) -> Unit,
    onBillSourceAccountChange: (String) -> Unit,
    onBillAmountChange: (String) -> Unit,
    onSubmitBillPayment: () -> Unit,
    onP2pNameChange: (String) -> Unit,
    onP2pContactChange: (String) -> Unit,
    onP2pSourceAccountChange: (String) -> Unit,
    onP2pAmountChange: (String) -> Unit,
    onP2pMemoChange: (String) -> Unit,
    onSubmitP2P: () -> Unit,
    onClearConfirmation: () -> Unit,
    modifier: Modifier = Modifier
) {
    val formatCurrency = { amount: Double ->
        if (isMasked) "$••••••" else String.format(Locale.US, "$%,.2f", amount)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Tab Header
        TabRow(
            selectedTabIndex = state.selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = RedwoodPrimary
        ) {
            Tab(
                selected = state.selectedTab == 0,
                onClick = { onTabSelect(0) },
                text = { Text("Transfer") },
                icon = { Icon(Icons.Outlined.SwapHoriz, contentDescription = "Internal Transfer") },
                modifier = Modifier.testTag("transfer_tab_internal")
            )
            Tab(
                selected = state.selectedTab == 1,
                onClick = { onTabSelect(1) },
                text = { Text("Pay Bills") },
                icon = { Icon(Icons.Outlined.Receipt, contentDescription = "Pay Bills") },
                modifier = Modifier.testTag("transfer_tab_bill_pay")
            )
            Tab(
                selected = state.selectedTab == 2,
                onClick = { onTabSelect(2) },
                text = { Text("Redwood Pay") },
                icon = { Icon(Icons.Outlined.Send, contentDescription = "Redwood Pay P2P") },
                modifier = Modifier.testTag("transfer_tab_p2p")
            )
        }

        // Error Banner
        state.errorMessage?.let { error ->
            Surface(
                color = RedwoodErrorRed.copy(alpha = 0.1f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.Error, contentDescription = null, tint = RedwoodErrorRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(error, color = RedwoodErrorRed, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (state.selectedTab) {
                0 -> {
                    // Internal Transfers Tab
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Internal Account Transfer",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(14.dp))

                                // Source Account Dropdown Selector
                                Text("From Account", style = MaterialTheme.typography.labelMedium)
                                AccountSelector(
                                    selectedAccountId = state.fromAccountId,
                                    accounts = accounts,
                                    isMasked = isMasked,
                                    onSelect = onFromAccountChange
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Destination Account Selector
                                Text("To Account", style = MaterialTheme.typography.labelMedium)
                                AccountSelector(
                                    selectedAccountId = state.toAccountId,
                                    accounts = accounts,
                                    isMasked = isMasked,
                                    onSelect = onToAccountChange
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Amount Input
                                OutlinedTextField(
                                    value = state.transferAmountText,
                                    onValueChange = onTransferAmountChange,
                                    label = { Text("Transfer Amount (\$)") },
                                    leadingIcon = { Text("\$", style = MaterialTheme.typography.titleMedium) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("transfer_amount_input")
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Memo Input
                                OutlinedTextField(
                                    value = state.transferMemo,
                                    onValueChange = onTransferMemoChange,
                                    label = { Text("Memo / Note (Optional)") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("transfer_memo_input")
                                )

                                Spacer(modifier = Modifier.height(20.dp))

                                Button(
                                    onClick = onSubmitInternalTransfer,
                                    enabled = !state.isExecuting,
                                    colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("submit_transfer_button")
                                ) {
                                    if (state.isExecuting) {
                                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                    } else {
                                        Text("Submit Transfer", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Bill Pay Tab
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Pay a Bill",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(14.dp))

                                Text("Select Payee", style = MaterialTheme.typography.labelMedium)
                                PayeeSelector(
                                    selectedPayeeId = state.selectedPayeeId,
                                    payees = payees,
                                    onSelect = onSelectPayee
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Text("Pay From Account", style = MaterialTheme.typography.labelMedium)
                                AccountSelector(
                                    selectedAccountId = state.billSourceAccountId,
                                    accounts = accounts,
                                    isMasked = isMasked,
                                    onSelect = onBillSourceAccountChange
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = state.billAmountText,
                                    onValueChange = onBillAmountChange,
                                    label = { Text("Payment Amount (\$)") },
                                    leadingIcon = { Text("\$", style = MaterialTheme.typography.titleMedium) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("bill_amount_input")
                                )

                                Spacer(modifier = Modifier.height(20.dp))

                                Button(
                                    onClick = onSubmitBillPayment,
                                    enabled = !state.isExecuting,
                                    colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("submit_bill_button")
                                ) {
                                    if (state.isExecuting) {
                                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                    } else {
                                        Text("Send Bill Payment", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Scheduled Bills Header
                    item {
                        Text(
                            text = "Scheduled AutoPay Bills",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    items(scheduledBills) { bill ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(14.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(bill.payeeName, fontWeight = FontWeight.Bold)
                                    Text("Due: ${bill.dueDate} • ${bill.recurringFrequency}", style = MaterialTheme.typography.bodySmall)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(formatCurrency(bill.amount), fontWeight = FontWeight.Bold, color = RedwoodPrimary)
                                    if (bill.isAutoPay) {
                                        Text("AutoPay On", style = MaterialTheme.typography.labelSmall, color = RedwoodPositiveGreen)
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Redwood Pay (P2P) Tab
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Send Money with Redwood Pay",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Instant peer-to-peer transfers (Fictional Demo Service)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = state.p2pRecipientName,
                                    onValueChange = onP2pNameChange,
                                    label = { Text("Recipient Name") },
                                    leadingIcon = { Icon(Icons.Outlined.Person, contentDescription = null) },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("p2p_name_input")
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = state.p2pRecipientContact,
                                    onValueChange = onP2pContactChange,
                                    label = { Text("Email or Phone Number") },
                                    leadingIcon = { Icon(Icons.Outlined.ContactPhone, contentDescription = null) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text("From Account", style = MaterialTheme.typography.labelMedium)
                                AccountSelector(
                                    selectedAccountId = state.p2pSourceAccountId,
                                    accounts = accounts,
                                    isMasked = isMasked,
                                    onSelect = onP2pSourceAccountChange
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = state.p2pAmountText,
                                    onValueChange = onP2pAmountChange,
                                    label = { Text("Amount (\$)") },
                                    leadingIcon = { Text("\$", style = MaterialTheme.typography.titleMedium) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("p2p_amount_input")
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = state.p2pMemo,
                                    onValueChange = onP2pMemoChange,
                                    label = { Text("What's it for? (e.g. Dinner split)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(20.dp))

                                Button(
                                    onClick = onSubmitP2P,
                                    enabled = !state.isExecuting,
                                    colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("submit_p2p_button")
                                ) {
                                    if (state.isExecuting) {
                                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                    } else {
                                        Text("Send Money Now", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Confirmation Dialog
        state.successReference?.let { ref ->
            AlertDialog(
                onDismissRequest = onClearConfirmation,
                icon = {
                    Icon(
                        imageVector = Icons.Outlined.CheckCircle,
                        contentDescription = null,
                        tint = RedwoodPositiveGreen,
                        modifier = Modifier.size(48.dp)
                    )
                },
                title = { Text("Transaction Successful") },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Your transaction has been submitted and processed.")
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Confirmation Reference:", style = MaterialTheme.typography.labelMedium)
                        Text(ref, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = RedwoodPrimary)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = onClearConfirmation,
                        colors = ButtonDefaults.buttonColors(containerColor = RedwoodPrimary)
                    ) {
                        Text("Done")
                    }
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AccountSelector(
    selectedAccountId: String,
    accounts: List<Account>,
    isMasked: Boolean,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedAcc = accounts.find { it.id == selectedAccountId }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selectedAcc?.let { "${it.name} (${it.accountNumberMasked})" } ?: "Select Account",
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            accounts.forEach { acc ->
                DropdownMenuItem(
                    text = { Text("${acc.name} (${acc.accountNumberMasked})") },
                    onClick = {
                        onSelect(acc.id)
                        expanded = false
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PayeeSelector(
    selectedPayeeId: String,
    payees: List<Payee>,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedPayee = payees.find { it.id == selectedPayeeId }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selectedPayee?.name ?: "Select Payee",
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            payees.forEach { payee ->
                DropdownMenuItem(
                    text = { Text("${payee.name} (${payee.category})") },
                    onClick = {
                        onSelect(payee.id)
                        expanded = false
                    }
                )
            }
        }
    }
}
