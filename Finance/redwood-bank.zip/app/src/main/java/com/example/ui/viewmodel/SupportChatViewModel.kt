package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String,
    val sender: String, // "USER" or "ASSISTANT"
    val text: String,
    val timestamp: String
)

data class SupportChatUiState(
    val messages: List<ChatMessage> = listOf(
        ChatMessage(
            id = "m1",
            sender = "ASSISTANT",
            text = "Hello! I'm the Redwood Digital Assistant. How can I assist with your accounts, transfers, cards, or statements today?",
            timestamp = "Just now"
        )
    ),
    val inputText: String = "",
    val isTyping: Boolean = false
)

class SupportChatViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(SupportChatUiState())
    val uiState: StateFlow<SupportChatUiState> = _uiState.asStateFlow()

    fun setInputText(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun sendMessage(promptText: String? = null) {
        val query = promptText ?: _uiState.value.inputText
        if (query.isBlank()) return

        val userMsg = ChatMessage(
            id = System.currentTimeMillis().toString(),
            sender = "USER",
            text = query,
            timestamp = "Just now"
        )

        _uiState.update {
            it.copy(
                messages = it.messages + userMsg,
                inputText = "",
                isTyping = true
            )
        }

        viewModelScope.launch {
            delay(1000) // Simulate response
            val replyText = generateBotReply(query)
            val assistantMsg = ChatMessage(
                id = (System.currentTimeMillis() + 1).toString(),
                sender = "ASSISTANT",
                text = replyText,
                timestamp = "Just now"
            )
            _uiState.update {
                it.copy(
                    messages = it.messages + assistantMsg,
                    isTyping = false
                )
            }
        }
    }

    private fun generateBotReply(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("transfer") -> "To make an internal transfer or send money via Redwood Pay, tap the 'Transfer & Pay' tab on the bottom menu. Transfers between Redwood accounts are instant!"
            q.contains("card") || q.contains("lock") || q.contains("debit") -> "You can lock your debit or credit card instantly under Menu -> Card Management. Locking your card prevents new purchases while keeping recurring bill payments active."
            q.contains("deposit") || q.contains("check") -> "To deposit a check, go to the 'Deposit' tab. You can scan or preview sample check images and confirm your deposit with immediate verification."
            q.contains("statement") || q.contains("document") -> "Your monthly statements for checking, savings, and credit cards are available under Menu -> Statements & Documents."
            q.contains("fee") || q.contains("overdraft") -> "Redwood Everyday Checking offers \$0 monthly service fees when you maintain a \$500 minimum daily balance or receive \$500+ in qualifying direct deposits."
            q.contains("hours") || q.contains("branch") -> "Our branches are open Monday - Friday 9:00 AM - 5:00 PM and Saturday 9:00 AM - 1:00 PM. Mobile banking is available 24/7!"
            else -> "Thank you for reaching out! You can view account details, make transfers, lock cards, or reset demonstration data anytime in the app. Is there a specific account or feature you'd like help with?"
        }
    }
}
