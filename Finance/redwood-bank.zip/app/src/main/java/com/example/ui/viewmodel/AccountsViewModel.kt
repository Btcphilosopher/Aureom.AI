package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.BankRepository
import com.example.domain.model.*
import kotlinx.coroutines.flow.*

data class AccountsUiState(
    val accounts: List<Account> = emptyList(),
    val totalDepositBalance: Double = 0.0,
    val totalCreditDebt: Double = 0.0,
    val transactions: List<Transaction> = emptyList(),
    val filteredTransactions: List<Transaction> = emptyList(),
    val searchQuery: String = "",
    val selectedCategory: TransactionCategory? = null,
    val selectedAccountFilterId: String? = null,
    val selectedAccountId: String? = null,
    val selectedTransactionId: String? = null,
    val isLoading: Boolean = false
)

private data class AccountFilters(
    val query: String,
    val category: TransactionCategory?,
    val filterAccId: String?,
    val selAccId: String?,
    val selTxId: String?
)

class AccountsViewModel(
    private val repository: BankRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _selectedCategory = MutableStateFlow<TransactionCategory?>(null)
    private val _selectedAccountFilterId = MutableStateFlow<String?>(null)
    private val _selectedAccountId = MutableStateFlow<String?>(null)
    private val _selectedTransactionId = MutableStateFlow<String?>(null)

    val accounts: StateFlow<List<Account>> = repository.getAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<Transaction>> = repository.getTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _filters = combine(
        _searchQuery,
        _selectedCategory,
        _selectedAccountFilterId,
        _selectedAccountId,
        _selectedTransactionId
    ) { query, category, filterAccId, selAccId, selTxId ->
        AccountFilters(query, category, filterAccId, selAccId, selTxId)
    }

    val uiState: StateFlow<AccountsUiState> = combine(
        accounts,
        transactions,
        _filters
    ) { accs, txs, filters ->

        val totalDeposits = accs
            .filter { it.type == AccountType.CHECKING || it.type == AccountType.SAVINGS }
            .sumOf { it.availableBalance }

        val totalCredit = accs
            .filter { it.type == AccountType.CREDIT_CARD }
            .sumOf { it.currentBalance }

        val filtered = txs.filter { tx ->
            val matchesQuery = filters.query.isBlank() || 
                tx.title.contains(filters.query, ignoreCase = true) ||
                (tx.merchantName?.contains(filters.query, ignoreCase = true) == true) ||
                tx.category.name.contains(filters.query, ignoreCase = true) ||
                tx.referenceNumber.contains(filters.query, ignoreCase = true)

            val matchesCategory = filters.category == null || tx.category == filters.category
            val matchesAccount = filters.filterAccId == null || tx.accountId == filters.filterAccId

            matchesQuery && matchesCategory && matchesAccount
        }

        AccountsUiState(
            accounts = accs,
            totalDepositBalance = totalDeposits,
            totalCreditDebt = totalCredit,
            transactions = txs,
            filteredTransactions = filtered,
            searchQuery = filters.query,
            selectedCategory = filters.category,
            selectedAccountFilterId = filters.filterAccId,
            selectedAccountId = filters.selAccId,
            selectedTransactionId = filters.selTxId
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AccountsUiState())

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategoryFilter(category: TransactionCategory?) {
        _selectedCategory.value = category
    }

    fun selectAccountFilter(accountId: String?) {
        _selectedAccountFilterId.value = accountId
    }

    fun selectAccount(accountId: String?) {
        _selectedAccountId.value = accountId
    }

    fun selectTransaction(transactionId: String?) {
        _selectedTransactionId.value = transactionId
    }
}
