package com.example.data.repository

import com.example.data.local.dao.BankDao
import com.example.data.local.entity.*
import com.example.data.seed.DemoDataInitializer
import com.example.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class BankRepositoryImpl(
    private val dao: BankDao
) : BankRepository {

    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.US)

    override fun getAccounts(): Flow<List<Account>> {
        return dao.getAllAccounts().map { entities -> entities.map { it.toDomain() } }
    }

    override suspend fun getAccountById(id: String): Account? {
        return dao.getAccountById(id)?.toDomain()
    }

    override fun getTransactions(): Flow<List<Transaction>> {
        return dao.getAllTransactions().map { entities -> entities.map { it.toDomain() } }
    }

    override fun getTransactionsForAccount(accountId: String): Flow<List<Transaction>> {
        return dao.getTransactionsForAccount(accountId).map { entities -> entities.map { it.toDomain() } }
    }

    override fun getPayees(): Flow<List<Payee>> {
        return dao.getAllPayees().map { entities -> entities.map { it.toDomain() } }
    }

    override fun getScheduledBills(): Flow<List<ScheduledBill>> {
        return dao.getAllScheduledBills().map { entities -> entities.map { it.toDomain() } }
    }

    override fun getCheckDeposits(): Flow<List<CheckDeposit>> {
        return dao.getAllCheckDeposits().map { entities -> entities.map { it.toDomain() } }
    }

    override fun getCards(): Flow<List<Card>> {
        return dao.getAllCards().map { entities -> entities.map { it.toDomain() } }
    }

    override fun getSavingsGoals(): Flow<List<SavingsGoal>> {
        return dao.getAllSavingsGoals().map { entities -> entities.map { it.toDomain() } }
    }

    override fun getBudgets(): Flow<List<Budget>> {
        return dao.getAllBudgets().map { entities -> entities.map { it.toDomain() } }
    }

    override fun getNotifications(): Flow<List<NotificationItem>> {
        return dao.getAllNotifications().map { entities -> entities.map { it.toDomain() } }
    }

    override fun getStatements(): Flow<List<BankStatement>> {
        return dao.getAllStatements().map { entities -> entities.map { it.toDomain() } }
    }

    override suspend fun executeInternalTransfer(
        fromAccountId: String,
        toAccountId: String,
        amount: Double,
        memo: String
    ): Result<String> {
        if (amount <= 0) return Result.failure(Exception("Transfer amount must be greater than zero."))
        if (fromAccountId == toAccountId) return Result.failure(Exception("Source and destination accounts must be different."))

        val fromAcc = dao.getAccountById(fromAccountId) ?: return Result.failure(Exception("Source account not found."))
        val toAcc = dao.getAccountById(toAccountId) ?: return Result.failure(Exception("Destination account not found."))

        // Validation for available funds
        if (fromAcc.type != AccountType.CREDIT_CARD.name && fromAcc.availableBalance < amount) {
            return Result.failure(Exception("Insufficient available funds in ${fromAcc.name}."))
        }

        val now = System.currentTimeMillis()
        val dateStr = dateFormat.format(Date(now))
        val refNum = "TRF-" + (100000..999999).random()

        // Update Source Account
        val updatedFrom = if (fromAcc.type == AccountType.CREDIT_CARD.name) {
            fromAcc.copy(
                currentBalance = fromAcc.currentBalance + amount,
                availableBalance = (fromAcc.creditLimit ?: 0.0) - (fromAcc.currentBalance + amount)
            )
        } else {
            fromAcc.copy(
                currentBalance = fromAcc.currentBalance - amount,
                availableBalance = fromAcc.availableBalance - amount
            )
        }

        // Update Destination Account
        val updatedTo = if (toAcc.type == AccountType.CREDIT_CARD.name) {
            // Paying off credit card
            toAcc.copy(
                currentBalance = (toAcc.currentBalance - amount).coerceAtLeast(0.0),
                availableBalance = (toAcc.creditLimit ?: 0.0) - (toAcc.currentBalance - amount).coerceAtLeast(0.0)
            )
        } else {
            toAcc.copy(
                currentBalance = toAcc.currentBalance + amount,
                availableBalance = toAcc.availableBalance + amount
            )
        }

        dao.updateAccount(updatedFrom)
        dao.updateAccount(updatedTo)

        // Debit Transaction
        dao.insertTransaction(
            TransactionEntity(
                id = "tx_" + UUID.randomUUID().toString().take(8),
                accountId = fromAccountId,
                title = "Transfer to ${toAcc.name}",
                subtitle = if (memo.isNotBlank()) memo else "Internal Transfer",
                category = TransactionCategory.TRANSFER.name,
                amount = -amount,
                timestamp = now,
                dateString = dateStr,
                status = TransactionStatus.POSTED.name,
                merchantName = "Redwood Transfer",
                referenceNumber = refNum
            )
        )

        // Credit Transaction
        dao.insertTransaction(
            TransactionEntity(
                id = "tx_" + UUID.randomUUID().toString().take(8),
                accountId = toAccountId,
                title = "Transfer from ${fromAcc.name}",
                subtitle = if (memo.isNotBlank()) memo else "Internal Transfer",
                category = TransactionCategory.TRANSFER.name,
                amount = amount,
                timestamp = now,
                dateString = dateStr,
                status = TransactionStatus.POSTED.name,
                merchantName = "Redwood Transfer",
                referenceNumber = refNum
            )
        )

        // Notification
        dao.insertNotification(
            NotificationEntity(
                id = "n_" + UUID.randomUUID().toString().take(8),
                title = "Transfer Confirmed",
                message = "Successfully transferred \$${String.format(Locale.US, "%.2f", amount)} from ${fromAcc.name} to ${toAcc.name}.",
                timestamp = now,
                dateString = dateStr,
                category = "TRANSFER",
                isRead = false,
                targetScreen = "ACCOUNTS"
            )
        )

        return Result.success(refNum)
    }

    override suspend fun executeBillPayment(
        payeeId: String,
        payeeName: String,
        sourceAccountId: String,
        amount: Double,
        dueDate: String
    ): Result<String> {
        if (amount <= 0) return Result.failure(Exception("Payment amount must be greater than zero."))
        val sourceAcc = dao.getAccountById(sourceAccountId) ?: return Result.failure(Exception("Source account not found."))

        if (sourceAcc.availableBalance < amount) {
            return Result.failure(Exception("Insufficient funds in ${sourceAcc.name} to complete payment."))
        }

        val now = System.currentTimeMillis()
        val dateStr = dateFormat.format(Date(now))
        val refNum = "PAY-" + (100000..999999).random()

        // Deduct balance
        val updatedAcc = sourceAcc.copy(
            currentBalance = sourceAcc.currentBalance - amount,
            availableBalance = sourceAcc.availableBalance - amount
        )
        dao.updateAccount(updatedAcc)

        // Insert Transaction
        dao.insertTransaction(
            TransactionEntity(
                id = "tx_" + UUID.randomUUID().toString().take(8),
                accountId = sourceAccountId,
                title = payeeName,
                subtitle = "Bill Payment - Ref $refNum",
                category = TransactionCategory.UTILITIES.name,
                amount = -amount,
                timestamp = now,
                dateString = dateStr,
                status = TransactionStatus.POSTED.name,
                merchantName = payeeName,
                referenceNumber = refNum
            )
        )

        // Notification
        dao.insertNotification(
            NotificationEntity(
                id = "n_" + UUID.randomUUID().toString().take(8),
                title = "Bill Payment Sent",
                message = "Payment of \$${String.format(Locale.US, "%.2f", amount)} sent to $payeeName.",
                timestamp = now,
                dateString = dateStr,
                category = "BILL",
                isRead = false,
                targetScreen = "TRANSFERS"
            )
        )

        return Result.success(refNum)
    }

    override suspend fun executeP2PPayment(
        recipientName: String,
        recipientContact: String,
        sourceAccountId: String,
        amount: Double,
        memo: String
    ): Result<String> {
        if (amount <= 0) return Result.failure(Exception("Payment amount must be greater than zero."))
        val sourceAcc = dao.getAccountById(sourceAccountId) ?: return Result.failure(Exception("Source account not found."))

        if (sourceAcc.availableBalance < amount) {
            return Result.failure(Exception("Insufficient funds in ${sourceAcc.name}."))
        }

        val now = System.currentTimeMillis()
        val dateStr = dateFormat.format(Date(now))
        val refNum = "P2P-" + (100000..999999).random()

        val updatedAcc = sourceAcc.copy(
            currentBalance = sourceAcc.currentBalance - amount,
            availableBalance = sourceAcc.availableBalance - amount
        )
        dao.updateAccount(updatedAcc)

        dao.insertTransaction(
            TransactionEntity(
                id = "tx_" + UUID.randomUUID().toString().take(8),
                accountId = sourceAccountId,
                title = "Redwood Pay to $recipientName",
                subtitle = if (memo.isNotBlank()) memo else recipientContact,
                category = TransactionCategory.P2P.name,
                amount = -amount,
                timestamp = now,
                dateString = dateStr,
                status = TransactionStatus.POSTED.name,
                merchantName = recipientName,
                referenceNumber = refNum
            )
        )

        dao.insertNotification(
            NotificationEntity(
                id = "n_" + UUID.randomUUID().toString().take(8),
                title = "Redwood Pay Sent",
                message = "Sent \$${String.format(Locale.US, "%.2f", amount)} to $recipientName.",
                timestamp = now,
                dateString = dateStr,
                category = "TRANSFER",
                isRead = false,
                targetScreen = "ACCOUNTS"
            )
        )

        return Result.success(refNum)
    }

    override suspend fun executeCheckDeposit(
        accountId: String,
        amount: Double,
        frontImageUri: String?,
        backImageUri: String?
    ): Result<CheckDeposit> {
        if (amount <= 0) return Result.failure(Exception("Deposit amount must be greater than zero."))
        val acc = dao.getAccountById(accountId) ?: return Result.failure(Exception("Target account not found."))

        val now = System.currentTimeMillis()
        val dateStr = dateFormat.format(Date(now))
        val refNum = "DEP-" + (100000..999999).random()

        val checkDeposit = CheckDeposit(
            id = "dep_" + UUID.randomUUID().toString().take(8),
            accountId = accountId,
            amount = amount,
            frontImageUri = frontImageUri,
            backImageUri = backImageUri,
            timestamp = now,
            dateString = dateStr,
            referenceNumber = refNum,
            status = DepositStatus.COMPLETED_DEMO
        )

        dao.insertCheckDeposit(CheckDepositEntity.fromDomain(checkDeposit))

        // Increase account balance
        val updatedAcc = acc.copy(
            currentBalance = acc.currentBalance + amount,
            availableBalance = acc.availableBalance + amount
        )
        dao.updateAccount(updatedAcc)

        // Transaction record
        dao.insertTransaction(
            TransactionEntity(
                id = "tx_" + UUID.randomUUID().toString().take(8),
                accountId = accountId,
                title = "Mobile Check Deposit",
                subtitle = "Ref: $refNum (DEMO)",
                category = TransactionCategory.INCOME.name,
                amount = amount,
                timestamp = now,
                dateString = dateStr,
                status = TransactionStatus.POSTED.name,
                merchantName = "Mobile Deposit",
                referenceNumber = refNum
            )
        )

        dao.insertNotification(
            NotificationEntity(
                id = "n_" + UUID.randomUUID().toString().take(8),
                title = "Mobile Deposit Complete",
                message = "Your check deposit of \$${String.format(Locale.US, "%.2f", amount)} has been processed.",
                timestamp = now,
                dateString = dateStr,
                category = "DEPOSIT",
                isRead = false,
                targetScreen = "DEPOSIT"
            )
        )

        return Result.success(checkDeposit)
    }

    override suspend fun toggleCardLock(cardId: String): Result<Boolean> {
        val cardEntity = dao.getCardById(cardId) ?: return Result.failure(Exception("Card not found."))
        val newLockState = !cardEntity.isLocked
        val updated = cardEntity.copy(isLocked = newLockState)
        dao.updateCard(updated)

        val now = System.currentTimeMillis()
        val dateStr = dateFormat.format(Date(now))
        dao.insertNotification(
            NotificationEntity(
                id = "n_" + UUID.randomUUID().toString().take(8),
                title = if (newLockState) "Card Locked" else "Card Unlocked",
                message = "Your ${cardEntity.cardNumberMasked} has been ${if (newLockState) "locked" else "unlocked"}.",
                timestamp = now,
                dateString = dateStr,
                category = "SECURITY",
                isRead = false,
                targetScreen = "CARDS"
            )
        )

        return Result.success(newLockState)
    }

    override suspend fun updateCardSettings(
        cardId: String,
        online: Boolean,
        international: Boolean,
        contactless: Boolean,
        limit: Double
    ): Result<Unit> {
        val cardEntity = dao.getCardById(cardId) ?: return Result.failure(Exception("Card not found."))
        val updated = cardEntity.copy(
            onlineTransactionsEnabled = online,
            internationalTransactionsEnabled = international,
            contactlessEnabled = contactless,
            dailyLimit = limit
        )
        dao.updateCard(updated)
        return Result.success(Unit)
    }

    override suspend fun contributeToSavingsGoal(
        goalId: String,
        amount: Double,
        sourceAccountId: String
    ): Result<Unit> {
        if (amount <= 0) return Result.failure(Exception("Amount must be greater than zero."))
        val sourceAcc = dao.getAccountById(sourceAccountId) ?: return Result.failure(Exception("Source account not found."))
        if (sourceAcc.availableBalance < amount) return Result.failure(Exception("Insufficient funds."))

        val goalsEntities = dao.getAllSavingsGoals()
        // Find goal by reading Flow synchronously or updating directly
        // We will query goals:
        val updatedAcc = sourceAcc.copy(
            currentBalance = sourceAcc.currentBalance - amount,
            availableBalance = sourceAcc.availableBalance - amount
        )
        dao.updateAccount(updatedAcc)

        val now = System.currentTimeMillis()
        val dateStr = dateFormat.format(Date(now))

        dao.insertTransaction(
            TransactionEntity(
                id = "tx_" + UUID.randomUUID().toString().take(8),
                accountId = sourceAccountId,
                title = "Savings Goal Contribution",
                subtitle = "Goal Deposit",
                category = TransactionCategory.TRANSFER.name,
                amount = -amount,
                timestamp = now,
                dateString = dateStr,
                status = TransactionStatus.POSTED.name,
                merchantName = "Redwood Savings",
                referenceNumber = "GOAL-" + (1000..9999).random()
            )
        )

        return Result.success(Unit)
    }

    override suspend fun createSavingsGoal(
        title: String,
        targetAmount: Double,
        targetDate: String,
        categoryIcon: String
    ): Result<Unit> {
        val entity = SavingsGoalEntity(
            id = "g_" + UUID.randomUUID().toString().take(8),
            title = title,
            targetAmount = targetAmount,
            currentAmount = 0.0,
            targetDate = targetDate,
            categoryIcon = categoryIcon
        )
        dao.insertSavingsGoal(entity)
        return Result.success(Unit)
    }

    override suspend fun createOrUpdateBudget(
        category: TransactionCategory,
        monthlyLimit: Double
    ): Result<Unit> {
        val entity = BudgetEntity(
            id = "bg_" + category.name.lowercase(),
            category = category.name,
            monthlyLimit = monthlyLimit,
            currentSpend = 0.0
        )
        dao.insertBudget(entity)
        return Result.success(Unit)
    }

    override suspend fun markNotificationAsRead(id: String) {
        dao.markNotificationAsRead(id)
    }

    override suspend fun markAllNotificationsAsRead() {
        dao.markAllNotificationsAsRead()
    }

    override suspend fun resetDemoData(): Result<Unit> {
        DemoDataInitializer.resetAllData(dao)
        return Result.success(Unit)
    }
}
