package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.*

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val name: String,
    val accountNumberMasked: String,
    val type: String,
    val currentBalance: Double,
    val availableBalance: Double,
    val status: String,
    val apyOrApr: Double?,
    val creditLimit: Double?,
    val minimumPayment: Double?,
    val paymentDueDate: String?,
    val statementBalance: Double?
) {
    fun toDomain() = Account(
        id = id,
        name = name,
        accountNumberMasked = accountNumberMasked,
        type = AccountType.valueOf(type),
        currentBalance = currentBalance,
        availableBalance = availableBalance,
        status = AccountStatus.valueOf(status),
        apyOrApr = apyOrApr,
        creditLimit = creditLimit,
        minimumPayment = minimumPayment,
        paymentDueDate = paymentDueDate,
        statementBalance = statementBalance
    )

    companion object {
        fun fromDomain(account: Account) = AccountEntity(
            id = account.id,
            name = account.name,
            accountNumberMasked = account.accountNumberMasked,
            type = account.type.name,
            currentBalance = account.currentBalance,
            availableBalance = account.availableBalance,
            status = account.status.name,
            apyOrApr = account.apyOrApr,
            creditLimit = account.creditLimit,
            minimumPayment = account.minimumPayment,
            paymentDueDate = account.paymentDueDate,
            statementBalance = account.statementBalance
        )
    }
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val title: String,
    val subtitle: String?,
    val category: String,
    val amount: Double,
    val timestamp: Long,
    val dateString: String,
    val status: String,
    val merchantName: String?,
    val referenceNumber: String
) {
    fun toDomain() = Transaction(
        id = id,
        accountId = accountId,
        title = title,
        subtitle = subtitle,
        category = TransactionCategory.valueOf(category),
        amount = amount,
        timestamp = timestamp,
        dateString = dateString,
        status = TransactionStatus.valueOf(status),
        merchantName = merchantName,
        referenceNumber = referenceNumber
    )

    companion object {
        fun fromDomain(tx: Transaction) = TransactionEntity(
            id = tx.id,
            accountId = tx.accountId,
            title = tx.title,
            subtitle = tx.subtitle,
            category = tx.category.name,
            amount = tx.amount,
            timestamp = tx.timestamp,
            dateString = tx.dateString,
            status = tx.status.name,
            merchantName = tx.merchantName,
            referenceNumber = tx.referenceNumber
        )
    }
}

@Entity(tableName = "payees")
data class PayeeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val accountNumber: String,
    val category: String,
    val defaultAmount: Double?
) {
    fun toDomain() = Payee(id, name, accountNumber, category, defaultAmount)
    companion object {
        fun fromDomain(p: Payee) = PayeeEntity(p.id, p.name, p.accountNumber, p.category, p.defaultAmount)
    }
}

@Entity(tableName = "scheduled_bills")
data class ScheduledBillEntity(
    @PrimaryKey val id: String,
    val payeeId: String,
    val payeeName: String,
    val amount: Double,
    val dueDate: String,
    val sourceAccountId: String,
    val recurringFrequency: String,
    val isAutoPay: Boolean,
    val status: String
) {
    fun toDomain() = ScheduledBill(id, payeeId, payeeName, amount, dueDate, sourceAccountId, recurringFrequency, isAutoPay, status)
    companion object {
        fun fromDomain(b: ScheduledBill) = ScheduledBillEntity(b.id, b.payeeId, b.payeeName, b.amount, b.dueDate, b.sourceAccountId, b.recurringFrequency, b.isAutoPay, b.status)
    }
}

@Entity(tableName = "check_deposits")
data class CheckDepositEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val amount: Double,
    val frontImageUri: String?,
    val backImageUri: String?,
    val timestamp: Long,
    val dateString: String,
    val referenceNumber: String,
    val status: String
) {
    fun toDomain() = CheckDeposit(
        id, accountId, amount, frontImageUri, backImageUri, timestamp, dateString, referenceNumber, DepositStatus.valueOf(status)
    )
    companion object {
        fun fromDomain(d: CheckDeposit) = CheckDepositEntity(
            d.id, d.accountId, d.amount, d.frontImageUri, d.backImageUri, d.timestamp, d.dateString, d.referenceNumber, d.status.name
        )
    }
}

@Entity(tableName = "cards")
data class CardEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val cardType: String,
    val cardHolderName: String,
    val cardNumberMasked: String,
    val expirationDate: String,
    val cvvMasked: String,
    val isLocked: Boolean,
    val dailyLimit: Double,
    val onlineTransactionsEnabled: Boolean,
    val internationalTransactionsEnabled: Boolean,
    val contactlessEnabled: Boolean
) {
    fun toDomain() = Card(
        id, accountId, CardType.valueOf(cardType), cardHolderName, cardNumberMasked, expirationDate, cvvMasked, isLocked, dailyLimit, onlineTransactionsEnabled, internationalTransactionsEnabled, contactlessEnabled
    )
    companion object {
        fun fromDomain(c: Card) = CardEntity(
            c.id, c.accountId, c.cardType.name, c.cardHolderName, c.cardNumberMasked, c.expirationDate, c.cvvMasked, c.isLocked, c.dailyLimit, c.onlineTransactionsEnabled, c.internationalTransactionsEnabled, c.contactlessEnabled
        )
    }
}

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey val id: String,
    val title: String,
    val targetAmount: Double,
    val currentAmount: Double,
    val targetDate: String,
    val categoryIcon: String
) {
    fun toDomain() = SavingsGoal(id, title, targetAmount, currentAmount, targetDate, categoryIcon)
    companion object {
        fun fromDomain(g: SavingsGoal) = SavingsGoalEntity(g.id, g.title, g.targetAmount, g.currentAmount, g.targetDate, g.categoryIcon)
    }
}

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val id: String,
    val category: String,
    val monthlyLimit: Double,
    val currentSpend: Double
) {
    fun toDomain() = Budget(id, TransactionCategory.valueOf(category), monthlyLimit, currentSpend)
    companion object {
        fun fromDomain(b: Budget) = BudgetEntity(b.id, b.category.name, b.monthlyLimit, b.currentSpend)
    }
}

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val dateString: String,
    val category: String,
    val isRead: Boolean,
    val targetScreen: String?
) {
    fun toDomain() = NotificationItem(id, title, message, timestamp, dateString, category, isRead, targetScreen)
    companion object {
        fun fromDomain(n: NotificationItem) = NotificationEntity(n.id, n.title, n.message, n.timestamp, n.dateString, n.category, n.isRead, n.targetScreen)
    }
}

@Entity(tableName = "statements")
data class StatementEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val accountName: String,
    val statementPeriod: String,
    val documentUrl: String,
    val openingBalance: Double,
    val closingBalance: Double,
    val totalDeposits: Double,
    val totalWithdrawals: Double
) {
    fun toDomain() = BankStatement(id, accountId, accountName, statementPeriod, documentUrl, openingBalance, closingBalance, totalDeposits, totalWithdrawals)
    companion object {
        fun fromDomain(s: BankStatement) = StatementEntity(s.id, s.accountId, s.accountName, s.statementPeriod, s.documentUrl, s.openingBalance, s.closingBalance, s.totalDeposits, s.totalWithdrawals)
    }
}
