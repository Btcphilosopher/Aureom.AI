package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.BankDatabase
import com.example.data.repository.BankRepositoryImpl
import com.example.data.seed.DemoDataInitializer
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var db: BankDatabase
    private lateinit var repository: BankRepositoryImpl

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, BankDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = BankRepositoryImpl(db.bankDao())
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun verifyAppNameResource() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Redwood Bank", appName)
    }

    @Test
    fun testInitialSeedDataAndBalanceCalculation() = runBlocking {
        DemoDataInitializer.populateInitialData(db.bankDao())

        val accounts = repository.getAccounts().first()
        assertTrue(accounts.isNotEmpty())

        val checking = accounts.find { it.id == "acc_checking" }
        assertNotNull(checking)
        assertEquals(5120.50, checking!!.currentBalance, 0.01)
        assertEquals(4850.25, checking.availableBalance, 0.01)
    }

    @Test
    fun testInternalTransferExecution() = runBlocking {
        DemoDataInitializer.populateInitialData(db.bankDao())

        val result = repository.executeInternalTransfer(
            fromAccountId = "acc_checking",
            toAccountId = "acc_savings",
            amount = 100.00,
            memo = "Test Transfer"
        )

        assertTrue(result.isSuccess)
        val ref = result.getOrNull()
        assertNotNull(ref)
        assertTrue(ref!!.startsWith("TRF-"))

        val checking = repository.getAccountById("acc_checking")
        assertNotNull(checking)
        assertEquals(5020.50, checking!!.currentBalance, 0.01)
        assertEquals(4750.25, checking.availableBalance, 0.01)

        val savings = repository.getAccountById("acc_savings")
        assertNotNull(savings)
        assertEquals(18520.00, savings!!.currentBalance, 0.01)
    }

    @Test
    fun testInsufficientFundsTransferValidation() = runBlocking {
        DemoDataInitializer.populateInitialData(db.bankDao())

        val result = repository.executeInternalTransfer(
            fromAccountId = "acc_checking",
            toAccountId = "acc_savings",
            amount = 999999.00,
            memo = "Excessive Transfer"
        )

        assertTrue(result.isFailure)
        val exception = result.exceptionOrNull()
        assertNotNull(exception)
        assertTrue(exception!!.message!!.contains("Insufficient available funds"))
    }

    @Test
    fun testCardLockToggle() = runBlocking {
        DemoDataInitializer.populateInitialData(db.bankDao())

        val initialCards = repository.getCards().first()
        val debitCard = initialCards.find { it.id == "card_debit_01" }
        assertNotNull(debitCard)
        assertFalse(debitCard!!.isLocked)

        val toggleResult = repository.toggleCardLock("card_debit_01")
        assertTrue(toggleResult.isSuccess)
        assertTrue(toggleResult.getOrThrow())

        val updatedCards = repository.getCards().first()
        val updatedDebitCard = updatedCards.find { it.id == "card_debit_01" }
        assertTrue(updatedDebitCard!!.isLocked)
    }

    @Test
    fun testMobileCheckDeposit() = runBlocking {
        DemoDataInitializer.populateInitialData(db.bankDao())

        val depositResult = repository.executeCheckDeposit(
            accountId = "acc_checking",
            amount = 250.00,
            frontImageUri = "sample_check_front",
            backImageUri = "sample_check_back"
        )

        assertTrue(depositResult.isSuccess)
        val deposit = depositResult.getOrNull()
        assertNotNull(deposit)
        assertEquals(250.00, deposit!!.amount, 0.01)

        val checking = repository.getAccountById("acc_checking")
        assertEquals(5370.50, checking!!.currentBalance, 0.01)
    }
}
