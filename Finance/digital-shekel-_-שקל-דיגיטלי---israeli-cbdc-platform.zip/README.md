# Digital Shekel | שקל דיגיטלי
## Bilingual Israeli CBDC Research & Engineering Platform

An independent, secure, bilingual central bank digital currency (CBDC) software prototype denominated in Israeli New Shekels (ILS), featuring an append-only double-entry accounting ledger, consumer digital wallet, merchant point of sale with dynamic QR settlement, central bank issuance & dual-control governance, compliance & risk simulation, and live automated invariant testing.

---

### Important Disclaimer & Legal Boundary
**This project is an independent research and engineering prototype.**
It is **not** an official application of the Bank of Israel, does not represent legal tender, and is not an authorised payment service provider. All balances, transactions, and identities are synthetic demonstration records.

---

## Key Modules & Capabilities

1. **Consumer Digital Wallet (ארנק צרכן דיגיטלי)**
   - Demonstration balances displayed in exact integer Agorot (`1 ILS = 100 Agorot`).
   - Instant wallet-to-wallet transfers with atomic settlement.
   - Solvency defense: hard-blocking overdrafts and negative balances.
   - Daily spending velocity tracking and synthetic commercial bank deposit simulator.
   - Real-time QR generation for receiving funds.
   - Cryptographic receipt modal with SHA-256 reference digests.

2. **Merchant Portal & POS (מסוף סליקה לבתי עסק)**
   - Dynamic payment requests with short-lived expiration (5 minutes).
   - Real-time QR generation using the `IL-CBDC-QR-V1` protocol.
   - Live settlement detection: merchant screen automatically transitions upon payment posting.
   - Compensating refund workflow: generates reverse entries linked to parent transactions.
   - Daily settlement reports and gross/net revenue breakdown.

3. **Central Bank Operations & Issuance Engine (מערך בנק מרכזי)**
   - Money supply conservation invariant:
     $$\text{Outstanding CBDC} = \text{Cumulative Issued} - \text{Cumulative Redeemed}$$
   - Four-Eyes Principle (Dual-Control): Initiator cannot approve their own monetary proposal.
   - Controlled minting and redemption to commercial bank settlement reserves (Bank Leumi, Bank Hapoalim).
   - Interbank wholesale reserves monitoring.

4. **Double-Entry General Ledger (ספר ראשי כפול)**
   - Append-only immutable postings ($\sum \text{Debits} == \sum \text{Credits}$).
   - Zero tolerance for floating point errors (all values in integer Agorot).
   - Export audit history to CSV.

5. **Risk, Compliance & Tiered Privacy (ציות ופרטיות)**
   - Tier 1: Micro-retail transfers (< ₪500) with complete consumer pseudonymity.
   - Tier 2: Standard transfers (₪500 – ₪5,000) with standard audit retention.
   - Tier 3: Institutional transfers (> ₪5,000) flagged for compliance review.
   - Configurable velocity checks and case notes management.

6. **Automated Invariant Test Suite (מבדקי מערכת אוטומטיים)**
   - 13 live programmatic assertions testing ledger balance, solvency, idempotency, self-approval defense, and replay protection.

---

## Technology Stack

- **Frontend:** React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons, Assistant & Plus Jakarta Sans typography.
- **Backend:** Node.js, Express REST API (`/api/v1/...`), Double-Entry Ledger Engine with ACID semantics, SHA-256 cryptographic digests.
- **Localization:** 100% native Hebrew with true RTL layout and English with LTR layout.

---

## Running the Application

### Option A: Local Development
```bash
# Install dependencies
npm install

# Start full-stack dev server (Express backend + Vite middleware on port 3000)
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000) in your browser.

### Option B: Docker Compose
```bash
docker-compose up --build
```

---

## Automated Invariant Verification
To execute the live verification suite directly from the command line:
```bash
curl -s http://localhost:3000/api/v1/tests/run
```
Or open the **System Test Suite (מבדקי מערכת)** tab in the UI.
