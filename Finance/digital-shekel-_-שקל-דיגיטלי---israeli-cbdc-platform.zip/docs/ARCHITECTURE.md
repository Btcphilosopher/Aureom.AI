# Digital Shekel (שקל דיגיטלי) — Architecture & CBDC Engineering Specification

## 1. Executive Summary & Legal Boundary
**Digital Shekel (שקל דיגיטלי)** is an independent central bank digital currency (CBDC) research and software engineering prototype denominated in Israeli New Shekels (ILS). 

> **Regulatory & Institutional Boundary:** This system is an independent research and engineering prototype. It is **not** an official Bank of Israel application, an authorized payment service provider, or legal tender issued by a central bank. All balances, identities, and transactions are synthetic demonstration figures.

---

## 2. Core Financial Engine & Double-Entry Ledger Invariants

### Integer Agorot Precision
All financial amounts within the platform are modeled and stored in **exact integer Agorot** ($1 \text{ ILS} = 100 \text{ Agorot}$). Binary floating-point arithmetic is strictly prohibited in balance calculations to eliminate IEEE-754 precision drift.

$$\text{Balance}_{\text{ILS}} = \frac{\text{Balance}_{\text{Agorot}}}{100}$$

### Append-Only Double-Entry General Ledger
Every monetary movement consists of atomic, balanced postings where total debits strictly equal total credits:

$$\sum \text{Debits} \equiv \sum \text{Credits}$$

- **No In-Place Mutation:** Posted transactions are immutable. 
- **Compensating Reversals:** Adjustments and merchant refunds create linked compensating entries referencing the `parentTransactionId`.
- **Solvency Protection:** Overdrafts are mathematically blocked at the engine validation boundary.
- **Idempotency Keys:** Every submission verifies incoming idempotency tokens to protect against duplicate charging during network retries.

---

## 3. Central Bank Monetary Supply Equation

The central bank issuance simulator enforces the M0-CBDC supply conservation invariant:

$$\text{Active CBDC in Circulation} = \sum \text{Cumulative Authorized Issuance} - \sum \text{Cumulative Authorized Redemption}$$

### Four-Eyes Governance (Dual Control)
1. **Proposal:** An authorized desk officer initiates an issuance or redemption proposal.
2. **Approval:** A distinct senior official verifies and signs off. Self-approval is rejected by system rules.
3. **Posting:** Synchronous creation of balanced debit and credit entries between the Central Bank Mint Vault (`CB-ISSUANCE-MINT`) and commercial settlement reserves (e.g. `W-SETTLE-LEUMI`, `W-SETTLE-HAPOALIM`).

---

## 4. Merchant Dynamic QR Payment Protocol (`IL-CBDC-QR-V1`)
- Short-lived, opaque JSON payload generated at checkout.
- Contains `requestId`, `merchantId`, `amountAgorot`, and an explicit 5-minute expiration timestamp.
- No client-side balance manipulation; the merchant interface polls or listens for authoritative backend ledger confirmation.

---

## 5. Tiered Privacy Framework
- **Tier 1 (Micro-Retail < ₪500):** Maximum data minimization. Zero identifiable consumer metadata logged to central bank aggregators.
- **Tier 2 (Standard Retail ₪500 – ₪5,000):** Standard retail logging and transaction retention.
- **Tier 3 (Institutional > ₪5,000):** Statutory threshold. Triggers automatic synthetic AML review queue flags.

---

## 6. Simulated vs. Genuinely Implemented Capabilities

| Capability | Implementation Level | Notes |
| :--- | :--- | :--- |
| **Double-Entry Ledger Engine** | **Genuinely Implemented** | Full ACID-compliant integer agorot balancing and SHA-256 reference digests. |
| **Invariants & Solvency Defense** | **Genuinely Implemented** | Zero-overdraft enforcement, duplicate replay protection, self-transfer defense. |
| **Dual-Control Minting & Burning** | **Genuinely Implemented** | Four-eyes authorization checks and M0 conservation equation. |
| **Dynamic QR Settlement** | **Genuinely Implemented** | Live canvas QR generation and real-time backend state transitions. |
| **Bilingual Hebrew/English Engine** | **Genuinely Implemented** | Native Hebrew terminology, full RTL/LTR dynamic mirroring. |
| **Automated Verification Suite** | **Genuinely Implemented** | Live programmatic test runner with 13 automated invariant tests. |
| **Identity Verification & Biometrics** | **Synthetic / Simulated** | Uses synthetic masked IDs (`034****89`) to preserve real user privacy. |
| **Central Bank Core Liabilities** | **Synthetic / Simulated** | Research simulator without legal tender backing or Bank of Israel connection. |
