/**
 * Digital Shekel (שקל דיגיטלי) - Core CBDC TypeScript Data Models & Types
 * Denominated in Israeli New Shekels (ILS), integer agorot (1 ILS = 100 agorot)
 */

export type Currency = 'ILS';

/** Amount stored as an exact integer in Agorot (1 ILS = 100 Agorot) */
export type Agorot = number;

export type AccountType =
  | 'CENTRAL_BANK_ISSUANCE'
  | 'CENTRAL_BANK_RESERVE'
  | 'COMMERCIAL_BANK_SETTLEMENT'
  | 'RETAIL_WALLET'
  | 'MERCHANT_WALLET'
  | 'FEES_POOL';

export type EntryType = 'DEBIT' | 'CREDIT';

export interface LedgerEntry {
  id: string;
  transactionId: string;
  accountId: string;
  accountName: string;
  type: EntryType;
  amountAgorot: Agorot;
  currency: Currency;
  timestamp: string;
}

export type TransactionType =
  | 'ISSUANCE'
  | 'REDEMPTION'
  | 'P2P_TRANSFER'
  | 'MERCHANT_PAYMENT'
  | 'REFUND'
  | 'COMMERCIAL_SETTLEMENT';

export type TransactionStatus =
  | 'CREATED'
  | 'VALIDATED'
  | 'PENDING'
  | 'POSTED'
  | 'REJECTED'
  | 'REVERSED';

export type PrivacyTier =
  | 'TIER_1_RETAIL'        // < ₪500: Pseudonymous, data minimisation, zero central bank telemetry
  | 'TIER_2_STANDARD'      // ₪500 - ₪5,000: Standard audit logging
  | 'TIER_3_INSTITUTIONAL'; // > ₪5,000: Dual-compliance reporting, heightened AML review

export interface CBDCTransaction {
  id: string;
  idempotencyKey: string;
  type: TransactionType;
  status: TransactionStatus;
  senderWalletId?: string;
  senderName?: string;
  senderNameHe?: string;
  recipientWalletId?: string;
  recipientName?: string;
  recipientNameHe?: string;
  amountAgorot: Agorot;
  description: string;
  descriptionHe: string;
  privacyTier: PrivacyTier;
  timestamp: string;
  postedAt?: string;
  referenceHash: string;
  parentTransactionId?: string; // For linked refunds/compensations
  entries: LedgerEntry[];
  failureReason?: string;
}

export interface PaymentRequest {
  id: string;
  merchantWalletId: string;
  merchantName: string;
  merchantNameHe: string;
  amountAgorot: Agorot;
  referenceNote: string;
  status: 'PENDING' | 'COMPLETED' | 'EXPIRED' | 'CANCELLED';
  qrPayload: string;
  expiresAt: string;
  createdAt: string;
  completedPaymentId?: string;
}

export interface CentralBankOperation {
  id: string;
  type: 'ISSUANCE' | 'REDEMPTION';
  amountAgorot: Agorot;
  initiatorId: string;
  initiatorName: string;
  approverId?: string;
  approverName?: string;
  status: 'PROPOSED' | 'APPROVED' | 'REJECTED';
  targetAccountId: string;
  targetAccountName: string;
  reason: string;
  reasonHe: string;
  timestamp: string;
  approvedAt?: string;
  ledgerTransactionId?: string;
}

export type RiskSeverity = 'LOW' | 'MEDIUM' | 'HIGH';
export type RiskStatus = 'PENDING_REVIEW' | 'CLEARED' | 'RESTRICTED';

export interface RiskAlert {
  id: string;
  transactionId: string;
  walletId: string;
  walletName: string;
  ruleTriggered: string;
  ruleTriggeredHe: string;
  severity: RiskSeverity;
  status: RiskStatus;
  caseNotes?: string;
  timestamp: string;
}

export interface UserWallet {
  id: string;
  identityMasked: string;
  holderName: string;
  holderNameHe: string;
  phoneAlias: string;
  role: 'CONSUMER' | 'MERCHANT' | 'CENTRAL_BANK_OPERATOR' | 'COMPLIANCE_OFFICER';
  balanceAgorot: Agorot;
  reservedAgorot: Agorot;
  status: 'ACTIVE' | 'RESTRICTED' | 'FROZEN';
  dailyLimitAgorot: Agorot;
  spentTodayAgorot: Agorot;
  privacySetting: 'DEFAULT' | 'MAXIMUM_MINIMIZATION';
  createdAt: string;
}

export interface MonetarySupplyStats {
  cumulativeIssuedAgorot: Agorot;
  cumulativeRedeemedAgorot: Agorot;
  outstandingSupplyAgorot: Agorot;
  totalRetailAgorot: Agorot;
  totalMerchantAgorot: Agorot;
  totalSettlementAgorot: Agorot;
  totalLedgerDebitsAgorot: Agorot;
  totalLedgerCreditsAgorot: Agorot;
  isLedgerBalanced: boolean;
  reconciliationDifferenceAgorot: Agorot;
}

export interface TestResult {
  id: string;
  name: string;
  nameHe: string;
  category: 'LEDGER' | 'PAYMENTS' | 'ISSUANCE' | 'PRIVACY' | 'CONCURRENCY';
  passed: boolean;
  message: string;
  details?: string;
  durationMs: number;
}

// Helpers for Agorot <-> Shekel conversions
export function agorotToShekels(agorot: Agorot): number {
  return agorot / 100;
}

export function shekelsToAgorot(shekels: number | string): Agorot {
  const num = typeof shekels === 'string' ? parseFloat(shekels) : shekels;
  if (isNaN(num)) return 0;
  return Math.round(num * 100);
}

export function formatILS(agorot: Agorot, lang: 'he' | 'en' = 'he'): string {
  const shekels = agorot / 100;
  const formatted = new Intl.NumberFormat(lang === 'he' ? 'he-IL' : 'en-IL', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(shekels);

  return lang === 'he' ? `${formatted} ₪` : `₪${formatted}`;
}

export function getPrivacyTier(amountAgorot: Agorot): PrivacyTier {
  if (amountAgorot < 50000) return 'TIER_1_RETAIL'; // < ₪500
  if (amountAgorot <= 500000) return 'TIER_2_STANDARD'; // ₪500 - ₪5,000
  return 'TIER_3_INSTITUTIONAL'; // > ₪5,000
}
