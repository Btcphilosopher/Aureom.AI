import React, { useState, useEffect } from 'react';
import { LanguageProvider, useLanguage } from './localization/useLanguage';
import { Header, ActiveTab } from './components/layout/Header';
import { PrototypeNotice } from './components/layout/PrototypeNotice';
import { ConsumerWallet } from './components/wallet/ConsumerWallet';
import { MerchantPortal } from './components/merchant/MerchantPortal';
import { CentralBankConsole } from './components/centralbank/CentralBankConsole';
import { GeneralLedgerViewer } from './components/ledger/GeneralLedgerViewer';
import { RiskComplianceConsole } from './components/compliance/RiskComplianceConsole';
import { TestRunnerSuite } from './components/testrunner/TestRunnerSuite';
import { UserWallet } from './types/cbdc';
import { cbdcApi } from './services/api';

function MainApp() {
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState<ActiveTab>('wallet');
  const [wallets, setWallets] = useState<UserWallet[]>([]);
  const [currentConsumerWalletId, setCurrentConsumerWalletId] = useState<string>('W-MAYA-01');
  const [refreshTrigger, setRefreshTrigger] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  const triggerRefresh = () => {
    setRefreshTrigger((prev) => prev + 1);
  };

  useEffect(() => {
    let isMounted = true;
    async function initWallets() {
      try {
        const fetched = await cbdcApi.getWallets();
        if (isMounted) {
          setWallets(fetched);
          const firstConsumer = fetched.find((w) => w.role === 'CONSUMER');
          if (firstConsumer) {
            setCurrentConsumerWalletId(firstConsumer.id);
          }
        }
      } catch (err) {
        console.error('Failed to initialize wallets:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    initWallets();
    return () => {
      isMounted = false;
    };
  }, [refreshTrigger]);

  const merchantWallets = wallets.filter((w) => w.role === 'MERCHANT');
  const consumerWallets = wallets.filter((w) => w.role === 'CONSUMER');
  const settlementAccounts = wallets.filter(
    (w) => w.role === 'CENTRAL_BANK_OPERATOR' && w.id.startsWith('W-SETTLE-')
  );

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-slate-900 selection:text-white">
      {/* Top Bar Header */}
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Prototype Status Disclaimer */}
      <PrototypeNotice />

      {/* Main App Content Viewport */}
      <main className="flex-1 pb-16">
        {loading ? (
          <div className="max-w-7xl mx-auto px-4 py-20 text-center text-xs text-slate-500">
            {language === 'he' ? 'טוען מערכת שקל דיגיטלי...' : 'Loading Digital Shekel Platform...'}
          </div>
        ) : (
          <>
            {activeTab === 'wallet' && (
              <ConsumerWallet
                currentWalletId={currentConsumerWalletId}
                onWalletChange={setCurrentConsumerWalletId}
                wallets={wallets}
                refreshTrigger={refreshTrigger}
                triggerRefresh={triggerRefresh}
              />
            )}

            {activeTab === 'merchant' && (
              <MerchantPortal
                merchants={merchantWallets}
                consumerWallets={consumerWallets}
                refreshTrigger={refreshTrigger}
                triggerRefresh={triggerRefresh}
              />
            )}

            {activeTab === 'centralBank' && (
              <CentralBankConsole
                settlementAccounts={settlementAccounts}
                refreshTrigger={refreshTrigger}
                triggerRefresh={triggerRefresh}
              />
            )}

            {activeTab === 'ledger' && (
              <GeneralLedgerViewer
                refreshTrigger={refreshTrigger}
                triggerRefresh={triggerRefresh}
              />
            )}

            {activeTab === 'compliance' && (
              <RiskComplianceConsole
                refreshTrigger={refreshTrigger}
                triggerRefresh={triggerRefresh}
              />
            )}

            {activeTab === 'tests' && (
              <TestRunnerSuite
                refreshTrigger={refreshTrigger}
                triggerRefresh={triggerRefresh}
              />
            )}
          </>
        )}
      </main>

      {/* Quiet Architectural Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">
              {language === 'he' ? 'שקל דיגיטלי' : 'Digital Shekel'}
            </span>
            <span>·</span>
            <span>{language === 'he' ? 'אב-טיפוס הנדסי ומחקרי בלתי תלוי' : 'Independent CBDC Engineering Prototype'}</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400 text-[11px]">
            <span>{language === 'he' ? 'מטבע: ש״ח (ILS) ברישום אגורות' : 'Denominated in ILS Agorot'}</span>
            <span>·</span>
            <span>{language === 'he' ? 'תמיכה דו-לשונית עברית ואנגלית' : 'Bilingual Hebrew & English RTL/LTR'}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <MainApp />
    </LanguageProvider>
  );
}
