import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../localization/useLanguage';
import {
  MonetarySupplyStats,
  CentralBankOperation,
  UserWallet,
  formatILS,
  shekelsToAgorot,
} from '../../types/cbdc';
import { cbdcApi } from '../../services/api';
import {
  Landmark,
  Scale,
  CheckCircle2,
  AlertTriangle,
  ArrowDownCircle,
  ArrowUpCircle,
  ShieldAlert,
  UserCheck,
  Check,
  X,
  FileText,
  Building,
} from 'lucide-react';

interface CentralBankConsoleProps {
  settlementAccounts: UserWallet[];
  refreshTrigger: number;
  triggerRefresh: () => void;
}

export const CentralBankConsole: React.FC<CentralBankConsoleProps> = ({
  settlementAccounts,
  refreshTrigger,
  triggerRefresh,
}) => {
  const { t, language } = useLanguage();
  const [stats, setStats] = useState<MonetarySupplyStats | null>(null);
  const [operations, setOperations] = useState<CentralBankOperation[]>([]);
  const [loading, setLoading] = useState(true);

  // Proposal Form State
  const [opType, setOpType] = useState<'ISSUANCE' | 'REDEMPTION'>('ISSUANCE');
  const [amountStr, setAmountStr] = useState('50000.00');
  const [targetAccount, setTargetAccount] = useState<string>(
    settlementAccounts[0]?.id || 'W-SETTLE-LEUMI'
  );
  const [reason, setReason] = useState('Interbank settlement liquidity allocation');
  const [reasonHe, setReasonHe] = useState('הקצאת נזילות בינבנקאית לסליקה מוסדית');
  const [initiatorName, setInitiatorName] = useState('Amir Ben-Porat (Operations Desk)');
  const [initiatorId, setInitiatorId] = useState('BOI-OPERATOR-AMIR');
  const [proposing, setProposing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Senior Approver Identity for Dual Control demonstration
  const [approverName, setApproverName] = useState('Dr. Shira Tal (Senior Governor)');
  const [approverId, setApproverId] = useState('BOI-GOVERNOR-SHIRA');

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        setLoading(true);
        const [s, ops] = await Promise.all([
          cbdcApi.getLedgerStats(),
          cbdcApi.getCentralBankOperations(),
        ]);
        if (isMounted) {
          setStats(s);
          setOperations(ops);
        }
      } catch (err) {
        console.error('Failed to load central bank data:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, [refreshTrigger]);

  const handlePropose = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const amountAgorot = shekelsToAgorot(amountStr);
    if (amountAgorot <= 0) {
      setErrorMsg(language === 'he' ? 'הסכום חייב להיות חיובי' : 'Amount must be positive');
      return;
    }

    setProposing(true);
    try {
      await cbdcApi.proposeCentralBankOperation({
        type: opType,
        amountAgorot,
        initiatorId,
        initiatorName,
        targetAccountId: targetAccount,
        reason,
        reasonHe,
      });

      setSuccessMsg(
        language === 'he'
          ? 'ההצעה נרשמה בהצלחה והועברה לתור אישור כפול (Four-Eyes Principle)'
          : 'Proposal submitted to the Dual-Control approval queue'
      );
      triggerRefresh();
    } catch (err: any) {
      setErrorMsg(err.message || 'Proposal failed');
    } finally {
      setProposing(false);
    }
  };

  const handleApprove = async (opId: string) => {
    setErrorMsg(null);
    try {
      await cbdcApi.approveCentralBankOperation(opId, approverId, approverName);
      triggerRefresh();
    } catch (err: any) {
      setErrorMsg(err.message || 'Approval failed');
    }
  };

  const handleReject = async (opId: string) => {
    setErrorMsg(null);
    try {
      await cbdcApi.rejectCentralBankOperation(opId, approverId, approverName);
      triggerRefresh();
    } catch (err: any) {
      setErrorMsg(err.message || 'Rejection failed');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Title & Central Bank Operations Header */}
      <div className="bg-slate-900 text-white p-6 rounded-xl shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-white border border-slate-700">
              <Landmark className="w-6 h-6 text-slate-200" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">{t.centralBank.title}</h2>
              <p className="text-xs text-slate-300 mt-0.5">{t.centralBank.subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-[11px] px-2.5 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700 font-mono">
              ROLE: CENTRAL_BANK_GOVERNANCE
            </span>
          </div>
        </div>
      </div>

      {/* Monetary Supply & Conservation Equation Grid */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Cumulative Authorized Issuance */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
              <span className="font-medium">{t.centralBank.cumulativeIssued}</span>
              <ArrowDownCircle className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
              {formatILS(stats.cumulativeIssuedAgorot, language)}
            </div>
            <div className="text-xs text-slate-500 mt-2 font-mono">
              Σ Mint Postings: {stats.cumulativeIssuedAgorot.toLocaleString()} {t.common.agorot}
            </div>
          </div>

          {/* Cumulative Authorized Redemption */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
              <span className="font-medium">{t.centralBank.cumulativeRedeemed}</span>
              <ArrowUpCircle className="w-4 h-4 text-rose-600" />
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
              {formatILS(stats.cumulativeRedeemedAgorot, language)}
            </div>
            <div className="text-xs text-slate-500 mt-2 font-mono">
              Σ Burn Postings: {stats.cumulativeRedeemedAgorot.toLocaleString()} {t.common.agorot}
            </div>
          </div>

          {/* Active Outstanding CBDC in Circulation */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
              <span className="font-medium">{t.centralBank.outstandingCBDC}</span>
              <Scale className="w-4 h-4 text-slate-700" />
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
              {formatILS(stats.outstandingSupplyAgorot, language)}
            </div>
            <div className="mt-2 flex items-center gap-1.5 text-xs text-emerald-700 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t.centralBank.perfectBalance}</span>
            </div>
          </div>
        </div>
      )}

      {/* Dual-Control Governance Notice Banner */}
      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-slate-700 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold block text-slate-900 mb-0.5">
            {language === 'he' ? 'עקרון הבקרה הכפולה (Four-Eyes Principle)' : 'Dual-Control Governance (Four-Eyes Principle)'}
          </span>
          <p className="text-slate-600 leading-relaxed text-[11px]">
            {t.centralBank.dualControlNotice}
          </p>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Main Dual Grid: Propose Operation (Left) & Pending Dual-Control Approvals (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Proposal Form (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-xs p-6">
          <h3 className="text-base font-bold text-slate-900 mb-1">{t.centralBank.proposeIssuance}</h3>
          <p className="text-xs text-slate-500 mb-4">
            {language === 'he' ? 'הגשת בקשה מוניטרית לאישור הנהלת הבנק המרכזי' : 'Propose controlled issuance or redemption'}
          </p>

          <form onSubmit={handlePropose} className="space-y-4 text-xs">
            {/* Operation Type Switcher */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {language === 'he' ? 'סוג הפעולה המוניטרית' : 'Operation Type'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setOpType('ISSUANCE')}
                  className={`py-2 px-3 rounded-lg font-semibold border transition-colors ${
                    opType === 'ISSUANCE'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {language === 'he' ? 'הנפקה חדשה (Mint)' : 'Issuance (Mint)'}
                </button>
                <button
                  type="button"
                  onClick={() => setOpType('REDEMPTION')}
                  className={`py-2 px-3 rounded-lg font-semibold border transition-colors ${
                    opType === 'REDEMPTION'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {language === 'he' ? 'משיכה ופדיון (Burn)' : 'Redemption (Burn)'}
                </button>
              </div>
            </div>

            {/* Target Account */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {t.centralBank.targetAccountLabel}
              </label>
              <select
                value={targetAccount}
                onChange={(e) => setTargetAccount(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900"
              >
                {settlementAccounts.map((sa) => (
                  <option key={sa.id} value={sa.id}>
                    {language === 'he' ? sa.holderNameHe : sa.holderName} ({formatILS(sa.balanceAgorot, language)})
                  </option>
                ))}
              </select>
            </div>

            {/* Amount */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {t.centralBank.amountAgorotLabel}
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="1000"
                  min="100"
                  value={amountStr}
                  onChange={(e) => setAmountStr(e.target.value)}
                  className="w-full px-3 py-2 text-base font-bold tabular-nums border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                  required
                />
                <span className="absolute end-3 top-2.5 text-xs font-semibold text-slate-400">
                  ILS ₪
                </span>
              </div>
            </div>

            {/* Proposer Identity (Display) */}
            <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-[11px] text-slate-500 block">
                {language === 'he' ? 'מזהה היוזם (Proposer Desk)' : 'Initiator Officer'}
              </span>
              <span className="font-semibold text-slate-800">{initiatorName}</span>
              <span className="text-[10px] text-slate-400 font-mono block">{initiatorId}</span>
            </div>

            {/* Reason */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {t.centralBank.reasonLabel}
              </label>
              <input
                type="text"
                value={language === 'he' ? reasonHe : reason}
                onChange={(e) => {
                  if (language === 'he') setReasonHe(e.target.value);
                  else setReason(e.target.value);
                }}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                required
              />
            </div>

            <button
              type="submit"
              disabled={proposing}
              className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors"
            >
              {proposing ? t.common.loading : t.centralBank.submitProposal}
            </button>
          </form>
        </div>

        {/* Dual-Control Approval Queue (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 shadow-xs p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">{t.centralBank.pendingApprovals}</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {language === 'he' ? 'חתימת מנהל בכיר נפרד לביצוע פעולה מוניטרית' : 'Senior Officer sign-off terminal'}
                </p>
              </div>

              {/* Approver Switcher for demonstration */}
              <div className="text-end">
                <span className="text-[10px] text-slate-500 block">
                  {language === 'he' ? 'חותם מורשה:' : 'Logged Approver:'}
                </span>
                <span className="text-xs font-semibold text-slate-900">{approverName}</span>
              </div>
            </div>

            {operations.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                {t.centralBank.noPendingApprovals}
              </div>
            ) : (
              <div className="divide-y divide-slate-100 mt-3 max-h-96 overflow-y-auto">
                {operations.map((op) => {
                  const isPending = op.status === 'PROPOSED';
                  const isSelf = op.initiatorId === approverId;

                  return (
                    <div key={op.id} className="py-3.5 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-semibold px-2 py-0.5 rounded text-[10px] ${
                              op.type === 'ISSUANCE'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}
                          >
                            {op.type}
                          </span>
                          <span className="font-mono font-medium text-slate-800">{op.id}</span>
                        </div>

                        <span
                          className={`text-[11px] font-semibold ${
                            op.status === 'APPROVED'
                              ? 'text-emerald-600'
                              : op.status === 'REJECTED'
                              ? 'text-rose-600'
                              : 'text-amber-600'
                          }`}
                        >
                          {op.status}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-xs">
                        <div>
                          <span className="text-slate-500 block text-[11px]">
                            {language === 'he' ? op.reasonHe : op.reason}
                          </span>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Target: <span className="text-slate-600">{op.targetAccountName}</span> · Initiator: <span className="text-slate-600">{op.initiatorName}</span>
                          </div>
                        </div>

                        <div className="text-base font-bold tabular-nums text-slate-900 shrink-0">
                          {formatILS(op.amountAgorot, language)}
                        </div>
                      </div>

                      {/* Approval Buttons for Pending */}
                      {isPending && (
                        <div className="pt-2 flex items-center justify-end gap-2">
                          {isSelf && (
                            <span className="text-[11px] text-rose-600 font-medium me-2">
                              {language === 'he' ? 'איסור אישור עצמי' : 'Cannot self-approve'}
                            </span>
                          )}
                          <button
                            onClick={() => handleReject(op.id)}
                            className="px-2.5 py-1 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
                          >
                            {t.centralBank.rejectAction}
                          </button>
                          <button
                            onClick={() => handleApprove(op.id)}
                            disabled={isSelf}
                            className={`px-3 py-1 text-xs font-semibold rounded text-white transition-colors flex items-center gap-1.5 ${
                              isSelf ? 'bg-slate-300 cursor-not-allowed' : 'bg-slate-900 hover:bg-slate-800'
                            }`}
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>{t.centralBank.approveAction}</span>
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
            <span>{language === 'he' ? 'פרוטוקול אימות: SHA-256 Multi-Sig' : 'Audit Protocol: Multi-Sig Signature'}</span>
            <span>·</span>
            <span>{language === 'he' ? 'רישום מיידי בספר הראשי' : 'Synchronous Ledger Posting'}</span>
          </div>
        </div>
      </div>

      {/* Interbank Settlement Accounts (Wholesale Reserves) */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6">
        <h3 className="text-base font-bold text-slate-900 mb-1">{t.centralBank.settlementReserves}</h3>
        <p className="text-xs text-slate-500 mb-4">
          {language === 'he' ? 'יתרות מסלקות בנקים מסחריים וקונסורציום הפיקוח' : 'Tier-1 commercial bank settlement reserves'}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {settlementAccounts.map((sa) => (
            <div key={sa.id} className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Building className="w-5 h-5 text-slate-700" />
                <div>
                  <span className="font-semibold text-xs text-slate-900 block">
                    {language === 'he' ? sa.holderNameHe : sa.holderName}
                  </span>
                  <span className="font-mono text-[10px] text-slate-500">{sa.id}</span>
                </div>
              </div>

              <div className="text-end">
                <div className="text-sm font-bold tabular-nums text-slate-900">
                  {formatILS(sa.balanceAgorot, language)}
                </div>
                <span className="text-[10px] text-slate-500 font-mono">
                  {sa.balanceAgorot.toLocaleString()} Agorot
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
