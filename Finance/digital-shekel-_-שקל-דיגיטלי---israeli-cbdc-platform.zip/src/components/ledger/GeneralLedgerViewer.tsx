import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../localization/useLanguage';
import { LedgerEntry, MonetarySupplyStats, formatILS } from '../../types/cbdc';
import { cbdcApi } from '../../services/api';
import {
  BookOpen,
  Scale,
  CheckCircle2,
  AlertTriangle,
  Download,
  Filter,
  Search,
  RefreshCw,
} from 'lucide-react';

interface GeneralLedgerViewerProps {
  refreshTrigger: number;
  triggerRefresh: () => void;
}

export const GeneralLedgerViewer: React.FC<GeneralLedgerViewerProps> = ({
  refreshTrigger,
  triggerRefresh,
}) => {
  const { t, language } = useLanguage();
  const [entries, setEntries] = useState<LedgerEntry[]>([]);
  const [stats, setStats] = useState<MonetarySupplyStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'DEBIT' | 'CREDIT'>('ALL');
  const [searchAccount, setSearchAccount] = useState('');

  useEffect(() => {
    let isMounted = true;
    async function loadLedger() {
      try {
        setLoading(true);
        const [ledgerRes, s] = await Promise.all([
          cbdcApi.getLedgerEntries(),
          cbdcApi.getLedgerStats(),
        ]);
        if (isMounted) {
          setEntries(ledgerRes.entries);
          setStats(s);
        }
      } catch (err) {
        console.error('Failed to load ledger:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadLedger();
    return () => {
      isMounted = false;
    };
  }, [refreshTrigger]);

  const filteredEntries = entries.filter((e) => {
    if (typeFilter !== 'ALL' && e.type !== typeFilter) return false;
    if (searchAccount) {
      const q = searchAccount.toLowerCase();
      return (
        e.accountId.toLowerCase().includes(q) ||
        e.accountName.toLowerCase().includes(q) ||
        e.transactionId.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const exportLedgerCSV = () => {
    const headers = 'ID,TransactionID,Timestamp,AccountID,AccountName,Type,AmountILS,AmountAgorot,Currency\n';
    const rows = entries
      .map(
        (e) =>
          `"${e.id}","${e.transactionId}","${e.timestamp}","${e.accountId}","${e.accountName}","${e.type}",${(e.amountAgorot / 100).toFixed(2)},${e.amountAgorot},"${e.currency}"`
      )
      .join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `digital_shekel_ledger_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Ledger Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold">
            <BookOpen className="w-5 h-5 text-slate-100" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">{t.ledger.title}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.ledger.subtitle}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={triggerRefresh}
            className="p-2 text-slate-600 hover:text-slate-900 bg-slate-50 border border-slate-200 rounded-lg transition-colors"
            title={t.common.refresh}
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={exportLedgerCSV}
            className="flex items-center gap-2 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{language === 'he' ? 'ייצוא יומן ל-CSV' : 'Export Audit CSV'}</span>
          </button>
        </div>
      </div>

      {/* Financial Invariant & Balance Verification Strip */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-xs text-slate-500 block mb-1">{t.ledger.totalDebits}</span>
            <div className="text-2xl font-bold tabular-nums text-slate-900">
              {formatILS(stats.totalLedgerDebitsAgorot, language)}
            </div>
            <div className="text-[11px] text-slate-400 font-mono mt-1">
              Σ {stats.totalLedgerDebitsAgorot.toLocaleString()} {t.common.agorot}
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-xs text-slate-500 block mb-1">{t.ledger.totalCredits}</span>
            <div className="text-2xl font-bold tabular-nums text-slate-900">
              {formatILS(stats.totalLedgerCreditsAgorot, language)}
            </div>
            <div className="text-[11px] text-slate-400 font-mono mt-1">
              Σ {stats.totalLedgerCreditsAgorot.toLocaleString()} {t.common.agorot}
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-xs text-slate-500 block mb-1">{t.ledger.auditStatus}</span>
              <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{t.ledger.allBalanced}</span>
              </div>
            </div>
            <div className="text-[11px] text-slate-500 mt-2">
              {t.ledger.discrepancy}: <span className="font-mono font-bold text-slate-800">0.00 ₪</span>
            </div>
          </div>
        </div>
      )}

      {/* Ledger Table with Filter Controls */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Controls */}
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium">{t.ledger.filterType}:</span>
            <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg">
              <button
                onClick={() => setTypeFilter('ALL')}
                className={`px-2.5 py-1 text-xs rounded transition-colors ${
                  typeFilter === 'ALL' ? 'bg-white font-semibold text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                {t.ledger.all}
              </button>
              <button
                onClick={() => setTypeFilter('DEBIT')}
                className={`px-2.5 py-1 text-xs rounded transition-colors ${
                  typeFilter === 'DEBIT' ? 'bg-white font-semibold text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Debits (חובה)
              </button>
              <button
                onClick={() => setTypeFilter('CREDIT')}
                className={`px-2.5 py-1 text-xs rounded transition-colors ${
                  typeFilter === 'CREDIT' ? 'bg-white font-semibold text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Credits (זכות)
              </button>
            </div>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute start-3 top-2.5" />
            <input
              type="text"
              value={searchAccount}
              onChange={(e) => setSearchAccount(e.target.value)}
              placeholder={language === 'he' ? 'חיפוש לפי חשבון או תנועה...' : 'Search account or transaction...'}
              className="text-xs ps-8 pe-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>
        </div>

        {/* Postings Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-start">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-2.5 px-4 text-start">Entry ID</th>
                <th className="py-2.5 px-4 text-start">{t.ledger.tableTxId}</th>
                <th className="py-2.5 px-4 text-start">{t.common.date}</th>
                <th className="py-2.5 px-4 text-start">{t.ledger.tableAccount}</th>
                <th className="py-2.5 px-4 text-center">{t.common.type}</th>
                <th className="py-2.5 px-4 text-end">{t.ledger.tableDebit}</th>
                <th className="py-2.5 px-4 text-end">{t.ledger.tableCredit}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {filteredEntries.map((entry, idx) => {
                const isDebit = entry.type === 'DEBIT';
                return (
                  <tr key={`${entry.id}-${entry.transactionId}-${idx}`} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 px-4 text-slate-500 text-[11px]">{entry.id}</td>
                    <td className="py-2.5 px-4 font-semibold text-slate-900">{entry.transactionId}</td>
                    <td className="py-2.5 px-4 text-slate-600 font-sans whitespace-nowrap text-[11px]">
                      {new Date(entry.timestamp).toLocaleString(language === 'he' ? 'he-IL' : 'en-US')}
                    </td>
                    <td className="py-2.5 px-4 text-slate-800 font-sans">
                      <span className="font-semibold block">{entry.accountName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{entry.accountId}</span>
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isDebit
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        }`}
                      >
                        {entry.type}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-end font-bold tabular-nums">
                      {isDebit ? formatILS(entry.amountAgorot, language) : '—'}
                    </td>
                    <td className="py-2.5 px-4 text-end font-bold tabular-nums">
                      {!isDebit ? formatILS(entry.amountAgorot, language) : '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
