import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../localization/useLanguage';
import { RiskAlert } from '../../types/cbdc';
import { cbdcApi } from '../../services/api';
import {
  ShieldAlert,
  ShieldCheck,
  EyeOff,
  AlertTriangle,
  Lock,
  UserCheck,
  CheckCircle2,
  FileText,
  Sliders,
} from 'lucide-react';

interface RiskComplianceConsoleProps {
  refreshTrigger: number;
  triggerRefresh: () => void;
}

export const RiskComplianceConsole: React.FC<RiskComplianceConsoleProps> = ({
  refreshTrigger,
  triggerRefresh,
}) => {
  const { t, language } = useLanguage();
  const [alerts, setAlerts] = useState<RiskAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAlert, setSelectedAlert] = useState<RiskAlert | null>(null);
  const [caseNoteInput, setCaseNoteInput] = useState('');
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    let isMounted = true;
    async function loadAlerts() {
      try {
        setLoading(true);
        const data = await cbdcApi.getRiskAlerts();
        if (isMounted) setAlerts(data);
      } catch (err) {
        console.error('Failed to load risk alerts:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadAlerts();
    return () => {
      isMounted = false;
    };
  }, [refreshTrigger]);

  const handleAction = async (alertId: string, action: 'CLEAR' | 'RESTRICT') => {
    setActionLoading(true);
    try {
      await cbdcApi.actionRiskAlert(alertId, action, caseNoteInput || undefined);
      setSelectedAlert(null);
      setCaseNoteInput('');
      triggerRefresh();
    } catch (err) {
      console.error('Failed to action alert:', err);
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Console Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold">
            <ShieldAlert className="w-5 h-5 text-slate-100" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">{t.compliance.title}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.compliance.subtitle}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs px-2.5 py-1 rounded bg-amber-50 text-amber-700 border border-amber-200 font-medium">
            {language === 'he' ? 'סימולציית ניטור וציות' : 'Synthetic AML Engine'}
          </span>
        </div>
      </div>

      {/* Tiered Privacy Architecture Demonstration Cards */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <EyeOff className="w-5 h-5 text-slate-700" />
          <h3 className="text-sm font-bold text-slate-900">{t.compliance.privacyTiersTitle}</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {/* Tier 1 */}
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900">Tier 1: Micro-Retail</span>
              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 font-bold rounded text-[10px]">
                &lt; 500 ₪
              </span>
            </div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              {t.compliance.privacyTier1Desc}
            </p>
            <div className="text-[10px] text-slate-400 font-mono">
              Attribute: Pseudonymous · Zero Telemetry
            </div>
          </div>

          {/* Tier 2 */}
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900">Tier 2: Standard Retail</span>
              <span className="px-2 py-0.5 bg-blue-50 text-blue-700 font-bold rounded text-[10px]">
                500 ₪ – 5,000 ₪
              </span>
            </div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              {t.compliance.privacyTier2Desc}
            </p>
            <div className="text-[10px] text-slate-400 font-mono">
              Attribute: Audit Retention · Standard Rules
            </div>
          </div>

          {/* Tier 3 */}
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900">Tier 3: Institutional</span>
              <span className="px-2 py-0.5 bg-amber-50 text-amber-700 font-bold rounded text-[10px]">
                &gt; 5,000 ₪
              </span>
            </div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              {t.compliance.privacyTier3Desc}
            </p>
            <div className="text-[10px] text-slate-400 font-mono">
              Attribute: Dual Compliance · Review Queue
            </div>
          </div>
        </div>
      </div>

      {/* Active Rules Grid & Review Queue */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Active Rules Strip (4 cols) */}
        <div className="lg:col-span-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <Sliders className="w-4 h-4 text-slate-700" />
            <h3 className="text-sm font-bold text-slate-900">{t.compliance.activeRules}</h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-semibold text-slate-900 block mb-1">
                {language === 'he' ? 'בדיקת מהירות (Velocity Monitor)' : 'Velocity Monitor'}
              </span>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {t.compliance.velocityRule}
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-semibold text-slate-900 block mb-1">
                {language === 'he' ? 'התרעת סכום גבוה (High-Value Filter)' : 'High-Value Filter'}
              </span>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {t.compliance.highValueRule}
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-semibold text-slate-900 block mb-1">
                {language === 'he' ? 'אכיפת תקרה יומית (Velocity Ceiling)' : 'Velocity Ceiling'}
              </span>
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {t.compliance.dailyLimitRule}
              </p>
            </div>
          </div>
        </div>

        {/* Review Queue (8 cols) */}
        <div className="lg:col-span-8 bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">{t.compliance.reviewQueue}</h3>
              <span className="text-xs font-mono text-slate-500">
                {alerts.filter((a) => a.status === 'PENDING_REVIEW').length} {language === 'he' ? 'ממתינים' : 'Pending'}
              </span>
            </div>

            {alerts.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                {t.compliance.noAlerts}
              </div>
            ) : (
              <div className="divide-y divide-slate-100 mt-2 max-h-96 overflow-y-auto">
                {alerts.map((alert) => {
                  const isPending = alert.status === 'PENDING_REVIEW';
                  return (
                    <div key={alert.id} className="py-3.5 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              alert.severity === 'HIGH'
                                ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                : 'bg-amber-50 text-amber-700 border border-amber-200'
                            }`}
                          >
                            {alert.severity}
                          </span>
                          <span className="font-mono text-slate-800 font-medium">{alert.id}</span>
                          <span className="text-slate-400">·</span>
                          <span className="font-medium text-slate-900">{alert.walletName}</span>
                        </div>

                        <span
                          className={`text-[11px] font-semibold ${
                            alert.status === 'CLEARED'
                              ? 'text-emerald-600'
                              : alert.status === 'RESTRICTED'
                              ? 'text-rose-600'
                              : 'text-amber-600'
                          }`}
                        >
                          {alert.status}
                        </span>
                      </div>

                      <p className="text-xs text-slate-700">
                        {language === 'he' ? alert.ruleTriggeredHe : alert.ruleTriggered}
                      </p>

                      {alert.caseNotes && (
                        <div className="p-2 bg-slate-50 rounded border border-slate-200 text-[11px] font-mono text-slate-600">
                          {alert.caseNotes}
                        </div>
                      )}

                      {isPending && (
                        <div className="pt-2 flex items-center justify-end gap-2">
                          <button
                            onClick={() => setSelectedAlert(alert)}
                            className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold transition-colors"
                          >
                            {language === 'he' ? 'בדיקת תיק וקבלת החלטה' : 'Review Case'}
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-100 text-[11px] text-slate-500">
            {language === 'he'
              ? 'מודול סימולציה מחקרי בלבד — אינו מייצג מנוע מוסמך למניעת פשיעה פיננסית.'
              : 'Synthetic research engine for CBDC compliance and velocity rules.'}
          </div>
        </div>
      </div>

      {/* Case Action Modal */}
      {selectedAlert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-md w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">{t.compliance.caseNotes}</h3>
            <p className="text-xs text-slate-600">
              {language === 'he' ? 'בדיקת התרעה עבור' : 'Review alert for'}: <span className="font-semibold">{selectedAlert.walletName}</span> ({selectedAlert.walletId})
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {t.compliance.caseNotes}
              </label>
              <textarea
                value={caseNoteInput}
                onChange={(e) => setCaseNoteInput(e.target.value)}
                placeholder={language === 'he' ? 'הוסף נימוק קצין ציות...' : 'Add compliance assessment notes...'}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 h-24"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedAlert(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
              >
                {t.common.cancel}
              </button>
              <button
                onClick={() => handleAction(selectedAlert.id, 'CLEAR')}
                disabled={actionLoading}
                className="px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors"
              >
                {t.compliance.actionClear}
              </button>
              <button
                onClick={() => handleAction(selectedAlert.id, 'RESTRICT')}
                disabled={actionLoading}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors"
              >
                {t.compliance.actionRestrict}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
