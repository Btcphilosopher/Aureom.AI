import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../localization/useLanguage';
import { TestResult } from '../../types/cbdc';
import { cbdcApi } from '../../services/api';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Play,
  RefreshCw,
  Cpu,
  Layers,
  Database,
  ArrowRightLeft,
  Lock,
} from 'lucide-react';

interface TestRunnerSuiteProps {
  refreshTrigger: number;
  triggerRefresh: () => void;
}

export const TestRunnerSuite: React.FC<TestRunnerSuiteProps> = ({
  refreshTrigger,
  triggerRefresh,
}) => {
  const { t, language } = useLanguage();
  const [results, setResults] = useState<TestResult[]>([]);
  const [summary, setSummary] = useState<{
    total: number;
    passed: number;
    failed: number;
    allPassed: boolean;
  } | null>(null);
  const [running, setRunning] = useState(false);

  const runTests = async () => {
    setRunning(true);
    try {
      const data = await cbdcApi.runAutomatedTests();
      setResults(data.results);
      setSummary(data.summary);
      triggerRefresh();
    } catch (err) {
      console.error('Failed to run test suite:', err);
    } finally {
      setRunning(false);
    }
  };

  useEffect(() => {
    runTests();
  }, []);

  const categories = [
    { id: 'LEDGER', label: t.tests.testSuiteLedger, icon: Database },
    { id: 'PAYMENTS', label: t.tests.testSuitePayments, icon: ArrowRightLeft },
    { id: 'CONCURRENCY', label: t.tests.testSuiteConcurrency, icon: Layers },
    { id: 'ISSUANCE', label: t.tests.testSuiteIssuance, icon: Cpu },
    { id: 'PRIVACY', label: t.tests.testSuitePrivacy, icon: Lock },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold">
            <ShieldCheck className="w-5 h-5 text-slate-100" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">{t.tests.title}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.tests.subtitle}</p>
          </div>
        </div>

        <button
          onClick={runTests}
          disabled={running}
          className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg transition-colors shadow-xs"
        >
          {running ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
          <span>{running ? t.tests.running : t.tests.runAllBtn}</span>
        </button>
      </div>

      {/* Summary KPI Strip */}
      {summary && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-xs text-slate-500 block mb-1">
              {language === 'he' ? 'סך מבדקי אימות שנבדקו' : 'Total Test Assertions'}
            </span>
            <div className="text-3xl font-extrabold text-slate-900 tabular-nums">
              {summary.total}
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              100% Core Invariants Covered
            </span>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-xs text-slate-500 block mb-1">{t.tests.passedTests}</span>
            <div className="text-3xl font-extrabold text-emerald-600 tabular-nums">
              {summary.passed}
            </div>
            <span className="text-[11px] text-emerald-700 mt-1 block font-medium">
              Mathematical invariants fully verified
            </span>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <span className="text-xs text-slate-500 block mb-1">{t.tests.failedTests}</span>
            <div className={`text-3xl font-extrabold tabular-nums ${summary.failed > 0 ? 'text-rose-600' : 'text-slate-400'}`}>
              {summary.failed}
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Zero violations detected
            </span>
          </div>
        </div>
      )}

      {/* Categorized Test Results */}
      <div className="space-y-6">
        {categories.map((cat) => {
          const catResults = results.filter((r) => r.category === cat.id);
          if (catResults.length === 0) return null;
          const CatIcon = cat.icon;

          return (
            <div key={cat.id} className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CatIcon className="w-4 h-4 text-slate-700" />
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                    {cat.label}
                  </h3>
                </div>
                <span className="text-xs text-slate-500 font-mono">
                  {catResults.filter((r) => r.passed).length}/{catResults.length} {language === 'he' ? 'עברו' : 'Passed'}
                </span>
              </div>

              <div className="divide-y divide-slate-100 text-xs">
                {catResults.map((r) => (
                  <div key={r.id} className="p-4 hover:bg-slate-50/50 transition-colors space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {r.passed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        ) : (
                          <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        )}
                        <span className="font-semibold text-slate-900">
                          {language === 'he' ? r.nameHe : r.name}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">({r.id})</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-slate-400">{r.durationMs}ms</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            r.passed
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {r.passed ? 'PASSED' : 'FAILED'}
                        </span>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-600 ps-6">
                      {r.message}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
