import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { useLanguage } from '../../localization/useLanguage';
import { UserWallet, PaymentRequest, CBDCTransaction, formatILS, shekelsToAgorot } from '../../types/cbdc';
import { cbdcApi } from '../../services/api';
import { ReceiptModal } from '../wallet/ReceiptModal';
import {
  Store,
  QrCode,
  CheckCircle2,
  RefreshCw,
  Clock,
  RotateCcw,
  ArrowRight,
  ArrowLeft,
  Search,
  Receipt,
  AlertCircle,
} from 'lucide-react';

interface MerchantPortalProps {
  merchants: UserWallet[];
  consumerWallets: UserWallet[];
  refreshTrigger: number;
  triggerRefresh: () => void;
}

export const MerchantPortal: React.FC<MerchantPortalProps> = ({
  merchants,
  consumerWallets,
  refreshTrigger,
  triggerRefresh,
}) => {
  const { t, language, direction } = useLanguage();
  const [selectedMerchantId, setSelectedMerchantId] = useState<string>(
    merchants[0]?.id || 'W-MERCHANT-01'
  );
  const [merchantWallet, setMerchantWallet] = useState<UserWallet | null>(null);
  const [transactions, setTransactions] = useState<CBDCTransaction[]>([]);
  const [activePaymentRequest, setActivePaymentRequest] = useState<PaymentRequest | null>(null);
  const [amountStr, setAmountStr] = useState('38.50');
  const [referenceNote, setReferenceNote] = useState('Supermarket checkout #1042');
  const [generating, setGenerating] = useState(false);
  const [simulatingPay, setSimulatingPay] = useState(false);
  const [selectedReceiptTx, setSelectedReceiptTx] = useState<CBDCTransaction | null>(null);
  const [refundTxId, setRefundTxId] = useState<string | null>(null);
  const [refunding, setRefunding] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const qrCanvasRef = useRef<HTMLCanvasElement>(null);

  // Load merchant wallet and transactions
  useEffect(() => {
    let isMounted = true;
    async function loadMerchantData() {
      try {
        const mw = await cbdcApi.getWallet(selectedMerchantId);
        const txs = await cbdcApi.getWalletTransactions(selectedMerchantId);
        if (isMounted) {
          setMerchantWallet(mw);
          setTransactions(txs);
        }
      } catch (err) {
        console.error('Failed to load merchant data:', err);
      }
    }
    loadMerchantData();
    return () => {
      isMounted = false;
    };
  }, [selectedMerchantId, refreshTrigger]);

  // Render QR code whenever activePaymentRequest changes
  useEffect(() => {
    if (activePaymentRequest && qrCanvasRef.current) {
      QRCode.toCanvas(qrCanvasRef.current, activePaymentRequest.qrPayload, {
        width: 200,
        margin: 2,
        color: {
          dark: '#0F172A',
          light: '#FFFFFF',
        },
      });
    }
  }, [activePaymentRequest]);

  // Poll status of active payment request
  useEffect(() => {
    if (!activePaymentRequest || activePaymentRequest.status === 'COMPLETED') return;

    const interval = setInterval(async () => {
      try {
        const updated = await cbdcApi.getPaymentRequest(activePaymentRequest.id);
        if (updated.status === 'COMPLETED') {
          setActivePaymentRequest(updated);
          triggerRefresh();
        }
      } catch (err) {
        // Ignored
      }
    }, 1500);

    return () => clearInterval(interval);
  }, [activePaymentRequest, triggerRefresh]);

  const handleCreatePaymentRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    const agorot = shekelsToAgorot(amountStr);
    if (agorot <= 0) return;

    setGenerating(true);
    try {
      const res = await cbdcApi.createPaymentRequest({
        merchantWalletId: selectedMerchantId,
        amountAgorot: agorot,
        referenceNote: referenceNote || 'POS Checkout',
      });
      setActivePaymentRequest(res.paymentRequest);
    } catch (err) {
      console.error('Failed to create payment request:', err);
    } finally {
      setGenerating(false);
    }
  };

  // Immediate demonstration trigger: simulates customer scanning and approving payment
  const handleSimulateCustomerPay = async () => {
    if (!activePaymentRequest || consumerWallets.length === 0) return;
    setSimulatingPay(true);
    try {
      const payer = consumerWallets[0]; // Maya Cohen
      const res = await cbdcApi.confirmPaymentRequest(activePaymentRequest.id, payer.id);
      setActivePaymentRequest(res.paymentRequest);
      triggerRefresh();
    } catch (err) {
      console.error('Failed to simulate pay:', err);
    } finally {
      setSimulatingPay(false);
    }
  };

  const handleProcessRefund = async (txId: string) => {
    setRefunding(true);
    try {
      await cbdcApi.executeRefund({
        originalTransactionId: txId,
        merchantWalletId: selectedMerchantId,
        reason: 'Customer return confirmed at POS',
      });
      setRefundTxId(null);
      triggerRefresh();
    } catch (err: any) {
      alert(`Refund failed: ${err.message}`);
    } finally {
      setRefunding(false);
    }
  };

  const currentMerchant = merchants.find((m) => m.id === selectedMerchantId) || merchants[0];

  // Daily Settlement Metrics
  const completedSales = transactions.filter(
    (t) => t.recipientWalletId === selectedMerchantId && t.type === 'MERCHANT_PAYMENT'
  );
  const refundedSales = transactions.filter(
    (t) => t.senderWalletId === selectedMerchantId && t.type === 'REFUND'
  );

  const totalGrossAgorot = completedSales.reduce((acc, cur) => acc + cur.amountAgorot, 0);
  const totalRefundedAgorot = refundedSales.reduce((acc, cur) => acc + cur.amountAgorot, 0);
  const netSettledAgorot = totalGrossAgorot - totalRefundedAgorot;

  const filteredTransactions = transactions.filter((tx) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      tx.id.toLowerCase().includes(q) ||
      tx.description.toLowerCase().includes(q) ||
      (tx.senderName && tx.senderName.toLowerCase().includes(q))
    );
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Merchant Profile & Selector Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold">
            <Store className="w-5 h-5 text-slate-100" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              {language === 'he' ? currentMerchant?.holderNameHe : currentMerchant?.holderName}
            </h2>
            <div className="text-xs text-slate-500 flex items-center gap-3 mt-0.5">
              <span>{language === 'he' ? 'חשבון מסוף סוחר' : 'Merchant POS Account'}: <span className="font-mono text-slate-700">{currentMerchant?.id}</span></span>
              <span>·</span>
              <span>{language === 'he' ? 'יתרת מסחר נוכחית' : 'Current Balance'}: <span className="font-semibold tabular-nums text-slate-900">{formatILS(merchantWallet?.balanceAgorot || currentMerchant?.balanceAgorot || 0, language)}</span></span>
            </div>
          </div>
        </div>

        {/* Switch Merchant */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 whitespace-nowrap">{language === 'he' ? 'החלף בית עסק' : 'Switch Store'}:</span>
          <select
            value={selectedMerchantId}
            onChange={(e) => {
              setSelectedMerchantId(e.target.value);
              setActivePaymentRequest(null);
            }}
            className="text-xs font-medium px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900"
          >
            {merchants.map((m) => (
              <option key={m.id} value={m.id}>
                {language === 'he' ? m.holderNameHe : m.holderName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Split: Point of Sale Terminal (Left) & Daily Settlement Overview (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Point of Sale (POS) Dynamic QR Generator (7 columns) */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 shadow-xs p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">{t.merchant.title}</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {language === 'he' ? 'סליקת שקל דיגיטלי מול יומן בנק מרכזי ללא עמלות סליקה' : 'Instant settlement with zero interchange fees'}
                </p>
              </div>
              <span className="text-xs font-medium text-slate-500 font-mono">
                POS-REG-01
              </span>
            </div>

            {!activePaymentRequest || activePaymentRequest.status === 'COMPLETED' ? (
              <form onSubmit={handleCreatePaymentRequest} className="mt-5 space-y-4">
                {activePaymentRequest?.status === 'COMPLETED' && (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between text-xs text-emerald-900 animate-in fade-in">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      <div>
                        <span className="font-bold block">{t.merchant.paymentReceived}</span>
                        <span className="text-[11px] text-emerald-700">{t.merchant.settledDirectly}</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActivePaymentRequest(null)}
                      className="px-3 py-1 bg-emerald-600 text-white font-semibold rounded text-xs hover:bg-emerald-700 transition-colors"
                    >
                      {t.merchant.resetPos}
                    </button>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {t.merchant.itemReference}
                  </label>
                  <input
                    type="text"
                    value={referenceNote}
                    onChange={(e) => setReferenceNote(e.target.value)}
                    placeholder={t.merchant.itemPlaceholder}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {t.merchant.amountLabel}
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0.10"
                      value={amountStr}
                      onChange={(e) => setAmountStr(e.target.value)}
                      className="w-full px-3 py-2.5 text-2xl font-bold tabular-nums border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
                      required
                    />
                    <span className="absolute end-3 top-3 text-sm font-semibold text-slate-400">
                      ILS ₪
                    </span>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={generating}
                  className="w-full py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm"
                >
                  <QrCode className="w-4 h-4" />
                  <span>{generating ? t.common.loading : t.merchant.createQRPayload}</span>
                </button>
              </form>
            ) : (
              /* Active QR Code View awaiting payment */
              <div className="mt-5 text-center space-y-4">
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl max-w-xs mx-auto">
                  <canvas ref={qrCanvasRef} className="mx-auto rounded" />
                  <div className="mt-2 text-xs font-bold text-slate-900 tabular-nums">
                    {formatILS(activePaymentRequest.amountAgorot, language)}
                  </div>
                  <div className="text-[11px] text-slate-500 truncate">
                    {activePaymentRequest.referenceNote}
                  </div>
                </div>

                <div className="flex items-center justify-center gap-2 text-xs text-amber-700 bg-amber-50 py-2 px-3 rounded-lg border border-amber-200">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-600" />
                  <span>{t.merchant.waitingScan}</span>
                </div>

                {/* Demonstration Simulator Button for reviewer */}
                <div className="pt-2">
                  <button
                    onClick={handleSimulateCustomerPay}
                    disabled={simulatingPay}
                    className="px-4 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors flex items-center justify-center gap-2 mx-auto"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>
                      {simulatingPay
                        ? t.common.loading
                        : language === 'he'
                        ? 'סימולציית סריקה ואישור לקוח (מיה כהן)'
                        : 'Simulate Customer Tap & Pay (Maya Cohen)'}
                    </span>
                  </button>
                </div>

                <div>
                  <button
                    onClick={() => setActivePaymentRequest(null)}
                    className="text-xs text-slate-500 hover:text-slate-800 underline"
                  >
                    {t.common.cancel}
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>{language === 'he' ? 'פרוטוקול: IL-CBDC-QR-V1' : 'Protocol: IL-CBDC-QR-V1'}</span>
            <span>·</span>
            <span>{language === 'he' ? 'זמן אישור ממוצע: מיידי (<1 שניה)' : 'Settlement: Real-time (<1 sec)'}</span>
          </div>
        </div>

        {/* Daily Settlement Summary Strip (5 columns) */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-5">
          <div>
            <h3 className="text-base font-bold text-slate-900">{t.merchant.dailySummary}</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'he' ? 'סליקה יומית והתאמת קופה' : 'Automated daily reconciliation'}
            </p>
          </div>

          <div className="space-y-3">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
              <span className="text-xs text-slate-500 block mb-0.5">{t.merchant.totalRevenue}</span>
              <div className="text-2xl font-bold tabular-nums text-slate-900">
                {formatILS(netSettledAgorot, language)}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <span className="text-slate-500 block mb-1">
                  {language === 'he' ? 'עסקאות שאושרו' : 'Settled Transactions'}
                </span>
                <span className="font-bold text-slate-900 text-base tabular-nums">
                  {completedSales.length}
                </span>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <span className="text-slate-500 block mb-1">
                  {language === 'he' ? 'החזרים כספיים' : 'Refunds Processed'}
                </span>
                <span className="font-bold text-rose-700 text-base tabular-nums">
                  {refundedSales.length}
                </span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1 text-slate-600">
            <div className="font-semibold text-slate-900 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 text-slate-500" />
              <span>{language === 'he' ? 'מדיניות החזרים מקושרים' : 'Linked Reversal Policy'}</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-500">
              {language === 'he'
                ? 'החזר כספי אינו מוחק עסקאות קודמות, אלא יוצר רשומת יומן מאוזנת המקשרת לאסמכתא המקורית.'
                : 'Refunds never erase past ledger transactions. They append linked compensating entries directly crediting the customer.'}
            </p>
          </div>
        </div>
      </div>

      {/* Merchant Transactions & Refund Management Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">{t.merchant.recentSales}</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'he' ? 'יומן פדיון וסליקה מפורט' : 'Real-time sales & return ledger'}
            </p>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute start-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.common.search}
              className="text-xs ps-8 pe-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-sm">
            {language === 'he' ? 'אין עסקאות להצגה בבית עסק זה' : 'No transactions recorded for this merchant'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-start">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-2.5 px-4 text-start">{t.ledger.tableTxId}</th>
                  <th className="py-2.5 px-4 text-start">{t.common.date}</th>
                  <th className="py-2.5 px-4 text-start">{language === 'he' ? 'לקוח משלם' : 'Customer'}</th>
                  <th className="py-2.5 px-4 text-start">{t.common.notes}</th>
                  <th className="py-2.5 px-4 text-end">{t.common.amount}</th>
                  <th className="py-2.5 px-4 text-center">{language === 'he' ? 'פעולות' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTransactions.map((tx) => {
                  const isRefund = tx.type === 'REFUND';
                  return (
                    <tr key={tx.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-mono font-medium text-slate-900">
                        {tx.id}
                      </td>
                      <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                        {new Date(tx.timestamp).toLocaleString(language === 'he' ? 'he-IL' : 'en-US')}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900">
                        {language === 'he' ? tx.senderNameHe || tx.senderName : tx.senderName}
                      </td>
                      <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                        {language === 'he' ? tx.descriptionHe || tx.description : tx.description}
                      </td>
                      <td className="py-3 px-4 text-end font-bold tabular-nums">
                        <span className={isRefund ? 'text-rose-600' : 'text-emerald-600'}>
                          {isRefund ? '-' : '+'}{formatILS(tx.amountAgorot, language)}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => setSelectedReceiptTx(tx)}
                            className="px-2 py-1 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded"
                          >
                            {language === 'he' ? 'קבלה' : 'Receipt'}
                          </button>

                          {!isRefund && tx.type === 'MERCHANT_PAYMENT' && (
                            <button
                              onClick={() => setRefundTxId(tx.id)}
                              className="px-2 py-1 text-[11px] font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded"
                            >
                              {language === 'he' ? 'החזר' : 'Refund'}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Refund Confirmation Modal */}
      {refundTxId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-md w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">{t.merchant.refundModalTitle}</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              {t.merchant.refundConfirmText}
            </p>
            <div className="font-mono text-xs p-2 bg-slate-50 rounded border border-slate-200 text-slate-700">
              Transaction: {refundTxId}
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setRefundTxId(null)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800"
              >
                {t.common.cancel}
              </button>
              <button
                onClick={() => handleProcessRefund(refundTxId)}
                disabled={refunding}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors"
              >
                {refunding ? t.common.loading : t.merchant.executeRefund}
              </button>
            </div>
          </div>
        </div>
      )}

      {selectedReceiptTx && (
        <ReceiptModal
          transaction={selectedReceiptTx}
          onClose={() => setSelectedReceiptTx(null)}
        />
      )}
    </div>
  );
};
