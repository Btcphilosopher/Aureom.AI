import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../localization/useLanguage';
import { UserWallet, CBDCTransaction, formatILS, agorotToShekels } from '../../types/cbdc';
import { cbdcApi } from '../../services/api';
import { SendTransferModal } from './SendTransferModal';
import { ReceiveQRModal } from './ReceiveQRModal';
import { ReceiptModal } from './ReceiptModal';
import {
  Send,
  QrCode,
  Building2,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldCheck,
  User,
  Clock,
  Filter,
  CheckCircle2,
} from 'lucide-react';

interface ConsumerWalletProps {
  currentWalletId: string;
  onWalletChange: (id: string) => void;
  wallets: UserWallet[];
  refreshTrigger: number;
  triggerRefresh: () => void;
}

export const ConsumerWallet: React.FC<ConsumerWalletProps> = ({
  currentWalletId,
  onWalletChange,
  wallets,
  refreshTrigger,
  triggerRefresh,
}) => {
  const { t, language } = useLanguage();
  const [wallet, setWallet] = useState<UserWallet | null>(null);
  const [transactions, setTransactions] = useState<CBDCTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showSendModal, setShowSendModal] = useState(false);
  const [showReceiveModal, setShowReceiveModal] = useState(false);
  const [selectedReceiptTx, setSelectedReceiptTx] = useState<CBDCTransaction | null>(null);
  const [topUpLoading, setTopUpLoading] = useState(false);
  const [topUpSuccess, setTopUpSuccess] = useState(false);
  const [txFilter, setTxFilter] = useState<'ALL' | 'IN' | 'OUT'>('ALL');

  // Consumer accounts
  const consumerWallets = wallets.filter((w) => w.role === 'CONSUMER');

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        setLoading(true);
        const w = await cbdcApi.getWallet(currentWalletId);
        const txs = await cbdcApi.getWalletTransactions(currentWalletId);
        if (isMounted) {
          setWallet(w);
          setTransactions(txs);
        }
      } catch (err) {
        console.error('Failed to load wallet data:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, [currentWalletId, refreshTrigger]);

  const handleTopUp = async () => {
    if (!wallet) return;
    setTopUpLoading(true);
    try {
      // Top up 250 ILS (25,000 agorot) from commercial settlement reserve
      await cbdcApi.topUpWallet(wallet.id, 25000);
      setTopUpSuccess(true);
      triggerRefresh();
      setTimeout(() => setTopUpSuccess(false), 3000);
    } catch (err) {
      console.error('Top-up failed:', err);
    } finally {
      setTopUpLoading(false);
    }
  };

  const filteredTransactions = transactions.filter((tx) => {
    if (txFilter === 'IN') return tx.recipientWalletId === currentWalletId;
    if (txFilter === 'OUT') return tx.senderWalletId === currentWalletId;
    return true;
  });

  if (!wallet) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8 text-center text-slate-500">
        {t.common.loading}
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Banner: User Identity & Account Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-800 font-bold border border-slate-200">
            <User className="w-5 h-5 text-slate-700" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900">
                {language === 'he' ? wallet.holderNameHe : wallet.holderName}
              </h2>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                {t.wallet.active}
              </span>
            </div>
            <div className="text-xs text-slate-500 flex items-center gap-3 mt-0.5">
              <span>{t.wallet.identityMasked}: <span className="font-mono text-slate-700">{wallet.identityMasked}</span></span>
              <span>·</span>
              <span>{t.wallet.phoneAlias}: <span className="font-mono text-slate-700">{wallet.phoneAlias}</span></span>
            </div>
          </div>
        </div>

        {/* Account Switcher */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 whitespace-nowrap">{t.wallet.switchUser}:</span>
          <select
            value={currentWalletId}
            onChange={(e) => onWalletChange(e.target.value)}
            className="text-xs font-medium px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900"
          >
            {consumerWallets.map((cw) => (
              <option key={cw.id} value={cw.id}>
                {language === 'he' ? cw.holderNameHe : cw.holderName} ({formatILS(cw.balanceAgorot, language)})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Financial Balance Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Available Demonstration Balance */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-medium">{t.wallet.availableBalance}</span>
            <span className="text-[11px] font-mono text-slate-400">ILS · אגורות</span>
          </div>

          <div className="text-3xl sm:text-4xl font-extrabold text-slate-900 tabular-nums tracking-tight">
            {formatILS(wallet.balanceAgorot, language)}
          </div>

          <div className="text-xs text-slate-500 mt-2 font-mono">
            = {wallet.balanceAgorot.toLocaleString()} {t.common.agorot}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
            <span>{t.wallet.reservedBalance}:</span>
            <span className="font-medium tabular-nums text-slate-700">{formatILS(wallet.reservedAgorot, language)}</span>
          </div>
        </div>

        {/* Daily Velocity & Limit Tracker */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-medium">{t.wallet.dailyLimit}</span>
            <Clock className="w-4 h-4 text-slate-400" />
          </div>

          <div className="text-2xl font-bold text-slate-900 tabular-nums">
            {formatILS(wallet.dailyLimitAgorot, language)}
          </div>

          {/* Progress bar */}
          <div className="mt-3">
            <div className="flex justify-between text-xs text-slate-500 mb-1">
              <span>{t.wallet.spentToday}</span>
              <span className="font-semibold tabular-nums text-slate-800">
                {formatILS(wallet.spentTodayAgorot, language)}
              </span>
            </div>
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <div
                className="bg-slate-900 h-full rounded-full transition-all duration-300"
                style={{
                  width: `${Math.min(100, (wallet.spentTodayAgorot / wallet.dailyLimitAgorot) * 100)}%`,
                }}
              />
            </div>
          </div>

          <div className="mt-4 text-[11px] text-slate-500">
            {language === 'he'
              ? 'מגבלת מהירות מבוקרת למניעת סיכונים קמעונאיים'
              : 'Configured retail velocity ceiling to prevent retail risk'}
          </div>
        </div>

        {/* Quick Payment Action Panel */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-700 block mb-3">
              {t.wallet.quickActions}
            </span>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setShowSendModal(true)}
                className="flex items-center justify-center gap-2 p-3 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors text-xs font-semibold"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{t.wallet.sendPayment}</span>
              </button>

              <button
                onClick={() => setShowReceiveModal(true)}
                className="flex items-center justify-center gap-2 p-3 bg-slate-100 text-slate-800 hover:bg-slate-200 rounded-lg transition-colors text-xs font-semibold"
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>{t.wallet.receiveQR}</span>
              </button>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100">
            <button
              onClick={handleTopUp}
              disabled={topUpLoading}
              className="w-full py-2 px-3 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              <Building2 className="w-3.5 h-3.5 text-slate-600" />
              <span>
                {topUpSuccess
                  ? (language === 'he' ? 'נטען בהצלחה! (+250 ₪)' : 'Deposit Complete! (+₪250)')
                  : topUpLoading
                  ? t.common.loading
                  : t.wallet.syntheticTopUp + ' (+250 ₪)'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Transaction History Section */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Header & Filter Controls */}
        <div className="p-4 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">{t.wallet.recentTransactions}</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'he' ? 'רישום כפול מאוזן ביומן הספר הראשי' : 'Balanced double-entry postings'}
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start sm:self-auto">
            <button
              onClick={() => setTxFilter('ALL')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                txFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'he' ? 'הכל' : 'All'}
            </button>
            <button
              onClick={() => setTxFilter('IN')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                txFilter === 'IN' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'he' ? 'נכנס' : 'Incoming'}
            </button>
            <button
              onClick={() => setTxFilter('OUT')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                txFilter === 'OUT' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'he' ? 'יוצא' : 'Outgoing'}
            </button>
          </div>
        </div>

        {/* Transactions Table / List */}
        {filteredTransactions.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-sm">
            {t.wallet.noTransactions}
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredTransactions.map((tx) => {
              const isIncoming = tx.recipientWalletId === currentWalletId;
              const counterpartyName = isIncoming
                ? (language === 'he' ? tx.senderNameHe || tx.senderName : tx.senderName) || 'Interbank Reserve'
                : (language === 'he' ? tx.recipientNameHe || tx.recipientName : tx.recipientName);

              return (
                <div
                  key={tx.id}
                  onClick={() => setSelectedReceiptTx(tx)}
                  className="p-4 hover:bg-slate-50/80 transition-colors cursor-pointer flex items-center justify-between gap-4 text-xs"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                        isIncoming ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {isIncoming ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900 truncate">
                          {counterpartyName}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {tx.id}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                        <span>{new Date(tx.timestamp).toLocaleTimeString(language === 'he' ? 'he-IL' : 'en-US', { hour: '2-digit', minute: '2-digit' })}</span>
                        <span>·</span>
                        <span className="truncate">{language === 'he' ? (tx.descriptionHe || tx.description) : tx.description}</span>
                        <span>·</span>
                        <span className="font-mono text-slate-400">{tx.privacyTier}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-end shrink-0">
                    <div
                      className={`font-bold tabular-nums text-sm ${
                        isIncoming ? 'text-emerald-600' : 'text-slate-900'
                      }`}
                    >
                      {isIncoming ? '+' : '-'}{formatILS(tx.amountAgorot, language)}
                    </div>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {language === 'he' ? 'הצג קבלה' : 'Receipt'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modals */}
      {showSendModal && (
        <SendTransferModal
          currentWallet={wallet}
          allWallets={wallets}
          onClose={() => setShowSendModal(false)}
          onSuccess={(tx) => {
            setShowSendModal(false);
            setSelectedReceiptTx(tx);
            triggerRefresh();
          }}
        />
      )}

      {showReceiveModal && (
        <ReceiveQRModal
          wallet={wallet}
          onClose={() => setShowReceiveModal(false)}
        />
      )}

      {selectedReceiptTx && (
        <ReceiptModal
          transaction={selectedReceiptTx}
          onClose={() => setSelectedReceiptTx(null)}
        />
      )}
    </div>
  );
};
