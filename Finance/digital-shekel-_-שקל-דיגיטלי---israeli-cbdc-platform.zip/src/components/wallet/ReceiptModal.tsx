import React, { useState } from 'react';
import { useLanguage } from '../../localization/useLanguage';
import { CBDCTransaction, formatILS } from '../../types/cbdc';
import { CheckCircle2, Copy, Check, Printer, X, Shield, Lock } from 'lucide-react';

interface ReceiptModalProps {
  transaction: CBDCTransaction;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ transaction, onClose }) => {
  const { t, language } = useLanguage();
  const [copied, setCopied] = useState(false);

  const copyHash = () => {
    navigator.clipboard.writeText(transaction.referenceHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Receipt Header */}
        <div className="bg-slate-900 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 end-4 text-slate-400 hover:text-white transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-2 text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
            <span className="text-xs font-semibold uppercase tracking-wider">
              {language === 'he' ? 'אישור העברה ורישום סופי' : 'Settled & Posted to Ledger'}
            </span>
          </div>

          <h3 className="text-xl font-bold tracking-tight">
            {language === 'he' ? 'קבלה דיגיטלית - שקל דיגיטלי' : 'Digital Shekel Electronic Receipt'}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'he' ? 'אסמכתא חשבונאית בלתי ניתנת לשינוי' : 'Immutable double-entry ledger reference'}
          </p>
        </div>

        {/* Receipt Content */}
        <div className="p-6 space-y-5 text-sm">
          {/* Main Amount */}
          <div className="text-center py-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-xs text-slate-500 block mb-1">
              {language === 'he' ? 'סכום הפעולה' : 'Transaction Amount'}
            </span>
            <div className="text-3xl font-bold tabular-nums text-slate-900">
              {formatILS(transaction.amountAgorot, language)}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 font-mono">
              {transaction.amountAgorot.toLocaleString()} {t.common.agorot}
            </div>
          </div>

          {/* Key-Value Details Grid */}
          <div className="space-y-2.5 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{language === 'he' ? 'מספר אסמכתא' : 'Transaction ID'}</span>
              <span className="font-mono font-medium text-slate-900">{transaction.id}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{t.common.date}</span>
              <span className="text-slate-800">
                {new Date(transaction.timestamp).toLocaleString(language === 'he' ? 'he-IL' : 'en-US')}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{t.common.from}</span>
              <span className="font-medium text-slate-900">
                {language === 'he' ? (transaction.senderNameHe || transaction.senderName) : transaction.senderName || 'System Reserve'}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{t.common.to}</span>
              <span className="font-medium text-slate-900">
                {language === 'he' ? (transaction.recipientNameHe || transaction.recipientName) : transaction.recipientName}
              </span>
            </div>

            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">{language === 'he' ? 'רמת פרטיות' : 'Privacy Tier'}</span>
              <span className="inline-flex items-center gap-1 font-medium text-slate-800">
                <Shield className="w-3 h-3 text-slate-600" />
                {transaction.privacyTier}
              </span>
            </div>

            {transaction.description && (
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">{t.common.notes}</span>
                <span className="text-slate-800 italic">
                  {language === 'he' ? (transaction.descriptionHe || transaction.description) : transaction.description}
                </span>
              </div>
            )}
          </div>

          {/* Cryptographic Hash */}
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-medium text-slate-600 flex items-center gap-1">
                <Lock className="w-3 h-3 text-slate-500" />
                {language === 'he' ? 'חתימת אסמכתא קריפטוגרפית (SHA-256)' : 'Cryptographic Reference Hash (SHA-256)'}
              </span>
              <button
                onClick={copyHash}
                className="text-[11px] text-slate-600 hover:text-slate-900 flex items-center gap-1"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? t.common.copied : t.common.copy}</span>
              </button>
            </div>
            <div className="font-mono text-[10px] break-all text-slate-700 leading-tight">
              {transaction.referenceHash}
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{t.common.downloadReceipt}</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
          >
            {t.common.close}
          </button>
        </div>
      </div>
    </div>
  );
};
