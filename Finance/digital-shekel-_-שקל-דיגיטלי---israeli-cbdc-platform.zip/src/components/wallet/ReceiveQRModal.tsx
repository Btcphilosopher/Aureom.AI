import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { useLanguage } from '../../localization/useLanguage';
import { UserWallet } from '../../types/cbdc';
import { X, Copy, Check, QrCode } from 'lucide-react';

interface ReceiveQRModalProps {
  wallet: UserWallet;
  onClose: () => void;
}

export const ReceiveQRModal: React.FC<ReceiveQRModalProps> = ({ wallet, onClose }) => {
  const { t, language } = useLanguage();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [copied, setCopied] = useState(false);

  const qrData = JSON.stringify({
    protocol: 'IL-CBDC-WALLET-V1',
    walletId: wallet.id,
    phoneAlias: wallet.phoneAlias,
    holderName: wallet.holderName,
  });

  useEffect(() => {
    if (canvasRef.current) {
      QRCode.toCanvas(canvasRef.current, qrData, {
        width: 220,
        margin: 2,
        color: {
          dark: '#0F172A',
          light: '#FFFFFF',
        },
      });
    }
  }, [qrData]);

  const copyAddress = () => {
    navigator.clipboard.writeText(wallet.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-sm w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-slate-800" />
            <h3 className="text-base font-bold text-slate-900">{t.wallet.receiveQR}</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 text-center space-y-4">
          <div className="inline-block p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
            <canvas ref={canvasRef} className="mx-auto rounded" />
          </div>

          <div>
            <div className="font-semibold text-slate-900 text-sm">
              {language === 'he' ? wallet.holderNameHe : wallet.holderName}
            </div>
            <div className="text-xs text-slate-500 font-mono mt-0.5">
              {wallet.phoneAlias}
            </div>
          </div>

          <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 flex items-center justify-between gap-2 text-xs">
            <span className="font-mono text-slate-700 truncate">{wallet.id}</span>
            <button
              onClick={copyAddress}
              className="text-slate-600 hover:text-slate-900 flex items-center gap-1 shrink-0 font-medium px-2 py-1 bg-white border border-slate-200 rounded"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? t.common.copied : t.common.copy}</span>
            </button>
          </div>

          <p className="text-[11px] text-slate-500 leading-relaxed">
            {language === 'he'
              ? 'הצג קוד זה לסורק לצורך קבלת שקלים דיגיטליים ישירות לחשבון ארנק זה'
              : 'Display this QR to the payer to receive digital shekels directly into this wallet'}
          </p>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200 text-center">
          <button
            onClick={onClose}
            className="w-full py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
          >
            {t.common.close}
          </button>
        </div>
      </div>
    </div>
  );
};
