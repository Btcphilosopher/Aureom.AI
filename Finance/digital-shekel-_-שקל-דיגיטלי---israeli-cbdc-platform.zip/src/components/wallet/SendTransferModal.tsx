import React, { useState } from 'react';
import { useLanguage } from '../../localization/useLanguage';
import { UserWallet, CBDCTransaction, shekelsToAgorot, formatILS, getPrivacyTier } from '../../types/cbdc';
import { cbdcApi } from '../../services/api';
import { X, ArrowRight, ArrowLeft, Shield, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface SendTransferModalProps {
  currentWallet: UserWallet;
  allWallets: UserWallet[];
  onClose: () => void;
  onSuccess: (tx: CBDCTransaction) => void;
}

export const SendTransferModal: React.FC<SendTransferModalProps> = ({
  currentWallet,
  allWallets,
  onClose,
  onSuccess,
}) => {
  const { t, language, direction } = useLanguage();
  const [recipientInput, setRecipientInput] = useState('');
  const [amountStr, setAmountStr] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Filter available contacts (exclude current wallet and CB mint)
  const contacts = allWallets.filter(
    (w) => w.id !== currentWallet.id && w.id !== 'CB-ISSUANCE-MINT'
  );

  const amountAgorot = shekelsToAgorot(amountStr);
  const privacyTier = getPrivacyTier(amountAgorot);

  // Check solvency
  const isOverdraft = amountAgorot > currentWallet.balanceAgorot;
  const isExceedingDaily =
    currentWallet.role === 'CONSUMER' &&
    currentWallet.spentTodayAgorot + amountAgorot > currentWallet.dailyLimitAgorot;

  const handleSelectContact = (wallet: UserWallet) => {
    setRecipientInput(wallet.phoneAlias || wallet.id);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (amountAgorot <= 0) {
      setErrorMsg(language === 'he' ? 'אנא הזן סכום חיובי להעברה' : 'Please enter a valid positive amount');
      return;
    }

    if (isOverdraft) {
      setErrorMsg(t.transfer.errorInsufficient);
      return;
    }

    if (isExceedingDaily) {
      setErrorMsg(t.transfer.errorDailyLimit);
      return;
    }

    // Resolve recipient wallet ID from input (phone alias or wallet ID)
    const trimmed = recipientInput.trim();
    const matchedRecipient = allWallets.find(
      (w) => w.id === trimmed || w.phoneAlias.replace(/-/g, '') === trimmed.replace(/-/g, '') || w.phoneAlias === trimmed
    );

    if (!matchedRecipient) {
      setErrorMsg(t.transfer.errorInvalidRecipient);
      return;
    }

    if (matchedRecipient.id === currentWallet.id) {
      setErrorMsg(language === 'he' ? 'לא ניתן להעביר כספים לאותו הארנק' : 'Cannot transfer funds to your own wallet');
      return;
    }

    setLoading(true);

    try {
      const res = await cbdcApi.sendPayment({
        senderWalletId: currentWallet.id,
        recipientWalletId: matchedRecipient.id,
        amountAgorot,
        description: description || undefined,
        descriptionHe: description || undefined,
      });

      onSuccess(res.transaction);
    } catch (err: any) {
      setErrorMsg(err.message || 'Transfer failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div>
            <h3 className="text-base font-bold text-slate-900">{t.transfer.modalTitle}</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'he' ? 'סליקה אטומית מיידית מול הספר הראשי' : 'Instant atomic settlement against the ledger'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-2 text-rose-800 text-xs">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Quick Contact Selection */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              {language === 'he' ? 'אנשי קשר ובתי עסק בהדגמה' : 'Demonstration Recipients'}
            </label>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {contacts.map((contact) => (
                <button
                  type="button"
                  key={contact.id}
                  onClick={() => handleSelectContact(contact)}
                  className={`text-xs px-2.5 py-1.5 rounded-md border text-start whitespace-nowrap transition-colors ${
                    recipientInput === contact.phoneAlias || recipientInput === contact.id
                      ? 'border-slate-900 bg-slate-900 text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="font-semibold block text-[11px]">
                    {language === 'he' ? contact.holderNameHe : contact.holderName}
                  </span>
                  <span className="text-[10px] opacity-80 font-mono">
                    {contact.phoneAlias}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Recipient Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {t.transfer.recipientLabel}
            </label>
            <input
              type="text"
              value={recipientInput}
              onChange={(e) => setRecipientInput(e.target.value)}
              placeholder={t.transfer.recipientPlaceholder}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-slate-900"
              required
            />
          </div>

          {/* Amount Input */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700">
                {t.transfer.amountLabel}
              </label>
              <span className="text-xs text-slate-500">
                {t.transfer.available}: <span className="font-semibold tabular-nums text-slate-800">{formatILS(currentWallet.balanceAgorot, language)}</span>
              </span>
            </div>
            <div className="relative">
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                placeholder={t.transfer.amountPlaceholder}
                className={`w-full px-3 py-2.5 text-lg font-bold tabular-nums border rounded-lg focus:outline-none focus:ring-2 ${
                  isOverdraft
                    ? 'border-rose-400 focus:ring-rose-500 bg-rose-50/30'
                    : 'border-slate-300 focus:ring-slate-900 focus:border-slate-900'
                }`}
                required
              />
              <span className="absolute end-3 top-3 text-sm font-semibold text-slate-400">
                ILS ₪
              </span>
            </div>

            {amountAgorot > 0 && (
              <div className="text-[11px] text-slate-500 mt-1 font-mono">
                = {amountAgorot.toLocaleString()} {t.common.agorot}
              </div>
            )}
          </div>

          {/* Transfer Reference */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {t.transfer.descriptionLabel}
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t.transfer.descriptionPlaceholder}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {/* Applicable Privacy Tier Info Box */}
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5">
            <div className="flex items-center justify-between text-slate-700">
              <span className="font-medium flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-slate-600" />
                {t.transfer.privacyTier}
              </span>
              <span className="font-mono font-semibold text-slate-900">{privacyTier}</span>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              {privacyTier === 'TIER_1_RETAIL' && t.transfer.tier1Note}
              {privacyTier === 'TIER_2_STANDARD' && t.transfer.tier2Note}
              {privacyTier === 'TIER_3_INSTITUTIONAL' && t.transfer.tier3Note}
            </p>
          </div>

          {/* Solvency / Fee Summary */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>{t.transfer.fee}</span>
            <span className="font-medium text-emerald-600">0.00 ₪</span>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={loading || isOverdraft || isExceedingDaily || amountAgorot <= 0}
              className={`w-full py-2.5 px-4 text-sm font-semibold rounded-lg text-white transition-all flex items-center justify-center gap-2 ${
                loading || isOverdraft || isExceedingDaily || amountAgorot <= 0
                  ? 'bg-slate-300 cursor-not-allowed'
                  : 'bg-slate-900 hover:bg-slate-800 active:scale-[0.99] shadow-sm'
              }`}
            >
              {loading ? (
                <span>{t.transfer.processing}</span>
              ) : (
                <>
                  <span>{t.transfer.submitBtn}</span>
                  {direction === 'rtl' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
