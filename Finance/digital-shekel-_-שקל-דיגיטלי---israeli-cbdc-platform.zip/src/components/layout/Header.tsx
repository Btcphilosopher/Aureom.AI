import React from 'react';
import { useLanguage } from '../../localization/useLanguage';
import { Languages, ShieldCheck } from 'lucide-react';

export type ActiveTab = 'wallet' | 'merchant' | 'centralBank' | 'ledger' | 'compliance' | 'tests';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  const { language, toggleLanguage, t } = useLanguage();

  const navItems: { id: ActiveTab; label: string }[] = [
    { id: 'wallet', label: t.nav.wallet },
    { id: 'merchant', label: t.nav.merchant },
    { id: 'centralBank', label: t.nav.centralBank },
    { id: 'ledger', label: t.nav.ledger },
    { id: 'compliance', label: t.nav.compliance },
    { id: 'tests', label: t.nav.tests },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element wordmark with domain mark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-sm tracking-wider shadow-sm">
              ₪D
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap">
                {t.brand.name}
              </span>
              <span className="text-[11px] text-slate-500 whitespace-nowrap">
                {language === 'he' ? 'שקל דיגיטלי ILS' : 'Israeli CBDC Prototype'}
              </span>
            </div>
          </div>

          {/* Zone 2: Clean single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-6">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`text-sm font-medium transition-colors whitespace-nowrap py-1 border-b-2 ${
                    isActive
                      ? 'border-slate-900 text-slate-950 font-semibold'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action / Language Toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap"
              title={language === 'he' ? 'Switch to English' : 'עבור לעברית'}
            >
              <Languages className="w-3.5 h-3.5 text-slate-600" />
              <span>{t.nav.langToggle}</span>
            </button>
          </div>
        </div>

        {/* Mobile secondary navigation strip */}
        <div className="lg:hidden flex items-center gap-2 overflow-x-auto py-2 border-t border-slate-100 no-scrollbar">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`text-xs px-2.5 py-1 rounded whitespace-nowrap transition-colors ${
                activeTab === item.id
                  ? 'bg-slate-900 text-white font-medium'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
