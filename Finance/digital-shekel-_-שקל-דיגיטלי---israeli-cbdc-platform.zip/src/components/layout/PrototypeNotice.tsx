import React, { useState } from 'react';
import { useLanguage } from '../../localization/useLanguage';
import { AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';

export const PrototypeNotice: React.FC = () => {
  const { t, language } = useLanguage();
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="bg-slate-100 border-b border-slate-200 text-slate-700 text-xs py-2 px-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 min-w-0">
          <AlertCircle className="w-4 h-4 text-slate-600 shrink-0" />
          <span className="font-semibold shrink-0 text-slate-900">
            {t.brand.disclaimerBadge}:
          </span>
          <span className="truncate hidden sm:inline text-slate-600">
            {t.brand.disclaimerText}
          </span>
        </div>

        <button
          onClick={() => setExpanded(!expanded)}
          className="text-slate-600 hover:text-slate-900 flex items-center gap-1 text-[11px] font-medium shrink-0 underline"
        >
          {expanded ? (language === 'he' ? 'צמצם' : 'Collapse') : (language === 'he' ? 'הרחב תנאים' : 'Details')}
          {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>
      </div>

      {expanded && (
        <div className="max-w-7xl mx-auto mt-2 pt-2 border-t border-slate-200 text-slate-600 leading-relaxed text-[11px]">
          <p>{t.brand.disclaimerText}</p>
          <div className="mt-1 flex items-center gap-4 text-slate-500">
            <span>{language === 'he' ? 'מטבע: שקל חדש (ILS)' : 'Currency: Israeli New Shekel (ILS)'}</span>
            <span>·</span>
            <span>{language === 'he' ? 'דיוק חשבונאי: אגורות (Integer Agorot 1/100)' : 'Precision: Exact integer agorot'}</span>
            <span>·</span>
            <span>{language === 'he' ? 'מודל: רישום כפול (Double-entry Ledger)' : 'Core: Append-only double-entry ledger'}</span>
          </div>
        </div>
      )}
    </div>
  );
};
