/**
 * Digital Shekel (שקל דיגיטלי) - Client API Service
 * Strongly-typed communication with backend financial engine.
 */

import {
  UserWallet,
  CBDCTransaction,
  PaymentRequest,
  CentralBankOperation,
  RiskAlert,
  LedgerEntry,
  MonetarySupplyStats,
  TestResult,
  Agorot,
} from '../types/cbdc';

const BASE_URL = '/api/v1';

async function handleResponse<T>(res: Response): Promise<T> {
  const data = await res.json();
  if (!res.ok || data.success === false) {
    throw new Error(data.error || 'Request failed');
  }
  return data;
}

export const cbdcApi = {
  async getWallets(): Promise<UserWallet[]> {
    const res = await fetch(`${BASE_URL}/wallets`);
    const data = await handleResponse<{ wallets: UserWallet[] }>(res);
    return data.wallets;
  },

  async getWallet(id: string): Promise<UserWallet> {
    const res = await fetch(`${BASE_URL}/wallets/${id}`);
    const data = await handleResponse<{ wallet: UserWallet }>(res);
    return data.wallet;
  },

  async getWalletTransactions(id: string): Promise<CBDCTransaction[]> {
    const res = await fetch(`${BASE_URL}/wallets/${id}/transactions`);
    const data = await handleResponse<{ transactions: CBDCTransaction[] }>(res);
    return data.transactions;
  },

  async topUpWallet(walletId: string, amountAgorot: Agorot): Promise<{ transaction: CBDCTransaction }> {
    const res = await fetch(`${BASE_URL}/wallets/${walletId}/topup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amountAgorot }),
    });
    return handleResponse<{ transaction: CBDCTransaction }>(res);
  },

  async sendPayment(params: {
    senderWalletId: string;
    recipientWalletId: string;
    amountAgorot: Agorot;
    description?: string;
    descriptionHe?: string;
    idempotencyKey?: string;
  }): Promise<{ transaction: CBDCTransaction }> {
    const res = await fetch(`${BASE_URL}/payments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return handleResponse<{ transaction: CBDCTransaction }>(res);
  },

  async createPaymentRequest(params: {
    merchantWalletId: string;
    amountAgorot: Agorot;
    referenceNote?: string;
  }): Promise<{ paymentRequest: PaymentRequest }> {
    const res = await fetch(`${BASE_URL}/payment-requests`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return handleResponse<{ paymentRequest: PaymentRequest }>(res);
  },

  async getPaymentRequest(id: string): Promise<PaymentRequest> {
    const res = await fetch(`${BASE_URL}/payment-requests/${id}`);
    const data = await handleResponse<{ paymentRequest: PaymentRequest }>(res);
    return data.paymentRequest;
  },

  async confirmPaymentRequest(
    id: string,
    payerWalletId: string
  ): Promise<{ paymentRequest: PaymentRequest; transaction: CBDCTransaction }> {
    const res = await fetch(`${BASE_URL}/payment-requests/${id}/confirm`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ payerWalletId }),
    });
    return handleResponse<{ paymentRequest: PaymentRequest; transaction: CBDCTransaction }>(res);
  },

  async executeRefund(params: {
    originalTransactionId: string;
    merchantWalletId: string;
    reason?: string;
  }): Promise<{ transaction: CBDCTransaction }> {
    const res = await fetch(`${BASE_URL}/refunds`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return handleResponse<{ transaction: CBDCTransaction }>(res);
  },

  async getLedgerEntries(accountId?: string): Promise<{ entries: LedgerEntry[]; totalCount: number }> {
    const url = accountId ? `${BASE_URL}/ledger/entries?accountId=${accountId}` : `${BASE_URL}/ledger/entries`;
    const res = await fetch(url);
    return handleResponse<{ entries: LedgerEntry[]; totalCount: number }>(res);
  },

  async getLedgerStats(): Promise<MonetarySupplyStats> {
    const res = await fetch(`${BASE_URL}/ledger/stats`);
    const data = await handleResponse<{ stats: MonetarySupplyStats }>(res);
    return data.stats;
  },

  async getCentralBankOperations(): Promise<CentralBankOperation[]> {
    const res = await fetch(`${BASE_URL}/central-bank/operations`);
    const data = await handleResponse<{ operations: CentralBankOperation[] }>(res);
    return data.operations;
  },

  async proposeCentralBankOperation(params: {
    type: 'ISSUANCE' | 'REDEMPTION';
    amountAgorot: Agorot;
    initiatorId: string;
    initiatorName: string;
    targetAccountId: string;
    reason: string;
    reasonHe: string;
  }): Promise<{ operation: CentralBankOperation }> {
    const res = await fetch(`${BASE_URL}/central-bank/operations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return handleResponse<{ operation: CentralBankOperation }>(res);
  },

  async approveCentralBankOperation(
    id: string,
    approverId: string,
    approverName: string
  ): Promise<{ operation: CentralBankOperation }> {
    const res = await fetch(`${BASE_URL}/central-bank/operations/${id}/approve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ approverId, approverName }),
    });
    return handleResponse<{ operation: CentralBankOperation }>(res);
  },

  async rejectCentralBankOperation(
    id: string,
    approverId: string,
    approverName: string
  ): Promise<{ operation: CentralBankOperation }> {
    const res = await fetch(`${BASE_URL}/central-bank/operations/${id}/reject`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ approverId, approverName }),
    });
    return handleResponse<{ operation: CentralBankOperation }>(res);
  },

  async getRiskAlerts(): Promise<RiskAlert[]> {
    const res = await fetch(`${BASE_URL}/compliance/alerts`);
    const data = await handleResponse<{ alerts: RiskAlert[] }>(res);
    return data.alerts;
  },

  async actionRiskAlert(
    id: string,
    action: 'CLEAR' | 'RESTRICT',
    notes?: string
  ): Promise<{ alert: RiskAlert }> {
    const res = await fetch(`${BASE_URL}/compliance/alerts/${id}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, notes }),
    });
    return handleResponse<{ alert: RiskAlert }>(res);
  },

  async runAutomatedTests(): Promise<{
    results: TestResult[];
    summary: { total: number; passed: number; failed: number; allPassed: boolean };
  }> {
    const res = await fetch(`${BASE_URL}/tests/run`);
    return handleResponse<{
      results: TestResult[];
      summary: { total: number; passed: number; failed: number; allPassed: boolean };
    }>(res);
  },
};
