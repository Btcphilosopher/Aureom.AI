/**
 * Digital Shekel (שקל דיגיטלי) - Automated CBDC Verification & Invariant Test Suite
 * Executes live tests on the ledger engine, solvency, dual-control, and idempotency.
 */

import { TestResult, formatILS } from '../src/types/cbdc';
import { db } from './cbdcState';
import { LedgerEngine } from './ledgerEngine';

export class TestEngine {
  public static runAllTests(): TestResult[] {
    const results: TestResult[] = [];

    // --- TEST SUITE 1: LEDGER BALANCING & CONSERVATION ---
    results.push(this.testEveryTransactionBalances());
    results.push(this.testGlobalLedgerDebitCreditConservation());
    results.push(this.testMoneySupplyConservationInvariant());

    // --- TEST SUITE 2: PAYMENTS & SOLVENCY ---
    results.push(this.testSuccessfulTransfer());
    results.push(this.testOverdraftPrevention());
    results.push(this.testInvalidNegativeAmountRejected());
    results.push(this.testDistinctSenderRecipientEnforced());

    // --- TEST SUITE 3: CONCURRENCY & IDEMPOTENCY ---
    results.push(this.testIdempotencyKeyDeduplication());
    results.push(this.testCompensatingRefundLinkage());

    // --- TEST SUITE 4: CENTRAL BANK & DUAL CONTROL ---
    results.push(this.testDualControlProposerCannotSelfApprove());
    results.push(this.testRedemptionCannotExceedReserveBalance());

    // --- TEST SUITE 5: PRIVACY & RISK ---
    results.push(this.testPrivacyTierAssignmentByValue());
    results.push(this.testVelocityDailyLimitEnforcement());

    return results;
  }

  private static testEveryTransactionBalances(): TestResult {
    const start = performance.now();
    let allBalanced = true;
    let failingTx = '';

    for (const tx of db.transactions) {
      let debits = 0;
      let credits = 0;
      for (const entry of tx.entries) {
        if (entry.type === 'DEBIT') debits += entry.amountAgorot;
        if (entry.type === 'CREDIT') credits += entry.amountAgorot;
      }
      if (debits !== credits) {
        allBalanced = false;
        failingTx = tx.id;
        break;
      }
    }

    return {
      id: 'TEST-LEDGER-01',
      name: 'Every Posted Transaction Has Equal Debits and Credits',
      nameHe: 'כל תנועה רשומה מכילה סכום חובות השווה במדויק לסכום הזכויות',
      category: 'LEDGER',
      passed: allBalanced,
      message: allBalanced
        ? `Verified ${db.transactions.length} transactions in history. Invariant Σ Debits == Σ Credits satisfied.`
        : `Transaction ${failingTx} violates double-entry balancing.`,
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testGlobalLedgerDebitCreditConservation(): TestResult {
    const start = performance.now();
    const stats = LedgerEngine.getMonetarySupplyStats();
    const passed = stats.isLedgerBalanced && stats.totalLedgerDebitsAgorot === stats.totalLedgerCreditsAgorot;

    return {
      id: 'TEST-LEDGER-02',
      name: 'Global Ledger Conservation (Total Debits == Total Credits)',
      nameHe: 'אימות שימור ספר ראשי גלובלי (סך כל החובות שווה לסך כל הזכויות)',
      category: 'LEDGER',
      passed,
      message: passed
        ? `Total Debits (${formatILS(stats.totalLedgerDebitsAgorot, 'en')}) == Total Credits (${formatILS(stats.totalLedgerCreditsAgorot, 'en')}). Zero variance.`
        : `Discrepancy of ${stats.reconciliationDifferenceAgorot} Agorot detected.`,
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testMoneySupplyConservationInvariant(): TestResult {
    const start = performance.now();
    const stats = LedgerEngine.getMonetarySupplyStats();
    const expected = stats.cumulativeIssuedAgorot - stats.cumulativeRedeemedAgorot;
    const passed = stats.outstandingSupplyAgorot === expected && stats.reconciliationDifferenceAgorot === 0;

    return {
      id: 'TEST-LEDGER-03',
      name: 'Money Supply Conservation Equation (Outstanding = Issued − Redeemed)',
      nameHe: 'משוואת שימור היצע כסף (מטבע במחזור = סך הנפקה מאושרת פחות סך פדיון)',
      category: 'LEDGER',
      passed,
      message: passed
        ? `Outstanding supply ${formatILS(stats.outstandingSupplyAgorot, 'en')} exactly matches active wallet balances.`
        : `Reconciliation error: delta of ${stats.reconciliationDifferenceAgorot} Agorot between supply and circulation.`,
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testSuccessfulTransfer(): TestResult {
    const start = performance.now();
    // Test small transfer from Maya to David
    const sender = db.wallets.get('W-MAYA-01');
    const recipient = db.wallets.get('W-DAVID-02');

    if (!sender || !recipient) {
      return {
        id: 'TEST-PAY-01',
        name: 'Atomic Wallet-to-Wallet Transfer',
        nameHe: 'העברה אטומית מארנק לארנק עם זיכוי וחיוב מיידיים',
        category: 'PAYMENTS',
        passed: false,
        message: 'Test wallets not found.',
        durationMs: 0,
      };
    }

    const testAmount = 500; // 5.00 ILS
    const senderBefore = sender.balanceAgorot;
    const recipientBefore = recipient.balanceAgorot;

    const res = LedgerEngine.postTransfer({
      senderWalletId: 'W-MAYA-01',
      recipientWalletId: 'W-DAVID-02',
      amountAgorot: testAmount,
      description: 'Automated Test Micro-Transfer',
      descriptionHe: 'העברת בדיקה אוטומטית',
    });

    const passed =
      res.success &&
      sender.balanceAgorot === senderBefore - testAmount &&
      recipient.balanceAgorot === recipientBefore + testAmount;

    return {
      id: 'TEST-PAY-01',
      name: 'Atomic Wallet-to-Wallet Transfer',
      nameHe: 'העברה אטומית מארנק לארנק עם זיכוי וחיוב מיידיים',
      category: 'PAYMENTS',
      passed,
      message: passed
        ? `Successfully transferred 5.00 ₪. Sender and recipient balances adjusted atomically.`
        : `Transfer failed: ${res.error}`,
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testOverdraftPrevention(): TestResult {
    const start = performance.now();
    const sender = db.wallets.get('W-DAVID-02');
    const excessiveAmount = (sender ? sender.balanceAgorot : 1000000) + 100000;

    const res = LedgerEngine.postTransfer({
      senderWalletId: 'W-DAVID-02',
      recipientWalletId: 'W-MAYA-01',
      amountAgorot: excessiveAmount,
      description: 'Attempted overdraft test',
    });

    const passed = !res.success && res.error?.includes('Insufficient funds');

    return {
      id: 'TEST-PAY-02',
      name: 'Overdraft Protection (Zero Negative Balances Allowed)',
      nameHe: 'מניעת משיכת יתר (איסור מוחלט על יתרות שליליות בארנק)',
      category: 'PAYMENTS',
      passed: !!passed,
      message: passed
        ? 'Overdraft transfer was rejected as expected. Wallet balance strictly protected.'
        : 'Overdraft was improperly permitted or error string mismatch.',
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testInvalidNegativeAmountRejected(): TestResult {
    const start = performance.now();
    const res = LedgerEngine.postTransfer({
      senderWalletId: 'W-MAYA-01',
      recipientWalletId: 'W-DAVID-02',
      amountAgorot: -2500,
      description: 'Negative amount exploit test',
    });

    const passed = !res.success;

    return {
      id: 'TEST-PAY-03',
      name: 'Negative and Non-Integer Amount Rejection',
      nameHe: 'דחיית סכומים שליליים וערכים שאינם שלמים באגורות',
      category: 'PAYMENTS',
      passed,
      message: passed
        ? 'Negative transfer attempt was safely rejected by validation boundary.'
        : 'Negative transfer succeeded unexpectedly!',
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testDistinctSenderRecipientEnforced(): TestResult {
    const start = performance.now();
    const res = LedgerEngine.postTransfer({
      senderWalletId: 'W-MAYA-01',
      recipientWalletId: 'W-MAYA-01',
      amountAgorot: 1000,
      description: 'Self transfer test',
    });

    const passed = !res.success && res.error?.includes('distinct');

    return {
      id: 'TEST-PAY-04',
      name: 'Self-Transfer Identity Collision Defense',
      nameHe: 'מניעת העברה עצמית לאותו ארנק (חובת נמען נפרד)',
      category: 'PAYMENTS',
      passed: !!passed,
      message: passed
        ? 'Identical sender-recipient transfer rejected.'
        : 'Self-transfer check failed.',
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testIdempotencyKeyDeduplication(): TestResult {
    const start = performance.now();
    const idempotencyKey = `TEST-IDEMP-${Date.now()}`;

    // First call
    const res1 = LedgerEngine.postTransfer({
      senderWalletId: 'W-MAYA-01',
      recipientWalletId: 'W-DAVID-02',
      amountAgorot: 100,
      idempotencyKey,
    });

    const balanceAfterFirst = db.wallets.get('W-MAYA-01')?.balanceAgorot;

    // Retry call with exact same idempotency key (simulating network retry)
    const res2 = LedgerEngine.postTransfer({
      senderWalletId: 'W-MAYA-01',
      recipientWalletId: 'W-DAVID-02',
      amountAgorot: 100,
      idempotencyKey,
    });

    const balanceAfterSecond = db.wallets.get('W-MAYA-01')?.balanceAgorot;

    const passed =
      res1.success &&
      res2.success &&
      res1.transaction?.id === res2.transaction?.id &&
      balanceAfterFirst === balanceAfterSecond;

    return {
      id: 'TEST-CONC-01',
      name: 'Idempotent Payment Submission & Replay Protection',
      nameHe: 'הגנת שידור חוזר ותשלום אידמפוטנטי (מניעת תשלום כפול)',
      category: 'CONCURRENCY',
      passed,
      message: passed
        ? 'Duplicate submission with identical key returned existing transaction without double-charging.'
        : 'Idempotency failed: balance changed on retry.',
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testCompensatingRefundLinkage(): TestResult {
    const start = performance.now();
    // Simulate payment to merchant Super-Pharm
    const payRes = LedgerEngine.postTransfer({
      senderWalletId: 'W-MAYA-01',
      recipientWalletId: 'W-MERCHANT-01',
      amountAgorot: 2000,
      description: 'Shampoo purchase',
      type: 'MERCHANT_PAYMENT',
    });

    if (!payRes.success || !payRes.transaction) {
      return {
        id: 'TEST-CONC-02',
        name: 'Compensating Reversal & Refund Linkage',
        nameHe: 'מנגנון זיכוי מקושר וביטול מפצה ללא מחיקת נתונים',
        category: 'CONCURRENCY',
        passed: false,
        message: 'Setup payment failed.',
        durationMs: 0,
      };
    }

    // Now execute refund
    const refundRes = LedgerEngine.executeRefund({
      originalTransactionId: payRes.transaction.id,
      merchantWalletId: 'W-MERCHANT-01',
      reason: 'Returned unopened goods',
    });

    const passed =
      refundRes.success &&
      refundRes.transaction?.parentTransactionId === payRes.transaction.id &&
      refundRes.transaction.type === 'REFUND';

    return {
      id: 'TEST-CONC-02',
      name: 'Compensating Reversal & Refund Linkage',
      nameHe: 'מנגנון זיכוי מקושר וביטול מפצה ללא מחיקת נתונים',
      category: 'CONCURRENCY',
      passed,
      message: passed
        ? `Refund generated compensating transaction #${refundRes.transaction?.id} linked to parent #${payRes.transaction.id}. Original transaction untouched.`
        : `Refund failed: ${refundRes.error}`,
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testDualControlProposerCannotSelfApprove(): TestResult {
    const start = performance.now();
    const propRes = LedgerEngine.proposeCentralBankOperation({
      type: 'ISSUANCE',
      amountAgorot: 5000000, // 50,000 ILS
      initiatorId: 'OPERATOR-YONATAN',
      initiatorName: 'Yonatan S. (Operations Desk)',
      targetAccountId: 'W-SETTLE-HAPOALIM',
      reason: 'Dual control security verification',
      reasonHe: 'מבדק אבטחת בקרה כפולה',
    });

    if (!propRes.success || !propRes.operation) {
      return {
        id: 'TEST-CB-01',
        name: 'Dual-Control Four-Eyes Principle Enforcement',
        nameHe: 'אכיפת עקרון הבקרה הכפולה (איסור אישור עצמי של הנפקה)',
        category: 'ISSUANCE',
        passed: false,
        message: 'Proposal failed.',
        durationMs: 0,
      };
    }

    // Proposer attempts to approve their own proposal
    const approveRes = LedgerEngine.approveCentralBankOperation({
      operationId: propRes.operation.id,
      approverId: 'OPERATOR-YONATAN', // Same ID!
      approverName: 'Yonatan S. (Attempting self-approval)',
    });

    const passed = !approveRes.success && approveRes.error?.includes('Four-Eyes Principle');

    return {
      id: 'TEST-CB-01',
      name: 'Dual-Control Four-Eyes Principle Enforcement',
      nameHe: 'אכיפת עקרון הבקרה הכפולה (איסור אישור עצמי של הנפקה)',
      category: 'ISSUANCE',
      passed: !!passed,
      message: passed
        ? 'Self-approval was blocked: proposer cannot approve their own monetary operation.'
        : 'Four-eyes principle was breached!',
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testRedemptionCannotExceedReserveBalance(): TestResult {
    const start = performance.now();
    const reserve = db.wallets.get('W-SETTLE-HAPOALIM');
    const excessiveRedeem = (reserve?.balanceAgorot || 0) + 1000000000;

    const propRes = LedgerEngine.proposeCentralBankOperation({
      type: 'REDEMPTION',
      amountAgorot: excessiveRedeem,
      initiatorId: 'DESK-A',
      initiatorName: 'Desk Officer A',
      targetAccountId: 'W-SETTLE-HAPOALIM',
      reason: 'Redemption limit check',
      reasonHe: 'בדיקת תקרת משיכה מול יתרת המסלקה',
    });

    const passed = !propRes.success && propRes.error?.includes('less than');

    return {
      id: 'TEST-CB-02',
      name: 'Currency Redemption Capped by Target Reserve Balance',
      nameHe: 'הגבלת פדיון ומשיכת מטבע עד גובה יתרת המסלקה הקיימת',
      category: 'ISSUANCE',
      passed: !!passed,
      message: passed
        ? 'Attempted redemption exceeding reserve balance was rejected.'
        : 'Redemption exceeded permissible reserve.',
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testPrivacyTierAssignmentByValue(): TestResult {
    const start = performance.now();
    const tier1 = LedgerEngine.postTransfer({
      senderWalletId: 'W-NOA-03',
      recipientWalletId: 'W-DAVID-02',
      amountAgorot: 15000, // 150 ILS < 500 ILS
      description: 'Coffee and snacks',
    });

    const tier3 = LedgerEngine.postTransfer({
      senderWalletId: 'W-SETTLE-LEUMI',
      recipientWalletId: 'W-SETTLE-HAPOALIM',
      amountAgorot: 600000, // 6,000 ILS > 5,000 ILS
      description: 'Major interbank liquidity transfer',
    });

    const passed =
      tier1.success &&
      tier1.transaction?.privacyTier === 'TIER_1_RETAIL' &&
      tier3.success &&
      tier3.transaction?.privacyTier === 'TIER_3_INSTITUTIONAL';

    return {
      id: 'TEST-PRIV-01',
      name: 'Tiered Privacy Classification by Amount Thresholds',
      nameHe: 'סיווג מדורג של רמות פרטיות לפי גובה סכום ההעברה',
      category: 'PRIVACY',
      passed,
      message: passed
        ? '150 ₪ classified as TIER_1_RETAIL (data minimization); 6,000 ₪ classified as TIER_3_INSTITUTIONAL (AML review flag triggered).'
        : `Privacy tier test failed: tier1(${tier1.success}, err=${tier1.error}, tier=${tier1.transaction?.privacyTier}), tier3(${tier3.success}, err=${tier3.error}, tier=${tier3.transaction?.privacyTier})`,
      durationMs: Math.round(performance.now() - start),
    };
  }

  private static testVelocityDailyLimitEnforcement(): TestResult {
    const start = performance.now();
    const david = db.wallets.get('W-DAVID-02');
    if (!david) {
      return {
        id: 'TEST-PRIV-02',
        name: 'Velocity Check & Daily Spending Ceiling',
        nameHe: 'אכיפת מגבלת סכום יומית ומניעת פריצת תקרת פעילות',
        category: 'PRIVACY',
        passed: false,
        message: 'Wallet not found',
        durationMs: 0,
      };
    }

    // Set spent today near limit
    david.spentTodayAgorot = david.dailyLimitAgorot - 1000; // 10 ILS left
    const attemptTransfer = LedgerEngine.postTransfer({
      senderWalletId: 'W-DAVID-02',
      recipientWalletId: 'W-MAYA-01',
      amountAgorot: 5000, // 50 ILS exceeds limit!
    });

    const passed = !attemptTransfer.success && attemptTransfer.error?.includes('Daily spending limit');
    david.spentTodayAgorot = 0; // Reset for demo state

    return {
      id: 'TEST-PRIV-02',
      name: 'Velocity Check & Daily Spending Ceiling',
      nameHe: 'אכיפת מגבלת סכום יומית ומניעת פריצת תקרת פעילות',
      category: 'PRIVACY',
      passed: !!passed,
      message: passed
        ? 'Daily spending limit hard-cap was enforced as expected.'
        : 'Velocity ceiling failed.',
      durationMs: Math.round(performance.now() - start),
    };
  }
}
