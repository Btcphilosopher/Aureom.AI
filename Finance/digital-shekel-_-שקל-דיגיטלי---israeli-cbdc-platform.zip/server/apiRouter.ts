import { Router, Request, Response } from 'express';
import { db } from './cbdcState';
import { LedgerEngine } from './ledgerEngine';
import { TestEngine } from './testEngine';

export const apiRouter = Router();

// ==========================================
// 1. WALLETS & PROFILES
// ==========================================

apiRouter.get('/wallets', (req: Request, res: Response) => {
  const wallets = Array.from(db.wallets.values());
  res.json({ success: true, wallets });
});

apiRouter.get('/wallets/:id', (req: Request, res: Response) => {
  const wallet = db.wallets.get(req.params.id);
  if (!wallet) {
    return res.status(404).json({ success: false, error: 'Wallet not found' });
  }
  res.json({ success: true, wallet });
});

apiRouter.get('/wallets/:id/transactions', (req: Request, res: Response) => {
  const walletId = req.params.id;
  const txs = db.transactions.filter(
    (tx) => tx.senderWalletId === walletId || tx.recipientWalletId === walletId
  );
  res.json({ success: true, transactions: txs });
});

apiRouter.post('/wallets/:id/topup', (req: Request, res: Response) => {
  const walletId = req.params.id;
  const { amountAgorot } = req.body;

  const result = LedgerEngine.topUpFromCommercialBank({
    walletId,
    amountAgorot: Number(amountAgorot),
  });

  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

// ==========================================
// 2. PAYMENTS & TRANSFERS
// ==========================================

apiRouter.post('/payments', (req: Request, res: Response) => {
  const {
    senderWalletId,
    recipientWalletId,
    amountAgorot,
    description,
    descriptionHe,
    idempotencyKey,
  } = req.body;

  const result = LedgerEngine.postTransfer({
    senderWalletId,
    recipientWalletId,
    amountAgorot: Number(amountAgorot),
    description,
    descriptionHe,
    idempotencyKey,
    type: 'P2P_TRANSFER',
  });

  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

// ==========================================
// 3. MERCHANT POINT OF SALE & DYNAMIC QR
// ==========================================

apiRouter.post('/payment-requests', (req: Request, res: Response) => {
  const { merchantWalletId, amountAgorot, referenceNote } = req.body;

  const result = LedgerEngine.createPaymentRequest({
    merchantWalletId,
    amountAgorot: Number(amountAgorot),
    referenceNote,
  });

  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

apiRouter.get('/payment-requests/:id', (req: Request, res: Response) => {
  const pr = db.paymentRequests.get(req.params.id);
  if (!pr) {
    return res.status(404).json({ success: false, error: 'Payment request not found' });
  }

  // Check if expired
  if (pr.status === 'PENDING' && new Date(pr.expiresAt).getTime() < Date.now()) {
    pr.status = 'EXPIRED';
  }

  res.json({ success: true, paymentRequest: pr });
});

apiRouter.post('/payment-requests/:id/confirm', (req: Request, res: Response) => {
  const pr = db.paymentRequests.get(req.params.id);
  if (!pr) {
    return res.status(404).json({ success: false, error: 'Payment request not found' });
  }

  if (pr.status !== 'PENDING') {
    return res.status(400).json({ success: false, error: `Payment request is already ${pr.status}` });
  }

  if (new Date(pr.expiresAt).getTime() < Date.now()) {
    pr.status = 'EXPIRED';
    return res.status(400).json({ success: false, error: 'Payment request has expired' });
  }

  const { payerWalletId } = req.body;
  if (!payerWalletId) {
    return res.status(400).json({ success: false, error: 'Payer wallet ID is required' });
  }

  // Execute payment from consumer to merchant
  const transferRes = LedgerEngine.postTransfer({
    senderWalletId: payerWalletId,
    recipientWalletId: pr.merchantWalletId,
    amountAgorot: pr.amountAgorot,
    description: `Merchant Checkout: ${pr.referenceNote}`,
    descriptionHe: `תשלום לבית עסק: ${pr.referenceNote}`,
    idempotencyKey: `PR-CONFIRM-${pr.id}`,
    type: 'MERCHANT_PAYMENT',
  });

  if (!transferRes.success) {
    return res.status(400).json(transferRes);
  }

  pr.status = 'COMPLETED';
  pr.completedPaymentId = transferRes.transaction?.id;

  res.json({ success: true, paymentRequest: pr, transaction: transferRes.transaction });
});

apiRouter.post('/refunds', (req: Request, res: Response) => {
  const { originalTransactionId, merchantWalletId, reason } = req.body;

  const result = LedgerEngine.executeRefund({
    originalTransactionId,
    merchantWalletId,
    reason,
  });

  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

// ==========================================
// 4. GENERAL LEDGER & AUDIT
// ==========================================

apiRouter.get('/ledger/entries', (req: Request, res: Response) => {
  const accountFilter = req.query.accountId as string;
  const entries = accountFilter
    ? db.ledgerEntries.filter((e) => e.accountId === accountFilter)
    : db.ledgerEntries;

  res.json({
    success: true,
    entries: entries.slice().reverse(), // Latest first
    totalCount: entries.length,
  });
});

apiRouter.get('/ledger/stats', (req: Request, res: Response) => {
  const stats = LedgerEngine.getMonetarySupplyStats();
  res.json({ success: true, stats });
});

// ==========================================
// 5. CENTRAL BANK ENGINE & DUAL CONTROL
// ==========================================

apiRouter.get('/central-bank/operations', (req: Request, res: Response) => {
  const ops = Array.from(db.centralBankOps.values()).reverse();
  res.json({ success: true, operations: ops });
});

apiRouter.post('/central-bank/operations', (req: Request, res: Response) => {
  const { type, amountAgorot, initiatorId, initiatorName, targetAccountId, reason, reasonHe } = req.body;

  const result = LedgerEngine.proposeCentralBankOperation({
    type,
    amountAgorot: Number(amountAgorot),
    initiatorId,
    initiatorName,
    targetAccountId,
    reason,
    reasonHe,
  });

  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

apiRouter.post('/central-bank/operations/:id/approve', (req: Request, res: Response) => {
  const { approverId, approverName } = req.body;

  const result = LedgerEngine.approveCentralBankOperation({
    operationId: req.params.id,
    approverId,
    approverName,
  });

  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

apiRouter.post('/central-bank/operations/:id/reject', (req: Request, res: Response) => {
  const { approverId, approverName } = req.body;

  const result = LedgerEngine.rejectCentralBankOperation({
    operationId: req.params.id,
    approverId,
    approverName,
  });

  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

// ==========================================
// 6. COMPLIANCE & RISK ALERTS
// ==========================================

apiRouter.get('/compliance/alerts', (req: Request, res: Response) => {
  const alerts = Array.from(db.riskAlerts.values()).reverse();
  res.json({ success: true, alerts });
});

apiRouter.post('/compliance/alerts/:id/action', (req: Request, res: Response) => {
  const alert = db.riskAlerts.get(req.params.id);
  if (!alert) {
    return res.status(404).json({ success: false, error: 'Alert not found' });
  }

  const { action, notes } = req.body; // 'CLEAR' | 'RESTRICT'
  if (action === 'CLEAR') {
    alert.status = 'CLEARED';
    if (notes) alert.caseNotes = (alert.caseNotes ? `${alert.caseNotes}\n` : '') + `[CLEARED]: ${notes}`;
  } else if (action === 'RESTRICT') {
    alert.status = 'RESTRICTED';
    if (notes) alert.caseNotes = (alert.caseNotes ? `${alert.caseNotes}\n` : '') + `[RESTRICTED]: ${notes}`;
    const wallet = db.wallets.get(alert.walletId);
    if (wallet) {
      wallet.status = 'RESTRICTED';
    }
  }

  res.json({ success: true, alert });
});

// ==========================================
// 7. AUTOMATED TESTS RUNNER
// ==========================================

apiRouter.get('/tests/run', (req: Request, res: Response) => {
  const results = TestEngine.runAllTests();
  const passedCount = results.filter((r) => r.passed).length;
  const failedCount = results.filter((r) => !r.passed).length;

  res.json({
    success: true,
    results,
    summary: {
      total: results.length,
      passed: passedCount,
      failed: failedCount,
      allPassed: failedCount === 0,
    },
  });
});
