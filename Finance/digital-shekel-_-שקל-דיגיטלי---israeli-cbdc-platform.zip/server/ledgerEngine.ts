/**
 * Digital Shekel (שקל דיגיטלי) - Authoritative Double-Entry Ledger Engine
 *
 * Mathematical Invariants:
 * 1. Conservation of Money: Outstanding Supply = Cumulative Issued − Cumulative Redeemed
 * 2. Every transaction balances: Sum(Debits) == Sum(Credits)
 * 3. Exact integer arithmetic in Agorot (1 ILS = 100 Agorot) - No binary floating point rounding.
 * 4. Append-only ledger: No posted transaction is ever mutated or deleted. Corrections are strictly compensating reversals.
 * 5. Concurrency & Idempotency: Duplicate submissions with the same idempotency key are safely deduplicated.
 */

import crypto from 'crypto';
import {
  Agorot,
  CBDCTransaction,
  LedgerEntry,
  PaymentRequest,
  CentralBankOperation,
  MonetarySupplyStats,
  RiskAlert,
  getPrivacyTier,
  UserWallet,
} from '../src/types/cbdc';
import { db } from './cbdcState';

let entryCounter = 1;
function nextEntryId(prefix = 'LE'): string {
  const rand = crypto.randomBytes(3).toString('hex');
  return `${prefix}-${Date.now()}-${entryCounter++}-${rand}`;
}

export class LedgerEngine {
  /**
   * Post a transfer between wallets with strict double-entry balancing.
   */
  public static postTransfer(params: {
    senderWalletId: string;
    recipientWalletId: string;
    amountAgorot: Agorot;
    description?: string;
    descriptionHe?: string;
    idempotencyKey?: string;
    type?: 'P2P_TRANSFER' | 'MERCHANT_PAYMENT' | 'REFUND' | 'COMMERCIAL_SETTLEMENT';
    parentTransactionId?: string;
  }): { success: boolean; transaction?: CBDCTransaction; error?: string } {
    const {
      senderWalletId,
      recipientWalletId,
      amountAgorot,
      description = 'CBDC Digital Transfer',
      descriptionHe = 'העברת שקל דיגיטלי',
      idempotencyKey = `IDEMP-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      type = 'P2P_TRANSFER',
      parentTransactionId,
    } = params;

    // Check idempotency first
    if (idempotencyKey && db.idempotencyStore.has(idempotencyKey)) {
      return { success: true, transaction: db.idempotencyStore.get(idempotencyKey)! };
    }

    // Input validations
    if (amountAgorot <= 0 || !Number.isInteger(amountAgorot)) {
      return { success: false, error: 'Transfer amount must be a positive integer in Agorot.' };
    }

    if (senderWalletId === recipientWalletId) {
      return { success: false, error: 'Sender and recipient wallets must be distinct.' };
    }

    const sender = db.wallets.get(senderWalletId);
    const recipient = db.wallets.get(recipientWalletId);

    if (!sender) {
      return { success: false, error: `Sender wallet ${senderWalletId} not found.` };
    }
    if (!recipient) {
      return { success: false, error: `Recipient wallet ${recipientWalletId} not found.` };
    }

    if (sender.status !== 'ACTIVE') {
      return { success: false, error: `Sender wallet is currently ${sender.status}.` };
    }
    if (recipient.status !== 'ACTIVE') {
      return { success: false, error: `Recipient wallet is currently ${recipient.status}.` };
    }

    // Solvency check (No Overdrafts permitted in CBDC retail model)
    if (sender.balanceAgorot < amountAgorot) {
      return {
        success: false,
        error: `Insufficient funds. Available: ${(sender.balanceAgorot / 100).toFixed(2)} ₪, Requested: ${(amountAgorot / 100).toFixed(2)} ₪.`,
      };
    }

    // Velocity / Daily limit check
    if (sender.role === 'CONSUMER' && sender.spentTodayAgorot + amountAgorot > sender.dailyLimitAgorot) {
      return {
        success: false,
        error: `Daily spending limit exceeded. Limit: ${(sender.dailyLimitAgorot / 100).toFixed(2)} ₪, Already spent today: ${(sender.spentTodayAgorot / 100).toFixed(2)} ₪.`,
      };
    }

    const txId = `TX-${Date.now()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    const timestamp = new Date().toISOString();
    const privacyTier = getPrivacyTier(amountAgorot);

    // Cryptographic hash digest for tamper evidence
    const hashData = `${txId}|${idempotencyKey}|${senderWalletId}|${recipientWalletId}|${amountAgorot}|${timestamp}`;
    const referenceHash = crypto.createHash('sha256').update(hashData).digest('hex');

    // Double-Entry accounting entries:
    // Debit Recipient (increasing asset/balance)
    // Credit Sender (decreasing asset/balance)
    const entry1: LedgerEntry = {
      id: nextEntryId('LE-TR-DR'),
      transactionId: txId,
      accountId: recipientWalletId,
      accountName: recipient.holderName,
      type: 'DEBIT',
      amountAgorot,
      currency: 'ILS',
      timestamp,
    };

    const entry2: LedgerEntry = {
      id: nextEntryId('LE-TR-CR'),
      transactionId: txId,
      accountId: senderWalletId,
      accountName: sender.holderName,
      type: 'CREDIT',
      amountAgorot,
      currency: 'ILS',
      timestamp,
    };

    // Assert double-entry invariant: Sum(Debits) == Sum(Credits)
    const totalDebits = entry1.amountAgorot;
    const totalCredits = entry2.amountAgorot;
    if (totalDebits !== totalCredits) {
      throw new Error(`CRITICAL LEDGER FAULT: Debits (${totalDebits}) != Credits (${totalCredits})`);
    }

    // Atomically update wallet balances
    sender.balanceAgorot -= amountAgorot;
    sender.spentTodayAgorot += amountAgorot;
    recipient.balanceAgorot += amountAgorot;

    const transaction: CBDCTransaction = {
      id: txId,
      idempotencyKey,
      type,
      status: 'POSTED',
      senderWalletId,
      senderName: sender.holderName,
      senderNameHe: sender.holderNameHe,
      recipientWalletId,
      recipientName: recipient.holderName,
      recipientNameHe: recipient.holderNameHe,
      amountAgorot,
      description,
      descriptionHe,
      privacyTier,
      timestamp,
      postedAt: timestamp,
      referenceHash,
      parentTransactionId,
      entries: [entry1, entry2],
    };

    // Append to immutable ledger
    db.ledgerEntries.push(entry1, entry2);
    db.transactions.unshift(transaction);
    db.idempotencyStore.set(idempotencyKey, transaction);

    // Trigger synthetic risk monitoring for high value or rapid velocity
    if (amountAgorot >= 500000) { // >= ₪5,000
      const alertId = `ALERT-${Date.now()}`;
      db.riskAlerts.set(alertId, {
        id: alertId,
        transactionId: txId,
        walletId: senderWalletId,
        walletName: sender.holderName,
        ruleTriggered: 'Statutory threshold exceeded (Tier 3 Institutional transfer > ₪5,000)',
        ruleTriggeredHe: 'חריגה מרף תשלום קמעונאי רגיל (העברה מעל ₪5,000 המחייבת בדיקה)',
        severity: 'HIGH',
        status: 'PENDING_REVIEW',
        caseNotes: 'Automatic flag for high-value CBDC transaction monitoring.',
        timestamp,
      });
    }

    return { success: true, transaction };
  }

  /**
   * Execute an authorized compensating refund for a merchant payment.
   * Creates reverse balancing entries linked to the original transaction.
   */
  public static executeRefund(params: {
    originalTransactionId: string;
    merchantWalletId: string;
    reason?: string;
  }): { success: boolean; transaction?: CBDCTransaction; error?: string } {
    const { originalTransactionId, merchantWalletId, reason = 'Customer refund request' } = params;

    const originalTx = db.transactions.find((tx) => tx.id === originalTransactionId);
    if (!originalTx) {
      return { success: false, error: 'Original transaction not found.' };
    }

    if (originalTx.recipientWalletId !== merchantWalletId) {
      return { success: false, error: 'Only the original recipient merchant can initiate this refund.' };
    }

    if (!originalTx.senderWalletId) {
      return { success: false, error: 'Original sender wallet cannot be determined.' };
    }

    const merchant = db.wallets.get(merchantWalletId);
    if (!merchant || merchant.balanceAgorot < originalTx.amountAgorot) {
      return { success: false, error: 'Merchant balance is insufficient to process this refund.' };
    }

    // Execute compensating transfer from merchant back to consumer
    const refundResult = this.postTransfer({
      senderWalletId: merchantWalletId,
      recipientWalletId: originalTx.senderWalletId,
      amountAgorot: originalTx.amountAgorot,
      description: `Refund for TX #${originalTransactionId}: ${reason}`,
      descriptionHe: `החזר כספי לעסקה #${originalTransactionId}: ${reason}`,
      idempotencyKey: `REFUND-${originalTransactionId}`,
      type: 'REFUND',
      parentTransactionId: originalTransactionId,
    });

    return refundResult;
  }

  /**
   * Create a dynamic payment request for merchant point of sale.
   */
  public static createPaymentRequest(params: {
    merchantWalletId: string;
    amountAgorot: Agorot;
    referenceNote?: string;
  }): { success: boolean; paymentRequest?: PaymentRequest; error?: string } {
    const { merchantWalletId, amountAgorot, referenceNote = 'Counter Sale' } = params;
    const merchant = db.wallets.get(merchantWalletId);

    if (!merchant || merchant.role !== 'MERCHANT') {
      return { success: false, error: 'Invalid merchant account.' };
    }

    if (amountAgorot <= 0) {
      return { success: false, error: 'Amount must be greater than zero.' };
    }

    const requestId = `PR-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString(); // 5 minutes validity

    // Structured opaque QR payload
    const qrPayload = JSON.stringify({
      protocol: 'IL-CBDC-QR-V1',
      requestId,
      merchantId: merchantWalletId,
      amountAgorot,
      note: referenceNote,
      expiresAt,
    });

    const paymentRequest: PaymentRequest = {
      id: requestId,
      merchantWalletId,
      merchantName: merchant.holderName,
      merchantNameHe: merchant.holderNameHe,
      amountAgorot,
      referenceNote,
      status: 'PENDING',
      qrPayload,
      expiresAt,
      createdAt: new Date().toISOString(),
    };

    db.paymentRequests.set(requestId, paymentRequest);
    return { success: true, paymentRequest };
  }

  /**
   * Propose a privileged Central Bank Operation (Issuance or Redemption).
   * Enforces dual-control workflow (Four-Eyes Principle).
   */
  public static proposeCentralBankOperation(params: {
    type: 'ISSUANCE' | 'REDEMPTION';
    amountAgorot: Agorot;
    initiatorId: string;
    initiatorName: string;
    targetAccountId: string;
    reason: string;
    reasonHe: string;
  }): { success: boolean; operation?: CentralBankOperation; error?: string } {
    const { type, amountAgorot, initiatorId, initiatorName, targetAccountId, reason, reasonHe } = params;

    if (amountAgorot <= 0) {
      return { success: false, error: 'Amount must be positive.' };
    }

    const targetAccount = db.wallets.get(targetAccountId);
    if (!targetAccount) {
      return { success: false, error: 'Target account not found.' };
    }

    if (type === 'REDEMPTION' && targetAccount.balanceAgorot < amountAgorot) {
      return { success: false, error: 'Cannot redeem currency: target account balance is less than requested redemption amount.' };
    }

    const opId = `CBO-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
    const operation: CentralBankOperation = {
      id: opId,
      type,
      amountAgorot,
      initiatorId,
      initiatorName,
      status: 'PROPOSED',
      targetAccountId,
      targetAccountName: targetAccount.holderName,
      reason,
      reasonHe,
      timestamp: new Date().toISOString(),
    };

    db.centralBankOps.set(opId, operation);
    return { success: true, operation };
  }

  /**
   * Approve and execute a Central Bank Operation with Four-Eyes principle.
   */
  public static approveCentralBankOperation(params: {
    operationId: string;
    approverId: string;
    approverName: string;
  }): { success: boolean; operation?: CentralBankOperation; error?: string } {
    const { operationId, approverId, approverName } = params;
    const op = db.centralBankOps.get(operationId);

    if (!op) {
      return { success: false, error: 'Operation not found.' };
    }

    if (op.status !== 'PROPOSED') {
      return { success: false, error: `Operation is already ${op.status}.` };
    }

    // Enforce Four-Eyes Principle: Proposer cannot be the Approver
    if (op.initiatorId === approverId) {
      return {
        success: false,
        error: 'Four-Eyes Principle violation: The initiator cannot approve their own monetary operation proposal.',
      };
    }

    const targetAccount = db.wallets.get(op.targetAccountId);
    if (!targetAccount) {
      return { success: false, error: 'Target account no longer exists.' };
    }

    const txId = `TX-${op.type}-${Date.now()}`;
    const timestamp = new Date().toISOString();
    const vaultAccountId = 'CB-ISSUANCE-MINT';

    let entry1: LedgerEntry;
    let entry2: LedgerEntry;

    if (op.type === 'ISSUANCE') {
      // Credit Vault (Contra-Liability), Debit Target Reserve (Circulating Asset)
      entry1 = {
        id: nextEntryId('LE-CB-DR'),
        transactionId: txId,
        accountId: targetAccount.id,
        accountName: targetAccount.holderName,
        type: 'DEBIT',
        amountAgorot: op.amountAgorot,
        currency: 'ILS',
        timestamp,
      };
      entry2 = {
        id: nextEntryId('LE-CB-CR'),
        transactionId: txId,
        accountId: vaultAccountId,
        accountName: 'Central Bank Digital Currency Issuance Vault',
        type: 'CREDIT',
        amountAgorot: op.amountAgorot,
        currency: 'ILS',
        timestamp,
      };

      targetAccount.balanceAgorot += op.amountAgorot;
      db.cumulativeIssuedAgorot += op.amountAgorot;
    } else {
      // Redemption: Debit Vault, Credit Target Reserve (Withdrawing from circulation)
      if (targetAccount.balanceAgorot < op.amountAgorot) {
        return { success: false, error: 'Target reserve balance is insufficient for redemption withdrawal.' };
      }

      entry1 = {
        id: nextEntryId('LE-CB-DR'),
        transactionId: txId,
        accountId: vaultAccountId,
        accountName: 'Central Bank Digital Currency Issuance Vault',
        type: 'DEBIT',
        amountAgorot: op.amountAgorot,
        currency: 'ILS',
        timestamp,
      };
      entry2 = {
        id: nextEntryId('LE-CB-CR'),
        transactionId: txId,
        accountId: targetAccount.id,
        accountName: targetAccount.holderName,
        type: 'CREDIT',
        amountAgorot: op.amountAgorot,
        currency: 'ILS',
        timestamp,
      };

      targetAccount.balanceAgorot -= op.amountAgorot;
      db.cumulativeRedeemedAgorot += op.amountAgorot;
    }

    // Append to authoritative ledger
    db.ledgerEntries.push(entry1, entry2);

    const hashData = `${txId}|${op.type}|${op.amountAgorot}|${op.initiatorId}|${approverId}|${timestamp}`;
    const referenceHash = crypto.createHash('sha256').update(hashData).digest('hex');

    const tx: CBDCTransaction = {
      id: txId,
      idempotencyKey: `IDEMP-${op.id}`,
      type: op.type,
      status: 'POSTED',
      amountAgorot: op.amountAgorot,
      description: `Authorized Central Bank ${op.type}: ${op.reason}`,
      descriptionHe: `פעולת ${op.type === 'ISSUANCE' ? 'הנפקה' : 'משיכה'} מאושרת: ${op.reasonHe}`,
      privacyTier: 'TIER_3_INSTITUTIONAL',
      timestamp,
      postedAt: timestamp,
      referenceHash,
      entries: [entry1, entry2],
    };

    db.transactions.unshift(tx);

    op.status = 'APPROVED';
    op.approverId = approverId;
    op.approverName = approverName;
    op.approvedAt = timestamp;
    op.ledgerTransactionId = txId;

    return { success: true, operation: op };
  }

  /**
   * Reject a Central Bank Operation proposal.
   */
  public static rejectCentralBankOperation(params: {
    operationId: string;
    approverId: string;
    approverName: string;
  }): { success: boolean; operation?: CentralBankOperation; error?: string } {
    const { operationId, approverId, approverName } = params;
    const op = db.centralBankOps.get(operationId);

    if (!op || op.status !== 'PROPOSED') {
      return { success: false, error: 'Operation not pending.' };
    }

    op.status = 'REJECTED';
    op.approverId = approverId;
    op.approverName = approverName;
    op.approvedAt = new Date().toISOString();

    return { success: true, operation: op };
  }

  /**
   * Compute authoritative Money Supply and Ledger Conservation Statistics.
   */
  public static getMonetarySupplyStats(): MonetarySupplyStats {
    let totalLedgerDebitsAgorot = 0;
    let totalLedgerCreditsAgorot = 0;

    for (const entry of db.ledgerEntries) {
      if (entry.type === 'DEBIT') {
        totalLedgerDebitsAgorot += entry.amountAgorot;
      } else {
        totalLedgerCreditsAgorot += entry.amountAgorot;
      }
    }

    let totalRetailAgorot = 0;
    let totalMerchantAgorot = 0;
    let totalSettlementAgorot = 0;

    for (const [id, wallet] of db.wallets) {
      if (id === 'CB-ISSUANCE-MINT') continue;
      if (wallet.role === 'CONSUMER') {
        totalRetailAgorot += wallet.balanceAgorot;
      } else if (wallet.role === 'MERCHANT') {
        totalMerchantAgorot += wallet.balanceAgorot;
      } else if (wallet.role === 'CENTRAL_BANK_OPERATOR' && id.startsWith('W-SETTLE-')) {
        totalSettlementAgorot += wallet.balanceAgorot;
      }
    }

    const outstandingSupplyAgorot = db.cumulativeIssuedAgorot - db.cumulativeRedeemedAgorot;
    const totalInCirculationFromWallets = totalRetailAgorot + totalMerchantAgorot + totalSettlementAgorot;
    const reconciliationDifferenceAgorot = Math.abs(outstandingSupplyAgorot - totalInCirculationFromWallets);

    const isLedgerBalanced =
      totalLedgerDebitsAgorot === totalLedgerCreditsAgorot && reconciliationDifferenceAgorot === 0;

    return {
      cumulativeIssuedAgorot: db.cumulativeIssuedAgorot,
      cumulativeRedeemedAgorot: db.cumulativeRedeemedAgorot,
      outstandingSupplyAgorot,
      totalRetailAgorot,
      totalMerchantAgorot,
      totalSettlementAgorot,
      totalLedgerDebitsAgorot,
      totalLedgerCreditsAgorot,
      isLedgerBalanced,
      reconciliationDifferenceAgorot,
    };
  }

  /**
   * Deposit synthetic funds into a consumer wallet from an external commercial bank simulator.
   */
  public static topUpFromCommercialBank(params: {
    walletId: string;
    amountAgorot: Agorot;
  }): { success: boolean; transaction?: CBDCTransaction; error?: string } {
    const { walletId, amountAgorot } = params;
    const commercialReserveId = 'W-SETTLE-LEUMI';

    return this.postTransfer({
      senderWalletId: commercialReserveId,
      recipientWalletId: walletId,
      amountAgorot,
      description: 'Commercial Bank Account Transfer into Digital Shekel Wallet',
      descriptionHe: 'טעינת ארנק דיגיטלי בהעברה מחשבון עו״ש בנקאי',
      type: 'COMMERCIAL_SETTLEMENT' as any,
    });
  }
}
