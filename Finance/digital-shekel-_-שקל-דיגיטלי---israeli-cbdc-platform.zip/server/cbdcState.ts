/**
 * Digital Shekel (שקל דיגיטלי) - In-Memory State & Synthetic Israeli Seed Data
 * All amounts are strictly in integer Agorot (1 ILS = 100 Agorot).
 */

import {
  UserWallet,
  CBDCTransaction,
  PaymentRequest,
  CentralBankOperation,
  RiskAlert,
  LedgerEntry,
} from '../src/types/cbdc';

export interface CBDCDatabase {
  wallets: Map<string, UserWallet>;
  transactions: CBDCTransaction[];
  ledgerEntries: LedgerEntry[];
  paymentRequests: Map<string, PaymentRequest>;
  centralBankOps: Map<string, CentralBankOperation>;
  riskAlerts: Map<string, RiskAlert>;
  idempotencyStore: Map<string, CBDCTransaction>;
  cumulativeIssuedAgorot: number;
  cumulativeRedeemedAgorot: number;
}

export function createInitialSeedState(): CBDCDatabase {
  const wallets = new Map<string, UserWallet>();
  const paymentRequests = new Map<string, PaymentRequest>();
  const centralBankOps = new Map<string, CentralBankOperation>();
  const riskAlerts = new Map<string, RiskAlert>();
  const idempotencyStore = new Map<string, CBDCTransaction>();
  const transactions: CBDCTransaction[] = [];
  const ledgerEntries: LedgerEntry[] = [];

  // 1. Central Bank & Institutional Settlement Wallets
  const cbMintWallet: UserWallet = {
    id: 'CB-ISSUANCE-MINT',
    identityMasked: 'BOI-MINT-001',
    holderName: 'Central Bank Digital Currency Issuance Vault',
    holderNameHe: 'כספת הנפקה - בנק ישראל (סימולטור)',
    phoneAlias: 'BOI-MINT',
    role: 'CENTRAL_BANK_OPERATOR',
    balanceAgorot: 0,
    reservedAgorot: 0,
    status: 'ACTIVE',
    dailyLimitAgorot: 10000000000, // 100M ILS
    spentTodayAgorot: 0,
    privacySetting: 'DEFAULT',
    createdAt: '2026-01-01T00:00:00.000Z',
  };
  wallets.set(cbMintWallet.id, cbMintWallet);

  const settleLeumi: UserWallet = {
    id: 'W-SETTLE-LEUMI',
    identityMasked: 'LEUMI-SETTLE-501',
    holderName: 'Bank Leumi Settlement Reserve',
    holderNameHe: 'בנק לאומי - עתודת סליקה בינבנקאית',
    phoneAlias: 'LEUMI-CBDC',
    role: 'CENTRAL_BANK_OPERATOR',
    balanceAgorot: 25000000, // 250,000 ILS
    reservedAgorot: 0,
    status: 'ACTIVE',
    dailyLimitAgorot: 5000000000,
    spentTodayAgorot: 0,
    privacySetting: 'DEFAULT',
    createdAt: '2026-01-01T00:00:00.000Z',
  };
  wallets.set(settleLeumi.id, settleLeumi);

  const settleHapoalim: UserWallet = {
    id: 'W-SETTLE-HAPOALIM',
    identityMasked: 'HAPOALIM-SETTLE-502',
    holderName: 'Bank Hapoalim Settlement Reserve',
    holderNameHe: 'בנק הפועלים - עתודת סליקה בינבנקאית',
    phoneAlias: 'POALIM-CBDC',
    role: 'CENTRAL_BANK_OPERATOR',
    balanceAgorot: 35000000, // 350,000 ILS
    reservedAgorot: 0,
    status: 'ACTIVE',
    dailyLimitAgorot: 5000000000,
    spentTodayAgorot: 0,
    privacySetting: 'DEFAULT',
    createdAt: '2026-01-01T00:00:00.000Z',
  };
  wallets.set(settleHapoalim.id, settleHapoalim);

  // 2. Synthetic Retail Consumer Wallets
  const mayaWallet: UserWallet = {
    id: 'W-MAYA-01',
    identityMasked: '034****89',
    holderName: 'Maya Cohen',
    holderNameHe: 'מיה כהן',
    phoneAlias: '050-7123456',
    role: 'CONSUMER',
    balanceAgorot: 125000, // 1,250.00 ILS
    reservedAgorot: 0,
    status: 'ACTIVE',
    dailyLimitAgorot: 500000, // 5,000 ILS daily limit
    spentTodayAgorot: 4500,   // 45.00 ILS spent today
    privacySetting: 'MAXIMUM_MINIMIZATION',
    createdAt: '2026-01-15T09:30:00.000Z',
  };
  wallets.set(mayaWallet.id, mayaWallet);

  const davidWallet: UserWallet = {
    id: 'W-DAVID-02',
    identityMasked: '028****12',
    holderName: 'David Levi',
    holderNameHe: 'דוד לוי',
    phoneAlias: '052-8987654',
    role: 'CONSUMER',
    balanceAgorot: 48000, // 480.00 ILS
    reservedAgorot: 0,
    status: 'ACTIVE',
    dailyLimitAgorot: 500000,
    spentTodayAgorot: 0,
    privacySetting: 'DEFAULT',
    createdAt: '2026-01-20T11:15:00.000Z',
  };
  wallets.set(davidWallet.id, davidWallet);

  const noaWallet: UserWallet = {
    id: 'W-NOA-03',
    identityMasked: '019****45',
    holderName: 'Noa Ben-David',
    holderNameHe: 'נועה בן דוד',
    phoneAlias: '054-3322110',
    role: 'CONSUMER',
    balanceAgorot: 340000, // 3,400.00 ILS
    reservedAgorot: 0,
    status: 'ACTIVE',
    dailyLimitAgorot: 1000000, // 10,000 ILS
    spentTodayAgorot: 0,
    privacySetting: 'DEFAULT',
    createdAt: '2026-02-01T14:20:00.000Z',
  };
  wallets.set(noaWallet.id, noaWallet);

  // 3. Synthetic Merchant Wallets
  const superPharmWallet: UserWallet = {
    id: 'W-MERCHANT-01',
    identityMasked: '514****32',
    holderName: 'Super-Pharm Dizengoff',
    holderNameHe: 'סופר-פארם דיזנגוף תל אביב',
    phoneAlias: '03-5551234',
    role: 'MERCHANT',
    balanceAgorot: 1420000, // 14,200.00 ILS
    reservedAgorot: 0,
    status: 'ACTIVE',
    dailyLimitAgorot: 50000000,
    spentTodayAgorot: 0,
    privacySetting: 'DEFAULT',
    createdAt: '2026-01-10T08:00:00.000Z',
  };
  wallets.set(superPharmWallet.id, superPharmWallet);

  const aromaWallet: UserWallet = {
    id: 'W-MERCHANT-02',
    identityMasked: '516****98',
    holderName: 'Aroma Cafe Rothschild',
    holderNameHe: 'קפה ארומה שדרות רוטשילד',
    phoneAlias: '03-6667890',
    role: 'MERCHANT',
    balanceAgorot: 685000, // 6,850.00 ILS
    reservedAgorot: 0,
    status: 'ACTIVE',
    dailyLimitAgorot: 20000000,
    spentTodayAgorot: 0,
    privacySetting: 'DEFAULT',
    createdAt: '2026-01-12T10:00:00.000Z',
  };
  wallets.set(aromaWallet.id, aromaWallet);

  // Initial balanced seed issuance:
  // Total in circulation = 250,000 + 350,000 + 1,250 + 480 + 3,400 + 14,200 + 6,850 = 626,180.00 ILS
  // (62,618,000 agorot)
  const totalCirculationAgorot = 62618000;
  const initialIssuanceTxId = 'TX-INIT-ISSUANCE-001';

  // Balanced double entry for initial genesis issuance:
  // DEBIT: Reserves/Wallets (Asset/Liability)
  // CREDIT: CB Issuance Mint Account
  const genesisEntries: LedgerEntry[] = [
    {
      id: 'LE-GEN-001',
      transactionId: initialIssuanceTxId,
      accountId: 'W-SETTLE-LEUMI',
      accountName: 'Bank Leumi Settlement Reserve',
      type: 'DEBIT',
      amountAgorot: 25000000,
      currency: 'ILS',
      timestamp: '2026-01-01T00:00:00.000Z',
    },
    {
      id: 'LE-GEN-002',
      transactionId: initialIssuanceTxId,
      accountId: 'W-SETTLE-HAPOALIM',
      accountName: 'Bank Hapoalim Settlement Reserve',
      type: 'DEBIT',
      amountAgorot: 35000000,
      currency: 'ILS',
      timestamp: '2026-01-01T00:00:00.000Z',
    },
    {
      id: 'LE-GEN-003',
      transactionId: initialIssuanceTxId,
      accountId: 'W-MAYA-01',
      accountName: 'Maya Cohen',
      type: 'DEBIT',
      amountAgorot: 125000,
      currency: 'ILS',
      timestamp: '2026-01-01T00:00:00.000Z',
    },
    {
      id: 'LE-GEN-004',
      transactionId: initialIssuanceTxId,
      accountId: 'W-DAVID-02',
      accountName: 'David Levi',
      type: 'DEBIT',
      amountAgorot: 48000,
      currency: 'ILS',
      timestamp: '2026-01-01T00:00:00.000Z',
    },
    {
      id: 'LE-GEN-005',
      transactionId: initialIssuanceTxId,
      accountId: 'W-NOA-03',
      accountName: 'Noa Ben-David',
      type: 'DEBIT',
      amountAgorot: 340000,
      currency: 'ILS',
      timestamp: '2026-01-01T00:00:00.000Z',
    },
    {
      id: 'LE-GEN-006',
      transactionId: initialIssuanceTxId,
      accountId: 'W-MERCHANT-01',
      accountName: 'Super-Pharm Dizengoff',
      type: 'DEBIT',
      amountAgorot: 1420000,
      currency: 'ILS',
      timestamp: '2026-01-01T00:00:00.000Z',
    },
    {
      id: 'LE-GEN-007',
      transactionId: initialIssuanceTxId,
      accountId: 'W-MERCHANT-02',
      accountName: 'Aroma Cafe Rothschild',
      type: 'DEBIT',
      amountAgorot: 685000,
      currency: 'ILS',
      timestamp: '2026-01-01T00:00:00.000Z',
    },
    {
      id: 'LE-GEN-008',
      transactionId: initialIssuanceTxId,
      accountId: 'CB-ISSUANCE-MINT',
      accountName: 'Central Bank Digital Currency Issuance Vault',
      type: 'CREDIT',
      amountAgorot: totalCirculationAgorot,
      currency: 'ILS',
      timestamp: '2026-01-01T00:00:00.000Z',
    },
  ];

  ledgerEntries.push(...genesisEntries);

  transactions.push({
    id: initialIssuanceTxId,
    idempotencyKey: 'IDEMP-GENESIS-2026-001',
    type: 'ISSUANCE',
    status: 'POSTED',
    recipientWalletId: 'W-SETTLE-LEUMI',
    recipientName: 'Interbank Settlement Consortium',
    recipientNameHe: 'קונסורציום מסלקות בנקאיות',
    amountAgorot: totalCirculationAgorot,
    description: 'Initial Authorized Genesis Minting of Digital Shekel Simulation',
    descriptionHe: 'הנפקה מוניטרית ראשונית מאושרת של שקלים דיגיטליים למחזור',
    privacyTier: 'TIER_3_INSTITUTIONAL',
    timestamp: '2026-01-01T00:00:00.000Z',
    postedAt: '2026-01-01T00:00:00.000Z',
    referenceHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    entries: genesisEntries,
  });

  // Seed sample transactions
  const sampleTx1: CBDCTransaction = {
    id: 'TX-SAMPLE-001',
    idempotencyKey: 'IDEMP-SAMPLE-001',
    type: 'MERCHANT_PAYMENT',
    status: 'POSTED',
    senderWalletId: 'W-MAYA-01',
    senderName: 'Maya Cohen',
    senderNameHe: 'מיה כהן',
    recipientWalletId: 'W-MERCHANT-02',
    recipientName: 'Aroma Cafe Rothschild',
    recipientNameHe: 'קפה ארומה שדרות רוטשילד',
    amountAgorot: 4500, // 45.00 ILS
    description: 'Espresso & fresh pastry',
    descriptionHe: 'אספרסו כפול ומאפה טרי',
    privacyTier: 'TIER_1_RETAIL',
    timestamp: '2026-02-18T10:30:00.000Z',
    postedAt: '2026-02-18T10:30:01.000Z',
    referenceHash: 'a1b2c3d4e5f67890123456789abcdef0123456789abcdef0123456789abcdef0',
    entries: [
      {
        id: 'LE-S1-01',
        transactionId: 'TX-SAMPLE-001',
        accountId: 'W-MAYA-01',
        accountName: 'Maya Cohen',
        type: 'CREDIT',
        amountAgorot: 4500,
        currency: 'ILS',
        timestamp: '2026-02-18T10:30:00.000Z',
      },
      {
        id: 'LE-S1-02',
        transactionId: 'TX-SAMPLE-001',
        accountId: 'W-MERCHANT-02',
        accountName: 'Aroma Cafe Rothschild',
        type: 'DEBIT',
        amountAgorot: 4500,
        currency: 'ILS',
        timestamp: '2026-02-18T10:30:00.000Z',
      },
    ],
  };
  transactions.push(sampleTx1);
  ledgerEntries.push(...sampleTx1.entries);

  // Seed a pending compliance alert
  riskAlerts.set('ALERT-001', {
    id: 'ALERT-001',
    transactionId: 'TX-SAMPLE-001',
    walletId: 'W-DAVID-02',
    walletName: 'David Levi',
    ruleTriggered: 'Rapid repetitive micro-transfer attempt flagged by synthetic velocity heuristic',
    ruleTriggeredHe: 'ניסיון העברות מהירות רצופות שזוהה על ידי מנגנון ניטור המהירות',
    severity: 'MEDIUM',
    status: 'PENDING_REVIEW',
    caseNotes: 'Observed 2 transfers within 180 seconds. Awaiting review confirmation.',
    timestamp: '2026-02-18T11:45:00.000Z',
  });

  // Seed sample Central Bank Operation awaiting dual control
  centralBankOps.set('CBO-001', {
    id: 'CBO-001',
    type: 'ISSUANCE',
    amountAgorot: 10000000, // 100,000 ILS
    initiatorId: 'BOI-OPERATOR-AMIR',
    initiatorName: 'Amir Ben-Porat (Operations Desk)',
    status: 'PROPOSED',
    targetAccountId: 'W-SETTLE-LEUMI',
    targetAccountName: 'Bank Leumi Settlement Reserve',
    reason: 'Monthly interbank liquidity injection for RTGS CBDC testing bridge',
    reasonHe: 'הזרמת נזילות חודשית לבחינת גשר סליקה בזמן אמת (RTGS)',
    timestamp: '2026-02-20T08:00:00.000Z',
  });

  return {
    wallets,
    transactions,
    ledgerEntries,
    paymentRequests,
    centralBankOps,
    riskAlerts,
    idempotencyStore,
    cumulativeIssuedAgorot: totalCirculationAgorot,
    cumulativeRedeemedAgorot: 0,
  };
}

export const db: CBDCDatabase = createInitialSeedState();
