# KONTUR Bank — Digital Banking

> **Hinweis zur Produkt- und Regulierungstransparenz**: KONTUR ist ein fiktives Produktkonzept für Demonstrations- und Evaluierungszwecke. Die Demo bietet keine echten Bank- oder Zahlungsdienstleistungen und steht nicht im Besitz einer Banklizenz.

---

## 1. Übersicht & Markenidentität

KONTUR Bank verbindet deutsche Produktdisziplin, architektonische Klarheit und europäische Softwarequalität zu einem digitalen Bankerlebnis.

- **Farbpalette**: Midnight Navy (`#172536`), Warm Off-White (`#F7F6F2`), Graphite (`#292E34`), Slate Grey (`#75808C`), Muted Blue (`#587CA0`), Deep Forest Green (`#286B59`), Pale Sage (`#DDE9E0`), Soft Stone (`#E8E5DE`), Kupfer-Akzent (`#B98559`).
- **Typografie**: Moderner deutscher Sans-Serif-Standard mit konsequenten `tabular-nums` für alle Finanzdaten und Beträge.
- **Konventionen**: Formatierung nach `de-DE` Standard (z.B. `12.840,65 €`), vollständige Unterstützung von Umlauten (ä, ö, ü) und des ß.
- **Bilingualität**: 100% umschaltbar zwischen Deutsch (Standard) und Englisch.

---

## 2. Kernfunktionen

### Homepage (Präsentation & Showroom)
- **Hero-Bereich**: Klare Markenpositionierung mit interaktivem Live-Konto-Vorschau-Widget (`12.840,65 €`).
- **Nutzen-Streifen**: Vier Kernvorteile (Klarer Finanzüberblick, Intuitive Kontoverwaltung, Transparente Ausgaben, Digitale Finanzplanung).
- **Girokonto der Zukunft**: Berliner Architektur-Split, Echtzeit-Umsatzfilter und Live-Transaktionssuche.
- **Ausgabenanalyse**: Interaktives Verteilungsdiagramm mit Zeitraum-Umschaltung (Diesen Monat, Letzten Monat, 3 Monate) und Vormonatsvergleich.
- **Karten-Showcase**: Physische Edelstahl-Metallkarte und virtuelle Einmalkarte mit Live-Kartensperre und Ausgabenlimit-Schieberegler.
- **Sparziele & Rücklagen**: Dynamischer Sparfortschritt mit Sofort-Einzahlungssimulation.
- **Sicherheitskonzept & Transparenz**: Biometrie, 2FA, DSGVO-Konformität und ehrliche regulatorische Einordnung.
- **Warteliste & Footer**: Validiertes Formular mit Bestätigung, Impressum (§ 5 TMG), Datenschutz und Barrierefreiheitserklärung.

### Interaktives Banking-Dashboard (`/demo` oder Website-Umschalter)
- **Übersicht**: Verfügbares Guthaben, monatliche Einnahmen/Ausgaben, 6-Monats-Cashflow-Balkendiagramm.
- **Umsätze**: Durchsuchbare Buchungstabelle mit Kategorie- und Typenfiltern, CSV-Export und Transaktionsdetails-Modal.
- **Auswertungen**: Responsive Recharts-Visualisierungen (Kategorien-Donut, monatliche Trendkurven, Budget-KPIs).
- **Kartenverwaltung**: Visuelle Kartendarstellung, PIN-Abfrage, Kartensperre/Entsperrung, Online- & Auslandszahlungstoggles, Tageslimit-Slider.
- **Sparziele**: Sparziele erstellen, Einzahlungen simulieren, Sparziele auflösen mit automatischer Rückbuchung auf das Hauptkonto.
- **SEPA-Überweisungs-Workflow**: 5-stufiger Prozess (Empfängerauswahl, Betrag & Verwendungszweck, Prüfung, PhotoTAN-Simulation, Quittung mit Referenznummer).
- **Mitteilungszentrale**: Push-Benachrichtigungen für Buchungen, Sparziele und Sicherheitsevents mit Gelesen-Status.
- **Demo-Daten zurücksetzen**: Stellt den Ausgangszustand jederzeit per Klick wieder her.

### 6-Stufen-Onboarding-Prototyp
1. Willkommen
2. Wohnsitzland
3. Persönliche Angaben
4. Kontaktangaben
5. Produktauswahl (KONTUR Free vs. KONTUR Metal)
6. Zusammenfassung & Aktivierung mit Übergang ins Dashboard.

---

## 3. Installation & Lokale Ausführung

```bash
# 1. Abhängigkeiten installieren
npm install

# 2. Entwicklungsserver starten (Port 3000)
npm run dev

# 3. Production Build erstellen
npm run build

# 4. Production Server ausführen
npm run start
```

---

## 4. Architektur: Übergang von Mock- zu Realdiensten

Die Geschäftslogik und Zustandsverwaltung ist in `context/BankingContext.tsx` gekapselt und von der UI entkoppelt. Für eine spätere Anbindung an autorisierte Banking-as-a-Service (BaaS) Anbieter (z.B. Solarisbank, Swan, Banking Circle) oder ein Kernbankensystem (Core Banking API) können die Mock-Funktionen 1:1 durch API-Clients ersetzt werden:

```typescript
// Beispiel für spätere BaaS-Integration:
export async function executeTransfer(payload: TransferPayload) {
  // Ersetzt die Client-Simulation durch einen authentifizierten Backend-Call:
  const response = await fetch('/api/v1/sepa/transfers', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${userSessionToken}` },
    body: JSON.stringify(payload)
  });
  return response.json();
}
```
