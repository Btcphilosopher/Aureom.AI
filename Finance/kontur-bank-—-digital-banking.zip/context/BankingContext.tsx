'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Language,
  Transaction,
  BankCard,
  SavingsGoal,
  Beneficiary,
  AppNotification,
  TransferPayload,
} from '@/types/banking';
import {
  INITIAL_ACCOUNT_DATA,
  INITIAL_TRANSACTIONS,
  INITIAL_CARDS,
  INITIAL_SAVINGS_GOALS,
  INITIAL_BENEFICIARIES,
  INITIAL_NOTIFICATIONS,
} from '@/data/mockData';
import { translations } from '@/lib/translations';

interface BankingContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.de;
  balance: number;
  transactions: Transaction[];
  cards: BankCard[];
  savingsGoals: SavingsGoal[];
  beneficiaries: Beneficiary[];
  notifications: AppNotification[];
  currentView: 'landing' | 'dashboard';
  setCurrentView: (view: 'landing' | 'dashboard') => void;
  activeDashboardTab: 'overview' | 'transactions' | 'analytics' | 'cards' | 'savings';
  setActiveDashboardTab: (tab: 'overview' | 'transactions' | 'analytics' | 'cards' | 'savings') => void;
  isTransferModalOpen: boolean;
  openTransferModal: () => void;
  closeTransferModal: () => void;
  isWaitlistModalOpen: boolean;
  openWaitlistModal: () => void;
  closeWaitlistModal: () => void;
  isOnboardingOpen: boolean;
  openOnboarding: () => void;
  closeOnboarding: () => void;
  activeLegalModal: string | null;
  setActiveLegalModal: (modal: string | null) => void;
  executeTransfer: (payload: TransferPayload) => { success: boolean; reference: string; error?: string };
  toggleCardFreeze: (cardId: string) => void;
  updateSpendingLimit: (cardId: string, limit: number) => void;
  toggleCardPermission: (cardId: string, type: 'allowOnline' | 'allowForeign') => void;
  addSavingsGoal: (goal: Omit<SavingsGoal, 'id' | 'currentAmount'>) => void;
  depositToSavingsGoal: (goalId: string, amount: number) => boolean;
  deleteSavingsGoal: (goalId: string) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  resetDemoData: () => void;
}

const BankingContext = createContext<BankingContextType | undefined>(undefined);

export function BankingProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('de');
  const [balance, setBalance] = useState<number>(INITIAL_ACCOUNT_DATA.initialBalance);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [cards, setCards] = useState<BankCard[]>(INITIAL_CARDS);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>(INITIAL_SAVINGS_GOALS);
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>(INITIAL_BENEFICIARIES);
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [currentView, setCurrentView] = useState<'landing' | 'dashboard'>('landing');
  const [activeDashboardTab, setActiveDashboardTab] = useState<'overview' | 'transactions' | 'analytics' | 'cards' | 'savings'>('overview');
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isWaitlistModalOpen, setIsWaitlistModalOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [activeLegalModal, setActiveLegalModal] = useState<string | null>(null);

  // Sync html lang attribute
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.lang = language;
    }
  }, [language]);

  const t = translations[language];

  const executeTransfer = (payload: TransferPayload) => {
    if (payload.amount <= 0) {
      return { success: false, reference: '', error: 'Betrag muss größer als 0 sein.' };
    }
    if (payload.amount > balance) {
      return { success: false, reference: '', error: 'Nicht genügend Guthaben auf dem Hauptkonto.' };
    }

    const ref = `KT-2026-${Math.floor(10000 + Math.random() * 90000)}`;
    const today = new Date().toISOString().split('T')[0];

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      merchant: payload.recipientName,
      date: today,
      category: 'Sonstiges',
      amount: -payload.amount,
      status: 'Abgeschlossen',
      reference: ref,
      notes: payload.purpose || 'SEPA-Überweisung',
    };

    setBalance((prev) => +(prev - payload.amount).toFixed(2));
    setTransactions((prev) => [newTx, ...prev]);

    // Check if beneficiary is new and add to quick list
    setBeneficiaries((prev) => {
      const exists = prev.some((b) => b.iban.replace(/\s+/g, '') === payload.iban.replace(/\s+/g, ''));
      if (!exists && payload.recipientName.trim().length > 0) {
        return [
          {
            id: `ben-${Date.now()}`,
            name: payload.recipientName,
            iban: payload.iban,
            bic: 'GENODED1XXX',
            bankName: 'Deutsche Bank / Partnerbank',
            avatarColor: '#587CA0',
          },
          ...prev,
        ];
      }
      return prev;
    });

    // Add confirmation notification
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: language === 'de' ? 'Überweisung ausgeführt' : 'Transfer Completed',
      description: `${payload.amount.toFixed(2)} € erfolgreich an ${payload.recipientName} übermittelt.`,
      timestamp: language === 'de' ? 'Gerade eben' : 'Just now',
      type: 'transaction',
      isRead: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);

    return { success: true, reference: ref };
  };

  const toggleCardFreeze = (cardId: string) => {
    setCards((prev) =>
      prev.map((c) => {
        if (c.id === cardId) {
          const nextFrozen = !c.isFrozen;
          const notif: AppNotification = {
            id: `notif-${Date.now()}`,
            title: nextFrozen
              ? (language === 'de' ? 'Karte gesperrt' : 'Card Frozen')
              : (language === 'de' ? 'Karte entsperrt' : 'Card Unfrozen'),
            description: nextFrozen
              ? (language === 'de' ? `Karte •• ${c.last4} wurde vorübergehend deaktiviert.` : `Card •• ${c.last4} has been temporarily deactivated.`)
              : (language === 'de' ? `Karte •• ${c.last4} ist wieder einsatzbereit.` : `Card •• ${c.last4} is active again.`),
            timestamp: language === 'de' ? 'Gerade eben' : 'Just now',
            type: 'security',
            isRead: false,
          };
          setNotifications((n) => [notif, ...n]);
          return { ...c, isFrozen: nextFrozen };
        }
        return c;
      })
    );
  };

  const updateSpendingLimit = (cardId: string, limit: number) => {
    setCards((prev) =>
      prev.map((c) => (c.id === cardId ? { ...c, spendingLimit: limit } : c))
    );
  };

  const toggleCardPermission = (cardId: string, type: 'allowOnline' | 'allowForeign') => {
    setCards((prev) =>
      prev.map((c) => (c.id === cardId ? { ...c, [type]: !c[type] } : c))
    );
  };

  const addSavingsGoal = (goalData: Omit<SavingsGoal, 'id' | 'currentAmount'>) => {
    const newGoal: SavingsGoal = {
      id: `goal-${Date.now()}`,
      ...goalData,
      currentAmount: 0,
    };
    setSavingsGoals((prev) => [...prev, newGoal]);
  };

  const depositToSavingsGoal = (goalId: string, amount: number) => {
    if (amount <= 0 || amount > balance) return false;

    setBalance((prev) => +(prev - amount).toFixed(2));
    setSavingsGoals((prev) =>
      prev.map((g) => {
        if (g.id === goalId) {
          return { ...g, currentAmount: +(g.currentAmount + amount).toFixed(2) };
        }
        return g;
      })
    );

    const goal = savingsGoals.find((g) => g.id === goalId);
    const ref = `KT-SAVE-${Math.floor(1000 + Math.random() * 9000)}`;
    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      merchant: `Rücklage: ${goal ? goal.name : 'Sparziel'}`,
      date: new Date().toISOString().split('T')[0],
      category: 'Sonstiges',
      amount: -amount,
      status: 'Abgeschlossen',
      reference: ref,
      notes: 'Manuelle Einzahlung Sparziel',
    };
    setTransactions((prev) => [newTx, ...prev]);

    const notif: AppNotification = {
      id: `notif-${Date.now()}`,
      title: language === 'de' ? 'Sparziel aufgeladen' : 'Savings Goal Funded',
      description: `${amount.toFixed(2)} € wurden für „${goal ? goal.name : 'Sparziel'}“ zurückgelegt.`,
      timestamp: language === 'de' ? 'Gerade eben' : 'Just now',
      type: 'savings',
      isRead: false,
    };
    setNotifications((prev) => [notif, ...prev]);

    return true;
  };

  const deleteSavingsGoal = (goalId: string) => {
    const goal = savingsGoals.find((g) => g.id === goalId);
    if (goal && goal.currentAmount > 0) {
      // return funds to main balance
      setBalance((prev) => +(prev + goal.currentAmount).toFixed(2));
      const newTx: Transaction = {
        id: `tx-${Date.now()}`,
        merchant: `Sparziel aufgelöst: ${goal.name}`,
        date: new Date().toISOString().split('T')[0],
        category: 'Gehalt',
        amount: goal.currentAmount,
        status: 'Abgeschlossen',
        reference: `KT-REFUND-${Math.floor(1000 + Math.random() * 9000)}`,
        notes: 'Rückübertrag Sparziel Guthaben',
      };
      setTransactions((prev) => [newTx, ...prev]);
    }
    setSavingsGoals((prev) => prev.filter((g) => g.id !== goalId));
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const resetDemoData = () => {
    setBalance(INITIAL_ACCOUNT_DATA.initialBalance);
    setTransactions(INITIAL_TRANSACTIONS);
    setCards(INITIAL_CARDS);
    setSavingsGoals(INITIAL_SAVINGS_GOALS);
    setBeneficiaries(INITIAL_BENEFICIARIES);
    setNotifications(INITIAL_NOTIFICATIONS);
  };

  return (
    <BankingContext.Provider
      value={{
        language,
        setLanguage,
        t,
        balance,
        transactions,
        cards,
        savingsGoals,
        beneficiaries,
        notifications,
        currentView,
        setCurrentView,
        activeDashboardTab,
        setActiveDashboardTab,
        isTransferModalOpen,
        openTransferModal: () => setIsTransferModalOpen(true),
        closeTransferModal: () => setIsTransferModalOpen(false),
        isWaitlistModalOpen,
        openWaitlistModal: () => setIsWaitlistModalOpen(true),
        closeWaitlistModal: () => setIsWaitlistModalOpen(false),
        isOnboardingOpen,
        openOnboarding: () => setIsOnboardingOpen(true),
        closeOnboarding: () => setIsOnboardingOpen(false),
        activeLegalModal,
        setActiveLegalModal,
        executeTransfer,
        toggleCardFreeze,
        updateSpendingLimit,
        toggleCardPermission,
        addSavingsGoal,
        depositToSavingsGoal,
        deleteSavingsGoal,
        markNotificationRead,
        markAllNotificationsRead,
        resetDemoData,
      }}
    >
      {children}
    </BankingContext.Provider>
  );
}

export function useBanking() {
  const context = useContext(BankingContext);
  if (!context) {
    throw new Error('useBanking must be used within a BankingProvider');
  }
  return context;
}
