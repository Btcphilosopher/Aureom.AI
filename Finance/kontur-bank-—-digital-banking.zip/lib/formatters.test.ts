import { formatCurrency, formatDate, isValidIBAN, formatIBAN } from './formatters';

/**
 * Basic Calculation & Validation Test Suite for KONTUR Banking Conventions
 */
export function runCalculationTests() {
  const results: { test: string; passed: boolean; message?: string }[] = [];

  // Test 1: German currency formatting
  const currDe = formatCurrency(12840.65, 'de');
  // In German locale, format should contain 12.840,65 and €
  const passedCurr = currDe.includes('12.840,65') && currDe.includes('€');
  results.push({
    test: 'German Currency Format (12.840,65 €)',
    passed: passedCurr,
    message: `Result: "${currDe}"`,
  });

  // Test 2: IBAN validation
  const validIban = 'DE89370400440532013000';
  const invalidIban = 'DE1234';
  const passedIban = isValidIBAN(validIban) && !isValidIBAN(invalidIban);
  results.push({
    test: 'IBAN Validation Logic',
    passed: passedIban,
    message: `Valid: ${isValidIBAN(validIban)}, Invalid: ${isValidIBAN(invalidIban)}`,
  });

  // Test 3: IBAN chunk spacing
  const formattedIban = formatIBAN('DE89370400440532013000');
  const passedFormatIban = formattedIban === 'DE89 3704 0044 0532 0130 00';
  results.push({
    test: 'IBAN 4-Character Grouping',
    passed: passedFormatIban,
    message: `Result: "${formattedIban}"`,
  });

  return results;
}
