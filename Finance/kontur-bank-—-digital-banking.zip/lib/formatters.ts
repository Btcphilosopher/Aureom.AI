import { Language } from '@/types/banking';

/**
 * Formats currency values in German de-DE style (e.g. 12.840,65 €)
 */
export function formatCurrency(amount: number, locale: Language = 'de'): string {
  const code = locale === 'de' ? 'de-DE' : 'en-US';
  return new Intl.NumberFormat(code, {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Formats a date string (YYYY-MM-DD) into readable German or English format
 */
export function formatDate(dateStr: string, locale: Language = 'de'): string {
  try {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return dateStr;
    return new Intl.DateTimeFormat(locale === 'de' ? 'de-DE' : 'en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    }).format(date);
  } catch {
    return dateStr;
  }
}

/**
 * Formats relative dates (e.g., 'Heute', 'Gestern')
 */
export function formatRelativeDate(dateStr: string, locale: Language = 'de'): string {
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  if (dateStr === today) {
    return locale === 'de' ? 'Heute' : 'Today';
  }
  if (dateStr === yesterday) {
    return locale === 'de' ? 'Gestern' : 'Yesterday';
  }
  return formatDate(dateStr, locale);
}

/**
 * Validates a standard IBAN format
 */
export function isValidIBAN(iban: string): boolean {
  const sanitized = iban.replace(/\s+/g, '').toUpperCase();
  const ibanRegex = /^[A-Z]{2}[0-9]{2}[A-Z0-9]{11,30}$/;
  return ibanRegex.test(sanitized);
}

/**
 * Formats IBAN into 4-character separated blocks for visual readability
 */
export function formatIBAN(iban: string): string {
  const sanitized = iban.replace(/\s+/g, '').toUpperCase();
  return sanitized.replace(/(.{4})/g, '$1 ').trim();
}
