'use client';

import React from 'react';
import { useBanking } from '@/context/BankingContext';
import { X, ShieldAlert, FileText, CheckCircle, HelpCircle } from 'lucide-react';

export function LegalModal() {
  const { language, activeLegalModal, setActiveLegalModal } = useBanking();

  if (!activeLegalModal) return null;

  const closeModal = () => setActiveLegalModal(null);

  return (
    <div className="fixed inset-0 z-50 bg-[#172536]/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 sm:p-8 space-y-6 shadow-2xl relative animate-in fade-in text-[#172536]">
        {/* Close Button */}
        <button
          onClick={closeModal}
          className="absolute top-5 right-5 p-1.5 text-[#75808C] hover:text-[#172536] rounded"
        >
          <X className="w-5 h-5" />
        </button>

        {/* IMPRESSUM (§ 5 TMG) */}
        {activeLegalModal === 'impressum' && (
          <div className="space-y-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase text-[#75808C]">Rechtliche Angaben</span>
              <h2 className="text-xl font-semibold">Impressum</h2>
            </div>

            <div className="p-3 bg-[#F7F6F2] rounded border border-[#E8E5DE] text-[11px] font-mono text-[#B98559]">
              Hinweis: KONTUR Bank ist ein fiktives Design- und Produktkonzept für Demonstrationszwecke.
            </div>

            <div className="space-y-3 leading-relaxed text-[#292E34]">
              <p>
                <strong>Angaben gemäß § 5 TMG:</strong><br />
                KONTUR Fintech Design Prototype Ltd.<br />
                Brunnenstraße 142<br />
                10115 Berlin, Deutschland
              </p>

              <p>
                <strong>Vertreten durch:</strong><br />
                Maximilian Förster (Konzeptautor & Frontend Architect)
              </p>

              <p>
                <strong>Kontakt:</strong><br />
                E-Mail: kontakt@kontur-concept.de<br />
                Web: www.kontur-banking-concept.de
              </p>

              <p>
                <strong>Haftungshinweis:</strong><br />
                Diese Webapplikation stellt zu keinem Zeitpunkt ein lizenziertes Kreditinstitut im Sinne des Kreditwesengesetzes (KWG) dar. Es werden keine Einlagen entgegengenommen und keine Zahlungsdienste im Sinne des Zahlungsdiensteaufsichtsgesetzes (ZAG) erbracht.
              </p>
            </div>
          </div>
        )}

        {/* DATENSCHUTZ (GDPR / DSGVO) */}
        {activeLegalModal === 'datenschutz' && (
          <div className="space-y-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase text-[#75808C]">Privatsphäre</span>
              <h2 className="text-xl font-semibold">Datenschutzerklärung (DSGVO)</h2>
            </div>

            <div className="space-y-3 leading-relaxed text-[#292E34]">
              <p>
                <strong>1. Grundsatz der Datenvermeidung:</strong><br />
                Der Schutz deiner personenbezogenen Daten hat für KONTUR höchste Priorität. Im Rahmen dieses Prototyps werden eingegebene Testdaten ausschließlich lokal im Browser gespeichert und zu keinem Zeitpunkt an externe Dritte übertragen.
              </p>

              <p>
                <strong>2. Wartelisten-Vormerkung:</strong><br />
                Sofern du dich über das Formular für die geschlossene Beta anmeldest, werden deine Kontaktdaten ausschließlich für die Benachrichtigung über den Entwicklungsstand genutzt. Ein Widerruf ist jederzeit formlos per E-Mail möglich.
              </p>

              <p>
                <strong>3. Server-Logs und Hosting:</strong><br />
                Unsere Serverinfrastruktur arbeitet im europäischen Rechtsraum gemäß Art. 6 Abs. 1 lit. f DSGVO. Es werden keine Third-Party-Werbetracker oder Social-Media-Pixel eingesetzt.
              </p>
            </div>
          </div>
        )}

        {/* AGB */}
        {activeLegalModal === 'agb' && (
          <div className="space-y-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase text-[#75808C]">Geschäftsbedingungen</span>
              <h2 className="text-xl font-semibold">Allgemeine Bedingungen (Demo)</h2>
            </div>

            <div className="space-y-3 leading-relaxed text-[#292E34]">
              <p>
                <strong>§ 1 Geltungsbereich:</strong><br />
                Diese Bedingungen regeln die Nutzung der Demonstrationsplattform von KONTUR. Die Nutzung erfolgt rein zu Evaluierungs- und Anschauungszwecken.
              </p>

              <p>
                <strong>§ 2 Ausschluss von Bankdienstleistungen:</strong><br />
                Transaktionen, Guthabenstände, IBANs und Kartenanzeigen sind rein fiktive Simulationen. Eine Auszahlung von simuliertem Guthaben ist ausgeschlossen.
              </p>
            </div>
          </div>
        )}

        {/* BARRIEREFREIHEIT */}
        {activeLegalModal === 'barrierefreiheit' && (
          <div className="space-y-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase text-[#75808C]">Inklusion & Zugänglichkeit</span>
              <h2 className="text-xl font-semibold">Erklärung zur Barrierefreiheit</h2>
            </div>

            <div className="space-y-3 leading-relaxed text-[#292E34]">
              <p>
                KONTUR orientiert sich an den Web Content Accessibility Guidelines (WCAG 2.1 Level AA). Wir legen besonderen Wert auf:
              </p>
              <ul className="list-disc pl-5 space-y-1 text-[#75808C]">
                <li>Ausreichende Farbkontraste für alle Text- und Dateninhalte</li>
                <li>Vollständige Tastaturbedienbarkeit aller interaktiven Steuerelemente</li>
                <li>Verzicht auf Farbsignale ohne begleitenden Text</li>
                <li>Berücksichtigung von reduzierter Bewegung (<code className="font-mono">prefers-reduced-motion</code>)</li>
              </ul>
            </div>
          </div>
        )}

        {/* PROTOTYP HINWEISE / REGULATORY */}
        {(activeLegalModal === 'prototyp' || activeLegalModal === 'sicherheit' || activeLegalModal === 'ueber-uns' || activeLegalModal === 'kontakt') && (
          <div className="space-y-4 text-xs">
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase text-[#B98559]">Transparenz-Erklärung</span>
              <h2 className="text-xl font-semibold">
                {activeLegalModal === 'ueber-uns'
                  ? 'Über KONTUR & Die Vision'
                  : 'Konzeptioneller Prototyp & Regulatorischer Rahmen'}
              </h2>
            </div>

            <div className="p-4 bg-[#F7F6F2] rounded-xl border border-[#E8E5DE] space-y-2">
              <div className="flex items-center gap-2 font-semibold text-[#172536]">
                <ShieldAlert className="w-4 h-4 text-[#B98559]" />
                <span>Offizieller Status</span>
              </div>
              <p className="text-[11px] text-[#75808C] leading-relaxed">
                KONTUR ist ein fiktives Produktkonzept. Die Demo bietet keine echten Bank- oder Zahlungsdienstleistungen. Ein zukünftiger Marktstart würde den Abschluss von Vereinbarungen mit einem lizenzierten Bankpartner (Banking-as-a-Service) oder eine eigenständige BaFin-Genehmigung erfordern.
              </p>
            </div>

            <div className="space-y-3 leading-relaxed text-[#292E34]">
              <h4 className="font-semibold text-sm">Design-Philosophie</h4>
              <p>
                Gegründet auf den Prinzipien deutscher Produktdisziplin: funktionale Klarheit, Verzicht auf unnötige Animationen und Krypto-Hypes, dafür absolute Transparenz über Finanzen, Budgets und Reserven.
              </p>
            </div>
          </div>
        )}

        <div className="pt-4 border-t border-[#E8E5DE] flex justify-end">
          <button
            onClick={closeModal}
            className="px-5 py-2 bg-[#172536] hover:bg-[#292E34] text-white text-xs font-semibold rounded transition-colors"
          >
            Verstanden & Schließen
          </button>
        </div>
      </div>
    </div>
  );
}
