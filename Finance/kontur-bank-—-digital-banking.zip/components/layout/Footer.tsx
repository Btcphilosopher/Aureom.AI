'use client';

import React from 'react';
import { Logo } from '@/components/brand/Logo';
import { useBanking } from '@/context/BankingContext';
import { Globe } from 'lucide-react';

export function Footer() {
  const {
    t,
    language,
    setLanguage,
    setActiveLegalModal,
    setCurrentView,
    openWaitlistModal,
  } = useBanking();

  return (
    <footer className="bg-[#172536] text-white border-t border-[#292E34] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-12 border-b border-white/10">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-4">
            <Logo variant="light" showDescriptor={true} />
            <p className="text-xs text-white/60 leading-relaxed max-w-sm">
              {t.footer.brandDesc}
            </p>
            <div className="pt-2">
              <span className="inline-block text-[11px] font-mono text-[#B98559] bg-white/5 border border-white/10 px-2.5 py-1 rounded">
                Berlin · Frankfurt am Main · 2026
              </span>
            </div>
          </div>

          {/* Product Links */}
          <div className="space-y-3">
            <p className="text-xs font-mono uppercase tracking-wider text-white/40">
              {t.footer.products}
            </p>
            <ul className="space-y-2 text-xs text-white/70">
              <li>
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Girokonto & Debitkarte
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Sparziele & Rücklagen
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  SEPA-Echtzeitüberweisung
                </button>
              </li>
              <li>
                <button
                  onClick={() => openWaitlistModal()}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  KONTUR Metal (Vormerkung)
                </button>
              </li>
            </ul>
          </div>

          {/* Company Links */}
          <div className="space-y-3">
            <p className="text-xs font-mono uppercase tracking-wider text-white/40">
              {t.footer.company}
            </p>
            <ul className="space-y-2 text-xs text-white/70">
              <li>
                <button
                  onClick={() => setActiveLegalModal('ueber-uns')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {language === 'de' ? 'Über uns & Vision' : 'About Us & Vision'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveLegalModal('sicherheit')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.footer.securityCompliance}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveLegalModal('kontakt')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {language === 'de' ? 'Kontakt & Presse' : 'Contact & Press'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveLegalModal('prototyp')}
                  className="hover:text-white transition-colors cursor-pointer text-[#B98559]"
                >
                  {language === 'de' ? 'Design-Prototyp Hinweise' : 'Prototype Disclosures'}
                </button>
              </li>
            </ul>
          </div>

          {/* Legal Links */}
          <div className="space-y-3">
            <p className="text-xs font-mono uppercase tracking-wider text-white/40">
              {t.footer.legal}
            </p>
            <ul className="space-y-2 text-xs text-white/70">
              <li>
                <button
                  onClick={() => setActiveLegalModal('impressum')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.footer.impressum}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveLegalModal('datenschutz')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.footer.privacy}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveLegalModal('agb')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.footer.terms}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveLegalModal('barrierefreiheit')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  {t.footer.accessibility}
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/50 font-mono">
          <p>{t.footer.prototypeNotice}</p>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setLanguage(language === 'de' ? 'en' : 'de')}
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <Globe className="w-3.5 h-3.5" />
              <span className="uppercase">{language === 'de' ? 'English' : 'Deutsch'}</span>
            </button>
            <span aria-hidden="true">·</span>
            <span>{t.footer.allRightsReserved}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
