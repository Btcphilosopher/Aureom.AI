'use client';

import React, { useState } from 'react';
import { Logo } from '@/components/brand/Logo';
import { useBanking } from '@/context/BankingContext';
import { Menu, X, ArrowUpRight, Globe } from 'lucide-react';

export function Header() {
  const {
    t,
    language,
    setLanguage,
    currentView,
    setCurrentView,
    openWaitlistModal,
    openOnboarding,
  } = useBanking();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleLanguage = () => {
    setLanguage(language === 'de' ? 'en' : 'de');
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    if (currentView !== 'landing') {
      setCurrentView('landing');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(id);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#F7F6F2]/90 backdrop-blur-md border-b border-[#E8E5DE] transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <button
          onClick={() => {
            setCurrentView('landing');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-2 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#172536] rounded"
          aria-label="KONTUR Bank Startseite"
        >
          <Logo showDescriptor={false} />
        </button>

        {/* Zone 2: Navigation Links (single line, clean text, no capsule pills) */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#292E34]">
          <button
            onClick={() => scrollToSection('banking')}
            className="hover:text-[#172536] transition-colors whitespace-nowrap cursor-pointer py-1"
          >
            {t.nav.banking}
          </button>
          <button
            onClick={() => scrollToSection('cards')}
            className="hover:text-[#172536] transition-colors whitespace-nowrap cursor-pointer py-1"
          >
            {t.nav.cards}
          </button>
          <button
            onClick={() => scrollToSection('savings')}
            className="hover:text-[#172536] transition-colors whitespace-nowrap cursor-pointer py-1"
          >
            {t.nav.savings}
          </button>
          <button
            onClick={() => scrollToSection('security')}
            className="hover:text-[#172536] transition-colors whitespace-nowrap cursor-pointer py-1"
          >
            {t.nav.security}
          </button>
          <button
            onClick={() => scrollToSection('about')}
            className="hover:text-[#172536] transition-colors whitespace-nowrap cursor-pointer py-1"
          >
            {t.nav.about}
          </button>
        </nav>

        {/* Zone 3: Actions (Language switcher, Demo switch, Primary CTA) */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Language toggle */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-[#292E34] hover:text-[#172536] transition-colors border border-[#E8E5DE] rounded hover:border-[#75808C] cursor-pointer"
            title="Sprache wechseln / Switch Language"
            aria-label="Sprache umschalten"
          >
            <Globe className="w-3.5 h-3.5 text-[#75808C]" />
            <span className="uppercase tracking-wider">{language}</span>
          </button>

          {/* Switch to Interactive Dashboard */}
          {currentView === 'landing' ? (
            <button
              onClick={() => setCurrentView('dashboard')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#172536] hover:bg-[#E8E5DE]/70 transition-colors border border-[#172536]/20 rounded cursor-pointer whitespace-nowrap"
            >
              <span>{t.nav.demoBanking}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={() => setCurrentView('landing')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#172536] hover:bg-[#E8E5DE]/70 transition-colors border border-[#172536]/20 rounded cursor-pointer whitespace-nowrap"
            >
              <span>Website</span>
            </button>
          )}

          {/* Primary Action Button */}
          <button
            onClick={() => {
              if (currentView === 'dashboard') {
                openOnboarding();
              } else {
                openWaitlistModal();
              }
            }}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#172536] hover:bg-[#292E34] transition-colors rounded shadow-sm whitespace-nowrap cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#172536]"
          >
            {currentView === 'dashboard' ? t.nav.openAccount : t.nav.waitlist}
          </button>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-[#172536] hover:bg-[#E8E5DE] rounded transition-colors"
            aria-label="Menü öffnen"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#F7F6F2] border-b border-[#E8E5DE] px-4 py-5 space-y-4">
          <nav className="flex flex-col space-y-3 text-sm font-medium text-[#292E34]">
            <button
              onClick={() => scrollToSection('banking')}
              className="text-left py-1 hover:text-[#172536]"
            >
              {t.nav.banking}
            </button>
            <button
              onClick={() => scrollToSection('cards')}
              className="text-left py-1 hover:text-[#172536]"
            >
              {t.nav.cards}
            </button>
            <button
              onClick={() => scrollToSection('savings')}
              className="text-left py-1 hover:text-[#172536]"
            >
              {t.nav.savings}
            </button>
            <button
              onClick={() => scrollToSection('security')}
              className="text-left py-1 hover:text-[#172536]"
            >
              {t.nav.security}
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="text-left py-1 hover:text-[#172536]"
            >
              {t.nav.about}
            </button>
          </nav>
          <div className="pt-3 border-t border-[#E8E5DE] flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setCurrentView(currentView === 'landing' ? 'dashboard' : 'landing');
              }}
              className="w-full text-center py-2 text-xs font-semibold border border-[#172536]/30 rounded text-[#172536]"
            >
              {currentView === 'landing' ? t.nav.demoBanking : 'Zur Website'}
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openWaitlistModal();
              }}
              className="w-full text-center py-2.5 text-xs font-semibold bg-[#172536] text-white rounded"
            >
              {t.nav.waitlist}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
