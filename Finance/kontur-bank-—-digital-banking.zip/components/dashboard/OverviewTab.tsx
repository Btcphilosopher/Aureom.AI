'use client';

import React from 'react';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency, formatRelativeDate } from '@/lib/formatters';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Send,
  CreditCard,
  Target,
  Sparkles,
  RefreshCw,
  Plus,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';
import { MONTHLY_TREND_DATA } from '@/data/mockData';

export function OverviewTab() {
  const {
    t,
    language,
    balance,
    transactions,
    savingsGoals,
    cards,
    openTransferModal,
    setActiveDashboardTab,
    resetDemoData,
  } = useBanking();

  const primaryCard = cards[0];
  const recentTransactions = transactions.slice(0, 5);
  const totalSavings = savingsGoals.reduce((sum, g) => sum + g.currentAmount, 0);

  // Calculate current month income vs expenses
  const currentMonthIncome = transactions
    .filter((tx) => tx.amount > 0 && tx.date.startsWith('2026-10'))
    .reduce((sum, tx) => sum + tx.amount, 0);

  const currentMonthExpenses = Math.abs(
    transactions
      .filter((tx) => tx.amount < 0 && tx.date.startsWith('2026-10'))
      .reduce((sum, tx) => sum + tx.amount, 0)
  );

  return (
    <div className="space-y-8">
      {/* Top Balance Banner & Quick Actions */}
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 sm:p-8 space-y-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-[#E8E5DE]">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase text-[#75808C]">
                {t.dashboard.accountHeader.mainAccount}
              </span>
              <span className="text-[10px] font-mono text-[#B98559] bg-[#E8E5DE]/60 px-2 py-0.5 rounded">
                DE89 •••• 0000
              </span>
            </div>
            <div className="flex items-baseline gap-4 pt-1">
              <h1 className="text-3xl sm:text-4xl font-semibold tracking-tight text-[#172536] tabular-nums font-mono">
                {formatCurrency(balance, language)}
              </h1>
            </div>
            <p className="text-xs text-[#75808C]">
              {t.dashboard.accountHeader.available} · BIC: {t.dashboard.accountHeader.bic}
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={openTransferModal}
              className="px-4 py-2.5 text-xs font-semibold text-white bg-[#172536] hover:bg-[#292E34] transition-colors rounded shadow-sm flex items-center gap-2 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{t.dashboard.accountHeader.newTransfer}</span>
            </button>

            <button
              onClick={() => setActiveDashboardTab('savings')}
              className="px-3.5 py-2.5 text-xs font-medium text-[#172536] bg-[#F7F6F2] hover:bg-[#E8E5DE] transition-colors border border-[#E8E5DE] rounded flex items-center gap-1.5 cursor-pointer"
            >
              <Target className="w-3.5 h-3.5 text-[#286B59]" />
              <span>{language === 'de' ? 'Sparen' : 'Savings'}</span>
            </button>

            <button
              onClick={resetDemoData}
              title={t.dashboard.accountHeader.resetData}
              className="p-2.5 text-[#75808C] hover:text-[#172536] bg-[#F7F6F2] hover:bg-[#E8E5DE] transition-colors border border-[#E8E5DE] rounded cursor-pointer"
              aria-label="Demo-Daten zurücksetzen"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 3 Metric Summary Boxes */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div className="p-4 bg-[#F7F6F2] border border-[#E8E5DE] rounded-lg">
            <p className="text-xs text-[#75808C] font-mono uppercase">
              {t.dashboard.accountHeader.income}
            </p>
            <p className="text-xl font-semibold text-[#286B59] tabular-nums font-mono mt-1">
              +{formatCurrency(currentMonthIncome, language)}
            </p>
          </div>

          <div className="p-4 bg-[#F7F6F2] border border-[#E8E5DE] rounded-lg">
            <p className="text-xs text-[#75808C] font-mono uppercase">
              {t.dashboard.accountHeader.expenses}
            </p>
            <p className="text-xl font-semibold text-[#172536] tabular-nums font-mono mt-1">
              -{formatCurrency(currentMonthExpenses, language)}
            </p>
          </div>

          <div className="p-4 bg-[#F7F6F2] border border-[#E8E5DE] rounded-lg">
            <p className="text-xs text-[#75808C] font-mono uppercase">
              {language === 'de' ? 'Gesamte Rücklagen' : 'Total Savings'}
            </p>
            <p className="text-xl font-semibold text-[#B98559] tabular-nums font-mono mt-1">
              {formatCurrency(totalSavings, language)}
            </p>
          </div>
        </div>
      </div>

      {/* 2-Column Section: Trend Bar Chart & Savings Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Monthly Trend Mini-Chart */}
        <div className="lg:col-span-7 bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 space-y-4 shadow-sm">
          <div className="flex items-center justify-between pb-2 border-b border-[#E8E5DE]">
            <div>
              <h3 className="text-sm font-semibold text-[#172536]">
                {language === 'de' ? 'Einnahmen vs. Ausgaben (6 Monate)' : 'Income vs Expenses (6 Months)'}
              </h3>
              <p className="text-xs text-[#75808C]">
                {language === 'de' ? 'Historischer Cashflow-Verlauf' : 'Historical cashflow trends'}
              </p>
            </div>
            <button
              onClick={() => setActiveDashboardTab('analytics')}
              className="text-xs font-semibold text-[#172536] hover:underline"
            >
              {language === 'de' ? 'Zur Analyse →' : 'To Analytics →'}
            </button>
          </div>

          <div className="h-48 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MONTHLY_TREND_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="month" stroke="#75808C" fontSize={11} tickLine={false} />
                <YAxis stroke="#75808C" fontSize={10} tickLine={false} tickFormatter={(val) => `${val / 1000}k`} />
                <Tooltip
                  formatter={(value: any) => [`${value} €`, '']}
                  contentStyle={{
                    backgroundColor: '#172536',
                    border: 'none',
                    borderRadius: '6px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="income" fill="#286B59" name="Einnahmen" radius={[2, 2, 0, 0]} />
                <Bar dataKey="expenses" fill="#172536" name="Ausgaben" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Card Status & Savings Widget */}
        <div className="lg:col-span-5 bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 space-y-5 shadow-sm flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#E8E5DE]">
              <h3 className="text-sm font-semibold text-[#172536]">
                {language === 'de' ? 'Aktive Karte' : 'Active Card'}
              </h3>
              <button
                onClick={() => setActiveDashboardTab('cards')}
                className="text-xs font-semibold text-[#172536] hover:underline"
              >
                {language === 'de' ? 'Karten verwalten →' : 'Manage cards →'}
              </button>
            </div>

            <div className="p-4 bg-[#172536] text-white rounded-lg flex items-center justify-between">
              <div>
                <p className="text-[10px] font-mono text-[#B98559] uppercase tracking-widest">
                  KONTUR Metal
                </p>
                <p className="font-mono text-sm tracking-wider mt-1">•••• •••• •••• {primaryCard.last4}</p>
                <p className="text-[10px] text-white/50 mt-1">Limit: {formatCurrency(primaryCard.spendingLimit, language)}/Tag</p>
              </div>

              <div className="text-right">
                <span className={`inline-block px-2 py-0.5 text-[10px] font-mono rounded ${primaryCard.isFrozen ? 'bg-red-400 text-black font-semibold' : 'bg-[#286B59] text-white'}`}>
                  {primaryCard.isFrozen ? (language === 'de' ? 'Gesperrt' : 'Frozen') : (language === 'de' ? 'Aktiv' : 'Active')}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold text-[#172536] uppercase font-mono">
                {language === 'de' ? 'Top Sparziel' : 'Top Goal'}
              </h4>
              <button
                onClick={() => setActiveDashboardTab('savings')}
                className="text-xs text-[#286B59] font-semibold hover:underline"
              >
                + Ziel anlegen
              </button>
            </div>

            {savingsGoals[0] && (
              <div className="p-3 bg-[#F7F6F2] border border-[#E8E5DE] rounded-lg space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-[#172536]">{savingsGoals[0].name}</span>
                  <span className="font-mono text-[#286B59] font-semibold">
                    {Math.round((savingsGoals[0].currentAmount / savingsGoals[0].targetAmount) * 100)}%
                  </span>
                </div>
                <div className="w-full bg-[#E8E5DE] h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#286B59] h-full rounded-full"
                    style={{
                      width: `${Math.min(
                        100,
                        (savingsGoals[0].currentAmount / savingsGoals[0].targetAmount) * 100
                      )}%`,
                    }}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-[#75808C] font-mono tabular-nums">
                  <span>{formatCurrency(savingsGoals[0].currentAmount, language)}</span>
                  <span>Ziel: {formatCurrency(savingsGoals[0].targetAmount, language)}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Recent Transactions List */}
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 sm:p-8 space-y-4 shadow-sm">
        <div className="flex items-center justify-between pb-3 border-b border-[#E8E5DE]">
          <div>
            <h3 className="text-sm font-semibold text-[#172536]">
              {language === 'de' ? 'Neueste Umsätze' : 'Recent Transactions'}
            </h3>
            <p className="text-xs text-[#75808C]">
              {language === 'de' ? 'Letzte Buchungen auf dem Hauptkonto' : 'Latest checking account ledger activity'}
            </p>
          </div>
          <button
            onClick={() => setActiveDashboardTab('transactions')}
            className="text-xs font-semibold text-[#172536] hover:underline"
          >
            {language === 'de' ? 'Alle Umsätze anzeigen →' : 'View all ledger →'}
          </button>
        </div>

        <div className="divide-y divide-[#E8E5DE]">
          {recentTransactions.map((tx) => (
            <div key={tx.id} className="py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded flex items-center justify-center shrink-0 ${
                    tx.amount > 0 ? 'bg-[#286B59]/10 text-[#286B59]' : 'bg-[#F7F6F2] text-[#172536]'
                  }`}
                >
                  {tx.amount > 0 ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                </div>
                <div>
                  <p className="text-xs font-semibold text-[#172536]">{tx.merchant}</p>
                  <p className="text-[11px] text-[#75808C]">
                    {tx.category} · {formatRelativeDate(tx.date, language)}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <p
                  className={`text-xs font-semibold tabular-nums font-mono ${
                    tx.amount > 0 ? 'text-[#286B59]' : 'text-[#172536]'
                  }`}
                >
                  {tx.amount > 0 ? '+' : ''}
                  {formatCurrency(tx.amount, language)}
                </p>
                <p className="text-[10px] text-[#75808C] font-mono">{tx.reference}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
