'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { Logo } from '@/components/brand/Logo';
import { OverviewTab } from '@/components/dashboard/OverviewTab';
import { TransactionsTab } from '@/components/dashboard/TransactionsTab';
import { AnalyticsTab } from '@/components/dashboard/AnalyticsTab';
import { CardsTab } from '@/components/dashboard/CardsTab';
import { SavingsTab } from '@/components/dashboard/SavingsTab';
import { TransferModal } from '@/components/dashboard/TransferModal';
import { NotificationCenter } from '@/components/dashboard/NotificationCenter';
import {
  LayoutDashboard,
  ReceiptText,
  PieChart,
  CreditCard,
  Target,
  Send,
  Bell,
  ArrowLeft,
  RotateCcw,
  AlertTriangle,
  Globe,
} from 'lucide-react';

export function BankingDashboard() {
  const {
    t,
    language,
    setLanguage,
    setCurrentView,
    activeDashboardTab,
    setActiveDashboardTab,
    openTransferModal,
    notifications,
    resetDemoData,
  } = useBanking();

  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const tabs = [
    { id: 'overview', label: t.dashboard.tabs.overview, icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'transactions', label: t.dashboard.tabs.transactions, icon: <ReceiptText className="w-4 h-4" /> },
    { id: 'analytics', label: t.dashboard.tabs.analytics, icon: <PieChart className="w-4 h-4" /> },
    { id: 'cards', label: t.dashboard.tabs.cards, icon: <CreditCard className="w-4 h-4" /> },
    { id: 'savings', label: t.dashboard.tabs.savings, icon: <Target className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-[#F7F6F2] flex flex-col text-[#172536]">
      {/* Mandatory Demo-Modus Notice Banner */}
      <div className="bg-[#172536] text-white px-4 py-2 text-xs font-mono flex items-center justify-between border-b border-[#292E34]">
        <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
          <AlertTriangle className="w-3.5 h-3.5 text-[#B98559] shrink-0" />
          <span className="font-semibold text-[#B98559]">
            {t.dashboard.demoNotice}
          </span>
          <span className="hidden md:inline text-white/50">
            — Keine Verbindung zu realen Zahlungssystemen oder Bankinstituten.
          </span>
        </div>

        <button
          onClick={() => setCurrentView('landing')}
          className="text-xs text-white/70 hover:text-white flex items-center gap-1 shrink-0"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>{language === 'de' ? 'Zurück zur Website' : 'Back to Website'}</span>
        </button>
      </div>

      {/* Main Dashboard Header */}
      <header className="sticky top-0 z-30 bg-[#FFFFFF] border-b border-[#E8E5DE] shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <button
              onClick={() => setCurrentView('landing')}
              className="flex items-center gap-2 focus:outline-none"
            >
              <Logo showDescriptor={false} />
            </button>

            {/* Desktop Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveDashboardTab(tab.id as any)}
                  className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded transition-colors cursor-pointer ${
                    activeDashboardTab === tab.id
                      ? 'bg-[#172536] text-white shadow-xs'
                      : 'text-[#292E34] hover:text-[#172536] hover:bg-[#F7F6F2]'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Right Header Affordances */}
          <div className="flex items-center gap-3">
            {/* Language switcher */}
            <button
              onClick={() => setLanguage(language === 'de' ? 'en' : 'de')}
              className="p-2 text-[#75808C] hover:text-[#172536] rounded border border-[#E8E5DE] text-xs font-mono uppercase"
              title="Sprache wechseln"
            >
              {language}
            </button>

            {/* Notification Bell */}
            <div className="relative">
              <button
                onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                className="p-2 text-[#292E34] hover:bg-[#F7F6F2] rounded border border-[#E8E5DE] relative cursor-pointer"
                aria-label="Benachrichtigungen"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#286B59] text-white text-[9px] font-mono rounded-full flex items-center justify-center font-bold">
                    {unreadCount}
                  </span>
                )}
              </button>

              <NotificationCenter
                isOpen={isNotificationsOpen}
                onClose={() => setIsNotificationsOpen(false)}
              />
            </div>

            {/* Transfer CTA */}
            <button
              onClick={openTransferModal}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-[#172536] hover:bg-[#292E34] transition-colors rounded shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t.dashboard.accountHeader.newTransfer}</span>
              <span className="sm:hidden">Senden</span>
            </button>
          </div>
        </div>

        {/* Mobile Horizontal Tabs Scroll */}
        <div className="md:hidden flex items-center gap-1 px-4 py-2 border-t border-[#E8E5DE] overflow-x-auto bg-[#F7F6F2]">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveDashboardTab(tab.id as any)}
              className={`flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded whitespace-nowrap ${
                activeDashboardTab === tab.id
                  ? 'bg-[#172536] text-white'
                  : 'text-[#292E34] bg-white border border-[#E8E5DE]'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </header>

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        {activeDashboardTab === 'overview' && <OverviewTab />}
        {activeDashboardTab === 'transactions' && <TransactionsTab />}
        {activeDashboardTab === 'analytics' && <AnalyticsTab />}
        {activeDashboardTab === 'cards' && <CardsTab />}
        {activeDashboardTab === 'savings' && <SavingsTab />}
      </main>

      {/* Global Transfer Modal */}
      <TransferModal />
    </div>
  );
}
