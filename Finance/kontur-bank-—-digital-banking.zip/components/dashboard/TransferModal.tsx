'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency, formatIBAN, isValidIBAN } from '@/lib/formatters';
import {
  X,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  User,
  CreditCard,
  FileText,
  Copy,
  Check,
} from 'lucide-react';

export function TransferModal() {
  const {
    t,
    language,
    balance,
    beneficiaries,
    isTransferModalOpen,
    closeTransferModal,
    executeTransfer,
  } = useBanking();

  // Workflow steps: 1: Beneficiary, 2: Amount & Purpose, 3: Review, 4: Confirmation / PhotoTAN, 5: Success
  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(1);

  // Form State
  const [recipientName, setRecipientName] = useState('');
  const [iban, setIban] = useState('');
  const [amountInput, setAmountInput] = useState('');
  const [purpose, setPurpose] = useState('');
  const [isInstant, setIsInstant] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [tanCode, setTanCode] = useState('849 201');
  const [tanInput, setTanInput] = useState('');
  const [transferRef, setTransferRef] = useState('');
  const [copiedRef, setCopiedRef] = useState(false);

  if (!isTransferModalOpen) return null;

  const resetForm = () => {
    setStep(1);
    setRecipientName('');
    setIban('');
    setAmountInput('');
    setPurpose('');
    setErrorMessage('');
    setTanInput('');
    setTransferRef('');
  };

  const handleClose = () => {
    resetForm();
    closeTransferModal();
  };

  const selectBeneficiary = (ben: typeof beneficiaries[0]) => {
    setRecipientName(ben.name);
    setIban(ben.iban);
    setErrorMessage('');
    setStep(2);
  };

  const handleStep1Next = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientName.trim()) {
      setErrorMessage(
        language === 'de' ? 'Bitte gib einen Empfängernamen an.' : 'Please enter recipient name.'
      );
      return;
    }
    const cleanIban = iban.replace(/\s+/g, '');
    if (cleanIban.length < 15) {
      setErrorMessage(
        language === 'de' ? 'Bitte gib eine gültige IBAN an.' : 'Please enter a valid IBAN.'
      );
      return;
    }
    setErrorMessage('');
    setStep(2);
  };

  const handleStep2Next = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amountInput.replace(',', '.'));
    if (isNaN(amt) || amt <= 0) {
      setErrorMessage(
        language === 'de' ? 'Bitte gib einen Betrag größer als 0 € ein.' : 'Amount must be greater than 0.'
      );
      return;
    }
    if (amt > balance) {
      setErrorMessage(
        language === 'de'
          ? `Nicht genügend Guthaben. Verfügbar: ${formatCurrency(balance, language)}`
          : `Insufficient funds. Available: ${formatCurrency(balance, language)}`
      );
      return;
    }
    setErrorMessage('');
    setStep(3); // To Review
  };

  const handleConfirmReview = () => {
    setErrorMessage('');
    setStep(4); // To PhotoTAN approval simulation
  };

  const handleExecuteFinal = () => {
    const amt = parseFloat(amountInput.replace(',', '.'));
    const result = executeTransfer({
      recipientName: recipientName.trim(),
      iban: iban.trim(),
      amount: amt,
      purpose: purpose.trim() || 'SEPA-Überweisung',
      instant: isInstant,
    });

    if (result.success) {
      setTransferRef(result.reference);
      setStep(5); // Success
    } else {
      setErrorMessage(result.error || 'Fehler bei der Ausführung.');
      setStep(2);
    }
  };

  const handleCopyRef = () => {
    navigator.clipboard?.writeText(transferRef);
    setCopiedRef(true);
    setTimeout(() => setCopiedRef(false), 2000);
  };

  const amtValue = parseFloat(amountInput.replace(',', '.')) || 0;

  return (
    <div className="fixed inset-0 z-50 bg-[#172536]/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl relative animate-in fade-in">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-5 right-5 p-1.5 text-[#75808C] hover:text-[#172536] rounded transition-colors"
          aria-label="Schließen"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono uppercase text-[#B98559] tracking-wider">
              {language === 'de' ? 'SIMULATION' : 'SIMULATION'}
            </span>
            <span className="text-xs text-[#75808C] font-mono">
              (Schritt {step} von {step === 5 ? 5 : 4})
            </span>
          </div>
          <h2 className="text-xl font-semibold text-[#172536]">
            {step === 5 ? t.dashboard.transferModal.success : t.dashboard.transferModal.title}
          </h2>
          <p className="text-xs text-[#75808C]">
            {step === 5
              ? language === 'de'
                ? 'Der Betrag wurde von deinem Musterkonto abgebucht.'
                : 'Funds have been debited from your mock account.'
              : t.dashboard.transferModal.sub}
          </p>
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* STEP 1: Select or enter beneficiary */}
        {step === 1 && (
          <div className="space-y-5 text-xs">
            {/* Quick Contacts */}
            <div className="space-y-2">
              <label className="font-mono uppercase text-[11px] text-[#75808C]">
                {language === 'de' ? 'Gespeicherte Empfänger' : 'Recent Beneficiaries'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {beneficiaries.map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => selectBeneficiary(b)}
                    className="p-2.5 bg-[#F7F6F2] hover:bg-[#E8E5DE] border border-[#E8E5DE] rounded-lg text-left transition-colors cursor-pointer"
                  >
                    <p className="font-semibold text-[#172536] truncate">{b.name}</p>
                    <p className="text-[10px] text-[#75808C] truncate font-mono">
                      {b.iban.slice(0, 10)}...
                    </p>
                  </button>
                ))}
              </div>
            </div>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-[#E8E5DE]"></div>
              <span className="flex-shrink mx-3 text-[#75808C] text-[11px] font-mono">
                {language === 'de' ? 'ODER NEUE IBAN EINGEBEN' : 'OR ENTER NEW IBAN'}
              </span>
              <div className="flex-grow border-t border-[#E8E5DE]"></div>
            </div>

            <form onSubmit={handleStep1Next} className="space-y-4">
              <div className="space-y-1">
                <label className="font-medium text-[#172536]">
                  {t.dashboard.transferModal.recipient}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#75808C] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    placeholder="z.B. Clara Zimmermann"
                    className="w-full pl-9 pr-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536] text-[#172536]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-medium text-[#172536]">
                  {t.dashboard.transferModal.iban}
                </label>
                <input
                  type="text"
                  value={iban}
                  onChange={(e) => setIban(e.target.value)}
                  placeholder="DE89 3704 0044 0532 0130 00"
                  className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536] text-[#172536] font-mono"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#172536] text-white rounded font-semibold hover:bg-[#292E34] transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>{language === 'de' ? 'Weiter zu Betrag' : 'Next to Amount'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>
        )}

        {/* STEP 2: Amount & Purpose */}
        {step === 2 && (
          <form onSubmit={handleStep2Next} className="space-y-4 text-xs">
            <div className="p-3 bg-[#F7F6F2] rounded border border-[#E8E5DE] flex justify-between items-center">
              <div>
                <p className="text-[10px] text-[#75808C] uppercase font-mono">
                  {language === 'de' ? 'Überweisung an' : 'Transfer to'}
                </p>
                <p className="font-semibold text-[#172536]">{recipientName}</p>
                <p className="text-[11px] text-[#75808C] font-mono">{formatIBAN(iban)}</p>
              </div>
              <button
                type="button"
                onClick={() => setStep(1)}
                className="text-xs text-[#587CA0] hover:underline"
              >
                {language === 'de' ? 'Ändern' : 'Change'}
              </button>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between items-baseline">
                <label className="font-medium text-[#172536]">
                  {t.dashboard.transferModal.amount}
                </label>
                <span className="text-[11px] text-[#75808C] font-mono">
                  {language === 'de' ? 'Verfügbar:' : 'Available:'}{' '}
                  {formatCurrency(balance, language)}
                </span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  max={balance}
                  value={amountInput}
                  onChange={(e) => setAmountInput(e.target.value)}
                  placeholder="0,00"
                  className="w-full pl-3 pr-10 py-2.5 bg-[#F7F6F2] border border-[#E8E5DE] rounded text-lg font-mono font-semibold text-[#172536] focus:outline-none focus:border-[#172536]"
                  autoFocus
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-[#75808C]">
                  EUR €
                </span>
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-medium text-[#172536]">
                {t.dashboard.transferModal.purpose}
              </label>
              <input
                type="text"
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                placeholder="z.B. Rechnung Oktober, Geburtstagsgeschenk"
                className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded text-[#172536] focus:outline-none focus:border-[#172536]"
              />
            </div>

            {/* SEPA Instant toggle */}
            <label className="flex items-center justify-between p-3 bg-[#F7F6F2] rounded border border-[#E8E5DE] cursor-pointer">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#286B59]" />
                <span className="font-medium text-[#172536]">
                  {t.dashboard.transferModal.instantTransfer}
                </span>
              </div>
              <input
                type="checkbox"
                checked={isInstant}
                onChange={(e) => setIsInstant(e.target.checked)}
                className="w-4 h-4 accent-[#172536] rounded"
              />
            </label>

            <div className="pt-2 flex justify-between gap-3">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2.5 bg-[#F7F6F2] hover:bg-[#E8E5DE] text-[#172536] rounded font-semibold transition-colors"
              >
                {language === 'de' ? 'Zurück' : 'Back'}
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-[#172536] hover:bg-[#292E34] text-white rounded font-semibold transition-colors flex items-center gap-2"
              >
                <span>{language === 'de' ? 'Zur Prüfung' : 'Review Payment'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: Review Payment */}
        {step === 3 && (
          <div className="space-y-5 text-xs">
            <div className="p-4 bg-[#F7F6F2] rounded-lg border border-[#E8E5DE] space-y-3">
              <h4 className="font-semibold text-sm text-[#172536] pb-2 border-b border-[#E8E5DE]">
                {t.dashboard.transferModal.review}
              </h4>

              <div className="flex justify-between py-1">
                <span className="text-[#75808C]">{language === 'de' ? 'Empfänger:' : 'Recipient:'}</span>
                <span className="font-semibold text-[#172536]">{recipientName}</span>
              </div>

              <div className="flex justify-between py-1">
                <span className="text-[#75808C]">IBAN:</span>
                <span className="font-mono text-[#172536]">{formatIBAN(iban)}</span>
              </div>

              <div className="flex justify-between py-1">
                <span className="text-[#75808C]">{language === 'de' ? 'Verwendungszweck:' : 'Purpose:'}</span>
                <span className="text-[#172536]">{purpose || 'SEPA-Überweisung'}</span>
              </div>

              <div className="flex justify-between py-1">
                <span className="text-[#75808C]">{language === 'de' ? 'Ausführung:' : 'Type:'}</span>
                <span className="text-[#286B59] font-medium font-mono">
                  {isInstant ? 'SEPA-Echtzeit (sofort)' : 'SEPA Standard (1 Bankarbeitstag)'}
                </span>
              </div>

              <div className="flex justify-between py-2 border-t border-[#E8E5DE] items-baseline">
                <span className="font-semibold text-[#172536] text-sm">
                  {language === 'de' ? 'Gesamtbetrag:' : 'Total Amount:'}
                </span>
                <span className="text-xl font-semibold font-mono tabular-nums text-[#172536]">
                  {formatCurrency(amtValue, language)}
                </span>
              </div>
            </div>

            <div className="flex justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-4 py-2.5 bg-[#F7F6F2] hover:bg-[#E8E5DE] text-[#172536] rounded font-semibold transition-colors"
              >
                {language === 'de' ? 'Korrigieren' : 'Edit'}
              </button>
              <button
                type="button"
                onClick={handleConfirmReview}
                className="px-5 py-2.5 bg-[#172536] hover:bg-[#292E34] text-white rounded font-semibold transition-colors flex items-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-[#B98559]" />
                <span>{language === 'de' ? 'Weiter zur Freigabe' : 'Proceed to Authorization'}</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: PhotoTAN / Security confirmation */}
        {step === 4 && (
          <div className="space-y-5 text-xs text-center">
            <div className="w-12 h-12 rounded-full bg-[#172536]/10 flex items-center justify-center mx-auto text-[#172536]">
              <ShieldCheck className="w-6 h-6 text-[#172536]" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-semibold text-[#172536]">
                {t.dashboard.transferModal.securityCheck}
              </h3>
              <p className="text-xs text-[#75808C]">
                {language === 'de'
                  ? 'Simulierte 2-Faktor-Freigabe für '
                  : 'Simulated 2-factor approval for '}
                <strong className="text-[#172536] font-mono">{formatCurrency(amtValue, language)}</strong>
              </p>
            </div>

            {/* Simulated PhotoTAN Graphic / Code */}
            <div className="p-4 bg-[#F7F6F2] rounded-lg border border-[#E8E5DE] space-y-2 max-w-xs mx-auto">
              <span className="text-[10px] font-mono uppercase text-[#75808C]">
                {language === 'de' ? 'Muster-Freigabecode' : 'Sample Security TAN'}
              </span>
              <p className="text-2xl font-mono tracking-widest font-semibold text-[#172536]">
                {tanCode}
              </p>
              <p className="text-[10px] text-[#75808C]">
                {language === 'de'
                  ? 'Klicke unten zur automatischen Bestätigung'
                  : 'Click below to simulate approval'}
              </p>
            </div>

            <div className="flex justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep(3)}
                className="px-4 py-2.5 bg-[#F7F6F2] text-[#172536] rounded font-semibold hover:bg-[#E8E5DE]"
              >
                {language === 'de' ? 'Abbrechen' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleExecuteFinal}
                className="px-6 py-2.5 bg-[#286B59] hover:bg-[#286B59]/90 text-white rounded font-semibold transition-colors flex items-center justify-center gap-2 flex-1 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{language === 'de' ? 'Zahlung jetzt autorisieren' : 'Authorize & Send'}</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Success & Receipt */}
        {step === 5 && (
          <div className="space-y-6 text-xs text-center">
            <div className="w-14 h-14 rounded-full bg-[#DDE9E0] text-[#286B59] flex items-center justify-center mx-auto border border-[#286B59]/30">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-semibold text-[#172536]">
                {t.dashboard.transferModal.success}
              </h3>
              <p className="text-base font-semibold font-mono text-[#286B59]">
                -{formatCurrency(amtValue, language)}
              </p>
            </div>

            <div className="p-4 bg-[#F7F6F2] rounded-lg border border-[#E8E5DE] space-y-2 text-left">
              <div className="flex justify-between">
                <span className="text-[#75808C]">{language === 'de' ? 'Empfänger:' : 'Recipient:'}</span>
                <span className="font-semibold text-[#172536]">{recipientName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#75808C]">{t.dashboard.transferModal.ref}:</span>
                <div className="flex items-center gap-1 font-mono text-[#172536]">
                  <span>{transferRef}</span>
                  <button onClick={handleCopyRef} className="hover:text-[#B98559]">
                    {copiedRef ? <Check className="w-3.5 h-3.5 text-[#286B59]" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-[#75808C]">{language === 'de' ? 'Status:' : 'Status:'}</span>
                <span className="text-[#286B59] font-semibold">SEPA Echtzeit ausgeführt</span>
              </div>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                type="button"
                onClick={handleClose}
                className="w-full py-3 bg-[#172536] hover:bg-[#292E34] text-white rounded font-semibold transition-colors cursor-pointer"
              >
                {t.dashboard.transferModal.backToDashboard}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
