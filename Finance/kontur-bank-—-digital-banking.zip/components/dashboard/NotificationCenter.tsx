'use client';

import React from 'react';
import { useBanking } from '@/context/BankingContext';
import {
  Bell,
  CheckCheck,
  CreditCard,
  Target,
  ShieldCheck,
  User,
  X,
} from 'lucide-react';
import { AppNotification } from '@/types/banking';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NotificationCenter({ isOpen, onClose }: NotificationCenterProps) {
  const {
    language,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
  } = useBanking();

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'transaction':
        return <CreditCard className="w-4 h-4 text-[#587CA0]" />;
      case 'savings':
        return <Target className="w-4 h-4 text-[#286B59]" />;
      case 'security':
        return <ShieldCheck className="w-4 h-4 text-[#B98559]" />;
      default:
        return <User className="w-4 h-4 text-[#172536]" />;
    }
  };

  return (
    <div className="absolute right-0 top-12 z-50 w-80 sm:w-96 bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl shadow-2xl p-4 space-y-4 animate-in fade-in">
      <div className="flex items-center justify-between pb-3 border-b border-[#E8E5DE]">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-[#172536]" />
          <h3 className="text-sm font-semibold text-[#172536]">
            {language === 'de' ? 'Mitteilungen' : 'Notifications'}
          </h3>
          {unreadCount > 0 && (
            <span className="text-[10px] font-mono bg-[#286B59] text-white px-2 py-0.5 rounded-full">
              {unreadCount} neu
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <button
              onClick={markAllNotificationsRead}
              className="text-[11px] text-[#587CA0] hover:underline flex items-center gap-1"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>{language === 'de' ? 'Alle gelesen' : 'Mark all read'}</span>
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1 text-[#75808C] hover:text-[#172536] rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="space-y-2 max-h-80 overflow-y-auto divide-y divide-[#E8E5DE]">
        {notifications.map((item) => (
          <div
            key={item.id}
            onClick={() => markNotificationRead(item.id)}
            className={`pt-2.5 first:pt-0 pb-1 cursor-pointer transition-colors ${
              !item.isRead ? 'bg-[#F7F6F2]/70 -mx-2 px-2 rounded' : ''
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="p-2 rounded bg-[#FFFFFF] border border-[#E8E5DE] shrink-0 mt-0.5">
                {getIcon(item.type)}
              </div>
              <div className="flex-1 space-y-0.5">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-[#172536]">{item.title}</p>
                  <span className="text-[10px] text-[#75808C] font-mono">
                    {item.timestamp}
                  </span>
                </div>
                <p className="text-[11px] text-[#75808C] leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          </div>
        ))}

        {notifications.length === 0 && (
          <p className="text-center py-6 text-xs text-[#75808C]">
            {language === 'de' ? 'Keine Benachrichtigungen.' : 'No notifications.'}
          </p>
        )}
      </div>
    </div>
  );
}
