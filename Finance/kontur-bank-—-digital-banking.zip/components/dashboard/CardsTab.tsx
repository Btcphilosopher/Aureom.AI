'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency, formatRelativeDate } from '@/lib/formatters';
import {
  Lock,
  Unlock,
  CreditCard,
  Smartphone,
  Eye,
  EyeOff,
  ShieldCheck,
  Globe,
  ShoppingBag,
  Sliders,
  Check,
} from 'lucide-react';

export function CardsTab() {
  const {
    t,
    language,
    cards,
    transactions,
    toggleCardFreeze,
    updateSpendingLimit,
    toggleCardPermission,
  } = useBanking();
  const [selectedCardId, setSelectedCardId] = useState<string>(cards[0].id);
  const [showPin, setShowPin] = useState(false);

  const currentCard = cards.find((c) => c.id === selectedCardId) || cards[0];
  const cardTransactions = transactions
    .filter((tx) => tx.cardLast4 === currentCard.last4)
    .slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Cards Header & Selector */}
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 sm:p-8 space-y-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8E5DE]">
          <div>
            <h2 className="text-xl font-semibold text-[#172536]">
              {language === 'de' ? 'Kartenverwaltung' : 'Card Management'}
            </h2>
            <p className="text-xs text-[#75808C]">
              {language === 'de'
                ? 'Echtzeit-Sicherheit, Limits und digitale Wallets'
                : 'Real-time security, limits, and digital wallet controls'}
            </p>
          </div>

          {/* Card Selector Pills */}
          <div className="flex items-center gap-2">
            {cards.map((card) => (
              <button
                key={card.id}
                onClick={() => {
                  setSelectedCardId(card.id);
                  setShowPin(false);
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded cursor-pointer transition-colors ${
                  selectedCardId === card.id
                    ? 'bg-[#172536] text-white'
                    : 'bg-[#F7F6F2] text-[#292E34] hover:bg-[#E8E5DE]'
                }`}
              >
                {card.type === 'physical'
                  ? (language === 'de' ? 'Metallkarte (•• 8834)' : 'Metal Card (•• 8834)')
                  : (language === 'de' ? 'Virtuell (•• 1904)' : 'Virtual (•• 1904)')}
              </button>
            ))}
          </div>
        </div>

        {/* 2-Column: Card Representation & Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Card Visual Graphic */}
          <div className="lg:col-span-5 space-y-4">
            <div
              className={`aspect-[1.586/1] rounded-2xl p-6 sm:p-7 text-white flex flex-col justify-between relative overflow-hidden shadow-lg transition-all ${
                currentCard.isFrozen
                  ? 'bg-neutral-800 grayscale opacity-90'
                  : currentCard.type === 'physical'
                  ? 'bg-gradient-to-br from-[#172536] via-[#292E34] to-[#172536]'
                  : 'bg-gradient-to-br from-[#292E34] via-[#587CA0] to-[#172536]'
              }`}
            >
              <div className="flex justify-between items-start">
                <div className="space-y-0.5">
                  <span className="text-xs font-mono tracking-[0.25em] text-[#B98559]">
                    KONTUR
                  </span>
                  <p className="text-[10px] text-white/60 uppercase tracking-wider font-mono">
                    {currentCard.type === 'physical' ? 'Stainless Metal' : 'Single-Use Virtual'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {currentCard.isFrozen && (
                    <span className="px-2 py-0.5 bg-red-500/80 text-white text-[10px] font-mono rounded">
                      Gesperrt
                    </span>
                  )}
                  <CreditCard className="w-5 h-5 text-white/60" />
                </div>
              </div>

              {/* Card Number & Chip */}
              <div className="space-y-4 my-auto">
                <div className="w-9 h-7 rounded bg-[#B98559]/30 border border-[#B98559]/60 flex items-center justify-center">
                  <div className="w-6 h-4 border border-[#B98559]/80 rounded-sm" />
                </div>
                <p className="font-mono text-lg sm:text-xl tracking-widest text-white/95">
                  •••• •••• •••• {currentCard.last4}
                </p>
              </div>

              <div className="flex justify-between items-end text-xs font-mono text-white/70">
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-white/40 block">
                    Karteninhaber
                  </span>
                  <span className="text-white font-medium">{currentCard.nameOnCard}</span>
                </div>
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-white/40 block">
                    Gültig bis
                  </span>
                  <span className="text-white font-medium">{currentCard.expiry}</span>
                </div>
              </div>
            </div>

            {/* Quick Actions (Reveal PIN, Apple Pay) */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => setShowPin(!showPin)}
                className="py-2.5 px-3 bg-[#F7F6F2] hover:bg-[#E8E5DE] border border-[#E8E5DE] text-[#172536] text-xs font-medium rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>
                  {showPin
                    ? (language === 'de' ? 'PIN: 4 8 2 1' : 'PIN: 4 8 2 1')
                    : (language === 'de' ? 'PIN anzeigen' : 'Show PIN')}
                </span>
              </button>

              <button
                onClick={() => toggleCardFreeze(currentCard.id)}
                className={`py-2.5 px-3 text-xs font-medium rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                  currentCard.isFrozen
                    ? 'bg-[#286B59] hover:bg-[#286B59]/90 text-white'
                    : 'bg-[#172536] hover:bg-[#292E34] text-white'
                }`}
              >
                {currentCard.isFrozen ? (
                  <>
                    <Unlock className="w-3.5 h-3.5" />
                    <span>{t.cards.unfreezeCard}</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    <span>{t.cards.freezeCard}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right Column: Settings & Security Controls */}
          <div className="lg:col-span-7 space-y-5">
            {/* Limit Adjustment */}
            <div className="p-5 bg-[#F7F6F2] border border-[#E8E5DE] rounded-xl space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-[#172536]">
                  {t.cards.spendingLimit}
                </span>
                <span className="font-mono font-semibold text-[#172536] text-sm tabular-nums">
                  {formatCurrency(currentCard.spendingLimit, language)}
                </span>
              </div>

              <input
                type="range"
                min="200"
                max="5000"
                step="100"
                value={currentCard.spendingLimit}
                onChange={(e) =>
                  updateSpendingLimit(currentCard.id, Number(e.target.value))
                }
                className="w-full accent-[#172536] cursor-pointer"
              />

              <div className="flex justify-between text-[11px] text-[#75808C] font-mono">
                <span>200 €</span>
                <span>
                  {language === 'de' ? 'Tagesumsatz:' : 'Daily used:'}{' '}
                  {formatCurrency(currentCard.dailySpent, language)}
                </span>
                <span>5.000 €</span>
              </div>
            </div>

            {/* Granular Toggles */}
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3.5 bg-[#FFFFFF] border border-[#E8E5DE] rounded-lg">
                <div className="flex items-center gap-3">
                  <ShoppingBag className="w-4 h-4 text-[#75808C]" />
                  <div>
                    <p className="text-xs font-semibold text-[#172536]">
                      {t.cards.onlinePayments}
                    </p>
                    <p className="text-[11px] text-[#75808C]">
                      {language === 'de'
                        ? 'Internetkäufe und Abo-Zahlungen zulassen'
                        : 'Enable e-commerce & subscription charges'}
                    </p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={currentCard.allowOnline}
                  onChange={() => toggleCardPermission(currentCard.id, 'allowOnline')}
                  className="w-4 h-4 accent-[#172536] rounded cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-3.5 bg-[#FFFFFF] border border-[#E8E5DE] rounded-lg">
                <div className="flex items-center gap-3">
                  <Globe className="w-4 h-4 text-[#75808C]" />
                  <div>
                    <p className="text-xs font-semibold text-[#172536]">
                      {t.cards.foreignPayments}
                    </p>
                    <p className="text-[11px] text-[#75808C]">
                      {language === 'de'
                        ? 'Zahlungen außerhalb der Euro-Zone gestatten'
                        : 'Allow transactions outside the Eurozone'}
                    </p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={currentCard.allowForeign}
                  onChange={() => toggleCardPermission(currentCard.id, 'allowForeign')}
                  className="w-4 h-4 accent-[#172536] rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Card Recent Transactions */}
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 space-y-4 shadow-sm">
        <h3 className="text-sm font-semibold text-[#172536]">
          {language === 'de' ? 'Umsätze dieser Karte' : 'Transactions for this Card'}
        </h3>

        <div className="divide-y divide-[#E8E5DE]">
          {cardTransactions.map((tx) => (
            <div key={tx.id} className="py-3 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-[#172536]">{tx.merchant}</p>
                <p className="text-[11px] text-[#75808C]">
                  {formatRelativeDate(tx.date, language)} · {tx.category}
                </p>
              </div>

              <div className="text-right">
                <span className="text-xs font-semibold text-[#172536] tabular-nums font-mono">
                  {formatCurrency(tx.amount, language)}
                </span>
                <p className="text-[10px] text-[#286B59] font-mono">Autorisiert</p>
              </div>
            </div>
          ))}

          {cardTransactions.length === 0 && (
            <p className="py-4 text-xs text-[#75808C] text-center">
              {language === 'de'
                ? 'Keine Kartenzahlungen in diesem Zeitraum.'
                : 'No charges recorded on this card.'}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
