'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency, formatDate } from '@/lib/formatters';
import { Transaction, TransactionCategory } from '@/types/banking';
import {
  Search,
  Filter,
  ArrowDownLeft,
  ArrowUpRight,
  Download,
  Calendar,
  X,
  Copy,
  Check,
} from 'lucide-react';

export function TransactionsTab() {
  const { t, language, transactions } = useBanking();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'in' | 'out'>('all');
  const [sortOrder, setSortOrder] = useState<'dateDesc' | 'amountDesc'>('dateDesc');
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [copiedRef, setCopiedRef] = useState(false);

  const categories: TransactionCategory[] = [
    'Wohnen',
    'Lebensmittel',
    'Mobilität',
    'Freizeit',
    'Einkäufe',
    'Gehalt',
    'Sonstiges',
  ];

  // Filtering & Sorting
  const filtered = transactions
    .filter((tx) => {
      const matchesSearch =
        tx.merchant.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.reference.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (tx.notes && tx.notes.toLowerCase().includes(searchQuery.toLowerCase()));

      if (!matchesSearch) return false;
      if (categoryFilter !== 'all' && tx.category !== categoryFilter) return false;
      if (typeFilter === 'in' && tx.amount <= 0) return false;
      if (typeFilter === 'out' && tx.amount >= 0) return false;
      return true;
    })
    .sort((a, b) => {
      if (sortOrder === 'amountDesc') {
        return Math.abs(b.amount) - Math.abs(a.amount);
      }
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    });

  const handleCopyRef = (ref: string) => {
    navigator.clipboard?.writeText(ref);
    setCopiedRef(true);
    setTimeout(() => setCopiedRef(false), 2000);
  };

  const handleExportCSV = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,Datum,Händler,Kategorie,Betrag,Status,Referenz\n' +
      filtered
        .map(
          (t) =>
            `${t.date},"${t.merchant}",${t.category},${t.amount},${t.status},${t.reference}`
        )
        .join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `kontur_kontoauszug_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Search & Filter Toolbar */}
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-5 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-[#172536]">
              {language === 'de' ? 'Kontoauszug & Umsätze' : 'Ledger & Transactions'}
            </h2>
            <p className="text-xs text-[#75808C]">
              {filtered.length} {language === 'de' ? 'Buchungen gefunden' : 'records found'} (Demo-Daten)
            </p>
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#172536] bg-[#F7F6F2] hover:bg-[#E8E5DE] border border-[#E8E5DE] rounded transition-colors self-start sm:self-auto cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{language === 'de' ? 'CSV Exportieren' : 'Export CSV'}</span>
          </button>
        </div>

        {/* Filters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#75808C] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.dashboard.transactionFilter.searchPlaceholder}
              className="w-full pl-9 pr-3 py-2 text-xs bg-[#F7F6F2] border border-[#E8E5DE] rounded text-[#172536] focus:outline-none focus:border-[#172536]"
            />
          </div>

          {/* Category Dropdown */}
          <div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-[#F7F6F2] border border-[#E8E5DE] rounded text-[#172536] focus:outline-none focus:border-[#172536]"
            >
              <option value="all">{t.dashboard.transactionFilter.allCategories}</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Type Dropdown */}
          <div>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as any)}
              className="w-full px-3 py-2 text-xs bg-[#F7F6F2] border border-[#E8E5DE] rounded text-[#172536] focus:outline-none focus:border-[#172536]"
            >
              <option value="all">{t.dashboard.transactionFilter.allTypes}</option>
              <option value="in">{t.dashboard.transactionFilter.incomingOnly}</option>
              <option value="out">{t.dashboard.transactionFilter.outgoingOnly}</option>
            </select>
          </div>

          {/* Sort Order */}
          <div>
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as any)}
              className="w-full px-3 py-2 text-xs bg-[#F7F6F2] border border-[#E8E5DE] rounded text-[#172536] focus:outline-none focus:border-[#172536]"
            >
              <option value="dateDesc">{t.dashboard.transactionFilter.sortDateDesc}</option>
              <option value="amountDesc">{t.dashboard.transactionFilter.sortAmountDesc}</option>
            </select>
          </div>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#E8E5DE] bg-[#F7F6F2] text-[11px] font-mono uppercase text-[#75808C]">
                <th className="py-3 px-4 font-semibold">{language === 'de' ? 'Händler / Empfänger' : 'Merchant'}</th>
                <th className="py-3 px-4 font-semibold">{language === 'de' ? 'Kategorie' : 'Category'}</th>
                <th className="py-3 px-4 font-semibold">{language === 'de' ? 'Datum' : 'Date'}</th>
                <th className="py-3 px-4 font-semibold">{language === 'de' ? 'Status' : 'Status'}</th>
                <th className="py-3 px-4 font-semibold text-right">{language === 'de' ? 'Betrag' : 'Amount'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E8E5DE] text-xs">
              {filtered.map((tx) => (
                <tr
                  key={tx.id}
                  onClick={() => setSelectedTx(tx)}
                  className="hover:bg-[#F7F6F2]/70 cursor-pointer transition-colors"
                >
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-7 h-7 rounded flex items-center justify-center shrink-0 ${
                          tx.amount > 0
                            ? 'bg-[#286B59]/10 text-[#286B59]'
                            : 'bg-[#F7F6F2] text-[#172536]'
                        }`}
                      >
                        {tx.amount > 0 ? (
                          <ArrowDownLeft className="w-3.5 h-3.5" />
                        ) : (
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        )}
                      </div>
                      <div>
                        <p className="font-semibold text-[#172536]">{tx.merchant}</p>
                        <p className="text-[11px] text-[#75808C] font-mono">{tx.reference}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-[#75808C] font-medium">{tx.category}</td>
                  <td className="py-3 px-4 text-[#75808C] font-mono">{formatDate(tx.date, language)}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        tx.status === 'Abgeschlossen'
                          ? 'bg-[#DDE9E0] text-[#286B59]'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {tx.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-semibold tabular-nums font-mono">
                    <span className={tx.amount > 0 ? 'text-[#286B59]' : 'text-[#172536]'}>
                      {tx.amount > 0 ? '+' : ''}
                      {formatCurrency(tx.amount, language)}
                    </span>
                  </td>
                </tr>
              ))}

              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-xs text-[#75808C]">
                    {language === 'de'
                      ? 'Keine Buchungen mit diesen Filterkriterien.'
                      : 'No transactions found.'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transaction Details Modal */}
      {selectedTx && (
        <div className="fixed inset-0 z-50 bg-[#172536]/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl max-w-lg w-full p-6 space-y-6 shadow-xl relative animate-in fade-in duration-150">
            <button
              onClick={() => setSelectedTx(null)}
              className="absolute top-4 right-4 p-1.5 text-[#75808C] hover:text-[#172536] rounded"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase text-[#75808C]">
                {language === 'de' ? 'Transaktionsdetails (Muster)' : 'Transaction Details (Mock)'}
              </span>
              <h3 className="text-xl font-semibold text-[#172536]">{selectedTx.merchant}</h3>
            </div>

            <div className="p-4 bg-[#F7F6F2] rounded-lg flex items-baseline justify-between border border-[#E8E5DE]">
              <span className="text-xs text-[#75808C] uppercase font-mono">
                {language === 'de' ? 'Buchungsbetrag' : 'Amount'}
              </span>
              <span
                className={`text-2xl font-semibold tabular-nums font-mono ${
                  selectedTx.amount > 0 ? 'text-[#286B59]' : 'text-[#172536]'
                }`}
              >
                {selectedTx.amount > 0 ? '+' : ''}
                {formatCurrency(selectedTx.amount, language)}
              </span>
            </div>

            <div className="space-y-3 text-xs divide-y divide-[#E8E5DE]">
              <div className="flex justify-between pt-2">
                <span className="text-[#75808C]">{language === 'de' ? 'Datum' : 'Date'}</span>
                <span className="font-mono text-[#172536]">{formatDate(selectedTx.date, language)}</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-[#75808C]">{language === 'de' ? 'Kategorie' : 'Category'}</span>
                <span className="font-medium text-[#172536]">{selectedTx.category}</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-[#75808C]">{language === 'de' ? 'Referenz' : 'Reference'}</span>
                <button
                  onClick={() => handleCopyRef(selectedTx.reference)}
                  className="flex items-center gap-1 font-mono text-[#172536] hover:text-[#B98559]"
                >
                  <span>{selectedTx.reference}</span>
                  {copiedRef ? <Check className="w-3 h-3 text-[#286B59]" /> : <Copy className="w-3 h-3 text-[#75808C]" />}
                </button>
              </div>
              {selectedTx.notes && (
                <div className="flex justify-between pt-2">
                  <span className="text-[#75808C]">{language === 'de' ? 'Verwendungszweck' : 'Notes'}</span>
                  <span className="text-[#172536] text-right max-w-xs">{selectedTx.notes}</span>
                </div>
              )}
              {selectedTx.cardLast4 && (
                <div className="flex justify-between pt-2">
                  <span className="text-[#75808C]">{language === 'de' ? 'Zahlungsmittel' : 'Card Used'}</span>
                  <span className="font-mono text-[#172536]">KONTUR Debit •• {selectedTx.cardLast4}</span>
                </div>
              )}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedTx(null)}
                className="px-4 py-2 bg-[#172536] text-white text-xs font-semibold rounded hover:bg-[#292E34] transition-colors"
              >
                {language === 'de' ? 'Schließen' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
