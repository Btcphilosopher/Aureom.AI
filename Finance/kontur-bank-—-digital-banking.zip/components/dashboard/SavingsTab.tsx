'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency } from '@/lib/formatters';
import { SavingsGoal } from '@/types/banking';
import {
  Target,
  Plus,
  Trash2,
  TrendingUp,
  X,
  Check,
  Calendar,
  AlertCircle,
} from 'lucide-react';

export function SavingsTab() {
  const {
    t,
    language,
    balance,
    savingsGoals,
    addSavingsGoal,
    depositToSavingsGoal,
    deleteSavingsGoal,
  } = useBanking();

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [depositGoal, setDepositGoal] = useState<SavingsGoal | null>(null);
  const [depositAmountInput, setDepositAmountInput] = useState('100');
  const [depositError, setDepositError] = useState('');

  // Form states for creating goal
  const [newGoalName, setNewGoalName] = useState('');
  const [newGoalTarget, setNewGoalTarget] = useState('2000');
  const [newGoalDate, setNewGoalDate] = useState('2027-12');
  const [newGoalMonthly, setNewGoalMonthly] = useState('150');
  const [newGoalCategory, setNewGoalCategory] = useState('Sicherheit');
  const [createError, setCreateError] = useState('');

  const totalCurrentSavings = savingsGoals.reduce((sum, g) => sum + g.currentAmount, 0);
  const totalTargetSavings = savingsGoals.reduce((sum, g) => sum + g.targetAmount, 0);

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalName.trim()) {
      setCreateError(language === 'de' ? 'Bitte gib einen Namen an.' : 'Please enter a name.');
      return;
    }
    const target = parseFloat(newGoalTarget);
    if (isNaN(target) || target <= 0) {
      setCreateError(language === 'de' ? 'Ungültiger Zielbetrag.' : 'Invalid target amount.');
      return;
    }

    addSavingsGoal({
      name: newGoalName.trim(),
      targetAmount: target,
      targetDate: newGoalDate,
      monthlyContribution: parseFloat(newGoalMonthly) || 100,
      category: newGoalCategory,
    });

    setIsCreateModalOpen(false);
    setNewGoalName('');
    setCreateError('');
  };

  const handleExecuteDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!depositGoal) return;

    const amt = parseFloat(depositAmountInput);
    if (isNaN(amt) || amt <= 0) {
      setDepositError(language === 'de' ? 'Betrag muss größer als 0 sein.' : 'Amount must be greater than 0.');
      return;
    }
    if (amt > balance) {
      setDepositError(
        language === 'de'
          ? 'Nicht genügend Guthaben auf dem Girokonto.'
          : 'Insufficient checking account balance.'
      );
      return;
    }

    const success = depositToSavingsGoal(depositGoal.id, amt);
    if (success) {
      setDepositGoal(null);
      setDepositError('');
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Overview Banner */}
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 sm:p-8 space-y-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8E5DE]">
          <div>
            <h2 className="text-xl font-semibold text-[#172536]">
              {language === 'de' ? 'Sparziele & Rücklagen' : 'Savings Goals & Reserves'}
            </h2>
            <p className="text-xs text-[#75808C]">
              {language === 'de'
                ? 'Automatisiertes Sparen für Meilensteine und unvorhergesehene Ausgaben'
                : 'Automated savings for milestones and emergency cushions'}
            </p>
          </div>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#172536] hover:bg-[#292E34] transition-colors rounded shadow-sm self-start sm:self-auto cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t.savings.addGoal}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 bg-[#F7F6F2] rounded-lg">
            <span className="text-[11px] font-mono text-[#75808C] uppercase">
              {language === 'de' ? 'Aktuelle Gesamtrücklage' : 'Current Total Saved'}
            </span>
            <p className="text-2xl font-semibold text-[#286B59] tabular-nums font-mono mt-1">
              {formatCurrency(totalCurrentSavings, language)}
            </p>
          </div>

          <div className="p-4 bg-[#F7F6F2] rounded-lg">
            <span className="text-[11px] font-mono text-[#75808C] uppercase">
              {language === 'de' ? 'Zielsumme aller Töpfe' : 'Cumulative Target'}
            </span>
            <p className="text-2xl font-semibold text-[#172536] tabular-nums font-mono mt-1">
              {formatCurrency(totalTargetSavings, language)}
            </p>
          </div>

          <div className="p-4 bg-[#F7F6F2] rounded-lg">
            <span className="text-[11px] font-mono text-[#75808C] uppercase">
              {language === 'de' ? 'Aktive Sparziele' : 'Active Goals'}
            </span>
            <p className="text-2xl font-semibold text-[#B98559] tabular-nums font-mono mt-1">
              {savingsGoals.length}
            </p>
          </div>
        </div>
      </div>

      {/* Goals Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {savingsGoals.map((goal) => {
          const percent = Math.min(
            100,
            Math.round((goal.currentAmount / goal.targetAmount) * 100)
          );
          const remaining = Math.max(0, goal.targetAmount - goal.currentAmount);

          return (
            <div
              key={goal.id}
              className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 flex flex-col justify-between space-y-5 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono uppercase text-[#75808C] bg-[#F7F6F2] px-2 py-0.5 rounded border border-[#E8E5DE]">
                      {goal.category}
                    </span>
                    <h3 className="text-base font-semibold text-[#172536] mt-1.5">
                      {goal.name}
                    </h3>
                  </div>

                  <button
                    onClick={() => deleteSavingsGoal(goal.id)}
                    className="p-1.5 text-[#75808C] hover:text-red-600 rounded transition-colors"
                    title={language === 'de' ? 'Sparziel auflösen' : 'Close goal'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="font-semibold text-[#286B59]">{percent}%</span>
                    <span className="text-[#75808C]">
                      {language === 'de' ? 'Noch' : 'Remaining'}: {formatCurrency(remaining, language)}
                    </span>
                  </div>

                  <div className="w-full bg-[#E8E5DE] h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-[#286B59] h-full rounded-full transition-all duration-300"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>

                <div className="pt-2 flex justify-between items-baseline text-xs font-mono">
                  <div>
                    <p className="text-[10px] text-[#75808C] uppercase">
                      {language === 'de' ? 'Gespart' : 'Saved'}
                    </p>
                    <p className="text-lg font-semibold text-[#172536] tabular-nums">
                      {formatCurrency(goal.currentAmount, language)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-[#75808C] uppercase">
                      {language === 'de' ? 'Zielsumme' : 'Target'}
                    </p>
                    <p className="text-sm text-[#75808C] tabular-nums">
                      {formatCurrency(goal.targetAmount, language)}
                    </p>
                  </div>
                </div>

                <div className="p-2.5 bg-[#F7F6F2] rounded border border-[#E8E5DE] text-[11px] text-[#75808C] flex justify-between items-center font-mono">
                  <span>Zieltermin: {goal.targetDate}</span>
                  <span>{formatCurrency(goal.monthlyContribution, language)}/Mo.</span>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-3 border-t border-[#E8E5DE]">
                <button
                  onClick={() => {
                    setDepositGoal(goal);
                    setDepositAmountInput('100');
                    setDepositError('');
                  }}
                  className="w-full py-2 bg-[#F7F6F2] hover:bg-[#172536] text-[#172536] hover:text-white border border-[#E8E5DE] text-xs font-semibold rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{language === 'de' ? 'Betrag einzahlen' : 'Deposit funds'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create Goal Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#172536]/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl max-w-md w-full p-6 space-y-5 shadow-xl relative animate-in fade-in">
            <button
              onClick={() => setIsCreateModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 text-[#75808C] hover:text-[#172536] rounded"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <h3 className="text-lg font-semibold text-[#172536]">
                {language === 'de' ? 'Neues Sparziel erstellen' : 'Create New Savings Goal'}
              </h3>
              <p className="text-xs text-[#75808C]">
                {language === 'de'
                  ? 'Definiere Zielbetrag und monatliche Rücklage'
                  : 'Define target amount and monthly contribution'}
              </p>
            </div>

            {createError && (
              <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded">
                {createError}
              </div>
            )}

            <form onSubmit={handleCreateGoal} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-medium text-[#172536]">
                  {language === 'de' ? 'Bezeichnung des Ziels' : 'Goal Name'}
                </label>
                <input
                  type="text"
                  value={newGoalName}
                  onChange={(e) => setNewGoalName(e.target.value)}
                  placeholder="z.B. Urlaub 2027, Kaution"
                  className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-medium text-[#172536]">
                    {language === 'de' ? 'Zielbetrag (€)' : 'Target Amount (€)'}
                  </label>
                  <input
                    type="number"
                    step="50"
                    value={newGoalTarget}
                    onChange={(e) => setNewGoalTarget(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536] font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-medium text-[#172536]">
                    {language === 'de' ? 'Monatlich (€)' : 'Monthly (€)'}
                  </label>
                  <input
                    type="number"
                    step="10"
                    value={newGoalMonthly}
                    onChange={(e) => setNewGoalMonthly(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536] font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-medium text-[#172536]">
                    {language === 'de' ? 'Ziel-Monat' : 'Target Month'}
                  </label>
                  <input
                    type="month"
                    value={newGoalDate}
                    onChange={(e) => setNewGoalDate(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536] font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-medium text-[#172536]">
                    {language === 'de' ? 'Kategorie' : 'Category'}
                  </label>
                  <select
                    value={newGoalCategory}
                    onChange={(e) => setNewGoalCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536]"
                  >
                    <option value="Sicherheit">Sicherheit</option>
                    <option value="Urlaub">Urlaub</option>
                    <option value="Freizeit">Freizeit</option>
                    <option value="Anschaffung">Anschaffung</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="w-1/2 py-2.5 bg-[#F7F6F2] text-[#172536] rounded font-semibold hover:bg-[#E8E5DE] transition-colors"
                >
                  {language === 'de' ? 'Abbrechen' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-[#172536] text-white rounded font-semibold hover:bg-[#292E34] transition-colors"
                >
                  {language === 'de' ? 'Ziel anlegen' : 'Save Goal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Deposit Modal */}
      {depositGoal && (
        <div className="fixed inset-0 z-50 bg-[#172536]/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl max-w-sm w-full p-6 space-y-4 shadow-xl relative animate-in fade-in">
            <button
              onClick={() => setDepositGoal(null)}
              className="absolute top-4 right-4 p-1.5 text-[#75808C] hover:text-[#172536] rounded"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <h3 className="text-base font-semibold text-[#172536]">
                {language === 'de' ? 'Einzahlung simulieren' : 'Simulate Deposit'}
              </h3>
              <p className="text-xs text-[#75808C]">
                {language === 'de' ? `Für „${depositGoal.name}“` : `For “${depositGoal.name}”`}
              </p>
            </div>

            {depositError && (
              <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded">
                {depositError}
              </div>
            )}

            <form onSubmit={handleExecuteDeposit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-medium text-[#172536]">
                  {language === 'de' ? 'Betrag in €' : 'Amount in €'}
                </label>
                <input
                  type="number"
                  min="5"
                  step="5"
                  value={depositAmountInput}
                  onChange={(e) => setDepositAmountInput(e.target.value)}
                  className="w-full px-3 py-2 text-base font-mono bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536]"
                />
                <p className="text-[11px] text-[#75808C]">
                  {language === 'de' ? 'Verfügbares Giro-Guthaben:' : 'Available balance:'}{' '}
                  {formatCurrency(balance, language)}
                </p>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setDepositGoal(null)}
                  className="w-1/2 py-2 bg-[#F7F6F2] text-[#172536] rounded font-semibold hover:bg-[#E8E5DE]"
                >
                  {language === 'de' ? 'Abbrechen' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2 bg-[#286B59] text-white rounded font-semibold hover:bg-[#286B59]/90"
                >
                  {language === 'de' ? 'Jetzt einzahlen' : 'Deposit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
