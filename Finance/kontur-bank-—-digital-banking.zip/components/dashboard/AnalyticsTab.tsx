'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency } from '@/lib/formatters';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
} from 'recharts';
import { MONTHLY_SPENDING_BREAKDOWN, MONTHLY_TREND_DATA } from '@/data/mockData';
import { ArrowUpRight, ArrowDownRight, PieChart as PieIcon, TrendingUp } from 'lucide-react';

export function AnalyticsTab() {
  const { t, language } = useBanking();
  const [activeChartPeriod, setActiveChartPeriod] = useState<'6m' | '12m'>('6m');

  const totalSpent = MONTHLY_SPENDING_BREAKDOWN.reduce((acc, c) => acc + c.amount, 0);

  return (
    <div className="space-y-8">
      {/* Analytics Header */}
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 sm:p-8 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold text-[#172536]">
              {language === 'de' ? 'Finanzanalyse & Budgetierung' : 'Financial Analytics & Budgeting'}
            </h2>
            <p className="text-xs text-[#75808C]">
              {language === 'de'
                ? 'Monatliche Auswertung von Einnahmen, Fixkosten und Konsumausgaben'
                : 'Monthly spending evaluation, fixed costs, and consumption analysis'}
            </p>
          </div>

          <div className="flex items-center gap-1 bg-[#F7F6F2] p-1 rounded border border-[#E8E5DE]">
            <button
              onClick={() => setActiveChartPeriod('6m')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeChartPeriod === '6m'
                  ? 'bg-[#172536] text-white shadow-sm'
                  : 'text-[#292E34]'
              }`}
            >
              {language === 'de' ? '6 Monate' : '6 Months'}
            </button>
            <button
              onClick={() => setActiveChartPeriod('12m')}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                activeChartPeriod === '12m'
                  ? 'bg-[#172536] text-white shadow-sm'
                  : 'text-[#292E34]'
              }`}
            >
              {language === 'de' ? '12 Monate (Projektion)' : '12 Months (Projected)'}
            </button>
          </div>
        </div>

        {/* Top 3 KPI stat cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-[#E8E5DE]">
          <div className="p-4 bg-[#F7F6F2] rounded-lg">
            <span className="text-[11px] font-mono text-[#75808C] uppercase">
              {language === 'de' ? 'Durchschn. Ausgaben / Mo.' : 'Avg. Monthly Outflow'}
            </span>
            <p className="text-xl font-semibold text-[#172536] tabular-nums font-mono mt-1">
              2.418,20 €
            </p>
            <p className="text-[11px] text-[#286B59] mt-0.5 flex items-center font-mono">
              <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" /> -3,4% vs. Vormonat
            </p>
          </div>

          <div className="p-4 bg-[#F7F6F2] rounded-lg">
            <span className="text-[11px] font-mono text-[#75808C] uppercase">
              {language === 'de' ? 'Sparquote Oktober' : 'Savings Rate October'}
            </span>
            <p className="text-xl font-semibold text-[#286B59] tabular-nums font-mono mt-1">
              34,5%
            </p>
            <p className="text-[11px] text-[#75808C] mt-0.5 font-mono">
              Ziel: min. 25% monatlich
            </p>
          </div>

          <div className="p-4 bg-[#F7F6F2] rounded-lg">
            <span className="text-[11px] font-mono text-[#75808C] uppercase">
              {language === 'de' ? 'Größter Ausgabenposten' : 'Top Category'}
            </span>
            <p className="text-xl font-semibold text-[#172536] mt-1">
              Wohnen (48%)
            </p>
            <p className="text-[11px] text-[#75808C] mt-0.5 font-mono">
              1.212,50 € (Miete + Strom)
            </p>
          </div>
        </div>
      </div>

      {/* 2-Column Split: Donut Category Chart & Cashflow Bar Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Category Donut Chart */}
        <div className="lg:col-span-5 bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 space-y-4 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-base font-semibold text-[#172536]">
              {language === 'de' ? 'Ausgaben nach Kategorie' : 'Spending by Category'}
            </h3>
            <p className="text-xs text-[#75808C]">
              {language === 'de' ? 'Aufschlüsselung für Oktober 2026' : 'Breakdown for October 2026'}
            </p>
          </div>

          <div className="h-64 w-full relative flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={MONTHLY_SPENDING_BREAKDOWN}
                  cx="50%"
                  cy="50%"
                  innerRadius={65}
                  outerRadius={95}
                  paddingAngle={3}
                  dataKey="amount"
                >
                  {MONTHLY_SPENDING_BREAKDOWN.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: any) => [`${formatCurrency(value, language)}`, '']}
                  contentStyle={{
                    backgroundColor: '#172536',
                    borderRadius: '6px',
                    border: 'none',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
              <span className="text-[11px] font-mono text-[#75808C] uppercase">
                {language === 'de' ? 'Gesamt' : 'Total'}
              </span>
              <span className="text-base font-semibold text-[#172536] font-mono">
                {formatCurrency(totalSpent, language)}
              </span>
            </div>
          </div>

          <div className="space-y-1.5 pt-2 border-t border-[#E8E5DE]">
            {MONTHLY_SPENDING_BREAKDOWN.map((cat) => (
              <div key={cat.category} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-sm"
                    style={{ backgroundColor: cat.color }}
                  />
                  <span className="text-[#172536] font-medium">{cat.category}</span>
                </div>
                <div className="flex items-center gap-3 font-mono">
                  <span className="text-[#75808C]">{cat.percentage}%</span>
                  <span className="font-semibold text-[#172536] tabular-nums">
                    {formatCurrency(cat.amount, language)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 6-Month Income vs Expenses Comparison Chart */}
        <div className="lg:col-span-7 bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 space-y-4 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-base font-semibold text-[#172536]">
              {language === 'de' ? 'Einnahmen vs. Ausgaben im Trend' : 'Income vs Expenses Trend'}
            </h3>
            <p className="text-xs text-[#75808C]">
              {language === 'de' ? 'Gegenüberstellung des monatlichen Netto-Cashflows' : 'Comparison of monthly net cashflow'}
            </p>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MONTHLY_TREND_DATA} margin={{ top: 20, right: 20, left: 0, bottom: 5 }}>
                <XAxis dataKey="month" stroke="#75808C" fontSize={12} tickLine={false} />
                <YAxis stroke="#75808C" fontSize={11} tickLine={false} tickFormatter={(val) => `${val / 1000}k €`} />
                <Tooltip
                  formatter={(val: any) => [`${val} €`, '']}
                  contentStyle={{
                    backgroundColor: '#172536',
                    borderRadius: '6px',
                    border: 'none',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }}
                />
                <Bar dataKey="income" name="Einnahmen (€)" fill="#286B59" radius={[3, 3, 0, 0]} />
                <Bar dataKey="expenses" name="Ausgaben (€)" fill="#172536" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="p-3 bg-[#F7F6F2] rounded-lg border border-[#E8E5DE] text-xs text-[#75808C] flex items-center justify-between font-mono">
            <span>{language === 'de' ? 'Netto-Überschuss Okt.:' : 'Net Surplus Oct:'} +1.330,35 €</span>
            <span className="text-[#286B59] font-semibold">{language === 'de' ? 'Finanziell stabil' : 'Healthy status'}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
