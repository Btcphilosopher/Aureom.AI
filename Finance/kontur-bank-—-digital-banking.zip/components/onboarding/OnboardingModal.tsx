'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import {
  X,
  ArrowRight,
  ArrowLeft,
  Check,
  ShieldCheck,
  CheckCircle2,
  CreditCard,
  User,
  Mail,
  MapPin,
  Sparkles,
} from 'lucide-react';

export function OnboardingModal() {
  const {
    language,
    isOnboardingOpen,
    closeOnboarding,
    setCurrentView,
  } = useBanking();

  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5 | 6 | 7>(1);

  // Form states
  const [country, setCountry] = useState('Deutschland');
  const [taxResidence, setTaxResidence] = useState('Deutschland');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [dob, setDob] = useState('');
  const [nationality, setNationality] = useState('Deutsch');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<'free' | 'plus'>('plus');
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOnboardingOpen) return null;

  const handleNext = () => {
    setErrorMsg('');

    if (step === 2) {
      if (!country) {
        setErrorMsg('Bitte wähle dein Wohnsitzland aus.');
        return;
      }
    } else if (step === 3) {
      if (!firstName.trim() || !lastName.trim()) {
        setErrorMsg('Bitte gib Vor- und Nachnamen ein.');
        return;
      }
    } else if (step === 4) {
      if (!email.includes('@') || !email.includes('.')) {
        setErrorMsg('Bitte gib eine gültige E-Mail-Adresse ein.');
        return;
      }
    } else if (step === 6) {
      if (!agreedTerms) {
        setErrorMsg('Bitte bestätige die prototype-relevanten Bedingungen.');
        return;
      }
      setStep(7); // Completed
      return;
    }

    setStep((prev) => (prev + 1) as any);
  };

  const handleBack = () => {
    setErrorMsg('');
    setStep((prev) => (prev - 1) as any);
  };

  const handleFinish = () => {
    closeOnboarding();
    setCurrentView('dashboard');
  };

  const stepsLabels = [
    'Willkommen',
    'Wohnsitzland',
    'Persönliche Angaben',
    'Kontaktangaben',
    'Produktauswahl',
    'Zusammenfassung',
  ];

  return (
    <div className="fixed inset-0 z-50 bg-[#172536]/70 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-2xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative animate-in fade-in">
        {/* Close Button */}
        <button
          onClick={closeOnboarding}
          className="absolute top-5 right-5 p-1.5 text-[#75808C] hover:text-[#172536] rounded"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Progress Bar (if step <= 6) */}
        {step <= 6 && (
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-[#B98559] uppercase tracking-wider font-semibold">
                KONTUR ONBOARDING
              </span>
              <span className="text-[#75808C]">
                Schritt {step} von 6: {stepsLabels[step - 1]}
              </span>
            </div>
            <div className="w-full bg-[#E8E5DE] h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-[#172536] h-full transition-all duration-300 rounded-full"
                style={{ width: `${(step / 6) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* Error notice */}
        {errorMsg && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded">
            {errorMsg}
          </div>
        )}

        {/* STEP 1: Willkommen */}
        {step === 1 && (
          <div className="space-y-6 text-center py-4">
            <div className="w-16 h-16 rounded-2xl bg-[#F7F6F2] border border-[#E8E5DE] flex items-center justify-center mx-auto text-[#172536]">
              <Sparkles className="w-8 h-8 text-[#B98559]" />
            </div>

            <div className="space-y-2 max-w-md mx-auto">
              <h2 className="text-2xl font-semibold text-[#172536]">
                Willkommen bei KONTUR
              </h2>
              <p className="text-xs sm:text-sm text-[#75808C] leading-relaxed">
                Erlebe die kontoeröffnung der nächsten Generation. In wenigen simulierten Schritten zu deinem persönlichen KONTUR Girokonto.
              </p>
            </div>

            <div className="p-4 bg-[#F7F6F2] rounded-xl border border-[#E8E5DE] text-left text-xs space-y-2">
              <div className="flex items-center gap-2 font-medium text-[#172536]">
                <ShieldCheck className="w-4 h-4 text-[#286B59]" />
                <span>Interaktiver Prototyp ohne echte Ausweis-Scans</span>
              </div>
              <p className="text-[11px] text-[#75808C] leading-relaxed">
                Dies ist ein Demonstrationsablauf. Es werden keine Schufa-Auskünfte eingeholt oder reale Identitätsprüfungen durchgeführt.
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={handleNext}
                className="w-full py-3 bg-[#172536] hover:bg-[#292E34] text-white text-xs font-semibold rounded uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Jetzt starten</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Wohnsitzland */}
        {step === 2 && (
          <div className="space-y-5 text-xs">
            <div>
              <h3 className="text-lg font-semibold text-[#172536]">
                Wo hast du deinen ständigen Wohnsitz?
              </h3>
              <p className="text-[#75808C] mt-0.5">
                KONTUR richtet sich an Kunden mit steuerlichem Wohnsitz im EWR.
              </p>
            </div>

            <div className="space-y-2">
              {['Deutschland', 'Österreich', 'Schweiz'].map((c) => (
                <label
                  key={c}
                  onClick={() => setCountry(c)}
                  className={`flex items-center justify-between p-3.5 rounded-lg border cursor-pointer transition-all ${
                    country === c
                      ? 'border-[#172536] bg-[#F7F6F2] font-semibold text-[#172536]'
                      : 'border-[#E8E5DE] text-[#292E34] hover:bg-[#F7F6F2]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <MapPin className="w-4 h-4 text-[#75808C]" />
                    <span>{c}</span>
                  </div>
                  {country === c && <Check className="w-4 h-4 text-[#286B59]" />}
                </label>
              ))}
            </div>

            <div className="pt-4 flex justify-between gap-3">
              <button
                onClick={handleBack}
                className="px-4 py-2.5 bg-[#F7F6F2] hover:bg-[#E8E5DE] text-[#172536] rounded font-semibold transition-colors"
              >
                Zurück
              </button>
              <button
                onClick={handleNext}
                className="px-6 py-2.5 bg-[#172536] hover:bg-[#292E34] text-white rounded font-semibold transition-colors flex items-center gap-2"
              >
                <span>Weiter</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Persönliche Angaben */}
        {step === 3 && (
          <div className="space-y-5 text-xs">
            <div>
              <h3 className="text-lg font-semibold text-[#172536]">
                Persönliche Angaben
              </h3>
              <p className="text-[#75808C] mt-0.5">
                Gib deine Basisdaten für den Kontovertrag an.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-medium text-[#172536]">Vorname</label>
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="Maximilian"
                  className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536]"
                />
              </div>

              <div className="space-y-1">
                <label className="font-medium text-[#172536]">Nachname</label>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="Förster"
                  className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="font-medium text-[#172536]">Geburtsdatum</label>
                <input
                  type="date"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536] font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="font-medium text-[#172536]">Staatsangehörigkeit</label>
                <select
                  value={nationality}
                  onChange={(e) => setNationality(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536]"
                >
                  <option value="Deutsch">Deutsch</option>
                  <option value="Österreichisch">Österreichisch</option>
                  <option value="Schweizerisch">Schweizerisch</option>
                  <option value="Andere (EU)">Andere (EU)</option>
                </select>
              </div>
            </div>

            <div className="pt-4 flex justify-between gap-3">
              <button
                onClick={handleBack}
                className="px-4 py-2.5 bg-[#F7F6F2] hover:bg-[#E8E5DE] text-[#172536] rounded font-semibold transition-colors"
              >
                Zurück
              </button>
              <button
                onClick={handleNext}
                className="px-6 py-2.5 bg-[#172536] hover:bg-[#292E34] text-white rounded font-semibold transition-colors flex items-center gap-2"
              >
                <span>Weiter</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Kontaktangaben */}
        {step === 4 && (
          <div className="space-y-5 text-xs">
            <div>
              <h3 className="text-lg font-semibold text-[#172536]">
                Wie können wir dich erreichen?
              </h3>
              <p className="text-[#75808C] mt-0.5">
                Für Login-Bestätigungen und Push-Sicherheitsmitteilungen.
              </p>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <label className="font-medium text-[#172536]">E-Mail-Adresse</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#75808C] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="maximilian@example.de"
                    className="w-full pl-9 pr-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-medium text-[#172536]">Mobilfunknummer</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+49 170 1234567"
                  className="w-full px-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536] font-mono"
                />
              </div>
            </div>

            <div className="pt-4 flex justify-between gap-3">
              <button
                onClick={handleBack}
                className="px-4 py-2.5 bg-[#F7F6F2] hover:bg-[#E8E5DE] text-[#172536] rounded font-semibold transition-colors"
              >
                Zurück
              </button>
              <button
                onClick={handleNext}
                className="px-6 py-2.5 bg-[#172536] hover:bg-[#292E34] text-white rounded font-semibold transition-colors flex items-center gap-2"
              >
                <span>Weiter</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Produktauswahl */}
        {step === 5 && (
          <div className="space-y-5 text-xs">
            <div>
              <h3 className="text-lg font-semibold text-[#172536]">
                Wähle dein KONTUR Paket
              </h3>
              <p className="text-[#75808C] mt-0.5">
                Jederzeit im Banking monatlich kündbar oder anpassbar.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div
                onClick={() => setSelectedPlan('free')}
                className={`p-4 rounded-xl border cursor-pointer transition-all space-y-3 ${
                  selectedPlan === 'free'
                    ? 'border-[#172536] bg-[#F7F6F2] shadow-sm ring-1 ring-[#172536]'
                    : 'border-[#E8E5DE] hover:border-[#75808C]'
                }`}
              >
                <div className="flex justify-between items-start">
                  <h4 className="font-semibold text-sm text-[#172536]">KONTUR Free</h4>
                  <span className="font-mono font-semibold text-[#172536]">0 € / Mo.</span>
                </div>
                <p className="text-[#75808C] text-[11px]">
                  Digitales Girokonto, virtuelle Debitkarte und Standard-Sparziele.
                </p>
              </div>

              <div
                onClick={() => setSelectedPlan('plus')}
                className={`p-4 rounded-xl border cursor-pointer transition-all space-y-3 ${
                  selectedPlan === 'plus'
                    ? 'border-[#172536] bg-[#F7F6F2] shadow-sm ring-1 ring-[#172536]'
                    : 'border-[#E8E5DE] hover:border-[#75808C]'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold text-sm text-[#172536]">KONTUR Metal</h4>
                    <span className="text-[10px] text-[#B98559] font-mono">Beliebteste Wahl</span>
                  </div>
                  <span className="font-mono font-semibold text-[#172536]">9,90 € / Mo.</span>
                </div>
                <p className="text-[#75808C] text-[11px]">
                  Gebürstete Edelstahl-Karte, weltweiter Reiseversicherungsschutz & 5 Unterkonten.
                </p>
              </div>
            </div>

            <div className="pt-4 flex justify-between gap-3">
              <button
                onClick={handleBack}
                className="px-4 py-2.5 bg-[#F7F6F2] hover:bg-[#E8E5DE] text-[#172536] rounded font-semibold transition-colors"
              >
                Zurück
              </button>
              <button
                onClick={handleNext}
                className="px-6 py-2.5 bg-[#172536] hover:bg-[#292E34] text-white rounded font-semibold transition-colors flex items-center gap-2"
              >
                <span>Weiter zur Übersicht</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 6: Zusammenfassung */}
        {step === 6 && (
          <div className="space-y-5 text-xs">
            <div>
              <h3 className="text-lg font-semibold text-[#172536]">
                Zusammenfassung deiner Angaben
              </h3>
              <p className="text-[#75808C] mt-0.5">
                Überprüfe deine Eingaben vor dem simulierten Kontoabschluss.
              </p>
            </div>

            <div className="p-4 bg-[#F7F6F2] border border-[#E8E5DE] rounded-xl space-y-2.5 font-mono">
              <div className="flex justify-between">
                <span className="text-[#75808C]">Name:</span>
                <span className="text-[#172536] font-semibold">{firstName || 'Maximilian'} {lastName || 'Förster'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#75808C]">Wohnsitz:</span>
                <span className="text-[#172536]">{country}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#75808C]">E-Mail:</span>
                <span className="text-[#172536]">{email || 'maximilian@example.de'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#75808C]">Paket:</span>
                <span className="text-[#286B59] font-semibold">{selectedPlan === 'plus' ? 'KONTUR Metal' : 'KONTUR Free'}</span>
              </div>
            </div>

            <label className="flex items-start gap-2.5 text-xs text-[#292E34] pt-1 cursor-pointer">
              <input
                type="checkbox"
                checked={agreedTerms}
                onChange={(e) => setAgreedTerms(e.target.checked)}
                className="mt-0.5 accent-[#172536] rounded"
              />
              <span className="leading-relaxed">
                Ich bestätige, dass dies ein Demonstrationsprototyp ist und kein rechtlich bindender Bankvertrag geschlossen wird.
              </span>
            </label>

            <div className="pt-4 flex justify-between gap-3">
              <button
                onClick={handleBack}
                className="px-4 py-2.5 bg-[#F7F6F2] hover:bg-[#E8E5DE] text-[#172536] rounded font-semibold transition-colors"
              >
                Zurück
              </button>
              <button
                onClick={handleNext}
                className="px-6 py-2.5 bg-[#286B59] hover:bg-[#286B59]/90 text-white rounded font-semibold transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Simuliertes Konto aktivieren</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 7: Fertiggestellt / Success */}
        {step === 7 && (
          <div className="space-y-6 text-center py-6 text-xs">
            <div className="w-16 h-16 rounded-full bg-[#DDE9E0] text-[#286B59] flex items-center justify-center mx-auto border border-[#286B59]/30">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2 max-w-sm mx-auto">
              <h2 className="text-2xl font-semibold text-[#172536]">
                Konto erfolgreich eingerichtet!
              </h2>
              <p className="text-xs text-[#75808C] leading-relaxed">
                Willkommen bei KONTUR. Dein Testzugang ist sofort freigeschaltet und mit Muster-Guthaben ausgestattet.
              </p>
            </div>

            <div className="p-4 bg-[#F7F6F2] border border-[#E8E5DE] rounded-xl text-left font-mono space-y-1 max-w-sm mx-auto">
              <p className="text-[10px] text-[#75808C] uppercase">Neue IBAN</p>
              <p className="text-sm font-semibold text-[#172536]">DE89 3704 0044 0532 0130 00</p>
              <p className="text-[11px] text-[#286B59] pt-1">Startguthaben: 12.840,65 €</p>
            </div>

            <div className="pt-2">
              <button
                onClick={handleFinish}
                className="w-full py-3.5 bg-[#172536] hover:bg-[#292E34] text-white text-xs font-semibold rounded uppercase tracking-wider transition-colors cursor-pointer"
              >
                Direkt zum Banking-Dashboard
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
