'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { X, ArrowRight, CheckCircle2, Mail, User } from 'lucide-react';

export function WaitlistModal() {
  const {
    t,
    language,
    isWaitlistModalOpen,
    closeWaitlistModal,
    setCurrentView,
  } = useBanking();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [consent, setConsent] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isWaitlistModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMessage(language === 'de' ? 'Bitte gib deinen Namen an.' : 'Please enter your name.');
      return;
    }
    if (!email.includes('@') || !email.includes('.')) {
      setErrorMessage(
        language === 'de'
          ? 'Bitte gib eine gültige E-Mail-Adresse ein.'
          : 'Please enter a valid email address.'
      );
      return;
    }
    if (!consent) {
      setErrorMessage(
        language === 'de'
          ? 'Bitte bestätige die Datenschutzerklärung.'
          : 'Please accept the privacy terms.'
      );
      return;
    }

    setErrorMessage('');
    setIsSubmitted(true);
  };

  const handleClose = () => {
    setIsSubmitted(false);
    setName('');
    setEmail('');
    setConsent(false);
    setErrorMessage('');
    closeWaitlistModal();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#172536]/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-2xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl relative animate-in fade-in text-[#172536]">
        <button
          onClick={handleClose}
          className="absolute top-5 right-5 p-1.5 text-[#75808C] hover:text-[#172536] rounded"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSubmitted ? (
          <div className="space-y-5">
            <div className="space-y-1">
              <span className="text-[10px] font-mono uppercase text-[#B98559] tracking-wider">
                {language === 'de' ? 'GESCHLOSSENE BETA' : 'CLOSED BETA'}
              </span>
              <h2 className="text-xl font-semibold text-[#172536]">
                {t.cta.headline}
              </h2>
              <p className="text-xs text-[#75808C]">
                {t.cta.subline}
              </p>
            </div>

            {errorMessage && (
              <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded">
                {errorMessage}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-medium text-[#172536]">
                  {language === 'de' ? 'Vollständiger Name' : 'Full Name'}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-[#75808C] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Maximilian Förster"
                    className="w-full pl-9 pr-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded text-[#172536] focus:outline-none focus:border-[#172536]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-medium text-[#172536]">
                  {language === 'de' ? 'E-Mail-Adresse' : 'Email Address'}
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#75808C] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="maximilian@example.de"
                    className="w-full pl-9 pr-3 py-2 bg-[#F7F6F2] border border-[#E8E5DE] rounded text-[#172536] focus:outline-none focus:border-[#172536]"
                  />
                </div>
              </div>

              <label className="flex items-start gap-2.5 text-xs text-[#75808C] pt-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={consent}
                  onChange={(e) => setConsent(e.target.checked)}
                  className="mt-0.5 accent-[#172536] rounded"
                />
                <span className="leading-relaxed">{t.cta.privacyAgreement}</span>
              </label>

              <button
                type="submit"
                className="w-full py-3 bg-[#172536] hover:bg-[#292E34] text-white text-xs font-semibold rounded uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <span>{t.cta.button}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        ) : (
          <div className="space-y-5 text-center py-4 text-xs">
            <div className="w-14 h-14 rounded-full bg-[#DDE9E0] text-[#286B59] flex items-center justify-center mx-auto border border-[#286B59]/30">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-xl font-semibold text-[#172536]">
                {t.cta.successTitle}
              </h3>
              <p className="text-xs text-[#75808C] leading-relaxed">
                {t.cta.successDesc}
              </p>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => {
                  handleClose();
                  setCurrentView('dashboard');
                }}
                className="w-full py-3 bg-[#172536] text-white rounded font-semibold text-xs transition-colors"
              >
                {t.cta.directDemo}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
