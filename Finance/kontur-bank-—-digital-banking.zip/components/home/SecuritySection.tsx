'use client';

import React from 'react';
import { useBanking } from '@/context/BankingContext';
import { Shield, Fingerprint, Lock, Bell, Smartphone, AlertCircle } from 'lucide-react';

export function SecuritySection() {
  const { t, language } = useBanking();

  const capabilities = [
    {
      icon: <Fingerprint className="w-5 h-5 text-[#286B59]" />,
      title: t.security.item1Title,
      desc: t.security.item1Desc,
    },
    {
      icon: <Lock className="w-5 h-5 text-[#286B59]" />,
      title: t.security.item2Title,
      desc: t.security.item2Desc,
    },
    {
      icon: <Shield className="w-5 h-5 text-[#286B59]" />,
      title: t.security.item3Title,
      desc: t.security.item3Desc,
    },
    {
      icon: <Smartphone className="w-5 h-5 text-[#286B59]" />,
      title: t.security.item4Title,
      desc: t.security.item4Desc,
    },
  ];

  return (
    <section id="security" className="py-20 lg:py-28 bg-[#F7F6F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="max-w-2xl space-y-3">
          <p className="text-xs font-mono tracking-widest text-[#B98559] uppercase">
            {t.security.eyebrow}
          </p>
          <h2 className="text-3xl sm:text-4xl font-normal tracking-tight text-[#172536]">
            {t.security.headline}
          </h2>
          <p className="text-base text-[#75808C] leading-relaxed">
            {t.security.desc}
          </p>
        </div>

        {/* 4 Architectural Capabilities */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {capabilities.map((item, idx) => (
            <div
              key={idx}
              className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 space-y-4 shadow-sm"
            >
              <div className="w-10 h-10 rounded bg-[#DDE9E0]/50 flex items-center justify-center">
                {item.icon}
              </div>
              <h3 className="text-base font-semibold text-[#172536]">
                {item.title}
              </h3>
              <p className="text-xs text-[#75808C] leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Regulatory Disclosure Banner (Honest & Clear) */}
        <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 sm:p-8 flex flex-col sm:flex-row items-start gap-4">
          <div className="p-2.5 rounded bg-[#E8E5DE] text-[#172536] shrink-0">
            <AlertCircle className="w-5 h-5 text-[#B98559]" />
          </div>
          <div className="space-y-1.5">
            <h4 className="text-sm font-semibold text-[#172536]">
              {t.security.regulatoryNoticeTitle}
            </h4>
            <p className="text-xs text-[#75808C] leading-relaxed">
              {t.security.regulatoryNoticeText}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
