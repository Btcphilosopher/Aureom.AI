'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency } from '@/lib/formatters';
import { Lock, Unlock, Sliders, Smartphone, ShieldCheck, Check } from 'lucide-react';

export function CardsShowcase() {
  const {
    t,
    language,
    cards,
    toggleCardFreeze,
    updateSpendingLimit,
    toggleCardPermission,
  } = useBanking();
  const [activeCardType, setActiveCardType] = useState<'physical' | 'virtual'>('physical');

  const currentCard = cards.find((c) => c.type === activeCardType) || cards[0];

  return (
    <section id="cards" className="py-20 lg:py-28 bg-[#F7F6F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="max-w-2xl space-y-3">
          <p className="text-xs font-mono tracking-widest text-[#B98559] uppercase">
            {t.cards.eyebrow}
          </p>
          <h2 className="text-3xl sm:text-4xl font-normal tracking-tight text-[#172536]">
            {t.cards.headline}
          </h2>
          <p className="text-base text-[#75808C] leading-relaxed">
            {t.cards.desc}
          </p>
        </div>

        {/* 2-Column Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Visual Card Rendering or Studio Card Photo */}
          <div className="lg:col-span-6 space-y-6">
            <div className="relative aspect-[16/10] rounded-2xl overflow-hidden border border-[#E8E5DE] shadow-md bg-[#292E34]">
              {activeCardType === 'physical' ? (
                <Image
                  src="/images/card_showcase.jpg"
                  alt="KONTUR Edelstahl Metallkarte"
                  fill
                  className="object-cover transition-opacity duration-300"
                  referrerPolicy="no-referrer"
                />
              ) : (
                /* Virtual Card Graphic */
                <div className="w-full h-full bg-gradient-to-br from-[#172536] via-[#292E34] to-[#587CA0] p-8 flex flex-col justify-between text-white relative">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-xs font-mono tracking-[0.25em] text-[#B98559]">
                        KONTUR
                      </span>
                      <p className="text-[10px] text-white/60 uppercase tracking-widest">
                        {language === 'de' ? 'Virtuelle Karte' : 'Virtual Card'}
                      </p>
                    </div>
                    <Smartphone className="w-6 h-6 text-white/70" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-lg tracking-widest">
                        •••• •••• •••• {currentCard.last4}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs text-white/70 font-mono">
                      <span>{currentCard.nameOnCard}</span>
                      <span>EXP {currentCard.expiry}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Status Badge Over Image */}
              <div className="absolute top-4 right-4 bg-[#172536]/80 backdrop-blur-md text-white text-[11px] font-mono px-3 py-1 rounded-full border border-white/10 flex items-center gap-1.5">
                <span
                  className={`w-2 h-2 rounded-full ${
                    currentCard.isFrozen ? 'bg-red-400' : 'bg-[#286B59]'
                  }`}
                />
                <span>
                  {currentCard.isFrozen
                    ? language === 'de'
                      ? 'Gesperrt'
                      : 'Frozen'
                    : language === 'de'
                    ? 'Aktiv'
                    : 'Active'}
                </span>
              </div>
            </div>

            {/* Apple Pay & Google Wallet Support Banner */}
            <div className="flex items-center justify-between p-4 bg-[#FFFFFF] border border-[#E8E5DE] rounded-lg text-xs text-[#292E34]">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#75808C]" />
                <span className="font-medium">{t.cards.applePayReady}</span>
              </div>
              <span className="text-[#75808C] font-mono">NFC / Contactless</span>
            </div>
          </div>

          {/* Right Column: Live Interactive Card Controls */}
          <div className="lg:col-span-6 bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 sm:p-8 space-y-6 shadow-sm">
            {/* Card selector tabs */}
            <div className="flex items-center gap-2 pb-4 border-b border-[#E8E5DE]">
              <button
                onClick={() => setActiveCardType('physical')}
                className={`px-4 py-2 text-xs font-semibold rounded cursor-pointer transition-colors ${
                  activeCardType === 'physical'
                    ? 'bg-[#172536] text-white'
                    : 'bg-[#F7F6F2] text-[#292E34] hover:bg-[#E8E5DE]'
                }`}
              >
                {t.cards.physicalCard}
              </button>
              <button
                onClick={() => setActiveCardType('virtual')}
                className={`px-4 py-2 text-xs font-semibold rounded cursor-pointer transition-colors ${
                  activeCardType === 'virtual'
                    ? 'bg-[#172536] text-white'
                    : 'bg-[#F7F6F2] text-[#292E34] hover:bg-[#E8E5DE]'
                }`}
              >
                {t.cards.virtualCard}
              </button>
            </div>

            {/* Freeze & Unfreeze Action */}
            <div className="flex items-center justify-between p-4 bg-[#F7F6F2] rounded-lg border border-[#E8E5DE]">
              <div>
                <h4 className="text-sm font-semibold text-[#172536]">
                  {currentCard.isFrozen ? t.cards.unfreezeCard : t.cards.freezeCard}
                </h4>
                <p className="text-xs text-[#75808C] mt-0.5">
                  {currentCard.isFrozen
                    ? t.cards.cardFrozenNotice
                    : language === 'de'
                    ? 'Transaktionen sofort blockieren oder freigeben'
                    : 'Instantly block or allow card payments'}
                </p>
              </div>

              <button
                onClick={() => toggleCardFreeze(currentCard.id)}
                className={`px-4 py-2 text-xs font-medium rounded transition-colors flex items-center gap-1.5 cursor-pointer ${
                  currentCard.isFrozen
                    ? 'bg-[#286B59] hover:bg-[#286B59]/90 text-white'
                    : 'bg-[#172536] hover:bg-[#292E34] text-white'
                }`}
              >
                {currentCard.isFrozen ? (
                  <>
                    <Unlock className="w-3.5 h-3.5" />
                    <span>{t.cards.unfreezeCard}</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    <span>{t.cards.freezeCard}</span>
                  </>
                )}
              </button>
            </div>

            {/* Daily Spending Limit Slider */}
            <div className="space-y-3 p-4 bg-[#F7F6F2] rounded-lg border border-[#E8E5DE]">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-[#172536]">
                  {t.cards.spendingLimit}
                </span>
                <span className="font-mono font-semibold text-[#172536] tabular-nums">
                  {formatCurrency(currentCard.spendingLimit, language)}
                </span>
              </div>

              <input
                type="range"
                min="200"
                max="5000"
                step="100"
                value={currentCard.spendingLimit}
                onChange={(e) =>
                  updateSpendingLimit(currentCard.id, Number(e.target.value))
                }
                className="w-full accent-[#172536] cursor-pointer"
              />

              <div className="flex justify-between text-[11px] text-[#75808C] font-mono">
                <span>Min: 200 €</span>
                <span>
                  {language === 'de' ? 'Heute verbraucht:' : 'Spent today:'}{' '}
                  {formatCurrency(currentCard.dailySpent, language)}
                </span>
                <span>Max: 5.000 €</span>
              </div>
            </div>

            {/* Feature Toggles */}
            <div className="space-y-2 pt-2">
              <label className="flex items-center justify-between p-3 rounded border border-[#E8E5DE] hover:bg-[#F7F6F2] transition-colors cursor-pointer">
                <span className="text-xs font-medium text-[#172536]">
                  {t.cards.onlinePayments}
                </span>
                <input
                  type="checkbox"
                  checked={currentCard.allowOnline}
                  onChange={() => toggleCardPermission(currentCard.id, 'allowOnline')}
                  className="w-4 h-4 accent-[#172536] rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded border border-[#E8E5DE] hover:bg-[#F7F6F2] transition-colors cursor-pointer">
                <span className="text-xs font-medium text-[#172536]">
                  {t.cards.foreignPayments}
                </span>
                <input
                  type="checkbox"
                  checked={currentCard.allowForeign}
                  onChange={() => toggleCardPermission(currentCard.id, 'allowForeign')}
                  className="w-4 h-4 accent-[#172536] rounded"
                />
              </label>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
