'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { ArrowRight, CheckCircle2, ShieldCheck, Mail, User } from 'lucide-react';

export function WaitlistSection() {
  const { t, language, setCurrentView } = useBanking();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [consent, setConsent] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMessage(
        language === 'de' ? 'Bitte gib deinen Namen an.' : 'Please enter your name.'
      );
      return;
    }
    if (!email.includes('@') || !email.includes('.')) {
      setErrorMessage(
        language === 'de'
          ? 'Bitte gib eine gültige E-Mail-Adresse ein.'
          : 'Please enter a valid email address.'
      );
      return;
    }
    if (!consent) {
      setErrorMessage(
        language === 'de'
          ? 'Bitte bestätige die Datenschutzerklärung.'
          : 'Please accept the privacy terms.'
      );
      return;
    }

    setErrorMessage('');
    setIsSubmitted(true);
  };

  return (
    <section id="waitlist" className="py-20 lg:py-28 bg-[#172536] text-white relative overflow-hidden">
      {/* Subtle architectural background texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.04]"
        style={{
          backgroundImage:
            'radial-gradient(#FFFFFF 1px, transparent 1px)',
          backgroundSize: '24px 24px',
        }}
        aria-hidden="true"
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center space-y-8">
        <div className="space-y-4 max-w-2xl mx-auto">
          <p className="text-xs font-mono tracking-widest text-[#B98559] uppercase">
            {language === 'de' ? 'GESCHLOSSENE BETA' : 'CLOSED BETA'}
          </p>
          <h2 className="text-3xl sm:text-5xl font-normal tracking-tight text-white leading-tight">
            {t.cta.headline}
          </h2>
          <p className="text-base text-white/70 leading-relaxed">
            {t.cta.subline}
          </p>
        </div>

        {!isSubmitted ? (
          <form
            onSubmit={handleSubmit}
            className="max-w-xl mx-auto bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-6 sm:p-8 space-y-4 text-left"
          >
            {errorMessage && (
              <div className="p-3 bg-red-500/20 border border-red-500/30 rounded text-red-200 text-xs">
                {errorMessage}
              </div>
            )}

            <div className="space-y-1.5">
              <label className="text-xs font-mono uppercase text-white/60">
                {language === 'de' ? 'Vollständiger Name' : 'Full Name'}
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Maximilian Förster"
                  className="w-full pl-9 pr-4 py-2.5 bg-white/10 border border-white/20 rounded text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#B98559]"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-mono uppercase text-white/60">
                {language === 'de' ? 'E-Mail-Adresse' : 'Email Address'}
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="maximilian@example.de"
                  className="w-full pl-9 pr-4 py-2.5 bg-white/10 border border-white/20 rounded text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#B98559]"
                />
              </div>
            </div>

            <label className="flex items-start gap-2.5 text-xs text-white/70 pt-1 cursor-pointer">
              <input
                type="checkbox"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                className="mt-0.5 accent-[#B98559] rounded"
              />
              <span>{t.cta.privacyAgreement}</span>
            </label>

            <button
              type="submit"
              className="w-full py-3.5 bg-[#B98559] hover:bg-[#a6744a] text-white text-xs font-semibold rounded uppercase tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-2 mt-2"
            >
              <span>{t.cta.button}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <p className="text-[11px] text-white/40 text-center font-mono pt-1">
              {language === 'de'
                ? 'Kein echtes Bankkonto. Reine Produkt-Vormerkung ohne Schufa-Abfrage.'
                : 'No real bank account created. Product waitlist only.'}
            </p>
          </form>
        ) : (
          <div className="max-w-md mx-auto bg-white/5 border border-white/10 rounded-xl p-8 space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-[#286B59]/30 border border-[#286B59] flex items-center justify-center mx-auto text-[#286B59]">
              <CheckCircle2 className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="text-xl font-semibold text-white">
              {t.cta.successTitle}
            </h3>
            <p className="text-xs text-white/70 leading-relaxed">
              {t.cta.successDesc}
            </p>

            <div className="pt-4 border-t border-white/10 flex flex-col gap-2">
              <button
                onClick={() => setCurrentView('dashboard')}
                className="w-full py-2.5 bg-white text-[#172536] hover:bg-white/90 text-xs font-semibold rounded transition-colors"
              >
                {t.cta.directDemo}
              </button>
              <button
                onClick={() => {
                  setIsSubmitted(false);
                  setName('');
                  setEmail('');
                  setConsent(false);
                }}
                className="text-xs text-white/50 hover:text-white transition-colors"
              >
                {language === 'de' ? 'Weitere Person eintragen' : 'Register another person'}
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
