'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency, formatRelativeDate } from '@/lib/formatters';
import { Search, ArrowDownLeft, ArrowUpRight, CheckCircle2, Shield } from 'lucide-react';
import { TransactionCategory } from '@/types/banking';

export function EverydayBanking() {
  const { t, language, transactions, setCurrentView } = useBanking();
  const [filterType, setFilterType] = useState<'all' | 'incoming' | 'outgoing'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = transactions.filter((tx) => {
    const matchesSearch =
      tx.merchant.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (tx.notes && tx.notes.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;
    if (filterType === 'incoming') return tx.amount > 0;
    if (filterType === 'outgoing') return tx.amount < 0;
    return true;
  }).slice(0, 5);

  return (
    <section id="banking" className="py-20 lg:py-28 bg-[#F7F6F2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="max-w-2xl space-y-3">
          <p className="text-xs font-mono tracking-widest text-[#B98559] uppercase">
            {t.everyday.eyebrow}
          </p>
          <h2 className="text-3xl sm:text-4xl font-normal tracking-tight text-[#172536]">
            {t.everyday.headline}
          </h2>
          <p className="text-base text-[#75808C] leading-relaxed">
            {t.everyday.desc}
          </p>
        </div>

        {/* 2-Column Split: Architectural Image & Interactive Account Preview */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Berlin Architecture Image & Feature highlights */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="relative aspect-[4/3] rounded-xl overflow-hidden border border-[#E8E5DE] shadow-sm bg-[#E8E5DE]">
              <Image
                src="/images/berlin_architecture.jpg"
                alt="KONTUR Architektur Berlin"
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#172536]/80 via-transparent to-transparent flex items-end p-6">
                <p className="text-xs font-mono text-white/90">
                  {t.everyday.photoCaption}
                </p>
              </div>
            </div>

            {/* Feature Points */}
            <div className="bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#286B59] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-[#172536]">
                    {t.everyday.feature1Title}
                  </h4>
                  <p className="text-xs text-[#75808C] mt-0.5">
                    {t.everyday.feature1Desc}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#286B59] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-[#172536]">
                    {t.everyday.feature2Title}
                  </h4>
                  <p className="text-xs text-[#75808C] mt-0.5">
                    {t.everyday.feature2Desc}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-[#286B59] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-[#172536]">
                    {t.everyday.feature3Title}
                  </h4>
                  <p className="text-xs text-[#75808C] mt-0.5">
                    {t.everyday.feature3Desc}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Interactive Account Experience */}
          <div className="lg:col-span-7 bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl p-6 sm:p-8 space-y-6 flex flex-col justify-between shadow-sm">
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E8E5DE]">
                <div>
                  <h3 className="text-lg font-semibold text-[#172536]">
                    {language === 'de' ? 'Live-Umsatzübersicht' : 'Live Transaction Feed'}
                  </h3>
                  <p className="text-xs text-[#75808C]">
                    {language === 'de'
                      ? 'Interaktive Filter und Suche im Musterkonto'
                      : 'Interactive filters and search in sample account'}
                  </p>
                </div>

                {/* Segmented Filter Control */}
                <div className="flex items-center gap-1 bg-[#F7F6F2] p-1 rounded border border-[#E8E5DE]">
                  <button
                    onClick={() => setFilterType('all')}
                    className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                      filterType === 'all'
                        ? 'bg-[#172536] text-white shadow-sm'
                        : 'text-[#292E34] hover:text-[#172536]'
                    }`}
                  >
                    {language === 'de' ? 'Alle' : 'All'}
                  </button>
                  <button
                    onClick={() => setFilterType('incoming')}
                    className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                      filterType === 'incoming'
                        ? 'bg-[#172536] text-white shadow-sm'
                        : 'text-[#292E34] hover:text-[#172536]'
                    }`}
                  >
                    {language === 'de' ? 'Eingänge' : 'Income'}
                  </button>
                  <button
                    onClick={() => setFilterType('outgoing')}
                    className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                      filterType === 'outgoing'
                        ? 'bg-[#172536] text-white shadow-sm'
                        : 'text-[#292E34] hover:text-[#172536]'
                    }`}
                  >
                    {language === 'de' ? 'Ausgaben' : 'Expenses'}
                  </button>
                </div>
              </div>

              {/* Search input */}
              <div className="relative">
                <Search className="w-4 h-4 text-[#75808C] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={
                    language === 'de'
                      ? 'Händler, Zweck oder Kategorie suchen...'
                      : 'Search merchant, purpose, or category...'
                  }
                  className="w-full pl-9 pr-4 py-2 text-xs bg-[#F7F6F2] border border-[#E8E5DE] rounded focus:outline-none focus:border-[#172536] text-[#172536] transition-colors"
                />
              </div>

              {/* Filtered list */}
              <div className="space-y-2.5 divide-y divide-[#E8E5DE]">
                {filtered.map((tx) => (
                  <div
                    key={tx.id}
                    className="pt-2.5 first:pt-0 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded flex items-center justify-center shrink-0 ${
                          tx.amount > 0
                            ? 'bg-[#286B59]/10 text-[#286B59]'
                            : 'bg-[#F7F6F2] text-[#172536]'
                        }`}
                      >
                        {tx.amount > 0 ? (
                          <ArrowDownLeft className="w-4 h-4" />
                        ) : (
                          <ArrowUpRight className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-[#172536]">
                          {tx.merchant}
                        </p>
                        <div className="flex items-center gap-2 text-[11px] text-[#75808C]">
                          <span>{tx.category}</span>
                          <span aria-hidden="true">·</span>
                          <span>{formatRelativeDate(tx.date, language)}</span>
                          {tx.notes && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="hidden sm:inline truncate max-w-[140px]">
                                {tx.notes}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <p
                        className={`text-xs font-semibold tabular-nums font-mono ${
                          tx.amount > 0 ? 'text-[#286B59]' : 'text-[#172536]'
                        }`}
                      >
                        {tx.amount > 0 ? '+' : ''}
                        {formatCurrency(tx.amount, language)}
                      </p>
                      <p className="text-[10px] text-[#75808C] font-mono">
                        {tx.status}
                      </p>
                    </div>
                  </div>
                ))}

                {filtered.length === 0 && (
                  <div className="py-8 text-center text-xs text-[#75808C]">
                    {language === 'de'
                      ? 'Keine Umsätze für diese Suchkriterien gefunden.'
                      : 'No transactions found matching your criteria.'}
                  </div>
                )}
              </div>
            </div>

            {/* Bottom link to full banking interface */}
            <div className="pt-4 border-t border-[#E8E5DE] flex items-center justify-between">
              <span className="text-xs text-[#75808C]">
                {language === 'de'
                  ? 'Alle Transaktionen mit PDF-Export im Dashboard verfügbar.'
                  : 'Full transaction history with PDF export available in demo.'}
              </span>
              <button
                onClick={() => setCurrentView('dashboard')}
                className="text-xs font-semibold text-[#172536] hover:text-[#B98559] transition-colors flex items-center gap-1 cursor-pointer"
              >
                <span>{language === 'de' ? 'Zum Dashboard' : 'Open Dashboard'}</span>
                <span>→</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
