'use client';

import React from 'react';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency } from '@/lib/formatters';
import { ArrowRight, CreditCard, ShieldCheck, TrendingDown, Sparkles } from 'lucide-react';

export function Hero() {
  const {
    t,
    language,
    balance,
    transactions,
    savingsGoals,
    setCurrentView,
    openWaitlistModal,
  } = useBanking();

  const recentTransactions = transactions.slice(0, 3);
  const primaryGoal = savingsGoals[0];

  return (
    <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
      {/* Background Architectural Grid Lines */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{
          backgroundImage:
            'linear-gradient(to right, #172536 1px, transparent 1px), linear-gradient(to bottom, #172536 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Proposition & CTAs */}
          <div className="lg:col-span-6 space-y-8">
            {/* Architectural German trust marker (in hero, not header) */}
            <div className="flex items-center gap-3 text-xs tracking-wider uppercase text-[#75808C] font-mono">
              <span className="text-[#172536] font-semibold">BERLIN</span>
              <span aria-hidden="true">/</span>
              <span>DEUTSCHE PRODUKTDISZIPLIN</span>
              <span aria-hidden="true">/</span>
              <span className="text-[#B98559]">2026</span>
            </div>

            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-normal tracking-[-0.03em] text-[#172536] leading-[1.08] text-balance">
                {t.hero.headline}
              </h1>
              <p className="text-base sm:text-lg text-[#292E34]/80 leading-relaxed max-w-xl">
                {t.hero.subline}
              </p>
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={openWaitlistModal}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-[#172536] hover:bg-[#292E34] transition-all rounded shadow-sm hover:shadow cursor-pointer flex items-center gap-2 group"
              >
                <span>{t.hero.primaryCta}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
              </button>

              <button
                onClick={() => setCurrentView('dashboard')}
                className="px-6 py-3.5 text-sm font-medium text-[#172536] bg-[#FFFFFF] hover:bg-[#E8E5DE]/40 transition-all border border-[#172536]/20 rounded cursor-pointer flex items-center gap-2"
              >
                <span>{t.hero.secondaryCta}</span>
                <span className="text-xs text-[#75808C] font-mono">→ Demo</span>
              </button>
            </div>

            {/* Quiet Trust Notes */}
            <div className="pt-4 border-t border-[#E8E5DE] grid grid-cols-3 gap-4 text-xs text-[#75808C]">
              <div>
                <p className="font-semibold text-[#172536]">100% Digital</p>
                <p>Ohne Filialaufwand</p>
              </div>
              <div>
                <p className="font-semibold text-[#172536]">Echtzeit-SEPA</p>
                <p>Sofortüberweisungen</p>
              </div>
              <div>
                <p className="font-semibold text-[#172536]">DSGVO-Konform</p>
                <p>Europäische Server</p>
              </div>
            </div>
          </div>

          {/* Right Column: Live Banking Dashboard Preview */}
          <div className="lg:col-span-6 relative">
            {/* Subtle glow / shadow canvas */}
            <div className="relative bg-[#FFFFFF] border border-[#E8E5DE] rounded-xl shadow-xl p-6 sm:p-8 space-y-6">
              {/* Header of the preview widget */}
              <div className="flex items-center justify-between pb-4 border-b border-[#E8E5DE]">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2 text-xs font-mono text-[#75808C]">
                    <span>{t.hero.sampleAccountLabel}</span>
                  </div>
                  <p className="text-xs text-[#75808C]">Girokonto DE89 •••• 0000</p>
                </div>
                {/* Prototype disclosure pill (interactive demo badge) */}
                <div className="flex items-center gap-1.5 text-[11px] font-mono text-[#75808C] bg-[#F7F6F2] px-2.5 py-1 rounded border border-[#E8E5DE]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#B98559]" />
                  <span>{t.hero.demoBadge}</span>
                </div>
              </div>

              {/* Main Balance Display */}
              <div className="space-y-1">
                <p className="text-xs uppercase tracking-wider text-[#75808C] font-medium">
                  {t.hero.availableBalance}
                </p>
                <div className="flex items-baseline gap-3">
                  <span className="text-3xl sm:text-4xl font-semibold tracking-tight text-[#172536] tabular-nums">
                    {formatCurrency(balance, language)}
                  </span>
                  <span className="text-xs font-medium text-[#286B59] flex items-center">
                    +3.850,00 € {language === 'de' ? 'diesen Monat' : 'this month'}
                  </span>
                </div>
              </div>

              {/* Grid: Card Preview & Savings Goal */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Debit Card Preview */}
                <div className="bg-[#172536] text-white p-4 rounded-lg flex flex-col justify-between h-36 relative overflow-hidden shadow-inner">
                  <div className="flex justify-between items-start">
                    <span className="text-xs font-mono tracking-widest text-[#B98559]">KONTUR</span>
                    <CreditCard className="w-4 h-4 text-white/60" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-mono text-white/70">•••• •••• •••• 8834</p>
                    <div className="flex justify-between text-[10px] text-white/50 font-mono">
                      <span>M. FÖRSTER</span>
                      <span>11/29</span>
                    </div>
                  </div>
                  {/* Subtle metallic diagonal edge */}
                  <div className="absolute -right-6 -bottom-6 w-20 h-20 bg-[#B98559]/20 rounded-full blur-xl pointer-events-none" />
                </div>

                {/* Savings goal preview */}
                {primaryGoal && (
                  <div className="bg-[#F7F6F2] border border-[#E8E5DE] p-4 rounded-lg flex flex-col justify-between h-36">
                    <div className="flex justify-between items-start">
                      <span className="text-xs font-medium text-[#292E34] truncate max-w-[130px]">
                        {primaryGoal.name}
                      </span>
                      <span className="text-[11px] font-mono text-[#286B59] font-medium">
                        {Math.round((primaryGoal.currentAmount / primaryGoal.targetAmount) * 100)}%
                      </span>
                    </div>

                    <div className="space-y-2">
                      <div className="w-full bg-[#E8E5DE] h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-[#286B59] h-full transition-all duration-500 rounded-full"
                          style={{
                            width: `${Math.min(
                              100,
                              (primaryGoal.currentAmount / primaryGoal.targetAmount) * 100
                            )}%`,
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-[#75808C] tabular-nums font-mono">
                        <span>{formatCurrency(primaryGoal.currentAmount, language)}</span>
                        <span>Ziel: {formatCurrency(primaryGoal.targetAmount, language)}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Recent Activity List */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between text-xs font-medium text-[#75808C]">
                  <span>{language === 'de' ? 'Letzte Umsätze' : 'Recent Transactions'}</span>
                  <button
                    onClick={() => setCurrentView('dashboard')}
                    className="text-[#172536] hover:underline font-semibold cursor-pointer"
                  >
                    {language === 'de' ? 'Alle anzeigen →' : 'View all →'}
                  </button>
                </div>

                <div className="space-y-2">
                  {recentTransactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="flex items-center justify-between p-2.5 bg-[#F7F6F2]/70 hover:bg-[#F7F6F2] rounded border border-[#E8E5DE]/80 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-[#E8E5DE] flex items-center justify-between p-2 text-[#172536] text-xs font-semibold">
                          {tx.merchant.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-xs font-medium text-[#172536] truncate max-w-[180px]">
                            {tx.merchant}
                          </p>
                          <p className="text-[11px] text-[#75808C]">{tx.category}</p>
                        </div>
                      </div>
                      <span
                        className={`text-xs font-semibold tabular-nums font-mono ${
                          tx.amount > 0 ? 'text-[#286B59]' : 'text-[#172536]'
                        }`}
                      >
                        {tx.amount > 0 ? '+' : ''}
                        {formatCurrency(tx.amount, language)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
