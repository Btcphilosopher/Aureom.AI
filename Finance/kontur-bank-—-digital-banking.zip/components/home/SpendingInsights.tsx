'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency } from '@/lib/formatters';
import { ArrowDownRight, ArrowUpRight, TrendingUp } from 'lucide-react';

type Period = 'this_month' | 'last_month' | 'three_months';

interface SpendingCategoryData {
  category: string;
  amount: number;
  color: string;
  percentage: number;
  prevAmount: number;
}

const PERIOD_DATA: Record<Period, SpendingCategoryData[]> = {
  this_month: [
    { category: 'Wohnen', amount: 1212.50, color: '#172536', percentage: 48, prevAmount: 1212.50 },
    { category: 'Lebensmittel', amount: 480.25, color: '#286B59', percentage: 19, prevAmount: 510.00 },
    { category: 'Mobilität', amount: 165.90, color: '#587CA0', percentage: 7, prevAmount: 180.40 },
    { category: 'Einkäufe', amount: 320.40, color: '#B98559', percentage: 13, prevAmount: 290.00 },
    { category: 'Freizeit', amount: 185.60, color: '#75808C', percentage: 7, prevAmount: 215.30 },
    { category: 'Sonstiges', amount: 155.00, color: '#292E34', percentage: 6, prevAmount: 120.00 },
  ],
  last_month: [
    { category: 'Wohnen', amount: 1212.50, color: '#172536', percentage: 48, prevAmount: 1212.50 },
    { category: 'Lebensmittel', amount: 510.00, color: '#286B59', percentage: 20, prevAmount: 495.00 },
    { category: 'Mobilität', amount: 180.40, color: '#587CA0', percentage: 7, prevAmount: 170.00 },
    { category: 'Einkäufe', amount: 290.00, color: '#B98559', percentage: 11, prevAmount: 340.00 },
    { category: 'Freizeit', amount: 215.30, color: '#75808C', percentage: 8, prevAmount: 190.00 },
    { category: 'Sonstiges', amount: 120.00, color: '#292E34', percentage: 5, prevAmount: 130.00 },
  ],
  three_months: [
    { category: 'Wohnen', amount: 3637.50, color: '#172536', percentage: 48, prevAmount: 3637.50 },
    { category: 'Lebensmittel', amount: 1485.25, color: '#286B59', percentage: 20, prevAmount: 1520.00 },
    { category: 'Mobilität', amount: 516.30, color: '#587CA0', percentage: 7, prevAmount: 490.00 },
    { category: 'Einkäufe', amount: 950.40, color: '#B98559', percentage: 13, prevAmount: 880.00 },
    { category: 'Freizeit', amount: 590.90, color: '#75808C', percentage: 8, prevAmount: 610.00 },
    { category: 'Sonstiges', amount: 405.00, color: '#292E34', percentage: 5, prevAmount: 390.00 },
  ],
};

export function SpendingInsights() {
  const { t, language } = useBanking();
  const [period, setPeriod] = useState<Period>('this_month');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = PERIOD_DATA[period];
  const totalAmount = categories.reduce((sum, item) => sum + item.amount, 0);
  const prevTotalAmount = categories.reduce((sum, item) => sum + item.prevAmount, 0);
  const diffPercent = (((totalAmount - prevTotalAmount) / prevTotalAmount) * 100).toFixed(1);
  const isLower = totalAmount <= prevTotalAmount;

  return (
    <section className="py-20 lg:py-28 bg-[#FFFFFF] border-b border-[#E8E5DE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header with Period Selector */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl space-y-3">
            <p className="text-xs font-mono tracking-widest text-[#B98559] uppercase">
              {t.insights.eyebrow}
            </p>
            <h2 className="text-3xl sm:text-4xl font-normal tracking-tight text-[#172536]">
              {t.insights.headline}
            </h2>
            <p className="text-base text-[#75808C] leading-relaxed">
              {t.insights.desc}
            </p>
          </div>

          {/* Interactive Date-Range Selector */}
          <div className="flex items-center gap-1 bg-[#F7F6F2] p-1 rounded border border-[#E8E5DE] self-start md:self-auto">
            <button
              onClick={() => setPeriod('this_month')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                period === 'this_month'
                  ? 'bg-[#172536] text-white shadow-sm'
                  : 'text-[#292E34] hover:text-[#172536]'
              }`}
            >
              {t.insights.periodThisMonth}
            </button>
            <button
              onClick={() => setPeriod('last_month')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                period === 'last_month'
                  ? 'bg-[#172536] text-white shadow-sm'
                  : 'text-[#292E34] hover:text-[#172536]'
              }`}
            >
              {t.insights.periodLastMonth}
            </button>
            <button
              onClick={() => setPeriod('three_months')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer ${
                period === 'three_months'
                  ? 'bg-[#172536] text-white shadow-sm'
                  : 'text-[#292E34] hover:text-[#172536]'
              }`}
            >
              {t.insights.periodQuarter}
            </button>
          </div>
        </div>

        {/* Content Box */}
        <div className="bg-[#F7F6F2] border border-[#E8E5DE] rounded-xl p-6 sm:p-10 space-y-8">
          {/* Top KPI row */}
          <div className="flex flex-wrap items-baseline justify-between gap-4 pb-6 border-b border-[#E8E5DE]">
            <div>
              <p className="text-xs uppercase tracking-wider text-[#75808C] font-mono">
                {t.insights.totalSpent}
              </p>
              <p className="text-3xl sm:text-4xl font-semibold tracking-tight text-[#172536] tabular-nums font-mono mt-1">
                {formatCurrency(totalAmount, language)}
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono">
              <span
                className={`flex items-center font-semibold px-2 py-0.5 rounded ${
                  isLower
                    ? 'text-[#286B59] bg-[#DDE9E0]'
                    : 'text-[#B98559] bg-[#E8E5DE]'
                }`}
              >
                {isLower ? (
                  <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />
                ) : (
                  <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
                )}
                {diffPercent}%
              </span>
              <span className="text-[#75808C]">{t.insights.vsLastMonth}</span>
            </div>
          </div>

          {/* Visual Stacked Proportional Bar */}
          <div className="space-y-2">
            <div className="w-full h-5 rounded overflow-hidden flex bg-[#E8E5DE]">
              {categories.map((cat) => (
                <div
                  key={cat.category}
                  style={{
                    width: `${cat.percentage}%`,
                    backgroundColor: cat.color,
                  }}
                  className={`h-full transition-all duration-300 relative group cursor-pointer ${
                    selectedCategory === cat.category ? 'ring-2 ring-[#B98559] z-10' : ''
                  }`}
                  onClick={() =>
                    setSelectedCategory(
                      selectedCategory === cat.category ? null : cat.category
                    )
                  }
                  title={`${cat.category}: ${formatCurrency(cat.amount, language)} (${cat.percentage}%)`}
                />
              ))}
            </div>
            <p className="text-[11px] text-[#75808C] font-mono">
              {language === 'de'
                ? 'Klicke auf eine Kategorie in der Leiste oder Tabelle, um Details hervorzuheben.'
                : 'Click any category in the bar or table below to highlight details.'}
            </p>
          </div>

          {/* Category Cards / Table */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat.category;
              return (
                <div
                  key={cat.category}
                  onClick={() =>
                    setSelectedCategory(isSelected ? null : cat.category)
                  }
                  className={`p-4 rounded-lg border transition-all cursor-pointer bg-[#FFFFFF] ${
                    isSelected
                      ? 'border-[#172536] shadow-sm ring-1 ring-[#172536]'
                      : 'border-[#E8E5DE] hover:border-[#75808C]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3 h-3 rounded-sm shrink-0"
                        style={{ backgroundColor: cat.color }}
                      />
                      <span className="text-sm font-semibold text-[#172536]">
                        {t.insights.categories[cat.category as keyof typeof t.insights.categories] ||
                          cat.category}
                      </span>
                    </div>
                    <span className="text-xs font-mono text-[#75808C]">
                      {cat.percentage}%
                    </span>
                  </div>

                  <div className="mt-3 flex items-baseline justify-between">
                    <span className="text-base font-semibold text-[#172536] tabular-nums font-mono">
                      {formatCurrency(cat.amount, language)}
                    </span>
                    <span className="text-[11px] text-[#75808C]">
                      {language === 'de' ? 'Vormonat:' : 'Prev:'}{' '}
                      {formatCurrency(cat.prevAmount, language)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
