'use client';

import React from 'react';
import { useBanking } from '@/context/BankingContext';
import { Eye, Sliders, PieChart, Target } from 'lucide-react';

export function Benefits() {
  const { t } = useBanking();

  const icons = [
    <Eye key="eye" className="w-5 h-5 text-[#172536]" />,
    <Sliders key="sliders" className="w-5 h-5 text-[#172536]" />,
    <PieChart key="pie" className="w-5 h-5 text-[#172536]" />,
    <Target key="target" className="w-5 h-5 text-[#172536]" />,
  ];

  return (
    <section className="border-y border-[#E8E5DE] bg-[#FFFFFF] py-12 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6 divide-y md:divide-y-0 md:divide-x divide-[#E8E5DE]">
          {t.benefits.items.map((item, idx) => (
            <div
              key={idx}
              className={`space-y-3 ${idx !== 0 ? 'pt-6 md:pt-0 md:pl-6' : ''}`}
            >
              <div className="w-10 h-10 rounded bg-[#F7F6F2] border border-[#E8E5DE] flex items-center justify-center">
                {icons[idx]}
              </div>
              <h3 className="text-base font-semibold text-[#172536]">
                {item.title}
              </h3>
              <p className="text-sm text-[#75808C] leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
