'use client';

import React, { useState } from 'react';
import { useBanking } from '@/context/BankingContext';
import { formatCurrency } from '@/lib/formatters';
import { Plus, Target, ArrowRight, Check } from 'lucide-react';

export function SavingsSection() {
  const {
    t,
    language,
    savingsGoals,
    depositToSavingsGoal,
    setCurrentView,
    setActiveDashboardTab,
  } = useBanking();
  const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);
  const [depositAmount, setDepositAmount] = useState<number>(50);
  const [depositSuccess, setDepositSuccess] = useState<string | null>(null);

  const handleSimulateDeposit = (goalId: string) => {
    const success = depositToSavingsGoal(goalId, depositAmount);
    if (success) {
      setDepositSuccess(goalId);
      setTimeout(() => setDepositSuccess(null), 2500);
    }
  };

  return (
    <section id="savings" className="py-20 lg:py-28 bg-[#FFFFFF] border-b border-[#E8E5DE]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl space-y-3">
            <p className="text-xs font-mono tracking-widest text-[#B98559] uppercase">
              {t.savings.eyebrow}
            </p>
            <h2 className="text-3xl sm:text-4xl font-normal tracking-tight text-[#172536]">
              {t.savings.headline}
            </h2>
            <p className="text-base text-[#75808C] leading-relaxed">
              {t.savings.desc}
            </p>
          </div>

          <button
            onClick={() => {
              setCurrentView('dashboard');
              setActiveDashboardTab('savings');
            }}
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#172536] bg-[#F7F6F2] hover:bg-[#E8E5DE] transition-colors rounded border border-[#E8E5DE] cursor-pointer self-start md:self-auto"
          >
            <Plus className="w-4 h-4 text-[#172536]" />
            <span>{t.savings.addGoal}</span>
          </button>
        </div>

        {/* Savings Goals Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {savingsGoals.map((goal) => {
            const percent = Math.min(
              100,
              Math.round((goal.currentAmount / goal.targetAmount) * 100)
            );
            const isTargetReached = goal.currentAmount >= goal.targetAmount;

            return (
              <div
                key={goal.id}
                className="bg-[#F7F6F2] border border-[#E8E5DE] rounded-xl p-6 flex flex-col justify-between space-y-6 hover:shadow-sm transition-all"
              >
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[11px] font-mono uppercase text-[#75808C]">
                        {goal.category}
                      </span>
                      <h3 className="text-lg font-semibold text-[#172536] mt-0.5">
                        {goal.name}
                      </h3>
                    </div>
                    <div className="w-8 h-8 rounded bg-[#FFFFFF] border border-[#E8E5DE] flex items-center justify-center text-[#286B59]">
                      <Target className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="font-semibold text-[#172536]">
                        {percent}%
                      </span>
                      <span className="text-[#75808C]">
                        {language === 'de' ? 'Ziel' : 'Target'}: {goal.targetDate}
                      </span>
                    </div>

                    <div className="w-full bg-[#E8E5DE] h-2.5 rounded-full overflow-hidden">
                      <div
                        className="bg-[#286B59] h-full rounded-full transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>

                  {/* Amount Details */}
                  <div className="pt-2 flex justify-between items-baseline text-xs font-mono tabular-nums">
                    <div>
                      <p className="text-[10px] uppercase text-[#75808C]">
                        {language === 'de' ? 'Aktuell' : 'Current'}
                      </p>
                      <p className="text-base font-semibold text-[#172536]">
                        {formatCurrency(goal.currentAmount, language)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] uppercase text-[#75808C]">
                        {language === 'de' ? 'Zielbetrag' : 'Target'}
                      </p>
                      <p className="text-sm text-[#75808C]">
                        {formatCurrency(goal.targetAmount, language)}
                      </p>
                    </div>
                  </div>

                  <div className="p-2.5 bg-[#FFFFFF] rounded border border-[#E8E5DE] text-[11px] text-[#75808C] flex justify-between items-center">
                    <span>{t.savings.monthlyPlan}</span>
                    <span className="font-semibold text-[#172536] font-mono">
                      {formatCurrency(goal.monthlyContribution, language)} / Mo.
                    </span>
                  </div>
                </div>

                {/* Simulated Deposit Button */}
                <div className="pt-2 border-t border-[#E8E5DE]">
                  {depositSuccess === goal.id ? (
                    <div className="w-full py-2 bg-[#DDE9E0] text-[#286B59] text-xs font-semibold rounded flex items-center justify-center gap-1.5 font-mono">
                      <Check className="w-4 h-4" />
                      <span>+50,00 € {language === 'de' ? 'eingezahlt!' : 'deposited!'}</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleSimulateDeposit(goal.id)}
                      className="w-full py-2 bg-[#FFFFFF] hover:bg-[#172536] text-[#172536] hover:text-white border border-[#172536]/20 hover:border-transparent text-xs font-semibold rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <span>+50 € {t.savings.simulateDeposit}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
