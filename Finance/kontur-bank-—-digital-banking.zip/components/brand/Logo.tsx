'use client';

import React from 'react';

interface LogoProps {
  variant?: 'dark' | 'light' | 'auto';
  className?: string;
  showDescriptor?: boolean;
}

export function Logo({ variant = 'auto', className = '', showDescriptor = false }: LogoProps) {
  const isLight = variant === 'light';

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      {/* Precision Geometric Architectural Symbol */}
      <svg
        width="28"
        height="28"
        viewBox="0 0 28 28"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 transition-transform duration-200 group-hover:scale-105"
        aria-hidden="true"
      >
        {/* Outer boundary frame */}
        <rect
          x="2"
          y="2"
          width="24"
          height="24"
          rx="2"
          stroke={isLight ? '#FFFFFF' : '#172536'}
          strokeWidth="1.75"
        />
        {/* Architectural diagonal coordinate divider */}
        <line
          x1="2"
          y1="26"
          x2="26"
          y2="2"
          stroke={isLight ? '#FFFFFF' : '#172536'}
          strokeWidth="1.5"
        />
        {/* Restrained copper accent coordinate */}
        <polygon
          points="2,2 14,2 2,14"
          fill="#B98559"
          opacity="0.9"
        />
        <circle
          cx="20"
          cy="20"
          r="2.5"
          fill={isLight ? '#FFFFFF' : '#286B59'}
        />
      </svg>

      <div className="flex flex-col">
        <span
          className={`font-semibold tracking-[-0.04em] text-lg leading-tight uppercase ${
            isLight ? 'text-white' : 'text-[#172536]'
          }`}
          style={{ letterSpacing: '0.12em' }}
        >
          KONTUR
        </span>
        {showDescriptor && (
          <span
            className={`text-[9px] tracking-[0.2em] uppercase font-medium -mt-0.5 ${
              isLight ? 'text-white/70' : 'text-[#75808C]'
            }`}
          >
            Digital Banking
          </span>
        )}
      </div>
    </div>
  );
}
