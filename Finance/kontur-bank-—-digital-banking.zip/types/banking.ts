export type Language = 'de' | 'en';

export type TransactionCategory =
  | 'Wohnen'
  | 'Lebensmittel'
  | 'Mobilität'
  | 'Freizeit'
  | 'Einkäufe'
  | 'Gehalt'
  | 'Sonstiges';

export interface Transaction {
  id: string;
  merchant: string;
  date: string; // ISO date string YYYY-MM-DD
  category: TransactionCategory;
  amount: number; // positive for incoming, negative for outgoing
  status: 'Abgeschlossen' | 'Vorgemerkt';
  reference: string;
  notes?: string;
  cardLast4?: string;
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string; // YYYY-MM
  monthlyContribution: number;
  category: string;
}

export interface BankCard {
  id: string;
  type: 'physical' | 'virtual';
  nameOnCard: string;
  last4: string;
  expiry: string;
  isFrozen: boolean;
  spendingLimit: number;
  dailySpent: number;
  allowOnline: boolean;
  allowForeign: boolean;
  color: 'graphite' | 'navy' | 'copper';
}

export interface Beneficiary {
  id: string;
  name: string;
  iban: string;
  bic: string;
  bankName: string;
  avatarColor: string;
}

export interface AppNotification {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  type: 'transaction' | 'security' | 'savings' | 'account';
  isRead: boolean;
}

export interface TransferPayload {
  recipientName: string;
  iban: string;
  amount: number;
  purpose: string;
  instant: boolean;
}
