'use client';

import React from 'react';
import { BankingProvider } from '@/context/BankingContext';
import { BankingDashboard } from '@/components/dashboard/BankingDashboard';
import { OnboardingModal } from '@/components/onboarding/OnboardingModal';
import { LegalModal } from '@/components/legal/LegalModal';
import { WaitlistModal } from '@/components/home/WaitlistModal';

export default function DemoPage() {
  return (
    <BankingProvider>
      <BankingDashboard />
      <OnboardingModal />
      <LegalModal />
      <WaitlistModal />
    </BankingProvider>
  );
}
