import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'KONTUR Bank — Digital Banking',
  description: 'Banking, das in dein Leben passt. Ein klarer Blick auf deine Finanzen mit modernem deutschem Produktdesign, transparenter Ausgabenübersicht und digitaler Sparzielverwaltung.',
  openGraph: {
    title: 'KONTUR Bank — Digital Banking',
    description: 'Banking, das in dein Leben passt. Premium deutsches Digital-Banking-Konzept mit interaktivem Dashboard.',
    type: 'website',
    locale: 'de_DE',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'KONTUR Bank — Digital Banking',
    description: 'Banking, das in dein Leben passt. Premium deutsches Digital-Banking-Konzept.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="de" className="scroll-smooth">
      <body className="min-h-screen bg-[#F7F6F2] text-[#172536] selection:bg-[#B98559]/20 selection:text-[#172536]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
