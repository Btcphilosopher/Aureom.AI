'use client';

import React from 'react';
import { BankingProvider, useBanking } from '@/context/BankingContext';
import { Header } from '@/components/layout/Header';
import { Hero } from '@/components/home/Hero';
import { Benefits } from '@/components/home/Benefits';
import { EverydayBanking } from '@/components/home/EverydayBanking';
import { SpendingInsights } from '@/components/home/SpendingInsights';
import { CardsShowcase } from '@/components/home/CardsShowcase';
import { SavingsSection } from '@/components/home/SavingsSection';
import { SecuritySection } from '@/components/home/SecuritySection';
import { WaitlistSection } from '@/components/home/WaitlistSection';
import { Footer } from '@/components/layout/Footer';
import { BankingDashboard } from '@/components/dashboard/BankingDashboard';
import { OnboardingModal } from '@/components/onboarding/OnboardingModal';
import { LegalModal } from '@/components/legal/LegalModal';
import { WaitlistModal } from '@/components/home/WaitlistModal';

function MainContent() {
  const { currentView } = useBanking();

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F6F2]">
      {currentView === 'landing' ? (
        <>
          <Header />
          <main className="flex-1">
            <Hero />
            <Benefits />
            <EverydayBanking />
            <SpendingInsights />
            <CardsShowcase />
            <SavingsSection />
            <SecuritySection />
            <WaitlistSection />
          </main>
          <Footer />
        </>
      ) : (
        <BankingDashboard />
      )}

      {/* Global Modals */}
      <OnboardingModal />
      <LegalModal />
      <WaitlistModal />
    </div>
  );
}

export default function Home() {
  return (
    <BankingProvider>
      <MainContent />
    </BankingProvider>
  );
}
