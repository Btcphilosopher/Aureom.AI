package com.example

import com.example.model.AppLanguage
import com.example.model.Beneficiary
import com.example.viewmodel.MadarViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class MadarViewModelTest {

    private lateinit var viewModel: MadarViewModel

    @Before
    fun setUp() {
        viewModel = MadarViewModel()
    }

    @Test
    fun defaultLanguageIsArabic() {
        assertEquals(AppLanguage.ARABIC, viewModel.currentLanguage.value)
    }

    @Test
    fun toggleLanguageSwitchToEnglish() {
        viewModel.toggleLanguage()
        assertEquals(AppLanguage.ENGLISH, viewModel.currentLanguage.value)
    }

    @Test
    fun toggleCardFreezeUpdatesState() {
        val initialCards = viewModel.cards.value
        val cardId = initialCards.first().id
        val initialFreezeState = initialCards.first().isFrozen

        viewModel.toggleCardFreeze(cardId)
        val updatedCard = viewModel.cards.value.find { it.id == cardId }
        assertEquals(!initialFreezeState, updatedCard?.isFrozen)
    }

    @Test
    fun transferDeductsBalanceOnSuccess() {
        val initialBalance = viewModel.account.value.balance
        val beneficiary = viewModel.beneficiaries.value.first()
        val transferAmount = 500.0

        val success = viewModel.executeTransfer(beneficiary, transferAmount, "Test Note")

        assertTrue(success)
        assertEquals(initialBalance - transferAmount, viewModel.account.value.balance, 0.01)
    }

    @Test
    fun transferFailsOnInsufficientFunds() {
        val beneficiary = viewModel.beneficiaries.value.first()
        val transferAmount = 999999.0

        val success = viewModel.executeTransfer(beneficiary, transferAmount, "Huge Transfer")

        assertFalse(success)
    }

    @Test
    fun addSavingsGoalIncreasesList() {
        val initialSize = viewModel.savingsGoals.value.size
        val success = viewModel.addSavingsGoal("شراء حاسوب", "New Laptop", 8000.0, "2027-01-01")

        assertTrue(success)
        assertEquals(initialSize + 1, viewModel.savingsGoals.value.size)
    }

    @Test
    fun waitlistSubmitUpdatesState() {
        viewModel.submitWaitlist("محمد علي", "test@madar.sa", "+966501234567", "السعودية")

        assertTrue(viewModel.waitlistState.value.isSubmitted)
        assertEquals("test@madar.sa", viewModel.waitlistState.value.email)
    }
}
