package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CardInfo
import com.example.model.CardType
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.BrightGold
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun CustomCardView(
    card: CardInfo,
    language: AppLanguage,
    onToggleFreeze: (String) -> Unit,
    onEditLimit: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC
    var showFullDetails by remember { mutableStateOf(false) }

    val gradientBrush = when (card.cardType) {
        CardType.PHYSICAL_BLACK -> Brush.linearGradient(
            colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF1E1E24))
        )
        CardType.VIRTUAL_GOLD -> Brush.linearGradient(
            colors = listOf(Color(0xFF3B2F15), Color(0xFF634D21), Color(0xFF261D09))
        )
        CardType.TEAL_DIGITAL -> Brush.linearGradient(
            colors = listOf(Color(0xFF0D47A1), Color(0xFF00695C), Color(0xFF004D40))
        )
    }

    val accentColor = when (card.cardType) {
        CardType.PHYSICAL_BLACK -> SubtleGold
        CardType.VIRTUAL_GOLD -> BrightGold
        CardType.TEAL_DIGITAL -> SoftMint
    }

    val cardTypeName = when (card.cardType) {
        CardType.PHYSICAL_BLACK -> if (isAr) "بطاقة مدار السوداء (البلاستيكية)" else "MADAR Physical Black"
        CardType.VIRTUAL_GOLD -> if (isAr) "بطاقة مدار الذهبية (الافتراضية)" else "MADAR Virtual Gold"
        CardType.TEAL_DIGITAL -> if (isAr) "بطاقة مدار الرقمية" else "MADAR Digital Teal"
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = modifier
            .fillMaxWidth()
            .height(210.dp)
            .testTag("card_item_${card.id}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(brush = gradientBrush)
                .border(
                    width = 1.dp,
                    color = accentColor.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(18.dp)
                )
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header: Logo & Contactless Symbol
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(accentColor.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "مـ",
                                fontFamily = CairoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = accentColor
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "MADAR",
                            fontFamily = CairoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = WarmIvory,
                            letterSpacing = 1.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { showFullDetails = !showFullDetails },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = if (showFullDetails) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle Details",
                                tint = WarmIvory.copy(alpha = 0.8f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Contactless,
                            contentDescription = "Contactless",
                            tint = accentColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Chip & Card Type Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(42.dp)
                            .height(30.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(SubtleGold.copy(alpha = 0.8f))
                            .border(1.dp, Color.Yellow.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    )
                    Text(
                        text = cardTypeName,
                        fontSize = 11.sp,
                        color = ArchitecturalSand,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Card Number
                val displayPan = if (showFullDetails) {
                    "4532  8901  2234  8819"
                } else card.cardNumber

                Text(
                    text = displayPan,
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp,
                    color = WarmIvory,
                    letterSpacing = 2.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                // Footer: Cardholder Name & Expiry / CVV
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isAr) "حامل البطاقة" else "CARD HOLDER",
                            fontSize = 9.sp,
                            color = MutedTeal,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = card.cardHolder,
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            color = WarmIvory
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (isAr) "الانتهاء / CVV" else "EXPIRES / CVV",
                            fontSize = 9.sp,
                            color = MutedTeal,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${card.expiry}  |  " + if (showFullDetails) card.cvv else "•••",
                            fontFamily = InterFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp,
                            color = WarmIvory
                        )
                    }
                }
            }

            // Frozen overlay badge if frozen
            if (card.isFrozen) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.8f))
                        .clip(RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Frozen",
                            tint = ErrorRed,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = if (isAr) "البطاقة مجمدة حالياً" else "CARD CURRENTLY FROZEN",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Button(
                            onClick = { onToggleFreeze(card.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.testTag("unfreeze_card_overlay_button")
                        ) {
                            Text(text = if (isAr) "إلغاء التجميد" else "Unfreeze Card", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    // Quick Action Bar under card
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedButton(
            onClick = { onToggleFreeze(card.id) },
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = if (card.isFrozen) ErrorRed else SubtleGold
            ),
            modifier = Modifier.testTag("toggle_freeze_action_${card.id}")
        ) {
            Icon(
                imageVector = if (card.isFrozen) Icons.Default.LockOpen else Icons.Default.Lock,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (card.isFrozen) {
                    if (isAr) "إلغاء التجميد" else "Unfreeze"
                } else {
                    if (isAr) "تجميد البطاقة" else "Freeze Card"
                },
                fontSize = 12.sp
            )
        }

        Text(
            text = if (isAr) "الحد اليومي: ${card.dailyLimit.toInt()} ر.س" else "Limit: ${card.dailyLimit.toInt()} SAR",
            color = SubtleGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
