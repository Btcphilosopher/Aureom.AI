package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhonelinkSetup
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun SecurityScreen(
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC
    val scrollState = rememberScrollState()

    var biometricEnabled by remember { mutableStateOf(true) }
    var pushNotificationsEnabled by remember { mutableStateOf(true) }
    var locationSecurityEnabled by remember { mutableStateOf(true) }
    var strictLimitsEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightNavy)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MutedTeal.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = MutedTeal,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = if (isAr) "مركز الأمان والحماية" else "Security & Privacy Center",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = WarmIvory
                )
                Text(
                    text = if (isAr) "حماية حسابك مصممة بأعلى معايير التشفير المصرفي" else "Bank-grade encryption & security features",
                    fontSize = 11.sp,
                    color = MutedGrey
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Security Status Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = SoftMint,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = if (isAr) "مستوى حماية الحساب: ممتاز (100%)" else "Account Protection Level: Excellent (100%)",
                        color = WarmIvory,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isAr) "تم تفعيل التوثيق الثنائي والتشفير اللحظي والمعاملات الآمنة." else "2FA, end-to-end encryption, and live fraud detection are active.",
                        color = ArchitecturalSand,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = if (isAr) "خيارات الأمان المتقدمة" else "Advanced Security Settings",
            fontFamily = CairoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = WarmIvory
        )

        Spacer(modifier = Modifier.height(12.dp))

        SecurityToggleRow(
            title = if (isAr) "تسجيل الدخول بالبصمة / الوجه (Biometric)" else "Biometric / Face ID Login",
            desc = if (isAr) "تسجيل دخول آمن وسريع باستخدام بصمة الاصبع أو الوجه" else "Fast & secure access using fingerprint or facial recognition",
            icon = Icons.Default.Fingerprint,
            checked = biometricEnabled,
            onCheckedChange = { biometricEnabled = it }
        )

        Spacer(modifier = Modifier.height(10.dp))

        SecurityToggleRow(
            title = if (isAr) "تنبيهات الدفع اللحظية الفورية" else "Instant Payment Alerts",
            desc = if (isAr) "تنبيهات فورية لكل عملية خصم أو إيداع مجاناً" else "Instant notifications for every debit & deposit",
            icon = Icons.Default.NotificationsActive,
            checked = pushNotificationsEnabled,
            onCheckedChange = { pushNotificationsEnabled = it }
        )

        Spacer(modifier = Modifier.height(10.dp))

        SecurityToggleRow(
            title = if (isAr) "الحماية المبنية على الموقع الجغرافي" else "Location-Based Fraud Prevention",
            desc = if (isAr) "مطابقة موقع الهاتف مع عمليات الشراء لتجنب الاحتيال" else "Match card transactions with phone location to block fraud",
            icon = Icons.Default.PhonelinkSetup,
            checked = locationSecurityEnabled,
            onCheckedChange = { locationSecurityEnabled = it }
        )

        Spacer(modifier = Modifier.height(10.dp))

        SecurityToggleRow(
            title = if (isAr) "تقييد الشراء عبر الإنترنت (E-Commerce Block)" else "Strict E-Commerce Restriction",
            desc = if (isAr) "تعطيل الشراء عبر المواقع الإلكترونية مؤقتاً" else "Temporarily disable online website card purchases",
            icon = Icons.Default.Lock,
            checked = strictLimitsEnabled,
            onCheckedChange = { strictLimitsEnabled = it }
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Active Devices Section
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavySurface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isAr) "الأجهزة المصرح لها حالياً" else "Authorized Active Devices",
                    color = WarmIvory,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Samsung Galaxy S24 Ultra (هذا الجهاز)",
                            color = SubtleGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "الرياض، المملكة العربية السعودية • آخر نشاط: الآن",
                            color = MutedGrey,
                            fontSize = 11.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MutedTeal.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = if (isAr) "جهاز رئيسي" else "Primary", color = SoftMint, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SecurityToggleRow(
    title: String,
    desc: String,
    icon: ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MutedTeal.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = SubtleGold,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = title,
                        color = WarmIvory,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = desc,
                        color = MutedGrey,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = WarmIvory,
                    checkedTrackColor = MutedTeal,
                    uncheckedThumbColor = MutedGrey,
                    uncheckedTrackColor = MidnightNavy
                )
            )
        }
    }
}
