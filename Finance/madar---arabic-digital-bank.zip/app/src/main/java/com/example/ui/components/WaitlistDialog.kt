package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AppLanguage
import com.example.model.WaitlistFormState
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.WarmIvory

@Composable
fun WaitlistDialog(
    language: AppLanguage,
    state: WaitlistFormState,
    onSubmit: (fullName: String, email: String, phone: String, country: String) -> Unit,
    onDismiss: () -> Unit
) {
    val isAr = language == AppLanguage.ARABIC

    var fullName by remember { mutableStateOf(state.fullName) }
    var email by remember { mutableStateOf(state.email) }
    var phone by remember { mutableStateOf(state.phone) }
    var country by remember { mutableStateOf(state.country) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                // Header & Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAr) "انضم إلى قائمة الانتظار لـ مدار" else "Join MADAR Waitlist",
                        color = WarmIvory,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MutedGrey
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (state.isSubmitted) {
                    // Success View
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(SoftMint.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Success",
                                tint = SoftMint,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (isAr) "تم تسجيلك بنجاح في قائمة الانتظار!" else "You're on the waitlist!",
                            color = WarmIvory,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isAr) {
                                "شكراً لانضمامك. سنقوم بموافاتك بالتحديثات ودعوات الوصول المبكر فور إطلاق الخدمة."
                            } else {
                                "Thank you for joining. We will notify you with updates and early access invitations."
                            },
                            color = MutedGrey,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(text = if (isAr) "تم" else "Done")
                        }
                    }
                } else {
                    // Form View
                    Text(
                        text = if (isAr) {
                            "كن أول من يخوض تجربة المصرفية الرقمية فائقة الحداثة فور انطلاقنا."
                        } else {
                            "Be among the first to experience modern digital banking in the region."
                        },
                        color = MutedGrey,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (state.errorMessage != null) {
                        Text(
                            text = state.errorMessage,
                            color = ErrorRed,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text(if (isAr) "الاسم الكامل" else "Full Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WarmIvory,
                            unfocusedTextColor = WarmIvory,
                            focusedBorderColor = MutedTeal,
                            unfocusedBorderColor = MutedGrey
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("waitlist_fullname_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text(if (isAr) "البريد الإلكتروني" else "Email Address") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WarmIvory,
                            unfocusedTextColor = WarmIvory,
                            focusedBorderColor = MutedTeal,
                            unfocusedBorderColor = MutedGrey
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("waitlist_email_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text(if (isAr) "رقم الجوال (اختياري)" else "Phone Number (Optional)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WarmIvory,
                            unfocusedTextColor = WarmIvory,
                            focusedBorderColor = MutedTeal,
                            unfocusedBorderColor = MutedGrey
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = { onSubmit(fullName, email, phone, country) },
                        colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("submit_waitlist_button")
                    ) {
                        Text(
                            text = if (isAr) "تأكيد الانضمام" else "Confirm & Join",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
