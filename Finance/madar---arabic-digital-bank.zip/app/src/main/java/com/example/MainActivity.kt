package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.NavScreen
import com.example.ui.components.HeaderNav
import com.example.ui.components.PrototypeNoticeBanner
import com.example.ui.components.WaitlistDialog
import com.example.ui.screens.CardsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SavingsScreen
import com.example.ui.screens.SecurityScreen
import com.example.ui.screens.TransactionsScreen
import com.example.ui.screens.TransfersScreen
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.MADARTheme
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory
import com.example.viewmodel.MadarViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MadarViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val currentLanguage by viewModel.currentLanguage.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()
            val account by viewModel.account.collectAsState()
            val cards by viewModel.cards.collectAsState()
            val transactions by viewModel.transactions.collectAsState()
            val savingsGoals by viewModel.savingsGoals.collectAsState()
            val beneficiaries by viewModel.beneficiaries.collectAsState()
            val waitlistState by viewModel.waitlistState.collectAsState()
            val toastMessage by viewModel.toastMessage.collectAsState()

            val context = LocalContext.current
            var isWaitlistOpen by remember { mutableStateOf(false) }

            // Show Toast notifications when viewmodel triggers message
            LaunchedEffect(toastMessage) {
                toastMessage?.let { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    viewModel.clearToast()
                }
            }

            val layoutDir = if (currentLanguage == AppLanguage.ARABIC) {
                LayoutDirection.Rtl
            } else {
                LayoutDirection.Ltr
            }

            // Handle system back button for custom navigation stack
            if (currentScreen != NavScreen.HOME) {
                BackHandler {
                    viewModel.navigateTo(NavScreen.HOME)
                }
            }

            CompositionLocalProvider(LocalLayoutDirection provides layoutDir) {
                MADARTheme(darkTheme = true) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MidnightNavy
                    ) {
                        Scaffold(
                            topBar = {
                                Column(modifier = Modifier.statusBarsPadding()) {
                                    PrototypeNoticeBanner(
                                        language = currentLanguage,
                                        onResetDemo = { viewModel.resetDemoData() }
                                    )
                                    HeaderNav(
                                        currentScreen = currentScreen,
                                        currentLanguage = currentLanguage,
                                        onNavigate = { viewModel.navigateTo(it) },
                                        onToggleLanguage = { viewModel.toggleLanguage() }
                                    )
                                }
                            },
                            bottomBar = {
                                MADARBottomNavigation(
                                    currentScreen = currentScreen,
                                    language = currentLanguage,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            },
                            modifier = Modifier.fillMaxSize()
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                Crossfade(
                                    targetState = currentScreen,
                                    label = "ScreenTransition"
                                ) { target ->
                                    when (target) {
                                        NavScreen.HOME -> HomeScreen(
                                            account = account,
                                            language = currentLanguage,
                                            onNavigate = { viewModel.navigateTo(it) },
                                            onOpenWaitlist = { isWaitlistOpen = true }
                                        )

                                        NavScreen.DASHBOARD -> DashboardScreen(
                                            account = account,
                                            cards = cards,
                                            transactions = transactions,
                                            savingsGoals = savingsGoals,
                                            language = currentLanguage,
                                            onNavigate = { viewModel.navigateTo(it) },
                                            onToggleFreeze = { viewModel.toggleCardFreeze(it) }
                                        )

                                        NavScreen.TRANSACTIONS -> TransactionsScreen(
                                            transactions = transactions,
                                            language = currentLanguage
                                        )

                                        NavScreen.CARDS -> CardsScreen(
                                            cards = cards,
                                            language = currentLanguage,
                                            onToggleFreeze = { viewModel.toggleCardFreeze(it) },
                                            onUpdateLimit = { id, limit -> viewModel.updateCardLimit(id, limit) }
                                        )

                                        NavScreen.TRANSFERS -> TransfersScreen(
                                            account = account,
                                            beneficiaries = beneficiaries,
                                            language = currentLanguage,
                                            onExecuteTransfer = { ben, amt, note ->
                                                viewModel.executeTransfer(ben, amt, note)
                                            }
                                        )

                                        NavScreen.SAVINGS -> SavingsScreen(
                                            account = account,
                                            savingsGoals = savingsGoals,
                                            language = currentLanguage,
                                            onAddGoal = { titleAr, titleEn, amt, date ->
                                                viewModel.addSavingsGoal(titleAr, titleEn, amt, date)
                                            },
                                            onContribute = { goalId, amt ->
                                                viewModel.contributeToGoal(goalId, amt)
                                            }
                                        )

                                        NavScreen.SECURITY -> SecurityScreen(
                                            language = currentLanguage
                                        )

                                        NavScreen.ONBOARDING -> OnboardingScreen(
                                            language = currentLanguage,
                                            onNavigate = { viewModel.navigateTo(it) }
                                        )
                                    }
                                }
                            }
                        }

                        // Waitlist Modal Dialog
                        if (isWaitlistOpen) {
                            WaitlistDialog(
                                language = currentLanguage,
                                state = waitlistState,
                                onSubmit = { name, email, phone, country ->
                                    viewModel.submitWaitlist(name, email, phone, country)
                                },
                                onDismiss = {
                                    isWaitlistOpen = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MADARBottomNavigation(
    currentScreen: NavScreen,
    language: AppLanguage,
    onNavigate: (NavScreen) -> Unit
) {
    val isAr = language == AppLanguage.ARABIC

    val navItems = listOf(
        Pair(NavScreen.HOME, Icons.Default.Home),
        Pair(NavScreen.DASHBOARD, Icons.Default.PieChart),
        Pair(NavScreen.CARDS, Icons.Default.CreditCard),
        Pair(NavScreen.TRANSFERS, Icons.Default.Send),
        Pair(NavScreen.SAVINGS, Icons.Default.Savings)
    )

    NavigationBar(
        containerColor = DarkNavySurface,
        tonalElevation = 8.dp,
        modifier = Modifier.navigationBarsPadding()
    ) {
        navItems.forEach { (screen, icon) ->
            val isSelected = currentScreen == screen
            val label = if (isAr) screen.titleAr else screen.titleEn

            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) SubtleGold else MutedGrey
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) WarmIvory else MutedGrey
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = MutedTeal.copy(alpha = 0.3f)
                ),
                modifier = Modifier.testTag("nav_tab_${screen.name.lowercase()}")
            )
        }
    }
}
