package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.NavScreen
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun FooterView(
    language: AppLanguage,
    onNavigate: (NavScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MidnightNavy)
            .padding(24.dp)
    ) {
        // Logo & Tagline
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MutedTeal),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "مَ",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = WarmIvory
                )
            }
            Text(
                text = if (isAr) "مَدار — المصرفية الرقمية" else "MADAR — Digital Banking",
                fontFamily = CairoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = WarmIvory
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = if (isAr) {
                "مصرفك. مستقبلك. بطريقتك. تصميم ونموذج أولي فائق الحداثة لإعادة تعريف التجربة المصرفية العربية."
            } else {
                "Your bank. Your future. Your way. A super-modern digital banking prototype redefining Middle Eastern financial experiences."
            },
            color = MutedGrey,
            fontSize = 13.sp,
            lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Navigation Quick Links Grid
        val navLinks = listOf(
            NavScreen.HOME,
            NavScreen.DASHBOARD,
            NavScreen.TRANSACTIONS,
            NavScreen.CARDS,
            NavScreen.TRANSFERS,
            NavScreen.SAVINGS,
            NavScreen.SECURITY,
            NavScreen.ONBOARDING
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                navLinks.take(4).forEach { screen ->
                    Text(
                        text = if (isAr) screen.titleAr else screen.titleEn,
                        color = ArchitecturalSand,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable { onNavigate(screen) }
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                navLinks.drop(4).forEach { screen ->
                    Text(
                        text = if (isAr) screen.titleAr else screen.titleEn,
                        color = ArchitecturalSand,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable { onNavigate(screen) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Divider(color = MutedGrey.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(16.dp))

        // Legal & Prototype Disclaimer
        Text(
            text = if (isAr) {
                "تنبيه قانوني: هذا التطبيق هو نموذج أولي واجهة مستخدم (UI Prototype) افتراضي لأغراض التوضيح والتصميم، ولا يقدم أي خدمات مالية، مصرفية، أو تحويلات حقيقية."
            } else {
                "Legal Notice: This application is a UI prototype created for demonstration and design purposes. It does not provide actual financial services or money movement."
            },
            color = MutedGrey,
            fontSize = 11.sp,
            lineHeight = 16.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "© 2026 MADAR Digital Bank Prototype. All rights reserved.",
            color = SubtleGold,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
