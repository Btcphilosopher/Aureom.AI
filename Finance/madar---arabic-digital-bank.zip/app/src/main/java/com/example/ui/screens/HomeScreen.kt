package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Account
import com.example.model.AppLanguage
import com.example.model.NavScreen
import com.example.ui.components.FooterView
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.BrightGold
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.LightTeal
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun HomeScreen(
    account: Account,
    language: AppLanguage,
    onNavigate: (NavScreen) -> Unit,
    onOpenWaitlist: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightNavy)
            .verticalScroll(scrollState)
    ) {
        // Hero Banner Art & Headline Composition
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_banner_1792944112193),
                contentDescription = "Futuristic Financial City Skyline",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Dark Navy Gradient Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                MidnightNavy.copy(alpha = 0.5f),
                                MidnightNavy.copy(alpha = 0.95f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                // Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(MutedTeal.copy(alpha = 0.3f))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = SubtleGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isAr) "مصرفية عربية رقمية فائقة الحداثة" else "Arabic Super-Modern Digital Banking",
                        color = ArchitecturalSand,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isAr) "أموالك. حياتك. مساحة أكبر للمستقبل." else "Your Money. Your Life. Room for the Future.",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp,
                    lineHeight = 34.sp,
                    color = WarmIvory
                )
            }
        }

        // Hero Sub-description & Primary Action buttons
        Column(modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)) {
            Text(
                text = if (isAr) {
                    "حساب رقمي يجمع بين البساطة والتحكم والوضوح، لتدير أموالك اليومية وتخطط لما هو قادم بثقة أكبر."
                } else {
                    "A digital banking experience combining simplicity, control, and clarity—manage your everyday money and plan your future with confidence."
                },
                color = MutedGrey,
                fontSize = 14.sp,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { onNavigate(NavScreen.ONBOARDING) },
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MutedTeal,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("hero_open_account_button")
                ) {
                    Text(
                        text = if (isAr) "افتح حسابك الآن" else "Open Your Account",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = { onNavigate(NavScreen.DASHBOARD) },
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SubtleGold),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("hero_explore_demo_button")
                ) {
                    Text(
                        text = if (isAr) "جرب لوحة التحكم" else "Explore Dashboard",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Banking Teaser Card Mockup
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .clickable { onNavigate(NavScreen.DASHBOARD) }
                .testTag("hero_live_preview_card")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isAr) "معاينة الحساب الجاري" else "Current Account Live Teaser",
                        fontSize = 12.sp,
                        color = MutedGrey,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isAr) "عرض تفاعلي >" else "Interactive >",
                        fontSize = 12.sp,
                        color = SubtleGold,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "${String.format("%.2f", account.balance)} ${account.currency}",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 28.sp,
                    color = WarmIvory
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuickBadge(
                        label = if (isAr) "الدخل الشهري" else "Income",
                        valStr = "+12,000 SAR",
                        color = SoftMint
                    )
                    QuickBadge(
                        label = if (isAr) "المصاريف" else "Spent",
                        valStr = "-4,280.50 SAR",
                        color = BrightGold
                    )
                    QuickBadge(
                        label = if (isAr) "هدف الادخار" else "Savings Goal",
                        valStr = "7,500 SAR",
                        color = LightTeal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Trust Strip (4 Core Values)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkNavySurface)
                .padding(24.dp)
        ) {
            Text(
                text = if (isAr) "لماذا تختار مدار؟" else "Why Choose MADAR?",
                fontFamily = CairoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = SubtleGold
            )

            Spacer(modifier = Modifier.height(16.dp))

            val trustItems = listOf(
                Pair(if (isAr) "تحكم أوضح في أموالك" else "Clearer Financial Control", Icons.Default.Speed),
                Pair(if (isAr) "تجربة رقمية سهلة" else "Seamless Digital Experience", Icons.Default.AutoAwesome),
                Pair(if (isAr) "متابعة فورية للمعاملات" else "Instant Transaction Tracking", Icons.Default.Send),
                Pair(if (isAr) "أمان مصمم لحماية حسابك" else "Bank-Grade Account Security", Icons.Default.Security)
            )

            trustItems.chunked(2).forEach { rowItems ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    rowItems.forEach { item ->
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MidnightNavy)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(MutedTeal.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = item.second,
                                    contentDescription = null,
                                    tint = MutedTeal,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = item.first,
                                color = WarmIvory,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Core Pillars Section
        Column(modifier = Modifier.padding(horizontal = 24.dp)) {
            Text(
                text = if (isAr) "كل ما تحتاجه لإدارة أموالك، في مكان واحد." else "Everything you need to manage money, in one place.",
                fontFamily = CairoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                lineHeight = 28.sp,
                color = WarmIvory
            )

            Spacer(modifier = Modifier.height(16.dp))

            FeatureCardItem(
                title = if (isAr) "1. الخدمات المصرفية اليومية" else "1. Everyday Banking",
                desc = if (isAr) "حسابات فورية، بطاقات رقمية ومادية مع إشعارات لحظية وإمكانية تجميد البطاقة بضغطة واحدة." else "Instant accounts, physical & digital cards with real-time notifications and instant freeze controls.",
                icon = Icons.Default.CreditCard,
                onClick = { onNavigate(NavScreen.CARDS) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            FeatureCardItem(
                title = if (isAr) "2. تحليلات وإدارة المال الذكية" else "2. Smart Money Management",
                desc = if (isAr) "تصنيف آلي لكافة مصاريفك اليومية، تقارير شهرية واضحة ومقارنات تساعدك على اتخاذ قرارات مالية أفضل." else "Automated category breakdown for all transactions, clear monthly summaries and financial analytics.",
                icon = Icons.Default.PieChart,
                onClick = { onNavigate(NavScreen.DASHBOARD) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            FeatureCardItem(
                title = if (isAr) "3. الادخار والتخطيط للمستقبل" else "3. Savings & Future Planning",
                desc = if (isAr) "إنشاء أهداف ادخار مخصصة، إيداعات تلقائية وتتبع نسبة الإنجاز بصورة مرئية ممتعة." else "Custom savings goals, automated contributions, and visual progress tracking.",
                icon = Icons.Default.Savings,
                onClick = { onNavigate(NavScreen.SAVINGS) }
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Call to action Join Waitlist
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavySurface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isAr) "ابدأ علاقتك الجديدة مع المال." else "Start your new relationship with money.",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = WarmIvory
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isAr) {
                        "انضم إلى قائمة الانتظار الحصرية لتكون من الأوائل الذين يخوضون تجربة المصرفية الرقمية المستقبلية."
                    } else {
                        "Join our exclusive waitlist to be among the first to experience future digital banking."
                    },
                    color = MutedGrey,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onOpenWaitlist,
                    colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.testTag("join_waitlist_home_button")
                ) {
                    Text(
                        text = if (isAr) "انضم إلى قائمة الانتظار" else "Join Waitlist",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))

        // Footer
        FooterView(language = language, onNavigate = onNavigate)
    }
}

@Composable
private fun QuickBadge(label: String, valStr: String, color: Color) {
    Column {
        Text(text = label, fontSize = 10.sp, color = MutedGrey)
        Text(text = valStr, fontSize = 12.sp, color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FeatureCardItem(
    title: String,
    desc: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MutedTeal.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MutedTeal,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = WarmIvory,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = desc,
                    color = MutedGrey,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
