package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MADAR Brand Color Palette
val MidnightNavy = Color(0xFF101D32)
val DarkNavySurface = Color(0xFF182740)
val DarkNavyCard = Color(0xFF1E3150)

val WarmIvory = Color(0xFFF8F6F0)
val ArchitecturalSand = Color(0xFFE7DDCA)

val MutedTeal = Color(0xFF197C78)
val LightTeal = Color(0xFF26A69A)
val SoftMint = Color(0xFFCBE9DC)

val Graphite = Color(0xFF333A43)
val SubtleGold = Color(0xFFC4A46A)
val BrightGold = Color(0xFFE5C17C)

val MutedGrey = Color(0xFF7C8490)
val SurfaceGrey = Color(0xFFF1F3F6)
val BorderGrey = Color(0xFFE0E4EC)

val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val WarningOrange = Color(0xFFF59E0B)
