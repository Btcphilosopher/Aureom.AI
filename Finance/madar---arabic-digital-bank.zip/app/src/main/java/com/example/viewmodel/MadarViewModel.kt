package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.MockData
import com.example.model.Account
import com.example.model.AppLanguage
import com.example.model.Beneficiary
import com.example.model.CardInfo
import com.example.model.NavScreen
import com.example.model.NotificationItem
import com.example.model.SavingsGoal
import com.example.model.Transaction
import com.example.model.WaitlistFormState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

class MadarViewModel : ViewModel() {

    private val _currentLanguage = MutableStateFlow(AppLanguage.ARABIC)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _currentScreen = MutableStateFlow(NavScreen.HOME)
    val currentScreen: StateFlow<NavScreen> = _currentScreen.asStateFlow()

    private val _account = MutableStateFlow(MockData.initialAccount)
    val account: StateFlow<Account> = _account.asStateFlow()

    private val _cards = MutableStateFlow(MockData.initialCards)
    val cards: StateFlow<List<CardInfo>> = _cards.asStateFlow()

    private val _transactions = MutableStateFlow(MockData.initialTransactions)
    val transactions: StateFlow<List<Transaction>> = _transactions.asStateFlow()

    private val _savingsGoals = MutableStateFlow(MockData.initialSavingsGoals)
    val savingsGoals: StateFlow<List<SavingsGoal>> = _savingsGoals.asStateFlow()

    private val _beneficiaries = MutableStateFlow(MockData.initialBeneficiaries)
    val beneficiaries: StateFlow<List<Beneficiary>> = _beneficiaries.asStateFlow()

    private val _notifications = MutableStateFlow(MockData.initialNotifications)
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    private val _waitlistState = MutableStateFlow(WaitlistFormState())
    val waitlistState: StateFlow<WaitlistFormState> = _waitlistState.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun toggleLanguage() {
        _currentLanguage.update {
            if (it == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        }
    }

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    fun navigateTo(screen: NavScreen) {
        _currentScreen.value = screen
    }

    fun toggleCardFreeze(cardId: String) {
        _cards.update { list ->
            list.map { card ->
                if (card.id == cardId) {
                    val newState = !card.isFrozen
                    val msg = if (_currentLanguage.value == AppLanguage.ARABIC) {
                        if (newState) "تم تجميد البطاقة بنجاح" else "تم إلغاء تجميد البطاقة بنجاح"
                    } else {
                        if (newState) "Card frozen successfully" else "Card unfrozen successfully"
                    }
                    _toastMessage.value = msg
                    card.copy(isFrozen = newState)
                } else card
            }
        }
    }

    fun updateCardLimit(cardId: String, newLimit: Double) {
        _cards.update { list ->
            list.map { card ->
                if (card.id == cardId) {
                    card.copy(dailyLimit = newLimit)
                } else card
            }
        }
        _toastMessage.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
            "تم تحديث حد الإنفاق اليومي إلى ${newLimit.toInt()} ر.س"
        } else {
            "Daily limit updated to ${newLimit.toInt()} SAR"
        }
    }

    fun addSavingsGoal(titleAr: String, titleEn: String, targetAmount: Double, targetDate: String): Boolean {
        if (titleAr.isBlank() || targetAmount <= 0) return false
        val newGoal = SavingsGoal(
            id = "sg_" + UUID.randomUUID().toString().take(6),
            titleAr = titleAr,
            titleEn = if (titleEn.isBlank()) titleAr else titleEn,
            targetAmount = targetAmount,
            currentAmount = 0.0,
            targetDate = targetDate.ifBlank { "2027-12-31" }
        )
        _savingsGoals.update { listOf(newGoal) + it }
        _toastMessage.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
            "تم إنشاء هدف الادخار الجديد بنجاح"
        } else {
            "New savings goal created successfully"
        }
        return true
    }

    fun contributeToGoal(goalId: String, amount: Double): Boolean {
        if (amount <= 0) return false
        val currentBal = _account.value.balance
        if (currentBal < amount) {
            _toastMessage.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
                "عفواً، الرصيد المتاح غير كافٍ"
            } else {
                "Insufficient funds"
            }
            return false
        }

        // Deduct from account balance
        _account.update { it.copy(balance = it.balance - amount) }

        // Add to goal
        _savingsGoals.update { list ->
            list.map { goal ->
                if (goal.id == goalId) {
                    goal.copy(currentAmount = goal.currentAmount + amount)
                } else goal
            }
        }

        // Add transaction
        val goalName = _savingsGoals.value.find { it.id == goalId }?.titleAr ?: "هدف ادخار"
        val newTx = Transaction(
            id = "tx_" + UUID.randomUUID().toString().take(6),
            titleAr = "إيداع في $goalName",
            titleEn = "Savings Deposit",
            merchant = "مدار ادخار",
            categoryAr = "الادخار والتوفير",
            categoryEn = "Savings Deposit",
            date = "2026-10-25",
            amount = amount,
            isIncoming = false,
            reference = "MDR-SG-${(1000..9999).random()}"
        )
        _transactions.update { listOf(newTx) + it }

        _toastMessage.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
            "تمت إضافة $amount ر.س إلى هدف الادخار"
        } else {
            "$amount SAR added to savings goal"
        }
        return true
    }

    fun executeTransfer(beneficiary: Beneficiary, amount: Double, note: String): Boolean {
        if (amount <= 0) return false
        val currentBal = _account.value.balance
        if (currentBal < amount) {
            _toastMessage.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
                "عفواً، الرصيد المتاح غير كافٍ لإتمام التحويل"
            } else {
                "Insufficient funds for transfer"
            }
            return false
        }

        // Deduct balance
        _account.update { it.copy(balance = it.balance - amount) }

        // Add transaction record
        val ref = "MDR-TX-${(10000..99999).random()}"
        val newTx = Transaction(
            id = "tx_" + UUID.randomUUID().toString().take(6),
            titleAr = "تحويل إلى ${beneficiary.nameAr}",
            titleEn = "Transfer to ${beneficiary.nameEn}",
            merchant = beneficiary.bankName,
            categoryAr = "تحويلات مالية",
            categoryEn = "Bank Transfer",
            date = "2026-10-25",
            amount = amount,
            isIncoming = false,
            reference = ref
        )
        _transactions.update { listOf(newTx) + it }

        _toastMessage.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
            "تم إرسال $amount ر.س بنجاح إلى ${beneficiary.nameAr}"
        } else {
            "Successfully sent $amount SAR to ${beneficiary.nameEn}"
        }
        return true
    }

    fun submitWaitlist(fullName: String, email: String, phone: String, country: String) {
        if (fullName.isBlank() || email.isBlank()) {
            _waitlistState.value = _waitlistState.value.copy(
                errorMessage = if (_currentLanguage.value == AppLanguage.ARABIC) "يرجى تعبئة كافة الحقول المطلوب" else "Please fill all required fields"
            )
            return
        }

        _waitlistState.value = WaitlistFormState(
            fullName = fullName,
            email = email,
            phone = phone,
            country = country,
            isSubmitted = true,
            errorMessage = null
        )

        _toastMessage.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
            "أهلاً بك في قائمة الانتظار لـ مدار!"
        } else {
            "Welcome to the MADAR waitlist!"
        }
    }

    fun resetWaitlistForm() {
        _waitlistState.value = WaitlistFormState()
    }

    fun markNotificationRead(id: String) {
        _notifications.update { list ->
            list.map { if (it.id == id) it.copy(isRead = true) else it }
        }
    }

    fun resetDemoData() {
        _account.value = MockData.initialAccount
        _cards.value = MockData.initialCards
        _transactions.value = MockData.initialTransactions
        _savingsGoals.value = MockData.initialSavingsGoals
        _beneficiaries.value = MockData.initialBeneficiaries
        _notifications.value = MockData.initialNotifications
        _waitlistState.value = WaitlistFormState()
        _toastMessage.value = if (_currentLanguage.value == AppLanguage.ARABIC) {
            "تم إعادة ضبط البيانات التجريبية"
        } else {
            "Demo data reset to initial state"
        }
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
