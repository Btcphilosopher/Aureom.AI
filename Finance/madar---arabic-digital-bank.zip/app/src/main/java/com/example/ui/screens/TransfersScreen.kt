package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Account
import com.example.model.AppLanguage
import com.example.model.Beneficiary
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun TransfersScreen(
    account: Account,
    beneficiaries: List<Beneficiary>,
    language: AppLanguage,
    onExecuteTransfer: (Beneficiary, Double, String) -> Boolean,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC
    val scrollState = rememberScrollState()

    var step by remember { mutableStateOf(1) } // 1: Select, 2: Amount, 3: Confirmation, 4: Receipt
    var selectedBeneficiary by remember { mutableStateOf<Beneficiary?>(beneficiaries.firstOrNull()) }
    var amountInput by remember { mutableStateOf("500") }
    var noteInput by remember { mutableStateOf("") }

    var lastReceiptRef by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightNavy)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = if (isAr) "التحويلات المالية الفورية" else "Instant Money Transfers",
            fontFamily = CairoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = WarmIvory
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = if (isAr) "حول الأموال فوراً إلى أي بنك محلي برصيد متاح ${account.balance.toInt()} ر.س" else "Transfer funds instantly to any local bank. Available: ${account.balance.toInt()} SAR",
            color = MutedGrey,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Wizard Step Indicator
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf(
                if (isAr) "1. المستفيد" else "1. Beneficiary",
                if (isAr) "2. المبلغ" else "2. Amount",
                if (isAr) "3. التأكيد" else "3. Confirm",
                if (isAr) "4. الإيصال" else "4. Receipt"
            ).forEachIndexed { index, title ->
                val isCurrent = step == index + 1
                val isDone = step > index + 1
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            when {
                                isDone -> SuccessGreen.copy(alpha = 0.8f)
                                isCurrent -> MutedTeal
                                else -> DarkNavyCard
                            }
                        )
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        fontSize = 10.sp,
                        color = WarmIvory,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        when (step) {
            1 -> {
                // Step 1: Beneficiary Selection
                Text(
                    text = if (isAr) "اختر المستفيد من القائمة" else "Select Beneficiary",
                    color = WarmIvory,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                beneficiaries.forEach { ben ->
                    val isSelected = selectedBeneficiary?.id == ben.id
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) DarkNavySurface else DarkNavyCard
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { selectedBeneficiary = ben }
                            .testTag("beneficiary_select_${ben.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) MutedTeal else MutedGrey.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = WarmIvory,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isAr) ben.nameAr else ben.nameEn,
                                    color = WarmIvory,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${ben.bankName} • ${ben.iban}",
                                    color = MutedGrey,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { if (selectedBeneficiary != null) step = 2 },
                    colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("transfer_next_step1")
                ) {
                    Text(
                        text = if (isAr) "متابعة لإدخال المبلغ" else "Continue to Amount",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            2 -> {
                // Step 2: Amount & Note Input
                Text(
                    text = if (isAr) "إدخال تفاصيل التحويل" else "Enter Transfer Details",
                    color = WarmIvory,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = ErrorRed,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text(if (isAr) "المبلغ (ر.س SAR)" else "Amount (SAR)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = WarmIvory,
                        unfocusedTextColor = WarmIvory,
                        focusedBorderColor = MutedTeal,
                        unfocusedBorderColor = MutedGrey
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("transfer_amount_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Quick preset amounts
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("100", "250", "500", "1000", "2500").forEach { amt ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkNavyCard)
                                .clickable { amountInput = amt }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "$amt SAR", color = SubtleGold, fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = noteInput,
                    onValueChange = { noteInput = it },
                    label = { Text(if (isAr) "ملاحظات أو سبب التحويل (اختياري)" else "Note / Reason (Optional)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = WarmIvory,
                        unfocusedTextColor = WarmIvory,
                        focusedBorderColor = MutedTeal,
                        unfocusedBorderColor = MutedGrey
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { step = 1 },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkNavyCard),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = if (isAr) "رجوع" else "Back")
                    }

                    Button(
                        onClick = {
                            val amt = amountInput.toDoubleOrNull() ?: 0.0
                            if (amt <= 0) {
                                errorMessage = if (isAr) "يرجى إدخال مبلغ صحيح" else "Please enter valid amount"
                            } else if (amt > account.balance) {
                                errorMessage = if (isAr) "المبلغ أكبر من الرصيد المتاح" else "Amount exceeds available balance"
                            } else {
                                errorMessage = null
                                step = 3
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("transfer_next_step2")
                    ) {
                        Text(text = if (isAr) "مراجعة التفاصيل" else "Review Transfer")
                    }
                }
            }

            3 -> {
                // Step 3: Confirmation Summary
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = if (isAr) "تأكيد تفاصيل العملية" else "Confirm Transfer Details",
                            color = WarmIvory,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        SummaryRow(
                            label = if (isAr) "المستفيد:" else "Beneficiary:",
                            valStr = selectedBeneficiary?.let { if (isAr) it.nameAr else it.nameEn } ?: ""
                        )
                        SummaryRow(
                            label = if (isAr) "البنك المستلم:" else "Destination Bank:",
                            valStr = selectedBeneficiary?.bankName ?: ""
                        )
                        SummaryRow(
                            label = if (isAr) "آيبان المستفيد:" else "Beneficiary IBAN:",
                            valStr = selectedBeneficiary?.iban ?: ""
                        )
                        SummaryRow(
                            label = if (isAr) "المبلغ المخصوم:" else "Amount:",
                            valStr = "$amountInput.00 SAR",
                            valColor = SubtleGold
                        )
                        SummaryRow(
                            label = if (isAr) "رسوم التحويل:" else "Transfer Fee:",
                            valStr = "0.00 SAR (مجاناً / Free)",
                            valColor = SuccessGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { step = 2 },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkNavyCard),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = if (isAr) "تعديل" else "Edit")
                    }

                    Button(
                        onClick = {
                            val ben = selectedBeneficiary
                            val amt = amountInput.toDoubleOrNull() ?: 0.0
                            if (ben != null && amt > 0) {
                                val success = onExecuteTransfer(ben, amt, noteInput)
                                if (success) {
                                    lastReceiptRef = "MDR-TX-${(10000..99999).random()}"
                                    step = 4
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("confirm_transfer_final_button")
                    ) {
                        Text(text = if (isAr) "تأكيد وإرسال" else "Confirm & Send")
                    }
                }
            }

            4 -> {
                // Step 4: Success Receipt
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(SuccessGreen.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Success",
                                tint = SuccessGreen,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (isAr) "تم تنفيذ التحويل بنجاح!" else "Transfer Executed Successfully!",
                            color = WarmIvory,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Ref: $lastReceiptRef",
                            color = SubtleGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        SummaryRow(
                            label = if (isAr) "المبلغ المحول:" else "Transferred Amount:",
                            valStr = "$amountInput.00 SAR",
                            valColor = SuccessGreen
                        )
                        SummaryRow(
                            label = if (isAr) "المستفيد:" else "Beneficiary:",
                            valStr = selectedBeneficiary?.let { if (isAr) it.nameAr else it.nameEn } ?: ""
                        )
                        SummaryRow(
                            label = if (isAr) "التاريخ والوقت:" else "Date & Time:",
                            valStr = "2026-10-25 09:30"
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                step = 1
                                amountInput = "500"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = if (isAr) "إجراء تحويل جديد" else "Make Another Transfer")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, valStr: String, valColor: Color = WarmIvory) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = MutedGrey, fontSize = 12.sp)
        Text(text = valStr, color = valColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}
