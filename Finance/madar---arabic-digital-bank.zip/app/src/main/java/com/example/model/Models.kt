package com.example.model

enum class AppLanguage(val code: String, val label: String) {
    ARABIC("ar", "العربية"),
    ENGLISH("en", "English")
}

enum class NavScreen(val titleAr: String, val titleEn: String) {
    HOME("الرئيسية", "Home"),
    DASHBOARD("لوحة التحكم", "Dashboard"),
    TRANSACTIONS("المعاملات", "Transactions"),
    CARDS("البطاقات", "Cards"),
    TRANSFERS("التحويلات", "Transfers"),
    SAVINGS("الادخار", "Savings"),
    SECURITY("الأمان", "Security"),
    ONBOARDING("فتح حساب", "Open Account")
}

data class Account(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val accountNumber: String,
    val iban: String,
    val balance: Double,
    val currency: String = "SAR",
    val type: String = "Current"
)

data class Transaction(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val merchant: String,
    val categoryAr: String,
    val categoryEn: String,
    val date: String,
    val amount: Double,
    val isIncoming: Boolean,
    val reference: String,
    val currency: String = "SAR"
)

enum class CardType {
    PHYSICAL_BLACK,
    VIRTUAL_GOLD,
    TEAL_DIGITAL
}

data class CardInfo(
    val id: String,
    val cardHolder: String,
    val cardNumber: String,
    val expiry: String,
    val cvv: String,
    val isFrozen: Boolean = false,
    val dailyLimit: Double = 5000.0,
    val cardType: CardType = CardType.PHYSICAL_BLACK
)

data class SavingsGoal(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val targetAmount: Double,
    val currentAmount: Double,
    val targetDate: String,
    val categoryIconName: String = "DirectionsCar"
)

data class Beneficiary(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val bankName: String,
    val iban: String
)

data class NotificationItem(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val date: String,
    val isRead: Boolean = false,
    val type: String = "info"
)

data class WaitlistFormState(
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val country: String = "السعودية",
    val isSubmitted: Boolean = false,
    val errorMessage: String? = null
)
