package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Account
import com.example.model.AppLanguage
import com.example.model.SavingsGoal
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun SavingsScreen(
    account: Account,
    savingsGoals: List<SavingsGoal>,
    language: AppLanguage,
    onAddGoal: (String, String, Double, String) -> Boolean,
    onContribute: (String, Double) -> Boolean,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC
    val scrollState = rememberScrollState()

    var showAddDialog by remember { mutableStateOf(false) }
    var contributeGoalId by remember { mutableStateOf<String?>(null) }
    var contributeAmountInput by remember { mutableStateOf("500") }

    val totalSaved = savingsGoals.sumOf { it.currentAmount }
    val totalTarget = savingsGoals.sumOf { it.targetAmount }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightNavy)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isAr) "أهداف الادخار والتوفير" else "Savings & Future Goals",
                fontFamily = CairoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = WarmIvory
            )

            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("create_savings_goal_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = if (isAr) "هدف جديد" else "New Goal", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Total Savings Overview Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.TrendingUp,
                        contentDescription = null,
                        tint = SubtleGold,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text(
                        text = if (isAr) "إجمالي الادخار الحالي" else "Total Savings Accumulated",
                        color = ArchitecturalSand,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "${String.format("%.2f", totalSaved)} SAR",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 28.sp,
                    color = WarmIvory
                )

                Spacer(modifier = Modifier.height(12.dp))

                val overallProgress = if (totalTarget > 0) (totalSaved / totalTarget).toFloat() else 0f
                Text(
                    text = if (isAr) "نسبة إنجاز الخطة الكلية: ${(overallProgress * 100).toInt()}%" else "Overall Goal Completion: ${(overallProgress * 100).toInt()}%",
                    color = SoftMint,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { overallProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MutedTeal,
                    trackColor = Color.White.copy(alpha = 0.1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Active Goals List
        Text(
            text = if (isAr) "قائمة الأهداف النشطة (${savingsGoals.size})" else "Active Goals (${savingsGoals.size})",
            fontFamily = CairoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = WarmIvory
        )

        Spacer(modifier = Modifier.height(12.dp))

        savingsGoals.forEach { goal ->
            val progress = (goal.currentAmount / goal.targetAmount).coerceIn(0.0, 1.0).toFloat()
            val percentInt = (progress * 100).toInt()

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("savings_goal_item_${goal.id}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MutedTeal.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Savings,
                                    contentDescription = null,
                                    tint = MutedTeal,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = if (isAr) goal.titleAr else goal.titleEn,
                                    color = WarmIvory,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isAr) "التاريخ المستهدف: ${goal.targetDate}" else "Target Date: ${goal.targetDate}",
                                    color = MutedGrey,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Text(
                            text = "$percentInt%",
                            color = SubtleGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${goal.currentAmount.toInt()} SAR",
                            color = WarmIvory,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "المستهدف: ${goal.targetAmount.toInt()} SAR",
                            color = ArchitecturalSand,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (percentInt >= 100) SoftMint else MutedTeal,
                        trackColor = Color.White.copy(alpha = 0.1f)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { contributeGoalId = goal.id },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkNavySurface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isAr) "+ إيداع مبلغ في الهدف" else "+ Add Contribution",
                            color = SubtleGold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }

    // Add Goal Dialog
    if (showAddDialog) {
        var newTitleAr by remember { mutableStateOf("") }
        var newTargetAmt by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddDialog = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (isAr) "إنشاء هدف ادخار جديد" else "Create New Savings Goal",
                        color = WarmIvory,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = newTitleAr,
                        onValueChange = { newTitleAr = it },
                        label = { Text(if (isAr) "اسم الهدف (مثال: رحلة، سيارة)" else "Goal Title") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WarmIvory,
                            unfocusedTextColor = WarmIvory,
                            focusedBorderColor = MutedTeal,
                            unfocusedBorderColor = MutedGrey
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = newTargetAmt,
                        onValueChange = { newTargetAmt = it },
                        label = { Text(if (isAr) "المبلغ المستهدف (ر.س)" else "Target Amount (SAR)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WarmIvory,
                            unfocusedTextColor = WarmIvory,
                            focusedBorderColor = MutedTeal,
                            unfocusedBorderColor = MutedGrey
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showAddDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkNavySurface),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = if (isAr) "إلغاء" else "Cancel")
                        }

                        Button(
                            onClick = {
                                val amt = newTargetAmt.toDoubleOrNull() ?: 0.0
                                if (newTitleAr.isNotBlank() && amt > 0) {
                                    onAddGoal(newTitleAr, newTitleAr, amt, "2027-12-31")
                                    showAddDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = if (isAr) "إنشاء" else "Create")
                        }
                    }
                }
            }
        }
    }

    // Contribute Dialog
    if (contributeGoalId != null) {
        Dialog(onDismissRequest = { contributeGoalId = null }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (isAr) "إيداع مبلغ في هدف الادخار" else "Deposit into Savings Goal",
                        color = WarmIvory,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = contributeAmountInput,
                        onValueChange = { contributeAmountInput = it },
                        label = { Text(if (isAr) "المبلغ (ر.س)" else "Amount (SAR)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WarmIvory,
                            unfocusedTextColor = WarmIvory,
                            focusedBorderColor = MutedTeal,
                            unfocusedBorderColor = MutedGrey
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { contributeGoalId = null },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkNavySurface),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = if (isAr) "إلغاء" else "Cancel")
                        }

                        Button(
                            onClick = {
                                val amt = contributeAmountInput.toDoubleOrNull() ?: 0.0
                                if (amt > 0) {
                                    onContribute(contributeGoalId!!, amt)
                                    contributeGoalId = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = if (isAr) "تأكيد الإيداع" else "Confirm Deposit")
                        }
                    }
                }
            }
        }
    }
}
