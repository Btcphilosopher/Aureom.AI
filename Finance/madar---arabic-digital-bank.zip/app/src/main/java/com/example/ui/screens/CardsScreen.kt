package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CardInfo
import com.example.ui.components.CustomCardView
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun CardsScreen(
    cards: List<CardInfo>,
    language: AppLanguage,
    onToggleFreeze: (String) -> Unit,
    onUpdateLimit: (String, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC
    val scrollState = rememberScrollState()

    var selectedCardId by remember { mutableStateOf(cards.firstOrNull()?.id ?: "") }
    val activeCard = cards.find { it.id == selectedCardId } ?: cards.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightNavy)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isAr) "إدارة بطاقات مدار" else "MADAR Card Controls",
                fontFamily = CairoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = WarmIvory
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(MutedTeal.copy(alpha = 0.2f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AddCard,
                        contentDescription = null,
                        tint = MutedTeal,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    Text(
                        text = if (isAr) "+ إصدار بطاقة رقمية" else "+ Issue Digital Card",
                        fontSize = 11.sp,
                        color = SoftMint,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Card Selection Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            cards.forEach { card ->
                val isSelected = card.id == selectedCardId
                val label = when (card.cardType) {
                    com.example.model.CardType.PHYSICAL_BLACK -> if (isAr) "المادية (سوداء)" else "Physical"
                    com.example.model.CardType.VIRTUAL_GOLD -> if (isAr) "الافتراضية (ذهبية)" else "Virtual"
                    com.example.model.CardType.TEAL_DIGITAL -> if (isAr) "الرقمية" else "Digital"
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) MutedTeal else DarkNavyCard)
                        .clickable { selectedCardId = card.id }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) WarmIvory else MutedGrey,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected Active Card Preview
        activeCard?.let { card ->
            CustomCardView(
                card = card,
                language = language,
                onToggleFreeze = onToggleFreeze
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Card Controls & Spending Limit Adjustment
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (isAr) "التحكم في حدود الإنفاق اليومي" else "Daily Spending Limit Control",
                        color = WarmIvory,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isAr) {
                            "يمكنك تعديل الحد الأقصى للمشتريات اليومية لحماية حسابك."
                        } else {
                            "Adjust maximum daily purchase limit to secure your funds."
                        },
                        color = MutedGrey,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    var currentLimit by remember(card.id) { mutableStateOf(card.dailyLimit.toFloat()) }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isAr) "الحد الحالي:" else "Current Limit:",
                            color = ArchitecturalSand,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "${currentLimit.toInt()} SAR",
                            color = SubtleGold,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Slider(
                        value = currentLimit,
                        onValueChange = { currentLimit = it },
                        valueRange = 1000f..20000f,
                        steps = 18,
                        onValueChangeFinished = {
                            onUpdateLimit(card.id, currentLimit.toDouble())
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = SubtleGold,
                            activeTrackColor = MutedTeal,
                            inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier.testTag("card_limit_slider")
                    )

                    // Quick Preset Limit Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(2500.0, 5000.0, 10000.0, 15000.0).forEach { preset ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DarkNavySurface)
                                    .clickable {
                                        currentLimit = preset.toFloat()
                                        onUpdateLimit(card.id, preset)
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${preset.toInt() / 1000}k SAR",
                                    color = ArchitecturalSand,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Card Security Capabilities Box
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkNavySurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = SoftMint,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = if (isAr) "خصائص الأمان الذكي المتقدمة" else "Advanced Card Security",
                            color = WarmIvory,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val securityFeatures = listOf(
                        if (isAr) "تجميد لحظي متاح 24/7 عبر التطبيق" else "24/7 Instant card freeze via app",
                        if (isAr) "رمز CVV ديناميكي متجدد لحماية الشراء عبر الإنترنت" else "Dynamic CVV for ultra-safe online shopping",
                        if (isAr) "إشعارات دفع فورية لكل معاملة" else "Instant push alerts for every payment",
                        if (isAr) "تعطيل الشراء الدولي أو أجهزة السحب الآلي عند الطلب" else "Toggle international transactions or ATM access"
                    )

                    securityFeatures.forEach { feature ->
                        Text(
                            text = "• $feature",
                            color = MutedGrey,
                            fontSize = 12.sp,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
