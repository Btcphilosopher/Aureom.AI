package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.NavScreen
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun OnboardingScreen(
    language: AppLanguage,
    onNavigate: (NavScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC
    val scrollState = rememberScrollState()

    var step by remember { mutableStateOf(1) } // 1: Country, 2: Personal, 3: Contact, 4: Preferences, 5: Success

    var selectedCountry by remember { mutableStateOf("المملكة العربية السعودية") }
    var fullNameAr by remember { mutableStateOf("محمد بن عبدالله العتيبي") }
    var fullNameEn by remember { mutableStateOf("Mohammed Al-Otaibi") }
    var nationalId by remember { mutableStateOf("1098421004") }
    var mobilePhone by remember { mutableStateOf("+966 50 123 4567") }
    var emailInput by remember { mutableStateOf("mohammed@example.com") }
    var accountTier by remember { mutableStateOf("حساب التميز الأسود (Elite Black)") }
    var primaryCurrency by remember { mutableStateOf("رصيد بالريال السعودي (SAR)") }

    var generatedIban by remember { mutableStateOf("") }
    var formError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightNavy)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = if (isAr) "فتح حساب مصرفي رقمي جديد" else "Open New Digital Bank Account",
            fontFamily = CairoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = WarmIvory
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = if (isAr) "انضم إلى مدار بخطوات بسيطة وفورية دون الحاجة لزيارة الفروع" else "Join MADAR instantly with simple steps—no branch visit needed",
            color = MutedGrey,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Progress Bar Steps
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf("1. الدولة", "2. البيانات", "3. التواصل", "4. المنتج", "5. التأكيد").forEachIndexed { index, title ->
                val isCurrent = step == index + 1
                val isDone = step > index + 1
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            when {
                                isDone -> SuccessGreen
                                isCurrent -> MutedTeal
                                else -> DarkNavyCard
                            }
                        )
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = title,
                        fontSize = 9.sp,
                        color = WarmIvory,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        when (step) {
            1 -> {
                // Step 1: Country Selection
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = if (isAr) "اختر دولة الإقامة والرعوية" else "Select Country of Residence",
                            color = WarmIvory,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        val countries = listOf(
                            "المملكة العربية السعودية",
                            "الإمارات العربية المتحدة",
                            "دولة الكويت",
                            "دولة قطر",
                            "مملكة البحرين",
                            "سلطنة عمان",
                            "جمهورية مصر العربية"
                        )

                        countries.forEach { country ->
                            val isSelected = selectedCountry == country
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) DarkNavySurface else MidnightNavy)
                                    .clickable { selectedCountry = country }
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Public,
                                            contentDescription = null,
                                            tint = if (isSelected) SubtleGold else MutedGrey,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = country,
                                            color = WarmIvory,
                                            fontSize = 13.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    }

                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = SoftMint,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = { step = 2 },
                    colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("onboarding_next_step1")
                ) {
                    Text(text = if (isAr) "متابعة لإدخال البيانات الشخصية" else "Continue", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }

            2 -> {
                // Step 2: Personal Details
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = if (isAr) "البيانات الشخصية والهوية" else "Personal & Identity Details",
                            color = WarmIvory,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        if (formError != null) {
                            Text(text = formError!!, color = ErrorRed, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                        }

                        OutlinedTextField(
                            value = fullNameAr,
                            onValueChange = { fullNameAr = it },
                            label = { Text(if (isAr) "الاسم الرباعي بالعربية" else "Full Name (Arabic)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = WarmIvory,
                                unfocusedTextColor = WarmIvory,
                                focusedBorderColor = MutedTeal,
                                unfocusedBorderColor = MutedGrey
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = fullNameEn,
                            onValueChange = { fullNameEn = it },
                            label = { Text(if (isAr) "الاسم باللغة الإنجليزية" else "Full Name (English)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = WarmIvory,
                                unfocusedTextColor = WarmIvory,
                                focusedBorderColor = MutedTeal,
                                unfocusedBorderColor = MutedGrey
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = nationalId,
                            onValueChange = { nationalId = it },
                            label = { Text(if (isAr) "رقم الهوية الوطنية / الإقامة" else "National ID / Iqama Number") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = WarmIvory,
                                unfocusedTextColor = WarmIvory,
                                focusedBorderColor = MutedTeal,
                                unfocusedBorderColor = MutedGrey
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = { step = 1 },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkNavyCard),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(text = if (isAr) "رجوع" else "Back") }

                    Button(
                        onClick = {
                            if (fullNameAr.isBlank() || nationalId.isBlank()) {
                                formError = if (isAr) "يرجى تعبئة كافة الحقول المطلوب" else "Please fill all fields"
                            } else {
                                formError = null
                                step = 3
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("onboarding_next_step2")
                    ) { Text(text = if (isAr) "التالي" else "Next") }
                }
            }

            3 -> {
                // Step 3: Contact Details
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = if (isAr) "معلومات التواصل والتفعيل" else "Contact & Verification Info",
                            color = WarmIvory,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = mobilePhone,
                            onValueChange = { mobilePhone = it },
                            label = { Text(if (isAr) "رقم الجوال المعتمد" else "Mobile Number") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = WarmIvory,
                                unfocusedTextColor = WarmIvory,
                                focusedBorderColor = MutedTeal,
                                unfocusedBorderColor = MutedGrey
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text(if (isAr) "البريد الإلكتروني الرئيسي" else "Email Address") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = WarmIvory,
                                unfocusedTextColor = WarmIvory,
                                focusedBorderColor = MutedTeal,
                                unfocusedBorderColor = MutedGrey
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = { step = 2 },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkNavyCard),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(text = if (isAr) "رجوع" else "Back") }

                    Button(
                        onClick = { step = 4 },
                        colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("onboarding_next_step3")
                    ) { Text(text = if (isAr) "التالي" else "Next") }
                }
            }

            4 -> {
                // Step 4: Product Preferences
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = if (isAr) "تخصيص فئة الحساب والبطاقة" else "Product & Card Preferences",
                            color = WarmIvory,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        val tiers = listOf(
                            "حساب التميز الأسود (Elite Black)",
                            "حساب مدار الرقمي (Digital Teal)",
                            "حساب الادخار الذكي (Smart Savings)"
                        )

                        tiers.forEach { tier ->
                            val isSelected = accountTier == tier
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) DarkNavySurface else MidnightNavy)
                                    .clickable { accountTier = tier }
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = tier,
                                        color = if (isSelected) SubtleGold else WarmIvory,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                    if (isSelected) {
                                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = SoftMint)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = { step = 3 },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkNavyCard),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(text = if (isAr) "رجوع" else "Back") }

                    Button(
                        onClick = {
                            generatedIban = "SA" + (10..99).random() + " 8000 0000 " + (1000..9999).random() + " " + (1000..9999).random() + " 8101"
                            step = 5
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("onboarding_submit_final")
                    ) { Text(text = if (isAr) "إصدار الحساب والآيبان" else "Issue Account") }
                }
            }

            5 -> {
                // Step 5: Success & Generated IBAN Screen
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(SuccessGreen.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(40.dp))
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (isAr) "مبروك! تم فتح حسابك في مدار بنجاح" else "Congratulations! Your Account is Ready",
                            color = WarmIvory,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkNavySurface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = if (isAr) "رقم الآيبان الدولي (IBAN):" else "International IBAN:", color = MutedGrey, fontSize = 11.sp)
                                Text(text = generatedIban, color = SubtleGold, fontSize = 15.sp, fontWeight = FontWeight.Bold)

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(text = if (isAr) "صاحب الحساب:" else "Account Holder:", color = MutedGrey, fontSize = 11.sp)
                                Text(text = fullNameAr, color = WarmIvory, fontSize = 14.sp, fontWeight = FontWeight.Bold)

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(text = if (isAr) "فئة الحساب:" else "Account Tier:", color = MutedGrey, fontSize = 11.sp)
                                Text(text = accountTier, color = SoftMint, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = { onNavigate(NavScreen.DASHBOARD) },
                            colors = ButtonDefaults.buttonColors(containerColor = MutedTeal),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("go_to_dashboard_after_onboarding")
                        ) {
                            Text(text = if (isAr) "الانتقال إلى لوحة التحكم المصرفية" else "Go to Banking Dashboard")
                        }
                    }
                }
            }
        }
    }
}
