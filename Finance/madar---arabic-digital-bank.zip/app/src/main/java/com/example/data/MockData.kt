package com.example.data

import com.example.model.Account
import com.example.model.Beneficiary
import com.example.model.CardInfo
import com.example.model.CardType
import com.example.model.NotificationItem
import com.example.model.SavingsGoal
import com.example.model.Transaction

object MockData {
    val initialAccount = Account(
        id = "acc_01",
        titleAr = "الحساب الجاري الرئيسي",
        titleEn = "Main Current Account",
        accountNumber = "9842100481",
        iban = "SA44 8000 0000 9842 1004 8101",
        balance = 18450.75,
        currency = "SAR",
        type = "Premium Current"
    )

    val initialCards = listOf(
        CardInfo(
            id = "c1",
            cardHolder = "MOHAMMED AL-OTAIBI",
            cardNumber = "4532 •••• •••• 8819",
            expiry = "08/29",
            cvv = "382",
            isFrozen = false,
            dailyLimit = 8000.0,
            cardType = CardType.PHYSICAL_BLACK
        ),
        CardInfo(
            id = "c2",
            cardHolder = "MOHAMMED AL-OTAIBI (VIRTUAL)",
            cardNumber = "4921 •••• •••• 3041",
            expiry = "11/27",
            cvv = "914",
            isFrozen = false,
            dailyLimit = 2500.0,
            cardType = CardType.VIRTUAL_GOLD
        ),
        CardInfo(
            id = "c3",
            cardHolder = "MOHAMMED AL-OTAIBI (DIGITAL)",
            cardNumber = "5214 •••• •••• 1109",
            expiry = "04/28",
            cvv = "105",
            isFrozen = true,
            dailyLimit = 1500.0,
            cardType = CardType.TEAL_DIGITAL
        )
    )

    val initialTransactions = listOf(
        Transaction(
            id = "tx_01",
            titleAr = "راتب شركة التقنية العالية",
            titleEn = "HighTech Corp Salary",
            merchant = "شركة التقنية العالية",
            categoryAr = "الدخل والراتب",
            categoryEn = "Salary & Income",
            date = "2026-10-25",
            amount = 12000.00,
            isIncoming = true,
            reference = "MDR-TX-9012"
        ),
        Transaction(
            id = "tx_02",
            titleAr = "أسواق التميمي - الملقا",
            titleEn = "Tamimi Markets - Al Malqa",
            merchant = "أسواق التميمي",
            categoryAr = "الطعام والتسوق",
            categoryEn = "Groceries & Food",
            date = "2026-10-24",
            amount = 345.50,
            isIncoming = false,
            reference = "MDR-TX-8821"
        ),
        Transaction(
            id = "tx_03",
            titleAr = "جرير للتكنولوجيا والمكتبة",
            titleEn = "Jarir Bookstore & Tech",
            merchant = "مكتبة جرير",
            categoryAr = "التسوق والإلكترونيات",
            categoryEn = "Shopping & Tech",
            date = "2026-10-23",
            amount = 1290.00,
            isIncoming = false,
            reference = "MDR-TX-8740"
        ),
        Transaction(
            id = "tx_04",
            titleAr = "كافيه دانكن ودونات",
            titleEn = "Dunkin Coffee",
            merchant = "Dunkin Cafe",
            categoryAr = "المقاهي والمطاعم",
            categoryEn = "Dining & Cafes",
            date = "2026-10-22",
            amount = 32.00,
            isIncoming = false,
            reference = "MDR-TX-8603"
        ),
        Transaction(
            id = "tx_05",
            titleAr = "شركة الكهرباء السعودية",
            titleEn = "Saudi Electricity Co.",
            merchant = "SEC Utility",
            categoryAr = "الفواتير والخدمات",
            categoryEn = "Utilities & Bills",
            date = "2026-10-20",
            amount = 412.00,
            isIncoming = false,
            reference = "MDR-TX-8419"
        ),
        Transaction(
            id = "tx_06",
            titleAr = "تحويل وارد من سارة المطيري",
            titleEn = "Transfer from Sarah Al-Mutairi",
            merchant = "سارة المطيري",
            categoryAr = "تحويلات شخصية",
            categoryEn = "Personal Transfer",
            date = "2026-10-18",
            amount = 1500.00,
            isIncoming = true,
            reference = "MDR-TX-8290"
        ),
        Transaction(
            id = "tx_07",
            titleAr = "تطبيقات النقل (أوبر/كريم)",
            titleEn = "Uber Ride Service",
            merchant = "Uber Saudi Arabia",
            categoryAr = "النقل والمواصلات",
            categoryEn = "Transport",
            date = "2026-10-17",
            amount = 68.00,
            isIncoming = false,
            reference = "MDR-TX-8115"
        )
    )

    val initialSavingsGoals = listOf(
        SavingsGoal(
            id = "sg_01",
            titleAr = "رحلة الصيف 2027",
            titleEn = "Summer Vacation 2027",
            targetAmount = 12000.0,
            currentAmount = 7500.0,
            targetDate = "2027-06-15",
            categoryIconName = "FlightTakeoff"
        ),
        SavingsGoal(
            id = "sg_02",
            titleAr = "دفعة السيارة الجديدة",
            titleEn = "New Car Downpayment",
            targetAmount = 45000.0,
            currentAmount = 18500.0,
            targetDate = "2027-12-30",
            categoryIconName = "DirectionsCar"
        ),
        SavingsGoal(
            id = "sg_03",
            titleAr = "صندوق الطوارئ والأمان",
            titleEn = "Emergency Reserve Fund",
            targetAmount = 30000.0,
            currentAmount = 22000.0,
            targetDate = "2026-12-31",
            categoryIconName = "Security"
        )
    )

    val initialBeneficiaries = listOf(
        Beneficiary("b1", "أحمد المحمد", "Ahmed Al-Mohammed", "البنك الأهلي السعودي", "SA12 1000 0000 1234 5678 9012"),
        Beneficiary("b2", "سارة المطيري", "Sarah Al-Mutairi", "مصرف الراجحي", "SA80 8000 0000 9876 5432 1098"),
        Beneficiary("b3", "خالد الشمري", "Khalid Al-Shammari", "بنك الرياض", "SA55 2000 0000 4567 8901 2345"),
        Beneficiary("b4", "شركة العقار المتحد", "United Real Estate Co.", "بنك الإنماء", "SA99 5000 0000 7890 1234 5678")
    )

    val initialNotifications = listOf(
        NotificationItem(
            id = "n1",
            titleAr = "إيداع راتب جديد",
            titleEn = "New Salary Credit",
            descriptionAr = "تم إيداع مبلغ 12,000.00 ر.س في حسابك الجاري بنجاح.",
            descriptionEn = "12,000.00 SAR has been credited to your account.",
            date = "اليوم، 09:30 ص",
            isRead = false,
            type = "success"
        ),
        NotificationItem(
            id = "n2",
            titleAr = "هدف الادخار قارب على الانتهاء",
            titleEn = "Savings Milestone Reached",
            descriptionAr = "حققت 62.5% من هدفك (رحلة الصيف 2027)!",
            descriptionEn = "You reached 62.5% of Summer Vacation goal!",
            date = "أمس، 04:15 م",
            isRead = false,
            type = "info"
        ),
        NotificationItem(
            id = "n3",
            titleAr = "تحديث الأمان الحساب",
            titleEn = "Security Notification",
            descriptionAr = "تم تسجيل الدخول بنجاح من جهاز Android جديد.",
            descriptionEn = "Successful login recorded from new Android device.",
            date = "23 أكتوبر",
            isRead = true,
            type = "warning"
        )
    )
}
