package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.SubtleGold

@Composable
fun PrototypeNoticeBanner(
    language: AppLanguage,
    onResetDemo: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC
    val noticeText = if (isAr) {
        "عرض تجريبي — بيانات افتراضية. هذا نموذج تجريبي لواجهة مصرفية، ولا يقدم خدمات مالية فعلية."
    } else {
        "Prototype Demo — Simulated Data. This is a banking interface prototype and does not provide actual financial services."
    }
    val resetText = if (isAr) "إعادة ضبط البيانات" else "Reset Demo"

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(MidnightNavy)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = SubtleGold,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = noticeText,
                color = ArchitecturalSand,
                fontSize = 12.sp,
                lineHeight = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }

        OutlinedButton(
            onClick = onResetDemo,
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = SubtleGold
            ),
            border = ButtonDefaults.outlinedButtonBorder(enabled = true),
            modifier = Modifier
                .padding(start = 8.dp)
                .testTag("reset_demo_button")
        ) {
            Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = null,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = resetText,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 4.dp)
            )
        }
    }
}
