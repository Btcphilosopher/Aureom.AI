package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.Transaction
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun TransactionsScreen(
    transactions: List<Transaction>,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") }

    val categories = listOf(
        Pair("ALL", if (isAr) "الكل" else "All"),
        Pair("INCOME", if (isAr) "الدخل" else "Income"),
        Pair("EXPENSE", if (isAr) "المصاريف" else "Expenses"),
        Pair("SHOPPING", if (isAr) "التسوق" else "Shopping"),
        Pair("UTILITIES", if (isAr) "الفواتير" else "Utilities")
    )

    val filteredTransactions = transactions.filter { tx ->
        val matchesSearch = tx.titleAr.contains(searchQuery, ignoreCase = true) ||
                tx.titleEn.contains(searchQuery, ignoreCase = true) ||
                tx.merchant.contains(searchQuery, ignoreCase = true) ||
                tx.reference.contains(searchQuery, ignoreCase = true)

        val matchesCategory = when (selectedCategory) {
            "INCOME" -> tx.isIncoming
            "EXPENSE" -> !tx.isIncoming
            "SHOPPING" -> tx.categoryAr.contains("تسوق") || tx.categoryEn.contains("Shopping")
            "UTILITIES" -> tx.categoryAr.contains("فواتير") || tx.categoryEn.contains("Utilities")
            else -> true
        }

        matchesSearch && matchesCategory
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightNavy)
            .padding(16.dp)
    ) {
        Text(
            text = if (isAr) "سجل المعاملات المالية" else "Transaction History",
            fontFamily = CairoFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = WarmIvory
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(if (isAr) "ابحث عن تاجر، مرجع أو فئة..." else "Search merchant, reference...") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = MutedGrey
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = WarmIvory,
                unfocusedTextColor = WarmIvory,
                focusedBorderColor = MutedTeal,
                unfocusedBorderColor = MutedGrey
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("transaction_search_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Filter Pills Row
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories) { cat ->
                val isSelected = selectedCategory == cat.first
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) MutedTeal else DarkNavyCard)
                        .clickable { selectedCategory = cat.first }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = cat.second,
                        color = if (isSelected) WarmIvory else MutedGrey,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Transaction Count Header
        Text(
            text = if (isAr) "عرض (${filteredTransactions.size}) معاملة" else "Showing (${filteredTransactions.size}) transactions",
            color = ArchitecturalSand,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Transaction List
        if (filteredTransactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Receipt,
                        contentDescription = null,
                        tint = MutedGrey,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isAr) "لا توجد معاملات مطابقة للبحث" else "No transactions found",
                        color = MutedGrey,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredTransactions) { tx ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transaction_item_${tx.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (tx.isIncoming) SuccessGreen.copy(alpha = 0.2f) else ErrorRed.copy(alpha = 0.2f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (tx.isIncoming) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                        contentDescription = null,
                                        tint = if (tx.isIncoming) SuccessGreen else ErrorRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = if (isAr) tx.titleAr else tx.titleEn,
                                        color = WarmIvory,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${if (isAr) tx.categoryAr else tx.categoryEn} • ${tx.date}",
                                        color = MutedGrey,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "Ref: ${tx.reference}",
                                        color = SubtleGold,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Text(
                                text = (if (tx.isIncoming) "+" else "-") + "${String.format("%.2f", tx.amount)} SAR",
                                color = if (tx.isIncoming) SuccessGreen else WarmIvory,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
