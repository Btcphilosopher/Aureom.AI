package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Account
import com.example.model.AppLanguage
import com.example.model.CardInfo
import com.example.model.NavScreen
import com.example.model.SavingsGoal
import com.example.model.Transaction
import com.example.ui.components.CustomCardView
import com.example.ui.components.SpendingChart
import com.example.ui.theme.ArchitecturalSand
import com.example.ui.theme.BrightGold
import com.example.ui.theme.CairoFontFamily
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkNavySurface
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.LightTeal
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.MutedTeal
import com.example.ui.theme.SoftMint
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SubtleGold
import com.example.ui.theme.WarmIvory

@Composable
fun DashboardScreen(
    account: Account,
    cards: List<CardInfo>,
    transactions: List<Transaction>,
    savingsGoals: List<SavingsGoal>,
    language: AppLanguage,
    onNavigate: (NavScreen) -> Unit,
    onToggleFreeze: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isAr = language == AppLanguage.ARABIC
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightNavy)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Welcome Header & Account Type
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (isAr) "أهلاً بك، محمد العتيبي" else "Welcome, Mohammed Al-Otaibi",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = WarmIvory
                )
                Text(
                    text = if (isAr) "رقم الحساب: ${account.accountNumber}" else "Account #: ${account.accountNumber}",
                    fontSize = 12.sp,
                    color = MutedGrey
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkNavySurface)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isAr) "حساب مدار التميز" else "MADAR Elite",
                    fontSize = 11.sp,
                    color = SubtleGold,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Main Balance Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("dashboard_balance_card")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = if (isAr) "الرصف المتاح الكلي" else "Total Available Balance",
                    fontSize = 12.sp,
                    color = ArchitecturalSand,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "${String.format("%.2f", account.balance)} ${account.currency}",
                    fontFamily = CairoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    color = WarmIvory
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (isAr) "إجمالي الدخل الشهري" else "Monthly Income",
                            fontSize = 10.sp,
                            color = MutedGrey
                        )
                        Text(
                            text = "+12,000.00 SAR",
                            fontSize = 13.sp,
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Column {
                        Text(
                            text = if (isAr) "إجمالي المصاريف" else "Monthly Spending",
                            fontSize = 10.sp,
                            color = MutedGrey
                        )
                        Text(
                            text = "-4,280.50 SAR",
                            fontSize = 13.sp,
                            color = ErrorRed,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Column {
                        Text(
                            text = if (isAr) "الرصيد الإجمالي" else "Current Balance",
                            fontSize = 10.sp,
                            color = MutedGrey
                        )
                        Text(
                            text = "48,250.00 SAR",
                            fontSize = 13.sp,
                            color = BrightGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Action Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            QuickActionButton(
                label = if (isAr) "تحويل أموال" else "Transfer",
                icon = Icons.Default.Send,
                onClick = { onNavigate(NavScreen.TRANSFERS) },
                testTag = "quick_transfer_button"
            )
            QuickActionButton(
                label = if (isAr) "إدارة البطاقات" else "Cards",
                icon = Icons.Default.CreditCard,
                onClick = { onNavigate(NavScreen.CARDS) },
                testTag = "quick_cards_button"
            )
            QuickActionButton(
                label = if (isAr) "هدف ادخار" else "Add Goal",
                icon = Icons.Default.Savings,
                onClick = { onNavigate(NavScreen.SAVINGS) },
                testTag = "quick_savings_button"
            )
            QuickActionButton(
                label = if (isAr) "المعاملات" else "History",
                icon = Icons.Default.PieChart,
                onClick = { onNavigate(NavScreen.TRANSACTIONS) },
                testTag = "quick_transactions_button"
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Active Card Preview Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isAr) "بطاقاتك النشطة" else "Your Active Cards",
                fontFamily = CairoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = WarmIvory
            )
            Text(
                text = if (isAr) "عرض الكل >" else "View All >",
                fontSize = 12.sp,
                color = SubtleGold,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onNavigate(NavScreen.CARDS) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (cards.isNotEmpty()) {
            CustomCardView(
                card = cards.first(),
                language = language,
                onToggleFreeze = onToggleFreeze
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Spending Analytics Component
        SpendingChart(language = language)

        Spacer(modifier = Modifier.height(24.dp))

        // Recent Transactions Overview
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isAr) "آخر المعاملات المالية" else "Recent Transactions",
                fontFamily = CairoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = WarmIvory
            )
            Text(
                text = if (isAr) "السجل الكامل >" else "Full History >",
                fontSize = 12.sp,
                color = SubtleGold,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onNavigate(NavScreen.TRANSACTIONS) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                transactions.take(4).forEach { tx ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (tx.isIncoming) SuccessGreen.copy(alpha = 0.2f) else ErrorRed.copy(alpha = 0.2f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (tx.isIncoming) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                    contentDescription = null,
                                    tint = if (tx.isIncoming) SuccessGreen else ErrorRed,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = if (isAr) tx.titleAr else tx.titleEn,
                                    color = WarmIvory,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${tx.categoryAr} • ${tx.date}",
                                    color = MutedGrey,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Text(
                            text = (if (tx.isIncoming) "+" else "-") + "${String.format("%.2f", tx.amount)} SAR",
                            color = if (tx.isIncoming) SuccessGreen else WarmIvory,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Savings Goals Teaser
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isAr) "أهداف الادخار الحالية" else "Active Savings Goals",
                fontFamily = CairoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = WarmIvory
            )
            Text(
                text = if (isAr) "إدارة الأهداف >" else "Manage Goals >",
                fontSize = 12.sp,
                color = SubtleGold,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onNavigate(NavScreen.SAVINGS) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        savingsGoals.take(2).forEach { goal ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkNavySurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isAr) goal.titleAr else goal.titleEn,
                            color = WarmIvory,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${goal.currentAmount.toInt()} / ${goal.targetAmount.toInt()} SAR",
                            color = SubtleGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val progress = (goal.currentAmount / goal.targetAmount).coerceIn(0.0, 1.0).toFloat()
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = MutedTeal,
                        trackColor = Color.White.copy(alpha = 0.1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(DarkNavyCard),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = SubtleGold,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = WarmIvory,
            fontWeight = FontWeight.Medium
        )
    }
}
