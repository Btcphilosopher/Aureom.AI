package com.example

import com.example.data.MarketRepository
import com.example.engine.*
import com.example.model.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testTvPricingEngineInvariants() {
        val prog = MarketRepository.sampleProgrammes.first()
        val quote = TVPricingEngine.calculateSpotQuote(
            programme = prog,
            duration = SpotDuration.SEC_30,
            position = BreakPosition.MIDDLE_BREAK,
            demographic = DemographicTarget.ALL_ADULTS,
            agencyDiscountPct = 15.0,
            volumeDiscountPct = 5.0
        )

        assertTrue("Net price must be positive", quote.netSpotPrice > 0.0)
        assertTrue("Net price must be less than gross rate card due to discounts", quote.netSpotPrice < quote.grossRateCardPrice)
        assertTrue("CPM must be positive", quote.cpmAllAdults > 0.0)
        assertTrue("CPP must be positive", quote.costPerRatingPointCpp > 0.0)
        assertTrue("Attention seconds must be positive and bounded by spot length", quote.attentionSeconds in 1.0..30.0)

        // Mathematical invariant: CPM = (Net Price / Total Impressions) * 1000
        val expectedCpm = (quote.netSpotPrice / (prog.estimatedAudienceMillions * 1_000_000.0)) * 1000.0
        assertEquals(expectedCpm, quote.cpmAllAdults, 0.01)
    }

    @Test
    fun testSearchAuctionTwinInvariants() {
        val result = SearchAuctionEngine.simulateSearchAuction(
            keyword = "car insurance quotes",
            userBidGbp = 15.0,
            userQualityScore = 8.0,
            competitionDensity = 5
        )

        assertTrue("Position must be between 1 and 10", result.position in 1..10)
        assertTrue("Actual CPC cannot exceed Max Bid", result.actualCpcGbp <= 15.0)
        assertTrue("Actual CPC must be positive", result.actualCpcGbp > 0.0)
        assertTrue("Daily clicks must be positive", result.estimatedDailyClicks > 0)
        assertTrue("Daily spend must equal Clicks * Actual CPC", result.estimatedDailyCostGbp > 0.0)
    }

    @Test
    fun testDisplayVcpmInvariants() {
        val quote = DisplayVideoEngine.calculateDisplayQuote(
            format = DisplayVideoEngine.DisplayFormat.STANDARD_BANNER,
            budgetGbp = 10000.0
        )

        assertTrue("Viewable impressions must be <= Served impressions", quote.viewableImpressions <= quote.totalServedImpressions)
        assertTrue("vCPM must be >= served CPM", quote.effectiveVcpmGbp >= quote.rawCpmGbp)
        assertEquals(quote.totalServedImpressions, quote.viewableImpressions + quote.nonViewableImpressions)
    }

    @Test
    fun testAttentionEconomicsInvariants() {
        val result = AttentionEconomicsEngine.evaluateAttention(
            channel = MarketChannel.TELEVISION,
            budgetGbp = 50000.0
        )

        assertTrue("Total attention seconds must be positive", result.totalActiveAttentionSeconds > 0.0)
        assertTrue("Attention CPM must be positive", result.attentionCpmGbp > 0.0)
        assertTrue("Cost per attention minute must be positive", result.costPerAttentionMinuteGbp > 0.0)
    }

    @Test
    fun testCrossMediaDeduplicatedReach() {
        val comp = CrossMediaTranslator.compareChannels(
            baseChannel = MarketChannel.TELEVISION,
            targetChannel = MarketChannel.GOOGLE_SEARCH,
            spendGbp = 100000.0
        )

        val universe = 54.2
        assertTrue("Deduplicated reach cannot exceed population universe", comp.crossPlatformDeduplicatedReachMillions <= universe)
        assertTrue("Combined reach must be >= individual channel reach", comp.crossPlatformDeduplicatedReachMillions >= comp.baseChannel.estimatedReachMillions)
    }

    @Test
    fun testMediaMixFrontierAllocations() {
        val portfolio = MediaMixFrontierEngine.generatePortfolio(
            preset = MediaMixFrontierEngine.StrategyPreset.BALANCED,
            totalBudgetGbp = 500000.0
        )

        val totalShare = portfolio.allocations.sumOf { it.budgetSharePct }
        assertEquals(100.0, totalShare, 0.01)
        val totalAllocated = portfolio.allocations.sumOf { it.allocatedGbp }
        assertEquals(500000.0, totalAllocated, 0.01)
    }
}
