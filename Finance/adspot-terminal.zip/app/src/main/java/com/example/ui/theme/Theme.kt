package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = TerminalCyan,
    onPrimary = TerminalBackground,
    primaryContainer = TerminalCyanDim,
    onPrimaryContainer = TerminalCyan,
    secondary = TerminalGold,
    onSecondary = TerminalBackground,
    secondaryContainer = TerminalGoldDim,
    onSecondaryContainer = TerminalGold,
    tertiary = TerminalGreen,
    onTertiary = TerminalBackground,
    background = TerminalBackground,
    onBackground = TerminalWhite,
    surface = TerminalSurface,
    onSurface = TerminalWhite,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TerminalSteel,
    outline = TerminalCardBorder,
    error = TerminalRed,
    onError = TerminalWhite
)

@Composable
fun AdspotTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = TerminalTypography,
        content = content
    )
}
