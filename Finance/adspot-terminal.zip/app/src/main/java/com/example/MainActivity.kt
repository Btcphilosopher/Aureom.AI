package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.AdspotIndicesEngine
import com.example.engine.ArbitrageScenarioEngine
import com.example.model.Currency
import com.example.ui.components.TerminalHeader
import com.example.ui.components.TickerBar
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AdspotTheme {
                AdspotTerminalApp()
            }
        }
    }
}

data class NavTab(
    val id: Int,
    val title: String,
    val tag: String,
    val icon: ImageVector
)

@Composable
fun AdspotTerminalApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var selectedCurrency by remember { mutableStateOf(Currency.GBP) }
    var pppMode by remember { mutableStateOf(false) }
    var activeShock by remember { mutableStateOf<ArbitrageScenarioEngine.ShockScenario?>(null) }
    var cliInitialCommand by remember { mutableStateOf<String?>(null) }

    // Handle Android system back button when on sub-screen
    BackHandler(enabled = selectedTab != 0) {
        selectedTab = 0
    }

    val tabs = listOf(
        NavTab(0, "TERMINAL", "MARKET", Icons.Default.Analytics),
        NavTab(1, "TV SPOT", "TV-30", Icons.Default.Tv),
        NavTab(2, "DIGITAL", "AUCTION", Icons.Default.TrendingUp),
        NavTab(3, "EQUIVALENCE", "CROSS", Icons.Default.CompareArrows),
        NavTab(4, "ORDER BOOK", "BOOK", Icons.Default.FormatListNumbered),
        NavTab(5, "FRONTIER", "QUANT", Icons.Default.AccountBalance),
        NavTab(6, "AI & CLI", "PROMPT", Icons.Default.Terminal)
    )

    val activeShockDelta = activeShock?.aggregateAdInflationDelta ?: 0.0
    val tickerItems = AdspotIndicesEngine.getMainIndices(selectedCurrency, activeShockDelta)

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground),
        topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
                TerminalHeader(
                    selectedCurrency = selectedCurrency,
                    onSelectCurrency = { selectedCurrency = it },
                    pppMode = pppMode,
                    onTogglePpp = { pppMode = !pppMode },
                    activeShockTitle = activeShock?.title,
                    onResetShock = { activeShock = null },
                    onOpenCli = {
                        cliInitialCommand = "WHAT IS THE CURRENT VALUE OF A 30 SECOND TV SPOT?"
                        selectedTab = 6
                    }
                )
                TickerBar(items = tickerItems)
            }
        },
        bottomBar = {
            // Institutional Monospace Bottom Navigation Rail / Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                color = TerminalSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    tabs.forEach { tab ->
                        val isSelected = tab.id == selectedTab
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (isSelected) TerminalCyanDim.copy(alpha = 0.5f) else TerminalBackground,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) TerminalCyan else TerminalCardBorder
                            ),
                            modifier = Modifier
                                .clickable { selectedTab = tab.id }
                                .testTag("nav_tab_${tab.tag.lowercase()}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) TerminalCyan else TerminalSteel,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = tab.tag,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isSelected) TerminalWhite else TerminalSteel
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> TerminalHomeScreen(
                    selectedCurrency = selectedCurrency,
                    activeShockDeltaPct = activeShockDelta,
                    onNavigateToTab = { selectedTab = it },
                    onRunCommand = { cmd ->
                        cliInitialCommand = cmd
                        selectedTab = 6
                    }
                )
                1 -> TVSpotMarketScreen(
                    selectedCurrency = selectedCurrency
                )
                2 -> DigitalAuctionScreen(
                    selectedCurrency = selectedCurrency
                )
                3 -> CrossMediaEquivalenceScreen(
                    selectedCurrency = selectedCurrency
                )
                4 -> OrderBookArbitrageScreen(
                    selectedCurrency = selectedCurrency
                )
                5 -> QuantScenarioReplayScreen(
                    selectedCurrency = selectedCurrency,
                    activeShockId = activeShock?.id,
                    onApplyShock = { shock -> activeShock = shock },
                    onClearShock = { activeShock = null }
                )
                6 -> AiTerminalCliScreen(
                    selectedCurrency = selectedCurrency,
                    initialCommand = cliInitialCommand
                )
            }
        }
    }
}
