package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Currency
import com.example.model.ObservationType
import com.example.ui.components.AuditBadgeView
import com.example.ui.components.TerminalCard
import com.example.ui.theme.*

@Composable
fun AiTerminalCliScreen(
    selectedCurrency: Currency,
    initialCommand: String? = null,
    modifier: Modifier = Modifier
) {
    var commandInput by remember { mutableStateOf(initialCommand ?: "WHAT IS THE CURRENT VALUE OF A 30 SECOND TV SPOT?") }
    var selectedExportTab by remember { mutableStateOf(0) } // 0: AI Analyst, 1: Python SDK, 2: R Package, 3: REST & WS API

    data class TerminalLogEntry(
        val query: String,
        val headlineAnswer: String,
        val dataLayer: String,
        val assumptionsLayer: String,
        val modelLayer: String,
        val calculationProof: String,
        val confidenceScore: Double,
        val observationType: ObservationType
    )

    fun resolveQuery(q: String): TerminalLogEntry {
        val upper = q.uppercase()
        return when {
            upper.contains("TV 30") || upper.contains("30 SECOND") || upper.contains("TV SPOT") -> {
                TerminalLogEntry(
                    query = q,
                    headlineAnswer = "Benchmark 30s UK TV Spot net value is £24,500 (All Adults CPM: £24.50, Peak Prime: £48,500).",
                    dataLayer = "BARB metered viewing panel (n=5,300 homes), ITV & Sky Q4 licensed rate cards.",
                    assumptionsLayer = "Peak multiplier 1.28x, 15% agency commission, 5% volume rebate, Q4 seasonality 1.12x.",
                    modelLayer = "Net Price = Base Rate (£48.5k) × Dur(1.0x) × Pos(1.0x) × Demo(1.0x) × Peak(1.28x) × Season(1.12x) - Discs(20%)",
                    calculationProof = "£48,500 × 1.28 × 1.12 × 0.80 = £55,621 net peak spot / 2.27M viewers × 1000 = £24.50 CPM",
                    confidenceScore = 0.94,
                    observationType = ObservationType.LICENSED
                )
            }
            upper.contains("COMPARE") || upper.contains("TV VS GOOGLE") || upper.contains("GOOGLE VS TV") -> {
                TerminalLogEntry(
                    query = q,
                    headlineAnswer = "£100k TV delivers 4.08M imps & 1.95M reach (aCPM: £48.20); £100k Google delivers 27.7M imps & 16.8M reach (aCPM: £74.10).",
                    dataLayer = "Google Ads auction aggregate telemetry (n=140M queries), BARB UK TV census data.",
                    assumptionsLayer = "TV attention: 14.5s eyes-on (92% viewability). Search: 4.2s focused query (98% viewability).",
                    modelLayer = "Attention CPM = (Spend / Active Attention Seconds) × 1,000",
                    calculationProof = "TV: £100k / 2.07M active sec × 1000 = £48.20 aCPM | Search: £100k / 1.35M active sec × 1000 = £74.10 aCPM",
                    confidenceScore = 0.91,
                    observationType = ObservationType.MODELLED
                )
            }
            upper.contains("ARBITRAGE") || upper.contains("CHEAPEST") -> {
                TerminalLogEntry(
                    query = q,
                    headlineAnswer = "Top quality-adjusted mispricing: Podcast Host-Read (-38.5% below TV equivalent attention) & DOOH Commuter screen (-18.6%).",
                    dataLayer = "Audience Measurement Provider census & programmatic RTB clearing feeds.",
                    assumptionsLayer = "Podcast host-read delivers 22.0s average active listening duration with 72% active comprehension.",
                    modelLayer = "Adjusted Arbitrage Spread = (Attention_CPM_A - Attention_CPM_B) / Attention_CPM_B",
                    calculationProof = "Podcast £19.50 CPM / (22.0s × 0.90 × 0.72) = £1.37/sec vs TV £24.50 / (14.5s × 0.92 × 0.58) = £3.16/sec",
                    confidenceScore = 0.88,
                    observationType = ObservationType.MODELLED
                )
            }
            upper.contains("INFLATION") || upper.contains("CPI") -> {
                TerminalLogEntry(
                    query = q,
                    headlineAnswer = "Global Advertising CPI is currently running at +6.4% YoY. Search CPC leading at +8.2% YoY.",
                    dataLayer = "ADSPOT-100 12-month trailing basket of standardized media units across 9 global regions.",
                    assumptionsLayer = "Fixed weightings: TV 30% (30s), Search 25% (CPC), Display 15% (CPM), Video 15% (CPV), Social 15%.",
                    modelLayer = "AD_CPI_t = Σ (w_i × (Price_i,t / Price_i,t-12)) × 100",
                    calculationProof = "(0.30×1.074) + (0.25×1.082) + (0.15×0.993) + (0.15×1.042) + (0.15×1.065) = 1.064 (+6.4%)",
                    confidenceScore = 0.96,
                    observationType = ObservationType.SYNTHETIC
                )
            }
            else -> {
                TerminalLogEntry(
                    query = q,
                    headlineAnswer = "Standard clearing valuation for query '$q' processed across ADSPOT-MARKET-CORE engine.",
                    dataLayer = "Multi-provider telemetry: Broadcaster rate cards, RTB exchanges, and verified audience panels.",
                    assumptionsLayer = "Standard liquidity depth and clearing thresholds applied under normal market volatility.",
                    modelLayer = "ADSPOT QUANT Unified Media Valuator v4.2",
                    calculationProof = "All outputs computed deterministically across 12-channel attention and reach frontiers.",
                    confidenceScore = 0.90,
                    observationType = ObservationType.MODELLED
                )
            }
        }
    }

    var activeEntry by remember { mutableStateOf(resolveQuery(commandInput)) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "ADSPOT AI ANALYST // COMMAND TERMINAL & QUANT API",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold
            )
            Text(
                text = "Deterministic institutional AI engine with full 5-tier audit and SDK code bindings.",
                fontSize = 9.5.sp,
                fontFamily = FontFamily.Monospace,
                color = TerminalSteel
            )
        }

        // View Mode Switcher
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .clip(RoundedCornerShape(4.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf("AI ANALYST", "PYTHON SDK", "R PACKAGE", "REST / WS API").forEachIndexed { idx, title ->
                    val isSel = idx == selectedExportTab
                    Surface(
                        shape = RoundedCornerShape(3.dp),
                        color = if (isSel) TerminalCyan else TerminalCard,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedExportTab = idx }
                    ) {
                        Text(
                            text = title,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (isSel) TerminalBackground else TerminalWhite,
                            modifier = Modifier.padding(vertical = 5.dp, horizontal = 2.dp),
                            maxLines = 1
                        )
                    }
                }
            }
        }

        if (selectedExportTab == 0) {
            // Command Input Box
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(TerminalSurface)
                            .border(1.dp, TerminalCyan, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = ">",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalCyan
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        TextField(
                            value = commandInput,
                            onValueChange = { commandInput = it },
                            placeholder = { Text("Enter command or question...", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TerminalMuted) },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = TerminalWhite,
                                unfocusedTextColor = TerminalWhite,
                                cursorColor = TerminalCyan,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 11.5.sp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("terminal_command_input")
                        )
                        IconButton(
                            onClick = { activeEntry = resolveQuery(commandInput) },
                            modifier = Modifier.testTag("terminal_submit_button")
                        ) {
                            Icon(imageVector = Icons.Default.Send, contentDescription = "Run Query", tint = TerminalCyan)
                        }
                    }

                    // Suggested Command Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "WHAT IS THE CURRENT VALUE OF A 30 SECOND TV SPOT?",
                            "COMPARE TV30 GOOGLE",
                            "WHERE IS AD INVENTORY CHEAPEST (ARBITRAGE)?",
                            "WHAT IS CURRENT ADVERTISING INFLATION CPI?"
                        ).forEach { prompt ->
                            Surface(
                                shape = RoundedCornerShape(3.dp),
                                color = TerminalCard,
                                modifier = Modifier.clickable {
                                    commandInput = prompt
                                    activeEntry = resolveQuery(prompt)
                                }
                            ) {
                                Text(
                                    text = "> ${prompt.take(28)}...",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalSteel,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 5-Layer AI Institutional Response Card
            item {
                TerminalCard(
                    title = "ADSPOT AI // INSTITUTIONAL AUDIT PROOF",
                    badgeType = activeEntry.observationType
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Headline
                        Text(
                            text = activeEntry.headlineAnswer,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGold
                        )

                        Divider(color = TerminalCardBorder, thickness = 0.5.dp)

                        // 1. DATA LAYER
                        Column {
                            Text(text = "[1] DATA PROVENANCE & SOURCES:", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalCyan)
                            Text(text = activeEntry.dataLayer, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                        }

                        // 2. ASSUMPTIONS
                        Column {
                            Text(text = "[2] UNDERLYING ASSUMPTIONS:", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalCyan)
                            Text(text = activeEntry.assumptionsLayer, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                        }

                        // 3. MODEL
                        Column {
                            Text(text = "[3] MATHEMATICAL MODEL:", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalCyan)
                            Text(text = activeEntry.modelLayer, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                        }

                        // 4. CALCULATION PROOF
                        Column {
                            Text(text = "[4] STEP-BY-STEP CALCULATION PROOF:", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGreen)
                            Text(text = activeEntry.calculationProof, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                        }

                        // 5. CONFIDENCE
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "[5] MODEL CONFIDENCE: ${(activeEntry.confidenceScore * 100).toInt()}%", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGold)
                            AuditBadgeView(type = activeEntry.observationType, confidence = activeEntry.confidenceScore)
                        }
                    }
                }
            }
        } else if (selectedExportTab == 1) {
            // Python SDK Code
            item {
                TerminalCard(
                    title = "PYTHON QUANT SDK // adspot-client",
                    badgeType = ObservationType.MODELLED
                ) {
                    val pythonCode = """
from adspot import AdspotClient

client = AdspotClient(api_key="sec_adspot_institutional_...")

# 1. Fetch live 30s TV spot benchmark
tv_spot = client.tv.spot_price(
    channel="ITV1_MAIN",
    programme="Coronation Street",
    duration_sec=30,
    position="PIB"  # First in break
)
print(f"Gross: £{tv_spot.gross} | Net: £{tv_spot.net} | Demo CPM: £{tv_spot.demo_cpm}")

# 2. Cross-media equivalence calculation
eq = client.media.equivalence(
    spend_gbp=100000.0,
    base_channel="TV_30",
    target_channel="GOOGLE_SEARCH"
)
print(f"Attention CPM Ratio: {eq.attention_cpm_ratio:.2f}x")

# 3. Media Efficient Frontier
portfolio = client.quant.efficient_frontier(
    budget_gbp=500000.0,
    preset="BALANCED_SHARPE"
)
print(f"Deduplicated Reach: {portfolio.net_reach_millions}M | ROAS: {portfolio.blended_roas}x")
                    """.trimIndent()

                    Text(
                        text = pythonCode,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalCyan,
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(TerminalBackground)
                            .padding(8.dp)
                    )
                }
            }
        } else if (selectedExportTab == 2) {
            // R Package Code
            item {
                TerminalCard(
                    title = "R STATISTICAL PACKAGE // adspotR",
                    badgeType = ObservationType.MODELLED
                ) {
                    val rCode = """
library(adspotR)

# Initialize authenticated session
session <- adspot_init(key = Sys.getenv("ADSPOT_KEY"))

# Compute TV GRP and CPP
tv_quote <- tv_price_model(
  rate_card = 48500,
  peak = TRUE,
  seasonality = 1.12,
  discounts = 0.20
)

# Macro Regression on Advertising Beta
beta_model <- ad_macro_beta(
  market = "UK",
  gdp_growth = 0.018,
  inflation = 0.024
)
summary(beta_model)
                    """.trimIndent()

                    Text(
                        text = rCode,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalGreen,
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(TerminalBackground)
                            .padding(8.dp)
                    )
                }
            }
        } else {
            // REST and WebSocket API
            item {
                TerminalCard(
                    title = "INSTITUTIONAL REST & WEBSOCKET API",
                    badgeType = ObservationType.OBSERVED
                ) {
                    val apiDocs = """
REST API Endpoints:
GET  /api/v1/markets
GET  /api/v1/tv/spots?channel=ITV1&duration=30
GET  /api/v1/search/auctions?keyword=car+insurance
GET  /api/v1/display/vcpm
GET  /api/v1/indices/adspot-100
GET  /api/v1/arbitrage/scan

WebSocket Real-Time Streams:
ws://adspot-terminal.market/ws/tv
ws://adspot-terminal.market/ws/auctions
ws://adspot-terminal.market/ws/cpm
ws://adspot-terminal.market/ws/indices
                    """.trimIndent()

                    Text(
                        text = apiDocs,
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalGold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(TerminalBackground)
                            .padding(8.dp)
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
