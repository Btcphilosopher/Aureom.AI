package com.example.engine

import com.example.model.MarketChannel
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object CrossMediaTranslator {

    data class ChannelMetricRow(
        val channel: MarketChannel,
        val spendGbp: Double,
        val rawCpmGbp: Double,
        val impressions: Long,
        val estimatedReachMillions: Double,
        val averageFrequency: Double,
        val totalAttentionSecondsMillions: Double,
        val estimatedClicksOrVisits: Long,
        val estimatedConversions: Long,
        val brandRecallUnits: Long,
        val attentionCpmGbp: Double
    )

    data class ComparisonResult(
        val baseChannel: ChannelMetricRow,
        val targetChannel: ChannelMetricRow,
        val spendGbp: Double,
        val impressionRatio: Double,
        val reachRatio: Double,
        val attentionSecondsRatio: Double,
        val cpmDifferencePct: Double,
        val crossPlatformDeduplicatedReachMillions: Double,
        val qualitativeVerdict: String
    )

    fun calculateChannelRow(channel: MarketChannel, spendGbp: Double): ChannelMetricRow {
        val attentionRes = AttentionEconomicsEngine.evaluateAttention(channel, spendGbp)
        val impressions = attentionRes.totalImpressions
        val cpm = attentionRes.rawCpmGbp

        // Universe of total population (UK benchmark = 54.2M adults)
        val universe = 54.2
        val rawReachUncapped = (impressions / 1_000_000.0)

        // Diminishing returns reach curve: Reach = Universe * (1 - e^(-k * Imps / Universe))
        val reachConstant = when (channel) {
            MarketChannel.TELEVISION -> 0.45
            MarketChannel.STREAMING_TV -> 0.38
            MarketChannel.CINEMA -> 0.22
            MarketChannel.YOUTUBE -> 0.52
            MarketChannel.PODCAST -> 0.20
            MarketChannel.RADIO -> 0.35
            MarketChannel.GOOGLE_SEARCH -> 0.30
            MarketChannel.SOCIAL -> 0.60
            MarketChannel.DIGITAL_OUT_OF_HOME -> 0.42
            MarketChannel.OUT_OF_HOME -> 0.48
            MarketChannel.RETAIL_MEDIA -> 0.25
            MarketChannel.GOOGLE_DISPLAY -> 0.55
            MarketChannel.PROGRAMMATIC_DISPLAY -> 0.50
            MarketChannel.PRINT -> 0.28
        }

        val estimatedReach = (universe * (1.0 - Math.exp(-reachConstant * (rawReachUncapped / universe) * 12.0))).coerceIn(0.05, universe * 0.90)
        val frequency = max(1.0, (impressions / 1_000_000.0) / estimatedReach)

        val ctrOrEngageRate = when (channel) {
            MarketChannel.GOOGLE_SEARCH -> 0.045
            MarketChannel.SOCIAL -> 0.012
            MarketChannel.YOUTUBE -> 0.008
            MarketChannel.GOOGLE_DISPLAY -> 0.0018
            MarketChannel.PROGRAMMATIC_DISPLAY -> 0.0012
            MarketChannel.RETAIL_MEDIA -> 0.022
            else -> 0.0005 // Direct/halo search response
        }

        val clicks = (impressions * ctrOrEngageRate).toLong()

        val convRate = when (channel) {
            MarketChannel.GOOGLE_SEARCH -> 0.038
            MarketChannel.RETAIL_MEDIA -> 0.042
            MarketChannel.SOCIAL -> 0.018
            MarketChannel.YOUTUBE -> 0.006
            else -> 0.002
        }
        val conversions = max(1L, (clicks.toDouble() * convRate).toLong())

        val recallMultiplier = when (channel) {
            MarketChannel.CINEMA -> 0.65
            MarketChannel.TELEVISION -> 0.42
            MarketChannel.STREAMING_TV -> 0.48
            MarketChannel.PODCAST -> 0.38
            MarketChannel.RADIO -> 0.22
            MarketChannel.YOUTUBE -> 0.26
            MarketChannel.OUT_OF_HOME -> 0.18
            MarketChannel.DIGITAL_OUT_OF_HOME -> 0.20
            MarketChannel.SOCIAL -> 0.09
            MarketChannel.GOOGLE_SEARCH -> 0.15
            else -> 0.04
        }
        val recallUnits = ((estimatedReach * 1_000_000.0) * recallMultiplier).toLong()

        return ChannelMetricRow(
            channel = channel,
            spendGbp = spendGbp,
            rawCpmGbp = cpm,
            impressions = impressions,
            estimatedReachMillions = estimatedReach,
            averageFrequency = frequency,
            totalAttentionSecondsMillions = attentionRes.totalActiveAttentionSeconds / 1_000_000.0,
            estimatedClicksOrVisits = clicks,
            estimatedConversions = conversions,
            brandRecallUnits = recallUnits,
            attentionCpmGbp = attentionRes.attentionCpmGbp
        )
    }

    fun compareChannels(
        baseChannel: MarketChannel,
        targetChannel: MarketChannel,
        spendGbp: Double
    ): ComparisonResult {
        val base = calculateChannelRow(baseChannel, spendGbp)
        val target = calculateChannelRow(targetChannel, spendGbp)

        val impRatio = if (target.impressions > 0) base.impressions.toDouble() / target.impressions.toDouble() else 1.0
        val reachRatio = if (target.estimatedReachMillions > 0) base.estimatedReachMillions / target.estimatedReachMillions else 1.0
        val attRatio = if (target.totalAttentionSecondsMillions > 0) base.totalAttentionSecondsMillions / target.totalAttentionSecondsMillions else 1.0
        val cpmDiffPct = ((target.rawCpmGbp - base.rawCpmGbp) / base.rawCpmGbp) * 100.0

        // Deduplication formula: Reach_A + Reach_B - (Reach_A * Reach_B / Universe)
        val universe = 54.2
        val combinedReach = base.estimatedReachMillions + target.estimatedReachMillions - (base.estimatedReachMillions * target.estimatedReachMillions / universe)

        val verdict = if (base.attentionCpmGbp < target.attentionCpmGbp) {
            "${base.channel.tag} provides +${String.format("%.1f", (target.attentionCpmGbp / base.attentionCpmGbp - 1.0) * 100)}% more cost-effective active attention per £, while ${target.channel.tag} delivers higher direct clickable intent."
        } else {
            "${target.channel.tag} yields lower cost-per-attention-minute with higher volume impressions, while ${base.channel.tag} delivers deeper brand salience and higher memory encoding."
        }

        return ComparisonResult(
            baseChannel = base,
            targetChannel = target,
            spendGbp = spendGbp,
            impressionRatio = impRatio,
            reachRatio = reachRatio,
            attentionSecondsRatio = attRatio,
            cpmDifferencePct = cpmDiffPct,
            crossPlatformDeduplicatedReachMillions = combinedReach,
            qualitativeVerdict = verdict
        )
    }
}
