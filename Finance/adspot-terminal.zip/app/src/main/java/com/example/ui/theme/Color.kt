package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Terminal Core Palette
val TerminalBackground = Color(0xFF090D12)
val TerminalSurface = Color(0xFF101620)
val TerminalSurfaceVariant = Color(0xFF17202C)
val TerminalCard = Color(0xFF1E293B)
val TerminalCardBorder = Color(0xFF2A3A4D)

// Terminal Accents
val TerminalGold = Color(0xFFE5A93C)
val TerminalGoldDim = Color(0xFF8C6219)
val TerminalCyan = Color(0xFF38BDF8)
val TerminalCyanDim = Color(0xFF0C4A6E)
val TerminalBlue = Color(0xFF60A5FA)
val TerminalGreen = Color(0xFF22C55E)
val TerminalGreenDim = Color(0xFF14532D)
val TerminalRed = Color(0xFFEF4444)
val TerminalRedDim = Color(0xFF450A0A)
val TerminalPurple = Color(0xFFA855F7)
val TerminalSteel = Color(0xFF94A3B8)
val TerminalMuted = Color(0xFF64748B)
val TerminalWhite = Color(0xFFF1F5F9)

// Quality / Badge Colors
val BadgeObservedBg = Color(0xFF1E3A8A)
val BadgeObservedText = Color(0xFF93C5FD)
val BadgeLicensedBg = Color(0xFF064E3B)
val BadgeLicensedText = Color(0xFF6EE7B7)
val BadgeModelledBg = Color(0xFF3B0764)
val BadgeModelledText = Color(0xFFD8B4FE)
val BadgeEstimatedBg = Color(0xFF78350F)
val BadgeEstimatedText = Color(0xFFFDE68A)
val BadgeSyntheticBg = Color(0xFF312E81)
val BadgeSyntheticText = Color(0xFFC7D2FE)
