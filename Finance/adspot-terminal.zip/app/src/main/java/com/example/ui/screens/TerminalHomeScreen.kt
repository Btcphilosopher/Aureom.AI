package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.AdspotIndicesEngine
import com.example.model.Currency
import com.example.model.MarketChannel
import com.example.model.MarketTickerItem
import com.example.model.ObservationType
import com.example.ui.components.AuditBadgeView
import com.example.ui.components.TerminalCard
import com.example.ui.components.TerminalMiniChart
import com.example.ui.theme.*

@Composable
fun TerminalHomeScreen(
    selectedCurrency: Currency,
    activeShockDeltaPct: Double,
    onNavigateToTab: (Int) -> Unit,
    onRunCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val indices = AdspotIndicesEngine.getMainIndices(selectedCurrency, activeShockDeltaPct)
    val globalRegions = AdspotIndicesEngine.getGlobalRegions()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Quick Command Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val quickPrompts = listOf(
                    "COMPARE TV30 GOOGLE" to 3,
                    "TV 30SEC QUOTE" to 1,
                    "SEARCH AUCTION TWIN" to 2,
                    "ORDER BOOK & ARBITRAGE" to 4,
                    "SCENARIO SHOCK TEST" to 5
                )
                items(quickPrompts) { (label, tabIndex) ->
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = TerminalSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, TerminalCyan.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .clickable { onNavigateToTab(tabIndex) }
                            .testTag("quick_command_${label.replace(" ", "_").lowercase()}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "> $label",
                                fontSize = 10.5.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TerminalCyan
                            )
                        }
                    }
                }
            }
        }

        // Macro Health & Recession Indicator Banner
        item {
            TerminalCard(
                title = "MACRO ADVERTISING ECONOMIC REGIME",
                badgeType = ObservationType.MODELLED
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AD RECESSION INDEX: EXPANSION (Score: 24/100)",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGreen
                        )
                        Text(
                            text = "Annual Ad Inflation (AD CPI): +6.4% YoY | Corporate Ad Elasticity β = 1.34",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalSteel
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(TerminalGreenDim)
                            .border(0.5.dp, TerminalGreen, RoundedCornerShape(3.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "MARKET CLEARING",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TerminalGreen
                        )
                    }
                }
            }
        }

        // Benchmark Indices Grid
        item {
            Text(
                text = "STANDARDIZED BENCHMARK INDICES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold,
                letterSpacing = 0.5.sp
            )
        }

        items(indices.chunked(2)) { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                pair.forEach { item ->
                    Box(modifier = Modifier.weight(1f)) {
                        IndexCard(item = item, onClick = {
                            if (item.ticker.contains("TV")) onNavigateToTab(1)
                            else if (item.ticker.contains("SEARCH") || item.ticker.contains("DISPLAY") || item.ticker.contains("VIDEO")) onNavigateToTab(2)
                            else if (item.ticker.contains("ATTENTION")) onNavigateToTab(3)
                            else onNavigateToTab(5)
                        })
                    }
                }
                if (pair.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }

        // Media Market Inventory Snapshot
        item {
            TerminalCard(
                title = "MARKET CHANNEL PRICING MATRIX",
                badgeType = ObservationType.LICENSED,
                trailingAction = {
                    Text(
                        text = "EXPLORE >",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalCyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onNavigateToTab(3) }
                    )
                }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val channels = listOf(
                        Triple(MarketChannel.TELEVISION, "£24.50 CPM", "14.5s attention (92% viewability)"),
                        Triple(MarketChannel.STREAMING_TV, "£28.00 CPM", "16.8s attention (95% viewability)"),
                        Triple(MarketChannel.GOOGLE_SEARCH, "£2.41 CPC", "High intent / 4.2s focused search"),
                        Triple(MarketChannel.YOUTUBE, "£0.041 CPV", "8.5s eyes-on (85% viewability)"),
                        Triple(MarketChannel.PODCAST, "£19.50 CPM", "22.0s deep listening (88% comp)"),
                        Triple(MarketChannel.DIGITAL_OUT_OF_HOME, "£9.20 CPM", "4.5s high-salience outdoor eyes"),
                        Triple(MarketChannel.RETAIL_MEDIA, "£16.00 CPM", "5.0s point-of-sale commerce intent"),
                        Triple(MarketChannel.PROGRAMMATIC_DISPLAY, "£2.80 CPM", "1.1s active attention (52% view)")
                    )
                    channels.forEach { (chan, price, note) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(TerminalCard)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = chan.displayName,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = TerminalWhite
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "[${chan.tag}]",
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = TerminalCyan
                                    )
                                }
                                Text(
                                    text = note,
                                    fontSize = 9.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalMuted
                                )
                            }
                            Text(
                                text = price,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGold
                            )
                        }
                    }
                }
            }
        }

        // Global Matrix Matrix
        item {
            TerminalCard(
                title = "GLOBAL ADVERTISING PRICE REGIONS",
                badgeType = ObservationType.OBSERVED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    globalRegions.forEach { reg ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(TerminalCard)
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = reg.regionCode,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalCyan
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = reg.countryName,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalWhite
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "TV: ${reg.currency.symbol}${String.format("%.1f", reg.tvCpm)}",
                                    fontSize = 10.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalSteel
                                )
                                Text(
                                    text = "CPC: ${reg.currency.symbol}${String.format("%.2f", reg.searchCpc)}",
                                    fontSize = 10.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalGold
                                )
                                Text(
                                    text = "CPI: +${reg.adInflationYoY}%",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalGreen
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun IndexCard(
    item: MarketTickerItem,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalCardBorder, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(8.dp)
            .testTag("index_card_${item.ticker.lowercase()}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = item.ticker,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalCyan
            )
            AuditBadgeView(type = item.observationType)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                text = item.valueFormatted,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalWhite
            )
            val changeColor = if (item.changePct >= 0) TerminalGreen else TerminalRed
            val sign = if (item.changePct >= 0) "+" else ""
            Text(
                text = "$sign${String.format("%.1f", item.changePct)}%",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = changeColor
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = item.name,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            color = TerminalMuted,
            maxLines = 1
        )
    }
}
