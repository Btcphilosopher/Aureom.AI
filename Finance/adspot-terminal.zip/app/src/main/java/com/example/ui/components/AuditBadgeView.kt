package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ObservationType
import com.example.ui.theme.*

@Composable
fun AuditBadgeView(
    type: ObservationType,
    confidence: Double? = null,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, borderColor) = when (type) {
        ObservationType.OBSERVED -> Triple(BadgeObservedBg.copy(alpha = 0.35f), BadgeObservedText, BadgeObservedText.copy(alpha = 0.6f))
        ObservationType.LICENSED -> Triple(BadgeLicensedBg.copy(alpha = 0.35f), BadgeLicensedText, BadgeLicensedText.copy(alpha = 0.6f))
        ObservationType.SURVEY -> Triple(BadgeEstimatedBg.copy(alpha = 0.35f), BadgeEstimatedText, BadgeEstimatedText.copy(alpha = 0.6f))
        ObservationType.ESTIMATED -> Triple(BadgeEstimatedBg.copy(alpha = 0.35f), BadgeEstimatedText, BadgeEstimatedText.copy(alpha = 0.6f))
        ObservationType.MODELLED -> Triple(BadgeModelledBg.copy(alpha = 0.35f), BadgeModelledText, BadgeModelledText.copy(alpha = 0.6f))
        ObservationType.SYNTHETIC -> Triple(BadgeSyntheticBg.copy(alpha = 0.35f), BadgeSyntheticText, BadgeSyntheticText.copy(alpha = 0.6f))
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .testTag("audit_badge_${type.name.lowercase()}")
            .clip(RoundedCornerShape(3.dp))
            .background(bgColor)
            .border(0.75.dp, borderColor, RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = "[${type.label}]",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = textColor,
            letterSpacing = 0.5.sp
        )
        if (confidence != null) {
            Text(
                text = " ${(confidence * 100).toInt()}%",
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace,
                color = textColor.copy(alpha = 0.8f)
            )
        }
    }
}
