package com.example.engine

object DisplayVideoEngine {

    enum class DisplayFormat(val label: String, val baseCpmGbp: Double, val avgViewabilityPct: Double, val avgCtrPct: Double) {
        STANDARD_BANNER("Standard Display Banner (300x250 / 728x90)", 3.40, 54.0, 0.12),
        EXPANDABLE_RICH_MEDIA("Rich Media / High-Impact Interstitial", 8.80, 78.0, 0.45),
        NATIVE_IN_FEED("Native In-Feed Sponsored Card", 5.20, 68.0, 0.32),
        CTV_IN_STREAM_DISPLAY("CTV Home Screen / Pause Banner", 14.50, 92.0, 0.20),
        MOBILE_STICKY_FOOTER("Mobile Sticky Anchor Unit", 4.10, 84.0, 0.28)
    }

    enum class VideoPricingModel(val label: String) {
        CPM("Cost Per 1,000 Served (CPM)"),
        VCPM("Cost Per 1,000 Viewable (vCPM)"),
        CPV("Cost Per Completed View (CPV)"),
        TCPM("Target CPM / Optimized (tCPM)")
    }

    enum class ProgrammaticAuctionType(val label: String, val feePct: Double, val description: String) {
        FIRST_PRICE_OPEN("Open Exchange First-Price", 18.0, "Highest validated bid clears at full bid value"),
        SECOND_PRICE_HYBRID("PMP Hybrid Second-Price", 12.0, "Winner pays 2nd highest bid + £0.01 above floor"),
        PRIVATE_MARKETPLACE("Private Marketplace (PMP Deal)", 10.0, "Exclusive publisher inventory with negotiated floor"),
        PROGRAMMATIC_GUARANTEED("Programmatic Guaranteed (PG)", 5.0, "Fixed price and guaranteed volume commitment"),
        PREFERRED_DEAL("Preferred Deal (1-to-1 Unreserved)", 8.0, "Priority access at fixed CPM before open auction")
    }

    data class DisplayQuote(
        val format: DisplayFormat,
        val totalBudgetGbp: Double,
        val rawCpmGbp: Double,
        val viewabilityPct: Double,
        val totalServedImpressions: Long,
        val viewableImpressions: Long,
        val nonViewableImpressions: Long,
        val effectiveVcpmGbp: Double,
        val estimatedClicks: Long,
        val effectiveCpcGbp: Double
    )

    fun calculateDisplayQuote(
        format: DisplayFormat,
        budgetGbp: Double,
        customCpmGbp: Double? = null,
        customViewabilityPct: Double? = null
    ): DisplayQuote {
        val cpm = customCpmGbp ?: format.baseCpmGbp
        val viewability = (customViewabilityPct ?: format.avgViewabilityPct).coerceIn(10.0, 100.0)

        val servedImpressions = ((budgetGbp / cpm) * 1000).toLong()
        val viewableImpressions = (servedImpressions * (viewability / 100.0)).toLong()
        val nonViewableImpressions = servedImpressions - viewableImpressions

        // vCPM = (Cost / Viewable Impressions) * 1000
        val vcpm = if (viewableImpressions > 0) (budgetGbp / viewableImpressions) * 1000.0 else cpm * 2.0
        val clicks = (servedImpressions * (format.avgCtrPct / 100.0)).toLong()
        val cpc = if (clicks > 0) budgetGbp / clicks else 0.0

        return DisplayQuote(
            format = format,
            totalBudgetGbp = budgetGbp,
            rawCpmGbp = cpm,
            viewabilityPct = viewability,
            totalServedImpressions = servedImpressions,
            viewableImpressions = viewableImpressions,
            nonViewableImpressions = nonViewableImpressions,
            effectiveVcpmGbp = vcpm,
            estimatedClicks = clicks,
            effectiveCpcGbp = cpc
        )
    }

    data class VideoQuote(
        val pricingModel: VideoPricingModel,
        val budgetGbp: Double,
        val rateGbp: Double, // CPM, vCPM or CPV
        val durationSec: Int,
        val completionRatePct: Double,
        val viewabilityPct: Double,
        val totalImpressions: Long,
        val completedViews: Long,
        val totalWatchTimeHours: Double,
        val effectiveCpm: Double,
        val effectiveCpv: Double,
        val attentionSecondsTotal: Double
    )

    fun calculateVideoQuote(
        pricingModel: VideoPricingModel,
        budgetGbp: Double,
        unitRate: Double = 0.045, // e.g. £0.045 CPV or £18.50 CPM
        durationSec: Int = 15,
        completionRatePct: Double = 72.0,
        viewabilityPct: Double = 85.0
    ): VideoQuote {
        val impressions: Long
        val completedViews: Long
        val effectiveCpm: Double
        val effectiveCpv: Double

        when (pricingModel) {
            VideoPricingModel.CPV -> {
                completedViews = (budgetGbp / unitRate).toLong()
                impressions = (completedViews / (completionRatePct / 100.0)).toLong()
                effectiveCpv = unitRate
                effectiveCpm = (budgetGbp / impressions) * 1000.0
            }
            VideoPricingModel.CPM, VideoPricingModel.TCPM -> {
                impressions = ((budgetGbp / unitRate) * 1000).toLong()
                completedViews = (impressions * (completionRatePct / 100.0)).toLong()
                effectiveCpm = unitRate
                effectiveCpv = if (completedViews > 0) budgetGbp / completedViews else 0.0
            }
            VideoPricingModel.VCPM -> {
                val viewableImps = ((budgetGbp / unitRate) * 1000).toLong()
                impressions = (viewableImps / (viewabilityPct / 100.0)).toLong()
                completedViews = (impressions * (completionRatePct / 100.0)).toLong()
                effectiveCpm = (budgetGbp / impressions) * 1000.0
                effectiveCpv = if (completedViews > 0) budgetGbp / completedViews else 0.0
            }
        }

        val avgSecondsPerImpression = (durationSec * (completionRatePct / 100.0) * 0.75)
        val totalWatchSec = impressions * avgSecondsPerImpression
        val totalWatchHours = totalWatchSec / 3600.0

        return VideoQuote(
            pricingModel = pricingModel,
            budgetGbp = budgetGbp,
            rateGbp = unitRate,
            durationSec = durationSec,
            completionRatePct = completionRatePct,
            viewabilityPct = viewabilityPct,
            totalImpressions = impressions,
            completedViews = completedViews,
            totalWatchTimeHours = totalWatchHours,
            effectiveCpm = effectiveCpm,
            effectiveCpv = effectiveCpv,
            attentionSecondsTotal = totalWatchSec
        )
    }
}
