package com.example.engine

import com.example.model.OrderBookLevel

object InventoryOrderBookEngine {

    data class AdMarketBook(
        val marketCategory: String,
        val midPriceCpm: Double,
        val spreadCpm: Double,
        val spreadPct: Double,
        val totalBidDepthMillions: Double,
        val totalAskDepthMillions: Double,
        val sellOrders: List<OrderBookLevel>,
        val buyOrders: List<OrderBookLevel>
    )

    fun getOrderBook(category: String = "PREMIUM_VIDEO_TV"): AdMarketBook {
        val rawSells = when (category) {
            "SEARCH_CLICKS" -> listOf(
                Pair(3.40, 4.2),
                Pair(3.10, 8.5),
                Pair(2.85, 14.0),
                Pair(2.65, 22.4),
                Pair(2.50, 35.0)
            )
            "DISPLAY_OPEN" -> listOf(
                Pair(4.80, 85.0),
                Pair(4.20, 140.0),
                Pair(3.80, 220.0),
                Pair(3.40, 380.0),
                Pair(3.05, 510.0)
            )
            else -> listOf(
                // PREMIUM_VIDEO_TV
                Pair(48.00, 2.1),
                Pair(45.00, 4.5),
                Pair(42.00, 8.2),
                Pair(39.50, 12.8),
                Pair(38.00, 18.5)
            )
        }

        val rawBuys = when (category) {
            "SEARCH_CLICKS" -> listOf(
                Pair(2.40, 28.0),
                Pair(2.25, 18.5),
                Pair(2.05, 12.0),
                Pair(1.80, 8.0),
                Pair(1.50, 4.5)
            )
            "DISPLAY_OPEN" -> listOf(
                Pair(2.95, 420.0),
                Pair(2.65, 290.0),
                Pair(2.35, 180.0),
                Pair(2.00, 120.0),
                Pair(1.60, 60.0)
            )
            else -> listOf(
                // PREMIUM_VIDEO_TV
                Pair(36.50, 16.2),
                Pair(34.00, 11.4),
                Pair(31.50, 7.8),
                Pair(28.00, 5.2),
                Pair(25.00, 3.1)
            )
        }

        var askCum = 0.0
        val totalAskVolume = rawSells.sumOf { it.second }
        val sellOrders = rawSells.map { (price, vol) ->
            askCum += vol
            OrderBookLevel(
                priceCpm = price,
                volumeMillions = vol,
                cumulativeMillions = askCum,
                sharePct = (vol / totalAskVolume) * 100.0,
                publisher = when {
                    price > 42.0 -> "Premium Linear / Upfront Pool"
                    price > 35.0 -> "Tier 1 Broadcaster VOD"
                    else -> "Syndicated Video Exchange"
                }
            )
        }

        var bidCum = 0.0
        val totalBidVolume = rawBuys.sumOf { it.second }
        val buyOrders = rawBuys.map { (price, vol) ->
            bidCum += vol
            OrderBookLevel(
                priceCpm = price,
                volumeMillions = vol,
                cumulativeMillions = bidCum,
                sharePct = (vol / totalBidVolume) * 100.0,
                publisher = when {
                    price > 34.0 -> "Global Holding Agency Desk"
                    price > 29.0 -> "Direct Institutional Brand"
                    else -> "Programmatic DSP Algorithmic Bid"
                }
            )
        }

        val bestAsk = sellOrders.lastOrNull()?.priceCpm ?: 38.0
        val bestBid = buyOrders.firstOrNull()?.priceCpm ?: 36.5
        val mid = (bestAsk + bestBid) / 2.0
        val spread = bestAsk - bestBid
        val spreadPct = (spread / mid) * 100.0

        return AdMarketBook(
            marketCategory = category,
            midPriceCpm = mid,
            spreadCpm = spread,
            spreadPct = spreadPct,
            totalBidDepthMillions = totalBidVolume,
            totalAskDepthMillions = totalAskVolume,
            sellOrders = sellOrders,
            buyOrders = buyOrders
        )
    }
}
