package com.example.engine

import com.example.model.MarketChannel
import kotlin.math.max

object AttentionEconomicsEngine {

    data class ChannelAttentionProfile(
        val channel: MarketChannel,
        val defaultDurationSec: Double,
        val viewabilityPct: Double,
        val activeAttentionPct: Double,
        val averageEyesOnScreenSec: Double,
        val attentionRetentionPct: Double
    )

    data class AttentionAnalysisResult(
        val channel: MarketChannel,
        val budgetGbp: Double,
        val rawCpmGbp: Double,
        val totalImpressions: Long,
        val totalActiveAttentionSeconds: Double,
        val totalAttentionMinutes: Double,
        val attentionCpmGbp: Double, // Cost per 1,000 active attention seconds
        val costPerAttentionMinuteGbp: Double,
        val qualityDiscountFactor: Double,
        val effectiveAttentionIndex: Double
    )

    fun getProfileForChannel(channel: MarketChannel): ChannelAttentionProfile {
        return when (channel) {
            MarketChannel.TELEVISION -> ChannelAttentionProfile(channel, 30.0, 92.0, 58.0, 14.5, 78.0)
            MarketChannel.STREAMING_TV -> ChannelAttentionProfile(channel, 20.0, 95.0, 68.0, 16.8, 86.0)
            MarketChannel.CINEMA -> ChannelAttentionProfile(channel, 60.0, 98.0, 85.0, 32.0, 95.0)
            MarketChannel.YOUTUBE -> ChannelAttentionProfile(channel, 15.0, 85.0, 48.0, 8.5, 62.0)
            MarketChannel.PODCAST -> ChannelAttentionProfile(channel, 45.0, 90.0, 72.0, 26.0, 82.0)
            MarketChannel.RADIO -> ChannelAttentionProfile(channel, 30.0, 82.0, 45.0, 10.2, 58.0)
            MarketChannel.GOOGLE_SEARCH -> ChannelAttentionProfile(channel, 5.0, 98.0, 82.0, 4.2, 90.0)
            MarketChannel.SOCIAL -> ChannelAttentionProfile(channel, 10.0, 65.0, 28.0, 2.1, 35.0)
            MarketChannel.DIGITAL_OUT_OF_HOME -> ChannelAttentionProfile(channel, 10.0, 78.0, 36.0, 3.8, 45.0)
            MarketChannel.OUT_OF_HOME -> ChannelAttentionProfile(channel, 8.0, 70.0, 30.0, 2.8, 40.0)
            MarketChannel.RETAIL_MEDIA -> ChannelAttentionProfile(channel, 8.0, 75.0, 44.0, 4.2, 55.0)
            MarketChannel.GOOGLE_DISPLAY -> ChannelAttentionProfile(channel, 5.0, 58.0, 18.0, 1.4, 22.0)
            MarketChannel.PROGRAMMATIC_DISPLAY -> ChannelAttentionProfile(channel, 5.0, 52.0, 14.0, 1.1, 18.0)
            MarketChannel.PRINT -> ChannelAttentionProfile(channel, 15.0, 60.0, 40.0, 6.5, 52.0)
        }
    }

    fun evaluateAttention(
        channel: MarketChannel,
        budgetGbp: Double,
        customCpm: Double? = null
    ): AttentionAnalysisResult {
        val profile = getProfileForChannel(channel)
        val cpm = customCpm ?: when (channel) {
            MarketChannel.TELEVISION -> 24.50
            MarketChannel.STREAMING_TV -> 28.00
            MarketChannel.CINEMA -> 42.00
            MarketChannel.YOUTUBE -> 14.20
            MarketChannel.PODCAST -> 19.50
            MarketChannel.RADIO -> 6.80
            MarketChannel.GOOGLE_SEARCH -> 55.00 // effective CPM equivalent
            MarketChannel.SOCIAL -> 8.50
            MarketChannel.DIGITAL_OUT_OF_HOME -> 9.20
            MarketChannel.OUT_OF_HOME -> 5.80
            MarketChannel.RETAIL_MEDIA -> 16.00
            MarketChannel.GOOGLE_DISPLAY -> 3.60
            MarketChannel.PROGRAMMATIC_DISPLAY -> 2.80
            MarketChannel.PRINT -> 18.00
        }

        val impressions = max(100.0, (budgetGbp / cpm) * 1000.0).toLong()
        val activeSecPerImp = profile.averageEyesOnScreenSec * (profile.viewabilityPct / 100.0) * (profile.activeAttentionPct / 100.0)
        val totalActiveSec = impressions * activeSecPerImp
        val totalMinutes = totalActiveSec / 60.0

        // Attention CPM = (Budget / Total Active Attention Seconds) * 1000
        val attentionCpm = if (totalActiveSec > 0) (budgetGbp / totalActiveSec) * 1000.0 else 0.0
        val costPerMin = if (totalMinutes > 0) budgetGbp / totalMinutes else 0.0

        // Quality multiplier relative to benchmark TV 30s
        val qualityFactor = (activeSecPerImp / 7.7).coerceIn(0.1, 5.0)
        val attentionIndex = (100.0 * (1.0 / (attentionCpm / 20.0))).coerceIn(10.0, 300.0)

        return AttentionAnalysisResult(
            channel = channel,
            budgetGbp = budgetGbp,
            rawCpmGbp = cpm,
            totalImpressions = impressions,
            totalActiveAttentionSeconds = totalActiveSec,
            totalAttentionMinutes = totalMinutes,
            attentionCpmGbp = attentionCpm,
            costPerAttentionMinuteGbp = costPerMin,
            qualityDiscountFactor = qualityFactor,
            effectiveAttentionIndex = attentionIndex
        )
    }
}
