package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MarketRepository
import com.example.engine.DisplayVideoEngine
import com.example.engine.SearchAuctionEngine
import com.example.model.Currency
import com.example.model.ObservationType
import com.example.ui.components.AuditBadgeView
import com.example.ui.components.FormulaExplanationBox
import com.example.ui.components.TerminalCard
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun DigitalAuctionScreen(
    selectedCurrency: Currency,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableStateOf(0) } // 0: Search, 1: Display & vCPM, 2: Video & CPV, 3: Programmatic

    val currSymbol = selectedCurrency.symbol
    val fx = selectedCurrency.rateAgainstGbp

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
    ) {
        // Sub-tabs row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurface)
                .border(0.5.dp, TerminalCardBorder)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tabs = listOf("SEARCH AUCTION", "DISPLAY & vCPM", "VIDEO & CPV", "PROGRAMMATIC")
            tabs.forEachIndexed { index, title ->
                val isSel = index == selectedSubTab
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = if (isSel) TerminalCyan else TerminalCard,
                    modifier = Modifier
                        .clickable { selectedSubTab = index }
                        .testTag("digital_tab_$index")
                ) {
                    Text(
                        text = title,
                        fontSize = 10.5.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (isSel) TerminalBackground else TerminalSteel,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
            }
        }

        when (selectedSubTab) {
            0 -> SearchAuctionView(selectedCurrency = selectedCurrency)
            1 -> DisplayVcpmView(selectedCurrency = selectedCurrency)
            2 -> VideoCpvView(selectedCurrency = selectedCurrency)
            3 -> ProgrammaticView(selectedCurrency = selectedCurrency)
        }
    }
}

@Composable
private fun SearchAuctionView(selectedCurrency: Currency) {
    val keywords = MarketRepository.sampleKeywords
    var selectedKw by remember { mutableStateOf(keywords.first()) }
    var userBidGbp by remember { mutableStateOf(14.50) }
    var userQualityScore by remember { mutableStateOf(8.0) }
    var competitionDensity by remember { mutableStateOf(6) }

    val currSymbol = selectedCurrency.symbol
    val fx = selectedCurrency.rateAgainstGbp

    val auctionResult = remember(selectedKw, userBidGbp, userQualityScore, competitionDensity) {
        SearchAuctionEngine.simulateSearchAuction(
            keyword = selectedKw.keyword,
            userBidGbp = userBidGbp,
            userQualityScore = userQualityScore,
            competitionDensity = competitionDensity
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "SEARCH AUCTION TWIN (ANALYTICAL MODEL)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold
            )
            Text(
                text = "Independent analytical generalized second-price (GSP) auction model. Not Google's production auction.",
                fontSize = 9.5.sp,
                fontFamily = FontFamily.Monospace,
                color = TerminalSteel
            )
        }

        // Keyword Selection
        item {
            TerminalCard(
                title = "1. TARGET KEYWORD & QUERY CONTEXT",
                badgeType = ObservationType.OBSERVED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    keywords.forEach { kw ->
                        val isSel = kw.keyword == selectedKw.keyword
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (isSel) TerminalCyanDim.copy(alpha = 0.4f) else TerminalCard)
                                .border(
                                    0.5.dp,
                                    if (isSel) TerminalCyan else TerminalCardBorder,
                                    RoundedCornerShape(3.dp)
                                )
                                .clickable {
                                    selectedKw = kw
                                    userBidGbp = kw.estTopPageCpcGbp
                                }
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = kw.keyword,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isSel) TerminalCyan else TerminalWhite
                                )
                                Text(
                                    text = "${kw.vertical} | Vol: ${kw.monthlyVolume} queries/mo",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalMuted
                                )
                            }
                            Text(
                                text = "Est: $currSymbol${String.format("%.2f", kw.estTopPageCpcGbp * fx)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGold
                            )
                        }
                    }
                }
            }
        }

        // Auction Bid & QS Controls
        item {
            TerminalCard(
                title = "2. ADVERTISER BID & QUALITY CONTROLS",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "MAX CPC BID: $currSymbol${String.format("%.2f", userBidGbp * fx)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalCyan
                        )
                        Text(
                            text = "AD QUALITY SCORE: ${userQualityScore.toInt()}/10",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGold
                        )
                    }

                    Slider(
                        value = userBidGbp.toFloat(),
                        onValueChange = { userBidGbp = it.toDouble() },
                        valueRange = 0.50f..40.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = TerminalCyan,
                            activeTrackColor = TerminalCyan,
                            inactiveTrackColor = TerminalCardBorder
                        ),
                        modifier = Modifier.testTag("max_cpc_slider")
                    )

                    Slider(
                        value = userQualityScore.toFloat(),
                        onValueChange = { userQualityScore = it.toDouble().roundToInt().toDouble() },
                        valueRange = 1f..10f,
                        steps = 8,
                        colors = SliderDefaults.colors(
                            thumbColor = TerminalGold,
                            activeTrackColor = TerminalGold,
                            inactiveTrackColor = TerminalCardBorder
                        ),
                        modifier = Modifier.testTag("quality_score_slider")
                    )
                }
            }
        }

        // Auction Outcome Output
        item {
            TerminalCard(
                title = "3. AUCTION CLEARING & POSITION OUTCOME",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "WON POSITION",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )
                            Text(
                                text = "#${auctionResult.position} in Auction",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = if (auctionResult.position <= 2) TerminalGreen else if (auctionResult.position <= 4) TerminalGold else TerminalRed
                            )
                            Text(
                                text = "AdRank: ${String.format("%.2f", auctionResult.adRank)}",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalMuted
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "ACTUAL CLEARING CPC",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )
                            Text(
                                text = "$currSymbol${String.format("%.2f", auctionResult.actualCpcGbp * fx)}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalCyan
                            )
                            Text(
                                text = "Discount vs Max: -${String.format("%.1f", (1.0 - auctionResult.actualCpcGbp / userBidGbp) * 100)}%",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGreen
                            )
                        }
                    }

                    Divider(color = TerminalCardBorder, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "EST. CTR", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "${String.format("%.2f", auctionResult.estimatedCtrPct)}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                        }
                        Column {
                            Text(text = "DAILY CLICKS", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "${auctionResult.estimatedDailyClicks}", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                        }
                        Column {
                            Text(text = "DAILY SPEND", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "$currSymbol${String.format("%.2f", auctionResult.estimatedDailyCostGbp * fx)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "EST. CPA", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "$currSymbol${String.format("%.2f", auctionResult.costPerAcquisitionCpaGbp * fx)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGreen)
                        }
                    }
                }
            }
        }

        // Competitor Auction Ladder
        item {
            TerminalCard(
                title = "4. AUCTION PARTICIPANTS RANKING LADDER",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    auctionResult.rankingLadder.forEach { row ->
                        val isUser = row.advertiser.contains("ADSPOT User")
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (isUser) TerminalCyanDim.copy(alpha = 0.35f) else TerminalCard)
                                .border(
                                    0.5.dp,
                                    if (isUser) TerminalCyan else TerminalCardBorder,
                                    RoundedCornerShape(3.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "#${row.rank}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (row.rank == 1) TerminalGold else TerminalSteel
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = row.advertiser,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (isUser) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isUser) TerminalCyan else TerminalWhite
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "AdRank: ${String.format("%.1f", row.adRank)}",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalSteel
                                )
                                Text(
                                    text = "Clr: $currSymbol${String.format("%.2f", row.clearingCpc * fx)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalGold
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            FormulaExplanationBox(
                formulaName = "ANALYTICAL SEARCH GSP AUCTION",
                formulaText = "Actual CPC = (Next Highest AdRank / Your Quality Score) + 0.01",
                denominatorDefinition = "AdRank = Max Bid × Ad Quality Score (Expected CTR × Landing Page × Ad Relevance)",
                modelType = ObservationType.MODELLED
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun DisplayVcpmView(selectedCurrency: Currency) {
    var selectedFormat by remember { mutableStateOf(DisplayVideoEngine.DisplayFormat.STANDARD_BANNER) }
    var budgetGbp by remember { mutableStateOf(10000.0) }

    val currSymbol = selectedCurrency.symbol
    val fx = selectedCurrency.rateAgainstGbp

    val quote = remember(selectedFormat, budgetGbp) {
        DisplayVideoEngine.calculateDisplayQuote(format = selectedFormat, budgetGbp = budgetGbp)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "GOOGLE DISPLAY & vCPM ENGINE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold
            )
            Text(
                text = "Compare served CPM vs viewable vCPM (MRC standard: ≥50% pixels in view for ≥1 second).",
                fontSize = 9.5.sp,
                fontFamily = FontFamily.Monospace,
                color = TerminalSteel
            )
        }

        // Format Selector
        item {
            TerminalCard(
                title = "SELECT DISPLAY AD FORMAT",
                badgeType = ObservationType.LICENSED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    DisplayVideoEngine.DisplayFormat.values().forEach { fmt ->
                        val isSel = fmt == selectedFormat
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (isSel) TerminalCyanDim.copy(alpha = 0.35f) else TerminalCard)
                                .border(0.5.dp, if (isSel) TerminalCyan else TerminalCardBorder, RoundedCornerShape(3.dp))
                                .clickable { selectedFormat = fmt }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = fmt.label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isSel) TerminalCyan else TerminalWhite
                                )
                                Text(
                                    text = "Avg Viewability: ${fmt.avgViewabilityPct}% | Avg CTR: ${fmt.avgCtrPct}%",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalMuted
                                )
                            }
                            Text(
                                text = "$currSymbol${String.format("%.2f", fmt.baseCpmGbp * fx)} CPM",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGold
                            )
                        }
                    }
                }
            }
        }

        // vCPM Calculation Card
        item {
            TerminalCard(
                title = "CPM VS vCPM ECONOMIC COMPARISON",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "RAW SERVED CPM", fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "$currSymbol${String.format("%.2f", quote.rawCpmGbp * fx)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                            Text(text = "${String.format("%,d", quote.totalServedImpressions)} served", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalMuted)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "VIEWABLE vCPM", fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "$currSymbol${String.format("%.2f", quote.effectiveVcpmGbp * fx)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGold)
                            Text(text = "${String.format("%,d", quote.viewableImpressions)} in-view", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalGreen)
                        }
                    }

                    Divider(color = TerminalCardBorder, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Non-Viewable Waste: ${String.format("%,d", quote.nonViewableImpressions)} imps (${(100 - quote.viewabilityPct).toInt()}%)",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalRed
                        )
                        Text(
                            text = "Effective CPC: $currSymbol${String.format("%.2f", quote.effectiveCpcGbp * fx)}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalCyan
                        )
                    }
                }
            }
        }

        item {
            FormulaExplanationBox(
                formulaName = "VIEWABLE CPM (vCPM)",
                formulaText = "vCPM = (Total Spend / Viewable Impressions) × 1,000",
                denominatorDefinition = "Viewable Impressions = Total Served × Verified MRC Viewability Fraction",
                modelType = ObservationType.MODELLED
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun VideoCpvView(selectedCurrency: Currency) {
    var pricingModel by remember { mutableStateOf(DisplayVideoEngine.VideoPricingModel.CPV) }
    var completionRatePct by remember { mutableStateOf(72.0) }
    val currSymbol = selectedCurrency.symbol
    val fx = selectedCurrency.rateAgainstGbp

    val quote = remember(pricingModel, completionRatePct) {
        DisplayVideoEngine.calculateVideoQuote(
            pricingModel = pricingModel,
            budgetGbp = 25000.0,
            completionRatePct = completionRatePct
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "YOUTUBE & STREAMING VIDEO AD MARKET",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold
            )
        }

        item {
            TerminalCard(
                title = "VIDEO PRICING METRICS & WATCH TIME",
                badgeType = ObservationType.OBSERVED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "EFFECTIVE CPV", fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "$currSymbol${String.format("%.3f", quote.effectiveCpv * fx)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalCyan)
                            Text(text = "${String.format("%,d", quote.completedViews)} completed views", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalMuted)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "EFFECTIVE CPM", fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "$currSymbol${String.format("%.2f", quote.effectiveCpm * fx)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGold)
                            Text(text = "${String.format("%,d", quote.totalImpressions)} impressions", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalMuted)
                        }
                    }

                    Divider(color = TerminalCardBorder, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Total Watch Time: ${String.format("%,d", quote.totalWatchTimeHours.toInt())} hours",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGreen
                        )
                        Text(
                            text = "Completion Rate: ${completionRatePct.toInt()}%",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalWhite
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ProgrammaticView(selectedCurrency: Currency) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "PROGRAMMATIC AUCTION MECHANISMS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold
            )
        }

        items(DisplayVideoEngine.ProgrammaticAuctionType.values()) { auction ->
            TerminalCard(
                title = auction.label,
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = auction.description,
                        fontSize = 10.5.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalWhite
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "DSP/SSP Take-Rate Tech Fee: ${auction.feePct}%",
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalSteel
                        )
                        Text(
                            text = "[AUDITED]",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGreen
                        )
                    }
                }
            }
        }
    }
}
