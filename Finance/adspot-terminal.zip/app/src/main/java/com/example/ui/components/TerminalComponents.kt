package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Currency
import com.example.model.MarketTickerItem
import com.example.model.ObservationType
import com.example.ui.theme.*

@Composable
fun TerminalHeader(
    selectedCurrency: Currency,
    onSelectCurrency: (Currency) -> Unit,
    pppMode: Boolean,
    onTogglePpp: () -> Unit,
    activeShockTitle: String? = null,
    onResetShock: () -> Unit,
    onOpenCli: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showCurrencyMenu by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalBackground)
            .border(1.dp, TerminalCardBorder)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(TerminalGreen)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ADSPOT // TERMINAL",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalWhite,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "v4.2-QUANT",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalGold,
                    modifier = Modifier
                        .background(TerminalGoldDim.copy(alpha = 0.3f), RoundedCornerShape(2.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Currency dropdown button
                Box {
                    Button(
                        onClick = { showCurrencyMenu = true },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TerminalCard,
                            contentColor = TerminalCyan
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .height(28.dp)
                            .testTag("currency_selector_button")
                    ) {
                        Text(
                            text = "${selectedCurrency.code} (${selectedCurrency.symbol})",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    DropdownMenu(
                        expanded = showCurrencyMenu,
                        onDismissRequest = { showCurrencyMenu = false },
                        modifier = Modifier.background(TerminalCard)
                    ) {
                        Currency.values().forEach { curr ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "${curr.code} - ${curr.symbol} (fx: ${curr.rateAgainstGbp})",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        color = if (curr == selectedCurrency) TerminalCyan else TerminalWhite
                                    )
                                },
                                onClick = {
                                    onSelectCurrency(curr)
                                    showCurrencyMenu = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // CLI prompt trigger
                IconButton(
                    onClick = onOpenCli,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalCard)
                        .testTag("terminal_cli_icon_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Command Prompt",
                        tint = TerminalGold,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        if (activeShockTitle != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(3.dp))
                    .background(TerminalRedDim.copy(alpha = 0.5f))
                    .border(0.5.dp, TerminalRed, RoundedCornerShape(3.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⚠ SHOCK ACTIVE: $activeShockTitle",
                    fontSize = 9.5.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalWhite,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "[RESET]",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalGold,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onResetShock() }
                        .padding(horizontal = 4.dp)
                )
            }
        }
    }
}

@Composable
fun TickerBar(
    items: List<MarketTickerItem>,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(0.5.dp, TerminalCardBorder)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.testTag("ticker_item_${item.ticker.lowercase()}")
            ) {
                Text(
                    text = item.ticker,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalSteel
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = item.valueFormatted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalWhite
                )
                Spacer(modifier = Modifier.width(4.dp))
                val changeColor = if (item.changePct >= 0) TerminalGreen else TerminalRed
                val sign = if (item.changePct >= 0) "+" else ""
                Text(
                    text = "$sign${String.format("%.1f", item.changePct)}%",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = changeColor
                )
                Spacer(modifier = Modifier.width(4.dp))
                AuditBadgeView(type = item.observationType)
            }
        }
    }
}

@Composable
fun TerminalCard(
    title: String,
    badgeType: ObservationType? = null,
    modifier: Modifier = Modifier,
    trailingAction: @Composable (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalCardBorder, RoundedCornerShape(6.dp))
    ) {
        // Card Title Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceVariant)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title.uppercase(),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalGold,
                    letterSpacing = 0.5.sp
                )
                if (badgeType != null) {
                    Spacer(modifier = Modifier.width(6.dp))
                    AuditBadgeView(type = badgeType)
                }
            }
            if (trailingAction != null) {
                trailingAction()
            }
        }
        // Body Content
        Column(
            modifier = Modifier.padding(10.dp),
            content = content
        )
    }
}

@Composable
fun FormulaExplanationBox(
    formulaName: String,
    formulaText: String,
    denominatorDefinition: String,
    modelType: ObservationType,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalBackground)
            .border(0.5.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "FORMULA: $formulaName",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalCyan
            )
            AuditBadgeView(type = modelType)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = formulaText,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            color = TerminalWhite
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = "Denom: $denominatorDefinition",
            fontSize = 9.5.sp,
            fontFamily = FontFamily.Monospace,
            color = TerminalMuted
        )
    }
}

@Composable
fun TerminalMiniChart(
    points: List<Float>,
    isPositive: Boolean = true,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (points.size < 2) return@Canvas
        val minVal = points.minOrNull() ?: 0f
        val maxVal = points.maxOrNull() ?: 1f
        val range = if (maxVal - minVal == 0f) 1f else maxVal - minVal

        val path = Path()
        val stepX = size.width / (points.size - 1)

        points.forEachIndexed { i, p ->
            val normY = size.height - ((p - minVal) / range) * size.height
            val x = i * stepX
            if (i == 0) path.moveTo(x, normY) else path.lineTo(x, normY)
        }

        drawPath(
            path = path,
            color = if (isPositive) TerminalGreen else TerminalRed,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}
