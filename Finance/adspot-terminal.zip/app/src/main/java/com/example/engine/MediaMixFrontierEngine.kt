package com.example.engine

import com.example.model.MarketChannel
import kotlin.math.sqrt

object MediaMixFrontierEngine {

    data class ChannelAllocation(
        val channel: MarketChannel,
        val budgetSharePct: Double,
        val allocatedGbp: Double
    )

    data class MediaMixPortfolio(
        val name: String,
        val totalBudgetGbp: Double,
        val allocations: List<ChannelAllocation>,
        val totalImpressionsMillions: Double,
        val netDeduplicatedReachMillions: Double,
        val blendedCpmGbp: Double,
        val totalAttentionHours: Double,
        val blendedRoasRatio: Double,
        val riskVolScore: Double, // 1-100
        val portfolioStrategyDescription: String
    )

    enum class StrategyPreset(val label: String, val description: String) {
        BALANCED("Balanced Optimal (Sharpe Media Max)", "Mix of high-reach broadcast and targeted bottom-funnel channels"),
        TV_HEAVY("Broadcaster Dominant (Brand Salience)", "Heavy allocation to Linear TV, CTV and Cinema for maximum cultural reach"),
        DIGITAL_PERFORMANCE("Digital Performance Max (Immediate ROI)", "Concentrated in Google Search, Retail Media, Meta and YouTube"),
        ATTENTION_OPTIMIZED("Attention-Seconds Frontier", "Maximizing verified active eyes-on-screen minutes per currency unit")
    }

    fun generatePortfolio(
        preset: StrategyPreset,
        totalBudgetGbp: Double
    ): MediaMixPortfolio {
        val shares: Map<MarketChannel, Double> = when (preset) {
            StrategyPreset.BALANCED -> mapOf(
                MarketChannel.TELEVISION to 30.0,
                MarketChannel.STREAMING_TV to 15.0,
                MarketChannel.GOOGLE_SEARCH to 20.0,
                MarketChannel.YOUTUBE to 12.0,
                MarketChannel.SOCIAL to 10.0,
                MarketChannel.DIGITAL_OUT_OF_HOME to 5.0,
                MarketChannel.RETAIL_MEDIA to 5.0,
                MarketChannel.PODCAST to 3.0
            )
            StrategyPreset.TV_HEAVY -> mapOf(
                MarketChannel.TELEVISION to 55.0,
                MarketChannel.STREAMING_TV to 20.0,
                MarketChannel.CINEMA to 10.0,
                MarketChannel.OUT_OF_HOME to 10.0,
                MarketChannel.RADIO to 5.0
            )
            StrategyPreset.DIGITAL_PERFORMANCE -> mapOf(
                MarketChannel.GOOGLE_SEARCH to 40.0,
                MarketChannel.RETAIL_MEDIA to 25.0,
                MarketChannel.SOCIAL to 20.0,
                MarketChannel.YOUTUBE to 10.0,
                MarketChannel.GOOGLE_DISPLAY to 5.0
            )
            StrategyPreset.ATTENTION_OPTIMIZED -> mapOf(
                MarketChannel.CINEMA to 25.0,
                MarketChannel.PODCAST to 25.0,
                MarketChannel.STREAMING_TV to 25.0,
                MarketChannel.TELEVISION to 15.0,
                MarketChannel.GOOGLE_SEARCH to 10.0
            )
        }

        val allocations = shares.map { (channel, pct) ->
            ChannelAllocation(
                channel = channel,
                budgetSharePct = pct,
                allocatedGbp = totalBudgetGbp * (pct / 100.0)
            )
        }

        var totalImps = 0.0
        var totalActiveAttentionSec = 0.0
        var reachAccumulator = 0.0
        val universe = 54.2

        allocations.forEach { alloc ->
            val row = CrossMediaTranslator.calculateChannelRow(alloc.channel, alloc.allocatedGbp)
            totalImps += row.impressions
            totalActiveAttentionSec += (row.totalAttentionSecondsMillions * 1_000_000.0)

            // Iterative deduplication: NetReach = PrevReach + NewReach - (PrevReach * NewReach / Universe)
            reachAccumulator = if (reachAccumulator == 0.0) {
                row.estimatedReachMillions
            } else {
                reachAccumulator + row.estimatedReachMillions - (reachAccumulator * row.estimatedReachMillions / universe)
            }
        }

        val totalImpsMillions = totalImps / 1_000_000.0
        val blendedCpm = if (totalImps > 0) (totalBudgetGbp / totalImps) * 1000.0 else 0.0
        val totalAttentionHours = totalActiveAttentionSec / 3600.0

        val blendedRoas = when (preset) {
            StrategyPreset.DIGITAL_PERFORMANCE -> 4.35
            StrategyPreset.BALANCED -> 3.82
            StrategyPreset.TV_HEAVY -> 3.15
            StrategyPreset.ATTENTION_OPTIMIZED -> 3.48
        }

        val volScore = when (preset) {
            StrategyPreset.DIGITAL_PERFORMANCE -> 28.5 // Low volatility, quick return
            StrategyPreset.BALANCED -> 42.0
            StrategyPreset.TV_HEAVY -> 58.0
            StrategyPreset.ATTENTION_OPTIMIZED -> 36.0
        }

        return MediaMixPortfolio(
            name = preset.label,
            totalBudgetGbp = totalBudgetGbp,
            allocations = allocations,
            totalImpressionsMillions = totalImpsMillions,
            netDeduplicatedReachMillions = reachAccumulator.coerceIn(0.1, universe * 0.94),
            blendedCpmGbp = blendedCpm,
            totalAttentionHours = totalAttentionHours,
            blendedRoasRatio = blendedRoas,
            riskVolScore = volScore,
            portfolioStrategyDescription = preset.description
        )
    }
}
