package com.example.data

import com.example.model.DemographicTarget
import com.example.model.TVProgrammeRate

object MarketRepository {

    val sampleProgrammes = listOf(
        TVProgrammeRate(
            id = "PRG-001",
            broadcaster = "ITV Commercial",
            channel = "ITV1 Main",
            programmeTitle = "Coronation Street (Prime Slot)",
            genre = "Drama / Soap",
            timeSlot = "20:00 - 20:30",
            isPeakTime = true,
            baseRateCardGbp = 48500.0,
            estimatedAudienceMillions = 4.25,
            grp = 7.84,
            scarcityFactor = 0.85,
            demandScore = 9.2,
            defaultTarget = DemographicTarget.ALL_ADULTS
        ),
        TVProgrammeRate(
            id = "PRG-002",
            broadcaster = "Sky Media",
            channel = "Sky Sports Premier League",
            programmeTitle = "Sunday Live Derby: Super Match",
            genre = "Live Sports / Tier 1",
            timeSlot = "16:30 - 18:30",
            isPeakTime = true,
            baseRateCardGbp = 85000.0,
            estimatedAudienceMillions = 3.10,
            grp = 5.72,
            scarcityFactor = 0.98,
            demandScore = 9.8,
            defaultTarget = DemographicTarget.ADULTS_18_34
        ),
        TVProgrammeRate(
            id = "PRG-003",
            broadcaster = "Channel 4",
            channel = "Channel 4 Main",
            programmeTitle = "The Great British Bake Off",
            genre = "Entertainment / Reality",
            timeSlot = "20:00 - 21:15",
            isPeakTime = true,
            baseRateCardGbp = 62000.0,
            estimatedAudienceMillions = 5.10,
            grp = 9.41,
            scarcityFactor = 0.90,
            demandScore = 9.5,
            defaultTarget = DemographicTarget.ABC1_SOCIO
        ),
        TVProgrammeRate(
            id = "PRG-004",
            broadcaster = "Channel 5 / Paramount",
            channel = "Channel 5",
            programmeTitle = "All Creatures Great & Small",
            genre = "Period Drama",
            timeSlot = "21:00 - 22:00",
            isPeakTime = true,
            baseRateCardGbp = 22000.0,
            estimatedAudienceMillions = 2.40,
            grp = 4.43,
            scarcityFactor = 0.55,
            demandScore = 6.8,
            defaultTarget = DemographicTarget.ADULTS_35_64
        ),
        TVProgrammeRate(
            id = "PRG-005",
            broadcaster = "ITV Commercial",
            channel = "ITV1 Daytime",
            programmeTitle = "This Morning",
            genre = "Daytime Magazine",
            timeSlot = "10:00 - 12:30",
            isPeakTime = false,
            baseRateCardGbp = 7200.0,
            estimatedAudienceMillions = 0.95,
            grp = 1.75,
            scarcityFactor = 0.30,
            demandScore = 5.2,
            defaultTarget = DemographicTarget.ALL_ADULTS
        ),
        TVProgrammeRate(
            id = "PRG-006",
            broadcaster = "Sky Media",
            channel = "Sky News",
            programmeTitle = "The News Hour at 8",
            genre = "Rolling News / Analysis",
            timeSlot = "20:00 - 21:00",
            isPeakTime = true,
            baseRateCardGbp = 9800.0,
            estimatedAudienceMillions = 0.65,
            grp = 1.20,
            scarcityFactor = 0.40,
            demandScore = 6.0,
            defaultTarget = DemographicTarget.HIGH_NET_WORTH
        )
    )

    data class SearchKeywordItem(
        val keyword: String,
        val vertical: String,
        val monthlyVolume: String,
        val estTopPageCpcGbp: Double,
        val estFirstPosCpcGbp: Double,
        val compIndex: Double,
        val commercialIntent: String
    )

    val sampleKeywords = listOf(
        SearchKeywordItem("car insurance quotes online", "Financial Services", "320,000", 12.80, 24.50, 0.96, "Transactional (High Value)"),
        SearchKeywordItem("cloud computing enterprise erp", "B2B Technology", "45,000", 18.50, 38.00, 0.92, "B2B Institutional"),
        SearchKeywordItem("luxury holiday maldives all inclusive", "Travel & Luxury", "110,000", 4.20, 8.90, 0.84, "Commercial Intent"),
        SearchKeywordItem("best electric suv 2026", "Automotive", "180,000", 3.80, 7.20, 0.78, "Research / Commercial"),
        SearchKeywordItem("mortgage rate calculator uk", "Financial Services", "450,000", 8.40, 16.50, 0.94, "Transactional"),
        SearchKeywordItem("designer leather sneakers men", "Retail & Apparel", "95,000", 1.80, 3.40, 0.65, "Product E-Commerce")
    )
}
