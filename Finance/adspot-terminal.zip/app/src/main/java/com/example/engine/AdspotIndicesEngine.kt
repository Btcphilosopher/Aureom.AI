package com.example.engine

import com.example.model.AuditBadge
import com.example.model.Currency
import com.example.model.MarketTickerItem
import com.example.model.ObservationType

object AdspotIndicesEngine {

    data class GlobalRegionData(
        val regionCode: String,
        val countryName: String,
        val tvCpm: Double,
        val searchCpc: Double,
        val displayCpm: Double,
        val videoCpv: Double,
        val adInflationYoY: Double,
        val marketRecessionStatus: String,
        val currency: Currency
    )

    fun getMainIndices(currency: Currency, shockDeltaPct: Double = 0.0): List<MarketTickerItem> {
        val mult = currency.rateAgainstGbp
        val symbol = currency.symbol
        val shockMult = 1.0 + (shockDeltaPct / 100.0)

        return listOf(
            MarketTickerItem(
                ticker = "ADSPOT-100",
                name = "Global Ad Price Benchmark Index",
                valueFormatted = String.format("%.1f", 117.4 * shockMult),
                rawValue = 117.4 * shockMult,
                changePct = 1.8 + (shockDeltaPct * 0.25),
                isPositive = true,
                observationType = ObservationType.SYNTHETIC,
                unit = "pts"
            ),
            MarketTickerItem(
                ticker = "TVSPOT-30",
                name = "Standard 30s TV Spot Index",
                valueFormatted = String.format("%.1f", 128.2 * shockMult),
                rawValue = 128.2 * shockMult,
                changePct = 2.4 + (shockDeltaPct * 0.3),
                isPositive = true,
                observationType = ObservationType.SYNTHETIC,
                unit = "pts"
            ),
            MarketTickerItem(
                ticker = "SEARCH-CPC",
                name = "Institutional Search Click Price",
                valueFormatted = "$symbol${String.format("%.2f", 2.41 * mult * shockMult)}",
                rawValue = 2.41 * mult * shockMult,
                changePct = 4.1 + (shockDeltaPct * 0.2),
                isPositive = true,
                observationType = ObservationType.MODELLED,
                unit = "CPC"
            ),
            MarketTickerItem(
                ticker = "DISPLAY-CPM",
                name = "Open Exchange Display CPM",
                valueFormatted = "$symbol${String.format("%.2f", 5.84 * mult * shockMult)}",
                rawValue = 5.84 * mult * shockMult,
                changePct = -0.7 + (shockDeltaPct * 0.1),
                isPositive = false,
                observationType = ObservationType.OBSERVED,
                unit = "CPM"
            ),
            MarketTickerItem(
                ticker = "VIDEO-CPV",
                name = "Streaming Video Completed View",
                valueFormatted = "$symbol${String.format("%.3f", 0.041 * mult * shockMult)}",
                rawValue = 0.041 * mult * shockMult,
                changePct = 1.2 + (shockDeltaPct * 0.15),
                isPositive = true,
                observationType = ObservationType.OBSERVED,
                unit = "CPV"
            ),
            MarketTickerItem(
                ticker = "TV-PRIME-CPM",
                name = "Peak Linear TV Audience CPM",
                valueFormatted = "$symbol${String.format("%.2f", 29.80 * mult * shockMult)}",
                rawValue = 29.80 * mult * shockMult,
                changePct = 3.7 + (shockDeltaPct * 0.35),
                isPositive = true,
                observationType = ObservationType.LICENSED,
                unit = "CPM"
            ),
            MarketTickerItem(
                ticker = "ATTENTION-CPM",
                name = "Effective Attention-Adjusted CPM",
                valueFormatted = "$symbol${String.format("%.2f", 48.20 * mult * shockMult)}",
                rawValue = 48.20 * mult * shockMult,
                changePct = 2.8 + (shockDeltaPct * 0.2),
                isPositive = true,
                observationType = ObservationType.MODELLED,
                unit = "aCPM"
            )
        )
    }

    fun getGlobalRegions(): List<GlobalRegionData> {
        return listOf(
            GlobalRegionData("UK", "United Kingdom", 24.50, 2.41, 5.84, 0.041, 6.4, "EXPANSION", Currency.GBP),
            GlobalRegionData("USA", "United States", 34.20, 3.85, 7.20, 0.052, 7.8, "EXPANSION", Currency.USD),
            GlobalRegionData("DE", "Germany", 22.80, 2.15, 4.90, 0.038, 5.1, "NORMAL", Currency.EUR),
            GlobalRegionData("FR", "France", 21.40, 1.95, 4.60, 0.036, 4.8, "NORMAL", Currency.EUR),
            GlobalRegionData("JP", "Japan", 28.50, 2.60, 5.10, 0.044, 3.2, "COOLING", Currency.JPY),
            GlobalRegionData("AU", "Australia", 26.00, 2.80, 6.10, 0.046, 6.8, "EXPANSION", Currency.AUD),
            GlobalRegionData("SG", "Singapore", 29.00, 3.10, 6.80, 0.049, 7.2, "EXPANSION", Currency.SGD),
            GlobalRegionData("AE", "United Arab Emirates", 31.50, 3.40, 7.50, 0.055, 8.4, "EXPANSION", Currency.AED),
            GlobalRegionData("ZA", "South Africa", 14.20, 1.20, 3.10, 0.024, 9.1, "NORMAL", Currency.ZAR)
        )
    }
}
