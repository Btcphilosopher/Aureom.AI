package com.example.engine

import com.example.model.MarketChannel
import com.example.model.MediaArbitrageItem

object ArbitrageScenarioEngine {

    fun scanArbitrageOpportunities(): List<MediaArbitrageItem> {
        return listOf(
            MediaArbitrageItem(
                id = "ARB-001",
                channelA = MarketChannel.PODCAST,
                channelB = MarketChannel.TELEVISION,
                rawSpreadCpm = -5.00,
                rawSpreadPct = -20.4,
                qualityAdjustedSpreadCpm = -14.20,
                qualityAdjustedPct = -38.5,
                confidence = 0.88,
                rationale = "Podcast host-read delivers 22.0s average active listening at £19.50 CPM vs £24.50 TV CPM (14.5s attention). Attention-adjusted cost is 38.5% lower.",
                actionSignal = "LONG PODCAST ATTENTION // ROTATE FROM LINEAR"
            ),
            MediaArbitrageItem(
                id = "ARB-002",
                channelA = MarketChannel.STREAMING_TV,
                channelB = MarketChannel.PROGRAMMATIC_DISPLAY,
                rawSpreadCpm = 25.20,
                rawSpreadPct = 900.0,
                qualityAdjustedSpreadCpm = -8.50,
                qualityAdjustedPct = -24.0,
                confidence = 0.92,
                rationale = "Apparent arbitrage favours Display (£2.80 vs £28.00 CTV), but Display viewability (52%) and 1.4s attention make effective Attention CPM £48.20 vs £38.40 for CTV.",
                actionSignal = "AVOID DISPLAY APPARENT ARBITRAGE // OVERWEIGHT CTV"
            ),
            MediaArbitrageItem(
                id = "ARB-003",
                channelA = MarketChannel.DIGITAL_OUT_OF_HOME,
                channelB = MarketChannel.SOCIAL,
                rawSpreadCpm = 0.70,
                rawSpreadPct = 8.2,
                qualityAdjustedSpreadCpm = -3.40,
                qualityAdjustedPct = -18.6,
                confidence = 0.79,
                rationale = "DOOH roadside screen delivery provides unskippable high-salience exposure (4.5s eyes-on) at £9.20 CPM vs Meta in-feed scroll degradation (2.1s eyes-on at £8.50 CPM).",
                actionSignal = "TACTICAL LONG DOOH ON PRIME COMMUTE CORRIDORS"
            ),
            MediaArbitrageItem(
                id = "ARB-004",
                channelA = MarketChannel.RETAIL_MEDIA,
                channelB = MarketChannel.GOOGLE_SEARCH,
                rawSpreadCpm = -39.00,
                rawSpreadPct = -70.9,
                qualityAdjustedSpreadCpm = -12.80,
                qualityAdjustedPct = -22.5,
                confidence = 0.85,
                rationale = "Retail Media sponsored listings capture end-of-funnel checkout intent at ~£16.00 equivalent CPM vs competitive Generic Search at £55.00 equivalent CPM.",
                actionSignal = "OVERWEIGHT RETAIL MEDIA IN COMMERCE MIX"
            )
        )
    }

    data class ShockScenario(
        val id: String,
        val title: String,
        val description: String,
        val tvSpotPriceChangePct: Double,
        val googleCpcChangePct: Double,
        val displayCpmChangePct: Double,
        val aggregateAdInflationDelta: Double,
        val marketRecessionScore: Double, // 0-100
        val summaryImpact: String
    )

    fun getScenarios(): List<ShockScenario> {
        return listOf(
            ShockScenario(
                id = "SCEN-01",
                title = "TV Linear Inventory Shock (-20%)",
                description = "Sudden migration to ad-free SVOD shrinks linear viewing minutes by 20% while advertiser demand remains inelastic.",
                tvSpotPriceChangePct = 28.4,
                googleCpcChangePct = 8.2,
                displayCpmChangePct = 4.5,
                aggregateAdInflationDelta = 9.6,
                marketRecessionScore = 32.0,
                summaryImpact = "Severe linear TV inflation (+28.4%). Spillover demand forces digital video and CTV prices up +18%."
            ),
            ShockScenario(
                id = "SCEN-02",
                title = "E-Commerce Black Friday Surge",
                description = "Q4 seasonal demand peak where retail, consumer tech, and DTC brands deploy 40% of annual digital budgets.",
                tvSpotPriceChangePct = 35.0,
                googleCpcChangePct = 42.5,
                displayCpmChangePct = 22.0,
                aggregateAdInflationDelta = 32.0,
                marketRecessionScore = 12.0,
                summaryImpact = "Search CPC spikes to £3.45 (+42.5%). Prime TV 30s rate cards surge past £65,000 per spot."
            ),
            ShockScenario(
                id = "SCEN-03",
                title = "Macroeconomic Recession & Budget Freeze",
                description = "Corporate earnings drop by 15%, consumer confidence contracts, leading to immediate cancellation of uncommitted scatter TV and programmatic spend.",
                tvSpotPriceChangePct = -24.5,
                googleCpcChangePct = -18.0,
                displayCpmChangePct = -32.0,
                aggregateAdInflationDelta = -14.2,
                marketRecessionScore = 82.0,
                summaryImpact = "Broad deflationary pressure across all media. Open programmatic display crashes -32%."
            ),
            ShockScenario(
                id = "SCEN-04",
                title = "Major World Cup / Olympic Super Spike",
                description = "Global broadcast and streaming event consolidates massive live concurrent audiences in prime time.",
                tvSpotPriceChangePct = 48.0,
                googleCpcChangePct = 12.0,
                displayCpmChangePct = 8.0,
                aggregateAdInflationDelta = 18.5,
                marketRecessionScore = 18.0,
                summaryImpact = "Sports programming spot prices double. Huge incremental reach surge of +6.5M unique viewers."
            )
        )
    }

    data class ReplayEvent(
        val id: String,
        val date: String,
        val eventName: String,
        val keyMetric: String,
        val clearingPrice: String,
        val audienceOrImpressions: String,
        val commentary: String
    )

    fun getHistoricalReplayEvents(): List<ReplayEvent> {
        return listOf(
            ReplayEvent(
                "REP-01",
                "2026-10-01",
                "Q4 Upfront Opening Bell",
                "TV Benchmark 30s",
                "£28,400 net",
                "3.8M viewers",
                "Agency holding companies committed 68% of Q4 allocations within first 4 hours of opening."
            ),
            ReplayEvent(
                "REP-02",
                "2026-07-14",
                "European Football Final",
                "Live Sports 30s",
                "£115,000 net",
                "18.4M live peak",
                "Highest live simultaneous reach event in 24 months. GRP hit 34.0 in commercial 18-54 demo."
            ),
            ReplayEvent(
                "REP-03",
                "2025-11-28",
                "Black Friday Flash Auction",
                "Google Retail CPC",
                "£4.12 actual",
                "142M daily queries",
                "Algorithmic bid escalation caused commercial keyword CPCs to peak at 2.4x standard baseline."
            ),
            ReplayEvent(
                "REP-04",
                "2025-12-24",
                "Christmas Eve Broadcast Special",
                "Festive Prime 30s",
                "£48,500 net",
                "7.2M co-viewers",
                "High co-viewing index (1.8x per screen) delivered unmatched family household attention salience."
            )
        )
    }
}
