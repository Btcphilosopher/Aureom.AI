package com.example.engine

import com.example.model.BreakPosition
import com.example.model.DemographicTarget
import com.example.model.SpotDuration
import com.example.model.TVProgrammeRate
import kotlin.math.max
import kotlin.math.roundToInt

object TVPricingEngine {

    data class TVSpotQuote(
        val programme: TVProgrammeRate,
        val duration: SpotDuration,
        val position: BreakPosition,
        val demographic: DemographicTarget,
        val agencyDiscountPct: Double,
        val volumeDiscountPct: Double,
        val seasonalityIndex: Double,
        // Computed values
        val grossRateCardPrice: Double,
        val netSpotPrice: Double,
        val effectiveAudienceMillions: Double,
        val effectiveGrp: Double,
        val cpmAllAdults: Double,
        val cpmTargetDemo: Double,
        val costPerRatingPointCpp: Double,
        val attentionSeconds: Double,
        val attentionAdjustedCpm: Double,
        val priceFormulaBreakdown: String
    )

    fun calculateSpotQuote(
        programme: TVProgrammeRate,
        duration: SpotDuration,
        position: BreakPosition,
        demographic: DemographicTarget,
        agencyDiscountPct: Double = 15.0,
        volumeDiscountPct: Double = 5.0,
        seasonalityIndex: Double = 1.12, // Q4 Peak default
        demandMultiplier: Double = 1.05
    ): TVSpotQuote {
        val baseRate = programme.baseRateCardGbp
        val durationFactor = duration.multiplier
        val positionFactor = position.positionMultiplier
        val demoFactor = demographic.universeWeight
        val programmePremium = 1.0 + (programme.scarcityFactor * 0.25)
        val peakFactor = if (programme.isPeakTime) 1.28 else 1.0

        // Gross analytical price before discounts
        val grossCalculated = baseRate *
                durationFactor *
                positionFactor *
                demoFactor *
                programmePremium *
                peakFactor *
                seasonalityIndex *
                demandMultiplier

        // Net price after agency commission & volume discounts
        val totalDiscountFraction = (agencyDiscountPct + volumeDiscountPct) / 100.0
        val netPrice = grossCalculated * (1.0 - totalDiscountFraction.coerceIn(0.0, 0.50))

        // Target audience calculation
        val demoShare = demographic.universeMillions / 54.2
        val effectiveAudience = programme.estimatedAudienceMillions * demoShare
        val effectiveGrp = (effectiveAudience / demographic.universeMillions) * 100.0

        // CPM = (Price / Impressions) * 1000
        val totalImpressions = max(100.0, programme.estimatedAudienceMillions * 1_000_000.0)
        val targetImpressions = max(50.0, effectiveAudience * 1_000_000.0)

        val cpmAdults = (netPrice / totalImpressions) * 1000.0
        val cpmDemo = (netPrice / targetImpressions) * 1000.0
        val cpp = if (effectiveGrp > 0) netPrice / effectiveGrp else 0.0

        // Attention seconds: 30s base attention ~ 14.5s adjusted for duration and break position
        val baseAttentionSec = (duration.seconds.toDouble() * 0.48) * position.attentionRetention
        val attentionSeconds = baseAttentionSec.coerceAtLeast(1.0)
        val attentionCpm = (netPrice / (targetImpressions * (attentionSeconds / duration.seconds))) * 1000.0

        val formula = "Gross (£${grossCalculated.roundToInt()}) = Base (£${baseRate.roundToInt()}) × Dur(${durationFactor}x) × Pos(${positionFactor}x) × Demo(${demoFactor}x) × Peak(${peakFactor}x) × Season(${seasonalityIndex}x) - Discs(${agencyDiscountPct + volumeDiscountPct}%)"

        return TVSpotQuote(
            programme = programme,
            duration = duration,
            position = position,
            demographic = demographic,
            agencyDiscountPct = agencyDiscountPct,
            volumeDiscountPct = volumeDiscountPct,
            seasonalityIndex = seasonalityIndex,
            grossRateCardPrice = grossCalculated,
            netSpotPrice = netPrice,
            effectiveAudienceMillions = effectiveAudience,
            effectiveGrp = effectiveGrp,
            cpmAllAdults = cpmAdults,
            cpmTargetDemo = cpmDemo,
            costPerRatingPointCpp = cpp,
            attentionSeconds = attentionSeconds,
            attentionAdjustedCpm = attentionCpm,
            priceFormulaBreakdown = formula
        )
    }

    data class ForwardCurvePoint(
        val period: String,
        val expectedCpmGbp: Double,
        val demandIndex: Double,
        val scarcityIndex: Double,
        val catalystEvent: String
    )

    fun getSyntheticForwardCurve(): List<ForwardCurvePoint> {
        return listOf(
            ForwardCurvePoint("2026-Q1 Jan-Feb", 18.40, 0.82, 0.75, "Post-Holiday Reset / Low Retail"),
            ForwardCurvePoint("2026-Q1 Mar (Easter)", 22.10, 1.05, 0.95, "Spring Campaigns / Easter Ad Waves"),
            ForwardCurvePoint("2026-Q2 Apr-May", 24.50, 1.10, 1.00, "Banking, Auto & Travel Surge"),
            ForwardCurvePoint("2026-Q2 Jun (Sports)", 28.90, 1.35, 1.40, "Major Tournament & Summer Upfronts"),
            ForwardCurvePoint("2026-Q3 Jul-Aug", 19.80, 0.88, 0.80, "Summer Slump / Lower Linear Viewing"),
            ForwardCurvePoint("2026-Q3 Sep (BackToSchool)", 25.40, 1.15, 1.10, "Autumn Schedule Launches"),
            ForwardCurvePoint("2026-Q4 Oct", 29.80, 1.30, 1.25, "Pre-Holiday Retail Ramp"),
            ForwardCurvePoint("2026-Q4 Nov (Black Fri)", 36.50, 1.65, 1.70, "E-Commerce & Tech Peak Demand"),
            ForwardCurvePoint("2026-Q4 Dec (Christmas)", 42.80, 1.95, 2.05, "Luxury, Retail & Festive Scarcity Spike")
        )
    }
}
