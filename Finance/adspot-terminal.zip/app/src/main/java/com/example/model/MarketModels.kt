package com.example.model

enum class ObservationType(val label: String, val description: String) {
    OBSERVED("OBSERVED", "Directly observed commercial transaction data"),
    LICENSED("LICENSED", "Audited industry rate card & verified metering"),
    SURVEY("SURVEY", "Panel-based survey & sample telemetry"),
    ESTIMATED("ESTIMATED", "Econometric statistical regression estimation"),
    MODELLED("MODELLED", "Algorithmic simulation & auction twin output"),
    SYNTHETIC("SYNTHETIC", "Synthetic standardized benchmark instrument")
}

enum class Currency(
    val code: String,
    val symbol: String,
    val rateAgainstGbp: Double,
    val pppFactor: Double
) {
    GBP("GBP", "£", 1.0, 1.0),
    USD("USD", "$", 1.30, 0.85),
    EUR("EUR", "€", 1.18, 0.92),
    JPY("JPY", "¥", 195.0, 140.0),
    AUD("AUD", "A$", 1.95, 1.45),
    CAD("CAD", "C$", 1.76, 1.32),
    CHF("CHF", "Fr", 1.12, 0.88),
    SGD("SGD", "S$", 1.70, 1.25),
    AED("AED", "AED ", 4.77, 3.60),
    ZAR("ZAR", "R ", 22.5, 9.80)
}

enum class MarketChannel(val displayName: String, val tag: String, val defaultViewability: Double, val defaultAttentionSec: Double) {
    TELEVISION("Linear Television", "TV-30", 0.92, 14.5),
    STREAMING_TV("Streaming / Connected TV", "CTV", 0.95, 18.2),
    YOUTUBE("YouTube Video Ads", "YT-SKP", 0.85, 9.8),
    GOOGLE_SEARCH("Google Paid Search", "G-SEARCH", 0.98, 4.2),
    GOOGLE_DISPLAY("Google Display Network", "GDN", 0.58, 1.8),
    PROGRAMMATIC_DISPLAY("Programmatic Open Exchange", "PROG", 0.52, 1.4),
    SOCIAL("Social Feed Ads", "META/TK", 0.65, 2.4),
    PODCAST("Podcast Host-Read / Dynamic", "PODCAST", 0.88, 22.0),
    RADIO("Commercial Terrestrial Radio", "RADIO", 0.82, 11.0),
    CINEMA("Cinema Screen Commercials", "CINEMA", 0.98, 28.0),
    OUT_OF_HOME("Classic Out-Of-Home", "OOH", 0.70, 3.2),
    DIGITAL_OUT_OF_HOME("Digital Out-Of-Home", "DOOH", 0.78, 4.5),
    RETAIL_MEDIA("Retail Media Networks", "RETAIL", 0.75, 5.0),
    PRINT("National & Trade Print", "PRINT", 0.60, 6.5)
}

enum class SpotDuration(val seconds: Int, val multiplier: Double, val label: String) {
    SEC_5(5, 0.35, "5s"),
    SEC_10(10, 0.50, "10s"),
    SEC_15(15, 0.70, "15s"),
    SEC_20(20, 0.85, "20s"),
    SEC_30(30, 1.00, "30s (Benchmark)"),
    SEC_40(40, 1.30, "40s"),
    SEC_60(60, 1.85, "60s"),
    SEC_90(90, 2.65, "90s"),
    SEC_120(120, 3.40, "120s")
}

enum class BreakPosition(val label: String, val positionMultiplier: Double, val recallBonusPct: Double, val attentionRetention: Double) {
    FIRST_IN_BREAK("First in Break (PIB)", 1.25, 34.0, 0.92),
    EARLY_BREAK("Early Break (Pos 2)", 1.10, 18.0, 0.85),
    MIDDLE_BREAK("Middle Break", 1.00, 0.0, 0.76),
    LATE_BREAK("Late Break", 1.05, 12.0, 0.81),
    LAST_IN_BREAK("Last in Break (LIB)", 1.20, 28.0, 0.90)
}

enum class DemographicTarget(val code: String, val label: String, val universeMillions: Double, val universeWeight: Double) {
    ALL_ADULTS("ALL_ADULTS", "All Adults 16+", 54.2, 1.0),
    ADULTS_16_34("16-34", "Young Adults 16–34", 15.8, 1.45),
    ADULTS_18_34("18-34", "Commercial 18–34", 14.5, 1.50),
    ADULTS_25_54("25-54", "Core Commercial 25–54", 25.1, 1.28),
    ADULTS_35_64("35-64", "Affluent Adults 35–64", 22.4, 1.15),
    ABC1_SOCIO("ABC1", "ABC1 High Socio-Economic", 29.8, 1.38),
    HIGH_NET_WORTH("HNW", "High Net Worth / Decision Makers", 6.2, 2.10)
}

data class AuditBadge(
    val type: ObservationType,
    val source: String,
    val confidence: Double,
    val sampleSize: String = "n=4.8M panel / telemetry",
    val timestamp: String = "2026-10-07 09:41:31 UTC"
)

data class MarketTickerItem(
    val ticker: String,
    val name: String,
    val valueFormatted: String,
    val rawValue: Double,
    val changePct: Double,
    val isPositive: Boolean,
    val observationType: ObservationType,
    val unit: String
)

data class TVProgrammeRate(
    val id: String,
    val broadcaster: String,
    val channel: String,
    val programmeTitle: String,
    val genre: String,
    val timeSlot: String,
    val isPeakTime: Boolean,
    val baseRateCardGbp: Double,
    val estimatedAudienceMillions: Double,
    val grp: Double,
    val scarcityFactor: Double,
    val demandScore: Double,
    val defaultTarget: DemographicTarget = DemographicTarget.ALL_ADULTS
)

data class OrderBookLevel(
    val priceCpm: Double,
    val volumeMillions: Double,
    val cumulativeMillions: Double,
    val sharePct: Double,
    val publisher: String
)

data class MediaArbitrageItem(
    val id: String,
    val channelA: MarketChannel,
    val channelB: MarketChannel,
    val rawSpreadCpm: Double,
    val rawSpreadPct: Double,
    val qualityAdjustedSpreadCpm: Double,
    val qualityAdjustedPct: Double,
    val confidence: Double,
    val rationale: String,
    val actionSignal: String
)
