package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.CrossMediaTranslator
import com.example.model.Currency
import com.example.model.MarketChannel
import com.example.model.ObservationType
import com.example.ui.components.AuditBadgeView
import com.example.ui.components.FormulaExplanationBox
import com.example.ui.components.TerminalCard
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun CrossMediaEquivalenceScreen(
    selectedCurrency: Currency,
    modifier: Modifier = Modifier
) {
    var spendGbp by remember { mutableStateOf(100000.0) }
    var channelA by remember { mutableStateOf(MarketChannel.TELEVISION) }
    var channelB by remember { mutableStateOf(MarketChannel.GOOGLE_SEARCH) }

    val currSymbol = selectedCurrency.symbol
    val fx = selectedCurrency.rateAgainstGbp

    val comparison = remember(spendGbp, channelA, channelB) {
        CrossMediaTranslator.compareChannels(channelA, channelB, spendGbp)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "MEDIA EQUIVALENCE ENGINE // CROSS-PLATFORM TRANSLATOR",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold
            )
            Text(
                text = "Translates commercial spend across disparate media channels into normalized economic units.",
                fontSize = 9.5.sp,
                fontFamily = FontFamily.Monospace,
                color = TerminalSteel
            )
        }

        // Spend Budget Selector
        item {
            TerminalCard(
                title = "1. CAPITAL ALLOCATION BUDGET",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BUDGET: $currSymbol${String.format("%,d", (spendGbp * fx).roundToInt())}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalCyan
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(25000.0, 50000.0, 100000.0, 500000.0, 1000000.0).forEach { preset ->
                                Surface(
                                    shape = RoundedCornerShape(3.dp),
                                    color = if (spendGbp == preset) TerminalCyan else TerminalCard,
                                    modifier = Modifier.clickable { spendGbp = preset }
                                ) {
                                    Text(
                                        text = "${(preset / 1000).toInt()}k",
                                        fontSize = 9.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (spendGbp == preset) TerminalBackground else TerminalWhite,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }

                    Slider(
                        value = spendGbp.toFloat(),
                        onValueChange = { spendGbp = it.toDouble() },
                        valueRange = 10000f..1000000f,
                        colors = SliderDefaults.colors(
                            thumbColor = TerminalCyan,
                            activeTrackColor = TerminalCyan,
                            inactiveTrackColor = TerminalCardBorder
                        ),
                        modifier = Modifier.testTag("spend_slider")
                    )
                }
            }
        }

        // Channel Selectors
        item {
            TerminalCard(
                title = "2. PAIRWISE CHANNEL COMPARISON SELECTOR",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column {
                        Text(text = "BASE CHANNEL [A]: ${channelA.displayName}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                        Spacer(modifier = Modifier.height(3.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            MarketChannel.values().take(7).forEach { ch ->
                                val isSel = ch == channelA
                                Surface(
                                    shape = RoundedCornerShape(3.dp),
                                    color = if (isSel) TerminalCyan else TerminalCard,
                                    modifier = Modifier.clickable { channelA = ch }
                                ) {
                                    Text(
                                        text = ch.tag,
                                        fontSize = 9.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) TerminalBackground else TerminalWhite,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }

                    Column {
                        Text(text = "TARGET CHANNEL [B]: ${channelB.displayName}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                        Spacer(modifier = Modifier.height(3.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            MarketChannel.values().takeLast(7).forEach { ch ->
                                val isSel = ch == channelB
                                Surface(
                                    shape = RoundedCornerShape(3.dp),
                                    color = if (isSel) TerminalGold else TerminalCard,
                                    modifier = Modifier.clickable { channelB = ch }
                                ) {
                                    Text(
                                        text = ch.tag,
                                        fontSize = 9.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) TerminalBackground else TerminalWhite,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Side by Side Equivalence Table
        item {
            TerminalCard(
                title = "3. SIDE-BY-SIDE MEDIA VALUATION",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Header row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(TerminalSurfaceVariant)
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "METRIC", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalSteel, modifier = Modifier.weight(1.3f))
                        Text(text = channelA.tag, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalCyan, modifier = Modifier.weight(1f))
                        Text(text = channelB.tag, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGold, modifier = Modifier.weight(1f))
                    }

                    val rowMetrics = listOf(
                        Triple("Spend Capital", "$currSymbol${String.format("%,d", (comparison.baseChannel.spendGbp * fx).roundToInt())}", "$currSymbol${String.format("%,d", (comparison.targetChannel.spendGbp * fx).roundToInt())}"),
                        Triple("Served Impressions", String.format("%,d", comparison.baseChannel.impressions), String.format("%,d", comparison.targetChannel.impressions)),
                        Triple("Raw Media CPM", "$currSymbol${String.format("%.2f", comparison.baseChannel.rawCpmGbp * fx)}", "$currSymbol${String.format("%.2f", comparison.targetChannel.rawCpmGbp * fx)}"),
                        Triple("Target Reach (Unique)", "${String.format("%.2f", comparison.baseChannel.estimatedReachMillions)}M", "${String.format("%.2f", comparison.targetChannel.estimatedReachMillions)}M"),
                        Triple("Avg Frequency", "${String.format("%.1f", comparison.baseChannel.averageFrequency)}x", "${String.format("%.1f", comparison.targetChannel.averageFrequency)}x"),
                        Triple("Active Attention Secs", "${String.format("%.2f", comparison.baseChannel.totalAttentionSecondsMillions)}M sec", "${String.format("%.2f", comparison.targetChannel.totalAttentionSecondsMillions)}M sec"),
                        Triple("Attention CPM (aCPM)", "$currSymbol${String.format("%.2f", comparison.baseChannel.attentionCpmGbp * fx)}", "$currSymbol${String.format("%.2f", comparison.targetChannel.attentionCpmGbp * fx)}"),
                        Triple("Estimated Visits/Clicks", String.format("%,d", comparison.baseChannel.estimatedClicksOrVisits), String.format("%,d", comparison.targetChannel.estimatedClicksOrVisits)),
                        Triple("Estimated Conversions", String.format("%,d", comparison.baseChannel.estimatedConversions), String.format("%,d", comparison.targetChannel.estimatedConversions)),
                        Triple("Brand Salience Units", String.format("%,d", comparison.baseChannel.brandRecallUnits), String.format("%,d", comparison.targetChannel.brandRecallUnits))
                    )

                    rowMetrics.forEach { (label, valA, valB) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = label, fontSize = 9.5.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel, modifier = Modifier.weight(1.3f))
                            Text(text = valA, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalWhite, modifier = Modifier.weight(1f))
                            Text(text = valB, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalWhite, modifier = Modifier.weight(1f))
                        }
                    }

                    Divider(color = TerminalCardBorder, thickness = 0.5.dp)

                    // Deduplicated Reach & Verdict
                    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                        Text(
                            text = "COMBINED CROSS-MEDIA NET REACH: ${String.format("%.2f", comparison.crossPlatformDeduplicatedReachMillions)}M (${String.format("%.1f", comparison.crossPlatformDeduplicatedReachMillions / 54.2 * 100)}% universe)",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGreen
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "VERDICT: ${comparison.qualitativeVerdict}",
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGold
                        )
                    }
                }
            }
        }

        // Formula definitions box
        item {
            FormulaExplanationBox(
                formulaName = "CROSS-MEDIA DEDUPLICATION & ATTENTION CPM",
                formulaText = "Attention CPM = (Spend / Active Attention Seconds) × 1,000",
                denominatorDefinition = "Net Reach = Reach_A + Reach_B - ((Reach_A × Reach_B) / Universe)",
                modelType = ObservationType.MODELLED
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
