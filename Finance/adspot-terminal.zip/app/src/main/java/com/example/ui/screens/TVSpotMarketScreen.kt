package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MarketRepository
import com.example.engine.TVPricingEngine
import com.example.model.*
import com.example.ui.components.AuditBadgeView
import com.example.ui.components.FormulaExplanationBox
import com.example.ui.components.TerminalCard
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun TVSpotMarketScreen(
    selectedCurrency: Currency,
    modifier: Modifier = Modifier
) {
    val programmes = MarketRepository.sampleProgrammes
    var selectedProg by remember { mutableStateOf(programmes.first()) }
    var selectedDuration by remember { mutableStateOf(SpotDuration.SEC_30) }
    var selectedPosition by remember { mutableStateOf(BreakPosition.MIDDLE_BREAK) }
    var selectedDemo by remember { mutableStateOf(DemographicTarget.ALL_ADULTS) }
    var agencyDiscountPct by remember { mutableStateOf(15.0) }
    var volumeDiscountPct by remember { mutableStateOf(5.0) }
    var seasonalityIndex by remember { mutableStateOf(1.12) }

    val quote = remember(selectedProg, selectedDuration, selectedPosition, selectedDemo, agencyDiscountPct, volumeDiscountPct, seasonalityIndex) {
        TVPricingEngine.calculateSpotQuote(
            programme = selectedProg,
            duration = selectedDuration,
            position = selectedPosition,
            demographic = selectedDemo,
            agencyDiscountPct = agencyDiscountPct,
            volumeDiscountPct = volumeDiscountPct,
            seasonalityIndex = seasonalityIndex
        )
    }

    val currSymbol = selectedCurrency.symbol
    val fx = selectedCurrency.rateAgainstGbp
    val forwardCurves = remember { TVPricingEngine.getSyntheticForwardCurve() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "TV-SPOT-MARKET // PRICING & RATE CARD ENGINE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold
            )
            Text(
                text = "Analytical pricing model for broadcaster inventory, break positions, and audience GRPs.",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = TerminalSteel
            )
        }

        // Programme Selector Carousel
        item {
            TerminalCard(
                title = "1. SELECT BROADCASTER & PROGRAMME",
                badgeType = ObservationType.LICENSED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    programmes.forEach { prg ->
                        val isSelected = prg.id == selectedProg.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) TerminalCyanDim.copy(alpha = 0.4f) else TerminalCard)
                                .border(
                                    width = if (isSelected) 1.dp else 0.5.dp,
                                    color = if (isSelected) TerminalCyan else TerminalCardBorder,
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable { selectedProg = prg }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("programme_${prg.id.lowercase()}"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = prg.programmeTitle,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (isSelected) TerminalCyan else TerminalWhite
                                    )
                                    if (prg.isPeakTime) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "[PEAK]",
                                            fontSize = 8.5.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = TerminalGold,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Text(
                                    text = "${prg.broadcaster} | ${prg.timeSlot} | Aud: ${prg.estimatedAudienceMillions}M | GRP: ${prg.grp}",
                                    fontSize = 9.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalMuted
                                )
                            }
                            Text(
                                text = "$currSymbol${String.format("%,d", (prg.baseRateCardGbp * fx).roundToInt())}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGold
                            )
                        }
                    }
                }
            }
        }

        // Spot Configuration Parameters
        item {
            TerminalCard(
                title = "2. SPOT PARAMETERS & DEMOGRAPHICS",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Spot Duration Selector
                    Column {
                        Text(
                            text = "SPOT DURATION: ${selectedDuration.label} (${selectedDuration.multiplier}x base rate)",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalWhite
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SpotDuration.values().forEach { dur ->
                                val isSel = dur == selectedDuration
                                Surface(
                                    shape = RoundedCornerShape(3.dp),
                                    color = if (isSel) TerminalCyan else TerminalCard,
                                    modifier = Modifier.clickable { selectedDuration = dur }
                                ) {
                                    Text(
                                        text = dur.label,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) TerminalBackground else TerminalWhite,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Break Position Selector
                    Column {
                        Text(
                            text = "BREAK POSITION: ${selectedPosition.label} (+${((selectedPosition.positionMultiplier - 1.0) * 100).toInt()}% prem)",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalWhite
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            BreakPosition.values().forEach { pos ->
                                val isSel = pos == selectedPosition
                                Surface(
                                    shape = RoundedCornerShape(3.dp),
                                    color = if (isSel) TerminalGold else TerminalCard,
                                    modifier = Modifier.clickable { selectedPosition = pos }
                                ) {
                                    Text(
                                        text = pos.label,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) TerminalBackground else TerminalWhite,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Demographic Target Selector
                    Column {
                        Text(
                            text = "TARGET DEMOGRAPHIC: ${selectedDemo.label} (Universe: ${selectedDemo.universeMillions}M)",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalWhite
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DemographicTarget.values().forEach { demo ->
                                val isSel = demo == selectedDemo
                                Surface(
                                    shape = RoundedCornerShape(3.dp),
                                    color = if (isSel) TerminalGreen else TerminalCard,
                                    modifier = Modifier.clickable { selectedDemo = demo }
                                ) {
                                    Text(
                                        text = demo.code,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) TerminalBackground else TerminalWhite,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Discounts and Seasonality Sliders
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Agency & Volume Discount: ${(agencyDiscountPct + volumeDiscountPct).toInt()}%",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )
                            Text(
                                text = "Seasonality Index: ${String.format("%.2f", seasonalityIndex)}x",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGold
                            )
                        }
                        Slider(
                            value = seasonalityIndex.toFloat(),
                            onValueChange = { seasonalityIndex = it.toDouble() },
                            valueRange = 0.80f..2.10f,
                            colors = SliderDefaults.colors(
                                thumbColor = TerminalGold,
                                activeTrackColor = TerminalGold,
                                inactiveTrackColor = TerminalCardBorder
                            ),
                            modifier = Modifier.testTag("seasonality_slider")
                        )
                    }
                }
            }
        }

        // Calculated Spot Quote Result
        item {
            TerminalCard(
                title = "3. CALCULATED NET SPOT QUOTE & VALUATION",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Highlight numbers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "ESTIMATED NET SPOT PRICE",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )
                            Text(
                                text = "$currSymbol${String.format("%,d", (quote.netSpotPrice * fx).roundToInt())}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGold
                            )
                            Text(
                                text = "Gross Rate Card: $currSymbol${String.format("%,d", (quote.grossRateCardPrice * fx).roundToInt())}",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalMuted
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "TARGET DEMO CPM",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )
                            Text(
                                text = "$currSymbol${String.format("%.2f", quote.cpmTargetDemo * fx)}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalCyan
                            )
                            Text(
                                text = "All Adults CPM: $currSymbol${String.format("%.2f", quote.cpmAllAdults * fx)}",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalMuted
                            )
                        }
                    }

                    Divider(color = TerminalCardBorder, thickness = 0.5.dp)

                    // Secondary Metrics Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "CPP (COST PER POINT)",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )
                            Text(
                                text = "$currSymbol${String.format("%,d", (quote.costPerRatingPointCpp * fx).roundToInt())}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalWhite
                            )
                            Text(
                                text = "Target GRP: ${String.format("%.2f", quote.effectiveGrp)}",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalMuted
                            )
                        }

                        Column {
                            Text(
                                text = "ATTENTION SECONDS",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )
                            Text(
                                text = "${String.format("%.1f", quote.attentionSeconds)}s / ${selectedDuration.seconds}s",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalWhite
                            )
                            Text(
                                text = "Retention: ${(selectedPosition.attentionRetention * 100).toInt()}%",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalMuted
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "ATTENTION CPM",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )
                            Text(
                                text = "$currSymbol${String.format("%.2f", quote.attentionAdjustedCpm * fx)}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGreen
                            )
                            Text(
                                text = "Verified Eyes-On",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalMuted
                            )
                        }
                    }
                }
            }
        }

        // Mathematical Breakdown Box
        item {
            FormulaExplanationBox(
                formulaName = "TV SPOT PRICING ENGINE",
                formulaText = quote.priceFormulaBreakdown,
                denominatorDefinition = "TV CPM = (Net Spot Price / Target Audience Impressions) * 1000",
                modelType = ObservationType.MODELLED
            )
        }

        // Synthetic Forward Curve Table
        item {
            TerminalCard(
                title = "TV ADVERTISING FORWARD CURVE (SYNTHETIC BENCHMARK)",
                badgeType = ObservationType.SYNTHETIC
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    forwardCurves.forEach { pt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(TerminalCard)
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = pt.period,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalCyan
                                )
                                Text(
                                    text = pt.catalystEvent,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalMuted
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "$currSymbol${String.format("%.2f", pt.expectedCpmGbp * fx)} CPM",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalGold
                                )
                                Text(
                                    text = "Demand ${pt.demandIndex}x | Scarcity ${pt.scarcityIndex}x",
                                    fontSize = 8.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalSteel
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
