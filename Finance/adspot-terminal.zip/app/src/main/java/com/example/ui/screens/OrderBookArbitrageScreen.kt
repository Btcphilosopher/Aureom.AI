package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ArbitrageScenarioEngine
import com.example.engine.InventoryOrderBookEngine
import com.example.model.Currency
import com.example.model.ObservationType
import com.example.ui.components.AuditBadgeView
import com.example.ui.components.FormulaExplanationBox
import com.example.ui.components.TerminalCard
import com.example.ui.theme.*

@Composable
fun OrderBookArbitrageScreen(
    selectedCurrency: Currency,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("PREMIUM_VIDEO_TV") }
    val book = remember(selectedCategory) { InventoryOrderBookEngine.getOrderBook(selectedCategory) }
    val arbitrageItems = remember { ArbitrageScenarioEngine.scanArbitrageOpportunities() }

    val currSymbol = selectedCurrency.symbol
    val fx = selectedCurrency.rateAgainstGbp

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "AD INVENTORY BOOK & ARBITRAGE SCANNER",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold
            )
            Text(
                text = "Synthetic bid/ask market representation & quality-adjusted mispricing arbitrage scanner.",
                fontSize = 9.5.sp,
                fontFamily = FontFamily.Monospace,
                color = TerminalSteel
            )
        }

        // Category Switcher
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "PREMIUM_VIDEO_TV" to "TV / Video Inventory",
                    "SEARCH_CLICKS" to "Search Queries",
                    "DISPLAY_OPEN" to "Programmatic Display"
                ).forEach { (cat, label) ->
                    val isSel = cat == selectedCategory
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (isSel) TerminalCyan else TerminalCard,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedCategory = cat }
                    ) {
                        Text(
                            text = label,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (isSel) TerminalBackground else TerminalWhite,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Order Book Card
        item {
            TerminalCard(
                title = "AD INVENTORY ORDER BOOK // LEVEL 2 DEPTH",
                badgeType = ObservationType.SYNTHETIC
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Top stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "MID CPM: $currSymbol${String.format("%.2f", book.midPriceCpm * fx)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGold
                        )
                        Text(
                            text = "SPREAD: $currSymbol${String.format("%.2f", book.spreadCpm * fx)} (${String.format("%.1f", book.spreadPct)}%)",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalSteel
                        )
                    }

                    Divider(color = TerminalCardBorder, thickness = 0.5.dp)

                    // SELL ASKS LADDER (Red)
                    Text(text = "--- ASKS (SELL / PUBLISHER SUPPLY) ---", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalRed)
                    book.sellOrders.forEach { ask ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(2.dp))
                                .background(TerminalRedDim.copy(alpha = 0.25f))
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "$currSymbol${String.format("%.2f", ask.priceCpm * fx)}", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalRed)
                            Text(text = "${ask.volumeMillions}M imps (${ask.publisher})", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                            Text(text = "Cum: ${String.format("%.1f", ask.cumulativeMillions)}M", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                        }
                    }

                    // MID MARKET BAR
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalGoldDim.copy(alpha = 0.4f))
                            .padding(vertical = 3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "====== MID CLEARING: $currSymbol${String.format("%.2f", book.midPriceCpm * fx)} ======",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGold
                        )
                    }

                    // BUY BIDS LADDER (Green)
                    Text(text = "--- BIDS (BUY / ADVERTISER DEMAND) ---", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalGreen)
                    book.buyOrders.forEach { bid ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(2.dp))
                                .background(TerminalGreenDim.copy(alpha = 0.25f))
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "$currSymbol${String.format("%.2f", bid.priceCpm * fx)}", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGreen)
                            Text(text = "${bid.volumeMillions}M imps (${bid.publisher})", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                            Text(text = "Cum: ${String.format("%.1f", bid.cumulativeMillions)}M", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                        }
                    }
                }
            }
        }

        // Media Arbitrage Scanner
        item {
            TerminalCard(
                title = "MEDIA ARBITRAGE OPPORTUNITY SCANNER",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    arbitrageItems.forEach { arb ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalCard)
                                .border(0.5.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "[${arb.id}]",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = TerminalCyan
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${arb.channelA.tag} vs ${arb.channelB.tag}",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = TerminalWhite
                                    )
                                }
                                AuditBadgeView(type = ObservationType.MODELLED, confidence = arb.confidence)
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Apparent Spread: ${String.format("%+.1f", arb.rawSpreadPct)}%",
                                    fontSize = 9.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalMuted
                                )
                                Text(
                                    text = "Quality-Adjusted Spread: ${String.format("%+.1f", arb.qualityAdjustedPct)}%",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (arb.qualityAdjustedPct < 0) TerminalGreen else TerminalRed
                                )
                            }

                            Text(
                                text = arb.rationale,
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )

                            Text(
                                text = "SIGNAL: ${arb.actionSignal}",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGold
                            )
                        }
                    }
                }
            }
        }

        item {
            FormulaExplanationBox(
                formulaName = "QUALITY-ADJUSTED MEDIA ARBITRAGE",
                formulaText = "Adjusted Spread = (Attention_CPM_A - Attention_CPM_B) / Attention_CPM_B",
                denominatorDefinition = "Adjusts raw CPM for Viewability × Completion × Active Attention Seconds",
                modelType = ObservationType.MODELLED
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
