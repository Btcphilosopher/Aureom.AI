package com.example.engine

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

object SearchAuctionEngine {

    data class AuctionParticipant(
        val advertiserName: String,
        val maxBidGbp: Double,
        val qualityScore: Double, // 1 to 10
        val isUserSimulated: Boolean = false
    ) {
        val adRank: Double get() = maxBidGbp * qualityScore
    }

    data class AuctionResult(
        val position: Int,
        val maxBidGbp: Double,
        val qualityScore: Double,
        val adRank: Double,
        val actualCpcGbp: Double,
        val estimatedCtrPct: Double,
        val estimatedDailyClicks: Int,
        val estimatedDailyCostGbp: Double,
        val costPerAcquisitionCpaGbp: Double,
        val competitionSummary: String,
        val rankingLadder: List<LadderRow>
    )

    data class LadderRow(
        val rank: Int,
        val advertiser: String,
        val bid: Double,
        val qs: Double,
        val adRank: Double,
        val clearingCpc: Double
    )

    fun simulateSearchAuction(
        keyword: String,
        userBidGbp: Double,
        userQualityScore: Double,
        competitionDensity: Int = 6, // 1-10
        conversionRatePct: Double = 3.5,
        deviceMultiplier: Double = 1.0 // Mobile vs Desktop
    ): AuctionResult {
        // Base market competitors
        val baseCompetitors = listOf(
            AuctionParticipant("Tier 1 Global Brand", 4.50 * deviceMultiplier, 8.5),
            AuctionParticipant("Institutional Aggregator", 3.80 * deviceMultiplier, 7.8),
            AuctionParticipant("Specialist Challenger", 3.20 * deviceMultiplier, 7.2),
            AuctionParticipant("Growth Startup", 2.60 * deviceMultiplier, 6.5),
            AuctionParticipant("Regional Network", 1.90 * deviceMultiplier, 6.0),
            AuctionParticipant("Long-tail Bidder", 1.20 * deviceMultiplier, 5.0)
        ).take(competitionDensity)

        val allBidders = (baseCompetitors + AuctionParticipant("ADSPOT User", userBidGbp, userQualityScore, true))
            .sortedByDescending { it.adRank }

        val userIndex = allBidders.indexOfFirst { it.isUserSimulated }
        val userPosition = if (userIndex >= 0) userIndex + 1 else 99

        val userBidder = allBidders.getOrNull(userIndex) ?: AuctionParticipant("ADSPOT User", userBidGbp, userQualityScore, true)
        val nextRank = if (userIndex + 1 < allBidders.size) allBidders[userIndex + 1].adRank else 0.5

        // Actual CPC formula in analytical generalized second-price auction: (Next AdRank / Your QS) + 0.01
        val rawClearingCpc = (nextRank / max(1.0, userBidder.qualityScore)) + 0.01
        val actualCpc = min(userBidGbp, max(0.10, rawClearingCpc))

        // Position-based CTR curve
        val positionCtrBase = when (userPosition) {
            1 -> 9.8
            2 -> 6.2
            3 -> 3.9
            4 -> 2.1
            else -> 0.8
        }
        val estimatedCtr = positionCtrBase * (userBidder.qualityScore / 7.0) * (if (deviceMultiplier > 1.0) 1.15 else 0.95)

        val totalDailyQueries = 25_000
        val dailyImpressions = (totalDailyQueries * (if (userPosition <= 4) 0.85 else 0.25)).toInt()
        val dailyClicks = ((dailyImpressions * (estimatedCtr / 100.0))).toInt().coerceAtLeast(1)
        val dailySpend = dailyClicks * actualCpc
        val estimatedConversions = (dailyClicks * (conversionRatePct / 100.0)).toInt().coerceAtLeast(1)
        val cpa = dailySpend / estimatedConversions

        val ladder = allBidders.mapIndexed { index, participant ->
            val nxt = if (index + 1 < allBidders.size) allBidders[index + 1].adRank else 0.4
            val clr = min(participant.maxBidGbp, (nxt / max(1.0, participant.qualityScore)) + 0.01)
            LadderRow(
                rank = index + 1,
                advertiser = participant.advertiserName,
                bid = participant.maxBidGbp,
                qs = participant.qualityScore,
                adRank = participant.adRank,
                clearingCpc = clr
            )
        }

        return AuctionResult(
            position = userPosition,
            maxBidGbp = userBidGbp,
            qualityScore = userQualityScore,
            adRank = userBidder.adRank,
            actualCpcGbp = actualCpc,
            estimatedCtrPct = estimatedCtr,
            estimatedDailyClicks = dailyClicks,
            estimatedDailyCostGbp = dailySpend,
            costPerAcquisitionCpaGbp = cpa,
            competitionSummary = "Auction with ${allBidders.size} participants on '$keyword'. AdRank required for #1: ${String.format("%.2f", allBidders.first().adRank)}",
            rankingLadder = ladder
        )
    }
}
