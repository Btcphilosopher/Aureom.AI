package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ArbitrageScenarioEngine
import com.example.engine.MediaMixFrontierEngine
import com.example.model.Currency
import com.example.model.ObservationType
import com.example.ui.components.AuditBadgeView
import com.example.ui.components.FormulaExplanationBox
import com.example.ui.components.TerminalCard
import com.example.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun QuantScenarioReplayScreen(
    selectedCurrency: Currency,
    activeShockId: String?,
    onApplyShock: (ArbitrageScenarioEngine.ShockScenario) -> Unit,
    onClearShock: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedPreset by remember { mutableStateOf(MediaMixFrontierEngine.StrategyPreset.BALANCED) }
    var mixBudgetGbp by remember { mutableStateOf(500000.0) }

    val currSymbol = selectedCurrency.symbol
    val fx = selectedCurrency.rateAgainstGbp

    val portfolio = remember(selectedPreset, mixBudgetGbp) {
        MediaMixFrontierEngine.generatePortfolio(selectedPreset, mixBudgetGbp)
    }

    val shockScenarios = remember { ArbitrageScenarioEngine.getScenarios() }
    val replayEvents = remember { ArbitrageScenarioEngine.getHistoricalReplayEvents() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "MEDIA FRONTIER, SHOCK SCENARIOS & MARKET REPLAY",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TerminalGold
            )
            Text(
                text = "Institutional portfolio optimization, macro stress testing, and historical market tape replay.",
                fontSize = 9.5.sp,
                fontFamily = FontFamily.Monospace,
                color = TerminalSteel
            )
        }

        // Efficient Frontier Portfolio Optimizer
        item {
            TerminalCard(
                title = "1. MEDIA EFFICIENT FRONTIER OPTIMIZER",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Preset Selector
                    Text(text = "STRATEGY ALLOCATION PRESET:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MediaMixFrontierEngine.StrategyPreset.values().forEach { preset ->
                            val isSel = preset == selectedPreset
                            Surface(
                                shape = RoundedCornerShape(3.dp),
                                color = if (isSel) TerminalCyan else TerminalCard,
                                modifier = Modifier
                                    .clickable { selectedPreset = preset }
                                    .testTag("preset_${preset.name.lowercase()}")
                            ) {
                                Text(
                                    text = preset.label,
                                    fontSize = 9.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSel) TerminalBackground else TerminalWhite,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Budget Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "BUDGET: $currSymbol${String.format("%,d", (mixBudgetGbp * fx).roundToInt())}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGold
                        )
                        Text(
                            text = "Blended ROAS: ${portfolio.blendedRoasRatio}x",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGreen
                        )
                    }

                    Slider(
                        value = mixBudgetGbp.toFloat(),
                        onValueChange = { mixBudgetGbp = it.toDouble() },
                        valueRange = 50000f..5000000f,
                        colors = SliderDefaults.colors(
                            thumbColor = TerminalGold,
                            activeTrackColor = TerminalGold,
                            inactiveTrackColor = TerminalCardBorder
                        )
                    )

                    // Results KPI Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "DEDUP REACH", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "${String.format("%.2f", portfolio.netDeduplicatedReachMillions)}M", fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalCyan)
                        }
                        Column {
                            Text(text = "TOTAL IMPS", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "${String.format("%.1f", portfolio.totalImpressionsMillions)}M", fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalWhite)
                        }
                        Column {
                            Text(text = "BLENDED CPM", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = "$currSymbol${String.format("%.2f", portfolio.blendedCpmGbp * fx)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGold)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "ATTENTION HOURS", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TerminalSteel)
                            Text(text = String.format("%,d", portfolio.totalAttentionHours.toInt()), fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGreen)
                        }
                    }

                    Divider(color = TerminalCardBorder, thickness = 0.5.dp)

                    // Channel Breakdown Table
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        portfolio.allocations.forEach { alloc ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(TerminalCard)
                                    .padding(horizontal = 6.dp, vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${alloc.channel.displayName} (${alloc.budgetSharePct.toInt()}%)",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalWhite
                                )
                                Text(
                                    text = "$currSymbol${String.format("%,d", (alloc.allocatedGbp * fx).roundToInt())}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalCyan
                                )
                            }
                        }
                    }
                }
            }
        }

        // Macro Shock Scenarios
        item {
            TerminalCard(
                title = "2. MACRO ADVERTISING SHOCK STRESS-TESTING",
                badgeType = ObservationType.MODELLED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    shockScenarios.forEach { sc ->
                        val isActive = sc.id == activeShockId
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isActive) TerminalRedDim.copy(alpha = 0.4f) else TerminalCard)
                                .border(
                                    0.5.dp,
                                    if (isActive) TerminalRed else TerminalCardBorder,
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = sc.title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isActive) TerminalRed else TerminalWhite
                                )
                                Button(
                                    onClick = {
                                        if (isActive) onClearShock() else onApplyShock(sc)
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isActive) TerminalRed else TerminalCardBorder,
                                        contentColor = TerminalWhite
                                    ),
                                    shape = RoundedCornerShape(3.dp),
                                    modifier = Modifier.height(24.dp)
                                ) {
                                    Text(
                                        text = if (isActive) "ACTIVE [RESET]" else "SIMULATE SHOCK",
                                        fontSize = 8.5.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = sc.description,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalMuted
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "TV: ${String.format("%+.1f", sc.tvSpotPriceChangePct)}% | Search: ${String.format("%+.1f", sc.googleCpcChangePct)}% | CPI: ${String.format("%+.1f", sc.aggregateAdInflationDelta)}%",
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (sc.tvSpotPriceChangePct > 0) TerminalRed else TerminalGreen
                                )
                            }
                        }
                    }
                }
            }
        }

        // Market Replay Events
        item {
            TerminalCard(
                title = "3. HISTORICAL MARKET TAPE REPLAY",
                badgeType = ObservationType.OBSERVED
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    replayEvents.forEach { ev ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(3.dp))
                                .background(TerminalCard)
                                .padding(6.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${ev.date}: ${ev.eventName}",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalCyan
                                )
                                Text(
                                    text = ev.clearingPrice,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = TerminalGold
                                )
                            }
                            Text(
                                text = "Metric: ${ev.keyMetric} | Volume: ${ev.audienceOrImpressions}",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalSteel
                            )
                            Text(
                                text = ev.commentary,
                                fontSize = 8.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalMuted
                            )
                        }
                    }
                }
            }
        }

        item {
            FormulaExplanationBox(
                formulaName = "MEDIA EFFICIENT FRONTIER",
                formulaText = "Max Blended ROAS / Portfolio Variance subject to Reach Constraints",
                denominatorDefinition = "Portfolio Variance = Σ Σ w_i × w_j × Cov(Media_i, Media_j)",
                modelType = ObservationType.MODELLED
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
