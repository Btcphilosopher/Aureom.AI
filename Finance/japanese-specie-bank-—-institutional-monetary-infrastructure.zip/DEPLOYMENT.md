# Production Deployment Guide — JSB Infrastructure

## Overview

JSB is designed for containerized deployment across multi-zone Kubernetes clusters or Docker Compose environments.

## Docker Compose Quickstart

```bash
docker-compose up -d
```

Services started:
- `db`: PostgreSQL 16 with double-entry schema migrations
- `consensus`: Rust consensus validator node
- `monetary-api`: Python / Express API service
- `terminal`: React institutional web application
