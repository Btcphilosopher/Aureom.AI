# Security & Operational Controls — Japanese Specie Bank

## 1. Cryptographic Security Standards
- **Transaction Signing**: ECDSA over secp256k1 / Ed25519 signatures with domain separator `JSB_YEN_SETTLEMENT_V1`.
- **Key Storage Interface**: Integrates with Hardware Security Modules (HSM - PKCS#11) and AWS KMS / GCP Cloud KMS. No raw private keys stored in persistent storage.
- **TLS & API Encryption**: Mutual TLS (mTLS) enforced between internal microservices. AES-256-GCM encryption for database columns containing sensitive institution profile data.

## 2. Dual-Control Maker-Checker Safeguards
- All monetary minting, burning, validator parameters, and emergency freeze triggers require independent Maker (proposer) and Checker (approver) roles.
- No single user account can authorize monetary supply changes.

## 3. Rate Limiting & Replay Protection
- Nonce-based replay protection for all ledger payloads.
- Timestamp validity window enforced (+/- 5 seconds JST).
