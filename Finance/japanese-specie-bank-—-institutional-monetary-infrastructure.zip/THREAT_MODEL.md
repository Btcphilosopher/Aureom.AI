# Threat Model — JSB Settlement Network

## STRIDE Threat Matrix

| Threat Category | Potential Attack Vector | JSB Safeguard / Mitigation |
|---|---|---|
| **Spoofing** | Fake validator node submitting transactions | mTLS + On-chain RSA/ECDSA node certificate verification |
| **Tampering** | Altering posted double-entry ledger entries | Cryptographic block hashing & PostgreSQL immutable append-only logs |
| **Repudiation** | Institution denying payment authorization | Signed instruction payloads with nonces & JST audit trails |
| **Information Disclosure** | Leakage of private settlement flows | Role-based data masking & encrypted database storage |
| **Denial of Service** | Transaction spamming by validator | Gas-metering in JSC units + rate limiting per node ID |
| **Elevation of Privilege** | Maker self-approving issuance proposal | Strict RBAC enforcement & DB trigger checks prohibiting self-approval |
