# Operations & Emergency Protocols — JSB

## 1. Reserve Reconciliation Runbook

1. Automated hourly job queries BOJ open-banking APIs & Custodian trust balances.
2. Adjusts market asset values with live hair-cut matrix.
3. Compares total adjusted reserves vs outstanding JSY claims in the general ledger.
4. If ARCR < 102.5%, sends automated Slack/PagerDuty alert and places JSY issuance engine into `WARN` state.
5. If ARCR < 100.0%, automatically triggers `EMERGENCY_MINT_FREEZE`.

## 2. Validator Slashing Procedure

When a node misses >100 blocks or double signs:
1. Consensus engine generates proof of fault.
2. System broadcasts slash event to all validators.
3. Node status set to `JAILED` or `SLASHED`.
4. Governance committee notifies institution compliance team.
