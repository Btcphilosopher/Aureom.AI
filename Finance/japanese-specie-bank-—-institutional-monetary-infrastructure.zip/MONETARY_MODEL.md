# Monetary Model & Instrument Taxonomy — Japanese Specie Bank

## 1. Instrument Taxonomy & Separation Rules

JSB strictly isolates three instrument classes to preserve legal clarity and prevent cross-contagion:

| Property | JSB Yen Claim (JSY) | Tokenised Deposit (JTD) | Settlement Credit (JSC) |
|---|---|---|---|
| **Legal Status** | Electronic Payment Claim (PSA Art 2(5)) | Commercial Bank Liability | Sandbox Settlement Exposure |
| **Issuer** | JSB Issuer Special Purpose Vehicle | Participating Commercial Bank (e.g. MUFG) | JSB Clearinghouse Engine |
| **Target Value** | 1 JSY = ¥1.00 | 1 JTD = ¥1.00 (Bank Credit) | ¥1.00 Net Credit Unit |
| **Backing Model** | 100%+ BOJ Cash + Short JGBs + Repo | Commercial Bank Balance Sheet | Bilateral Pledged Collateral |
| **Transferability** | Sandbox Allowlisted Institutions | Interbank Settlement Network | Bilateral Counterparties |
| **Redemption Term** | Immediate T+0 On-Demand Cash | Commercial Bank Account Credit | End-of-Day Net Clearing |

## 2. Reserve hair-cut & Coverage Mathematics

Reserves backing JSY liabilities are subjected to risk haircuts before calculating the **Adjusted Reserve Coverage Ratio (ARCR)**:

$$\text{Adjusted Reserves} = \sum_{i} \left( \text{Asset Market Value}_i \times (1 - \text{Haircut}_i) \right)$$

$$\text{ARCR} = \frac{\text{Adjusted Reserves}}{\text{Total JSY Liabilities Outstanding}}$$

- **BOJ Central Bank Cash / Deposits**: Haircut = 0.0%
- **Short-Dated JGBs (<2 Years)**: Haircut = 2.0%
- **Medium-Dated JGBs (2–5 Years)**: Haircut = 4.5%
- **Triparty Gensaki Repo Claims**: Haircut = 3.0%
- **Commercial Bank Certificates of Deposit**: Haircut = 4.0%

Min Target ARCR: **102.5%** (Failsafe threshold triggers automatic mint freeze).

## 3. Integer Monetary Arithmetic & Replay Protection

To prevent rounding bugs and floating-point drift, all balance calculations are conducted strictly in **Integer Yen (JPY)**:
- 1 JSY = `1` internal integer unit.
- Sub-yen precision (if needed for interest accrual) uses fixed-point scale factor `10^6` (micro-yen).
- All journal entries enforce:

$$\sum \text{Debits} - \sum \text{Credits} = 0$$
