# Legal and Regulatory Assumptions — JSB Framework

## 1. Japanese Regulatory Scope

- **Payment Services Act (PSA - 資金決済法)**: JSY claims are structured under the amended Payment Services Act governing Electronic Payment Instruments (電子決済手段). JSB operates as a Type 1 Electronic Payment Instruments Clearing Service Provider.
- **Banking Act (銀行法)**: JTD (Tokenised Deposits) are issued solely by licensed commercial banks under Bank Act Article 2 provisions. JSB does not take commercial deposits on its own balance sheet.
- **Financial Instruments and Exchange Act (FIEA - 金融商品取引法)**: Short-dated JGB collateral and repo clearing operations adhere to JSDA (Japan Securities Dealers Association) transaction rules.

## 2. Sandbox Disclaimer

*Disclaimer: This codebase is an institutional sandbox simulator and technology demonstration platform. It does not constitute a licensed bank, money transfer provider, or financial exchange under Japanese law. Production deployment requires authorization from the Financial Services Agency (FSA / 金融庁) and Bank of Japan (BOJ).*
