# Proof-of-Stake Consensus & Settlement Finality — JSB

## 1. Permissioned Proof-of-Stake Model (PBFT-PoS Hybrid)

The JSB network utilizes a permissioned Byzantine Fault Tolerant Proof-of-Stake consensus mechanism designed for institutional high-throughput settlement:

- **Validator Eligibility**: Only FSA-approved financial institutions with registered public key infrastructure (PKI) certificates can register as validators.
- **Staking & Voting Weight**: Voting weight is directly proportional to bonded JPY collateral staked on-chain. Minimum stake requirement: ¥500,000,000.
- **Block Production**: Round-robin leader selection weighted by active stake.
- **BFT Finality**: 2-step attestation (Prepare + Commit). Requires >66.7% weighted vote approval for block confirmation.
- **Block Time & Target Throughput**: Target block duration 1,000 ms; throughput cap 10,000 transactions per second.

## 2. Slashing & Fault Conditions

Validators are subjected to automated slashing penalties:
- **Equivocation (Double Signing)**: 20% stake slash + immediate permanent node ejection.
- **Liveness Fault (Missed >100 consecutive blocks)**: 0.5% stake slash + 24-hour jail sentence.
- **Invalid State Transition Proposal**: 5% stake slash + manual governance review.
