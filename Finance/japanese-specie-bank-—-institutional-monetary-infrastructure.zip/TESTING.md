# Testing & Invariant Validation — JSB

## Invariant Test Suite

The JSB test suite validates key monetary and ledger invariants:

1. **Ledger Symmetry**: Every posted transaction satisfies $\sum \text{Debits} = \sum \text{Credits}$.
2. **Integer Arithmetic**: Ensures zero float rounding error in JPY balance math.
3. **Reserve Sufficiency**: JSY issuance fails closed if eligible reserve coverage is below 100%.
4. **Maker-Checker Isolation**: Prohibits identical user ID for proposal creation and proposal approval.
5. **Validator Slashing**: Verified double-signature proofs correctly deduct stake and lock validator accounts.

Run automated build and lint checks:
```bash
npm run lint
npm run build
```
