/**
 * Japanese Specie Bank (JSB) — Domain Type Definitions
 */

export type InstrumentType = 'JSY' | 'JTD' | 'JSC';

// 1. Core Instruments
export interface JSYClaim {
  id: string;
  instrument: 'JSY';
  issuer: string;
  legalClassification: string;
  targetPeg: number; // Always 1.00
  totalSupplyJPY: bigint;
  redeemableLiabilitiesJPY: bigint;
  backingModel: string;
  redemptionPolicy: string;
  reserveCoverageRatio: number;
  lastReconciledAt: string;
  status: 'ACTIVE' | 'WARNING' | 'FROZEN';
}

export interface JTDDeposit {
  id: string;
  instrument: 'JTD';
  issuingBankBIC: string;
  bankName: string;
  bankNameJP: string;
  accountNumber: string;
  holderInstitution: string;
  balanceJPY: bigint;
  settlementEligibility: boolean;
  transferCondition: string;
  lastUpdated: string;
}

export interface JSCSettlementCredit {
  id: string;
  instrument: 'JSC';
  counterpartyId: string;
  counterpartyName: string;
  creditLimitJPY: bigint;
  utilizedJPY: bigint;
  availableJPY: bigint;
  collateralHaircutPct: number;
  maturityDate: string;
  exposureStatus: 'NORMAL' | 'ELEVATED' | 'DEFAULT_WARNING';
}

// 2. Double-Entry Accounting
export type AccountCategory = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE' | 'SUSPENSE';

export interface LedgerAccount {
  accountNumber: string;
  name: string;
  nameJP: string;
  category: AccountCategory;
  balanceJPY: bigint;
  debitsJPY: bigint;
  creditsJPY: bigint;
  isAuthoritative: boolean;
}

export interface GeneralLedgerEntry {
  id: string;
  transactionId: string;
  timestampJST: string;
  debitAccount: string;
  debitAccountName: string;
  creditAccount: string;
  creditAccountName: string;
  amountJPY: bigint;
  instrument: InstrumentType;
  counterparty: string;
  authorizer: string;
  memo: string;
  status: 'POSTED' | 'REVERSED' | 'PENDING';
  reversalRefId?: string;
}

// 3. PoS Validator Network
export interface PoSValidator {
  id: string;
  institutionName: string;
  institutionNameJP: string;
  nodePublicKey: string;
  stakeJPY: bigint;
  stakeSharePct: number;
  status: 'ACTIVE' | 'PENDING' | 'JAILED' | 'SLASHED';
  uptimePct: number;
  blocksProposed: number;
  missedAttestations: number;
  slashingEvents: number;
  lastAttestedBlock: number;
}

export interface ConsensusState {
  currentBlockHeight: number;
  blockHash: string;
  previousHash: string;
  tps: number;
  finalityMs: number;
  activeValidators: number;
  consensusMechanism: string;
  faultTolerance: string;
  networkStatus: 'OPERATIONAL' | 'DEGRADED' | 'PAUSED';
}

// 4. Reserve & Collateral Management
export interface ReserveAsset {
  id: string;
  assetClass: 'BOJ_CASH' | 'JGB_SHORT' | 'JGB_MEDIUM' | 'GENSAKI_REPO' | 'BANK_CD';
  description: string;
  isinOrRef: string;
  nominalValueJPY: bigint;
  marketValueJPY: bigint;
  haircutPct: number;
  adjustedEligibleValueJPY: bigint;
  custodian: string;
  encumbranceStatus: 'UNENCUMBERED' | 'PLEDGED_REPO';
  maturityDate: string;
  liquidityTier: 'TIER_1_IMMEDIATE' | 'TIER_2_T1_CLEARING' | 'TIER_3_T2_CLEARING';
  verificationSource: string;
  lastValuationJST: string;
}

export interface StressScenarioResult {
  scenarioId: string;
  scenarioName: string;
  description: string;
  simulatedRedemptionPct: number;
  jgbYieldShiftBps: number;
  custodianOutageDays: number;
  projectedCoverageRatio: number;
  liquidityShortfallJPY: bigint;
  riskRating: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
}

// 5. Issuance & Redemption Proposals
export interface IssuanceProposal {
  id: string;
  type: 'MINT' | 'BURN';
  instrument: InstrumentType;
  amountJPY: bigint;
  proposerId: string;
  proposerName: string;
  approverId?: string;
  approverName?: string;
  backingAssetId: string;
  legalJustification: string;
  createdAtJST: string;
  status: 'PROPOSED' | 'APPROVED' | 'REJECTED' | 'EXECUTED';
  executionTxId?: string;
}

// 6. Payment & DvP Settlement Instructions
export type PaymentStatus = 'PENDING' | 'APPROVED' | 'SUBMITTED' | 'CONFIRMED' | 'REJECTED' | 'REVERSED';

export interface PaymentInstruction {
  instructionId: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  instrument: InstrumentType;
  amountJPY: bigint;
  dvpSecurityRef?: string;
  settlementMode: 'GROSS_T0' | 'NET_BATCH_EOD' | 'DVP_SIMULATION';
  createdJST: string;
  settledJST?: string;
  status: PaymentStatus;
  complianceScreened: boolean;
  blockHeightConfirmed?: number;
}

// 7. Market Reference Data
export interface JGBYieldPoint {
  tenor: string;
  yieldPct: number;
  changeBps: number;
}

export interface MarketQuotes {
  usdjpy: number;
  eurjpy: number;
  gbpjpy: number;
  tonaRatePct: number;
  mutanRatePct: number;
  genkatsuRepoPct: number;
  jgbYieldCurve: JGBYieldPoint[];
  updatedAtJST: string;
}

// 8. Compliance & Governance
export interface ComplianceRecord {
  institutionId: string;
  name: string;
  kybStatus: 'VERIFIED' | 'PENDING' | 'SUSPENDED';
  sanctionsMatch: boolean;
  allowlistStatus: 'APPROVED' | 'BLOCKED';
  dailyLimitJPY: bigint;
  utilizedLimitJPY: bigint;
  riskScore: number;
}

export interface GovernanceVote {
  proposalId: string;
  title: string;
  category: 'PARAMETER_CHANGE' | 'NEW_VALIDATOR' | 'EMERGENCY_PAUSE';
  proposedBy: string;
  votesForStakeJPY: bigint;
  votesAgainstStakeJPY: bigint;
  thresholdStakeJPY: bigint;
  expiresAtJST: string;
  status: 'OPEN' | 'PASSED' | 'FAILED' | 'EXECUTED';
}

export interface AuditLogItem {
  id: string;
  timestampJST: string;
  actor: string;
  role: string;
  action: string;
  details: string;
  ipHash: string;
  signature: string;
}
