/**
 * Japanese Specie Bank (JSB) — Institutional Monetary Terminal
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar, NavTab } from './components/Sidebar';
import { OverviewView } from './components/views/OverviewView';
import { InstrumentsView } from './components/views/InstrumentsView';
import { IssuanceView } from './components/views/IssuanceView';
import { ValidatorsView } from './components/views/ValidatorsView';
import { ReservesView } from './components/views/ReservesView';
import { SettlementView } from './components/views/SettlementView';
import { MarketsView } from './components/views/MarketsView';
import { RiskView } from './components/views/RiskView';
import { AccountingView } from './components/views/AccountingView';
import { ComplianceView } from './components/views/ComplianceView';
import { GovernanceView } from './components/views/GovernanceView';
import { AuditView } from './components/views/AuditView';
import { AdminView } from './components/views/AdminView';
import { ProposalModal } from './components/modals/ProposalModal';
import { PaymentModal } from './components/modals/PaymentModal';
import { monetaryStore } from './services/monetaryStore';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('overview');
  const [isIssuanceModalOpen, setIsIssuanceModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [storeState, setStoreState] = useState(monetaryStore.getState());

  useEffect(() => {
    const unsubscribe = monetaryStore.subscribe(() => {
      setStoreState(monetaryStore.getState());
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const pendingProposalsCount = storeState.proposals.filter((p) => p.status === 'PROPOSED').length;

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col font-sans text-slate-900 antialiased selection:bg-red-700 selection:text-white">
      {/* Header Bar */}
      <Header
        status={storeState.consensus.networkStatus}
        blockHeight={storeState.consensus.currentBlockHeight}
        tps={storeState.consensus.tps}
        onOpenIssuanceModal={() => setIsIssuanceModalOpen(true)}
        onOpenPaymentModal={() => setIsPaymentModalOpen(true)}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar Navigation */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          unresolvedCount={pendingProposalsCount}
        />

        {/* Content View */}
        <main className="flex-1 overflow-y-auto bg-[#F8F9FA]">
          {currentTab === 'overview' && (
            <OverviewView
              onSelectTab={setCurrentTab}
              onOpenIssuanceModal={() => setIsIssuanceModalOpen(true)}
              onOpenPaymentModal={() => setIsPaymentModalOpen(true)}
            />
          )}

          {currentTab === 'instruments' && <InstrumentsView />}

          {currentTab === 'issuance' && (
            <IssuanceView onOpenModal={() => setIsIssuanceModalOpen(true)} />
          )}

          {currentTab === 'validators' && <ValidatorsView />}

          {currentTab === 'reserves' && <ReservesView />}

          {currentTab === 'settlement' && (
            <SettlementView onOpenModal={() => setIsPaymentModalOpen(true)} />
          )}

          {currentTab === 'markets' && <MarketsView />}

          {currentTab === 'risk' && <RiskView />}

          {currentTab === 'accounting' && <AccountingView />}

          {currentTab === 'compliance' && <ComplianceView />}

          {currentTab === 'governance' && <GovernanceView />}

          {currentTab === 'audit' && <AuditView />}

          {currentTab === 'admin' && <AdminView />}
        </main>
      </div>

      {/* Interactive Modals */}
      <ProposalModal
        isOpen={isIssuanceModalOpen}
        onClose={() => setIsIssuanceModalOpen(false)}
      />

      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
      />
    </div>
  );
}
