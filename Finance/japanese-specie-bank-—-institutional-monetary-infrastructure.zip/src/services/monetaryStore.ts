import {
  JSYClaim,
  JTDDeposit,
  JSCSettlementCredit,
  LedgerAccount,
  GeneralLedgerEntry,
  PoSValidator,
  ConsensusState,
  ReserveAsset,
  StressScenarioResult,
  IssuanceProposal,
  PaymentInstruction,
  MarketQuotes,
  ComplianceRecord,
  GovernanceVote,
  AuditLogItem,
  InstrumentType,
} from '../types';
import {
  INITIAL_JSY,
  INITIAL_JTD_LIST,
  INITIAL_JSC_LIST,
  INITIAL_ACCOUNTS,
  INITIAL_GL_ENTRIES,
  INITIAL_VALIDATORS,
  INITIAL_CONSENSUS,
  INITIAL_RESERVES,
  INITIAL_STRESS_SCENARIOS,
  INITIAL_PROPOSALS,
  INITIAL_PAYMENTS,
  INITIAL_MARKETS,
  INITIAL_COMPLIANCE,
  INITIAL_VOTES,
  INITIAL_AUDIT_LOGS,
} from './mockData';

class MonetaryStore {
  private jsy: JSYClaim = { ...INITIAL_JSY };
  private jtdList: JTDDeposit[] = [...INITIAL_JTD_LIST];
  private jscList: JSCSettlementCredit[] = [...INITIAL_JSC_LIST];
  private accounts: LedgerAccount[] = [...INITIAL_ACCOUNTS];
  private glEntries: GeneralLedgerEntry[] = [...INITIAL_GL_ENTRIES];
  private validators: PoSValidator[] = [...INITIAL_VALIDATORS];
  private consensus: ConsensusState = { ...INITIAL_CONSENSUS };
  private reserves: ReserveAsset[] = [...INITIAL_RESERVES];
  private stressScenarios: StressScenarioResult[] = [...INITIAL_STRESS_SCENARIOS];
  private proposals: IssuanceProposal[] = [...INITIAL_PROPOSALS];
  private payments: PaymentInstruction[] = [...INITIAL_PAYMENTS];
  private markets: MarketQuotes = { ...INITIAL_MARKETS };
  private complianceRecords: ComplianceRecord[] = [...INITIAL_COMPLIANCE];
  private votes: GovernanceVote[] = [...INITIAL_VOTES];
  private auditLogs: AuditLogItem[] = [...INITIAL_AUDIT_LOGS];
  private subscribers: Set<() => void> = new Set();
  private blockInterval: any = null;

  constructor() {
    this.recalculateReservesAndCoverage();
    this.startBlockTicker();
  }

  public subscribe(callback: () => void) {
    this.subscribers.add(callback);
    return () => this.subscribers.delete(callback);
  }

  private notify() {
    this.subscribers.forEach((cb) => cb());
  }

  // --- Real-Time Block Production Ticker ---
  private startBlockTicker() {
    if (this.blockInterval) return;
    this.blockInterval = setInterval(() => {
      if (this.consensus.networkStatus === 'PAUSED') return;

      this.consensus.currentBlockHeight += 1;
      this.consensus.tps = 2700 + Math.floor(Math.random() * 400);
      this.consensus.finalityMs = 110 + Math.floor(Math.random() * 20);

      const randomBytes = Array.from({ length: 16 }, () =>
        Math.floor(Math.random() * 256).toString(16).padStart(2, '0')
      ).join('');
      this.consensus.previousHash = this.consensus.blockHash;
      this.consensus.blockHash = `0x${randomBytes}${Date.now().toString(16)}`;

      // Update active validator blocks proposed
      const activeVals = this.validators.filter((v) => v.status === 'ACTIVE');
      if (activeVals.length > 0) {
        const leader = activeVals[this.consensus.currentBlockHeight % activeVals.length];
        leader.blocksProposed += 1;
        leader.lastAttestedBlock = this.consensus.currentBlockHeight;
      }

      this.notify();
    }, 2500);
  }

  // --- Calculations & Invariants ---

  public recalculateReservesAndCoverage() {
    let totalAdjustedJPY = BigInt(0);

    this.reserves.forEach((asset) => {
      // Adjusted = MarketValue * (1 - Haircut%)
      const haircutFactor = (1000 - Math.round(asset.haircutPct * 10)) / 1000;
      const adjusted = BigInt(Math.floor(Number(asset.marketValueJPY) * haircutFactor));
      asset.adjustedEligibleValueJPY = adjusted;
      totalAdjustedJPY += adjusted;
    });

    const liabilities = this.jsy.totalSupplyJPY > BigInt(0) ? this.jsy.totalSupplyJPY : BigInt(1);
    const coverageRatio = (Number(totalAdjustedJPY) / Number(liabilities)) * 100;
    this.jsy.reserveCoverageRatio = Math.round(coverageRatio * 10) / 10;
    this.jsy.lastReconciledAt = `${new Date().toISOString().replace('T', ' ').substring(0, 19)} JST`;
  }

  public getTrialBalance() {
    let totalDebits = BigInt(0);
    let totalCredits = BigInt(0);

    this.accounts.forEach((acc) => {
      totalDebits += acc.debitsJPY;
      totalCredits += acc.creditsJPY;
    });

    return {
      totalDebits,
      totalCredits,
      isBalanced: totalDebits === totalCredits,
      imbalanceAmountJPY: totalDebits > totalCredits ? totalDebits - totalCredits : totalCredits - totalDebits,
    };
  }

  // --- Getters ---

  public getState() {
    return {
      jsy: this.jsy,
      jtdList: this.jtdList,
      jscList: this.jscList,
      accounts: this.accounts,
      glEntries: this.glEntries,
      validators: this.validators,
      consensus: this.consensus,
      reserves: this.reserves,
      stressScenarios: this.stressScenarios,
      proposals: this.proposals,
      payments: this.payments,
      markets: this.markets,
      complianceRecords: this.complianceRecords,
      votes: this.votes,
      auditLogs: this.auditLogs,
      trialBalance: this.getTrialBalance(),
    };
  }

  // --- Actions ---

  // 1. Dual-Control Proposal Creation & Execution
  public createIssuanceProposal(params: {
    type: 'MINT' | 'BURN';
    instrument: InstrumentType;
    amountJPY: bigint;
    proposerName: string;
    backingAssetId: string;
    legalJustification: string;
  }) {
    const proposal: IssuanceProposal = {
      id: `PROP-${params.type}-${Date.now().toString().slice(-6)}`,
      type: params.type,
      instrument: params.instrument,
      amountJPY: params.amountJPY,
      proposerId: 'USER-TREASURY-MAKER',
      proposerName: params.proposerName,
      backingAssetId: params.backingAssetId,
      legalJustification: params.legalJustification,
      createdAtJST: `${new Date().toISOString().replace('T', ' ').substring(0, 19)} JST`,
      status: 'PROPOSED',
    };

    this.proposals.unshift(proposal);
    this.logAudit(
      params.proposerName,
      'TREASURY_OFFICER',
      `PROPOSE_${params.type}`,
      `Created ${params.type} proposal ${proposal.id} for ¥${params.amountJPY.toLocaleString()} JPY`
    );
    this.notify();
    return proposal;
  }

  public approveAndExecuteProposal(proposalId: string, approverName: string) {
    const prop = this.proposals.find((p) => p.id === proposalId);
    if (!prop || prop.status !== 'PROPOSED') return false;

    // Maker-Checker Invariant check: Approver must be distinct from Proposer
    if (prop.proposerName === approverName) {
      throw new Error('Maker-Checker Security Violation: Approver cannot be identical to the Proposer.');
    }

    prop.status = 'APPROVED';
    prop.approverId = 'USER-COMPLIANCE-CHECKER';
    prop.approverName = approverName;

    // Execute ledger entry
    const txId = `TX-EXEC-${Date.now().toString().slice(-6)}`;
    prop.executionTxId = txId;
    prop.status = 'EXECUTED';

    if (prop.type === 'MINT') {
      this.jsy.totalSupplyJPY += prop.amountJPY;
      this.jsy.redeemableLiabilitiesJPY += prop.amountJPY;

      // Double-entry record
      const debitAcc = this.accounts.find((a) => a.accountNumber === '1010')!;
      const creditAcc = this.accounts.find((a) => a.accountNumber === '2010')!;

      debitAcc.balanceJPY += prop.amountJPY;
      debitAcc.debitsJPY += prop.amountJPY;
      creditAcc.balanceJPY += prop.amountJPY;
      creditAcc.creditsJPY += prop.amountJPY;

      this.glEntries.unshift({
        id: `GLE-${Date.now()}`,
        transactionId: txId,
        timestampJST: `${new Date().toISOString().replace('T', ' ').substring(0, 19)} JST`,
        debitAccount: '1010',
        debitAccountName: debitAcc.name,
        creditAccount: '2010',
        creditAccountName: creditAcc.name,
        amountJPY: prop.amountJPY,
        instrument: prop.instrument,
        counterparty: prop.proposerName,
        authorizer: `${prop.proposerName} (Maker) / ${approverName} (Checker)`,
        memo: `Dual-control approved minting of ${prop.instrument}`,
        status: 'POSTED',
      });
    } else {
      // BURN
      this.jsy.totalSupplyJPY -= prop.amountJPY;
      this.jsy.redeemableLiabilitiesJPY -= prop.amountJPY;

      const debitAcc = this.accounts.find((a) => a.accountNumber === '2010')!;
      const creditAcc = this.accounts.find((a) => a.accountNumber === '1010')!;

      debitAcc.debitsJPY += prop.amountJPY;
      creditAcc.creditsJPY += prop.amountJPY;

      this.glEntries.unshift({
        id: `GLE-${Date.now()}`,
        transactionId: txId,
        timestampJST: `${new Date().toISOString().replace('T', ' ').substring(0, 19)} JST`,
        debitAccount: '2010',
        debitAccountName: debitAcc.name,
        creditAccount: '1010',
        creditAccountName: creditAcc.name,
        amountJPY: prop.amountJPY,
        instrument: prop.instrument,
        counterparty: prop.proposerName,
        authorizer: `${prop.proposerName} (Maker) / ${approverName} (Checker)`,
        memo: `Dual-control approved redemption & burn of ${prop.instrument}`,
        status: 'POSTED',
      });
    }

    this.recalculateReservesAndCoverage();
    this.logAudit(
      approverName,
      'COMPLIANCE_DIRECTOR',
      `APPROVE_${prop.type}`,
      `Executed proposal ${prop.id} for ¥${prop.amountJPY.toLocaleString()} JPY (${prop.instrument})`
    );
    this.notify();
    return true;
  }

  // 2. Submit Payment & Settle Instruction
  public submitPaymentInstruction(params: {
    senderName: string;
    receiverName: string;
    instrument: InstrumentType;
    amountJPY: bigint;
    settlementMode: 'GROSS_T0' | 'NET_BATCH_EOD' | 'DVP_SIMULATION';
    dvpRef?: string;
  }) {
    const instId = `PAY-${Date.now().toString().slice(-6)}`;
    const instruction: PaymentInstruction = {
      instructionId: instId,
      senderId: `INST-${params.senderName.replace(/\s+/g, '-').toUpperCase()}`,
      senderName: params.senderName,
      receiverId: `INST-${params.receiverName.replace(/\s+/g, '-').toUpperCase()}`,
      receiverName: params.receiverName,
      instrument: params.instrument,
      amountJPY: params.amountJPY,
      settlementMode: params.settlementMode,
      dvpSecurityRef: params.dvpRef,
      createdJST: `${new Date().toISOString().replace('T', ' ').substring(0, 19)} JST`,
      status: 'APPROVED',
      complianceScreened: true,
    };

    this.payments.unshift(instruction);
    this.logAudit(
      params.senderName,
      'TREASURY_OPERATOR',
      'PAYMENT_INSTRUCTION_CREATED',
      `Instruction ${instId} submitted for ¥${params.amountJPY.toLocaleString()} (${params.instrument})`
    );

    // Immediate Settlement Simulation
    setTimeout(() => {
      instruction.status = 'CONFIRMED';
      instruction.settledJST = `${new Date().toISOString().replace('T', ' ').substring(0, 19)} JST`;
      instruction.blockHeightConfirmed = this.consensus.currentBlockHeight;

      this.logAudit(
        'JSB_POS_CONSENSUS',
        'SYSTEM',
        'PAYMENT_SETTLED_CONFIRMED',
        `Instruction ${instId} confirmed on PoS Block #${instruction.blockHeightConfirmed}`
      );
      this.notify();
    }, 1500);

    this.notify();
    return instruction;
  }

  // 3. PoS Validator Slashing Simulation
  public slashValidator(validatorId: string, reason: string) {
    const val = this.validators.find((v) => v.id === validatorId);
    if (!val) return false;

    val.status = 'SLASHED';
    val.slashingEvents += 1;
    const penaltyJPY = (val.stakeJPY * BigInt(20)) / BigInt(100); // 20% slash
    val.stakeJPY -= penaltyJPY;

    this.logAudit(
      'BOJ_GOVERNANCE_ENGINE',
      'CONSENSUS_ADMIN',
      'VALIDATOR_SLASHED',
      `Slashed node ${val.institutionName} by 20% (¥${penaltyJPY.toLocaleString()} penalty). Reason: ${reason}`
    );
    this.notify();
    return true;
  }

  // 4. Governance Emergency Pause
  public toggleEmergencyPause() {
    if (this.consensus.networkStatus === 'OPERATIONAL') {
      this.consensus.networkStatus = 'PAUSED';
      this.logAudit(
        'CHIEF_RISK_OFFICER',
        'ADMIN',
        'EMERGENCY_NETWORK_PAUSED',
        'Activated emergency network halt on JSB PoS settlement layer.'
      );
    } else {
      this.consensus.networkStatus = 'OPERATIONAL';
      this.logAudit(
        'CHIEF_RISK_OFFICER',
        'ADMIN',
        'NETWORK_RESUMED',
        'Resumed JSB PoS settlement operations.'
      );
    }
    this.notify();
  }

  // 5. Stress Test Execution
  public runStressTestScenario(scenarioId: string) {
    const scenario = this.stressScenarios.find((s) => s.scenarioId === scenarioId);
    if (!scenario) return;

    // R-model execution simulation
    const redemptionLoss = (this.jsy.totalSupplyJPY * BigInt(Math.floor(scenario.simulatedRedemptionPct))) / BigInt(100);
    const updatedLiabilities = this.jsy.totalSupplyJPY - redemptionLoss;
    const yieldHaircutIncrease = (scenario.jgbYieldShiftBps / 100) * 0.02; // 2% additional haircut per 100bps

    let totalSimReserves = BigInt(0);
    this.reserves.forEach((asset) => {
      const simHaircut = asset.haircutPct + yieldHaircutIncrease * 100;
      const factor = (1000 - Math.round(simHaircut * 10)) / 1000;
      totalSimReserves += BigInt(Math.floor(Number(asset.marketValueJPY) * factor));
    });

    const newCov = (Number(totalSimReserves) / Number(updatedLiabilities || 1)) * 100;
    scenario.projectedCoverageRatio = Math.round(newCov * 10) / 10;

    this.logAudit(
      'R_RISK_ANALYTICS_ENGINE',
      'ANALYST',
      'STRESS_TEST_EXECUTED',
      `Ran Monte Carlo scenario ${scenario.scenarioName}. Projected Coverage: ${scenario.projectedCoverageRatio}%`
    );
    this.notify();
  }

  // Helper: Log audit trail
  private logAudit(actor: string, role: string, action: string, details: string) {
    const logItem: AuditLogItem = {
      id: `AUD-${Math.floor(100000 + Math.random() * 900000)}`,
      timestampJST: `${new Date().toISOString().replace('T', ' ').substring(0, 19)} JST`,
      actor,
      role,
      action,
      details,
      ipHash: '127.0.0.1 (mTLS Authorized)',
      signature: `0x${Array.from({ length: 8 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
    };
    this.auditLogs.unshift(logItem);
  }
}

export const monetaryStore = new MonetaryStore();
