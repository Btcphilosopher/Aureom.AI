import React, { useState, useEffect } from 'react';
import { ShieldCheck, Clock, Building2, AlertTriangle } from 'lucide-react';

interface HeaderProps {
  status: 'OPERATIONAL' | 'DEGRADED' | 'PAUSED';
  blockHeight: number;
  tps: number;
  onOpenIssuanceModal: () => void;
  onOpenPaymentModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  status,
  blockHeight,
  tps,
  onOpenIssuanceModal,
  onOpenPaymentModal,
}) => {
  const [jstTime, setJstTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Format to JST (UTC+9)
      const options: Intl.DateTimeFormatOptions = {
        timeZone: 'Asia/Tokyo',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      };
      setJstTime(new Intl.DateTimeFormat('ja-JP', options).format(now) + ' JST');
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 bg-red-700 text-white font-bold flex items-center justify-center rounded-xs text-sm tracking-widest shadow-xs">
          正
        </div>
        <div>
          <a href="/" className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap block">
            JAPANESE SPECIE BANK
          </a>
          <span className="text-xs text-slate-500 font-medium tracking-wider block">
            日本正金銀行 · MONETARY INFRASTRUCTURE
          </span>
        </div>
      </div>

      {/* Zone 2: Real-time JST Clock & Network Telemetry */}
      <div className="hidden lg:flex items-center gap-6 text-xs font-mono text-slate-600 bg-slate-50 px-4 py-1.5 rounded-sm border border-slate-200">
        <div className="flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>{jstTime || '2026-10-27 15:30:00 JST'}</span>
        </div>
        <span className="text-slate-300">|</span>
        <div className="flex items-center gap-1.5">
          <Building2 className="w-3.5 h-3.5 text-slate-400" />
          <span>PoS HEIGHT: #{blockHeight.toLocaleString()}</span>
        </div>
        <span className="text-slate-300">|</span>
        <div className="flex items-center gap-1.5">
          <span>TPS: {tps.toLocaleString()}</span>
        </div>
        <span className="text-slate-300">|</span>
        <div className="flex items-center gap-1.5 font-semibold">
          {status === 'OPERATIONAL' ? (
            <span className="text-emerald-700 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> SYSTEM OPERATIONAL
            </span>
          ) : (
            <span className="text-amber-700 flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" /> PAUSED / HALTED
            </span>
          )}
        </div>
      </div>

      {/* Zone 3: Primary Action Buttons */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          onClick={onOpenIssuanceModal}
          className="px-3.5 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-sm border border-slate-300 transition-colors whitespace-nowrap shrink-0"
        >
          + Propose Issuance / Burn
        </button>
        <button
          onClick={onOpenPaymentModal}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-red-700 hover:bg-red-800 rounded-sm shadow-xs transition-colors whitespace-nowrap shrink-0"
        >
          Create Settlement
        </button>
      </div>
    </header>
  );
};
