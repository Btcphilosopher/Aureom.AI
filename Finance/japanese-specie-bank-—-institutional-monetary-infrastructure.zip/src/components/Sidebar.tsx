import React from 'react';
import {
  LayoutDashboard,
  Coins,
  ArrowLeftRight,
  Cpu,
  ShieldCheck,
  Send,
  TrendingUp,
  Activity,
  BookOpen,
  FileCheck,
  Vote,
  FileText,
  Server,
} from 'lucide-react';

export type NavTab =
  | 'overview'
  | 'instruments'
  | 'issuance'
  | 'validators'
  | 'reserves'
  | 'settlement'
  | 'markets'
  | 'risk'
  | 'accounting'
  | 'compliance'
  | 'governance'
  | 'audit'
  | 'admin';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  unresolvedCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, onSelectTab, unresolvedCount = 0 }) => {
  const menuItems: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string }[] = [
    { id: 'overview', label: '1. Executive Overview', icon: LayoutDashboard },
    { id: 'instruments', label: '2. Yen Instruments', icon: Coins },
    { id: 'issuance', label: '3. Issuance & Redemption', icon: ArrowLeftRight },
    { id: 'validators', label: '4. Validator Network', icon: Cpu },
    { id: 'reserves', label: '5. Reserves & Collateral', icon: ShieldCheck },
    { id: 'settlement', label: '6. Settlement & DvP', icon: Send },
    { id: 'markets', label: '7. Yen Markets', icon: TrendingUp },
    { id: 'risk', label: '8. Risk & Liquidity', icon: Activity },
    { id: 'accounting', label: '9. Accounting Ledger', icon: BookOpen },
    { id: 'compliance', label: '10. Compliance & KYB', icon: FileCheck },
    { id: 'governance', label: '11. Governance & Slashing', icon: Vote },
    { id: 'audit', label: '12. Audit & Reporting', icon: FileText },
    { id: 'admin', label: '13. System Admin', icon: Server },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-200 flex flex-col shrink-0 border-r border-slate-800">
      <div className="p-4 border-b border-slate-800">
        <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
          Monetary Navigation
        </div>
        <div className="text-xs text-slate-500 mt-1">
          Permissioned Institutional Access
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-xs transition-colors text-left ${
                isActive
                  ? 'bg-red-700 text-white font-semibold shadow-xs'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </div>
              {item.id === 'issuance' && unresolvedCount > 0 && (
                <span className="ml-2 px-1.5 py-0.5 text-[10px] font-bold bg-amber-500 text-slate-950 rounded-xs">
                  {unresolvedCount}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800 bg-slate-950 text-[11px] text-slate-400 font-mono">
        <div className="flex items-center justify-between text-slate-300">
          <span>INSTITUTION:</span>
          <span className="font-semibold text-slate-200">BOJ_SANDBOX</span>
        </div>
        <div className="flex items-center justify-between mt-1 text-slate-300">
          <span>ROLE:</span>
          <span className="text-red-400 font-semibold">TREASURY_MAKER</span>
        </div>
        <div className="mt-3 pt-2 border-t border-slate-800 text-[10px] text-slate-400 leading-tight">
          JSB Monetary Engine v3.6
          <br />
          Integer JPY Standard (No-Float)
        </div>
      </div>
    </aside>
  );
};
