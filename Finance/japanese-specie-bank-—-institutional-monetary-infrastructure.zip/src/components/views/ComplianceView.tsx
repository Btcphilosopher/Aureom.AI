import React from 'react';
import { FileCheck, Shield, AlertTriangle, UserCheck } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

export const ComplianceView: React.FC = () => {
  const state = monetaryStore.getState();

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          Compliance, KYB & Sanctions Framework
          <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 rounded-xs border border-slate-200">
            METI / MOF / FSA SANCTIONS
          </span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          KYB institution onboarding state, automated METI/MOF sanctions screening, counterparty allowlist, and daily transfer limits.
        </p>
      </div>

      {/* Compliance Onboarding Registry Table */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Onboarded Institutional Participant Register
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Institution ID</th>
                <th className="p-3">Legal Institution Name</th>
                <th className="p-3 text-center">KYB Verification</th>
                <th className="p-3 text-center">Sanctions Screening</th>
                <th className="p-3 text-center">Allowlist Status</th>
                <th className="p-3 text-right">Daily Limit JPY</th>
                <th className="p-3 text-right">Utilized Today</th>
                <th className="p-3 text-center">Risk Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {state.complianceRecords.map((c) => (
                <tr key={c.institutionId} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-900">{c.institutionId}</td>
                  <td className="p-3 font-sans font-semibold text-slate-900">{c.name}</td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded-xs">
                      {c.kybStatus}
                    </span>
                  </td>
                  <td className="p-3 text-center font-sans">
                    {c.sanctionsMatch ? (
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-red-100 text-red-800 rounded-xs">
                        ⚠️ MATCH FOUND
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded-xs">
                        ✓ PASSED (CLEAR)
                      </span>
                    )}
                  </td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-blue-100 text-blue-800 rounded-xs">
                      {c.allowlistStatus}
                    </span>
                  </td>
                  <td className="p-3 text-right font-bold text-slate-900">
                    ¥{c.dailyLimitJPY.toLocaleString()}
                  </td>
                  <td className="p-3 text-right text-slate-700">
                    ¥{c.utilizedLimitJPY.toLocaleString()}
                  </td>
                  <td className="p-3 text-center font-bold text-slate-800">{c.riskScore} / 100</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
