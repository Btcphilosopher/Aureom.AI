import React from 'react';
import { Server, Code2, Database, Terminal, ShieldAlert } from 'lucide-react';

export const AdminView: React.FC = () => {
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          System Administration & Multi-Stack Architecture
          <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 rounded-xs border border-slate-200">
            RUST / PYTHON / R / POSTGRES
          </span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Technical service boundaries, database connections, REST API endpoints, and sandbox runtime configuration.
        </p>
      </div>

      {/* Tech Stack Components Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="jsb-card p-4 space-y-2 border-t-2 border-t-amber-700">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800">
            <span>RUST CONSENSUS CORE</span>
            <span className="font-mono text-[10px] bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-xs">
              v1.82 CRATE
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Deterministic state transition engine, BFT block proposed verification, and integer math primitives.
          </p>
        </div>

        <div className="jsb-card p-4 space-y-2 border-t-2 border-t-blue-700">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800">
            <span>PYTHON ORCHESTRATION</span>
            <span className="font-mono text-[10px] bg-blue-100 text-blue-900 px-1.5 py-0.5 rounded-xs">
              3.12+ FASTAPI
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Dual-control issuance controls, reserve reconciliation, KYC allowlists, and FastAPI endpoints.
          </p>
        </div>

        <div className="jsb-card p-4 space-y-2 border-t-2 border-t-emerald-700">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800">
            <span>R ANALYTICS PACKAGE</span>
            <span className="font-mono text-[10px] bg-emerald-100 text-emerald-900 px-1.5 py-0.5 rounded-xs">
              v4.4 STATS
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Monte Carlo liquidity-at-risk simulation, yield curve shock sensitivity, and duration models.
          </p>
        </div>

        <div className="jsb-card p-4 space-y-2 border-t-2 border-t-purple-700">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800">
            <span>POSTGRESQL DB</span>
            <span className="font-mono text-[10px] bg-purple-100 text-purple-900 px-1.5 py-0.5 rounded-xs">
              PG 16 IMMUTABLE
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Authoritative double-entry general ledger schema, transaction logs, and system audit trail.
          </p>
        </div>
      </div>

      {/* REST API Explorer Card */}
      <div className="jsb-card p-5 space-y-4">
        <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
          <Code2 className="w-4 h-4 text-red-700" />
          Exposed REST API Endpoints Specification
        </h2>

        <div className="space-y-3 font-mono text-xs">
          <div className="p-3 bg-slate-900 text-slate-200 rounded-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-emerald-400 font-bold">GET /api/overview</span>
              <span className="text-slate-400">System Telemetry</span>
            </div>
            <div className="text-[11px] text-slate-400">
              Returns JSY supply, reserve coverage ratio, PoS consensus block height, and trial balance health status.
            </div>
          </div>

          <div className="p-3 bg-slate-900 text-slate-200 rounded-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-emerald-400 font-bold">GET /api/instruments</span>
              <span className="text-slate-400">Instrument Classification</span>
            </div>
            <div className="text-[11px] text-slate-400">
              Returns separated data models for JSY claims, commercial JTD deposits, and JSC settlement credits.
            </div>
          </div>

          <div className="p-3 bg-slate-900 text-slate-200 rounded-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-amber-400 font-bold">POST /api/issuance/propose</span>
              <span className="text-slate-400">Dual Control Maker</span>
            </div>
            <div className="text-[11px] text-slate-400">
              Body: &#123; type: "MINT", instrument: "JSY", amountJPY: "5000000000", proposerName: "..." &#125;
            </div>
          </div>

          <div className="p-3 bg-slate-900 text-slate-200 rounded-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-amber-400 font-bold">POST /api/issuance/approve</span>
              <span className="text-slate-400">Dual Control Checker</span>
            </div>
            <div className="text-[11px] text-slate-400">
              Executes pending monetary proposals into the double-entry general ledger upon secondary verification.
            </div>
          </div>

          <div className="p-3 bg-slate-900 text-slate-200 rounded-xs space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-emerald-400 font-bold">GET /api/ledger</span>
              <span className="text-slate-400">General Ledger & Trial Balance</span>
            </div>
            <div className="text-[11px] text-slate-400">
              Returns chart of accounts, posted debits/credits, and verifies trial balance symmetry.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
