import React from 'react';
import { TrendingUp, Clock, BarChart3, Globe } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

export const MarketsView: React.FC = () => {
  const state = monetaryStore.getState();
  const markets = state.markets;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          Japanese Yen Institutional Market Terminal
          <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 rounded-xs border border-slate-200">
            TOKYO MARKET TIME (JST)
          </span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Reference spot FX rates, JGB yield curve benchmarks, TONA overnight call rates, and Genkatsu repo spreads.
        </p>
      </div>

      {/* FX & Reference Rates Ticker Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500 font-semibold uppercase">USD / JPY Spot Rate</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1">{markets.usdjpy.toFixed(2)}</div>
          <div className="text-[11px] text-emerald-700 font-mono mt-0.5">Reference BOJ Fix</div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500 font-semibold uppercase">EUR / JPY Spot Rate</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1">{markets.eurjpy.toFixed(2)}</div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">Tokyo Fixing Rate</div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500 font-semibold uppercase">TONA Call Rate (BOJ Benchmark)</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1">{markets.tonaRatePct}%</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Uncollateralized Overnight</div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500 font-semibold uppercase">Genkatsu Triparty Repo Rate</div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1">{markets.genkatsuRepoPct}%</div>
          <div className="text-[11px] text-slate-500 mt-0.5">JGB Backed Collateralized</div>
        </div>
      </div>

      {/* JGB Yield Curve Visual Representation */}
      <div className="jsb-card p-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-6">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-red-700" />
              Japan Government Bond (JGB) Sovereign Yield Curve
            </h2>
            <span className="text-xs text-slate-500">
              Benchmark yields used for reserve haircut valuation and collateral margin calculations.
            </span>
          </div>
          <span className="text-xs font-mono text-slate-500">{markets.updatedAtJST}</span>
        </div>

        {/* Bar Chart Representation of Yield Curve */}
        <div className="grid grid-cols-7 gap-3 items-end h-48 pt-6 pb-2 border-b border-slate-200">
          {markets.jgbYieldCurve.map((point) => {
            const heightPct = Math.min(100, Math.max(15, (point.yieldPct / 2.5) * 100));
            return (
              <div key={point.tenor} className="flex flex-col items-center gap-2 h-full justify-end">
                <span className="font-mono text-xs font-bold text-slate-900">{point.yieldPct.toFixed(2)}%</span>
                <div
                  style={{ height: `${heightPct}%` }}
                  className="w-full max-w-[48px] bg-slate-800 hover:bg-red-700 transition-colors rounded-t-xs relative group"
                >
                  <div className="hidden group-hover:block absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-2 py-1 bg-slate-900 text-white text-[10px] font-mono rounded-xs shadow-md whitespace-nowrap z-10">
                    +{point.changeBps} bps shift
                  </div>
                </div>
                <span className="font-mono text-xs font-semibold text-slate-700">{point.tenor}</span>
              </div>
            );
          })}
        </div>

        {/* Yield Curve Data Table */}
        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Tenor</th>
                <th className="p-3 text-right">Yield %</th>
                <th className="p-3 text-right">Daily Change (bps)</th>
                <th className="p-3">Haircut Classification Category</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {markets.jgbYieldCurve.map((p) => (
                <tr key={p.tenor} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-900 font-sans">{p.tenor} Tenor JGB</td>
                  <td className="p-3 text-right font-bold text-slate-900">{p.yieldPct.toFixed(2)}%</td>
                  <td className="p-3 text-right text-emerald-700 font-bold">+{p.changeBps} bps</td>
                  <td className="p-3 font-sans text-slate-600">
                    {p.tenor === '3M' || p.tenor === '6M' || p.tenor === '1Y' || p.tenor === '2Y'
                      ? 'Tier 1 Short JGB (2.0% Haircut)'
                      : p.tenor === '5Y' || p.tenor === '10Y'
                      ? 'Tier 2 Medium JGB (4.5% Haircut)'
                      : 'Tier 3 Long JGB (8.0% Haircut)'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
