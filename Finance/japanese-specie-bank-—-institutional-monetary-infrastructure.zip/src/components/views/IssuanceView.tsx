import React, { useState } from 'react';
import { ArrowLeftRight, CheckCircle2, AlertOctagon, UserCheck, ShieldAlert, PlusCircle } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

interface IssuanceViewProps {
  onOpenModal: () => void;
}

export const IssuanceView: React.FC<IssuanceViewProps> = ({ onOpenModal }) => {
  const state = monetaryStore.getState();
  const [checkerName, setCheckerName] = useState('Kenji Sato (Chief Risk Officer)');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleApprove = (proposalId: string) => {
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      monetaryStore.approveAndExecuteProposal(proposalId, checkerName);
      setSuccessMsg(`Proposal ${proposalId} approved and executed into General Ledger.`);
    } catch (err: any) {
      setErrorMsg(err.message);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            Private Yen Issuance & Redemption Engine
            <span className="text-xs font-mono font-semibold px-2 py-0.5 bg-red-100 text-red-900 rounded-xs">
              DUAL-CONTROL MAKER-CHECKER
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Monetary issuance & destruction controls. All minting and burning actions require explicit dual-authorization and deterministic integer ledger execution.
          </p>
        </div>
        <button
          onClick={onOpenModal}
          className="px-4 py-2 text-xs font-semibold bg-red-700 hover:bg-red-800 text-white rounded-xs shadow-xs flex items-center gap-1.5"
        >
          <PlusCircle className="w-4 h-4" /> Propose New Mint / Burn
        </button>
      </div>

      {/* Notifications */}
      {errorMsg && (
        <div className="p-3 bg-red-50 border border-red-300 text-red-900 text-xs font-medium rounded-xs flex items-center gap-2">
          <AlertOctagon className="w-4 h-4 text-red-700 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-medium rounded-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Dual Control Authorization Active Session */}
      <div className="jsb-card p-4 bg-slate-50 border border-slate-300 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <UserCheck className="w-5 h-5 text-slate-700" />
          <div>
            <span className="font-bold text-slate-900 block">Active Checker Approval Session:</span>
            <span className="text-slate-600">Simulating secondary authorized compliance checker role</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-slate-500 font-medium">Checker Name:</label>
          <input
            type="text"
            value={checkerName}
            onChange={(e) => setCheckerName(e.target.value)}
            className="px-3 py-1 bg-white border border-slate-300 rounded-xs text-slate-900 font-medium focus:outline-none focus:border-red-700"
          />
        </div>
      </div>

      {/* Pending Proposals Section */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-700" />
          Pending Monetary Proposals Requiring Checker Sign-off
        </h2>

        {state.proposals.filter((p) => p.status === 'PROPOSED').length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 border border-dashed border-slate-300 rounded-xs">
            No pending issuance or redemption proposals. Use "+ Propose New Mint / Burn" to create one.
          </div>
        ) : (
          <div className="space-y-4">
            {state.proposals
              .filter((p) => p.status === 'PROPOSED')
              .map((prop) => (
                <div
                  key={prop.id}
                  className="p-4 bg-amber-50/50 border border-amber-200 rounded-xs flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 font-bold text-slate-900 font-mono">
                      <span className="px-2 py-0.5 bg-amber-600 text-white text-[10px] rounded-xs font-bold">
                        {prop.type} {prop.instrument}
                      </span>
                      <span>{prop.id}</span>
                      <span className="text-slate-500 font-normal">({prop.createdAtJST})</span>
                    </div>
                    <div className="text-slate-700 font-semibold text-sm font-mono mt-1">
                      Amount: ¥{prop.amountJPY.toLocaleString()} JPY
                    </div>
                    <div className="text-slate-600">
                      <strong>Proposer (Maker):</strong> {prop.proposerName}
                    </div>
                    <div className="text-slate-500">
                      <strong>Legal Justification:</strong> {prop.legalJustification}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleApprove(prop.id)}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xs shadow-xs"
                    >
                      ✓ Authorize & Commit Ledger
                    </button>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>

      {/* Issuance & Redemption Log Table */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Historical Monetary Issuance & Redemption Ledger
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Proposal ID</th>
                <th className="p-3">Type</th>
                <th className="p-3 text-right">Amount JPY</th>
                <th className="p-3">Proposer (Maker)</th>
                <th className="p-3">Approver (Checker)</th>
                <th className="p-3">Backing Asset</th>
                <th className="p-3 text-center">Execution Tx ID</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {state.proposals.map((prop) => (
                <tr key={prop.id} className="hover:bg-slate-50">
                  <td className="p-3 font-semibold text-slate-900">{prop.id}</td>
                  <td className="p-3">
                    <span
                      className={`px-1.5 py-0.5 text-[10px] font-bold rounded-xs ${
                        prop.type === 'MINT'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {prop.type} ({prop.instrument})
                    </span>
                  </td>
                  <td className="p-3 text-right font-bold text-slate-900">
                    ¥{prop.amountJPY.toLocaleString()}
                  </td>
                  <td className="p-3 text-slate-700 font-sans">{prop.proposerName}</td>
                  <td className="p-3 text-slate-700 font-sans">{prop.approverName || '—'}</td>
                  <td className="p-3 text-slate-600 font-sans">{prop.backingAssetId}</td>
                  <td className="p-3 text-center text-slate-500">{prop.executionTxId || 'PENDING'}</td>
                  <td className="p-3 text-center">
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-xs ${
                        prop.status === 'EXECUTED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {prop.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
