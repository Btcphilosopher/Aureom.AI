import React, { useState } from 'react';
import { ShieldCheck, Building2, CreditCard, ArrowRightLeft, Lock, FileText } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

export const InstrumentsView: React.FC = () => {
  const state = monetaryStore.getState();
  const [activeSubTab, setActiveSubTab] = useState<'JSY' | 'JTD' | 'JSC'>('JSY');

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">
          Yen Instrument Classification & Balance Isolation
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          JSB enforces strict legal & operational segregation between digital claims (JSY), commercial bank deposits (JTD), and settlement credit lines (JSC).
        </p>
      </div>

      {/* Segmented Control Selector */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/80 rounded-sm w-fit border border-slate-300">
        <button
          onClick={() => setActiveSubTab('JSY')}
          className={`px-4 py-2 text-xs font-semibold rounded-xs transition-colors ${
            activeSubTab === 'JSY'
              ? 'bg-red-700 text-white shadow-xs'
              : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          A. JSB Yen Claim (JSY)
        </button>
        <button
          onClick={() => setActiveSubTab('JTD')}
          className={`px-4 py-2 text-xs font-semibold rounded-xs transition-colors ${
            activeSubTab === 'JTD'
              ? 'bg-blue-700 text-white shadow-xs'
              : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          B. Tokenised Deposits (JTD)
        </button>
        <button
          onClick={() => setActiveSubTab('JSC')}
          className={`px-4 py-2 text-xs font-semibold rounded-xs transition-colors ${
            activeSubTab === 'JSC'
              ? 'bg-amber-700 text-white shadow-xs'
              : 'text-slate-700 hover:text-slate-900'
          }`}
        >
          C. Settlement Credit (JSC)
        </button>
      </div>

      {/* SubTab 1: JSY Yen Claim */}
      {activeSubTab === 'JSY' && (
        <div className="space-y-6">
          <div className="jsb-card p-6 border-l-4 border-l-red-700">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <span className="text-xs font-bold text-red-700 uppercase tracking-widest">
                  INSTRUMENT SPECIFICATION
                </span>
                <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                  JSB Yen Digital Payment Claim (JSY)
                </h2>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-500 block">TOTAL OUTSTANDING SUPPLY</span>
                <span className="font-mono text-xl font-bold text-slate-900">
                  ¥{state.jsy.totalSupplyJPY.toLocaleString()} JPY
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6 text-xs">
              <div className="space-y-1">
                <div className="text-slate-500 font-semibold">LEGAL CLASSIFICATION</div>
                <div className="text-slate-900 font-medium">{state.jsy.legalClassification}</div>
              </div>

              <div className="space-y-1">
                <div className="text-slate-500 font-semibold">LEGAL ISSUER SPV</div>
                <div className="text-slate-900 font-medium">{state.jsy.issuer}</div>
              </div>

              <div className="space-y-1">
                <div className="text-slate-500 font-semibold">TARGET VALUE PEG</div>
                <div className="text-emerald-700 font-mono font-bold">1 JSY = ¥1.0000 JPY (Target Peg)</div>
              </div>

              <div className="space-y-1">
                <div className="text-slate-500 font-semibold">REDEMPTION POLICY</div>
                <div className="text-slate-900">{state.jsy.redemptionPolicy}</div>
              </div>

              <div className="space-y-1">
                <div className="text-slate-500 font-semibold">RESERVE BACKING MODEL</div>
                <div className="text-slate-900">{state.jsy.backingModel}</div>
              </div>

              <div className="space-y-1">
                <div className="text-slate-500 font-semibold">LAST AUDIT RECONCILIATION</div>
                <div className="text-slate-900 font-mono">{state.jsy.lastReconciledAt}</div>
              </div>
            </div>
          </div>

          {/* Reserve Haircut & Backing Table */}
          <div className="jsb-card p-5">
            <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              JSY Segregated Reserve Portfolio & Haircut Schedule
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Asset Bucket</th>
                    <th className="p-3">ISIN / Reference</th>
                    <th className="p-3 text-right">Nominal JPY</th>
                    <th className="p-3 text-right">Market Value JPY</th>
                    <th className="p-3 text-center">Haircut %</th>
                    <th className="p-3 text-right">Adjusted Reserve JPY</th>
                    <th className="p-3">Custodian</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {state.reserves.map((asset) => (
                    <tr key={asset.id} className="hover:bg-slate-50">
                      <td className="p-3 font-semibold text-slate-900">{asset.description}</td>
                      <td className="p-3 text-slate-600">{asset.isinOrRef}</td>
                      <td className="p-3 text-right">¥{asset.nominalValueJPY.toLocaleString()}</td>
                      <td className="p-3 text-right">¥{asset.marketValueJPY.toLocaleString()}</td>
                      <td className="p-3 text-center text-amber-800 font-bold">{asset.haircutPct}%</td>
                      <td className="p-3 text-right text-emerald-700 font-bold">
                        ¥{asset.adjustedEligibleValueJPY.toLocaleString()}
                      </td>
                      <td className="p-3 text-slate-600 font-sans">{asset.custodian}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SubTab 2: JTD Tokenised Deposits */}
      {activeSubTab === 'JTD' && (
        <div className="space-y-6">
          <div className="jsb-card p-6 border-l-4 border-l-blue-700">
            <h2 className="text-lg font-bold text-slate-900">
              Commercial Bank Tokenised Deposits (JTD)
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              JTDs represent direct commercial-bank liabilities of the issuing financial institution, governed under Bank Act Art 2. They are not liabilities of the JSB SPV.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {state.jtdList.map((dep) => (
              <div key={dep.id} className="jsb-card p-5 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <div>
                    <span className="text-xs font-bold text-blue-800 uppercase font-mono">{dep.bankName}</span>
                    <div className="text-xs text-slate-500">{dep.bankNameJP}</div>
                  </div>
                  <span className="font-mono text-xs font-semibold bg-blue-50 text-blue-900 px-2 py-0.5 rounded-xs border border-blue-200">
                    BIC: {dep.issuingBankBIC}
                  </span>
                </div>

                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Account Number:</span>
                    <span className="font-mono text-slate-900">{dep.accountNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Holder Institution:</span>
                    <span className="font-medium text-slate-900">{dep.holderInstitution}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-100">
                    <span className="text-slate-500 font-semibold">Deposit Balance:</span>
                    <span className="font-mono text-base font-bold text-slate-900">
                      ¥{dep.balanceJPY.toLocaleString()} JPY
                    </span>
                  </div>
                </div>

                <div className="pt-2 text-[11px] text-slate-500 bg-slate-50 p-2 rounded-xs border border-slate-200">
                  <span className="font-semibold text-slate-700">Settlement Eligibility:</span> {dep.transferCondition}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SubTab 3: JSC Settlement Credit */}
      {activeSubTab === 'JSC' && (
        <div className="space-y-6">
          <div className="jsb-card p-6 border-l-4 border-l-amber-600">
            <h2 className="text-lg font-bold text-slate-900">
              Institutional Sandbox Settlement Credit Lines (JSC)
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              JSC is an explicitly labeled sandbox settlement credit line used for interbank clearing simulations. It is not legal tender, commercial bank deposits, or public money.
            </p>
          </div>

          <div className="jsb-card p-5">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Counterparty Institution</th>
                    <th className="p-3 text-right">Credit Limit JPY</th>
                    <th className="p-3 text-right">Utilized JPY</th>
                    <th className="p-3 text-right">Available JPY</th>
                    <th className="p-3 text-center">Required Haircut</th>
                    <th className="p-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {state.jscList.map((cred) => (
                    <tr key={cred.id} className="hover:bg-slate-50">
                      <td className="p-3 font-semibold text-slate-900 font-sans">{cred.counterpartyName}</td>
                      <td className="p-3 text-right font-bold">¥{cred.creditLimitJPY.toLocaleString()}</td>
                      <td className="p-3 text-right text-amber-800">¥{cred.utilizedJPY.toLocaleString()}</td>
                      <td className="p-3 text-right text-emerald-700 font-bold">
                        ¥{cred.availableJPY.toLocaleString()}
                      </td>
                      <td className="p-3 text-center">{cred.collateralHaircutPct}%</td>
                      <td className="p-3 text-center">
                        <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded-xs">
                          {cred.exposureStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
