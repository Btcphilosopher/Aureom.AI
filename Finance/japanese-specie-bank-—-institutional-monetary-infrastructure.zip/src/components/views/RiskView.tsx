import React, { useState } from 'react';
import { Activity, Play, ShieldAlert, Cpu, BarChart2 } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

export const RiskView: React.FC = () => {
  const state = monetaryStore.getState();
  const [runningScenarioId, setRunningScenarioId] = useState<string | null>(null);

  const handleRunStress = (scenarioId: string) => {
    setRunningScenarioId(scenarioId);
    setTimeout(() => {
      monetaryStore.runStressTestScenario(scenarioId);
      setRunningScenarioId(null);
    }, 1000);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          R-Based Financial Risk & Liquidity Simulation Engine
          <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 rounded-xs border border-slate-200">
            MONTE CARLO / SENSITIVITY
          </span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Reproducible mathematical modeling of redemption runs, JGB duration/convexity yield shocks, custodian outages, and reserve liquidity-at-risk.
        </p>
      </div>

      {/* Stress Scenarios List */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Activity className="w-4 h-4 text-red-700" />
          R-Analytics Stress Scenario Test Suite
        </h2>

        <div className="space-y-4">
          {state.stressScenarios.map((sc) => (
            <div
              key={sc.scenarioId}
              className="p-5 bg-slate-50 border border-slate-200 rounded-xs space-y-3"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-200 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{sc.scenarioName}</span>
                    <span className="font-mono text-xs text-slate-500 font-semibold">({sc.scenarioId})</span>
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-xs ${
                        sc.riskRating === 'LOW'
                          ? 'bg-emerald-100 text-emerald-800'
                          : sc.riskRating === 'MODERATE'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      RISK: {sc.riskRating}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{sc.description}</p>
                </div>

                <button
                  onClick={() => handleRunStress(sc.scenarioId)}
                  disabled={runningScenarioId === sc.scenarioId}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xs shadow-xs flex items-center gap-1.5 shrink-0 disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  {runningScenarioId === sc.scenarioId ? 'Simulating R Model...' : 'Execute Stress Simulation'}
                </button>
              </div>

              {/* Stress Results Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono pt-1">
                <div>
                  <span className="text-slate-500 block">Simulated Redemption:</span>
                  <span className="font-bold text-slate-900">{sc.simulatedRedemptionPct}% JSY Supply</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Yield Curve Shock:</span>
                  <span className="font-bold text-slate-900">+{sc.jgbYieldShiftBps} bps</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Projected Reserve Coverage:</span>
                  <span
                    className={`font-bold ${
                      sc.projectedCoverageRatio >= 102.5
                        ? 'text-emerald-700'
                        : sc.projectedCoverageRatio >= 100
                        ? 'text-amber-700'
                        : 'text-red-700'
                    }`}
                  >
                    {sc.projectedCoverageRatio}%
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Projected Shortfall:</span>
                  <span className="font-bold text-slate-900">
                    ¥{sc.liquidityShortfallJPY.toLocaleString()} JPY
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
