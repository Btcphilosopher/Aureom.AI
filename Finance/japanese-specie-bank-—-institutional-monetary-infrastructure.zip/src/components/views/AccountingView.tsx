import React from 'react';
import { BookOpen, CheckCircle2, ShieldCheck, Scale, AlertOctagon } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

export const AccountingView: React.FC = () => {
  const state = monetaryStore.getState();
  const trial = state.trialBalance;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          Double-Entry General Ledger & Trial Balance
          <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 rounded-xs border border-slate-200">
            INTEGER JPY ARITHMETIC
          </span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Authoritative financial accounting records. Every posted journal entry enforces SUM(Debits) == SUM(Credits). Reversals use compensating entries only.
        </p>
      </div>

      {/* Trial Balance Health Banner */}
      <div
        className={`p-5 rounded-xs border flex items-center justify-between text-xs font-mono ${
          trial.isBalanced
            ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
            : 'bg-red-50 border-red-300 text-red-950'
        }`}
      >
        <div className="flex items-center gap-3">
          <Scale className="w-6 h-6 text-emerald-700" />
          <div>
            <span className="text-sm font-bold block">
              {trial.isBalanced
                ? 'TRIAL BALANCE INVARIANT VERIFIED: DEBITS EQUAL CREDITS'
                : 'CRITICAL WARNING: UNBALANCED LEDGER DETECTED'}
            </span>
            <span className="text-slate-600 font-sans">
              Total Debits: ¥{trial.totalDebits.toLocaleString()} JPY | Total Credits: ¥{trial.totalCredits.toLocaleString()} JPY
            </span>
          </div>
        </div>
        <div className="text-right">
          <span className="px-3 py-1 bg-emerald-700 text-white font-bold text-xs rounded-xs">
            ZERO DRIFT INVARIANT OK
          </span>
        </div>
      </div>

      {/* Chart of Accounts */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">Chart of Accounts & Account Balances</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Account #</th>
                <th className="p-3">Account Title</th>
                <th className="p-3">Japanese Name</th>
                <th className="p-3 text-center">Category</th>
                <th className="p-3 text-right">Total Debits JPY</th>
                <th className="p-3 text-right">Total Credits JPY</th>
                <th className="p-3 text-right">Net Balance JPY</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {state.accounts.map((acc) => (
                <tr key={acc.accountNumber} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-900">{acc.accountNumber}</td>
                  <td className="p-3 font-sans font-semibold text-slate-900">{acc.name}</td>
                  <td className="p-3 font-sans text-slate-600">{acc.nameJP}</td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-slate-200 text-slate-800 rounded-xs">
                      {acc.category}
                    </span>
                  </td>
                  <td className="p-3 text-right text-slate-700">¥{acc.debitsJPY.toLocaleString()}</td>
                  <td className="p-3 text-right text-slate-700">¥{acc.creditsJPY.toLocaleString()}</td>
                  <td className="p-3 text-right font-bold text-slate-900">
                    ¥{acc.balanceJPY.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Posted Journal Entries */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">Posted General Ledger Journal Entries</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Entry ID</th>
                <th className="p-3">Timestamp (JST)</th>
                <th className="p-3">Debit Account</th>
                <th className="p-3">Credit Account</th>
                <th className="p-3 text-right">Amount JPY</th>
                <th className="p-3">Authorizer</th>
                <th className="p-3">Memo</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {state.glEntries.map((entry) => (
                <tr key={entry.id} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-900">{entry.id}</td>
                  <td className="p-3 text-slate-500 font-sans">{entry.timestampJST}</td>
                  <td className="p-3 font-sans">
                    <span className="font-mono font-bold text-slate-900">{entry.debitAccount}</span> - {entry.debitAccountName}
                  </td>
                  <td className="p-3 font-sans">
                    <span className="font-mono font-bold text-slate-900">{entry.creditAccount}</span> - {entry.creditAccountName}
                  </td>
                  <td className="p-3 text-right font-bold text-slate-900">
                    ¥{entry.amountJPY.toLocaleString()}
                  </td>
                  <td className="p-3 font-sans text-slate-600">{entry.authorizer}</td>
                  <td className="p-3 font-sans text-slate-600">{entry.memo}</td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded-xs">
                      {entry.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
