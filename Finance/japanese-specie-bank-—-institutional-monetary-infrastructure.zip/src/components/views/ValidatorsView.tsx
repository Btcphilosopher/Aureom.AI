import React, { useState } from 'react';
import { Cpu, ShieldAlert, CheckCircle2, Zap, AlertTriangle } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

export const ValidatorsView: React.FC = () => {
  const state = monetaryStore.getState();
  const [selectedValidatorId, setSelectedValidatorId] = useState<string>('VAL-MUFG-NODE-02');
  const [slashReason, setSlashReason] = useState('Double-Signing Equivocation Proof #0912');
  const [slashMessage, setSlashMessage] = useState<string | null>(null);

  const handleSlash = () => {
    const success = monetaryStore.slashValidator(selectedValidatorId, slashReason);
    if (success) {
      setSlashMessage(`Validator ${selectedValidatorId} was slashed by 20% and moved to SLASHED status.`);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          Permissioned Proof-of-Stake Validator Network
          <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 rounded-xs border border-slate-200">
            RUST CONSENSUS CORE
          </span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Institutional BFT consensus nodes. Staking bonded JPY grants validator voting weight under network rules; monetary issuance remains strictly controlled by the independent issuer permission layer.
        </p>
      </div>

      {/* Consensus Metrics Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500">Current Block Height</div>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1">
            #{state.consensus.currentBlockHeight.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5 truncate">
            {state.consensus.blockHash}
          </div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500">Network Throughput & Finality</div>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1">
            {state.consensus.tps.toLocaleString()} TPS
          </div>
          <div className="text-[11px] text-emerald-700 font-mono mt-0.5 font-semibold">
            Deterministic Finality: {state.consensus.finalityMs}ms
          </div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500">Active Institutional Validators</div>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1">
            {state.validators.filter((v) => v.status === 'ACTIVE').length} / {state.validators.length} Nodes
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            BFT Threshold: &gt; 66.7% Stake Agreement
          </div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500">Consensus Engine State</div>
          <div className="text-sm font-bold font-mono text-emerald-700 mt-1 flex items-center gap-1.5">
            <Zap className="w-4 h-4" /> {state.consensus.networkStatus}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            PBFT BFT Security Model Active
          </div>
        </div>
      </div>

      {/* Slashing Simulation Control */}
      <div className="jsb-card p-5 bg-amber-50/40 border border-amber-200">
        <h2 className="text-sm font-bold text-amber-900 flex items-center gap-2 mb-2">
          <ShieldAlert className="w-4 h-4 text-amber-700" />
          Slashing Simulation & Fault Enforcement
        </h2>
        <p className="text-xs text-slate-600 mb-4">
          Simulate malicious behavior (e.g., double-signing, prolonged liveness fault). Slashes 20% of bonded stake and ejects the validator node.
        </p>

        {slashMessage && (
          <div className="p-3 mb-4 bg-red-100 text-red-900 font-medium text-xs rounded-xs border border-red-300">
            {slashMessage}
          </div>
        )}

        <div className="flex flex-col sm:flex-row items-center gap-3 text-xs">
          <select
            value={selectedValidatorId}
            onChange={(e) => setSelectedValidatorId(e.target.value)}
            className="px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-medium text-slate-900 focus:outline-none"
          >
            {state.validators.map((v) => (
              <option key={v.id} value={v.id}>
                {v.institutionName} ({v.id})
              </option>
            ))}
          </select>

          <input
            type="text"
            value={slashReason}
            onChange={(e) => setSlashReason(e.target.value)}
            className="px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-medium text-slate-900 flex-1 focus:outline-none"
            placeholder="Fault Reason"
          />

          <button
            onClick={handleSlash}
            className="px-4 py-1.5 bg-red-700 hover:bg-red-800 text-white font-bold rounded-xs shadow-xs shrink-0"
          >
            Execute Slashing Penalty
          </button>
        </div>
      </div>

      {/* Validators Table */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Registered Institutional Validator Registry
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Validator Institution</th>
                <th className="p-3">Public Key</th>
                <th className="p-3 text-right">Bonded Stake JPY</th>
                <th className="p-3 text-center">Vote Weight</th>
                <th className="p-3 text-center">Uptime</th>
                <th className="p-3 text-right">Blocks Proposed</th>
                <th className="p-3 text-center">Missed Attestations</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {state.validators.map((val) => (
                <tr key={val.id} className="hover:bg-slate-50">
                  <td className="p-3 font-semibold text-slate-900 font-sans">
                    {val.institutionName}
                    <div className="text-[11px] text-slate-500 font-normal">{val.institutionNameJP}</div>
                  </td>
                  <td className="p-3 text-slate-500 font-mono text-[11px]">{val.nodePublicKey}</td>
                  <td className="p-3 text-right font-bold text-slate-900">
                    ¥{val.stakeJPY.toLocaleString()}
                  </td>
                  <td className="p-3 text-center font-bold text-slate-800">{val.stakeSharePct}%</td>
                  <td className="p-3 text-center text-emerald-700 font-bold">{val.uptimePct}%</td>
                  <td className="p-3 text-right text-slate-700">{val.blocksProposed.toLocaleString()}</td>
                  <td className="p-3 text-center text-slate-600">{val.missedAttestations}</td>
                  <td className="p-3 text-center">
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-xs ${
                        val.status === 'ACTIVE'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {val.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
