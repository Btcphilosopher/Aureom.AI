import React from 'react';
import { Send, CheckCircle2, Clock, ShieldCheck, ArrowRight } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

interface SettlementViewProps {
  onOpenModal: () => void;
}

export const SettlementView: React.FC<SettlementViewProps> = ({ onOpenModal }) => {
  const state = monetaryStore.getState();

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            Institutional Payment & Settlement Terminal
            <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 rounded-xs border border-slate-200">
              DVP / GROSS / NET BATCH
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Execution terminal for institutional participants. Transactions are settled deterministically on the PoS validation network.
          </p>
        </div>
        <button
          onClick={onOpenModal}
          className="px-4 py-2 text-xs font-semibold bg-red-700 hover:bg-red-800 text-white rounded-xs shadow-xs flex items-center gap-1.5"
        >
          <Send className="w-4 h-4" /> Create Payment Instruction
        </button>
      </div>

      {/* Mode Explanations */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="jsb-card p-4">
          <span className="text-xs font-bold text-slate-700 block uppercase">Real-Time Gross (GROSS_T0)</span>
          <p className="text-xs text-slate-500 mt-1">
            Immediate intra-day gross settlement with instant PoS finality verification.
          </p>
        </div>
        <div className="jsb-card p-4">
          <span className="text-xs font-bold text-slate-700 block uppercase">Net Batch EOD (NET_BATCH_EOD)</span>
          <p className="text-xs text-slate-500 mt-1">
            End-of-day interbank bilateral net clearing with liquidity compression optimization.
          </p>
        </div>
        <div className="jsb-card p-4">
          <span className="text-xs font-bold text-slate-700 block uppercase">Delivery-vs-Payment (DVP_SIMULATION)</span>
          <p className="text-xs text-slate-500 mt-1">
            Atomic simultaneous transfer of JGB security lot against JSY/JTD monetary payment.
          </p>
        </div>
      </div>

      {/* Payment Instruction Table */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">
          Institutional Settlement Instruction Register
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Instruction ID</th>
                <th className="p-3">Sender Institution</th>
                <th className="p-3">Beneficiary Institution</th>
                <th className="p-3 text-center">Instrument</th>
                <th className="p-3 text-right">Amount JPY</th>
                <th className="p-3 text-center">Mode</th>
                <th className="p-3 text-center">Sanctions Screened</th>
                <th className="p-3 text-center">Confirmed Height</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {state.payments.map((inst) => (
                <tr key={inst.instructionId} className="hover:bg-slate-50">
                  <td className="p-3 font-semibold text-slate-900">{inst.instructionId}</td>
                  <td className="p-3 font-sans text-slate-800 font-medium">{inst.senderName}</td>
                  <td className="p-3 font-sans text-slate-800 font-medium">{inst.receiverName}</td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-slate-200 text-slate-800 rounded-xs">
                      {inst.instrument}
                    </span>
                  </td>
                  <td className="p-3 text-right font-bold text-slate-900">
                    ¥{inst.amountJPY.toLocaleString()}
                  </td>
                  <td className="p-3 text-center text-slate-600 font-sans text-[11px]">{inst.settlementMode}</td>
                  <td className="p-3 text-center">
                    <span className="text-emerald-700 font-bold">✓ PASSED</span>
                  </td>
                  <td className="p-3 text-center text-slate-600">
                    {inst.blockHeightConfirmed ? `#${inst.blockHeightConfirmed}` : '—'}
                  </td>
                  <td className="p-3 text-center">
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-xs ${
                        inst.status === 'CONFIRMED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {inst.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
