import React from 'react';
import { ShieldCheck, Database, Scale, AlertCircle } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

export const ReservesView: React.FC = () => {
  const state = monetaryStore.getState();

  const totalNominal = state.reserves.reduce((acc, r) => acc + r.nominalValueJPY, BigInt(0));
  const totalMarket = state.reserves.reduce((acc, r) => acc + r.marketValueJPY, BigInt(0));
  const totalAdjusted = state.reserves.reduce((acc, r) => acc + r.adjustedEligibleValueJPY, BigInt(0));

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          Reserve & Collateral Portfolio Management
          <span className="text-xs font-mono font-normal px-2 py-0.5 bg-emerald-100 text-emerald-900 rounded-xs">
            ARCR 104.8% RECONCILED
          </span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Adjusted Eligible Reserves ÷ Outstanding Redeemable Liabilities. Evaluates haircut margins across central bank cash, JGBs, and triparty Gensaki repos.
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500">Total Nominal Reserve Value</div>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1">
            ¥{(Number(totalNominal) / 1e12).toFixed(2)} Trillion
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5 font-mono">
            Unadjusted Face Value
          </div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500">Total Market Value JPY</div>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1">
            ¥{(Number(totalMarket) / 1e12).toFixed(2)} Trillion
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Mark-to-Market Valuation
          </div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500">Adjusted Eligible Reserves</div>
          <div className="text-xl font-bold font-mono text-emerald-700 mt-1">
            ¥{(Number(totalAdjusted) / 1e12).toFixed(2)} Trillion
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Post-Haircut Risk Value
          </div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500">Reserve Coverage Ratio (ARCR)</div>
          <div className="text-xl font-bold font-mono text-emerald-700 mt-1 flex items-center gap-1.5">
            <ShieldCheck className="w-5 h-5 text-emerald-700" />
            {state.jsy.reserveCoverageRatio}%
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Target Threshold: ≥ 102.5%
          </div>
        </div>
      </div>

      {/* Haircut Schedule Table */}
      <div className="jsb-card p-5">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
          <h2 className="text-sm font-bold text-slate-900">
            Segregated Asset Inventory & Haircut Matrices
          </h2>
          <span className="text-xs font-mono text-slate-500">
            Last Valuation: {state.jsy.lastReconciledAt}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Asset Description</th>
                <th className="p-3">Asset Class</th>
                <th className="p-3 text-right">Nominal JPY</th>
                <th className="p-3 text-right">Market JPY</th>
                <th className="p-3 text-center">Haircut %</th>
                <th className="p-3 text-right">Adjusted Eligible JPY</th>
                <th className="p-3">Custodian Account</th>
                <th className="p-3 text-center">Liquidity Tier</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {state.reserves.map((asset) => (
                <tr key={asset.id} className="hover:bg-slate-50">
                  <td className="p-3 font-semibold text-slate-900 font-sans">
                    {asset.description}
                    <div className="text-[11px] text-slate-500 font-mono">{asset.isinOrRef}</div>
                  </td>
                  <td className="p-3 font-sans">
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-slate-200 text-slate-800 rounded-xs">
                      {asset.assetClass}
                    </span>
                  </td>
                  <td className="p-3 text-right text-slate-700">¥{asset.nominalValueJPY.toLocaleString()}</td>
                  <td className="p-3 text-right font-semibold text-slate-900">
                    ¥{asset.marketValueJPY.toLocaleString()}
                  </td>
                  <td className="p-3 text-center font-bold text-amber-800">{asset.haircutPct}%</td>
                  <td className="p-3 text-right font-bold text-emerald-700">
                    ¥{asset.adjustedEligibleValueJPY.toLocaleString()}
                  </td>
                  <td className="p-3 font-sans text-slate-600">{asset.custodian}</td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xs">
                      {asset.liquidityTier}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
