import React from 'react';
import { Vote, ShieldAlert, AlertOctagon, CheckCircle2 } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

export const GovernanceView: React.FC = () => {
  const state = monetaryStore.getState();

  const handleToggleEmergency = () => {
    monetaryStore.toggleEmergencyPause();
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          Governance & Emergency Controls
          <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 rounded-xs border border-slate-200">
            STAKE-WEIGHTED VOTING
          </span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Controlled parameter updates, validator admissions, and emergency circuit breaker controls.
        </p>
      </div>

      {/* Emergency Circuit Breaker Banner */}
      <div className="jsb-card p-5 border-2 border-red-700 bg-red-50/40 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <AlertOctagon className="w-5 h-5 text-red-700" />
            <span className="text-sm font-bold text-red-950">
              EMERGENCY NETWORK PAUSE CIRCUIT BREAKER
            </span>
          </div>
          <p className="text-xs text-red-900 mt-1">
            Immediately halts PoS consensus block generation and interbank settlement processing. Active status: <strong>{state.consensus.networkStatus}</strong>.
          </p>
        </div>
        <button
          onClick={handleToggleEmergency}
          className={`px-5 py-2 text-xs font-bold rounded-xs shadow-xs text-white transition-colors shrink-0 ${
            state.consensus.networkStatus === 'OPERATIONAL'
              ? 'bg-red-700 hover:bg-red-800'
              : 'bg-emerald-700 hover:bg-emerald-800'
          }`}
        >
          {state.consensus.networkStatus === 'OPERATIONAL'
            ? '🚨 HALT NETWORK OPERATIONS'
            : '✓ RESUME NETWORK OPERATIONS'}
        </button>
      </div>

      {/* Governance Votes Table */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">Institutional Voting Proposals</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Proposal ID</th>
                <th className="p-3">Title / Description</th>
                <th className="p-3 text-center">Category</th>
                <th className="p-3">Proposed By</th>
                <th className="p-3 text-right">Votes FOR (JPY Stake)</th>
                <th className="p-3 text-right">Votes AGAINST</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {state.votes.map((v) => (
                <tr key={v.proposalId} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-900">{v.proposalId}</td>
                  <td className="p-3 font-sans font-semibold text-slate-900">{v.title}</td>
                  <td className="p-3 text-center font-sans">
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-slate-200 text-slate-800 rounded-xs">
                      {v.category}
                    </span>
                  </td>
                  <td className="p-3 font-sans text-slate-700">{v.proposedBy}</td>
                  <td className="p-3 text-right text-emerald-700 font-bold">
                    ¥{v.votesForStakeJPY.toLocaleString()}
                  </td>
                  <td className="p-3 text-right text-red-700">
                    ¥{v.votesAgainstStakeJPY.toLocaleString()}
                  </td>
                  <td className="p-3 text-center font-sans">
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-xs ${
                        v.status === 'PASSED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {v.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
