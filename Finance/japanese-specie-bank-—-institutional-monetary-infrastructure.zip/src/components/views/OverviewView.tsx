import React from 'react';
import {
  ShieldCheck,
  TrendingUp,
  Cpu,
  BookOpen,
  ArrowUpRight,
  Clock,
  Coins,
  Building2,
  FileCheck,
  AlertTriangle,
} from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';
import { NavTab } from '../Sidebar';

interface OverviewViewProps {
  onSelectTab: (tab: NavTab) => void;
  onOpenIssuanceModal: () => void;
  onOpenPaymentModal: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  onSelectTab,
  onOpenIssuanceModal,
  onOpenPaymentModal,
}) => {
  const state = monetaryStore.getState();

  const totalJtdJPY = state.jtdList.reduce((acc, item) => acc + item.balanceJPY, BigInt(0));
  const totalJscLimitJPY = state.jscList.reduce((acc, item) => acc + item.creditLimitJPY, BigInt(0));
  const totalJscUtilizedJPY = state.jscList.reduce((acc, item) => acc + item.utilizedJPY, BigInt(0));

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Title & Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            Executive Monetary Overview
            <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 border border-slate-200 rounded-xs">
              JST LIVE INFRASTRUCTURE
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Institutional summary of JPY monetary claims, commercial tokenised deposits, PoS consensus, double-entry trial balance, and reserve coverage.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenIssuanceModal}
            className="px-3 py-1.5 text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xs border border-slate-300"
          >
            + New Issuance Proposal
          </button>
          <button
            onClick={onOpenPaymentModal}
            className="px-3.5 py-1.5 text-xs font-semibold bg-red-700 hover:bg-red-800 text-white rounded-xs shadow-xs"
          >
            Create Settlement Instruction
          </button>
        </div>
      </div>

      {/* Primary Monetary Cards Grid (3 Instruments Separation) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: JSY (Yen Claim) */}
        <div className="jsb-card p-5 border-t-4 border-t-red-700">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold text-slate-700 uppercase tracking-wider">A. JSB Yen Claim (JSY)</span>
            <span className="font-mono text-[11px] bg-red-50 text-red-800 px-1.5 py-0.5 rounded-xs border border-red-200">
              PEG TARGET ¥1.00
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900">
              ¥{(Number(state.jsy.totalSupplyJPY) / 1e12).toFixed(2)} Trillion
            </div>
            <div className="text-xs text-slate-500 mt-0.5 font-mono">
              Outstanding Supply: ¥{state.jsy.totalSupplyJPY.toLocaleString()} JPY
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Adjusted Reserve Coverage:</span>
            <span className="font-bold font-mono text-emerald-700 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              {state.jsy.reserveCoverageRatio}% (Target ≥ 102.5%)
            </span>
          </div>
          <button
            onClick={() => onSelectTab('instruments')}
            className="mt-3 w-full text-center text-xs font-medium text-red-700 hover:text-red-900 flex items-center justify-center gap-1 py-1"
          >
            View Redemption Terms & Backing <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        {/* Card 2: JTD (Tokenised Deposit) */}
        <div className="jsb-card p-5 border-t-4 border-t-blue-700">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold text-slate-700 uppercase tracking-wider">B. Tokenised Deposits (JTD)</span>
            <span className="font-mono text-[11px] bg-blue-50 text-blue-800 px-1.5 py-0.5 rounded-xs border border-blue-200">
              COMMERCIAL LIABILITIES
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900">
              ¥{(Number(totalJtdJPY) / 1e12).toFixed(2)} Trillion
            </div>
            <div className="text-xs text-slate-500 mt-0.5 font-mono">
              Across {state.jtdList.length} Participating Banks (MUFG, SMBC, Mizuho...)
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Settlement Status:</span>
            <span className="font-medium text-blue-800">Interbank Gross & Net Netting</span>
          </div>
          <button
            onClick={() => onSelectTab('instruments')}
            className="mt-3 w-full text-center text-xs font-medium text-blue-700 hover:text-blue-900 flex items-center justify-center gap-1 py-1"
          >
            View Bank Deposit Accounts <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        {/* Card 3: JSC (Settlement Credit) */}
        <div className="jsb-card p-5 border-t-4 border-t-amber-600">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold text-slate-700 uppercase tracking-wider">C. Settlement Credit (JSC)</span>
            <span className="font-mono text-[11px] bg-amber-50 text-amber-800 px-1.5 py-0.5 rounded-xs border border-amber-200">
              SANDBOX CLEARING LINE
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900">
              ¥{(Number(totalJscUtilizedJPY) / 1e9).toFixed(1)}B / ¥{(Number(totalJscLimitJPY) / 1e9).toFixed(1)}B
            </div>
            <div className="text-xs text-slate-500 mt-0.5 font-mono">
              Utilized Credit / Total Authorised Lines
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">Haircut Margin Range:</span>
            <span className="font-medium text-slate-700">3.5% – 5.0% Collateralized</span>
          </div>
          <button
            onClick={() => onSelectTab('instruments')}
            className="mt-3 w-full text-center text-xs font-medium text-amber-700 hover:text-amber-900 flex items-center justify-center gap-1 py-1"
          >
            View Counterparty Exposures <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Key Metric Tickers Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5 text-slate-400" /> Double-Entry Trial Balance
          </div>
          <div className="mt-2 flex items-center justify-between">
            <span className="font-mono text-base font-bold text-slate-900">
              ¥{(Number(state.trialBalance.totalDebits) / 1e12).toFixed(2)}T
            </span>
            {state.trialBalance.isBalanced ? (
              <span className="px-2 py-0.5 text-[10px] font-bold text-emerald-800 bg-emerald-100 rounded-xs">
                BALANCED (Debits = Credits)
              </span>
            ) : (
              <span className="px-2 py-0.5 text-[10px] font-bold text-red-800 bg-red-100 rounded-xs">
                IMBALANCE DETECTED
              </span>
            )}
          </div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-slate-400" /> PoS Consensus Network
          </div>
          <div className="mt-2 flex items-center justify-between">
            <span className="font-mono text-base font-bold text-slate-900">
              #{state.consensus.currentBlockHeight.toLocaleString()}
            </span>
            <span className="font-mono text-xs text-slate-600">
              {state.consensus.activeValidators} Nodes · {state.consensus.finalityMs}ms
            </span>
          </div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-slate-400" /> JPY Reference Rates
          </div>
          <div className="mt-2 flex items-center justify-between font-mono text-xs text-slate-800">
            <span>TONA: <strong className="text-slate-900">{state.markets.tonaRatePct}%</strong></span>
            <span>USD/JPY: <strong className="text-slate-900">{state.markets.usdjpy}</strong></span>
          </div>
        </div>

        <div className="jsb-card p-4">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <FileCheck className="w-3.5 h-3.5 text-slate-400" /> Pending Governance / Proposals
          </div>
          <div className="mt-2 flex items-center justify-between">
            <span className="font-mono text-base font-bold text-slate-900">
              {state.proposals.filter((p) => p.status === 'PROPOSED').length} Pending
            </span>
            <button
              onClick={() => onSelectTab('issuance')}
              className="text-xs text-red-700 font-medium hover:underline"
            >
              Review Maker/Checker
            </button>
          </div>
        </div>
      </div>

      {/* Two Column Layout: Settlement Instructions + Recent Audit Trail */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Active Settlement Instructions */}
        <div className="jsb-card p-5">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-red-700" />
              Recent Institutional Settlements
            </h2>
            <button
              onClick={() => onSelectTab('settlement')}
              className="text-xs text-slate-600 hover:text-slate-900 font-medium"
            >
              View All →
            </button>
          </div>

          <div className="mt-4 space-y-3">
            {state.payments.slice(0, 4).map((pay) => (
              <div
                key={pay.instructionId}
                className="p-3 bg-slate-50 border border-slate-200 rounded-xs flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900 flex items-center gap-2">
                    <span>{pay.instructionId}</span>
                    <span className="font-mono text-[10px] px-1.5 py-0.2 bg-slate-200 text-slate-800 rounded-xs">
                      {pay.instrument}
                    </span>
                  </div>
                  <div className="text-slate-500 mt-0.5">
                    {pay.senderName} → {pay.receiverName}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-slate-900">
                    ¥{pay.amountJPY.toLocaleString()} JPY
                  </div>
                  <div className="mt-0.5">
                    {pay.status === 'CONFIRMED' ? (
                      <span className="text-emerald-700 font-semibold font-mono text-[11px]">
                        ✓ CONFIRMED (BLOCK #{pay.blockHeightConfirmed})
                      </span>
                    ) : (
                      <span className="text-amber-700 font-semibold font-mono text-[11px]">
                        ⏳ PENDING CLEARING
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Live Audit & Reconciled Reserves */}
        <div className="jsb-card p-5">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              Reserve Backing & Audit Telemetry
            </h2>
            <button
              onClick={() => onSelectTab('audit')}
              className="text-xs text-slate-600 hover:text-slate-900 font-medium"
            >
              Export Audit Trail →
            </button>
          </div>

          <div className="mt-4 space-y-3 text-xs">
            <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-xs">
              <div className="font-bold text-emerald-900 flex items-center justify-between">
                <span>BOJ Cash & JGB Collateral Health</span>
                <span>COVERAGE: {state.jsy.reserveCoverageRatio}%</span>
              </div>
              <p className="text-emerald-800 text-[11px] mt-1">
                All 4 reserve buckets reconciled at {state.jsy.lastReconciledAt}. Zero reserve deficit observed.
              </p>
            </div>

            <div className="space-y-2 mt-3">
              <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Recent Ledger Audit Logs
              </div>
              {state.auditLogs.slice(0, 3).map((log) => (
                <div key={log.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xs font-mono">
                  <div className="flex items-center justify-between text-[11px] text-slate-700 font-semibold">
                    <span>{log.actor}</span>
                    <span className="text-slate-400">{log.timestampJST}</span>
                  </div>
                  <div className="text-slate-600 text-[11px] mt-0.5 truncate">{log.details}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
