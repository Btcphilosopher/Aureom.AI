import React from 'react';
import { FileText, Download, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { monetaryStore } from '../../services/monetaryStore';

export const AuditView: React.FC = () => {
  const state = monetaryStore.getState();

  const handleDownloadExport = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state.auditLogs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', 'JSB-Audit-Trail-Export.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            Immutable Audit Trail & Regulatory Reporting
            <span className="text-xs font-mono font-normal px-2 py-0.5 bg-slate-100 text-slate-700 rounded-xs border border-slate-200">
              TAMPER-EVIDENT SIGNATURES
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Complete event log containing cryptographic proofs for all monetary, consensus, and compliance actions.
          </p>
        </div>
        <button
          onClick={handleDownloadExport}
          className="px-4 py-2 text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white rounded-xs shadow-xs flex items-center gap-1.5"
        >
          <Download className="w-4 h-4" /> Download Audit JSON Report
        </button>
      </div>

      {/* Audit Log Table */}
      <div className="jsb-card p-5">
        <h2 className="text-sm font-bold text-slate-900 mb-3">System Event Audit Records</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-100 text-slate-700 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">Audit Log ID</th>
                <th className="p-3">Timestamp (JST)</th>
                <th className="p-3">Actor</th>
                <th className="p-3">Role</th>
                <th className="p-3">Action Type</th>
                <th className="p-3">Event Details</th>
                <th className="p-3">IP / Auth Info</th>
                <th className="p-3 text-center">Crypto Signature</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {state.auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="p-3 font-bold text-slate-900">{log.id}</td>
                  <td className="p-3 text-slate-500 font-sans">{log.timestampJST}</td>
                  <td className="p-3 font-sans font-semibold text-slate-900">{log.actor}</td>
                  <td className="p-3 font-sans">
                    <span className="px-1.5 py-0.5 text-[10px] font-bold bg-slate-200 text-slate-800 rounded-xs">
                      {log.role}
                    </span>
                  </td>
                  <td className="p-3 font-bold text-red-700">{log.action}</td>
                  <td className="p-3 font-sans text-slate-700 max-w-xs truncate">{log.details}</td>
                  <td className="p-3 text-slate-500 font-sans text-[11px]">{log.ipHash}</td>
                  <td className="p-3 text-center text-slate-400 text-[11px]">{log.signature}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
