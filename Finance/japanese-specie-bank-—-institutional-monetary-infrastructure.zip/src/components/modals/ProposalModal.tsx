import React, { useState } from 'react';
import { X, ArrowLeftRight, ShieldCheck } from 'lucide-react';
import { InstrumentType } from '../../types';
import { monetaryStore } from '../../services/monetaryStore';

interface ProposalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProposalModal: React.FC<ProposalModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [type, setType] = useState<'MINT' | 'BURN'>('MINT');
  const [instrument, setInstrument] = useState<InstrumentType>('JSY');
  const [amountBillion, setAmountBillion] = useState<number>(25);
  const [proposerName, setProposerName] = useState<string>('Takeshi Yamamoto (Head of Treasury Ops)');
  const [backingAssetId, setBackingAssetId] = useState<string>('RES-BOJ-CASH-01');
  const [legalJustification, setLegalJustification] = useState<string>(
    'Providing Q4 intra-day liquidity for participating interbank clearing members.'
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountJPY = BigInt(Math.round(amountBillion * 1e9));

    monetaryStore.createIssuanceProposal({
      type,
      instrument,
      amountJPY,
      proposerName,
      backingAssetId,
      legalJustification,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white border border-slate-300 rounded-sm shadow-xl w-full max-w-lg overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-red-700" />
            Create Monetary Issuance / Redemption Proposal (Maker)
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-600 font-semibold mb-1">Proposal Action Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as 'MINT' | 'BURN')}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-semibold focus:outline-none"
              >
                <option value="MINT">MINT (Issue Supply)</option>
                <option value="BURN">BURN (Redeem & Destroy)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-600 font-semibold mb-1">Target Instrument</label>
              <select
                value={instrument}
                onChange={(e) => setInstrument(e.target.value as InstrumentType)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-semibold focus:outline-none"
              >
                <option value="JSY">JSY — JSB Yen Claim</option>
                <option value="JTD">JTD — Tokenised Deposit</option>
                <option value="JSC">JSC — Settlement Credit</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-600 font-semibold mb-1">
              Proposal Amount (¥ Billions JPY)
            </label>
            <input
              type="number"
              min="1"
              max="1000"
              value={amountBillion}
              onChange={(e) => setAmountBillion(Number(e.target.value))}
              className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-mono font-bold text-slate-900 focus:outline-none"
            />
            <div className="text-[11px] text-slate-500 mt-1 font-mono">
              Equivalent Integer JPY: ¥{(amountBillion * 1e9).toLocaleString()} JPY
            </div>
          </div>

          <div>
            <label className="block text-slate-600 font-semibold mb-1">Maker (Proposer Identity)</label>
            <input
              type="text"
              value={proposerName}
              onChange={(e) => setProposerName(e.target.value)}
              className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-medium focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-600 font-semibold mb-1">Pledged Backing Asset Account</label>
            <select
              value={backingAssetId}
              onChange={(e) => setBackingAssetId(e.target.value)}
              className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-medium focus:outline-none"
            >
              <option value="RES-BOJ-CASH-01">RES-BOJ-CASH-01 (BOJ Central Cash Balance - 0% Haircut)</option>
              <option value="RES-JGB-SHORT-442">RES-JGB-SHORT-442 (JGB #442 1Y Bond - 2.0% Haircut)</option>
              <option value="RES-JGB-MED-368">RES-JGB-MED-368 (JGB #368 5Y Bond - 4.5% Haircut)</option>
              <option value="RES-GENSAKI-REPO-09">RES-GENSAKI-REPO-09 (Triparty Repo - 3.0% Haircut)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-600 font-semibold mb-1">Legal / Operational Justification</label>
            <textarea
              rows={2}
              value={legalJustification}
              onChange={(e) => setLegalJustification(e.target.value)}
              className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-medium focus:outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-red-700 hover:bg-red-800 text-white font-bold rounded-xs shadow-xs"
            >
              Submit Proposal for Checker Authorization
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
