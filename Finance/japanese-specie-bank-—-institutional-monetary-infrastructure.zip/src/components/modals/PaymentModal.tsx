import React, { useState } from 'react';
import { X, Send, ShieldCheck } from 'lucide-react';
import { InstrumentType } from '../../types';
import { monetaryStore } from '../../services/monetaryStore';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const [senderName, setSenderName] = useState('MUFG Bank, Ltd.');
  const [receiverName, setReceiverName] = useState('Sumitomo Mitsui Banking Corporation');
  const [instrument, setInstrument] = useState<InstrumentType>('JSY');
  const [amountBillion, setAmountBillion] = useState<number>(10);
  const [settlementMode, setSettlementMode] = useState<'GROSS_T0' | 'NET_BATCH_EOD' | 'DVP_SIMULATION'>('GROSS_T0');
  const [dvpRef, setDvpRef] = useState('JGB-442-LOT-12');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amountJPY = BigInt(Math.round(amountBillion * 1e9));

    monetaryStore.submitPaymentInstruction({
      senderName,
      receiverName,
      instrument,
      amountJPY,
      settlementMode,
      dvpRef: settlementMode === 'DVP_SIMULATION' ? dvpRef : undefined,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white border border-slate-300 rounded-sm shadow-xl w-full max-w-lg overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Send className="w-4 h-4 text-red-700" />
            Create Institutional Payment & Settlement Instruction
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          <div>
            <label className="block text-slate-600 font-semibold mb-1">Sender Institution</label>
            <select
              value={senderName}
              onChange={(e) => setSenderName(e.target.value)}
              className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-semibold focus:outline-none"
            >
              <option value="MUFG Bank, Ltd.">MUFG Bank, Ltd. (三菱UFJ銀行)</option>
              <option value="Sumitomo Mitsui Banking Corporation">Sumitomo Mitsui Banking Corporation (三井住友銀行)</option>
              <option value="Mizuho Bank, Ltd.">Mizuho Bank, Ltd. (みずほ銀行)</option>
              <option value="Nomura Securities Co., Ltd.">Nomura Securities Co., Ltd. (野村證券)</option>
              <option value="Daiwa Capital Markets Japan">Daiwa Capital Markets Japan (大和証券)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-600 font-semibold mb-1">Beneficiary Institution</label>
            <select
              value={receiverName}
              onChange={(e) => setReceiverName(e.target.value)}
              className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-semibold focus:outline-none"
            >
              <option value="Sumitomo Mitsui Banking Corporation">Sumitomo Mitsui Banking Corporation (三井住友銀行)</option>
              <option value="MUFG Bank, Ltd.">MUFG Bank, Ltd. (三菱UFJ銀行)</option>
              <option value="Mizuho Bank, Ltd.">Mizuho Bank, Ltd. (みずほ銀行)</option>
              <option value="Nomura Securities Co., Ltd. font-semibold">Nomura Securities Co., Ltd. (野村證券)</option>
              <option value="SBI Financial Services">SBI Financial Services (SBIホールディングス)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-600 font-semibold mb-1">Settlement Instrument</label>
              <select
                value={instrument}
                onChange={(e) => setInstrument(e.target.value as InstrumentType)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-semibold focus:outline-none"
              >
                <option value="JSY">JSY — JSB Yen Claim</option>
                <option value="JTD">JTD — Tokenised Deposit</option>
                <option value="JSC">JSC — Settlement Credit</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-600 font-semibold mb-1">Amount (¥ Billions JPY)</label>
              <input
                type="number"
                min="0.5"
                step="0.5"
                max="500"
                value={amountBillion}
                onChange={(e) => setAmountBillion(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-mono font-bold text-slate-900 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-600 font-semibold mb-1">Settlement Mode</label>
            <select
              value={settlementMode}
              onChange={(e) => setSettlementMode(e.target.value as any)}
              className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-semibold focus:outline-none"
            >
              <option value="GROSS_T0">Real-Time Gross Settlement (GROSS_T0)</option>
              <option value="NET_BATCH_EOD">End-of-Day Bilateral Net Batch (NET_BATCH_EOD)</option>
              <option value="DVP_SIMULATION">Delivery-vs-Payment Bond Swap (DVP_SIMULATION)</option>
            </select>
          </div>

          {settlementMode === 'DVP_SIMULATION' && (
            <div>
              <label className="block text-slate-600 font-semibold mb-1">JGB Bond Security Reference</label>
              <input
                type="text"
                value={dvpRef}
                onChange={(e) => setDvpRef(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xs font-mono focus:outline-none"
              />
            </div>
          )}

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-red-700 hover:bg-red-800 text-white font-bold rounded-xs shadow-xs"
            >
              Submit Instruction to PoS Network
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
