# System Architecture — Japanese Specie Bank (JSB)

## Overview & Service Boundaries

JSB employs a micro-service architecture separating deterministic transaction execution from high-level orchestration, financial risk analytics, authoritative ledger storage, and institutional user interfaces.

```
+---------------------------------------------------------------------------------+
|                               React + TypeScript UI                             |
|                        Institutional Terminal & Executive Dashboard             |
+---------------------------------------------------------------------------------+
                                       |
                                       v
+---------------------------------------------------------------------------------+
|                               FastAPI / Express API Gateway                     |
|                   Idempotency, Maker-Checker Auth, Schema Validation             |
+---------------------------------------------------------------------------------+
       |                               |                              |
       v                               v                              v
+------------------------+  +--------------------+  +-----------------------------+
|    Python Engine       |  |   Rust Consensus   |  |        R Analytics          |
|  Reserve Reconciliation|  | Deterministic Ledger| | Liquidity-at-Risk, Monte    |
|  Issuance & Compliance |  |  PoS Validator Net |  | Carlo, Yield Curve Shocks   |
+------------------------+  +--------------------+  +-----------------------------+
       |                               |                              |
       +-------------------------------+------------------------------+
                                       |
                                       v
+---------------------------------------------------------------------------------+
|                               PostgreSQL Database                               |
|        Authoritative Double-Entry Ledger, Audit Trail, System Governance State  |
+---------------------------------------------------------------------------------+
```

## Module Responsibilities

1. **Rust Core Consensus Client (`jsb-consensus`)**:
   - Manages validator attestations, block proposal verification, state root hashing, and slashing penalties.
   - Enforces deterministic, integer-based state transitions.

2. **Python Monetary Service (`jsb-monetary-service`)**:
   - Manages dual-control issuance/redemption proposals.
   - Reconciles reserve reports against custodian API feeds.
   - Validates legal instrument scopes and counterparty concentration limits.

3. **R Risk Subsystem (`jsb-risk-r`)**:
   - Runs Monte Carlo simulations for reserve liquidity runs.
   - Computes JGB price sensitivity (duration/convexity) under BOJ yield curve shifts.

4. **PostgreSQL Ledger Engine**:
   - Holds authoritative general ledger accounts (`account_id`, `balance_jpy`, `account_type`).
   - Transaction table with strict double-entry debits/credits symmetry.

5. **React Terminal Interface**:
   - High-density JST financial clock, 13 functional modules, real-time PoS block ticker, DvP settlement instruction creator, and audit log exporter.
