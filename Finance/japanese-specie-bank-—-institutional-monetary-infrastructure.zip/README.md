# Japanese Specie Bank (JSB) — 日本正金銀行
## Institutional Yen Monetary & Proof-of-Stake Settlement Infrastructure

Japanese Specie Bank (JSB) is an institutional monetary technology platform engineered for Japan's yen monetary system. It integrates yen-denominated digital claims, tokenised commercial deposits, permissioned Proof-of-Stake (PoS) settlement, double-entry ledger accounting, collateral haircut management, liquidity stress testing, and legal compliance workflows.

---

### Core Architecture & Instrument Classes

JSB enforces a strict separation between three distinct financial instrument classes:

1. **JSB Yen Claim (JSY)**: Yen-denominated digital payment instrument target pegged at 1 JSY = ¥1. Issued under the Payment Services Act (PSA) of Japan as an electronic fund transfer claim, backed 100%+ by liquid reserve assets (BOJ cash balances, short-dated JGBs, and triparty repo).
2. **JSB Tokenised Deposit (JTD)**: Tokenised commercial bank deposits modeled strictly as direct liabilities of participating Japanese commercial banks (MUFG, SMBC, Mizuho, Resona, Nomura Trust, Norinchukin).
3. **JSB Settlement Credit (JSC)**: Sandbox institutional net-settlement credit line used for interbank sandbox simulations with bilateral collateral haircuts, maturity windows, and exposure caps.

---

### Multi-Tiered Technology Stack

- **Rust Subsystem**: Deterministic PoS consensus engine, state transition validation, cryptographic signatures, replay protection, integer math ledger primitives.
- **Python Subsystem**: Monetary issuance controls, reserve reconciliation, dual-control maker-checker rules, risk engine APIs.
- **R Subsystem**: Monte Carlo liquidity-at-risk simulation, yield curve shock models, JGB haircut sensitivity stress testing.
- **PostgreSQL**: Authoritative double-entry general ledger (`SUM(Debits) == SUM(Credits)` invariant enforcement), audit logs, and account balances.
- **React + TypeScript + Tailwind**: High-density institutional terminal styled after Japanese merchant banking standards.

---

### Key Capabilities

- **13 Institutional Dashboard Modules**: Executive Overview, Instruments, Issuance/Redemption, PoS Validators, Reserves, Settlement & DvP, Yen Markets, Risk & Liquidity, Double-Entry Accounting, Compliance & Sanctions, Governance & Slashing, Audit Logs, System Admin.
- **Integer JPY Ledger Engine**: Zero floating-point drift. All ledger amounts are accounted in exact Japanese Yen.
- **Dual-Control Maker-Checker**: Issuance and destruction proposals require explicit secondary authorization.
- **Reserve Haircuts & Coverage Ratio**: Operational risk monitoring with automated hair-cut calculations across asset classes.
- **Interactive Simulation**: Sandbox PoS block production, validator slashing, market curve shocks, and payment instruction settlement.

---

### Quick Start (Local Setup)

```bash
# 1. Clone & Install Dependencies
npm install

# 2. Run Development Server (Vite + Express Backend)
npm run dev

# 3. Build & Verify
npm run build
npm run lint
```
