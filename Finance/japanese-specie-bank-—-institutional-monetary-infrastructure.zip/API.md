# API Documentation — Japanese Specie Bank REST Service

## Core Endpoints

### 1. System Overview
`GET /api/overview`
Returns high-level monetary metrics: JSY supply, JTD deposits, JSC exposures, reserve coverage ratio, validator network state, and JST server time.

### 2. Issuance Engine
`POST /api/issuance/propose`
Request body:
```json
{
  "instrument": "JSY",
  "amount_jpy": 5000000000,
  "recipient_id": "INST_MUFG_01",
  "backing_asset_id": "RES_BOJ_CASH_01",
  "reason": "Institutional Liquidity Expansion"
}
```

`POST /api/issuance/approve`
Approves a pending issuance proposal (Requires Checker authorization).

### 3. Reserve Management
`GET /api/reserves`
Returns active reserve assets, nominal/market values, hair-cuts, and calculated coverage ratio.

### 4. PoS Validator Network
`GET /api/validators`
Returns list of registered institutional validators, stake weight, block uptime, and missed attestations.

### 5. Double-Entry General Ledger
`GET /api/ledger`
Returns trial balance, account breakdown, and posted debits/credits balance verification (`SUM(Debits) == SUM(Credits)`).
