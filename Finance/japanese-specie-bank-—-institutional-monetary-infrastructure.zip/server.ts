import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { monetaryStore } from './src/services/monetaryStore';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

// --- REST API Endpoints ---

// 1. Executive Overview
app.get('/api/overview', (req, res) => {
  const state = monetaryStore.getState();
  res.json({
    success: true,
    data: {
      jsy: {
        totalSupplyJPY: state.jsy.totalSupplyJPY.toString(),
        reserveCoverageRatio: state.jsy.reserveCoverageRatio,
        status: state.jsy.status,
      },
      consensus: state.consensus,
      trialBalance: {
        totalDebits: state.trialBalance.totalDebits.toString(),
        totalCredits: state.trialBalance.totalCredits.toString(),
        isBalanced: state.trialBalance.isBalanced,
      },
      activeValidatorsCount: state.validators.filter((v) => v.status === 'ACTIVE').length,
    },
  });
});

// 2. Instrument Details
app.get('/api/instruments', (req, res) => {
  const state = monetaryStore.getState();
  res.json({
    success: true,
    data: {
      jsy: {
        ...state.jsy,
        totalSupplyJPY: state.jsy.totalSupplyJPY.toString(),
        redeemableLiabilitiesJPY: state.jsy.redeemableLiabilitiesJPY.toString(),
      },
      jtdList: state.jtdList.map((j) => ({
        ...j,
        balanceJPY: j.balanceJPY.toString(),
      })),
      jscList: state.jscList.map((c) => ({
        ...c,
        creditLimitJPY: c.creditLimitJPY.toString(),
        utilizedJPY: c.utilizedJPY.toString(),
        availableJPY: c.availableJPY.toString(),
      })),
    },
  });
});

// 3. Dual-Control Proposal Endpoint
app.post('/api/issuance/propose', (req, res) => {
  try {
    const { type, instrument, amountJPY, proposerName, backingAssetId, legalJustification } = req.body;
    if (!type || !instrument || !amountJPY || !proposerName) {
      return res.status(400).json({ success: false, error: 'Missing required parameters' });
    }

    const prop = monetaryStore.createIssuanceProposal({
      type,
      instrument,
      amountJPY: BigInt(amountJPY),
      proposerName,
      backingAssetId: backingAssetId || 'RES-BOJ-CASH-01',
      legalJustification: legalJustification || 'Standard Treasury Mint Request',
    });

    res.json({
      success: true,
      data: {
        ...prop,
        amountJPY: prop.amountJPY.toString(),
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Approve Proposal (Checker)
app.post('/api/issuance/approve', (req, res) => {
  try {
    const { proposalId, approverName } = req.body;
    if (!proposalId || !approverName) {
      return res.status(400).json({ success: false, error: 'proposalId and approverName required' });
    }

    monetaryStore.approveAndExecuteProposal(proposalId, approverName);
    res.json({ success: true, message: `Proposal ${proposalId} executed successfully` });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// 5. General Ledger & Trial Balance
app.get('/api/ledger', (req, res) => {
  const state = monetaryStore.getState();
  res.json({
    success: true,
    data: {
      trialBalance: {
        totalDebits: state.trialBalance.totalDebits.toString(),
        totalCredits: state.trialBalance.totalCredits.toString(),
        isBalanced: state.trialBalance.isBalanced,
      },
      accounts: state.accounts.map((a) => ({
        ...a,
        balanceJPY: a.balanceJPY.toString(),
        debitsJPY: a.debitsJPY.toString(),
        creditsJPY: a.creditsJPY.toString(),
      })),
      entries: state.glEntries.map((e) => ({
        ...e,
        amountJPY: e.amountJPY.toString(),
      })),
    },
  });
});

// 6. Audit Logs Export
app.get('/api/audit/export', (req, res) => {
  const state = monetaryStore.getState();
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', 'attachment; filename="jsb-audit-trail-export.json"');
  res.json({
    exportTimestampJST: `${new Date().toISOString()} JST`,
    institution: 'Japanese Specie Bank',
    auditLogs: state.auditLogs,
  });
});

// --- Vite Dev Middleware Setup ---
const PORT = process.env.PORT || 3000;

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[JSB MONETARY SERVER] Running on http://localhost:${PORT}`);
  });
}

startServer();
