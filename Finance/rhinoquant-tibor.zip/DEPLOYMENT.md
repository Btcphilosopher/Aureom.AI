# RHINOQUANT SECURITY, LICENSING & DEPLOYMENT

## 1. Security Architecture
- **Authentication**: API Keys with prefix hashing (`rq_live_...`), JWT bearer tokens, and optional mTLS for institutional cross-connects.
- **Role-Based Access Control (RBAC)**: `READ_ONLY`, `ANALYST`, `TRADER`, `RISK`, `ADMIN`, `DATA_ENGINEER`, `AUDITOR`.
- **Rate Limiting**: Tiered token-bucket rate limiting returning HTTP 429 with `Retry-After`.

## 2. Licensing Governance
- Every market data observation is linked to a `DataLicence`.
- Entitlements: `TIBOR_REALTIME`, `TIBOR_HISTORICAL`, `TIBOR_CURVES`, `DERIVED_ANALYTICS`, `BULK_EXPORT`.
- Strict safeguards prevent accidental redistribution of non-redistributable proprietary market feeds.

## 3. Deployment & Operations
- **Containerization**: `docker compose up -d` boots API, PostgreSQL 16, Redis 7, worker services, and OpenTelemetry instrumentation.
- **Monitoring**: Prometheus metrics exported at `/metrics`:
  - `api_requests_total`
  - `api_latency_seconds`
  - `fixings_received_total`
  - `publication_delay_seconds`
  - `data_quality_errors_total`

## 4. Testing & Verification
- Unit & Property tests: Verified via JVM tests (`:app:testDebugUnitTest`) and Rust cargo tests (`cargo test`).
- Independent Model Validation: Validated using R statistical engine (`r/validation/tibor_validation.R`).
