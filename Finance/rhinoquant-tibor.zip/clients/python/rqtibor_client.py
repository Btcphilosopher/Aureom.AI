"""RhinoQuant TIBOR API Official Python Client."""

import httpx
from typing import Any, Dict, Optional


class RhinoQuantTiborClient:
    """Institutional Client for RhinoQuant Japanese Yen Rates API."""

    def __init__(self, base_url: str = "http://localhost:8000", api_key: Optional[str] = None):
        self.base_url = base_url.rstrip("/")
        self.headers = {"X-API-KEY": api_key} if api_key else {}

    async def get_latest_fixings(self) -> Dict[str, Any]:
        """Fetch current JBA TIBOR fixings across all published tenors."""
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{self.base_url}/api/v1/tibor/latest", headers=self.headers)
            resp.raise_for_status()
            return resp.json()

    async def get_fixing(self, date: str, tenor: str = "3M") -> Dict[str, Any]:
        """Fetch verified fixing for specific date and tenor."""
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{self.base_url}/api/v1/tibor",
                params={"date": date, "tenor": tenor},
                headers=self.headers
            )
            resp.raise_for_status()
            return resp.json()

    async def get_tibor_curve(self) -> Dict[str, Any]:
        """Fetch current term structure zero curve and discount factors."""
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{self.base_url}/api/v1/curves/tibor", headers=self.headers)
            resp.raise_for_status()
            return resp.json()

    async def get_tokyo_terminal_overview(self) -> Dict[str, Any]:
        """Fetch compact high-speed Tokyo Rates overview."""
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"{self.base_url}/terminal/v1/tokyo/overview", headers=self.headers)
            resp.raise_for_status()
            return resp.json()
