use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum ClientError {
    #[error("Network HTTP error: {0}")]
    Http(#[from] reqwest::Error),
    #[error("API error response: {0}")]
    Api(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LatestFixingsResponse {
    pub benchmark: String,
    pub currency: String,
    pub fixing_date: String,
    pub rates: std::collections::HashMap<String, Option<f64>>,
    pub derived: bool,
}

pub struct RhinoQuantClient {
    base_url: String,
    http: reqwest::Client,
    api_key: Option<String>,
}

impl RhinoQuantClient {
    pub fn new(base_url: &str, api_key: Option<&str>) -> Self {
        Self {
            base_url: base_url.trim_end_matches('/').to_string(),
            http: reqwest::Client::new(),
            api_key: api_key.map(|s| s.to_string()),
        }
    }

    pub async fn get_latest(&self) -> Result<LatestFixingsResponse, ClientError> {
        let url = format!("{}/api/v1/tibor/latest", self.base_url);
        let mut req = self.http.get(&url);
        if let Some(ref key) = self.api_key {
            req = req.header("X-API-KEY", key);
        }
        let res = req.send().await?.json::<LatestFixingsResponse>().await?;
        Ok(res)
    }
}
