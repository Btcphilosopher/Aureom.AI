# RHINOQUANT TIBOR API: ENDPOINT REFERENCE

Base Path: `/api/v1`
Terminal Base Path: `/terminal/v1`

## 1. Benchmarks
- `GET /api/v1/benchmarks` — List supported money market benchmarks.
- `GET /api/v1/benchmarks/{benchmark}` — Benchmark metadata and methodology details.
- `GET /api/v1/benchmarks/{benchmark}/calendar` — Tokyo holiday calendar and 13:00 JST fixing schedule.

## 2. Official TIBOR Fixings
- `GET /api/v1/tibor?date={date}&tenor={tenor}` — Retrieve verified fixing for given date and tenor.
- `GET /api/v1/tibor/latest` — Retrieve current fixings across all published tenors (1W, 1M, 3M, 6M, 12M).
- `GET /api/v1/tibor/history?start_date={start}&end_date={end}&tenor={tenor}` — Historical time series query.
- `GET /api/v1/tibor/export?format=PARQUET` — Trigger asynchronous bulk historical export.
- `GET /api/v1/jobs/{job_id}` — Query status of asynchronous export job.

## 3. Analytics & Curves
- `GET /api/v1/curves/tibor` — Monotonic cubic Hermite spline term structure curve.
- `POST /api/v1/curves/tibor/build` — Custom curve interpolation with user parameters.
- `GET /api/v1/forwards/tibor?start={start}&end={end}` — Continuous compounded implied forward rate.
- `GET /api/v1/basis/tibor-tona?tenor=3M` — TIBOR vs TONA basis spread analysis.
- `GET /api/v1/tibor/change` — 1D, 5D, 1M, 3M, 6M, 1Y delta metrics in basis points.
- `GET /api/v1/tibor/volatility` — 20D, 60D, 120D, 250D annualised rolling volatility.
- `GET /api/v1/tibor/regime` — Analytical regime classification (RISING, FALLING, STABLE, etc.).

## 4. Institutional Terminal & WebSocket
- `GET /terminal/v1/tokyo/overview` — High-speed compact overview payload for terminal boot.
- `WS /ws/v1/tibor` — Low-latency WebSocket streaming feed for terminal tickers.

## 5. Research Laboratory
- `POST /api/v1/research/tibor/calculate` — JBATA trimmed arithmetic mean simulator (8+ submissions, exclude 2 high & 2 low).
