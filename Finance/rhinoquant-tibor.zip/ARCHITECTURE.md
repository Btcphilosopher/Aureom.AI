# RHINOQUANT TIBOR API: ARCHITECTURE SPECIFICATION

## 1. High-Level System Architecture

```
                  ┌──────────────────────────────────────────────┐
                  │          AUTHORISED JBATA PROVIDER           │
                  │ (Direct line / Bloomberg B-PIPE / Refinitiv) │
                  └──────────────────────┬───────────────────────┘
                                         │
                                         ▼
                              ┌─────────────────────┐
                              │  INGESTION SERVICE  │ (Idempotent, Content-Hash)
                              └──────────┬──────────┘
                                         │
                                         ▼
                              ┌─────────────────────┐
                              │  VALIDATION ENGINE  │ (Z-Score, Monotonicity, Tenor Integrity)
                              └──────────┬──────────┘
                                         │
                         ┌───────────────┴───────────────┐
                         ▼                               ▼
                 RAW MARKET DATA                  NORMALISED DATA
              (Immutable Audit Log)          (Canonical Fixings Store)
                         │                               │
                         └───────────────┬───────────────┘
                                         ▼
                              ┌─────────────────────┐
                              │  TIBOR DATA STORE   │ (PostgreSQL 16 + TimescaleDB)
                              └──────────┬──────────┘
                                         │
            ┌────────────────────────────┼───────────────────────────┐
            ▼                            ▼                           ▼
     HISTORICAL DATA                 CURVES & FORWARDS            RISK & SHOCK
    (Parquet / Polars)             (Rust Engine SIMD Spline)     (DV01 Scenarios)
            │                            │                           │
            ▼                            ▼                           ▼
       REST / BULK API            ANALYTICS SERVICE           TERMINAL ENGINE
      (/api/v1/tibor)           (/api/v1/curves/tibor)     (/terminal/v1/tokyo)
```

## 2. Ingestion & Invariant Guarantee

1. **Idempotence**: Every incoming message receives a deterministic content hash (`SHA-256`). Replayed or duplicate observations cannot produce duplicate fixings in the canonical store.
2. **Four-Tier Separation**:
   - `OFFICIAL JBA TIBOR`: Benchmark reference published by JBATA.
   - `SOURCE & PROVENANCE`: Metadata tracing publisher, ingress timing, and license entitlement.
   - `NORMALISED RHINOQUANT DATA`: Storage in canonical domain representation.
   - `DERIVED ANALYTICS`: Curves, forwards, basis spreads. Explicitly marked `derived=true`.

## 3. Technology Matrix

- **Backend Framework**: Python 3.12+, FastAPI, Pydantic v2
- **Performance Layer**: Rust (`rust/tibor_engine`)
- **Statistical Quality**: R (`r/validation`)
- **Terminal UI**: Native Android Jetpack Compose Tokyo Rates Terminal
- **Database**: PostgreSQL 16
- **Bulk Storage**: Apache Parquet / PyArrow / Polars
