# RHINOQUANT CURVES & ANALYTICAL DERIVATION

## 1. Zero Curve Construction
RhinoQuant uses a Monotonic Cubic Hermite Spline (Fritsch-Carlson algorithm) to interpolate zero rates across published pillars (1W, 1M, 3M, 6M, 12M).
- **Monotonicity**: Ensures artificial oscillations do not produce negative forward rates in steep curve regimes.
- **Continuous Compounding Discount Factor**:
  $$DF(t) = \exp\left( - \frac{r(t)}{100} \cdot \frac{t}{365} \right)$$

## 2. Forward Rate Calculation
Implied forward rates between period $t_1$ and $t_2$:
$$F(t_1, t_2) = \frac{r(t_2) t_2 - r(t_1) t_1}{t_2 - t_1}$$

## 3. TIBOR-TONA Basis
The spread over the Tokyo Overnight Average Rate (TONA) isolates bank credit and term liquidity premiums in Tokyo call markets:
$$\text{Basis}_{3M} = (\text{TIBOR}_{3M} - \text{TONA}) \times 100 \text{ bp}$$
