"""RhinoQuant Institutional Rates Domain Models & Typing."""

from decimal import Decimal
from enum import Enum
from typing import Dict, List, Optional
from pydantic import BaseModel, Field
from datetime import date, datetime


class TenorCode(str, Enum):
    W1 = "1W"
    M1 = "1M"
    M3 = "3M"
    M6 = "6M"
    M12 = "12M"


class BenchmarkStatus(str, Enum):
    OFFICIAL = "OFFICIAL"
    CORRECTED = "CORRECTED"
    PROVISIONAL = "PROVISIONAL"
    REFERENCE = "REFERENCE"
    SYNTHETIC = "SYNTHETIC"
    DERIVED = "DERIVED"


class PublicationStatus(str, Enum):
    EXPECTED = "EXPECTED"
    PUBLISHED = "PUBLISHED"
    DELAYED = "DELAYED"
    WITHHELD = "WITHHELD"
    CORRECTED = "CORRECTED"
    CONTINGENCY = "CONTINGENCY"


class SourceType(str, Enum):
    AUTHORISED_PROVIDER = "AUTHORISED_PROVIDER"
    REFERENCE_WEBSITE = "REFERENCE_WEBSITE"
    LICENSED_MARKET_DATA = "LICENSED_MARKET_DATA"
    MOCK_PROVIDER = "MOCK_PROVIDER"


class SourceRecord(BaseModel):
    provider: str
    source_type: SourceType
    retrieved_at: datetime
    published_at: datetime
    source_identifier: str
    checksum: str
    licence: str
    entitlement: str
    authoritative: bool = True


class TiborFixing(BaseModel):
    id: str
    fixing_date: date
    publication_timestamp: datetime
    currency: str = "JPY"
    benchmark: str = "JBA_TIBOR"
    tenor: TenorCode
    rate: Decimal
    unit: str = "percent"
    status: BenchmarkStatus = BenchmarkStatus.OFFICIAL
    source: SourceRecord
    source_timestamp: datetime
    revision: int = 0
    effective_from: datetime
    effective_to: Optional[datetime] = None
    derived: bool = False


class TenorMetadata(BaseModel):
    code: TenorCode
    name: str
    days: int
    frequency_per_year: float
    active: bool = True


class TenorRegistry:
    """Versioned registry for benchmark tenors."""
    
    _TENORS: Dict[TenorCode, TenorMetadata] = {
        TenorCode.W1: TenorMetadata(code=TenorCode.W1, name="1 Week", days=7, frequency_per_year=52.0),
        TenorCode.M1: TenorMetadata(code=TenorCode.M1, name="1 Month", days=30, frequency_per_year=12.0),
        TenorCode.M3: TenorMetadata(code=TenorCode.M3, name="3 Months", days=90, frequency_per_year=4.0),
        TenorCode.M6: TenorMetadata(code=TenorCode.M6, name="6 Months", days=180, frequency_per_year=2.0),
        TenorCode.M12: TenorMetadata(code=TenorCode.M12, name="12 Months", days=360, frequency_per_year=1.0),
    }

    @classmethod
    def get(cls, code: TenorCode) -> Optional[TenorMetadata]:
        return cls._TENORS.get(code)

    @classmethod
    def list_all(cls) -> List[TenorMetadata]:
        return list(cls._TENORS.values())


class BenchmarkEntity(BaseModel):
    id: str = "JBA_TIBOR"
    name: str = "Japanese Yen TIBOR"
    short_name: str = "JBA TIBOR"
    name_ja: str = "日本円TIBOR"
    administrator: str = "JBA TIBOR Administration"
    jurisdiction: str = "Japan"
    currency: str = "JPY"
    status: str = "ACTIVE"
    methodology_version: str = "v2026.1"
    publication_frequency: str = "DAILY"
    publication_time: str = "13:00 JST"
    effective_date: str = "1995-11-01"
    termination_date: Optional[str] = None


class CorrectionEvent(BaseModel):
    original_rate: Decimal
    corrected_rate: Decimal
    reason: str
    announcement_timestamp: datetime
    effective_timestamp: datetime
    source: str
    reference: str
    status: str = "CONFIRMED" # PENDING, CONFIRMED, REJECTED, SUPERSEDED


class DataQualityReport(BaseModel):
    quality: str = "PASS" # PASS, WARNING, FAIL
    warnings: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class CalculationSnapshot(BaseModel):
    snapshot_id: str
    input_data_version: str
    methodology_version: str
    software_version: str
    configuration: Dict[str, str]
    timestamp: datetime
    result: Dict[str, float]
