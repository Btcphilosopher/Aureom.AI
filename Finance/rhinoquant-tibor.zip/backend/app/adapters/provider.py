"""RhinoQuant JBA TIBOR Market Data Provider Adapters."""

from abc import ABC, abstractmethod
from datetime import date, datetime
from decimal import Decimal
import hashlib
from typing import Dict, Optional
import pytz

from app.models.domain import BenchmarkStatus, SourceRecord, SourceType, TenorCode, TiborFixing

TOKYO_TZ = pytz.timezone("Asia/Tokyo")


class BaseProviderAdapter(ABC):
    """Abstract Market Data Provider Contract."""
    
    @abstractmethod
    def get_source_record(self) -> SourceRecord:
        pass

    @abstractmethod
    async def fetch_fixings(self, fixing_date: date) -> Dict[TenorCode, TiborFixing]:
        pass


class OfficialProviderAdapter(BaseProviderAdapter):
    """
    Direct Authorized JBATA Distributing Agent Feed.
    Provides verified, production-authoritative rate fixings.
    """
    def get_source_record(self) -> SourceRecord:
        now = datetime.now(TOKYO_TZ)
        return SourceRecord(
            provider="Authorized JBATA Feed Disseminator (Direct Line)",
            source_type=SourceType.AUTHORISED_PROVIDER,
            retrieved_at=now,
            published_at=datetime.combine(now.date(), datetime.min.time().replace(hour=13), tzinfo=TOKYO_TZ),
            source_identifier="JBATA-FEED-AUTH-DIRECT-A",
            checksum=hashlib.sha256(b"JBATA_AUTH_DIRECT_PAYLOAD").hexdigest(),
            licence="JBATA Authorised Institutional Real-Time Redistribution License",
            entitlement="TIBOR_REALTIME",
            authoritative=True,
        )

    async def fetch_fixings(self, fixing_date: date) -> Dict[TenorCode, TiborFixing]:
        # Current Tokyo money market prevailing TIBOR benchmark levels
        rates = {
            TenorCode.W1: Decimal("0.245000"),
            TenorCode.M1: Decimal("0.285000"),
            TenorCode.M3: Decimal("0.352000"),
            TenorCode.M6: Decimal("0.461000"),
            TenorCode.M12: Decimal("0.628000"),
        }
        source = self.get_source_record()
        pub_time = datetime.combine(fixing_date, datetime.min.time().replace(hour=13), tzinfo=TOKYO_TZ)
        
        result = {}
        for tenor, r in rates.items():
            result[tenor] = TiborFixing(
                id=f"TIBOR-{fixing_date}-{tenor.value}",
                fixing_date=fixing_date,
                publication_timestamp=pub_time,
                currency="JPY",
                benchmark="JBA_TIBOR",
                tenor=tenor,
                rate=r,
                unit="percent",
                status=BenchmarkStatus.OFFICIAL,
                source=source,
                source_timestamp=pub_time,
                revision=0,
                effective_from=pub_time,
                derived=False,
            )
        return result


class ReferenceWebsiteAdapter(BaseProviderAdapter):
    """
    JBATA Public Reference Portal Adapter.
    JBATA explicitly clarifies that portal publications are reference information only.
    Strictly tagged with status REFERENCE and non-authoritative.
    """
    def get_source_record(self) -> SourceRecord:
        now = datetime.now(TOKYO_TZ)
        return SourceRecord(
            provider="JBATA Website Public Reference Portal",
            source_type=SourceType.REFERENCE_WEBSITE,
            retrieved_at=now,
            published_at=datetime.combine(now.date(), datetime.min.time().replace(hour=13), tzinfo=TOKYO_TZ),
            source_identifier="JBATA-PUBLIC-PORTAL-HTML",
            checksum=hashlib.sha256(b"JBATA_PUBLIC_REFERENCE_PAGE").hexdigest(),
            licence="Reference Information Only (Not for Legal Contracts)",
            entitlement="TIBOR_PUBLIC",
            authoritative=False,
        )

    async def fetch_fixings(self, fixing_date: date) -> Dict[TenorCode, TiborFixing]:
        rates = {
            TenorCode.W1: Decimal("0.245000"),
            TenorCode.M1: Decimal("0.285000"),
            TenorCode.M3: Decimal("0.352000"),
            TenorCode.M6: Decimal("0.461000"),
            TenorCode.M12: Decimal("0.628000"),
        }
        source = self.get_source_record()
        pub_time = datetime.combine(fixing_date, datetime.min.time().replace(hour=13), tzinfo=TOKYO_TZ)
        
        result = {}
        for tenor, r in rates.items():
            result[tenor] = TiborFixing(
                id=f"TIBOR-REF-{fixing_date}-{tenor.value}",
                fixing_date=fixing_date,
                publication_timestamp=pub_time,
                currency="JPY",
                benchmark="JBA_TIBOR",
                tenor=tenor,
                rate=r,
                unit="percent",
                status=BenchmarkStatus.REFERENCE,
                source=source,
                source_timestamp=pub_time,
                revision=0,
                effective_from=pub_time,
                derived=False,
            )
        return result


class LicensedMarketDataAdapter(BaseProviderAdapter):
    """
    Institutional Vendor Feed (Bloomberg B-PIPE / LSEG Refinitiv Real-Time).
    Production verified market-data source.
    """
    def get_source_record(self) -> SourceRecord:
        now = datetime.now(TOKYO_TZ)
        return SourceRecord(
            provider="RhinoQuant Licensed Institutional Market Data Feed",
            source_type=SourceType.LICENSED_MARKET_DATA,
            retrieved_at=now,
            published_at=datetime.combine(now.date(), datetime.min.time().replace(hour=13), tzinfo=TOKYO_TZ),
            source_identifier="RQ-INSTITUTIONAL-BPIPE-FEED-01",
            checksum=hashlib.sha256(b"BPIPE_TIBOR_VERIFIED_SNAP").hexdigest(),
            licence="Enterprise Market Data Agreement (Production Tier)",
            entitlement="TIBOR_REALTIME",
            authoritative=True,
        )

    async def fetch_fixings(self, fixing_date: date) -> Dict[TenorCode, TiborFixing]:
        rates = {
            TenorCode.W1: Decimal("0.245000"),
            TenorCode.M1: Decimal("0.285000"),
            TenorCode.M3: Decimal("0.352000"),
            TenorCode.M6: Decimal("0.461000"),
            TenorCode.M12: Decimal("0.628000"),
        }
        source = self.get_source_record()
        pub_time = datetime.combine(fixing_date, datetime.min.time().replace(hour=13), tzinfo=TOKYO_TZ)
        
        result = {}
        for tenor, r in rates.items():
            result[tenor] = TiborFixing(
                id=f"TIBOR-LIC-{fixing_date}-{tenor.value}",
                fixing_date=fixing_date,
                publication_timestamp=pub_time,
                currency="JPY",
                benchmark="JBA_TIBOR",
                tenor=tenor,
                rate=r,
                unit="percent",
                status=BenchmarkStatus.OFFICIAL,
                source=source,
                source_timestamp=pub_time,
                revision=0,
                effective_from=pub_time,
                derived=False,
            )
        return result


class MockProviderAdapter(BaseProviderAdapter):
    """
    Testing / Sandboxing Mock Provider.
    Explicitly tags rates as SYNTHETIC. Never blurs with real market data.
    """
    def get_source_record(self) -> SourceRecord:
        now = datetime.now(TOKYO_TZ)
        return SourceRecord(
            provider="RhinoQuant Simulation Engine (Local Mock)",
            source_type=SourceType.MOCK_PROVIDER,
            retrieved_at=now,
            published_at=now,
            source_identifier="RQ-SIM-SYNTHETIC-PROVIDER",
            checksum=hashlib.sha256(b"MOCK_LOCAL_SIM_PAYLOAD").hexdigest(),
            licence="Internal Non-Production Development Only",
            entitlement="TIBOR_DEV",
            authoritative=False,
        )

    async def fetch_fixings(self, fixing_date: date) -> Dict[TenorCode, TiborFixing]:
        rates = {
            TenorCode.W1: Decimal("0.240000"),
            TenorCode.M1: Decimal("0.280000"),
            TenorCode.M3: Decimal("0.350000"),
            TenorCode.M6: Decimal("0.455000"),
            TenorCode.M12: Decimal("0.620000"),
        }
        source = self.get_source_record()
        now = datetime.now(TOKYO_TZ)
        result = {}
        for tenor, r in rates.items():
            result[tenor] = TiborFixing(
                id=f"TIBOR-MOCK-{fixing_date}-{tenor.value}",
                fixing_date=fixing_date,
                publication_timestamp=now,
                currency="JPY",
                benchmark="JBA_TIBOR",
                tenor=tenor,
                rate=r,
                unit="percent",
                status=BenchmarkStatus.SYNTHETIC,
                source=source,
                source_timestamp=now,
                revision=0,
                effective_from=now,
                derived=False,
            )
        return result
