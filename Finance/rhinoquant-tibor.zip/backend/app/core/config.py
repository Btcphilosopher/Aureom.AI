"""RhinoQuant TIBOR API Configuration."""

from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List


class Settings(BaseSettings):
    PROJECT_NAME: str = "rhinoquant-tibor-api"
    CODENAME: str = "RQTIBOR"
    VERSION: str = "1.4.0"
    API_V1_PREFIX: str = "/api/v1"
    TERMINAL_PREFIX: str = "/terminal/v1"
    
    ENVIRONMENT: str = "development"
    DEFAULT_TIMEZONE: str = "Asia/Tokyo"
    
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/rqtibor"
    REDIS_URL: str = "redis://localhost:6379/0"
    
    JWT_SECRET: str = "rhinoquant_rates_top_secret_key_change_in_production_2026"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    
    DEFAULT_PROVIDER: str = "LICENSED_MARKET_DATA" # LICENSED_MARKET_DATA, OFFICIAL_PROVIDER, REFERENCE_WEBSITE, MOCK_PROVIDER
    
    ALLOW_ORIGINS: List[str] = ["*"]
    
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
