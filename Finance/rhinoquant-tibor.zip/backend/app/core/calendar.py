"""RhinoQuant Institutional Japan Business Calendar & Publication Window Engine."""

from datetime import date, datetime, time, timedelta
from typing import Set, Tuple
import pytz

TOKYO_TZ = pytz.timezone("Asia/Tokyo")

# Japanese Statutory Holidays (2025 - 2027)
JAPAN_HOLIDAYS_SET: Set[date] = {
    # 2026 Holidays
    date(2026, 1, 1),   # New Year's Day
    date(2026, 1, 2),   # Bank Holiday
    date(2026, 1, 3),   # Bank Holiday
    date(2026, 1, 12),  # Coming of Age Day
    date(2026, 2, 11),  # National Foundation Day
    date(2026, 2, 23),  # Emperor's Birthday
    date(2026, 3, 20),  # Vernal Equinox Day
    date(2026, 4, 29),  # Showa Day
    date(2026, 5, 3),   # Constitution Memorial Day
    date(2026, 5, 4),   # Greenery Day
    date(2026, 5, 5),   # Children's Day
    date(2026, 5, 6),   # Substitute Holiday
    date(2026, 7, 20),  # Marine Day
    date(2026, 8, 11),  # Mountain Day
    date(2026, 9, 21),  # Respect for the Aged Day
    date(2026, 9, 22),  # Citizens' Holiday
    date(2026, 9, 23),  # Autumnal Equinox Day
    date(2026, 10, 12), # Sports Day
    date(2026, 11, 3),  # Culture Day
    date(2026, 11, 23), # Labor Thanksgiving Day
    date(2026, 12, 31), # Bank Holiday
}


class JapanBusinessCalendar:
    """Tokyo Interbank Money Market business calendar implementation."""
    
    def __init__(self, holidays: Set[date] = JAPAN_HOLIDAYS_SET):
        self.holidays = holidays
        
    def is_business_day(self, target_date: date) -> bool:
        """Determines if a given date is a Tokyo business day."""
        # Weekend check: Monday is 0, Sunday is 6
        if target_date.weekday() >= 5:
            return False
        if target_date in self.holidays:
            return False
        return True

    def next_business_day(self, current_date: date) -> date:
        """Returns the next valid Tokyo business day."""
        d = current_date + timedelta(days=1)
        while not self.is_business_day(d):
            d += timedelta(days=1)
        return d

    def prev_business_day(self, current_date: date) -> date:
        """Returns the previous valid Tokyo business day."""
        d = current_date - timedelta(days=1)
        while not self.is_business_day(d):
            d -= timedelta(days=1)
        return d

    def get_publication_window(self, market_date: date) -> Tuple[datetime, datetime, datetime]:
        """
        Returns (observation_cutoff, submission_deadline, scheduled_publication)
        in timezone-aware Asia/Tokyo.
        Official JBA TIBOR publication is at 13:00 JST.
        """
        obs_time = TOKYO_TZ.localize(datetime.combine(market_date, time(11, 0, 0)))
        sub_deadline = TOKYO_TZ.localize(datetime.combine(market_date, time(12, 0, 0)))
        pub_time = TOKYO_TZ.localize(datetime.combine(market_date, time(13, 0, 0)))
        return obs_time, sub_deadline, pub_time


calendar = JapanBusinessCalendar()
