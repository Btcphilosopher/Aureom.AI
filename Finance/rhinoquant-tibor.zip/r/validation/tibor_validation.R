#!/usr/bin/env Rscript
# RhinoQuant Institutional Rates - Independent Statistical Validation Engine
# Target: JBA Japanese Yen TIBOR Benchmark Quality & Time-Series Rigour
# Framework: R (data.table, xts, zoo, forecast, rugarch)

suppressPackageStartupMessages({
  if (requireNamespace("data.table", quietly = TRUE)) library(data.table)
  if (requireNamespace("zoo", quietly = TRUE)) library(zoo)
  if (requireNamespace("xts", quietly = TRUE)) library(xts)
})

validate_tibor_series <- function(dates, rates_3m, rates_6m = NULL) {
  df <- data.frame(
    date = as.Date(dates),
    rate_3m = as.numeric(rates_3m)
  )
  df <- df[order(df$date), ]
  n <- nrow(df)
  
  if (n < 10) {
    return(list(
      status = "INSUFFICIENT_DATA",
      observations = n
    ))
  }
  
  # 1. First-order differences (Daily Basis Point Jumps)
  diffs <- diff(df$rate_3m) * 100 # In basis points
  mean_jump <- mean(diffs, na.rm = TRUE)
  sd_jump <- sd(diffs, na.rm = TRUE)
  
  # 2. Extreme jump detection (|z| > 4.0)
  z_scores <- (diffs - mean_jump) / ifelse(sd_jump == 0, 1e-6, sd_jump)
  outlier_idx <- which(abs(z_scores) > 4.0)
  outlier_count <- length(outlier_idx)
  
  # 3. Monotonicity & Tenor Relationship (3M <= 6M in normal upward sloping regime)
  inversion_count <- 0
  if (!is.null(rates_6m) && length(rates_6m) == n) {
    inversions <- which(df$rate_3m > as.numeric(rates_6m))
    inversion_count <- length(inversions)
  }
  
  # 4. GARCH Volatility proxy (EWMA / rolling 20D)
  roll_vol_20d <- zoo::rollapply(diffs, width = 20, FUN = sd, fill = NA, align = "right")
  ann_vol <- tail(roll_vol_20d[!is.na(roll_vol_20d)], 1) * sqrt(250)
  
  # 5. Quality Classification
  quality_status <- if (outlier_count == 0) "PASS" else "WARNING"
  
  list(
    benchmark = "JBA_TIBOR",
    currency = "JPY",
    observations = n,
    date_start = as.character(min(df$date)),
    date_end = as.character(max(df$date)),
    mean_daily_jump_bp = round(mean_jump, 4),
    sd_daily_jump_bp = round(sd_jump, 4),
    annualised_vol_bp = round(if (length(ann_vol) > 0) ann_vol else 0, 4),
    outlier_count = outlier_count,
    curve_inversion_count = inversion_count,
    quality_status = quality_status,
    validation_engine = "RhinoQuant-R-Statistical-Engine/v2026.1"
  )
}

# Example execution if run standalone
if (!interactive()) {
  test_dates <- seq(from = as.Date("2026-01-01"), by = "days", length.out = 100)
  test_rates <- 0.25 + cumsum(rnorm(100, mean = 0.0005, sd = 0.002))
  res <- validate_tibor_series(test_dates, test_rates)
  cat("=== RhinoQuant R Statistical Validation Result ===\n")
  cat(paste("Quality Status: ", res$quality_status, "\n"))
  cat(paste("Observations:   ", res$observations, "\n"))
  cat(paste("Ann. Vol (bp):  ", res$annualised_vol_bp, "\n"))
}
