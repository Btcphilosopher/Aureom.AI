# RHINOQUANT TIBOR DATA MODEL SPECIFICATION

## 1. Relational Entities (PostgreSQL 16)

- `benchmarks`: Benchmark master definition (JBA_TIBOR, currency=JPY, administrator=JBATA, methodology=v2026.1).
- `benchmark_versions`: Versioned definition tags and trim rule parameters.
- `benchmark_fixings`: Canonical daily fixings with Decimal rates, revision counters, and timestamps.
- `source_observations`: Immutable raw market data payloads with SHA-256 hashes.
- `publication_events`: Daily publication lifecycle (EXPECTED, PUBLISHED, DELAYED, WITHHELD, CORRECTED, CONTINGENCY).
- `corrections`: Explicit audit trail linking original fixing to corrected fixing with timestamp and reasoning.
- `holidays` & `business_days`: Tokyo statutory holiday calendar and interbank working days.
- `reference_banks` & `submission_observations`: Anonymized/synthetic bank submission rows with trimming flags.
- `data_quality_events`: Real-time anomaly flags, z-score jumps, and resolution tracking.
- `curve_points` & `forward_rates`: Derived term structure points and implied forwards.
- `audit_events`: Regulatory operational audit logs.

## 2. Immutable Versioning
Historical observations are never mutated in place. If an official rate correction is issued:
```
Original Fixing (Rev 0) ──> Correction Event ──> Revised Fixing (Rev 1)
```
This guarantees RhinoQuant can answer both historical audit inquiries:
- "What rate did RhinoQuant hold at 14:00 JST on that date?"
- "What is the currently effective official value?"
