//! RhinoQuant Institutional JBA TIBOR Performance Engine
//!
//! Provides zero-cost abstraction high throughput computation for:
//! - Monotonic cubic Hermite spline curve interpolation
//! - Forward rate period derivation
//! - JBATA reference bank trimmed average calculation
//! - Rolling volatility (annualised) and z-score anomaly detection

use chrono::NaiveDate;
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum EngineError {
    #[error("Insufficient pillar points: minimum {0} required, got {1}")]
    InsufficientPillars(usize, usize),
    #[error("Reference banks count {0} below JBATA minimum required 8")]
    InsufficientReferenceBanks(usize),
    #[error("Non-monotonic pillar maturities detected")]
    NonMonotonicPillars,
    #[error("Computation domain error: {0}")]
    DomainError(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CurvePillar {
    pub tenor: String,
    pub days: f64,
    pub rate: f64, // In percent, e.g., 0.350000
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InterpolatedPoint {
    pub days: f64,
    pub zero_rate: f64,
    pub discount_factor: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ForwardResult {
    pub start_days: f64,
    pub end_days: f64,
    pub forward_rate: f64,
    pub period_label: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JbataTrimResult {
    pub all_submissions: Vec<f64>,
    pub sorted_submissions: Vec<f64>,
    pub excluded_high: Vec<f64>,
    pub excluded_low: Vec<f64>,
    pub included_submissions: Vec<f64>,
    pub calculated_average: f64,
}

/// Official JBATA Japanese Yen TIBOR calculation methodology:
/// Simple arithmetic average after excluding the two highest and two lowest submitted rates.
pub fn calculate_jbata_fixing(submissions: &[f64]) -> Result<JbataTrimResult, EngineError> {
    if submissions.len() < 8 {
        return Err(EngineError::InsufficientReferenceBanks(submissions.len()));
    }

    let mut sorted = submissions.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

    let n = sorted.len();
    let excluded_low = sorted[0..2].to_vec();
    let excluded_high = sorted[n - 2..n].to_vec();
    let included = sorted[2..n - 2].to_vec();

    let sum: f64 = included.iter().sum();
    let calculated_average = sum / (included.len() as f64);

    Ok(JbataTrimResult {
        all_submissions: submissions.to_vec(),
        sorted_submissions: sorted,
        excluded_high,
        excluded_low,
        included_submissions: included,
        calculated_average: (calculated_average * 1_000_000.0).round() / 1_000_000.0,
    })
}

/// Monotonic Cubic Hermite Spline (Fritsch-Carlson) interpolation for yield curves
pub fn interpolate_curve(pillars: &[CurvePillar], query_days: &[f64]) -> Result<Vec<InterpolatedPoint>, EngineError> {
    if pillars.len() < 2 {
        return Err(EngineError::InsufficientPillars(2, pillars.len()));
    }

    // Verify monotonic days
    for i in 1..pillars.len() {
        if pillars[i].days <= pillars[i - 1].days {
            return Err(EngineError::NonMonotonicPillars);
        }
    }

    let n = pillars.len();
    let mut h = vec![0.0; n - 1];
    let mut delta = vec![0.0; n - 1];

    for i in 0..n - 1 {
        h[i] = pillars[i + 1].days - pillars[i].days;
        delta[i] = (pillars[i + 1].rate - pillars[i].rate) / h[i];
    }

    // Tangents
    let mut d = vec![0.0; n];
    d[0] = delta[0];
    d[n - 1] = delta[n - 2];
    for i in 1..n - 1 {
        d[i] = (delta[i - 1] + delta[i]) * 0.5;
    }

    // Fritsch-Carlson monotonicity condition
    for i in 0..n - 1 {
        if delta[i] == 0.0 {
            d[i] = 0.0;
            d[i + 1] = 0.0;
        } else {
            let alpha = d[i] / delta[i];
            let beta = d[i + 1] / delta[i];
            let dist = alpha.hypot(beta);
            if dist > 3.0 {
                let tau = 3.0 / dist;
                d[i] = tau * alpha * delta[i];
                d[i + 1] = tau * beta * delta[i];
            }
        }
    }

    let mut results = Vec::with_capacity(query_days.len());

    for &qd in query_days {
        let rate = if qd <= pillars[0].days {
            pillars[0].rate
        } else if qd >= pillars[n - 1].days {
            pillars[n - 1].rate // Flat extrapolation
        } else {
            // Find bracket
            let mut idx = 0;
            while idx < n - 1 && pillars[idx + 1].days < qd {
                idx += 1;
            }
            let t = (qd - pillars[idx].days) / h[idx];
            let t2 = t * t;
            let t3 = t2 * t;

            let h00 = 2.0 * t3 - 3.0 * t2 + 1.0;
            let h10 = t3 - 2.0 * t2 + t;
            let h01 = -2.0 * t3 + 3.0 * t2;
            let h11 = t3 - t2;

            h00 * pillars[idx].rate
                + h10 * h[idx] * d[idx]
                + h01 * pillars[idx + 1].rate
                + h11 * h[idx] * d[idx + 1]
        };

        // Japanese Money Market: Actual/365 or Actual/360 daycount
        // Zero rate to continuous discount factor: df = exp(-rate/100 * days/365)
        let df = (-rate / 100.0 * (qd / 365.0)).exp();

        results.push(InterpolatedPoint {
            days: qd,
            zero_rate: rate,
            discount_factor: df,
        });
    }

    Ok(results)
}

/// Compute forward rate between two periods using continuous compounding
pub fn compute_forward_rate(
    r1: f64,
    t1_days: f64,
    r2: f64,
    t2_days: f64,
    label: &str,
) -> Result<ForwardResult, EngineError> {
    if t2_days <= t1_days {
        return Err(EngineError::DomainError("t2 must be strictly greater than t1".to_string()));
    }

    let y1 = t1_days / 365.0;
    let y2 = t2_days / 365.0;

    // F(t1, t2) = (r2 * y2 - r1 * y1) / (y2 - y1)
    let fwd = (r2 * y2 - r1 * y1) / (y2 - y1);

    Ok(ForwardResult {
        start_days: t1_days,
        end_days: t2_days,
        forward_rate: (fwd * 1_000_000.0).round() / 1_000_000.0,
        period_label: label.to_string(),
    })
}

/// Batch historical volatility calculation: annualised standard deviation of log returns
pub fn calculate_annualised_volatility(rates: &[f64], window: usize) -> Vec<f64> {
    if rates.len() < window || window < 2 {
        return vec![0.0; rates.len()];
    }

    let mut result = vec![0.0; rates.len()];

    for i in window..=rates.len() {
        let slice = &rates[i - window..i];
        let mean = slice.iter().sum::<f64>() / (window as f64);
        let var = slice.iter().map(|&x| (x - mean).powi(2)).sum::<f64>() / ((window - 1) as f64);
        let std_dev = var.sqrt();
        // Annualise with sqrt(250) business days
        result[i - 1] = std_dev * (250.0_f64).sqrt();
    }

    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_jbata_trimming() {
        let subs = vec![0.31, 0.32, 0.33, 0.34, 0.35, 0.36, 0.37, 0.38];
        let res = calculate_jbata_fixing(&subs).unwrap();
        assert_eq!(res.excluded_low, vec![0.31, 0.32]);
        assert_eq!(res.excluded_high, vec![0.37, 0.38]);
        assert_eq!(res.included_submissions, vec![0.33, 0.34, 0.35, 0.36]);
        assert_eq!(res.calculated_average, 0.345);
    }

    #[test]
    fn test_forward_computation() {
        let fwd = compute_forward_rate(0.20, 90.0, 0.35, 180.0, "3M-6M").unwrap();
        assert!(fwd.forward_rate > 0.40);
    }
}
