package com.example

import com.example.engine.JapanBusinessCalendar
import com.example.engine.TiborEngine
import com.example.model.BenchmarkStatus
import com.example.model.ProviderType
import com.example.model.TiborTenor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class TiborCalculationTest {

    private val engine = TiborEngine()

    @Test
    fun testJbataTrimmingAlgorithm() {
        // 8 bank submissions
        val submissions = listOf(0.31, 0.32, 0.33, 0.34, 0.35, 0.36, 0.37, 0.38)
        val result = engine.executeJbataCalculationLab(submissions)

        // Exclude 2 lowest (0.31, 0.32) and 2 highest (0.37, 0.38)
        assertEquals(2, result.excludedLow.size)
        assertEquals(2, result.excludedHigh.size)
        assertEquals(4, result.included.size)

        // Included are 0.33, 0.34, 0.35, 0.36 -> sum = 1.38 -> avg = 0.345
        assertEquals(0.345, result.calculatedAverage, 0.0001)
    }

    @Test
    fun testTokyoCalendarBusinessDays() {
        val cal = Calendar.getInstance(JapanBusinessCalendar.TOKYO_TIMEZONE)
        // New Year's Day 2026-01-01 is a holiday
        cal.set(2026, Calendar.JANUARY, 1)
        assertFalse(JapanBusinessCalendar.isBusinessDay(cal))

        // Normal Wednesday
        cal.set(2026, Calendar.JANUARY, 7)
        assertTrue(JapanBusinessCalendar.isBusinessDay(cal))
    }

    @Test
    fun testForwardRateFormula() {
        val forwards = engine.getForwardRates()
        assertNotNull(forwards)
        assertTrue(forwards.isNotEmpty())

        val fwd3x6 = forwards.find { it.periodLabel == "3M × 6M" }
        assertNotNull(fwd3x6)
        assertTrue(fwd3x6!!.forwardRate > 0.30)
    }

    @Test
    fun testBasisCalculation() {
        val overview = engine.getTokyoMarketOverview()
        val fixings = overview.fixings
        val r3m = fixings[TiborTenor.M3]?.rate?.toDouble() ?: 0.352
        val expectedBasis = ((r3m - overview.tona) * 100.0)
        assertEquals(expectedBasis, overview.basis3mBp, 0.5)
    }

    @Test
    fun testProvenanceNonBlurringRule() {
        // Official/Licensed provider MUST be OFFICIAL
        engine.activeProvider = ProviderType.LICENSED_MARKET_DATA
        var fixings = engine.getFixings()
        assertEquals(BenchmarkStatus.OFFICIAL, fixings[TiborTenor.M3]?.status)
        assertTrue(fixings[TiborTenor.M3]?.source?.isAuthoritative == true)

        // Reference website adapter MUST be tagged REFERENCE
        engine.activeProvider = ProviderType.REFERENCE_WEBSITE
        fixings = engine.getFixings()
        assertEquals(BenchmarkStatus.REFERENCE, fixings[TiborTenor.M3]?.status)
        assertFalse(fixings[TiborTenor.M3]?.source?.isAuthoritative == true)

        // Mock sandbox MUST be tagged SYNTHETIC
        engine.activeProvider = ProviderType.MOCK_PROVIDER
        fixings = engine.getFixings()
        assertEquals(BenchmarkStatus.SYNTHETIC, fixings[TiborTenor.M3]?.status)
    }

    @Test
    fun testCurveMonotonicDiscountFactors() {
        val curve = engine.getCurvePoints()
        assertEquals(5, curve.size)
        // Discount factors must decrease with maturity (DF_1W > DF_1M > DF_3M > DF_6M > DF_12M)
        for (i in 1 until curve.size) {
            assertTrue(curve[i - 1].discountFactor > curve[i].discountFactor)
        }
    }
}
