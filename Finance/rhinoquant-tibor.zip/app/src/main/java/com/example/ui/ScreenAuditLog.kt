package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun ScreenAuditLog(
    state: TerminalUiState,
    modifier: Modifier = Modifier
) {
    val events = state.auditEvents
    val dq = state.dataQuality

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        Text(
            text = "AUDIT <GO> REGULATORY COMPLIANCE & AUDIT TRAIL",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TerminalGold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "IOSCO Benchmark Principles & JBATA Audit Compliance",
            fontSize = 10.sp,
            color = TerminalTextMuted,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Data Quality Status Card
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DATA QUALITY ENGINE: ${dq.status}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TerminalGreen,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Passed ${dq.checksPassed}/${dq.checksTotal} Checks",
                        fontSize = 10.sp,
                        color = TerminalCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                dq.notes.forEach { note ->
                    Text(
                        text = "• $note",
                        fontSize = 10.sp,
                        color = TerminalTextSecondary,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Immutable Audit Events List
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "IMMUTABLE AUDIT EVENT LOG",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                events.forEach { ev ->
                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${ev.id} | ${ev.operation}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = TerminalCyan,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = ev.timestamp,
                                fontSize = 10.sp,
                                color = TerminalTextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = ev.detail,
                            fontSize = 10.sp,
                            color = TerminalTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Actor: ${ev.actor} | Resource: ${ev.resource}",
                                fontSize = 9.sp,
                                color = TerminalTextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = ev.status,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = TerminalGreen,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Divider(color = TerminalCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}
