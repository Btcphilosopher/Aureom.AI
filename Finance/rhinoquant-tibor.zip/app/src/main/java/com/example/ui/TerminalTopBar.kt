package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.SensorsOff
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.JapanBusinessCalendar
import com.example.model.ProviderType
import com.example.model.PublicationStatus
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalOrange
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun TerminalTopBar(
    state: TerminalUiState,
    onToggleLanguage: () -> Unit,
    onSetProvider: (ProviderType) -> Unit,
    onToggleLiveStreaming: () -> Unit,
    modifier: Modifier = Modifier
) {
    var providerMenuExpanded by remember { mutableStateOf(false) }

    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(width = 1.dp, color = TerminalCardBorder)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Upper row: Branding, Live Clock, and Action Toggles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & Codename
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (state.isLiveStreaming) TerminalGreen else TerminalRed)
                        .alpha(if (state.isLiveStreaming) pulseAlpha else 1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (state.isJapanese) "ライノクオンツ 東京" else "RHINOQUANT TOKYO",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TerminalGold,
                        letterSpacing = 1.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (state.isJapanese) "RQTIBOR 基準金利ターミナル" else "RQTIBOR BENCHMARK TERMINAL",
                        fontSize = 9.sp,
                        color = TerminalTextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Right side: Clock, Language Toggle, Stream Toggle
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Live JST Clock
                Text(
                    text = state.overview.timestampJst,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TerminalCyan,
                    modifier = Modifier
                        .background(Color(0xFF0F172A), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                )

                Spacer(modifier = Modifier.width(6.dp))

                // Language Toggle Button (EN / 日本語)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF1E293B))
                        .border(1.dp, TerminalGold.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .clickable { onToggleLanguage() }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                        .testTag("lang_toggle_button")
                ) {
                    Text(
                        text = if (state.isJapanese) "日本語" else "EN",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalGold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Live Stream Toggle
                IconButton(
                    onClick = onToggleLiveStreaming,
                    modifier = Modifier.size(32.dp).testTag("stream_toggle_button")
                ) {
                    Icon(
                        imageVector = if (state.isLiveStreaming) Icons.Default.Sensors else Icons.Default.SensorsOff,
                        contentDescription = "Toggle Streaming",
                        tint = if (state.isLiveStreaming) TerminalGreen else TerminalTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Lower row: Provider status pill & Publication status
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Source Provider selector
            Box {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF142032))
                        .border(1.dp, TerminalCyan.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                        .clickable { providerMenuExpanded = true }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                        .testTag("provider_dropdown_trigger")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = if (state.overview.source.isAuthoritative) TerminalGreen else TerminalOrange,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = when (state.activeProvider) {
                            ProviderType.OFFICIAL_PROVIDER, ProviderType.AUTHORISED_PROVIDER -> if (state.isJapanese) "JBATA公認配信" else "JBATA Direct Feed"
                            ProviderType.LICENSED_MARKET_DATA -> if (state.isJapanese) "認証ライセンス情報 (B-PIPE)" else "Licensed Market Feed"
                            ProviderType.REFERENCE_WEBSITE -> if (state.isJapanese) "JBATA参考Web (法的効力無)" else "JBATA Web (Reference)"
                            ProviderType.MOCK_PROVIDER -> if (state.isJapanese) "モック/シミュレータ" else "Simulation Mock"
                        },
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalTextPrimary
                    )
                    Text(
                        text = " ▾",
                        fontSize = 10.sp,
                        color = TerminalCyan
                    )
                }

                DropdownMenu(
                    expanded = providerMenuExpanded,
                    onDismissRequest = { providerMenuExpanded = false },
                    modifier = Modifier.background(TerminalSurface)
                ) {
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text("Licensed Market Data (Tier 1)", color = TerminalTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Authoritative Bloomberg B-PIPE verified feed", color = TerminalTextMuted, fontSize = 10.sp)
                            }
                        },
                        onClick = {
                            onSetProvider(ProviderType.LICENSED_MARKET_DATA)
                            providerMenuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text("Official Provider Adapter", color = TerminalTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Direct authorised dissemination agent", color = TerminalTextMuted, fontSize = 10.sp)
                            }
                        },
                        onClick = {
                            onSetProvider(ProviderType.OFFICIAL_PROVIDER)
                            providerMenuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text("Reference Website Adapter", color = TerminalOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("JBATA portal (Reference only, non-contractual)", color = TerminalTextMuted, fontSize = 10.sp)
                            }
                        },
                        onClick = {
                            onSetProvider(ProviderType.REFERENCE_WEBSITE)
                            providerMenuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = {
                            Column {
                                Text("Mock Provider Sandbox", color = TerminalGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Local simulation for testing and validation", color = TerminalTextMuted, fontSize = 10.sp)
                            }
                        },
                        onClick = {
                            onSetProvider(ProviderType.MOCK_PROVIDER)
                            providerMenuExpanded = false
                        }
                    )
                }
            }

            // Publication status badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (state.isJapanese) "公表状況: " else "PUB STATUS: ",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TerminalTextMuted
                )
                Text(
                    text = when (state.publicationStatus) {
                        PublicationStatus.PUBLISHED -> if (state.isJapanese) "公表済 (13:00 JST)" else "PUBLISHED (13:00 JST)"
                        PublicationStatus.EXPECTED -> if (state.isJapanese) "公表待機中" else "EXPECTED"
                        PublicationStatus.DELAYED -> if (state.isJapanese) "遅延発生" else "DELAYED"
                        PublicationStatus.CONTINGENCY -> if (state.isJapanese) "コンティンジェンシー" else "CONTINGENCY"
                        else -> state.publicationStatus.name
                    },
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = when (state.publicationStatus) {
                        PublicationStatus.PUBLISHED -> TerminalGreen
                        PublicationStatus.DELAYED, PublicationStatus.CONTINGENCY -> TerminalRed
                        else -> TerminalGold
                    }
                )
            }
        }
    }
}
