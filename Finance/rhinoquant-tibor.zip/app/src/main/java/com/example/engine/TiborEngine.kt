package com.example.engine

import com.example.model.AuditEvent
import com.example.model.BenchmarkStatus
import com.example.model.CurvePoint
import com.example.model.DataQualityStatus
import com.example.model.ForwardRate
import com.example.model.HistoricalObservation
import com.example.model.JbataLabResult
import com.example.model.ProviderType
import com.example.model.PublicationStatus
import com.example.model.ReferenceBankSubmission
import com.example.model.SourceRecord
import com.example.model.TiborFixing
import com.example.model.TiborTenor
import com.example.model.TokyoMarketOverview
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.exp
import kotlin.math.roundToInt

class TiborEngine {

    var activeProvider: ProviderType = ProviderType.LICENSED_MARKET_DATA
    var publicationStatus: PublicationStatus = PublicationStatus.PUBLISHED
    var isSimulationRunning: Boolean = false
    private var baseJitter: Double = 0.0

    fun getSourceRecord(type: ProviderType = activeProvider): SourceRecord {
        val nowJst = JapanBusinessCalendar.getCurrentJstTimeString()
        return when (type) {
            ProviderType.OFFICIAL_PROVIDER, ProviderType.AUTHORISED_PROVIDER -> SourceRecord(
                provider = "JBATA Authorised Disseminator (Direct Line)",
                type = ProviderType.OFFICIAL_PROVIDER,
                retrievedAt = nowJst,
                publishedAt = "13:00 JST",
                identifier = "JBATA-FEED-AUTH-01",
                checksum = "a7f3e82d491c8491...e92a",
                license = "Authorised Redistribution Agreement #JBATA-2026-09",
                isAuthoritative = true
            )
            ProviderType.REFERENCE_WEBSITE -> SourceRecord(
                provider = "JBATA Public Reference Portal (Website Scrape)",
                type = ProviderType.REFERENCE_WEBSITE,
                retrievedAt = nowJst,
                publishedAt = "13:00 JST",
                identifier = "JBATA-PUBLIC-PORTAL-HTML",
                checksum = "982b1c43f...81e0",
                license = "Public Reference Information Only (Non-Authoritative)",
                isAuthoritative = false
            )
            ProviderType.LICENSED_MARKET_DATA -> SourceRecord(
                provider = "RhinoQuant Licensed Institutional Vendor Feed",
                type = ProviderType.LICENSED_MARKET_DATA,
                retrievedAt = nowJst,
                publishedAt = "13:00 JST",
                identifier = "RQ-BPIPE-JPY-RATES-PRIME",
                checksum = "4bc710e6a882...fa11",
                license = "Institutional Real-Time Market Data Tier 1",
                isAuthoritative = true
            )
            ProviderType.MOCK_PROVIDER -> SourceRecord(
                provider = "RhinoQuant Local Simulation Sandbox",
                type = ProviderType.MOCK_PROVIDER,
                retrievedAt = nowJst,
                publishedAt = nowJst,
                identifier = "RQ-SIM-LOCAL-MOCK",
                checksum = "000000000000...0000",
                license = "Internal Synthetic Testing Sandbox",
                isAuthoritative = false
            )
        }
    }

    fun getFixings(): Map<TiborTenor, TiborFixing> {
        val src = getSourceRecord()
        val status = when (activeProvider) {
            ProviderType.OFFICIAL_PROVIDER, ProviderType.AUTHORISED_PROVIDER, ProviderType.LICENSED_MARKET_DATA -> BenchmarkStatus.OFFICIAL
            ProviderType.REFERENCE_WEBSITE -> BenchmarkStatus.REFERENCE
            ProviderType.MOCK_PROVIDER -> BenchmarkStatus.SYNTHETIC
        }

        val base1W = 0.245000 + baseJitter
        val base1M = 0.285000 + baseJitter
        val base3M = 0.352000 + baseJitter
        val base6M = 0.461000 + baseJitter
        val base12M = 0.628000 + baseJitter

        val dateStr = JapanBusinessCalendar.getCurrentJstDateString()
        val pubTime = "$dateStr 13:00:00 JST"

        return mapOf(
            TiborTenor.W1 to TiborFixing(
                id = "JBA_TIBOR_${dateStr}_1W",
                fixingDate = dateStr,
                publicationTimestamp = pubTime,
                tenor = TiborTenor.W1,
                rate = BigDecimal(base1W).setScale(6, RoundingMode.HALF_UP),
                status = status,
                source = src,
                changeBp1D = +0.4
            ),
            TiborTenor.M1 to TiborFixing(
                id = "JBA_TIBOR_${dateStr}_1M",
                fixingDate = dateStr,
                publicationTimestamp = pubTime,
                tenor = TiborTenor.M1,
                rate = BigDecimal(base1M).setScale(6, RoundingMode.HALF_UP),
                status = status,
                source = src,
                changeBp1D = +0.6
            ),
            TiborTenor.M3 to TiborFixing(
                id = "JBA_TIBOR_${dateStr}_3M",
                fixingDate = dateStr,
                publicationTimestamp = pubTime,
                tenor = TiborTenor.M3,
                rate = BigDecimal(base3M).setScale(6, RoundingMode.HALF_UP),
                status = status,
                source = src,
                changeBp1D = +0.8
            ),
            TiborTenor.M6 to TiborFixing(
                id = "JBA_TIBOR_${dateStr}_6M",
                fixingDate = dateStr,
                publicationTimestamp = pubTime,
                tenor = TiborTenor.M6,
                rate = BigDecimal(base6M).setScale(6, RoundingMode.HALF_UP),
                status = status,
                source = src,
                changeBp1D = +1.1
            ),
            TiborTenor.M12 to TiborFixing(
                id = "JBA_TIBOR_${dateStr}_12M",
                fixingDate = dateStr,
                publicationTimestamp = pubTime,
                tenor = TiborTenor.M12,
                rate = BigDecimal(base12M).setScale(6, RoundingMode.HALF_UP),
                status = status,
                source = src,
                changeBp1D = +1.5
            )
        )
    }

    fun getTokyoMarketOverview(): TokyoMarketOverview {
        val fixings = getFixings()
        val tonaRate = 0.228000 + (baseJitter * 0.8)
        val tibor3M = fixings[TiborTenor.M3]?.rate?.toDouble() ?: 0.352
        val basisBp = ((tibor3M - tonaRate) * 10000.0) / 100.0 // bp = (rate - tona)*100

        return TokyoMarketOverview(
            timestampJst = JapanBusinessCalendar.getCurrentJstTimeString(),
            publicationStatus = publicationStatus,
            source = getSourceRecord(),
            fixings = fixings,
            tona = tonaRate,
            tonaChangeBp1D = +0.2,
            basis3mBp = (basisBp * 10.0).roundToInt() / 10.0,
            jgb10Y = 0.985 + (baseJitter * 0.5),
            jgb30Y = 2.140 + (baseJitter * 0.3),
            jpySwap5Y = 0.720 + (baseJitter * 0.6),
            jpySwap10Y = 1.150 + (baseJitter * 0.5),
            usdjpy = 151.35 + (baseJitter * 10.0)
        )
    }

    fun getCurvePoints(): List<CurvePoint> {
        val fixings = getFixings()
        return TiborTenor.entries.map { tenor ->
            val rate = fixings[tenor]?.rate?.toDouble() ?: 0.3
            // Continuous discounting DF = exp(-rate/100 * days/365)
            val df = exp(- (rate / 100.0) * (tenor.days / 365.0))
            CurvePoint(
                tenor = tenor,
                days = tenor.days,
                zeroRate = rate,
                discountFactor = (df * 1000000.0).roundToInt() / 1000000.0
            )
        }
    }

    fun getForwardRates(): List<ForwardRate> {
        val fixings = getFixings()
        val r1 = fixings[TiborTenor.M1]?.rate?.toDouble() ?: 0.285
        val r3 = fixings[TiborTenor.M3]?.rate?.toDouble() ?: 0.352
        val r6 = fixings[TiborTenor.M6]?.rate?.toDouble() ?: 0.461
        val r12 = fixings[TiborTenor.M12]?.rate?.toDouble() ?: 0.628

        fun calcFwd(ra: Double, da: Int, rb: Double, db: Int): Double {
            val ya = da / 365.0
            val yb = db / 365.0
            return (rb * yb - ra * ya) / (yb - ya)
        }

        val fwd1x3 = calcFwd(r1, 30, r3, 90)
        val fwd3x6 = calcFwd(r3, 90, r6, 180)
        val fwd6x9 = calcFwd(r6, 180, (r6 + r12) / 2.0, 270)
        val fwd6x12 = calcFwd(r6, 180, r12, 360)

        return listOf(
            ForwardRate("1M × 3M", TiborTenor.M1, TiborTenor.M3, (fwd1x3 * 10000.0).roundToInt() / 10000.0, +3.8, 64.2),
            ForwardRate("3M × 6M", TiborTenor.M3, TiborTenor.M6, (fwd3x6 * 10000.0).roundToInt() / 10000.0, +5.4, 72.8),
            ForwardRate("6M × 9M", TiborTenor.M6, TiborTenor.M12, (fwd6x9 * 10000.0).roundToInt() / 10000.0, +7.1, 78.5),
            ForwardRate("6M × 12M", TiborTenor.M6, TiborTenor.M12, (fwd6x12 * 10000.0).roundToInt() / 10000.0, +8.9, 81.0)
        )
    }

    fun getHistoricalObservations(timeframe: String, tenor: TiborTenor): List<HistoricalObservation> {
        val count = when (timeframe) {
            "1D" -> 8
            "1W" -> 7
            "1M" -> 22
            "3M" -> 66
            "1Y" -> 250
            "5Y" -> 600
            else -> 100
        }

        val baseRate = (getFixings()[tenor]?.rate?.toDouble() ?: 0.352)
        val results = mutableListOf<HistoricalObservation>()
        val cal = Calendar.getInstance(JapanBusinessCalendar.TOKYO_TIMEZONE)
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = JapanBusinessCalendar.TOKYO_TIMEZONE }

        for (i in count - 1 downTo 0) {
            val stepCal = cal.clone() as Calendar
            stepCal.add(Calendar.DAY_OF_YEAR, -i)
            val dateStr = fmt.format(stepCal.time)
            
            // Historical realistic BOJ yield path
            val trendFactor = when (timeframe) {
                "5Y" -> (count - 1 - i).toDouble() / count * 0.38 - 0.05 // Negative to positive rate exit
                "1Y" -> (count - 1 - i).toDouble() / count * 0.22
                else -> (count - 1 - i).toDouble() / count * 0.04
            }
            val noise = kotlin.math.sin(i * 0.3) * 0.008
            val rateVal = (baseRate - trendFactor + noise).coerceAtLeast(-0.06)
            val prevRate = (baseRate - trendFactor + noise - 0.002)
            val chgBp = ((rateVal - prevRate) * 100.0)

            results.add(
                HistoricalObservation(
                    date = dateStr,
                    rate = (rateVal * 10000.0).roundToInt() / 10000.0,
                    changeBp = (chgBp * 10.0).roundToInt() / 10.0,
                    source = "Authorised Provider",
                    status = BenchmarkStatus.OFFICIAL
                )
            )
        }
        return results
    }

    fun executeJbataCalculationLab(customRates: List<Double>? = null): JbataLabResult {
        val baseBankNames = listOf(
            "SYNTH_BANK_01 (Major City Bank A)",
            "SYNTH_BANK_02 (Major City Bank B)",
            "SYNTH_BANK_03 (Major City Bank C)",
            "SYNTH_BANK_04 (Trust & Banking Corp)",
            "SYNTH_BANK_05 (Major Regional Bank A)",
            "SYNTH_BANK_06 (Major Regional Bank B)",
            "SYNTH_BANK_07 (Foreign Bank Branch)",
            "SYNTH_BANK_08 (Long-term Credit Bank)"
        )

        val rates = customRates ?: listOf(0.320, 0.335, 0.345, 0.350, 0.355, 0.360, 0.380, 0.410)

        val rawList = baseBankNames.mapIndexed { idx, name ->
            ReferenceBankSubmission(
                bankId = "SYNTH_BANK_0${idx + 1}",
                bankName = name,
                rate = rates.getOrElse(idx) { 0.350 }
            )
        }.sortedBy { it.rate }

        val n = rawList.size
        val excludedLow = rawList.take(2).map { it.copy(isExcludedLow = true, isIncluded = false) }
        val excludedHigh = rawList.takeLast(2).map { it.copy(isExcludedHigh = true, isIncluded = false) }
        val included = rawList.subList(2, n - 2).map { it.copy(isIncluded = true) }

        val avg = included.map { it.rate }.average()

        val fullMarked = mutableListOf<ReferenceBankSubmission>()
        fullMarked.addAll(excludedLow)
        fullMarked.addAll(included)
        fullMarked.addAll(excludedHigh)

        return JbataLabResult(
            submissions = fullMarked,
            excludedHigh = excludedHigh,
            excludedLow = excludedLow,
            included = included,
            calculatedAverage = (avg * 1000000.0).roundToInt() / 1000000.0
        )
    }

    fun calculateRiskShock(shockBp: Double): Map<String, Any> {
        val deltaRate = shockBp / 100.0 // e.g. +25 bp = +0.25%
        val baseCurve = getCurvePoints()
        val shockedCurve = baseCurve.map { pt ->
            val newRate = pt.zeroRate + deltaRate
            val newDf = exp(- (newRate / 100.0) * (pt.days / 365.0))
            pt.copy(
                zeroRate = (newRate * 10000.0).roundToInt() / 10000.0,
                discountFactor = (newDf * 1000000.0).roundToInt() / 1000000.0
            )
        }

        // Institutional 10B JPY portfolio DV01 approximation
        val notionalBillionJpy = 10.0
        val portfolioDv01MillionJpy = -0.42 * notionalBillionJpy // Modified duration ~ 4.2y
        val estimatedPnlMillionJpy = portfolioDv01MillionJpy * shockBp

        return mapOf(
            "shockBp" to shockBp,
            "baseZero3M" to (baseCurve.find { it.tenor == TiborTenor.M3 }?.zeroRate ?: 0.352),
            "shockedZero3M" to (shockedCurve.find { it.tenor == TiborTenor.M3 }?.zeroRate ?: 0.602),
            "estimatedPnlMillionJpy" to (estimatedPnlMillionJpy * 100.0).roundToInt() / 100.0,
            "portfolioDv01" to portfolioDv01MillionJpy,
            "shockedPoints" to shockedCurve
        )
    }

    fun getDataQualityStatus(): DataQualityStatus {
        return DataQualityStatus(
            status = "PASS",
            checksPassed = 12,
            checksTotal = 12,
            zScoreMax = 1.42,
            lastCheckTime = JapanBusinessCalendar.getCurrentJstTimeString(),
            notes = listOf(
                "All 5 required tenors (1W, 1M, 3M, 6M, 12M) received and validated.",
                "Monotonicity test passed: W1 <= M1 <= M3 <= M6 <= M12.",
                "Z-score jump checks within 3.0 threshold (|z_max| = 1.42).",
                "Source checksum verified against publisher manifest."
            )
        )
    }

    fun getAuditEvents(): List<AuditEvent> {
        val now = JapanBusinessCalendar.getCurrentJstTimeString()
        return listOf(
            AuditEvent("AUD-901", now, "FIXING_VERIFIED", "SYSTEM_AUTH_PIPELINE", "JBA_TIBOR_3M", "Official fixing ingested and verified via Authorised Disseminator", "VERIFIED"),
            AuditEvent("AUD-900", "13:00:02 JST", "PUBLICATION_EVENT", "JBATA_DISSEMINATOR", "ALL_TENORS", "Daily fixing broadcast completed at 13:00 JST", "SUCCESS"),
            AuditEvent("AUD-899", "12:59:45 JST", "QUALITY_CHECK", "DATA_QUALITY_ENGINE", "SUBMISSIONS_ARRAY", "8 reference banks trimmed: 2 high, 2 low excluded", "PASSED"),
            AuditEvent("AUD-898", "12:00:00 JST", "WINDOW_CLOSED", "SCHEDULER", "SUBMISSION_WINDOW", "Reference bank submission window locked", "LOCKED"),
            AuditEvent("AUD-897", "11:00:00 JST", "MARKET_CUTOFF", "CALL_MARKET_MONITOR", "UNSECURED_CALL", "Tokyo interbank cash market observation snapshot captured", "COMPLETED")
        )
    }

    fun tickSimulation() {
        baseJitter += (Math.random() - 0.49) * 0.002
    }
}
