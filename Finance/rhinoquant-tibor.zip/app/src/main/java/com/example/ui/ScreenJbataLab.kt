package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.JbataLabResult
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalOrange
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun ScreenJbataLab(
    labResult: JbataLabResult,
    onRunRandomSimulation: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        // Title Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "LAB <GO> JBATA CALCULATION ENGINE",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Research-Only Model: Exclude 2 Highest & 2 Lowest Submitted Rates",
                    fontSize = 10.sp,
                    color = TerminalTextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }

            Button(
                onClick = onRunRandomSimulation,
                colors = ButtonDefaults.buttonColors(containerColor = TerminalOrange),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.height(30.dp).testTag("lab_resimulate_button")
            ) {
                Text("RE-SIMULATE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Headline Result Card
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "CALCULATED JBATA BENCHMARK AVERAGE",
                    fontSize = 10.sp,
                    color = TerminalTextMuted,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${String.format("%.6f", labResult.calculatedAverage)}%",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalGreen,
                        fontFamily = FontFamily.Monospace
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Submitted: 8 Banks", fontSize = 10.sp, color = TerminalTextSecondary, fontFamily = FontFamily.Monospace)
                        Text("Trimmed: 4 Excluded", fontSize = 10.sp, color = TerminalOrange, fontFamily = FontFamily.Monospace)
                        Text("Included: 4 In Mean", fontSize = 10.sp, color = TerminalCyan, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Reference Bank Submissions Table
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "REFERENCE BANK SUBMISSION ARRAY (SIMULATED)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Status: STRICTLY SIMULATED. JBATA methodology rule applies.",
                    fontSize = 9.sp,
                    color = TerminalTextMuted,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                labResult.submissions.forEach { sub ->
                    val statusText = when {
                        sub.isExcludedLow -> "EXCLUDED (LOW)"
                        sub.isExcludedHigh -> "EXCLUDED (HIGH)"
                        else -> "INCLUDED IN MEAN"
                    }
                    val statusColor = when {
                        sub.isExcludedLow || sub.isExcludedHigh -> TerminalRed
                        else -> TerminalGreen
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.8f)) {
                            Text(
                                text = sub.bankName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TerminalTextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = sub.bankId,
                                fontSize = 9.sp,
                                color = TerminalTextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = "${String.format("%.4f", sub.rate)}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (sub.isIncluded) TerminalCyan else TerminalTextMuted,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1.0f)
                        )

                        Text(
                            text = statusText,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusColor,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .background(statusColor.copy(alpha = 0.12f), RoundedCornerShape(3.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                    Divider(color = TerminalCardBorder.copy(alpha = 0.4f), thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Statutory Research Boundary Warning Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF131D2A), RoundedCornerShape(6.dp))
                .border(1.dp, TerminalCardBorder, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "Compliance Boundary Notice: This laboratory calculates an arithmetic trimmed average for research, validation, and historical backtesting purposes only. It is not an authorized engine for publishing official JBA TIBOR benchmarks.",
                fontSize = 10.sp,
                color = TerminalTextMuted,
                fontFamily = FontFamily.Monospace,
                lineHeight = 14.sp
            )
        }
    }
}
