package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.ui.ScreenAuditLog
import com.example.ui.ScreenHealthStatus
import com.example.ui.ScreenJbataLab
import com.example.ui.ScreenRiskSimulator
import com.example.ui.ScreenTiborBasis
import com.example.ui.ScreenTiborCurve
import com.example.ui.ScreenTiborDataProvenance
import com.example.ui.ScreenTiborForwards
import com.example.ui.ScreenTiborHistory
import com.example.ui.ScreenTiborOverview
import com.example.ui.TerminalCommandLine
import com.example.ui.TerminalTopBar
import com.example.ui.TerminalViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TerminalBackground

class MainActivity : ComponentActivity() {
    private val viewModel: TerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                RhinoQuantRatesTerminalApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun RhinoQuantRatesTerminalApp(viewModel: TerminalViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    // BackHandler: Navigate back to TIBOR overview if on any secondary screen
    BackHandler(enabled = uiState.currentRoute != "TIBOR") {
        viewModel.setRoute("TIBOR")
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .testTag("rhinoquant_terminal_root"),
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(TerminalBackground)
        ) {
            // Institutional Top Bar with Clock and Status
            TerminalTopBar(
                state = uiState,
                onToggleLanguage = { viewModel.toggleLanguage() },
                onSetProvider = { viewModel.setProvider(it) },
                onToggleLiveStreaming = { viewModel.toggleLiveStreaming() }
            )

            // Dynamic Screen Content based on Active Terminal Route
            Box(modifier = Modifier.weight(1f)) {
                when (uiState.currentRoute) {
                    "TIBOR" -> ScreenTiborOverview(
                        state = uiState,
                        onNavigateCommand = { viewModel.executeCommand(it) },
                        onTriggerExport = { viewModel.triggerExport(it) }
                    )
                    "TIBH" -> ScreenTiborHistory(
                        state = uiState,
                        onSelectTenor = { viewModel.setSelectedTenor(it) },
                        onSelectTimeframe = { viewModel.setHistoricalTimeframe(it) }
                    )
                    "TIBC" -> ScreenTiborCurve(
                        state = uiState,
                        onNavigateCommand = { viewModel.executeCommand(it) }
                    )
                    "TIBF" -> ScreenTiborForwards(
                        state = uiState
                    )
                    "BASIS", "TONA" -> ScreenTiborBasis(
                        state = uiState
                    )
                    "DATA" -> ScreenTiborDataProvenance(
                        state = uiState
                    )
                    "LAB" -> ScreenJbataLab(
                        labResult = uiState.labResult,
                        onRunRandomSimulation = { viewModel.runJbataLabSimulation() }
                    )
                    "RISK" -> ScreenRiskSimulator(
                        state = uiState,
                        onUpdateShockBp = { viewModel.updateRiskShock(it) }
                    )
                    "AUDIT" -> ScreenAuditLog(
                        state = uiState
                    )
                    "HEALTH" -> ScreenHealthStatus(
                        state = uiState
                    )
                    else -> ScreenTiborOverview(
                        state = uiState,
                        onNavigateCommand = { viewModel.executeCommand(it) },
                        onTriggerExport = { viewModel.triggerExport(it) }
                    )
                }
            }

            // Command Prompt and Quick Action Chip Bar at the bottom
            TerminalCommandLine(
                currentRoute = uiState.currentRoute,
                onExecuteCommand = { viewModel.executeCommand(it) }
            )
        }
    }
}
