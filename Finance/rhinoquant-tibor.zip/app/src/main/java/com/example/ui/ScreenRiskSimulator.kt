package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CurvePoint
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalOrange
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun ScreenRiskSimulator(
    state: TerminalUiState,
    onUpdateShockBp: (Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val shockBp = state.riskShockBp
    val shockResult = state.riskShockResult
    val pnlMillion = shockResult["estimatedPnlMillionJpy"] as? Double ?: -10.5
    val dv01 = shockResult["portfolioDv01"] as? Double ?: -0.42
    @Suppress("UNCHECKED_CAST")
    val shockedPoints = shockResult["shockedPoints"] as? List<CurvePoint> ?: emptyList()

    val quickShocks = listOf(-25.0, -10.0, +10.0, +25.0, +50.0, +100.0)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        Text(
            text = "RISK <GO> SCENARIO SHOCK & DV01 SIMULATOR",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TerminalGold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "Portfolio Stress: \"What happens if TIBOR shifts +25 bp?\"",
            fontSize = 10.sp,
            color = TerminalTextMuted,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Headline Shock Impact Card
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ESTIMATED P&L IMPACT (10B JPY INSTITUTIONAL PORTFOLIO)",
                    fontSize = 10.sp,
                    color = TerminalTextMuted,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${if (pnlMillion >= 0) "+" else ""}$pnlMillion M JPY",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (pnlMillion >= 0) TerminalGreen else TerminalRed,
                        fontFamily = FontFamily.Monospace
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Active Shock: ${if (shockBp >= 0) "+" else ""}${shockBp.toInt()} bp", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TerminalCyan, fontFamily = FontFamily.Monospace)
                        Text("Portfolio DV01: -¥4.2M / bp", fontSize = 10.sp, color = TerminalTextSecondary, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Shock Preset Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickShocks.forEach { s ->
                val isSelected = shockBp == s
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) TerminalOrange else TerminalSurfaceVariant)
                        .border(1.dp, if (isSelected) TerminalGold else TerminalCardBorder, RoundedCornerShape(4.dp))
                        .clickable { onUpdateShockBp(s) }
                        .padding(vertical = 6.dp)
                        .testTag("shock_btn_${s.toInt()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${if (s >= 0) "+" else ""}${s.toInt()} bp",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) androidx.compose.ui.graphics.Color.Black else TerminalTextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Slider control for continuous basis point shift
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "CONTINUOUS PARALLEL CURVE SHIFT SLIDER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalCyan,
                    fontFamily = FontFamily.Monospace
                )
                Slider(
                    value = shockBp.toFloat(),
                    onValueChange = { onUpdateShockBp(it.toDouble()) },
                    valueRange = -50f..100f,
                    steps = 29,
                    colors = SliderDefaults.colors(
                        thumbColor = TerminalOrange,
                        activeTrackColor = TerminalCyan,
                        inactiveTrackColor = TerminalSurfaceVariant
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("risk_shock_slider")
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("-50 bp (Cut)", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("0 bp (Base)", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("+100 bp (Emergency Hike)", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Shifted Yield Curve Table
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "SHOCKED TERM STRUCTURE (POST-SHIFT PILLARS)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                shockedPoints.forEach { pt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${pt.tenor.code} (${pt.days}d)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TerminalTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Shifted Zero: ${String.format("%.4f", pt.zeroRate)}%",
                            fontSize = 11.sp,
                            color = TerminalCyan,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "DF: ${String.format("%.5f", pt.discountFactor)}",
                            fontSize = 10.sp,
                            color = TerminalTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Divider(color = TerminalCardBorder.copy(alpha = 0.4f), thickness = 0.5.dp)
                }
            }
        }
    }
}
