package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TerminalBackground = Color(0xFF080D14)
val TerminalSurface = Color(0xFF0E1724)
val TerminalSurfaceVariant = Color(0xFF142032)
val TerminalCardBorder = Color(0xFF1E2E44)

val TerminalGold = Color(0xFFF59E0B)
val TerminalOrange = Color(0xFFFF6D00) // Classic Bloomberg / Terminal <GO> orange
val TerminalCyan = Color(0xFF06B6D4)
val TerminalGreen = Color(0xFF10B981)
val TerminalRed = Color(0xFFEF4444)
val TerminalBlue = Color(0xFF3B82F6)

val TerminalTextPrimary = Color(0xFFF8FAFC)
val TerminalTextSecondary = Color(0xFF94A3B8)
val TerminalTextMuted = Color(0xFF64748B)

val TerminalGridLine = Color(0x2238BDF8)
