package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalOrange
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun ScreenTiborDataProvenance(
    state: TerminalUiState,
    modifier: Modifier = Modifier
) {
    val src = state.overview.source

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        Text(
            text = "DATA <GO> MARKET DATA PROVENANCE & GOVERNANCE",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TerminalGold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "Full Lineage Traceability & Source Authorization Architecture",
            fontSize = 10.sp,
            color = TerminalTextMuted,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Requirement 1 & 75: Source Record Card
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SOURCE RECORD AUDIT",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalCyan,
                        fontFamily = FontFamily.Monospace
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (src.isAuthoritative) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (src.isAuthoritative) TerminalGreen else TerminalOrange,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (src.isAuthoritative) "VERIFIED" else "NON-AUTHORITATIVE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (src.isAuthoritative) TerminalGreen else TerminalOrange,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = TerminalCardBorder, thickness = 1.dp)

                ProvenanceRow("Provider", src.provider)
                ProvenanceRow("Source Type", src.type.name)
                ProvenanceRow("Published At", src.publishedAt)
                ProvenanceRow("Received At", src.retrievedAt)
                ProvenanceRow("Identifier", src.identifier)
                ProvenanceRow("SHA-256 Checksum", src.checksum)
                ProvenanceRow("License Terms", src.license)
                ProvenanceRow("Legal Validity", if (src.isAuthoritative) "Enforceable in Contracts & Valuations" else "Informational Reference Only")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Four-Tier Architecture Diagram
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "FOUR-TIER BENCHMARK DATA BOUNDARY",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(10.dp))

                TierCard(
                    tierNumber = "TIER 1",
                    title = "OFFICIAL JBA TIBOR",
                    desc = "Authorised JBATA Dissemination Line. Strictly tagged as official benchmark reference.",
                    badgeColor = TerminalGreen
                )
                Spacer(modifier = Modifier.height(6.dp))
                TierCard(
                    tierNumber = "TIER 2",
                    title = "SOURCE & PROVENANCE",
                    desc = "Cryptographic content hashing, ingress timestamps, license entitlements.",
                    badgeColor = TerminalCyan
                )
                Spacer(modifier = Modifier.height(6.dp))
                TierCard(
                    tierNumber = "TIER 3",
                    title = "NORMALISED RHINOQUANT DATA",
                    desc = "Canonical immutable datastore. Deduplication & data quality validation.",
                    badgeColor = TerminalGold
                )
                Spacer(modifier = Modifier.height(6.dp))
                TierCard(
                    tierNumber = "TIER 4",
                    title = "DERIVED RHINOQUANT ANALYTICS",
                    desc = "Curves, forwards, spreads, scenarios. Explicitly marked: derived=true, methodology=RHINOQUANT.",
                    badgeColor = TerminalOrange
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // JBATA Official Disclaimer Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF161F2E), RoundedCornerShape(6.dp))
                .border(1.dp, TerminalGold.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "JBATA OFFICIAL DISSEMINATION POLICY",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "JBATA (JBA TIBOR Administration) explicitly warns that rates displayed on its public website are reference information only. Financial market participants requiring rates for commercial transactions, loan contracts, or legal agreements are legally directed to obtain rates via authorised information providers (e.g. Bloomberg B-PIPE, LSEG Refinitiv, Quick Corp).",
                    fontSize = 10.sp,
                    color = TerminalTextSecondary,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 14.sp
                )
            }
        }
    }
}

@Composable
private fun ProvenanceRow(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 5.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 10.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
            Text(value, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = TerminalTextPrimary, fontFamily = FontFamily.Monospace)
        }
        Divider(color = TerminalCardBorder.copy(alpha = 0.4f), thickness = 0.5.dp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun TierCard(
    tierNumber: String,
    title: String,
    desc: String,
    badgeColor: Color
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalSurfaceVariant)
            .border(1.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = tierNumber,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = badgeColor,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .background(badgeColor.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TerminalTextPrimary, fontFamily = FontFamily.Monospace)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, fontSize = 9.sp, color = TerminalTextSecondary, fontFamily = FontFamily.Monospace)
        }
    }
}
