package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalOrange
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun ScreenTiborForwards(
    state: TerminalUiState,
    modifier: Modifier = Modifier
) {
    val forwards = state.forwardRates

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        // Title Header
        Text(
            text = "TIBF <GO> FORWARD-RATE ANALYSIS MATRIX",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TerminalGold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "Continuous Compounding: F(t1, t2) = (r2*t2 - r1*t1) / (t2 - t1)",
            fontSize = 10.sp,
            color = TerminalTextMuted,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Requirement 74: Forward Matrix Cards (1Mx3M, 3Mx6M, 6Mx9M, 6Mx12M)
        forwards.forEach { fwd ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = fwd.periodLabel,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TerminalGold,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = "${String.format("%.4f", fwd.forwardRate)}%",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TerminalCyan,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "SPREAD VS SPOT: ",
                                fontSize = 10.sp,
                                color = TerminalTextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "+${fwd.spreadBp} bp",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (fwd.spreadBp >= 0) TerminalGreen else TerminalRed,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = "PERCENTILE: ${fwd.percentile}%",
                            fontSize = 10.sp,
                            color = TerminalTextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Percentile gauge bar
                    Box(modifier = Modifier.fillMaxWidth()) {
                        LinearProgressIndicator(
                            progress = { (fwd.percentile / 100.0).toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (fwd.percentile > 75) TerminalOrange else TerminalCyan,
                            trackColor = TerminalSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Analytical Footnote Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceVariant, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalCardBorder, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "Methodology Guarantee: RhinoQuant Forward Rates are analytical derivations (derived=true). They are mathematical implications of the spot benchmark curve and do not constitute newly published JBATA cash benchmarks.",
                fontSize = 10.sp,
                color = TerminalTextMuted,
                fontFamily = FontFamily.Monospace,
                lineHeight = 14.sp
            )
        }
    }
}
