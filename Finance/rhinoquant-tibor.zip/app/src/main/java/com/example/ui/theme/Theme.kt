package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TerminalColorScheme = darkColorScheme(
    primary = TerminalGold,
    onPrimary = TerminalBackground,
    primaryContainer = TerminalSurfaceVariant,
    onPrimaryContainer = TerminalGold,
    secondary = TerminalCyan,
    onSecondary = TerminalBackground,
    secondaryContainer = TerminalSurfaceVariant,
    onSecondaryContainer = TerminalCyan,
    tertiary = TerminalOrange,
    onTertiary = TerminalBackground,
    background = TerminalBackground,
    onBackground = TerminalTextPrimary,
    surface = TerminalSurface,
    onSurface = TerminalTextPrimary,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TerminalTextSecondary,
    outline = TerminalCardBorder,
    error = TerminalRed,
    onError = TerminalBackground
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
