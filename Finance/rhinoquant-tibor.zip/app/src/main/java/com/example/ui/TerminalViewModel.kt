package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.TiborEngine
import com.example.model.AuditEvent
import com.example.model.CurvePoint
import com.example.model.DataQualityStatus
import com.example.model.ForwardRate
import com.example.model.HistoricalObservation
import com.example.model.JbataLabResult
import com.example.model.ProviderType
import com.example.model.PublicationStatus
import com.example.model.TiborFixing
import com.example.model.TiborTenor
import com.example.model.TokyoMarketOverview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TerminalUiState(
    val currentRoute: String = "TIBOR", // TIBOR, TIBH, TIBC, TIBF, BASIS, TONA, JGB, JPSW, RISK, DATA, LAB, AUDIT, HEALTH
    val commandText: String = "",
    val isJapanese: Boolean = false,
    val activeProvider: ProviderType = ProviderType.LICENSED_MARKET_DATA,
    val publicationStatus: PublicationStatus = PublicationStatus.PUBLISHED,
    val isLiveStreaming: Boolean = true,
    val overview: TokyoMarketOverview,
    val selectedTenor: TiborTenor = TiborTenor.M3,
    val selectedTimeframe: String = "1M", // 1D, 1W, 1M, 3M, 1Y, 5Y, MAX
    val historicalObservations: List<HistoricalObservation> = emptyList(),
    val curvePoints: List<CurvePoint> = emptyList(),
    val forwardRates: List<ForwardRate> = emptyList(),
    val labResult: JbataLabResult,
    val riskShockBp: Double = 25.0,
    val riskShockResult: Map<String, Any> = emptyMap(),
    val dataQuality: DataQualityStatus,
    val auditEvents: List<AuditEvent> = emptyList(),
    val exportJobState: String? = null // e.g. "Exporting Parquet... JOB-89A1"
)

class TerminalViewModel : ViewModel() {
    private val engine = TiborEngine()

    private val _uiState = MutableStateFlow(
        TerminalUiState(
            overview = engine.getTokyoMarketOverview(),
            historicalObservations = engine.getHistoricalObservations("1M", TiborTenor.M3),
            curvePoints = engine.getCurvePoints(),
            forwardRates = engine.getForwardRates(),
            labResult = engine.executeJbataCalculationLab(),
            riskShockResult = engine.calculateRiskShock(25.0),
            dataQuality = engine.getDataQualityStatus(),
            auditEvents = engine.getAuditEvents()
        )
    )
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    init {
        // Start background ticker simulation
        viewModelScope.launch {
            while (true) {
                delay(2500)
                if (_uiState.value.isLiveStreaming) {
                    engine.tickSimulation()
                    refreshMarketData()
                }
            }
        }
    }

    private fun refreshMarketData() {
        val ov = engine.getTokyoMarketOverview()
        val hist = engine.getHistoricalObservations(_uiState.value.selectedTimeframe, _uiState.value.selectedTenor)
        val curve = engine.getCurvePoints()
        val forwards = engine.getForwardRates()
        val risk = engine.calculateRiskShock(_uiState.value.riskShockBp)

        _uiState.update { current ->
            current.copy(
                overview = ov,
                historicalObservations = hist,
                curvePoints = curve,
                forwardRates = forwards,
                riskShockResult = risk,
                auditEvents = engine.getAuditEvents()
            )
        }
    }

    fun executeCommand(commandInput: String) {
        val clean = commandInput.trim().uppercase()
            .replace("<GO>", "")
            .replace("GO", "")
            .trim()

        val route = when {
            clean.startsWith("TIBOR") -> "TIBOR"
            clean.startsWith("TIBH") -> "TIBH"
            clean.startsWith("TIBC") -> "TIBC"
            clean.startsWith("TIBF") -> "TIBF"
            clean.startsWith("BASIS") -> "BASIS"
            clean.startsWith("TONA") -> "TONA"
            clean.startsWith("JGB") -> "JGB"
            clean.startsWith("JPSW") -> "JPSW"
            clean.startsWith("RISK") -> "RISK"
            clean.startsWith("DATA") -> "DATA"
            clean.startsWith("LAB") -> "LAB"
            clean.startsWith("AUDIT") -> "AUDIT"
            clean.startsWith("HEALTH") -> "HEALTH"
            else -> "TIBOR"
        }

        _uiState.update { it.copy(currentRoute = route, commandText = "") }
    }

    fun setRoute(route: String) {
        _uiState.update { it.copy(currentRoute = route) }
    }

    fun toggleLanguage() {
        _uiState.update { it.copy(isJapanese = !it.isJapanese) }
    }

    fun setProvider(provider: ProviderType) {
        engine.activeProvider = provider
        _uiState.update { it.copy(activeProvider = provider) }
        refreshMarketData()
    }

    fun toggleLiveStreaming() {
        _uiState.update { it.copy(isLiveStreaming = !it.isLiveStreaming) }
    }

    fun setHistoricalTimeframe(tf: String) {
        _uiState.update { it.copy(selectedTimeframe = tf) }
        val hist = engine.getHistoricalObservations(tf, _uiState.value.selectedTenor)
        _uiState.update { it.copy(historicalObservations = hist) }
    }

    fun setSelectedTenor(tenor: TiborTenor) {
        _uiState.update { it.copy(selectedTenor = tenor) }
        val hist = engine.getHistoricalObservations(_uiState.value.selectedTimeframe, tenor)
        _uiState.update { it.copy(historicalObservations = hist) }
    }

    fun updateRiskShock(shockBp: Double) {
        _uiState.update { it.copy(riskShockBp = shockBp) }
        val risk = engine.calculateRiskShock(shockBp)
        _uiState.update { it.copy(riskShockResult = risk) }
    }

    fun runJbataLabSimulation(customRates: List<Double>? = null) {
        val result = engine.executeJbataCalculationLab(customRates)
        _uiState.update { it.copy(labResult = result) }
    }

    fun triggerExport(format: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(exportJobState = "Starting async $format export...") }
            delay(800)
            _uiState.update { it.copy(exportJobState = "Processing 12,840 historical records...") }
            delay(1000)
            _uiState.update { it.copy(exportJobState = "✓ Export complete: RQTIBOR_${format.lowercase()}_2026.parquet") }
            delay(3000)
            _uiState.update { it.copy(exportJobState = null) }
        }
    }
}
