package com.example.model

import java.math.BigDecimal
import java.util.Date

enum class TiborTenor(val code: String, val label: String, val days: Int, val freqPerYear: Double) {
    W1("1W", "1 Week", 7, 52.0),
    M1("1M", "1 Month", 30, 12.0),
    M3("3M", "3 Months", 90, 4.0),
    M6("6M", "6 Months", 180, 2.0),
    M12("12M", "12 Months", 360, 1.0);

    companion object {
        fun fromCode(code: String): TiborTenor? = entries.find { it.code.equals(code, ignoreCase = true) }
    }
}

enum class BenchmarkStatus {
    OFFICIAL,
    CORRECTED,
    PROVISIONAL,
    REFERENCE,
    SYNTHETIC,
    DERIVED
}

enum class PublicationStatus {
    EXPECTED,
    PUBLISHED,
    DELAYED,
    WITHHELD,
    CORRECTED,
    CONTINGENCY
}

enum class ProviderType {
    OFFICIAL_PROVIDER,
    AUTHORISED_PROVIDER,
    REFERENCE_WEBSITE,
    LICENSED_MARKET_DATA,
    MOCK_PROVIDER
}

data class SourceRecord(
    val provider: String,
    val type: ProviderType,
    val retrievedAt: String,
    val publishedAt: String,
    val identifier: String,
    val checksum: String,
    val license: String,
    val isAuthoritative: Boolean
)

data class TiborFixing(
    val id: String,
    val fixingDate: String,
    val publicationTimestamp: String,
    val currency: String = "JPY",
    val benchmark: String = "JBA_TIBOR",
    val tenor: TiborTenor,
    val rate: BigDecimal,
    val unit: String = "percent",
    val status: BenchmarkStatus,
    val source: SourceRecord,
    val revision: Int = 0,
    val derived: Boolean = false,
    val changeBp1D: Double = 0.0
)

data class TokyoMarketOverview(
    val timestampJst: String,
    val publicationStatus: PublicationStatus,
    val source: SourceRecord,
    val fixings: Map<TiborTenor, TiborFixing>,
    val tona: Double,
    val tonaChangeBp1D: Double,
    val basis3mBp: Double,
    val jgb10Y: Double,
    val jgb30Y: Double,
    val jpySwap5Y: Double,
    val jpySwap10Y: Double,
    val usdjpy: Double
)

data class CurvePoint(
    val tenor: TiborTenor,
    val days: Int,
    val zeroRate: Double,
    val discountFactor: Double
)

data class ForwardRate(
    val periodLabel: String,
    val startTenor: TiborTenor,
    val endTenor: TiborTenor,
    val forwardRate: Double,
    val spreadBp: Double,
    val percentile: Double
)

data class HistoricalObservation(
    val date: String,
    val rate: Double,
    val changeBp: Double,
    val source: String,
    val status: BenchmarkStatus
)

data class ReferenceBankSubmission(
    val bankId: String,
    val bankName: String,
    val rate: Double,
    val isExcludedHigh: Boolean = false,
    val isExcludedLow: Boolean = false,
    val isIncluded: Boolean = true
)

data class JbataLabResult(
    val submissions: List<ReferenceBankSubmission>,
    val excludedHigh: List<ReferenceBankSubmission>,
    val excludedLow: List<ReferenceBankSubmission>,
    val included: List<ReferenceBankSubmission>,
    val calculatedAverage: Double
)

data class AuditEvent(
    val id: String,
    val timestamp: String,
    val operation: String,
    val actor: String,
    val resource: String,
    val detail: String,
    val status: String
)

data class DataQualityStatus(
    val status: String, // PASS, WARNING, FAIL
    val checksPassed: Int,
    val checksTotal: Int,
    val zScoreMax: Double,
    val lastCheckTime: String,
    val notes: List<String>
)
