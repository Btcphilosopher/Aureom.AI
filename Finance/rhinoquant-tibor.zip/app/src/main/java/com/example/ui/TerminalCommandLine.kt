package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalOrange
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary

@Composable
fun TerminalCommandLine(
    currentRoute: String,
    onExecuteCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var textInput by remember { mutableStateOf("") }
    val quickCommands = listOf(
        "TIBOR" to "Overview",
        "TIBH" to "History",
        "TIBC" to "Curves",
        "TIBF" to "Forwards",
        "BASIS" to "TIBOR/TONA",
        "LAB" to "JBATA Lab",
        "RISK" to "Shock Lab",
        "DATA" to "Provenance",
        "AUDIT" to "Compliance",
        "HEALTH" to "System"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(1.dp, TerminalCardBorder)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        // Quick command navigation chip bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickCommands.forEach { (cmd, label) ->
                val isSelected = currentRoute == cmd
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) TerminalOrange else TerminalSurfaceVariant)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) TerminalGold else TerminalCardBorder,
                            shape = RoundedCornerShape(4.dp)
                        )
                        .clickable { onExecuteCommand(cmd) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("nav_chip_$cmd")
                ) {
                    Text(
                        text = "$cmd <GO>",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.Black else TerminalTextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Command Prompt Input line with institutional <GO> button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF070B12))
                .border(1.dp, TerminalCyan.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "RQTIBOR> ",
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TerminalGold
            )

            BasicTextField(
                value = textInput,
                onValueChange = { textInput = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_command_input"),
                textStyle = TextStyle(
                    color = TerminalTextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium
                ),
                cursorBrush = SolidColor(TerminalGold),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = {
                        if (textInput.isNotBlank()) {
                            onExecuteCommand(textInput)
                            textInput = ""
                        }
                    }
                ),
                decorationBox = { innerTextField ->
                    if (textInput.isEmpty()) {
                        Text(
                            text = "Type command (e.g. TIBOR, TIBH, TIBC, LAB) then press <GO>",
                            color = TerminalTextMuted,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    innerTextField()
                }
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Bloomberg Orange <GO> Action Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(TerminalOrange)
                    .clickable {
                        if (textInput.isNotBlank()) {
                            onExecuteCommand(textInput)
                            textInput = ""
                        } else {
                            onExecuteCommand("TIBOR")
                        }
                    }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .testTag("terminal_go_button")
            ) {
                Text(
                    text = "<GO>",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    color = Color.Black
                )
            }
        }
    }
}
