package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalOrange
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun ScreenTiborCurve(
    state: TerminalUiState,
    onNavigateCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val curvePoints = state.curvePoints

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        // Title Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TIBC <GO> TERM STRUCTURE CURVE BUILDER",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Curve: RQTIBOR-ZERO-JPY | Methodology: Monotonic Cubic Spline",
                    fontSize = 10.sp,
                    color = TerminalTextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Curve Canvas Display
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF070C14))
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        if (curvePoints.size < 2) return@Canvas

                        val w = size.width
                        val h = size.height
                        val topPad = 25f
                        val botPad = 30f
                        val leftPad = 30f
                        val rightPad = 30f

                        val rates = curvePoints.map { it.zeroRate }
                        val minR = 0.20
                        val maxR = (rates.maxOrNull() ?: 0.65) * 1.15
                        val rangeR = maxR - minR

                        val maxDays = 360f
                        val usableW = w - leftPad - rightPad
                        val usableH = h - topPad - botPad

                        // Grid lines
                        for (i in 0..3) {
                            val y = topPad + (usableH / 3) * i
                            drawLine(
                                color = Color(0x2238BDF8),
                                start = Offset(leftPad, y),
                                end = Offset(w - rightPad, y),
                                strokeWidth = 1f
                            )
                        }

                        // Curve coordinates
                        val pts = curvePoints.map { pt ->
                            val x = leftPad + (pt.days.toFloat() / maxDays) * usableW
                            val y = topPad + usableH * (1f - ((pt.zeroRate - minR) / rangeR).toFloat())
                            Offset(x, y)
                        }

                        // Spline line
                        val path = Path().apply {
                            moveTo(pts.first().x, pts.first().y)
                            for (i in 1 until pts.size) {
                                val prev = pts[i - 1]
                                val cur = pts[i]
                                val cpx = (prev.x + cur.x) / 2f
                                cubicTo(cpx, prev.y, cpx, cur.y, cur.x, cur.y)
                            }
                        }
                        drawPath(
                            path = path,
                            color = TerminalGold,
                            style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                        )

                        // Pillar points
                        pts.forEach { pt ->
                            drawCircle(color = TerminalCyan, radius = 5.5f, center = pt)
                            drawCircle(color = Color.Black, radius = 2.5f, center = pt)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("1W (7D)", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("1M (30D)", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("3M (90D)", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("6M (180D)", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("12M (360D)", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Requirement 73: Pillars Table with Zero Rates and Discount Factors
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "PILLAR POINTS & DISCOUNT FACTORS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalCyan,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TENOR", modifier = Modifier.weight(1f), fontSize = 10.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("DAYS", modifier = Modifier.weight(1f), textAlign = TextAlign.End, fontSize = 10.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("ZERO RATE", modifier = Modifier.weight(1.5f), textAlign = TextAlign.End, fontSize = 10.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("DISCOUNT FACTOR", modifier = Modifier.weight(2f), textAlign = TextAlign.End, fontSize = 10.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                }
                Divider(color = TerminalCardBorder, thickness = 1.dp)

                curvePoints.forEach { pt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(pt.tenor.code, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TerminalGold, fontFamily = FontFamily.Monospace)
                        Text("${pt.days}d", modifier = Modifier.weight(1f), textAlign = TextAlign.End, fontSize = 12.sp, color = TerminalTextSecondary, fontFamily = FontFamily.Monospace)
                        Text("${String.format("%.4f", pt.zeroRate)}%", modifier = Modifier.weight(1.5f), textAlign = TextAlign.End, fontSize = 12.sp, color = TerminalTextPrimary, fontFamily = FontFamily.Monospace)
                        Text(String.format("%.6f", pt.discountFactor), modifier = Modifier.weight(2f), textAlign = TextAlign.End, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = TerminalGreen, fontFamily = FontFamily.Monospace)
                    }
                    Divider(color = TerminalCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quick Navigation to Forward Rates
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(TerminalSurfaceVariant)
                .border(1.dp, TerminalOrange.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                .clickable { onNavigateCommand("TIBF") }
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("CALCULATE FORWARD-RATE CURVES", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TerminalOrange, fontFamily = FontFamily.Monospace)
                    Text("Inspect 1Mx3M, 3Mx6M, 6Mx9M, 6Mx12M implied forwards", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                }
                Text("TIBF <GO> →", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TerminalGold, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
