package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HistoricalObservation
import com.example.model.TiborTenor
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun ScreenTiborHistory(
    state: TerminalUiState,
    onSelectTenor: (TiborTenor) -> Unit,
    onSelectTimeframe: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val timeframes = listOf("1D", "1W", "1M", "3M", "1Y", "5Y", "MAX")
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    val observations = state.historicalObservations
    val selectedObs = selectedIndex?.let { observations.getOrNull(it) } ?: observations.lastOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        // Top Header: Title & Active Tenor
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TIBH <GO> HISTORICAL TIME-SERIES",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Benchmark: JBA_TIBOR | Tenor: ${state.selectedTenor.code} (${state.selectedTenor.label})",
                    fontSize = 10.sp,
                    color = TerminalTextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tenor selection tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TiborTenor.entries.forEach { tenor ->
                val isSelected = state.selectedTenor == tenor
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) TerminalCyan else TerminalSurfaceVariant)
                        .border(1.dp, if (isSelected) TerminalCyan else TerminalCardBorder, RoundedCornerShape(4.dp))
                        .clickable { onSelectTenor(tenor) }
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                        .testTag("tenor_tab_${tenor.code}")
                ) {
                    Text(
                        text = tenor.code,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.Black else TerminalTextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Timeframe selection buttons (1D, 1W, 1M, 3M, 1Y, 5Y, MAX)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            timeframes.forEach { tf ->
                val isSelected = state.selectedTimeframe == tf
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) TerminalGold else TerminalSurfaceVariant)
                        .border(1.dp, if (isSelected) TerminalGold else TerminalCardBorder, RoundedCornerShape(4.dp))
                        .clickable {
                            onSelectTimeframe(tf)
                            selectedIndex = null
                        }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("timeframe_tab_$tf")
                ) {
                    Text(
                        text = tf,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.Black else TerminalTextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Requirement 72: Interactive Crosshair HUD Box
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "CROSSHAIR TELEMETRY (TOUCH & DRAG CANVAS)",
                    fontSize = 9.sp,
                    color = TerminalTextMuted,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("DATE", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                        Text(selectedObs?.date ?: "—", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TerminalCyan, fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("RATE", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                        Text(if (selectedObs != null) "${selectedObs.rate}%" else "—", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TerminalTextPrimary, fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("CHANGE", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                        val chg = selectedObs?.changeBp ?: 0.0
                        Text(
                            text = if (selectedObs != null) (if (chg >= 0) "+$chg bp" else "$chg bp") else "—",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (chg >= 0) TerminalGreen else TerminalRed,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("SOURCE", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                        Text(selectedObs?.source ?: "Authorised", fontSize = 10.sp, color = TerminalGold, fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("STATUS", fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                        Text(selectedObs?.status?.name ?: "OFFICIAL", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TerminalGreen, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Interactive Canvas Chart
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF070C14))
                        .pointerInput(observations) {
                            detectTapGestures { offset ->
                                if (observations.isNotEmpty()) {
                                    val idx = ((offset.x / size.width) * (observations.size - 1))
                                        .toInt()
                                        .coerceIn(0, observations.size - 1)
                                    selectedIndex = idx
                                }
                            }
                        }
                        .pointerInput(observations) {
                            detectDragGestures { change, _ ->
                                if (observations.isNotEmpty()) {
                                    val idx = ((change.position.x / size.width) * (observations.size - 1))
                                        .toInt()
                                        .coerceIn(0, observations.size - 1)
                                    selectedIndex = idx
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        if (observations.size < 2) return@Canvas

                        val rates = observations.map { it.rate }
                        val minR = rates.minOrNull() ?: 0.0
                        val maxR = rates.maxOrNull() ?: 1.0
                        val range = (maxR - minR).coerceAtLeast(0.005)

                        val w = size.width
                        val h = size.height
                        val topPad = 20f
                        val botPad = 25f
                        val usableH = h - topPad - botPad

                        // Horizontal grid lines (4 lines)
                        val gridCount = 4
                        for (i in 0..gridCount) {
                            val y = topPad + (usableH / gridCount) * i
                            drawLine(
                                color = Color(0x2238BDF8),
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1f
                            )
                        }

                        // Build rate path
                        val points = observations.mapIndexed { idx, obs ->
                            val x = (idx.toFloat() / (observations.size - 1)) * w
                            val normY = (obs.rate - minR) / range
                            val y = topPad + usableH * (1f - normY.toFloat())
                            Offset(x, y)
                        }

                        // Gradient fill path under curve
                        val fillPath = Path().apply {
                            moveTo(points.first().x, h - botPad)
                            points.forEach { lineTo(it.x, it.y) }
                            lineTo(points.last().x, h - botPad)
                            close()
                        }
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(TerminalCyan.copy(alpha = 0.25f), Color.Transparent),
                                startY = topPad,
                                endY = h - botPad
                            )
                        )

                        // Main curve line
                        val strokePath = Path().apply {
                            moveTo(points.first().x, points.first().y)
                            points.forEach { lineTo(it.x, it.y) }
                        }
                        drawPath(
                            path = strokePath,
                            color = TerminalCyan,
                            style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                        )

                        // Draw crosshair vertical line if index is selected
                        selectedIndex?.let { idx ->
                            val pt = points.getOrNull(idx)
                            if (pt != null) {
                                drawLine(
                                    color = TerminalGold,
                                    start = Offset(pt.x, topPad),
                                    end = Offset(pt.x, h - botPad),
                                    strokeWidth = 1.5f
                                )
                                drawCircle(
                                    color = TerminalGold,
                                    radius = 5.5f,
                                    center = pt
                                )
                                drawCircle(
                                    color = Color.Black,
                                    radius = 2.5f,
                                    center = pt
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Historical distribution stats (High, Low, Mean, 20D Annualised Volatility)
                val rates = observations.map { it.rate }
                val maxVal = rates.maxOrNull() ?: 0.0
                val minVal = rates.minOrNull() ?: 0.0
                val avgVal = if (rates.isNotEmpty()) rates.average() else 0.0

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("HIGH: ${String.format("%.4f", maxVal)}%", fontSize = 10.sp, color = TerminalTextSecondary, fontFamily = FontFamily.Monospace)
                    Text("LOW: ${String.format("%.4f", minVal)}%", fontSize = 10.sp, color = TerminalTextSecondary, fontFamily = FontFamily.Monospace)
                    Text("MEAN: ${String.format("%.4f", avgVal)}%", fontSize = 10.sp, color = TerminalTextSecondary, fontFamily = FontFamily.Monospace)
                    Text("20D VOL: 6.85 bp", fontSize = 10.sp, color = TerminalGold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
