package com.example.client

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Body

@JsonClass(generateAdapter = true)
data class TiborLatest(
    val benchmark: String,
    val currency: String,
    @Json(name = "fixing_date") val fixingDate: String,
    val rates: Map<String, Double?>,
    val derived: Boolean = false
)

@JsonClass(generateAdapter = true)
data class ObservationItem(
    val date: String,
    val rate: Double,
    val status: String,
    val derived: Boolean
)

@JsonClass(generateAdapter = true)
data class TiborHistory(
    val benchmark: String,
    val tenor: String,
    val observations: List<ObservationItem>
)

@JsonClass(generateAdapter = true)
data class TokyoTerminalOverviewResponse(
    val terminal: String,
    @Json(name = "timestamp_jst") val timestampJst: String,
    @Json(name = "publication_status") val publicationStatus: String,
    val tona: Double,
    @Json(name = "jgb_10y") val jgb10Y: Double,
    @Json(name = "usdjpy") val usdjpy: Double
)

interface TiborApi {

    @GET("/api/v1/tibor/latest")
    suspend fun latest(): TiborLatest

    @GET("/api/v1/tibor/history")
    suspend fun history(
        @Query("tenor") tenor: String,
        @Query("start_date") startDate: String,
        @Query("end_date") endDate: String
    ): TiborHistory

    @GET("/terminal/v1/tokyo/overview")
    suspend fun overview(): TokyoTerminalOverviewResponse
}
