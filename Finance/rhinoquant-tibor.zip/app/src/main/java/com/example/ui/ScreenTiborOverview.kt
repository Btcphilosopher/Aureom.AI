package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.TiborFixing
import com.example.model.TiborTenor
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalOrange
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun ScreenTiborOverview(
    state: TerminalUiState,
    onNavigateCommand: (String) -> Unit,
    onTriggerExport: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var exportMenuOpen by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        // Institutional Hero Header with trading desk visual
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, TerminalCardBorder, RoundedCornerShape(8.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.rhinoquant_banner_1791803418789),
                contentDescription = "Tokyo Money Market Desk",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(12.dp)
            ) {
                Column(modifier = Modifier.align(Alignment.BottomStart)) {
                    Text(
                        text = if (state.isJapanese) "全銀協TIBOR 日本円金利ベンチマーク" else "JBA TIBOR JAPANESE YEN BENCHMARK",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalGold
                    )
                    Text(
                        text = if (state.isJapanese)
                            "無担保コール翌日物(TONA)・国債・円スワップ連動型 機関投資家向けデータ基盤"
                        else
                            "Institutional Money-Market Dissemination: Call Market, TONA, JGB & IRS",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TerminalTextPrimary
                    )
                }

                // Top right provenance badge
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = if (state.overview.source.isAuthoritative) TerminalGreen else TerminalOrange,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (state.overview.source.isAuthoritative) "VERIFIED AUTHORISED" else "REFERENCE PORTAL",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (state.overview.source.isAuthoritative) TerminalGreen else TerminalOrange,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Requirement 71: Official JBA TIBOR Board
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (state.isJapanese) "全銀協 日本円TIBOR (公表値)" else "JBA JAPANESE YEN TIBOR (OFFICIAL)",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TerminalGold
                        )
                        Text(
                            text = "Currency: JPY | Unit: % | Convention: Act/365 | Rule: Exclude 2 Max & 2 Min",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = TerminalTextMuted
                        )
                    }

                    Box {
                        Button(
                            onClick = { exportMenuOpen = true },
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalSurfaceVariant),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp).testTag("export_button")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, tint = TerminalCyan, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("EXPORT", fontSize = 10.sp, color = TerminalCyan, fontFamily = FontFamily.Monospace)
                        }

                        DropdownMenu(
                            expanded = exportMenuOpen,
                            onDismissRequest = { exportMenuOpen = false },
                            modifier = Modifier.background(TerminalSurface)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Apache Parquet (.parquet)", color = TerminalTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                                onClick = {
                                    onTriggerExport("PARQUET")
                                    exportMenuOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Historical CSV (.csv)", color = TerminalTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                                onClick = {
                                    onTriggerExport("CSV")
                                    exportMenuOpen = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Canonical JSON (.json)", color = TerminalTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                                onClick = {
                                    onTriggerExport("JSON")
                                    exportMenuOpen = false
                                }
                            )
                        }
                    }
                }

                // Async Export Notification toast
                if (state.exportJobState != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F2537), RoundedCornerShape(4.dp))
                            .border(1.dp, TerminalCyan, RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    ) {
                        Text(
                            text = state.exportJobState,
                            fontSize = 11.sp,
                            color = TerminalCyan,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("TENOR", modifier = Modifier.weight(1.2f), fontSize = 10.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("RATE (%)", modifier = Modifier.weight(2.0f), textAlign = TextAlign.End, fontSize = 10.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("1D CHG (BP)", modifier = Modifier.weight(1.5f), textAlign = TextAlign.End, fontSize = 10.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                    Text("STATUS", modifier = Modifier.weight(1.5f), textAlign = TextAlign.End, fontSize = 10.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
                }

                Divider(color = TerminalCardBorder, thickness = 1.dp)

                // Tenor Rows: 1W, 1M, 3M, 6M, 12M
                TiborTenor.entries.forEach { tenor ->
                    val fixing = state.overview.fixings[tenor]
                    val isAvailable = fixing != null

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateCommand("TIBH") }
                            .padding(horizontal = 8.dp, vertical = 9.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tenor.code,
                            modifier = Modifier.weight(1.2f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TerminalCyan,
                            fontFamily = FontFamily.Monospace
                        )

                        Text(
                            text = if (isAvailable) "${fixing!!.rate}%" else "—",
                            modifier = Modifier.weight(2.0f),
                            textAlign = TextAlign.End,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = TerminalTextPrimary,
                            fontFamily = FontFamily.Monospace
                        )

                        val chg = fixing?.changeBp1D ?: 0.0
                        Text(
                            text = if (isAvailable) (if (chg >= 0) "+$chg bp" else "$chg bp") else "—",
                            modifier = Modifier.weight(1.5f),
                            textAlign = TextAlign.End,
                            fontSize = 11.sp,
                            color = if (chg >= 0) TerminalGreen else TerminalRed,
                            fontFamily = FontFamily.Monospace
                        )

                        Box(
                            modifier = Modifier.weight(1.5f),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            Text(
                                text = fixing?.status?.name ?: "UNAVAILABLE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (fixing?.status) {
                                    com.example.model.BenchmarkStatus.OFFICIAL -> TerminalGreen
                                    com.example.model.BenchmarkStatus.REFERENCE -> TerminalOrange
                                    com.example.model.BenchmarkStatus.SYNTHETIC -> TerminalGold
                                    else -> TerminalTextMuted
                                },
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier
                                    .background(Color(0xFF0F1A28), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Divider(color = TerminalCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tokyo Money Market Cross-Asset Matrix (TONA, Basis, JGB, Swaps, USDJPY)
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (state.isJapanese) "東京短期金融・国債・金利スワップ指標" else "TOKYO MONEY MARKET & BENCHMARK SUITE",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = TerminalGold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // TONA (Tokyo Overnight Average Rate)
                    MarketMetricCard(
                        title = "TONA (Overnight)",
                        value = "${String.format("%.4f", state.overview.tona)}%",
                        subValue = "+0.2 bp (Unsecured)",
                        color = TerminalGreen,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateCommand("TONA") }
                    )

                    // TIBOR / TONA 3M Basis
                    MarketMetricCard(
                        title = "TIBOR-TONA 3M",
                        value = "${state.overview.basis3mBp} bp",
                        subValue = "Term Premium",
                        color = TerminalCyan,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateCommand("BASIS") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // JGB 10Y Yield
                    MarketMetricCard(
                        title = "JGB 10Y Yield",
                        value = "${String.format("%.3f", state.overview.jgb10Y)}%",
                        subValue = "+1.2 bp 10Y Benchmark",
                        color = TerminalGold,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateCommand("TIBC") }
                    )

                    // JPY 10Y IRS Swap
                    MarketMetricCard(
                        title = "JPY 10Y Swap (IRS)",
                        value = "${String.format("%.3f", state.overview.jpySwap10Y)}%",
                        subValue = "OIS Spread: +16.5 bp",
                        color = TerminalTextPrimary,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateCommand("TIBC") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // USDJPY Spot
                    MarketMetricCard(
                        title = "USD / JPY Spot",
                        value = "${String.format("%.2f", state.overview.usdjpy)}",
                        subValue = "FX Call Hedge Ref",
                        color = TerminalOrange,
                        modifier = Modifier.weight(1f),
                        onClick = {}
                    )

                    // JGB 30Y Super-long
                    MarketMetricCard(
                        title = "JGB 30Y Yield",
                        value = "${String.format("%.3f", state.overview.jgb30Y)}%",
                        subValue = "Super-Long End",
                        color = TerminalTextPrimary,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigateCommand("TIBC") }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Institutional Dissemination Notice / JBATA Disclaimer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A121D), RoundedCornerShape(6.dp))
                .border(1.dp, TerminalCardBorder, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(
                    Icons.Default.Info,
                    contentDescription = null,
                    tint = TerminalGold,
                    modifier = Modifier.size(16.dp).padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (state.isJapanese)
                        "重要告知: 全銀協TIBOR運営機関(JBATA)の公式規定に基づき、ウェブサイト上の公表値は参考情報です。契約や法的決定には公認情報提供機関経由の配信データをご使用ください。"
                    else
                        "Institutional Boundary Notice: JBATA explicitly stipulates that portal website rates represent reference information. Authoritative contracts must consume feeds disseminated via licensed, authorized market data providers.",
                    fontSize = 10.sp,
                    color = TerminalTextMuted,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 14.sp
                )
            }
        }
    }
}

@Composable
fun MarketMetricCard(
    title: String,
    value: String,
    subValue: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalSurfaceVariant)
            .border(1.dp, TerminalCardBorder, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(8.dp)
    ) {
        Column {
            Text(title, fontSize = 9.sp, color = TerminalTextMuted, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(3.dp))
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subValue, fontSize = 9.sp, color = TerminalTextSecondary, fontFamily = FontFamily.Monospace)
        }
    }
}
