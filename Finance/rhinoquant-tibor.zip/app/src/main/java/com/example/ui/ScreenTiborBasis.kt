package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TiborTenor
import com.example.ui.theme.TerminalCardBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TerminalTextMuted
import com.example.ui.theme.TerminalTextPrimary
import com.example.ui.theme.TerminalTextSecondary

@Composable
fun ScreenTiborBasis(
    state: TerminalUiState,
    modifier: Modifier = Modifier
) {
    val tona = state.overview.tona
    val fixings = state.overview.fixings

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        Text(
            text = "BASIS <GO> TIBOR - TONA BASIS SPREADS",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TerminalGold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = "Credit Risk & Term Premium over Unsecured Overnight Call (TONA)",
            fontSize = 10.sp,
            color = TerminalTextMuted,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Headline 3M Basis Card
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "HEADLINE 3M BENCHMARK BASIS",
                    fontSize = 10.sp,
                    color = TerminalTextMuted,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "+${state.overview.basis3mBp} bp",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = TerminalCyan,
                        fontFamily = FontFamily.Monospace
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Text("3M TIBOR: ${fixings[TiborTenor.M3]?.rate}%", fontSize = 11.sp, color = TerminalTextPrimary, fontFamily = FontFamily.Monospace)
                        Text("TONA Spot: ${String.format("%.4f", tona)}%", fontSize = 11.sp, color = TerminalTextSecondary, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tenor Basis Spreads Table
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "TENOR TERM BASIS MATRIX",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                TiborTenor.entries.forEach { tenor ->
                    val rate = fixings[tenor]?.rate?.toDouble() ?: 0.3
                    val spreadBp = ((rate - tona) * 100.0)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "TIBOR ${tenor.code} (${tenor.days}d) - TONA",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = TerminalTextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "TIBOR: ${String.format("%.4f", rate)}% | TONA: ${String.format("%.4f", tona)}%",
                                fontSize = 10.sp,
                                color = TerminalTextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = "+${String.format("%.2f", spreadBp)} bp",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TerminalGreen,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Divider(color = TerminalCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Economic Commentary
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceVariant, RoundedCornerShape(6.dp))
                .border(1.dp, TerminalCardBorder, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Text(
                text = "Market Commentary: The TIBOR-TONA basis measures the interbank funding premium over the risk-free overnight rate. As Bank of Japan normalizes policy, term liquidity premiums widen, reflecting credit and liquidity risk across Japanese money center banks.",
                fontSize = 10.sp,
                color = TerminalTextMuted,
                fontFamily = FontFamily.Monospace,
                lineHeight = 14.sp
            )
        }
    }
}
