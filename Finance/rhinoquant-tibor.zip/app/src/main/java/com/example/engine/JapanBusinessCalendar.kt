package com.example.engine

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object JapanBusinessCalendar {
    val TOKYO_TIMEZONE: TimeZone = TimeZone.getTimeZone("Asia/Tokyo")

    // Statutory Japanese National Holidays set (2025-2027 representation)
    private val holidaysYmd = setOf(
        "2026-01-01", "2026-01-02", "2026-01-03", "2026-01-12",
        "2026-02-11", "2026-02-23", "2026-03-20", "2026-04-29",
        "2026-05-03", "2026-05-04", "2026-05-05", "2026-05-06",
        "2026-07-20", "2026-08-11", "2026-09-21", "2026-09-22",
        "2026-09-23", "2026-10-12", "2026-11-03", "2026-11-23",
        "2026-12-31"
    )

    fun isBusinessDay(cal: Calendar): Boolean {
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        if (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY) {
            return false
        }
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TOKYO_TIMEZONE }
        val ymd = fmt.format(cal.time)
        return !holidaysYmd.contains(ymd)
    }

    fun getCurrentJstTimeString(): String {
        val fmt = SimpleDateFormat("HH:mm:ss 'JST'", Locale.US).apply { timeZone = TOKYO_TIMEZONE }
        return fmt.format(Date())
    }

    fun getCurrentJstDateString(): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TOKYO_TIMEZONE }
        return fmt.format(Date())
    }

    fun getPublicationWindowText(): String {
        return "13:00 JST (Cut-off: 11:00 JST / Submissions: 12:00 JST)"
    }
}
