-- RhinoQuant Institutional JBA TIBOR Market Data Database Schema
-- Version: 2026.1
-- Compatible with PostgreSQL 15+ / TimescaleDB

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Currencies
CREATE TABLE currencies (
    code VARCHAR(3) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    symbol VARCHAR(10) NOT NULL,
    fractional_digits INT NOT NULL DEFAULT 2,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO currencies (code, name, symbol, fractional_digits) VALUES
('JPY', 'Japanese Yen', '¥', 0),
('USD', 'US Dollar', '$', 2),
('EUR', 'Euro', '€', 2)
ON CONFLICT (code) DO NOTHING;

-- 2. Tenors
CREATE TABLE tenors (
    code VARCHAR(10) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    days_count INT NOT NULL,
    frequency_per_year NUMERIC(5,2) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO tenors (code, name, days_count, frequency_per_year) VALUES
('1W', '1 Week', 7, 52.0),
('1M', '1 Month', 30, 12.0),
('3M', '3 Months', 90, 4.0),
('6M', '6 Months', 180, 2.0),
('12M', '12 Months', 360, 1.0)
ON CONFLICT (code) DO NOTHING;

-- 3. Benchmarks
CREATE TABLE benchmarks (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    short_name VARCHAR(50) NOT NULL,
    currency VARCHAR(3) NOT NULL REFERENCES currencies(code),
    administrator VARCHAR(100) NOT NULL,
    jurisdiction VARCHAR(50) NOT NULL DEFAULT 'Japan',
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE', -- ACTIVE, TERMINATED, SUSPENDED
    methodology_version VARCHAR(20) NOT NULL DEFAULT 'v2026.1',
    publication_frequency VARCHAR(20) NOT NULL DEFAULT 'DAILY',
    publication_time_jst TIME NOT NULL DEFAULT '13:00:00',
    effective_date DATE NOT NULL,
    termination_date DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO benchmarks (id, name, short_name, currency, administrator, jurisdiction, status, methodology_version, publication_time_jst, effective_date)
VALUES ('JBA_TIBOR', 'Japanese Yen TIBOR', 'JBA TIBOR', 'JPY', 'JBA TIBOR Administration (JBATA)', 'Japan', 'ACTIVE', 'v2026.1', '13:00:00', '1995-11-01')
ON CONFLICT (id) DO NOTHING;

-- 4. Benchmark Versions
CREATE TABLE benchmark_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    benchmark_id VARCHAR(50) NOT NULL REFERENCES benchmarks(id),
    version_tag VARCHAR(30) NOT NULL,
    methodology_summary TEXT NOT NULL,
    trim_rules JSONB NOT NULL, -- e.g. {"exclude_top": 2, "exclude_bottom": 2}
    effective_from TIMESTAMPTZ NOT NULL,
    effective_to TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. Benchmark Sources & Licensing
CREATE TABLE benchmark_sources (
    id VARCHAR(50) PRIMARY KEY,
    provider_name VARCHAR(100) NOT NULL,
    source_type VARCHAR(50) NOT NULL, -- AUTHORISED_PROVIDER, REFERENCE_WEBSITE, LICENSED_MARKET_DATA, MOCK_PROVIDER
    is_authoritative BOOLEAN NOT NULL DEFAULT FALSE,
    licence_type VARCHAR(50) NOT NULL, -- COMMERCIAL, REDISTRIBUTION, REFERENCE_ONLY
    entitlement_required VARCHAR(50) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO benchmark_sources (id, provider_name, source_type, is_authoritative, licence_type, entitlement_required)
VALUES 
('JBATA_AUTH_01', 'Authorised Information Provider Feed A', 'AUTHORISED_PROVIDER', TRUE, 'COMMERCIAL', 'TIBOR_REALTIME'),
('JBATA_REF_WEB', 'JBATA Reference Public Portal', 'REFERENCE_WEBSITE', FALSE, 'REFERENCE_ONLY', 'TIBOR_PUBLIC'),
('RHINO_MOCK_SIM', 'RhinoQuant Institutional Simulator', 'MOCK_PROVIDER', FALSE, 'DEVELOPMENT', 'TIBOR_DEV')
ON CONFLICT (id) DO NOTHING;

-- 6. Source Observations (Immutable Raw Data)
CREATE TABLE source_observations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_id VARCHAR(50) NOT NULL REFERENCES benchmark_sources(id),
    benchmark_id VARCHAR(50) NOT NULL REFERENCES benchmarks(id),
    tenor VARCHAR(10) NOT NULL REFERENCES tenors(code),
    raw_payload JSONB NOT NULL,
    raw_rate NUMERIC(10, 6) NOT NULL,
    source_timestamp TIMESTAMPTZ NOT NULL,
    ingestion_timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    content_hash VARCHAR(64) NOT NULL,
    version INT NOT NULL DEFAULT 1
);
CREATE UNIQUE INDEX idx_source_obs_hash ON source_observations(content_hash);

-- 7. Benchmark Fixings (Canonical Observations)
CREATE TABLE benchmark_fixings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fixing_date DATE NOT NULL,
    publication_timestamp TIMESTAMPTZ NOT NULL,
    currency VARCHAR(3) NOT NULL REFERENCES currencies(code),
    benchmark VARCHAR(50) NOT NULL REFERENCES benchmarks(id),
    tenor VARCHAR(10) NOT NULL REFERENCES tenors(code),
    rate NUMERIC(10, 6) NOT NULL,
    unit VARCHAR(20) NOT NULL DEFAULT 'percent',
    status VARCHAR(30) NOT NULL DEFAULT 'OFFICIAL', -- OFFICIAL, CORRECTED, PROVISIONAL, REFERENCE, SYNTHETIC, DERIVED
    source VARCHAR(50) NOT NULL REFERENCES benchmark_sources(id),
    source_timestamp TIMESTAMPTZ NOT NULL,
    revision INT NOT NULL DEFAULT 0,
    effective_from TIMESTAMPTZ NOT NULL,
    effective_to TIMESTAMPTZ,
    content_hash VARCHAR(64) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_fixing UNIQUE (benchmark, fixing_date, tenor, revision)
);
CREATE INDEX idx_fixings_lookup ON benchmark_fixings(benchmark, tenor, fixing_date);

-- 8. Benchmark Rates
CREATE TABLE benchmark_rates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fixing_id UUID NOT NULL REFERENCES benchmark_fixings(id),
    spread_over_tona NUMERIC(8, 4),
    day_change_bp NUMERIC(8, 4),
    annualised_volatility_20d NUMERIC(8, 4),
    regime_classification VARCHAR(30),
    calculated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9. Publication Events
CREATE TABLE publication_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    benchmark VARCHAR(50) NOT NULL REFERENCES benchmarks(id),
    publication_date DATE NOT NULL,
    scheduled_time TIMESTAMPTZ NOT NULL,
    actual_time TIMESTAMPTZ,
    status VARCHAR(30) NOT NULL DEFAULT 'EXPECTED', -- EXPECTED, PUBLISHED, DELAYED, WITHHELD, CORRECTED, CONTINGENCY
    provider VARCHAR(50) NOT NULL REFERENCES benchmark_sources(id),
    source_timestamp TIMESTAMPTZ,
    contingency_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. Corrections
CREATE TABLE corrections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fixing_id UUID NOT NULL REFERENCES benchmark_fixings(id),
    benchmark VARCHAR(50) NOT NULL,
    tenor VARCHAR(10) NOT NULL,
    fixing_date DATE NOT NULL,
    original_rate NUMERIC(10, 6) NOT NULL,
    corrected_rate NUMERIC(10, 6) NOT NULL,
    reason TEXT NOT NULL,
    announcement_timestamp TIMESTAMPTZ NOT NULL,
    effective_timestamp TIMESTAMPTZ NOT NULL,
    source VARCHAR(50) NOT NULL,
    reference VARCHAR(100),
    status VARCHAR(30) NOT NULL DEFAULT 'CONFIRMED', -- PENDING, CONFIRMED, REJECTED, SUPERSEDED
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. Japan Holidays & Business Days
CREATE TABLE holidays (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    calendar_code VARCHAR(30) NOT NULL DEFAULT 'JP_TOKYO',
    holiday_date DATE NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    name_ja VARCHAR(100) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_holiday UNIQUE (calendar_code, holiday_date)
);

CREATE TABLE business_days (
    calendar_code VARCHAR(30) NOT NULL DEFAULT 'JP_TOKYO',
    market_date DATE NOT NULL PRIMARY KEY,
    is_business_day BOOLEAN NOT NULL DEFAULT TRUE,
    prev_business_day DATE NOT NULL,
    next_business_day DATE NOT NULL
);

-- 12. Reference Banks & Submissions
CREATE TABLE reference_banks (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    institution_type VARCHAR(50) NOT NULL, -- MAJOR_BANK, REGIONAL_BANK, TRUST_BANK
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_simulated BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE submission_observations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bank_id VARCHAR(50) NOT NULL REFERENCES reference_banks(id),
    tenor VARCHAR(10) NOT NULL REFERENCES tenors(code),
    fixing_date DATE NOT NULL,
    submission_rate NUMERIC(10, 6) NOT NULL,
    submission_timestamp TIMESTAMPTZ NOT NULL,
    included BOOLEAN NOT NULL DEFAULT TRUE,
    trimmed VARCHAR(10), -- HIGH, LOW, NULL
    methodology_version VARCHAR(20) NOT NULL,
    is_synthetic BOOLEAN NOT NULL DEFAULT FALSE
);

-- 13. Data Quality Events
CREATE TABLE data_quality_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    benchmark VARCHAR(50) NOT NULL,
    tenor VARCHAR(10) NOT NULL,
    event_timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    quality VARCHAR(20) NOT NULL, -- PASS, WARNING, FAIL
    check_type VARCHAR(50) NOT NULL, -- MISSING, JUMP, STALE, MISMATCH, OUTLIER
    z_score NUMERIC(8, 4),
    details JSONB NOT NULL,
    resolved BOOLEAN NOT NULL DEFAULT FALSE
);

-- 14. Curve Definitions & Curve Points
CREATE TABLE curve_definitions (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    currency VARCHAR(3) NOT NULL REFERENCES currencies(code),
    methodology VARCHAR(50) NOT NULL, -- MONOTONIC_CUBIC, NELSON_SIEGEL, LINEAR_ZERO
    derived BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE curve_points (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    curve_id VARCHAR(50) NOT NULL REFERENCES curve_definitions(id),
    as_of TIMESTAMPTZ NOT NULL,
    pillar_label VARCHAR(20) NOT NULL,
    days_to_maturity INT NOT NULL,
    zero_rate NUMERIC(10, 6) NOT NULL,
    discount_factor NUMERIC(12, 8) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 15. Forward Rates
CREATE TABLE forward_rates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    index_name VARCHAR(50) NOT NULL,
    period_start VARCHAR(10) NOT NULL,
    period_end VARCHAR(10) NOT NULL,
    as_of TIMESTAMPTZ NOT NULL,
    forward_rate NUMERIC(10, 6) NOT NULL,
    derived BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 16. Audit Events
CREATE TABLE audit_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    actor VARCHAR(100) NOT NULL,
    event_timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    operation VARCHAR(50) NOT NULL, -- DATA_CORRECTION, MANUAL_OVERRIDE, SOURCE_CHANGE, API_KEY_CREATE, ENTITLEMENT_CHANGE
    resource VARCHAR(100) NOT NULL,
    state_before JSONB,
    state_after JSONB,
    reason TEXT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    request_id VARCHAR(64) NOT NULL
);

-- 17. API Clients, Keys & Usage
CREATE TABLE api_clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    organization VARCHAR(100) NOT NULL,
    role VARCHAR(30) NOT NULL DEFAULT 'ANALYST', -- READ_ONLY, ANALYST, TRADER, RISK, ADMIN, DATA_ENGINEER, AUDITOR
    entitlements JSONB NOT NULL DEFAULT '["TIBOR_HISTORICAL", "TIBOR_REALTIME", "DERIVED_ANALYTICS"]'::jsonb,
    rate_limit_per_min INT NOT NULL DEFAULT 600,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES api_clients(id),
    key_hash VARCHAR(128) NOT NULL UNIQUE,
    key_prefix VARCHAR(10) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE usage_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID REFERENCES api_clients(id),
    endpoint VARCHAR(100) NOT NULL,
    method VARCHAR(10) NOT NULL,
    response_code INT NOT NULL,
    latency_ms NUMERIC(8, 2) NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
