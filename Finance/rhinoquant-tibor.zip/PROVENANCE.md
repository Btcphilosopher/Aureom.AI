# RHINOQUANT PROVENANCE & LINEAGE ARCHITECTURE

## 1. Traceability Standard
Every market rate fixing exposed by the RhinoQuant API provides complete cryptographic traceability:
- **Provider Identity**: Authorised disseminator vs reference scrape vs simulation mock.
- **Source Identifier**: Upstream feed message ID.
- **Timestamps**: Upstream publication timestamp (13:00 JST) vs ingress timestamp (13:00:02 JST).
- **Integrity Checksum**: Deterministic SHA-256 payload digest.
- **Licence Reference**: Contractual redistribute entitlement.

## 2. Statutory Public Dissemination Policy
JBATA explicitly directs that rates published on its public portal constitute reference information only.
Contractual rate determinations (e.g. loan benchmark fixings, interest rate derivatives settlements) must rely on feeds disseminated through authorized information providers (Bloomberg B-PIPE, LSEG Refinitiv, Quick).
RhinoQuant enforces this policy by tagging reference web scrapes as `status="REFERENCE"` and non-authoritative.
