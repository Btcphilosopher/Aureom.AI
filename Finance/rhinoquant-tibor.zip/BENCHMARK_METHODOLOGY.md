# RHINOQUANT BENCHMARK METHODOLOGY

## 1. JBATA Japanese Yen TIBOR Specification

- **Jurisdiction**: Tokyo Interbank Unsecured Call Money Market.
- **Published Tenors**: 1 Week (1W), 1 Month (1M), 3 Months (3M), 6 Months (6M), 12 Months (12M).
- **Publication Time**: 13:00 JST on Tokyo business days.
- **Calculation Formula**:
  $$\text{TIBOR} = \frac{1}{N - 4} \sum_{i=3}^{N-2} r_{(i)}$$
  Where submissions $r_{(1)} \le r_{(2)} \le \dots \le r_{(N)}$ are ordered ascendingly, and the 2 highest and 2 lowest submissions are strictly trimmed.

## 2. Contingency Protocol
Under JBATA published contingency conditions (severe market disruption, system failure, insufficient reference bank submissions):
1. **NORMAL**: Standard calculation from eligible submitted rates.
2. **DELAYED**: Publication delayed beyond 13:00 JST due to telecommunication verification.
3. **CONTINGENCY / PREVIOUS_FIXING**: Roll forward previous business day's official fixing if submission threshold is unmet.
4. **CORRECTION_PENDING**: Formal correction notification broadcast to market participants.
