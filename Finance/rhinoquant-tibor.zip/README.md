# RHINOQUANT TIBOR API (RQTIBOR)
### Institutional Japanese Yen Money-Market Benchmark Platform & Tokyo Rates Terminal

[![CI/CD Status](https://github.com/rhinoquant/rhinoquant-tibor-api/actions/workflows/ci.yml/badge.svg)](https://github.com/rhinoquant/rhinoquant-tibor-api)
[![Benchmark](https://img.shields.io/badge/Benchmark-JBA%20TIBOR-blue)](https://www.jbatibor.or.jp/)
[![Currency](https://img.shields.io/badge/Currency-JPY-green)](https://en.wikipedia.org/wiki/Japanese_yen)
[![Architecture](https://img.shields.io/badge/Standard-IOSCO%20Principles-purple)](https://www.iosco.org/)

---

## 1. Core Principles & Provenance Boundary

RhinoQuant TIBOR API strictly distinguishes four levels of market data:

```
OFFICIAL JBA TIBOR (JBATA Benchmark via Authorised Providers)
        ↓
SOURCE / PROVENANCE (Audit trail, timestamps, checksums, licenses)
        ↓
NORMALISED RHINOQUANT DATA (Verified canonical observations)
        ↓
DERIVED RHINOQUANT ANALYTICS (Curves, forwards, basis, shock scenarios)
```

**Non-Blurring Guarantee**:
- Official JBA TIBOR fixings are flagged `status="OFFICIAL"`, `derived=false`.
- Calculated analytics (e.g. forward rates, spline curves, basis spreads) are explicitly flagged `derived=true`, `methodology="RHINOQUANT"`.
- JBATA public website scrapes are categorized as `REFERENCE`, never as authoritative legal contract benchmarks.

---

## 2. Benchmark Specifications

- **Administrator**: JBA TIBOR Administration (JBATA)
- **Currency**: Japanese Yen (JPY)
- **Official Tenors**: 1W, 1M, 3M, 6M, 12M
- **Publication Time**: Daily at 13:00 JST (Tokyo Business Days)
- **Calculation Methodology**: Arithmetic mean after excluding the two highest and two lowest submitted rates across reference banks.

---

## 3. Technology Stack

- **Primary Service**: Python 3.12+, FastAPI, Pydantic v2, SQLAlchemy 2, asyncpg
- **Performance Layer**: Rust (`rust/tibor_engine`) - Monotonic cubic spline, forward generation, JBATA trimming
- **Statistical Validation**: R (`r/validation`) - Time series jump tests, rugarch, GARCH volatility checks
- **Database**: PostgreSQL 16+ / TimescaleDB
- **Bulk Market Data**: Apache Parquet via PyArrow / Polars
- **Terminal UI**: Native Android Jetpack Compose Tokyo Rates Terminal with Bloomberg-style `<GO>` command engine.

---

## 4. RhinoQuant Terminal Commands

| Command | Destination | Description |
|---|---|---|
| `TIBOR <GO>` | Tokyo Rates Overview | Complete rates board (1W-12M TIBOR, TONA, Basis, JGB, Swaps) |
| `TIBH <GO>` | Historical Charts | Interactive time-series with crosshairs (1D, 1W, 1M, 3M, 1Y, 5Y) |
| `TIBC <GO>` | Curve Builder | Monotonic cubic zero curve, discount factors, pillars |
| `TIBF <GO>` | Forward Rate Matrix | 3Mx6M, 6Mx9M, 9Mx12M implied forwards & percentiles |
| `BASIS <GO>` | TIBOR - TONA Basis | Spread analysis and historical basis evolution |
| `TONA <GO>` | Tokyo Overnight Average | Unsecured call overnight benchmark monitor |
| `JGB <GO>` | Japanese Govt Bonds | 10Y and 30Y JGB yields |
| `JPSW <GO>` | JPY Interest Rate Swaps | 5Y and 10Y IRS market data |
| `RISK <GO>` | Scenario / Shock Lab | +25 bp rate hike simulation, DV01 portfolio impact |
| `DATA <GO>` | Provenance & Licensing | Source tracking, checksums, authorisations |
| `LAB <GO>` | JBATA Calculation Lab | Reference banks trimmed mean simulator |
| `AUDIT <GO>` | Regulatory Audit Log | Immutable event log for corrections and operations |

---

## 5. Quickstart

```bash
# Start backend, postgres, redis, and rust workers
docker compose up -d

# Verify system health
curl http://localhost:8000/health/ready

# Query latest 3M fixing
curl "http://localhost:8000/api/v1/tibor?tenor=3M"
```
