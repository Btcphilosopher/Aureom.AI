package com.example.domain.model

enum class TransactionCategory(val displayName: String) {
    GROCERIES("Groceries"),
    TRANSPORT("Transport"),
    HOUSING("Housing & Rent"),
    BILLS("Utilities & Bills"),
    RESTAURANTS("Restaurants & Cafes"),
    SHOPPING("Shopping"),
    ENTERTAINMENT("Entertainment"),
    SALARY("Salary & Income"),
    TRANSFERS("Transfers"),
    HEALTH("Health & Fitness"),
    TRAVEL("Travel"),
    OTHER("Other")
}

enum class TransactionStatus(val displayName: String) {
    COMPLETED("Completed"),
    PENDING("Pending"),
    REVERSED("Reversed")
}

enum class TransactionType(val displayName: String) {
    CARD_PURCHASE("Card Payment"),
    FASTER_PAYMENT("Faster Payment"),
    DIRECT_DEBIT("Direct Debit"),
    STANDING_ORDER("Standing Order"),
    SALARY_CREDIT("Salary Credit"),
    INTERNAL_TRANSFER("Internal Transfer"),
    ATM_WITHDRAWAL("ATM Cash")
}

data class Transaction(
    val id: String,
    val accountId: String,
    val merchantOrPayee: String,
    val amount: Long, // negative for money out, positive for money in (pence)
    val timestamp: Long,
    val category: TransactionCategory,
    val status: TransactionStatus,
    val reference: String,
    val type: TransactionType,
    val reversalOfTransactionId: String? = null,
    val idempotencyKey: String = "",
    val location: String? = null
)
