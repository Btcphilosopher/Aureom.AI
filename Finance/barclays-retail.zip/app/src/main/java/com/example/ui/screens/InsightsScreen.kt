package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Money
import com.example.domain.service.ExplainableInsight
import com.example.domain.service.InsightType
import com.example.ui.BarclaysViewModel
import com.example.ui.components.getCategoryColor
import com.example.ui.components.getCategoryIcon
import com.example.ui.theme.BarclaysCyan
import com.example.ui.theme.BarclaysNavyDark
import com.example.ui.theme.BarclaysNavyDeep
import com.example.ui.theme.BarclaysWhite
import com.example.ui.theme.FinancialAmber
import com.example.ui.theme.FinancialGreen
import com.example.ui.theme.FinancialRed
import kotlin.math.abs
import androidx.compose.material3.ExperimentalMaterial3Api

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InsightsScreen(
    viewModel: BarclaysViewModel,
    modifier: Modifier = Modifier
) {
    var selectedSection by remember { mutableIntStateOf(0) } // 0: Spending & Budgets, 1: Savings Growth, 2: Borrowing Calculator

    val summary by viewModel.spendingSummary.collectAsStateWithLifecycle()
    val budgets by viewModel.budgets.collectAsStateWithLifecycle()
    val savingsGoals by viewModel.savingsGoals.collectAsStateWithLifecycle()
    val isPrivacyMasked by viewModel.privacyHideBalances.collectAsStateWithLifecycle()

    val savingsProjection by viewModel.savingsProjectionResult.collectAsStateWithLifecycle()
    val loanResult by viewModel.loanCalculationResult.collectAsStateWithLifecycle()

    // Interactive slider states
    val currentInitPence by viewModel.savingsInitialPence.collectAsStateWithLifecycle()
    val currentMonthlyPence by viewModel.savingsMonthlyPence.collectAsStateWithLifecycle()
    val currentRate by viewModel.savingsRatePercent.collectAsStateWithLifecycle()
    val currentYears by viewModel.savingsYears.collectAsStateWithLifecycle()

    val currentPrincipalPence by viewModel.loanPrincipalPence.collectAsStateWithLifecycle()
    val currentApr by viewModel.loanAprPercent.collectAsStateWithLifecycle()
    val currentTermMonths by viewModel.loanTermMonths.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        SecondaryTabRow(
            selectedTabIndex = selectedSection,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = BarclaysNavyDeep
        ) {
            Tab(
                selected = selectedSection == 0,
                onClick = { selectedSection = 0 },
                text = { Text("Spending & Budgets", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_insights_spending")
            )
            Tab(
                selected = selectedSection == 1,
                onClick = { selectedSection = 1 },
                text = { Text("Savings Engine", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_insights_savings")
            )
            Tab(
                selected = selectedSection == 2,
                onClick = { selectedSection = 2 },
                text = { Text("Loan Calculator", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_insights_borrowing")
            )
        }

        when (selectedSection) {
            0 -> {
                // SPENDING & BUDGETS
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Month-over-Month Delta Hero Card
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = "MONTHLY CASH FLOW & COMPARISON",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    letterSpacing = 1.sp
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "Outgoings This Month",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = if (isPrivacyMasked) "£ ••••••" else Money.formatPence(summary.totalOutgoingsPence),
                                            style = MaterialTheme.typography.headlineMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = BarclaysNavyDark
                                        )
                                    }

                                    // Delta Badge
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (summary.deltaPence > 0) FinancialAmber.copy(alpha = 0.15f) else FinancialGreen.copy(alpha = 0.15f)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = if (summary.deltaPence > 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                                contentDescription = null,
                                                tint = if (summary.deltaPence > 0) FinancialAmber else FinancialGreen,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "${if (summary.deltaPence > 0) "+" else ""}${"%.1f".format(summary.percentageChange)}%",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (summary.deltaPence > 0) FinancialAmber else FinancialGreen
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))
                                HorizontalDivider()
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Previous Month Outgoings: ${Money.formatPence(summary.previousMonthTotalPence)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = if (summary.deltaPence > 0) "+${Money.formatPence(summary.deltaPence)} vs last month" else "-${Money.formatPence(abs(summary.deltaPence))} vs last month",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (summary.deltaPence > 0) FinancialAmber else FinancialGreen
                                    )
                                }
                            }
                        }
                    }

                    // Explainable Insights Cards
                    item {
                        Text(
                            text = "INTELLIGENT FINANCIAL INSIGHTS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                    }

                    items(summary.insights) { insight ->
                        InsightCard(insight = insight)
                    }

                    // Category Breakdown Visual
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = "SPENDING BY CATEGORY",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    letterSpacing = 1.sp
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                summary.categoryBreakdown.forEach { catSpend ->
                                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(28.dp)
                                                        .clip(CircleShape)
                                                        .background(getCategoryColor(catSpend.category).copy(alpha = 0.15f)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = getCategoryIcon(catSpend.category),
                                                        contentDescription = null,
                                                        tint = getCategoryColor(catSpend.category),
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = catSpend.category.displayName,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = Money.formatPence(catSpend.totalPence),
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "(${ "%.0f".format(catSpend.percentageOfTotal) }%)",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        LinearProgressIndicator(
                                            progress = { (catSpend.percentageOfTotal / 100f).coerceIn(0f, 1f) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(6.dp)
                                                .clip(RoundedCornerShape(3.dp)),
                                            color = getCategoryColor(catSpend.category),
                                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Monthly Budgets Tracker
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = "MONTHLY BUDGET LIMITS",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    letterSpacing = 1.sp
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                budgets.forEach { budget ->
                                    val progress = budget.progressPercent
                                    val isOverBudget = progress > 1f
                                    val isWarning = progress > 0.8f

                                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = budget.category.displayName,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "${Money.formatPence(budget.spentThisMonth)} / ${Money.formatPence(budget.monthlyLimit)}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isOverBudget) FinancialRed else if (isWarning) FinancialAmber else MaterialTheme.colorScheme.onSurface
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        LinearProgressIndicator(
                                            progress = { progress.coerceIn(0f, 1f) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(8.dp)
                                                .clip(RoundedCornerShape(4.dp)),
                                            color = if (isOverBudget) FinancialRed else if (isWarning) FinancialAmber else FinancialGreen,
                                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // SAVINGS PROJECTION ENGINE
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Text(
                            text = "COMPOUND SAVINGS PROJECTION ENGINE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Model compound returns with monthly deposits and annual interest compounding.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Result Highlight Card
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = BarclaysNavyDeep),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text(
                                    text = "Estimated Balance in $currentYears Years",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BarclaysCyan
                                )
                                Text(
                                    text = Money.formatPence(savingsProjection.finalBalance),
                                    style = MaterialTheme.typography.headlineLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BarclaysWhite
                                )

                                Spacer(modifier = Modifier.height(14.dp))
                                HorizontalDivider(color = BarclaysWhite.copy(alpha = 0.2f))
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Total Contributed", style = MaterialTheme.typography.bodySmall, color = BarclaysWhite.copy(alpha = 0.7f))
                                        Text(Money.formatPence(savingsProjection.totalPrincipalContributed), fontWeight = FontWeight.Bold, color = BarclaysWhite)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Interest Earned", style = MaterialTheme.typography.bodySmall, color = BarclaysWhite.copy(alpha = 0.7f))
                                        Text(Money.formatPence(savingsProjection.totalInterestEarned), fontWeight = FontWeight.Bold, color = FinancialGreen)
                                    }
                                }
                            }
                        }
                    }

                    // Controls Card
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text("Interactive Model Parameters", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                                // Initial Deposit Slider
                                Column {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Initial Deposit", style = MaterialTheme.typography.bodySmall)
                                        Text(Money.formatPence(currentInitPence), fontWeight = FontWeight.Bold)
                                    }
                                    Slider(
                                        value = (currentInitPence / 100).toFloat(),
                                        onValueChange = {
                                            viewModel.updateSavingsProjectionInputs(it.toLong() * 100, currentMonthlyPence, currentRate, currentYears)
                                        },
                                        valueRange = 0f..25000f,
                                        steps = 50,
                                        colors = SliderDefaults.colors(thumbColor = BarclaysCyan, activeTrackColor = BarclaysNavyDeep),
                                        modifier = Modifier.testTag("slider_savings_init")
                                    )
                                }

                                // Monthly Contribution Slider
                                Column {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Monthly Deposit", style = MaterialTheme.typography.bodySmall)
                                        Text(Money.formatPence(currentMonthlyPence), fontWeight = FontWeight.Bold)
                                    }
                                    Slider(
                                        value = (currentMonthlyPence / 100).toFloat(),
                                        onValueChange = {
                                            viewModel.updateSavingsProjectionInputs(currentInitPence, it.toLong() * 100, currentRate, currentYears)
                                        },
                                        valueRange = 0f..1500f,
                                        steps = 30,
                                        colors = SliderDefaults.colors(thumbColor = BarclaysCyan, activeTrackColor = BarclaysNavyDeep),
                                        modifier = Modifier.testTag("slider_savings_monthly")
                                    )
                                }

                                // Interest Rate Slider
                                Column {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Annual AER / APY", style = MaterialTheme.typography.bodySmall)
                                        Text("${"%.2f".format(currentRate)}%", fontWeight = FontWeight.Bold)
                                    }
                                    Slider(
                                        value = currentRate.toFloat(),
                                        onValueChange = {
                                            viewModel.updateSavingsProjectionInputs(currentInitPence, currentMonthlyPence, it.toDouble(), currentYears)
                                        },
                                        valueRange = 1.0f..8.0f,
                                        colors = SliderDefaults.colors(thumbColor = BarclaysCyan, activeTrackColor = BarclaysNavyDeep),
                                        modifier = Modifier.testTag("slider_savings_rate")
                                    )
                                }

                                // Duration Years Slider
                                Column {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Timeline", style = MaterialTheme.typography.bodySmall)
                                        Text("$currentYears Years", fontWeight = FontWeight.Bold)
                                    }
                                    Slider(
                                        value = currentYears.toFloat(),
                                        onValueChange = {
                                            viewModel.updateSavingsProjectionInputs(currentInitPence, currentMonthlyPence, currentRate, it.toInt())
                                        },
                                        valueRange = 1f..15f,
                                        steps = 14,
                                        colors = SliderDefaults.colors(thumbColor = BarclaysCyan, activeTrackColor = BarclaysNavyDeep),
                                        modifier = Modifier.testTag("slider_savings_years")
                                    )
                                }
                            }
                        }
                    }

                    // Yearly Breakdown Timeline
                    item {
                        Text(
                            text = "PROJECTED ANNUAL GROWTH TIMELINE",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                    }

                    items(savingsProjection.yearlyBreakdown.take(10)) { year ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("End of Year ${year.year}", fontWeight = FontWeight.Bold)
                                    Text("Deposits: ${Money.formatPence(year.totalContributed)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(Money.formatPence(year.totalSaved), fontWeight = FontWeight.Bold, color = BarclaysNavyDark)
                                    Text("+${Money.formatPence(year.interestEarned)} interest", fontSize = 11.sp, color = FinancialGreen, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // LOAN & MORTGAGE REPAYMENT ESTIMATOR
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Text(
                            text = "BORROWING & REPAYMENT ESTIMATOR",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Illustrative calculation of monthly payments using standard amortization math. Clearly labelled demonstration.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Result Card
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = BarclaysNavyDeep),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text("Estimated Monthly Payment", style = MaterialTheme.typography.bodySmall, color = BarclaysCyan)
                                Text(
                                    text = Money.formatPence(loanResult.monthlyPaymentPence),
                                    style = MaterialTheme.typography.headlineLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BarclaysWhite
                                )

                                Spacer(modifier = Modifier.height(14.dp))
                                HorizontalDivider(color = BarclaysWhite.copy(alpha = 0.2f))
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Total Repayment", style = MaterialTheme.typography.bodySmall, color = BarclaysWhite.copy(alpha = 0.7f))
                                        Text(Money.formatPence(loanResult.totalRepaymentPence), fontWeight = FontWeight.Bold, color = BarclaysWhite)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Total Interest Charge", style = MaterialTheme.typography.bodySmall, color = BarclaysWhite.copy(alpha = 0.7f))
                                        Text(Money.formatPence(loanResult.totalInterestPence), fontWeight = FontWeight.Bold, color = FinancialAmber)
                                    }
                                }
                            }
                        }
                    }

                    // Sliders
                    item {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text("Loan Parameters", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                                // Principal Slider
                                Column {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Borrowing Amount", style = MaterialTheme.typography.bodySmall)
                                        Text(Money.formatPence(currentPrincipalPence), fontWeight = FontWeight.Bold)
                                    }
                                    Slider(
                                        value = (currentPrincipalPence / 100).toFloat(),
                                        onValueChange = {
                                            viewModel.updateLoanInputs(it.toLong() * 100, currentApr, currentTermMonths)
                                        },
                                        valueRange = 1000f..50000f,
                                        steps = 49,
                                        colors = SliderDefaults.colors(thumbColor = BarclaysCyan, activeTrackColor = BarclaysNavyDeep),
                                        modifier = Modifier.testTag("slider_loan_principal")
                                    )
                                }

                                // APR Slider
                                Column {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Representative APR", style = MaterialTheme.typography.bodySmall)
                                        Text("${"%.1f".format(currentApr)}%", fontWeight = FontWeight.Bold)
                                    }
                                    Slider(
                                        value = currentApr.toFloat(),
                                        onValueChange = {
                                            viewModel.updateLoanInputs(currentPrincipalPence, it.toDouble(), currentTermMonths)
                                        },
                                        valueRange = 3.0f..19.9f,
                                        colors = SliderDefaults.colors(thumbColor = BarclaysCyan, activeTrackColor = BarclaysNavyDeep),
                                        modifier = Modifier.testTag("slider_loan_apr")
                                    )
                                }

                                // Term Slider
                                Column {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Repayment Term", style = MaterialTheme.typography.bodySmall)
                                        Text("$currentTermMonths Months (${currentTermMonths / 12} yrs)", fontWeight = FontWeight.Bold)
                                    }
                                    Slider(
                                        value = currentTermMonths.toFloat(),
                                        onValueChange = {
                                            viewModel.updateLoanInputs(currentPrincipalPence, currentApr, it.toInt())
                                        },
                                        valueRange = 12f..84f,
                                        steps = 6,
                                        colors = SliderDefaults.colors(thumbColor = BarclaysCyan, activeTrackColor = BarclaysNavyDeep),
                                        modifier = Modifier.testTag("slider_loan_term")
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = BarclaysCyan.copy(alpha = 0.08f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = BarclaysNavyDeep)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Illustrative estimate only. Actual personal loan quotes depend on credit assessment and individual affordability status.",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = BarclaysNavyDeep
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InsightCard(insight: ExplainableInsight) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(
                            when (insight.type) {
                                InsightType.SPENDING_ALERT -> FinancialAmber.copy(alpha = 0.15f)
                                InsightType.SAVING_OPPORTUNITY -> BarclaysCyan.copy(alpha = 0.15f)
                                InsightType.POSITIVE_TREND -> FinancialGreen.copy(alpha = 0.15f)
                                InsightType.SUBSCRIPTION_CHECK -> Color(0xFF6A1B9A).copy(alpha = 0.15f)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (insight.type) {
                            InsightType.SPENDING_ALERT -> Icons.Default.Warning
                            InsightType.SAVING_OPPORTUNITY -> Icons.Default.Lightbulb
                            InsightType.POSITIVE_TREND -> Icons.Default.CheckCircle
                            InsightType.SUBSCRIPTION_CHECK -> Icons.Default.Payments
                        },
                        contentDescription = null,
                        tint = when (insight.type) {
                            InsightType.SPENDING_ALERT -> FinancialAmber
                            InsightType.SAVING_OPPORTUNITY -> BarclaysCyan
                            InsightType.POSITIVE_TREND -> FinancialGreen
                            InsightType.SUBSCRIPTION_CHECK -> Color(0xFF6A1B9A)
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = insight.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BarclaysNavyDark
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = insight.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Method: ${insight.calculationDetails}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
    }
}
