package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Account
import com.example.domain.model.Money
import com.example.domain.model.Transaction
import com.example.domain.model.TransactionCategory
import com.example.domain.model.TransactionStatus
import com.example.ui.BarclaysViewModel
import com.example.ui.TxDirectionFilter
import com.example.ui.components.TransactionRow
import com.example.ui.theme.BarclaysCyan
import com.example.ui.theme.BarclaysNavyDark
import com.example.ui.theme.BarclaysNavyDeep
import com.example.ui.theme.BarclaysWhite
import com.example.ui.theme.FinancialAmber
import com.example.ui.theme.FinancialGreen
import com.example.ui.theme.FinancialRed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(
    viewModel: BarclaysViewModel,
    onNavigateToMove: (String) -> Unit,
    onOpenStatements: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accounts by viewModel.accounts.collectAsStateWithLifecycle()
    val selectedAccountId by viewModel.selectedAccountId.collectAsStateWithLifecycle()
    val filteredTransactions by viewModel.filteredTransactions.collectAsStateWithLifecycle()
    val isPrivacyMasked by viewModel.privacyHideBalances.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedTxCategory.collectAsStateWithLifecycle()
    val selectedDirection by viewModel.selectedDirection.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    var activeDetailTx by remember { mutableStateOf<Transaction?>(null) }
    var txToReverse by remember { mutableStateOf<Transaction?>(null) }

    val selectedAccount = accounts.firstOrNull { it.id == selectedAccountId }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Account Switcher Horizontal Bar
        item {
            Column(modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) {
                Text(
                    text = "SELECT ACCOUNT",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedAccountId == null,
                        onClick = { viewModel.selectAccount(null) },
                        label = { Text("All Accounts (${accounts.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BarclaysNavyDeep,
                            selectedLabelColor = BarclaysWhite
                        ),
                        modifier = Modifier.testTag("filter_account_all")
                    )

                    accounts.forEach { acc ->
                        FilterChip(
                            selected = selectedAccountId == acc.id,
                            onClick = { viewModel.selectAccount(acc.id) },
                            label = { Text(acc.name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BarclaysNavyDeep,
                                selectedLabelColor = BarclaysWhite
                            ),
                            modifier = Modifier.testTag("filter_account_${acc.id}")
                        )
                    }
                }
            }
        }

        // Account Details Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = selectedAccount?.name ?: "All Portfolio Accounts",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = BarclaysNavyDark
                            )
                            Text(
                                text = selectedAccount?.let { "${it.sortCode} • ${it.accountNumber} • Synthetic Demo" }
                                    ?: "Combined Sterling Balances • Reconciled Ledger",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = BarclaysCyan.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = selectedAccount?.accountType?.displayName?.uppercase() ?: "PORTFOLIO",
                                color = BarclaysNavyDeep,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    val balancePence = selectedAccount?.availableBalance ?: accounts.sumOf { it.availableBalance }
                    Text(
                        text = "Available to Spend",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (isPrivacyMasked) "£ ••••••" else Money.formatPence(balancePence),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = BarclaysNavyDark,
                        letterSpacing = (-0.5).sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Secondary Balances: Booked, Pending, Overdraft/APY
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Booked Balance",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val booked = selectedAccount?.bookedBalance ?: accounts.sumOf { it.bookedBalance }
                            Text(
                                text = if (isPrivacyMasked) "£••••" else Money.formatPence(booked),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Pending",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val pending = selectedAccount?.totalPendingCommitments ?: accounts.sumOf { it.totalPendingCommitments }
                            Text(
                                text = if (isPrivacyMasked) "£•••" else Money.formatPence(pending),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = if (pending > 0) FinancialAmber else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            if (selectedAccount?.interestRateApy != null) {
                                Text(
                                    text = "Annual Interest",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${selectedAccount.interestRateApy}% AER",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = FinancialGreen
                                )
                            } else {
                                Text(
                                    text = "Overdraft Buffer",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                val overdraft = selectedAccount?.overdraftLimit ?: 50000L
                                Text(
                                    text = if (isPrivacyMasked) "£•••" else Money.formatPence(overdraft),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onNavigateToMove(selectedAccountId ?: accounts.firstOrNull()?.id ?: "") },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BarclaysNavyDeep),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("account_move_money_button")
                        ) {
                            Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, tint = BarclaysCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Move Money", fontSize = 13.sp, color = BarclaysWhite)
                        }

                        OutlinedButton(
                            onClick = onOpenStatements,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("account_statements_button")
                        ) {
                            Icon(imageVector = Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Statements", fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Search Field & Direction Filters
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search merchant, reference, category...") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("accounts_search_field")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Direction Filters (All, Money In, Money Out, Pending)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TxDirectionFilter.entries.forEach { dir ->
                        FilterChip(
                            selected = selectedDirection == dir,
                            onClick = { viewModel.setDirectionFilter(dir) },
                            label = { Text(dir.label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BarclaysNavyDeep,
                                selectedLabelColor = BarclaysWhite
                            ),
                            modifier = Modifier.testTag("direction_chip_${dir.name.lowercase()}")
                        )
                    }
                }

                // Category Chips row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { viewModel.setCategoryFilter(null) },
                        label = { Text("All Categories", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BarclaysCyan.copy(alpha = 0.2f),
                            selectedLabelColor = BarclaysNavyDark
                        )
                    )

                    TransactionCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { viewModel.setCategoryFilter(if (selectedCategory == cat) null else cat) },
                            label = { Text(cat.displayName, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BarclaysCyan.copy(alpha = 0.2f),
                                selectedLabelColor = BarclaysNavyDark
                            )
                        )
                    }
                }
            }
        }

        // Transaction Ledger Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TRANSACTION LEDGER (${filteredTransactions.size})",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            }
        }

        if (filteredTransactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No matching transactions found",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Try clearing filters or searching another keyword.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredTransactions, key = { it.id }) { tx ->
                TransactionRow(
                    transaction = tx,
                    isPrivacyMasked = isPrivacyMasked,
                    onClick = { activeDetailTx = tx },
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
        }
    }

    // Transaction Detail Bottom Sheet
    activeDetailTx?.let { tx ->
        ModalBottomSheet(
            onDismissRequest = { activeDetailTx = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Transaction Record",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { activeDetailTx = null }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Big Amount
                Text(
                    text = Money.formatPence(tx.amount, includeSign = true),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (tx.amount > 0) FinancialGreen else BarclaysNavyDark
                )

                Text(
                    text = tx.merchantOrPayee,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(12.dp))

                DetailRow("Status", tx.status.displayName)
                DetailRow("Type", tx.type.displayName)
                DetailRow("Reference", tx.reference)
                DetailRow(
                    "Timestamp",
                    SimpleDateFormat("dd MMMM yyyy, HH:mm:ss", Locale.UK).format(Date(tx.timestamp))
                )
                DetailRow("Location", tx.location ?: "UK Domestic Payment Gateway")
                DetailRow("Idempotency Key", tx.idempotencyKey.ifEmpty { "idemp-sys-gen" })

                if (tx.reversalOfTransactionId != null) {
                    DetailRow("Reversal Of", tx.reversalOfTransactionId)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Reversal Button if not already reversed
                if (tx.status != TransactionStatus.REVERSED && tx.amount < 0) {
                    OutlinedButton(
                        onClick = {
                            txToReverse = tx
                            activeDetailTx = null
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = FinancialRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("reverse_transaction_button")
                    ) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reverse Transaction (Audit Action)", fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Safety Confirmation Dialog for Transaction Reversal
    txToReverse?.let { tx ->
        AlertDialog(
            onDismissRequest = { txToReverse = null },
            title = { Text("Confirm Transaction Reversal", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "This action will credit ${Money.formatPence(-tx.amount)} back into your account and write a linked, permanent reversal audit record to the banking ledger for \"${tx.merchantOrPayee}\".",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.reverseTransaction(tx.id)
                        txToReverse = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FinancialRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_reversal_button")
                ) {
                    Text("Confirm Reversal", color = BarclaysWhite)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { txToReverse = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
    }
}
