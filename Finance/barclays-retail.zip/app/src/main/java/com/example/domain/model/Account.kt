package com.example.domain.model

enum class AccountType(val displayName: String) {
    CURRENT("Current Account"),
    SAVINGS("Savings Account"),
    POT("Goal Pot"),
    BILLS("Bills Account")
}

data class Account(
    val id: String,
    val name: String,
    val accountType: AccountType,
    val sortCode: String,
    val accountNumber: String,
    val availableBalance: Long, // in pence
    val bookedBalance: Long,    // in pence
    val pendingBalance: Long,   // in pence
    val interestRateApy: Double? = null, // e.g. 4.75 for 4.75%
    val isPrimary: Boolean = false,
    val overdraftLimit: Long = 50000L // £500.00
) {
    val totalPendingCommitments: Long
        get() = bookedBalance - availableBalance
}
