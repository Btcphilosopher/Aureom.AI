package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Money
import com.example.domain.model.Transaction
import com.example.domain.model.TransactionCategory
import com.example.domain.model.TransactionStatus
import com.example.ui.theme.BarclaysCyan
import com.example.ui.theme.BarclaysNavyDeep
import com.example.ui.theme.FinancialAmber
import com.example.ui.theme.FinancialGreen
import com.example.ui.theme.FinancialRed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TransactionRow(
    transaction: Transaction,
    isPrivacyMasked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPositive = transaction.amount > 0
    val isReversed = transaction.status == TransactionStatus.REVERSED
    val isPending = transaction.status == TransactionStatus.PENDING

    val dateStr = SimpleDateFormat("dd MMM, HH:mm", Locale.UK).format(Date(transaction.timestamp))

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("tx_row_${transaction.id}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            // Category Icon Badge
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(getCategoryColor(transaction.category).copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getCategoryIcon(transaction.category),
                    contentDescription = transaction.category.displayName,
                    tint = getCategoryColor(transaction.category),
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.merchantOrPayee,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isReversed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textDecoration = if (isReversed) TextDecoration.LineThrough else null
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "$dateStr • ${transaction.type.displayName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )

                    if (isPending) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(3.dp),
                            color = FinancialAmber.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "PENDING",
                                color = FinancialAmber,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    } else if (isReversed) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(3.dp),
                            color = FinancialRed.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "REVERSED",
                                color = FinancialRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Amount Column
        Column(horizontalAlignment = Alignment.End) {
            val amountText = if (isPrivacyMasked) {
                if (isPositive) "+£•••" else "-£•••"
            } else {
                Money.formatPence(transaction.amount, includeSign = true)
            }

            Text(
                text = amountText,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = when {
                    isReversed -> MaterialTheme.colorScheme.onSurfaceVariant
                    isPending -> FinancialAmber
                    isPositive -> FinancialGreen
                    else -> MaterialTheme.colorScheme.onSurface
                },
                textDecoration = if (isReversed) TextDecoration.LineThrough else null
            )

            Text(
                text = transaction.category.displayName,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp
            )
        }
    }
}

fun getCategoryIcon(category: TransactionCategory): ImageVector {
    return when (category) {
        TransactionCategory.GROCERIES -> Icons.Default.Fastfood
        TransactionCategory.TRANSPORT -> Icons.Default.DirectionsCar
        TransactionCategory.HOUSING -> Icons.Default.Home
        TransactionCategory.BILLS -> Icons.Default.Lightbulb
        TransactionCategory.RESTAURANTS -> Icons.Default.Fastfood
        TransactionCategory.SHOPPING -> Icons.Default.ShoppingBag
        TransactionCategory.ENTERTAINMENT -> Icons.Default.Movie
        TransactionCategory.SALARY -> Icons.Default.Payments
        TransactionCategory.TRANSFERS -> Icons.Default.SyncAlt
        TransactionCategory.HEALTH -> Icons.Default.FitnessCenter
        TransactionCategory.TRAVEL -> Icons.Default.CreditCard
        TransactionCategory.OTHER -> Icons.Default.ReceiptLong
    }
}

fun getCategoryColor(category: TransactionCategory): Color {
    return when (category) {
        TransactionCategory.SALARY -> FinancialGreen
        TransactionCategory.GROCERIES -> Color(0xFF2E7D32)
        TransactionCategory.TRANSPORT -> Color(0xFF0288D1)
        TransactionCategory.HOUSING -> Color(0xFF6A1B9A)
        TransactionCategory.BILLS -> Color(0xFFEF6C00)
        TransactionCategory.RESTAURANTS -> Color(0xFFD81B60)
        TransactionCategory.SHOPPING -> Color(0xFF5E35B1)
        TransactionCategory.ENTERTAINMENT -> Color(0xFFC2185B)
        TransactionCategory.TRANSFERS -> BarclaysCyan
        TransactionCategory.HEALTH -> Color(0xFF00897B)
        TransactionCategory.TRAVEL -> Color(0xFF0097A7)
        TransactionCategory.OTHER -> Color(0xFF78909C)
    }
}
