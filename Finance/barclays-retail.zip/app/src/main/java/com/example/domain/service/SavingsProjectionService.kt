package com.example.domain.service

import kotlin.math.pow
import kotlin.math.roundToLong

data class SavingsProjectionYear(
    val year: Int,
    val totalSaved: Long,       // in pence
    val totalContributed: Long, // in pence
    val interestEarned: Long    // in pence
)

data class SavingsProjectionResult(
    val finalBalance: Long,
    val totalPrincipalContributed: Long,
    val totalInterestEarned: Long,
    val yearlyBreakdown: List<SavingsProjectionYear>
)

object SavingsProjectionService {

    /**
     * Models compound savings with monthly compounding and regular monthly contributions.
     * @param initialBalancePence Starting balance in minor units (pence)
     * @param monthlyContributionPence Monthly contribution in minor units
     * @param annualInterestRatePercent Annual interest rate, e.g. 4.5 for 4.5% APY
     * @param years Number of years to project
     */
    fun calculateProjection(
        initialBalancePence: Long,
        monthlyContributionPence: Long,
        annualInterestRatePercent: Double,
        years: Int
    ): SavingsProjectionResult {
        val safeYears = years.coerceIn(1, 40)
        val monthlyRate = (annualInterestRatePercent / 100.0) / 12.0

        var currentBalance = initialBalancePence.toDouble()
        var totalContributed = initialBalancePence

        val yearlyBreakdown = mutableListOf<SavingsProjectionYear>()

        for (year in 1..safeYears) {
            for (month in 1..12) {
                // Add monthly interest
                currentBalance *= (1.0 + monthlyRate)
                // Add monthly contribution
                currentBalance += monthlyContributionPence.toDouble()
                totalContributed += monthlyContributionPence
            }
            val balancePence = currentBalance.roundToLong()
            val interestSoFar = (balancePence - totalContributed).coerceAtLeast(0L)
            yearlyBreakdown.add(
                SavingsProjectionYear(
                    year = year,
                    totalSaved = balancePence,
                    totalContributed = totalContributed,
                    interestEarned = interestSoFar
                )
            )
        }

        val finalBalancePence = currentBalance.roundToLong()
        val totalInterestPence = (finalBalancePence - totalContributed).coerceAtLeast(0L)

        return SavingsProjectionResult(
            finalBalance = finalBalancePence,
            totalPrincipalContributed = totalContributed,
            totalInterestEarned = totalInterestPence,
            yearlyBreakdown = yearlyBreakdown
        )
    }
}
