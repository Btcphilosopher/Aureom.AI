package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Barclays Heritage & Modern UK Banking Palette
val BarclaysCyan = Color(0xFF00AEEF)
val BarclaysCyanDark = Color(0xFF008CC4)
val BarclaysCyanLight = Color(0xFF68D3FF)
val BarclaysCyanMuted = Color(0xFFE0F4FC)

val BarclaysNavyDark = Color(0xFF00182E)
val BarclaysNavyDeep = Color(0xFF00263E)
val BarclaysNavyMedium = Color(0xFF00395D)
val BarclaysNavySoft = Color(0xFF0A4D7B)

val BarclaysIceSurface = Color(0xFFF2F6F9)
val BarclaysWhite = Color(0xFFFFFFFF)
val BarclaysCardBorder = Color(0xFFDCE7F0)

val BarclaysTextPrimary = Color(0xFF00182E)
val BarclaysTextSecondary = Color(0xFF55697D)
val BarclaysTextMuted = Color(0xFF8899A6)

// Financial Indicators
val FinancialGreen = Color(0xFF009F87)
val FinancialGreenSurface = Color(0xFFE5F7F3)
val FinancialRed = Color(0xFFD9383A)
val FinancialRedSurface = Color(0xFFFCEAEA)
val FinancialAmber = Color(0xFFE58700)
val FinancialAmberSurface = Color(0xFFFEF4E6)

// Dark Theme Variants
val DarkBackground = Color(0xFF05121F)
val DarkSurface = Color(0xFF0A1C2E)
val DarkSurfaceVariant = Color(0xFF102842)
val DarkTextPrimary = Color(0xFFF0F6FA)
val DarkTextSecondary = Color(0xFFA1B4C7)
val DarkCardBorder = Color(0xFF1B3654)
