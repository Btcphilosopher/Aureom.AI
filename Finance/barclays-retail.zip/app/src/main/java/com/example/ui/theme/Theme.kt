package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = BarclaysNavyDeep,
    onPrimary = BarclaysWhite,
    primaryContainer = BarclaysCyanMuted,
    onPrimaryContainer = BarclaysNavyDark,
    secondary = BarclaysCyan,
    onSecondary = BarclaysNavyDark,
    secondaryContainer = BarclaysCyanMuted,
    onSecondaryContainer = BarclaysNavyDark,
    tertiary = FinancialGreen,
    onTertiary = BarclaysWhite,
    background = BarclaysIceSurface,
    onBackground = BarclaysTextPrimary,
    surface = BarclaysWhite,
    onSurface = BarclaysTextPrimary,
    surfaceVariant = BarclaysIceSurface,
    onSurfaceVariant = BarclaysTextSecondary,
    outline = BarclaysCardBorder,
    error = FinancialRed,
    onError = BarclaysWhite
)

private val DarkColorScheme = darkColorScheme(
    primary = BarclaysCyan,
    onPrimary = BarclaysNavyDark,
    primaryContainer = BarclaysNavyMedium,
    onPrimaryContainer = BarclaysCyanLight,
    secondary = BarclaysCyanLight,
    onSecondary = BarclaysNavyDark,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = BarclaysCyanLight,
    tertiary = FinancialGreen,
    onTertiary = BarclaysWhite,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkCardBorder,
    error = FinancialRed,
    onError = BarclaysWhite
)

@Composable
fun BarclaysTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = if (darkTheme) DarkBackground.toArgb() else BarclaysNavyDark.toArgb()
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
