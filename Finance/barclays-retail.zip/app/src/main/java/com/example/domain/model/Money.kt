package com.example.domain.model

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

/**
 * Domain utility for monetary arithmetic and formatting in UK Pounds Sterling (GBP).
 * All monetary amounts are authoritative integer minor units (pence / cents) to prevent
 * floating-point inaccuracy.
 */
object Money {
    /**
     * Formats minor units (pence) to GBP currency string (e.g. 125050L -> "£1,250.50")
     */
    fun formatPence(
        amountInPence: Long,
        includeSign: Boolean = false,
        hideDecimalsIfZero: Boolean = false
    ): String {
        val isNegative = amountInPence < 0
        val positivePence = abs(amountInPence)
        val pounds = positivePence / 100
        val pence = positivePence % 100

        val format = NumberFormat.getNumberInstance(Locale.UK)
        format.minimumFractionDigits = if (hideDecimalsIfZero && pence == 0L) 0 else 2
        format.maximumFractionDigits = 2

        val formattedNumber = format.format(pounds + (pence / 100.0))

        val signPrefix = when {
            isNegative -> "-£"
            includeSign && amountInPence > 0 -> "+£"
            else -> "£"
        }

        return "$signPrefix$formattedNumber"
    }

    /**
     * Parses a string representation such as "45.50", "45", or "£45.50" into pence (Long).
     * Returns null if the input is not a valid non-negative decimal amount.
     */
    fun parseToPence(input: String): Long? {
        val clean = input.trim().removePrefix("£").replace(",", "").trim()
        if (clean.isEmpty()) return null
        val parts = clean.split(".")
        return when (parts.size) {
            1 -> {
                val pounds = parts[0].toLongOrNull() ?: return null
                if (pounds < 0) return null
                pounds * 100
            }
            2 -> {
                val pounds = parts[0].ifEmpty { "0" }.toLongOrNull() ?: return null
                if (pounds < 0) return null
                val penceStr = parts[1].padEnd(2, '0').take(2)
                val pence = penceStr.toLongOrNull() ?: return null
                (pounds * 100) + pence
            }
            else -> null
        }
    }

    /**
     * Safe subtraction to verify if balance has sufficient funds.
     */
    fun hasSufficientFunds(availableBalance: Long, paymentAmount: Long, overdraftBuffer: Long = 0L): Boolean {
        return (availableBalance + overdraftBuffer) >= paymentAmount
    }
}
