package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Account
import com.example.domain.model.AccountType
import com.example.domain.model.Money
import com.example.ui.theme.BarclaysCyan
import com.example.ui.theme.BarclaysNavyDark
import com.example.ui.theme.BarclaysNavyDeep
import com.example.ui.theme.BarclaysWhite
import com.example.ui.theme.FinancialAmber
import com.example.ui.theme.FinancialGreen

@Composable
fun AccountCarouselCard(
    account: Account,
    isPrivacyMasked: Boolean,
    onSelectAccount: (Account) -> Unit,
    modifier: Modifier = Modifier
) {
    val isPrimary = account.isPrimary

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isPrimary) BarclaysNavyDeep else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .width(280.dp)
            .height(180.dp)
            .clip(RoundedCornerShape(18.dp))
            .border(
                width = 1.dp,
                color = if (isPrimary) BarclaysCyan.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outline,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable { onSelectAccount(account) }
            .testTag("account_card_${account.id}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Top Row: Account Type Badge & Icon
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = account.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isPrimary) BarclaysWhite else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${account.sortCode} • ${account.accountNumber} (Demo)",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isPrimary) BarclaysCyan.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                if (isPrimary) BarclaysCyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (account.accountType) {
                                AccountType.SAVINGS -> Icons.Default.Savings
                                AccountType.POT -> Icons.Default.Shield
                                else -> Icons.Default.AccountBalance
                            },
                            contentDescription = account.accountType.displayName,
                            tint = if (isPrimary) BarclaysCyan else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Middle: Available Balance
                Column {
                    Text(
                        text = "Available Balance",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isPrimary) BarclaysWhite.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (isPrivacyMasked) "£ ••••••" else Money.formatPence(account.availableBalance),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isPrimary) BarclaysWhite else MaterialTheme.colorScheme.onSurface,
                        letterSpacing = (-0.5).sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Footer: Booked vs Pending or APY
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (account.interestRateApy != null) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = FinancialGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${account.interestRateApy}% AER / Variable",
                                color = FinancialGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    } else if (account.totalPendingCommitments > 0) {
                        Text(
                            text = "Pending: ${if (isPrivacyMasked) "£•••" else Money.formatPence(account.totalPendingCommitments)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = FinancialAmber
                        )
                    } else {
                        Text(
                            text = "Booked: ${if (isPrivacyMasked) "£•••" else Money.formatPence(account.bookedBalance)}",
                            fontSize = 11.sp,
                            color = if (isPrimary) BarclaysWhite.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Details",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isPrimary) BarclaysCyan else MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = if (isPrimary) BarclaysCyan else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}
