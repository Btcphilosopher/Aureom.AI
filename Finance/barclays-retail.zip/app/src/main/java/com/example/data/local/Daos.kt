package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY isPrimary DESC, name ASC")
    fun getAllAccounts(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1")
    suspend fun getAccountById(id: String): AccountEntity?

    @Query("UPDATE accounts SET availableBalance = :available, bookedBalance = :booked, pendingBalance = :pending WHERE id = :id")
    suspend fun updateBalances(id: String, available: Long, booked: Long, pending: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccounts(accounts: List<AccountEntity>)

    @Query("DELETE FROM accounts")
    suspend fun clearAll()
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId ORDER BY timestamp DESC")
    fun getTransactionsForAccount(accountId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getTransactionById(id: String): TransactionEntity?

    @Query("SELECT * FROM transactions WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getByIdempotencyKey(key: String): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<TransactionEntity>)

    @Query("UPDATE transactions SET category = :category WHERE id = :id")
    suspend fun updateCategory(id: String, category: String)

    @Query("UPDATE transactions SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Query("DELETE FROM transactions")
    suspend fun clearAll()
}

@Dao
interface PayeeDao {
    @Query("SELECT * FROM payees ORDER BY name ASC")
    fun getAllPayees(): Flow<List<PayeeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayee(payee: PayeeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayees(payees: List<PayeeEntity>)

    @Query("DELETE FROM payees WHERE id = :id")
    suspend fun deletePayee(id: String)

    @Query("DELETE FROM payees")
    suspend fun clearAll()
}

@Dao
interface CardDao {
    @Query("SELECT * FROM cards ORDER BY id ASC")
    fun getAllCards(): Flow<List<CardEntity>>

    @Query("SELECT * FROM cards WHERE id = :id LIMIT 1")
    suspend fun getCardById(id: String): CardEntity?

    @Query("UPDATE cards SET isFrozen = :isFrozen WHERE id = :id")
    suspend fun updateFreeze(id: String, isFrozen: Boolean)

    @Query("UPDATE cards SET contactlessEnabled = :contactless, onlinePaymentsEnabled = :online, atmWithdrawalsEnabled = :atm, monthlySpendingLimit = :limit WHERE id = :id")
    suspend fun updateSettings(id: String, contactless: Boolean, online: Boolean, atm: Boolean, limit: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCards(cards: List<CardEntity>)

    @Query("DELETE FROM cards")
    suspend fun clearAll()
}

@Dao
interface SavingsGoalDao {
    @Query("SELECT * FROM savings_goals ORDER BY targetDateMillis ASC")
    fun getAllGoals(): Flow<List<SavingsGoalEntity>>

    @Query("SELECT * FROM savings_goals WHERE id = :id LIMIT 1")
    suspend fun getGoalById(id: String): SavingsGoalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: SavingsGoalEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoals(goals: List<SavingsGoalEntity>)

    @Query("UPDATE savings_goals SET currentAmount = :amount WHERE id = :id")
    suspend fun updateGoalAmount(id: String, amount: Long)

    @Query("DELETE FROM savings_goals WHERE id = :id")
    suspend fun deleteGoal(id: String)

    @Query("DELETE FROM savings_goals")
    suspend fun clearAll()
}

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budgets ORDER BY spentThisMonth DESC")
    fun getAllBudgets(): Flow<List<BudgetEntity>>

    @Query("UPDATE budgets SET monthlyLimit = :limit, spentThisMonth = :spent WHERE id = :id")
    suspend fun updateBudget(id: String, limit: Long, spent: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBudgets(budgets: List<BudgetEntity>)

    @Query("DELETE FROM budgets")
    suspend fun clearAll()
}

@Dao
interface ScheduledPaymentDao {
    @Query("SELECT * FROM scheduled_payments ORDER BY nextPaymentDateMillis ASC")
    fun getAllScheduled(): Flow<List<ScheduledPaymentEntity>>

    @Query("UPDATE scheduled_payments SET isActive = :isActive WHERE id = :id")
    suspend fun updateActive(id: String, isActive: Boolean)

    @Query("DELETE FROM scheduled_payments WHERE id = :id")
    suspend fun deleteScheduled(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScheduled(items: List<ScheduledPaymentEntity>)

    @Query("DELETE FROM scheduled_payments")
    suspend fun clearAll()
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationEntity>)

    @Query("DELETE FROM notifications")
    suspend fun clearAll()
}
