package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Atm
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Contactless
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.CreditCardOff
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.model.Card
import com.example.domain.model.Money
import com.example.domain.model.TransactionType
import com.example.ui.BarclaysViewModel
import com.example.ui.components.TransactionRow
import com.example.ui.theme.BarclaysCyan
import com.example.ui.theme.BarclaysNavyDark
import com.example.ui.theme.BarclaysNavyDeep
import com.example.ui.theme.BarclaysWhite
import com.example.ui.theme.FinancialAmber
import com.example.ui.theme.FinancialGreen
import com.example.ui.theme.FinancialRed

@Composable
fun CardsScreen(
    viewModel: BarclaysViewModel,
    modifier: Modifier = Modifier
) {
    val cards by viewModel.cards.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val isPrivacyMasked by viewModel.privacyHideBalances.collectAsStateWithLifecycle()

    var selectedCardIndex by remember { mutableIntStateOf(0) }
    val activeCard: Card? = cards.getOrNull(selectedCardIndex) ?: cards.firstOrNull()

    var showFreezeConfirmationDialog by remember { mutableStateOf(false) }
    var showReplacementDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "CARD MANAGEMENT & CONTROLS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
        }

        // Card Switcher (if multiple cards e.g. Debit and Barclaycard Credit)
        if (cards.size > 1) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    cards.forEachIndexed { index, card ->
                        val isSelected = index == selectedCardIndex
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) BarclaysNavyDeep else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) BarclaysCyan else MaterialTheme.colorScheme.outline
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedCardIndex = index }
                                .padding(vertical = 2.dp)
                        ) {
                            Text(
                                text = card.cardType.displayName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) BarclaysWhite else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }

        // Realistic Barclays Card Artwork
        activeCard?.let { card ->
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .testTag("card_artwork_view")
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Image(
                            painter = painterResource(id = R.drawable.barclays_debit_card_1792490647433),
                            contentDescription = "Barclays Card Artwork",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Frozen state overlay if frozen
                        if (card.isFrozen) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(BarclaysNavyDark.copy(alpha = 0.85f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Frozen",
                                        tint = BarclaysCyan,
                                        modifier = Modifier.size(42.dp)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "CARD TEMPORARILY FROZEN",
                                        color = BarclaysWhite,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = "All ATM and card purchases are locked",
                                        color = BarclaysWhite.copy(alpha = 0.75f),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        // Subtle overlay chip status
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (card.isFrozen) FinancialAmber.copy(alpha = 0.9f) else FinancialGreen.copy(alpha = 0.9f)
                            ) {
                                Text(
                                    text = if (card.isFrozen) "LOCKED" else "ACTIVE",
                                    color = BarclaysWhite,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Primary Freeze / Unfreeze Action
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(if (card.isFrozen) FinancialAmber.copy(alpha = 0.15f) else BarclaysCyan.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (card.isFrozen) Icons.Default.LockOpen else Icons.Default.AcUnit,
                                    contentDescription = null,
                                    tint = if (card.isFrozen) FinancialAmber else BarclaysNavyDeep,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (card.isFrozen) "Unfreeze Card" else "Freeze Card Instantly",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (card.isFrozen) "Unlock your card to resume spending" else "Temporarily stop transactions if misplaced",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Switch(
                            checked = card.isFrozen,
                            onCheckedChange = { showFreezeConfirmationDialog = true },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = FinancialAmber,
                                checkedTrackColor = BarclaysNavyDeep
                            ),
                            modifier = Modifier.testTag("toggle_card_freeze")
                        )
                    }
                }
            }

            // Monthly Card Spending Limit
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Monthly Spending Limit", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                text = Money.formatPence(card.monthlySpendingLimit),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = BarclaysNavyDark
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        val progress = (card.currentSpentThisMonth.toFloat() / card.monthlySpendingLimit.toFloat()).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = BarclaysCyan,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Spent so far: ${Money.formatPence(card.currentSpentThisMonth)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${"%.0f".format(progress * 100)}% used",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = FinancialGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Limit slider
                        Slider(
                            value = (card.monthlySpendingLimit / 100).toFloat(),
                            onValueChange = {
                                viewModel.updateCardControls(
                                    card.id,
                                    card.contactlessEnabled,
                                    card.onlinePaymentsEnabled,
                                    card.atmWithdrawalsEnabled,
                                    it.toLong() * 100
                                )
                            },
                            valueRange = 500f..5000f,
                            steps = 45,
                            colors = SliderDefaults.colors(thumbColor = BarclaysCyan, activeTrackColor = BarclaysNavyDeep),
                            modifier = Modifier.testTag("slider_card_spending_limit")
                        )
                    }
                }
            }

            // Security Controls (Contactless, Online, ATM)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Security & Usage Controls", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Contactless
                        ControlToggleRow(
                            icon = Icons.Default.Contactless,
                            title = "Contactless Payments",
                            subtitle = "Tap and pay at terminals (up to £100 per tap)",
                            checked = card.contactlessEnabled,
                            onToggle = {
                                viewModel.updateCardControls(card.id, it, card.onlinePaymentsEnabled, card.atmWithdrawalsEnabled, card.monthlySpendingLimit)
                            }
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        // Online Payments
                        ControlToggleRow(
                            icon = Icons.Default.Language,
                            title = "Online & In-App Purchases",
                            subtitle = "E-commerce and card-on-file subscriptions",
                            checked = card.onlinePaymentsEnabled,
                            onToggle = {
                                viewModel.updateCardControls(card.id, card.contactlessEnabled, it, card.atmWithdrawalsEnabled, card.monthlySpendingLimit)
                            }
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        // ATM Cash
                        ControlToggleRow(
                            icon = Icons.Default.Atm,
                            title = "ATM Cash Withdrawals",
                            subtitle = "Withdraw currency at domestic and overseas ATMs",
                            checked = card.atmWithdrawalsEnabled,
                            onToggle = {
                                viewModel.updateCardControls(card.id, card.contactlessEnabled, card.onlinePaymentsEnabled, it, card.monthlySpendingLimit)
                            }
                        )
                    }
                }
            }

            // Lost & Stolen Guidance Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.ReportProblem, contentDescription = null, tint = FinancialAmber)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Lost or Stolen Card?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "If your card is permanently lost, stolen, or compromised, cancel it immediately to protect your funds. A new replacement card will arrive in 2-3 business days.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { showReplacementDialog = true },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("button_order_replacement_card")
                        ) {
                            Text("Report Lost & Order Replacement", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // Recent Card Transactions
            item {
                Text(
                    text = "RECENT CARD PURCHASES",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            }

            val cardTx = transactions.filter { it.type == TransactionType.CARD_PURCHASE }.take(4)
            items(cardTx) { tx ->
                TransactionRow(
                    transaction = tx,
                    isPrivacyMasked = isPrivacyMasked,
                    onClick = { /* Detail */ }
                )
            }
        }
    }

    // Freeze Confirmation Dialog
    if (showFreezeConfirmationDialog && activeCard != null) {
        val willFreeze = !activeCard.isFrozen
        AlertDialog(
            onDismissRequest = { showFreezeConfirmationDialog = false },
            title = {
                Text(if (willFreeze) "Freeze Card?" else "Unfreeze Card?", fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    if (willFreeze)
                        "Freezing your card instantly blocks in-person purchases, online payments, and ATM withdrawals. You can unfreeze it at any time."
                    else
                        "Unfreezing will restore immediate spending permissions across all authorized channels."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.toggleCardFreeze(activeCard.id, willFreeze)
                        showFreezeConfirmationDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (willFreeze) FinancialAmber else BarclaysNavyDeep
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_freeze_button")
                ) {
                    Text(if (willFreeze) "Freeze Card" else "Unfreeze Now", color = BarclaysWhite)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showFreezeConfirmationDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Replacement Card Dialog
    if (showReplacementDialog) {
        AlertDialog(
            onDismissRequest = { showReplacementDialog = false },
            title = { Text("Replacement Card Ordered", fontWeight = FontWeight.Bold) },
            text = {
                Text("In this simulation, card ${activeCard?.maskedNumber} has been permanently cancelled and a new contactless Premier Debit card dispatched to your registered UK address.")
            },
            confirmButton = {
                Button(
                    onClick = { showReplacementDialog = false },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BarclaysNavyDeep)
                ) {
                    Text("Understood", color = BarclaysWhite)
                }
            }
        )
    }
}

@Composable
private fun ControlToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(BarclaysCyan.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = BarclaysNavyDeep, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(checkedThumbColor = BarclaysCyan, checkedTrackColor = BarclaysNavyDeep)
        )
    }
}
