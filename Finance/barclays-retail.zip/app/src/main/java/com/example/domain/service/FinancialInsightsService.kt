package com.example.domain.service

import com.example.domain.model.Money
import com.example.domain.model.Transaction
import com.example.domain.model.TransactionCategory
import com.example.domain.model.TransactionStatus
import java.util.Calendar
import kotlin.math.abs

data class CategorySpending(
    val category: TransactionCategory,
    val totalPence: Long,
    val transactionCount: Int,
    val percentageOfTotal: Float
)

data class MonthSpendingSummary(
    val currentMonthTotalPence: Long,
    val previousMonthTotalPence: Long,
    val deltaPence: Long,
    val percentageChange: Float,
    val totalIncomePence: Long,
    val totalOutgoingsPence: Long,
    val categoryBreakdown: List<CategorySpending>,
    val insights: List<ExplainableInsight>
)

data class ExplainableInsight(
    val id: String,
    val title: String,
    val description: String,
    val calculationDetails: String,
    val type: InsightType
)

enum class InsightType {
    SPENDING_ALERT,
    SAVING_OPPORTUNITY,
    SUBSCRIPTION_CHECK,
    POSITIVE_TREND
}

object FinancialInsightsService {

    /**
     * Analyses transactions to extract explainable, mathematically sound financial insights.
     */
    fun analyzeSpending(transactions: List<Transaction>): MonthSpendingSummary {
        val now = System.currentTimeMillis()
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = now

        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)

        calendar.add(Calendar.MONTH, -1)
        val prevMonth = calendar.get(Calendar.MONTH)
        val prevYear = calendar.get(Calendar.YEAR)

        var currentMonthSpend = 0L
        var prevMonthSpend = 0L
        var currentMonthIncome = 0L

        val categoryTotals = mutableMapOf<TransactionCategory, Long>()
        val categoryCounts = mutableMapOf<TransactionCategory, Int>()

        for (tx in transactions) {
            if (tx.status == TransactionStatus.REVERSED) continue

            calendar.timeInMillis = tx.timestamp
            val txMonth = calendar.get(Calendar.MONTH)
            val txYear = calendar.get(Calendar.YEAR)

            if (txYear == currentYear && txMonth == currentMonth) {
                if (tx.amount < 0) {
                    val spent = abs(tx.amount)
                    currentMonthSpend += spent
                    categoryTotals[tx.category] = (categoryTotals[tx.category] ?: 0L) + spent
                    categoryCounts[tx.category] = (categoryCounts[tx.category] ?: 0) + 1
                } else {
                    currentMonthIncome += tx.amount
                }
            } else if (txYear == prevYear && txMonth == prevMonth) {
                if (tx.amount < 0) {
                    prevMonthSpend += abs(tx.amount)
                }
            }
        }

        val deltaPence = currentMonthSpend - prevMonthSpend
        val percentageChange = if (prevMonthSpend > 0) {
            ((deltaPence.toFloat() / prevMonthSpend.toFloat()) * 100f)
        } else {
            0f
        }

        val breakdown = categoryTotals.entries.map { (cat, total) ->
            val pct = if (currentMonthSpend > 0) (total.toFloat() / currentMonthSpend.toFloat()) * 100f else 0f
            CategorySpending(
                category = cat,
                totalPence = total,
                transactionCount = categoryCounts[cat] ?: 0,
                percentageOfTotal = pct
            )
        }.sortedByDescending { it.totalPence }

        // Generate explainable insights
        val insights = mutableListOf<ExplainableInsight>()

        // 1. Month-over-month insight
        if (deltaPence > 0) {
            insights.add(
                ExplainableInsight(
                    id = "spend_delta",
                    title = "Monthly Outgoings Increased",
                    description = "You have spent ${Money.formatPence(deltaPence)} more this month than the same period last month.",
                    calculationDetails = "Current month (${Money.formatPence(currentMonthSpend)}) minus previous month (${Money.formatPence(prevMonthSpend)}) = +${Money.formatPence(deltaPence)} (+${"%.1f".format(percentageChange)}%).",
                    type = InsightType.SPENDING_ALERT
                )
            )
        } else if (deltaPence < 0) {
            insights.add(
                ExplainableInsight(
                    id = "spend_delta_saved",
                    title = "Spending Under Control",
                    description = "Great job! You spent ${Money.formatPence(abs(deltaPence))} less than last month.",
                    calculationDetails = "Current month (${Money.formatPence(currentMonthSpend)}) vs previous month (${Money.formatPence(prevMonthSpend)}) = -${Money.formatPence(abs(deltaPence))} (${"%.1f".format(abs(percentageChange))}% decrease).",
                    type = InsightType.POSITIVE_TREND
                )
            )
        }

        // 2. Top spending category
        breakdown.firstOrNull()?.let { top ->
            insights.add(
                ExplainableInsight(
                    id = "top_category",
                    title = "Top Category: ${top.category.displayName}",
                    description = "${top.category.displayName} represents ${"%.1f".format(top.percentageOfTotal)}% of your outgoings (${Money.formatPence(top.totalPence)} across ${top.transactionCount} transactions).",
                    calculationDetails = "Aggregated from ${top.transactionCount} verified ledger debits this calendar month.",
                    type = InsightType.SAVING_OPPORTUNITY
                )
            )
        }

        // 3. Subscriptions / recurring
        val recurringCount = transactions.count { it.type == com.example.domain.model.TransactionType.DIRECT_DEBIT || it.merchantOrPayee.contains("Spotify", true) || it.merchantOrPayee.contains("Netflix", true) || it.merchantOrPayee.contains("Gym", true) }
        insights.add(
            ExplainableInsight(
                id = "subscriptions",
                title = "Subscription & Bill Health",
                description = "You have $recurringCount recurring commitments active this month. All scheduled payments were honoured.",
                calculationDetails = "Derived from monthly Direct Debits and recurring card subscriptions.",
                type = InsightType.SUBSCRIPTION_CHECK
            )
        )

        return MonthSpendingSummary(
            currentMonthTotalPence = currentMonthSpend,
            previousMonthTotalPence = prevMonthSpend,
            deltaPence = deltaPence,
            percentageChange = percentageChange,
            totalIncomePence = currentMonthIncome,
            totalOutgoingsPence = currentMonthSpend,
            categoryBreakdown = breakdown,
            insights = insights
        )
    }

    /**
     * Rule-based automatic merchant categorisation.
     */
    fun categoriseMerchant(merchantName: String): TransactionCategory {
        val lower = merchantName.lowercase()
        return when {
            lower.contains("waitrose") || lower.contains("sainsbury") || lower.contains("tesco") || lower.contains("m&s food") || lower.contains("asda") || lower.contains("grocer") -> TransactionCategory.GROCERIES
            lower.contains("tfl") || lower.contains("transport for london") || lower.contains("uber") || lower.contains("trainline") || lower.contains("national rail") -> TransactionCategory.TRANSPORT
            lower.contains("rent") || lower.contains("mortgage") || lower.contains("council tax") || lower.contains("landlord") -> TransactionCategory.HOUSING
            lower.contains("british gas") || lower.contains("thames water") || lower.contains("octopus") || lower.contains("edf") || lower.contains("electric") -> TransactionCategory.BILLS
            lower.contains("dishoom") || lower.contains("restaurant") || lower.contains("cafe") || lower.contains("coffee") || lower.contains("nando") || lower.contains("pret") || lower.contains("starbucks") -> TransactionCategory.RESTAURANTS
            lower.contains("amazon") || lower.contains("apple") || lower.contains("zara") || lower.contains("john lewis") || lower.contains("boots") -> TransactionCategory.SHOPPING
            lower.contains("cinema") || lower.contains("theatre") || lower.contains("spotify") || lower.contains("netflix") || lower.contains("disney") -> TransactionCategory.ENTERTAINMENT
            lower.contains("gym") || lower.contains("fitness") || lower.contains("puregym") || lower.contains("pharmacy") -> TransactionCategory.HEALTH
            lower.contains("british airways") || lower.contains("easyjet") || lower.contains("hotel") || lower.contains("booking.com") || lower.contains("airbnb") -> TransactionCategory.TRAVEL
            lower.contains("salary") || lower.contains("payroll") || lower.contains("employer") || lower.contains("dividend") -> TransactionCategory.SALARY
            lower.contains("transfer") || lower.contains("savings") -> TransactionCategory.TRANSFERS
            else -> TransactionCategory.OTHER
        }
    }
}
