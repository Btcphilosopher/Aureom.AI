package com.example.data.local

import com.example.domain.model.Account
import com.example.domain.model.Budget
import com.example.domain.model.Card
import com.example.domain.model.NotificationCategory
import com.example.domain.model.NotificationItem
import com.example.domain.model.Payee
import com.example.domain.model.SavingsGoal
import com.example.domain.model.ScheduledPayment
import com.example.domain.model.Transaction
import com.example.domain.model.TransactionCategory
import com.example.domain.model.TransactionStatus
import com.example.domain.model.TransactionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class PaymentResult {
    data class Success(val transactionId: String, val reference: String, val timestamp: Long) : PaymentResult()
    data class Failure(val reason: String) : PaymentResult()
}

class BarclaysRepository(private val database: BarclaysDatabase) {

    private val accountDao = database.accountDao()
    private val transactionDao = database.transactionDao()
    private val payeeDao = database.payeeDao()
    private val cardDao = database.cardDao()
    private val savingsGoalDao = database.savingsGoalDao()
    private val budgetDao = database.budgetDao()
    private val scheduledPaymentDao = database.scheduledPaymentDao()
    private val notificationDao = database.notificationDao()

    val accounts: Flow<List<Account>> = accountDao.getAllAccounts().map { list -> list.map { it.toDomain() } }
    val transactions: Flow<List<Transaction>> = transactionDao.getAllTransactions().map { list -> list.map { it.toDomain() } }
    val payees: Flow<List<Payee>> = payeeDao.getAllPayees().map { list -> list.map { it.toDomain() } }
    val cards: Flow<List<Card>> = cardDao.getAllCards().map { list -> list.map { it.toDomain() } }
    val savingsGoals: Flow<List<SavingsGoal>> = savingsGoalDao.getAllGoals().map { list -> list.map { it.toDomain() } }
    val budgets: Flow<List<Budget>> = budgetDao.getAllBudgets().map { list -> list.map { it.toDomain() } }
    val scheduledPayments: Flow<List<ScheduledPayment>> = scheduledPaymentDao.getAllScheduled().map { list -> list.map { it.toDomain() } }
    val notifications: Flow<List<NotificationItem>> = notificationDao.getAllNotifications().map { list -> list.map { it.toDomain() } }

    fun getTransactionsForAccount(accountId: String): Flow<List<Transaction>> {
        return transactionDao.getTransactionsForAccount(accountId).map { list -> list.map { it.toDomain() } }
    }

    /**
     * Executes atomic Faster Payment transfer to payee with idempotency.
     */
    suspend fun executePayment(
        sourceAccountId: String,
        payeeName: String,
        sortCode: String,
        accountNumber: String,
        amountPence: Long,
        reference: String,
        idempotencyKey: String = UUID.randomUUID().toString()
    ): PaymentResult = withContext(Dispatchers.IO) {
        val existing = transactionDao.getByIdempotencyKey(idempotencyKey)
        if (existing != null) {
            return@withContext PaymentResult.Success(existing.id, existing.reference, existing.timestamp)
        }

        val account = accountDao.getAccountById(sourceAccountId)
            ?: return@withContext PaymentResult.Failure("Source account not found.")

        if (account.availableBalance + account.overdraftLimit < amountPence) {
            return@withContext PaymentResult.Failure("Insufficient funds in account.")
        }

        val now = System.currentTimeMillis()
        val txId = "tx_" + UUID.randomUUID().toString().take(12)
        val formalRef = if (reference.isNotBlank()) reference else "BKL-${UUID.randomUUID().toString().take(8).uppercase()}"

        // Atomic update of balances
        val newAvailable = account.availableBalance - amountPence
        val newBooked = account.bookedBalance - amountPence
        accountDao.updateBalances(account.id, newAvailable, newBooked, account.pendingBalance)

        // Write ledger entry
        val transaction = TransactionEntity(
            id = txId,
            accountId = sourceAccountId,
            merchantOrPayee = payeeName,
            amount = -amountPence,
            timestamp = now,
            category = TransactionCategory.TRANSFERS.name,
            status = TransactionStatus.COMPLETED.name,
            reference = formalRef,
            type = TransactionType.FASTER_PAYMENT.name,
            reversalOfTransactionId = null,
            idempotencyKey = idempotencyKey,
            location = "Barclays Faster Payments Gateway"
        )
        transactionDao.insertTransaction(transaction)

        // Upsert payee
        val initials = payeeName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString("").uppercase().ifEmpty { "BP" }
        payeeDao.insertPayee(
            PayeeEntity(
                id = "payee_${sortCode}_$accountNumber",
                name = payeeName,
                sortCode = sortCode,
                accountNumber = accountNumber,
                bankName = "UK Financial Institution",
                avatarInitials = initials,
                lastPaymentDate = now,
                reference = formalRef
            )
        )

        // Push notification
        notificationDao.insertNotification(
            NotificationEntity(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                title = "Payment Sent",
                message = "£${"%.2f".format(amountPence / 100.0)} sent to $payeeName. Ref: $formalRef",
                timestamp = now,
                category = NotificationCategory.PAYMENT.name,
                isRead = false
            )
        )

        PaymentResult.Success(txId, formalRef, now)
    }

    /**
     * Executes atomic transfer between two own accounts.
     */
    suspend fun transferBetweenAccounts(
        sourceAccountId: String,
        destinationAccountId: String,
        amountPence: Long,
        reference: String
    ): PaymentResult = withContext(Dispatchers.IO) {
        if (sourceAccountId == destinationAccountId) {
            return@withContext PaymentResult.Failure("Source and destination accounts must be different.")
        }
        val source = accountDao.getAccountById(sourceAccountId)
            ?: return@withContext PaymentResult.Failure("Source account not found.")
        val destination = accountDao.getAccountById(destinationAccountId)
            ?: return@withContext PaymentResult.Failure("Destination account not found.")

        if (source.availableBalance + source.overdraftLimit < amountPence) {
            return@withContext PaymentResult.Failure("Insufficient funds in ${source.name}.")
        }

        val now = System.currentTimeMillis()
        val debitTxId = "tx_deb_" + UUID.randomUUID().toString().take(10)
        val creditTxId = "tx_crd_" + UUID.randomUUID().toString().take(10)
        val formalRef = if (reference.isNotBlank()) reference else "INT-TRF-${UUID.randomUUID().toString().take(6).uppercase()}"

        // Update source
        accountDao.updateBalances(
            source.id,
            source.availableBalance - amountPence,
            source.bookedBalance - amountPence,
            source.pendingBalance
        )

        // Update destination
        accountDao.updateBalances(
            destination.id,
            destination.availableBalance + amountPence,
            destination.bookedBalance + amountPence,
            destination.pendingBalance
        )

        // Ledger entries
        transactionDao.insertTransaction(
            TransactionEntity(
                id = debitTxId,
                accountId = source.id,
                merchantOrPayee = "Transfer to ${destination.name}",
                amount = -amountPence,
                timestamp = now,
                category = TransactionCategory.TRANSFERS.name,
                status = TransactionStatus.COMPLETED.name,
                reference = formalRef,
                type = TransactionType.INTERNAL_TRANSFER.name,
                reversalOfTransactionId = null,
                idempotencyKey = UUID.randomUUID().toString(),
                location = "Online Banking Transfer"
            )
        )

        transactionDao.insertTransaction(
            TransactionEntity(
                id = creditTxId,
                accountId = destination.id,
                merchantOrPayee = "Transfer from ${source.name}",
                amount = amountPence,
                timestamp = now,
                category = TransactionCategory.TRANSFERS.name,
                status = TransactionStatus.COMPLETED.name,
                reference = formalRef,
                type = TransactionType.INTERNAL_TRANSFER.name,
                reversalOfTransactionId = null,
                idempotencyKey = UUID.randomUUID().toString(),
                location = "Online Banking Transfer"
            )
        )

        notificationDao.insertNotification(
            NotificationEntity(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                title = "Internal Transfer Completed",
                message = "Moved £${"%.2f".format(amountPence / 100.0)} from ${source.name} to ${destination.name}.",
                timestamp = now,
                category = NotificationCategory.PAYMENT.name,
                isRead = false
            )
        )

        PaymentResult.Success(debitTxId, formalRef, now)
    }

    /**
     * Performs a compliant transaction reversal with full traceability.
     */
    suspend fun reverseTransaction(transactionId: String): Boolean = withContext(Dispatchers.IO) {
        val original = transactionDao.getTransactionById(transactionId) ?: return@withContext false
        if (original.status == TransactionStatus.REVERSED.name) return@withContext false

        val account = accountDao.getAccountById(original.accountId) ?: return@withContext false

        val now = System.currentTimeMillis()
        val reversalTxId = "tx_rev_" + UUID.randomUUID().toString().take(10)
        val invertedAmount = -original.amount // if original was -5000, reversal is +5000

        // Mark original as reversed
        transactionDao.updateStatus(original.id, TransactionStatus.REVERSED.name)

        // Add reversal ledger entry
        transactionDao.insertTransaction(
            TransactionEntity(
                id = reversalTxId,
                accountId = account.id,
                merchantOrPayee = "Reversal: ${original.merchantOrPayee}",
                amount = invertedAmount,
                timestamp = now,
                category = original.category,
                status = TransactionStatus.COMPLETED.name,
                reference = "REV-${original.reference}",
                type = original.type,
                reversalOfTransactionId = original.id,
                idempotencyKey = UUID.randomUUID().toString(),
                location = "Banking Ledger Audit"
            )
        )

        // Adjust balances
        accountDao.updateBalances(
            account.id,
            account.availableBalance + invertedAmount,
            account.bookedBalance + invertedAmount,
            account.pendingBalance
        )

        notificationDao.insertNotification(
            NotificationEntity(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                title = "Transaction Reversed",
                message = "Reversal credited £${"%.2f".format(invertedAmount / 100.0)} for ${original.merchantOrPayee}.",
                timestamp = now,
                category = NotificationCategory.PAYMENT.name,
                isRead = false
            )
        )

        true
    }

    suspend fun setCardFreeze(cardId: String, isFrozen: Boolean) = withContext(Dispatchers.IO) {
        cardDao.updateFreeze(cardId, isFrozen)
        notificationDao.insertNotification(
            NotificationEntity(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                title = if (isFrozen) "Card Temporarily Frozen" else "Card Unfrozen",
                message = if (isFrozen) "Your card has been locked for all purchases and ATM use." else "Your card is active and ready for use.",
                timestamp = System.currentTimeMillis(),
                category = NotificationCategory.SECURITY.name,
                isRead = false
            )
        )
    }

    suspend fun updateCardControls(
        cardId: String,
        contactless: Boolean,
        online: Boolean,
        atm: Boolean,
        limitPence: Long
    ) = withContext(Dispatchers.IO) {
        cardDao.updateSettings(cardId, contactless, online, atm, limitPence)
    }

    suspend fun createSavingsGoal(
        accountId: String,
        title: String,
        targetAmountPence: Long,
        initialDepositPence: Long,
        monthsTarget: Int
    ): Boolean = withContext(Dispatchers.IO) {
        val account = accountDao.getAccountById(accountId) ?: return@withContext false
        if (initialDepositPence > 0 && account.availableBalance < initialDepositPence) {
            return@withContext false
        }

        val targetDate = System.currentTimeMillis() + (monthsTarget.toLong() * 30L * 24L * 3600L * 1000L)
        val goalId = "goal_" + UUID.randomUUID().toString().take(8)

        if (initialDepositPence > 0) {
            accountDao.updateBalances(
                account.id,
                account.availableBalance - initialDepositPence,
                account.bookedBalance - initialDepositPence,
                account.pendingBalance
            )
            transactionDao.insertTransaction(
                TransactionEntity(
                    id = "tx_goal_" + UUID.randomUUID().toString().take(8),
                    accountId = accountId,
                    merchantOrPayee = "Goal Deposit: $title",
                    amount = -initialDepositPence,
                    timestamp = System.currentTimeMillis(),
                    category = TransactionCategory.TRANSFERS.name,
                    status = TransactionStatus.COMPLETED.name,
                    reference = "GOAL-INIT",
                    type = TransactionType.INTERNAL_TRANSFER.name,
                    reversalOfTransactionId = null,
                    idempotencyKey = UUID.randomUUID().toString(),
                    location = "Savings Engine"
                )
            )
        }

        savingsGoalDao.insertGoal(
            SavingsGoalEntity(
                id = goalId,
                accountId = accountId,
                title = title,
                targetAmount = targetAmountPence,
                currentAmount = initialDepositPence,
                targetDateMillis = targetDate,
                autoSaveRule = "WEEKLY",
                iconName = "savings"
            )
        )
        true
    }

    suspend fun topUpGoal(goalId: String, sourceAccountId: String, amountPence: Long): Boolean = withContext(Dispatchers.IO) {
        val goal = savingsGoalDao.getGoalById(goalId) ?: return@withContext false
        val account = accountDao.getAccountById(sourceAccountId) ?: return@withContext false
        if (account.availableBalance < amountPence) return@withContext false

        accountDao.updateBalances(
            account.id,
            account.availableBalance - amountPence,
            account.bookedBalance - amountPence,
            account.pendingBalance
        )

        savingsGoalDao.updateGoalAmount(goalId, goal.currentAmount + amountPence)

        transactionDao.insertTransaction(
            TransactionEntity(
                id = "tx_topup_" + UUID.randomUUID().toString().take(8),
                accountId = sourceAccountId,
                merchantOrPayee = "Savings Goal: ${goal.title}",
                amount = -amountPence,
                timestamp = System.currentTimeMillis(),
                category = TransactionCategory.TRANSFERS.name,
                status = TransactionStatus.COMPLETED.name,
                reference = "GOAL-TOPUP",
                type = TransactionType.INTERNAL_TRANSFER.name,
                reversalOfTransactionId = null,
                idempotencyKey = UUID.randomUUID().toString(),
                location = "Savings Engine"
            )
        )
        true
    }

    suspend fun updateBudgetLimit(budgetId: String, newLimitPence: Long) = withContext(Dispatchers.IO) {
        val budgetsList = budgetDao.getAllBudgets().first()
        val existing = budgetsList.firstOrNull { it.id == budgetId } ?: return@withContext
        budgetDao.updateBudget(budgetId, newLimitPence, existing.spentThisMonth)
    }

    suspend fun updateTransactionCategory(txId: String, newCategory: TransactionCategory) = withContext(Dispatchers.IO) {
        transactionDao.updateCategory(txId, newCategory.name)
    }

    suspend fun markNotificationRead(notifId: String) = withContext(Dispatchers.IO) {
        notificationDao.markAsRead(notifId)
    }

    suspend fun markAllNotificationsRead() = withContext(Dispatchers.IO) {
        notificationDao.markAllAsRead()
    }

    suspend fun toggleScheduledPayment(paymentId: String, isActive: Boolean) = withContext(Dispatchers.IO) {
        scheduledPaymentDao.updateActive(paymentId, isActive)
    }

    /**
     * Seeds initial synthetic banking data or resets to initial demo state.
     */
    suspend fun resetDemoData() = withContext(Dispatchers.IO) {
        accountDao.clearAll()
        transactionDao.clearAll()
        payeeDao.clearAll()
        cardDao.clearAll()
        savingsGoalDao.clearAll()
        budgetDao.clearAll()
        scheduledPaymentDao.clearAll()
        notificationDao.clearAll()
        seedInitialData()
    }

    suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
        val existing = accountDao.getAllAccounts().first()
        if (existing.isEmpty()) {
            seedInitialData()
        }
    }

    private suspend fun seedInitialData() {
        val now = System.currentTimeMillis()
        val oneDay = 24L * 3600L * 1000L

        // Accounts
        val accountsList = listOf(
            AccountEntity(
                id = "acc_current",
                name = "Everyday Current Account",
                accountType = "CURRENT",
                sortCode = "20-04-15",
                accountNumber = "73829104",
                availableBalance = 342050L, // £3,420.50
                bookedBalance = 354550L,    // £3,545.50
                pendingBalance = 12500L,    // £125.00
                interestRateApy = null,
                isPrimary = true,
                overdraftLimit = 50000L     // £500.00
            ),
            AccountEntity(
                id = "acc_savings",
                name = "Rainy Day Savings",
                accountType = "SAVINGS",
                sortCode = "20-04-15",
                accountNumber = "98214532",
                availableBalance = 1285000L, // £12,850.00
                bookedBalance = 1285000L,
                pendingBalance = 0L,
                interestRateApy = 4.85,
                isPrimary = false,
                overdraftLimit = 0L
            ),
            AccountEntity(
                id = "acc_holiday",
                name = "Lisbon Holiday Pot",
                accountType = "POT",
                sortCode = "20-04-15",
                accountNumber = "43109283",
                availableBalance = 165000L, // £1,650.00
                bookedBalance = 165000L,
                pendingBalance = 0L,
                interestRateApy = 3.25,
                isPrimary = false,
                overdraftLimit = 0L
            ),
            AccountEntity(
                id = "acc_bills",
                name = "Household Bills Account",
                accountType = "BILLS",
                sortCode = "20-04-15",
                accountNumber = "61829034",
                availableBalance = 82000L, // £820.00
                bookedBalance = 82000L,
                pendingBalance = 0L,
                interestRateApy = null,
                isPrimary = false,
                overdraftLimit = 25000L
            )
        )
        accountDao.insertAccounts(accountsList)

        // Transactions
        val txList = listOf(
            TransactionEntity(
                id = "tx_1",
                accountId = "acc_current",
                merchantOrPayee = "Barclays Group Global - Salary",
                amount = 385000L, // +£3,850.00
                timestamp = now - (2 * oneDay),
                category = "SALARY",
                status = "COMPLETED",
                reference = "PAYROLL-OCT26-REF882",
                type = "SALARY_CREDIT",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_1",
                location = "London, UK"
            ),
            TransactionEntity(
                id = "tx_2",
                accountId = "acc_current",
                merchantOrPayee = "Waitrose & Partners Canary Wharf",
                amount = -6420L, // -£64.20
                timestamp = now - (3 * 3600L * 1000L),
                category = "GROCERIES",
                status = "COMPLETED",
                reference = "WAT-CW-9281",
                type = "CARD_PURCHASE",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_2",
                location = "Canary Wharf, London"
            ),
            TransactionEntity(
                id = "tx_3",
                accountId = "acc_current",
                merchantOrPayee = "Transport for London (TfL)",
                amount = -340L, // -£3.40
                timestamp = now - (5 * 3600L * 1000L),
                category = "TRANSPORT",
                status = "COMPLETED",
                reference = "TFL-CONTACTLESS-094",
                type = "CARD_PURCHASE",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_3",
                location = "London Underground"
            ),
            TransactionEntity(
                id = "tx_4",
                accountId = "acc_current",
                merchantOrPayee = "Dishoom Covent Garden",
                amount = -7850L, // -£78.50
                timestamp = now - (1 * oneDay),
                category = "RESTAURANTS",
                status = "COMPLETED",
                reference = "DISH-CG-382",
                type = "CARD_PURCHASE",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_4",
                location = "Covent Garden, London"
            ),
            TransactionEntity(
                id = "tx_5",
                accountId = "acc_current",
                merchantOrPayee = "Apple Store Regent Street",
                amount = -12500L, // -£125.00
                timestamp = now - (1 * 3600L * 1000L),
                category = "SHOPPING",
                status = "PENDING",
                reference = "APL-REG-9910",
                type = "CARD_PURCHASE",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_5",
                location = "Regent St, London"
            ),
            TransactionEntity(
                id = "tx_6",
                accountId = "acc_current",
                merchantOrPayee = "British Gas Energy",
                amount = -11850L, // -£118.50
                timestamp = now - (4 * oneDay),
                category = "BILLS",
                status = "COMPLETED",
                reference = "BG-DIRECT-DEBIT-440",
                type = "DIRECT_DEBIT",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_6",
                location = "Direct Debit"
            ),
            TransactionEntity(
                id = "tx_7",
                accountId = "acc_current",
                merchantOrPayee = "Spotify Family Subscription",
                amount = -1799L, // -£17.99
                timestamp = now - (6 * oneDay),
                category = "ENTERTAINMENT",
                status = "COMPLETED",
                reference = "SPOTIFY-REC-481",
                type = "DIRECT_DEBIT",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_7",
                location = "Recurring Subscription"
            ),
            TransactionEntity(
                id = "tx_8",
                accountId = "acc_current",
                merchantOrPayee = "PureGym London Wall",
                amount = -3499L, // -£34.99
                timestamp = now - (7 * oneDay),
                category = "HEALTH",
                status = "COMPLETED",
                reference = "PGYM-DD-881",
                type = "DIRECT_DEBIT",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_8",
                location = "London Wall"
            ),
            TransactionEntity(
                id = "tx_9",
                accountId = "acc_current",
                merchantOrPayee = "Transfer to Rainy Day Savings",
                amount = -25000L, // -£250.00
                timestamp = now - (2 * oneDay),
                category = "TRANSFERS",
                status = "COMPLETED",
                reference = "INT-TRF-SAVINGS",
                type = "INTERNAL_TRANSFER",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_9",
                location = "Online Transfer"
            ),
            TransactionEntity(
                id = "tx_10",
                accountId = "acc_current",
                merchantOrPayee = "Pret A Manger Bishopsgate",
                amount = -720L, // -£7.20
                timestamp = now - (8 * 3600L * 1000L),
                category = "RESTAURANTS",
                status = "COMPLETED",
                reference = "PRET-BISHOP-12",
                type = "CARD_PURCHASE",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_10",
                location = "Bishopsgate, London"
            ),
            // Previous month transactions for comparative insights
            TransactionEntity(
                id = "tx_prev_1",
                accountId = "acc_current",
                merchantOrPayee = "TfL Travel Previous Month",
                amount = -8200L,
                timestamp = now - (35 * oneDay),
                category = "TRANSPORT",
                status = "COMPLETED",
                reference = "TFL-PREV-MONTH",
                type = "CARD_PURCHASE",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_prev1",
                location = "London"
            ),
            TransactionEntity(
                id = "tx_prev_2",
                accountId = "acc_current",
                merchantOrPayee = "Waitrose Groceries Previous",
                amount = -28500L,
                timestamp = now - (36 * oneDay),
                category = "GROCERIES",
                status = "COMPLETED",
                reference = "WAT-PREV-MONTH",
                type = "CARD_PURCHASE",
                reversalOfTransactionId = null,
                idempotencyKey = "tx_seed_prev2",
                location = "London"
            )
        )
        transactionDao.insertTransactions(txList)

        // Payees
        val payeesList = listOf(
            PayeeEntity(
                id = "payee_1",
                name = "Dr. Emma Watson",
                sortCode = "40-02-18",
                accountNumber = "81920481",
                bankName = "HSBC UK",
                avatarInitials = "EW",
                lastPaymentDate = now - (10 * oneDay),
                reference = "RENT OCT"
            ),
            PayeeEntity(
                id = "payee_2",
                name = "Oliver Sterling",
                sortCode = "11-08-34",
                accountNumber = "49201948",
                bankName = "Barclays Bank UK",
                avatarInitials = "OS",
                lastPaymentDate = now - (14 * oneDay),
                reference = "Dinner split"
            ),
            PayeeEntity(
                id = "payee_3",
                name = "Tower Hamlets Council",
                sortCode = "60-00-01",
                accountNumber = "10293847",
                bankName = "NatWest",
                avatarInitials = "TH",
                lastPaymentDate = now - (20 * oneDay),
                reference = "Council Tax"
            ),
            PayeeEntity(
                id = "payee_4",
                name = "Sophie Lancaster",
                sortCode = "20-04-15",
                accountNumber = "55443322",
                bankName = "Barclays Premier",
                avatarInitials = "SL",
                lastPaymentDate = now - (3 * oneDay),
                reference = "Concert tickets"
            )
        )
        payeeDao.insertPayees(payeesList)

        // Cards
        val cardsList = listOf(
            CardEntity(
                id = "card_debit_1",
                accountId = "acc_current",
                cardholderName = "MR J ALEXANDER",
                maskedNumber = "•••• •••• •••• 9010",
                expiry = "10/29",
                cardType = "BARCLAYS_DEBIT",
                isFrozen = false,
                contactlessEnabled = true,
                onlinePaymentsEnabled = true,
                atmWithdrawalsEnabled = true,
                monthlySpendingLimit = 200000L, // £2,000.00
                currentSpentThisMonth = 42050L   // £420.50
            ),
            CardEntity(
                id = "card_credit_1",
                accountId = "acc_current",
                cardholderName = "MR J ALEXANDER",
                maskedNumber = "•••• •••• •••• 4429",
                expiry = "04/30",
                cardType = "BARCLAYS_REWARDS_CREDIT",
                isFrozen = false,
                contactlessEnabled = true,
                onlinePaymentsEnabled = true,
                atmWithdrawalsEnabled = false,
                monthlySpendingLimit = 500000L, // £5,000.00
                currentSpentThisMonth = 12500L   // £125.00
            )
        )
        cardDao.insertCards(cardsList)

        // Savings Goals
        val goalsList = listOf(
            SavingsGoalEntity(
                id = "goal_1",
                accountId = "acc_savings",
                title = "Emergency Cash Buffer",
                targetAmount = 1500000L, // £15,000.00
                currentAmount = 1285000L, // £12,850.00
                targetDateMillis = now + (90 * oneDay),
                autoSaveRule = "MONTHLY_PAYDAY",
                iconName = "shield"
            ),
            SavingsGoalEntity(
                id = "goal_2",
                accountId = "acc_holiday",
                title = "Lisbon Summer Retreat",
                targetAmount = 250000L, // £2,500.00
                currentAmount = 165000L, // £1,650.00
                targetDateMillis = now + (180 * oneDay),
                autoSaveRule = "WEEKLY",
                iconName = "flight"
            ),
            SavingsGoalEntity(
                id = "goal_3",
                accountId = "acc_savings",
                title = "Property Deposit Fund",
                targetAmount = 5000000L, // £50,000.00
                currentAmount = 2450000L, // £24,500.00
                targetDateMillis = now + (720 * oneDay),
                autoSaveRule = "MONTHLY_PAYDAY",
                iconName = "home"
            )
        )
        savingsGoalDao.insertGoals(goalsList)

        // Budgets
        val budgetsList = listOf(
            BudgetEntity(
                id = "bgt_groceries",
                category = "GROCERIES",
                monthlyLimit = 40000L, // £400.00
                spentThisMonth = 9700L  // £97.00
            ),
            BudgetEntity(
                id = "bgt_restaurants",
                category = "RESTAURANTS",
                monthlyLimit = 25000L, // £250.00
                spentThisMonth = 8570L  // £85.70
            ),
            BudgetEntity(
                id = "bgt_transport",
                category = "TRANSPORT",
                monthlyLimit = 15000L, // £150.00
                spentThisMonth = 4240L  // £42.40
            ),
            BudgetEntity(
                id = "bgt_entertainment",
                category = "ENTERTAINMENT",
                monthlyLimit = 10000L, // £100.00
                spentThisMonth = 2698L  // £26.98
            ),
            BudgetEntity(
                id = "bgt_shopping",
                category = "SHOPPING",
                monthlyLimit = 30000L, // £300.00
                spentThisMonth = 12500L // £125.00
            )
        )
        budgetDao.insertBudgets(budgetsList)

        // Scheduled Payments
        val scheduledList = listOf(
            ScheduledPaymentEntity(
                id = "sched_1",
                title = "London Residential Rent",
                recipient = "Dr. Emma Watson",
                amount = 165000L, // £1,650.00
                scheduleDescription = "Monthly on 1st",
                nextPaymentDateMillis = now + (11 * oneDay),
                type = "STANDING_ORDER",
                isActive = true
            ),
            ScheduledPaymentEntity(
                id = "sched_2",
                title = "Tower Hamlets Council Tax",
                recipient = "Tower Hamlets Council",
                amount = 15800L, // £158.00
                scheduleDescription = "Monthly on 15th",
                nextPaymentDateMillis = now + (25 * oneDay),
                type = "DIRECT_DEBIT",
                isActive = true
            ),
            ScheduledPaymentEntity(
                id = "sched_3",
                title = "British Gas Energy DD",
                recipient = "British Gas Trading",
                amount = 11850L, // £118.50
                scheduleDescription = "Monthly on 28th",
                nextPaymentDateMillis = now + (8 * oneDay),
                type = "DIRECT_DEBIT",
                isActive = true
            ),
            ScheduledPaymentEntity(
                id = "sched_4",
                title = "Spotify Family Subscription",
                recipient = "Spotify AB",
                amount = 1799L, // £17.99
                scheduleDescription = "Monthly on 5th",
                nextPaymentDateMillis = now + (15 * oneDay),
                type = "RECURRING_CARD",
                isActive = true
            )
        )
        scheduledPaymentDao.insertScheduled(scheduledList)

        // Notifications
        val notifsList = listOf(
            NotificationItem(
                id = "notif_1",
                title = "Salary Credited",
                message = "Your salary of £3,850.00 from Barclays Group Global has cleared into your Everyday Current Account.",
                timestamp = now - (2 * oneDay),
                category = NotificationCategory.PAYMENT,
                isRead = false
            ).let {
                NotificationEntity(it.id, it.title, it.message, it.timestamp, it.category.name, it.isRead)
            },
            NotificationItem(
                id = "notif_2",
                title = "Security Check: Premier Protection",
                message = "Biometric confirmation is enabled on this device. No suspicious card activity detected.",
                timestamp = now - (3 * oneDay),
                category = NotificationCategory.SECURITY,
                isRead = true
            ).let {
                NotificationEntity(it.id, it.title, it.message, it.timestamp, it.category.name, it.isRead)
            },
            NotificationItem(
                id = "notif_3",
                title = "Savings Milestone",
                message = "Emergency Cash Buffer is now 85% funded! You're on track to complete this goal ahead of schedule.",
                timestamp = now - (5 * oneDay),
                category = NotificationCategory.BUDGET,
                isRead = true
            ).let {
                NotificationEntity(it.id, it.title, it.message, it.timestamp, it.category.name, it.isRead)
            }
        )
        notificationDao.insertNotifications(notifsList)
    }
}
