package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.BarclaysDatabase
import com.example.data.local.BarclaysRepository
import com.example.data.local.PaymentResult
import com.example.domain.model.Account
import com.example.domain.model.Budget
import com.example.domain.model.Card
import com.example.domain.model.Money
import com.example.domain.model.NotificationItem
import com.example.domain.model.Payee
import com.example.domain.model.SavingsGoal
import com.example.domain.model.ScheduledPayment
import com.example.domain.model.Transaction
import com.example.domain.model.TransactionCategory
import com.example.domain.model.TransactionStatus
import com.example.domain.service.FinancialInsightsService
import com.example.domain.service.LoanCalculationResult
import com.example.domain.service.LoanCalculatorService
import com.example.domain.service.MonthSpendingSummary
import com.example.domain.service.PaymentValidationResult
import com.example.domain.service.PaymentValidationService
import com.example.domain.service.SavingsProjectionResult
import com.example.domain.service.SavingsProjectionService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class TxDirectionFilter(val label: String) {
    ALL("All"),
    MONEY_IN("Money In"),
    MONEY_OUT("Money Out"),
    PENDING("Pending")
}

data class PaymentUiReceipt(
    val reference: String,
    val payeeName: String,
    val sortCode: String,
    val accountNumber: String,
    val amountPence: Long,
    val timestamp: Long,
    val sourceAccountName: String
)

class BarclaysViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BarclaysRepository

    init {
        val db = BarclaysDatabase.getDatabase(application)
        repository = BarclaysRepository(db)
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    val accounts: StateFlow<List<Account>> = repository.accounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedAccountId = MutableStateFlow<String?>(null)
    val selectedAccountId = _selectedAccountId.asStateFlow()

    val transactions: StateFlow<List<Transaction>> = repository.transactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payees: StateFlow<List<Payee>> = repository.payees
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cards: StateFlow<List<Card>> = repository.cards
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savingsGoals: StateFlow<List<SavingsGoal>> = repository.savingsGoals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val budgets: StateFlow<List<Budget>> = repository.budgets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scheduledPayments: StateFlow<List<ScheduledPayment>> = repository.scheduledPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationItem>> = repository.notifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Privacy mask toggle (e.g. £••••••)
    private val _privacyHideBalances = MutableStateFlow(false)
    val privacyHideBalances = _privacyHideBalances.asStateFlow()

    // Transaction filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedTxCategory = MutableStateFlow<TransactionCategory?>(null)
    val selectedTxCategory = _selectedTxCategory.asStateFlow()

    private val _selectedDirection = MutableStateFlow(TxDirectionFilter.ALL)
    val selectedDirection = _selectedDirection.asStateFlow()

    // Filtered transaction list
    val filteredTransactions: StateFlow<List<Transaction>> = combine(
        transactions,
        _selectedAccountId,
        _searchQuery,
        _selectedTxCategory,
        _selectedDirection
    ) { list, accId, query, category, direction ->
        list.filter { tx ->
            val matchAccount = accId == null || tx.accountId == accId
            val matchQuery = query.isBlank() ||
                    tx.merchantOrPayee.contains(query, ignoreCase = true) ||
                    tx.reference.contains(query, ignoreCase = true) ||
                    tx.category.displayName.contains(query, ignoreCase = true)
            val matchCategory = category == null || tx.category == category
            val matchDirection = when (direction) {
                TxDirectionFilter.ALL -> true
                TxDirectionFilter.MONEY_IN -> tx.amount > 0
                TxDirectionFilter.MONEY_OUT -> tx.amount < 0
                TxDirectionFilter.PENDING -> tx.status == TransactionStatus.PENDING
            }
            matchAccount && matchQuery && matchCategory && matchDirection
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Insights summary derived from live ledger
    val spendingSummary: StateFlow<MonthSpendingSummary> = transactions.combine(_privacyHideBalances) { list, _ ->
        FinancialInsightsService.analyzeSpending(list)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        FinancialInsightsService.analyzeSpending(emptyList())
    )

    // Interactive Savings Projection State
    private val _savingsInitialPence = MutableStateFlow(500000L) // £5,000.00
    val savingsInitialPence = _savingsInitialPence.asStateFlow()

    private val _savingsMonthlyPence = MutableStateFlow(25000L)  // £250.00
    val savingsMonthlyPence = _savingsMonthlyPence.asStateFlow()

    private val _savingsRatePercent = MutableStateFlow(4.85)     // 4.85% APY
    val savingsRatePercent = _savingsRatePercent.asStateFlow()

    private val _savingsYears = MutableStateFlow(5)              // 5 years
    val savingsYears = _savingsYears.asStateFlow()

    val savingsProjectionResult: StateFlow<SavingsProjectionResult> = combine(
        _savingsInitialPence,
        _savingsMonthlyPence,
        _savingsRatePercent,
        _savingsYears
    ) { init, monthly, rate, years ->
        SavingsProjectionService.calculateProjection(init, monthly, rate, years)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        SavingsProjectionService.calculateProjection(500000L, 25000L, 4.85, 5)
    )

    // Interactive Loan Calculator State
    private val _loanPrincipalPence = MutableStateFlow(1000000L) // £10,000.00
    val loanPrincipalPence = _loanPrincipalPence.asStateFlow()

    private val _loanAprPercent = MutableStateFlow(6.9)          // 6.9% APR
    val loanAprPercent = _loanAprPercent.asStateFlow()

    private val _loanTermMonths = MutableStateFlow(36)           // 36 months
    val loanTermMonths = _loanTermMonths.asStateFlow()

    val loanCalculationResult: StateFlow<LoanCalculationResult> = combine(
        _loanPrincipalPence,
        _loanAprPercent,
        _loanTermMonths
    ) { principal, apr, term ->
        LoanCalculatorService.calculateLoanRepayment(principal, apr, term)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        LoanCalculatorService.calculateLoanRepayment(1000000L, 6.9, 36)
    )

    // Payment & Dialog states
    private val _activeReceipt = MutableStateFlow<PaymentUiReceipt?>(null)
    val activeReceipt = _activeReceipt.asStateFlow()

    private val _paymentError = MutableStateFlow<String?>(null)
    val paymentError = _paymentError.asStateFlow()

    private val _isPaymentProcessing = MutableStateFlow(false)
    val isPaymentProcessing = _isPaymentProcessing.asStateFlow()

    fun togglePrivacyMask() {
        _privacyHideBalances.value = !_privacyHideBalances.value
    }

    fun selectAccount(accountId: String?) {
        _selectedAccountId.value = accountId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(category: TransactionCategory?) {
        _selectedTxCategory.value = category
    }

    fun setDirectionFilter(direction: TxDirectionFilter) {
        _selectedDirection.value = direction
    }

    fun updateSavingsProjectionInputs(initialPence: Long, monthlyPence: Long, rate: Double, years: Int) {
        _savingsInitialPence.value = initialPence
        _savingsMonthlyPence.value = monthlyPence
        _savingsRatePercent.value = rate
        _savingsYears.value = years
    }

    fun updateLoanInputs(principalPence: Long, apr: Double, termMonths: Int) {
        _loanPrincipalPence.value = principalPence
        _loanAprPercent.value = apr
        _loanTermMonths.value = termMonths
    }

    fun executeSendPayment(
        sourceAccountId: String,
        payeeName: String,
        sortCode: String,
        accountNumber: String,
        amountPence: Long,
        reference: String,
        onSuccess: () -> Unit
    ) {
        val account = accounts.value.firstOrNull { it.id == sourceAccountId }
            ?: accounts.value.firstOrNull { it.isPrimary }
            ?: accounts.value.firstOrNull()

        if (account == null) {
            _paymentError.value = "No source account available."
            return
        }

        val validation = PaymentValidationService.validatePayment(
            payeeName = payeeName,
            sortCode = sortCode,
            accountNumber = accountNumber,
            amountPence = amountPence,
            availableBalancePence = account.availableBalance,
            overdraftLimitPence = account.overdraftLimit
        )

        if (validation is PaymentValidationResult.Error) {
            _paymentError.value = validation.message
            return
        }

        _isPaymentProcessing.value = true
        _paymentError.value = null

        viewModelScope.launch {
            val result = repository.executePayment(
                sourceAccountId = account.id,
                payeeName = payeeName,
                sortCode = sortCode,
                accountNumber = accountNumber,
                amountPence = amountPence,
                reference = reference
            )
            _isPaymentProcessing.value = false
            when (result) {
                is PaymentResult.Success -> {
                    _activeReceipt.value = PaymentUiReceipt(
                        reference = result.reference,
                        payeeName = payeeName,
                        sortCode = sortCode,
                        accountNumber = accountNumber,
                        amountPence = amountPence,
                        timestamp = result.timestamp,
                        sourceAccountName = account.name
                    )
                    onSuccess()
                }
                is PaymentResult.Failure -> {
                    _paymentError.value = result.reason
                }
            }
        }
    }

    fun executeOwnTransfer(
        sourceAccountId: String,
        destinationAccountId: String,
        amountPence: Long,
        reference: String,
        onSuccess: () -> Unit
    ) {
        val source = accounts.value.firstOrNull { it.id == sourceAccountId }
        val dest = accounts.value.firstOrNull { it.id == destinationAccountId }

        if (source == null || dest == null) {
            _paymentError.value = "Please select both source and destination accounts."
            return
        }
        if (source.id == dest.id) {
            _paymentError.value = "Cannot transfer between the same account."
            return
        }
        if (amountPence <= 0) {
            _paymentError.value = "Please enter an amount greater than £0.00."
            return
        }
        if (source.availableBalance + source.overdraftLimit < amountPence) {
            _paymentError.value = "Insufficient funds in ${source.name}."
            return
        }

        _isPaymentProcessing.value = true
        _paymentError.value = null

        viewModelScope.launch {
            val result = repository.transferBetweenAccounts(
                sourceAccountId = source.id,
                destinationAccountId = dest.id,
                amountPence = amountPence,
                reference = reference
            )
            _isPaymentProcessing.value = false
            when (result) {
                is PaymentResult.Success -> {
                    _activeReceipt.value = PaymentUiReceipt(
                        reference = result.reference,
                        payeeName = dest.name,
                        sortCode = dest.sortCode,
                        accountNumber = dest.accountNumber,
                        amountPence = amountPence,
                        timestamp = result.timestamp,
                        sourceAccountName = source.name
                    )
                    onSuccess()
                }
                is PaymentResult.Failure -> {
                    _paymentError.value = result.reason
                }
            }
        }
    }

    fun reverseTransaction(txId: String) {
        viewModelScope.launch {
            repository.reverseTransaction(txId)
        }
    }

    fun toggleCardFreeze(cardId: String, isFrozen: Boolean) {
        viewModelScope.launch {
            repository.setCardFreeze(cardId, isFrozen)
        }
    }

    fun updateCardControls(cardId: String, contactless: Boolean, online: Boolean, atm: Boolean, limit: Long) {
        viewModelScope.launch {
            repository.updateCardControls(cardId, contactless, online, atm, limit)
        }
    }

    fun createSavingsGoal(accountId: String, title: String, targetPence: Long, initialPence: Long, months: Int, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.createSavingsGoal(accountId, title, targetPence, initialPence, months)
            onComplete()
        }
    }

    fun topUpGoal(goalId: String, sourceAccountId: String, amountPence: Long, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.topUpGoal(goalId, sourceAccountId, amountPence)
            onComplete()
        }
    }

    fun updateBudgetLimit(budgetId: String, newLimitPence: Long) {
        viewModelScope.launch {
            repository.updateBudgetLimit(budgetId, newLimitPence)
        }
    }

    fun toggleScheduledPayment(schedId: String, isActive: Boolean) {
        viewModelScope.launch {
            repository.toggleScheduledPayment(schedId, isActive)
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }

    fun dismissReceipt() {
        _activeReceipt.value = null
    }

    fun clearPaymentError() {
        _paymentError.value = null
    }

    fun resetDemoData() {
        viewModelScope.launch {
            repository.resetDemoData()
        }
    }
}
