package com.example.domain.service

import com.example.domain.model.Money

sealed class PaymentValidationResult {
    data object Valid : PaymentValidationResult()
    data class Error(val field: Field, val message: String) : PaymentValidationResult()

    enum class Field {
        PAYEE_NAME,
        SORT_CODE,
        ACCOUNT_NUMBER,
        AMOUNT,
        FUNDS
    }
}

object PaymentValidationService {

    /**
     * Validates UK payment inputs according to banking standards.
     */
    fun validatePayment(
        payeeName: String,
        sortCode: String,
        accountNumber: String,
        amountPence: Long?,
        availableBalancePence: Long,
        overdraftLimitPence: Long = 0L
    ): PaymentValidationResult {
        if (payeeName.trim().length < 2) {
            return PaymentValidationResult.Error(
                PaymentValidationResult.Field.PAYEE_NAME,
                "Please enter a valid payee name (at least 2 characters)."
            )
        }

        val cleanSortCode = sortCode.replace("-", "").replace(" ", "").trim()
        if (cleanSortCode.length != 6 || !cleanSortCode.all { it.isDigit() }) {
            return PaymentValidationResult.Error(
                PaymentValidationResult.Field.SORT_CODE,
                "UK Sort code must be 6 digits (e.g. 20-04-15)."
            )
        }

        val cleanAccountNumber = accountNumber.replace(" ", "").trim()
        if (cleanAccountNumber.length != 8 || !cleanAccountNumber.all { it.isDigit() }) {
            return PaymentValidationResult.Error(
                PaymentValidationResult.Field.ACCOUNT_NUMBER,
                "Account number must be 8 digits."
            )
        }

        if (amountPence == null || amountPence <= 0L) {
            return PaymentValidationResult.Error(
                PaymentValidationResult.Field.AMOUNT,
                "Please enter an amount greater than £0.00."
            )
        }

        val maximumSinglePaymentPence = 100000000L // £1,000,000 limit
        if (amountPence > maximumSinglePaymentPence) {
            return PaymentValidationResult.Error(
                PaymentValidationResult.Field.AMOUNT,
                "Payment exceeds the Faster Payments daily limit of £1,000,000.00."
            )
        }

        if (!Money.hasSufficientFunds(availableBalancePence, amountPence, overdraftLimitPence)) {
            val totalAvailableWithOverdraft = availableBalancePence + overdraftLimitPence
            return PaymentValidationResult.Error(
                PaymentValidationResult.Field.FUNDS,
                "Insufficient funds. Maximum available including overdraft buffer: ${Money.formatPence(totalAvailableWithOverdraft)}."
            )
        }

        return PaymentValidationResult.Valid
    }

    /**
     * Formats raw digits into standard UK sort code string "XX-XX-XX".
     */
    fun formatSortCode(input: String): String {
        val digits = input.filter { it.isDigit() }.take(6)
        val chunks = digits.chunked(2)
        return chunks.joinToString("-")
    }
}
