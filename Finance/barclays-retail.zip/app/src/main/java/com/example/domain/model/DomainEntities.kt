package com.example.domain.model

data class Payee(
    val id: String,
    val name: String,
    val sortCode: String,
    val accountNumber: String,
    val bankName: String,
    val avatarInitials: String,
    val lastPaymentDate: Long? = null,
    val reference: String = ""
)

enum class CardType(val displayName: String) {
    BARCLAYS_DEBIT("Premier Debit"),
    BARCLAYS_REWARDS_CREDIT("Barclaycard Rewards")
}

data class Card(
    val id: String,
    val accountId: String,
    val cardholderName: String,
    val maskedNumber: String,
    val expiry: String,
    val cardType: CardType,
    val isFrozen: Boolean = false,
    val contactlessEnabled: Boolean = true,
    val onlinePaymentsEnabled: Boolean = true,
    val atmWithdrawalsEnabled: Boolean = true,
    val monthlySpendingLimit: Long = 150000L, // £1,500.00
    val currentSpentThisMonth: Long = 42050L  // £420.50
)

enum class AutoSaveRule(val label: String) {
    NONE("Off"),
    ROUND_UPS("Spare Change Round-ups"),
    WEEKLY("Weekly £25 Transfer"),
    MONTHLY_PAYDAY("Monthly £150 on Payday")
}

data class SavingsGoal(
    val id: String,
    val accountId: String,
    val title: String,
    val targetAmount: Long, // in pence
    val currentAmount: Long, // in pence
    val targetDateMillis: Long,
    val autoSaveRule: AutoSaveRule = AutoSaveRule.NONE,
    val iconName: String = "savings"
) {
    val progressPercent: Float
        get() = if (targetAmount <= 0) 1f else (currentAmount.toFloat() / targetAmount.toFloat()).coerceIn(0f, 1f)
}

data class Budget(
    val id: String,
    val category: TransactionCategory,
    val monthlyLimit: Long, // in pence
    val spentThisMonth: Long // in pence
) {
    val progressPercent: Float
        get() = if (monthlyLimit <= 0) 0f else (spentThisMonth.toFloat() / monthlyLimit.toFloat()).coerceIn(0f, 1.5f)
}

enum class ScheduledPaymentType(val label: String) {
    DIRECT_DEBIT("Direct Debit"),
    STANDING_ORDER("Standing Order"),
    RECURRING_CARD("Recurring Card")
}

data class ScheduledPayment(
    val id: String,
    val title: String,
    val recipient: String,
    val amount: Long, // in pence
    val scheduleDescription: String,
    val nextPaymentDateMillis: Long,
    val type: ScheduledPaymentType,
    val isActive: Boolean = true
)

enum class NotificationCategory(val label: String) {
    ALL("All"),
    PAYMENT("Payments"),
    SECURITY("Security"),
    BUDGET("Budgets & Goals")
}

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val category: NotificationCategory,
    val isRead: Boolean = false
)
