package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Account
import com.example.domain.model.Money
import com.example.domain.model.Payee
import com.example.domain.service.PaymentValidationService
import com.example.ui.BarclaysViewModel
import com.example.ui.theme.BarclaysCyan
import com.example.ui.theme.BarclaysNavyDark
import com.example.ui.theme.BarclaysNavyDeep
import com.example.ui.theme.BarclaysWhite
import com.example.ui.theme.FinancialAmber
import com.example.ui.theme.FinancialGreen
import com.example.ui.theme.FinancialRed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentsScreen(
    viewModel: BarclaysViewModel,
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(initialTab.coerceIn(0, 3)) }

    val accounts by viewModel.accounts.collectAsStateWithLifecycle()
    val payees by viewModel.payees.collectAsStateWithLifecycle()
    val scheduledPayments by viewModel.scheduledPayments.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isPaymentProcessing.collectAsStateWithLifecycle()
    val paymentError by viewModel.paymentError.collectAsStateWithLifecycle()
    val isPrivacyMasked by viewModel.privacyHideBalances.collectAsStateWithLifecycle()

    // Send Money Form state
    var selectedPayee by remember { mutableStateOf<Payee?>(null) }
    var payeeNameInput by remember { mutableStateOf("") }
    var sortCodeInput by remember { mutableStateOf("") }
    var accountNumberInput by remember { mutableStateOf("") }
    var amountInput by remember { mutableStateOf("") }
    var referenceInput by remember { mutableStateOf("") }
    var selectedSourceAccountId by remember { mutableStateOf<String?>(null) }

    // Multi-step review modal state
    var showReviewModal by remember { mutableStateOf(false) }

    // Own Transfer Form state
    var transferSourceAccountId by remember { mutableStateOf<String?>(null) }
    var transferDestAccountId by remember { mutableStateOf<String?>(null) }
    var transferAmountInput by remember { mutableStateOf("") }
    var transferRefInput by remember { mutableStateOf("") }

    val activeSourceAccount = accounts.firstOrNull { it.id == selectedSourceAccountId }
        ?: accounts.firstOrNull { it.isPrimary }
        ?: accounts.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Tab Navigation: Pay Someone, Own Transfer, Scheduled, Saved Payees
        SecondaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = BarclaysNavyDeep
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Pay Someone", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_pay_someone")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Move Money", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_move_money")
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Scheduled", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_scheduled")
            )
            Tab(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                text = { Text("Payees (${payees.size})", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_saved_payees")
            )
        }

        // Error message banner if present
        paymentError?.let { err ->
            Surface(
                color = FinancialRed.copy(alpha = 0.12f),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = FinancialRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = err, style = MaterialTheme.typography.bodySmall, color = FinancialRed, modifier = Modifier.weight(1f))
                    IconButton(onClick = { viewModel.clearPaymentError() }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Dismiss error", tint = FinancialRed, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        when (selectedTab) {
            0 -> {
                // PAY SOMEONE JOURNEY
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Text(
                            text = "FASTER PAYMENTS TRANSFER",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                    }

                    // Source Account Selector Card
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "Pay From",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = activeSourceAccount?.name ?: "No Account",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Available: ${if (isPrivacyMasked) "£•••" else Money.formatPence(activeSourceAccount?.availableBalance ?: 0L)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = FinancialGreen,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    // Saved Payees Quick Selection
                    item {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Select Saved Payee",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (selectedPayee != null) {
                                    Text(
                                        text = "Clear",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.clickable {
                                            selectedPayee = null
                                            payeeNameInput = ""
                                            sortCodeInput = ""
                                            accountNumberInput = ""
                                        }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                payees.forEach { p ->
                                    val isSelected = selectedPayee?.id == p.id
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isSelected) BarclaysNavyDeep else MaterialTheme.colorScheme.surface,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (isSelected) BarclaysCyan else MaterialTheme.colorScheme.outline
                                        ),
                                        modifier = Modifier
                                            .clickable {
                                                selectedPayee = p
                                                payeeNameInput = p.name
                                                sortCodeInput = p.sortCode
                                                accountNumberInput = p.accountNumber
                                                referenceInput = p.reference
                                            }
                                            .testTag("payee_chip_${p.id}")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(28.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isSelected) BarclaysCyan else MaterialTheme.colorScheme.surfaceVariant),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = p.avatarInitials,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isSelected) BarclaysNavyDark else MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = p.name,
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (isSelected) BarclaysWhite else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Payee Form Details
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "Payee Information",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )

                                OutlinedTextField(
                                    value = payeeNameInput,
                                    onValueChange = {
                                        payeeNameInput = it
                                        selectedPayee = null
                                    },
                                    label = { Text("Full Name or Company") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_payee_name")
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedTextField(
                                        value = sortCodeInput,
                                        onValueChange = {
                                            sortCodeInput = PaymentValidationService.formatSortCode(it)
                                            selectedPayee = null
                                        },
                                        label = { Text("Sort Code") },
                                        placeholder = { Text("20-04-15") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("input_sort_code")
                                    )

                                    OutlinedTextField(
                                        value = accountNumberInput,
                                        onValueChange = {
                                            accountNumberInput = it.filter { ch -> ch.isDigit() }.take(8)
                                            selectedPayee = null
                                        },
                                        label = { Text("Account No.") },
                                        placeholder = { Text("8 digits") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .weight(1.2f)
                                            .testTag("input_account_number")
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = BarclaysCyan.copy(alpha = 0.08f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = BarclaysNavyDeep, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Confirmation of Payee (CoP): Account details verified as UK Domestic match.",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontSize = 11.sp,
                                            color = BarclaysNavyDeep
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Amount & Reference Card
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "Payment Amount",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )

                                OutlinedTextField(
                                    value = amountInput,
                                    onValueChange = { amountInput = it },
                                    label = { Text("Amount (£)") },
                                    placeholder = { Text("0.00") },
                                    prefix = { Text("£", fontWeight = FontWeight.Bold) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_payment_amount")
                                )

                                // Quick Amount Chips
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("10.00", "25.00", "50.00", "100.00").forEach { quick ->
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            modifier = Modifier
                                                .clickable { amountInput = quick }
                                                .padding(vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "£$quick",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = referenceInput,
                                    onValueChange = { referenceInput = it.take(30) },
                                    label = { Text("Payment Reference (Optional)") },
                                    placeholder = { Text("e.g. Dinner, Rent, Invoice") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_payment_reference")
                                )
                            }
                        }
                    }

                    // Review & Submit Button
                    item {
                        Button(
                            onClick = {
                                val pence = Money.parseToPence(amountInput)
                                val validation = PaymentValidationService.validatePayment(
                                    payeeName = payeeNameInput,
                                    sortCode = sortCodeInput,
                                    accountNumber = accountNumberInput,
                                    amountPence = pence,
                                    availableBalancePence = activeSourceAccount?.availableBalance ?: 0L,
                                    overdraftLimitPence = activeSourceAccount?.overdraftLimit ?: 0L
                                )
                                if (validation is com.example.domain.service.PaymentValidationResult.Error) {
                                    // Handled in VM or trigger error
                                }
                                showReviewModal = true
                            },
                            enabled = !isProcessing,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BarclaysNavyDeep),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("button_review_payment")
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(color = BarclaysWhite, modifier = Modifier.size(24.dp))
                            } else {
                                Icon(imageVector = Icons.Default.Send, contentDescription = null, tint = BarclaysCyan)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Review Payment", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = BarclaysWhite)
                            }
                        }
                    }
                }
            }

            1 -> {
                // MOVE MONEY BETWEEN OWN ACCOUNTS
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Text(
                            text = "TRANSFER BETWEEN OWN ACCOUNTS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                    }

                    // Source Account Picker
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("From Account", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(6.dp))
                                accounts.forEach { acc ->
                                    val isSelected = (transferSourceAccountId ?: accounts.firstOrNull()?.id) == acc.id
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) BarclaysNavyDeep else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clickable { transferSourceAccountId = acc.id }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(acc.name, fontWeight = FontWeight.Bold, color = if (isSelected) BarclaysWhite else MaterialTheme.colorScheme.onSurface)
                                                Text("Available: ${Money.formatPence(acc.availableBalance)}", fontSize = 12.sp, color = if (isSelected) BarclaysCyan else MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            if (isSelected) {
                                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = BarclaysCyan)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Destination Account Picker
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("To Account", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(6.dp))
                                accounts.forEach { acc ->
                                    val isSelected = (transferDestAccountId ?: accounts.getOrNull(1)?.id) == acc.id
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) BarclaysNavyDeep else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clickable { transferDestAccountId = acc.id }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(acc.name, fontWeight = FontWeight.Bold, color = if (isSelected) BarclaysWhite else MaterialTheme.colorScheme.onSurface)
                                                Text("Current balance: ${Money.formatPence(acc.availableBalance)}", fontSize = 12.sp, color = if (isSelected) BarclaysCyan else MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            if (isSelected) {
                                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = BarclaysCyan)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Transfer Amount
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Transfer Amount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                OutlinedTextField(
                                    value = transferAmountInput,
                                    onValueChange = { transferAmountInput = it },
                                    label = { Text("Amount (£)") },
                                    placeholder = { Text("0.00") },
                                    prefix = { Text("£", fontWeight = FontWeight.Bold) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_transfer_amount")
                                )

                                OutlinedTextField(
                                    value = transferRefInput,
                                    onValueChange = { transferRefInput = it },
                                    label = { Text("Reference (Optional)") },
                                    placeholder = { Text("e.g. Savings Top-Up") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    // Submit Transfer Button
                    item {
                        Button(
                            onClick = {
                                val pence = Money.parseToPence(transferAmountInput) ?: 0L
                                val src = transferSourceAccountId ?: accounts.firstOrNull()?.id ?: ""
                                val dst = transferDestAccountId ?: accounts.getOrNull(1)?.id ?: ""
                                viewModel.executeOwnTransfer(src, dst, pence, transferRefInput) {
                                    transferAmountInput = ""
                                    transferRefInput = ""
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BarclaysNavyDeep),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("button_confirm_transfer")
                        ) {
                            Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, tint = BarclaysCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Transfer Instantly", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = BarclaysWhite)
                        }
                    }
                }
            }

            2 -> {
                // SCHEDULED PAYMENTS & DIRECT DEBITS
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = "DIRECT DEBITS & STANDING ORDERS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Manage recurring commitments. You can pause or cancel synthetic demonstration payment instructions below.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    items(scheduledPayments) { sched ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(sched.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(sched.recipient, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    Text(
                                        text = Money.formatPence(sched.amount),
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (sched.isActive) BarclaysNavyDark else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                HorizontalDivider()
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = BarclaysCyan, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${sched.scheduleDescription} • ${sched.type.label}",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = if (sched.isActive) "Active" else "Paused",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (sched.isActive) FinancialGreen else FinancialAmber,
                                            modifier = Modifier.padding(end = 8.dp)
                                        )

                                        Switch(
                                            checked = sched.isActive,
                                            onCheckedChange = { viewModel.toggleScheduledPayment(sched.id, it) },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = BarclaysCyan,
                                                checkedTrackColor = BarclaysNavyDeep
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                // SAVED PAYEES
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            text = "SAVED PAYEES & RECIPIENTS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            letterSpacing = 1.sp
                        )
                    }

                    items(payees) { payee ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(BarclaysNavyDeep),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = payee.avatarInitials,
                                            fontWeight = FontWeight.Bold,
                                            color = BarclaysCyan,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(payee.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                        Text(
                                            text = "${payee.bankName} • ${payee.sortCode} • ${payee.accountNumber}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        selectedPayee = payee
                                        payeeNameInput = payee.name
                                        sortCodeInput = payee.sortCode
                                        accountNumberInput = payee.accountNumber
                                        referenceInput = payee.reference
                                        selectedTab = 0
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = BarclaysNavyDeep)
                                ) {
                                    Text("Pay", fontSize = 12.sp, color = BarclaysWhite)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Step 2 Review Modal Sheet before final execution
    if (showReviewModal) {
        val parsedPence = Money.parseToPence(amountInput) ?: 0L

        ModalBottomSheet(
            onDismissRequest = { showReviewModal = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Review Payment Details", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { showReviewModal = false }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // High-visibility confirmation box
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = BarclaysIceSurface(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Amount to Send", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = Money.formatPence(parsedPence),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = BarclaysNavyDark
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Recipient: $payeeNameInput", fontWeight = FontWeight.SemiBold)
                        Text("Sort Code: $sortCodeInput • Account: $accountNumberInput", style = MaterialTheme.typography.bodySmall)
                        Text("Debited from: ${activeSourceAccount?.name}", style = MaterialTheme.typography.bodySmall)
                        if (referenceInput.isNotBlank()) {
                            Text("Reference: $referenceInput", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Security confirmation warning
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = FinancialAmber.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = BarclaysNavyDeep, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Fraud check: Barclays will never ask you to move money to a safe account. This demonstration uses synthetic funds.",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        showReviewModal = false
                        val srcId = activeSourceAccount?.id ?: ""
                        viewModel.executeSendPayment(
                            sourceAccountId = srcId,
                            payeeName = payeeNameInput,
                            sortCode = sortCodeInput,
                            accountNumber = accountNumberInput,
                            amountPence = parsedPence,
                            reference = referenceInput
                        ) {
                            payeeNameInput = ""
                            sortCodeInput = ""
                            accountNumberInput = ""
                            amountInput = ""
                            referenceInput = ""
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BarclaysNavyDeep),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("button_confirm_and_pay")
                ) {
                    Text("Confirm & Authorise Payment", fontWeight = FontWeight.Bold, color = BarclaysWhite)
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun BarclaysIceSurface() = MaterialTheme.colorScheme.surfaceVariant
