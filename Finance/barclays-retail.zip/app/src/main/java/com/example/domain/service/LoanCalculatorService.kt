package com.example.domain.service

import kotlin.math.pow
import kotlin.math.roundToLong

data class LoanCalculationResult(
    val monthlyPaymentPence: Long,
    val totalRepaymentPence: Long,
    val totalInterestPence: Long,
    val aprPercent: Double,
    val termMonths: Int
)

object LoanCalculatorService {

    /**
     * Standard amortisation calculation for personal loans and mortgages.
     * M = P [ i(1 + i)^n ] / [ (1 + i)^n – 1]
     * @param principalPence Borrowing amount in pence
     * @param aprPercent Representative APR, e.g. 6.9 for 6.9%
     * @param termMonths Duration in months (e.g. 12, 24, 36, 60, 300)
     */
    fun calculateLoanRepayment(
        principalPence: Long,
        aprPercent: Double,
        termMonths: Int
    ): LoanCalculationResult {
        if (principalPence <= 0 || termMonths <= 0) {
            return LoanCalculationResult(
                monthlyPaymentPence = 0L,
                totalRepaymentPence = 0L,
                totalInterestPence = 0L,
                aprPercent = aprPercent,
                termMonths = termMonths
            )
        }

        if (aprPercent <= 0.0) {
            val monthly = principalPence / termMonths
            return LoanCalculationResult(
                monthlyPaymentPence = monthly,
                totalRepaymentPence = principalPence,
                totalInterestPence = 0L,
                aprPercent = 0.0,
                termMonths = termMonths
            )
        }

        val monthlyRate = (aprPercent / 100.0) / 12.0
        val factor = (1.0 + monthlyRate).pow(termMonths.toDouble())
        val monthlyPaymentDouble = principalPence.toDouble() * (monthlyRate * factor) / (factor - 1.0)
        val monthlyPaymentPence = monthlyPaymentDouble.roundToLong()
        val totalRepaymentPence = monthlyPaymentPence * termMonths
        val totalInterestPence = (totalRepaymentPence - principalPence).coerceAtLeast(0L)

        return LoanCalculationResult(
            monthlyPaymentPence = monthlyPaymentPence,
            totalRepaymentPence = totalRepaymentPence,
            totalInterestPence = totalInterestPence,
            aprPercent = aprPercent,
            termMonths = termMonths
        )
    }
}
