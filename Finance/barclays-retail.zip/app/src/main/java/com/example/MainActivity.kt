package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.AutoGraph
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Transaction
import com.example.ui.BarclaysViewModel
import com.example.ui.components.BarclaysHeader
import com.example.ui.components.PaymentReceiptDialog
import com.example.ui.screens.AccountsScreen
import com.example.ui.screens.CardsScreen
import com.example.ui.screens.GlobalSearchDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InsightsScreen
import com.example.ui.screens.NewSavingsGoalDialog
import com.example.ui.screens.NotificationSheet
import com.example.ui.screens.PaymentsScreen
import com.example.ui.screens.ProfileAndSecuritySheet
import com.example.ui.screens.StatementDialog
import com.example.ui.theme.BarclaysCyan
import com.example.ui.theme.BarclaysNavyDark
import com.example.ui.theme.BarclaysNavyDeep
import com.example.ui.theme.BarclaysTheme

enum class BankingNavSection(val label: String) {
    HOME("Home"),
    ACCOUNTS("Accounts"),
    PAYMENTS("Payments"),
    INSIGHTS("Insights"),
    CARDS("Cards")
}

class MainActivity : ComponentActivity() {

    private val viewModel: BarclaysViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BarclaysTheme {
                BarclaysMainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun BarclaysMainApp(viewModel: BarclaysViewModel) {
    var currentSection by remember { mutableStateOf(BankingNavSection.HOME) }
    var paymentsInitialTab by remember { mutableIntStateOf(0) }

    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val accounts by viewModel.accounts.collectAsStateWithLifecycle()
    val isPrivacyMasked by viewModel.privacyHideBalances.collectAsStateWithLifecycle()
    val activeReceipt by viewModel.activeReceipt.collectAsStateWithLifecycle()

    val unreadNotifs = notifications.count { !it.isRead }

    // Dialog & Sheet States
    var showNotificationSheet by remember { mutableStateOf(false) }
    var showProfileSheet by remember { mutableStateOf(false) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var showStatementsDialog by remember { mutableStateOf(false) }
    var showNewGoalDialog by remember { mutableStateOf(false) }

    // Back navigation handling
    BackHandler(enabled = currentSection != BankingNavSection.HOME) {
        currentSection = BankingNavSection.HOME
    }

    Scaffold(
        topBar = {
            BarclaysHeader(
                unreadNotificationCount = unreadNotifs,
                isPrivacyMasked = isPrivacyMasked,
                onTogglePrivacy = { viewModel.togglePrivacyMask() },
                onOpenNotifications = { showNotificationSheet = true },
                onOpenSearch = { showSearchDialog = true },
                onOpenProfile = { showProfileSheet = true }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = BarclaysNavyDeep,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("bottom_nav_bar")
            ) {
                BankingNavSection.entries.forEach { section ->
                    val isSelected = currentSection == section
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            currentSection = section
                            if (section == BankingNavSection.PAYMENTS) {
                                paymentsInitialTab = 0
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = when (section) {
                                    BankingNavSection.HOME -> if (isSelected) Icons.Filled.Home else Icons.Outlined.Home
                                    BankingNavSection.ACCOUNTS -> if (isSelected) Icons.Filled.AccountBalance else Icons.Outlined.AccountBalance
                                    BankingNavSection.PAYMENTS -> if (isSelected) Icons.Filled.Send else Icons.Outlined.Send
                                    BankingNavSection.INSIGHTS -> if (isSelected) Icons.Filled.AutoGraph else Icons.Outlined.AutoGraph
                                    BankingNavSection.CARDS -> if (isSelected) Icons.Filled.CreditCard else Icons.Outlined.CreditCard
                                },
                                contentDescription = section.label
                            )
                        },
                        label = {
                            Text(
                                text = section.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BarclaysNavyDark,
                            selectedTextColor = BarclaysNavyDark,
                            indicatorColor = BarclaysCyan.copy(alpha = 0.25f),
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_item_${section.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentSection) {
                BankingNavSection.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToAccounts = { accId ->
                            viewModel.selectAccount(accId)
                            currentSection = BankingNavSection.ACCOUNTS
                        },
                        onNavigateToPayments = { tabIdx ->
                            paymentsInitialTab = tabIdx
                            currentSection = BankingNavSection.PAYMENTS
                        },
                        onNavigateToCards = {
                            currentSection = BankingNavSection.CARDS
                        },
                        onNavigateToInsights = {
                            currentSection = BankingNavSection.INSIGHTS
                        },
                        onOpenStatements = { showStatementsDialog = true },
                        onOpenNewGoal = { showNewGoalDialog = true },
                        onSelectTransaction = { _ ->
                            currentSection = BankingNavSection.ACCOUNTS
                        }
                    )
                }

                BankingNavSection.ACCOUNTS -> {
                    AccountsScreen(
                        viewModel = viewModel,
                        onNavigateToMove = { _ ->
                            paymentsInitialTab = 1
                            currentSection = BankingNavSection.PAYMENTS
                        },
                        onOpenStatements = { showStatementsDialog = true }
                    )
                }

                BankingNavSection.PAYMENTS -> {
                    PaymentsScreen(
                        viewModel = viewModel,
                        initialTab = paymentsInitialTab
                    )
                }

                BankingNavSection.INSIGHTS -> {
                    InsightsScreen(
                        viewModel = viewModel
                    )
                }

                BankingNavSection.CARDS -> {
                    CardsScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    // Active Receipt Dialog
    activeReceipt?.let { receipt ->
        PaymentReceiptDialog(
            receipt = receipt,
            onDismiss = { viewModel.dismissReceipt() }
        )
    }

    // Modal Sheets
    if (showNotificationSheet) {
        NotificationSheet(
            viewModel = viewModel,
            onDismiss = { showNotificationSheet = false }
        )
    }

    if (showProfileSheet) {
        ProfileAndSecuritySheet(
            viewModel = viewModel,
            onDismiss = { showProfileSheet = false }
        )
    }

    if (showSearchDialog) {
        GlobalSearchDialog(
            viewModel = viewModel,
            onSelectTransaction = { _ ->
                currentSection = BankingNavSection.ACCOUNTS
            },
            onDismiss = { showSearchDialog = false }
        )
    }

    if (showStatementsDialog) {
        StatementDialog(
            onDismiss = { showStatementsDialog = false }
        )
    }

    if (showNewGoalDialog) {
        NewSavingsGoalDialog(
            accounts = accounts,
            onCreateGoal = { accId, title, targetPence, initialPence, months ->
                viewModel.createSavingsGoal(accId, title, targetPence, initialPence, months) {}
            },
            onDismiss = { showNewGoalDialog = false }
        )
    }
}
