package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.Account
import com.example.domain.model.AccountType
import com.example.domain.model.AutoSaveRule
import com.example.domain.model.Budget
import com.example.domain.model.Card
import com.example.domain.model.CardType
import com.example.domain.model.NotificationCategory
import com.example.domain.model.NotificationItem
import com.example.domain.model.Payee
import com.example.domain.model.SavingsGoal
import com.example.domain.model.ScheduledPayment
import com.example.domain.model.ScheduledPaymentType
import com.example.domain.model.Transaction
import com.example.domain.model.TransactionCategory
import com.example.domain.model.TransactionStatus
import com.example.domain.model.TransactionType

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val name: String,
    val accountType: String,
    val sortCode: String,
    val accountNumber: String,
    val availableBalance: Long,
    val bookedBalance: Long,
    val pendingBalance: Long,
    val interestRateApy: Double?,
    val isPrimary: Boolean,
    val overdraftLimit: Long
) {
    fun toDomain(): Account = Account(
        id = id,
        name = name,
        accountType = runCatching { AccountType.valueOf(accountType) }.getOrDefault(AccountType.CURRENT),
        sortCode = sortCode,
        accountNumber = accountNumber,
        availableBalance = availableBalance,
        bookedBalance = bookedBalance,
        pendingBalance = pendingBalance,
        interestRateApy = interestRateApy,
        isPrimary = isPrimary,
        overdraftLimit = overdraftLimit
    )
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val merchantOrPayee: String,
    val amount: Long,
    val timestamp: Long,
    val category: String,
    val status: String,
    val reference: String,
    val type: String,
    val reversalOfTransactionId: String?,
    val idempotencyKey: String,
    val location: String?
) {
    fun toDomain(): Transaction = Transaction(
        id = id,
        accountId = accountId,
        merchantOrPayee = merchantOrPayee,
        amount = amount,
        timestamp = timestamp,
        category = runCatching { TransactionCategory.valueOf(category) }.getOrDefault(TransactionCategory.OTHER),
        status = runCatching { TransactionStatus.valueOf(status) }.getOrDefault(TransactionStatus.COMPLETED),
        reference = reference,
        type = runCatching { TransactionType.valueOf(type) }.getOrDefault(TransactionType.CARD_PURCHASE),
        reversalOfTransactionId = reversalOfTransactionId,
        idempotencyKey = idempotencyKey,
        location = location
    )
}

@Entity(tableName = "payees")
data class PayeeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val sortCode: String,
    val accountNumber: String,
    val bankName: String,
    val avatarInitials: String,
    val lastPaymentDate: Long?,
    val reference: String
) {
    fun toDomain(): Payee = Payee(
        id = id,
        name = name,
        sortCode = sortCode,
        accountNumber = accountNumber,
        bankName = bankName,
        avatarInitials = avatarInitials,
        lastPaymentDate = lastPaymentDate,
        reference = reference
    )
}

@Entity(tableName = "cards")
data class CardEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val cardholderName: String,
    val maskedNumber: String,
    val expiry: String,
    val cardType: String,
    val isFrozen: Boolean,
    val contactlessEnabled: Boolean,
    val onlinePaymentsEnabled: Boolean,
    val atmWithdrawalsEnabled: Boolean,
    val monthlySpendingLimit: Long,
    val currentSpentThisMonth: Long
) {
    fun toDomain(): Card = Card(
        id = id,
        accountId = accountId,
        cardholderName = cardholderName,
        maskedNumber = maskedNumber,
        expiry = expiry,
        cardType = runCatching { CardType.valueOf(cardType) }.getOrDefault(CardType.BARCLAYS_DEBIT),
        isFrozen = isFrozen,
        contactlessEnabled = contactlessEnabled,
        onlinePaymentsEnabled = onlinePaymentsEnabled,
        atmWithdrawalsEnabled = atmWithdrawalsEnabled,
        monthlySpendingLimit = monthlySpendingLimit,
        currentSpentThisMonth = currentSpentThisMonth
    )
}

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val title: String,
    val targetAmount: Long,
    val currentAmount: Long,
    val targetDateMillis: Long,
    val autoSaveRule: String,
    val iconName: String
) {
    fun toDomain(): SavingsGoal = SavingsGoal(
        id = id,
        accountId = accountId,
        title = title,
        targetAmount = targetAmount,
        currentAmount = currentAmount,
        targetDateMillis = targetDateMillis,
        autoSaveRule = runCatching { AutoSaveRule.valueOf(autoSaveRule) }.getOrDefault(AutoSaveRule.NONE),
        iconName = iconName
    )
}

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val id: String,
    val category: String,
    val monthlyLimit: Long,
    val spentThisMonth: Long
) {
    fun toDomain(): Budget = Budget(
        id = id,
        category = runCatching { TransactionCategory.valueOf(category) }.getOrDefault(TransactionCategory.OTHER),
        monthlyLimit = monthlyLimit,
        spentThisMonth = spentThisMonth
    )
}

@Entity(tableName = "scheduled_payments")
data class ScheduledPaymentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val recipient: String,
    val amount: Long,
    val scheduleDescription: String,
    val nextPaymentDateMillis: Long,
    val type: String,
    val isActive: Boolean
) {
    fun toDomain(): ScheduledPayment = ScheduledPayment(
        id = id,
        title = title,
        recipient = recipient,
        amount = amount,
        scheduleDescription = scheduleDescription,
        nextPaymentDateMillis = nextPaymentDateMillis,
        type = runCatching { ScheduledPaymentType.valueOf(type) }.getOrDefault(ScheduledPaymentType.DIRECT_DEBIT),
        isActive = isActive
    )
}

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val timestamp: Long,
    val category: String,
    val isRead: Boolean
) {
    fun toDomain(): NotificationItem = NotificationItem(
        id = id,
        title = title,
        message = message,
        timestamp = timestamp,
        category = runCatching { NotificationCategory.valueOf(category) }.getOrDefault(NotificationCategory.ALL),
        isRead = isRead
    )
}
