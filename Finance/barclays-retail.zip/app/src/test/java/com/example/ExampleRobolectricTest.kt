package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.BarclaysDatabase
import com.example.data.local.BarclaysRepository
import com.example.data.local.PaymentResult
import com.example.domain.model.TransactionStatus
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var database: BarclaysDatabase
    private lateinit var repository: BarclaysRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, BarclaysDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = BarclaysRepository(database)
        runBlocking {
            repository.resetDemoData()
        }
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testAppNameResourceMatchesBarclaysRetail() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Barclays Retail", appName)
    }

    @Test
    fun testInitialSeedDataReconciles() = runBlocking {
        val accounts = repository.accounts.first()
        assertTrue(accounts.isNotEmpty())
        val currentAcc = accounts.first { it.id == "acc_current" }
        assertEquals(342050L, currentAcc.availableBalance)
        assertEquals(354550L, currentAcc.bookedBalance)
        assertEquals(12500L, currentAcc.totalPendingCommitments)

        val transactions = repository.transactions.first()
        assertTrue(transactions.size >= 10)
    }

    @Test
    fun testAtomicTransferBetweenAccounts() = runBlocking {
        val accountsBefore = repository.accounts.first()
        val currentBefore = accountsBefore.first { it.id == "acc_current" }
        val savingsBefore = accountsBefore.first { it.id == "acc_savings" }

        val transferAmount = 50000L // £500.00
        val result = repository.transferBetweenAccounts(
            sourceAccountId = currentBefore.id,
            destinationAccountId = savingsBefore.id,
            amountPence = transferAmount,
            reference = "MONTHLY-SAVINGS"
        )

        assertTrue(result is PaymentResult.Success)

        val accountsAfter = repository.accounts.first()
        val currentAfter = accountsAfter.first { it.id == "acc_current" }
        val savingsAfter = accountsAfter.first { it.id == "acc_savings" }

        // Source debited atomically
        assertEquals(currentBefore.availableBalance - transferAmount, currentAfter.availableBalance)
        // Destination credited atomically
        assertEquals(savingsBefore.availableBalance + transferAmount, savingsAfter.availableBalance)

        // Verifying ledger entries created
        val transactions = repository.transactions.first()
        val debitTx = transactions.firstOrNull { it.accountId == currentBefore.id && it.amount == -transferAmount }
        val creditTx = transactions.firstOrNull { it.accountId == savingsBefore.id && it.amount == transferAmount }
        assertNotNull(debitTx)
        assertNotNull(creditTx)
    }

    @Test
    fun testTransactionReversalIntegrity() = runBlocking {
        val accountsBefore = repository.accounts.first()
        val currentBefore = accountsBefore.first { it.id == "acc_current" }

        val txToReverse = repository.transactions.first().first { it.id == "tx_4" } // Dishoom £78.50
        val reversalSuccess = repository.reverseTransaction(txToReverse.id)
        assertTrue(reversalSuccess)

        // Verify original status is REVERSED
        val updatedTransactions = repository.transactions.first()
        val reversedOriginal = updatedTransactions.first { it.id == txToReverse.id }
        assertEquals(TransactionStatus.REVERSED, reversedOriginal.status)

        // Verify balance was credited back with inverted amount
        val currentAfter = repository.accounts.first().first { it.id == "acc_current" }
        assertEquals(currentBefore.availableBalance - txToReverse.amount, currentAfter.availableBalance)
    }

    @Test
    fun testCardFreezePersistence() = runBlocking {
        val cardsBefore = repository.cards.first()
        val card = cardsBefore.first()
        assertFalse(card.isFrozen)

        // Freeze
        repository.setCardFreeze(card.id, true)
        val cardsFrozen = repository.cards.first()
        assertTrue(cardsFrozen.first { it.id == card.id }.isFrozen)

        // Unfreeze
        repository.setCardFreeze(card.id, false)
        val cardsUnfrozen = repository.cards.first()
        assertFalse(cardsUnfrozen.first { it.id == card.id }.isFrozen)
    }
}
