package com.example

import com.example.domain.model.Money
import com.example.domain.model.Transaction
import com.example.domain.model.TransactionCategory
import com.example.domain.model.TransactionStatus
import com.example.domain.model.TransactionType
import com.example.domain.service.FinancialInsightsService
import com.example.domain.service.LoanCalculatorService
import com.example.domain.service.PaymentValidationResult
import com.example.domain.service.PaymentValidationService
import com.example.domain.service.SavingsProjectionService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BarclaysFinancialArithmeticTest {

    @Test
    fun testMoneyFormatting() {
        assertEquals("£1,250.50", Money.formatPence(125050L))
        assertEquals("-£42.00", Money.formatPence(-4200L))
        assertEquals("+£500.00", Money.formatPence(50000L, includeSign = true))
        assertEquals("£0.00", Money.formatPence(0L))
    }

    @Test
    fun testMoneyParsing() {
        assertEquals(4550L, Money.parseToPence("45.50"))
        assertEquals(4500L, Money.parseToPence("45"))
        assertEquals(125000L, Money.parseToPence("£1,250.00"))
        assertEquals(null, Money.parseToPence("abc"))
        assertEquals(null, Money.parseToPence("-50"))
    }

    @Test
    fun testSufficientFundsWithOverdraft() {
        // Available £100, payment £150, overdraft £100 -> total £200 >= £150 (true)
        assertTrue(Money.hasSufficientFunds(10000L, 15000L, 10000L))

        // Available £100, payment £250, overdraft £100 -> total £200 < £250 (false)
        assertFalse(Money.hasSufficientFunds(10000L, 25000L, 10000L))
    }

    @Test
    fun testSavingsProjectionCalculation() {
        val initialPence = 100000L // £1,000.00
        val monthlyPence = 10000L  // £100.00
        val apy = 5.0
        val years = 3

        val result = SavingsProjectionService.calculateProjection(initialPence, monthlyPence, apy, years)

        // Total principal = £1,000 + (36 * £100) = £4,600.00 = 460000L
        assertEquals(460000L, result.totalPrincipalContributed)
        assertTrue(result.finalBalance > result.totalPrincipalContributed)
        assertTrue(result.totalInterestEarned > 0L)
        assertEquals(result.finalBalance - result.totalPrincipalContributed, result.totalInterestEarned)
        assertEquals(3, result.yearlyBreakdown.size)
    }

    @Test
    fun testLoanAmortizationCalculation() {
        val principal = 1000000L // £10,000.00
        val apr = 6.9
        val termMonths = 36

        val result = LoanCalculatorService.calculateLoanRepayment(principal, apr, termMonths)

        // Monthly payment should be approx £308.31 (30831 pence)
        assertTrue(result.monthlyPaymentPence > 30000L && result.monthlyPaymentPence < 32000L)
        assertEquals(result.monthlyPaymentPence * termMonths, result.totalRepaymentPence)
        assertTrue(result.totalInterestPence > 0L)
    }

    @Test
    fun testPaymentValidation() {
        // Valid
        val valid = PaymentValidationService.validatePayment(
            payeeName = "Sarah Jenkins",
            sortCode = "20-04-15",
            accountNumber = "73829104",
            amountPence = 5000L,
            availableBalancePence = 10000L,
            overdraftLimitPence = 5000L
        )
        assertTrue(valid is PaymentValidationResult.Valid)

        // Invalid sort code
        val invalidSort = PaymentValidationService.validatePayment(
            payeeName = "Sarah Jenkins",
            sortCode = "20-04",
            accountNumber = "73829104",
            amountPence = 5000L,
            availableBalancePence = 10000L
        )
        assertTrue(invalidSort is PaymentValidationResult.Error)
        assertEquals(PaymentValidationResult.Field.SORT_CODE, (invalidSort as PaymentValidationResult.Error).field)

        // Insufficient funds
        val insufficient = PaymentValidationService.validatePayment(
            payeeName = "Sarah Jenkins",
            sortCode = "20-04-15",
            accountNumber = "73829104",
            amountPence = 50000L,
            availableBalancePence = 10000L,
            overdraftLimitPence = 0L
        )
        assertTrue(insufficient is PaymentValidationResult.Error)
        assertEquals(PaymentValidationResult.Field.FUNDS, (insufficient as PaymentValidationResult.Error).field)
    }

    @Test
    fun testMerchantCategorisation() {
        assertEquals(TransactionCategory.GROCERIES, FinancialInsightsService.categoriseMerchant("Waitrose & Partners"))
        assertEquals(TransactionCategory.TRANSPORT, FinancialInsightsService.categoriseMerchant("Transport for London TfL"))
        assertEquals(TransactionCategory.BILLS, FinancialInsightsService.categoriseMerchant("British Gas Energy"))
        assertEquals(TransactionCategory.RESTAURANTS, FinancialInsightsService.categoriseMerchant("Dishoom Shoreditch"))
        assertEquals(TransactionCategory.SHOPPING, FinancialInsightsService.categoriseMerchant("Amazon UK Marketplace"))
        assertEquals(TransactionCategory.ENTERTAINMENT, FinancialInsightsService.categoriseMerchant("Spotify Premium"))
    }
}
