package com.example.euronext.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.euronext.data.EuronextRepository
import com.example.euronext.data.SyntheticEuronextProvider
import com.example.euronext.engine.EuropeanTaxEngine
import com.example.euronext.engine.MatchingEngine
import com.example.euronext.engine.SmartOrderRouter
import com.example.euronext.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class TerminalTab {
    MARKETS,
    SECURITIES,
    ORDER_BOOK,
    INDICES,
    DERIVATIVES,
    CLEARING_CSD,
    SURVEILLANCE_RISK,
    DIGITAL_TWIN,
    DEVELOPER_API
}

class EuronextTerminalViewModel : ViewModel() {

    private val repository = EuronextRepository(viewModelScope)

    private val _currentTab = MutableStateFlow(TerminalTab.MARKETS)
    val currentTab: StateFlow<TerminalTab> = _currentTab.asStateFlow()

    private val _currentLanguage = MutableStateFlow(AppLanguage.EN)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    val markets = repository.markets
    val selectedMarket = repository.selectedMarket
    val securities = repository.securities
    val selectedSecurity = repository.selectedSecurity
    val indices = repository.indices
    val bonds = repository.bonds
    val powerContracts = repository.powerContracts
    val fxRates = repository.fxRates
    val clearingPositions = repository.clearingPositions
    val marginSummary = repository.marginSummary
    val settlementInstructions = repository.settlementInstructions
    val surveillanceAlerts = repository.surveillanceAlerts
    val circuitBreakers = repository.circuitBreakers
    val currentOrderBook = repository.currentOrderBook
    val recentTrades = repository.recentTrades

    // Command palette state
    private val _isCommandPaletteOpen = MutableStateFlow(false)
    val isCommandPaletteOpen: StateFlow<Boolean> = _isCommandPaletteOpen.asStateFlow()

    private val _commandInput = MutableStateFlow("")
    val commandInput: StateFlow<String> = _commandInput.asStateFlow()

    private val _terminalConsoleMessage = MutableStateFlow("SYSTEM READY: Optiq® Trading & Clearing Core Online. 7 Active Markets + Athens 2027 Roadmap.")
    val terminalConsoleMessage: StateFlow<String> = _terminalConsoleMessage.asStateFlow()

    // Provenance modal state
    private val _inspectingProvenance = MutableStateFlow<ProvenanceRecord?>(null)
    val inspectingProvenance: StateFlow<ProvenanceRecord?> = _inspectingProvenance.asStateFlow()

    // Trade trace modal
    private val _inspectingTrade = MutableStateFlow<Trade?>(null)
    val inspectingTrade: StateFlow<Trade?> = _inspectingTrade.asStateFlow()

    // Order entry ticket
    private val _orderSide = MutableStateFlow(OrderSide.BUY)
    val orderSide: StateFlow<OrderSide> = _orderSide.asStateFlow()

    private val _orderType = MutableStateFlow(OrderType.LIMIT)
    val orderType: StateFlow<OrderType> = _orderType.asStateFlow()

    private val _orderPrice = MutableStateFlow("688.50")
    val orderPrice: StateFlow<String> = _orderPrice.asStateFlow()

    private val _orderQuantity = MutableStateFlow("500")
    val orderQuantity: StateFlow<String> = _orderQuantity.asStateFlow()

    // Custom index builder state
    private val _customIndexName = MutableStateFlow("Euronext High Yield 30")
    val customIndexName: StateFlow<String> = _customIndexName.asStateFlow()

    // Replay mode state
    private val _replayTime = MutableStateFlow("09:30:00 CET")
    val replayTime: StateFlow<String> = _replayTime.asStateFlow()

    private val _isReplayPlaying = MutableStateFlow(false)
    val isReplayPlaying: StateFlow<Boolean> = _isReplayPlaying.asStateFlow()

    fun selectTab(tab: TerminalTab) {
        _currentTab.value = tab
    }

    fun setLanguage(lang: AppLanguage) {
        _currentLanguage.value = lang
    }

    fun selectMarket(marketId: MarketId) {
        repository.selectMarket(marketId)
        _terminalConsoleMessage.value = "MARKET SWITCH: Active Market Context set to ${marketId.name} (${marketId.cityName})"
    }

    fun selectSecurity(security: Security) {
        repository.updateSelectedSecurity(security)
        _orderPrice.value = String.format("%.2f", security.currentPrice)
        _terminalConsoleMessage.value = "SECURITY MASTER: Loaded ${security.ticker} (${security.isin}) [${security.mic}]"
    }

    fun setCommandPaletteOpen(open: Boolean) {
        _isCommandPaletteOpen.value = open
    }

    fun setCommandInput(cmd: String) {
        _commandInput.value = cmd
    }

    fun executeCommand(command: String) {
        val trimmed = command.trim().uppercase()
        _isCommandPaletteOpen.value = false
        _commandInput.value = ""

        when {
            trimmed == "CAC40" || trimmed == "CAC" -> {
                _currentTab.value = TerminalTab.INDICES
                _terminalConsoleMessage.value = "NAVIGATED TO INDEX: CAC 40® (Paris)"
            }
            trimmed == "AEX" -> {
                _currentTab.value = TerminalTab.INDICES
                _terminalConsoleMessage.value = "NAVIGATED TO INDEX: AEX-Index® (Amsterdam)"
            }
            trimmed == "MIB" || trimmed == "FTSEMIB" -> {
                _currentTab.value = TerminalTab.INDICES
                _terminalConsoleMessage.value = "NAVIGATED TO INDEX: FTSE MIB® (Milan)"
            }
            trimmed.startsWith("BOOK") -> {
                val tickerPart = trimmed.removePrefix("BOOK").trim()
                val sec = securities.value.find { it.ticker.equals(tickerPart, ignoreCase = true) }
                if (sec != null) selectSecurity(sec)
                _currentTab.value = TerminalTab.ORDER_BOOK
                _terminalConsoleMessage.value = "OPENED ORDER BOOK FOR $tickerPart"
            }
            trimmed.startsWith("MKT") || trimmed.startsWith("MARKET") -> {
                val code = trimmed.split(" ").lastOrNull() ?: "PAR"
                selectMarket(MarketId.fromCode(code))
                _currentTab.value = TerminalTab.MARKETS
            }
            trimmed == "CLEARING" || trimmed == "CCP" -> {
                _currentTab.value = TerminalTab.CLEARING_CSD
                _terminalConsoleMessage.value = "OPENED EURONEXT CLEARING & POST-TRADE"
            }
            trimmed == "SETTLE" || trimmed == "CSD" -> {
                _currentTab.value = TerminalTab.CLEARING_CSD
                _terminalConsoleMessage.value = "OPENED 2026 EURONEXT SECURITIES CSD CONTROLS"
            }
            trimmed == "SURVEILLANCE" || trimmed == "RISK" -> {
                _currentTab.value = TerminalTab.SURVEILLANCE_RISK
                _terminalConsoleMessage.value = "OPENED MARKET SURVEILLANCE & FACTOR LAB"
            }
            trimmed == "API" || trimmed == "DEV" -> {
                _currentTab.value = TerminalTab.DEVELOPER_API
                _terminalConsoleMessage.value = "OPENED EURONEXT MARKET API & SDK PORTAL"
            }
            trimmed == "REPLAY" || trimmed == "TWIN" -> {
                _currentTab.value = TerminalTab.DIGITAL_TWIN
                _terminalConsoleMessage.value = "OPENED DIGITAL TWIN TIME-TRAVEL REPLAY"
            }
            else -> {
                val foundSec = securities.value.find { it.ticker.equals(trimmed, ignoreCase = true) }
                if (foundSec != null) {
                    selectSecurity(foundSec)
                    _currentTab.value = TerminalTab.ORDER_BOOK
                    _terminalConsoleMessage.value = "LOADED SECURITY: ${foundSec.ticker}"
                } else {
                    _terminalConsoleMessage.value = "COMMAND EXECUTED: $trimmed"
                }
            }
        }
    }

    fun setOrderSide(side: OrderSide) {
        _orderSide.value = side
    }

    fun setOrderType(type: OrderType) {
        _orderType.value = type
    }

    fun setOrderPrice(price: String) {
        _orderPrice.value = price
    }

    fun setOrderQuantity(qty: String) {
        _orderQuantity.value = qty
    }

    fun submitOrder(): MatchingEngine.MatchResult? {
        val sec = selectedSecurity.value
        val p = _orderPrice.value.toDoubleOrNull() ?: sec.currentPrice
        val q = _orderQuantity.value.toLongOrNull() ?: 100L

        val order = Order(
            securityId = sec.isin,
            ticker = sec.ticker,
            isin = sec.isin,
            market = sec.primaryMarket,
            side = _orderSide.value,
            orderType = _orderType.value,
            price = p,
            quantity = q,
            clientAccount = "INSTITUTIONAL-DESK-PAR-01"
        )

        val result = repository.submitOrder(order)
        if (result.executedTrades.isNotEmpty()) {
            val totalMatched = result.executedTrades.sumOf { it.quantity }
            _terminalConsoleMessage.value = "TRADE EXECUTED: ${result.executedTrades.size} fill(s) total $totalMatched shares @ €${String.format("%.2f", result.executedTrades.first().executionPrice)} -> Routed to Euronext Clearing & Euronext Securities CSD."
        } else if (result.circuitBreakerTriggered != null) {
            _terminalConsoleMessage.value = "CIRCUIT BREAKER: Volatility interruption triggered for ${sec.ticker} at €$p! Order rejected."
        } else {
            _terminalConsoleMessage.value = "ORDER RESTING: Order ${order.orderId} queued in book at €$p for $q shares."
        }
        return result
    }

    fun applyMacroScenario(scenario: MacroScenario) {
        repository.applyMacroScenario(scenario)
        _terminalConsoleMessage.value = "STRESS SCENARIO APPLIED: ${scenario.name} (Margin requirement increased by ${scenario.ccpMarginIncreasePct}%)"
    }

    fun inspectProvenance(provenance: ProvenanceRecord) {
        _inspectingProvenance.value = provenance
    }

    fun closeProvenance() {
        _inspectingProvenance.value = null
    }

    fun inspectTrade(trade: Trade) {
        _inspectingTrade.value = trade
    }

    fun closeTrade() {
        _inspectingTrade.value = null
    }
}
