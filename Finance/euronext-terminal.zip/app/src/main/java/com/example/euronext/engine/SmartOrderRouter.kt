package com.example.euronext.engine

import com.example.euronext.model.MarketId
import com.example.euronext.model.OrderSide

data class MarketRouteQuote(
    val market: MarketId,
    val mic: String,
    val currency: String,
    val rawPrice: Double,
    val fxRateToEur: Double,
    val priceEur: Double,
    val availableDepth: Long,
    val exchangeFeeBps: Double,
    val clearingSettlementFeeEur: Double,
    val estimatedLatencyMicrosec: Int,
    val estimatedMarketImpactBps: Double,
    val netEffectivePriceEur: Double
)

data class BestExecutionRoute(
    val recommendedMarket: MarketId,
    val side: OrderSide,
    val requestedQuantity: Long,
    val bestNetPriceEur: Double,
    val priceImprovementBps: Double,
    val routeQuotes: List<MarketRouteQuote>,
    val executionSummary: String
)

object SmartOrderRouter {

    fun computeBestRoute(
        ticker: String,
        side: OrderSide,
        quantity: Long,
        quotes: List<MarketRouteQuote>
    ): BestExecutionRoute {
        val sorted = if (side == OrderSide.BUY) {
            quotes.sortedBy { it.netEffectivePriceEur }
        } else {
            quotes.sortedByDescending { it.netEffectivePriceEur }
        }

        val best = sorted.firstOrNull() ?: quotes.first()
        val secondBest = sorted.getOrNull(1)

        val improvementBps = if (secondBest != null && best.priceEur > 0) {
            val diff = if (side == OrderSide.BUY) secondBest.netEffectivePriceEur - best.netEffectivePriceEur else best.netEffectivePriceEur - secondBest.netEffectivePriceEur
            (diff / best.priceEur) * 10000.0
        } else 0.0

        val summary = "Optiq® Smart Order Router selected ${best.market.cityName} (${best.mic}) yielding €${String.format("%.3f", best.netEffectivePriceEur)} net effective price (${String.format("%.1f", improvementBps)} bps improvement over secondary venue)."

        return BestExecutionRoute(
            recommendedMarket = best.market,
            side = side,
            requestedQuantity = quantity,
            bestNetPriceEur = best.netEffectivePriceEur,
            priceImprovementBps = improvementBps,
            routeQuotes = sorted,
            executionSummary = summary
        )
    }
}
