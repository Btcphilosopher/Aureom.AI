package com.example.euronext.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.euronext.model.*
import com.example.euronext.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun MarketControlRoomScreen(
    markets: List<EuronextMarket>,
    selectedMarket: EuronextMarket,
    onMarketSelected: (MarketId) -> Unit,
    onInspectProvenance: (ProvenanceRecord) -> Unit,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Pan-European Control Banner
        item {
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = TerminalStrings.get("pan_european_control", language),
                                color = TerminalNavyPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "One Computational Infrastructure // Single Trading Platform // Harmonised & Local Rules",
                                color = TerminalTextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        ProvenanceBadge(
                            provenance = ProvenanceRecord(market = selectedMarket.marketId, dataStatus = DataStatus.SYNTHETIC),
                            onClick = { onInspectProvenance(ProvenanceRecord(market = selectedMarket.marketId, dataStatus = DataStatus.SYNTHETIC)) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = TerminalCardBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    // System Grid Status
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SystemStatusPill("MATCHING (OPTIQ®)", "NOMINAL", TerminalStatusGreen)
                        SystemStatusPill("MARKET DATA FEED", "1.2M msg/s", TerminalTealMarket)
                        SystemStatusPill("CCP NOVATION", "ACTIVE", TerminalStatusGreen)
                        SystemStatusPill("2026 CSD ROUTING", "ONLINE", TerminalStatusGreen)
                    }
                }
            }
        }

        // Active Market Selected Detail Card
        item {
            Surface(
                color = Color(0xFF131D33),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${selectedMarket.marketName.uppercase()} [${selectedMarket.mic}]",
                                color = TerminalTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            if (selectedMarket.isIntegrationScheduled) {
                                Surface(
                                    color = Color(0x33F59E0B),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "INTEGRATION ROADMAP JUNE 2027",
                                        color = TerminalGoldAccent,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "${selectedMarket.currency} // ${selectedMarket.city}, ${selectedMarket.country}",
                            color = TerminalGoldAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Regulatory Authority:", color = TerminalTextMuted, fontSize = 9.sp)
                            Text(selectedMarket.regulatoryJurisdiction, color = TerminalTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Column {
                            Text("Local Rulebook:", color = TerminalTextMuted, fontSize = 9.sp)
                            Text(selectedMarket.localRulebook, color = TerminalTextSecondary, fontSize = 10.sp, maxLines = 1)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricBox("BENCHMARK", "${selectedMarket.benchmarkIndex} (${selectedMarket.benchmarkValue})", if (selectedMarket.benchmarkChangePct >= 0) "+${selectedMarket.benchmarkChangePct}%" else "${selectedMarket.benchmarkChangePct}%", Modifier.weight(1f))
                        MetricBox("DAILY TURNOVER", "€${selectedMarket.dailyTurnoverEurM}M", "${selectedMarket.totalTradesToday} Trades", Modifier.weight(1f))
                        MetricBox("OPEN ORDERS", "${selectedMarket.openOrdersCount}", "Optiq Book", Modifier.weight(1f))
                    }
                }
            }
        }

        // Markets Directory List
        item {
            Text(
                text = "EURONEXT REGULATED VENUES & CALENDARS (2026)",
                color = TerminalTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(markets) { market ->
            val isSelected = market.marketId == selectedMarket.marketId
            Surface(
                color = if (isSelected) Color(0xFF162036) else TerminalCardDark,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) TerminalNavyPrimary else TerminalCardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onMarketSelected(market.marketId) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (market.isIntegrationScheduled) TerminalStatusAmber else TerminalStatusGreen)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = market.marketId.code,
                                    color = TerminalGoldAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = market.marketName,
                                    color = TerminalTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "${market.mic} • ${market.timezone} • ${market.clearingModel}",
                                color = TerminalTextMuted,
                                fontSize = 9.sp
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${market.benchmarkIndex} ${market.benchmarkValue}",
                            color = TerminalTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = if (market.benchmarkChangePct >= 0) "+${market.benchmarkChangePct}%" else "${market.benchmarkChangePct}%",
                            color = if (market.benchmarkChangePct >= 0) TerminalStatusGreen else TerminalStatusRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SystemStatusPill(name: String, status: String, color: Color) {
    Column {
        Text(name, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(status, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun MetricBox(title: String, value: String, sub: String, modifier: Modifier = Modifier) {
    Surface(
        color = TerminalSurfaceDark,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(title, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Text(value, color = TerminalTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(sub, color = TerminalNavyPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
