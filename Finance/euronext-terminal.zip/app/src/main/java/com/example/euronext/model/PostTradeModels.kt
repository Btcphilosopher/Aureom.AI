package com.example.euronext.model

import java.util.UUID

enum class CsdVenue(val fullName: String, val isDefaultPost2026: Boolean, val country: String) {
    EURONEXT_SECURITIES("Euronext Securities (Default CSD post-21 Sep 2026)", true, "Pan-European / PT, IT, NO, BE"),
    EUROCLEAR_FRANCE("Euroclear France", false, "France"),
    EUROCLEAR_NEDERLAND("Euroclear Nederland", false, "Netherlands"),
    EUROCLEAR_BELGIUM("Euroclear Belgium", false, "Belgium"),
    EUROCLEAR_BANK("Euroclear Bank (ICSD)", false, "International"),
    CLEARSTREAM_EUROPE_AG("Clearstream Europe AG", false, "Germany / Europe")
}

enum class SettlementStatus {
    PENDING,
    MATCHED,
    SETTLED,
    FAILED,
    PARTIALLY_SETTLED,
    CANCELLED
}

data class ClearingPosition(
    val memberId: String,
    val memberName: String,
    val isin: String,
    val ticker: String,
    val market: MarketId,
    val netQuantity: Long, // positive for long, negative for short
    val averageCostEur: Double,
    val unrealisedPnlEur: Double,
    val initialMarginEur: Double,
    val variationMarginEur: Double,
    val concentrationAddonEur: Double,
    val novationReference: String
)

data class MarginSummary(
    val totalInitialMarginEur: Double,
    val totalVariationMarginEur: Double,
    val stressMarginAddonEur: Double,
    val liquidityConcentrationAddonEur: Double,
    val totalMarginRequirementEur: Double,
    val eligibleCollateralPostedEur: Double,
    val marginCoverageRatioPct: Double,
    val defaultFundShareEur: Double,
    val marginCallStatus: String = "ADEQUATE"
)

data class CollateralHolding(
    val assetDescription: String,
    val isin: String,
    val marketValueEur: Double,
    val haircutPct: Double,
    val collateralValueEur: Double,
    val assetCategory: String // Cash, OAT Gov Bond, Bund, Euronext Top 50 Equity
)

data class SettlementInstruction(
    val instructionId: String = "SET-2026-" + UUID.randomUUID().toString().take(6).uppercase(),
    val tradeId: String,
    val isin: String,
    val ticker: String,
    val market: MarketId,
    val settlementDate: String = "T+2 (2026-10-09)",
    val destinationCsd: CsdVenue,
    val deliveringParticipant: String,
    val receivingParticipant: String,
    val quantity: Long,
    val settlementAmountEur: Double,
    val status: SettlementStatus,
    val failReason: String? = null,
    val finalityTimestamp: String? = null,
    val provenance: ProvenanceRecord
)

data class CustodyAccount(
    val accountId: String,
    val clientName: String,
    val csd: CsdVenue,
    val market: MarketId,
    val isin: String,
    val ticker: String,
    val settledBalance: Long,
    val pendingInbound: Long,
    val pendingOutbound: Long,
    val valuationEur: Double
)
