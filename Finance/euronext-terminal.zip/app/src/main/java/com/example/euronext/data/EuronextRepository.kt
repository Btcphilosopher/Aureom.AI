package com.example.euronext.data

import com.example.euronext.engine.MatchingEngine
import com.example.euronext.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

class EuronextRepository(private val scope: CoroutineScope) {

    private val _markets = MutableStateFlow<List<EuronextMarket>>(SyntheticEuronextProvider.getMarkets())
    val markets: StateFlow<List<EuronextMarket>> = _markets.asStateFlow()

    private val _securities = MutableStateFlow<List<Security>>(SyntheticEuronextProvider.getSecurities())
    val securities: StateFlow<List<Security>> = _securities.asStateFlow()

    private val _selectedSecurity = MutableStateFlow<Security>(_securities.value.first())
    val selectedSecurity: StateFlow<Security> = _selectedSecurity.asStateFlow()

    private val _selectedMarket = MutableStateFlow<EuronextMarket>(_markets.value.first())
    val selectedMarket: StateFlow<EuronextMarket> = _selectedMarket.asStateFlow()

    private val _indices = MutableStateFlow<List<IndexState>>(SyntheticEuronextProvider.getIndices())
    val indices: StateFlow<List<IndexState>> = _indices.asStateFlow()

    private val _bonds = MutableStateFlow<List<BondInstrument>>(SyntheticEuronextProvider.getBonds())
    val bonds: StateFlow<List<BondInstrument>> = _bonds.asStateFlow()

    private val _powerContracts = MutableStateFlow<List<EuropeanPowerContract>>(SyntheticEuronextProvider.getPowerContracts())
    val powerContracts: StateFlow<List<EuropeanPowerContract>> = _powerContracts.asStateFlow()

    private val _fxRates = MutableStateFlow<List<FxQuote>>(SyntheticEuronextProvider.getFxRates())
    val fxRates: StateFlow<List<FxQuote>> = _fxRates.asStateFlow()

    private val _clearingPositions = MutableStateFlow<List<ClearingPosition>>(SyntheticEuronextProvider.getClearingPositions())
    val clearingPositions: StateFlow<List<ClearingPosition>> = _clearingPositions.asStateFlow()

    private val _marginSummary = MutableStateFlow<MarginSummary>(SyntheticEuronextProvider.getMarginSummary())
    val marginSummary: StateFlow<MarginSummary> = _marginSummary.asStateFlow()

    private val _settlementInstructions = MutableStateFlow<List<SettlementInstruction>>(SyntheticEuronextProvider.getSettlementInstructions())
    val settlementInstructions: StateFlow<List<SettlementInstruction>> = _settlementInstructions.asStateFlow()

    private val _surveillanceAlerts = MutableStateFlow<List<SurveillanceAlert>>(SyntheticEuronextProvider.getSurveillanceAlerts())
    val surveillanceAlerts: StateFlow<List<SurveillanceAlert>> = _surveillanceAlerts.asStateFlow()

    private val _circuitBreakers = MutableStateFlow<List<CircuitBreakerEvent>>(emptyList())
    val circuitBreakers: StateFlow<List<CircuitBreakerEvent>> = _circuitBreakers.asStateFlow()

    private val _eventLogs = MutableStateFlow<List<EventLogEntry>>(emptyList())
    val eventLogs: StateFlow<List<EventLogEntry>> = _eventLogs.asStateFlow()

    private val matchingEngines = ConcurrentHashMap<String, MatchingEngine>()
    private val _currentOrderBook = MutableStateFlow<OrderBook?>(null)
    val currentOrderBook: StateFlow<OrderBook?> = _currentOrderBook.asStateFlow()

    private val _recentTrades = MutableStateFlow<List<Trade>>(emptyList())
    val recentTrades: StateFlow<List<Trade>> = _recentTrades.asStateFlow()

    init {
        // Initialize matching engines with resting liquidity for each security
        _securities.value.forEach { sec ->
            val engine = MatchingEngine(sec.ticker, sec.isin, sec.primaryMarket, sec.currentPrice)
            // Seed resting orders
            seedLiquidity(engine, sec)
            matchingEngines[sec.ticker] = engine
        }
        updateSelectedSecurity(_securities.value.first())
    }

    private fun seedLiquidity(engine: MatchingEngine, sec: Security) {
        val baseP = sec.currentPrice
        // Seed bids
        engine.submitOrder(Order(securityId = sec.isin, ticker = sec.ticker, isin = sec.isin, market = sec.primaryMarket, side = OrderSide.BUY, orderType = OrderType.LIMIT, price = baseP - 0.10, quantity = 1500, clientAccount = "MEMBER-BNP-PARIBAS"))
        engine.submitOrder(Order(securityId = sec.isin, ticker = sec.ticker, isin = sec.isin, market = sec.primaryMarket, side = OrderSide.BUY, orderType = OrderType.LIMIT, price = baseP - 0.25, quantity = 3200, clientAccount = "MEMBER-SOCIETE-GENERALE"))
        engine.submitOrder(Order(securityId = sec.isin, ticker = sec.ticker, isin = sec.isin, market = sec.primaryMarket, side = OrderSide.BUY, orderType = OrderType.LIMIT, price = baseP - 0.50, quantity = 5800, clientAccount = "MEMBER-ING-BANK"))

        // Seed asks
        engine.submitOrder(Order(securityId = sec.isin, ticker = sec.ticker, isin = sec.isin, market = sec.primaryMarket, side = OrderSide.SELL, orderType = OrderType.LIMIT, price = baseP + 0.10, quantity = 1400, clientAccount = "MEMBER-CREDIT-AGRICOLE"))
        engine.submitOrder(Order(securityId = sec.isin, ticker = sec.ticker, isin = sec.isin, market = sec.primaryMarket, side = OrderSide.SELL, orderType = OrderType.LIMIT, price = baseP + 0.30, quantity = 2800, clientAccount = "MEMBER-INTESA-SANPAOLO"))
        engine.submitOrder(Order(securityId = sec.isin, ticker = sec.ticker, isin = sec.isin, market = sec.primaryMarket, side = OrderSide.SELL, orderType = OrderType.LIMIT, price = baseP + 0.60, quantity = 6400, clientAccount = "MEMBER-DNB-MARKETS"))
    }

    fun selectMarket(marketId: MarketId) {
        val m = _markets.value.find { it.marketId == marketId } ?: return
        _selectedMarket.value = m
    }

    fun updateSelectedSecurity(sec: Security) {
        _selectedSecurity.value = sec
        val engine = matchingEngines[sec.ticker] ?: MatchingEngine(sec.ticker, sec.isin, sec.primaryMarket, sec.currentPrice).also {
            seedLiquidity(it, sec)
            matchingEngines[sec.ticker] = it
        }
        _currentOrderBook.value = engine.getOrderBookSnapshot()
        _recentTrades.value = engine.getTrades()
    }

    fun submitOrder(order: Order): MatchingEngine.MatchResult {
        val engine = matchingEngines[order.ticker] ?: MatchingEngine(order.ticker, order.isin, order.market, order.price).also {
            matchingEngines[order.ticker] = it
        }

        val result = engine.submitOrder(order)
        _currentOrderBook.value = engine.getOrderBookSnapshot()
        _recentTrades.value = engine.getTrades()

        if (result.circuitBreakerTriggered != null) {
            _circuitBreakers.value = listOf(result.circuitBreakerTriggered) + _circuitBreakers.value
        }

        // If trades executed, pipe to clearing & settlement
        if (result.executedTrades.isNotEmpty()) {
            result.executedTrades.forEach { tr ->
                processTradeToClearingAndSettlement(tr)
            }
        }

        return result
    }

    private fun processTradeToClearingAndSettlement(trade: Trade) {
        // Novate into clearing
        val newPos = ClearingPosition(
            memberId = "MEM-BNP-01",
            memberName = trade.buyerParticipant,
            isin = trade.isin,
            ticker = trade.ticker,
            market = trade.market,
            netQuantity = trade.quantity,
            averageCostEur = trade.executionPrice,
            unrealisedPnlEur = 0.0,
            initialMarginEur = trade.valueEur * 0.12,
            variationMarginEur = 0.0,
            concentrationAddonEur = trade.valueEur * 0.02,
            novationReference = trade.clearingRef
        )
        _clearingPositions.value = listOf(newPos) + _clearingPositions.value

        // Post-2026 Euronext Settlement Instruction
        val newSet = SettlementInstruction(
            tradeId = trade.tradeId,
            isin = trade.isin,
            ticker = trade.ticker,
            market = trade.market,
            settlementDate = "T+2 (2026-10-09)",
            destinationCsd = CsdVenue.EURONEXT_SECURITIES,
            deliveringParticipant = trade.sellerParticipant,
            receivingParticipant = trade.buyerParticipant,
            quantity = trade.quantity,
            settlementAmountEur = trade.valueEur,
            status = SettlementStatus.MATCHED,
            provenance = ProvenanceRecord(market = trade.market, dataStatus = DataStatus.SYNTHETIC)
        )
        _settlementInstructions.value = listOf(newSet) + _settlementInstructions.value
    }

    fun applyMacroScenario(scenario: MacroScenario) {
        // Update indices based on scenario shocks
        _indices.value = _indices.value.map { idx ->
            val shockPct = when (idx.indexCode) {
                "CAC40" -> scenario.cac40ShockPct
                "AEX" -> scenario.aexShockPct
                "FTSEMIB" -> scenario.mibShockPct
                "EUROBANKS" -> scenario.banksFactorShockPct
                else -> scenario.cac40ShockPct * 0.8
            }
            val newVal = idx.currentValue * (1.0 + shockPct / 100.0)
            idx.copy(
                currentValue = newVal,
                changePct = idx.changePct + shockPct,
                changePoints = idx.changePoints + (newVal - idx.currentValue)
            )
        }

        // Increase margin requirement at CCP
        val currentMargin = _marginSummary.value
        val mult = 1.0 + (scenario.ccpMarginIncreasePct / 100.0)
        _marginSummary.value = currentMargin.copy(
            totalInitialMarginEur = currentMargin.totalInitialMarginEur * mult,
            stressMarginAddonEur = currentMargin.stressMarginAddonEur * (mult * 1.2),
            totalMarginRequirementEur = currentMargin.totalMarginRequirementEur * mult,
            marginCoverageRatioPct = (currentMargin.eligibleCollateralPostedEur / (currentMargin.totalMarginRequirementEur * mult)) * 100.0,
            marginCallStatus = if (mult > 1.25) "CRITICAL: MARGIN CALL ISSUED (€24.8M DUE)" else "STRESSED (Coverage OK)"
        )
    }
}
