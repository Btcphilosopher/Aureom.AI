package com.example.euronext.model

enum class AppLanguage(val code: String, val displayName: String, val flag: String) {
    EN("en", "English", "🇬🇧"),
    FR("fr", "Français", "🇫🇷"),
    DE("de", "Deutsch", "🇩🇪")
}

object TerminalStrings {
    fun get(key: String, lang: AppLanguage): String {
        return translations[key]?.get(lang) ?: key
    }

    private val translations: Map<String, Map<AppLanguage, String>> = mapOf(
        "app_title" to mapOf(
            AppLanguage.EN to "EURONEXT // TERMINAL",
            AppLanguage.FR to "EURONEXT // TERMINAL",
            AppLanguage.DE to "EURONEXT // TERMINAL"
        ),
        "tagline" to mapOf(
            AppLanguage.EN to "One Europe. Many Markets. One Computational Infrastructure.",
            AppLanguage.FR to "Une Europe. Plusieurs Marchés. Une Infrastructure Computationnelle.",
            AppLanguage.DE to "Ein Europa. Viele Märkte. Eine Recheninfrastruktur."
        ),
        "tab_markets" to mapOf(
            AppLanguage.EN to "MARKETS",
            AppLanguage.FR to "MARCHÉS",
            AppLanguage.DE to "MÄRKTE"
        ),
        "tab_securities" to mapOf(
            AppLanguage.EN to "SECURITIES",
            AppLanguage.FR to "VALEURS",
            AppLanguage.DE to "WERTPAPIERE"
        ),
        "tab_orderbook" to mapOf(
            AppLanguage.EN to "ORDER BOOK",
            AppLanguage.FR to "CARNET D'ORDRES",
            AppLanguage.DE to "AUFTRAGSBUCH"
        ),
        "tab_indices" to mapOf(
            AppLanguage.EN to "INDICES",
            AppLanguage.FR to "INDICES",
            AppLanguage.DE to "INDIZES"
        ),
        "tab_derivatives" to mapOf(
            AppLanguage.EN to "DERIVATIVES & BONDS",
            AppLanguage.FR to "DÉRIVÉS & OBLIGATIONS",
            AppLanguage.DE to "DERIVATE & ANLEIHEN"
        ),
        "tab_clearing" to mapOf(
            AppLanguage.EN to "CLEARING & CSD",
            AppLanguage.FR to "COMPENSATION & CSD",
            AppLanguage.DE to "CLEARING & CSD"
        ),
        "tab_surveillance" to mapOf(
            AppLanguage.EN to "SURVEILLANCE & RISK",
            AppLanguage.FR to "SURVEILLANCE & RISQUE",
            AppLanguage.DE to "ÜBERWACHUNG & RISIKO"
        ),
        "tab_replay" to mapOf(
            AppLanguage.EN to "DIGITAL TWIN REPLAY",
            AppLanguage.FR to "REJEU JUMEAU NUMÉRIQUE",
            AppLanguage.DE to "DIGITALER ZWILLING REPLAY"
        ),
        "tab_api" to mapOf(
            AppLanguage.EN to "DEVELOPER API",
            AppLanguage.FR to "API DÉVELOPPEUR",
            AppLanguage.DE to "ENTWICKLER-API"
        ),
        "cmd_placeholder" to mapOf(
            AppLanguage.EN to "Type Command (e.g. CAC40, AEX, BOOK MC, MKT PAR, CLEARING, SETTLE)...",
            AppLanguage.FR to "Entrez commande (ex. CAC40, AEX, BOOK MC, MKT PAR, CLEARING, SETTLE)...",
            AppLanguage.DE to "Befehl eingeben (z.B. CAC40, AEX, BOOK MC, MKT PAR, CLEARING, SETTLE)..."
        ),
        "pan_european_control" to mapOf(
            AppLanguage.EN to "PAN-EUROPEAN MARKET CONTROL ROOM",
            AppLanguage.FR to "SALLE DE CONTRÔLE PAN-EUROPÉENNE",
            AppLanguage.DE to "PAN-EUROPÄISCHER KONTROLLRAUM"
        ),
        "trading_engine" to mapOf(
            AppLanguage.EN to "OPTIQ® SYNTHETIC MATCHING ENGINE",
            AppLanguage.FR to "MOTEUR D'APPARIEMENT SYNTHÉTIQUE OPTIQ®",
            AppLanguage.DE to "OPTIQ® SYNTHETISCHE MATCHING-ENGINE"
        ),
        "buy" to mapOf(
            AppLanguage.EN to "BUY / ACHAT",
            AppLanguage.FR to "ACHETER",
            AppLanguage.DE to "KAUFEN"
        ),
        "sell" to mapOf(
            AppLanguage.EN to "SELL / VENTE",
            AppLanguage.FR to "VENDRE",
            AppLanguage.DE to "VERKAUFEN"
        ),
        "provenance_badge" to mapOf(
            AppLanguage.EN to "SYNTHETIC DIGITAL TWIN",
            AppLanguage.FR to "JUMEAU NUMÉRIQUE SYNTHÉTIQUE",
            AppLanguage.DE to "SYNTHETISCHER DIGITALER ZWILLING"
        )
    )
}
