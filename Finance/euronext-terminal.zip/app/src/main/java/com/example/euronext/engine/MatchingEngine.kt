package com.example.euronext.engine

import com.example.euronext.model.*
import java.util.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MatchingEngine(
    val ticker: String,
    val isin: String,
    val market: MarketId,
    var referencePrice: Double
) {
    private val buyOrders = PriorityQueue<Order> { a, b ->
        val priceCmp = b.price.compareTo(a.price) // Highest price first
        if (priceCmp != 0) priceCmp else a.timestampNano.compareTo(b.timestampNano) // Earlier first
    }

    private val sellOrders = PriorityQueue<Order> { a, b ->
        val priceCmp = a.price.compareTo(b.price) // Lowest price first
        if (priceCmp != 0) priceCmp else a.timestampNano.compareTo(b.timestampNano) // Earlier first
    }

    private val tradesHistory = mutableListOf<Trade>()
    private val eventLog = mutableListOf<EventLogEntry>()
    private var sequenceNumber = 1000L
    private var isHalted = false
    private var dynamicCollarMin = referencePrice * 0.98
    private var dynamicCollarMax = referencePrice * 1.02
    private var staticCollarMin = referencePrice * 0.95
    private var staticCollarMax = referencePrice * 1.05

    data class MatchResult(
        val executedTrades: List<Trade>,
        val restingOrder: Order?,
        val circuitBreakerTriggered: CircuitBreakerEvent?
    )

    @Synchronized
    fun submitOrder(order: Order): MatchResult {
        sequenceNumber++
        logEvent("ORDER_SUBMITTED", order.orderId, "Side: ${order.side}, Price: ${order.price}, Qty: ${order.quantity}")

        // Check trading safeguard price collar
        if (order.price > 0 && (order.price < staticCollarMin || order.price > staticCollarMax)) {
            val cb = CircuitBreakerEvent(
                ticker = ticker,
                market = market,
                triggerPrice = order.price,
                referencePrice = referencePrice,
                deviationPct = ((order.price - referencePrice) / referencePrice) * 100.0,
                bandThresholdPct = 5.0,
                timestamp = order.timestampFormatted
            )
            logEvent("CIRCUIT_BREAKER_TRIPPED", cb.eventId, "Price ${order.price} breached static collar [${staticCollarMin.formatPrice()} - ${staticCollarMax.formatPrice()}]")
            return MatchResult(emptyList(), order.copy(status = OrderStatus.REJECTED), cb)
        }

        val generatedTrades = mutableListOf<Trade>()
        var remainingQty = order.quantity

        if (order.side == OrderSide.BUY) {
            while (remainingQty > 0 && sellOrders.isNotEmpty()) {
                val bestSell = sellOrders.peek() ?: break
                if (order.orderType != OrderType.MARKET && bestSell.price > order.price) {
                    break // No price cross
                }

                sellOrders.poll() // Pop best sell
                val tradePrice = bestSell.price // Maker price sets trade price
                val matchQty = min(remainingQty, bestSell.quantity - bestSell.executedQuantity)

                val trade = Trade(
                    isin = isin,
                    ticker = ticker,
                    market = market,
                    executionPrice = tradePrice,
                    quantity = matchQty,
                    buyerOrderId = order.orderId,
                    sellerOrderId = bestSell.orderId,
                    buyerParticipant = order.clientAccount,
                    sellerParticipant = bestSell.clientAccount,
                    timestamp = order.timestampFormatted,
                    provenance = ProvenanceRecord(market = market, dataStatus = DataStatus.SYNTHETIC)
                )
                generatedTrades.add(trade)
                tradesHistory.add(0, trade)
                referencePrice = tradePrice
                updateCollars(tradePrice)

                logEvent("TRADE_EXECUTED", trade.tradeId, "Price: $tradePrice, Qty: $matchQty, Value: €${trade.valueEur}")

                val newBestSellExecuted = bestSell.executedQuantity + matchQty
                if (newBestSellExecuted < bestSell.quantity) {
                    sellOrders.add(bestSell.copy(executedQuantity = newBestSellExecuted, status = OrderStatus.PARTIALLY_FILLED))
                }
                remainingQty -= matchQty
            }

            val finalStatus = if (remainingQty == 0L) OrderStatus.FILLED else if (remainingQty < order.quantity) OrderStatus.PARTIALLY_FILLED else OrderStatus.NEW
            val resting = order.copy(executedQuantity = order.quantity - remainingQty, status = finalStatus)
            if (remainingQty > 0 && order.orderType != OrderType.MARKET) {
                buyOrders.add(resting)
            }
            return MatchResult(generatedTrades, resting, null)
        } else {
            // SELL order matching against buy queue
            while (remainingQty > 0 && buyOrders.isNotEmpty()) {
                val bestBuy = buyOrders.peek() ?: break
                if (order.orderType != OrderType.MARKET && bestBuy.price < order.price) {
                    break
                }

                buyOrders.poll()
                val tradePrice = bestBuy.price
                val matchQty = min(remainingQty, bestBuy.quantity - bestBuy.executedQuantity)

                val trade = Trade(
                    isin = isin,
                    ticker = ticker,
                    market = market,
                    executionPrice = tradePrice,
                    quantity = matchQty,
                    buyerOrderId = bestBuy.orderId,
                    sellerOrderId = order.orderId,
                    buyerParticipant = bestBuy.clientAccount,
                    sellerParticipant = order.clientAccount,
                    timestamp = order.timestampFormatted,
                    provenance = ProvenanceRecord(market = market, dataStatus = DataStatus.SYNTHETIC)
                )
                generatedTrades.add(trade)
                tradesHistory.add(0, trade)
                referencePrice = tradePrice
                updateCollars(tradePrice)

                logEvent("TRADE_EXECUTED", trade.tradeId, "Price: $tradePrice, Qty: $matchQty, Value: €${trade.valueEur}")

                val newBestBuyExecuted = bestBuy.executedQuantity + matchQty
                if (newBestBuyExecuted < bestBuy.quantity) {
                    buyOrders.add(bestBuy.copy(executedQuantity = newBestBuyExecuted, status = OrderStatus.PARTIALLY_FILLED))
                }
                remainingQty -= matchQty
            }

            val finalStatus = if (remainingQty == 0L) OrderStatus.FILLED else if (remainingQty < order.quantity) OrderStatus.PARTIALLY_FILLED else OrderStatus.NEW
            val resting = order.copy(executedQuantity = order.quantity - remainingQty, status = finalStatus)
            if (remainingQty > 0 && order.orderType != OrderType.MARKET) {
                sellOrders.add(resting)
            }
            return MatchResult(generatedTrades, resting, null)
        }
    }

    private fun updateCollars(lastPrice: Double) {
        dynamicCollarMin = lastPrice * 0.98
        dynamicCollarMax = lastPrice * 1.02
        staticCollarMin = lastPrice * 0.95
        staticCollarMax = lastPrice * 1.05
    }

    @Synchronized
    fun getOrderBookSnapshot(): OrderBook {
        val buyLevels = buyOrders.toList()
            .groupBy { it.price }
            .map { (p, orders) ->
                PriceLevel(
                    price = p,
                    totalVolume = orders.sumOf { it.quantity - it.executedQuantity },
                    orderCount = orders.size,
                    orders = orders
                )
            }.sortedByDescending { it.price }

        val sellLevels = sellOrders.toList()
            .groupBy { it.price }
            .map { (p, orders) ->
                PriceLevel(
                    price = p,
                    totalVolume = orders.sumOf { it.quantity - it.executedQuantity },
                    orderCount = orders.size,
                    orders = orders
                )
            }.sortedBy { it.price }

        val bestBid = buyLevels.firstOrNull()?.price ?: (referencePrice - 0.05)
        val bestAsk = sellLevels.firstOrNull()?.price ?: (referencePrice + 0.05)
        val bidVol = buyLevels.firstOrNull()?.totalVolume ?: 1000L
        val askVol = sellLevels.firstOrNull()?.totalVolume ?: 1000L
        val spread = max(0.01, bestAsk - bestBid)
        val spreadBps = (spread / referencePrice) * 10000.0

        // Microprice = (BidVol * AskPrice + AskVol * BidPrice) / (BidVol + AskVol)
        val microprice = ((bidVol * bestAsk) + (askVol * bestBid)) / (bidVol + askVol)

        return OrderBook(
            securityId = isin,
            ticker = ticker,
            market = market,
            bids = buyLevels,
            asks = sellLevels,
            lastTradedPrice = referencePrice,
            sequenceNumber = sequenceNumber,
            microprice = microprice,
            spread = spread,
            spreadBps = spreadBps,
            vwap = referencePrice * 0.9994,
            timestamp = "09:30:52 UTC",
            auctionState = AuctionImbalance(
                uncrossingPrice = referencePrice,
                matchedVolume = 48200L,
                imbalanceVolume = 6300L,
                imbalanceDirection = OrderSide.BUY,
                staticCollarMin = staticCollarMin,
                staticCollarMax = staticCollarMax,
                dynamicCollarMin = dynamicCollarMin,
                dynamicCollarMax = dynamicCollarMax
            )
        )
    }

    fun getTrades(): List<Trade> = tradesHistory.toList()

    private fun logEvent(eventType: String, entityId: String, detail: String) {
        eventLog.add(
            EventLogEntry(
                eventId = sequenceNumber,
                eventType = eventType,
                entityType = "ORDER_OR_TRADE",
                entityId = entityId,
                payloadJson = "{\"ticker\":\"$ticker\",\"market\":\"${market.code}\",\"detail\":\"$detail\"}",
                timestampUtc = "2026-10-07 09:30:52",
                market = market
            )
        )
    }

    private fun Double.formatPrice(): String = String.format(Locale.US, "%.2f", this)
}
