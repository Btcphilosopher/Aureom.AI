package com.example.euronext.engine

data class DividendTaxResult(
    val grossDividendEur: Double,
    val domesticWithholdingRatePct: Double,
    val treatyWithholdingRatePct: Double,
    val withholdingTaxEur: Double,
    val netDividendEur: Double,
    val effectiveTaxRatePct: Double,
    val taxRegimeDescription: String,
    val ruleVersion: String = "EU-DIR-2026/FASTER-TAX-v1.4"
)

object EuropeanTaxEngine {
    private val domesticRates = mapOf(
        "France" to 25.0,        // Standard corporate / non-treaty rate (12.8% for French individuals)
        "Netherlands" to 15.0,   // Standard statutory rate
        "Belgium" to 30.0,       // Standard Belgian RV rate
        "Ireland" to 25.0,       // Standard Irish DWT
        "Portugal" to 28.0,      // Standard Portuguese withholding
        "Italy" to 26.0,         // Standard Italian capital gains/withholding
        "Norway" to 25.0         // Standard Norwegian shielding rate
    )

    fun calculateCrossBorderDividend(
        issuerCountry: String,
        investorCountry: String,
        grossDividendPerShare: Double,
        sharesCount: Long,
        hasTreatyReliefAtSource: Boolean = true
    ): DividendTaxResult {
        val domesticRate = domesticRates[issuerCountry] ?: 25.0
        val treatyRate = if (issuerCountry == investorCountry) {
            domesticRate
        } else if (hasTreatyReliefAtSource) {
            15.0 // Standard OECD Model Convention double tax treaty maximum
        } else {
            domesticRate
        }

        val totalGross = grossDividendPerShare * sharesCount
        val totalTax = totalGross * (treatyRate / 100.0)
        val totalNet = totalGross - totalTax

        val regimeDesc = if (issuerCountry == investorCountry) {
            "Domestic $issuerCountry Tax Regime (${treatyRate}%)"
        } else {
            "OECD Bilateral Tax Treaty $investorCountry <-> $issuerCountry with Relief at Source (${treatyRate}%)"
        }

        return DividendTaxResult(
            grossDividendEur = totalGross,
            domesticWithholdingRatePct = domesticRate,
            treatyWithholdingRatePct = treatyRate,
            withholdingTaxEur = totalTax,
            netDividendEur = totalNet,
            effectiveTaxRatePct = treatyRate,
            taxRegimeDescription = regimeDesc
        )
    }
}
