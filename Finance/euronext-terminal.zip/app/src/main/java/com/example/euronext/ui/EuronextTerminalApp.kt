package com.example.euronext.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.euronext.model.TerminalStrings
import com.example.euronext.ui.components.*
import com.example.euronext.ui.screens.*
import com.example.euronext.viewmodel.EuronextTerminalViewModel
import com.example.euronext.viewmodel.TerminalTab
import com.example.ui.theme.*

@Composable
fun EuronextTerminalApp(
    viewModel: EuronextTerminalViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val markets by viewModel.markets.collectAsStateWithLifecycle()
    val selectedMarket by viewModel.selectedMarket.collectAsStateWithLifecycle()
    val securities by viewModel.securities.collectAsStateWithLifecycle()
    val selectedSecurity by viewModel.selectedSecurity.collectAsStateWithLifecycle()
    val indices by viewModel.indices.collectAsStateWithLifecycle()
    val bonds by viewModel.bonds.collectAsStateWithLifecycle()
    val powerContracts by viewModel.powerContracts.collectAsStateWithLifecycle()
    val fxRates by viewModel.fxRates.collectAsStateWithLifecycle()
    val clearingPositions by viewModel.clearingPositions.collectAsStateWithLifecycle()
    val marginSummary by viewModel.marginSummary.collectAsStateWithLifecycle()
    val settlementInstructions by viewModel.settlementInstructions.collectAsStateWithLifecycle()
    val surveillanceAlerts by viewModel.surveillanceAlerts.collectAsStateWithLifecycle()
    val circuitBreakers by viewModel.circuitBreakers.collectAsStateWithLifecycle()
    val currentOrderBook by viewModel.currentOrderBook.collectAsStateWithLifecycle()
    val recentTrades by viewModel.recentTrades.collectAsStateWithLifecycle()

    val isCommandPaletteOpen by viewModel.isCommandPaletteOpen.collectAsStateWithLifecycle()
    val commandInput by viewModel.commandInput.collectAsStateWithLifecycle()
    val consoleMessage by viewModel.terminalConsoleMessage.collectAsStateWithLifecycle()
    val inspectingProvenance by viewModel.inspectingProvenance.collectAsStateWithLifecycle()
    val inspectingTrade by viewModel.inspectingTrade.collectAsStateWithLifecycle()

    val orderSide by viewModel.orderSide.collectAsStateWithLifecycle()
    val orderType by viewModel.orderType.collectAsStateWithLifecycle()
    val orderPrice by viewModel.orderPrice.collectAsStateWithLifecycle()
    val orderQuantity by viewModel.orderQuantity.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TerminalTopHeader(
                currentLanguage = currentLanguage,
                onLanguageChange = { viewModel.setLanguage(it) },
                onOpenCommandPalette = { viewModel.setCommandPaletteOpen(true) },
                activeMarket = selectedMarket,
                onMarketSelected = { viewModel.selectMarket(it) }
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                // Main Navigation Tabs
                Surface(
                    color = TerminalHeaderDark,
                    tonalElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 6.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        TerminalNavTabItem(TerminalTab.MARKETS, TerminalStrings.get("tab_markets", currentLanguage), currentTab == TerminalTab.MARKETS) { viewModel.selectTab(TerminalTab.MARKETS) }
                        TerminalNavTabItem(TerminalTab.SECURITIES, TerminalStrings.get("tab_securities", currentLanguage), currentTab == TerminalTab.SECURITIES) { viewModel.selectTab(TerminalTab.SECURITIES) }
                        TerminalNavTabItem(TerminalTab.ORDER_BOOK, TerminalStrings.get("tab_orderbook", currentLanguage), currentTab == TerminalTab.ORDER_BOOK) { viewModel.selectTab(TerminalTab.ORDER_BOOK) }
                        TerminalNavTabItem(TerminalTab.INDICES, TerminalStrings.get("tab_indices", currentLanguage), currentTab == TerminalTab.INDICES) { viewModel.selectTab(TerminalTab.INDICES) }
                        TerminalNavTabItem(TerminalTab.DERIVATIVES, TerminalStrings.get("tab_derivatives", currentLanguage), currentTab == TerminalTab.DERIVATIVES) { viewModel.selectTab(TerminalTab.DERIVATIVES) }
                        TerminalNavTabItem(TerminalTab.CLEARING_CSD, TerminalStrings.get("tab_clearing", currentLanguage), currentTab == TerminalTab.CLEARING_CSD) { viewModel.selectTab(TerminalTab.CLEARING_CSD) }
                        TerminalNavTabItem(TerminalTab.SURVEILLANCE_RISK, TerminalStrings.get("tab_surveillance", currentLanguage), currentTab == TerminalTab.SURVEILLANCE_RISK) { viewModel.selectTab(TerminalTab.SURVEILLANCE_RISK) }
                        TerminalNavTabItem(TerminalTab.DIGITAL_TWIN, TerminalStrings.get("tab_replay", currentLanguage), currentTab == TerminalTab.DIGITAL_TWIN) { viewModel.selectTab(TerminalTab.DIGITAL_TWIN) }
                        TerminalNavTabItem(TerminalTab.DEVELOPER_API, TerminalStrings.get("tab_api", currentLanguage), currentTab == TerminalTab.DEVELOPER_API) { viewModel.selectTab(TerminalTab.DEVELOPER_API) }
                    }
                }
                // Console Heartbeat Line
                TerminalConsoleFooter(message = consoleMessage)
            }
        },
        containerColor = TerminalBackgroundDark
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentTab) {
                TerminalTab.MARKETS -> MarketControlRoomScreen(
                    markets = markets,
                    selectedMarket = selectedMarket,
                    onMarketSelected = { viewModel.selectMarket(it) },
                    onInspectProvenance = { viewModel.inspectProvenance(it) },
                    language = currentLanguage
                )
                TerminalTab.SECURITIES -> SecurityMasterScreen(
                    securities = securities,
                    selectedSecurity = selectedSecurity,
                    onSecuritySelected = { viewModel.selectSecurity(it) },
                    onInspectProvenance = { viewModel.inspectProvenance(it) },
                    language = currentLanguage
                )
                TerminalTab.ORDER_BOOK -> OrderBookTradingScreen(
                    selectedSecurity = selectedSecurity,
                    orderBook = currentOrderBook,
                    recentTrades = recentTrades,
                    orderSide = orderSide,
                    orderType = orderType,
                    orderPrice = orderPrice,
                    orderQuantity = orderQuantity,
                    onSideChange = { viewModel.setOrderSide(it) },
                    onTypeChange = { viewModel.setOrderType(it) },
                    onPriceChange = { viewModel.setOrderPrice(it) },
                    onQuantityChange = { viewModel.setOrderQuantity(it) },
                    onSubmitOrder = { viewModel.submitOrder() },
                    onTradeSelected = { viewModel.inspectTrade(it) },
                    onInspectProvenance = { viewModel.inspectProvenance(it) },
                    language = currentLanguage
                )
                TerminalTab.INDICES -> IndexPlatformScreen(
                    indices = indices,
                    onInspectProvenance = { viewModel.inspectProvenance(it) },
                    language = currentLanguage
                )
                TerminalTab.DERIVATIVES -> DerivativesFixedIncomeScreen(
                    bonds = bonds,
                    powerContracts = powerContracts,
                    fxRates = fxRates,
                    selectedSecurity = selectedSecurity,
                    language = currentLanguage
                )
                TerminalTab.CLEARING_CSD -> PostTradeClearingScreen(
                    marginSummary = marginSummary,
                    clearingPositions = clearingPositions,
                    settlementInstructions = settlementInstructions,
                    language = currentLanguage
                )
                TerminalTab.SURVEILLANCE_RISK -> SurveillanceRiskScreen(
                    surveillanceAlerts = surveillanceAlerts,
                    circuitBreakers = circuitBreakers,
                    onApplyScenario = { viewModel.applyMacroScenario(it) },
                    language = currentLanguage
                )
                TerminalTab.DIGITAL_TWIN -> DigitalTwinReplayScreen(
                    language = currentLanguage
                )
                TerminalTab.DEVELOPER_API -> DeveloperApiPortalScreen(
                    language = currentLanguage
                )
            }

            // Command Palette Dialog
            CommandPaletteDialog(
                isOpen = isCommandPaletteOpen,
                onDismiss = { viewModel.setCommandPaletteOpen(false) },
                commandInput = commandInput,
                onCommandChange = { viewModel.setCommandInput(it) },
                onExecute = { viewModel.executeCommand(it) },
                language = currentLanguage
            )

            // Provenance Record Inspector
            ProvenanceDialog(
                provenance = inspectingProvenance,
                onDismiss = { viewModel.closeProvenance() }
            )

            // Trade Trace Inspector
            TradeTraceDialog(
                trade = inspectingTrade,
                onDismiss = { viewModel.closeTrade() }
            )
        }
    }
}

@Composable
private fun TerminalNavTabItem(
    tab: TerminalTab,
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) TerminalNavyPrimary else Color.Transparent,
        shape = RoundedCornerShape(4.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) TerminalNavyPrimary else TerminalCardBorder
        ),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = title,
            color = if (isSelected) TerminalBackgroundDark else TerminalTextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        )
    }
}
