package com.example.euronext.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.euronext.model.*
import com.example.euronext.ui.components.ProvenanceBadge
import com.example.ui.theme.*
import kotlin.math.max

@Composable
fun OrderBookTradingScreen(
    selectedSecurity: Security,
    orderBook: OrderBook?,
    recentTrades: List<Trade>,
    orderSide: OrderSide,
    orderType: OrderType,
    orderPrice: String,
    orderQuantity: String,
    onSideChange: (OrderSide) -> Unit,
    onTypeChange: (OrderType) -> Unit,
    onPriceChange: (String) -> Unit,
    onQuantityChange: (String) -> Unit,
    onSubmitOrder: () -> Unit,
    onTradeSelected: (Trade) -> Unit,
    onInspectProvenance: (ProvenanceRecord) -> Unit,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val book = orderBook ?: return

    val maxBidVol = max(1L, book.bids.maxOfOrNull { it.totalVolume } ?: 1000L)
    val maxAskVol = max(1L, book.asks.maxOfOrNull { it.totalVolume } ?: 1000L)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Security & Microprice Bar
        item {
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${selectedSecurity.ticker} (${selectedSecurity.name})",
                                    color = TerminalTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "[${selectedSecurity.mic}]",
                                    color = TerminalGoldAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "ISIN: ${selectedSecurity.isin} • Sequence: #${book.sequenceNumber}",
                                color = TerminalTextMuted,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        ProvenanceBadge(
                            provenance = selectedSecurity.provenance,
                            onClick = { onInspectProvenance(selectedSecurity.provenance) }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = TerminalCardBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        BookStat("LAST TRADE", "€${String.format("%.2f", book.lastTradedPrice)}")
                        BookStat("MICROPRICE", "€${String.format("%.3f", book.microprice)}")
                        BookStat("SPREAD", "€${String.format("%.2f", book.spread)} (${String.format("%.1f", book.spreadBps)} bps)")
                        BookStat("VWAP", "€${String.format("%.2f", book.vwap)}")
                    }
                }
            }
        }

        // Order Book Depth Ladder (L2/L3)
        item {
            Surface(
                color = TerminalSurfaceDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "OPTIQ® LEVEL 2 ORDER BOOK LADDER",
                            color = TerminalNavyPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "PRICE-TIME PRIORITY",
                            color = TerminalTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Headers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ORD / BID SIZE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("PRICE (€)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("ASK SIZE / ORD", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    HorizontalDivider(color = TerminalCardBorder)
                    Spacer(modifier = Modifier.height(4.dp))

                    // Asks (displayed in ascending order from best ask down)
                    book.asks.take(4).reversed().forEach { ask ->
                        val barPct = (ask.totalVolume.toFloat() / maxAskVol.toFloat()).coerceIn(0.05f, 1f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(22.dp)
                                .padding(vertical = 1.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(barPct)
                                    .align(Alignment.CenterEnd)
                                    .background(OrderBookAskRedBg)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("-", color = TerminalTextMuted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                                Text(
                                    text = String.format("%.2f", ask.price),
                                    color = OrderBookAskRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "${ask.totalVolume} (${ask.orderCount})",
                                    color = TerminalTextPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // Spread line
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(Color(0xFF1E293B))
                            .padding(vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "SPREAD: €${String.format("%.2f", book.spread)} (${String.format("%.1f", book.spreadBps)} bps)",
                            color = TerminalGoldAccent,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Bids (displayed descending from best bid)
                    book.bids.take(4).forEach { bid ->
                        val barPct = (bid.totalVolume.toFloat() / maxBidVol.toFloat()).coerceIn(0.05f, 1f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(22.dp)
                                .padding(vertical = 1.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(barPct)
                                    .align(Alignment.CenterStart)
                                    .background(OrderBookBidGreenBg)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${bid.totalVolume} (${bid.orderCount})",
                                    color = TerminalTextPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = String.format("%.2f", bid.price),
                                    color = OrderBookBidGreen,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                                Text("-", color = TerminalTextMuted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // Live Order Entry Ticket
        item {
            Surface(
                color = Color(0xFF131D33),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "INSTITUTIONAL ORDER ENTRY TICKET",
                            color = TerminalNavyPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(Icons.Default.FlashOn, contentDescription = "Order", tint = TerminalNavyPrimary, modifier = Modifier.size(16.dp))
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Side selector (BUY / SELL)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onSideChange(OrderSide.BUY) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (orderSide == OrderSide.BUY) TerminalStatusGreen else TerminalSurfaceDark
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("BUY / ACHAT", color = if (orderSide == OrderSide.BUY) TerminalBackgroundDark else TerminalTextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Button(
                            onClick = { onSideChange(OrderSide.SELL) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (orderSide == OrderSide.SELL) TerminalStatusRed else TerminalSurfaceDark
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("SELL / VENTE", color = if (orderSide == OrderSide.SELL) TerminalTextPrimary else TerminalTextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Price & Quantity Inputs
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = orderPrice,
                            onValueChange = onPriceChange,
                            label = { Text("LIMIT PRICE (€)", fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalNavyPrimary,
                                unfocusedBorderColor = TerminalCardBorder,
                                focusedTextColor = TerminalTextPrimary,
                                unfocusedTextColor = TerminalTextPrimary
                            )
                        )
                        OutlinedTextField(
                            value = orderQuantity,
                            onValueChange = onQuantityChange,
                            label = { Text("QUANTITY (LOTS)", fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalNavyPrimary,
                                unfocusedBorderColor = TerminalCardBorder,
                                focusedTextColor = TerminalTextPrimary,
                                unfocusedTextColor = TerminalTextPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onSubmitOrder,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (orderSide == OrderSide.BUY) TerminalStatusGreen else TerminalStatusRed
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Submit", tint = TerminalBackgroundDark)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "TRANSMIT ${orderSide.name} ORDER TO OPTIQ® MATCHING ENGINE",
                            color = TerminalBackgroundDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Recent Executed Trades Stream
        item {
            Text(
                text = "RECENT EXECUTED TRADES (CLICK TO TRACE POST-TRADE)",
                color = TerminalTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(recentTrades.take(8)) { trade ->
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onTradeSelected(trade) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = trade.tradeId,
                                color = TerminalNavyPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${trade.quantity} @ €${String.format("%.2f", trade.executionPrice)}",
                                color = TerminalTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Text(
                            text = "${trade.timestamp} • ${trade.buyerParticipant} / ${trade.sellerParticipant}",
                            color = TerminalTextMuted,
                            fontSize = 8.sp,
                            maxLines = 1
                        )
                    }

                    Text(
                        text = "€${String.format("%.2f", trade.valueEur)}",
                        color = TerminalGoldAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun BookStat(label: String, value: String) {
    Column {
        Text(label, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
