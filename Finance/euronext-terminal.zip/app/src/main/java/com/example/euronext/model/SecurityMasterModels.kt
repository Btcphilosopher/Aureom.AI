package com.example.euronext.model

enum class InstrumentType {
    ORDINARY_SHARE,
    PREFERENCE_SHARE,
    DUAL_CLASS_SHARE,
    ETF,
    ETP,
    INDEX_FUND,
    GOVERNMENT_BOND,
    CORPORATE_BOND,
    GREEN_BOND,
    EQUITY_OPTION,
    INDEX_OPTION,
    EQUITY_FUTURE,
    INDEX_FUTURE,
    DIVIDEND_FUTURE,
    COMMODITY_FUTURE,
    POWER_CONTRACT,
    FX_SPOT,
    WARRANT,
    CERTIFICATE
}

enum class AssetClass {
    EQUITIES,
    ETFs_AND_FUNDS,
    FIXED_INCOME,
    EQUITY_DERIVATIVES,
    INDEX_DERIVATIVES,
    COMMODITIES,
    POWER,
    FX
}

data class Listing(
    val securityId: String,
    val market: MarketId,
    val mic: String,
    val currency: String,
    val ticker: String,
    val isPrimary: Boolean,
    val tradingStatus: String = "ACTIVE",
    val tickSizeBand: String = "Table_01 (MiFID II)",
    val lotSize: Int = 1,
    val lastPrice: Double,
    val changePct: Double,
    val dayVolume: Long
)

data class IssuerProfile(
    val issuerId: String,
    val companyName: String,
    val legalEntityIdentifier: String, // LEI
    val country: String,
    val headquarters: String,
    val sector: String,
    val industry: String,
    val marketCapEurB: Double,
    val sharesOutstandingM: Double,
    val freeFloatPct: Double,
    val esgScore: Int, // out of 100
    val esgRating: String, // AAA, AA, A, BBB
    val primaryIndex: String,
    val description: String,
    val dividendYieldPct: Double,
    val peRatio: Double,
    val nextEarningsDate: String
)

data class Security(
    val securityId: String,
    val isin: String,
    val ticker: String,
    val sedol: String,
    val localCode: String,
    val name: String,
    val mic: String,
    val primaryMarket: MarketId,
    val country: String,
    val currency: String,
    val instrumentType: InstrumentType,
    val assetClass: AssetClass,
    val issuer: IssuerProfile,
    val listings: List<Listing>,
    val nominalValue: Double,
    val lotSize: Int = 1,
    val tickSize: Double = 0.01,
    val currentPrice: Double,
    val openPrice: Double,
    val highPrice: Double,
    val lowPrice: Double,
    val previousClose: Double,
    val volume: Long,
    val turnoverEur: Double,
    val changePct: Double,
    val bidPrice: Double,
    val askPrice: Double,
    val bidSize: Long,
    val askSize: Long,
    val provenance: ProvenanceRecord
)

enum class CorporateActionType {
    DIVIDEND_CASH,
    DIVIDEND_SPECIAL,
    STOCK_SPLIT,
    REVERSE_SPLIT,
    RIGHTS_ISSUE,
    SHARE_BUYBACK,
    MERGER_ACQUISITION,
    SPIN_OFF,
    CAPITAL_INCREASE
}

data class CorporateActionEvent(
    val eventId: String,
    val isin: String,
    val securityTicker: String,
    val actionType: CorporateActionType,
    val announcementDate: String,
    val exDate: String,
    val recordDate: String,
    val paymentEffectiveDate: String,
    val grossAmountPerShare: Double,
    val currency: String,
    val ratioDescription: String?,
    val taxWithholdingPct: Double,
    val status: String = "ANNOUNCED",
    val provenance: ProvenanceRecord
)
