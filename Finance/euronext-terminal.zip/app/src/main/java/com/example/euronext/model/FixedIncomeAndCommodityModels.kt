package com.example.euronext.model

data class BondInstrument(
    val isin: String,
    val bondName: String,
    val issuerCountry: String,
    val currency: String = "EUR",
    val couponPct: Double,
    val maturityDate: String,
    val yearsToMaturity: Double,
    val cleanPrice: Double,
    val yieldToMaturityPct: Double,
    val modifiedDuration: Double,
    val convexity: Double,
    val creditRating: String, // AAA, AA+, BBB-, etc.
    val isGreenBond: Boolean,
    val spreadOverBundBps: Double,
    val bidPrice: Double,
    val askPrice: Double
)

data class EuropeanPowerContract(
    val region: String, // France, Italy, Belgium, Netherlands, Norway, Germany
    val productType: String, // Baseload Day-Ahead, Peakload Month+1, Quarter+1
    val deliveryPeriod: String,
    val settlementPriceEurMwh: Double,
    val changePct: Double,
    val openInterestMwh: Long,
    val carbonIntensityGCo2Kwh: Int,
    val gridInterconnectionCapacityMw: Int
)

data class CommodityContract(
    val commodityName: String, // Milling Wheat No. 2, Rapeseed, Corn, Power
    val marketHub: String, // Rouen, Bordeaux, Paris Hub
    val contractCode: String,
    val deliveryMonth: String,
    val priceEurTonne: Double,
    val changePct: Double,
    val volumeLots: Long,
    val openInterestLots: Long,
    val lotSizeTonnes: Int = 50
)

data class FxQuote(
    val pair: String, // EUR/USD, EUR/GBP, EUR/CHF, EUR/NOK, EUR/SEK, EUR/DKK
    val spotRate: Double,
    val changePct: Double,
    val oneMonthForwardPoints: Double,
    val threeMonthForwardPoints: Double,
    val impliedVol3M: Double,
    val bid: Double,
    val ask: Double
)

data class EtfInstrument(
    val isin: String,
    val ticker: String,
    val etfName: String,
    val benchmarkIndex: String,
    val navEur: Double,
    val marketPriceEur: Double,
    val premiumDiscountBps: Double,
    val aumEurM: Double,
    val totalExpenseRatioPct: Double,
    val trackingErrorBps: Double,
    val replicationMethod: String = "Physical (Full Replication)",
    val primaryMarket: MarketId = MarketId.PAR,
    val creationRedemptionBasketCount: Int = 50000
)
