package com.example.euronext.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.euronext.model.*
import com.example.ui.theme.*

@Composable
fun DeveloperApiPortalScreen(
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    var selectedEndpoint by remember { mutableStateOf("GET /api/v1/markets") }
    var selectedLanguageSdk by remember { mutableStateOf("PYTHON") } // PYTHON, R, CURL
    var jsonOutput by remember {
        mutableStateOf(
            """
{
  "status": 200,
  "provenance": {
    "provider": "SyntheticEuronextProvider",
    "source": "EURONEXT-CORE-TWIN-v3.7",
    "market_status": "SYNTHETIC_OFFICIAL",
    "timestamp_utc": "2026-10-07T09:30:00Z"
  },
  "data": [
    {"market_id": "PAR", "name": "Euronext Paris", "mic": "XPAR", "currency": "EUR", "index": "CAC 40", "status": "CONTINUOUS"},
    {"market_id": "AMS", "name": "Euronext Amsterdam", "mic": "XAMS", "currency": "EUR", "index": "AEX", "status": "CONTINUOUS"},
    {"market_id": "MIL", "name": "Euronext Milan", "mic": "XMIL", "currency": "EUR", "index": "FTSE MIB", "status": "CONTINUOUS"},
    {"market_id": "BRU", "name": "Euronext Brussels", "mic": "XBRU", "currency": "EUR", "index": "BEL 20", "status": "CONTINUOUS"},
    {"market_id": "DUB", "name": "Euronext Dublin", "mic": "XDUB", "currency": "EUR", "index": "ISEQ 20", "status": "CONTINUOUS"},
    {"market_id": "LIS", "name": "Euronext Lisbon", "mic": "XLIS", "currency": "EUR", "index": "PSI", "status": "CONTINUOUS"},
    {"market_id": "OSL", "name": "Oslo Børs", "mic": "XOSL", "currency": "NOK", "index": "OBX", "status": "CONTINUOUS"},
    {"market_id": "ATH", "name": "Euronext Athens", "mic": "XATH", "currency": "EUR", "status": "OPTIO_MIGRATION_JUNE_2027"}
  ]
}
            """.trimIndent()
        )
    }

    val pythonSdkCode = """
from euronext import EuronextClient

client = EuronextClient(api_key="euronext_sec_demo_2026", environment="synthetic-twin")

# 1. Query Pan-European Regulated Markets
markets = client.markets.list()
for m in markets:
    print(f"{m.market_id} ({m.mic}): {m.status} | Benchmark: {m.benchmark_index}")

# 2. Query L2 Order Book
orderbook = client.orderbook.get(isin="FR0000121014", depth=10)
print(f"LVMH Spread: €{orderbook.spread} | Microprice: €{orderbook.microprice}")

# 3. Submit Limit Order to Optiq®
order = client.trading.submit_order(
    ticker="MC",
    market="PAR",
    side="BUY",
    order_type="LIMIT",
    price=688.40,
    quantity=500,
    participant="MEMBER-BNP-PARIBAS"
)
print(f"Order Status: {order.status} -> CCP Novation ID: {order.clearing_ref}")
""".trimIndent()

    val rSdkCode = """
library(euronextR)

client <- EuronextClient${'$'}new(api_key = "demo_key")

# Retrieve CAC 40 Historical Index & Constituents
cac40 <- client${'$'}indices${'$'}get("CAC40")
constituents <- client${'$'}indices${'$'}get_weights("CAC40")

# Compute Factor Exposures across Euronext Equities
factors <- client${'$'}research${'$'}factors(universe = "EURONEXT_100")
summary(factors)
""".trimIndent()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // API Overview Header
        item {
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "EURONEXT MARKET API // DEVELOPER PORTAL",
                                color = TerminalNavyPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "REST v1 & WebSocket Feeds // Python & R Institutional SDKs",
                                color = TerminalTextSecondary,
                                fontSize = 9.sp
                            )
                        }
                        Icon(Icons.Default.Code, contentDescription = "API", tint = TerminalNavyPrimary, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }

        // Interactive REST Tester Card
        item {
            Surface(
                color = Color(0xFF131D33),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "INTERACTIVE REST ENDPOINT EXPLORER",
                        color = TerminalGoldAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val endpoints = listOf(
                        "GET /api/v1/markets",
                        "GET /api/v1/securities/FR0000121014",
                        "GET /api/v1/orderbook/MC",
                        "GET /api/v1/clearing/margin",
                        "GET /api/v1/settlement/csd-routes"
                    )

                    endpoints.forEach { ep ->
                        val isSel = ep == selectedEndpoint
                        Surface(
                            color = if (isSel) TerminalNavyPrimary else TerminalSurfaceDark,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clickable {
                                    selectedEndpoint = ep
                                    jsonOutput = when (ep) {
                                        "GET /api/v1/securities/FR0000121014" -> """
{
  "isin": "FR0000121014",
  "ticker": "MC",
  "name": "LVMH Moët Hennessy Louis Vuitton",
  "primary_mic": "XPAR",
  "currency": "EUR",
  "price": 688.40,
  "listings": ["XPAR", "XAMS", "XMIL"],
  "esg_score": 88
}
                                        """.trimIndent()
                                        "GET /api/v1/orderbook/MC" -> """
{
  "ticker": "MC",
  "mic": "XPAR",
  "microprice": 688.374,
  "spread_bps": 2.9,
  "bids": [{"price": 688.30, "volume": 1450}, {"price": 688.20, "volume": 3200}],
  "asks": [{"price": 688.50, "volume": 1820}, {"price": 688.60, "volume": 2800}]
}
                                        """.trimIndent()
                                        "GET /api/v1/clearing/margin" -> """
{
  "ccp": "Euronext Clearing",
  "total_initial_margin_eur": 84500000.0,
  "total_variation_margin_eur": -1420000.0,
  "coverage_ratio_pct": 142.8,
  "status": "ADEQUATE"
}
                                        """.trimIndent()
                                        "GET /api/v1/settlement/csd-routes" -> """
{
  "effective_date": "2026-09-21",
  "default_csd": "Euronext Securities",
  "alternative_csds": ["Euroclear France", "Euroclear Nederland", "Euroclear Belgium", "Clearstream Europe AG"]
}
                                        """.trimIndent()
                                        else -> jsonOutput
                                    }
                                }
                        ) {
                            Text(
                                text = ep,
                                color = if (isSel) TerminalBackgroundDark else TerminalTextPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "RESPONSE JSON PAYLOAD [HTTP 200 OK]:",
                        color = TerminalTextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = TerminalBackgroundDark,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = jsonOutput,
                            color = TerminalTealMarket,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }

        // Python SDK & R SDK Code Samples
        item {
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "INSTITUTIONAL CLIENT SDK CODE",
                            color = TerminalNavyPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "PYTHON",
                                color = if (selectedLanguageSdk == "PYTHON") TerminalGoldAccent else TerminalTextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { selectedLanguageSdk = "PYTHON" }
                            )
                            Text("•", color = TerminalTextMuted, fontSize = 10.sp)
                            Text(
                                text = "R SDK",
                                color = if (selectedLanguageSdk == "R") TerminalGoldAccent else TerminalTextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { selectedLanguageSdk = "R" }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = TerminalBackgroundDark,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (selectedLanguageSdk == "PYTHON") pythonSdkCode else rSdkCode,
                            color = TerminalTextPrimary,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}
