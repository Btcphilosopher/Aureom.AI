package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Pan-European Exchange Terminal Palette
// Design reference: Paris, Amsterdam, Milan, Brussels financial architecture & digital twin
val TerminalBackgroundDark = Color(0xFF080D1A)
val TerminalSurfaceDark = Color(0xFF0F172A)
val TerminalCardDark = Color(0xFF162036)
val TerminalCardBorder = Color(0xFF263550)
val TerminalHeaderDark = Color(0xFF0B132B)

val TerminalNavyPrimary = Color(0xFF38BDF8)
val TerminalNavySecondary = Color(0xFF94A3B8)
val TerminalGoldAccent = Color(0xFFF59E0B)
val TerminalAmberWarm = Color(0xFFD97706)
val TerminalTealMarket = Color(0xFF06B6D4)

val TerminalStatusGreen = Color(0xFF10B981)
val TerminalStatusGreenMuted = Color(0xFF064E3B)
val TerminalStatusRed = Color(0xFFEF4444)
val TerminalStatusRedMuted = Color(0xFF7F1D1D)
val TerminalStatusAmber = Color(0xFFF59E0B)
val TerminalStatusBlue = Color(0xFF3B82F6)
val TerminalStatusPurple = Color(0xFF8B5CF6)

val TerminalTextPrimary = Color(0xFFF8FAFC)
val TerminalTextSecondary = Color(0xFF94A3B8)
val TerminalTextMuted = Color(0xFF64748B)

val OrderBookBidGreen = Color(0xFF10B981)
val OrderBookBidGreenBg = Color(0x2210B981)
val OrderBookAskRed = Color(0xFFEF4444)
val OrderBookAskRedBg = Color(0x22EF4444)

val ProvenanceBadgeOfficial = Color(0xFF3B82F6)
val ProvenanceBadgeSynthetic = Color(0xFFF59E0B)
val ProvenanceBadgeReconstructed = Color(0xFF10B981)
