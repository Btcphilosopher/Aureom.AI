package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = TerminalNavyPrimary,
    onPrimary = TerminalBackgroundDark,
    primaryContainer = TerminalCardDark,
    onPrimaryContainer = TerminalTextPrimary,
    secondary = TerminalTealMarket,
    onSecondary = TerminalBackgroundDark,
    secondaryContainer = TerminalSurfaceDark,
    onSecondaryContainer = TerminalTextPrimary,
    tertiary = TerminalGoldAccent,
    background = TerminalBackgroundDark,
    onBackground = TerminalTextPrimary,
    surface = TerminalSurfaceDark,
    onSurface = TerminalTextPrimary,
    surfaceVariant = TerminalCardDark,
    onSurfaceVariant = TerminalTextSecondary,
    outline = TerminalCardBorder,
    error = TerminalStatusRed,
    onError = TerminalTextPrimary
)

private val LightColorScheme = darkColorScheme(
    primary = TerminalNavyPrimary,
    background = TerminalBackgroundDark,
    surface = TerminalSurfaceDark,
    onBackground = TerminalTextPrimary,
    onSurface = TerminalTextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to institutional dark terminal mode
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
