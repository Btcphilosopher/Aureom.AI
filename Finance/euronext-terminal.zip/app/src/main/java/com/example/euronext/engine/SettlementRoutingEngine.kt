package com.example.euronext.engine

import com.example.euronext.model.*

object SettlementRoutingEngine {

    /**
     * Determines default and eligible CSDs under the September 2026 Euronext settlement architecture.
     * From 21 September 2026, Euronext Amsterdam, Brussels and Paris designated Euronext Securities
     * as the default CSD for equity and ETP euro transactions, with clients retaining choice for
     * Clearstream Europe AG, Euroclear Bank, Euroclear Belgium, Euroclear France, and Euroclear Nederland.
     */
    fun determineCsdRouting(
        market: MarketId,
        currency: String,
        instrumentType: InstrumentType,
        clientSelectedCsd: CsdVenue?
    ): Pair<CsdVenue, List<CsdVenue>> {
        val eligibleCsds = when (market) {
            MarketId.PAR, MarketId.AMS, MarketId.BRU -> listOf(
                CsdVenue.EURONEXT_SECURITIES,
                CsdVenue.EUROCLEAR_FRANCE,
                CsdVenue.EUROCLEAR_NEDERLAND,
                CsdVenue.EUROCLEAR_BELGIUM,
                CsdVenue.EUROCLEAR_BANK,
                CsdVenue.CLEARSTREAM_EUROPE_AG
            )
            MarketId.MIL, MarketId.LIS, MarketId.OSL -> listOf(
                CsdVenue.EURONEXT_SECURITIES,
                CsdVenue.EUROCLEAR_BANK,
                CsdVenue.CLEARSTREAM_EUROPE_AG
            )
            MarketId.DUB -> listOf(
                CsdVenue.EUROCLEAR_BANK,
                CsdVenue.EURONEXT_SECURITIES
            )
            MarketId.ATH -> listOf(
                CsdVenue.EURONEXT_SECURITIES // Post-migration 2027
            )
        }

        val defaultCsd = when (market) {
            MarketId.PAR, MarketId.AMS, MarketId.BRU, MarketId.MIL, MarketId.LIS, MarketId.OSL -> CsdVenue.EURONEXT_SECURITIES
            MarketId.DUB -> CsdVenue.EUROCLEAR_BANK
            MarketId.ATH -> CsdVenue.EURONEXT_SECURITIES
        }

        val finalCsd = clientSelectedCsd ?: defaultCsd
        return Pair(finalCsd, eligibleCsds)
    }

    data class SettlementDiagnosis(
        val isFailed: Boolean,
        val errorCode: String?,
        val rootCause: String,
        val financialPenaltyEur: Double,
        val recommendedResolution: String
    )

    fun diagnoseSettlementFail(
        status: SettlementStatus,
        quantity: Long,
        amountEur: Double,
        failReason: String?
    ): SettlementDiagnosis {
        return when {
            status != SettlementStatus.FAILED -> SettlementDiagnosis(
                isFailed = false,
                errorCode = null,
                rootCause = "Settlement instruction matching and validated against T2S / CSD finality window.",
                financialPenaltyEur = 0.0,
                recommendedResolution = "Settlement completed normally. Book-entry credit booked to custody account."
            )
            failReason?.contains("CASH", ignoreCase = true) == true -> SettlementDiagnosis(
                isFailed = true,
                errorCode = "SEPA-T2S-LACK-CASH-04",
                rootCause = "Delivering counterparty TARGET2 cash account has insufficient liquidity at DVP cut-off.",
                financialPenaltyEur = amountEur * 0.0001, // CSDR cash penalty ~1 bp/day
                recommendedResolution = "Trigger intraday auto-collateralisation or credit repo line before evening T2S batch."
            )
            failReason?.contains("SEC", ignoreCase = true) == true -> SettlementDiagnosis(
                isFailed = true,
                errorCode = "CSD-INSUFF-SEC-01",
                rootCause = "Delivering party account lacks eligible unencumbered securities on settlement date.",
                financialPenaltyEur = amountEur * 0.0002, // CSDR securities penalty ~2 bp/day
                recommendedResolution = "Execute automated securities lending borrow from Euronext Securities pool or invoke mandatory buy-in."
            )
            else -> SettlementDiagnosis(
                isFailed = true,
                errorCode = "MATCH-MISMATCH-99",
                rootCause = "Instruction trade date or settlement amount mismatch between delivering and receiving broker.",
                financialPenaltyEur = 50.0,
                recommendedResolution = "Cancel mismatched instruction and re-send ISO 20022 sese.023 with aligned place of settlement."
            )
        }
    }
}
