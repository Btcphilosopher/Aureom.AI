package com.example.euronext.model

import java.util.UUID

enum class AlertType {
    SPOOFING_DETECTED,
    LAYERING_ORDER_BOOK,
    WASH_TRADE_POTENTIAL,
    ABNORMAL_PRICE_VOLATILITY,
    CROSS_MARKET_ARBITRAGE_GAP,
    QUOTE_STUFFING_BURST,
    CIRCUIT_BREAKER_TRIPPED
}

enum class AlertSeverity {
    INFO,
    WARNING,
    CRITICAL
}

data class SurveillanceAlert(
    val alertId: String = "SURV-" + UUID.randomUUID().toString().take(6).uppercase(),
    val timestamp: String,
    val alertType: AlertType,
    val severity: AlertSeverity,
    val ticker: String,
    val isin: String,
    val market: MarketId,
    val triggerDetail: String,
    val detectionAlgorithm: String,
    val recommendedAction: String,
    val isInvestigated: Boolean = false
)

data class CircuitBreakerEvent(
    val eventId: String = "CB-" + UUID.randomUUID().toString().take(6).uppercase(),
    val ticker: String,
    val market: MarketId,
    val triggerPrice: Double,
    val referencePrice: Double,
    val deviationPct: Double,
    val bandThresholdPct: Double,
    val haltDurationSeconds: Int = 180,
    val state: String = "VOLATILITY_INTERRUPTION_INTRADAY_AUCTION",
    val timestamp: String
)

data class MacroScenario(
    val scenarioId: String,
    val name: String,
    val description: String,
    val cac40ShockPct: Double,
    val aexShockPct: Double,
    val mibShockPct: Double,
    val bel20ShockPct: Double,
    val ibexShockPct: Double,
    val psiShockPct: Double,
    val obxShockPct: Double,
    val banksFactorShockPct: Double,
    val energyFactorShockPct: Double,
    val eurFxShockPct: Double,
    val ratesShockBps: Int,
    val ccpMarginIncreasePct: Double
)

data class FactorScore(
    val ticker: String,
    val isin: String,
    val valueScore: Double,      // 0-100
    val qualityScore: Double,    // 0-100
    val momentumScore: Double,   // 0-100
    val lowVolScore: Double,     // 0-100
    val dividendScore: Double,   // 0-100
    val sizeScore: Double,       // 0-100
    val compositeRank: Int
)

data class EventLogEntry(
    val eventId: Long,
    val eventType: String,
    val entityType: String,
    val entityId: String,
    val payloadJson: String,
    val timestampUtc: String,
    val market: MarketId
)
