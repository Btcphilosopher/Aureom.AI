package com.example.euronext.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.euronext.engine.SettlementRoutingEngine
import com.example.euronext.model.*
import com.example.ui.theme.*

@Composable
fun PostTradeClearingScreen(
    marginSummary: MarginSummary,
    clearingPositions: List<ClearingPosition>,
    settlementInstructions: List<SettlementInstruction>,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    var selectedInstructionForDiagnosis by remember { mutableStateOf<SettlementInstruction?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // CCP Margin & Novation Summary
        item {
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "EURONEXT CLEARING (MULTI-ASSET CCP)",
                                color = TerminalNavyPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "SPAN & Portfolio Margin Engine // Stress Testing & Default Fund",
                                color = TerminalTextSecondary,
                                fontSize = 9.sp
                            )
                        }
                        Surface(
                            color = Color(0x3310B981),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = marginSummary.marginCallStatus,
                                color = TerminalStatusGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = TerminalCardBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MarginStat("INITIAL MARGIN", "€${String.format("%.1f", marginSummary.totalInitialMarginEur / 1e6)}M")
                        MarginStat("STRESS ADD-ON", "€${String.format("%.1f", marginSummary.stressMarginAddonEur / 1e6)}M")
                        MarginStat("COLLATERAL POSTED", "€${String.format("%.1f", marginSummary.eligibleCollateralPostedEur / 1e6)}M")
                        MarginStat("COVERAGE RATIO", "${String.format("%.1f", marginSummary.marginCoverageRatioPct)}%")
                    }
                }
            }
        }

        // 2026 Settlement Model & CSD Routing Engine
        item {
            Surface(
                color = Color(0xFF131D33),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalGoldAccent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "2026 POST-TRADE SETTLEMENT ARCHITECTURE",
                            color = TerminalGoldAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "SEPT 2026 RULEBOOK",
                            color = TerminalTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "From 21 September 2026, Euronext Amsterdam, Brussels and Paris designated Euronext Securities as default CSD for equity and ETP transactions, with client routing retained for Clearstream Europe AG, Euroclear Bank, Euroclear Belgium, Euroclear France and Euroclear Nederland.",
                        color = TerminalTextSecondary,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        // Settlement Instructions List
        item {
            Text(
                text = "T+2 SETTLEMENT INSTRUCTIONS & CSDR FAILS MONITOR",
                color = TerminalTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(settlementInstructions) { inst ->
            val isFailed = inst.status == SettlementStatus.FAILED
            Surface(
                color = if (isFailed) Color(0xFF2A1515) else TerminalCardDark,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isFailed) TerminalStatusRed else TerminalCardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedInstructionForDiagnosis = inst }
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = inst.instructionId,
                                color = TerminalGoldAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${inst.ticker} (${inst.quantity} sh)",
                                color = TerminalTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Surface(
                            color = if (isFailed) Color(0x33EF4444) else Color(0x3310B981),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = inst.status.name,
                                color = if (isFailed) TerminalStatusRed else TerminalStatusGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "CSD: ${inst.destinationCsd.fullName} • Settle Date: ${inst.settlementDate}",
                        color = TerminalTextSecondary,
                        fontSize = 9.sp
                    )
                    Text(
                        text = "Amount: €${String.format("%.2f", inst.settlementAmountEur)} • Counterparties: ${inst.deliveringParticipant} -> ${inst.receivingParticipant}",
                        color = TerminalTextMuted,
                        fontSize = 8.sp,
                        maxLines = 1
                    )

                    if (inst.failReason != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "FAIL REASON: ${inst.failReason}",
                            color = TerminalStatusRed,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Settlement Diagnosis Detail if selected
        selectedInstructionForDiagnosis?.let { diagInst ->
            item {
                val diagnosis = SettlementRoutingEngine.diagnoseSettlementFail(
                    diagInst.status,
                    diagInst.quantity,
                    diagInst.settlementAmountEur,
                    diagInst.failReason
                )
                Surface(
                    color = Color(0xFF1E293B),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "CSDR SETTLEMENT FAIL DIAGNOSIS: ${diagInst.instructionId}",
                                color = TerminalNavyPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            IconButton(onClick = { selectedInstructionForDiagnosis = null }, modifier = Modifier.size(24.dp)) {
                                Text("✕", color = TerminalTextSecondary, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Root Cause: ${diagnosis.rootCause}", color = TerminalTextPrimary, fontSize = 10.sp)
                        Text("CSDR Penalty Accrued: €${String.format("%.2f", diagnosis.financialPenaltyEur)}", color = TerminalGoldAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("Resolution Action: ${diagnosis.recommendedResolution}", color = TerminalTealMarket, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun MarginStat(label: String, value: String) {
    Column {
        Text(label, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
