package com.example.euronext.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.euronext.model.*
import com.example.ui.theme.*

@Composable
fun DigitalTwinReplayScreen(
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    var isPlaying by remember { mutableStateOf(false) }
    var currentSessionPhase by remember { mutableStateOf("09:30 CONTINUOUS LIQUIDITY") }
    var sliderPosition by remember { mutableFloatStateOf(0.35f) }

    val marketDaySchedule = listOf(
        "06:30 CET" to "PRE-MARKET PREPARATION & SYSTEM HEALTH CHECKS",
        "07:00 CET" to "EARLY MORNING REFERENCE & STATIC DATA DISSEMINATION",
        "08:00 CET" to "OPENING AUCTION ORDER ACCUMULATION & COLLAR CALCULATION",
        "09:00 CET" to "OFFICIAL MARKET OPENING & UNCROSSING",
        "10:00 CET" to "PAN-EUROPEAN CONTINUOUS TRADING & ARBITRAGE FLOW",
        "12:00 CET" to "MIDDAY LIQUIDITY & INTRADAY AUCTION CHECKS",
        "13:45 CET" to "ECB MONETARY POLICY DECISION BROADCAST",
        "15:30 CET" to "US CASH EQUITY MARKET OPENING LIQUIDITY CROSS",
        "17:30 CET" to "CLOSING AUCTION TAL-MATCHING & PRICE DISCOVERY",
        "18:00 CET" to "EURONEXT CLEARING CCP NOVATION & MULTI-ASSET MARGINING",
        "19:00 CET" to "EURONEXT SECURITIES & T2S SETTLEMENT BATCH RUN",
        "20:00 CET" to "EOD RISK AGGREGATION & AUDIT PROVENANCE FREEZE"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Digital Twin Control Station
        item {
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "EURONEXT DIGITAL TWIN // TIME-TRAVEL REPLAY",
                                color = TerminalNavyPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Deterministic Event-Sourced Market Reconstruction Engine",
                                color = TerminalTextSecondary,
                                fontSize = 9.sp
                            )
                        }
                        Surface(
                            color = Color(0x3310B981),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "REPLAY: 1.0x (SYNCHRONISED)",
                                color = TerminalStatusGreen,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Current Session State: $currentSessionPhase",
                        color = TerminalGoldAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    Slider(
                        value = sliderPosition,
                        onValueChange = {
                            sliderPosition = it
                            val idx = (it * (marketDaySchedule.size - 1)).toInt()
                            currentSessionPhase = "${marketDaySchedule[idx].first} - ${marketDaySchedule[idx].second}"
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = TerminalNavyPrimary,
                            activeTrackColor = TerminalNavyPrimary,
                            inactiveTrackColor = TerminalCardBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { isPlaying = !isPlaying },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isPlaying) TerminalStatusAmber else TerminalStatusGreen
                            )
                        ) {
                            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "Play", tint = TerminalBackgroundDark)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isPlaying) "PAUSE REPLAY" else "START REPLAY", color = TerminalBackgroundDark, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                sliderPosition = 0.0f
                                currentSessionPhase = marketDaySchedule.first().second
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TerminalSurfaceDark)
                        ) {
                            Icon(Icons.Default.Replay, contentDescription = "Reset", tint = TerminalTextPrimary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("RESET TO 06:30", color = TerminalTextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // European Market Day Timeline
        item {
            Text(
                text = "PAN-EUROPEAN MARKET DAY EVENT SEQUENCE (SYNTHETIC TWIN)",
                color = TerminalTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(marketDaySchedule) { (time, desc) ->
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(4.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = time,
                        color = TerminalGoldAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.width(80.dp)
                    )
                    Text(
                        text = desc,
                        color = TerminalTextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
