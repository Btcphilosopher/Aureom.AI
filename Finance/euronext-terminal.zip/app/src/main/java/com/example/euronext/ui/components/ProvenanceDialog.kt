package com.example.euronext.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.euronext.model.ProvenanceRecord
import com.example.euronext.model.Trade
import com.example.ui.theme.*

@Composable
fun ProvenanceDialog(
    provenance: ProvenanceRecord?,
    onDismiss: () -> Unit
) {
    if (provenance == null) return

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = TerminalCardDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalGoldAccent),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Audit",
                            tint = TerminalGoldAccent
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "DATA PROVENANCE & AUDIT TRAIL",
                            color = TerminalGoldAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TerminalTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = TerminalCardBorder)
                Spacer(modifier = Modifier.height(10.dp))

                ProvenanceItem("Provenance ID:", provenance.provenanceId)
                ProvenanceItem("Data Status:", provenance.dataStatus.name)
                ProvenanceItem("Provider Engine:", provenance.provider)
                ProvenanceItem("Source Infrastructure:", provenance.source)
                ProvenanceItem("Market & MIC:", "${provenance.market.name} (${provenance.market.mic})")
                ProvenanceItem("Jurisdiction:", provenance.jurisdiction)
                ProvenanceItem("Harmonised Rulebook:", provenance.ruleVersion)
                ProvenanceItem("Effective Timestamp:", provenance.effectiveAt)
                ProvenanceItem("Cryptographic Hash:", provenance.hashChecksum)

                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "NOTE: Euronext Terminal enforces explicit provenance. Synthetic digital twin objects are isolated with distinct cryptographic verification hashes.",
                    color = TerminalTextMuted,
                    fontSize = 9.sp,
                    lineHeight = 13.sp
                )
            }
        }
    }
}

@Composable
private fun ProvenanceItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = TerminalTextSecondary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun TradeTraceDialog(
    trade: Trade?,
    onDismiss: () -> Unit
) {
    if (trade == null) return

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = TerminalCardDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TRADE LIFECYCLE AUDIT TRACE",
                        color = TerminalNavyPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TerminalTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = TerminalCardBorder)
                Spacer(modifier = Modifier.height(10.dp))

                TraceStep("1. MATCHING", "Optiq® Engine matched ${trade.quantity} @ €${String.format("%.2f", trade.executionPrice)} (${trade.ticker})")
                TraceStep("2. TRADE ID", trade.tradeId)
                TraceStep("3. CCP NOVATION", "Euronext Clearing (Ref: ${trade.clearingRef})")
                TraceStep("4. MARGIN IMPACT", "Initial Margin calculated: €${String.format("%.2f", trade.valueEur * 0.12)}")
                TraceStep("5. 2026 SETTLEMENT", "Euronext Securities CSD (Default post-2026) T+2 DVP (Ref: ${trade.settlementRef})")
                TraceStep("6. PARTICIPANTS", "Buyer: ${trade.buyerParticipant} / Seller: ${trade.sellerParticipant}")

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalNavyPrimary),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("CLOSE AUDIT", color = TerminalBackgroundDark, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun TraceStep(title: String, desc: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            text = title,
            color = TerminalTealMarket,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = desc,
            color = TerminalTextPrimary,
            fontSize = 11.sp,
            lineHeight = 15.sp
        )
    }
}
