package com.example.euronext.model

import java.util.UUID

enum class OrderSide {
    BUY,
    SELL
}

enum class OrderType {
    LIMIT,
    MARKET,
    AUCTION,
    STOP_LOSS,
    ICEBERG
}

enum class OrderStatus {
    NEW,
    PARTIALLY_FILLED,
    FILLED,
    CANCELLED,
    REJECTED
}

data class Order(
    val orderId: String = "ORD-" + UUID.randomUUID().toString().take(8).uppercase(),
    val securityId: String,
    val ticker: String,
    val isin: String,
    val market: MarketId,
    val side: OrderSide,
    val orderType: OrderType,
    val price: Double,
    val quantity: Long,
    val executedQuantity: Long = 0,
    val displayQuantity: Long = quantity, // For Iceberg orders
    val clientAccount: String = "MEMBER-BNP-PARIBAS-EQ",
    val status: OrderStatus = OrderStatus.NEW,
    val timestampNano: Long = System.currentTimeMillis() * 1_000_000L,
    val timestampFormatted: String = "09:30:14.204"
)

data class PriceLevel(
    val price: Double,
    val totalVolume: Long,
    val orderCount: Int,
    val orders: List<Order> = emptyList()
)

data class OrderBook(
    val securityId: String,
    val ticker: String,
    val market: MarketId,
    val bids: List<PriceLevel>, // Sorted descending by price
    val asks: List<PriceLevel>, // Sorted ascending by price
    val lastTradedPrice: Double,
    val sequenceNumber: Long,
    val microprice: Double,
    val spread: Double,
    val spreadBps: Double,
    val vwap: Double,
    val timestamp: String,
    val auctionState: AuctionImbalance? = null
)

data class AuctionImbalance(
    val uncrossingPrice: Double,
    val matchedVolume: Long,
    val imbalanceVolume: Long,
    val imbalanceDirection: OrderSide,
    val staticCollarMin: Double,
    val staticCollarMax: Double,
    val dynamicCollarMin: Double,
    val dynamicCollarMax: Double,
    val auctionStatus: String = "UNCROSSING_IN_PROGRESS"
)

data class Trade(
    val tradeId: String = "TRD-" + UUID.randomUUID().toString().take(8).uppercase(),
    val isin: String,
    val ticker: String,
    val market: MarketId,
    val executionPrice: Double,
    val quantity: Long,
    val valueEur: Double = executionPrice * quantity,
    val buyerOrderId: String,
    val sellerOrderId: String,
    val buyerParticipant: String = "BNP PARIBAS ARBITRAGE",
    val sellerParticipant: String = "SOCIETE GENERALE EQ",
    val clearingRef: String = "NOV-CCP-" + UUID.randomUUID().toString().take(6).uppercase(),
    val settlementRef: String = "SET-ES-2026-" + UUID.randomUUID().toString().take(6).uppercase(),
    val timestamp: String = "09:30:22.841",
    val provenance: ProvenanceRecord
)
