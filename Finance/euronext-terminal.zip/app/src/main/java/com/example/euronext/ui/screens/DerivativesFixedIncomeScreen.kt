package com.example.euronext.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.euronext.data.SyntheticEuronextProvider
import com.example.euronext.model.*
import com.example.ui.theme.*

@Composable
fun DerivativesFixedIncomeScreen(
    bonds: List<BondInstrument>,
    powerContracts: List<EuropeanPowerContract>,
    fxRates: List<FxQuote>,
    selectedSecurity: Security,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableStateOf("OPTIONS") } // OPTIONS, BONDS, POWER, FX
    val optionChain = remember(selectedSecurity) {
        SyntheticEuronextProvider.getOptionChain(selectedSecurity.ticker, selectedSecurity.currentPrice)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Sub-Tab Switcher
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalCardDark, RoundedCornerShape(8.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                SubTabPill("EQUITY OPTIONS", activeSubTab == "OPTIONS") { activeSubTab = "OPTIONS" }
                SubTabPill("FIXED INCOME", activeSubTab == "BONDS") { activeSubTab = "BONDS" }
                SubTabPill("POWER & COMMODITY", activeSubTab == "POWER") { activeSubTab = "POWER" }
                SubTabPill("FX MATRIX", activeSubTab == "FX") { activeSubTab = "FX" }
            }
        }

        when (activeSubTab) {
            "OPTIONS" -> {
                item {
                    Surface(
                        color = TerminalCardDark,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "BLACK-SCHOLES OPTIONS MATRIX: ${selectedSecurity.ticker} (€${String.format("%.2f", selectedSecurity.currentPrice)})",
                                    color = TerminalNavyPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "ANALYTICAL GREEKS",
                                    color = TerminalGoldAccent,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("TYPE / STRIKE", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                                Text("PRICE (€)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                Text("DELTA (Δ)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                Text("IV (%)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                Text("GAMMA (Γ)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            HorizontalDivider(color = TerminalCardBorder)
                            Spacer(modifier = Modifier.height(4.dp))

                            optionChain.take(10).forEach { opt ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1.5f)) {
                                        Text(
                                            text = "${opt.optionType.name} €${String.format("%.0f", opt.strikePrice)}",
                                            color = if (opt.optionType == OptionType.CALL) TerminalStatusGreen else TerminalStatusRed,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(opt.expiryDate, color = TerminalTextMuted, fontSize = 8.sp)
                                    }
                                    Text("€${String.format("%.2f", opt.lastPrice)}", color = TerminalTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                    Text(String.format("%.2f", opt.greeks.delta), color = TerminalNavyPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                    Text("${String.format("%.1f", opt.greeks.impliedVolatility)}%", color = TerminalGoldAccent, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                    Text(String.format("%.4f", opt.greeks.gamma), color = TerminalTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                }
                                HorizontalDivider(color = TerminalCardBorder, thickness = 0.5.dp)
                            }
                        }
                    }
                }
            }

            "BONDS" -> {
                item {
                    Text(
                        text = "EUROPEAN SOVEREIGN & GREEN BONDS DIRECTORY",
                        color = TerminalTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                items(bonds) { bond ->
                    Surface(
                        color = TerminalCardDark,
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = bond.bondName,
                                            color = TerminalTextPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (bond.isGreenBond) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(color = Color(0x3310B981), shape = RoundedCornerShape(4.dp)) {
                                                Text("GREEN BOND", color = TerminalStatusGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                            }
                                        }
                                    }
                                    Text("ISIN: ${bond.isin} • Rating: ${bond.creditRating} • Maturity: ${bond.maturityDate}", color = TerminalTextMuted, fontSize = 9.sp)
                                }
                                Text("€${String.format("%.2f", bond.cleanPrice)}", color = TerminalGoldAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                StatBox("YTM", "${String.format("%.2f", bond.yieldToMaturityPct)}%")
                                StatBox("DURATION", "${bond.modifiedDuration} yrs")
                                StatBox("CONVEXITY", "${bond.convexity}")
                                StatBox("SPREAD / BUND", "+${String.format("%.1f", bond.spreadOverBundBps)} bps")
                            }
                        }
                    }
                }
            }

            "POWER" -> {
                item {
                    Text(
                        text = "EUROPEAN POWER MARKET DAY-AHEAD BASELOAD (EUR/MWh)",
                        color = TerminalTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                items(powerContracts) { pwr ->
                    Surface(
                        color = TerminalCardDark,
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Bolt, contentDescription = "Power", tint = TerminalGoldAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${pwr.region} - ${pwr.productType}",
                                        color = TerminalTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "Carbon: ${pwr.carbonIntensityGCo2Kwh} gCO2/kWh • Grid Capacity: ${pwr.gridInterconnectionCapacityMw} MW",
                                    color = TerminalTextMuted,
                                    fontSize = 9.sp
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "€${String.format("%.2f", pwr.settlementPriceEurMwh)}/MWh",
                                    color = TerminalGoldAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "${if (pwr.changePct >= 0) "+" else ""}${pwr.changePct}%",
                                    color = if (pwr.changePct >= 0) TerminalStatusGreen else TerminalStatusRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            "FX" -> {
                item {
                    Text(
                        text = "PAN-EUROPEAN FOREIGN EXCHANGE MATRIX",
                        color = TerminalTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                items(fxRates) { fx ->
                    Surface(
                        color = TerminalCardDark,
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CurrencyExchange, contentDescription = "FX", tint = TerminalTealMarket, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = fx.pair,
                                        color = TerminalGoldAccent,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                Text(
                                    text = "1M Fwd: ${fx.oneMonthForwardPoints} pts • 3M Vol: ${fx.impliedVol3M}%",
                                    color = TerminalTextMuted,
                                    fontSize = 9.sp
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = String.format("%.4f", fx.spotRate),
                                    color = TerminalTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "${if (fx.changePct >= 0) "+" else ""}${fx.changePct}%",
                                    color = if (fx.changePct >= 0) TerminalStatusGreen else TerminalStatusRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.SubTabPill(title: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (isSelected) TerminalNavyPrimary else Color.Transparent,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .weight(1f)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier.padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = title,
                color = if (isSelected) TerminalBackgroundDark else TerminalTextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun StatBox(label: String, value: String) {
    Column {
        Text(label, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
