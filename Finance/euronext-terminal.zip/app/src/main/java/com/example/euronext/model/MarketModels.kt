package com.example.euronext.model

import java.util.UUID

enum class MarketId(val code: String, val cityName: String, val countryName: String, val mic: String, val currency: String) {
    PAR("PAR", "Paris", "France", "XPAR", "EUR"),
    AMS("AMS", "Amsterdam", "Netherlands", "XAMS", "EUR"),
    MIL("MIL", "Milan", "Italy", "XMIL", "EUR"),
    BRU("BRU", "Brussels", "Belgium", "XBRU", "EUR"),
    DUB("DUB", "Dublin", "Ireland", "XDUB", "EUR"),
    LIS("LIS", "Lisbon", "Portugal", "XLIS", "EUR"),
    OSL("OSL", "Oslo", "Norway", "XOSL", "NOK"),
    ATH("ATH", "Athens", "Greece", "XATH", "EUR"); // Future / Optiq Migration June 2027

    companion object {
        fun fromCode(code: String): MarketId = entries.find { it.code.equals(code, ignoreCase = true) } ?: PAR
    }
}

enum class MarketState(val label: String) {
    PRE_OPEN("PRE-OPEN"),
    OPENING_AUCTION("OPENING AUCTION"),
    CONTINUOUS("CONTINUOUS"),
    INTRADAY_AUCTION("INTRADAY AUCTION"),
    CLOSING_AUCTION("CLOSING AUCTION"),
    POST_CLOSE("POST-CLOSE"),
    HALTED("HALTED"),
    SUSPENDED("SUSPENDED"),
    CLOSED("CLOSED")
}

enum class DataStatus {
    OFFICIAL,
    LICENSED,
    VENDOR,
    SYNTHETIC,
    SIMULATED,
    RECONSTRUCTED,
    HISTORICAL
}

data class ProvenanceRecord(
    val provenanceId: String = UUID.randomUUID().toString().take(8).uppercase(),
    val source: String = "EURONEXT-CORE-TWIN-v3.7",
    val provider: String = "SyntheticEuronextProvider",
    val timestampUtc: String = "2026-10-07 09:30:00 UTC",
    val effectiveAt: String = "2026-10-07 09:30:00 UTC",
    val market: MarketId = MarketId.PAR,
    val jurisdiction: String = "ESMA / AMF (France)",
    val dataStatus: DataStatus = DataStatus.SYNTHETIC,
    val hashChecksum: String = "0x8f2a9e...4b1",
    val ruleVersion: String = "EURONEXT-RULEBOOK-2026.09.v2"
)

data class EuronextMarket(
    val marketId: MarketId,
    val marketName: String,
    val city: String,
    val country: String,
    val mic: String,
    val currency: String,
    val timezone: String,
    val regulatoryJurisdiction: String,
    val isRegulatedMarket: Boolean,
    val isMtf: Boolean,
    val tradingPlatform: String = "Optiq®",
    val clearingModel: String = "Euronext Clearing (Multi-asset CCP)",
    val settlementModel: String = "Euronext Securities / T2S Multi-CSD",
    val localRulebook: String,
    val harmonisedRulebook: String = "Euronext Rule Book Book I (Harmonised)",
    val state: MarketState = MarketState.CONTINUOUS,
    val benchmarkIndex: String,
    val benchmarkChangePct: Double,
    val benchmarkValue: Double,
    val dailyTurnoverEurM: Double,
    val totalTradesToday: Int,
    val openOrdersCount: Int,
    val latitude: Double,
    val longitude: Double,
    val isIntegrationScheduled: Boolean = false, // for Athens 2027
    val scheduledMigrationDate: String? = null
)
