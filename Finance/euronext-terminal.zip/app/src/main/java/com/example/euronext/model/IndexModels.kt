package com.example.euronext.model

enum class IndexCategory {
    NATIONAL_BENCHMARK, // CAC 40, AEX, FTSE MIB, BEL 20, ISEQ 20, PSI, OBX
    PAN_EUROPEAN_CORE,  // Euronext Europe 100, Euronext Europe 50, Euronext Eurozone 50
    THEMATIC_SECTOR,    // Euronext European Banks, Industrials, Energy, Tech
    FACTOR_STRATEGY,    // Low Vol 50, Dividend 50, Quality 50, Value 50
    CUSTOM_SYNTHETIC    // User-created indices
}

data class IndexConstituent(
    val ticker: String,
    val isin: String,
    val name: String,
    val market: MarketId,
    val sector: String,
    val currentPrice: Double,
    val changePct: Double,
    val sharesInIndexM: Double,
    val freeFloatFactor: Double,
    val capFactor: Double = 1.0,
    val weightPct: Double,
    val pointsContribution: Double
)

data class IndexState(
    val indexCode: String,
    val indexName: String,
    val category: IndexCategory,
    val baseMarket: MarketId?,
    val currency: String = "EUR",
    val currentValue: Double,
    val openValue: Double,
    val highValue: Double,
    val lowValue: Double,
    val previousClose: Double,
    val changePoints: Double,
    val changePct: Double,
    val divisor: Double,
    val marketCapEurB: Double,
    val constituents: List<IndexConstituent>,
    val isRealTime: Boolean = true,
    val lastCalculationTime: String = "09:30:45 UTC",
    val reviewDate: String = "Third Friday of March/Sept",
    val methodology: String = "Free-float market capitalisation weighted with 15% constituent capping",
    val provenance: ProvenanceRecord
)

data class CustomIndexSpec(
    val code: String,
    val name: String,
    val universe: String = "EURONEXT_ALL_MARKETS",
    val filterSector: String? = null,
    val weightingRule: String = "EQUAL_WEIGHTED", // or MARKET_CAP, FACTOR_WEIGHTED
    val constituentTickers: List<String>,
    val baseDivisor: Double = 1000.0
)
