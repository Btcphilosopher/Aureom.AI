package com.example.euronext.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.euronext.data.SyntheticEuronextProvider
import com.example.euronext.model.*
import com.example.ui.theme.*

@Composable
fun SurveillanceRiskScreen(
    surveillanceAlerts: List<SurveillanceAlert>,
    circuitBreakers: List<CircuitBreakerEvent>,
    onApplyScenario: (MacroScenario) -> Unit,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val scenarios = remember { SyntheticEuronextProvider.getMacroScenarios() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Macroeconomic Stress Scenario Lab
        item {
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "EUROPEAN MACROECONOMIC SCENARIO & STRESS LAB",
                            color = TerminalNavyPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(Icons.Default.Security, contentDescription = "Risk", tint = TerminalNavyPrimary, modifier = Modifier.size(16.dp))
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Simulate pan-European cross-asset liquidity shocks, index repricing, and CCP margin spikes.",
                        color = TerminalTextSecondary,
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    scenarios.forEach { sc ->
                        Surface(
                            color = TerminalSurfaceDark,
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = sc.name,
                                        color = TerminalGoldAccent,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = sc.description,
                                        color = TerminalTextMuted,
                                        fontSize = 9.sp,
                                        maxLines = 2
                                    )
                                    Text(
                                        text = "Shocks: CAC40 ${sc.cac40ShockPct}% • MIB ${sc.mibShockPct}% • Banks ${sc.banksFactorShockPct}% • Margin +${sc.ccpMarginIncreasePct}%",
                                        color = TerminalTextSecondary,
                                        fontSize = 8.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Button(
                                    onClick = { onApplyScenario(sc) },
                                    colors = ButtonDefaults.buttonColors(containerColor = TerminalNavyPrimary),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Inject", tint = TerminalBackgroundDark, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("INJECT", color = TerminalBackgroundDark, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Market Surveillance Alerts Feed
        item {
            Text(
                text = "MAR / MiFID II REAL-TIME SURVEILLANCE ALERTS",
                color = TerminalTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(surveillanceAlerts) { alert ->
            val isCritical = alert.severity == AlertSeverity.CRITICAL
            Surface(
                color = if (isCritical) Color(0xFF2A1515) else TerminalCardDark,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isCritical) TerminalStatusRed else TerminalGoldAccent
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = "Alert",
                                tint = if (isCritical) TerminalStatusRed else TerminalGoldAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${alert.alertType.name} [${alert.alertId}]",
                                color = if (isCritical) TerminalStatusRed else TerminalGoldAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Text(
                            text = alert.timestamp,
                            color = TerminalTextMuted,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Target: ${alert.ticker} (${alert.isin}) on ${alert.market.cityName} (${alert.market.mic})",
                        color = TerminalTextPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = alert.triggerDetail,
                        color = TerminalTextSecondary,
                        fontSize = 9.sp,
                        lineHeight = 13.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Action: ${alert.recommendedAction}",
                        color = TerminalTealMarket,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Active Circuit Breaker Volatility Interruptions
        if (circuitBreakers.isNotEmpty()) {
            item {
                Text(
                    text = "OPTIQ® CIRCUIT BREAKERS & TRADING SAFEGUARDS",
                    color = TerminalStatusRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            items(circuitBreakers) { cb ->
                Surface(
                    color = Color(0xFF3B1515),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalStatusRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "VOLATILITY INTERRUPTION: ${cb.ticker} [${cb.market.mic}]",
                            color = TerminalStatusRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Triggered at €${String.format("%.2f", cb.triggerPrice)} (Ref: €${String.format("%.2f", cb.referencePrice)}, Deviation: ${String.format("%.1f", cb.deviationPct)}% > Threshold ${cb.bandThresholdPct}%)",
                            color = TerminalTextPrimary,
                            fontSize = 9.sp
                        )
                        Text(
                            text = "State: ${cb.state} • Halt Duration: ${cb.haltDurationSeconds}s",
                            color = TerminalGoldAccent,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
