package com.example.euronext.model

enum class OptionType {
    CALL,
    PUT
}

enum class ExerciseStyle {
    EUROPEAN,
    AMERICAN
}

data class OptionGreeks(
    val delta: Double,
    val gamma: Double,
    val vega: Double,
    val theta: Double,
    val rho: Double,
    val impliedVolatility: Double
)

data class OptionContract(
    val contractCode: String,
    val underlyingTicker: String,
    val underlyingPrice: Double,
    val optionType: OptionType,
    val strikePrice: Double,
    val expiryDate: String,
    val daysToExpiry: Int,
    val bidPrice: Double,
    val askPrice: Double,
    val lastPrice: Double,
    val volume: Long,
    val openInterest: Long,
    val greeks: OptionGreeks,
    val exerciseStyle: ExerciseStyle = ExerciseStyle.EUROPEAN,
    val multiplier: Int = 100
)

data class FuturesContract(
    val contractCode: String,
    val underlyingSymbol: String,
    val underlyingName: String,
    val assetClass: AssetClass,
    val spotPrice: Double,
    val futuresPrice: Double,
    val basis: Double,
    val impliedFinancingRatePct: Double,
    val rollYieldPct: Double,
    val expiryDate: String,
    val daysToExpiry: Int,
    val openInterest: Long,
    val volume: Long,
    val tickValue: Double,
    val settlementType: String = "CASH / Euronext Clearing"
)

data class DividendFutureContract(
    val contractCode: String,
    val underlyingTicker: String,
    val expiryYear: Int,
    val expectedDividendPoints: Double,
    val realisedDividendPoints: Double,
    val basisPoints: Double,
    val marketPriceEur: Double,
    val openInterest: Long
)

data class VolatilityPoint(
    val strike: Double,
    val moneynessPct: Double,
    val expiryDays: Int,
    val impliedVolPct: Double
)
