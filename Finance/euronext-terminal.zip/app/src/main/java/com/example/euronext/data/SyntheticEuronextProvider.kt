package com.example.euronext.data

import com.example.euronext.engine.BlackScholesEngine
import com.example.euronext.model.*
import java.util.UUID
import kotlin.math.max

object SyntheticEuronextProvider {

    fun getMarkets(): List<EuronextMarket> {
        return listOf(
            EuronextMarket(
                marketId = MarketId.PAR,
                marketName = "Euronext Paris",
                city = "Paris",
                country = "France",
                mic = "XPAR",
                currency = "EUR",
                timezone = "Europe/Paris (CET)",
                regulatoryJurisdiction = "Autorité des Marchés Financiers (AMF) / ESMA",
                isRegulatedMarket = true,
                isMtf = false,
                localRulebook = "Euronext Rule Book Book II (Paris Specific Rules)",
                state = MarketState.CONTINUOUS,
                benchmarkIndex = "CAC 40",
                benchmarkChangePct = +0.64,
                benchmarkValue = 8124.50,
                dailyTurnoverEurM = 4850.2,
                totalTradesToday = 342190,
                openOrdersCount = 98140,
                latitude = 48.8688,
                longitude = 2.3413
            ),
            EuronextMarket(
                marketId = MarketId.AMS,
                marketName = "Euronext Amsterdam",
                city = "Amsterdam",
                country = "Netherlands",
                mic = "XAMS",
                currency = "EUR",
                timezone = "Europe/Amsterdam (CET)",
                regulatoryJurisdiction = "Autoriteit Financiële Markten (AFM) / ESMA",
                isRegulatedMarket = true,
                isMtf = false,
                localRulebook = "Euronext Rule Book Book II (Amsterdam Specific Rules)",
                state = MarketState.CONTINUOUS,
                benchmarkIndex = "AEX",
                benchmarkChangePct = +0.88,
                benchmarkValue = 918.42,
                dailyTurnoverEurM = 3720.5,
                totalTradesToday = 265430,
                openOrdersCount = 74300,
                latitude = 52.3742,
                longitude = 4.8967
            ),
            EuronextMarket(
                marketId = MarketId.MIL,
                marketName = "Euronext Milan (Borsa Italiana)",
                city = "Milan",
                country = "Italy",
                mic = "XMIL",
                currency = "EUR",
                timezone = "Europe/Rome (CET)",
                regulatoryJurisdiction = "CONSOB / ESMA",
                isRegulatedMarket = true,
                isMtf = false,
                localRulebook = "Rules of the Markets organised and managed by Borsa Italiana S.p.A.",
                state = MarketState.CONTINUOUS,
                benchmarkIndex = "FTSE MIB",
                benchmarkChangePct = -0.32,
                benchmarkValue = 34890.10,
                dailyTurnoverEurM = 2940.8,
                totalTradesToday = 210870,
                openOrdersCount = 61920,
                latitude = 45.4654,
                longitude = 9.1865
            ),
            EuronextMarket(
                marketId = MarketId.BRU,
                marketName = "Euronext Brussels",
                city = "Brussels",
                country = "Belgium",
                mic = "XBRU",
                currency = "EUR",
                timezone = "Europe/Brussels (CET)",
                regulatoryJurisdiction = "Financial Services and Markets Authority (FSMA) / ESMA",
                isRegulatedMarket = true,
                isMtf = false,
                localRulebook = "Euronext Rule Book Book II (Brussels Specific Rules)",
                state = MarketState.CONTINUOUS,
                benchmarkIndex = "BEL 20",
                benchmarkChangePct = +0.41,
                benchmarkValue = 4210.85,
                dailyTurnoverEurM = 890.4,
                totalTradesToday = 74500,
                openOrdersCount = 28100,
                latitude = 50.8467,
                longitude = 4.3517
            ),
            EuronextMarket(
                marketId = MarketId.DUB,
                marketName = "Euronext Dublin",
                city = "Dublin",
                country = "Ireland",
                mic = "XDUB",
                currency = "EUR",
                timezone = "Europe/Dublin (GMT/IST)",
                regulatoryJurisdiction = "Central Bank of Ireland (CBI) / ESMA",
                isRegulatedMarket = true,
                isMtf = false,
                localRulebook = "Euronext Rule Book Book II (Dublin Specific Rules)",
                state = MarketState.CONTINUOUS,
                benchmarkIndex = "ISEQ 20",
                benchmarkChangePct = +0.15,
                benchmarkValue = 9740.20,
                dailyTurnoverEurM = 620.1,
                totalTradesToday = 49200,
                openOrdersCount = 18450,
                latitude = 53.3498,
                longitude = -6.2603
            ),
            EuronextMarket(
                marketId = MarketId.LIS,
                marketName = "Euronext Lisbon",
                city = "Lisbon",
                country = "Portugal",
                mic = "XLIS",
                currency = "EUR",
                timezone = "Europe/Lisbon (WET/WEST)",
                regulatoryJurisdiction = "Comissão do Mercado de Valores Mobiliários (CMVM) / ESMA",
                isRegulatedMarket = true,
                isMtf = false,
                localRulebook = "Euronext Rule Book Book II (Lisbon Specific Rules)",
                state = MarketState.CONTINUOUS,
                benchmarkIndex = "PSI",
                benchmarkChangePct = +0.28,
                benchmarkValue = 6845.30,
                dailyTurnoverEurM = 310.6,
                totalTradesToday = 31200,
                openOrdersCount = 12900,
                latitude = 38.7223,
                longitude = -9.1393
            ),
            EuronextMarket(
                marketId = MarketId.OSL,
                marketName = "Oslo Børs",
                city = "Oslo",
                country = "Norway",
                mic = "XOSL",
                currency = "NOK",
                timezone = "Europe/Oslo (CET)",
                regulatoryJurisdiction = "Finanstilsynet / EEA",
                isRegulatedMarket = true,
                isMtf = false,
                localRulebook = "Oslo Børs Rule Book II (Oslo Specific Rules)",
                state = MarketState.CONTINUOUS,
                benchmarkIndex = "OBX",
                benchmarkChangePct = +1.12,
                benchmarkValue = 1398.60,
                dailyTurnoverEurM = 1180.3,
                totalTradesToday = 94100,
                openOrdersCount = 35200,
                latitude = 59.9139,
                longitude = 10.7522
            ),
            EuronextMarket(
                marketId = MarketId.ATH,
                marketName = "Euronext Athens (Integration Roadmap)",
                city = "Athens",
                country = "Greece",
                mic = "XATH",
                currency = "EUR",
                timezone = "Europe/Athens (EET)",
                regulatoryJurisdiction = "Hellenic Capital Market Commission (HCMC) / ESMA",
                isRegulatedMarket = true,
                isMtf = false,
                localRulebook = "Athens Stock Exchange Rules (Transitioning to Euronext Optiq® Rulebook)",
                state = MarketState.PRE_OPEN,
                benchmarkIndex = "Athex Composite",
                benchmarkChangePct = +0.55,
                benchmarkValue = 1460.10,
                dailyTurnoverEurM = 145.0,
                totalTradesToday = 18200,
                openOrdersCount = 8900,
                latitude = 37.9838,
                longitude = 23.7275,
                isIntegrationScheduled = true,
                scheduledMigrationDate = "Optiq® Migration: June 2027"
            )
        )
    }

    fun getSecurities(): List<Security> {
        val prov = ProvenanceRecord(market = MarketId.PAR, dataStatus = DataStatus.SYNTHETIC)

        return listOf(
            Security(
                securityId = "SEC-MC-FR",
                isin = "FR0000121014",
                ticker = "MC",
                sedol = "4061412",
                localCode = "12101",
                name = "LVMH Moët Hennessy Louis Vuitton",
                mic = "XPAR",
                primaryMarket = MarketId.PAR,
                country = "France",
                currency = "EUR",
                instrumentType = InstrumentType.ORDINARY_SHARE,
                assetClass = AssetClass.EQUITIES,
                issuer = IssuerProfile(
                    issuerId = "ISS-LVMH-01",
                    companyName = "LVMH SE",
                    legalEntityIdentifier = "I92J5R0488O2N5U3G877",
                    country = "France",
                    headquarters = "Paris, France",
                    sector = "Consumer Discretionary",
                    industry = "Luxury Goods & Fashion",
                    marketCapEurB = 345.8,
                    sharesOutstandingM = 502.5,
                    freeFloatPct = 52.0,
                    esgScore = 88,
                    esgRating = "AA",
                    primaryIndex = "CAC 40",
                    description = "World leader in high-quality luxury products spanning Wines & Spirits, Fashion & Leather Goods, Perfumes & Cosmetics, and Watches & Jewelry.",
                    dividendYieldPct = 1.95,
                    peRatio = 24.2,
                    nextEarningsDate = "2026-10-24"
                ),
                listings = listOf(
                    Listing("SEC-MC-FR", MarketId.PAR, "XPAR", "EUR", "MC", true, "ACTIVE", "Table_01", 1, 688.40, +1.24, 620400),
                    Listing("SEC-MC-AMS", MarketId.AMS, "XAMS", "EUR", "MC", false, "ACTIVE", "Table_01", 1, 688.50, +1.25, 41200),
                    Listing("SEC-MC-MIL", MarketId.MIL, "XMIL", "EUR", "MC", false, "ACTIVE", "Table_01", 1, 688.30, +1.22, 35100)
                ),
                nominalValue = 0.30,
                currentPrice = 688.40,
                openPrice = 680.00,
                highPrice = 691.20,
                lowPrice = 679.50,
                previousClose = 679.95,
                volume = 620400,
                turnoverEur = 427103360.0,
                changePct = +1.24,
                bidPrice = 688.30,
                askPrice = 688.50,
                bidSize = 1450,
                askSize = 1820,
                provenance = prov
            ),
            Security(
                securityId = "SEC-ASML-NL",
                isin = "NL0010273215",
                ticker = "ASML",
                sedol = "B011DH2",
                localCode = "ASML",
                name = "ASML Holding N.V.",
                mic = "XAMS",
                primaryMarket = MarketId.AMS,
                country = "Netherlands",
                currency = "EUR",
                instrumentType = InstrumentType.ORDINARY_SHARE,
                assetClass = AssetClass.EQUITIES,
                issuer = IssuerProfile(
                    issuerId = "ISS-ASML-01",
                    companyName = "ASML Holding N.V.",
                    legalEntityIdentifier = "7245009UXNV207399D74",
                    country = "Netherlands",
                    headquarters = "Veldhoven, Netherlands",
                    sector = "Technology",
                    industry = "Semiconductors & Lithography",
                    marketCapEurB = 368.4,
                    sharesOutstandingM = 391.8,
                    freeFloatPct = 84.5,
                    esgScore = 93,
                    esgRating = "AAA",
                    primaryIndex = "AEX",
                    description = "Global provider of leading-edge photolithography systems (EUV and DUV) essential for semiconductor manufacturing worldwide.",
                    dividendYieldPct = 0.88,
                    peRatio = 38.5,
                    nextEarningsDate = "2026-10-16"
                ),
                listings = listOf(
                    Listing("SEC-ASML-NL", MarketId.AMS, "XAMS", "EUR", "ASML", true, "ACTIVE", "Table_01", 1, 940.20, +2.15, 845000),
                    Listing("SEC-ASML-PAR", MarketId.PAR, "XPAR", "EUR", "ASML", false, "ACTIVE", "Table_01", 1, 940.10, +2.14, 98200)
                ),
                nominalValue = 0.09,
                currentPrice = 940.20,
                openPrice = 920.40,
                highPrice = 944.80,
                lowPrice = 918.00,
                previousClose = 920.40,
                volume = 845000,
                turnoverEur = 794469000.0,
                changePct = +2.15,
                bidPrice = 940.00,
                askPrice = 940.40,
                bidSize = 2100,
                askSize = 1950,
                provenance = prov.copy(market = MarketId.AMS)
            ),
            Security(
                securityId = "SEC-TTE-FR",
                isin = "FR0000120271",
                ticker = "TTE",
                sedol = "5940428",
                localCode = "12027",
                name = "TotalEnergies SE",
                mic = "XPAR",
                primaryMarket = MarketId.PAR,
                country = "France",
                currency = "EUR",
                instrumentType = InstrumentType.ORDINARY_SHARE,
                assetClass = AssetClass.EQUITIES,
                issuer = IssuerProfile(
                    issuerId = "ISS-TTE-01",
                    companyName = "TotalEnergies SE",
                    legalEntityIdentifier = "529900S215GE231I5U11",
                    country = "France",
                    headquarters = "Courbevoie, France",
                    sector = "Energy",
                    industry = "Integrated Multi-Energy",
                    marketCapEurB = 148.2,
                    sharesOutstandingM = 2390.0,
                    freeFloatPct = 87.0,
                    esgScore = 81,
                    esgRating = "A",
                    primaryIndex = "CAC 40",
                    description = "Broad energy company producing and marketing oil, biofuels, natural gas, green gases, renewables and electricity across 130 countries.",
                    dividendYieldPct = 5.20,
                    peRatio = 7.8,
                    nextEarningsDate = "2026-10-31"
                ),
                listings = listOf(
                    Listing("SEC-TTE-FR", MarketId.PAR, "XPAR", "EUR", "TTE", true, "ACTIVE", "Table_01", 1, 62.05, -0.40, 2480000),
                    Listing("SEC-TTE-BRU", MarketId.BRU, "XBRU", "EUR", "TTE", false, "ACTIVE", "Table_01", 1, 62.04, -0.42, 142000)
                ),
                nominalValue = 2.50,
                currentPrice = 62.05,
                openPrice = 62.40,
                highPrice = 62.85,
                lowPrice = 61.90,
                previousClose = 62.30,
                volume = 2480000,
                turnoverEur = 153884000.0,
                changePct = -0.40,
                bidPrice = 62.04,
                askPrice = 62.06,
                bidSize = 12500,
                askSize = 14200,
                provenance = prov
            ),
            Security(
                securityId = "SEC-ENEL-IT",
                isin = "IT0003128367",
                ticker = "ENEL",
                sedol = "5751978",
                localCode = "ENEL",
                name = "Enel S.p.A.",
                mic = "XMIL",
                primaryMarket = MarketId.MIL,
                country = "Italy",
                currency = "EUR",
                instrumentType = InstrumentType.ORDINARY_SHARE,
                assetClass = AssetClass.EQUITIES,
                issuer = IssuerProfile(
                    issuerId = "ISS-ENEL-01",
                    companyName = "Enel S.p.A.",
                    legalEntityIdentifier = "W57H5K7G2J3Z90R48190",
                    country = "Italy",
                    headquarters = "Rome, Italy",
                    sector = "Utilities",
                    industry = "Renewable Electricity & Grid",
                    marketCapEurB = 71.4,
                    sharesOutstandingM = 10166.0,
                    freeFloatPct = 76.4,
                    esgScore = 91,
                    esgRating = "AAA",
                    primaryIndex = "FTSE MIB",
                    description = "Multinational power company and leading integrated player in world electricity and renewables markets.",
                    dividendYieldPct = 6.45,
                    peRatio = 10.1,
                    nextEarningsDate = "2026-11-05"
                ),
                listings = listOf(
                    Listing("SEC-ENEL-IT", MarketId.MIL, "XMIL", "EUR", "ENEL", true, "ACTIVE", "Table_01", 1, 7.02, +0.57, 4820000)
                ),
                nominalValue = 1.00,
                currentPrice = 7.02,
                openPrice = 6.98,
                highPrice = 7.06,
                lowPrice = 6.96,
                previousClose = 6.98,
                volume = 4820000,
                turnoverEur = 33836400.0,
                changePct = +0.57,
                bidPrice = 7.018,
                askPrice = 7.022,
                bidSize = 45000,
                askSize = 38000,
                provenance = prov.copy(market = MarketId.MIL)
            ),
            Security(
                securityId = "SEC-EQNR-NO",
                isin = "NO0010096985",
                ticker = "EQNR",
                sedol = "7156294",
                localCode = "EQNR",
                name = "Equinor ASA",
                mic = "XOSL",
                primaryMarket = MarketId.OSL,
                country = "Norway",
                currency = "NOK",
                instrumentType = InstrumentType.ORDINARY_SHARE,
                assetClass = AssetClass.EQUITIES,
                issuer = IssuerProfile(
                    issuerId = "ISS-EQNR-01",
                    companyName = "Equinor ASA",
                    legalEntityIdentifier = "549300UTDYXJ82DY9W85",
                    country = "Norway",
                    headquarters = "Stavanger, Norway",
                    sector = "Energy",
                    industry = "Oil, Gas & Offshore Wind",
                    marketCapEurB = 78.5,
                    sharesOutstandingM = 2950.0,
                    freeFloatPct = 33.0,
                    esgScore = 86,
                    esgRating = "AA",
                    primaryIndex = "OBX",
                    description = "Norwegian state-backed broad energy company developing oil, gas, wind and solar energy across 30 countries.",
                    dividendYieldPct = 7.80,
                    peRatio = 6.9,
                    nextEarningsDate = "2026-10-29"
                ),
                listings = listOf(
                    Listing("SEC-EQNR-NO", MarketId.OSL, "XOSL", "NOK", "EQNR", true, "ACTIVE", "Table_01", 1, 312.40, +1.80, 1850000)
                ),
                nominalValue = 2.50,
                currentPrice = 312.40,
                openPrice = 307.00,
                highPrice = 314.20,
                lowPrice = 306.50,
                previousClose = 306.87,
                volume = 1850000,
                turnoverEur = 50296400.0,
                changePct = +1.80,
                bidPrice = 312.20,
                askPrice = 312.60,
                bidSize = 8500,
                askSize = 9200,
                provenance = prov.copy(market = MarketId.OSL)
            ),
            Security(
                securityId = "SEC-CRH-IE",
                isin = "IE0001827041",
                ticker = "CRH",
                sedol = "0182704",
                localCode = "CRH",
                name = "CRH plc",
                mic = "XDUB",
                primaryMarket = MarketId.DUB,
                country = "Ireland",
                currency = "EUR",
                instrumentType = InstrumentType.ORDINARY_SHARE,
                assetClass = AssetClass.EQUITIES,
                issuer = IssuerProfile(
                    issuerId = "ISS-CRH-01",
                    companyName = "CRH plc",
                    legalEntityIdentifier = "549300MIDFDMN8W8L121",
                    country = "Ireland",
                    headquarters = "Dublin, Ireland",
                    sector = "Materials",
                    industry = "Building Materials & Solutions",
                    marketCapEurB = 58.1,
                    sharesOutstandingM = 712.0,
                    freeFloatPct = 95.0,
                    esgScore = 83,
                    esgRating = "A",
                    primaryIndex = "ISEQ 20",
                    description = "Leading provider of building materials solutions that build, connect and improve our world.",
                    dividendYieldPct = 1.70,
                    peRatio = 18.4,
                    nextEarningsDate = "2026-11-12"
                ),
                listings = listOf(
                    Listing("SEC-CRH-IE", MarketId.DUB, "XDUB", "EUR", "CRH", true, "ACTIVE", "Table_01", 1, 81.60, +0.37, 340000)
                ),
                nominalValue = 0.32,
                currentPrice = 81.60,
                openPrice = 81.30,
                highPrice = 82.10,
                lowPrice = 81.00,
                previousClose = 81.30,
                volume = 340000,
                turnoverEur = 27744000.0,
                changePct = +0.37,
                bidPrice = 81.55,
                askPrice = 81.65,
                bidSize = 3400,
                askSize = 4100,
                provenance = prov.copy(market = MarketId.DUB)
            ),
            Security(
                securityId = "SEC-GALP-PT",
                isin = "PTGAL0AM0009",
                ticker = "GALP",
                sedol = "B1FW730",
                localCode = "GALP",
                name = "Galp Energia SGPS S.A.",
                mic = "XLIS",
                primaryMarket = MarketId.LIS,
                country = "Portugal",
                currency = "EUR",
                instrumentType = InstrumentType.ORDINARY_SHARE,
                assetClass = AssetClass.EQUITIES,
                issuer = IssuerProfile(
                    issuerId = "ISS-GALP-01",
                    companyName = "Galp Energia SGPS S.A.",
                    legalEntityIdentifier = "549300H2083X719F0793",
                    country = "Portugal",
                    headquarters = "Lisbon, Portugal",
                    sector = "Energy",
                    industry = "Upstream, Refining & Gas",
                    marketCapEurB = 14.8,
                    sharesOutstandingM = 773.0,
                    freeFloatPct = 58.0,
                    esgScore = 79,
                    esgRating = "BBB",
                    primaryIndex = "PSI",
                    description = "Portuguese energy group focused on upstream exploration, green hydrogen, and retail energy networks.",
                    dividendYieldPct = 4.10,
                    peRatio = 9.4,
                    nextEarningsDate = "2026-10-26"
                ),
                listings = listOf(
                    Listing("SEC-GALP-PT", MarketId.LIS, "XLIS", "EUR", "GALP", true, "ACTIVE", "Table_01", 1, 19.15, +0.80, 890000)
                ),
                nominalValue = 1.00,
                currentPrice = 19.15,
                openPrice = 19.00,
                highPrice = 19.35,
                lowPrice = 18.95,
                previousClose = 19.00,
                volume = 890000,
                turnoverEur = 17043500.0,
                changePct = +0.80,
                bidPrice = 19.14,
                askPrice = 19.16,
                bidSize = 7800,
                askSize = 6500,
                provenance = prov.copy(market = MarketId.LIS)
            ),
            Security(
                securityId = "SEC-ABI-BE",
                isin = "BE0974293251",
                ticker = "ABI",
                sedol = "B056H42",
                localCode = "ABI",
                name = "Anheuser-Busch InBev SA/NV",
                mic = "XBRU",
                primaryMarket = MarketId.BRU,
                country = "Belgium",
                currency = "EUR",
                instrumentType = InstrumentType.ORDINARY_SHARE,
                assetClass = AssetClass.EQUITIES,
                issuer = IssuerProfile(
                    issuerId = "ISS-ABI-01",
                    companyName = "Anheuser-Busch InBev SA/NV",
                    legalEntityIdentifier = "5493008VUK0SS9113645",
                    country = "Belgium",
                    headquarters = "Leuven, Belgium",
                    sector = "Consumer Staples",
                    industry = "Brewing & Beverages",
                    marketCapEurB = 112.5,
                    sharesOutstandingM = 2018.0,
                    freeFloatPct = 56.0,
                    esgScore = 85,
                    esgRating = "AA",
                    primaryIndex = "BEL 20",
                    description = "World's largest brewing company managing a portfolio of over 500 global and local iconic beer brands.",
                    dividendYieldPct = 1.50,
                    peRatio = 19.1,
                    nextEarningsDate = "2026-10-30"
                ),
                listings = listOf(
                    Listing("SEC-ABI-BE", MarketId.BRU, "XBRU", "EUR", "ABI", true, "ACTIVE", "Table_01", 1, 55.80, +0.65, 1120000),
                    Listing("SEC-ABI-PAR", MarketId.PAR, "XPAR", "EUR", "ABI", false, "ACTIVE", "Table_01", 1, 55.78, +0.61, 84000)
                ),
                nominalValue = 1.00,
                currentPrice = 55.80,
                openPrice = 55.40,
                highPrice = 56.10,
                lowPrice = 55.30,
                previousClose = 55.44,
                volume = 1120000,
                turnoverEur = 62496000.0,
                changePct = +0.65,
                bidPrice = 55.78,
                askPrice = 55.82,
                bidSize = 8200,
                askSize = 7900,
                provenance = prov.copy(market = MarketId.BRU)
            )
        )
    }

    fun getIndices(): List<IndexState> {
        val prov = ProvenanceRecord(market = MarketId.PAR, dataStatus = DataStatus.SYNTHETIC)

        return listOf(
            IndexState(
                indexCode = "CAC40",
                indexName = "CAC 40® Index",
                category = IndexCategory.NATIONAL_BENCHMARK,
                baseMarket = MarketId.PAR,
                currentValue = 8124.50,
                openValue = 8072.90,
                highValue = 8140.20,
                lowValue = 8068.50,
                previousClose = 8072.90,
                changePoints = +51.60,
                changePct = +0.64,
                divisor = 28410294.0,
                marketCapEurB = 2410.8,
                constituents = listOf(
                    IndexConstituent("MC", "FR0000121014", "LVMH", MarketId.PAR, "Luxury", 688.40, +1.24, 502.5, 0.52, 1.0, 11.45, +12.4),
                    IndexConstituent("TTE", "FR0000120271", "TotalEnergies", MarketId.PAR, "Energy", 62.05, -0.40, 2390.0, 0.87, 1.0, 8.20, -3.1),
                    IndexConstituent("SAN", "FR0000120578", "Sanofi", MarketId.PAR, "Healthcare", 89.15, +0.30, 1260.0, 0.90, 1.0, 7.10, +2.2),
                    IndexConstituent("AIR", "NL0000235190", "Airbus", MarketId.PAR, "Aerospace", 154.20, +1.10, 788.0, 0.74, 1.0, 6.40, +6.8),
                    IndexConstituent("SU", "FR0000121972", "Schneider Electric", MarketId.PAR, "Industrials", 228.50, +0.95, 560.0, 0.93, 1.0, 7.80, +7.2)
                ),
                provenance = prov
            ),
            IndexState(
                indexCode = "AEX",
                indexName = "AEX-Index®",
                category = IndexCategory.NATIONAL_BENCHMARK,
                baseMarket = MarketId.AMS,
                currentValue = 918.42,
                openValue = 910.40,
                highValue = 920.15,
                lowValue = 909.80,
                previousClose = 910.40,
                changePoints = +8.02,
                changePct = +0.88,
                divisor = 14201940.0,
                marketCapEurB = 1380.5,
                constituents = listOf(
                    IndexConstituent("ASML", "NL0010273215", "ASML Holding", MarketId.AMS, "Technology", 940.20, +2.15, 391.8, 0.85, 1.0, 17.80, +5.4),
                    IndexConstituent("HEIA", "NL0000009165", "Heineken", MarketId.AMS, "Consumer Staples", 86.40, +0.25, 576.0, 0.48, 1.0, 4.10, +0.4),
                    IndexConstituent("INGA", "NL0011821202", "ING Groep", MarketId.AMS, "Financials", 16.45, +0.60, 3620.0, 0.98, 1.0, 6.20, +1.1)
                ),
                provenance = prov.copy(market = MarketId.AMS)
            ),
            IndexState(
                indexCode = "FTSEMIB",
                indexName = "FTSE MIB® Index",
                category = IndexCategory.NATIONAL_BENCHMARK,
                baseMarket = MarketId.MIL,
                currentValue = 34890.10,
                openValue = 35002.00,
                highValue = 35080.40,
                lowValue = 34810.00,
                previousClose = 35002.00,
                changePoints = -111.90,
                changePct = -0.32,
                divisor = 1948200.0,
                marketCapEurB = 840.2,
                constituents = listOf(
                    IndexConstituent("ENEL", "IT0003128367", "Enel", MarketId.MIL, "Utilities", 7.02, +0.57, 10166.0, 0.76, 1.0, 9.40, +18.2),
                    IndexConstituent("ISP", "IT0000072618", "Intesa Sanpaolo", MarketId.MIL, "Financials", 3.82, -0.75, 18280.0, 0.85, 1.0, 8.80, -22.4),
                    IndexConstituent("RACE", "NL0011586010", "Ferrari", MarketId.MIL, "Automotive", 412.00, +0.40, 181.0, 0.65, 1.0, 7.50, +12.0)
                ),
                provenance = prov.copy(market = MarketId.MIL)
            ),
            IndexState(
                indexCode = "EURONEXT100",
                indexName = "Euronext Europe 100™ (Synthetic)",
                category = IndexCategory.PAN_EUROPEAN_CORE,
                baseMarket = null,
                currentValue = 1580.40,
                openValue = 1571.20,
                highValue = 1584.10,
                lowValue = 1569.80,
                previousClose = 1571.20,
                changePoints = +9.20,
                changePct = +0.59,
                divisor = 48209100.0,
                marketCapEurB = 4920.0,
                constituents = listOf(
                    IndexConstituent("MC", "FR0000121014", "LVMH", MarketId.PAR, "Luxury", 688.40, +1.24, 502.5, 0.52, 1.0, 6.80, +1.8),
                    IndexConstituent("ASML", "NL0010273215", "ASML", MarketId.AMS, "Technology", 940.20, +2.15, 391.8, 0.85, 1.0, 7.20, +2.4),
                    IndexConstituent("TTE", "FR0000120271", "TotalEnergies", MarketId.PAR, "Energy", 62.05, -0.40, 2390.0, 0.87, 1.0, 4.10, -0.4)
                ),
                provenance = prov
            ),
            IndexState(
                indexCode = "EUROBANKS",
                indexName = "Euronext European Banks (Synthetic)",
                category = IndexCategory.THEMATIC_SECTOR,
                baseMarket = null,
                currentValue = 142.80,
                openValue = 143.50,
                highValue = 144.10,
                lowValue = 142.10,
                previousClose = 143.50,
                changePoints = -0.70,
                changePct = -0.49,
                divisor = 840100.0,
                marketCapEurB = 480.0,
                constituents = listOf(
                    IndexConstituent("BNP", "FR0000131104", "BNP Paribas", MarketId.PAR, "Banks", 65.40, -0.80, 1180.0, 0.95, 1.0, 22.50, -0.4),
                    IndexConstituent("INGA", "NL0011821202", "ING Groep", MarketId.AMS, "Banks", 16.45, +0.60, 3620.0, 0.98, 1.0, 18.20, +0.2),
                    IndexConstituent("ISP", "IT0000072618", "Intesa Sanpaolo", MarketId.MIL, "Banks", 3.82, -0.75, 18280.0, 0.85, 1.0, 16.40, -0.3)
                ),
                provenance = prov
            )
        )
    }

    fun getOptionChain(underlyingTicker: String, spotPrice: Double): List<OptionContract> {
        val strikes = listOf(
            spotPrice * 0.90,
            spotPrice * 0.95,
            spotPrice * 1.00,
            spotPrice * 1.05,
            spotPrice * 1.10
        )
        val expiries = listOf("2026-10-16 (10d)", "2026-11-20 (45d)", "2026-12-18 (73d)")

        val list = mutableListOf<OptionContract>()
        for (exp in expiries) {
            val days = if (exp.contains("10d")) 10 else if (exp.contains("45d")) 45 else 73
            val t = days / 365.0
            for (strike in strikes) {
                // Call
                val (callP, callG) = BlackScholesEngine.calculateOption(OptionType.CALL, spotPrice, strike, t, 0.0325, 0.24)
                list.add(
                    OptionContract(
                        contractCode = "C-$underlyingTicker-${String.format("%.0f", strike)}-$days",
                        underlyingTicker = underlyingTicker,
                        underlyingPrice = spotPrice,
                        optionType = OptionType.CALL,
                        strikePrice = strike,
                        expiryDate = exp,
                        daysToExpiry = days,
                        bidPrice = max(0.05, callP - 0.20),
                        askPrice = callP + 0.20,
                        lastPrice = callP,
                        volume = (200..1500).random().toLong(),
                        openInterest = (1000..8000).random().toLong(),
                        greeks = callG
                    )
                )

                // Put
                val (putP, putG) = BlackScholesEngine.calculateOption(OptionType.PUT, spotPrice, strike, t, 0.0325, 0.24)
                list.add(
                    OptionContract(
                        contractCode = "P-$underlyingTicker-${String.format("%.0f", strike)}-$days",
                        underlyingTicker = underlyingTicker,
                        underlyingPrice = spotPrice,
                        optionType = OptionType.PUT,
                        strikePrice = strike,
                        expiryDate = exp,
                        daysToExpiry = days,
                        bidPrice = max(0.05, putP - 0.20),
                        askPrice = putP + 0.20,
                        lastPrice = putP,
                        volume = (150..1200).random().toLong(),
                        openInterest = (800..6500).random().toLong(),
                        greeks = putG
                    )
                )
            }
        }
        return list
    }

    fun getBonds(): List<BondInstrument> {
        return listOf(
            BondInstrument(
                isin = "FR001400F560",
                bondName = "French Republic OAT 2.75% 2034",
                issuerCountry = "France",
                couponPct = 2.75,
                maturityDate = "2034-02-25",
                yearsToMaturity = 7.4,
                cleanPrice = 98.40,
                yieldToMaturityPct = 3.01,
                modifiedDuration = 6.8,
                convexity = 54.2,
                creditRating = "AA-",
                isGreenBond = false,
                spreadOverBundBps = 78.5,
                bidPrice = 98.38,
                askPrice = 98.42
            ),
            BondInstrument(
                isin = "FR0014007L93",
                bondName = "French Republic Green OAT 1.75% 2039",
                issuerCountry = "France",
                couponPct = 1.75,
                maturityDate = "2039-06-25",
                yearsToMaturity = 12.7,
                cleanPrice = 82.15,
                yieldToMaturityPct = 3.42,
                modifiedDuration = 11.2,
                convexity = 142.0,
                creditRating = "AA-",
                isGreenBond = true,
                spreadOverBundBps = 84.0,
                bidPrice = 82.10,
                askPrice = 82.20
            ),
            BondInstrument(
                isin = "NL0015000QL2",
                bondName = "Kingdom of Netherlands DSL 2.50% 2033",
                issuerCountry = "Netherlands",
                couponPct = 2.50,
                maturityDate = "2033-07-15",
                yearsToMaturity = 6.8,
                cleanPrice = 100.80,
                yieldToMaturityPct = 2.38,
                modifiedDuration = 6.3,
                convexity = 46.8,
                creditRating = "AAA",
                isGreenBond = false,
                spreadOverBundBps = 15.2,
                bidPrice = 100.78,
                askPrice = 100.82
            ),
            BondInstrument(
                isin = "IT0005544082",
                bondName = "Republic of Italy BTP 4.00% 2033",
                issuerCountry = "Italy",
                couponPct = 4.00,
                maturityDate = "2033-11-15",
                yearsToMaturity = 7.1,
                cleanPrice = 102.10,
                yieldToMaturityPct = 3.65,
                modifiedDuration = 6.4,
                convexity = 49.5,
                creditRating = "BBB",
                isGreenBond = false,
                spreadOverBundBps = 142.0,
                bidPrice = 102.05,
                askPrice = 102.15
            )
        )
    }

    fun getPowerContracts(): List<EuropeanPowerContract> {
        return listOf(
            EuropeanPowerContract("France", "Baseload Day-Ahead", "2026-10-08", 68.50, -2.4, 420000, 48, 14200),
            EuropeanPowerContract("Italy (PUN)", "Baseload Day-Ahead", "2026-10-08", 98.20, +1.1, 310000, 290, 8500),
            EuropeanPowerContract("Belgium", "Baseload Day-Ahead", "2026-10-08", 71.30, -0.8, 180000, 115, 6200),
            EuropeanPowerContract("Netherlands", "Baseload Day-Ahead", "2026-10-08", 74.80, +0.4, 260000, 240, 9100),
            EuropeanPowerContract("Norway (NO1)", "Baseload Day-Ahead", "2026-10-08", 34.10, -5.2, 540000, 18, 18900),
            EuropeanPowerContract("Germany", "Baseload Day-Ahead", "2026-10-08", 79.40, +1.8, 890000, 380, 24500)
        )
    }

    fun getFxRates(): List<FxQuote> {
        return listOf(
            FxQuote("EUR/USD", 1.0942, +0.18, +4.8, +14.2, 6.2, 1.0941, 1.0943),
            FxQuote("EUR/GBP", 0.8540, -0.12, +2.1, +6.5, 5.8, 0.8539, 0.8541),
            FxQuote("EUR/CHF", 0.9420, -0.05, -12.4, -36.0, 5.1, 0.9419, 0.9421),
            FxQuote("EUR/NOK", 11.4850, -0.42, +18.5, +54.0, 9.4, 11.4820, 11.4880),
            FxQuote("EUR/SEK", 11.3200, +0.22, +15.0, +42.0, 8.9, 11.3170, 11.3230),
            FxQuote("EUR/DKK", 7.4602, +0.01, +0.2, +0.6, 1.2, 7.4600, 7.4604)
        )
    }

    fun getClearingPositions(): List<ClearingPosition> {
        return listOf(
            ClearingPosition("MEM-BNP-01", "BNP Paribas Arbitrage", "FR0000121014", "MC", MarketId.PAR, +14500, 685.20, +46400.0, 1420000.0, -12500.0, 85000.0, "NOV-CCP-948210"),
            ClearingPosition("MEM-BNP-01", "BNP Paribas Arbitrage", "NL0010273215", "ASML", MarketId.AMS, -8200, 935.00, -42640.0, 1850000.0, +32000.0, 110000.0, "NOV-CCP-948211"),
            ClearingPosition("MEM-SG-02", "Société Générale Equities", "FR0000120271", "TTE", MarketId.PAR, +45000, 62.30, -11250.0, 520000.0, -8400.0, 24000.0, "NOV-CCP-948212"),
            ClearingPosition("MEM-ING-03", "ING Bank NV Global Markets", "IT0003128367", "ENEL", MarketId.MIL, +120000, 6.98, +4800.0, 185000.0, +1200.0, 15000.0, "NOV-CCP-948213")
        )
    }

    fun getMarginSummary(): MarginSummary {
        return MarginSummary(
            totalInitialMarginEur = 84500000.0,
            totalVariationMarginEur = -1420000.0,
            stressMarginAddonEur = 12500000.0,
            liquidityConcentrationAddonEur = 4200000.0,
            totalMarginRequirementEur = 99780000.0,
            eligibleCollateralPostedEur = 142500000.0,
            marginCoverageRatioPct = 142.8,
            defaultFundShareEur = 18500000.0,
            marginCallStatus = "ADEQUATE (Coverage 142.8%)"
        )
    }

    fun getSettlementInstructions(): List<SettlementInstruction> {
        val prov = ProvenanceRecord(market = MarketId.PAR, dataStatus = DataStatus.SYNTHETIC)
        return listOf(
            SettlementInstruction(
                instructionId = "SET-2026-98101",
                tradeId = "TRD-849102",
                isin = "FR0000121014",
                ticker = "MC",
                market = MarketId.PAR,
                settlementDate = "T+2 (2026-10-09)",
                destinationCsd = CsdVenue.EURONEXT_SECURITIES,
                deliveringParticipant = "BNP PARIBAS ARBITRAGE (FR)",
                receivingParticipant = "SOCIETE GENERALE EQ (FR)",
                quantity = 1500,
                settlementAmountEur = 1032600.0,
                status = SettlementStatus.SETTLED,
                finalityTimestamp = "2026-10-07 09:15:02 UTC",
                provenance = prov
            ),
            SettlementInstruction(
                instructionId = "SET-2026-98102",
                tradeId = "TRD-849105",
                isin = "NL0010273215",
                ticker = "ASML",
                market = MarketId.AMS,
                settlementDate = "T+2 (2026-10-09)",
                destinationCsd = CsdVenue.EURONEXT_SECURITIES,
                deliveringParticipant = "ING BANK NV (NL)",
                receivingParticipant = "ABN AMRO CLEARING (NL)",
                quantity = 800,
                settlementAmountEur = 752160.0,
                status = SettlementStatus.MATCHED,
                provenance = prov.copy(market = MarketId.AMS)
            ),
            SettlementInstruction(
                instructionId = "SET-2026-98103",
                tradeId = "TRD-849109",
                isin = "IT0003128367",
                ticker = "ENEL",
                market = MarketId.MIL,
                settlementDate = "T+2 (2026-10-09)",
                destinationCsd = CsdVenue.EURONEXT_SECURITIES,
                deliveringParticipant = "INTESA SANPAOLO (IT)",
                receivingParticipant = "UNICREDIT (IT)",
                quantity = 25000,
                settlementAmountEur = 175500.0,
                status = SettlementStatus.FAILED,
                failReason = "CSD-INSUFF-SEC-01: Delivering party account lacks eligible unencumbered securities on settlement date.",
                provenance = prov.copy(market = MarketId.MIL)
            ),
            SettlementInstruction(
                instructionId = "SET-2026-98104",
                tradeId = "TRD-849112",
                isin = "FR0000120271",
                ticker = "TTE",
                market = MarketId.PAR,
                settlementDate = "T+2 (2026-10-09)",
                destinationCsd = CsdVenue.EUROCLEAR_FRANCE,
                deliveringParticipant = "CREDIT AGRICOLE CIB (FR)",
                receivingParticipant = "NATIXIS (FR)",
                quantity = 5000,
                settlementAmountEur = 310250.0,
                status = SettlementStatus.PENDING,
                provenance = prov
            )
        )
    }

    fun getSurveillanceAlerts(): List<SurveillanceAlert> {
        return listOf(
            SurveillanceAlert(
                alertId = "SURV-0491",
                timestamp = "09:28:14 UTC",
                alertType = AlertType.SPOOFING_DETECTED,
                severity = AlertSeverity.CRITICAL,
                ticker = "MC",
                isin = "FR0000121014",
                market = MarketId.PAR,
                triggerDetail = "Rapid burst of 12 non-bona fide buy orders at deep bid followed by aggressive market sell order execution.",
                detectionAlgorithm = "MAR / MiFID II Algorithmic Pattern Engine (ML-v3)",
                recommendedAction = "Escalate to AMF Surveillance Directorate and freeze participant synthetic desk ID."
            ),
            SurveillanceAlert(
                alertId = "SURV-0492",
                timestamp = "09:22:40 UTC",
                alertType = AlertType.CROSS_MARKET_ARBITRAGE_GAP,
                severity = AlertSeverity.WARNING,
                ticker = "ASML",
                isin = "NL0010273215",
                market = MarketId.AMS,
                triggerDetail = "Cross-listing spread Amsterdam vs Paris exceeded 32 bps for > 850 ms (Normal < 4 bps).",
                detectionAlgorithm = "Cross-Venue Microstructure Monitor",
                recommendedAction = "Verify Optiq gateway latency and broadcast price feed integrity warning."
            )
        )
    }

    fun getMacroScenarios(): List<MacroScenario> {
        return listOf(
            MacroScenario(
                scenarioId = "SCEN-ECB-HIKE",
                name = "ECB +100BP Emergency Rate Hike",
                description = "Hawkish ECB monetary policy surprise tightening sovereign credit spreads and discounting equity valuation multiples.",
                cac40ShockPct = -2.8,
                aexShockPct = -2.1,
                mibShockPct = -4.2,
                bel20ShockPct = -2.4,
                ibexShockPct = -3.8,
                psiShockPct = -2.9,
                obxShockPct = -1.2,
                banksFactorShockPct = +3.4,
                energyFactorShockPct = -1.5,
                eurFxShockPct = +1.8,
                ratesShockBps = +100,
                ccpMarginIncreasePct = 18.5
            ),
            MacroScenario(
                scenarioId = "SCEN-BANK-SHOCK",
                name = "European Banking & Sovereign Stress",
                description = "Sharp widening in Southern European BTP/Bund spreads accompanied by liquidity stress in commercial bank interbank credit.",
                cac40ShockPct = -3.9,
                aexShockPct = -2.8,
                mibShockPct = -6.4,
                bel20ShockPct = -3.2,
                ibexShockPct = -5.8,
                psiShockPct = -4.9,
                obxShockPct = -1.8,
                banksFactorShockPct = -9.2,
                energyFactorShockPct = -2.4,
                eurFxShockPct = -2.6,
                ratesShockBps = +45,
                ccpMarginIncreasePct = 34.0
            ),
            MacroScenario(
                scenarioId = "SCEN-ENERGY-BOOM",
                name = "Nordic & European Energy Surge",
                description = "Commodity and power market rally driving Norwegian OBX outperformance and elevating transition utilities.",
                cac40ShockPct = +0.4,
                aexShockPct = +0.8,
                mibShockPct = +1.2,
                bel20ShockPct = +0.2,
                ibexShockPct = +0.5,
                psiShockPct = +1.4,
                obxShockPct = +4.8,
                banksFactorShockPct = +1.1,
                energyFactorShockPct = +8.5,
                eurFxShockPct = -0.4,
                ratesShockBps = +15,
                ccpMarginIncreasePct = 12.0
            )
        )
    }
}
