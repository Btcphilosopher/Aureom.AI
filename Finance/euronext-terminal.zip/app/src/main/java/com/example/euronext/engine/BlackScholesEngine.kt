package com.example.euronext.engine

import com.example.euronext.model.OptionGreeks
import com.example.euronext.model.OptionType
import kotlin.math.*

object BlackScholesEngine {

    // Standard Normal Cumulative Distribution Function (Abramowitz & Stegun approximation)
    fun normCdf(x: Double): Double {
        val a1 = 0.254829592
        val a2 = -0.284496736
        val a3 = 1.421413741
        val a4 = -1.453152027
        val a5 = 1.061405429
        val p = 0.3275911

        val sign = if (x < 0) -1.0 else 1.0
        val absX = abs(x) / sqrt(2.0)
        val t = 1.0 / (1.0 + p * absX)
        val erf = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * exp(-absX * absX)
        return 0.5 * (1.0 + sign * erf)
    }

    // Standard Normal Probability Density Function
    fun normPdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * PI)) * exp(-0.5 * x * x)
    }

    /**
     * Price and compute Greeks for European Call / Put
     * @param spot Current underlying price
     * @param strike Strike price
     * @param t Time to maturity in years (e.g. 30/365)
     * @param r Risk-free rate (e.g. 0.035 for 3.5% Euribor/ESTR)
     * @param sigma Implied volatility (e.g. 0.22 for 22%)
     * @param dividendYield Dividend yield (e.g. 0.02)
     */
    fun calculateOption(
        type: OptionType,
        spot: Double,
        strike: Double,
        t: Double,
        r: Double = 0.0325,
        sigma: Double = 0.24,
        dividendYield: Double = 0.015
    ): Pair<Double, OptionGreeks> {
        val safeT = max(t, 0.0001)
        val safeSigma = max(sigma, 0.001)

        val d1 = (ln(spot / strike) + (r - dividendYield + 0.5 * safeSigma * safeSigma) * safeT) / (safeSigma * sqrt(safeT))
        val d2 = d1 - safeSigma * sqrt(safeT)

        val dfDividend = exp(-dividendYield * safeT)
        val dfRate = exp(-r * safeT)

        val price: Double
        val delta: Double
        val gamma = (dfDividend * normPdf(d1)) / (spot * safeSigma * sqrt(safeT))
        val vega = spot * dfDividend * normPdf(d1) * sqrt(safeT) * 0.01 // per 1% vol change
        val theta: Double
        val rho: Double

        if (type == OptionType.CALL) {
            price = spot * dfDividend * normCdf(d1) - strike * dfRate * normCdf(d2)
            delta = dfDividend * normCdf(d1)
            val term1 = -(spot * dfDividend * normPdf(d1) * safeSigma) / (2.0 * sqrt(safeT))
            val term2 = -r * strike * dfRate * normCdf(d2)
            val term3 = dividendYield * spot * dfDividend * normCdf(d1)
            theta = (term1 + term2 + term3) / 365.0
            rho = strike * safeT * dfRate * normCdf(d2) * 0.01
        } else {
            price = strike * dfRate * normCdf(-d2) - spot * dfDividend * normCdf(-d1)
            delta = -dfDividend * normCdf(-d1)
            val term1 = -(spot * dfDividend * normPdf(d1) * safeSigma) / (2.0 * sqrt(safeT))
            val term2 = r * strike * dfRate * normCdf(-d2)
            val term3 = -dividendYield * spot * dfDividend * normCdf(-d1)
            theta = (term1 + term2 + term3) / 365.0
            rho = -strike * safeT * dfRate * normCdf(-d2) * 0.01
        }

        return Pair(
            max(0.01, price),
            OptionGreeks(
                delta = delta,
                gamma = gamma,
                vega = vega,
                theta = theta,
                rho = rho,
                impliedVolatility = safeSigma * 100.0
            )
        )
    }

    /**
     * Compute Implied Volatility via Newton-Raphson
     */
    fun findImpliedVolatility(
        type: OptionType,
        marketPrice: Double,
        spot: Double,
        strike: Double,
        t: Double,
        r: Double = 0.0325
    ): Double {
        var sigma = 0.25
        for (i in 0 until 50) {
            val (price, greeks) = calculateOption(type, spot, strike, t, r, sigma)
            val diff = price - marketPrice
            if (abs(diff) < 1e-4) break
            val vega = max(greeks.vega * 100.0, 0.001) // Convert back from 1% unit
            sigma -= diff / vega
            if (sigma <= 0.01) sigma = 0.01
            if (sigma > 3.0) sigma = 3.0
        }
        return sigma * 100.0
    }
}
