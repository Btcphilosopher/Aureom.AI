package com.example.euronext.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.euronext.model.AppLanguage
import com.example.euronext.model.TerminalStrings
import com.example.ui.theme.*

@Composable
fun CommandPaletteDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    commandInput: String,
    onCommandChange: (String) -> Unit,
    onExecute: (String) -> Unit,
    language: AppLanguage
) {
    if (!isOpen) return

    val shortcuts = listOf(
        "CAC40" to "Paris Benchmark Index (CAC 40®)",
        "AEX" to "Amsterdam Benchmark Index (AEX-Index®)",
        "MIB" to "Milan Benchmark Index (FTSE MIB®)",
        "BOOK MC" to "Open L2/L3 Order Book for LVMH (MC)",
        "BOOK ASML" to "Open L2/L3 Order Book for ASML (ASML)",
        "MKT PAR" to "Switch context to Euronext Paris (XPAR)",
        "MKT AMS" to "Switch context to Euronext Amsterdam (XAMS)",
        "CLEARING" to "Open Euronext Clearing Multi-Asset CCP",
        "SETTLE" to "Open 2026 Euronext Securities Multi-CSD",
        "SURVEILLANCE" to "Open MAR / MiFID II Market Surveillance",
        "API" to "Open Euronext REST & WebSocket Market API"
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = TerminalCardDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "EURONEXT COMMAND PALETTE [Ctrl+K]",
                        color = TerminalNavyPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TerminalTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = commandInput,
                    onValueChange = onCommandChange,
                    placeholder = {
                        Text(
                            text = TerminalStrings.get("cmd_placeholder", language),
                            fontSize = 11.sp,
                            color = TerminalTextMuted
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalNavyPrimary,
                        unfocusedBorderColor = TerminalCardBorder,
                        focusedTextColor = TerminalTextPrimary,
                        unfocusedTextColor = TerminalTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = { onExecute(commandInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalNavyPrimary)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Execute", tint = TerminalBackgroundDark)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("EXECUTE", color = TerminalBackgroundDark, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = TerminalCardBorder)
                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "QUICK INSTITUTIONAL COMMANDS:",
                    color = TerminalTextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 200.dp)
                ) {
                    items(shortcuts) { (cmd, desc) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { onExecute(cmd) }
                                .padding(vertical = 6.dp, horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = cmd,
                                color = TerminalGoldAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = desc,
                                color = TerminalTextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
