package com.example.euronext.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.euronext.engine.EuropeanTaxEngine
import com.example.euronext.model.*
import com.example.euronext.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun SecurityMasterScreen(
    securities: List<Security>,
    selectedSecurity: Security,
    onSecuritySelected: (Security) -> Unit,
    onInspectProvenance: (ProvenanceRecord) -> Unit,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var investorCountry by remember { mutableStateOf("France") }
    val filteredSecurities = securities.filter {
        it.ticker.contains(searchQuery, ignoreCase = true) ||
        it.name.contains(searchQuery, ignoreCase = true) ||
        it.isin.contains(searchQuery, ignoreCase = true)
    }

    val dividendTax = remember(selectedSecurity, investorCountry) {
        EuropeanTaxEngine.calculateCrossBorderDividend(
            issuerCountry = selectedSecurity.country,
            investorCountry = investorCountry,
            grossDividendPerShare = (selectedSecurity.currentPrice * (selectedSecurity.issuer.dividendYieldPct / 100.0)),
            sharesCount = 1000
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search ISIN, Ticker (e.g. MC, ASML, TTE, FR0000121014)...", fontSize = 11.sp, color = TerminalTextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TerminalNavyPrimary) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TerminalNavyPrimary,
                    unfocusedBorderColor = TerminalCardBorder,
                    focusedTextColor = TerminalTextPrimary,
                    unfocusedTextColor = TerminalTextPrimary
                )
            )
        }

        // Active Security Detail Header
        item {
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = selectedSecurity.ticker,
                                    color = TerminalGoldAccent,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = selectedSecurity.name,
                                    color = TerminalTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "ISIN: ${selectedSecurity.isin} • SEDOL: ${selectedSecurity.sedol} • LEI: ${selectedSecurity.issuer.legalEntityIdentifier}",
                                color = TerminalTextMuted,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        ProvenanceBadge(
                            provenance = selectedSecurity.provenance,
                            onClick = { onInspectProvenance(selectedSecurity.provenance) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = TerminalCardBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("LAST PRICE", color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("€${String.format("%.2f", selectedSecurity.currentPrice)}", color = TerminalTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("DAY CHANGE", color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                text = if (selectedSecurity.changePct >= 0) "+${selectedSecurity.changePct}%" else "${selectedSecurity.changePct}%",
                                color = if (selectedSecurity.changePct >= 0) TerminalStatusGreen else TerminalStatusRed,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column {
                            Text("MARKET CAP", color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("€${selectedSecurity.issuer.marketCapEurB}B", color = TerminalTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text("ESG RATING", color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text("${selectedSecurity.issuer.esgRating} (${selectedSecurity.issuer.esgScore}/100)", color = TerminalTealMarket, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = selectedSecurity.issuer.description,
                        color = TerminalTextSecondary,
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        // Pan-European Multi-Listing Table
        item {
            Surface(
                color = TerminalSurfaceDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PAN-EUROPEAN LISTINGS (WHERE DOES THIS SECURITY TRADE?)",
                            color = TerminalNavyPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(Icons.Default.Public, contentDescription = "Listings", tint = TerminalNavyPrimary, modifier = Modifier.size(16.dp))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    selectedSecurity.listings.forEach { listing ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${listing.market.cityName} (${listing.mic})",
                                    color = TerminalTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (listing.isPrimary) "PRIMARY LISTING" else "SECONDARY LISTING",
                                    color = if (listing.isPrimary) TerminalStatusGreen else TerminalTextMuted,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "€${String.format("%.2f", listing.lastPrice)}",
                                    color = TerminalTextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Vol: ${listing.dayVolume}",
                                    color = TerminalTextSecondary,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        HorizontalDivider(color = TerminalCardBorder, thickness = 0.5.dp)
                    }
                }
            }
        }

        // European Cross-Border Withholding Tax Engine
        item {
            Surface(
                color = Color(0xFF131D33),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalGoldAccent),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CROSS-BORDER WITHHOLDING TAX SIMULATOR",
                            color = TerminalGoldAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(Icons.Default.Calculate, contentDescription = "Tax", tint = TerminalGoldAccent, modifier = Modifier.size(16.dp))
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Issuer: ${selectedSecurity.country} | Tax Regime: ${dividendTax.taxRegimeDescription}",
                        color = TerminalTextSecondary,
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TaxStat("GROSS DIVIDEND (1k sh)", "€${String.format("%.2f", dividendTax.grossDividendEur)}")
                        TaxStat("WITHHOLDING TAX", "€${String.format("%.2f", dividendTax.withholdingTaxEur)} (${dividendTax.effectiveTaxRatePct}%)")
                        TaxStat("NET PAYOUT", "€${String.format("%.2f", dividendTax.netDividendEur)}")
                    }
                }
            }
        }

        // Security Selector List
        item {
            Text(
                text = "EURONEXT INSTITUTIONAL SECURITY DIRECTORY",
                color = TerminalTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(filteredSecurities) { sec ->
            val isSelected = sec.isin == selectedSecurity.isin
            Surface(
                color = if (isSelected) Color(0xFF162036) else TerminalCardDark,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) TerminalNavyPrimary else TerminalCardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSecuritySelected(sec) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = sec.ticker,
                                color = TerminalGoldAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = sec.name,
                                color = TerminalTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = "${sec.primaryMarket.cityName} (${sec.mic}) • ${sec.isin} • ${sec.issuer.sector}",
                            color = TerminalTextMuted,
                            fontSize = 9.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "€${String.format("%.2f", sec.currentPrice)}",
                            color = TerminalTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = if (sec.changePct >= 0) "+${sec.changePct}%" else "${sec.changePct}%",
                            color = if (sec.changePct >= 0) TerminalStatusGreen else TerminalStatusRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TaxStat(label: String, value: String) {
    Column {
        Text(label, color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = TerminalTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
