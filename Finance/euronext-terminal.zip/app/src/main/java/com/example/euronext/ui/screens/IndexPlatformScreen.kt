package com.example.euronext.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.euronext.model.*
import com.example.euronext.ui.components.ProvenanceBadge
import com.example.ui.theme.*

@Composable
fun IndexPlatformScreen(
    indices: List<IndexState>,
    onInspectProvenance: (ProvenanceRecord) -> Unit,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    var selectedIndex by remember { mutableStateOf(indices.first()) }
    var isCustomIndexFactoryOpen by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Selected Index Summary Card
        item {
            Surface(
                color = TerminalCardDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalNavyPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = selectedIndex.indexName,
                                    color = TerminalTextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "[${selectedIndex.indexCode}]",
                                    color = TerminalGoldAccent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "Category: ${selectedIndex.category.name} • Base Market: ${selectedIndex.baseMarket?.name ?: "Pan-European"}",
                                color = TerminalTextMuted,
                                fontSize = 9.sp
                            )
                        }
                        ProvenanceBadge(
                            provenance = selectedIndex.provenance,
                            onClick = { onInspectProvenance(selectedIndex.provenance) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = TerminalCardBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("INDEX LEVEL", color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                String.format("%.2f", selectedIndex.currentValue),
                                color = TerminalTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column {
                            Text("CHANGE", color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                text = "${if (selectedIndex.changePoints >= 0) "+" else ""}${String.format("%.2f", selectedIndex.changePoints)} (${if (selectedIndex.changePct >= 0) "+" else ""}${selectedIndex.changePct}%)",
                                color = if (selectedIndex.changePct >= 0) TerminalStatusGreen else TerminalStatusRed,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column {
                            Text("DIVISOR", color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                String.format("%.0f", selectedIndex.divisor),
                                color = TerminalNavyPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column {
                            Text("MARKET CAP", color = TerminalTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                "€${selectedIndex.marketCapEurB}B",
                                color = TerminalGoldAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Methodology: ${selectedIndex.methodology} (Review: ${selectedIndex.reviewDate})",
                        color = TerminalTextSecondary,
                        fontSize = 9.sp,
                        lineHeight = 13.sp
                    )
                }
            }
        }

        // Constituents Weight & Contribution Table
        item {
            Surface(
                color = TerminalSurfaceDark,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "INDEX CONSTITUENTS & WEIGHTING DECOMPOSITION",
                            color = TerminalNavyPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(Icons.Default.PieChart, contentDescription = "Weights", tint = TerminalNavyPrimary, modifier = Modifier.size(16.dp))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TICKER / NAME", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.5f))
                        Text("PRICE (€)", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("WEIGHT", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("PTS CONTR", color = TerminalTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    HorizontalDivider(color = TerminalCardBorder)
                    Spacer(modifier = Modifier.height(4.dp))

                    selectedIndex.constituents.forEach { const ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.5f)) {
                                Text(const.ticker, color = TerminalGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(const.name, color = TerminalTextSecondary, fontSize = 9.sp, maxLines = 1)
                            }
                            Text("€${String.format("%.2f", const.currentPrice)}", color = TerminalTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text("${String.format("%.2f", const.weightPct)}%", color = TerminalNavyPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text(
                                text = "${if (const.pointsContribution >= 0) "+" else ""}${String.format("%.1f", const.pointsContribution)}",
                                color = if (const.pointsContribution >= 0) TerminalStatusGreen else TerminalStatusRed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        HorizontalDivider(color = TerminalCardBorder, thickness = 0.5.dp)
                    }
                }
            }
        }

        // Indices Selector List
        item {
            Text(
                text = "EURONEXT BENCHMARK & THEMATIC INDEX DIRECTORY",
                color = TerminalTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }

        items(indices) { idx ->
            val isSelected = idx.indexCode == selectedIndex.indexCode
            Surface(
                color = if (isSelected) Color(0xFF162036) else TerminalCardDark,
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) TerminalNavyPrimary else TerminalCardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedIndex = idx }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = idx.indexCode,
                                color = TerminalGoldAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = idx.indexName,
                                color = TerminalTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = "${idx.category.name} • ${idx.constituents.size} Constituents",
                            color = TerminalTextMuted,
                            fontSize = 9.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = String.format("%.2f", idx.currentValue),
                            color = TerminalTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${if (idx.changePct >= 0) "+" else ""}${idx.changePct}%",
                            color = if (idx.changePct >= 0) TerminalStatusGreen else TerminalStatusRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
