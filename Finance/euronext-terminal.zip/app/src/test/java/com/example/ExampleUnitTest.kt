package com.example

import com.example.euronext.engine.BlackScholesEngine
import com.example.euronext.engine.EuropeanTaxEngine
import com.example.euronext.engine.MatchingEngine
import com.example.euronext.engine.SettlementRoutingEngine
import com.example.euronext.model.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testOrderMatchingAndTradeGeneration() {
        val engine = MatchingEngine(ticker = "MC", isin = "FR0000121014", market = MarketId.PAR, referencePrice = 688.00)

        // Submit resting Sell order
        val sellResult = engine.submitOrder(
            Order(
                securityId = "FR0000121014",
                ticker = "MC",
                isin = "FR0000121014",
                market = MarketId.PAR,
                side = OrderSide.SELL,
                orderType = OrderType.LIMIT,
                price = 688.00,
                quantity = 100
            )
        )
        assertEquals(OrderStatus.NEW, sellResult.restingOrder?.status)

        // Submit matching Buy order
        val buyResult = engine.submitOrder(
            Order(
                securityId = "FR0000121014",
                ticker = "MC",
                isin = "FR0000121014",
                market = MarketId.PAR,
                side = OrderSide.BUY,
                orderType = OrderType.LIMIT,
                price = 688.00,
                quantity = 100
            )
        )

        assertEquals(1, buyResult.executedTrades.size)
        assertEquals(688.00, buyResult.executedTrades[0].executionPrice, 0.001)
        assertEquals(100L, buyResult.executedTrades[0].quantity)
        assertEquals(OrderStatus.FILLED, buyResult.restingOrder?.status)
    }

    @Test
    fun testBlackScholesOptionGreeks() {
        val (callPrice, greeks) = BlackScholesEngine.calculateOption(
            type = OptionType.CALL,
            spot = 100.0,
            strike = 100.0,
            t = 1.0,
            r = 0.05,
            sigma = 0.20,
            dividendYield = 0.0
        )

        assertTrue(callPrice > 0)
        assertTrue(greeks.delta in 0.4..0.7)
        assertTrue(greeks.gamma > 0)
        assertTrue(greeks.vega > 0)
    }

    @Test
    fun testEuropeanCrossBorderDividendTax() {
        val result = EuropeanTaxEngine.calculateCrossBorderDividend(
            issuerCountry = "France",
            investorCountry = "Germany",
            grossDividendPerShare = 10.0,
            sharesCount = 100,
            hasTreatyReliefAtSource = true
        )

        assertEquals(1000.0, result.grossDividendEur, 0.001)
        assertEquals(15.0, result.effectiveTaxRatePct, 0.001)
        assertEquals(150.0, result.withholdingTaxEur, 0.001)
        assertEquals(850.0, result.netDividendEur, 0.001)
    }

    @Test
    fun test2026SettlementCsdDefault() {
        val (defaultCsd, eligible) = SettlementRoutingEngine.determineCsdRouting(
            market = MarketId.PAR,
            currency = "EUR",
            instrumentType = InstrumentType.ORDINARY_SHARE,
            clientSelectedCsd = null
        )

        assertEquals(CsdVenue.EURONEXT_SECURITIES, defaultCsd)
        assertTrue(eligible.contains(CsdVenue.EURONEXT_SECURITIES))
        assertTrue(eligible.contains(CsdVenue.EUROCLEAR_FRANCE))
    }
}
