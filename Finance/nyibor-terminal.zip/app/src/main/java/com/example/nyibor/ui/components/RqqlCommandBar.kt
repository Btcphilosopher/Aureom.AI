package com.example.nyibor.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * RhinoQuant Quant Language (RQQL) Command Bar & Terminal Interface
 * Allows typing queries like:
 * - GET NYIBOR(3M)
 * - GET NYIBOR CURVE
 * - GET NYIBOR VS SOFR
 * - PRICE NYIBOR SWAP 5Y
 * - STRESS NYIBOR +50BP
 * - DV01 PORTFOLIO
 * - SIMULATE MONTE CARLO
 */
@Composable
fun RqqlCommandBar(
    onExecuteCommand: (String) -> String,
    modifier: Modifier = Modifier
) {
    var commandText by remember { mutableStateOf("GET NYIBOR(3M)") }
    var commandOutput by remember { mutableStateOf("Ready. Type RQQL command or tap suggestions.") }
    var isExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NyiborNavyDark)
            .border(1.dp, NyiborBorderHighlight, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = NyiborGold.copy(alpha = 0.15f),
                shape = RoundedCornerShape(2.dp)
            ) {
                Text(
                    text = "RQQL",
                    color = NyiborGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
            Spacer(modifier = Modifier.width(6.dp))

            OutlinedTextField(
                value = commandText,
                onValueChange = { commandText = it },
                singleLine = true,
                placeholder = {
                    Text("e.g. GET NYIBOR(3M), PRICE NYIBOR SWAP 5Y, STRESS +50BP", fontSize = 11.sp, color = NyiborTextMuted)
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("rqql_input_field"),
                textStyle = LocalTextStyle.current.copy(
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = NyiborTextPrimary
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NyiborGold,
                    unfocusedBorderColor = NyiborBorder,
                    focusedContainerColor = NyiborSurfaceDark,
                    unfocusedContainerColor = NyiborSurfaceDark
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = {
                        commandOutput = onExecuteCommand(commandText.trim())
                        isExpanded = true
                    }
                )
            )

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = {
                    commandOutput = onExecuteCommand(commandText.trim())
                    isExpanded = true
                },
                modifier = Modifier
                    .testTag("rqql_execute_button")
                    .size(40.dp)
                    .background(NyiborSurfaceElevated, RoundedCornerShape(4.dp))
                    .border(1.dp, NyiborBorder, RoundedCornerShape(4.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Execute RQQL",
                    tint = NyiborGold,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // Quick Command Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val suggestions = listOf("GET NYIBOR(3M)", "NYIBOR VS SOFR", "PRICE SWAP 5Y", "STRESS +50BP", "MONTE CARLO")
            suggestions.forEach { suggestion ->
                Surface(
                    onClick = {
                        commandText = suggestion
                        commandOutput = onExecuteCommand(suggestion)
                        isExpanded = true
                    },
                    color = NyiborSurfaceElevated,
                    shape = RoundedCornerShape(2.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder)
                ) {
                    Text(
                        text = suggestion,
                        color = NyiborTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        // Terminal Output Drawer
        AnimatedVisibility(visible = isExpanded) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .background(NyiborSurfaceDark, RoundedCornerShape(3.dp))
                    .border(1.dp, NyiborBorder, RoundedCornerShape(3.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RQQL INTERPRETER EXECUTION OUTPUT",
                        color = NyiborTextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss",
                        tint = NyiborTextMuted,
                        modifier = Modifier
                            .size(14.dp)
                            .clickable { isExpanded = false }
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = commandOutput,
                    color = NyiborGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 15.sp
                )
            }
        }
    }
}
