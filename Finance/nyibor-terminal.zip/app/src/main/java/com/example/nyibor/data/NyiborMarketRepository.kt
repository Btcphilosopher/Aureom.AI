package com.example.nyibor.data

import com.example.nyibor.engine.FinancialMathEngine
import com.example.nyibor.engine.NYIBORCalculationEngine
import com.example.nyibor.engine.NyiborCurveEngine
import com.example.nyibor.model.*
import kotlin.math.roundToInt

/**
 * Fictional Institutional Market Data Repository for NYIBOR and NIBA.
 * Produces deterministic, mathematically coherent rates, quotes, submissions,
 * spreads vs SOFR/EFFR, and historical stress regimes.
 */
object NyiborMarketRepository {

    // 15 Fictional Panel Banks (strictly fictional, no real banks)
    val panelBanks = listOf(
        PanelBank("B01", "Atlantic Union Bank", "Wall St, NY", "Tier 1 G-SIB", "Diversified Wholesale", "Deep Reserve", "ACTIVE", QualityScore.GRADE_A_PLUS, 0.4, 1.1, 0.02),
        PanelBank("B02", "Manhattan Federal Bank", "Park Ave, NY", "Tier 1 G-SIB", "Corporate Wholesale", "Tier 1 Prime", "ACTIVE", QualityScore.GRADE_A_PLUS, 0.5, 1.2, 0.03),
        PanelBank("B03", "Hudson National", "Liberty St, NY", "Tier 1 G-SIB", "Interbank Term", "Robust", "ACTIVE", QualityScore.GRADE_A, 0.7, 1.3, 0.04),
        PanelBank("B04", "Empire Commercial Bank", "Broad St, NY", "Super-Regional", "Institutional Deposit", "Balanced", "ACTIVE", QualityScore.GRADE_A, 0.8, 1.4, 0.04),
        PanelBank("B05", "Metropolitan Trust Bank", "Lexington Ave, NY", "Super-Regional", "Asset Management Repo", "Moderate", "ACTIVE", QualityScore.GRADE_A, 0.9, 1.5, 0.05),
        PanelBank("B06", "New Amsterdam Bank", "Water St, NY", "Prime Wholesale", "Money Market Fund", "High Liquidity", "ACTIVE", QualityScore.GRADE_B, 1.1, 1.7, 0.07),
        PanelBank("B07", "Liberty Financial", "Battery Park, NY", "Tier 1 G-SIB", "Global Wholesale USD", "Prime Deep", "ACTIVE", QualityScore.GRADE_A_PLUS, 0.3, 0.9, 0.01),
        PanelBank("B08", "Hamilton National", "Trinity Pl, NY", "Super-Regional", "CP & CD Issuer", "Adequate", "ACTIVE", QualityScore.GRADE_A, 0.8, 1.3, 0.04),
        PanelBank("B09", "Continental Manhattan", "Avenue of the Americas, NY", "Tier 1 G-SIB", "Offshore Wholesale", "High Reserves", "ACTIVE", QualityScore.GRADE_A, 0.6, 1.2, 0.03),
        PanelBank("B10", "East River Bank", "FDR Drive, NY", "Prime Wholesale", "Municipal Funding", "Moderate", "ACTIVE", QualityScore.GRADE_B, 1.3, 1.9, 0.09),
        PanelBank("B11", "Fifth Avenue Commercial", "Midtown, NY", "Super-Regional", "Prime Commercial", "Stable", "ACTIVE", QualityScore.GRADE_A, 0.7, 1.4, 0.03),
        PanelBank("B12", "Hudson & Atlantic", "Financial District, NY", "Tier 1 G-SIB", "Dealer Repo & Term", "High Reserves", "ACTIVE", QualityScore.GRADE_A_PLUS, 0.4, 1.0, 0.02),
        PanelBank("B13", "Republic National Bank", "Grand Central, NY", "Super-Regional", "Syndicated Wholesale", "Adequate", "ACTIVE", QualityScore.GRADE_B, 1.0, 1.6, 0.06),
        PanelBank("B14", "Wall Street Union", "Pine St, NY", "Tier 1 G-SIB", "Prime Brokerage USD", "Extensive", "ACTIVE", QualityScore.GRADE_A, 0.5, 1.2, 0.03),
        PanelBank("B15", "American Mercantile Bank", "Maiden Lane, NY", "Prime Wholesale", "Trade Finance Wholesale", "Moderate", "ACTIVE", QualityScore.GRADE_B, 1.2, 1.8, 0.08)
    )

    // Baseline Fictional NYIBOR Fixings (Deterministic institutional rates)
    val baseNyiborRates = mapOf(
        Tenor.ON to 3.8200,
        Tenor.W1 to 3.8600,
        Tenor.W2 to 3.8850,
        Tenor.M1 to 3.9100,
        Tenor.M2 to 3.9650,
        Tenor.M3 to 4.0200,
        Tenor.M6 to 4.0800,
        Tenor.M9 to 4.1350,
        Tenor.M12 to 4.1900,
        Tenor.Y2 to 4.2800,
        Tenor.Y3 to 4.3600,
        Tenor.Y5 to 4.4500,
        Tenor.Y7 to 4.5200,
        Tenor.Y10 to 4.5900,
        Tenor.Y20 to 4.7100,
        Tenor.Y30 to 4.7700
    )

    val baseSofr = 3.6500 // Secured Overnight Financing Rate baseline
    val baseEffr = 3.8300 // Effective Federal Funds Rate baseline

    fun getFixings(): List<FixingDetail> {
        val dateStr = "2026-10-08"
        return Tenor.primaryTenors.map { tenor ->
            val rate = baseNyiborRates[tenor] ?: 4.00
            val prevRate = rate - 0.0075 // Down 0.75 bp on day
            val changeBp = (rate - prevRate) * 100.0

            FixingDetail(
                fixingId = "FIX-20261008-${tenor.code}",
                tenor = tenor,
                date = dateStr,
                rate = rate,
                previousRate = prevRate,
                changeBp = (changeBp * 100.0).roundToInt() / 100.0,
                change1Wbp = 1.4,
                change1Mbp = -4.2,
                changeYtdBp = 18.5,
                high52W = rate + 0.38,
                low52W = rate - 0.44,
                percentile52W = 68.4,
                fixingState = FixingState.PUBLISHED,
                methodologyLevel = if (tenor == Tenor.M3 || tenor == Tenor.M1) MethodologyLevel.LEVEL_1 else MethodologyLevel.LEVEL_2,
                qualityScore = QualityScore.GRADE_A,
                transactionVolumeMillion = when (tenor) {
                    Tenor.W1 -> 420.0
                    Tenor.M1 -> 890.0
                    Tenor.M3 -> 1450.0
                    Tenor.M6 -> 620.0
                    Tenor.M12 -> 380.0
                    else -> 200.0
                },
                transactionCount = when (tenor) {
                    Tenor.M3 -> 44
                    Tenor.M1 -> 32
                    else -> 18
                },
                contributorCount = 15,
                dispersionBp = when (tenor) {
                    Tenor.M3 -> 2.15
                    Tenor.M1 -> 2.45
                    Tenor.M6 -> 3.20
                    Tenor.M12 -> 4.10
                    else -> 2.80
                },
                trimmedMean = rate - 0.0005,
                median = rate,
                volumeWeightedMean = rate + 0.0010,
                auditHash = "A74F09BC3E1182D4",
                methodologyVersion = NYIBORCalculationEngine.METHODOLOGY_VERSION
            )
        }
    }

    fun generateSubmissions(tenor: Tenor): List<BankSubmission> {
        val baseRate = baseNyiborRates[tenor] ?: 4.0200
        val timestamp = "10:41:22 ET"

        return panelBanks.mapIndexed { index, bank ->
            // Generate deterministic spread offset per bank based on profile
            val spreadOffsetBp = (index - 7) * 0.42 + (if (index % 3 == 0) -0.3 else 0.2)
            val rate = baseRate + (spreadOffsetBp / 100.0)
            val volume = 25.0 + (index * 7.5) % 80.0
            val level = when {
                index < 6 -> MethodologyLevel.LEVEL_1
                index < 12 -> MethodologyLevel.LEVEL_2
                index < 14 -> MethodologyLevel.LEVEL_3
                else -> MethodologyLevel.LEVEL_4
            }

            BankSubmission(
                submissionId = "SUB-${bank.bankId}-${tenor.code}",
                bankId = bank.bankId,
                bankName = bank.name,
                tenor = tenor,
                submittedRate = NYIBORCalculationEngine.round4(rate),
                timestamp = timestamp,
                confidence = 0.95 - (index * 0.015),
                level = level,
                transactionVolumeMillion = volume
            )
        }
    }

    fun getRelativeValuePoints(): List<RelativeValuePoint> {
        return Tenor.primaryTenors.map { tenor ->
            val nyibor = baseNyiborRates[tenor] ?: 4.02
            // SOFR term spread (secured) is lower than unsecured NYIBOR
            val termPremiumSpread = (tenor.days / 360.0) * 0.18
            val termSofr = baseSofr + termPremiumSpread
            val effrTerm = baseEffr + (tenor.days / 360.0) * 0.12

            val nyiborMinusSofrBp = (nyibor - termSofr) * 100.0
            val nyiborMinusEffrBp = (nyibor - effrTerm) * 100.0

            // RhinoQuant Modelled Decomposition of the NYIBOR - SOFR spread
            val totalSpread = nyiborMinusSofrBp
            val credit = totalSpread * 0.42
            val liquidity = totalSpread * 0.22
            val term = totalSpread * 0.16
            val fundingBs = totalSpread * 0.12
            val marketStress = totalSpread * 0.08

            RelativeValuePoint(
                tenor = tenor,
                nyibor = nyibor,
                sofr = round4(termSofr),
                effr = round4(effrTerm),
                nyiborMinusSofrBp = round1(nyiborMinusSofrBp),
                nyiborMinusEffrBp = round1(nyiborMinusEffrBp),
                basisVolBp = 3.8 + (tenor.days / 90.0) * 0.7,
                zScore = 0.65,
                rolling30dAvgBp = round1(nyiborMinusSofrBp - 1.2),
                rolling30dVolBp = 4.2,
                creditComponentBp = round1(credit),
                liquidityComponentBp = round1(liquidity),
                termComponentBp = round1(term),
                fundingBalanceSheetBp = round1(fundingBs),
                marketStressBp = round1(marketStress)
            )
        }
    }

    fun getFutures(): List<FutureContract> {
        // Fictional New York Rates Exchange (NYRX)
        return listOf(
            FutureContract("NYM6", Tenor.M3, "Jun 2026", 95.960, 4.040, -0.015, 42100, 185000, 37.0, 4.040),
            FutureContract("NYU6", Tenor.M3, "Sep 2026", 95.905, 4.095, -0.020, 38400, 162000, 39.5, 4.095),
            FutureContract("NYZ6", Tenor.M3, "Dec 2026", 95.840, 4.160, 0.005, 29800, 134000, 42.0, 4.160),
            FutureContract("NYH7", Tenor.M3, "Mar 2027", 95.770, 4.230, 0.010, 21200, 98000, 44.2, 4.230),
            FutureContract("NYM7", Tenor.M3, "Jun 2027", 95.700, 4.300, 0.000, 16500, 76000, 45.8, 4.300),
            FutureContract("NYU7", Tenor.M3, "Sep 2027", 95.630, 4.370, -0.005, 12400, 58000, 47.1, 4.370)
        )
    }

    fun getSwaps(): List<SwapQuote> {
        return listOf(
            SwapQuote("1Y", 4.185, 34.5, 96.5),
            SwapQuote("2Y", 4.275, 36.2, 191.0),
            SwapQuote("3Y", 4.350, 38.0, 282.4),
            SwapQuote("5Y", 4.445, 41.5, 454.0),
            SwapQuote("7Y", 4.515, 43.8, 612.0),
            SwapQuote("10Y", 4.585, 46.2, 825.0),
            SwapQuote("30Y", 4.765, 52.0, 1740.0)
        )
    }

    fun getOptionQuotes(): List<OptionQuote> {
        return listOf(
            OptionQuote("Cap 4.00%", "3M NYIBOR", 4.00, "1Y", 68.0, 16.8, 38.2, 0.54, 1.45, 18.2, -0.85, 94.2),
            OptionQuote("Cap 4.25%", "3M NYIBOR", 4.25, "1Y", 69.5, 16.2, 24.6, 0.38, 1.38, 16.5, -0.62, 71.0),
            OptionQuote("Floor 3.75%", "3M NYIBOR", 3.75, "1Y", 67.0, 17.1, 19.4, -0.28, 1.25, 14.8, -0.48, 52.0),
            OptionQuote("Payer Swaption 1Yx5Y", "5Y Swap", 4.45, "1Y", 72.0, 15.9, 114.5, 0.51, 0.88, 45.4, -1.95, 440.0),
            OptionQuote("Receiver Swaption 1Yx5Y", "5Y Swap", 4.45, "1Y", 72.0, 15.9, 108.2, -0.49, 0.88, 45.4, -1.82, 440.0),
            OptionQuote("Collar 3.75% / 4.25%", "3M NYIBOR", 4.00, "1Y", 68.5, 16.5, 5.2, 0.10, 0.13, 1.7, -0.14, 19.0)
        )
    }

    fun getPortfolioPositions(): List<PortfolioPosition> {
        return listOf(
            PortfolioPosition("P01", "USD Rates", "Term Basis", "IRS Fixed vs NYIBOR 3M", "Receive Fixed 5Y", "NYIBOR 3M", 100.0, 245000.0, 48200.0, -4540.0, -0.52, 0.08, 120.0, 2.4),
            PortfolioPosition("P02", "Money Market", "Credit RV", "NYIBOR 3M vs SOFR Basis Swap", "Long NYIBOR / Short SOFR", "NYIBOR / SOFR", 250.0, 112000.0, 15800.0, 1250.0, 0.85, 0.02, 35.0, 3.1),
            PortfolioPosition("P03", "Exotics & Vol", "Cap/Floor Book", "NYIBOR 3M Cap 4.25% 2Y", "Long Vol Tail Hedge", "NYIBOR 3M", 50.0, 185000.0, -6400.0, 340.0, 0.42, 1.15, 850.0, 1.2),
            PortfolioPosition("P04", "Trading Desk", "Curve Flies", "NYIBOR 2s5s10s Butterfly", "Long Belly / Short Wings", "NYIBOR Curve", 150.0, 89000.0, 22100.0, -180.0, -0.04, 0.44, 45.0, 2.8),
            PortfolioPosition("P05", "Futures Desk", "Strip Hedge", "NYRX 3M Futures Pack", "Short Jun26-Mar27 Strip", "NYRX Futures", 75.0, 54000.0, 8900.0, -2950.0, -0.98, 0.01, 15.0, 1.5)
        )
    }

    val marketRegimes = listOf(
        MarketRegime("2026 CURRENT SIMULATED", "2026–Present", "Current baseline with steady USD interbank liquidity and moderate term premium", 4.02, 3.65, 37.0, "Stable L1 transactions, disciplined panel submissions"),
        MarketRegime("2025 DISINFLATION", "2024–2025", "Fed rate cut cycle begins, curve bull-steepens, bank wholesale costs decrease", 4.45, 4.15, 30.0, "Compressing credit spreads, tight dispersion"),
        MarketRegime("2024 CREDIT STRESS", "2023–2024", "Regional bank capital concerns, term unsecured premium widened sharply", 5.65, 5.05, 60.0, "Elevated dispersion, heightened tiering across panel"),
        MarketRegime("2022 RAPID TIGHTENING", "2022–2023", "Aggressive Fed rate hiking campaign (+500bp), forward curves strongly inverted", 4.80, 4.30, 50.0, "High rate volatility, frequent intraday revisions"),
        MarketRegime("2020 LIQUIDITY SHOCK", "Mar–Apr 2020", "Extreme dollar squeeze, CP/CD dislocation, wholesale market stress", 1.45, 0.05, 140.0, "Historic spread blowout, Level 4 fallback triggered"),
        MarketRegime("2018–2019 NORMAL", "2018–2019", "Steady interbank market pre-pandemic, orderly term structure", 2.60, 2.38, 22.0, "High L1 transaction proportion, tight spreads")
    )

    private fun round4(v: Double) = (v * 10000.0).roundToInt() / 10000.0
    private fun round1(v: Double) = (v * 10.0).roundToInt() / 10.0
}
