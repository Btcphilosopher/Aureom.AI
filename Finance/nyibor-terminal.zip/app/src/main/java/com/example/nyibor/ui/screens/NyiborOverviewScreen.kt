package com.example.nyibor.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nyibor.data.NyiborMarketRepository
import com.example.nyibor.engine.NYIBORCalculationEngine
import com.example.nyibor.engine.NyiborCurveEngine
import com.example.nyibor.model.BankSubmission
import com.example.nyibor.model.FixingDetail
import com.example.nyibor.model.FixingState
import com.example.nyibor.model.Tenor
import com.example.nyibor.ui.components.NyiborCurvePlot
import com.example.ui.theme.*

@Composable
fun NyiborOverviewScreen(
    fixings: List<FixingDetail>,
    selectedTenor: Tenor,
    onSelectTenor: (Tenor) -> Unit,
    onNavigateToWorkspace: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentFixing = fixings.firstOrNull { it.tenor == selectedTenor } ?: fixings.first()
    val curvePoints = remember(fixings) {
        NyiborCurveEngine.buildCurve(NyiborMarketRepository.baseNyiborRates)
    }

    var showMethodologyModal by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NyiborNavyDark)
            .padding(horizontal = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Institutional Benchmark Header Box
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("benchmark_header_card")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "NYIBOR",
                                    color = NyiborGold,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "NEW YORK INTERBANK OFFERED RATE",
                                    color = NyiborTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "Administrator: New York Interbank Benchmark Administration (NIBA)",
                                color = NyiborTextSecondary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        IconButton(
                            onClick = { showMethodologyModal = true },
                            modifier = Modifier
                                .testTag("methodology_info_button")
                                .size(32.dp)
                                .background(NyiborSurfaceElevated, RoundedCornerShape(3.dp))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Methodology",
                                tint = NyiborGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Key Stats Grid for selected tenor
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatTile(label = "FIXING RATE", value = String.format("%.4f%%", currentFixing.rate), color = NyiborTextPrimary, modifier = Modifier.weight(1f))
                        StatTile(label = "TRIMMED MEAN", value = String.format("%.4f%%", currentFixing.trimmedMean), color = NyiborBlue, modifier = Modifier.weight(1f))
                        StatTile(label = "DISPERSION", value = String.format("%.2f bp", currentFixing.dispersionBp), color = NyiborAmber, modifier = Modifier.weight(1f))
                        StatTile(label = "TURNOVER", value = "$${currentFixing.transactionVolumeMillion.toInt()}M", color = NyiborGreen, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Central NYIBOR Curve Plot
        item {
            NyiborCurvePlot(curvePoints = curvePoints)
        }

        // Tenor Matrix Quick Switcher
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "OFFICIAL BENCHMARK TENORS TABLE",
                        color = NyiborGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NyiborSurfaceElevated)
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TENOR", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("RATE", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                        Text("CHG(BP)", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("VOL(M)", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("LEVEL", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                        Text("QUALITY", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    }

                    fixings.forEach { fix ->
                        val isSel = fix.tenor == selectedTenor
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectTenor(fix.tenor) }
                                .background(if (isSel) NyiborSurfaceElevated else Color.Transparent)
                                .border(1.dp, if (isSel) NyiborGold.copy(alpha = 0.5f) else Color.Transparent)
                                .padding(horizontal = 6.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(fix.tenor.displayName, color = if (isSel) NyiborGold else NyiborTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text(String.format("%.4f%%", fix.rate), color = NyiborTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Text(String.format("%+.2f", fix.changeBp), color = if (fix.changeBp >= 0) NyiborGreen else NyiborRed, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text("$${fix.transactionVolumeMillion.toInt()}", color = NyiborTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text(fix.methodologyLevel.code, color = NyiborBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                            Text(fix.qualityScore.grade, color = NyiborGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                        }
                    }
                }
            }
        }

        // Fixing Audit & Governance Snapshot
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("fixing_audit_card")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "FIXING AUDIT TRAIL & INTEGRITY",
                            color = NyiborGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = NyiborGreen, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("STATUS: VERIFIED", color = NyiborGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("FIXING ID: ${currentFixing.fixingId}", color = NyiborTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("AUDIT HASH: ${currentFixing.auditHash}", color = NyiborTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("STATE: ${currentFixing.fixingState.name}", color = NyiborGold, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text("VERSION: ${currentFixing.methodologyVersion}", color = NyiborTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }

    if (showMethodologyModal) {
        AlertDialog(
            onDismissRequest = { showMethodologyModal = false },
            title = {
                Text(
                    text = "NIBA BENCHMARK METHODOLOGY",
                    color = NyiborGold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(modifier = Modifier.padding(4.dp)) {
                    Text(
                        text = "The New York Interbank Offered Rate (NYIBOR) is a fictional wholesale unsecured USD funding benchmark published by NIBA at 11:00 ET.\n\n" +
                                "Hybrid Waterfall Hierarchy:\n" +
                                "• Level 1: Eligible wholesale transactions\n" +
                                "• Level 2: Firm executable funding quotes\n" +
                                "• Level 3: Related maturity transactions\n" +
                                "• Level 4: Modelled / expert judgment\n\n" +
                                "Calculation: 60% Trimmed Mean (15% trim) + 40% Volume-Weighted Mean, with robust IQR outlier rejection.",
                        color = NyiborTextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showMethodologyModal = false },
                    colors = ButtonDefaults.buttonColors(containerColor = NyiborGold)
                ) {
                    Text("CLOSE", color = NyiborNavyDark, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = NyiborSurfaceDark
        )
    }
}

@Composable
fun StatTile(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(NyiborSurfaceElevated, RoundedCornerShape(2.dp))
            .border(1.dp, NyiborBorder, RoundedCornerShape(2.dp))
            .padding(6.dp)
    ) {
        Text(text = label, color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
