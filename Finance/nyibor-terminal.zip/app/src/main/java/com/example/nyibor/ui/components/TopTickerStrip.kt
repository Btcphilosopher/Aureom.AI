package com.example.nyibor.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nyibor.model.FixingDetail
import com.example.nyibor.model.Tenor
import com.example.ui.theme.*

@Composable
fun TopTickerStrip(
    fixings: List<FixingDetail>,
    selectedTenor: Tenor,
    onSelectTenor: (Tenor) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NyiborNavyDark)
            .border(width = 1.dp, color = NyiborBorder)
            .padding(vertical = 4.dp)
    ) {
        // Institutional Watermark & Disclaimer Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "NIBA OFFICIAL FIXING",
                    color = NyiborGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "11:00 ET • HYBRID WATERFALL v3.2.1",
                    color = NyiborTextSecondary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Surface(
                color = NyiborBorder,
                shape = RoundedCornerShape(2.dp)
            ) {
                Text(
                    text = "FICTIONAL BENCHMARK / SIMULATION",
                    color = NyiborAmber,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(fixings) { fix ->
                val isSelected = fix.tenor == selectedTenor
                TickerTile(
                    fixing = fix,
                    isSelected = isSelected,
                    onClick = { onSelectTenor(fix.tenor) }
                )
            }
        }
    }
}

@Composable
fun TickerTile(
    fixing: FixingDetail,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) NyiborGold else NyiborBorder
    val bgColor = if (isSelected) NyiborSurfaceElevated else NyiborSurfaceDark
    val isUp = fixing.changeBp >= 0

    Surface(
        onClick = onClick,
        modifier = Modifier
            .testTag("ticker_tile_${fixing.tenor.code}")
            .width(135.dp)
            .border(1.dp, borderColor, RoundedCornerShape(4.dp)),
        color = bgColor,
        shape = RoundedCornerShape(4.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = fixing.tenor.displayName,
                    color = if (isSelected) NyiborGold else NyiborTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Surface(
                    color = if (fixing.methodologyLevel.code == "L1") NyiborGreen.copy(alpha = 0.2f) else NyiborBlue.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        text = fixing.methodologyLevel.code,
                        color = if (fixing.methodologyLevel.code == "L1") NyiborGreen else NyiborBlue,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Rate Display
            Text(
                text = String.format("%.4f%%", fixing.rate),
                color = NyiborTextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(2.dp))

            // Change display
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isUp) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = if (isUp) NyiborGreen else NyiborRed,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = String.format("%+.2f bp", fixing.changeBp),
                        color = if (isUp) NyiborGreen else NyiborRed,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "Q:${fixing.qualityScore.grade}",
                    color = NyiborTextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
