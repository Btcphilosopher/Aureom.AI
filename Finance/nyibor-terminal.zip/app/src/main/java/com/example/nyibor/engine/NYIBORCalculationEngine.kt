package com.example.nyibor.engine

import com.example.nyibor.model.BankSubmission
import com.example.nyibor.model.FixingDetail
import com.example.nyibor.model.FixingState
import com.example.nyibor.model.MethodologyLevel
import com.example.nyibor.model.QualityScore
import com.example.nyibor.model.Tenor
import java.security.MessageDigest
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Institutional Calculation Engine for the fictional NYIBOR benchmark.
 * Implements:
 * 1. Filtering & validation
 * 2. Outlier detection (Modified Z-score / IQR)
 * 3. Trimmed mean (top/bottom 15%)
 * 4. Volume-weighted mean & Median
 * 5. Dispersion & Confidence scoring
 * 6. Cryptographic audit hashing
 */
object NYIBORCalculationEngine {

    const val METHODOLOGY_VERSION = "v3.2.1-NYIBOR-HYBRID"
    const val MINIMUM_SUBMISSION_THRESHOLD = 8
    const val TRIM_PERCENTAGE = 0.15 // Standard 15% top & bottom trim

    data class CalculationResult(
        val fixingRate: Double,
        val trimmedMean: Double,
        val median: Double,
        val volumeWeightedMean: Double,
        val dispersionBp: Double,
        val processedSubmissions: List<BankSubmission>,
        val qualityScore: QualityScore,
        val dominantLevel: MethodologyLevel,
        val totalVolumeMillion: Double,
        val auditHash: String
    )

    fun calculateFixing(
        tenor: Tenor,
        rawSubmissions: List<BankSubmission>
    ): CalculationResult {
        if (rawSubmissions.size < MINIMUM_SUBMISSION_THRESHOLD) {
            // Insufficient submissions fallback rule
            val fallbackRate = 4.00
            return CalculationResult(
                fixingRate = fallbackRate,
                trimmedMean = fallbackRate,
                median = fallbackRate,
                volumeWeightedMean = fallbackRate,
                dispersionBp = 0.0,
                processedSubmissions = rawSubmissions,
                qualityScore = QualityScore.INSUFFICIENT,
                dominantLevel = MethodologyLevel.LEVEL_4,
                totalVolumeMillion = 0.0,
                auditHash = generateAuditHash("INSUFFICIENT_${tenor.code}")
            )
        }

        // Step 1 & 2: Sort submissions by submitted rate
        val sorted = rawSubmissions.sortedBy { it.submittedRate }

        // Step 3: Outlier detection using Interquartile Range (IQR)
        val q1 = sorted[(sorted.size * 0.25).toInt()].submittedRate
        val q3 = sorted[(sorted.size * 0.75).toInt()].submittedRate
        val iqr = q3 - q1
        val lowerBound = q1 - 1.5 * iqr
        val upperBound = q3 + 1.5 * iqr

        // Step 4: Trim top and bottom 15%
        val trimCount = (sorted.size * TRIM_PERCENTAGE).roundToInt().coerceAtLeast(1)
        val trimmedList = sorted.subList(trimCount, sorted.size - trimCount)

        // Processed submissions tag outliers & trimmed
        val processedSubmissions = sorted.map { sub ->
            val isOut = sub.submittedRate < lowerBound || sub.submittedRate > upperBound
            val isTrim = sub.submittedRate <= sorted[trimCount - 1].submittedRate ||
                    sub.submittedRate >= sorted[sorted.size - trimCount].submittedRate
            sub.copy(isOutlier = isOut, isTrimmed = isTrim)
        }

        // Step 5: Trimmed Mean
        val trimmedMean = trimmedList.map { it.submittedRate }.average()

        // Step 6: Median
        val median = if (sorted.size % 2 == 1) {
            sorted[sorted.size / 2].submittedRate
        } else {
            (sorted[sorted.size / 2 - 1].submittedRate + sorted[sorted.size / 2].submittedRate) / 2.0
        }

        // Step 7: Volume-Weighted Mean
        val totalVolume = rawSubmissions.sumOf { it.transactionVolumeMillion }
        val volumeWeightedMean = if (totalVolume > 0) {
            rawSubmissions.sumOf { it.submittedRate * it.transactionVolumeMillion } / totalVolume
        } else {
            trimmedMean
        }

        // Standard Deviation / Dispersion (in basis points)
        val variance = rawSubmissions.map { (it.submittedRate - trimmedMean).pow(2) }.average()
        val stdDev = sqrt(variance)
        val dispersionBp = stdDev * 100.0 // 1% = 100 bps

        // Benchmark Methodology hierarchy determination:
        // 60% Trimmed Mean + 40% Volume-Weighted Mean (hybrid waterfall)
        val officialBenchmark = (0.60 * trimmedMean + 0.40 * volumeWeightedMean)

        // Determine dominant level
        val levelCounts = rawSubmissions.groupingBy { it.level }.eachCount()
        val dominantLevel = levelCounts.maxByOrNull { it.value }?.key ?: MethodologyLevel.LEVEL_1

        // Data Quality Scoring
        val quality = when {
            dispersionBp < 2.5 && totalVolume > 500 && dominantLevel == MethodologyLevel.LEVEL_1 -> QualityScore.GRADE_A_PLUS
            dispersionBp < 4.0 && totalVolume > 250 -> QualityScore.GRADE_A
            dispersionBp < 6.0 -> QualityScore.GRADE_B
            dispersionBp < 9.0 -> QualityScore.GRADE_C
            else -> QualityScore.GRADE_D
        }

        val auditHash = generateAuditHash(
            "${tenor.code}_${officialBenchmark}_${totalVolume}_${rawSubmissions.size}_$METHODOLOGY_VERSION"
        )

        return CalculationResult(
            fixingRate = round4(officialBenchmark),
            trimmedMean = round4(trimmedMean),
            median = round4(median),
            volumeWeightedMean = round4(volumeWeightedMean),
            dispersionBp = round2(dispersionBp),
            processedSubmissions = processedSubmissions,
            qualityScore = quality,
            dominantLevel = dominantLevel,
            totalVolumeMillion = totalVolume,
            auditHash = auditHash
        )
    }

    private fun generateAuditHash(payload: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }.take(16).uppercase()
    }

    fun round4(value: Double): Double = (value * 10000.0).roundToInt() / 10000.0
    fun round2(value: Double): Double = (value * 100.0).roundToInt() / 100.0
}
