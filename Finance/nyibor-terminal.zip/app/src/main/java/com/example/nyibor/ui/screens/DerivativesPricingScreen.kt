package com.example.nyibor.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nyibor.data.NyiborMarketRepository
import com.example.nyibor.engine.FinancialMathEngine
import com.example.nyibor.model.FutureContract
import com.example.nyibor.model.OptionQuote
import com.example.nyibor.model.SwapQuote
import com.example.ui.theme.*

@Composable
fun DerivativesPricingScreen(
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Swaps, 1: Futures (NYRX), 2: Options / Caps
    val swaps = remember { NyiborMarketRepository.getSwaps() }
    val futures = remember { NyiborMarketRepository.getFutures() }
    val options = remember { NyiborMarketRepository.getOptionQuotes() }

    // Live Trade Pricing Calculator State
    var calcNotional by remember { mutableStateOf("100") }
    var calcFixedRate by remember { mutableStateOf("4.35") }
    var calcTenorYears by remember { mutableStateOf("5") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NyiborNavyDark)
            .padding(horizontal = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Tab Selector Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("derivatives_header_card")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "NYIBOR DERIVATIVES DESK & NYRX FUTURES PRICER",
                        color = NyiborGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Fixed vs NYIBOR IRS • NYRX 3M Futures • Cap/Floor/Swaption Vol Surface",
                        color = NyiborTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TabButton("IRS SWAPS", selectedTab == 0, onClick = { selectedTab = 0 }, modifier = Modifier.weight(1f))
                        TabButton("NYRX FUTURES", selectedTab == 1, onClick = { selectedTab = 1 }, modifier = Modifier.weight(1f))
                        TabButton("OPTIONS & CAPS", selectedTab == 2, onClick = { selectedTab = 2 }, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Active Tab Content
        when (selectedTab) {
            0 -> {
                // Swaps Screen
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "FIXED VS NYIBOR 3M SWAP CURVE QUOTES",
                                color = NyiborGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(NyiborSurfaceElevated)
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("TENOR", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                Text("PAR RATE", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                                Text("VS SOFR(BP)", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                                Text("DV01 / $1M", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            }

                            swaps.forEach { sw ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 6.dp, vertical = 5.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(sw.tenor, color = NyiborGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                    Text(String.format("%.3f%%", sw.fixedRate), color = NyiborTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                                    Text(String.format("+%.1f bp", sw.spreadVsSofrBp), color = NyiborBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                                    Text(String.format("$%.1f", sw.dv01PerMillion), color = NyiborTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                                }
                            }
                        }
                    }
                }

                // Interactive Swap Pricing Tool
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorderHighlight),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().testTag("swap_pricer_tool")
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "INSTITUTIONAL SWAP PRICER & DV01 CALCULATOR",
                                color = NyiborGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(
                                    value = calcNotional,
                                    onValueChange = { calcNotional = it },
                                    label = { Text("Notional (\$M)", fontSize = 9.sp) },
                                    modifier = Modifier.weight(1f).height(50.dp),
                                    textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                )
                                OutlinedTextField(
                                    value = calcFixedRate,
                                    onValueChange = { calcFixedRate = it },
                                    label = { Text("Fixed Rate %", fontSize = 9.sp) },
                                    modifier = Modifier.weight(1f).height(50.dp),
                                    textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                )
                                OutlinedTextField(
                                    value = calcTenorYears,
                                    onValueChange = { calcTenorYears = it },
                                    label = { Text("Maturity (Y)", fontSize = 9.sp) },
                                    modifier = Modifier.weight(1f).height(50.dp),
                                    textStyle = LocalTextStyle.current.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            val notionalVal = calcNotional.toDoubleOrNull() ?: 100.0
                            val fixedVal = calcFixedRate.toDoubleOrNull() ?: 4.35
                            val tenorVal = calcTenorYears.toDoubleOrNull() ?: 5.0
                            val parRate = 4.445
                            val dv01Val = notionalVal * 100.0 * tenorVal * 0.90
                            val npvDollar = (parRate - fixedVal) * dv01Val * 100.0

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(NyiborNavyDark, RoundedCornerShape(3.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("PORTFOLIO DV01", color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                    Text(String.format("$%,.0f / bp", dv01Val), color = NyiborGold, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("ESTIMATED NPV", color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                    Text(String.format("$%,.0f", npvDollar), color = if (npvDollar >= 0) NyiborGreen else NyiborRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // NYRX Futures Tab
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().testTag("nyrx_futures_card")
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "NEW YORK RATES EXCHANGE (NYRX) 3M NYIBOR FUTURES",
                                    color = NyiborGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text("CONTRACT: $1,000,000", color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            }
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(NyiborSurfaceElevated)
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("CODE", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                                Text("EXPIRY", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                                Text("PRICE", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                Text("RATE", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                Text("CHG", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                                Text("VOLUME", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            }

                            futures.forEach { fut ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 6.dp, vertical = 5.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(fut.code, color = NyiborGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                                    Text(fut.expiry, color = NyiborTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                                    Text(String.format("%.3f", fut.price), color = NyiborTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                    Text(String.format("%.3f%%", fut.impliedRate), color = NyiborBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                    Text(String.format("%+.3f", fut.change), color = if (fut.change >= 0) NyiborGreen else NyiborRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                                    Text(String.format("%,d", fut.volume), color = NyiborTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // Options / Caps Screen
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().testTag("options_surface_card")
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "NYIBOR VOLATILITY SURFACE & CAP/SWAPTION QUOTES",
                                color = NyiborGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Bachelier Normal Vol (bp/yr) & Black-76 Lognormal Vol (%)",
                                color = NyiborTextSecondary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            options.forEach { opt ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = NyiborSurfaceElevated),
                                    shape = RoundedCornerShape(3.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(opt.instrumentType, color = NyiborGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                            Text("EXP: ${opt.expiry}", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Normal Vol: ${opt.normalVolBps} bp", color = NyiborBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            Text("Lognormal: ${opt.lognormalVolPct}%", color = NyiborPurple, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            Text("Premium: ${opt.premiumBp} bp", color = NyiborGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Delta: ${opt.delta}", color = NyiborTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                            Text("Gamma: ${opt.gamma}", color = NyiborTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                            Text("Vega: $${opt.vega}", color = NyiborTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                            Text("Theta: $${opt.theta}", color = NyiborTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
private fun TabButton(label: String, isSelected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onClick,
        color = if (isSelected) NyiborGold else NyiborSurfaceElevated,
        shape = RoundedCornerShape(2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) NyiborGold else NyiborBorder),
        modifier = modifier
    ) {
        Text(
            text = label,
            color = if (isSelected) NyiborNavyDark else NyiborTextSecondary,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(vertical = 5.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
