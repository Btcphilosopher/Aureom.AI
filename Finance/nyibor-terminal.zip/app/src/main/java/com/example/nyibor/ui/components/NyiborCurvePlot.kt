package com.example.nyibor.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nyibor.model.CurvePoint
import com.example.ui.theme.*

@Composable
fun NyiborCurvePlot(
    curvePoints: List<CurvePoint>,
    modifier: Modifier = Modifier,
    title: String = "NYIBOR ZERO & FORWARD TERM STRUCTURE (1W to 30Y)"
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(NyiborSurfaceDark, RoundedCornerShape(4.dp))
            .border(1.dp, NyiborBorder, RoundedCornerShape(4.dp))
            .padding(10.dp)
    ) {
        // Chart Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = NyiborTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LegendIndicator(color = NyiborGold, label = "NYIBOR Par/Zero")
                LegendIndicator(color = NyiborBlue, label = "Instant Forward")
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Canvas Curve Drawing
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            val minRate = 3.60
            val maxRate = 5.00

            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Draw horizontal grid lines
                val gridSteps = 5
                for (s in 0..gridSteps) {
                    val rateVal = minRate + s * (maxRate - minRate) / gridSteps
                    val y = h - ((rateVal - minRate) / (maxRate - minRate) * h).toFloat()
                    drawLine(
                        color = NyiborBorder.copy(alpha = 0.6f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                if (curvePoints.isNotEmpty()) {
                    val stepX = w / (curvePoints.size - 1).coerceAtLeast(1)

                    val zeroPath = Path()
                    val fwdPath = Path()

                    curvePoints.forEachIndexed { idx, pt ->
                        val x = idx * stepX
                        val yZero = h - (((pt.rate - minRate) / (maxRate - minRate)).coerceIn(0.0, 1.0) * h).toFloat()
                        val yFwd = h - (((pt.forwardRate - minRate) / (maxRate - minRate)).coerceIn(0.0, 1.0) * h).toFloat()

                        if (idx == 0) {
                            zeroPath.moveTo(x, yZero)
                            fwdPath.moveTo(x, yFwd)
                        } else {
                            zeroPath.lineTo(x, yZero)
                            fwdPath.lineTo(x, yFwd)
                        }

                        // Benchmark nodes highlight with circles
                        if (pt.isBenchmark) {
                            drawCircle(
                                color = NyiborGold,
                                radius = 4f,
                                center = Offset(x, yZero)
                            )
                        }
                    }

                    // Draw lines
                    drawPath(
                        path = zeroPath,
                        color = NyiborGold,
                        style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                    )
                    drawPath(
                        path = fwdPath,
                        color = NyiborBlue,
                        style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // X-axis Tenor Labels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val keyIndices = listOf(0, 1, 3, 5, 8, 11, 13, 15).filter { it < curvePoints.size }
            keyIndices.forEach { idx ->
                val pt = curvePoints[idx]
                Text(
                    text = pt.tenor.code,
                    color = if (pt.isBenchmark) NyiborGold else NyiborTextSecondary,
                    fontSize = 9.sp,
                    fontWeight = if (pt.isBenchmark) FontWeight.Bold else FontWeight.Normal,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun LegendIndicator(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color, RoundedCornerShape(1.dp))
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            color = NyiborTextSecondary,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
