package com.example.nyibor.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nyibor.data.NyiborMarketRepository
import com.example.nyibor.engine.FinancialMathEngine
import com.example.nyibor.model.MarketRegime
import com.example.nyibor.model.PortfolioPosition
import com.example.ui.theme.*

@Composable
fun RiskAndScenarioScreen(
    modifier: Modifier = Modifier
) {
    val positions = remember { NyiborMarketRepository.getPortfolioPositions() }
    val totalNotional = remember(positions) { positions.sumOf { it.notionalMillion } }
    val totalPnl = remember(positions) { positions.sumOf { it.pnlDollar } }
    val totalDv01 = remember(positions) { positions.sumOf { it.dv01 } }

    // Interactive Stress Scenario State
    var selectedScenarioBp by remember { mutableStateOf(25.0) } // +25bp parallel
    var selectedBasisShockBp by remember { mutableStateOf(10.0) } // +10bp NYIBOR-SOFR basis widen

    // Monte Carlo State
    val monteCarloResult = remember(totalNotional, totalDv01) {
        FinancialMathEngine.runMonteCarlo(
            portfolioNotionalMillion = totalNotional,
            portfolioDv01 = kotlin.math.abs(totalDv01)
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NyiborNavyDark)
            .padding(horizontal = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Institutional Risk Aggregation Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("risk_header_card")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "NYIBOR PORTFOLIO RISK & CAPITAL ADEQUACY DESK",
                        color = NyiborGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Cross-Asset Greeks • Key Rate Duration • Monte Carlo VaR (99% 10D)",
                        color = NyiborTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatTile(label = "NOTIONAL", value = "$${totalNotional.toInt()}M", color = NyiborTextPrimary, modifier = Modifier.weight(1f))
                        StatTile(label = "NET P&L", value = String.format("$%,.0f", totalPnl), color = if (totalPnl >= 0) NyiborGreen else NyiborRed, modifier = Modifier.weight(1.2f))
                        StatTile(label = "PORTFOLIO DV01", value = String.format("$%,.0f/bp", totalDv01), color = NyiborGold, modifier = Modifier.weight(1.3f))
                        StatTile(label = "99% 10D VaR", value = String.format("$%,.0f", monteCarloResult.valueAtRiskDollar), color = NyiborAmber, modifier = Modifier.weight(1.3f))
                    }
                }
            }
        }

        // Stress Scenario Engine
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorderHighlight),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("stress_scenario_card")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "INSTITUTIONAL STRESS TEST MATRIX",
                            color = NyiborGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "LIVE REVALUATION",
                            color = NyiborGreen,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Scenario buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val scenarios = listOf(
                            "+25bp Parallel" to 25.0,
                            "-25bp Parallel" to -25.0,
                            "+50bp Tighten" to 50.0,
                            "Basis Blowout +30bp" to 30.0
                        )
                        scenarios.forEach { (label, shift) ->
                            val isSel = selectedScenarioBp == shift
                            Surface(
                                onClick = { selectedScenarioBp = shift },
                                color = if (isSel) NyiborGold else NyiborSurfaceElevated,
                                shape = RoundedCornerShape(2.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) NyiborGold else NyiborBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSel) NyiborNavyDark else NyiborTextSecondary,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 4.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val simulatedStressPnl = totalDv01 * selectedScenarioBp * 100.0

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NyiborNavyDark, RoundedCornerShape(3.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("SCENARIO IMPACT (${selectedScenarioBp.toInt()} bp shift)", color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                text = String.format("$%,.0f", simulatedStressPnl),
                                color = if (simulatedStressPnl >= 0) NyiborGreen else NyiborRed,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("EXPECTED SHORTFALL", color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                text = String.format("$%,.0f", monteCarloResult.expectedShortfallDollar),
                                color = NyiborAmber,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Positions Ledger
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("portfolio_ledger_card")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "ACTIVE DESK POSITIONS & RISK ALLOCATION",
                        color = NyiborGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    positions.forEach { pos ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = NyiborSurfaceElevated),
                            shape = RoundedCornerShape(3.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(pos.instrument, color = NyiborGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        Text("Desk: ${pos.desk} • Strategy: ${pos.strategy}", color = NyiborTextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(String.format("$%,.0f", pos.pnlDollar), color = if (pos.pnlDollar >= 0) NyiborGreen else NyiborRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        Text("DV01: $${pos.dv01.toInt()}", color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Historical Fictional Market Regimes
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "SIMULATED HISTORICAL MARKET REGIMES (2018–2026)",
                        color = NyiborGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    NyiborMarketRepository.marketRegimes.forEach { reg ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(NyiborSurfaceElevated, RoundedCornerShape(2.dp))
                                .padding(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(reg.name, color = NyiborTextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(reg.period, color = NyiborGold, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Avg 3M: ${reg.nyibor3mAvg}% | SOFR: ${reg.sofrAvg}% | Basis: +${reg.avgBasisBp} bp",
                                color = NyiborBlue,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = reg.description,
                                color = NyiborTextMuted,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}
