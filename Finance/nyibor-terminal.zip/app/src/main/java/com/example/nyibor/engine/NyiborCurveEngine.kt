package com.example.nyibor.engine

import com.example.nyibor.model.CurvePoint
import com.example.nyibor.model.Tenor
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Multi-Curve and Forward Rate Engine for NYIBOR.
 * Bootstraps:
 * - Zero Rates
 * - Discount Factors: P(0, T) = exp(-z * T)
 * - Forward Rates: F(T1, T2) = (P(0, T1)/P(0, T2) - 1) / (T2 - T1)
 * - Curve Slope & Curvature (butterfly metrics e.g. 2s5s10s)
 */
object NyiborCurveEngine {

    fun buildCurve(baseRates: Map<Tenor, Double>): List<CurvePoint> {
        val tenors = Tenor.curveTenors
        val points = mutableListOf<CurvePoint>()

        var prevRate = baseRates[Tenor.M3] ?: 4.02

        for (i in tenors.indices) {
            val tenor = tenors[i]
            val rate = baseRates[tenor] ?: estimateRateForTenor(tenor, baseRates)
            val tYears = tenor.days / 360.0

            // Zero Rate (continuous compounding approximation for money markets)
            val zeroRate = rate * (1.0 - 0.005 * (tYears - 0.25).coerceAtLeast(0.0))
            // Discount factor: P(0, t) = 1 / (1 + r * t) for money markets < 1y, exp(-z*t) for > 1y
            val discountFactor = if (tYears <= 1.0) {
                1.0 / (1.0 + (rate / 100.0) * tYears)
            } else {
                exp(-(zeroRate / 100.0) * tYears)
            }

            // Forward rate to next standard node
            val nextTenor = tenors.getOrNull(i + 1)
            val forwardRate = if (nextTenor != null) {
                val nextRate = baseRates[nextTenor] ?: estimateRateForTenor(nextTenor, baseRates)
                val tNext = nextTenor.days / 360.0
                val dfNext = if (tNext <= 1.0) 1.0 / (1.0 + (nextRate / 100.0) * tNext) else exp(-(nextRate / 100.0) * tNext)
                val dt = tNext - tYears
                if (dt > 0.001) {
                    ((discountFactor / dfNext) - 1.0) / dt * 100.0
                } else rate
            } else {
                rate + 0.15 // Terminal extrapolation
            }

            // Curve slope (vs 3M benchmark in bp)
            val benchmark3m = baseRates[Tenor.M3] ?: 4.02
            val slopeBp = (rate - benchmark3m) * 100.0

            // Curvature: 2 * R(i) - R(i-1) - R(i+1)
            val prevR = if (i > 0) points[i - 1].rate else rate
            val nextR = baseRates[nextTenor] ?: rate
            val curvatureBp = (2 * rate - prevR - nextR) * 100.0

            // Historical percentile (modelled based on 5-year cycle)
            val percentile = ((rate - 3.20) / (5.40 - 3.20) * 100.0).coerceIn(5.0, 95.0)

            points.add(
                CurvePoint(
                    tenor = tenor,
                    rate = round3(rate),
                    zeroRate = round3(zeroRate),
                    forwardRate = round3(forwardRate),
                    discountFactor = round4(discountFactor),
                    isBenchmark = tenor.isPrimary,
                    slopeBp = round1(slopeBp),
                    curvatureBp = round1(curvatureBp),
                    percentile = round1(percentile)
                )
            )
            prevRate = rate
        }

        return points
    }

    private fun estimateRateForTenor(tenor: Tenor, known: Map<Tenor, Double>): Double {
        val tYears = tenor.days / 360.0
        val m3 = known[Tenor.M3] ?: 4.02
        val m12 = known[Tenor.M12] ?: 4.19
        // Log-linear interpolation/extrapolation
        return when {
            tYears < 0.25 -> m3 - (0.25 - tYears) * 0.45
            tYears <= 1.0 -> m3 + (tYears - 0.25) / 0.75 * (m12 - m3)
            tYears <= 5.0 -> m12 + (tYears - 1.0) * 0.08
            tYears <= 10.0 -> m12 + 0.32 + (tYears - 5.0) * 0.03
            else -> m12 + 0.47 + (tYears - 10.0) * 0.015
        }
    }

    fun calculateFra(
        startMonths: Int,
        endMonths: Int,
        notionalMillion: Double,
        fraFixedRatePct: Double,
        curveRates: Map<Tenor, Double>
    ): FraResult {
        val t1 = startMonths / 12.0
        val t2 = endMonths / 12.0
        val dt = t2 - t1

        // Model forward fixing
        val fwdRate = (curveRates[Tenor.M3] ?: 4.02) + (startMonths * 0.025)
        // Settlement amount = Notional * (Fwd - Strike) * dt / (1 + Fwd * dt)
        val num = notionalMillion * 1_000_000 * ((fwdRate - fraFixedRatePct) / 100.0) * dt
        val den = 1.0 + (fwdRate / 100.0) * dt
        val settlementDollar = num / den
        val dv01 = notionalMillion * 100.0 * dt / den

        return FraResult(
            fraName = "${startMonths}x$endMonths",
            impliedForwardPct = round3(fwdRate),
            strikePct = fraFixedRatePct,
            settlementDollar = round2(settlementDollar),
            dv01 = round2(dv01)
        )
    }

    data class FraResult(
        val fraName: String,
        val impliedForwardPct: Double,
        val strikePct: Double,
        val settlementDollar: Double,
        val dv01: Double
    )

    private fun round4(v: Double) = (v * 10000.0).roundToInt() / 10000.0
    private fun round3(v: Double) = (v * 1000.0).roundToInt() / 1000.0
    private fun round2(v: Double) = (v * 100.0).roundToInt() / 100.0
    private fun round1(v: Double) = (v * 10.0).roundToInt() / 10.0
}
