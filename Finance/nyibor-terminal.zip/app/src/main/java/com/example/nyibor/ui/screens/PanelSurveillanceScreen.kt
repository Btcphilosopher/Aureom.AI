package com.example.nyibor.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nyibor.data.NyiborMarketRepository
import com.example.nyibor.engine.NYIBORCalculationEngine
import com.example.nyibor.model.BankSubmission
import com.example.nyibor.model.PanelBank
import com.example.nyibor.model.Tenor
import com.example.ui.theme.*

@Composable
fun PanelSurveillanceScreen(
    modifier: Modifier = Modifier
) {
    var selectedTenor by remember { mutableStateOf(Tenor.M3) }
    val rawSubmissions = remember(selectedTenor) {
        NyiborMarketRepository.generateSubmissions(selectedTenor)
    }
    val calculationResult = remember(rawSubmissions) {
        NYIBORCalculationEngine.calculateFixing(selectedTenor, rawSubmissions)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NyiborNavyDark)
            .padding(horizontal = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Surveillance Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("surveillance_header_card")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "NIBA MARKET SURVEILLANCE & PANEL MONITOR",
                            color = NyiborGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Surface(
                            color = NyiborGreen.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = "SURVEILLANCE ACTIVE",
                                color = NyiborGreen,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "15 Submitting Panel Banks • 15% Trimmed Mean Algorithm • IQR Outlier Rejection",
                        color = NyiborTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Tenor Picker
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Tenor.primaryTenors.forEach { t ->
                            val isSel = t == selectedTenor
                            Surface(
                                onClick = { selectedTenor = t },
                                color = if (isSel) NyiborGold else NyiborSurfaceElevated,
                                shape = RoundedCornerShape(2.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) NyiborGold else NyiborBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = t.displayName,
                                    color = if (isSel) NyiborNavyDark else NyiborTextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.padding(vertical = 4.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dispersion Distribution Visual
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorderHighlight),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "SUBMISSION DISPERSION PLOT (${selectedTenor.displayName})",
                        color = NyiborGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Fixing: ${calculationResult.fixingRate}% | Std Dev: ${calculationResult.dispersionBp} bp | Volume: $${calculationResult.totalVolumeMillion.toInt()}M",
                        color = NyiborTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Distribution Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .background(NyiborNavyDark, RoundedCornerShape(3.dp))
                    ) {
                        val minR = calculationResult.fixingRate - 0.08
                        val maxR = calculationResult.fixingRate + 0.08

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height
                            val midY = h / 2f

                            // Baseline line
                            drawLine(
                                color = NyiborBorder,
                                start = Offset(0f, midY),
                                end = Offset(w, midY),
                                strokeWidth = 1.5f
                            )

                            // Fixing indicator
                            val fixingX = ((calculationResult.fixingRate - minR) / (maxR - minR)).toFloat().coerceIn(0f, 1f) * w
                            drawLine(
                                color = NyiborGold,
                                start = Offset(fixingX, 6f),
                                end = Offset(fixingX, h - 6f),
                                strokeWidth = 2.5f
                            )

                            // Bank dots
                            calculationResult.processedSubmissions.forEach { sub ->
                                val x = ((sub.submittedRate - minR) / (maxR - minR)).toFloat().coerceIn(0f, 1f) * w
                                val dotColor = when {
                                    sub.isOutlier -> NyiborRed
                                    sub.isTrimmed -> NyiborAmber
                                    sub.level.code == "L1" -> NyiborGreen
                                    else -> NyiborBlue
                                }
                                drawCircle(
                                    color = dotColor,
                                    radius = if (sub.isOutlier) 5f else 4f,
                                    center = Offset(x, midY)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LegendTag("L1 Valid", NyiborGreen)
                            LegendTag("L2/L3 Valid", NyiborBlue)
                            LegendTag("Trimmed (15%)", NyiborAmber)
                            LegendTag("Outlier", NyiborRed)
                        }
                        LegendTag("Official Fixing", NyiborGold)
                    }
                }
            }
        }

        // Submissions Table
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "PANEL SUBMISSIONS LOG (15 CONTRIBUTOR INSTITUTIONS)",
                        color = NyiborGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NyiborSurfaceElevated)
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("BANK", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.8f))
                        Text("RATE", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("VOL(M)", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                        Text("LVL", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.7f))
                        Text("STATUS", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    }

                    calculationResult.processedSubmissions.forEach { sub ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(sub.bankName, color = NyiborTextPrimary, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.8f), maxLines = 1)
                            Text(String.format("%.4f%%", sub.submittedRate), color = NyiborTextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text("$${sub.transactionVolumeMillion.toInt()}", color = NyiborTextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                            Text(sub.level.code, color = if (sub.level.code == "L1") NyiborGreen else NyiborBlue, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.7f))
                            val statusText = when {
                                sub.isOutlier -> "OUTLIER"
                                sub.isTrimmed -> "TRIMMED"
                                else -> "ACCEPTED"
                            }
                            val statusColor = when {
                                sub.isOutlier -> NyiborRed
                                sub.isTrimmed -> NyiborAmber
                                else -> NyiborGreen
                            }
                            Text(statusText, color = statusColor, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
private fun LegendTag(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(5.dp).background(color, RoundedCornerShape(1.dp)))
        Spacer(modifier = Modifier.width(3.dp))
        Text(text = label, color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}
