package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = NyiborGold,
    onPrimary = NyiborNavyDark,
    primaryContainer = NyiborSurfaceElevated,
    onPrimaryContainer = NyiborTextPrimary,
    secondary = NyiborBlue,
    onSecondary = NyiborNavyDark,
    secondaryContainer = NyiborBorder,
    onSecondaryContainer = NyiborTextPrimary,
    background = NyiborNavyDark,
    onBackground = NyiborTextPrimary,
    surface = NyiborSurfaceDark,
    onSurface = NyiborTextPrimary,
    surfaceVariant = NyiborSurfaceElevated,
    onSurfaceVariant = NyiborTextSecondary,
    outline = NyiborBorder,
    outlineVariant = NyiborBorderHighlight,
    error = NyiborRed,
    onError = NyiborTextPrimary
)

private val LightColorScheme = lightColorScheme(
    primary = NyiborGold,
    onPrimary = NyiborNavyDark,
    primaryContainer = NyiborSurfaceElevatedLight,
    onPrimaryContainer = NyiborTextPrimaryLight,
    secondary = NyiborBlue,
    onSecondary = NyiborNavyLight,
    secondaryContainer = NyiborBorderLight,
    onSecondaryContainer = NyiborTextPrimaryLight,
    background = NyiborNavyLight,
    onBackground = NyiborTextPrimaryLight,
    surface = NyiborSurfaceLight,
    onSurface = NyiborTextPrimaryLight,
    surfaceVariant = NyiborSurfaceElevatedLight,
    onSurfaceVariant = NyiborTextSecondaryLight,
    outline = NyiborBorderLight,
    outlineVariant = NyiborTextSecondaryLight,
    error = NyiborRed,
    onError = NyiborNavyLight
)

@Composable
fun NYIBORTheme(
    darkTheme: Boolean = true, // Default to true for institutional terminal trading vibe
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
