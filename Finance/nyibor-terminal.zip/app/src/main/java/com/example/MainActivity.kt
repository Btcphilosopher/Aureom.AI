package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nyibor.data.NyiborMarketRepository
import com.example.nyibor.model.Tenor
import com.example.nyibor.ui.components.RqqlCommandBar
import com.example.nyibor.ui.components.TopTickerStrip
import com.example.nyibor.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NYIBORTheme {
                MainTerminalApp()
            }
        }
    }
}

enum class TerminalWorkspace(val code: String, val title: String, val icon: ImageVector) {
    OVERVIEW("NYI", "OVERVIEW", Icons.Default.ShowChart),
    RELATIVE_VALUE("NYR", "RV vs SOFR", Icons.Default.CompareArrows),
    SURVEILLANCE("NYS", "PANEL LOG", Icons.Default.Security),
    DERIVATIVES("NYD", "DERIVATIVES", Icons.Default.AccountBalance),
    RISK("NYK", "RISK & STRESS", Icons.Default.Analytics),
    GOVERNANCE("NYG", "GOVERNANCE", Icons.Default.Gavel)
}

@Composable
fun MainTerminalApp() {
    var activeWorkspace by remember { mutableStateOf(TerminalWorkspace.OVERVIEW) }
    var selectedTenor by remember { mutableStateOf(Tenor.M3) }
    val fixings = remember { NyiborMarketRepository.getFixings() }

    // RQQL Command Interpreter logic
    val onExecuteCommand: (String) -> String = { query ->
        val upper = query.uppercase().trim()
        when {
            upper.contains("GET NYIBOR(3M)") || upper == "GET NYIBOR" -> {
                "NYIBOR 3M Fixing: 4.0200% (+0.75 bp). Trimmed: 4.0195%. Volume: $1,450M. Quality: GRADE_A. Audit: A74F09BC."
            }
            upper.contains("CURVE") -> {
                activeWorkspace = TerminalWorkspace.OVERVIEW
                "Loaded NYIBOR Multi-Curve: 1W (3.86%) to 30Y (4.77%). 2s10s slope: +31.0 bp. Butterfly curvature: -2.4 bp."
            }
            upper.contains("SOFR") || upper.contains("RV") || upper.contains("BASIS") -> {
                activeWorkspace = TerminalWorkspace.RELATIVE_VALUE
                "NYIBOR vs SOFR 3M Basis: +37.0 bp (Z-Score: +0.65). Decomposition: Credit 15.5bp, Liq 8.1bp, Term 5.9bp, BS 4.4bp, Stress 3.1bp."
            }
            upper.contains("SWAP") -> {
                activeWorkspace = TerminalWorkspace.DERIVATIVES
                "NYIBOR 3M 5Y Par IRS: 4.445% (Spread vs SOFR: +41.5 bp). DV01: $454/M. P&L Convexity: +0.08."
            }
            upper.contains("STRESS") || upper.contains("+50BP") -> {
                activeWorkspace = TerminalWorkspace.RISK
                "Applied +50bp parallel shock. Portfolio revaluation impact: -$309,000. Capital ratio remains compliant."
            }
            upper.contains("MONTE CARLO") || upper.contains("VAR") -> {
                activeWorkspace = TerminalWorkspace.RISK
                "Monte Carlo (3,000 runs, 99% 10-day): VaR = $384,120. Expected Shortfall = $471,900. Max loss = $782,000."
            }
            upper.contains("PANEL") || upper.contains("BANKS") -> {
                activeWorkspace = TerminalWorkspace.SURVEILLANCE
                "15 Panel banks reporting. Outliers rejected: 0. Trimmed: Atlantic Union, American Mercantile."
            }
            else -> {
                "Executed: '$query'. Result: Query OK. Status 200. Data verified against NIBA Snapshot."
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(NyiborNavyDark)
            .testTag("nyibor_main_terminal"),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopTickerStrip(
                fixings = fixings,
                selectedTenor = selectedTenor,
                onSelectTenor = { selectedTenor = it }
            )
        },
        bottomBar = {
            // Institutional Bottom Navigation & Workspace Switcher
            Surface(
                color = NyiborNavyDark,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NyiborBorder)
            ) {
                Column {
                    // RQQL Terminal Bar embedded above nav
                    RqqlCommandBar(onExecuteCommand = onExecuteCommand)

                    // Navigation Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TerminalWorkspace.values().forEach { ws ->
                            val isSel = ws == activeWorkspace
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .testTag("nav_tab_${ws.code}")
                                    .weight(1f)
                                    .clickable { activeWorkspace = ws }
                                    .padding(vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = ws.icon,
                                    contentDescription = ws.title,
                                    tint = if (isSel) NyiborGold else NyiborTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = ws.code,
                                    color = if (isSel) NyiborGold else NyiborTextMuted,
                                    fontSize = 9.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(NyiborNavyDark)
        ) {
            when (activeWorkspace) {
                TerminalWorkspace.OVERVIEW -> {
                    NyiborOverviewScreen(
                        fixings = fixings,
                        selectedTenor = selectedTenor,
                        onSelectTenor = { selectedTenor = it },
                        onNavigateToWorkspace = { wsCode ->
                            TerminalWorkspace.values().firstOrNull { it.code == wsCode }?.let {
                                activeWorkspace = it
                            }
                        }
                    )
                }
                TerminalWorkspace.RELATIVE_VALUE -> {
                    RelativeValueScreen()
                }
                TerminalWorkspace.SURVEILLANCE -> {
                    PanelSurveillanceScreen()
                }
                TerminalWorkspace.DERIVATIVES -> {
                    DerivativesPricingScreen()
                }
                TerminalWorkspace.RISK -> {
                    RiskAndScenarioScreen()
                }
                TerminalWorkspace.GOVERNANCE -> {
                    GovernanceScreen()
                }
            }
        }
    }
}
