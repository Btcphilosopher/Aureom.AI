package com.example.nyibor.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nyibor.data.NyiborMarketRepository
import com.example.nyibor.model.RelativeValuePoint
import com.example.nyibor.model.Tenor
import com.example.ui.theme.*

@Composable
fun RelativeValueScreen(
    modifier: Modifier = Modifier
) {
    val rvPoints = remember { NyiborMarketRepository.getRelativeValuePoints() }
    var selectedTenor by remember { mutableStateOf(Tenor.M3) }
    val currentRv = rvPoints.firstOrNull { it.tenor == selectedTenor } ?: rvPoints.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NyiborNavyDark)
            .padding(horizontal = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // RV Workspace Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("relative_value_card")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "NYIBOR VS SOFR & FED FUNDS (EFFR) SPREAD ANALYSIS",
                        color = NyiborGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Unsecured Wholesale Term Funding vs Secured Treasury Repo Benchmark",
                        color = NyiborTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Summary Stats
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatTile(label = "NYIBOR 3M", value = "4.0200%", color = NyiborGold, modifier = Modifier.weight(1f))
                        StatTile(label = "TERM SOFR 3M", value = "${currentRv.sofr}%", color = NyiborBlue, modifier = Modifier.weight(1f))
                        StatTile(label = "SPREAD (BASIS)", value = "+${currentRv.nyiborMinusSofrBp} bp", color = NyiborGreen, modifier = Modifier.weight(1f))
                        StatTile(label = "BASIS VOL (30D)", value = "${currentRv.basisVolBp} bp", color = NyiborAmber, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // RhinoQuant Modelled Decomposition of Spread
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorderHighlight),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RHINOQUANT MODELLED SPREAD DECOMPOSITION",
                            color = NyiborGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Surface(
                            color = NyiborBorder,
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = "MODELLED PROJECTION",
                                color = NyiborAmber,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "Theoretical structural decomposition of ${currentRv.nyiborMinusSofrBp} bp NYIBOR-SOFR basis",
                        color = NyiborTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Stacked Bar Visual for decomposition
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .background(NyiborNavyDark, RoundedCornerShape(3.dp))
                    ) {
                        val total = currentRv.nyiborMinusSofrBp.coerceAtLeast(1.0)
                        val creditPct = (currentRv.creditComponentBp / total).toFloat()
                        val liqPct = (currentRv.liquidityComponentBp / total).toFloat()
                        val termPct = (currentRv.termComponentBp / total).toFloat()
                        val bsPct = (currentRv.fundingBalanceSheetBp / total).toFloat()

                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            val w1 = w * creditPct
                            val w2 = w * liqPct
                            val w3 = w * termPct
                            val w4 = w * bsPct
                            val w5 = w - (w1 + w2 + w3 + w4)

                            drawRect(color = NyiborGold, topLeft = Offset(0f, 0f), size = Size(w1, h))
                            drawRect(color = NyiborBlue, topLeft = Offset(w1, 0f), size = Size(w2, h))
                            drawRect(color = NyiborPurple, topLeft = Offset(w1 + w2, 0f), size = Size(w3, h))
                            drawRect(color = NyiborGreen, topLeft = Offset(w1 + w2 + w3, 0f), size = Size(w4, h))
                            drawRect(color = NyiborAmber, topLeft = Offset(w1 + w2 + w3 + w4, 0f), size = Size(w5, h))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Component Breakdown Grid
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        DecompositionRow(label = "CREDIT RISK COMPONENT", bp = currentRv.creditComponentBp, color = NyiborGold, desc = "Unsecured bank balance sheet default risk premium")
                        DecompositionRow(label = "LIQUIDITY PREMIUM", bp = currentRv.liquidityComponentBp, color = NyiborBlue, desc = "Term funding liquidity preference vs daily overnight roll")
                        DecompositionRow(label = "TERM PREMIUM", bp = currentRv.termComponentBp, color = NyiborPurple, desc = "Duration interest-rate path uncertainty compensation")
                        DecompositionRow(label = "BALANCE SHEET / REGULATORY", bp = currentRv.fundingBalanceSheetBp, color = NyiborGreen, desc = "LCR / NSFR regulatory capital balance-sheet friction")
                        DecompositionRow(label = "MARKET STRESS FACTOR", bp = currentRv.marketStressBp, color = NyiborAmber, desc = "Idiosyncratic wholesale money-market friction")
                    }
                }
            }
        }

        // Relative Value Matrix Table
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "TENOR RV CROSS-BENCHMARK MATRIX",
                        color = NyiborGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NyiborSurfaceElevated)
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TENOR", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("NYIBOR", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                        Text("SOFR", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                        Text("NY-SOFR", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                        Text("NY-EFFR", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                        Text("Z-SCORE", color = NyiborTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                    }

                    rvPoints.forEach { pt ->
                        val isSel = pt.tenor == selectedTenor
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedTenor = pt.tenor }
                                .background(if (isSel) NyiborSurfaceElevated else Color.Transparent)
                                .border(1.dp, if (isSel) NyiborGold.copy(alpha = 0.5f) else Color.Transparent)
                                .padding(horizontal = 6.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(pt.tenor.displayName, color = if (isSel) NyiborGold else NyiborTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text(String.format("%.4f%%", pt.nyibor), color = NyiborTextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                            Text(String.format("%.4f%%", pt.sofr), color = NyiborBlue, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                            Text(String.format("+%.1f bp", pt.nyiborMinusSofrBp), color = NyiborGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Text(String.format("+%.1f bp", pt.nyiborMinusEffrBp), color = NyiborAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                            Text(String.format("%.2f", pt.zScore), color = NyiborTextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.9f))
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
fun DecompositionRow(label: String, bp: Double, color: Color, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NyiborSurfaceElevated, RoundedCornerShape(2.dp))
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(6.dp).background(color, RoundedCornerShape(1.dp)))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = label, color = NyiborTextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Text(text = desc, color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
        Text(
            text = String.format("%.1f bp", bp),
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
