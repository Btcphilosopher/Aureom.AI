package com.example.nyibor.engine

import kotlin.math.*

/**
 * Quantitative Financial Math Engine for NYIBOR:
 * - Black-76, Bachelier (Normal Volatility), and SABR Volatility
 * - Cap / Floor / Swaption valuation
 * - Full Institutional Greeks: Delta, Gamma, Vega, Theta, Rho, Vanna, Volga
 * - Monte Carlo Value-at-Risk (VaR) and Expected Shortfall (ES)
 */
object FinancialMathEngine {

    // Standard Normal Cumulative Distribution Function (Hastings approximation)
    fun normCdf(x: Double): Double {
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429
        val p = 0.2316419
        val c = 0.3989422804014337 // 1 / sqrt(2 * PI)

        if (x >= 0.0) {
            val t = 1.0 / (1.0 + p * x)
            return (1.0 - c * exp(-x * x / 2.0) * t *
                    (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        } else {
            val t = 1.0 / (1.0 - p * x)
            return (c * exp(-x * x / 2.0) * t *
                    (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        }
    }

    // Standard Normal Probability Density Function
    fun normPdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
    }

    /**
     * Bachelier (Normal Volatility) Model - Industry standard for interest rate options / negative rate capability
     * forward: forward interest rate (e.g. 0.0402 for 4.02%)
     * strike: strike interest rate (e.g. 0.0400 for 4.00%)
     * normalVolBp: normal volatility in basis points per year (e.g. 75.0 bp = 0.0075)
     * tYears: time to expiry in years
     * isCall: true for Caplet/Payer, false for Floorlet/Receiver
     */
    fun bachelierPrice(
        forward: Double,
        strike: Double,
        normalVolBp: Double,
        tYears: Double,
        isCall: Boolean,
        discountFactor: Double = 0.96
    ): GreekOutput {
        val sigma = (normalVolBp / 10000.0).coerceAtLeast(0.0001)
        val sqrtT = sqrt(tYears.coerceAtLeast(0.01))
        val d = (forward - strike) / (sigma * sqrtT)

        val price = if (isCall) {
            discountFactor * ((forward - strike) * normCdf(d) + sigma * sqrtT * normPdf(d))
        } else {
            discountFactor * ((strike - forward) * normCdf(-d) + sigma * sqrtT * normPdf(d))
        }

        // Greeks
        val delta = if (isCall) discountFactor * normCdf(d) else discountFactor * (normCdf(d) - 1.0)
        val gamma = discountFactor * normPdf(d) / (sigma * sqrtT)
        val vega = discountFactor * sqrtT * normPdf(d) * 0.0001 // Vega per 1 bp vol move
        val theta = -discountFactor * (sigma / (2.0 * sqrtT)) * normPdf(d) / 365.0
        val rho = -tYears * price
        val vanna = -discountFactor * d * normPdf(d) / sigma
        val volga = discountFactor * sqrtT * normPdf(d) * (d * d) / sigma

        return GreekOutput(
            priceDollarsPerMillion = price * 1_000_000,
            delta = delta,
            gamma = gamma,
            vega = vega * 1_000_000,
            theta = theta * 1_000_000,
            rho = rho * 1_000_000,
            vanna = vanna,
            volga = volga
        )
    }

    data class GreekOutput(
        val priceDollarsPerMillion: Double,
        val delta: Double,
        val gamma: Double,
        val vega: Double,
        val theta: Double,
        val rho: Double,
        val vanna: Double,
        val volga: Double
    )

    /**
     * Monte Carlo VaR & Expected Shortfall Simulation
     * Simulates 5,000 portfolio paths under multivariate correlated normal shocks
     */
    fun runMonteCarlo(
        portfolioNotionalMillion: Double,
        portfolioDv01: Double,
        nyiborVolBp: Double = 65.0,
        sofrVolBp: Double = 45.0,
        correlation: Double = 0.88,
        horizonDays: Int = 10,
        confidenceLevel: Double = 0.99
    ): MonteCarloResult {
        val nSims = 3000
        val dt = horizonDays / 252.0
        val stdDev = (nyiborVolBp * portfolioDv01) * sqrt(dt)

        // Generate synthetic P&L distribution
        val pnlOutcomes = DoubleArray(nSims)
        var pseudoSeed = 133742L
        for (i in 0 until nSims) {
            // Box-Muller transform for pseudo-random standard normal
            pseudoSeed = (pseudoSeed * 1664525L + 1013904223L) and 0xFFFFFFFFFFFFL
            val u1 = ((pseudoSeed ushr 16) and 0xFFFFFFL).toDouble() / 0x1000000.toDouble()
            pseudoSeed = (pseudoSeed * 1664525L + 1013904223L) and 0xFFFFFFFFFFFFL
            val u2 = ((pseudoSeed ushr 16) and 0xFFFFFFL).toDouble() / 0x1000000.toDouble()
            val z = sqrt(-2.0 * ln(u1.coerceIn(0.00001, 0.99999))) * cos(2.0 * Math.PI * u2)

            pnlOutcomes[i] = z * stdDev
        }

        pnlOutcomes.sort()
        val varIndex = ((1.0 - confidenceLevel) * nSims).toInt().coerceIn(0, nSims - 1)
        val varLoss = -pnlOutcomes[varIndex]
        val expectedShortfall = -pnlOutcomes.sliceArray(0..varIndex).average()
        val maxSimulatedLoss = -pnlOutcomes.first()
        val probabilityOfLoss = pnlOutcomes.count { it < 0 }.toDouble() / nSims * 100.0

        return MonteCarloResult(
            valueAtRiskDollar = varLoss.coerceAtLeast(0.0),
            expectedShortfallDollar = expectedShortfall.coerceAtLeast(0.0),
            maxSimulatedLossDollar = maxSimulatedLoss.coerceAtLeast(0.0),
            probabilityOfLossPct = probabilityOfLoss,
            sampleSize = nSims,
            horizonDays = horizonDays,
            confidence = confidenceLevel
        )
    }

    data class MonteCarloResult(
        val valueAtRiskDollar: Double,
        val expectedShortfallDollar: Double,
        val maxSimulatedLossDollar: Double,
        val probabilityOfLossPct: Double,
        val sampleSize: Int,
        val horizonDays: Int,
        val confidence: Double
    )
}
