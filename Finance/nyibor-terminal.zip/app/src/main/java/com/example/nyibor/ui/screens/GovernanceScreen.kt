package com.example.nyibor.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nyibor.data.NyiborMarketRepository
import com.example.ui.theme.*

@Composable
fun GovernanceScreen(
    modifier: Modifier = Modifier
) {
    var showConstitutionModal by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NyiborNavyDark)
            .padding(horizontal = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("governance_header_card")
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "NIBA BENCHMARK GOVERNANCE & CODE OF CONDUCT",
                            color = NyiborGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Surface(
                            color = NyiborGreen.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = "IOSCO PRINCIPLES COMPLIANT",
                                color = NyiborGreen,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "New York Interbank Benchmark Administration (FICTIONAL / SIMULATION)",
                        color = NyiborTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Administrative Committees
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorder),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "STATUTORY COMMITTEES & OVERSIGHT BODIES",
                        color = NyiborGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val committees = listOf(
                        "NIBA Oversight Committee" to "Independent supervision of calculation agent, review of complaints, scrutiny of panel banks.",
                        "NIBA Methodology Committee" to "Annual review of waterfall levels, fallback provisions, and transaction eligibility thresholds.",
                        "NIBA Data Operations Desk" to "Operational ingestion of submissions, Level 1 trade verification, cryptographic hash generation.",
                        "NIBA Market Surveillance" to "Continuous statistical monitoring, automated outlier detection, collusion prevention algorithms.",
                        "NIBA Benchmark Research" to "Quantitative modeling of credit-spread decompositions and macroeconomic regime shifts."
                    )

                    committees.forEach { (name, duties) ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .background(NyiborSurfaceElevated, RoundedCornerShape(2.dp))
                                .padding(6.dp)
                        ) {
                            Text(name, color = NyiborTextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(duties, color = NyiborTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // Contingency & Fallback Waterfall
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NyiborSurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, NyiborBorderHighlight),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "BENCHMARK CONTINGENCY & FALLBACK RULES",
                        color = NyiborGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "1. Minimum Submissions Threshold: Requires at least 8 eligible panel bank quotes.\n" +
                                "2. Severe Illiquidity Fallback: If < 8 banks submit, cascade to previous day fixing adjusted by EFFR overnight delta.\n" +
                                "3. Error Correction Policy: Republishing allowed up to 13:00 ET if error exceeds 0.50 bp.\n" +
                                "4. Conflict of Interest Rule: Submitting individuals strictly ring-fenced from proprietary interest-rate trading desks.",
                        color = NyiborTextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}
