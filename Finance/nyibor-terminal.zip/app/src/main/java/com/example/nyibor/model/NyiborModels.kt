package com.example.nyibor.model

enum class FixingState(val label: String, val windowEt: String) {
    OPEN("OPEN", "09:00 - 09:30 ET"),
    SUBMISSIONS("SUBMISSIONS", "09:30 - 10:45 ET"),
    VALIDATION("VALIDATION", "10:45 - 10:55 ET"),
    CALCULATION("CALCULATION", "10:55 - 11:00 ET"),
    QUALITY_CHECK("QUALITY_CHECK", "10:59 ET"),
    PUBLISHED("PUBLISHED", "11:00 ET (Official)"),
    REVIEW("REVIEW", "Post-Fixing Surveillance"),
    REPUBLISHED("REPUBLISHED", "Amended Fixing")
}

enum class MethodologyLevel(val code: String, val description: String) {
    LEVEL_1("L1", "Eligible wholesale unsecured transactions"),
    LEVEL_2("L2", "Firm executable wholesale funding quotes"),
    LEVEL_3("L3", "Transactions from closely related maturities"),
    LEVEL_4("L4", "Modelled / interpolated contribution (expert judgment)")
}

enum class QualityScore(val grade: String, val desc: String) {
    GRADE_A_PLUS("A+", "Superlative depth, high L1 transaction share"),
    GRADE_A("A", "Robust market depth, standard dispersion"),
    GRADE_B("B", "Satisfactory depth, moderate L2 quotes"),
    GRADE_C("C", "Elevated dispersion, heightened interpolation"),
    GRADE_D("D", "Marginal liquidity, heavy L4 reliance"),
    INSUFFICIENT("INSUFFICIENT", "Fallback triggered: insufficient submissions")
}

enum class Tenor(val code: String, val displayName: String, val days: Int, val isPrimary: Boolean) {
    ON("ON", "Overnight", 1, false),
    W1("1W", "NYIBOR 1W", 7, true),
    W2("2W", "NYIBOR 2W", 14, false),
    M1("1M", "NYIBOR 1M", 30, true),
    M2("2M", "NYIBOR 2M", 60, false),
    M3("3M", "NYIBOR 3M", 90, true),
    M6("6M", "NYIBOR 6M", 180, true),
    M9("9M", "NYIBOR 9M", 270, false),
    M12("12M", "NYIBOR 12M", 360, true),
    Y2("2Y", "NYIBOR 2Y", 720, false),
    Y3("3Y", "NYIBOR 3Y", 1080, false),
    Y5("5Y", "NYIBOR 5Y", 1800, false),
    Y7("7Y", "NYIBOR 7Y", 2520, false),
    Y10("10Y", "NYIBOR 10Y", 3600, false),
    Y20("20Y", "NYIBOR 20Y", 7200, false),
    Y30("30Y", "NYIBOR 30Y", 10800, false);

    companion object {
        val primaryTenors = listOf(W1, M1, M3, M6, M12)
        val curveTenors = values().toList()
    }
}

data class PanelBank(
    val bankId: String,
    val name: String,
    val location: String = "New York, NY",
    val creditTier: String, // "Tier 1 G-SIB", "Super-Regional", "Prime Wholesale"
    val fundingProfile: String,
    val liquidityProfile: String,
    val panelStatus: String = "ACTIVE",
    val submissionQuality: QualityScore = QualityScore.GRADE_A,
    val averageDeviationBp: Double = 0.8,
    val volatilityBp: Double = 1.4,
    val outlierScore: Double = 0.05
)

data class BankSubmission(
    val submissionId: String,
    val bankId: String,
    val bankName: String,
    val tenor: Tenor,
    val submittedRate: Double, // in percent e.g. 4.025
    val timestamp: String,
    val confidence: Double, // 0.0 to 1.0
    val level: MethodologyLevel,
    val transactionVolumeMillion: Double,
    val isOutlier: Boolean = false,
    val isTrimmed: Boolean = false
)

data class FixingDetail(
    val fixingId: String,
    val tenor: Tenor,
    val date: String,
    val rate: Double,
    val previousRate: Double,
    val changeBp: Double,
    val change1Wbp: Double,
    val change1Mbp: Double,
    val changeYtdBp: Double,
    val high52W: Double,
    val low52W: Double,
    val percentile52W: Double,
    val fixingState: FixingState,
    val methodologyLevel: MethodologyLevel,
    val qualityScore: QualityScore,
    val transactionVolumeMillion: Double,
    val transactionCount: Int,
    val contributorCount: Int,
    val dispersionBp: Double,
    val trimmedMean: Double,
    val median: Double,
    val volumeWeightedMean: Double,
    val auditHash: String,
    val methodologyVersion: String = "v3.2.1-NYIBOR-HYBRID"
)

data class CurvePoint(
    val tenor: Tenor,
    val rate: Double,
    val zeroRate: Double,
    val forwardRate: Double,
    val discountFactor: Double,
    val isBenchmark: Boolean,
    val slopeBp: Double,
    val curvatureBp: Double,
    val percentile: Double
)

data class RelativeValuePoint(
    val tenor: Tenor,
    val nyibor: Double,
    val sofr: Double,
    val effr: Double,
    val nyiborMinusSofrBp: Double,
    val nyiborMinusEffrBp: Double,
    val basisVolBp: Double,
    val zScore: Double,
    val rolling30dAvgBp: Double,
    val rolling30dVolBp: Double,
    // Modelled Decomposition of NYIBOR - SOFR (RhinoQuant Modelled)
    val creditComponentBp: Double,
    val liquidityComponentBp: Double,
    val termComponentBp: Double,
    val fundingBalanceSheetBp: Double,
    val marketStressBp: Double
)

data class FutureContract(
    val code: String, // e.g. "NYM4" (Jun 2026), "NYU4" (Sep 2026)
    val tenor: Tenor,
    val expiry: String,
    val price: Double, // 100 - implied rate
    val impliedRate: Double,
    val change: Double,
    val volume: Int,
    val openInterest: Int,
    val basisBp: Double,
    val impliedForward: Double
)

data class SwapQuote(
    val tenor: String, // 1Y, 2Y, 3Y, 5Y, 7Y, 10Y, 30Y
    val fixedRate: Double,
    val spreadVsSofrBp: Double,
    val dv01PerMillion: Double,
    val parNp: Double = 0.0,
    val paymentFreq: String = "Semi-Annual (30/360)",
    val resetFreq: String = "Quarterly (ACT/360)"
)

data class OptionQuote(
    val instrumentType: String, // Cap, Floor, Payer Swaption, Receiver Swaption
    val underlyingTenor: String,
    val strikeRate: Double,
    val expiry: String,
    val normalVolBps: Double,
    val lognormalVolPct: Double,
    val premiumBp: Double,
    val delta: Double,
    val gamma: Double,
    val vega: Double,
    val theta: Double,
    val dv01: Double
)

data class PortfolioPosition(
    val id: String,
    val desk: String,
    val book: String,
    val instrument: String,
    val strategy: String,
    val underlying: String,
    val notionalMillion: Double,
    val marketValue: Double,
    val pnlDollar: Double,
    val dv01: Double,
    val delta: Double,
    val gamma: Double,
    val vega: Double,
    val marginReqMillion: Double
)

data class MarketRegime(
    val name: String,
    val period: String,
    val description: String,
    val nyibor3mAvg: Double,
    val sofrAvg: Double,
    val avgBasisBp: Double,
    val characteristics: String
)
