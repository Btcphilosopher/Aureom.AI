package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NYIBOR Institutional Terminal Palette
// Deep navy, graphite, steel, off-white, muted blue, restrained red, amber, gold
val NyiborNavyDark = Color(0xFF090E17)       // Deepest background
val NyiborSurfaceDark = Color(0xFF0F1724)    // Panel background
val NyiborSurfaceElevated = Color(0xFF162032)// Card / Table header
val NyiborBorder = Color(0xFF223049)         // Subtle grid lines & borders
val NyiborBorderHighlight = Color(0xFF384B6E)// Focus / active border

val NyiborTextPrimary = Color(0xFFF1F5F9)   // Bright off-white
val NyiborTextSecondary = Color(0xFF94A3B8) // Steel gray
val NyiborTextMuted = Color(0xFF64748B)     // Subdued caption

val NyiborGold = Color(0xFFF59E0B)          // Institutional Gold / Benchmark Accent
val NyiborBlue = Color(0xFF38BDF8)          // Rates blue (active tenors)
val NyiborGreen = Color(0xFF10B981)         // Up / Positive / Compliant
val NyiborRed = Color(0xFFEF4444)           // Down / Warning / Spread widen
val NyiborAmber = Color(0xFFF97316)         // Caution / Attention
val NyiborPurple = Color(0xFFA78BFA)        // Modelled / Derivation tag

// Light Mode equivalents for institutional daytime mode
val NyiborNavyLight = Color(0xFFF8FAFC)
val NyiborSurfaceLight = Color(0xFFFFFFFF)
val NyiborSurfaceElevatedLight = Color(0xFFF1F5F9)
val NyiborBorderLight = Color(0xFFCBD5E1)
val NyiborTextPrimaryLight = Color(0xFF0F172A)
val NyiborTextSecondaryLight = Color(0xFF475569)
