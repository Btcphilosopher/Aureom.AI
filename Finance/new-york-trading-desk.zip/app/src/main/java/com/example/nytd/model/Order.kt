package com.example.nytd.model

enum class OrderSide {
  BUY,
  SELL
}

enum class OrderType(val displayName: String) {
  MARKET("Market"),
  LIMIT("Limit"),
  STOP("Stop"),
  STOP_LIMIT("Stop Limit"),
  ICEBERG("Iceberg"),
  TWAP("TWAP Algo"),
  VWAP("VWAP Algo"),
  RFQ("RFQ"),
  MULTI_LEG("Multi-Leg Spread")
}

enum class TimeInForce {
  DAY,
  GTC,
  IOC,
  FOK
}

/**
 * Formal Order State Machine:
 * CREATED -> VALIDATED -> RISK_CHECKED -> ROUTING -> ACKNOWLEDGED -> PARTIALLY_FILLED -> FILLED
 * Terminal/Failure States: REJECTED, CANCELLED, EXPIRED, SUSPENDED
 */
enum class OrderStatus(val isTerminal: Boolean, val badgeColorHex: Long) {
  CREATED(false, 0xFF94A3B8),
  VALIDATED(false, 0xFF38BDF8),
  RISK_CHECKED(false, 0xFF818CF8),
  ROUTING(false, 0xFFFBBF24),
  ACKNOWLEDGED(false, 0xFF60A5FA),
  PARTIALLY_FILLED(false, 0xFFF59E0B),
  FILLED(true, 0xFF10B981),
  CANCEL_PENDING(false, 0xFFFB923C),
  CANCELLED(true, 0xFF64748B),
  REJECTED(true, 0xFFF43F5E),
  EXPIRED(true, 0xFF94A3B8),
  SUSPENDED(false, 0xFFEC4899)
}

data class OrderEntity(
  val id: String,
  val clientOrderId: String,
  val symbol: String,
  val assetClass: AssetClass,
  val side: OrderSide,
  val type: OrderType,
  val timeInForce: TimeInForce,
  val quantity: Double,
  val filledQuantity: Double = 0.0,
  val avgFillPrice: Double = 0.0,
  val price: Double? = null,
  val stopPrice: Double? = null,
  val icebergVisibleQty: Double? = null,
  val targetVenue: String = "SMART",
  val routedVenue: String = "",
  val status: OrderStatus = OrderStatus.CREATED,
  val statusMessage: String = "Order created",
  val estimatedNotional: Double = 0.0,
  val estimatedFees: Double = 0.0,
  val timestamp: Long = System.currentTimeMillis(),
  val updatedTimestamp: Long = System.currentTimeMillis(),
  val isPaper: Boolean = true,
  val stateTransitions: List<StateTransitionRecord> = emptyList()
) {
  val remainingQuantity: Double get() = (quantity - filledQuantity).coerceAtLeast(0.0)
  val fillPercentage: Double get() = if (quantity > 0) (filledQuantity / quantity) * 100.0 else 0.0
}

data class StateTransitionRecord(
  val fromStatus: OrderStatus?,
  val toStatus: OrderStatus,
  val timestamp: Long,
  val reason: String
)

data class ExecutionReport(
  val executionId: String,
  val orderId: String,
  val symbol: String,
  val side: OrderSide,
  val execPrice: Double,
  val execQty: Double,
  val venue: String,
  val fee: Double,
  val timestamp: Long,
  val liquidityIndicator: String = "TAKER" // "MAKER" or "TAKER"
)
