package com.example.nytd.engine

import com.example.nytd.model.AssetClass
import com.example.nytd.model.ConnectorInfo
import com.example.nytd.model.ConnectorLogEntry
import com.example.nytd.model.ConnectorState
import com.example.nytd.model.ConnectorType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConnectorFabric {

  private val _connectors = MutableStateFlow<List<ConnectorInfo>>(emptyList())
  val connectors: StateFlow<List<ConnectorInfo>> = _connectors.asStateFlow()

  private val _logs = MutableStateFlow<List<ConnectorLogEntry>>(emptyList())
  val logs: StateFlow<List<ConnectorLogEntry>> = _logs.asStateFlow()

  init {
    initializeConnectors()
  }

  private fun initializeConnectors() {
    val initial = listOf(
      ConnectorInfo(
        id = "CONN-MD-01",
        name = "Global Market Data Feed",
        type = ConnectorType.MARKET_DATA,
        providerOrVenue = "Bloomberg B-PIPE & Refinitiv Elekron",
        state = ConnectorState.ONLINE,
        latencyMs = 4,
        rateLimitPct = 28,
        supportedAssets = AssetClass.entries,
        isSimulated = true
      ),
      ConnectorInfo(
        id = "CONN-EXEC-01",
        name = "Smart Execution Gateway",
        type = ConnectorType.EXECUTION,
        providerOrVenue = "NYSE / NASDAQ / CME / Currenex FIX 4.4",
        state = ConnectorState.ONLINE,
        latencyMs = 8,
        rateLimitPct = 34,
        supportedAssets = AssetClass.entries,
        isSimulated = true
      ),
      ConnectorInfo(
        id = "CONN-PORT-01",
        name = "Portfolio Accounting Core",
        type = ConnectorType.PORTFOLIO,
        providerOrVenue = "SimCorp Dimension & Geneva Adapter",
        state = ConnectorState.ONLINE,
        latencyMs = 15,
        rateLimitPct = 12,
        supportedAssets = AssetClass.entries,
        isSimulated = true
      ),
      ConnectorInfo(
        id = "CONN-RISK-01",
        name = "Enterprise Risk Engine",
        type = ConnectorType.RISK,
        providerOrVenue = "MSCI Barra / Axioma Risk SDK",
        state = ConnectorState.ONLINE,
        latencyMs = 6,
        rateLimitPct = 18,
        supportedAssets = AssetClass.entries,
        isSimulated = true
      ),
      ConnectorInfo(
        id = "CONN-PRICE-01",
        name = "Derivatives Pricing Grid",
        type = ConnectorType.PRICING,
        providerOrVenue = "Numerix / QuantLib Analytics Grid",
        state = ConnectorState.ONLINE,
        latencyMs = 12,
        rateLimitPct = 22,
        supportedAssets = listOf(AssetClass.DERIVATIVES, AssetClass.RATES, AssetClass.FX),
        isSimulated = true
      ),
      ConnectorInfo(
        id = "CONN-SETTLE-01",
        name = "Clearing & Settlement Fabric",
        type = ConnectorType.SETTLEMENT,
        providerOrVenue = "DTCC / Euroclear / Omgeo CTM",
        state = ConnectorState.ONLINE,
        latencyMs = 28,
        rateLimitPct = 8,
        supportedAssets = listOf(AssetClass.EQUITIES, AssetClass.RATES, AssetClass.CREDIT),
        isSimulated = true
      ),
      ConnectorInfo(
        id = "CONN-RES-01",
        name = "R & Python Research Gateway",
        type = ConnectorType.RESEARCH,
        providerOrVenue = "Posit RStudio / Jupyter Quantitative Kernel",
        state = ConnectorState.ONLINE,
        latencyMs = 18,
        rateLimitPct = 15,
        supportedAssets = AssetClass.entries,
        isSimulated = true
      ),
      ConnectorInfo(
        id = "CONN-CUST-01",
        name = "Digital Asset Custody Core",
        type = ConnectorType.CUSTODY,
        providerOrVenue = "Fireblocks / Copper MPC Vault",
        state = ConnectorState.ONLINE,
        latencyMs = 35,
        rateLimitPct = 5,
        supportedAssets = listOf(AssetClass.DIGITAL_ASSETS),
        isSimulated = true
      ),
      ConnectorInfo(
        id = "CONN-TREAS-01",
        name = "Treasury & Collateral Ops",
        type = ConnectorType.TREASURY,
        providerOrVenue = "SWIFT Alliance Lite2 / Fedwire ISO20022",
        state = ConnectorState.ONLINE,
        latencyMs = 22,
        rateLimitPct = 9,
        supportedAssets = listOf(AssetClass.RATES, AssetClass.FX),
        isSimulated = true
      )
    )
    _connectors.value = initial
  }

  fun toggleConnector(id: String) {
    val updated = _connectors.value.map { conn ->
      if (conn.id == id) {
        val newState = if (conn.state == ConnectorState.ONLINE) ConnectorState.DISCONNECTED else ConnectorState.ONLINE
        log(conn.id, "INFO", "Operator changed state to $newState")
        conn.copy(state = newState)
      } else conn
    }
    _connectors.value = updated
  }

  fun testConnection(id: String) {
    val updated = _connectors.value.map { conn ->
      if (conn.id == id) {
        log(conn.id, "INFO", "Diagnostic ping OK (latency: ${conn.latencyMs}ms, protocol: FIX 4.4 / REST TLS 1.3)")
        conn.copy(lastHeartbeatMs = System.currentTimeMillis())
      } else conn
    }
    _connectors.value = updated
  }

  private fun log(connectorId: String, severity: String, message: String) {
    val entry = ConnectorLogEntry(
      timestamp = System.currentTimeMillis(),
      connectorId = connectorId,
      severity = severity,
      message = message
    )
    _logs.value = listOf(entry) + _logs.value.take(99)
  }
}
