package com.example.nytd.model

enum class ConnectorType(val label: String) {
  MARKET_DATA("Market Data Feed"),
  EXECUTION("Execution & Routing"),
  PORTFOLIO("Portfolio Accounting"),
  RISK("Risk & Margining"),
  PRICING("Derivatives Pricing Engine"),
  SETTLEMENT("Clearing & Settlement"),
  RESEARCH("Quant Research & R Studio"),
  CUSTODY("Digital Asset Custody"),
  TREASURY("Treasury & Cash Ops")
}

enum class ConnectorState {
  ONLINE,
  DEGRADED,
  RECONNECTING,
  DISCONNECTED,
  STANDBY
}

data class ConnectorInfo(
  val id: String,
  val name: String,
  val type: ConnectorType,
  val providerOrVenue: String,
  val state: ConnectorState,
  val latencyMs: Int,
  val rateLimitPct: Int,
  val supportedAssets: List<AssetClass>,
  val isSimulated: Boolean,
  val errorCount: Int = 0,
  val lastHeartbeatMs: Long = System.currentTimeMillis()
)

data class ConnectorLogEntry(
  val timestamp: Long,
  val connectorId: String,
  val severity: String, // "INFO", "WARN", "ERROR", "TRACE"
  val message: String
)
