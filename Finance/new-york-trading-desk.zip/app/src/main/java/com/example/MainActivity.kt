package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.nytd.ui.screens.TerminalScreen
import com.example.nytd.ui.viewmodel.TradingDeskViewModel
import com.example.nytd.util.configureAppCheck
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  private val viewModel: TradingDeskViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    // Phase 1: App Check Foundation with launch intent
    configureAppCheck(this, intent)

    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        TerminalScreen(viewModel = viewModel)
      }
    }
  }
}
