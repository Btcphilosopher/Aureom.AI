package com.example.nytd.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.nytd.engine.FinancialMath
import com.example.nytd.model.ExecutionReport
import com.example.nytd.model.OrderEntity
import com.example.nytd.model.OrderSide
import com.example.nytd.model.OrderStatus
import com.example.ui.theme.DeskBlack
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskCardElevated
import com.example.ui.theme.DeskMidnight
import com.example.ui.theme.MarketGreen
import com.example.ui.theme.MarketRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OrderBlotter(
  orders: List<OrderEntity>,
  executions: List<ExecutionReport>,
  onCancelOrder: (String) -> Unit,
  onCancelAllOrders: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showExecutionsTab by remember { mutableStateOf(false) }
  var inspectedOrder by remember { mutableStateOf<OrderEntity?>(null) }
  val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
  ) {
    // Header & Tab toggles
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(if (!showExecutionsTab) WallStreetGold else DeskCard)
            .clickable { showExecutionsTab = false }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("tab_order_blotter")
        ) {
          Text(
            text = "ORDERS (${orders.size})",
            color = if (!showExecutionsTab) Color.Black else TextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(if (showExecutionsTab) WallStreetGold else DeskCard)
            .clickable { showExecutionsTab = true }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("tab_execution_blotter")
        ) {
          Text(
            text = "FILLS (${executions.size})",
            color = if (showExecutionsTab) Color.Black else TextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }
      }

      // Mass cancel action
      if (orders.any { !it.status.isTerminal }) {
        Button(
          onClick = onCancelAllOrders,
          colors = ButtonDefaults.buttonColors(containerColor = MarketRed.copy(alpha = 0.2f), contentColor = MarketRed),
          shape = RoundedCornerShape(3.dp),
          contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
          modifier = Modifier.testTag("cancel_all_button")
        ) {
          Text("CANCEL ALL", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
      }
    }

    // List view
    if (!showExecutionsTab) {
      if (orders.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(100.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("No active orders in OMS memory", color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          items(orders) { order ->
            val isBuy = order.side == OrderSide.BUY
            val statusColor = Color(order.status.badgeColorHex)

            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(3.dp))
                .background(DeskCard)
                .border(1.dp, DeskBorder, RoundedCornerShape(3.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .clickable { inspectedOrder = order }
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                // Left: ID, Side, Symbol, Qty
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = order.side.name,
                      color = if (isBuy) MarketGreen else MarketRed,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Black,
                      fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = order.symbol,
                      color = TextPrimary,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "${order.filledQuantity.toInt()}/${order.quantity.toInt()} (${order.type.name})",
                      color = TextSecondary,
                      fontSize = 10.sp,
                      fontFamily = FontFamily.Monospace
                    )
                  }
                  Text(
                    text = "${order.id} • ${timeFormat.format(Date(order.timestamp))} • Route: ${order.routedVenue.ifBlank { order.targetVenue }}",
                    color = TextDim,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }

                // Right: Status badge & Cancel button
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(2.dp))
                      .background(statusColor.copy(alpha = 0.2f))
                      .border(1.dp, statusColor, RoundedCornerShape(2.dp))
                      .padding(horizontal = 5.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = order.status.name,
                      color = statusColor,
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      fontFamily = FontFamily.Monospace
                    )
                  }

                  if (!order.status.isTerminal) {
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                      onClick = { onCancelOrder(order.id) },
                      modifier = Modifier
                        .size(24.dp)
                        .testTag("cancel_order_${order.id}")
                    ) {
                      Icon(Icons.Default.Cancel, contentDescription = "Cancel", tint = MarketRed, modifier = Modifier.size(16.dp))
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      // Execution Fills Table
      if (executions.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(100.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("No execution fills recorded yet", color = TextDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
      } else {
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .height(180.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          items(executions) { exec ->
            val isBuy = exec.side == OrderSide.BUY
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(3.dp))
                .background(DeskCard)
                .border(1.dp, DeskBorder, RoundedCornerShape(3.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = exec.side.name,
                      color = if (isBuy) MarketGreen else MarketRed,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = exec.symbol,
                      color = TextPrimary,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.Bold,
                      fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "${exec.execQty.toInt()} units @ $${exec.execPrice}",
                      color = TextSecondary,
                      fontSize = 10.sp,
                      fontFamily = FontFamily.Monospace
                    )
                  }
                  Text(
                    text = "${exec.executionId} • Venue: ${exec.venue} • Fee: $${exec.fee}",
                    color = TextDim,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }
                Text(
                  text = timeFormat.format(Date(exec.timestamp)),
                  color = TextSecondary,
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }
      }
    }

    // Order Lifecycle State Transition Inspector Dialog
    if (inspectedOrder != null) {
      val ord = inspectedOrder!!
      Dialog(onDismissRequest = { inspectedOrder = null }) {
        Card(
          colors = CardDefaults.cardColors(containerColor = DeskMidnight),
          border = androidx.compose.foundation.BorderStroke(1.dp, DeskBorder),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(
              text = "OMS STATE MACHINE AUDIT",
              color = WallStreetGold,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = "Order: ${ord.id} • ${ord.symbol} • ${ord.side.name} ${ord.quantity.toInt()} units",
              color = TextPrimary,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))

            Text("State Transitions:", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(vertical = 4.dp)) {
              ord.stateTransitions.forEach { tr ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "→ ${tr.toStatus.name}: ",
                    color = Color(tr.toStatus.badgeColorHex),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                  )
                  Text(
                    text = tr.reason,
                    color = TextSecondary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Button(
              onClick = { inspectedOrder = null },
              colors = ButtonDefaults.buttonColors(containerColor = WallStreetGold, contentColor = Color.Black),
              shape = RoundedCornerShape(3.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text("CLOSE AUDIT", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
          }
        }
      }
    }
  }
}
