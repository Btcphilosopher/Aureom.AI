package com.example.nytd.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "orders")
data class OrderRecord(
  @PrimaryKey val id: String,
  val clientOrderId: String,
  val symbol: String,
  val assetClass: String,
  val side: String,
  val type: String,
  val timeInForce: String,
  val quantity: Double,
  val filledQuantity: Double,
  val avgFillPrice: Double,
  val price: Double?,
  val stopPrice: Double?,
  val targetVenue: String,
  val routedVenue: String,
  val status: String,
  val statusMessage: String,
  val estimatedNotional: Double,
  val estimatedFees: Double,
  val timestamp: Long,
  val updatedTimestamp: Long,
  val isPaper: Boolean
)

@Dao
interface OrderDao {
  @Query("SELECT * FROM orders ORDER BY timestamp DESC")
  fun getAllOrdersFlow(): Flow<List<OrderRecord>>

  @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
  suspend fun getOrderById(orderId: String): OrderRecord?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertOrder(order: OrderRecord)

  @Update
  suspend fun updateOrder(order: OrderRecord)

  @Query("UPDATE orders SET status = 'CANCELLED', statusMessage = 'Cancelled by desk' WHERE status NOT IN ('FILLED', 'REJECTED', 'CANCELLED', 'EXPIRED')")
  suspend fun cancelAllActiveOrders()
}

@Entity(tableName = "positions")
data class PositionRecord(
  @PrimaryKey val symbol: String,
  val assetClass: String,
  val quantity: Double,
  val avgEntryPrice: Double,
  val currentPrice: Double,
  val realizedPnL: Double,
  val currency: String,
  val openTimestamp: Long
)

@Dao
interface PositionDao {
  @Query("SELECT * FROM positions WHERE quantity != 0.0")
  fun getAllPositionsFlow(): Flow<List<PositionRecord>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertPosition(position: PositionRecord)

  @Query("DELETE FROM positions WHERE symbol = :symbol")
  suspend fun deletePosition(symbol: String)

  @Query("DELETE FROM positions")
  suspend fun clearAllPositions()
}

@Entity(tableName = "audit_logs")
data class AuditLogRecord(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestamp: Long,
  val eventType: String,
  val entityId: String,
  val actor: String,
  val details: String,
  val severity: String
)

@Dao
interface AuditDao {
  @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 200")
  fun getRecentLogsFlow(): Flow<List<AuditLogRecord>>

  @Insert
  suspend fun insertLog(log: AuditLogRecord)
}
