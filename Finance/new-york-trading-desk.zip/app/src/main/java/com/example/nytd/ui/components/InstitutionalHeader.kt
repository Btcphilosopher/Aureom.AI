package com.example.nytd.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nytd.engine.FinancialMath
import com.example.nytd.model.MarketRegime
import com.example.nytd.model.PortfolioSummary
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskMidnight
import com.example.ui.theme.MarketGreen
import com.example.ui.theme.MarketRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

@Composable
fun InstitutionalHeader(
  portfolio: PortfolioSummary,
  currentRegime: MarketRegime,
  isKillSwitchActive: Boolean,
  onRegimeChange: (MarketRegime) -> Unit,
  onKillSwitchToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  var regimeMenuExpanded by remember { mutableStateOf(false) }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .border(width = 1.dp, color = DeskBorder, shape = androidx.compose.ui.graphics.RectangleShape)
      .padding(horizontal = 12.dp, vertical = 8.dp)
  ) {
    // Top Row: Brand & Live Account Metric Ticker
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(10.dp)
            .clip(RoundedCornerShape(5.dp))
            .background(if (isKillSwitchActive) MarketRed else MarketGreen)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "NEW YORK TRADING DESK",
          color = WallStreetGold,
          fontSize = 13.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp,
          fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "v3.7 INST-OS",
          color = TextDim,
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace
        )
      }

      // Emergency Kill Switch
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isKillSwitchActive) MarketRed else DeskCard)
            .border(
              width = 1.dp,
              color = if (isKillSwitchActive) Color.White else MarketRed.copy(alpha = 0.6f),
              shape = RoundedCornerShape(4.dp)
            )
            .clickable { onKillSwitchToggle() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("kill_switch_button")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = if (isKillSwitchActive) Icons.Default.Warning else Icons.Default.ElectricBolt,
              contentDescription = "Emergency Kill Switch",
              tint = if (isKillSwitchActive) Color.White else MarketRed,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (isKillSwitchActive) "HALTED" else "KILL SWITCH",
              color = if (isKillSwitchActive) Color.White else MarketRed,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    // Secondary Row: Live NAV, Daily P&L, Regime Picker
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // NAV and PnL
      val totalDailyPnl = portfolio.dailyRealizedPnLUsd + portfolio.dailyUnrealizedPnLUsd
      val pnlColor = if (totalDailyPnl >= 0) MarketGreen else MarketRed

      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "NAV ",
          color = TextSecondary,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          text = "$${FinancialMath.roundMoney(portfolio.navUsd)}",
          color = TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "P&L ",
          color = TextSecondary,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          text = "${if (totalDailyPnl >= 0) "+" else ""}$${FinancialMath.roundMoney(totalDailyPnl)}",
          color = pnlColor,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
      }

      // Regime selector button
      Box {
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(DeskCard)
            .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
            .clickable { regimeMenuExpanded = true }
            .padding(horizontal = 6.dp, vertical = 3.dp)
            .testTag("regime_selector"),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "REGIME: ",
            color = TextDim,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            text = currentRegime.label.take(16),
            color = WallStreetGold,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.Monospace
          )
        }

        DropdownMenu(
          expanded = regimeMenuExpanded,
          onDismissRequest = { regimeMenuExpanded = false },
          modifier = Modifier.background(DeskMidnight)
        ) {
          MarketRegime.entries.forEach { regime ->
            DropdownMenuItem(
              text = {
                Text(
                  text = regime.label,
                  color = if (regime == currentRegime) WallStreetGold else TextPrimary,
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace
                )
              },
              onClick = {
                onRegimeChange(regime)
                regimeMenuExpanded = false
              }
            )
          }
        }
      }
    }
  }
}
