package com.example.nytd.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.nytd.engine.FinancialMath
import com.example.nytd.engine.InstrumentCatalog
import com.example.nytd.model.AssetClass
import com.example.nytd.model.Quote
import com.example.nytd.model.TradingInstrument
import com.example.ui.theme.DeskBlack
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskCardElevated
import com.example.ui.theme.DeskMidnight
import com.example.ui.theme.MarketGreen
import com.example.ui.theme.MarketRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

@Composable
fun InstrumentSelectorDialog(
  currentSelected: TradingInstrument,
  quotes: Map<String, Quote>,
  onSelect: (TradingInstrument) -> Unit,
  onDismiss: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedAssetFilter by remember { mutableStateOf<AssetClass?>(null) }

  val filteredInstruments = remember(searchQuery, selectedAssetFilter) {
    val base = if (selectedAssetFilter == null) InstrumentCatalog.ALL_INSTRUMENTS else InstrumentCatalog.filterByAssetClass(selectedAssetFilter)
    if (searchQuery.isBlank()) base else {
      val q = searchQuery.trim().lowercase()
      base.filter {
        it.symbol.lowercase().contains(q) ||
            it.name.lowercase().contains(q) ||
            it.canonicalSymbol.lowercase().contains(q)
      }
    }
  }

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(max = 560.dp)
        .testTag("instrument_selector_card"),
      colors = CardDefaults.cardColors(containerColor = DeskMidnight),
      border = androidx.compose.foundation.BorderStroke(1.dp, DeskBorder),
      shape = RoundedCornerShape(6.dp)
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        // Dialog Title
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "GLOBAL INSTRUMENT MASTER",
              color = WallStreetGold,
              fontSize = 12.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = "Authoritative Multi-Asset Catalog",
              color = TextSecondary,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextDim)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Search text input
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("Search by symbol, name, or venue...", fontSize = 11.sp, color = TextDim, fontFamily = FontFamily.Monospace) },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextDim, modifier = Modifier.size(16.dp)) },
          colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedBorderColor = WallStreetGold,
            unfocusedBorderColor = DeskBorder,
            focusedContainerColor = DeskBlack,
            unfocusedContainerColor = DeskBlack
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("instrument_search_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Asset Class Filter Chips
        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(4.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          item {
            val isAll = selectedAssetFilter == null
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(if (isAll) WallStreetGold else DeskCard)
                .clickable { selectedAssetFilter = null }
                .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
              Text(
                text = "ALL",
                color = if (isAll) Color.Black else TextSecondary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
          items(AssetClass.entries.toTypedArray()) { ac ->
            val isSel = ac == selectedAssetFilter
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(if (isSel) WallStreetGold else DeskCard)
                .clickable { selectedAssetFilter = ac }
                .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
              Text(
                text = ac.badgeCode,
                color = if (isSel) Color.Black else TextSecondary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Instrument List
        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          items(filteredInstruments) { inst ->
            val q = quotes[inst.symbol]
            val last = q?.lastPrice ?: 100.0
            val chg = q?.changePct ?: 0.0
            val isSelected = inst.id == currentSelected.id

            Box(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(if (isSelected) DeskCardElevated else DeskCard)
                .border(1.dp, if (isSelected) WallStreetGold else DeskBorder, RoundedCornerShape(4.dp))
                .clickable {
                  onSelect(inst)
                  onDismiss()
                }
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .testTag("instrument_item_${inst.symbol}")
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = inst.symbol,
                      color = if (isSelected) WallStreetGold else TextPrimary,
                      fontSize = 13.sp,
                      fontWeight = FontWeight.Bold,
                      fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = inst.primaryVenue,
                      color = TextDim,
                      fontSize = 10.sp,
                      fontFamily = FontFamily.Monospace
                    )
                  }
                  Text(
                    text = inst.name,
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }

                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = "$${last}",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                  )
                  Text(
                    text = "${if (chg >= 0) "+" else ""}${FinancialMath.roundMoney(chg, 2)}%",
                    color = if (chg >= 0) MarketGreen else MarketRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
