package com.example.nytd.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nytd.ui.viewmodel.DeskWorkspace
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskMidnight
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

@Composable
fun WorkspaceTabs(
  currentWorkspace: DeskWorkspace,
  onSelectWorkspace: (DeskWorkspace) -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .horizontalScroll(rememberScrollState())
      .padding(horizontal = 8.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    DeskWorkspace.entries.forEach { ws ->
      val isSelected = ws == currentWorkspace
      val bgColor = if (isSelected) WallStreetGold else DeskCard
      val textColor = if (isSelected) Color.Black else TextSecondary
      val borderColor = if (isSelected) WallStreetGold else DeskBorder

      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(4.dp))
          .background(bgColor)
          .border(1.dp, borderColor, RoundedCornerShape(4.dp))
          .clickable { onSelectWorkspace(ws) }
          .padding(horizontal = 8.dp, vertical = 5.dp)
          .testTag("tab_${ws.name.lowercase()}")
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = ws.badge,
            color = if (isSelected) Color.Black else WallStreetGold,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(end = 4.dp)
          )
          Text(
            text = ws.displayName,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}
