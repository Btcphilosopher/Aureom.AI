package com.example.nytd.model

data class Position(
  val symbol: String,
  val assetClass: AssetClass,
  val quantity: Double,
  val avgEntryPrice: Double,
  val currentPrice: Double,
  val realizedPnL: Double = 0.0,
  val currency: String = "USD",
  val openTimestamp: Long = System.currentTimeMillis()
) {
  val isLong: Boolean get() = quantity > 0
  val isShort: Boolean get() = quantity < 0
  val marketValue: Double get() = quantity * currentPrice
  val notionalValue: Double get() = kotlin.math.abs(marketValue)
  val unrealizedPnL: Double get() = quantity * (currentPrice - avgEntryPrice)
  val unrealizedPnLPct: Double get() = if (avgEntryPrice > 0) ((currentPrice - avgEntryPrice) / avgEntryPrice) * (if (quantity >= 0) 100.0 else -100.0) else 0.0
}

data class PortfolioSummary(
  val accountId: String = "NYTD-PRIME-001",
  val cashUsd: Double = 10_000_000.0,
  val buyingPowerUsd: Double = 40_000_000.0,
  val grossExposureUsd: Double = 0.0,
  val netExposureUsd: Double = 0.0,
  val marginUsedUsd: Double = 0.0,
  val dailyRealizedPnLUsd: Double = 0.0,
  val dailyUnrealizedPnLUsd: Double = 0.0,
  val navUsd: Double = 10_000_000.0,
  val leverageRatio: Double = 0.0,
  val timestamp: Long = System.currentTimeMillis()
)

data class RiskLimits(
  val maxOrderNotionalUsd: Double = 5_000_000.0,
  val maxPositionNotionalUsd: Double = 15_000_000.0,
  val maxGrossLeverage: Double = 4.0,
  val dailyLossLimitUsd: Double = 500_000.0,
  val maxSingleAssetConcentrationPct: Double = 35.0,
  val isKillSwitchActive: Boolean = false,
  val readOnlyMode: Boolean = false
)

data class RiskCheckResult(
  val isApproved: Boolean,
  val breachedLimits: List<String>,
  val warningNotes: List<String>,
  val estimatedImpactNotional: Double
)
