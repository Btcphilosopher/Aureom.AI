package com.example.nytd.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [OrderRecord::class, PositionRecord::class, AuditLogRecord::class],
  version = 1,
  exportSchema = false
)
abstract class NytdDatabase : RoomDatabase() {
  abstract fun orderDao(): OrderDao
  abstract fun positionDao(): PositionDao
  abstract fun auditDao(): AuditDao

  companion object {
    @Volatile
    private var INSTANCE: NytdDatabase? = null

    fun getDatabase(context: Context): NytdDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          NytdDatabase::class.java,
          "nytd_trading_desk.db"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
