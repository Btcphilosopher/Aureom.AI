package com.example.nytd.model

enum class StrategyCategory {
  MEAN_REVERSION,
  MOMENTUM_TREND,
  STAT_ARB,
  VOLATILITY_ARBITRAGE,
  RATES_CURVE_CARRY,
  FX_TRIANGULAR
}

data class StrategyDefinition(
  val id: String,
  val name: String,
  val category: StrategyCategory,
  val targetAssetClass: AssetClass,
  val description: String,
  val targetSymbols: List<String>,
  val lookbackPeriodDays: Int = 30,
  val entryThresholdZScore: Double = 2.0,
  val stopLossPct: Double = 1.5,
  val takeProfitPct: Double = 3.0,
  val isActive: Boolean = false
)

data class BacktestMetrics(
  val strategyId: String,
  val period: String,
  val cagrPct: Double,
  val sharpeRatio: Double,
  val sortinoRatio: Double,
  val maxDrawdownPct: Double,
  val winRatePct: Double,
  val totalTrades: Int,
  val profitFactor: Double,
  val equityCurve: List<Double>
)

data class StrategyTradeProposal(
  val id: String,
  val strategyName: String,
  val symbol: String,
  val side: OrderSide,
  val orderType: OrderType,
  val suggestedQuantity: Double,
  val limitPrice: Double,
  val stopLoss: Double,
  val takeProfit: Double,
  val confidenceScore: Double,
  val quantitativeRationale: String,
  val timestamp: Long = System.currentTimeMillis()
)
