package com.example.nytd.engine

import com.example.nytd.model.AssetClass
import com.example.nytd.model.ExecutionReport
import com.example.nytd.model.OrderSide
import com.example.nytd.model.PortfolioSummary
import com.example.nytd.model.Position
import com.example.nytd.model.Quote
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

class PortfolioEngine {

  private val _positions = MutableStateFlow<Map<String, Position>>(emptyMap())
  val positions: StateFlow<Map<String, Position>> = _positions.asStateFlow()

  private val _summary = MutableStateFlow(PortfolioSummary())
  val summary: StateFlow<PortfolioSummary> = _summary.asStateFlow()

  private val internalPositions = ConcurrentHashMap<String, Position>()
  private var cashBalance: Double = 10_000_000.0
  private var cumulativeRealizedPnL: Double = 0.0

  init {
    recalculateSummary(emptyMap())
  }

  fun updateMarketPrices(quotes: Map<String, Quote>) {
    var hasChanges = false
    internalPositions.forEach { (sym, pos) ->
      val q = quotes[sym]
      if (q != null && q.lastPrice > 0 && q.lastPrice != pos.currentPrice) {
        internalPositions[sym] = pos.copy(currentPrice = q.lastPrice)
        hasChanges = true
      }
    }
    if (hasChanges) {
      _positions.value = HashMap(internalPositions)
      recalculateSummary(quotes)
    }
  }

  @Synchronized
  fun applyExecution(report: ExecutionReport, assetClass: AssetClass, multiplier: Double = 1.0) {
    val existing = internalPositions[report.symbol]
    val signedExecQty = if (report.side == OrderSide.BUY) report.execQty else -report.execQty
    val tradeNotional = report.execQty * report.execPrice * multiplier

    // Cash movement: BUY pays cash + fee; SELL receives cash - fee
    val cashDelta = if (report.side == OrderSide.BUY) -(tradeNotional + report.fee) else (tradeNotional - report.fee)
    cashBalance += cashDelta

    var realizedPnLDelta = 0.0

    if (existing == null || existing.quantity == 0.0) {
      // New position opened
      internalPositions[report.symbol] = Position(
        symbol = report.symbol,
        assetClass = assetClass,
        quantity = signedExecQty,
        avgEntryPrice = report.execPrice,
        currentPrice = report.execPrice,
        realizedPnL = 0.0
      )
    } else {
      val oldQty = existing.quantity
      val newQty = oldQty + signedExecQty

      if ((oldQty > 0 && signedExecQty > 0) || (oldQty < 0 && signedExecQty < 0)) {
        // Adding to existing position: weighted average entry price
        val totalCost = (abs(oldQty) * existing.avgEntryPrice) + (abs(signedExecQty) * report.execPrice)
        val newAvgPrice = totalCost / abs(newQty)
        internalPositions[report.symbol] = existing.copy(
          quantity = newQty,
          avgEntryPrice = newAvgPrice,
          currentPrice = report.execPrice
        )
      } else {
        // Trimming or flipping position: calculate realized P&L on closed portion
        val closedQty = minOf(abs(oldQty), abs(signedExecQty))
        val pnlPerUnit = if (oldQty > 0) (report.execPrice - existing.avgEntryPrice) else (existing.avgEntryPrice - report.execPrice)
        realizedPnLDelta = closedQty * pnlPerUnit * multiplier
        cumulativeRealizedPnL += realizedPnLDelta

        if (newQty == 0.0) {
          // Position fully closed
          internalPositions[report.symbol] = existing.copy(
            quantity = 0.0,
            realizedPnL = existing.realizedPnL + realizedPnLDelta,
            currentPrice = report.execPrice
          )
        } else if ((oldQty > 0 && newQty < 0) || (oldQty < 0 && newQty > 0)) {
          // Position flipped side
          internalPositions[report.symbol] = Position(
            symbol = report.symbol,
            assetClass = assetClass,
            quantity = newQty,
            avgEntryPrice = report.execPrice,
            currentPrice = report.execPrice,
            realizedPnL = existing.realizedPnL + realizedPnLDelta
          )
        } else {
          // Partial reduction in size: keep same average entry price
          internalPositions[report.symbol] = existing.copy(
            quantity = newQty,
            currentPrice = report.execPrice,
            realizedPnL = existing.realizedPnL + realizedPnLDelta
          )
        }
      }
    }

    _positions.value = HashMap(internalPositions)
    recalculateSummary(emptyMap())
  }

  private fun recalculateSummary(quotes: Map<String, Quote>) {
    var grossExposure = 0.0
    var netExposure = 0.0
    var unrealizedPnL = 0.0

    internalPositions.values.forEach { pos ->
      if (pos.quantity != 0.0) {
        val inst = InstrumentCatalog.findBySymbol(pos.symbol)
        val mult = inst?.contractMultiplier ?: 1.0
        val notional = abs(pos.quantity * pos.currentPrice * mult)
        grossExposure += notional
        netExposure += (pos.quantity * pos.currentPrice * mult)
        unrealizedPnL += pos.quantity * (pos.currentPrice - pos.avgEntryPrice) * mult
      }
    }

    val nav = cashBalance + unrealizedPnL
    val marginUsed = grossExposure * 0.25 // 25% margin
    val buyingPower = maxOf(0.0, (nav * 4.0) - grossExposure)
    val leverage = if (nav > 0) grossExposure / nav else 0.0

    _summary.value = PortfolioSummary(
      accountId = "NYTD-PRIME-001",
      cashUsd = FinancialMath.roundMoney(cashBalance),
      buyingPowerUsd = FinancialMath.roundMoney(buyingPower),
      grossExposureUsd = FinancialMath.roundMoney(grossExposure),
      netExposureUsd = FinancialMath.roundMoney(netExposure),
      marginUsedUsd = FinancialMath.roundMoney(marginUsed),
      dailyRealizedPnLUsd = FinancialMath.roundMoney(cumulativeRealizedPnL),
      dailyUnrealizedPnLUsd = FinancialMath.roundMoney(unrealizedPnL),
      navUsd = FinancialMath.roundMoney(nav),
      leverageRatio = FinancialMath.roundMoney(leverage, 2)
    )
  }

  fun resetPortfolio() {
    internalPositions.clear()
    cashBalance = 10_000_000.0
    cumulativeRealizedPnL = 0.0
    _positions.value = emptyMap()
    recalculateSummary(emptyMap())
  }
}
