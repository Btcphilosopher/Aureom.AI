package com.example.nytd.engine

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sqrt

object FinancialMath {

  fun roundMoney(value: Double, scale: Int = 2): Double {
    return try {
      BigDecimal.valueOf(value).setScale(scale, RoundingMode.HALF_UP).toDouble()
    } catch (_: Exception) {
      value
    }
  }

  fun roundBps(value: Double): Double {
    return roundMoney(value, 1)
  }

  /**
   * Standard cumulative normal distribution function approx (Abramowitz & Stegun)
   */
  fun standardNormalCdf(x: Double): Double {
    val b1 = 0.319381530
    val b2 = -0.356563782
    val b3 = 1.781477937
    val b4 = -1.821255978
    val b5 = 1.330274429
    val p = 0.2316419
    val c = 0.3989422804014327

    if (x >= 0.0) {
      val t = 1.0 / (1.0 + p * x)
      return (1.0 - c * exp(-x * x / 2.0) * t *
          (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
    } else {
      val t = 1.0 / (1.0 - p * x)
      return (c * exp(-x * x / 2.0) * t *
          (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
    }
  }

  fun standardNormalPdf(x: Double): Double {
    return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
  }

  data class BlackScholesGreeks(
    val price: Double,
    val delta: Double,
    val gamma: Double,
    val theta: Double,
    val vega: Double,
    val rho: Double
  )

  /**
   * Black-Scholes formula for European options
   * S: spot, K: strike, T: time to maturity in years, r: risk-free rate, sigma: volatility
   */
  fun calculateBlackScholes(
    isCall: Boolean,
    spotPrice: Double,
    strikePrice: Double,
    timeYears: Double,
    riskFreeRate: Double = 0.045,
    volatility: Double = 0.25
  ): BlackScholesGreeks {
    val tSafe = timeYears.coerceAtLeast(0.001)
    val sigmaSafe = volatility.coerceAtLeast(0.01)
    val d1 = (ln(spotPrice / strikePrice) + (riskFreeRate + 0.5 * sigmaSafe * sigmaSafe) * tSafe) / (sigmaSafe * sqrt(tSafe))
    val d2 = d1 - sigmaSafe * sqrt(tSafe)

    val nd1 = standardNormalCdf(d1)
    val nd2 = standardNormalCdf(d2)
    val npd1 = standardNormalPdf(d1)

    val discountFactor = exp(-riskFreeRate * tSafe)

    val price = if (isCall) {
      spotPrice * nd1 - strikePrice * discountFactor * nd2
    } else {
      strikePrice * discountFactor * standardNormalCdf(-d2) - spotPrice * standardNormalCdf(-d1)
    }

    val delta = if (isCall) nd1 else nd1 - 1.0
    val gamma = npd1 / (spotPrice * sigmaSafe * sqrt(tSafe))
    val vega = spotPrice * npd1 * sqrt(tSafe) / 100.0 // per 1% vol change
    val theta = if (isCall) {
      (-spotPrice * npd1 * sigmaSafe / (2.0 * sqrt(tSafe)) - riskFreeRate * strikePrice * discountFactor * nd2) / 365.0
    } else {
      (-spotPrice * npd1 * sigmaSafe / (2.0 * sqrt(tSafe)) + riskFreeRate * strikePrice * discountFactor * standardNormalCdf(-d2)) / 365.0
    }
    val rho = if (isCall) {
      strikePrice * tSafe * discountFactor * nd2 / 100.0
    } else {
      -strikePrice * tSafe * discountFactor * standardNormalCdf(-d2) / 100.0
    }

    return BlackScholesGreeks(
      price = roundMoney(price.coerceAtLeast(0.01)),
      delta = roundMoney(delta, 4),
      gamma = roundMoney(gamma, 4),
      theta = roundMoney(theta, 4),
      vega = roundMoney(vega, 4),
      rho = roundMoney(rho, 4)
    )
  }

  /**
   * Fixed Income: Modified Duration & DV01
   */
  fun calculateBondRisk(
    couponRatePct: Double,
    yieldToMaturityPct: Double,
    yearsToMaturity: Double,
    parValue: Double = 100.0
  ): Pair<Double, Double> {
    val y = (yieldToMaturityPct / 100.0).coerceAtLeast(0.001)
    val c = couponRatePct / 100.0
    val n = yearsToMaturity.coerceAtLeast(0.25)

    // Macaulay duration approx for semi-annual bond
    val macDuration = (1.0 + y / 2.0) / y - ((1.0 + y / 2.0) + n * (c - y)) / (c * ((1.0 + y / 2.0).pow(2 * n) - 1.0) + y)
    val modDuration = macDuration / (1.0 + y / 2.0)
    val dv01 = (modDuration * parValue * 0.0001)

    return Pair(roundMoney(modDuration, 2), roundMoney(dv01, 3))
  }
}
