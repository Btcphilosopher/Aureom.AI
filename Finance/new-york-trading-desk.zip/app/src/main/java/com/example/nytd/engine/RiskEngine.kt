package com.example.nytd.engine

import com.example.nytd.model.OrderEntity
import com.example.nytd.model.PortfolioSummary
import com.example.nytd.model.Position
import com.example.nytd.model.Quote
import com.example.nytd.model.RiskCheckResult
import com.example.nytd.model.RiskLimits
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

class RiskEngine {

  private val _limits = MutableStateFlow(RiskLimits())
  val limits: StateFlow<RiskLimits> = _limits.asStateFlow()

  fun updateLimits(newLimits: RiskLimits) {
    _limits.value = newLimits
  }

  fun setKillSwitch(active: Boolean) {
    _limits.value = _limits.value.copy(isKillSwitchActive = active)
  }

  fun setReadOnlyMode(readOnly: Boolean) {
    _limits.value = _limits.value.copy(readOnlyMode = readOnly)
  }

  fun evaluatePreTradeRisk(
    order: OrderEntity,
    quote: Quote?,
    portfolio: PortfolioSummary,
    currentPositions: List<Position>
  ): RiskCheckResult {
    val limits = _limits.value
    val breached = mutableListOf<String>()
    val warnings = mutableListOf<String>()

    // 1. Emergency Kill Switch check
    if (limits.isKillSwitchActive) {
      breached.add("EMERGENCY KILL SWITCH ACTIVE: Trading floor halted by Chief Risk Officer")
    }

    // 2. Read-only mode check
    if (limits.readOnlyMode) {
      breached.add("TERMINAL IN READ-ONLY AUDIT MODE: Order creation blocked")
    }

    // 3. Estimate order notional
    val unitPrice = order.price ?: quote?.askPrice ?: quote?.lastPrice ?: 100.0
    val inst = InstrumentCatalog.findBySymbol(order.symbol)
    val multiplier = inst?.contractMultiplier ?: 1.0
    val orderNotional = order.quantity * unitPrice * multiplier

    // 4. Max Order Notional Limit
    if (orderNotional > limits.maxOrderNotionalUsd) {
      breached.add(
        "ORDER NOTIONAL EXCEEDS LIMIT: \$${FinancialMath.roundMoney(orderNotional)} > \$${FinancialMath.roundMoney(limits.maxOrderNotionalUsd)}"
      )
    }

    // 5. Buying Power & Margin Check
    val requiredMargin = orderNotional * 0.25 // 25% reg T / prime broker margin
    if (requiredMargin > portfolio.buyingPowerUsd) {
      breached.add(
        "INSUFFICIENT BUYING POWER: Required margin \$${FinancialMath.roundMoney(requiredMargin)} exceeds available \$${FinancialMath.roundMoney(portfolio.buyingPowerUsd)}"
      )
    }

    // 6. Max Position Size / Concentration Check
    val existingPos = currentPositions.find { it.symbol == order.symbol }
    val existingQty = existingPos?.quantity ?: 0.0
    val signedNewQty = if (order.side == com.example.nytd.model.OrderSide.BUY) order.quantity else -order.quantity
    val projectedQty = existingQty + signedNewQty
    val projectedPositionNotional = abs(projectedQty * unitPrice * multiplier)

    if (projectedPositionNotional > limits.maxPositionNotionalUsd) {
      breached.add(
        "PROJECTED POSITION NOTIONAL EXCEEDS LIMIT: \$${FinancialMath.roundMoney(projectedPositionNotional)} > \$${FinancialMath.roundMoney(limits.maxPositionNotionalUsd)}"
      )
    }

    val concentrationPct = if (portfolio.navUsd > 0) (projectedPositionNotional / portfolio.navUsd) * 100.0 else 0.0
    if (concentrationPct > limits.maxSingleAssetConcentrationPct) {
      warnings.add(
        "High Concentration Alert: Projected position represents ${FinancialMath.roundMoney(concentrationPct, 1)}% of NAV (Guideline: ${limits.maxSingleAssetConcentrationPct}%)"
      )
    }

    // 7. Gross Leverage Check
    val projectedGrossExposure = portfolio.grossExposureUsd + orderNotional
    val projectedLeverage = if (portfolio.navUsd > 0) projectedGrossExposure / portfolio.navUsd else 0.0
    if (projectedLeverage > limits.maxGrossLeverage) {
      breached.add(
        "LEVERAGE LIMIT EXCEEDED: Projected leverage ${FinancialMath.roundMoney(projectedLeverage, 2)}x exceeds maximum ${limits.maxGrossLeverage}x"
      )
    }

    // 8. Daily Loss Limit Check
    if (portfolio.dailyRealizedPnLUsd + portfolio.dailyUnrealizedPnLUsd < -limits.dailyLossLimitUsd) {
      breached.add(
        "DAILY LOSS LIMIT BREACHED: Cumulative P&L loss exceeds \$${FinancialMath.roundMoney(limits.dailyLossLimitUsd)}"
      )
    }

    // Soft warnings for market quality
    if (quote != null && quote.spreadBps > 15.0) {
      warnings.add("Market Spread Elevated: Current spread is ${FinancialMath.roundMoney(quote.spreadBps, 1)} bps (Potential slippage)")
    }

    return RiskCheckResult(
      isApproved = breached.isEmpty(),
      breachedLimits = breached,
      warningNotes = warnings,
      estimatedImpactNotional = orderNotional
    )
  }
}
