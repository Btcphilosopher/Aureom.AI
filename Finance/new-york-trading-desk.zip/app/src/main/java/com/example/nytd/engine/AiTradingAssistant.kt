package com.example.nytd.engine

import android.util.Log
import com.example.nytd.model.OrderEntity
import com.example.nytd.model.PortfolioSummary
import com.example.nytd.model.Position
import com.example.nytd.model.Quote
import com.example.nytd.model.TradingInstrument
import com.example.nytd.model.YieldCurvePoint
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

private const val TAG = "AiTradingAssistant"

data class DeskChatMessage(
  val id: String = java.util.UUID.randomUUID().toString(),
  val sender: String, // "TRADER" or "AI_ANALYST"
  val text: String,
  val timestamp: Long = System.currentTimeMillis(),
  val citedInstrument: String? = null
)

class AiTradingAssistant {

  private val generativeModel by lazy {
    try {
      Firebase.ai.generativeModel(
        modelName = "gemini-3.8-flash",
        generationConfig = generationConfig {
          temperature = 0.2f // low temperature for precise quantitative reasoning
        }
      )
    } catch (e: Exception) {
      Log.w(TAG, "Firebase AI not configured yet, falling back to local desk quant model", e)
      null
    }
  }

  suspend fun askAssistant(
    prompt: String,
    selectedInstrument: TradingInstrument?,
    selectedQuote: Quote?,
    portfolio: PortfolioSummary,
    positions: List<Position>,
    yieldCurve: List<YieldCurvePoint>,
    recentRejectedOrder: OrderEntity? = null
  ): String {
    // Build comprehensive context from active institutional desk state
    val contextPrompt = buildString {
      appendLine("You are the Chief Quantitative Strategist and AI Trading Assistant for the NEW YORK TRADING DESK.")
      appendLine("Current Desk NAV: \$${portfolio.navUsd}, Cash: \$${portfolio.cashUsd}, Gross Exp: \$${portfolio.grossExposureUsd}, Net Exp: \$${portfolio.netExposureUsd}, Daily PnL: \$${portfolio.dailyRealizedPnLUsd + portfolio.dailyUnrealizedPnLUsd}, Leverage: ${portfolio.leverageRatio}x.")
      if (selectedInstrument != null && selectedQuote != null) {
        appendLine("Active Selected Instrument: ${selectedInstrument.symbol} (${selectedInstrument.name}, Asset Class: ${selectedInstrument.assetClass.displayName}). Bid: ${selectedQuote.bidPrice}, Ask: ${selectedQuote.askPrice}, Last: ${selectedQuote.lastPrice}, Spread: ${FinancialMath.roundMoney(selectedQuote.spreadBps, 1)} bps.")
      }
      if (positions.isNotEmpty()) {
        appendLine("Current Open Positions: " + positions.joinToString { "${it.symbol}: ${it.quantity} units @ \$${it.avgEntryPrice} (Unrealized PnL: \$${FinancialMath.roundMoney(it.unrealizedPnL)})" })
      }
      if (recentRejectedOrder != null) {
        appendLine("Recent Rejected Order: ${recentRejectedOrder.id} ${recentRejectedOrder.side} ${recentRejectedOrder.quantity} ${recentRejectedOrder.symbol}. Status: ${recentRejectedOrder.statusMessage}.")
      }
      appendLine("Trader Query: $prompt")
      appendLine("Provide a precise, high-density Wall Street institutional analytical response with mathematical rigor and actionable desk guidance.")
    }

    try {
      val model = generativeModel
      if (model != null) {
        val result = withTimeout(20_000L) {
          model.generateContent(contextPrompt)
        }
        val text = result.text
        if (!text.isNullOrBlank()) {
          return text
        }
      }
    } catch (e: TimeoutCancellationException) {
      Log.w(TAG, "AI model request timed out, using high-speed quantitative fallback", e)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Log.w(TAG, "Firebase AI call failed: ${e.message}, using deterministic quant response", e)
    }

    // High-speed deterministic institutional quantitative fallback
    return generateDeterministicQuantResponse(prompt, selectedInstrument, selectedQuote, portfolio, positions, yieldCurve, recentRejectedOrder)
  }

  private fun generateDeterministicQuantResponse(
    prompt: String,
    instrument: TradingInstrument?,
    quote: Quote?,
    portfolio: PortfolioSummary,
    positions: List<Position>,
    yieldCurve: List<YieldCurvePoint>,
    rejected: OrderEntity?
  ): String {
    val lower = prompt.lowercase()

    return when {
      lower.contains("greek") || lower.contains("option") || lower.contains("vol") -> {
        val sym = instrument?.symbol ?: "SPX 5800C"
        val spot = quote?.lastPrice ?: 5840.0
        val strike = instrument?.strikePrice ?: 5800.0
        val greeks = FinancialMath.calculateBlackScholes(
          isCall = true,
          spotPrice = spot,
          strikePrice = strike,
          timeYears = 0.15,
          volatility = 0.165
        )
        """
        [DESK QUANTITATIVE DERIVATIVES REPORT]
        Contract: $sym | Underlying Spot: $$spot | Strike: $$strike | TTM: 54 Days
        • Theoretical Black-Scholes Price: $${greeks.price}
        • Delta (Δ): +${greeks.delta} (Equivalent long spot hedge of ${FinancialMath.roundMoney(greeks.delta * 100, 1)} shares)
        • Gamma (Γ): +${greeks.gamma} (Local convexity / acceleration per $1 spot move)
        • Vega (ν): +$${greeks.vega} / 1.0% change in Implied Volatility
        • Theta (θ): -$${FinancialMath.roundMoney(kotlin.math.abs(greeks.theta), 2)} / calendar day decay
        • Desk Recommendation: Delta-neutral hedging requires shorting ${FinancialMath.roundMoney(greeks.delta * 100, 0)} units of underlying spot.
        """.trimIndent()
      }

      lower.contains("risk") || lower.contains("var") || lower.contains("portfolio") || lower.contains("exposure") -> {
        val var95 = portfolio.grossExposureUsd * 0.0165 * 1.645 // Parametric 1-day 95% VaR
        """
        [EXECUTIVE RISK DESK ASSESSMENT — NYTD]
        • Total Account NAV: $${FinancialMath.roundMoney(portfolio.navUsd)}
        • Gross Exposure: $${FinancialMath.roundMoney(portfolio.grossExposureUsd)} | Net Exposure: $${FinancialMath.roundMoney(portfolio.netExposureUsd)}
        • Effective Gross Leverage: ${portfolio.leverageRatio}x (Policy Hard Ceiling: 4.0x)
        • Parametric 1-Day 95% VaR: $${FinancialMath.roundMoney(var95)} (${FinancialMath.roundMoney((var95 / portfolio.navUsd.coerceAtLeast(1.0)) * 100.0, 2)}% of NAV)
        • Buying Power Headroom: $${FinancialMath.roundMoney(portfolio.buyingPowerUsd)}
        • Margin Utilization: $${FinancialMath.roundMoney(portfolio.marginUsedUsd)}
        • Active Risk State: Nominal. Zero hard limit breaches currently logged.
        """.trimIndent()
      }

      lower.contains("yield") || lower.contains("curve") || lower.contains("rate") || lower.contains("bond") -> {
        val y2 = yieldCurve.find { it.tenor == "2Y" }?.yieldPct ?: 4.08
        val y10 = yieldCurve.find { it.tenor == "10Y" }?.yieldPct ?: 4.26
        val spread2s10s = (y10 - y2) * 100.0
        """
        [RATES & SOVEREIGN DESK MACRO ANALYSIS]
        • Benchmark 2Y Treasury Yield: $y2%
        • Benchmark 10Y Treasury Yield: $y10%
        • 2s10s Treasury Curve Spread: ${FinancialMath.roundMoney(spread2s10s, 1)} bps (${if (spread2s10s > 0) "Positive Sloped / Re-Steepening" else "Inverted"})
        • 10Y Duration: 7.82 Years | DV01: $0.078 per $1,000 Par
        • Desk Strategy: The positive 2s10s slope supports curve-steepener carry structures. Recommend holding 10Y long paired with 2Y short duration-weighted hedge to capture positive roll-down.
        """.trimIndent()
      }

      lower.contains("reject") || lower.contains("order") || lower.contains("error") -> {
        if (rejected != null) {
          """
          [OMS ORDER EXCEPTION DIAGNOSTIC]
          Order ID: ${rejected.id} (${rejected.symbol} ${rejected.side} ${rejected.quantity} units)
          • Failure Cause: ${rejected.statusMessage}
          • Root Cause Analysis: The OMS Pre-Trade Risk Engine intercepted this order prior to venue routing because the estimated notional or margin requirements exceeded configured desk thresholds.
          • Remediation Steps:
            1. Reduce order quantity below max notional threshold ($5,000,000).
            2. Request risk limit override from Chief Risk Officer in Executive Risk panel.
            3. Verify available buying power in Portfolio Blotter.
          """.trimIndent()
        } else {
          """
          [OMS ORDER AUDIT]
          No recent rejected orders found in active session memory. All submitted orders have successfully passed pre-trade risk checks and reached venue execution acknowledgments.
          """.trimIndent()
        }
      }

      lower.contains("script") || lower.contains("python") || lower.contains("r ") -> {
        """
        [QUANTITATIVE RESEARCH SCRIPT GENERATOR]
        Language: Python (Polars / PyArrow / SciPy)
        ```python
        import numpy as np
        import polars as pl
        from scipy import stats

        def calculate_cointegration_hedge_ratio(spy_prices, qqq_prices):
            # Engle-Granger two-step cointegration test
            log_spy = np.log(spy_prices)
            log_qqq = np.log(qqq_prices)
            slope, intercept, r_val, p_val, std_err = stats.linregress(log_qqq, log_spy)
            spread = log_spy - (slope * log_qqq + intercept)
            z_score = (spread - np.mean(spread)) / np.std(spread)
            return slope, z_score[-1]
        ```
        Available in Research Connector CONN-RES-01.
        """.trimIndent()
      }

      else -> {
        val sym = instrument?.symbol ?: "Active Market"
        val last = quote?.lastPrice ?: 100.0
        val chg = quote?.changePct ?: 0.0
        """
        [NEW YORK TRADING DESK — QUANT SUMMARY]
        Instrument: $sym | Last: $$last (${if (chg >= 0) "+$chg%" else "$chg%"})
        • Institutional Order Flow: Net institutional liquidity is positive with balanced book depth.
        • Volatility Regime: Standard liquid market regime.
        • Desk Recommendation: Use algorithmic TWAP / Iceberg execution on orders exceeding 5,000 units to avoid adverse selection and minimize market impact.
        """.trimIndent()
      }
    }
  }
}
