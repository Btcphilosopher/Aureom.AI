package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NytdColorScheme = darkColorScheme(
  primary = WallStreetGold,
  onPrimary = Color.Black,
  primaryContainer = WallStreetGoldDim,
  onPrimaryContainer = Color.White,
  secondary = MarketCyan,
  onSecondary = Color.Black,
  secondaryContainer = DeskCardElevated,
  onSecondaryContainer = TextPrimary,
  tertiary = MarketGreen,
  onTertiary = Color.Black,
  background = DeskBlack,
  onBackground = TextPrimary,
  surface = DeskMidnight,
  onSurface = TextPrimary,
  surfaceVariant = DeskCard,
  onSurfaceVariant = TextSecondary,
  outline = DeskBorder,
  outlineVariant = DeskBorderSubtle,
  error = MarketRed,
  onError = Color.White,
  errorContainer = MarketRedBg,
  onErrorContainer = MarketRed
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit,
) {
  // Institutional Trading Desks use dedicated precision dark terminal theme
  MaterialTheme(
    colorScheme = NytdColorScheme,
    typography = Typography,
    content = content
  )
}
