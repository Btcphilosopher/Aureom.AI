package com.example.nytd.engine

import com.example.nytd.model.AssetClass
import com.example.nytd.model.OrderEntity
import com.example.nytd.model.OrderSide
import com.example.nytd.model.Quote
import kotlin.math.sqrt

data class RoutedVenueEstimate(
  val venueName: String,
  val estimatedExecPrice: Double,
  val estimatedSlippageBps: Double,
  val estimatedFeeUsd: Double,
  val venueLatencyMs: Int,
  val routingRationale: String
)

class SmartOrderRouter {

  fun routeOrder(order: OrderEntity, quote: Quote): RoutedVenueEstimate {
    val inst = InstrumentCatalog.findBySymbol(order.symbol)
    val assetClass = inst?.assetClass ?: AssetClass.EQUITIES
    val basePrice = if (order.side == OrderSide.BUY) quote.askPrice else quote.bidPrice

    // Determine candidate venues
    val venues = when (assetClass) {
      AssetClass.EQUITIES -> listOf("NYSE Arca", "NASDAQ Lit", "IEX Midpoint", "Citadel Dark ATS")
      AssetClass.RATES -> listOf("Tradeweb ATS", "BrokerTec", "Dealer Direct ATS")
      AssetClass.FX -> listOf("Currenex ECN", "FastMatch", "EBS Prime")
      AssetClass.CREDIT -> listOf("MarketAxess Open", "Tradeweb Credit", "NYSE Bonds")
      AssetClass.COMMODITIES -> listOf("CME Globex", "ICE Europe", "NYMEX Floor ATS")
      AssetClass.DIGITAL_ASSETS -> listOf("Coinbase Prime", "FalconX Liquidity", "Kraken Institutional")
      AssetClass.DERIVATIVES -> listOf("Cboe Options", "Nasdaq PHLX", "MIAX Emerald")
    }

    val selectedVenue = if (order.targetVenue != "SMART" && order.targetVenue.isNotBlank()) {
      order.targetVenue
    } else {
      venues.first()
    }

    // Square-root market impact slippage estimate
    val multiplier = inst?.contractMultiplier ?: 1.0
    val notional = order.quantity * basePrice * multiplier
    val impactBps = (sqrt(notional / 500_000.0) * 1.5).coerceIn(0.2, 12.0)
    val slippageSign = if (order.side == OrderSide.BUY) 1.0 else -1.0
    val estimatedPrice = basePrice * (1.0 + (slippageSign * (impactBps / 10000.0)))

    // Fee model: 0.8 bps for institutional lit execution
    val feeUsd = notional * 0.00008

    return RoutedVenueEstimate(
      venueName = selectedVenue,
      estimatedExecPrice = FinancialMath.roundMoney(estimatedPrice, if (inst?.tickSize ?: 0.01 < 0.001) 4 else 2),
      estimatedSlippageBps = FinancialMath.roundMoney(impactBps, 1),
      estimatedFeeUsd = FinancialMath.roundMoney(feeUsd, 2),
      venueLatencyMs = when (selectedVenue) {
        "IEX Midpoint" -> 350 // speed bump
        "Citadel Dark ATS" -> 8
        else -> 12
      },
      routingRationale = "NBBO Best Available Liquidity on $selectedVenue with estimated ${FinancialMath.roundMoney(impactBps, 1)} bps market impact"
    )
  }
}
