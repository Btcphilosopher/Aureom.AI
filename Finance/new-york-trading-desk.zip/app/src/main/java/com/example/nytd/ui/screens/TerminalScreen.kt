package com.example.nytd.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nytd.engine.InstrumentCatalog
import com.example.nytd.model.OrderSide
import com.example.nytd.model.OrderType
import com.example.nytd.model.TimeInForce
import com.example.nytd.ui.components.AiAssistantPanel
import com.example.nytd.ui.components.ConnectorFabricPanel
import com.example.nytd.ui.components.DerivativesDeskPanel
import com.example.nytd.ui.components.InstitutionalHeader
import com.example.nytd.ui.components.InstrumentMasterBar
import com.example.nytd.ui.components.InstrumentSelectorDialog
import com.example.nytd.ui.components.InteractiveChart
import com.example.nytd.ui.components.OrderBlotter
import com.example.nytd.ui.components.OrderTicketDialog
import com.example.nytd.ui.components.PositionBlotter
import com.example.nytd.ui.components.QuantStudioPanel
import com.example.nytd.ui.components.RatesDeskPanel
import com.example.nytd.ui.components.RiskExecutivePanel
import com.example.nytd.ui.components.WorkspaceTabs
import com.example.nytd.ui.viewmodel.DeskWorkspace
import com.example.nytd.ui.viewmodel.TradingDeskViewModel
import com.example.ui.theme.DeskBlack
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskMidnight
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

@Composable
fun TerminalScreen(
  viewModel: TradingDeskViewModel,
  modifier: Modifier = Modifier
) {
  val activeWorkspace by viewModel.activeWorkspace.collectAsState()
  val selectedInstrument by viewModel.selectedInstrument.collectAsState()
  val quotes by viewModel.marketDataSimulator.quotes.collectAsState()
  val currentRegime by viewModel.marketDataSimulator.currentRegime.collectAsState()
  val portfolioSummary by viewModel.portfolioEngine.summary.collectAsState()
  val positions by viewModel.portfolioEngine.positions.collectAsState()
  val riskLimits by viewModel.riskEngine.limits.collectAsState()
  val orders by viewModel.oms.orders.collectAsState()
  val executions by viewModel.oms.executions.collectAsState()
  val connectors by viewModel.connectorFabric.connectors.collectAsState()
  val proposals by viewModel.activeProposals.collectAsState()
  val chatMessages by viewModel.chatMessages.collectAsState()
  val isAiThinking by viewModel.isAiThinking.collectAsState()

  val activeQuote = quotes[selectedInstrument.symbol]
  val bars = viewModel.marketDataSimulator.getCandlestickHistory(selectedInstrument.symbol)
  val orderBook = viewModel.marketDataSimulator.getOrderBook(selectedInstrument.symbol)

  var showOrderTicket by remember { mutableStateOf(false) }
  var showInstrumentSelector by remember { mutableStateOf(false) }
  var bottomPanelTab by remember { mutableStateOf("BLOTTER") } // "BLOTTER" or "AI"

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = DeskBlack,
    topBar = {
      Column {
        InstitutionalHeader(
          portfolio = portfolioSummary,
          currentRegime = currentRegime,
          isKillSwitchActive = riskLimits.isKillSwitchActive,
          onRegimeChange = { viewModel.setMarketRegime(it) },
          onKillSwitchToggle = { viewModel.toggleKillSwitch() }
        )
        WorkspaceTabs(
          currentWorkspace = activeWorkspace,
          onSelectWorkspace = { viewModel.switchWorkspace(it) }
        )
      }
    }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
    ) {
      // Instrument Bar
      InstrumentMasterBar(
        instrument = selectedInstrument,
        quote = activeQuote,
        onOpenOrderTicket = { showOrderTicket = true },
        onOpenInstrumentSelector = { showInstrumentSelector = true }
      )

      Spacer(modifier = Modifier.height(4.dp))

      // Workspace-Specific Main Panels
      when (activeWorkspace) {
        DeskWorkspace.EQUITIES, DeskWorkspace.COMMODITIES, DeskWorkspace.DIGITAL_ASSETS, DeskWorkspace.FX, DeskWorkspace.CREDIT -> {
          InteractiveChart(
            bars = bars,
            orderBook = orderBook,
            currentPrice = activeQuote?.lastPrice ?: 100.0,
            modifier = Modifier.padding(horizontal = 6.dp)
          )
        }
        DeskWorkspace.RATES -> {
          RatesDeskPanel(
            yieldCurve = viewModel.marketDataSimulator.getUsYieldCurve(),
            onSelectTenor = { tenor ->
              val mapped = when (tenor) {
                "2Y" -> "US02Y"
                "10Y" -> "US10Y"
                "30Y" -> "US30Y"
                else -> "US10Y"
              }
              val found = InstrumentCatalog.findBySymbol(mapped)
              if (found != null) viewModel.selectInstrument(found)
            },
            modifier = Modifier.padding(horizontal = 6.dp)
          )
        }
        DeskWorkspace.DERIVATIVES -> {
          DerivativesDeskPanel(
            spotPrice = activeQuote?.lastPrice ?: 5840.0,
            modifier = Modifier.padding(horizontal = 6.dp)
          )
        }
        DeskWorkspace.QUANT_STUDIO -> {
          QuantStudioPanel(
            proposals = proposals,
            onExecuteProposal = { prop ->
              viewModel.submitOrder(
                symbol = prop.symbol,
                side = prop.side,
                type = prop.orderType,
                quantity = prop.suggestedQuantity,
                price = prop.limitPrice,
                stopPrice = prop.stopLoss,
                timeInForce = TimeInForce.DAY
              )
            },
            modifier = Modifier.padding(horizontal = 6.dp)
          )
        }
        DeskWorkspace.PORTFOLIO_BLOTTER -> {
          PositionBlotter(
            positions = positions.values.toList(),
            summary = portfolioSummary,
            onFlattenPosition = { pos ->
              // Flatten position with opposite market order
              viewModel.submitOrder(
                symbol = pos.symbol,
                side = if (pos.isLong) OrderSide.SELL else OrderSide.BUY,
                type = OrderType.MARKET,
                quantity = kotlin.math.abs(pos.quantity),
                price = null,
                stopPrice = null,
                timeInForce = TimeInForce.IOC
              )
            },
            modifier = Modifier.padding(horizontal = 6.dp)
          )
        }
        DeskWorkspace.EXECUTIVE_RISK -> {
          RiskExecutivePanel(
            limits = riskLimits,
            isKillSwitchActive = riskLimits.isKillSwitchActive,
            onToggleKillSwitch = { viewModel.toggleKillSwitch() },
            modifier = Modifier.padding(horizontal = 6.dp)
          )
        }
        DeskWorkspace.CONNECTOR_FABRIC -> {
          ConnectorFabricPanel(
            connectors = connectors,
            onToggleConnector = { viewModel.connectorFabric.toggleConnector(it) },
            onTestConnection = { viewModel.connectorFabric.testConnection(it) },
            modifier = Modifier.padding(horizontal = 6.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Bottom Auxiliary Panel Switcher
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        listOf("BLOTTER", "POSITIONS", "AI ASSISTANT").forEach { tab ->
          val isSel = tab == bottomPanelTab
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(3.dp))
              .background(if (isSel) WallStreetGold else DeskCard)
              .border(1.dp, if (isSel) WallStreetGold else DeskBorder, RoundedCornerShape(3.dp))
              .clickable { bottomPanelTab = tab }
              .padding(horizontal = 8.dp, vertical = 4.dp)
              .testTag("subtab_${tab.lowercase().replace(' ', '_')}")
          ) {
            Text(
              text = tab,
              color = if (isSel) Color.Black else TextSecondary,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      // Content for Bottom Panel
      Box(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)) {
        when (bottomPanelTab) {
          "BLOTTER" -> {
            OrderBlotter(
              orders = orders,
              executions = executions,
              onCancelOrder = { viewModel.cancelOrder(it) },
              onCancelAllOrders = { viewModel.oms.cancelAllOrders() }
            )
          }
          "POSITIONS" -> {
            PositionBlotter(
              positions = positions.values.toList(),
              summary = portfolioSummary,
              onFlattenPosition = { pos ->
                viewModel.submitOrder(
                  symbol = pos.symbol,
                  side = if (pos.isLong) OrderSide.SELL else OrderSide.BUY,
                  type = OrderType.MARKET,
                  quantity = kotlin.math.abs(pos.quantity),
                  price = null,
                  stopPrice = null,
                  timeInForce = TimeInForce.IOC
                )
              }
            )
          }
          "AI ASSISTANT" -> {
            AiAssistantPanel(
              messages = chatMessages,
              isThinking = isAiThinking,
              onSendPrompt = { viewModel.sendAiPrompt(it) }
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))
    }
  }

  // Order Ticket Modal Dialog
  if (showOrderTicket) {
    OrderTicketDialog(
      instrument = selectedInstrument,
      quote = activeQuote,
      portfolio = portfolioSummary,
      onDismiss = { showOrderTicket = false },
      onSubmitOrder = { side, type, qty, price, stop, tif, venue, onResult ->
        viewModel.submitOrder(
          symbol = selectedInstrument.symbol,
          side = side,
          type = type,
          quantity = qty,
          price = price,
          stopPrice = stop,
          timeInForce = tif,
          targetVenue = venue,
          onComplete = onResult
        )
      }
    )
  }

  // Global Instrument Master Search Dialog
  if (showInstrumentSelector) {
    InstrumentSelectorDialog(
      currentSelected = selectedInstrument,
      quotes = quotes,
      onSelect = { inst -> viewModel.selectInstrument(inst) },
      onDismiss = { showInstrumentSelector = false }
    )
  }
}
