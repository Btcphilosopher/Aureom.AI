package com.example.nytd.engine

import com.example.nytd.model.AssetClass
import com.example.nytd.model.TradingInstrument

object InstrumentCatalog {

  val ALL_INSTRUMENTS: List<TradingInstrument> = listOf(
    // Equities & ETFs
    TradingInstrument(
      id = "EQ-NVDA",
      symbol = "NVDA",
      canonicalSymbol = "NVDA.US",
      name = "NVIDIA Corporation",
      assetClass = AssetClass.EQUITIES,
      primaryVenue = "NASDAQ",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.01,
      lotSize = 1.0,
      providerSymbols = mapOf("BLOOMBERG" to "NVDA US Equity", "REFINITIV" to "NVDA.O", "FIX" to "NVDA")
    ),
    TradingInstrument(
      id = "EQ-AAPL",
      symbol = "AAPL",
      canonicalSymbol = "AAPL.US",
      name = "Apple Inc.",
      assetClass = AssetClass.EQUITIES,
      primaryVenue = "NASDAQ",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.01,
      lotSize = 1.0,
      providerSymbols = mapOf("BLOOMBERG" to "AAPL US Equity", "REFINITIV" to "AAPL.O")
    ),
    TradingInstrument(
      id = "EQ-MSFT",
      symbol = "MSFT",
      canonicalSymbol = "MSFT.US",
      name = "Microsoft Corporation",
      assetClass = AssetClass.EQUITIES,
      primaryVenue = "NASDAQ",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.01,
      lotSize = 1.0
    ),
    TradingInstrument(
      id = "EQ-SPY",
      symbol = "SPY",
      canonicalSymbol = "SPY.US",
      name = "SPDR S&P 500 ETF Trust",
      assetClass = AssetClass.EQUITIES,
      primaryVenue = "NYSE Arca",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.01,
      lotSize = 1.0
    ),
    TradingInstrument(
      id = "EQ-QQQ",
      symbol = "QQQ",
      canonicalSymbol = "QQQ.US",
      name = "Invesco QQQ Trust",
      assetClass = AssetClass.EQUITIES,
      primaryVenue = "NASDAQ",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.01,
      lotSize = 1.0
    ),

    // Rates & Sovereign Fixed Income
    TradingInstrument(
      id = "IR-US10Y",
      symbol = "US10Y",
      canonicalSymbol = "T 4.25 08/34",
      name = "US Treasury Benchmark 10Y",
      assetClass = AssetClass.RATES,
      primaryVenue = "Tradeweb ATS",
      currency = "USD",
      contractMultiplier = 1000.0,
      tickSize = 0.00390625, // 1/256
      lotSize = 100.0,
      couponPct = 4.25,
      maturityDate = "2034-08-15",
      durationYears = 7.82,
      dv01 = 0.078
    ),
    TradingInstrument(
      id = "IR-US02Y",
      symbol = "US02Y",
      canonicalSymbol = "T 4.125 09/26",
      name = "US Treasury Benchmark 2Y",
      assetClass = AssetClass.RATES,
      primaryVenue = "BrokerTec",
      currency = "USD",
      contractMultiplier = 1000.0,
      tickSize = 0.001953125,
      lotSize = 100.0,
      couponPct = 4.125,
      maturityDate = "2026-09-30",
      durationYears = 1.88,
      dv01 = 0.019
    ),
    TradingInstrument(
      id = "IR-US30Y",
      symbol = "US30Y",
      canonicalSymbol = "T 4.50 05/54",
      name = "US Treasury 30Y Long Bond",
      assetClass = AssetClass.RATES,
      primaryVenue = "Tradeweb ATS",
      currency = "USD",
      contractMultiplier = 1000.0,
      tickSize = 0.0078125,
      lotSize = 100.0,
      couponPct = 4.50,
      maturityDate = "2054-05-15",
      durationYears = 16.40,
      dv01 = 0.164
    ),

    // Foreign Exchange
    TradingInstrument(
      id = "FX-EURUSD",
      symbol = "EUR/USD",
      canonicalSymbol = "EURUSD.FX",
      name = "Euro / US Dollar Spot",
      assetClass = AssetClass.FX,
      primaryVenue = "Currenex ECN",
      currency = "USD",
      contractMultiplier = 100000.0,
      tickSize = 0.00001,
      lotSize = 100000.0,
      settlementConvention = "T+2"
    ),
    TradingInstrument(
      id = "FX-USDJPY",
      symbol = "USD/JPY",
      canonicalSymbol = "USDJPY.FX",
      name = "US Dollar / Japanese Yen Spot",
      assetClass = AssetClass.FX,
      primaryVenue = "EBS Prime",
      currency = "JPY",
      contractMultiplier = 100000.0,
      tickSize = 0.001,
      lotSize = 100000.0,
      settlementConvention = "T+2"
    ),
    TradingInstrument(
      id = "FX-GBPUSD",
      symbol = "GBP/USD",
      canonicalSymbol = "GBPUSD.FX",
      name = "British Pound / US Dollar Spot",
      assetClass = AssetClass.FX,
      primaryVenue = "FastMatch",
      currency = "USD",
      contractMultiplier = 100000.0,
      tickSize = 0.00001,
      lotSize = 100000.0,
      settlementConvention = "T+2"
    ),

    // Credit & Corporate Bonds
    TradingInstrument(
      id = "CR-HYG",
      symbol = "HYG",
      canonicalSymbol = "HYG.US",
      name = "iShares High Yield Corporate ETF",
      assetClass = AssetClass.CREDIT,
      primaryVenue = "NYSE Arca",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.01,
      lotSize = 1.0
    ),
    TradingInstrument(
      id = "CR-LQD",
      symbol = "LQD",
      canonicalSymbol = "LQD.US",
      name = "iShares Investment Grade Corporate",
      assetClass = AssetClass.CREDIT,
      primaryVenue = "NYSE Arca",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.01,
      lotSize = 1.0
    ),

    // Commodities & Energy
    TradingInstrument(
      id = "CM-CL",
      symbol = "CL.F",
      canonicalSymbol = "CLZ26",
      name = "WTI Crude Oil Front Futures",
      assetClass = AssetClass.COMMODITIES,
      primaryVenue = "NYMEX / CME",
      currency = "USD",
      contractMultiplier = 1000.0, // 1,000 barrels
      tickSize = 0.01,
      lotSize = 1.0,
      deliveryMonth = "DEC 2026"
    ),
    TradingInstrument(
      id = "CM-GC",
      symbol = "GC.F",
      canonicalSymbol = "GCZ26",
      name = "Gold Futures COMEX 100oz",
      assetClass = AssetClass.COMMODITIES,
      primaryVenue = "COMEX / CME",
      currency = "USD",
      contractMultiplier = 100.0,
      tickSize = 0.10,
      lotSize = 1.0,
      deliveryMonth = "DEC 2026"
    ),
    TradingInstrument(
      id = "CM-NG",
      symbol = "NG.F",
      canonicalSymbol = "NGZ26",
      name = "Henry Hub Natural Gas Front",
      assetClass = AssetClass.COMMODITIES,
      primaryVenue = "NYMEX / CME",
      currency = "USD",
      contractMultiplier = 10000.0,
      tickSize = 0.001,
      lotSize = 1.0
    ),

    // Digital Assets & Tokenized
    TradingInstrument(
      id = "DA-BTC",
      symbol = "BTC/USD",
      canonicalSymbol = "BTCUSD.CC",
      name = "Bitcoin Institutional Spot",
      assetClass = AssetClass.DIGITAL_ASSETS,
      primaryVenue = "Coinbase Prime",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.50,
      lotSize = 0.01
    ),
    TradingInstrument(
      id = "DA-ETH",
      symbol = "ETH/USD",
      canonicalSymbol = "ETHUSD.CC",
      name = "Ethereum Institutional Spot",
      assetClass = AssetClass.DIGITAL_ASSETS,
      primaryVenue = "FalconX Liquidity",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.10,
      lotSize = 0.10
    ),
    TradingInstrument(
      id = "DA-SOL",
      symbol = "SOL/USD",
      canonicalSymbol = "SOLUSD.CC",
      name = "Solana Spot Liquidity",
      assetClass = AssetClass.DIGITAL_ASSETS,
      primaryVenue = "Kraken Institutional",
      currency = "USD",
      contractMultiplier = 1.0,
      tickSize = 0.02,
      lotSize = 1.0
    ),

    // Derivatives & Options
    TradingInstrument(
      id = "DX-SPX-C5800",
      symbol = "SPX 5800C",
      canonicalSymbol = "SPXW261218C05800000",
      name = "S&P 500 Index Dec 5800 Call",
      assetClass = AssetClass.DERIVATIVES,
      primaryVenue = "Cboe Options",
      currency = "USD",
      contractMultiplier = 100.0,
      tickSize = 0.05,
      lotSize = 1.0,
      underlyingSymbol = "SPY",
      strikePrice = 5800.0,
      optionType = "CALL",
      expiryDate = "2026-12-18"
    ),
    TradingInstrument(
      id = "DX-NVDA-C140",
      symbol = "NVDA 140C",
      canonicalSymbol = "NVDA261120C00140000",
      name = "NVIDIA Nov 140.00 Call Option",
      assetClass = AssetClass.DERIVATIVES,
      primaryVenue = "Nasdaq PHLX",
      currency = "USD",
      contractMultiplier = 100.0,
      tickSize = 0.01,
      lotSize = 1.0,
      underlyingSymbol = "NVDA",
      strikePrice = 140.0,
      optionType = "CALL",
      expiryDate = "2026-11-20"
    )
  )

  fun findBySymbol(symbol: String): TradingInstrument? {
    return ALL_INSTRUMENTS.find {
      it.symbol.equals(symbol, ignoreCase = true) ||
          it.canonicalSymbol.equals(symbol, ignoreCase = true) ||
          it.id.equals(symbol, ignoreCase = true)
    }
  }

  fun filterByAssetClass(assetClass: AssetClass?): List<TradingInstrument> {
    if (assetClass == null) return ALL_INSTRUMENTS
    return ALL_INSTRUMENTS.filter { it.assetClass == assetClass }
  }

  fun search(query: String): List<TradingInstrument> {
    if (query.isBlank()) return ALL_INSTRUMENTS
    val q = query.trim().lowercase()
    return ALL_INSTRUMENTS.filter {
      it.symbol.lowercase().contains(q) ||
          it.canonicalSymbol.lowercase().contains(q) ||
          it.name.lowercase().contains(q) ||
          it.primaryVenue.lowercase().contains(q)
    }
  }
}
