package com.example.nytd.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.nytd.data.NytdDatabase
import com.example.nytd.engine.AiTradingAssistant
import com.example.nytd.engine.ConnectorFabric
import com.example.nytd.engine.DeskChatMessage
import com.example.nytd.engine.InstrumentCatalog
import com.example.nytd.engine.MarketDataSimulator
import com.example.nytd.engine.OrderManagementSystem
import com.example.nytd.engine.PortfolioEngine
import com.example.nytd.engine.QuantStrategyEngine
import com.example.nytd.engine.RiskEngine
import com.example.nytd.engine.SmartOrderRouter
import com.example.nytd.engine.SubmitOrderRequest
import com.example.nytd.model.AssetClass
import com.example.nytd.model.MarketRegime
import com.example.nytd.model.OrderEntity
import com.example.nytd.model.OrderSide
import com.example.nytd.model.OrderType
import com.example.nytd.model.StrategyTradeProposal
import com.example.nytd.model.TimeInForce
import com.example.nytd.model.TradingInstrument
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class DeskWorkspace(val displayName: String, val badge: String) {
  EQUITIES("Equities Desk", "EQ"),
  RATES("Rates & Sovereigns", "IR"),
  FX("Foreign Exchange", "FX"),
  CREDIT("Credit & Bonds", "CR"),
  COMMODITIES("Commodities Desk", "CM"),
  DIGITAL_ASSETS("Digital Assets Desk", "DA"),
  DERIVATIVES("Derivatives & Options", "DX"),
  QUANT_STUDIO("Quant Research", "QR"),
  PORTFOLIO_BLOTTER("Portfolio & Blotter", "PB"),
  EXECUTIVE_RISK("Executive Risk", "ER"),
  CONNECTOR_FABRIC("Systems Fabric", "SF")
}

class TradingDeskViewModel(application: Application) : AndroidViewModel(application) {

  private val database = NytdDatabase.getDatabase(application)
  val marketDataSimulator = MarketDataSimulator()
  val riskEngine = RiskEngine()
  val smartOrderRouter = SmartOrderRouter()
  val portfolioEngine = PortfolioEngine()
  val connectorFabric = ConnectorFabric()
  val aiTradingAssistant = AiTradingAssistant()

  val oms = OrderManagementSystem(
    riskEngine = riskEngine,
    smartOrderRouter = smartOrderRouter,
    marketDataSimulator = marketDataSimulator,
    portfolioEngine = portfolioEngine,
    orderDao = database.orderDao(),
    positionDao = database.positionDao(),
    auditDao = database.auditDao(),
    scope = viewModelScope
  )

  // Workspaces & Selected Instrument
  private val _activeWorkspace = MutableStateFlow(DeskWorkspace.EQUITIES)
  val activeWorkspace: StateFlow<DeskWorkspace> = _activeWorkspace.asStateFlow()

  private val _selectedInstrument = MutableStateFlow<TradingInstrument>(InstrumentCatalog.ALL_INSTRUMENTS.first())
  val selectedInstrument: StateFlow<TradingInstrument> = _selectedInstrument.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  // Chat / AI Assistant messages
  private val _chatMessages = MutableStateFlow<List<DeskChatMessage>>(
    listOf(
      DeskChatMessage(
        sender = "AI_ANALYST",
        text = "NEW YORK TRADING DESK OPERATING SYSTEM online. Multi-asset connectivity established across 9 external adapters. All pre-trade risk engines active. How may I assist your desk today?"
      )
    )
  )
  val chatMessages: StateFlow<List<DeskChatMessage>> = _chatMessages.asStateFlow()

  private val _isAiThinking = MutableStateFlow(false)
  val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

  // Active Proposal being routed
  private val _activeProposals = MutableStateFlow<List<StrategyTradeProposal>>(emptyList())
  val activeProposals: StateFlow<List<StrategyTradeProposal>> = _activeProposals.asStateFlow()

  // Audit Logs
  val auditLogs = database.auditDao().getRecentLogsFlow().stateIn(
    viewModelScope,
    SharingStarted.WhileSubscribed(5000),
    emptyList()
  )

  init {
    // Start market data simulation ticker
    viewModelScope.launch {
      while (isActive) {
        delay(1400L)
        marketDataSimulator.tickAllQuotes()
        portfolioEngine.updateMarketPrices(marketDataSimulator.quotes.value)
        _activeProposals.value = QuantStrategyEngine.generateProposals(marketDataSimulator.quotes.value)
      }
    }
  }

  fun switchWorkspace(workspace: DeskWorkspace) {
    _activeWorkspace.value = workspace
    // Also select a representative instrument for that workspace
    val targetAsset = when (workspace) {
      DeskWorkspace.EQUITIES -> AssetClass.EQUITIES
      DeskWorkspace.RATES -> AssetClass.RATES
      DeskWorkspace.FX -> AssetClass.FX
      DeskWorkspace.CREDIT -> AssetClass.CREDIT
      DeskWorkspace.COMMODITIES -> AssetClass.COMMODITIES
      DeskWorkspace.DIGITAL_ASSETS -> AssetClass.DIGITAL_ASSETS
      DeskWorkspace.DERIVATIVES -> AssetClass.DERIVATIVES
      else -> null
    }
    if (targetAsset != null) {
      val found = InstrumentCatalog.filterByAssetClass(targetAsset).firstOrNull()
      if (found != null) {
        _selectedInstrument.value = found
      }
    }
  }

  fun selectInstrument(instrument: TradingInstrument) {
    _selectedInstrument.value = instrument
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun setMarketRegime(regime: MarketRegime) {
    marketDataSimulator.setMarketRegime(regime)
  }

  fun submitOrder(
    symbol: String,
    side: OrderSide,
    type: OrderType,
    quantity: Double,
    price: Double?,
    stopPrice: Double?,
    timeInForce: TimeInForce,
    targetVenue: String = "SMART",
    onComplete: (OrderEntity) -> Unit = {}
  ) {
    oms.submitOrder(
      SubmitOrderRequest(
        symbol = symbol,
        side = side,
        type = type,
        quantity = quantity,
        price = price,
        stopPrice = stopPrice,
        timeInForce = timeInForce,
        targetVenue = targetVenue
      ),
      onResult = onComplete
    )
  }

  fun cancelOrder(orderId: String) {
    oms.cancelOrder(orderId)
  }

  fun emergencyKillSwitch() {
    riskEngine.setKillSwitch(true)
    oms.cancelAllOrders()
  }

  fun toggleKillSwitch() {
    val current = riskEngine.limits.value.isKillSwitchActive
    riskEngine.setKillSwitch(!current)
    if (!current) {
      oms.cancelAllOrders()
    }
  }

  fun sendAiPrompt(prompt: String) {
    if (prompt.isBlank()) return
    val userMsg = DeskChatMessage(sender = "TRADER", text = prompt)
    _chatMessages.value = _chatMessages.value + userMsg

    viewModelScope.launch {
      _isAiThinking.value = true
      val currentInst = _selectedInstrument.value
      val currentQuote = marketDataSimulator.quotes.value[currentInst.symbol]
      val rejected = oms.orders.value.firstOrNull { it.status == com.example.nytd.model.OrderStatus.REJECTED }

      val response = aiTradingAssistant.askAssistant(
        prompt = prompt,
        selectedInstrument = currentInst,
        selectedQuote = currentQuote,
        portfolio = portfolioEngine.summary.value,
        positions = portfolioEngine.positions.value.values.toList(),
        yieldCurve = marketDataSimulator.getUsYieldCurve(),
        recentRejectedOrder = rejected
      )

      _isAiThinking.value = false
      _chatMessages.value = _chatMessages.value + DeskChatMessage(
        sender = "AI_ANALYST",
        text = response,
        citedInstrument = currentInst.symbol
      )
    }
  }

  fun clearChat() {
    _chatMessages.value = emptyList()
  }
}
