package com.example.nytd.model

data class Quote(
  val symbol: String,
  val bidPrice: Double,
  val askPrice: Double,
  val bidSize: Double,
  val askSize: Double,
  val lastPrice: Double,
  val lastVolume: Double,
  val changePct: Double,
  val high24h: Double,
  val low24h: Double,
  val vwap: Double,
  val timestamp: Long,
  val sourceVenue: String,
  val isSynthetic: Boolean = true,
  val stalenessMs: Long = 12L
) {
  val midPrice: Double get() = (bidPrice + askPrice) / 2.0
  val spread: Double get() = askPrice - bidPrice
  val spreadBps: Double get() = if (midPrice > 0) (spread / midPrice) * 10000.0 else 0.0
}

data class OrderBookLevel(
  val price: Double,
  val size: Double,
  val total: Double,
  val count: Int
)

data class OrderBook(
  val symbol: String,
  val bids: List<OrderBookLevel>,
  val asks: List<OrderBookLevel>,
  val timestamp: Long
)

data class CandlestickBar(
  val timestamp: Long,
  val open: Double,
  val high: Double,
  val low: Double,
  val close: Double,
  val volume: Double
)

data class YieldCurvePoint(
  val tenor: String, // e.g. "1M", "3M", "6M", "1Y", "2Y", "5Y", "10Y", "30Y"
  val maturityYears: Double,
  val yieldPct: Double,
  val changeBps: Double
)

data class VolSurfacePoint(
  val strike: Double,
  val expiryDays: Int,
  val impliedVolPct: Double,
  val delta: Double
)

enum class MarketRegime(val label: String, val volatilityMultiplier: Double, val drift: Double) {
  NORMAL_LIQUID("Normal Liquid Market", 1.0, 0.0002),
  BULL_MOMENTUM("Bullish Risk-On Rally", 0.9, 0.0008),
  VOLATILITY_SHOCK("High Volatility Bear Shock", 2.8, -0.0009),
  FLASH_CRASH("Flash Liquidity Cascade", 4.5, -0.0035),
  LIQUIDITY_CRUNCH("Wide Spreads / Illiquid", 2.2, -0.0004)
}
