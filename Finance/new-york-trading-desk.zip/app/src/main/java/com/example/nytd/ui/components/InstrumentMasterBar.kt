package com.example.nytd.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nytd.engine.FinancialMath
import com.example.nytd.model.Quote
import com.example.nytd.model.TradingInstrument
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskCardElevated
import com.example.ui.theme.MarketGreen
import com.example.ui.theme.MarketRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

@Composable
fun InstrumentMasterBar(
  instrument: TradingInstrument,
  quote: Quote?,
  onOpenOrderTicket: () -> Unit,
  onOpenInstrumentSelector: () -> Unit,
  modifier: Modifier = Modifier
) {
  val last = quote?.lastPrice ?: 100.0
  val chg = quote?.changePct ?: 0.0
  val isPos = chg >= 0
  val chgColor = if (isPos) MarketGreen else MarketRed
  val bid = quote?.bidPrice ?: 100.0
  val ask = quote?.askPrice ?: 100.05
  val spreadBps = quote?.spreadBps ?: 1.5

  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskCard)
      .border(1.dp, DeskBorder, androidx.compose.ui.graphics.RectangleShape)
      .padding(horizontal = 10.dp, vertical = 8.dp)
  ) {
    Column {
      // Top row: Symbol, Name, Asset Class Badge, Open Search
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clickable { onOpenInstrumentSelector() }
            .testTag("instrument_picker_trigger")
        ) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(3.dp))
              .background(DeskCardElevated)
              .border(1.dp, WallStreetGold.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
              .padding(horizontal = 5.dp, vertical = 2.dp)
          ) {
            Text(
              text = instrument.assetClass.badgeCode,
              color = WallStreetGold,
              fontSize = 9.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = instrument.symbol,
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = instrument.primaryVenue,
            color = TextSecondary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.width(4.dp))
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search",
            tint = TextDim,
            modifier = Modifier.size(14.dp)
          )
        }

        // Fast Order Ticket Trigger
        Button(
          onClick = onOpenOrderTicket,
          colors = ButtonDefaults.buttonColors(containerColor = WallStreetGold, contentColor = Color.Black),
          shape = RoundedCornerShape(4.dp),
          contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier
            .testTag("open_order_ticket_button")
        ) {
          Icon(
            imageVector = Icons.Default.AddShoppingCart,
            contentDescription = null,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "ORDER TICKET",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }
      }

      // Bottom row: Live Market Quote (Bid, Ask, Last, Spread)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "$${last}",
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "${if (isPos) "+" else ""}${FinancialMath.roundMoney(chg, 2)}%",
            color = chgColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "BID ",
            color = TextDim,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            text = "$bid",
            color = MarketGreen,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "ASK ",
            color = TextDim,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            text = "$ask",
            color = MarketRed,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "SPD ",
            color = TextDim,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
          )
          Text(
            text = "${FinancialMath.roundMoney(spreadBps, 1)}bps",
            color = TextSecondary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}
