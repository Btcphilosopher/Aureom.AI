package com.example.nytd.engine

import com.example.nytd.model.CandlestickBar
import com.example.nytd.model.MarketRegime
import com.example.nytd.model.OrderBook
import com.example.nytd.model.OrderBookLevel
import com.example.nytd.model.Quote
import com.example.nytd.model.TradingInstrument
import com.example.nytd.model.VolSurfacePoint
import com.example.nytd.model.YieldCurvePoint
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sqrt
import kotlin.random.Random

private fun sampleGaussian(rng: Random): Double {
  val u1 = rng.nextDouble().coerceIn(1e-9, 1.0)
  val u2 = rng.nextDouble()
  return sqrt(-2.0 * ln(u1)) * cos(2.0 * Math.PI * u2)
}

class MarketDataSimulator {

  private val _currentRegime = MutableStateFlow(MarketRegime.NORMAL_LIQUID)
  val currentRegime: StateFlow<MarketRegime> = _currentRegime.asStateFlow()

  private val _quotes = MutableStateFlow<Map<String, Quote>>(emptyMap())
  val quotes: StateFlow<Map<String, Quote>> = _quotes.asStateFlow()

  private val basePrices = ConcurrentHashMap<String, Double>()
  private val activePrices = ConcurrentHashMap<String, Double>()
  private val candlestickHistories = ConcurrentHashMap<String, MutableList<CandlestickBar>>()

  private val rng = Random(42)

  init {
    initializePrices()
    generateInitialCandlesticks()
    tickAllQuotes()
  }

  fun setMarketRegime(regime: MarketRegime) {
    _currentRegime.value = regime
    tickAllQuotes()
  }

  private fun initializePrices() {
    val defaults = mapOf(
      "NVDA" to 142.80,
      "AAPL" to 232.50,
      "MSFT" to 428.10,
      "SPY" to 584.20,
      "QQQ" to 492.60,
      "US10Y" to 99.85,  // price corresponding to ~4.26% yield
      "US02Y" to 100.12, // price ~4.08% yield
      "US30Y" to 98.40,
      "EUR/USD" to 1.0845,
      "USD/JPY" to 152.30,
      "GBP/USD" to 1.2980,
      "HYG" to 79.40,
      "LQD" to 109.25,
      "CL.F" to 71.45,
      "GC.F" to 2738.50,
      "NG.F" to 2.45,
      "BTC/USD" to 68450.0,
      "ETH/USD" to 2540.0,
      "SOL/USD" to 175.80,
      "SPX 5800C" to 48.50,
      "NVDA 140C" to 8.20
    )
    defaults.forEach { (sym, price) ->
      basePrices[sym] = price
      activePrices[sym] = price
    }
  }

  private fun generateInitialCandlesticks() {
    val now = System.currentTimeMillis()
    val fiveMin = 5 * 60 * 1000L

    InstrumentCatalog.ALL_INSTRUMENTS.forEach { inst ->
      val base = activePrices[inst.symbol] ?: 100.0
      val bars = mutableListOf<CandlestickBar>()
      var currentClose = base * 0.96

      for (i in 30 downTo 1) {
        val barTime = now - (i * fiveMin)
        val move = (rng.nextDouble() - 0.49) * 0.008 * base
        val open = currentClose
        val close = (open + move).coerceAtLeast(0.01)
        val high = maxOf(open, close) + rng.nextDouble() * 0.004 * base
        val low = minOf(open, close) - rng.nextDouble() * 0.004 * base
        val volume = (rng.nextDouble() * 50000 + 10000) * (if (inst.symbol.contains("BTC")) 0.01 else 1.0)
        bars.add(
          CandlestickBar(
            timestamp = barTime,
            open = FinancialMath.roundMoney(open),
            high = FinancialMath.roundMoney(high),
            low = FinancialMath.roundMoney(low),
            close = FinancialMath.roundMoney(close),
            volume = FinancialMath.roundMoney(volume, 0)
          )
        )
        currentClose = close
      }
      activePrices[inst.symbol] = currentClose
      candlestickHistories[inst.symbol] = bars
    }
  }

  fun tickAllQuotes() {
    val regime = _currentRegime.value
    val newQuotes = mutableMapOf<String, Quote>()
    val now = System.currentTimeMillis()

    InstrumentCatalog.ALL_INSTRUMENTS.forEach { inst ->
      val current = activePrices[inst.symbol] ?: 100.0
      val base = basePrices[inst.symbol] ?: current

      // Volatility based on asset class & regime
      val assetVolFactor = when (inst.assetClass) {
        com.example.nytd.model.AssetClass.DIGITAL_ASSETS -> 2.5
        com.example.nytd.model.AssetClass.DERIVATIVES -> 3.0
        com.example.nytd.model.AssetClass.COMMODITIES -> 1.4
        com.example.nytd.model.AssetClass.EQUITIES -> 1.0
        com.example.nytd.model.AssetClass.CREDIT -> 0.6
        com.example.nytd.model.AssetClass.FX -> 0.4
        com.example.nytd.model.AssetClass.RATES -> 0.25
      }

      val shock = (sampleGaussian(rng) * 0.002 * regime.volatilityMultiplier * assetVolFactor) + (regime.drift * assetVolFactor)
      val newPrice = (current * (1.0 + shock)).coerceAtLeast(inst.tickSize)
      activePrices[inst.symbol] = newPrice

      // Spread model
      val spreadBps = when (regime) {
        MarketRegime.LIQUIDITY_CRUNCH -> 15.0
        MarketRegime.FLASH_CRASH -> 25.0
        MarketRegime.VOLATILITY_SHOCK -> 8.0
        else -> 1.5
      }
      val halfSpread = (newPrice * (spreadBps / 20000.0)).coerceAtLeast(inst.tickSize)
      val bid = FinancialMath.roundMoney(newPrice - halfSpread, if (inst.tickSize < 0.001) 4 else 2)
      val ask = FinancialMath.roundMoney(newPrice + halfSpread, if (inst.tickSize < 0.001) 4 else 2)

      val changePct = if (base > 0) ((newPrice - base) / base) * 100.0 else 0.0

      val quote = Quote(
        symbol = inst.symbol,
        bidPrice = bid,
        askPrice = ask,
        bidSize = FinancialMath.roundMoney(rng.nextDouble(50.0, 500.0) * inst.lotSize, 0),
        askSize = FinancialMath.roundMoney(rng.nextDouble(50.0, 500.0) * inst.lotSize, 0),
        lastPrice = FinancialMath.roundMoney(newPrice, if (inst.tickSize < 0.001) 4 else 2),
        lastVolume = FinancialMath.roundMoney(rng.nextDouble(10.0, 150.0), 0),
        changePct = FinancialMath.roundMoney(changePct, 2),
        high24h = FinancialMath.roundMoney(maxOf(base * 1.025, newPrice * 1.01)),
        low24h = FinancialMath.roundMoney(minOf(base * 0.975, newPrice * 0.99)),
        vwap = FinancialMath.roundMoney((base + newPrice) / 2.0),
        timestamp = now,
        sourceVenue = inst.primaryVenue,
        isSynthetic = true,
        stalenessMs = rng.nextLong(4, 25)
      )
      newQuotes[inst.symbol] = quote
    }

    _quotes.value = newQuotes
  }

  fun getOrderBook(symbol: String): OrderBook {
    val quote = _quotes.value[symbol] ?: Quote(
      symbol = symbol,
      bidPrice = 100.0,
      askPrice = 100.05,
      bidSize = 100.0,
      askSize = 100.0,
      lastPrice = 100.02,
      lastVolume = 50.0,
      changePct = 0.0,
      high24h = 102.0,
      low24h = 98.0,
      vwap = 100.0,
      timestamp = System.currentTimeMillis(),
      sourceVenue = "SIM"
    )

    val inst = InstrumentCatalog.findBySymbol(symbol)
    val tick = inst?.tickSize ?: 0.01

    val bids = mutableListOf<OrderBookLevel>()
    var bidAccum = 0.0
    for (i in 0 until 5) {
      val price = FinancialMath.roundMoney(quote.bidPrice - (i * tick * 2.0), 2)
      val size = FinancialMath.roundMoney((rng.nextDouble(150.0, 800.0) / (i + 1)), 0)
      bidAccum += size
      bids.add(OrderBookLevel(price = price, size = size, total = bidAccum, count = rng.nextInt(3, 14)))
    }

    val asks = mutableListOf<OrderBookLevel>()
    var askAccum = 0.0
    for (i in 0 until 5) {
      val price = FinancialMath.roundMoney(quote.askPrice + (i * tick * 2.0), 2)
      val size = FinancialMath.roundMoney((rng.nextDouble(150.0, 800.0) / (i + 1)), 0)
      askAccum += size
      asks.add(OrderBookLevel(price = price, size = size, total = askAccum, count = rng.nextInt(3, 14)))
    }

    return OrderBook(
      symbol = symbol,
      bids = bids,
      asks = asks,
      timestamp = System.currentTimeMillis()
    )
  }

  fun getCandlestickHistory(symbol: String): List<CandlestickBar> {
    return candlestickHistories[symbol] ?: emptyList()
  }

  fun getUsYieldCurve(): List<YieldCurvePoint> {
    val tenors = listOf(
      Triple("1M", 0.083, 4.62),
      Triple("3M", 0.25, 4.54),
      Triple("6M", 0.50, 4.42),
      Triple("1Y", 1.0, 4.22),
      Triple("2Y", 2.0, 4.08),
      Triple("5Y", 5.0, 4.02),
      Triple("10Y", 10.0, 4.26),
      Triple("30Y", 30.0, 4.51)
    )
    val regimeShift = when (_currentRegime.value) {
      MarketRegime.VOLATILITY_SHOCK -> -0.15 // flight to quality
      MarketRegime.FLASH_CRASH -> -0.35
      MarketRegime.BULL_MOMENTUM -> 0.08
      else -> 0.0
    }
    return tenors.map { (tenor, yrs, yield) ->
      YieldCurvePoint(
        tenor = tenor,
        maturityYears = yrs,
        yieldPct = FinancialMath.roundMoney(yield + regimeShift, 3),
        changeBps = FinancialMath.roundMoney((rng.nextDouble() - 0.5) * 4.0, 1)
      )
    }
  }

  fun getOptionVolSurface(underlying: String): List<VolSurfacePoint> {
    val strikes = listOf(5600.0, 5700.0, 5800.0, 5900.0, 6000.0)
    val expiries = listOf(7, 30, 60, 90)
    val points = mutableListOf<VolSurfacePoint>()

    strikes.forEach { strike ->
      expiries.forEach { exp ->
        val moneyness = strike / 5800.0
        // Smile curve: higher IV for OTM puts (moneyness < 1)
        val skew = (1.0 - moneyness) * 18.0
        val baseIv = 15.5 + skew + (exp * 0.04)
        points.add(
          VolSurfacePoint(
            strike = strike,
            expiryDays = exp,
            impliedVolPct = FinancialMath.roundMoney(baseIv.coerceAtLeast(8.0), 2),
            delta = FinancialMath.roundMoney((1.0 - (strike - 5600.0) / 500.0).coerceIn(0.1, 0.9), 2)
          )
        )
      }
    }
    return points
  }
}
