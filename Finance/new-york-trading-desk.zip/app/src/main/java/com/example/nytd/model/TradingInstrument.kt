package com.example.nytd.model

enum class AssetClass(val displayName: String, val badgeCode: String) {
  EQUITIES("Equities & ETFs", "EQ"),
  RATES("Rates & Sovereign Bonds", "IR"),
  FX("Foreign Exchange", "FX"),
  CREDIT("Credit & Corporate", "CR"),
  COMMODITIES("Commodities & Energy", "CM"),
  DIGITAL_ASSETS("Digital Assets & Tokens", "DA"),
  DERIVATIVES("Derivatives & Swaps", "DX")
}

data class TradingInstrument(
  val id: String,
  val symbol: String,
  val canonicalSymbol: String,
  val name: String,
  val assetClass: AssetClass,
  val primaryVenue: String,
  val currency: String = "USD",
  val contractMultiplier: Double = 1.0,
  val tickSize: Double = 0.01,
  val lotSize: Double = 1.0,
  val tradingStatus: String = "ACTIVE",
  val settlementConvention: String = "T+1",
  // Rates & Bond specific
  val couponPct: Double? = null,
  val maturityDate: String? = null,
  val durationYears: Double? = null,
  val dv01: Double? = null,
  // Derivative specific
  val underlyingSymbol: String? = null,
  val strikePrice: Double? = null,
  val optionType: String? = null, // "CALL", "PUT"
  val expiryDate: String? = null,
  // Commodities specific
  val deliveryMonth: String? = null,
  // Provider symbol mappings
  val providerSymbols: Map<String, String> = emptyMap()
)
