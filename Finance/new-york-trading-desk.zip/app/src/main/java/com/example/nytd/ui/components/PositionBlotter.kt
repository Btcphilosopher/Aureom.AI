package com.example.nytd.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nytd.engine.FinancialMath
import com.example.nytd.model.OrderSide
import com.example.nytd.model.PortfolioSummary
import com.example.nytd.model.Position
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskCardElevated
import com.example.ui.theme.DeskMidnight
import com.example.ui.theme.MarketGreen
import com.example.ui.theme.MarketRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

@Composable
fun PositionBlotter(
  positions: List<Position>,
  summary: PortfolioSummary,
  onFlattenPosition: (Position) -> Unit,
  modifier: Modifier = Modifier
) {
  val activePositions = positions.filter { it.quantity != 0.0 }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "PORTFOLIO & POSITIONS (${activePositions.size})",
        color = WallStreetGold,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
      Text(
        text = "Gross: $${FinancialMath.roundMoney(summary.grossExposureUsd)} | Lev: ${summary.leverageRatio}x",
        color = TextSecondary,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Position Rows
    if (activePositions.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(110.dp),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "No open positions. Use Order Ticket to establish inventory.",
          color = TextDim,
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .height(170.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        items(activePositions) { pos ->
          val isPos = pos.unrealizedPnL >= 0
          val pnlColor = if (isPos) MarketGreen else MarketRed

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(3.dp))
              .background(DeskCard)
              .border(1.dp, DeskBorder, RoundedCornerShape(3.dp))
              .padding(horizontal = 8.dp, vertical = 6.dp)
              .testTag("position_row_${pos.symbol}")
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              // Left: Symbol, Side, Size, Entry
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = if (pos.isLong) "LONG" else "SHORT",
                    color = if (pos.isLong) MarketGreen else MarketRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = pos.symbol,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "${pos.quantity.toInt()} units",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }
                Text(
                  text = "Entry: $${pos.avgEntryPrice} • Current: $${pos.currentPrice} • Notional: $${FinancialMath.roundMoney(pos.notionalValue)}",
                  color = TextDim,
                  fontSize = 9.sp,
                  fontFamily = FontFamily.Monospace
                )
              }

              // Right: Unrealized P&L & Flatten button
              Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = "${if (isPos) "+" else ""}$${FinancialMath.roundMoney(pos.unrealizedPnL)}",
                    color = pnlColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                  )
                  Text(
                    text = "${if (isPos) "+" else ""}${FinancialMath.roundMoney(pos.unrealizedPnLPct, 2)}%",
                    color = pnlColor,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }

                Spacer(modifier = Modifier.width(6.dp))
                Button(
                  onClick = { onFlattenPosition(pos) },
                  colors = ButtonDefaults.buttonColors(containerColor = DeskCardElevated, contentColor = TextPrimary),
                  shape = RoundedCornerShape(3.dp),
                  contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                  modifier = Modifier.testTag("flatten_${pos.symbol}")
                ) {
                  Text("CLOSE", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
              }
            }
          }
        }
      }
    }
  }
}
