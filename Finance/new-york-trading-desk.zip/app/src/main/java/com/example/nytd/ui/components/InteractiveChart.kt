package com.example.nytd.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nytd.engine.FinancialMath
import com.example.nytd.model.CandlestickBar
import com.example.nytd.model.OrderBook
import com.example.ui.theme.DeskBlack
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskCardElevated
import com.example.ui.theme.MarketGreen
import com.example.ui.theme.MarketRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

enum class ChartDisplayMode(val label: String) {
  CANDLESTICK("Candlesticks"),
  ORDER_BOOK_DEPTH("L2 Depth Ladder"),
  TECHNICALS("Technicals (SMA/RSI)")
}

@Composable
fun InteractiveChart(
  bars: List<CandlestickBar>,
  orderBook: OrderBook,
  currentPrice: Double,
  modifier: Modifier = Modifier
) {
  var selectedMode by remember { mutableStateOf(ChartDisplayMode.CANDLESTICK) }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskBlack)
      .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
  ) {
    // Top Bar: Chart mode selector
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 6.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        ChartDisplayMode.entries.forEach { mode ->
          val isSel = mode == selectedMode
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(3.dp))
              .background(if (isSel) WallStreetGold else DeskCard)
              .border(1.dp, if (isSel) WallStreetGold else DeskBorder, RoundedCornerShape(3.dp))
              .clickable { selectedMode = mode }
              .padding(horizontal = 6.dp, vertical = 3.dp)
              .testTag("chart_mode_${mode.name.lowercase()}")
          ) {
            Text(
              text = mode.label,
              color = if (isSel) Color.Black else TextSecondary,
              fontSize = 9.sp,
              fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }

      Text(
        text = "5M BAR • SYNTHETIC NBBO",
        color = TextDim,
        fontSize = 8.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    // Chart Canvas or Depth Ladder
    when (selectedMode) {
      ChartDisplayMode.CANDLESTICK, ChartDisplayMode.TECHNICALS -> {
        CandlestickCanvas(
          bars = bars,
          currentPrice = currentPrice,
          showTechnicals = selectedMode == ChartDisplayMode.TECHNICALS,
          modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
        )
      }
      ChartDisplayMode.ORDER_BOOK_DEPTH -> {
        OrderBookDepthLadder(
          orderBook = orderBook,
          modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
        )
      }
    }
  }
}

@Composable
private fun CandlestickCanvas(
  bars: List<CandlestickBar>,
  currentPrice: Double,
  showTechnicals: Boolean,
  modifier: Modifier = Modifier
) {
  if (bars.isEmpty()) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
      Text("Ingesting real-time tick stream...", color = TextSecondary, fontSize = 11.sp)
    }
    return
  }

  val minPrice = remember(bars) { bars.minOfOrNull { it.low }?.times(0.998) ?: 95.0 }
  val maxPrice = remember(bars) { bars.maxOfOrNull { it.high }?.times(1.002) ?: 105.0 }
  val priceRange = (maxPrice - minPrice).coerceAtLeast(0.1)

  Canvas(modifier = modifier.testTag("candlestick_canvas")) {
    val canvasWidth = size.width
    val canvasHeight = size.height
    val volumeHeight = canvasHeight * 0.22f
    val priceHeight = canvasHeight - volumeHeight

    // Draw horizontal grid lines
    val gridCount = 4
    for (i in 0..gridCount) {
      val y = (priceHeight / gridCount) * i
      drawLine(
        color = Color(0xFF182337),
        start = Offset(0f, y),
        end = Offset(canvasWidth, y),
        strokeWidth = 1f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
      )
    }

    // Draw candles
    val count = bars.size
    val barSlotWidth = canvasWidth / count.toFloat()
    val candleWidth = (barSlotWidth * 0.65f).coerceAtLeast(2f)

    bars.forEachIndexed { index, bar ->
      val x = (index * barSlotWidth) + (barSlotWidth / 2f)
      val isBullish = bar.close >= bar.open
      val candleColor = if (isBullish) MarketGreen else MarketRed

      val highY = priceHeight - (((bar.high - minPrice) / priceRange) * priceHeight).toFloat()
      val lowY = priceHeight - (((bar.low - minPrice) / priceRange) * priceHeight).toFloat()
      val openY = priceHeight - (((bar.open - minPrice) / priceRange) * priceHeight).toFloat()
      val closeY = priceHeight - (((bar.close - minPrice) / priceRange) * priceHeight).toFloat()

      // Wick
      drawLine(
        color = candleColor,
        start = Offset(x, highY),
        end = Offset(x, lowY),
        strokeWidth = 1.5f
      )

      // Body
      val topY = minOf(openY, closeY)
      val bodyHeight = kotlin.math.abs(closeY - openY).coerceAtLeast(1.5f)
      drawRect(
        color = candleColor,
        topLeft = Offset(x - (candleWidth / 2f), topY),
        size = Size(candleWidth, bodyHeight)
      )

      // Volume bar
      val maxVol = bars.maxOfOrNull { it.volume } ?: 10000.0
      val volHeightRatio = (bar.volume / maxVol).toFloat().coerceIn(0.05f, 1.0f)
      val vHeight = volumeHeight * volHeightRatio
      drawRect(
        color = candleColor.copy(alpha = 0.35f),
        topLeft = Offset(x - (candleWidth / 2f), canvasHeight - vHeight),
        size = Size(candleWidth, vHeight)
      )
    }

    // Last price line in gold
    val lastY = priceHeight - (((currentPrice - minPrice) / priceRange) * priceHeight).toFloat()
    if (lastY in 0f..priceHeight) {
      drawLine(
        color = WallStreetGold,
        start = Offset(0f, lastY),
        end = Offset(canvasWidth, lastY),
        strokeWidth = 1.2f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 4f), 0f)
      )
    }
  }
}

@Composable
private fun OrderBookDepthLadder(
  orderBook: OrderBook,
  modifier: Modifier = Modifier
) {
  val maxBidTotal = orderBook.bids.maxOfOrNull { it.total } ?: 1000.0
  val maxAskTotal = orderBook.asks.maxOfOrNull { it.total } ?: 1000.0
  val maxTotal = maxOf(maxBidTotal, maxAskTotal).coerceAtLeast(10.0)

  Column(
    modifier = modifier
      .background(DeskCardElevated)
      .padding(6.dp),
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("BID DEPTH (BUY)", color = MarketGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      Text("ASK DEPTH (SELL)", color = MarketRed, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }

    // Top 5 levels side by side
    for (i in 0 until 5) {
      val bid = orderBook.bids.getOrNull(i)
      val ask = orderBook.asks.getOrNull(i)

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Bid side (left)
        if (bid != null) {
          Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("${bid.price}", color = MarketGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("${bid.size.toInt()} (${bid.count})", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
          }
        } else {
          Spacer(modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.width(16.dp))

        // Ask side (right)
        if (ask != null) {
          Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("${ask.size.toInt()} (${ask.count})", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text("${ask.price}", color = MarketRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
          }
        } else {
          Spacer(modifier = Modifier.weight(1f))
        }
      }
    }

    Text(
      text = "L2 AGGREGATED DEPTH • DIRECT FIX 4.4 STREAM",
      color = TextDim,
      fontSize = 8.sp,
      fontFamily = FontFamily.Monospace,
      modifier = Modifier.align(Alignment.CenterHorizontally)
    )
  }
}
