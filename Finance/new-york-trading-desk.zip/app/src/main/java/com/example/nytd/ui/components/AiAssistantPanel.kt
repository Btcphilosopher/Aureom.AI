package com.example.nytd.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nytd.engine.DeskChatMessage
import com.example.ui.theme.DeskBlack
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskCardElevated
import com.example.ui.theme.DeskMidnight
import com.example.ui.theme.MarketGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

@Composable
fun AiAssistantPanel(
  messages: List<DeskChatMessage>,
  isThinking: Boolean,
  onSendPrompt: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var inputText by remember { mutableStateOf("") }
  val listState = rememberLazyListState()

  val promptChips = listOf(
    "Explain Option Greeks",
    "Analyze Portfolio Risk & VaR",
    "Review Yield Curve Shifts",
    "Diagnose Rejected Orders",
    "Generate Python Cointegration Script",
    "Desk Trade Ideas"
  )

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
      .padding(8.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = WallStreetGold,
          modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "AI TRADING DESK STRATEGIST",
          color = WallStreetGold,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
      }
      Text(
        text = "GEMINI 3.8 / QUANT LLM",
        color = TextDim,
        fontSize = 8.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Quick Prompt Chips
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(4.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(promptChips) { chip ->
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(DeskCard)
            .border(1.dp, DeskBorder, RoundedCornerShape(3.dp))
            .clickable { onSendPrompt(chip) }
            .padding(horizontal = 6.dp, vertical = 3.dp)
            .testTag("ai_chip_${chip.take(8).lowercase().replace(' ', '_')}")
        ) {
          Text(
            text = chip,
            color = TextSecondary,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Chat Message Log
    LazyColumn(
      state = listState,
      modifier = Modifier
        .fillMaxWidth()
        .height(160.dp)
        .background(DeskBlack)
        .border(1.dp, DeskBorder, RoundedCornerShape(3.dp))
        .padding(6.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      items(messages) { msg ->
        val isUser = msg.sender == "TRADER"
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(3.dp))
            .background(if (isUser) DeskCardElevated else DeskCard)
            .padding(6.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = if (isUser) "TRADER DESK" else "QUANT STRATEGIST",
              color = if (isUser) WallStreetGold else MarketGreen,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
            if (msg.citedInstrument != null) {
              Text(
                text = "Ref: ${msg.citedInstrument}",
                color = TextDim,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = msg.text,
            color = TextPrimary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 14.sp
          )
        }
      }

      if (isThinking) {
        item {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(4.dp)
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(10.dp),
              color = WallStreetGold,
              strokeWidth = 1.5.dp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Evaluating market factors and pricing models...",
              color = TextSecondary,
              fontSize = 9.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Input row
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      OutlinedTextField(
        value = inputText,
        onValueChange = { inputText = it },
        placeholder = { Text("Ask quant question or command...", fontSize = 10.sp, color = TextDim, fontFamily = FontFamily.Monospace) },
        colors = OutlinedTextFieldDefaults.colors(
          focusedTextColor = TextPrimary,
          unfocusedTextColor = TextPrimary,
          focusedBorderColor = WallStreetGold,
          unfocusedBorderColor = DeskBorder,
          focusedContainerColor = DeskBlack,
          unfocusedContainerColor = DeskBlack
        ),
        modifier = Modifier
          .weight(1f)
          .testTag("ai_assistant_input")
      )
      Spacer(modifier = Modifier.width(6.dp))
      IconButton(
        onClick = {
          if (inputText.isNotBlank()) {
            onSendPrompt(inputText)
            inputText = ""
          }
        },
        modifier = Modifier
          .clip(RoundedCornerShape(4.dp))
          .background(WallStreetGold)
          .size(40.dp)
          .testTag("ai_assistant_send_button")
      ) {
        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.Black, modifier = Modifier.size(16.dp))
      }
    }
  }
}
