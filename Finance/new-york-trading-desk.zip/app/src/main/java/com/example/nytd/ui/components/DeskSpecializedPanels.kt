package com.example.nytd.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nytd.engine.FinancialMath
import com.example.nytd.engine.QuantStrategyEngine
import com.example.nytd.model.ConnectorInfo
import com.example.nytd.model.ConnectorState
import com.example.nytd.model.RiskLimits
import com.example.nytd.model.StrategyTradeProposal
import com.example.nytd.model.YieldCurvePoint
import com.example.ui.theme.DeskBlack
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskCardElevated
import com.example.ui.theme.DeskMidnight
import com.example.ui.theme.MarketGreen
import com.example.ui.theme.MarketRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

@Composable
fun RatesDeskPanel(
  yieldCurve: List<YieldCurvePoint>,
  onSelectTenor: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val y2 = yieldCurve.find { it.tenor == "2Y" }?.yieldPct ?: 4.08
  val y10 = yieldCurve.find { it.tenor == "10Y" }?.yieldPct ?: 4.26
  val spread = (y10 - y2) * 100.0

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
      .padding(10.dp)
  ) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("US SOVEREIGN YIELD CURVE", color = WallStreetGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      Text("2s10s Spread: ${FinancialMath.roundMoney(spread, 1)} bps", color = if (spread > 0) MarketGreen else MarketRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
    Text("Active Treasury Benchmark Rates & Duration Risk", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)

    Spacer(modifier = Modifier.height(8.dp))

    // Tenor Ladder
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      yieldCurve.forEach { pt ->
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(DeskCard)
            .clickable { onSelectTenor(pt.tenor) }
            .padding(horizontal = 4.dp, vertical = 6.dp)
        ) {
          Text(pt.tenor, color = WallStreetGold, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
          Text("${pt.yieldPct}%", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
          Text("${if (pt.changeBps >= 0) "+" else ""}${pt.changeBps}", color = if (pt.changeBps >= 0) MarketGreen else MarketRed, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(DeskCardElevated)
        .padding(8.dp)
    ) {
      Text(
        text = "10Y BENCHMARK DURATION: 7.82 YRS • DV01: $0.078 per $1,000 Par • CONVEXITY: 0.88 • FED DISCOUNT: 4.75%",
        color = TextDim,
        fontSize = 8.sp,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}

@Composable
fun DerivativesDeskPanel(
  spotPrice: Double = 5840.0,
  modifier: Modifier = Modifier
) {
  var selectedStrike by remember { mutableStateOf(5800.0) }
  var isCall by remember { mutableStateOf(true) }

  val greeks = remember(selectedStrike, isCall, spotPrice) {
    FinancialMath.calculateBlackScholes(
      isCall = isCall,
      spotPrice = spotPrice,
      strikePrice = selectedStrike,
      timeYears = 0.15,
      volatility = 0.165
    )
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
      .padding(10.dp)
  ) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("BLACK-SCHOLES DERIVATIVES PRICING", color = WallStreetGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      Text("SPX Spot: $$spotPrice", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Call / Put Toggle & Strike Picker
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(3.dp))
          .background(if (isCall) MarketGreen else DeskCard)
          .clickable { isCall = true }
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Text("CALL", color = if (isCall) Color.Black else TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(3.dp))
          .background(if (!isCall) MarketRed else DeskCard)
          .clickable { isCall = false }
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Text("PUT", color = if (!isCall) Color.White else TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }

      listOf(5700.0, 5800.0, 5900.0).forEach { s ->
        val isSel = s == selectedStrike
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(if (isSel) WallStreetGold else DeskCard)
          .clickable { selectedStrike = s }
          .padding(horizontal = 6.dp, vertical = 4.dp)
        ) {
          Text("$${s.toInt()}", color = if (isSel) Color.Black else TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Greeks Grid
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Column {
        Text("Theoretical Price", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("$${greeks.price}", color = WallStreetGold, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Column {
        Text("Delta (Δ)", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("${greeks.delta}", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Column {
        Text("Gamma (Γ)", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("${greeks.gamma}", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
      }
      Column {
        Text("Vega (ν)", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("$${greeks.vega}", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
      }
      Column {
        Text("Theta (θ)", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("$${greeks.theta}/d", color = MarketRed, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
      }
    }
  }
}

@Composable
fun QuantStudioPanel(
  proposals: List<StrategyTradeProposal>,
  onExecuteProposal: (StrategyTradeProposal) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedStrategyId by remember { mutableStateOf("STRAT-MR-01") }
  val metrics = remember(selectedStrategyId) { QuantStrategyEngine.runBacktest(selectedStrategyId) }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
      .padding(10.dp)
  ) {
    Text("QUANTITATIVE RESEARCH STUDIO (R & PYTHON ENGINE)", color = WallStreetGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    Text("Backtested Factor Models & Algorithmic Strategy Proposals", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)

    Spacer(modifier = Modifier.height(8.dp))

    // Strategy selector
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
      QuantStrategyEngine.STRATEGIES.take(3).forEach { strat ->
        val isSel = strat.id == selectedStrategyId
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(3.dp))
            .background(if (isSel) WallStreetGold else DeskCard)
            .clickable { selectedStrategyId = strat.id }
            .padding(horizontal = 4.dp, vertical = 4.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(strat.name.take(16), color = if (isSel) Color.Black else TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Backtest Scorecard
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Column {
        Text("CAGR", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("${metrics.cagrPct}%", color = MarketGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Column {
        Text("Sharpe Ratio", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("${metrics.sharpeRatio}", color = WallStreetGold, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Column {
        Text("Max Drawdown", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("-${metrics.maxDrawdownPct}%", color = MarketRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Column {
        Text("Win Rate", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("${metrics.winRatePct}%", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Text("ALGORITHMIC TRADE PROPOSALS", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 4.dp)) {
      proposals.take(2).forEach { prop ->
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(3.dp))
            .background(DeskCard)
            .border(1.dp, DeskBorder, RoundedCornerShape(3.dp))
            .padding(6.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("${prop.strategyName}: ${prop.side.name} ${prop.suggestedQuantity.toInt()} ${prop.symbol} @ $${prop.limitPrice}", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
              Text(prop.quantitativeRationale, color = TextDim, fontSize = 8.sp, fontFamily = FontFamily.Monospace, maxLines = 2)
            }
            Spacer(modifier = Modifier.width(6.dp))
            Button(
              onClick = { onExecuteProposal(prop) },
              colors = ButtonDefaults.buttonColors(containerColor = WallStreetGold, contentColor = Color.Black),
              shape = RoundedCornerShape(3.dp),
              contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text("TRANSMIT", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
          }
        }
      }
    }
  }
}

@Composable
fun ConnectorFabricPanel(
  connectors: List<ConnectorInfo>,
  onToggleConnector: (String) -> Unit,
  onTestConnection: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
      .padding(10.dp)
  ) {
    Text("UNIFIED TRADING CONNECTIVITY FABRIC", color = WallStreetGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    Text("Standardized External Software Adapters & API Gateways", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)

    Spacer(modifier = Modifier.height(8.dp))

    LazyColumn(modifier = Modifier.height(220.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
      items(connectors) { conn ->
        val isOnline = conn.state == ConnectorState.ONLINE
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(3.dp))
            .background(DeskCard)
            .border(1.dp, DeskBorder, RoundedCornerShape(3.dp))
            .padding(6.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (isOnline) MarketGreen else MarketRed)
                    .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                  Text(conn.state.name, color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(conn.name, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
              }
              Text("${conn.providerOrVenue} • Latency: ${conn.latencyMs}ms • Load: ${conn.rateLimitPct}%", color = TextDim, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }

            Row {
              Button(
                onClick = { onTestConnection(conn.id) },
                colors = ButtonDefaults.buttonColors(containerColor = DeskCardElevated, contentColor = TextPrimary),
                shape = RoundedCornerShape(2.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text("PING", fontSize = 8.sp, fontFamily = FontFamily.Monospace)
              }
              Spacer(modifier = Modifier.width(4.dp))
              Button(
                onClick = { onToggleConnector(conn.id) },
                colors = ButtonDefaults.buttonColors(containerColor = if (isOnline) MarketRed.copy(alpha = 0.2f) else MarketGreen.copy(alpha = 0.2f), contentColor = if (isOnline) MarketRed else MarketGreen),
                shape = RoundedCornerShape(2.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(if (isOnline) "DISCONNECT" else "CONNECT", fontSize = 8.sp, fontFamily = FontFamily.Monospace)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun RiskExecutivePanel(
  limits: RiskLimits,
  isKillSwitchActive: Boolean,
  onToggleKillSwitch: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(DeskMidnight)
      .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
      .padding(10.dp)
  ) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("EXECUTIVE RISK CONTROL CENTER", color = WallStreetGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      Button(
        onClick = onToggleKillSwitch,
        colors = ButtonDefaults.buttonColors(containerColor = if (isKillSwitchActive) MarketGreen else MarketRed, contentColor = Color.White),
        shape = RoundedCornerShape(3.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
      ) {
        Text(if (isKillSwitchActive) "RESUME TRADING" else "ENGAGE KILL SWITCH", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Pre-trade rules summary
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Max Order Notional Hard Ceiling", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text("$${FinancialMath.roundMoney(limits.maxOrderNotionalUsd)}", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Max Position Exposure Ceiling", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text("$${FinancialMath.roundMoney(limits.maxPositionNotionalUsd)}", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Gross Leverage Hard Ceiling", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text("${limits.maxGrossLeverage}x NAV", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Cumulative Daily Loss Limit", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text("$${FinancialMath.roundMoney(limits.dailyLossLimitUsd)}", color = MarketRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Max Single Asset Concentration", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text("${limits.maxSingleAssetConcentrationPct}% NAV", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
      }
    }
  }
}
