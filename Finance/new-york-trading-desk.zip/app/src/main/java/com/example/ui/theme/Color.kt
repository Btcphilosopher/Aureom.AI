package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// New York Wall Street Institutional Palette
val DeskBlack = Color(0xFF070A11)
val DeskMidnight = Color(0xFF0C121D)
val DeskCard = Color(0xFF131B2A)
val DeskCardElevated = Color(0xFF182337)
val DeskCardHighlight = Color(0xFF1F2D46)
val DeskBorder = Color(0xFF24334E)
val DeskBorderSubtle = Color(0xFF1B283E)

// Accents & Typography
val WallStreetGold = Color(0xFFE5C158)
val WallStreetGoldDim = Color(0xFFB89332)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val TextDim = Color(0xFF475569)

// Market Data Financial Colors
val MarketGreen = Color(0xFF10B981)
val MarketGreenBg = Color(0xFF063321)
val MarketRed = Color(0xFFF43F5E)
val MarketRedBg = Color(0xFF3B121B)
val MarketAmber = Color(0xFFF59E0B)
val MarketCyan = Color(0xFF06B6D4)
val MarketPurple = Color(0xFFA855F7)
val MarketBlue = Color(0xFF3B82F6)
