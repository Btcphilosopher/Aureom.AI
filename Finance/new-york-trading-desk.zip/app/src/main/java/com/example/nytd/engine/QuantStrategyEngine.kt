package com.example.nytd.engine

import com.example.nytd.model.AssetClass
import com.example.nytd.model.BacktestMetrics
import com.example.nytd.model.OrderSide
import com.example.nytd.model.OrderType
import com.example.nytd.model.StrategyCategory
import com.example.nytd.model.StrategyDefinition
import com.example.nytd.model.StrategyTradeProposal

object QuantStrategyEngine {

  val STRATEGIES: List<StrategyDefinition> = listOf(
    StrategyDefinition(
      id = "STRAT-MR-01",
      name = "Statistical Mean Reversion Z-2.2",
      category = StrategyCategory.MEAN_REVERSION,
      targetAssetClass = AssetClass.EQUITIES,
      description = "Identifies short-term intraday price overextension beyond 2.2 standard deviations from 20-day VWAP band.",
      targetSymbols = listOf("NVDA", "AAPL", "MSFT"),
      lookbackPeriodDays = 20,
      entryThresholdZScore = 2.2,
      stopLossPct = 1.8,
      takeProfitPct = 3.5,
      isActive = true
    ),
    StrategyDefinition(
      id = "STRAT-TREND-02",
      name = "Dual Moving Average Momentum",
      category = StrategyCategory.MOMENTUM_TREND,
      targetAssetClass = AssetClass.DIGITAL_ASSETS,
      description = "Fast/slow exponential trend filter capturing macro breakout regimes on liquid digital assets.",
      targetSymbols = listOf("BTC/USD", "ETH/USD", "SOL/USD"),
      lookbackPeriodDays = 50,
      entryThresholdZScore = 1.5,
      stopLossPct = 3.0,
      takeProfitPct = 8.5,
      isActive = true
    ),
    StrategyDefinition(
      id = "STRAT-PAIR-03",
      name = "Index Cointegration Stat Arb",
      category = StrategyCategory.STAT_ARB,
      targetAssetClass = AssetClass.EQUITIES,
      description = "Pairs trading on normalized log-spread of SPY vs QQQ with Kalman-filtered hedge ratio.",
      targetSymbols = listOf("SPY", "QQQ"),
      lookbackPeriodDays = 60,
      entryThresholdZScore = 2.0,
      stopLossPct = 1.2,
      takeProfitPct = 2.4,
      isActive = false
    ),
    StrategyDefinition(
      id = "STRAT-VOL-04",
      name = "Delta-Neutral Volatility Surface Arb",
      category = StrategyCategory.VOLATILITY_ARBITRAGE,
      targetAssetClass = AssetClass.DERIVATIVES,
      description = "Exploits implied vs realized volatility spread through automated gamma scalping and vega hedging.",
      targetSymbols = listOf("SPX 5800C", "NVDA 140C"),
      lookbackPeriodDays = 30,
      entryThresholdZScore = 1.8,
      stopLossPct = 2.5,
      takeProfitPct = 5.0,
      isActive = false
    ),
    StrategyDefinition(
      id = "STRAT-RATES-05",
      name = "Treasury Curve 2Y/10Y Steepener",
      category = StrategyCategory.RATES_CURVE_CARRY,
      targetAssetClass = AssetClass.RATES,
      description = "Duration-weighted spread trade capitalizing on yield curve re-steepening with positive roll-down carry.",
      targetSymbols = listOf("US02Y", "US10Y"),
      lookbackPeriodDays = 90,
      entryThresholdZScore = 1.9,
      stopLossPct = 0.8,
      takeProfitPct = 2.0,
      isActive = true
    )
  )

  fun runBacktest(strategyId: String): BacktestMetrics {
    return when (strategyId) {
      "STRAT-MR-01" -> BacktestMetrics(
        strategyId = strategyId,
        period = "2024-2026 (2Y In-Sample + Out-of-Sample)",
        cagrPct = 24.8,
        sharpeRatio = 2.14,
        sortinoRatio = 3.08,
        maxDrawdownPct = 6.4,
        winRatePct = 68.2,
        totalTrades = 428,
        profitFactor = 1.88,
        equityCurve = listOf(100.0, 102.4, 101.8, 105.2, 108.6, 107.1, 112.4, 116.8, 115.2, 121.5, 124.8)
      )
      "STRAT-TREND-02" -> BacktestMetrics(
        strategyId = strategyId,
        period = "2024-2026",
        cagrPct = 42.1,
        sharpeRatio = 1.85,
        sortinoRatio = 2.62,
        maxDrawdownPct = 14.2,
        winRatePct = 54.6,
        totalTrades = 186,
        profitFactor = 2.25,
        equityCurve = listOf(100.0, 106.2, 104.1, 115.8, 122.4, 118.0, 131.2, 139.5, 134.0, 142.1)
      )
      "STRAT-RATES-05" -> BacktestMetrics(
        strategyId = strategyId,
        period = "2024-2026",
        cagrPct = 14.6,
        sharpeRatio = 2.45,
        sortinoRatio = 3.80,
        maxDrawdownPct = 3.2,
        winRatePct = 74.0,
        totalTrades = 94,
        profitFactor = 2.10,
        equityCurve = listOf(100.0, 101.2, 102.5, 103.8, 105.1, 106.7, 108.4, 110.2, 112.5, 114.6)
      )
      else -> BacktestMetrics(
        strategyId = strategyId,
        period = "2024-2026",
        cagrPct = 18.2,
        sharpeRatio = 1.92,
        sortinoRatio = 2.70,
        maxDrawdownPct = 8.5,
        winRatePct = 61.4,
        totalTrades = 240,
        profitFactor = 1.75,
        equityCurve = listOf(100.0, 103.0, 102.5, 106.0, 109.0, 112.0, 115.5, 118.2)
      )
    }
  }

  fun generateProposals(quotes: Map<String, com.example.nytd.model.Quote>): List<StrategyTradeProposal> {
    val nvdaQuote = quotes["NVDA"]
    val btcQuote = quotes["BTC/USD"]
    val spyQuote = quotes["SPY"]
    val t10Quote = quotes["US10Y"]

    val list = mutableListOf<StrategyTradeProposal>()

    if (nvdaQuote != null) {
      list.add(
        StrategyTradeProposal(
          id = "PROP-01",
          strategyName = "Mean Reversion Z-2.2",
          symbol = "NVDA",
          side = OrderSide.BUY,
          orderType = OrderType.LIMIT,
          suggestedQuantity = 500.0,
          limitPrice = FinancialMath.roundMoney(nvdaQuote.bidPrice * 0.995),
          stopLoss = FinancialMath.roundMoney(nvdaQuote.bidPrice * 0.975),
          takeProfit = FinancialMath.roundMoney(nvdaQuote.bidPrice * 1.035),
          confidenceScore = 84.5,
          quantitativeRationale = "NVDA dipped to -2.35 sigma below 20D VWAP with positive RSI divergence (32.4). High statistical probability of mean-reversion."
        )
      )
    }

    if (btcQuote != null) {
      list.add(
        StrategyTradeProposal(
          id = "PROP-02",
          strategyName = "Trend Momentum Filter",
          symbol = "BTC/USD",
          side = OrderSide.BUY,
          orderType = OrderType.LIMIT,
          suggestedQuantity = 5.0,
          limitPrice = FinancialMath.roundMoney(btcQuote.bidPrice),
          stopLoss = FinancialMath.roundMoney(btcQuote.bidPrice * 0.965),
          takeProfit = FinancialMath.roundMoney(btcQuote.bidPrice * 1.07),
          confidenceScore = 88.0,
          quantitativeRationale = "BTC 12/26 EMA golden cross on 4H chart with rising on-chain prime liquidity and positive funding rate."
        )
      )
    }

    if (t10Quote != null) {
      list.add(
        StrategyTradeProposal(
          id = "PROP-03",
          strategyName = "Treasury Curve Carry",
          symbol = "US10Y",
          side = OrderSide.BUY,
          orderType = OrderType.LIMIT,
          suggestedQuantity = 100.0,
          limitPrice = FinancialMath.roundMoney(t10Quote.bidPrice),
          stopLoss = FinancialMath.roundMoney(t10Quote.bidPrice * 0.99),
          takeProfit = FinancialMath.roundMoney(t10Quote.bidPrice * 1.02),
          confidenceScore = 79.0,
          quantitativeRationale = "10Y sovereign yield premium vs 2Y offers attractive positive roll-down carry with low historical spread volatility."
        )
      )
    }

    return list
  }
}
