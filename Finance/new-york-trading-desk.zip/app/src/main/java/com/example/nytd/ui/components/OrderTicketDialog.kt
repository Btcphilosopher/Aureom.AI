package com.example.nytd.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.nytd.engine.FinancialMath
import com.example.nytd.model.OrderEntity
import com.example.nytd.model.OrderSide
import com.example.nytd.model.OrderType
import com.example.nytd.model.PortfolioSummary
import com.example.nytd.model.Quote
import com.example.nytd.model.TimeInForce
import com.example.nytd.model.TradingInstrument
import com.example.ui.theme.DeskBlack
import com.example.ui.theme.DeskBorder
import com.example.ui.theme.DeskCard
import com.example.ui.theme.DeskCardElevated
import com.example.ui.theme.DeskMidnight
import com.example.ui.theme.MarketAmber
import com.example.ui.theme.MarketGreen
import com.example.ui.theme.MarketRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WallStreetGold

@Composable
fun OrderTicketDialog(
  instrument: TradingInstrument,
  quote: Quote?,
  portfolio: PortfolioSummary,
  onDismiss: () -> Unit,
  onSubmitOrder: (OrderSide, OrderType, Double, Double?, Double?, TimeInForce, String, (OrderEntity) -> Unit) -> Unit
) {
  var selectedSide by remember { mutableStateOf(OrderSide.BUY) }
  var selectedType by remember { mutableStateOf(OrderType.LIMIT) }
  var selectedTif by remember { mutableStateOf(TimeInForce.DAY) }
  var selectedVenue by remember { mutableStateOf("SMART") }

  val defaultPrice = quote?.askPrice ?: 100.0
  var quantityText by remember { mutableStateOf("100") }
  var priceText by remember { mutableStateOf(defaultPrice.toString()) }
  var stopPriceText by remember { mutableStateOf("") }
  var isConfirming by remember { mutableStateOf(false) }
  var submissionResult by remember { mutableStateOf<OrderEntity?>(null) }

  val quantity = quantityText.toDoubleOrNull() ?: 0.0
  val limitPrice = priceText.toDoubleOrNull()
  val stopPrice = stopPriceText.toDoubleOrNull()
  val multiplier = instrument.contractMultiplier
  val effectivePrice = if (selectedType == OrderType.MARKET) (if (selectedSide == OrderSide.BUY) quote?.askPrice ?: 100.0 else quote?.bidPrice ?: 100.0) else (limitPrice ?: defaultPrice)
  val estimatedNotional = quantity * effectivePrice * multiplier
  val estimatedMargin = estimatedNotional * 0.25
  val estimatedFee = estimatedNotional * 0.00008

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(4.dp)
        .testTag("order_ticket_card"),
      colors = CardDefaults.cardColors(containerColor = DeskMidnight),
      border = androidx.compose.foundation.BorderStroke(1.dp, DeskBorder),
      shape = RoundedCornerShape(6.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(14.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Ticket Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "INSTITUTIONAL ORDER TICKET",
              color = WallStreetGold,
              fontSize = 12.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = "${instrument.symbol} • ${instrument.canonicalSymbol} • ${instrument.primaryVenue}",
              color = TextSecondary,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
          }
          IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_ticket_button")) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextDim)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Side Selector (BUY vs SELL)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(DeskCard)
            .padding(2.dp)
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(4.dp))
              .background(if (selectedSide == OrderSide.BUY) MarketGreen else Color.Transparent)
              .clickable { selectedSide = OrderSide.BUY }
              .padding(vertical = 8.dp)
              .testTag("order_side_buy"),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "BUY / LONG",
              color = if (selectedSide == OrderSide.BUY) Color.Black else TextSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(4.dp))
              .background(if (selectedSide == OrderSide.SELL) MarketRed else Color.Transparent)
              .clickable { selectedSide = OrderSide.SELL }
              .padding(vertical = 8.dp)
              .testTag("order_side_sell"),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "SELL / SHORT",
              color = if (selectedSide == OrderSide.SELL) Color.White else TextSecondary,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Order Type Selector
        Text("ORDER TYPE", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          listOf(OrderType.MARKET, OrderType.LIMIT, OrderType.STOP, OrderType.TWAP, OrderType.ICEBERG).forEach { type ->
            val isSel = type == selectedType
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(if (isSel) WallStreetGold else DeskCard)
                .clickable { selectedType = type }
                .padding(horizontal = 6.dp, vertical = 4.dp)
                .testTag("type_${type.name.lowercase()}"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = type.displayName,
                color = if (isSel) Color.Black else TextSecondary,
                fontSize = 9.sp,
                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quantity & Price Inputs
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          // Quantity
          OutlinedTextField(
            value = quantityText,
            onValueChange = { quantityText = it },
            label = { Text("QUANTITY", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedBorderColor = WallStreetGold,
              unfocusedBorderColor = DeskBorder,
              focusedContainerColor = DeskBlack,
              unfocusedContainerColor = DeskBlack
            ),
            modifier = Modifier
              .weight(1f)
              .testTag("order_quantity_input")
          )

          // Limit Price
          if (selectedType != OrderType.MARKET) {
            OutlinedTextField(
              value = priceText,
              onValueChange = { priceText = it },
              label = { Text("PRICE (USD)", fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedBorderColor = WallStreetGold,
                unfocusedBorderColor = DeskBorder,
                focusedContainerColor = DeskBlack,
                unfocusedContainerColor = DeskBlack
              ),
              modifier = Modifier
                .weight(1f)
                .testTag("order_price_input")
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Time In Force & Venue Routing
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Column(modifier = Modifier.weight(1f)) {
            Text("TIME IN FORCE", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 2.dp)) {
              listOf(TimeInForce.DAY, TimeInForce.GTC, TimeInForce.IOC).forEach { tif ->
                val isSel = tif == selectedTif
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (isSel) WallStreetGold else DeskCard)
                    .clickable { selectedTif = tif }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                  Text(
                    text = tif.name,
                    color = if (isSel) Color.Black else TextSecondary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }
            }
          }

          Column(modifier = Modifier.weight(1f)) {
            Text("DESTINATION ROUTE", color = TextDim, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 2.dp)) {
              listOf("SMART", "PRIMARY", "DARK").forEach { v ->
                val isSel = v == selectedVenue
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (isSel) WallStreetGold else DeskCard)
                    .clickable { selectedVenue = v }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                  Text(
                    text = v,
                    color = if (isSel) Color.Black else TextSecondary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Financial & Risk Pre-Trade Inspection Box
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(DeskCardElevated)
            .border(1.dp, DeskBorder, RoundedCornerShape(4.dp))
            .padding(10.dp)
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Est. Notional", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              Text("$${FinancialMath.roundMoney(estimatedNotional)}", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Required Margin", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              Text("$${FinancialMath.roundMoney(estimatedMargin)}", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Est. Exchange / Clearing Fee", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              Text("$${FinancialMath.roundMoney(estimatedFee)}", color = TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text("Available Buying Power", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
              Text("$${FinancialMath.roundMoney(portfolio.buyingPowerUsd)}", color = WallStreetGold, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
          }
        }

        // Consequence confirmation warning
        if (!isConfirming && submissionResult == null) {
          Spacer(modifier = Modifier.height(12.dp))
          Button(
            onClick = { isConfirming = true },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (selectedSide == OrderSide.BUY) MarketGreen else MarketRed,
              contentColor = if (selectedSide == OrderSide.BUY) Color.Black else Color.White
            ),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("preview_order_button")
          ) {
            Text(
              text = "PREVIEW ${selectedSide.name} ORDER",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
        } else if (isConfirming && submissionResult == null) {
          Spacer(modifier = Modifier.height(10.dp))
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(DeskCard)
              .border(1.dp, MarketAmber, RoundedCornerShape(4.dp))
              .padding(8.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Warning, contentDescription = null, tint = MarketAmber, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "CONSEQUENTIAL TRADING EVENT: Order will pass pre-trade risk and route to $selectedVenue.",
                color = MarketAmber,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = { isConfirming = false },
              colors = ButtonDefaults.buttonColors(containerColor = DeskCard, contentColor = TextSecondary),
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.weight(1f)
            ) {
              Text("BACK", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
            Button(
              onClick = {
                onSubmitOrder(
                  selectedSide,
                  selectedType,
                  quantity,
                  limitPrice,
                  stopPrice,
                  selectedTif,
                  selectedVenue
                ) { result ->
                  submissionResult = result
                }
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (selectedSide == OrderSide.BUY) MarketGreen else MarketRed,
                contentColor = if (selectedSide == OrderSide.BUY) Color.Black else Color.White
              ),
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier
                .weight(1.5f)
                .testTag("confirm_submit_order_button")
            ) {
              Text(
                text = "TRANSMIT ORDER",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }

        // Submission Result View
        if (submissionResult != null) {
          val res = submissionResult!!
          val isRejected = res.status == com.example.nytd.model.OrderStatus.REJECTED
          Spacer(modifier = Modifier.height(10.dp))
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(if (isRejected) MarketRed.copy(alpha = 0.15f) else MarketGreen.copy(alpha = 0.15f))
              .border(1.dp, if (isRejected) MarketRed else MarketGreen, RoundedCornerShape(4.dp))
              .padding(10.dp)
          ) {
            Column {
              Text(
                text = if (isRejected) "ORDER REJECTED BY RISK ENGINE" else "ORDER TRANSMITTED TO OMS",
                color = if (isRejected) MarketRed else MarketGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
              )
              Text(
                text = "ID: ${res.id} • Status: ${res.status.name}",
                color = TextPrimary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
              )
              Text(
                text = res.statusMessage,
                color = TextSecondary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Button(
            onClick = onDismiss,
            colors = ButtonDefaults.buttonColors(containerColor = WallStreetGold, contentColor = Color.Black),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("DONE", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
          }
        }
      }
    }
  }
}
