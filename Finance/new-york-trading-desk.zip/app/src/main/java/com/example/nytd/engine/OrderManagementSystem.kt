package com.example.nytd.engine

import com.example.nytd.data.AuditDao
import com.example.nytd.data.AuditLogRecord
import com.example.nytd.data.OrderDao
import com.example.nytd.data.OrderRecord
import com.example.nytd.data.PositionDao
import com.example.nytd.data.PositionRecord
import com.example.nytd.model.ExecutionReport
import com.example.nytd.model.OrderEntity
import com.example.nytd.model.OrderSide
import com.example.nytd.model.OrderStatus
import com.example.nytd.model.OrderType
import com.example.nytd.model.Quote
import com.example.nytd.model.StateTransitionRecord
import com.example.nytd.model.TimeInForce
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

data class SubmitOrderRequest(
  val symbol: String,
  val side: OrderSide,
  val type: OrderType,
  val quantity: Double,
  val price: Double? = null,
  val stopPrice: Double? = null,
  val timeInForce: TimeInForce = TimeInForce.DAY,
  val targetVenue: String = "SMART",
  val clientOrderId: String = "CLORD-${System.currentTimeMillis()}-${UUID.randomUUID().toString().take(4)}"
)

class OrderManagementSystem(
  private val riskEngine: RiskEngine,
  private val smartOrderRouter: SmartOrderRouter,
  private val marketDataSimulator: MarketDataSimulator,
  private val portfolioEngine: PortfolioEngine,
  private val orderDao: OrderDao,
  private val positionDao: PositionDao,
  private val auditDao: AuditDao,
  private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {

  private val _orders = MutableStateFlow<List<OrderEntity>>(emptyList())
  val orders: StateFlow<List<OrderEntity>> = _orders.asStateFlow()

  private val _executions = MutableStateFlow<List<ExecutionReport>>(emptyList())
  val executions: StateFlow<List<ExecutionReport>> = _executions.asStateFlow()

  private val orderStore = ConcurrentHashMap<String, OrderEntity>()
  private val executionStore = mutableListOf<ExecutionReport>()

  init {
    // Load existing orders from Room on launch
    scope.launch {
      orderDao.getAllOrdersFlow().collect { records ->
        val entities = records.map { it.toDomain() }
        entities.forEach { orderStore[it.id] = it }
        _orders.value = orderStore.values.sortedByDescending { it.timestamp }
      }
    }
  }

  fun submitOrder(request: SubmitOrderRequest, onResult: (OrderEntity) -> Unit = {}) {
    val inst = InstrumentCatalog.findBySymbol(request.symbol)
    if (inst == null) {
      val rejected = createRejectedOrder(request, "Unknown instrument symbol: ${request.symbol}")
      onResult(rejected)
      return
    }

    val quote = marketDataSimulator.quotes.value[request.symbol]
    val now = System.currentTimeMillis()
    val orderId = "ORD-${UUID.randomUUID().toString().take(8).uppercase()}"

    val initialTransitions = mutableListOf(
      StateTransitionRecord(null, OrderStatus.CREATED, now, "Order accepted by OMS entry gateway")
    )

    // 1. Validation step
    if (request.quantity <= 0) {
      val rejected = createRejectedOrder(request, "Invalid order quantity: must be > 0")
      onResult(rejected)
      return
    }

    initialTransitions.add(
      StateTransitionRecord(OrderStatus.CREATED, OrderStatus.VALIDATED, now + 1, "Order structure validated against instrument master")
    )

    val multiplier = inst.contractMultiplier
    val estPrice = request.price ?: (if (request.side == OrderSide.BUY) quote?.askPrice ?: 100.0 else quote?.bidPrice ?: 100.0)
    val estNotional = request.quantity * estPrice * multiplier

    var currentOrder = OrderEntity(
      id = orderId,
      clientOrderId = request.clientOrderId,
      symbol = inst.symbol,
      assetClass = inst.assetClass,
      side = request.side,
      type = request.type,
      timeInForce = request.timeInForce,
      quantity = request.quantity,
      price = request.price,
      stopPrice = request.stopPrice,
      targetVenue = request.targetVenue,
      status = OrderStatus.VALIDATED,
      statusMessage = "Order validated",
      estimatedNotional = FinancialMath.roundMoney(estNotional),
      timestamp = now,
      updatedTimestamp = now,
      isPaper = true,
      stateTransitions = initialTransitions
    )

    // 2. Pre-Trade Risk Check
    val currentPortfolio = portfolioEngine.summary.value
    val currentPositions = portfolioEngine.positions.value.values.toList()
    val riskResult = riskEngine.evaluatePreTradeRisk(currentOrder, quote, currentPortfolio, currentPositions)

    if (!riskResult.isApproved) {
      val reason = riskResult.breachedLimits.joinToString("; ")
      currentOrder = currentOrder.copy(
        status = OrderStatus.REJECTED,
        statusMessage = "Risk check rejected: $reason",
        updatedTimestamp = System.currentTimeMillis(),
        stateTransitions = currentOrder.stateTransitions + StateTransitionRecord(
          OrderStatus.VALIDATED,
          OrderStatus.REJECTED,
          System.currentTimeMillis(),
          reason
        )
      )
      saveOrder(currentOrder)
      logAudit("ORDER_REJECTED", currentOrder.id, "RISK_ENGINE", reason, "WARN")
      onResult(currentOrder)
      return
    }

    // Risk approved
    currentOrder = currentOrder.copy(
      status = OrderStatus.RISK_CHECKED,
      statusMessage = "Passed all pre-trade risk checks",
      updatedTimestamp = System.currentTimeMillis(),
      stateTransitions = currentOrder.stateTransitions + StateTransitionRecord(
        OrderStatus.VALIDATED,
        OrderStatus.RISK_CHECKED,
        System.currentTimeMillis(),
        "Risk limits validated"
      )
    )
    saveOrder(currentOrder)

    // 3. Smart Order Routing
    val effectiveQuote = quote ?: marketDataSimulator.quotes.value[request.symbol] ?: Quote(
      symbol = inst.symbol,
      bidPrice = 100.0,
      askPrice = 100.1,
      bidSize = 100.0,
      askSize = 100.0,
      lastPrice = 100.05,
      lastVolume = 50.0,
      changePct = 0.0,
      high24h = 102.0,
      low24h = 98.0,
      vwap = 100.0,
      timestamp = System.currentTimeMillis(),
      sourceVenue = inst.primaryVenue
    )

    val routeEstimate = smartOrderRouter.routeOrder(currentOrder, effectiveQuote)

    currentOrder = currentOrder.copy(
      status = OrderStatus.ROUTING,
      routedVenue = routeEstimate.venueName,
      estimatedFees = routeEstimate.estimatedFeeUsd,
      statusMessage = "Routing to ${routeEstimate.venueName} (${routeEstimate.routingRationale})",
      updatedTimestamp = System.currentTimeMillis(),
      stateTransitions = currentOrder.stateTransitions + StateTransitionRecord(
        OrderStatus.RISK_CHECKED,
        OrderStatus.ROUTING,
        System.currentTimeMillis(),
        "Routed to ${routeEstimate.venueName}"
      )
    )
    saveOrder(currentOrder)

    // Notify result of submission
    onResult(currentOrder)

    // 4. Asynchronous Venue Execution simulation
    scope.launch {
      delay(routeEstimate.venueLatencyMs.toLong().coerceAtLeast(80L))

      // Acknowledged by venue
      currentOrder = currentOrder.copy(
        status = OrderStatus.ACKNOWLEDGED,
        statusMessage = "Venue acknowledged order",
        updatedTimestamp = System.currentTimeMillis(),
        stateTransitions = currentOrder.stateTransitions + StateTransitionRecord(
          OrderStatus.ROUTING,
          OrderStatus.ACKNOWLEDGED,
          System.currentTimeMillis(),
          "Venue ACK received"
        )
      )
      saveOrder(currentOrder)

      delay(120L)

      // Simulate execution: For Market / IOC orders or normal Limit orders near price, simulate partial then fill
      val execPrice = routeEstimate.estimatedExecPrice

      // Partial fill simulation if quantity >= 50
      if (currentOrder.quantity >= 50.0 && currentOrder.type != OrderType.MARKET) {
        val partialQty = FinancialMath.roundMoney(currentOrder.quantity * 0.4, 0)
        val partialReport = ExecutionReport(
          executionId = "EXEC-${UUID.randomUUID().toString().take(6).uppercase()}",
          orderId = currentOrder.id,
          symbol = currentOrder.symbol,
          side = currentOrder.side,
          execPrice = execPrice,
          execQty = partialQty,
          venue = routeEstimate.venueName,
          fee = FinancialMath.roundMoney(routeEstimate.estimatedFeeUsd * 0.4, 2),
          timestamp = System.currentTimeMillis()
        )
        recordExecution(partialReport, inst.assetClass, multiplier)

        currentOrder = currentOrder.copy(
          status = OrderStatus.PARTIALLY_FILLED,
          filledQuantity = partialQty,
          avgFillPrice = execPrice,
          statusMessage = "Partially filled $partialQty / ${currentOrder.quantity} @ $execPrice",
          updatedTimestamp = System.currentTimeMillis(),
          stateTransitions = currentOrder.stateTransitions + StateTransitionRecord(
            OrderStatus.ACKNOWLEDGED,
            OrderStatus.PARTIALLY_FILLED,
            System.currentTimeMillis(),
            "Partial fill executed"
          )
        )
        saveOrder(currentOrder)
        delay(150L)
      }

      // Final fill
      val remainingQty = currentOrder.quantity - currentOrder.filledQuantity
      val finalReport = ExecutionReport(
        executionId = "EXEC-${UUID.randomUUID().toString().take(6).uppercase()}",
        orderId = currentOrder.id,
        symbol = currentOrder.symbol,
        side = currentOrder.side,
        execPrice = execPrice,
        execQty = remainingQty,
        venue = routeEstimate.venueName,
        fee = FinancialMath.roundMoney(routeEstimate.estimatedFeeUsd * (remainingQty / currentOrder.quantity), 2),
        timestamp = System.currentTimeMillis()
      )
      recordExecution(finalReport, inst.assetClass, multiplier)

      currentOrder = currentOrder.copy(
        status = OrderStatus.FILLED,
        filledQuantity = currentOrder.quantity,
        avgFillPrice = execPrice,
        statusMessage = "Order fully filled @ $execPrice on ${routeEstimate.venueName}",
        updatedTimestamp = System.currentTimeMillis(),
        stateTransitions = currentOrder.stateTransitions + StateTransitionRecord(
          if (currentOrder.status == OrderStatus.PARTIALLY_FILLED) OrderStatus.PARTIALLY_FILLED else OrderStatus.ACKNOWLEDGED,
          OrderStatus.FILLED,
          System.currentTimeMillis(),
          "Complete execution report generated"
        )
      )
      saveOrder(currentOrder)
      logAudit("ORDER_FILLED", currentOrder.id, "VENUE_EXEC", "Filled ${currentOrder.quantity} @ $execPrice", "INFO")
    }
  }

  fun cancelOrder(orderId: String) {
    val order = orderStore[orderId] ?: return
    if (order.status.isTerminal) return

    val cancelled = order.copy(
      status = OrderStatus.CANCELLED,
      statusMessage = "Order cancelled by trader",
      updatedTimestamp = System.currentTimeMillis(),
      stateTransitions = order.stateTransitions + StateTransitionRecord(
        order.status,
        OrderStatus.CANCELLED,
        System.currentTimeMillis(),
        "Manual cancellation confirmed"
      )
    )
    saveOrder(cancelled)
    logAudit("ORDER_CANCELLED", order.id, "TRADER", "Cancelled active order", "INFO")
  }

  fun cancelAllOrders() {
    scope.launch {
      orderDao.cancelAllActiveOrders()
      orderStore.values.forEach { order ->
        if (!order.status.isTerminal) {
          val cancelled = order.copy(
            status = OrderStatus.CANCELLED,
            statusMessage = "Mass floor cancellation / Kill switch",
            updatedTimestamp = System.currentTimeMillis()
          )
          orderStore[order.id] = cancelled
        }
      }
      _orders.value = orderStore.values.sortedByDescending { it.timestamp }
      logAudit("MASS_CANCEL", "ALL_ORDERS", "RISK_CONTROL", "Executed Cancel-All on all desks", "WARN")
    }
  }

  private fun recordExecution(report: ExecutionReport, assetClass: com.example.nytd.model.AssetClass, multiplier: Double) {
    executionStore.add(0, report)
    _executions.value = ArrayList(executionStore)
    portfolioEngine.applyExecution(report, assetClass, multiplier)

    // Upsert into PositionDao for persistence
    scope.launch {
      val pos = portfolioEngine.positions.value[report.symbol]
      if (pos != null) {
        if (pos.quantity != 0.0) {
          positionDao.upsertPosition(
            PositionRecord(
              symbol = pos.symbol,
              assetClass = pos.assetClass.name,
              quantity = pos.quantity,
              avgEntryPrice = pos.avgEntryPrice,
              currentPrice = pos.currentPrice,
              realizedPnL = pos.realizedPnL,
              currency = pos.currency,
              openTimestamp = pos.openTimestamp
            )
          )
        } else {
          positionDao.deletePosition(pos.symbol)
        }
      }
    }
  }

  private fun saveOrder(order: OrderEntity) {
    orderStore[order.id] = order
    _orders.value = orderStore.values.sortedByDescending { it.timestamp }
    scope.launch {
      orderDao.insertOrder(order.toRecord())
    }
  }

  private fun logAudit(type: String, entityId: String, actor: String, details: String, severity: String) {
    scope.launch {
      auditDao.insertLog(
        AuditLogRecord(
          timestamp = System.currentTimeMillis(),
          eventType = type,
          entityId = entityId,
          actor = actor,
          details = details,
          severity = severity
        )
      )
    }
  }

  private fun createRejectedOrder(request: SubmitOrderRequest, reason: String): OrderEntity {
    val inst = InstrumentCatalog.findBySymbol(request.symbol)
    val now = System.currentTimeMillis()
    val order = OrderEntity(
      id = "ORD-${UUID.randomUUID().toString().take(8).uppercase()}",
      clientOrderId = request.clientOrderId,
      symbol = request.symbol,
      assetClass = inst?.assetClass ?: com.example.nytd.model.AssetClass.EQUITIES,
      side = request.side,
      type = request.type,
      timeInForce = request.timeInForce,
      quantity = request.quantity,
      price = request.price,
      status = OrderStatus.REJECTED,
      statusMessage = reason,
      timestamp = now,
      updatedTimestamp = now,
      stateTransitions = listOf(
        StateTransitionRecord(null, OrderStatus.CREATED, now, "Order intake"),
        StateTransitionRecord(OrderStatus.CREATED, OrderStatus.REJECTED, now + 1, reason)
      )
    )
    saveOrder(order)
    logAudit("ORDER_REJECTED", order.id, "OMS_GATEWAY", reason, "ERROR")
    return order
  }
}

private fun OrderEntity.toRecord(): OrderRecord {
  return OrderRecord(
    id = id,
    clientOrderId = clientOrderId,
    symbol = symbol,
    assetClass = assetClass.name,
    side = side.name,
    type = type.name,
    timeInForce = timeInForce.name,
    quantity = quantity,
    filledQuantity = filledQuantity,
    avgFillPrice = avgFillPrice,
    price = price,
    stopPrice = stopPrice,
    targetVenue = targetVenue,
    routedVenue = routedVenue,
    status = status.name,
    statusMessage = statusMessage,
    estimatedNotional = estimatedNotional,
    estimatedFees = estimatedFees,
    timestamp = timestamp,
    updatedTimestamp = updatedTimestamp,
    isPaper = isPaper
  )
}

private fun OrderRecord.toDomain(): OrderEntity {
  val ac = try { com.example.nytd.model.AssetClass.valueOf(assetClass) } catch (_: Exception) { com.example.nytd.model.AssetClass.EQUITIES }
  val sd = try { OrderSide.valueOf(side) } catch (_: Exception) { OrderSide.BUY }
  val ot = try { OrderType.valueOf(type) } catch (_: Exception) { OrderType.LIMIT }
  val tif = try { TimeInForce.valueOf(timeInForce) } catch (_: Exception) { TimeInForce.DAY }
  val st = try { OrderStatus.valueOf(status) } catch (_: Exception) { OrderStatus.CREATED }

  return OrderEntity(
    id = id,
    clientOrderId = clientOrderId,
    symbol = symbol,
    assetClass = ac,
    side = sd,
    type = ot,
    timeInForce = tif,
    quantity = quantity,
    filledQuantity = filledQuantity,
    avgFillPrice = avgFillPrice,
    price = price,
    stopPrice = stopPrice,
    targetVenue = targetVenue,
    routedVenue = routedVenue,
    status = st,
    statusMessage = statusMessage,
    estimatedNotional = estimatedNotional,
    estimatedFees = estimatedFees,
    timestamp = timestamp,
    updatedTimestamp = updatedTimestamp,
    isPaper = isPaper
  )
}
