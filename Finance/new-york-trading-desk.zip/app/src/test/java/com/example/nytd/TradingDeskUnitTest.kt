package com.example.nytd

import com.example.nytd.engine.FinancialMath
import com.example.nytd.engine.RiskEngine
import com.example.nytd.engine.SmartOrderRouter
import com.example.nytd.model.AssetClass
import com.example.nytd.model.OrderEntity
import com.example.nytd.model.OrderSide
import com.example.nytd.model.OrderStatus
import com.example.nytd.model.OrderType
import com.example.nytd.model.PortfolioSummary
import com.example.nytd.model.Quote
import com.example.nytd.model.TimeInForce
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TradingDeskUnitTest {

  @Test
  fun testBlackScholesGreeksCalculation() {
    val greeks = FinancialMath.calculateBlackScholes(
      isCall = true,
      spotPrice = 5840.0,
      strikePrice = 5800.0,
      timeYears = 0.15,
      volatility = 0.165
    )
    assertTrue("Call option price must be positive", greeks.price > 0.0)
    assertTrue("Call Delta must be between 0 and 1", greeks.delta in 0.0..1.0)
    assertTrue("Gamma must be positive", greeks.gamma > 0.0)
    assertTrue("Vega must be positive", greeks.vega > 0.0)
  }

  @Test
  fun testBondDurationAndDv01() {
    val (duration, dv01) = FinancialMath.calculateBondRisk(
      couponRatePct = 4.25,
      yieldToMaturityPct = 4.26,
      yearsToMaturity = 10.0,
      parValue = 1000.0
    )
    assertTrue("Duration must be between 6 and 9 years", duration in 6.0..9.0)
    assertTrue("DV01 must be positive", dv01 > 0.0)
  }

  @Test
  fun testPreTradeRiskLimitsEnforcement() {
    val riskEngine = RiskEngine()
    val portfolio = PortfolioSummary(navUsd = 10_000_000.0, buyingPowerUsd = 40_000_000.0)

    val validOrder = OrderEntity(
      id = "ORD-001",
      clientOrderId = "CLORD-001",
      symbol = "NVDA",
      assetClass = AssetClass.EQUITIES,
      side = OrderSide.BUY,
      type = OrderType.LIMIT,
      timeInForce = TimeInForce.DAY,
      quantity = 100.0,
      price = 140.0
    )

    val quote = Quote(
      symbol = "NVDA",
      bidPrice = 140.0,
      askPrice = 140.1,
      bidSize = 100.0,
      askSize = 100.0,
      lastPrice = 140.05,
      lastVolume = 50.0,
      changePct = 0.0,
      high24h = 142.0,
      low24h = 138.0,
      vwap = 140.0,
      timestamp = System.currentTimeMillis(),
      sourceVenue = "NASDAQ"
    )

    val approvedResult = riskEngine.evaluatePreTradeRisk(validOrder, quote, portfolio, emptyList())
    assertTrue("Normal order must be approved", approvedResult.isApproved)

    // Giant order exceeding $5M notional ceiling
    val hugeOrder = validOrder.copy(quantity = 50_000.0) // 50,000 * 140 = $7,000,000
    val rejectedResult = riskEngine.evaluatePreTradeRisk(hugeOrder, quote, portfolio, emptyList())
    assertFalse("Order exceeding notional ceiling must be rejected", rejectedResult.isApproved)
    assertTrue(rejectedResult.breachedLimits.any { it.contains("ORDER NOTIONAL EXCEEDS LIMIT") })

    // Kill switch engagement
    riskEngine.setKillSwitch(true)
    val killSwitchResult = riskEngine.evaluatePreTradeRisk(validOrder, quote, portfolio, emptyList())
    assertFalse("Kill switch active must reject all new orders", killSwitchResult.isApproved)
  }

  @Test
  fun testSmartOrderRouterVenueSelection() {
    val router = SmartOrderRouter()
    val order = OrderEntity(
      id = "ORD-002",
      clientOrderId = "CLORD-002",
      symbol = "NVDA",
      assetClass = AssetClass.EQUITIES,
      side = OrderSide.BUY,
      type = OrderType.LIMIT,
      timeInForce = TimeInForce.DAY,
      quantity = 200.0,
      targetVenue = "SMART"
    )

    val quote = Quote(
      symbol = "NVDA",
      bidPrice = 142.0,
      askPrice = 142.05,
      bidSize = 200.0,
      askSize = 200.0,
      lastPrice = 142.02,
      lastVolume = 100.0,
      changePct = 0.0,
      high24h = 145.0,
      low24h = 140.0,
      vwap = 142.0,
      timestamp = System.currentTimeMillis(),
      sourceVenue = "NASDAQ"
    )

    val estimate = router.routeOrder(order, quote)
    assertTrue("Selected venue should not be blank", estimate.venueName.isNotBlank())
    assertTrue("Slippage estimate should be calculated", estimate.estimatedSlippageBps >= 0.0)
    assertTrue("Estimated fee should be calculated", estimate.estimatedFeeUsd > 0.0)
  }
}
