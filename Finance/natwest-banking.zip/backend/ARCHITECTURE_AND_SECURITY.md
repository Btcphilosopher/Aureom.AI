# NATWEST NEXT-GENERATION UK DIGITAL BANKING PLATFORM
## Technical Architecture, Security Specifications & Operations Guide

### 1. Implemented Features Matrix

| Module | Feature | Implementation Details | Status |
| :--- | :--- | :--- | :--- |
| **Design System** | NatWest M3 Visual Identity | Aubergine (`#42145F`), NatWest Purple (`#6A1B9A`), and Vibrant Violet (`#7B2CBF`). Mathematical 3-cubes isometric chevron mark. Full edge-to-edge support with custom insets. | Completed |
| **Accounts** | Multi-Account Management | Select Current, Digital Regular Saver (3.85% AER), Cash ISA (3.40% AER Tax-Free), Reward Black Credit Card. Real-time balance privacy masking toggle. | Completed |
| **Ledger Engine** | Double-Entry Integrity | Integer minor units (pence) to eliminate IEEE 754 floating-point inaccuracies. Atomic ledger transfers with balance guarantees. | Completed |
| **Transactions** | Categorized Activity Feed | Filter chips (All, Outgoing, Incoming, Pending, Direct Debits), real-time search, interactive category re-assignment, and receipt generation. | Completed |
| **Payments** | UK Faster Payments (FPS) | 24/7 immediate transfer and scheduled payments. UK Sort Code (6 digits) and Account Number (8 digits) format validation. Confirmation of Payee (CoP) matching simulation. Biometric authorization step. | Completed |
| **Cards & Security** | Virtual Card Management | Custom gradient virtual cards, EMV chip, contactless wave, masked 16-digit card number, instant card freeze overlay, 10s timed PIN viewer, online/contactless/ATM/gambling toggles. | Completed |
| **Savings & Goals** | Financial Goal Pacing | Goals progress tracking, contribution workflow from Current Account, and UK Compound Savings Calculator with interactive sliders. | Completed |
| **Insights & Budgets**| Cash Flow & Budgeting | Monthly income vs spending breakdown, category budget adjustment sliders, over-budget warnings, and recurring subscriptions tracker. | Completed |
| **Borrowing** | Credit Cards & Loans | Reward Black card statement balance & repayment workflow. Personal Loan Repayment Calculator with 6.9% fixed representative APR. | Completed |
| **Customer Hub** | Support & Cora AI | Profile details, 24/7 Cora banking assistant simulation with banking domain knowledge, and Open Banking consent management. | Completed |
| **Security Centre** | Access & Device Integrity | Biometric unlock toggle, 6-digit passcode management, trusted device list with one-tap remote session revocation, and security audit log. | Completed |

---

### 2. Security & Compliance Architecture

1. **Authentication & Session Tokens:**
   - On Android devices, token signing keys and biometric credentials leverage the Android Keystore system with Hardware Security Module (HSM) / Trusted Execution Environment (TEE) backing (`KeyGenParameterSpec.Builder(..., KeyProperties.PURPOSE_SIGN)`).
   - Biometric authentication integrates via `androidx.biometric.BiometricPrompt`.

2. **Zero-Trust Network Security:**
   - All external endpoints require TLS 1.3 with certificate pinning (HPKP / Network Security Config `res/xml/network_security_config.xml`).
   - Mutual TLS (mTLS) compliant with Open Banking UK security profile.

3. **Confirmation of Payee (CoP):**
   - Implements UK Pay.UK Confirmation of Payee rules: checks recipient sort code and account number against clearing directory, returning "Match", "Close Match", or "No Match" before funds dispatch.

4. **Idempotency & Duplicate Prevention:**
   - Every payment instruction generates an idempotency key (`FPS-NWT-2026-XXXXXX`) to prevent duplicate debits during network retries or transient dropouts.

---

### 3. Docker Compose Development Environment

To start the local banking backend, PostgreSQL database, and Redis cache:

```bash
cd backend
docker compose up -d
```

- PostgreSQL runs on `localhost:5432` with pre-seeded demonstration accounts and double-entry ledger schema.
- Redis cache runs on `localhost:6379` for session caching and rate-limiting counters.
- REST API runs on `localhost:8080/api/v1` with OpenAPI documentation available at `openapi.yaml`.

---

### 4. Build & Testing Instructions

#### Running Unit and Robolectric Tests
```bash
gradle testDebugUnitTest
```

#### Assembling the Android APK
```bash
gradle assembleDebug
```
The output APK is generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---

### 5. Outstanding External Dependencies (For Live Production)

In this prototype and demonstration build, all financial ledgers, card controls, Confirmation of Payee validations, and payments operate within an offline, self-contained sandbox. For live UK production deployment, the following external banking rails would be connected:
- **Faster Payments Service (FPS) Direct Member Gateway** (Vocalink / Pay.UK).
- **Open Banking Directory & OpenID Connect PKI** (Open Banking Implementation Entity / OBIE).
- **Mastercard / Visa Card Management System API** (TSYS or Fiserv issuer-processor core).
- **Credit Reference Agencies** (Experian / Equifax for automated underwriting and credit decisions).
