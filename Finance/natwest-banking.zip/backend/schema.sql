-- ============================================================================
-- NATWEST DIGITAL BANKING PLATFORM - RELATIONAL DATABASE SCHEMA
-- Compliant with UK Faster Payments System (FPS) and Open Banking Standards
-- All monetary figures represented in integer minor units (GBP Pence)
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Customers
CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_number VARCHAR(12) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone_number VARCHAR(30) NOT NULL,
    address_line_1 VARCHAR(255) NOT NULL,
    address_city VARCHAR(100) NOT NULL,
    address_postcode VARCHAR(12) NOT NULL,
    membership_tier VARCHAR(50) DEFAULT 'PREMIER',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Accounts
CREATE TABLE accounts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    account_type VARCHAR(50) NOT NULL, -- CURRENT, SAVINGS_REGULAR, CASH_ISA, CREDIT_CARD
    account_name VARCHAR(150) NOT NULL,
    sort_code CHAR(6) NOT NULL,
    account_number CHAR(8) NOT NULL,
    iban VARCHAR(34) NOT NULL,
    currency CHAR(3) DEFAULT 'GBP',
    balance_pence BIGINT NOT NULL DEFAULT 0,
    available_pence BIGINT NOT NULL DEFAULT 0,
    credit_limit_pence BIGINT DEFAULT 0,
    interest_rate_aer NUMERIC(5, 4) DEFAULT 0.0000,
    is_primary BOOLEAN DEFAULT FALSE,
    is_frozen BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_sort_code CHECK (sort_code ~ '^[0-9]{6}$'),
    CONSTRAINT chk_account_number CHECK (account_number ~ '^[0-9]{8}$')
);

-- 3. Double-Entry Accounting Ledger (Strict Reconciliation)
CREATE TABLE ledger_entries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    transaction_reference VARCHAR(64) NOT NULL,
    source_account_id UUID REFERENCES accounts(id),
    destination_account_id UUID REFERENCES accounts(id),
    amount_pence BIGINT NOT NULL CHECK (amount_pence > 0),
    currency CHAR(3) DEFAULT 'GBP',
    entry_type VARCHAR(20) NOT NULL, -- DEBIT, CREDIT
    reconciled BOOLEAN DEFAULT TRUE,
    settlement_network VARCHAR(50) DEFAULT 'FASTER_PAYMENTS',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Transactions
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    ledger_entry_id UUID REFERENCES ledger_entries(id),
    merchant_name VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    amount_pence BIGINT NOT NULL, -- Negative for debits, positive for credits
    running_balance_pence BIGINT NOT NULL,
    status VARCHAR(30) DEFAULT 'COMPLETED', -- COMPLETED, PENDING, REVERSED
    payment_method VARCHAR(50) NOT NULL, -- CONTACTLESS, FASTER_PAYMENTS, DIRECT_DEBIT, STANDING_ORDER
    reference VARCHAR(255) NOT NULL,
    card_last_4 CHAR(4),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Payees (Confirmation of Payee Compliant)
CREATE TABLE payees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    sort_code CHAR(6) NOT NULL,
    account_number CHAR(8) NOT NULL,
    bank_name VARCHAR(150) NOT NULL,
    default_reference VARCHAR(100),
    is_favourite BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. Payment Cards
CREATE TABLE payment_cards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    card_type VARCHAR(20) NOT NULL, -- DEBIT, CREDIT
    cardholder_name VARCHAR(150) NOT NULL,
    masked_number VARCHAR(25) NOT NULL,
    expiry_month CHAR(2) NOT NULL,
    expiry_year CHAR(2) NOT NULL,
    is_frozen BOOLEAN DEFAULT FALSE,
    is_online_enabled BOOLEAN DEFAULT TRUE,
    is_contactless_enabled BOOLEAN DEFAULT TRUE,
    is_atm_enabled BOOLEAN DEFAULT TRUE,
    is_gambling_blocked BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. Savings Goals
CREATE TABLE savings_goals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    target_pence BIGINT NOT NULL,
    current_pence BIGINT NOT NULL DEFAULT 0,
    target_date DATE NOT NULL,
    category VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. Category Budgets
CREATE TABLE category_budgets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    category VARCHAR(50) NOT NULL,
    monthly_limit_pence BIGINT NOT NULL,
    spent_pence BIGINT NOT NULL DEFAULT 0,
    period_month VARCHAR(7) NOT NULL, -- YYYY-MM
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(customer_id, category, period_month)
);

-- 9. Security Audit Events
CREATE TABLE security_audit_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
    event_type VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    is_success BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Seed Initial Fictional Data
INSERT INTO customers (id, customer_number, first_name, last_name, email, phone_number, address_line_1, address_city, address_postcode)
VALUES ('a1b2c3d4-e5f6-7890-abcd-ef1234567890', '92817402', 'Eleanor', 'Rigby', 'eleanor.rigby@uk-demo-bank.co.uk', '+44 7700 900123', 'Flat 4B, 10 Downing Street', 'London', 'SW1A 2AA');

INSERT INTO accounts (id, customer_id, account_type, account_name, sort_code, account_number, iban, balance_pence, available_pence, is_primary)
VALUES ('b1b2c3d4-e5f6-7890-abcd-ef1234567891', 'a1b2c3d4-e5f6-7890-abcd-ef1234567890', 'CURRENT', 'Select Current Account', '601234', '98744821', 'GB29NWBK60123498744821', 348250, 348250, TRUE);

INSERT INTO accounts (id, customer_id, account_type, account_name, sort_code, account_number, iban, balance_pence, available_pence, interest_rate_aer)
VALUES ('b1b2c3d4-e5f6-7890-abcd-ef1234567892', 'a1b2c3d4-e5f6-7890-abcd-ef1234567890', 'SAVINGS_REGULAR', 'Digital Regular Saver', '601234', '77312940', 'GB29NWBK60123477312940', 865000, 865000, 0.0385);
