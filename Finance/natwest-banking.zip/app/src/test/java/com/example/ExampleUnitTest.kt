package com.example

import com.example.data.BankingRepository
import com.example.model.MoneyUtils
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class ExampleUnitTest {

    private lateinit var repository: BankingRepository

    @Before
    fun setUp() {
        repository = BankingRepository()
    }

    @Test
    fun testMoneyUtilsFormatting() {
        assertEquals("£3,482.50", MoneyUtils.formatPence(348250L))
        assertEquals("£0.00", MoneyUtils.formatPence(0L))
        assertEquals("+£50.00", MoneyUtils.formatPence(5000L, showSign = true))
        assertEquals(5000L, MoneyUtils.parsePoundsToPence("50.00"))
        assertEquals(123450L, MoneyUtils.parsePoundsToPence("£1,234.50"))
    }

    @Test
    fun testProcessPayment_deductsExactLedgerPence() {
        val initialCurrentBalance = repository.accounts.value.first { it.id == "acc_current" }.balancePence

        val paymentAmountPence = 5000L // £50.00
        val result = repository.processPayment(
            sourceAccountId = "acc_current",
            payeeName = "Oliver Smith",
            sortCode = "200415",
            accountNumber = "48291044",
            amountPence = paymentAmountPence,
            reference = "Dinner"
        )

        assertTrue(result.isSuccess)
        val receipt = result.getOrNull()
        assertNotNull(receipt)
        assertTrue(receipt!!.paymentReference.startsWith("FPS-NWT-2026-"))

        val updatedCurrentBalance = repository.accounts.value.first { it.id == "acc_current" }.balancePence
        assertEquals(initialCurrentBalance - paymentAmountPence, updatedCurrentBalance)
    }

    @Test
    fun testProcessPayment_insufficientFunds_rejected() {
        val current = repository.accounts.value.first { it.id == "acc_current" }
        val excessiveAmount = current.availablePence + 100000L

        val result = repository.processPayment(
            sourceAccountId = "acc_current",
            payeeName = "Test Payee",
            sortCode = "200415",
            accountNumber = "48291044",
            amountPence = excessiveAmount,
            reference = "Overdraft test"
        )

        assertTrue(result.isFailure)
        assertTrue(result.exceptionOrNull()?.message?.contains("Insufficient") == true)
    }

    @Test
    fun testTransferBetweenOwnAccounts_reconciledLedger() {
        val currentAcc = repository.accounts.value.first { it.id == "acc_current" }
        val saverAcc = repository.accounts.value.first { it.id == "acc_saver" }

        val transferPence = 20000L // £200.00
        val result = repository.transferBetweenOwnAccounts(
            sourceAccountId = currentAcc.id,
            destAccountId = saverAcc.id,
            amountPence = transferPence,
            reference = "Monthly Saver"
        )

        assertTrue(result.isSuccess)

        val updatedCurrent = repository.accounts.value.first { it.id == currentAcc.id }
        val updatedSaver = repository.accounts.value.first { it.id == saverAcc.id }

        assertEquals(currentAcc.balancePence - transferPence, updatedCurrent.balancePence)
        assertEquals(saverAcc.balancePence + transferPence, updatedSaver.balancePence)
    }

    @Test
    fun testAddPayee_validation() {
        // Invalid Sort Code
        val invalidSortResult = repository.addPayee("Bad Sort", "123", "12345678", "Bank", "Ref")
        assertTrue(invalidSortResult.isFailure)

        // Invalid Account Number
        val invalidAccResult = repository.addPayee("Bad Acc", "601234", "1234", "Bank", "Ref")
        assertTrue(invalidAccResult.isFailure)

        // Valid Payee
        val validResult = repository.addPayee("Valid Payee", "601234", "87654321", "NatWest", "Rent")
        assertTrue(validResult.isSuccess)
    }

    @Test
    fun testCardFreezeToggle() {
        val card = repository.cards.value.first { it.id == "card_debit" }
        assertFalse(card.isFrozen)

        repository.toggleCardFreeze(card.id)
        val frozenCard = repository.cards.value.first { it.id == "card_debit" }
        assertTrue(frozenCard.isFrozen)

        repository.toggleCardFreeze(card.id)
        val unfrozenCard = repository.cards.value.first { it.id == "card_debit" }
        assertFalse(unfrozenCard.isFrozen)
    }
}
