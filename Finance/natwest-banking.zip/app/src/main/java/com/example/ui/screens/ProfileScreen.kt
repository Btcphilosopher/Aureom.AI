package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SecurityEvent
import com.example.ui.components.DetailRow
import com.example.ui.components.NatWestLogo
import com.example.ui.theme.*
import com.example.viewmodel.BankingViewModel
import com.example.viewmodel.SubScreen

@Composable
fun ProfileScreen(
    viewModel: BankingViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isBiometricsEnabled by viewModel.isBiometricsEnabled.collectAsState()
    val securityEvents by viewModel.securityEvents.collectAsState()

    var isTravelNotificationActive by remember { mutableStateOf(false) }
    var showAuditLogDialog by remember { mutableStateOf(false) }
    var showOpenBankingDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("profile_screen_content"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Customer Profile Header Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                            .background(PaleLavender),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "ER",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepAubergine
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Eleanor Rigby",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = PrimaryText)
                    )

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DeepAubergine,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            text = "NATWEST PREMIER MEMBER",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = CleanWhite,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                fontSize = 10.sp
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Customer Number: 9281 7402  •  SW1A 1AA, London",
                        style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                    )
                }
            }
        }

        // Security Hub Section
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Security & Access",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepAubergine
                            )
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SuccessGreenLight
                        ) {
                            Text(
                                text = "Status: Strong",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SuccessGreen,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Biometrics Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Fingerprint, contentDescription = null, tint = DeepAubergine)
                            Column {
                                Text(
                                    text = "Biometric Sign-in",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                )
                                Text(
                                    text = "Use fingerprint or face recognition for fast unlock",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp)
                                )
                            }
                        }

                        Switch(
                            checked = isBiometricsEnabled,
                            onCheckedChange = { viewModel.toggleBiometrics(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CleanWhite,
                                checkedTrackColor = DeepAubergine
                            )
                        )
                    }

                    HorizontalDivider(color = PaleLavender)

                    // Security Audit Log Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAuditLogDialog = true }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, tint = DeepAubergine)
                            Column {
                                Text(text = "Security Audit Trail", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Text(text = "View recent device logins and authorizations", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp))
                            }
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SecondaryText)
                    }

                    HorizontalDivider(color = PaleLavender)

                    // Trusted Devices Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.Smartphone, contentDescription = null, tint = DeepAubergine)
                            Column {
                                Text(text = "Trusted Primary Device", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Text(text = "Google Pixel (Android 15) • SW Hardware Key", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp))
                            }
                        }
                        TextButton(
                            onClick = { Toast.makeText(context, "All secondary sessions signed out", Toast.LENGTH_SHORT).show() }
                        ) {
                            Text("Sign out others", color = NatWestPurple, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // Banking Services & Preferences
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Services & Integrations",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepAubergine
                        )
                    )

                    // Ask Cora Assistant
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateToSubScreen(SubScreen.SUPPORT_CORA) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.SmartToy, contentDescription = null, tint = NatWestPurple)
                            Column {
                                Text(text = "Ask Cora (Digital Assistant)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Text(text = "24/7 AI-powered support for your banking questions", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp))
                            }
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SecondaryText)
                    }

                    HorizontalDivider(color = PaleLavender)

                    // Open Banking Consents
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showOpenBankingDialog = true }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.Hub, contentDescription = null, tint = DeepAubergine)
                            Column {
                                Text(text = "Open Banking Consents", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Text(text = "Manage authorized third-party account linkages", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp))
                            }
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = SecondaryText)
                    }

                    HorizontalDivider(color = PaleLavender)

                    // Going Abroad / Travel Notification
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = DeepAubergine)
                            Column {
                                Text(text = "Travel Overseas Notice", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Text(text = "Prevents card fraud blocks when travelling in Europe", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp))
                            }
                        }

                        Switch(
                            checked = isTravelNotificationActive,
                            onCheckedChange = {
                                isTravelNotificationActive = it
                                Toast.makeText(
                                    context,
                                    if (it) "Travel notice active: Card safe for EU travel" else "Travel notice cleared",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CleanWhite,
                                checkedTrackColor = DeepAubergine
                            )
                        )
                    }
                }
            }
        }

        // Regulatory & Sandbox Notice
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "NatWest Bank Plc. Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority.",
                    style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 10.sp, lineHeight = 14.sp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "App Concept Demonstration • v3.8.0-UK • Build 82104",
                    style = MaterialTheme.typography.labelSmall.copy(color = TertiaryText, fontSize = 9.sp)
                )
            }
        }
    }

    // Security Audit Log Dialog
    if (showAuditLogDialog) {
        AlertDialog(
            onDismissRequest = { showAuditLogDialog = false },
            title = {
                Text(
                    text = "Security Audit Trail",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                )
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(securityEvents) { ev ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SoftNeutralBg,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = ev.title, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = SuccessGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Text(text = ev.description, style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp))
                                Text(text = ev.formattedDate, style = MaterialTheme.typography.labelSmall.copy(color = TertiaryText, fontSize = 10.sp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAuditLogDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("Close")
                }
            }
        )
    }

    // Open Banking Consents Dialog
    if (showOpenBankingDialog) {
        AlertDialog(
            onDismissRequest = { showOpenBankingDialog = false },
            title = {
                Text(
                    text = "Open Banking Connected Services",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Authorized third-party providers with active read consents under Open Banking UK standard:",
                        style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SoftNeutralBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "Monzo Bank App (Aggregation)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Text(text = "Read access to balances • Valid until Dec 2026", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                            }
                            TextButton(onClick = { Toast.makeText(context, "Consent revoked", Toast.LENGTH_SHORT).show() }) {
                                Text("Revoke", color = ErrorRed)
                            }
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SoftNeutralBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "American Express Card (Auto-Pay)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Text(text = "Payment Initiation Service • Active", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                            }
                            TextButton(onClick = { Toast.makeText(context, "Consent revoked", Toast.LENGTH_SHORT).show() }) {
                                Text("Revoke", color = ErrorRed)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showOpenBankingDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("Done")
                }
            }
        )
    }
}
