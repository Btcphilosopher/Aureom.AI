package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AccountType
import com.example.model.MoneyUtils
import com.example.ui.theme.*
import com.example.viewmodel.BankingViewModel
import kotlin.math.pow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BorrowingScreen(
    viewModel: BankingViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val accounts by viewModel.accounts.collectAsState()
    val isPrivacyEnabled by viewModel.isPrivacyEnabled.collectAsState()

    val creditCard = accounts.find { it.type == AccountType.CREDIT_CARD }
    val currentAccount = accounts.find { it.isPrimary }

    var showRepayModal by remember { mutableStateOf(false) }

    // Loan Calculator State
    var loanAmount by remember { mutableStateOf(7500f) }
    var loanTermMonths by remember { mutableStateOf(36f) }
    val repApr = 0.069 // 6.9% Representative APR

    // Standard loan repayment formula: M = P * [r(1+r)^n] / [(1+r)^n - 1]
    val monthlyRate = repApr / 12.0
    val n = loanTermMonths.toDouble()
    val monthlyPayment = (loanAmount.toDouble() * (monthlyRate * (1 + monthlyRate).pow(n))) / ((1 + monthlyRate).pow(n) - 1)
    val totalRepayable = monthlyPayment * n
    val totalInterest = totalRepayable - loanAmount.toDouble()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Credit & Borrowing",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = DeepAubergine)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .testTag("borrowing_screen_content"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Reward Black Credit Card Card
            if (creditCard != null) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = creditCard.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                                    )
                                    Text(
                                        text = "Limit: ${creditCard.formattedLimit}  •  23.9% APR variable",
                                        style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = PaleLavender
                                ) {
                                    Text(
                                        text = "Due 14 Nov 2026",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = DeepAubergine,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Current Balance (Spent)", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                    Text(
                                        text = if (isPrivacyEnabled) "£ ••••" else MoneyUtils.formatPence(-creditCard.balancePence),
                                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = PrimaryText)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Available Credit", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                    Text(
                                        text = if (isPrivacyEnabled) "£ ••••" else creditCard.formattedAvailable,
                                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = SuccessGreen)
                                    )
                                }
                            }

                            // Minimum Payment indicator
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = SoftNeutralBg,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Minimum Payment Due", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                        Text("£25.00", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                                    }
                                    Button(
                                        onClick = { showRepayModal = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Make Repayment")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // NatWest Personal Loan Calculator
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.Calculate, contentDescription = null, tint = DeepAubergine)
                            Text(
                                text = "Personal Loan Repayment Calculator",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                            )
                        }

                        Text(
                            text = "Model loans from £1,000 to £25,000 with NatWest Representative 6.9% APR.",
                            style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                        )

                        // Slider 1: Loan Amount
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Borrowing Amount", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                Text(
                                    text = "£%,d".format(loanAmount.toInt()),
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                                )
                            }
                            Slider(
                                value = loanAmount,
                                onValueChange = { loanAmount = it },
                                valueRange = 1000f..25000f,
                                steps = 23,
                                colors = SliderDefaults.colors(thumbColor = DeepAubergine, activeTrackColor = DeepAubergine)
                            )
                        }

                        // Slider 2: Term
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Repayment Period", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                Text(
                                    text = "${loanTermMonths.toInt()} Months (${loanTermMonths.toInt() / 12} Years)",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                                )
                            }
                            Slider(
                                value = loanTermMonths,
                                onValueChange = { loanTermMonths = it },
                                valueRange = 12f..60f,
                                steps = 3, // 12, 24, 36, 48, 60
                                colors = SliderDefaults.colors(thumbColor = DeepAubergine, activeTrackColor = DeepAubergine)
                            )
                        }

                        // Repayment Result Box
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PaleLavender,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Estimated Monthly Repayment", style = MaterialTheme.typography.bodySmall.copy(color = DeepAubergine))
                                Text(
                                    text = "£%,.2f / month".format(monthlyPayment),
                                    style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                                )
                                HorizontalDivider(color = DeepAubergine.copy(alpha = 0.2f))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Total Amount Repayable: £%,.2f".format(totalRepayable), style = MaterialTheme.typography.bodySmall)
                                    Text("Total Interest: £%,.2f".format(totalInterest), style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                }
                                Text("Representative APR: 6.9% fixed", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = DeepAubergine))
                            }
                        }

                        Button(
                            onClick = {
                                Toast.makeText(context, "Loan application sandbox submitted for £${loanAmount.toInt()}", Toast.LENGTH_LONG).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Apply in Demo Sandbox")
                        }

                        Text(
                            text = "Responsible lending notice: This calculator is for illustrative purposes only. All credit is subject to status, affordability and terms.",
                            style = MaterialTheme.typography.labelSmall.copy(color = TertiaryText, fontSize = 10.sp)
                        )
                    }
                }
            }
        }
    }

    // Repayment Modal
    if (showRepayModal && creditCard != null && currentAccount != null) {
        var repayOption by remember { mutableStateOf("minimum") } // "minimum", "statement", "custom"
        var customAmountInput by remember { mutableStateOf("50.00") }

        val amountToPayPence = when (repayOption) {
            "minimum" -> 2500L // £25.00
            "statement" -> -creditCard.balancePence // pay total spent
            else -> MoneyUtils.parsePoundsToPence(customAmountInput) ?: 0L
        }

        AlertDialog(
            onDismissRequest = { showRepayModal = false },
            title = {
                Text("Repay Credit Card", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine))
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select repayment amount from your Select Current Account:")

                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = repayOption == "minimum",
                            onClick = { repayOption = "minimum" },
                            shape = SegmentedButtonDefaults.itemShape(0, 3)
                        ) { Text("Min (£25)") }
                        SegmentedButton(
                            selected = repayOption == "statement",
                            onClick = { repayOption = "statement" },
                            shape = SegmentedButtonDefaults.itemShape(1, 3)
                        ) { Text("Full") }
                        SegmentedButton(
                            selected = repayOption == "custom",
                            onClick = { repayOption = "custom" },
                            shape = SegmentedButtonDefaults.itemShape(2, 3)
                        ) { Text("Custom") }
                    }

                    if (repayOption == "custom") {
                        OutlinedTextField(
                            value = customAmountInput,
                            onValueChange = { customAmountInput = it },
                            prefix = { Text("£ ") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Text(
                        text = "Total to transfer: ${MoneyUtils.formatPence(amountToPayPence)}",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ok = viewModel.transferBetweenAccounts(
                            sourceAccountId = currentAccount.id,
                            destAccountId = creditCard.id,
                            amountPence = amountToPayPence,
                            reference = "Credit Card Repayment"
                        )
                        if (ok) {
                            showRepayModal = false
                            Toast.makeText(context, "Credit card payment processed", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("Pay Now")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRepayModal = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
