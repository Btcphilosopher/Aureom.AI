package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = DeepAubergine,
    onPrimary = CleanWhite,
    primaryContainer = PaleLavender,
    onPrimaryContainer = DeepAubergine,
    secondary = NatWestPurple,
    onSecondary = CleanWhite,
    secondaryContainer = PaleLavender,
    onSecondaryContainer = NatWestPurple,
    tertiary = VibrantViolet,
    onTertiary = CleanWhite,
    background = SoftNeutralBg,
    onBackground = PrimaryText,
    surface = CleanWhite,
    onSurface = PrimaryText,
    surfaceVariant = SurfaceCardSecondaryLight,
    onSurfaceVariant = SecondaryText,
    error = ErrorRed,
    onError = CleanWhite,
    errorContainer = ErrorRedLight,
    onErrorContainer = ErrorRed
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkViolet,
    onPrimary = CleanWhite,
    primaryContainer = DarkAubergine,
    onPrimaryContainer = PaleLavender,
    secondary = VibrantViolet,
    onSecondary = CleanWhite,
    secondaryContainer = DarkSurfaceCardSecondary,
    onSecondaryContainer = PaleLavender,
    tertiary = PaleLavender,
    onTertiary = DeepAubergine,
    background = DarkBackground,
    onBackground = DarkPrimaryText,
    surface = DarkSurface,
    onSurface = DarkPrimaryText,
    surfaceVariant = DarkSurfaceCard,
    onSurfaceVariant = DarkSecondaryText,
    error = ErrorRed,
    onError = CleanWhite,
    errorContainer = DarkSurfaceCard,
    onErrorContainer = ErrorRed
)

@Composable
fun NatWestTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
