package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CardDetails
import com.example.model.CardType
import com.example.ui.components.NatWestLogo
import com.example.ui.theme.*
import com.example.viewmodel.BankingViewModel
import kotlinx.coroutines.delay

@Composable
fun CardsScreen(
    viewModel: BankingViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cards by viewModel.cards.collectAsState()
    val selectedCardId by viewModel.selectedCardId.collectAsState()

    val currentCard = cards.find { it.id == selectedCardId } ?: cards.firstOrNull()

    var showPinDialog by remember { mutableStateOf(false) }
    var showReplaceCardDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("cards_screen_content"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Card Switcher Tabs
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(cards) { card ->
                    val isSelected = card.id == selectedCardId
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectCard(card.id) },
                        label = {
                            Text(if (card.cardType == CardType.DEBIT) "Debit Mastercard" else "Reward Black Credit")
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = if (card.isFrozen) Icons.Default.AcUnit else Icons.Default.CreditCard,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (card.isFrozen) InfoBlue else DeepAubergine
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PaleLavender,
                            selectedLabelColor = DeepAubergine
                        )
                    )
                }
            }
        }

        // Virtual Card Graphic
        if (currentCard != null) {
            item {
                VisualPaymentCard(
                    card = currentCard,
                    onCardClick = { viewModel.toggleCardFreeze(currentCard.id) }
                )
            }

            // Quick Actions under Card
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = { showPinDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = DeepAubergine
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Pin, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View PIN", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    FilledTonalButton(
                        onClick = { showReplaceCardDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = DeepAubergine
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Replace Card", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }

            // Primary Security Toggle: Card Freeze
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (currentCard.isFrozen) Color(0xFFE3F2FD) else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (currentCard.isFrozen) InfoBlue else PaleLavender,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.AcUnit,
                                        contentDescription = null,
                                        tint = if (currentCard.isFrozen) CleanWhite else DeepAubergine,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = if (currentCard.isFrozen) "Card is Frozen" else "Freeze Card",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = if (currentCard.isFrozen)
                                        "All card transactions blocked. Direct debits still process."
                                    else
                                        "Temporarily pause card spending if misplaced.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                                )
                            }
                        }

                        Switch(
                            checked = currentCard.isFrozen,
                            onCheckedChange = { viewModel.toggleCardFreeze(currentCard.id) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CleanWhite,
                                checkedTrackColor = InfoBlue
                            ),
                            modifier = Modifier.testTag("freeze_card_switch")
                        )
                    }
                }
            }

            // Granular Card Controls
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Spending & Channel Controls",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepAubergine
                            )
                        )

                        CardControlRow(
                            icon = Icons.Default.Language,
                            title = "Online Transactions",
                            subtitle = "E-commerce and in-app checkout",
                            checked = currentCard.isOnlineEnabled && !currentCard.isFrozen,
                            enabled = !currentCard.isFrozen,
                            onCheckedChange = { viewModel.toggleCardControl(currentCard.id, "online", it) }
                        )

                        HorizontalDivider(color = PaleLavender)

                        CardControlRow(
                            icon = Icons.Default.Contactless,
                            title = "Contactless Payments",
                            subtitle = "Tap to pay up to £100 per transaction",
                            checked = currentCard.isContactlessEnabled && !currentCard.isFrozen,
                            enabled = !currentCard.isFrozen,
                            onCheckedChange = { viewModel.toggleCardControl(currentCard.id, "contactless", it) }
                        )

                        HorizontalDivider(color = PaleLavender)

                        CardControlRow(
                            icon = Icons.Default.LocalAtm,
                            title = "Cash Machine Withdrawals",
                            subtitle = "ATM withdrawals across the UK and worldwide",
                            checked = currentCard.isCashMachineEnabled && !currentCard.isFrozen,
                            enabled = !currentCard.isFrozen,
                            onCheckedChange = { viewModel.toggleCardControl(currentCard.id, "cash", it) }
                        )

                        HorizontalDivider(color = PaleLavender)

                        CardControlRow(
                            icon = Icons.Default.Casino,
                            title = "Gambling & Betting Block",
                            subtitle = "Blocks lottery, casino and betting transactions",
                            checked = currentCard.isGamblingBlockEnabled,
                            enabled = true,
                            onCheckedChange = { viewModel.toggleCardControl(currentCard.id, "gambling", it) }
                        )
                    }
                }
            }

            // Digital Wallet Status
            item {
                Surface(
                    color = SoftNeutralBg,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "Active in Google Wallet",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "Your virtual card is ready for contactless phone payments.",
                                style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                            )
                        }
                    }
                }
            }
        }
    }

    // View PIN Modal
    if (showPinDialog && currentCard != null) {
        var secondsRemaining by remember { mutableStateOf(10) }
        var isPinRevealed by remember { mutableStateOf(false) }

        LaunchedEffect(showPinDialog) {
            delay(600) // Simulated biometric authentication
            isPinRevealed = true
            while (secondsRemaining > 0) {
                delay(1000)
                secondsRemaining--
            }
            showPinDialog = false
        }

        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = {
                Text(
                    text = "Security PIN Reminder",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Authenticated with Biometric Security. Keep your PIN confidential.",
                        style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                    )

                    if (!isPinRevealed) {
                        CircularProgressIndicator(color = DeepAubergine, modifier = Modifier.size(36.dp))
                    } else {
                        // 4 digit PIN box
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(vertical = 14.dp)
                        ) {
                            listOf('3', '8', '2', '9').forEach { digit ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = PaleLavender,
                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, DeepAubergine),
                                    modifier = Modifier.size(54.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = digit.toString(),
                                            style = MaterialTheme.typography.displayMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = DeepAubergine
                                            )
                                        )
                                    }
                                }
                            }
                        }

                        Text(
                            text = "Hiding PIN in $secondsRemaining seconds...",
                            style = MaterialTheme.typography.labelSmall.copy(color = SecondaryText)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showPinDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("Hide Now")
                }
            }
        )
    }

    // Replace Card Dialog
    if (showReplaceCardDialog && currentCard != null) {
        var reason by remember { mutableStateOf("Lost") }
        AlertDialog(
            onDismissRequest = { showReplaceCardDialog = false },
            title = {
                Text(
                    text = "Order Replacement Card",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Your current card (${currentCard.cardNumberMasked}) will be cancelled immediately and a new contactless card dispatched via Royal Mail First Class to your registered address in London.",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = reason == "Lost",
                            onClick = { reason = "Lost" },
                            shape = SegmentedButtonDefaults.itemShape(0, 3)
                        ) { Text("Lost") }
                        SegmentedButton(
                            selected = reason == "Stolen",
                            onClick = { reason = "Stolen" },
                            shape = SegmentedButtonDefaults.itemShape(1, 3)
                        ) { Text("Stolen") }
                        SegmentedButton(
                            selected = reason == "Damaged",
                            onClick = { reason = "Damaged" },
                            shape = SegmentedButtonDefaults.itemShape(2, 3)
                        ) { Text("Damaged") }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        Toast.makeText(context, "Replacement card ordered. Delivery in 2-3 working days.", Toast.LENGTH_LONG).show()
                        showReplaceCardDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("Confirm Order")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReplaceCardDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

/**
 * Visual Payment Card representation with authentic NatWest aesthetics
 */
@Composable
fun VisualPaymentCard(
    card: CardDetails,
    onCardClick: () -> Unit
) {
    val gradientColors = if (card.cardType == CardType.DEBIT) {
        listOf(Color(0xFF42145F), Color(0xFF6A1B9A), Color(0xFF7B2CBF))
    } else {
        listOf(Color(0xFF1E1528), Color(0xFF381A4E), Color(0xFF5A1E7A))
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(210.dp)
            .clickable(onClick = onCardClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(gradientColors))
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Row: Logo & Card Type & Contactless Wave
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NatWestLogo(sizeDp = 24)
                        Text(
                            text = "NatWest",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = CleanWhite
                            )
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Contactless,
                            contentDescription = "Contactless",
                            tint = CleanWhite.copy(alpha = 0.9f),
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = if (card.cardType == CardType.DEBIT) "DEBIT" else "PREMIER BLACK",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = CleanWhite.copy(alpha = 0.85f),
                                letterSpacing = 1.sp
                            )
                        )
                    }
                }

                // Middle: EMV Chip Graphic
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Gold EMV Chip
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFD4AF37),
                        modifier = Modifier
                            .width(38.dp)
                            .height(28.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(4.dp)
                                .border(1.dp, Color(0xFF996515), RoundedCornerShape(4.dp))
                        )
                    }
                }

                // Masked Number & Cardholder Details
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = card.cardNumberMasked,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = CleanWhite,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = card.cardholderName,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = CleanWhite.copy(alpha = 0.85f),
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = "EXPIRES ${card.expiryDate}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = CleanWhite.copy(alpha = 0.85f),
                                letterSpacing = 1.sp
                            )
                        )
                    }
                }
            }

            // Frozen Overlay
            if (card.isFrozen) {
                Surface(
                    color = Color(0xCC0D47A1),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.AcUnit,
                                contentDescription = "Frozen",
                                tint = CleanWhite,
                                modifier = Modifier.size(42.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "CARD TEMPORARILY FROZEN",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CleanWhite,
                                    letterSpacing = 1.sp
                                )
                            )
                            Text(
                                text = "Tap to unfreeze anytime",
                                style = MaterialTheme.typography.bodySmall.copy(color = CleanWhite.copy(alpha = 0.8f))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CardControlRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (enabled) DeepAubergine else SecondaryText,
                modifier = Modifier.size(22.dp)
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = if (enabled) PrimaryText else SecondaryText
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp)
                )
            }
        }

        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CleanWhite,
                checkedTrackColor = DeepAubergine
            )
        )
    }
}
