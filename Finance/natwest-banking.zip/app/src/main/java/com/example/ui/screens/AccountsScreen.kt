package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.TransactionItemRow
import com.example.ui.theme.*
import com.example.viewmodel.BankingViewModel
import com.example.viewmodel.SubScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsScreen(
    viewModel: BankingViewModel,
    onNavigateToPayment: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val accounts by viewModel.accounts.collectAsState()
    val selectedAccountId by viewModel.selectedAccountId.collectAsState()
    val transactions by viewModel.filteredTransactions.collectAsState()
    val isPrivacyEnabled by viewModel.isPrivacyEnabled.collectAsState()
    val searchQuery by viewModel.txSearchQuery.collectAsState()
    val selectedTypeFilter by viewModel.selectedTypeFilter.collectAsState()
    val selectedCategoryFilter by viewModel.selectedCategoryFilter.collectAsState()

    val currentSpendPence by viewModel.currentMonthSpendPence.collectAsState()
    val currentIncomePence by viewModel.currentMonthIncomePence.collectAsState()

    val currentAccount = accounts.find { it.id == selectedAccountId } ?: accounts.firstOrNull()

    var showStatementViewer by remember { mutableStateOf(false) }
    var showCategoryMenu by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("accounts_screen_content"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Account Switcher Horizontal Chips
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedAccountId == "ALL",
                        onClick = { viewModel.selectAccount("ALL") },
                        label = { Text("All Accounts") },
                        leadingIcon = {
                            if (selectedAccountId == "ALL") {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PaleLavender,
                            selectedLabelColor = DeepAubergine
                        )
                    )
                }

                items(accounts) { acc ->
                    val isSelected = acc.id == selectedAccountId
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectAccount(acc.id) },
                        label = { Text(acc.name) },
                        leadingIcon = {
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PaleLavender,
                            selectedLabelColor = DeepAubergine
                        )
                    )
                }
            }
        }

        // Active Account Details Card
        if (currentAccount != null && selectedAccountId != "ALL") {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(16.dp),
                    tonalElevation = 2.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = currentAccount.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Sort Code: ${currentAccount.formattedSortCode}  •  Acc: ${currentAccount.accountNumber}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                                )
                            }

                            // Copy details button
                            FilledTonalIconButton(
                                onClick = {
                                    val text = "Sort Code: ${currentAccount.formattedSortCode}, Account: ${currentAccount.accountNumber}"
                                    clipboardManager.setText(AnnotatedString(text))
                                    Toast.makeText(context, "Account details copied to clipboard", Toast.LENGTH_SHORT).show()
                                },
                                colors = IconButtonDefaults.filledTonalIconButtonColors(
                                    containerColor = PaleLavender,
                                    contentColor = DeepAubergine
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy account details",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        HorizontalDivider(color = PaleLavender)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Current Balance",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                                )
                                Text(
                                    text = if (isPrivacyEnabled) "£ ••,•••.••" else currentAccount.formattedBalance,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryText
                                    )
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Available Balance",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                                )
                                Text(
                                    text = if (isPrivacyEnabled) "£ ••,•••.••" else currentAccount.formattedAvailable,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = SuccessGreen
                                    )
                                )
                            }
                        }

                        // Action Buttons: Pay and Statement
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onNavigateToPayment,
                                colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pay & Transfer")
                            }

                            OutlinedButton(
                                onClick = { showStatementViewer = true },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp), tint = DeepAubergine)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Statements", color = DeepAubergine)
                            }
                        }
                    }
                }
            }
        }

        // Monthly Summary Flow Widget
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "October Outgoings", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                        Text(
                            text = if (isPrivacyEnabled) "£ •••" else MoneyUtils.formatPence(currentSpendPence),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = PrimaryText)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(36.dp)
                            .background(PaleLavender)
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "October Incomings", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                        Text(
                            text = if (isPrivacyEnabled) "£ •••" else MoneyUtils.formatPence(currentIncomePence),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = SuccessGreen)
                        )
                    }
                }
            }
        }

        // Search Bar & Filter Row
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search merchant, amount, or reference...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SecondaryText) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NatWestPurple,
                        unfocusedBorderColor = PaleLavender,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("transaction_search_input")
                )

                // Filter Chips Row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val filterTypes = listOf("All", "Outgoing", "Incoming", "Pending", "Direct Debits")
                    items(filterTypes) { type ->
                        FilterChip(
                            selected = selectedTypeFilter == type,
                            onClick = { viewModel.setTypeFilter(type) },
                            label = { Text(type) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PaleLavender,
                                selectedLabelColor = DeepAubergine
                            )
                        )
                    }

                    item {
                        Box {
                            FilterChip(
                                selected = selectedCategoryFilter != null,
                                onClick = { showCategoryMenu = true },
                                label = { Text(selectedCategoryFilter?.displayName ?: "Category") },
                                trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PaleLavender,
                                    selectedLabelColor = DeepAubergine
                                )
                            )

                            DropdownMenu(
                                expanded = showCategoryMenu,
                                onDismissRequest = { showCategoryMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("All Categories") },
                                    onClick = {
                                        viewModel.setCategoryFilter(null)
                                        showCategoryMenu = false
                                    }
                                )
                                TransactionCategory.values().forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat.displayName) },
                                        onClick = {
                                            viewModel.setCategoryFilter(cat)
                                            showCategoryMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Transactions List
        if (transactions.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp, horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = null,
                        tint = SecondaryText,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No transactions found",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold, color = PrimaryText)
                    )
                    Text(
                        text = "Try adjusting your search query or active filter chips.",
                        style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                    )
                }
            }
        } else {
            items(transactions, key = { it.id }) { tx ->
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    TransactionItemRow(
                        transaction = tx,
                        isPrivacyEnabled = isPrivacyEnabled,
                        onClick = { viewModel.inspectTransaction(tx) }
                    )
                }
            }
        }
    }

    // Statement Viewer Dialog Simulation
    if (showStatementViewer && currentAccount != null) {
        AlertDialog(
            onDismissRequest = { showStatementViewer = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Description, contentDescription = null, tint = DeepAubergine)
                    Text("Monthly Account Statement", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = "NATWEST BANK PLC", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = DeepAubergine))
                    Text(text = "Statement Period: 01 Oct 2026 - 21 Oct 2026", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium))
                    Text(text = "Account: ${currentAccount.name} (${currentAccount.formattedSortCode} / ${currentAccount.accountNumber})", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                    HorizontalDivider(color = PaleLavender)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Opening Balance:", style = MaterialTheme.typography.bodySmall)
                        Text(text = "£4,210.00", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Total Money In:", style = MaterialTheme.typography.bodySmall)
                        Text(text = MoneyUtils.formatPence(currentIncomePence), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = SuccessGreen))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Total Money Out:", style = MaterialTheme.typography.bodySmall)
                        Text(text = MoneyUtils.formatPence(currentSpendPence), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Closing Balance:", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Text(text = currentAccount.formattedBalance, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        Toast.makeText(context, "Statement saved to downloads (Simulated)", Toast.LENGTH_SHORT).show()
                        showStatementViewer = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export PDF")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStatementViewer = false }) {
                    Text("Close")
                }
            }
        )
    }
}
