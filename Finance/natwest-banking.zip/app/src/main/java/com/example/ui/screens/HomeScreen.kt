package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.BankingViewModel
import com.example.viewmodel.SubScreen

@Composable
fun HomeScreen(
    viewModel: BankingViewModel,
    onNavigateToTab: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val accounts by viewModel.accounts.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val isPrivacyEnabled by viewModel.isPrivacyEnabled.collectAsState()
    val totalAvailablePence by viewModel.totalAvailablePence.collectAsState()

    var showUpcomingSheet by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("home_screen_content"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome & Net Worth Header
        item {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Good morning,",
                                style = MaterialTheme.typography.bodyMedium.copy(color = SecondaryText)
                            )
                            Text(
                                text = "Eleanor",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = DeepAubergine
                                )
                            )
                        }

                        // Sandbox demo pill
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = PaleLavender,
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(SuccessGreen)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "SANDBOX DEMO",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = DeepAubergine,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Total Available Funds",
                        style = MaterialTheme.typography.labelMedium.copy(color = SecondaryText)
                    )
                    Text(
                        text = if (isPrivacyEnabled) "£ ••,•••.••" else MoneyUtils.formatPence(totalAvailablePence),
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText,
                            letterSpacing = (-0.5).sp
                        )
                    )
                }
            }
        }

        // Account Cards Pager / List
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "My Accounts",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText
                        )
                    )
                    TextButton(onClick = { onNavigateToTab(1) }) {
                        Text(
                            text = "View all (${accounts.size})",
                            style = MaterialTheme.typography.labelLarge.copy(color = NatWestPurple)
                        )
                    }
                }

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(accounts, key = { it.id }) { acc ->
                        AccountCard(
                            account = acc,
                            isPrivacyEnabled = isPrivacyEnabled,
                            onCardClick = {
                                viewModel.selectAccount(acc.id)
                                onNavigateToTab(1)
                            },
                            onPayClick = {
                                viewModel.selectAccount(acc.id)
                                onNavigateToTab(2)
                            },
                            modifier = Modifier.width(310.dp)
                        )
                    }
                }
            }
        }

        // Quick Actions Row
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    QuickActionButton(
                        icon = Icons.Default.Send,
                        label = "Transfer",
                        onClick = { onNavigateToTab(2) }
                    )
                    QuickActionButton(
                        icon = Icons.Default.CreditCard,
                        label = "Cards",
                        onClick = { onNavigateToTab(3) }
                    )
                    QuickActionButton(
                        icon = Icons.Default.Savings,
                        label = "Savings",
                        onClick = { viewModel.navigateToSubScreen(SubScreen.SAVINGS_HUB) }
                    )
                    QuickActionButton(
                        icon = Icons.Default.PieChart,
                        label = "Insights",
                        onClick = { viewModel.navigateToSubScreen(SubScreen.SPENDING_INSIGHTS) }
                    )
                    QuickActionButton(
                        icon = Icons.Default.AccountBalance,
                        label = "Borrow",
                        onClick = { viewModel.navigateToSubScreen(SubScreen.BORROWING_HUB) }
                    )
                }
            }
        }

        // Upcoming Bills & Direct Debits Widget
        item {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(16.dp),
                tonalElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .clickable { showUpcomingSheet = true }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = PaleLavender,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = null,
                                    tint = DeepAubergine,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "Upcoming Scheduled Bills",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "3 Direct Debits due in next 14 days",
                                style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "View upcoming bills",
                        tint = SecondaryText
                    )
                }
            }
        }

        // Recent Transactions Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Activity",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText
                        )
                    )
                    TextButton(onClick = { onNavigateToTab(1) }) {
                        Text(
                            text = "See all",
                            style = MaterialTheme.typography.labelLarge.copy(color = NatWestPurple)
                        )
                    }
                }

                val recentList = transactions.take(5)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    recentList.forEach { tx ->
                        TransactionItemRow(
                            transaction = tx,
                            isPrivacyEnabled = isPrivacyEnabled,
                            onClick = { viewModel.inspectTransaction(tx) }
                        )
                    }
                }
            }
        }

        // Reassurance / FSCS Protection Banner
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PaleLavender.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = DeepAubergine,
                        modifier = Modifier.size(26.dp)
                    )
                    Column {
                        Text(
                            text = "FSCS Protected (Simulation)",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepAubergine
                            )
                        )
                        Text(
                            text = "Eligible deposits in NatWest accounts protected up to £85,000 by Financial Services Compensation Scheme.",
                            style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp)
                        )
                    }
                }
            }
        }
    }

    // Upcoming Direct Debits Sheet
    if (showUpcomingSheet) {
        AlertDialog(
            onDismissRequest = { showUpcomingSheet = false },
            title = {
                Text(
                    text = "Scheduled Direct Debits & Bills",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "These recurring commitments will be debited automatically from your Select Current Account.",
                        style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                    )
                    UpcomingBillRow("Westminster Council Tax", "£164.00", "Due 25 Oct 2026")
                    UpcomingBillRow("British Gas Energy", "£114.50", "Due 02 Nov 2026")
                    UpcomingBillRow("Netflix UK Subscription", "£15.99", "Due 08 Nov 2026")
                    UpcomingBillRow("PureGym London", "£34.99", "Due 14 Nov 2026")
                }
            },
            confirmButton = {
                TextButton(onClick = { showUpcomingSheet = false }) {
                    Text("Done", color = NatWestPurple, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun UpcomingBillRow(name: String, amount: String, dueDate: String) {
    Surface(
        color = SoftNeutralBg,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                Text(text = dueDate, style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
            }
            Text(text = amount, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
        }
    }
}
