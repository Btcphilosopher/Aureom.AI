package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

class BankingRepository {

    // Accounts State
    private val _accounts = MutableStateFlow<List<Account>>(initialAccounts())
    val accounts: StateFlow<List<Account>> = _accounts.asStateFlow()

    // Transactions State
    private val _transactions = MutableStateFlow<List<Transaction>>(initialTransactions())
    val transactions: StateFlow<List<Transaction>> = _transactions.asStateFlow()

    // Payees State
    private val _payees = MutableStateFlow<List<Payee>>(initialPayees())
    val payees: StateFlow<List<Payee>> = _payees.asStateFlow()

    // Cards State
    private val _cards = MutableStateFlow<List<CardDetails>>(initialCards())
    val cards: StateFlow<List<CardDetails>> = _cards.asStateFlow()

    // Savings Goals State
    private val _savingsGoals = MutableStateFlow<List<SavingsGoal>>(initialSavingsGoals())
    val savingsGoals: StateFlow<List<SavingsGoal>> = _savingsGoals.asStateFlow()

    // Budgets State
    private val _budgets = MutableStateFlow<List<BudgetCategory>>(initialBudgets())
    val budgets: StateFlow<List<BudgetCategory>> = _budgets.asStateFlow()

    // Security Audit State
    private val _securityEvents = MutableStateFlow<List<SecurityEvent>>(initialSecurityEvents())
    val securityEvents: StateFlow<List<SecurityEvent>> = _securityEvents.asStateFlow()

    // Cora Assistant Chat Messages
    private val _chatMessages = MutableStateFlow<List<SupportMessage>>(initialChatMessages())
    val chatMessages: StateFlow<List<SupportMessage>> = _chatMessages.asStateFlow()

    // Privacy Mask Toggle
    private val _isPrivacyEnabled = MutableStateFlow(false)
    val isPrivacyEnabled: StateFlow<Boolean> = _isPrivacyEnabled.asStateFlow()

    // Biometric Login Setting
    private val _isBiometricsEnabled = MutableStateFlow(true)
    val isBiometricsEnabled: StateFlow<Boolean> = _isBiometricsEnabled.asStateFlow()

    fun togglePrivacyMode() {
        _isPrivacyEnabled.update { !it }
    }

    fun toggleBiometrics(enabled: Boolean) {
        _isBiometricsEnabled.value = enabled
        recordSecurityEvent(
            title = if (enabled) "Biometrics Enabled" else "Biometrics Disabled",
            description = "Biometric authentication preference updated on this device."
        )
    }

    /**
     * Executes a validated UK payment using double-entry ledger bookkeeping.
     * Guaranteed integer pence arithmetic.
     */
    fun processPayment(
        sourceAccountId: String,
        payeeName: String,
        sortCode: String,
        accountNumber: String,
        amountPence: Long,
        reference: String,
        isImmediate: Boolean = true
    ): Result<PaymentReceipt> {
        val source = _accounts.value.find { it.id == sourceAccountId }
            ?: return Result.failure(IllegalArgumentException("Source account not found"))

        if (amountPence <= 0) {
            return Result.failure(IllegalArgumentException("Payment amount must be greater than £0.00"))
        }

        // Available balance check (for credit card, checks available credit)
        if (source.type == AccountType.CREDIT_CARD) {
            if (source.availablePence < amountPence) {
                return Result.failure(IllegalStateException("Transaction exceeds available credit limit"))
            }
        } else {
            if (source.availablePence < amountPence) {
                return Result.failure(IllegalStateException("Insufficient available funds in ${source.name}"))
            }
        }

        val fpsRef = "FPS-NWT-2026-${(100000..999999).random()}"
        val now = System.currentTimeMillis()

        // Deduct from source account
        val updatedSourceBalance = source.balancePence - amountPence
        val updatedSourceAvailable = source.availablePence - amountPence

        val updatedAccounts = _accounts.value.map { acc ->
            if (acc.id == sourceAccountId) {
                acc.copy(
                    balancePence = updatedSourceBalance,
                    availablePence = updatedSourceAvailable
                )
            } else {
                acc
            }
        }
        _accounts.value = updatedAccounts

        // Create debit transaction record
        val debitTx = Transaction(
            id = UUID.randomUUID().toString(),
            accountId = sourceAccountId,
            timestampMs = now,
            merchantName = payeeName,
            category = TransactionCategory.TRANSFER,
            amountPence = -amountPence,
            status = if (isImmediate) TransactionStatus.COMPLETED else TransactionStatus.PENDING,
            runningBalancePence = updatedSourceBalance,
            reference = reference.ifBlank { "FPS Transfer" },
            paymentMethod = PaymentMethod.FASTER_PAYMENTS
        )

        _transactions.update { listOf(debitTx) + it }

        recordSecurityEvent(
            title = "Payment Authorized: ${MoneyUtils.formatPence(amountPence)}",
            description = "Sent to $payeeName (Sort: $sortCode, Acc: $accountNumber). Ref: $fpsRef"
        )

        val receipt = PaymentReceipt(
            paymentReference = fpsRef,
            sourceAccountName = source.name,
            payeeName = payeeName,
            sortCode = sortCode,
            accountNumber = accountNumber,
            amountPence = amountPence,
            reference = reference,
            timestampMs = now,
            settlementType = if (isImmediate) "Faster Payments Service (FPS 24/7)" else "Scheduled Payment"
        )

        return Result.success(receipt)
    }

    /**
     * Internal transfer between user's own accounts (e.g. Current to Regular Saver).
     */
    fun transferBetweenOwnAccounts(
        sourceAccountId: String,
        destAccountId: String,
        amountPence: Long,
        reference: String
    ): Result<PaymentReceipt> {
        val source = _accounts.value.find { it.id == sourceAccountId }
            ?: return Result.failure(IllegalArgumentException("Source account not found"))
        val dest = _accounts.value.find { it.id == destAccountId }
            ?: return Result.failure(IllegalArgumentException("Destination account not found"))

        if (source.id == dest.id) {
            return Result.failure(IllegalArgumentException("Source and destination accounts must be different"))
        }

        if (source.availablePence < amountPence) {
            return Result.failure(IllegalStateException("Insufficient funds in ${source.name}"))
        }

        val now = System.currentTimeMillis()
        val fpsRef = "INT-NWT-${(100000..999999).random()}"

        // Update balances: debit source, credit dest
        _accounts.update { list ->
            list.map { acc ->
                when (acc.id) {
                    sourceAccountId -> acc.copy(
                        balancePence = acc.balancePence - amountPence,
                        availablePence = acc.availablePence - amountPence
                    )
                    destAccountId -> {
                        // For credit card, balance is negative; paying it off brings balance closer to 0
                        if (acc.type == AccountType.CREDIT_CARD) {
                            acc.copy(
                                balancePence = acc.balancePence + amountPence,
                                availablePence = (acc.availablePence + amountPence).coerceAtMost(acc.creditLimitPence)
                            )
                        } else {
                            acc.copy(
                                balancePence = acc.balancePence + amountPence,
                                availablePence = acc.availablePence + amountPence
                            )
                        }
                    }
                    else -> acc
                }
            }
        }

        val updatedSource = _accounts.value.first { it.id == sourceAccountId }
        val updatedDest = _accounts.value.first { it.id == destAccountId }

        val debitTx = Transaction(
            id = UUID.randomUUID().toString(),
            accountId = sourceAccountId,
            timestampMs = now,
            merchantName = "Transfer to ${dest.name}",
            category = TransactionCategory.TRANSFER,
            amountPence = -amountPence,
            status = TransactionStatus.COMPLETED,
            runningBalancePence = updatedSource.balancePence,
            reference = reference.ifBlank { "Internal Transfer" },
            paymentMethod = PaymentMethod.FASTER_PAYMENTS
        )

        val creditTx = Transaction(
            id = UUID.randomUUID().toString(),
            accountId = destAccountId,
            timestampMs = now,
            merchantName = "Transfer from ${source.name}",
            category = TransactionCategory.TRANSFER,
            amountPence = amountPence,
            status = TransactionStatus.COMPLETED,
            runningBalancePence = updatedDest.balancePence,
            reference = reference.ifBlank { "Internal Transfer" },
            paymentMethod = PaymentMethod.FASTER_PAYMENTS
        )

        _transactions.update { listOf(debitTx, creditTx) + it }

        val receipt = PaymentReceipt(
            paymentReference = fpsRef,
            sourceAccountName = source.name,
            payeeName = dest.name,
            sortCode = dest.sortCode,
            accountNumber = dest.accountNumber,
            amountPence = amountPence,
            reference = reference,
            timestampMs = now,
            settlementType = "Instant Internal Transfer"
        )

        return Result.success(receipt)
    }

    /**
     * Add new payee with UK bank details.
     */
    fun addPayee(
        name: String,
        sortCode: String,
        accountNumber: String,
        bankName: String,
        reference: String
    ): Result<Payee> {
        val cleanSort = sortCode.replace("-", "").trim()
        val cleanAcc = accountNumber.trim()

        if (cleanSort.length != 6 || !cleanSort.all { it.isDigit() }) {
            return Result.failure(IllegalArgumentException("UK Sort Code must be 6 digits"))
        }
        if (cleanAcc.length != 8 || !cleanAcc.all { it.isDigit() }) {
            return Result.failure(IllegalArgumentException("UK Account Number must be 8 digits"))
        }
        if (name.isBlank()) {
            return Result.failure(IllegalArgumentException("Payee name cannot be blank"))
        }

        val newPayee = Payee(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            sortCode = cleanSort,
            accountNumber = cleanAcc,
            bankName = bankName.ifBlank { "UK Clearing Bank" },
            defaultReference = reference.trim(),
            isFavourite = false
        )

        _payees.update { listOf(newPayee) + it }
        recordSecurityEvent(
            title = "New Payee Added: ${newPayee.name}",
            description = "Sort Code: ${newPayee.sortCode}, Account: ${newPayee.accountNumber}"
        )
        return Result.success(newPayee)
    }

    /**
     * Card controls
     */
    fun toggleCardFreeze(cardId: String) {
        _cards.update { list ->
            list.map { card ->
                if (card.id == cardId) {
                    val nextState = !card.isFrozen
                    recordSecurityEvent(
                        title = if (nextState) "Card Frozen: ${card.cardNumberMasked}" else "Card Unfrozen: ${card.cardNumberMasked}",
                        description = if (nextState) "All card authorizations temporarily blocked by customer." else "Card restored to active status."
                    )
                    card.copy(isFrozen = nextState)
                } else card
            }
        }
    }

    fun toggleCardControl(cardId: String, controlType: String, enabled: Boolean) {
        _cards.update { list ->
            list.map { card ->
                if (card.id == cardId) {
                    when (controlType) {
                        "online" -> card.copy(isOnlineEnabled = enabled)
                        "contactless" -> card.copy(isContactlessEnabled = enabled)
                        "cash" -> card.copy(isCashMachineEnabled = enabled)
                        "gambling" -> card.copy(isGamblingBlockEnabled = enabled)
                        else -> card
                    }
                } else card
            }
        }
    }

    /**
     * Savings Goals management
     */
    fun contributeToGoal(goalId: String, amountPence: Long): Result<SavingsGoal> {
        val primaryAcc = _accounts.value.find { it.isPrimary }
            ?: return Result.failure(IllegalStateException("No primary current account found"))

        if (primaryAcc.availablePence < amountPence) {
            return Result.failure(IllegalStateException("Insufficient funds in Current Account"))
        }

        val goal = _savingsGoals.value.find { it.id == goalId }
            ?: return Result.failure(IllegalArgumentException("Savings goal not found"))

        // Debit current account
        _accounts.update { list ->
            list.map { acc ->
                if (acc.id == primaryAcc.id) {
                    acc.copy(
                        balancePence = acc.balancePence - amountPence,
                        availablePence = acc.availablePence - amountPence
                    )
                } else acc
            }
        }

        // Credit savings goal
        var updatedGoal: SavingsGoal = goal
        _savingsGoals.update { list ->
            list.map { g ->
                if (g.id == goalId) {
                    val updated = g.copy(currentPence = g.currentPence + amountPence)
                    updatedGoal = updated
                    updated
                } else g
            }
        }

        // Record transaction
        val tx = Transaction(
            id = UUID.randomUUID().toString(),
            accountId = primaryAcc.id,
            timestampMs = System.currentTimeMillis(),
            merchantName = "Goal: ${goal.title}",
            category = TransactionCategory.TRANSFER,
            amountPence = -amountPence,
            status = TransactionStatus.COMPLETED,
            runningBalancePence = primaryAcc.balancePence - amountPence,
            reference = "Deposit to ${goal.title}",
            paymentMethod = PaymentMethod.FASTER_PAYMENTS
        )
        _transactions.update { listOf(tx) + it }

        return Result.success(updatedGoal)
    }

    fun createSavingsGoal(title: String, targetPence: Long, dateString: String, category: String): SavingsGoal {
        val newGoal = SavingsGoal(
            id = UUID.randomUUID().toString(),
            title = title.trim(),
            targetPence = targetPence,
            currentPence = 0L,
            targetDateString = dateString,
            category = category
        )
        _savingsGoals.update { it + newGoal }
        return newGoal
    }

    /**
     * Budgets
     */
    fun updateBudgetLimit(category: TransactionCategory, newLimitPence: Long) {
        _budgets.update { list ->
            list.map { b ->
                if (b.category == category) b.copy(monthlyLimitPence = newLimitPence) else b
            }
        }
    }

    /**
     * Edit transaction category
     */
    fun updateTransactionCategory(txId: String, newCategory: TransactionCategory) {
        _transactions.update { list ->
            list.map { tx ->
                if (tx.id == txId) tx.copy(category = newCategory) else tx
            }
        }
    }

    /**
     * Cora assistant chat
     */
    fun sendCoraMessage(userText: String) {
        val userMsg = SupportMessage(
            id = UUID.randomUUID().toString(),
            isFromUser = true,
            message = userText
        )
        _chatMessages.update { it + userMsg }

        val replyText = generateCoraResponse(userText)
        val assistantMsg = SupportMessage(
            id = UUID.randomUUID().toString(),
            isFromUser = false,
            message = replyText
        )
        _chatMessages.update { it + assistantMsg }
    }

    private fun generateCoraResponse(query: String): String {
        val lower = query.lowercase()
        return when {
            "balance" in lower -> {
                val current = _accounts.value.find { it.isPrimary }
                "Your primary Select Current Account balance is ${current?.formattedBalance ?: "£0.00"}, with ${current?.formattedAvailable ?: "£0.00"} available to spend. You also hold £8,650.00 in your Digital Regular Saver."
            }
            "freeze" in lower || "lost card" in lower || "stolen" in lower -> {
                "You can freeze your Debit or Credit card instantly in the Cards tab. Toggling 'Freeze' stops all new contactless, chip, and online transactions while keeping your standing orders and direct debits intact."
            }
            "isa" in lower || "allowance" in lower -> {
                "The UK Cash ISA allowance for the 2026/27 tax year is £20,000. Your current Cash ISA holds £14,200.00 tax-free at 3.40% AER."
            }
            "transfer" in lower || "pay" in lower || "send money" in lower -> {
                "To transfer money, head to the Pay & Transfer tab. UK Faster Payments (FPS) are processed 24/7 with instant confirmation and Confirmation of Payee verification."
            }
            "credit limit" in lower || "borrowing" in lower || "loan" in lower -> {
                "Your Reward Black Credit Card limit is £6,000.00 with £4,820.00 available. You can also model personal loans from £1,000 up to £25,000 in the Borrowing hub."
            }
            "fraud" in lower || "suspicious" in lower -> {
                "If you spot a transaction you don't recognise, freeze your card immediately in the Cards tab, or tap the transaction in Accounts to review its reference and report it to our 24/7 fraud helpline."
            }
            else -> {
                "Hello Eleanor! I'm Cora, your NatWest digital assistant. I can help with balance checks, card controls, Faster Payments, savings goals, and spending analytics. How can I assist you today?"
            }
        }
    }

    private fun recordSecurityEvent(title: String, description: String, isSuccess: Boolean = true) {
        val event = SecurityEvent(
            id = UUID.randomUUID().toString(),
            timestampMs = System.currentTimeMillis(),
            title = title,
            description = description,
            isSuccess = isSuccess
        )
        _securityEvents.update { listOf(event) + it }
    }

    // Seed Data Initializers
    private fun initialAccounts(): List<Account> {
        return listOf(
            Account(
                id = "acc_current",
                name = "Select Current Account",
                type = AccountType.CURRENT,
                sortCode = "601234",
                accountNumber = "98744821",
                balancePence = 348250L, // £3,482.50
                availablePence = 348250L,
                isPrimary = true
            ),
            Account(
                id = "acc_saver",
                name = "Digital Regular Saver",
                type = AccountType.SAVINGS_REGULAR,
                sortCode = "601234",
                accountNumber = "77312940",
                balancePence = 865000L, // £8,650.00
                availablePence = 865000L,
                interestRateText = "3.85% AER variable"
            ),
            Account(
                id = "acc_isa",
                name = "Cash ISA",
                type = AccountType.CASH_ISA,
                sortCode = "601234",
                accountNumber = "55209144",
                balancePence = 1420000L, // £14,200.00
                availablePence = 1420000L,
                interestRateText = "3.40% AER Tax-Free"
            ),
            Account(
                id = "acc_credit",
                name = "Reward Black Credit Card",
                type = AccountType.CREDIT_CARD,
                sortCode = "601234",
                accountNumber = "10394821",
                balancePence = -118000L, // -£1,180.00 (spent)
                availablePence = 482000L, // £4,820.00 available
                creditLimitPence = 600000L, // £6,000.00 limit
                interestRateText = "23.9% APR variable"
            )
        )
    }

    private fun initialTransactions(): List<Transaction> {
        val now = System.currentTimeMillis()
        val oneHour = 3600000L
        val oneDay = 86400000L

        return listOf(
            Transaction(
                id = "tx_1",
                accountId = "acc_current",
                timestampMs = now - (2 * oneHour),
                merchantName = "Waitrose & Partners",
                category = TransactionCategory.GROCERIES,
                amountPence = -6420L, // -£64.20
                runningBalancePence = 348250L,
                reference = "WTR-LONDON-MARYLEBONE",
                paymentMethod = PaymentMethod.CONTACTLESS,
                cardLast4 = "4821"
            ),
            Transaction(
                id = "tx_2",
                accountId = "acc_current",
                timestampMs = now - (5 * oneHour),
                merchantName = "Transport for London",
                category = TransactionCategory.TRANSPORT,
                amountPence = -340L, // -£3.40
                runningBalancePence = 354670L,
                reference = "TfL Travel Charge",
                paymentMethod = PaymentMethod.CONTACTLESS,
                cardLast4 = "4821"
            ),
            Transaction(
                id = "tx_3",
                accountId = "acc_current",
                timestampMs = now - (22 * oneHour),
                merchantName = "Pret A Manger",
                category = TransactionCategory.DINING,
                amountPence = -485L, // -£4.85
                runningBalancePence = 355010L,
                reference = "PRET STRAND WC2",
                paymentMethod = PaymentMethod.CONTACTLESS,
                cardLast4 = "4821"
            ),
            Transaction(
                id = "tx_4",
                accountId = "acc_current",
                timestampMs = now - (1 * oneDay),
                merchantName = "Deliveroo London",
                category = TransactionCategory.DINING,
                amountPence = -2650L, // -£26.50
                runningBalancePence = 355495L,
                reference = "DLV-9821734",
                paymentMethod = PaymentMethod.ONLINE_PURCHASE,
                cardLast4 = "4821"
            ),
            Transaction(
                id = "tx_5",
                accountId = "acc_current",
                timestampMs = now - (2 * oneDay),
                merchantName = "Netflix UK",
                category = TransactionCategory.SUBSCRIPTIONS,
                amountPence = -1599L, // -£15.99
                runningBalancePence = 358145L,
                reference = "NETFLIX.COM DIRECT DEBIT",
                paymentMethod = PaymentMethod.DIRECT_DEBIT
            ),
            Transaction(
                id = "tx_6",
                accountId = "acc_current",
                timestampMs = now - (3 * oneDay),
                merchantName = "Westminster Council Tax",
                category = TransactionCategory.HOUSING,
                amountPence = -16400L, // -£164.00
                runningBalancePence = 359744L,
                reference = "COUNCIL TAX REF 982104",
                paymentMethod = PaymentMethod.DIRECT_DEBIT
            ),
            Transaction(
                id = "tx_7",
                accountId = "acc_current",
                timestampMs = now - (4 * oneDay),
                merchantName = "Tech Labs UK Salary",
                category = TransactionCategory.INCOME,
                amountPence = 325000L, // +£3,250.00
                runningBalancePence = 376144L,
                reference = "BACS SALARY OCT 2026",
                paymentMethod = PaymentMethod.FASTER_PAYMENTS
            ),
            Transaction(
                id = "tx_8",
                accountId = "acc_current",
                timestampMs = now - (5 * oneDay),
                merchantName = "British Gas Electricity",
                category = TransactionCategory.UTILITIES,
                amountPence = -11450L, // -£114.50
                runningBalancePence = 51144L,
                reference = "BGAS ENERGY DIRECT DEBIT",
                paymentMethod = PaymentMethod.DIRECT_DEBIT
            ),
            Transaction(
                id = "tx_9",
                accountId = "acc_current",
                timestampMs = now - (6 * oneDay),
                merchantName = "Marks & Spencer",
                category = TransactionCategory.SHOPPING,
                amountPence = -4280L, // -£42.80
                runningBalancePence = 165644L,
                reference = "M&S OXFORD STREET",
                paymentMethod = PaymentMethod.CONTACTLESS,
                cardLast4 = "4821"
            ),
            Transaction(
                id = "tx_10",
                accountId = "acc_current",
                timestampMs = now - (7 * oneDay),
                merchantName = "PureGym London Bridge",
                category = TransactionCategory.SUBSCRIPTIONS,
                amountPence = -3499L, // -£34.99
                runningBalancePence = 208444L,
                reference = "PGYM MEMBERSHIP D/D",
                paymentMethod = PaymentMethod.DIRECT_DEBIT
            ),
            Transaction(
                id = "tx_11",
                accountId = "acc_credit",
                timestampMs = now - (1 * oneDay),
                merchantName = "Apple Regent Street",
                category = TransactionCategory.SHOPPING,
                amountPence = -28900L, // -£289.00
                runningBalancePence = -118000L,
                reference = "APPLE STORE 042",
                paymentMethod = PaymentMethod.CONTACTLESS,
                cardLast4 = "9104"
            )
        )
    }

    private fun initialPayees(): List<Payee> {
        return listOf(
            Payee(
                id = "p_1",
                name = "Oliver Smith",
                sortCode = "200415",
                accountNumber = "48291044",
                bankName = "Barclays Bank UK",
                defaultReference = "Dinner split",
                isFavourite = true
            ),
            Payee(
                id = "p_2",
                name = "Maya Patel",
                sortCode = "404784",
                accountNumber = "39182740",
                bankName = "HSBC UK",
                defaultReference = "Weekend trip",
                isFavourite = true
            ),
            Payee(
                id = "p_3",
                name = "Liam Davies",
                sortCode = "070116",
                accountNumber = "82910471",
                bankName = "Nationwide Building Society",
                defaultReference = "Football pitch hire",
                isFavourite = false
            ),
            Payee(
                id = "p_4",
                name = "High St Properties (Landlord)",
                sortCode = "600001",
                accountNumber = "90182736",
                bankName = "NatWest Bank",
                defaultReference = "Flat 4B Rent",
                isFavourite = true
            )
        )
    }

    private fun initialCards(): List<CardDetails> {
        return listOf(
            CardDetails(
                id = "card_debit",
                accountId = "acc_current",
                cardholderName = "ELEANOR RIGBY",
                cardNumberMasked = "5354 •••• •••• 4821",
                expiryDate = "08/28",
                cardType = CardType.DEBIT,
                isFrozen = false,
                isOnlineEnabled = true,
                isContactlessEnabled = true,
                isCashMachineEnabled = true,
                isGamblingBlockEnabled = true,
                isGoogleWalletAdded = true
            ),
            CardDetails(
                id = "card_credit",
                accountId = "acc_credit",
                cardholderName = "ELEANOR RIGBY",
                cardNumberMasked = "5412 •••• •••• 9104",
                expiryDate = "11/29",
                cardType = CardType.CREDIT,
                isFrozen = false,
                isOnlineEnabled = true,
                isContactlessEnabled = true,
                isCashMachineEnabled = true,
                isGamblingBlockEnabled = true,
                isGoogleWalletAdded = true
            )
        )
    }

    private fun initialSavingsGoals(): List<SavingsGoal> {
        return listOf(
            SavingsGoal(
                id = "goal_1",
                title = "Cotswolds Autumn Holiday",
                targetPence = 150000L, // £1,500.00
                currentPence = 112000L, // £1,120.00
                targetDateString = "15 Nov 2026",
                category = "Travel"
            ),
            SavingsGoal(
                id = "goal_2",
                title = "Rainy Day Emergency Fund",
                targetPence = 500000L, // £5,000.00
                currentPence = 420000L, // £4,200.00
                targetDateString = "31 Dec 2026",
                category = "Emergency"
            ),
            SavingsGoal(
                id = "goal_3",
                title = "New EV Deposit",
                targetPence = 1000000L, // £10,000.00
                currentPence = 335000L, // £3,350.00
                targetDateString = "30 Jun 2027",
                category = "Vehicle"
            )
        )
    }

    private fun initialBudgets(): List<BudgetCategory> {
        return listOf(
            BudgetCategory(TransactionCategory.GROCERIES, 45000L, 31250L),
            BudgetCategory(TransactionCategory.DINING, 25000L, 18450L),
            BudgetCategory(TransactionCategory.TRANSPORT, 15000L, 9820L),
            BudgetCategory(TransactionCategory.SHOPPING, 30000L, 24100L),
            BudgetCategory(TransactionCategory.ENTERTAINMENT, 10000L, 6500L)
        )
    }

    private fun initialSecurityEvents(): List<SecurityEvent> {
        val now = System.currentTimeMillis()
        return listOf(
            SecurityEvent("sec_1", now - 600000L, "App Sign-in: Biometrics (Fingerprint)", "Verified securely with device biometric key."),
            SecurityEvent("sec_2", now - 86400000L, "Standing Order Processed", "Council Tax (£164.00) transferred via Faster Payments."),
            SecurityEvent("sec_3", now - 2 * 86400000L, "Trusted Device Verified", "Google Pixel running Android 15 registered as primary device.")
        )
    }

    private fun initialChatMessages(): List<SupportMessage> {
        return listOf(
            SupportMessage(
                id = "chat_1",
                isFromUser = false,
                message = "Good morning Eleanor! I'm Cora, your NatWest digital assistant. Ask me anything about your accounts, card limits, savings goals, or UK payment transfers."
            )
        )
    }
}

data class PaymentReceipt(
    val paymentReference: String,
    val sourceAccountName: String,
    val payeeName: String,
    val sortCode: String,
    val accountNumber: String,
    val amountPence: Long,
    val reference: String,
    val timestampMs: Long,
    val settlementType: String
) {
    val formattedAmount: String get() = MoneyUtils.formatPence(amountPence)
    val formattedDate: String get() = MoneyUtils.formatDate(timestampMs, "dd MMM yyyy, HH:mm:ss")
}
