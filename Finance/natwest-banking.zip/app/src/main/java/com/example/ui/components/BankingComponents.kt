package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

/**
 * Custom NatWest-inspired Three-Cubes Brand Mark drawn mathematically with Jetpack Compose Canvas.
 */
@Composable
fun NatWestLogo(
    modifier: Modifier = Modifier,
    sizeDp: Int = 32
) {
    Canvas(modifier = modifier.size(sizeDp.dp)) {
        val w = size.width
        val h = size.height

        // Isometric 3-cubes chevron arrangement
        val cubeSize = w * 0.42f
        val color1 = Color(0xFF6A1B9A) // NatWest Purple
        val color2 = Color(0xFF7B2CBF) // Vibrant Violet
        val color3 = Color(0xFF9D4EDD) // Bright Lavender

        // Cube 1 (Top)
        val p1 = Path().apply {
            moveTo(w * 0.5f, h * 0.05f)
            lineTo(w * 0.72f, h * 0.22f)
            lineTo(w * 0.5f, h * 0.39f)
            lineTo(w * 0.28f, h * 0.22f)
            close()
        }
        drawPath(p1, color3)

        // Cube 2 (Bottom Left)
        val p2 = Path().apply {
            moveTo(w * 0.26f, h * 0.42f)
            lineTo(w * 0.48f, h * 0.59f)
            lineTo(w * 0.26f, h * 0.76f)
            lineTo(w * 0.04f, h * 0.59f)
            close()
        }
        drawPath(p2, color2)

        // Cube 3 (Bottom Right)
        val p3 = Path().apply {
            moveTo(w * 0.74f, h * 0.42f)
            lineTo(w * 0.96f, h * 0.59f)
            lineTo(w * 0.74f, h * 0.76f)
            lineTo(w * 0.52f, h * 0.59f)
            close()
        }
        drawPath(p3, color1)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NatWestTopBar(
    isPrivacyEnabled: Boolean,
    onTogglePrivacy: () -> Unit,
    onOpenSecurity: () -> Unit,
    onOpenCora: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                NatWestLogo(sizeDp = 30)
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "NatWest",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepAubergine,
                                letterSpacing = (-0.3).sp
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = PaleLavender,
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Text(
                                text = "PREMIER",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = DeepAubergine,
                                    fontSize = 9.sp
                                ),
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Eleanor Rigby",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = SecondaryText,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                // Privacy toggle
                IconButton(
                    onClick = onTogglePrivacy,
                    modifier = Modifier.testTag("privacy_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isPrivacyEnabled) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = "Toggle Balance Privacy",
                        tint = DeepAubergine
                    )
                }

                // Cora Assistant Shortcut
                IconButton(
                    onClick = onOpenCora,
                    modifier = Modifier.testTag("cora_assistant_button")
                ) {
                    BadgedBox(
                        badge = {
                            Badge(
                                containerColor = SuccessGreen,
                                modifier = Modifier.size(7.dp)
                            )
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = "Ask Cora",
                            tint = NatWestPurple
                        )
                    }
                }

                // Security Center Shortcut
                IconButton(
                    onClick = onOpenSecurity,
                    modifier = Modifier.testTag("security_center_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Security Centre",
                        tint = DeepAubergine
                    )
                }
            }
        }
    }
}

/**
 * Premium Account Card featuring NatWest brand gradients.
 */
@Composable
fun AccountCard(
    account: Account,
    isPrivacyEnabled: Boolean,
    onCardClick: () -> Unit,
    onPayClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val gradientColors = when (account.type) {
        AccountType.CURRENT -> listOf(Color(0xFF42145F), Color(0xFF6A1B9A))
        AccountType.SAVINGS_REGULAR -> listOf(Color(0xFF134E4A), Color(0xFF0F766E))
        AccountType.CASH_ISA -> listOf(Color(0xFF1E3A8A), Color(0xFF2563EB))
        AccountType.CREDIT_CARD -> listOf(Color(0xFF21152B), Color(0xFF4A1E6D))
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onCardClick)
            .testTag("account_card_${account.id}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(gradientColors))
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Top Row: Account Name & Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = account.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = CleanWhite,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "${account.formattedSortCode} • ••••${account.accountNumber.takeLast(4)}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = CleanWhite.copy(alpha = 0.8f)
                            )
                        )
                    }

                    if (account.interestRateText != null) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CleanWhite.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = account.interestRateText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CleanWhite,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    } else if (account.type == AccountType.CREDIT_CARD) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CleanWhite.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "Limit ${account.formattedLimit}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = CleanWhite,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // Balance Row
                Column {
                    Text(
                        text = if (account.type == AccountType.CREDIT_CARD) "Current balance" else "Available balance",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = CleanWhite.copy(alpha = 0.75f)
                        )
                    )
                    Text(
                        text = if (isPrivacyEnabled) "£ ••,•••.••" else account.formattedBalance,
                        style = MaterialTheme.typography.displayMedium.copy(
                            color = CleanWhite,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.5).sp
                        )
                    )
                    if (account.type == AccountType.CREDIT_CARD) {
                        Text(
                            text = "Available to spend: ${if (isPrivacyEnabled) "£ ••••" else account.formattedAvailable}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = CleanWhite.copy(alpha = 0.85f)
                            )
                        )
                    }
                }

                // Action Buttons inside Card
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = onPayClick,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = CleanWhite.copy(alpha = 0.22f),
                            contentColor = CleanWhite
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (account.type == AccountType.CREDIT_CARD) "Make Payment" else "Pay & Transfer",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }

                    OutlinedButton(
                        onClick = onCardClick,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CleanWhite),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.linearGradient(listOf(CleanWhite.copy(alpha = 0.4f), CleanWhite.copy(alpha = 0.4f)))
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(
                            text = "Details",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}

/**
 * Individual Transaction Row with category icon and clear UK currency representation.
 */
@Composable
fun TransactionItemRow(
    transaction: Transaction,
    isPrivacyEnabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(12.dp),
        tonalElevation = 1.dp,
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("transaction_item_${transaction.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Category Icon Box
                val (catBg, catTint) = when (transaction.category) {
                    TransactionCategory.INCOME -> Pair(SuccessGreenLight, SuccessGreen)
                    TransactionCategory.GROCERIES -> Pair(Color(0xFFE8F5E9), Color(0xFF2E7D32))
                    TransactionCategory.DINING -> Pair(Color(0xFFFFF3E0), Color(0xFFE65100))
                    TransactionCategory.TRANSPORT -> Pair(Color(0xFFE3F2FD), Color(0xFF1565C0))
                    TransactionCategory.HOUSING -> Pair(Color(0xFFEDE7F6), DeepAubergine)
                    TransactionCategory.SUBSCRIPTIONS -> Pair(PaleLavender, NatWestPurple)
                    TransactionCategory.SHOPPING -> Pair(Color(0xFFFCE4EC), Color(0xFFC2185B))
                    TransactionCategory.UTILITIES -> Pair(Color(0xFFFFFDE7), Color(0xFFF57F17))
                    TransactionCategory.TRANSFER -> Pair(PaleLavender, VibrantViolet)
                    else -> Pair(Color(0xFFECEFF1), Color(0xFF455A64))
                }

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(catBg),
                    contentAlignment = Alignment.Center
                ) {
                    val icon = when (transaction.category) {
                        TransactionCategory.INCOME -> Icons.Default.Payments
                        TransactionCategory.GROCERIES -> Icons.Default.ShoppingCart
                        TransactionCategory.DINING -> Icons.Default.Restaurant
                        TransactionCategory.TRANSPORT -> Icons.Default.DirectionsSubway
                        TransactionCategory.HOUSING -> Icons.Default.Home
                        TransactionCategory.SUBSCRIPTIONS -> Icons.Default.Subscriptions
                        TransactionCategory.SHOPPING -> Icons.Default.ShoppingBag
                        TransactionCategory.UTILITIES -> Icons.Default.Bolt
                        TransactionCategory.TRANSFER -> Icons.Default.SwapHoriz
                        else -> Icons.Default.Receipt
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = transaction.category.displayName,
                        tint = catTint,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = transaction.merchantName,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = PrimaryText
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = transaction.formattedDate,
                            style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                        )
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.bodySmall.copy(color = TertiaryText)
                        )
                        Text(
                            text = transaction.category.displayName,
                            style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.padding(start = 8.dp)
            ) {
                val amountColor = if (transaction.isDebit) PrimaryText else SuccessGreen
                Text(
                    text = if (isPrivacyEnabled) "••••" else transaction.formattedAmount,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = amountColor
                    )
                )
                if (transaction.status == TransactionStatus.PENDING) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = WarningAmberLight
                    ) {
                        Text(
                            text = "Pending",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = WarningAmber,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Quick Action Button for Top Action Row
 */
@Composable
fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp)
            .testTag("quick_action_${label.replace(" ", "_").lowercase()}")
    ) {
        Surface(
            shape = CircleShape,
            color = PaleLavender,
            tonalElevation = 2.dp,
            modifier = Modifier.size(50.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = DeepAubergine,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Medium,
                color = PrimaryText,
                fontSize = 11.sp
            ),
            maxLines = 1
        )
    }
}

/**
 * Transaction Detail Inspection Dialog
 */
@Composable
fun TransactionDetailDialog(
    transaction: Transaction,
    onDismiss: () -> Unit,
    onCategoryChange: (TransactionCategory) -> Unit
) {
    var expandedCatMenu by remember { mutableStateOf(false) }
    var showReceiptPreview by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (transaction.isDebit) PaleLavender else SuccessGreenLight,
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (transaction.isDebit) Icons.Default.ShoppingBag else Icons.Default.Payments,
                            contentDescription = null,
                            tint = if (transaction.isDebit) DeepAubergine else SuccessGreen,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = transaction.merchantName,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = PrimaryText
                )
                Text(
                    text = transaction.formattedAmount,
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (transaction.isDebit) PrimaryText else SuccessGreen
                    )
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HorizontalDivider(color = PaleLavender)

                DetailRow("Status", transaction.status.name)
                DetailRow("Date & Time", "${transaction.formattedDate} at ${transaction.formattedTime}")
                DetailRow("Payment Method", transaction.paymentMethod.displayName)
                DetailRow("Reference", transaction.reference)
                DetailRow("Running Balance", transaction.formattedRunningBalance)

                // Editable Category selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Category",
                        style = MaterialTheme.typography.bodyMedium.copy(color = SecondaryText)
                    )
                    Box {
                        TextButton(
                            onClick = { expandedCatMenu = true },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = transaction.category.displayName,
                                style = MaterialTheme.typography.labelLarge.copy(color = NatWestPurple)
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = NatWestPurple
                            )
                        }
                        DropdownMenu(
                            expanded = expandedCatMenu,
                            onDismissRequest = { expandedCatMenu = false }
                        ) {
                            TransactionCategory.values().forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.displayName) },
                                    onClick = {
                                        onCategoryChange(cat)
                                        expandedCatMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                if (showReceiptPreview) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SoftNeutralBg,
                        border = androidx.compose.foundation.BorderStroke(1.dp, PaleLavender),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "NATWEST TRANSACTION VOUCHER",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                            )
                            Text(
                                text = "Transaction ID: ${transaction.id.take(16).uppercase()}",
                                style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                            )
                            Text(
                                text = "Settled via Faster Payments clearing network (Simulated Sandbox).",
                                style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 10.sp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    clipboardManager.setText(AnnotatedString(transaction.reference))
                    showReceiptPreview = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
            ) {
                Icon(imageVector = Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Generate Receipt")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = SecondaryText)
            }
        }
    )
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(color = SecondaryText)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium, color = PrimaryText)
        )
    }
}
