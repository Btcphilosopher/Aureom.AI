package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.DetailRow
import com.example.ui.theme.*
import com.example.viewmodel.BankingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentScreen(
    viewModel: BankingViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val accounts by viewModel.accounts.collectAsState()
    val payees by viewModel.payees.collectAsState()
    val activeReceipt by viewModel.activeReceipt.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var isInternalTransferMode by remember { mutableStateOf(false) }

    // Source Account
    var selectedSourceId by remember {
        mutableStateOf(accounts.firstOrNull { it.isPrimary }?.id ?: accounts.firstOrNull()?.id ?: "")
    }

    // Destination for Internal Transfer
    var selectedDestInternalId by remember {
        mutableStateOf(accounts.firstOrNull { it.id != selectedSourceId }?.id ?: "")
    }

    // Payee for External Transfer
    var selectedPayee by remember { mutableStateOf<Payee?>(payees.firstOrNull()) }
    var showNewPayeeModal by remember { mutableStateOf(false) }

    // Amount & Reference
    var amountInput by remember { mutableStateOf("") }
    var referenceInput by remember { mutableStateOf("") }
    var isImmediate by remember { mutableStateOf(true) }

    // Confirmation Sheet
    var showConfirmationDialog by remember { mutableStateOf(false) }
    var isAuthenticating by remember { mutableStateOf(false) }

    val sourceAccount = accounts.find { it.id == selectedSourceId } ?: accounts.firstOrNull()

    // Sync reference when payee changes
    LaunchedEffect(selectedPayee) {
        if (referenceInput.isBlank() && selectedPayee != null) {
            referenceInput = selectedPayee?.defaultReference.orEmpty()
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("payment_screen_content"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Switcher: External Payee vs Between Own Accounts
        item {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = !isInternalTransferMode,
                    onClick = { isInternalTransferMode = false },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) {
                    Text("Pay Someone")
                }
                SegmentedButton(
                    selected = isInternalTransferMode,
                    onClick = { isInternalTransferMode = true },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) {
                    Text("Between Accounts")
                }
            }
        }

        // Source Account Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "From Account",
                        style = MaterialTheme.typography.labelMedium.copy(color = SecondaryText)
                    )

                    accounts.forEach { acc ->
                        val isSelected = acc.id == selectedSourceId
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) PaleLavender else SoftNeutralBg,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, DeepAubergine) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedSourceId = acc.id }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { selectedSourceId = acc.id },
                                        colors = RadioButtonDefaults.colors(selectedColor = DeepAubergine)
                                    )
                                    Column {
                                        Text(text = acc.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                        Text(text = "Sort: ${acc.formattedSortCode} • Acc: ${acc.accountNumber}", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                    }
                                }
                                Text(
                                    text = acc.formattedAvailable,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Destination Selection
        if (isInternalTransferMode) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "To My Account",
                            style = MaterialTheme.typography.labelMedium.copy(color = SecondaryText)
                        )

                        accounts.filter { it.id != selectedSourceId }.forEach { acc ->
                            val isSelected = acc.id == selectedDestInternalId
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) PaleLavender else SoftNeutralBg,
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, DeepAubergine) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedDestInternalId = acc.id }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { selectedDestInternalId = acc.id },
                                            colors = RadioButtonDefaults.colors(selectedColor = DeepAubergine)
                                        )
                                        Column {
                                            Text(text = acc.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                            Text(text = "Sort: ${acc.formattedSortCode} • Acc: ${acc.accountNumber}", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                        }
                                    }
                                    Text(
                                        text = acc.formattedBalance,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // External Payee Selector
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Select Payee",
                                style = MaterialTheme.typography.labelMedium.copy(color = SecondaryText)
                            )
                            TextButton(onClick = { showNewPayeeModal = true }) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = NatWestPurple)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Payee", color = NatWestPurple, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(payees) { p ->
                                val isSelected = p.id == selectedPayee?.id
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = if (isSelected) PaleLavender else SoftNeutralBg,
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, NatWestPurple) else null,
                                    modifier = Modifier
                                        .clickable { selectedPayee = p }
                                        .width(130.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(if (isSelected) DeepAubergine else Color(0xFFD6C7E2)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = p.avatarInitials,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = CleanWhite
                                                )
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = p.name,
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                            maxLines = 1
                                        )
                                        Text(
                                            text = p.bankName,
                                            style = MaterialTheme.typography.labelSmall.copy(color = SecondaryText, fontSize = 9.sp),
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }

                        selectedPayee?.let { p ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SoftNeutralBg,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(text = "Paying: ${p.name}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                        Text(text = "Sort Code: ${p.sortCode.chunked(2).joinToString("-")} • Acc: ${p.accountNumber}", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = SuccessGreenLight
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(12.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("CoP Match", style = MaterialTheme.typography.labelSmall.copy(color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 10.sp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Amount Input Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Amount to Pay",
                        style = MaterialTheme.typography.labelMedium.copy(color = SecondaryText)
                    )

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        placeholder = { Text("0.00") },
                        prefix = { Text("£ ", style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepAubergine
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NatWestPurple,
                            unfocusedBorderColor = PaleLavender
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("payment_amount_input")
                    )

                    // Quick Increment Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(10, 25, 50, 100).forEach { add ->
                            FilledTonalButton(
                                onClick = {
                                    val current = MoneyUtils.parsePoundsToPence(amountInput) ?: 0L
                                    val newPence = current + (add * 100)
                                    amountInput = String.format("%.2f", newPence / 100.0)
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = PaleLavender),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("+$add", style = MaterialTheme.typography.labelMedium.copy(color = DeepAubergine, fontWeight = FontWeight.Bold))
                            }
                        }
                    }

                    // Reference Field
                    OutlinedTextField(
                        value = referenceInput,
                        onValueChange = { referenceInput = it },
                        label = { Text("Payment Reference") },
                        placeholder = { Text("e.g. Dinner split, Rent") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NatWestPurple,
                            unfocusedBorderColor = PaleLavender
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("payment_reference_input")
                    )

                    // Immediate vs Scheduled Pill
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Send Immediately via Faster Payments",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "Arrives in seconds 24/7 with zero fees",
                                style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                            )
                        }
                        Switch(
                            checked = isImmediate,
                            onCheckedChange = { isImmediate = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CleanWhite,
                                checkedTrackColor = DeepAubergine
                            )
                        )
                    }
                }
            }
        }

        // Review & Pay Button
        item {
            Button(
                onClick = {
                    val pence = MoneyUtils.parsePoundsToPence(amountInput)
                    if (pence == null || pence <= 0) {
                        Toast.makeText(context, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (!isInternalTransferMode && selectedPayee == null) {
                        Toast.makeText(context, "Please select a payee", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    showConfirmationDialog = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_payment_button")
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Review & Confirm Payment",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }

    // Confirmation & Biometric Authorization Dialog
    if (showConfirmationDialog) {
        val pence = MoneyUtils.parsePoundsToPence(amountInput) ?: 0L
        AlertDialog(
            onDismissRequest = { if (!isAuthenticating) showConfirmationDialog = false },
            title = {
                Text(
                    text = "Confirm UK Faster Payment",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "You are sending ${MoneyUtils.formatPence(pence)} from ${sourceAccount?.name}.",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    HorizontalDivider(color = PaleLavender)

                    if (isInternalTransferMode) {
                        val destAcc = accounts.find { it.id == selectedDestInternalId }
                        DetailRow("Destination Account", destAcc?.name ?: "")
                    } else {
                        DetailRow("Recipient", selectedPayee?.name ?: "")
                        DetailRow("Sort Code", selectedPayee?.sortCode?.chunked(2)?.joinToString("-") ?: "")
                        DetailRow("Account Number", selectedPayee?.accountNumber ?: "")
                    }

                    DetailRow("Amount", MoneyUtils.formatPence(pence))
                    DetailRow("Reference", referenceInput.ifBlank { "FPS Transfer" })
                    DetailRow("Network", "Faster Payments System (FPS)")

                    // Reassurance notice
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SuccessGreenLight,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Confirmation of Payee validated. Account is safe.",
                                style = MaterialTheme.typography.bodySmall.copy(color = SuccessGreen, fontWeight = FontWeight.Medium, fontSize = 11.sp)
                            )
                        }
                    }

                    if (isAuthenticating) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(color = DeepAubergine, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Authorizing via Biometric Security...", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isAuthenticating = true
                        if (isInternalTransferMode) {
                            val success = viewModel.transferBetweenAccounts(
                                sourceAccountId = selectedSourceId,
                                destAccountId = selectedDestInternalId,
                                amountPence = pence,
                                reference = referenceInput
                            )
                            isAuthenticating = false
                            if (success) {
                                showConfirmationDialog = false
                                amountInput = ""
                                referenceInput = ""
                            }
                        } else {
                            val payee = selectedPayee ?: return@Button
                            val success = viewModel.makePayment(
                                sourceAccountId = selectedSourceId,
                                payeeName = payee.name,
                                sortCode = payee.sortCode,
                                accountNumber = payee.accountNumber,
                                amountPence = pence,
                                reference = referenceInput,
                                isImmediate = isImmediate
                            )
                            isAuthenticating = false
                            if (success) {
                                showConfirmationDialog = false
                                amountInput = ""
                                referenceInput = ""
                            }
                        }
                    },
                    enabled = !isAuthenticating,
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Authorize & Send")
                }
            },
            dismissButton = {
                if (!isAuthenticating) {
                    TextButton(onClick = { showConfirmationDialog = false }) {
                        Text("Cancel")
                    }
                }
            }
        )
    }

    // Success Receipt Voucher Dialog
    activeReceipt?.let { receipt ->
        AlertDialog(
            onDismissRequest = { viewModel.dismissReceipt() },
            title = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        shape = CircleShape,
                        color = SuccessGreenLight,
                        modifier = Modifier.size(60.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(34.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Payment Sent Successfully",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                    )
                    Text(
                        text = receipt.formattedAmount,
                        style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold, color = PrimaryText)
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HorizontalDivider(color = PaleLavender)
                    DetailRow("Recipient", receipt.payeeName)
                    DetailRow("Sort Code", receipt.sortCode.chunked(2).joinToString("-"))
                    DetailRow("Account Number", receipt.accountNumber)
                    DetailRow("From", receipt.sourceAccountName)
                    DetailRow("Reference", receipt.reference)
                    DetailRow("Payment Ref (FPS)", receipt.paymentReference)
                    DetailRow("Date & Time", receipt.formattedDate)
                    DetailRow("Network", receipt.settlementType)
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.dismissReceipt() },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Done")
                }
            }
        )
    }

    // Add New Payee Dialog
    if (showNewPayeeModal) {
        var newName by remember { mutableStateOf("") }
        var newSortCode by remember { mutableStateOf("") }
        var newAccountNumber by remember { mutableStateOf("") }
        var newBank by remember { mutableStateOf("") }
        var newRef by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showNewPayeeModal = false },
            title = {
                Text(
                    text = "Add New UK Payee",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Enter UK account details. NatWest validates name against Confirmation of Payee (CoP) standards.",
                        style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                    )

                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Account Holder / Business Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newSortCode,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) newSortCode = it },
                        label = { Text("Sort Code (6 digits)") },
                        placeholder = { Text("e.g. 601234") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newAccountNumber,
                        onValueChange = { if (it.length <= 8 && it.all { c -> c.isDigit() }) newAccountNumber = it },
                        label = { Text("Account Number (8 digits)") },
                        placeholder = { Text("e.g. 98744821") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newBank,
                        onValueChange = { newBank = it },
                        label = { Text("Bank Name (Optional)") },
                        placeholder = { Text("e.g. NatWest, Barclays, HSBC") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newRef,
                        onValueChange = { newRef = it },
                        label = { Text("Default Reference (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ok = viewModel.addPayee(
                            name = newName,
                            sortCode = newSortCode,
                            accountNumber = newAccountNumber,
                            bankName = newBank,
                            reference = newRef
                        )
                        if (ok) {
                            showNewPayeeModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("Save Payee")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewPayeeModal = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Error Snackbar or Dialog
    errorMessage?.let { error ->
        AlertDialog(
            onDismissRequest = { viewModel.clearError() },
            title = { Text("Payment Notice", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)) },
            text = { Text(error, style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = { viewModel.clearError() },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("OK")
                }
            }
        )
    }
}
