package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BankingRepository
import com.example.data.PaymentReceipt
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class SubScreen {
    SAVINGS_HUB,
    SPENDING_INSIGHTS,
    BORROWING_HUB,
    STATEMENTS_ARCHIVE,
    SUPPORT_CORA,
    SECURITY_HUB
}

class BankingViewModel(
    val repository: BankingRepository = BankingRepository()
) : ViewModel() {

    // Repository Flows
    val accounts: StateFlow<List<Account>> = repository.accounts
    val transactions: StateFlow<List<Transaction>> = repository.transactions
    val payees: StateFlow<List<Payee>> = repository.payees
    val cards: StateFlow<List<CardDetails>> = repository.cards
    val savingsGoals: StateFlow<List<SavingsGoal>> = repository.savingsGoals
    val budgets: StateFlow<List<BudgetCategory>> = repository.budgets
    val securityEvents: StateFlow<List<SecurityEvent>> = repository.securityEvents
    val chatMessages: StateFlow<List<SupportMessage>> = repository.chatMessages
    val isPrivacyEnabled: StateFlow<Boolean> = repository.isPrivacyEnabled
    val isBiometricsEnabled: StateFlow<Boolean> = repository.isBiometricsEnabled

    // UI States
    private val _currentTab = MutableStateFlow(0) // 0: Home, 1: Accounts, 2: Payments, 3: Cards, 4: Profile
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    private val _activeSubScreen = MutableStateFlow<SubScreen?>(null)
    val activeSubScreen: StateFlow<SubScreen?> = _activeSubScreen.asStateFlow()

    private val _selectedAccountId = MutableStateFlow("acc_current")
    val selectedAccountId: StateFlow<String> = _selectedAccountId.asStateFlow()

    private val _selectedCardId = MutableStateFlow("card_debit")
    val selectedCardId: StateFlow<String> = _selectedCardId.asStateFlow()

    // Transaction Filtering
    private val _txSearchQuery = MutableStateFlow("")
    val txSearchQuery: StateFlow<String> = _txSearchQuery.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow<TransactionCategory?>(null)
    val selectedCategoryFilter: StateFlow<TransactionCategory?> = _selectedCategoryFilter.asStateFlow()

    private val _selectedTypeFilter = MutableStateFlow("All") // "All", "Outgoing", "Incoming", "Pending", "Direct Debits"
    val selectedTypeFilter: StateFlow<String> = _selectedTypeFilter.asStateFlow()

    // Dialog & Receipt States
    private val _activeReceipt = MutableStateFlow<PaymentReceipt?>(null)
    val activeReceipt: StateFlow<PaymentReceipt?> = _activeReceipt.asStateFlow()

    private val _inspectedTransaction = MutableStateFlow<Transaction?>(null)
    val inspectedTransaction: StateFlow<Transaction?> = _inspectedTransaction.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _successToast = MutableStateFlow<String?>(null)
    val successToast: StateFlow<String?> = _successToast.asStateFlow()

    // Filtered Transactions Flow
    val filteredTransactions: StateFlow<List<Transaction>> = combine(
        transactions,
        selectedAccountId,
        txSearchQuery,
        selectedCategoryFilter,
        selectedTypeFilter
    ) { allTx, accId, query, catFilter, typeFilter ->
        allTx.filter { tx ->
            val matchAccount = (accId == "ALL" || tx.accountId == accId)
            val matchQuery = query.isBlank() ||
                    tx.merchantName.contains(query, ignoreCase = true) ||
                    tx.reference.contains(query, ignoreCase = true) ||
                    tx.formattedAmount.contains(query, ignoreCase = true)
            val matchCategory = catFilter == null || tx.category == catFilter
            val matchType = when (typeFilter) {
                "Outgoing" -> tx.isDebit
                "Incoming" -> !tx.isDebit
                "Pending" -> tx.status == TransactionStatus.PENDING
                "Direct Debits" -> tx.paymentMethod == PaymentMethod.DIRECT_DEBIT
                else -> true
            }
            matchAccount && matchQuery && matchCategory && matchType
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Aggregates
    val totalAvailablePence: StateFlow<Long> = accounts.map { list ->
        list.filter { it.type != AccountType.CREDIT_CARD }.sumOf { it.availablePence }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val currentMonthSpendPence: StateFlow<Long> = transactions.map { list ->
        list.filter { it.isDebit && it.category != TransactionCategory.TRANSFER }.sumOf { -it.amountPence }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val currentMonthIncomePence: StateFlow<Long> = transactions.map { list ->
        list.filter { !it.isDebit && it.category == TransactionCategory.INCOME }.sumOf { it.amountPence }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    fun selectTab(tabIndex: Int) {
        _currentTab.value = tabIndex
        _activeSubScreen.value = null
    }

    fun navigateToSubScreen(subScreen: SubScreen?) {
        _activeSubScreen.value = subScreen
    }

    fun selectAccount(accountId: String) {
        _selectedAccountId.value = accountId
    }

    fun selectCard(cardId: String) {
        _selectedCardId.value = cardId
    }

    fun setSearchQuery(query: String) {
        _txSearchQuery.value = query
    }

    fun setCategoryFilter(category: TransactionCategory?) {
        _selectedCategoryFilter.value = category
    }

    fun setTypeFilter(type: String) {
        _selectedTypeFilter.value = type
    }

    fun inspectTransaction(tx: Transaction?) {
        _inspectedTransaction.value = tx
    }

    fun dismissReceipt() {
        _activeReceipt.value = null
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun clearToast() {
        _successToast.value = null
    }

    fun togglePrivacy() {
        repository.togglePrivacyMode()
    }

    fun toggleBiometrics(enabled: Boolean) {
        repository.toggleBiometrics(enabled)
    }

    fun makePayment(
        sourceAccountId: String,
        payeeName: String,
        sortCode: String,
        accountNumber: String,
        amountPence: Long,
        reference: String,
        isImmediate: Boolean = true
    ): Boolean {
        val result = repository.processPayment(
            sourceAccountId = sourceAccountId,
            payeeName = payeeName,
            sortCode = sortCode,
            accountNumber = accountNumber,
            amountPence = amountPence,
            reference = reference,
            isImmediate = isImmediate
        )

        return result.fold(
            onSuccess = { receipt ->
                _activeReceipt.value = receipt
                _errorMessage.value = null
                true
            },
            onFailure = { error ->
                _errorMessage.value = error.message ?: "Payment could not be processed"
                false
            }
        )
    }

    fun transferBetweenAccounts(
        sourceAccountId: String,
        destAccountId: String,
        amountPence: Long,
        reference: String
    ): Boolean {
        val result = repository.transferBetweenOwnAccounts(
            sourceAccountId = sourceAccountId,
            destAccountId = destAccountId,
            amountPence = amountPence,
            reference = reference
        )

        return result.fold(
            onSuccess = { receipt ->
                _activeReceipt.value = receipt
                _errorMessage.value = null
                true
            },
            onFailure = { error ->
                _errorMessage.value = error.message ?: "Transfer failed"
                false
            }
        )
    }

    fun addPayee(
        name: String,
        sortCode: String,
        accountNumber: String,
        bankName: String,
        reference: String
    ): Boolean {
        val result = repository.addPayee(name, sortCode, accountNumber, bankName, reference)
        return result.fold(
            onSuccess = {
                _successToast.value = "Payee ${it.name} added successfully!"
                true
            },
            onFailure = {
                _errorMessage.value = it.message ?: "Could not add payee"
                false
            }
        )
    }

    fun toggleCardFreeze(cardId: String) {
        repository.toggleCardFreeze(cardId)
    }

    fun toggleCardControl(cardId: String, controlType: String, enabled: Boolean) {
        repository.toggleCardControl(cardId, controlType, enabled)
    }

    fun contributeToGoal(goalId: String, amountPence: Long) {
        val result = repository.contributeToGoal(goalId, amountPence)
        result.fold(
            onSuccess = {
                _successToast.value = "Added ${MoneyUtils.formatPence(amountPence)} to ${it.title}!"
            },
            onFailure = {
                _errorMessage.value = it.message ?: "Goal contribution failed"
            }
        )
    }

    fun createSavingsGoal(title: String, targetPence: Long, targetDate: String, category: String) {
        repository.createSavingsGoal(title, targetPence, targetDate, category)
        _successToast.value = "New savings goal '$title' created!"
    }

    fun updateBudgetLimit(category: TransactionCategory, newLimitPence: Long) {
        repository.updateBudgetLimit(category, newLimitPence)
        _successToast.value = "Budget for ${category.displayName} updated"
    }

    fun updateTxCategory(txId: String, newCategory: TransactionCategory) {
        repository.updateTransactionCategory(txId, newCategory)
        _inspectedTransaction.value = _inspectedTransaction.value?.copy(category = newCategory)
        _successToast.value = "Category updated to ${newCategory.displayName}"
    }

    fun sendCoraMessage(text: String) {
        if (text.isNotBlank()) {
            repository.sendCoraMessage(text)
        }
    }
}
