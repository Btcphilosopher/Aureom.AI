package com.example.model

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Monetary utilities ensuring integer minor units (pence) to prevent floating-point calculation errors.
 */
object MoneyUtils {
    private val ukLocale = Locale.UK
    private val currencyFormat = NumberFormat.getCurrencyInstance(ukLocale).apply {
        maximumFractionDigits = 2
        minimumFractionDigits = 2
    }

    fun formatPence(pence: Long, showSign: Boolean = false): String {
        val pounds = pence.toDouble() / 100.0
        val formatted = currencyFormat.format(pounds)
        return if (showSign && pence > 0) "+$formatted" else formatted
    }

    fun parsePoundsToPence(poundsString: String): Long? {
        val clean = poundsString.replace("£", "").replace(",", "").trim()
        return try {
            val amount = clean.toDouble()
            (amount * 100).toLong()
        } catch (e: Exception) {
            null
        }
    }

    fun formatDate(timestampMs: Long, pattern: String = "dd MMM yyyy, HH:mm"): String {
        val sdf = SimpleDateFormat(pattern, Locale.UK)
        return sdf.format(Date(timestampMs))
    }
}

enum class AccountType(val displayName: String) {
    CURRENT("Current Account"),
    SAVINGS_REGULAR("Digital Regular Saver"),
    CASH_ISA("Cash ISA"),
    CREDIT_CARD("Reward Black Credit Card")
}

data class Account(
    val id: String,
    val name: String,
    val type: AccountType,
    val sortCode: String,
    val accountNumber: String,
    val balancePence: Long,
    val availablePence: Long,
    val creditLimitPence: Long = 0L,
    val interestRateText: String? = null,
    val isPrimary: Boolean = false,
    val iban: String = "GB29 NWBK 6012 34${accountNumber.takeLast(8)}"
) {
    val formattedBalance: String
        get() = MoneyUtils.formatPence(balancePence)

    val formattedAvailable: String
        get() = MoneyUtils.formatPence(availablePence)

    val formattedLimit: String
        get() = MoneyUtils.formatPence(creditLimitPence)

    val formattedSortCode: String
        get() = sortCode.chunked(2).joinToString("-")
}

enum class TransactionCategory(val displayName: String, val iconName: String) {
    GROCERIES("Groceries", "shopping_cart"),
    DINING("Dining & Drinks", "restaurant"),
    TRANSPORT("Transport & Travel", "directions_subway"),
    HOUSING("Housing & Bills", "home"),
    SUBSCRIPTIONS("Subscriptions", "subscriptions"),
    SHOPPING("Shopping", "shopping_bag"),
    UTILITIES("Utilities", "bolt"),
    ENTERTAINMENT("Entertainment", "movie"),
    INCOME("Salary & Income", "payments"),
    TRANSFER("Internal Transfer", "swap_horiz"),
    BANKING("Banking & Fees", "account_balance")
}

enum class TransactionStatus {
    COMPLETED,
    PENDING,
    REVERSED
}

enum class PaymentMethod(val displayName: String) {
    CONTACTLESS("Contactless Card"),
    FASTER_PAYMENTS("Faster Payments (FPS)"),
    DIRECT_DEBIT("Direct Debit"),
    STANDING_ORDER("Standing Order"),
    ONLINE_PURCHASE("Online Card Purchase"),
    ATM_WITHDRAWAL("Cash Machine (ATM)")
}

data class Transaction(
    val id: String,
    val accountId: String,
    val timestampMs: Long,
    val merchantName: String,
    val category: TransactionCategory,
    val amountPence: Long, // negative for debits/spending, positive for credits
    val status: TransactionStatus = TransactionStatus.COMPLETED,
    val runningBalancePence: Long,
    val reference: String,
    val paymentMethod: PaymentMethod,
    val cardLast4: String? = null
) {
    val isDebit: Boolean get() = amountPence < 0
    val formattedAmount: String get() = MoneyUtils.formatPence(amountPence, showSign = true)
    val formattedRunningBalance: String get() = MoneyUtils.formatPence(runningBalancePence)
    val formattedDate: String get() = MoneyUtils.formatDate(timestampMs, "dd MMM yyyy")
    val formattedTime: String get() = MoneyUtils.formatDate(timestampMs, "HH:mm")
}

data class Payee(
    val id: String,
    val name: String,
    val sortCode: String,
    val accountNumber: String,
    val bankName: String = "UK Bank",
    val defaultReference: String = "",
    val isFavourite: Boolean = false,
    val avatarInitials: String = name.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString("")
)

enum class CardType {
    DEBIT,
    CREDIT
}

data class CardDetails(
    val id: String,
    val accountId: String,
    val cardholderName: String,
    val cardNumberMasked: String, // "5354 •••• •••• 4821"
    val expiryDate: String, // "08/28"
    val cardType: CardType,
    val isFrozen: Boolean = false,
    val isOnlineEnabled: Boolean = true,
    val isContactlessEnabled: Boolean = true,
    val isCashMachineEnabled: Boolean = true,
    val isGamblingBlockEnabled: Boolean = true,
    val isGoogleWalletAdded: Boolean = true
)

data class SavingsGoal(
    val id: String,
    val title: String,
    val targetPence: Long,
    val currentPence: Long,
    val targetDateString: String,
    val category: String
) {
    val progressFraction: Float
        get() = if (targetPence > 0) (currentPence.toFloat() / targetPence.toFloat()).coerceIn(0f, 1f) else 0f

    val percentComplete: Int
        get() = (progressFraction * 100).toInt()

    val formattedCurrent: String get() = MoneyUtils.formatPence(currentPence)
    val formattedTarget: String get() = MoneyUtils.formatPence(targetPence)
}

data class BudgetCategory(
    val category: TransactionCategory,
    val monthlyLimitPence: Long,
    val currentSpentPence: Long
) {
    val progressFraction: Float
        get() = if (monthlyLimitPence > 0) (currentSpentPence.toFloat() / monthlyLimitPence.toFloat()).coerceIn(0f, 1f) else 0f

    val isOverBudget: Boolean get() = currentSpentPence > monthlyLimitPence
    val formattedLimit: String get() = MoneyUtils.formatPence(monthlyLimitPence)
    val formattedSpent: String get() = MoneyUtils.formatPence(currentSpentPence)
}

data class SecurityEvent(
    val id: String,
    val timestampMs: Long,
    val title: String,
    val description: String,
    val isSuccess: Boolean = true
) {
    val formattedDate: String get() = MoneyUtils.formatDate(timestampMs, "dd MMM yyyy, HH:mm")
}

data class SupportMessage(
    val id: String,
    val isFromUser: Boolean,
    val message: String,
    val timestampMs: Long = System.currentTimeMillis()
)
