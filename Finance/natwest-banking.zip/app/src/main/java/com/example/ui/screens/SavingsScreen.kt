package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MoneyUtils
import com.example.model.SavingsGoal
import com.example.ui.theme.*
import com.example.viewmodel.BankingViewModel
import kotlin.math.pow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavingsScreen(
    viewModel: BankingViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val goals by viewModel.savingsGoals.collectAsState()
    val accounts by viewModel.accounts.collectAsState()
    val isPrivacyEnabled by viewModel.isPrivacyEnabled.collectAsState()

    var showNewGoalDialog by remember { mutableStateOf(false) }
    var selectedGoalForDeposit by remember { mutableStateOf<SavingsGoal?>(null) }

    // Simulator Sliders State
    var simInitialDeposit by remember { mutableStateOf(1000f) }
    var simMonthlyContribution by remember { mutableStateOf(150f) }
    var simYears by remember { mutableStateOf(3f) }
    val simAerRate = 0.0385 // 3.85% AER

    // Compound Interest Calculation
    val totalMonths = (simYears * 12).toInt()
    val monthlyRate = simAerRate / 12.0
    var calculatedTotal = simInitialDeposit.toDouble() * (1 + simAerRate).pow(simYears.toDouble())
    var totalDeposited = simInitialDeposit.toDouble() + (simMonthlyContribution * totalMonths)
    for (m in 1..totalMonths) {
        val remainingYears = (totalMonths - m) / 12.0
        calculatedTotal += simMonthlyContribution * (1 + simAerRate).pow(remainingYears)
    }
    val totalInterestEarned = (calculatedTotal - totalDeposited).coerceAtLeast(0.0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Savings & Goals",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = DeepAubergine)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .testTag("savings_screen_content"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // NatWest Savings Products Overview
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "My Savings Accounts",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                        )

                        accounts.filter { it.type == com.example.model.AccountType.SAVINGS_REGULAR || it.type == com.example.model.AccountType.CASH_ISA }.forEach { acc ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = SoftNeutralBg,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = acc.name, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                                        Text(text = acc.interestRateText ?: "Competitive AER", style = MaterialTheme.typography.bodySmall.copy(color = SuccessGreen, fontWeight = FontWeight.SemiBold))
                                    }
                                    Text(
                                        text = if (isPrivacyEnabled) "£ ••••" else acc.formattedBalance,
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Savings Goals List
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Target Savings Goals",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = PrimaryText)
                    )
                    TextButton(onClick = { showNewGoalDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = NatWestPurple)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Goal", color = NatWestPurple, fontWeight = FontWeight.Bold)
                    }
                }
            }

            items(goals) { goal ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = goal.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Target Date: ${goal.targetDateString}  •  ${goal.category}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = PaleLavender
                            ) {
                                Text(
                                    text = "${goal.percentComplete}%",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Progress Bar
                        LinearProgressIndicator(
                            progress = { goal.progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = NatWestPurple,
                            trackColor = PaleLavender
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Saved: ${if (isPrivacyEnabled) "£ •••" else goal.formattedCurrent}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = DeepAubergine)
                            )
                            Text(
                                text = "Target: ${goal.formattedTarget}",
                                style = MaterialTheme.typography.bodyMedium.copy(color = SecondaryText)
                            )
                        }

                        // Deposit Button
                        Button(
                            onClick = { selectedGoalForDeposit = goal },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Deposit to this Goal")
                        }
                    }
                }
            }

            // Interactive Savings Simulator Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = DeepAubergine)
                            Text(
                                text = "Savings Growth Simulator",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                            )
                        }

                        Text(
                            text = "Model compound returns with NatWest Digital Regular Saver rate (3.85% AER).",
                            style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                        )

                        // Slider 1: Initial Deposit
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Initial Deposit", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                Text("£${simInitialDeposit.toInt()}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Slider(
                                value = simInitialDeposit,
                                onValueChange = { simInitialDeposit = it },
                                valueRange = 0f..10000f,
                                steps = 19,
                                colors = SliderDefaults.colors(thumbColor = DeepAubergine, activeTrackColor = DeepAubergine)
                            )
                        }

                        // Slider 2: Monthly Deposit
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Monthly Contribution", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                Text("£${simMonthlyContribution.toInt()} / month", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Slider(
                                value = simMonthlyContribution,
                                onValueChange = { simMonthlyContribution = it },
                                valueRange = 25f..1000f,
                                steps = 38,
                                colors = SliderDefaults.colors(thumbColor = DeepAubergine, activeTrackColor = DeepAubergine)
                            )
                        }

                        // Slider 3: Time Horizon
                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Time Horizon", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                Text("${simYears.toInt()} Years", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Slider(
                                value = simYears,
                                onValueChange = { simYears = it },
                                valueRange = 1f..10f,
                                steps = 8,
                                colors = SliderDefaults.colors(thumbColor = DeepAubergine, activeTrackColor = DeepAubergine)
                            )
                        }

                        // Result Box
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PaleLavender,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Projected Balance in ${simYears.toInt()} Years", style = MaterialTheme.typography.bodySmall.copy(color = DeepAubergine))
                                Text(
                                    text = String.format("£%,.2f", calculatedTotal),
                                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                                )
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Your Deposits: £%,.2f".format(totalDeposited), style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                    Text("Interest Earned: +£%,.2f".format(totalInterestEarned), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = SuccessGreen))
                                }
                            }
                        }

                        Text(
                            text = "Figures are projections based on assumed interest rates and do not represent a guaranteed return.",
                            style = MaterialTheme.typography.labelSmall.copy(color = TertiaryText, fontSize = 10.sp)
                        )
                    }
                }
            }
        }
    }

    // Deposit to Goal Dialog
    selectedGoalForDeposit?.let { goal ->
        var depositAmount by remember { mutableStateOf("50.00") }

        AlertDialog(
            onDismissRequest = { selectedGoalForDeposit = null },
            title = {
                Text("Deposit to ${goal.title}", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine))
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Enter amount to transfer from Select Current Account into this goal.")
                    OutlinedTextField(
                        value = depositAmount,
                        onValueChange = { depositAmount = it },
                        prefix = { Text("£ ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pence = MoneyUtils.parsePoundsToPence(depositAmount) ?: 0L
                        if (pence > 0) {
                            viewModel.contributeToGoal(goal.id, pence)
                            selectedGoalForDeposit = null
                        } else {
                            Toast.makeText(context, "Enter a valid amount", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("Confirm Deposit")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedGoalForDeposit = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add New Goal Dialog
    if (showNewGoalDialog) {
        var goalTitle by remember { mutableStateOf("") }
        var goalTarget by remember { mutableStateOf("") }
        var goalDate by remember { mutableStateOf("31 Dec 2027") }
        var goalCat by remember { mutableStateOf("General") }

        AlertDialog(
            onDismissRequest = { showNewGoalDialog = false },
            title = {
                Text("Create Savings Goal", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine))
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = goalTitle,
                        onValueChange = { goalTitle = it },
                        label = { Text("Goal Name") },
                        placeholder = { Text("e.g. Wedding, New Car") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = goalTarget,
                        onValueChange = { goalTarget = it },
                        label = { Text("Target Amount") },
                        prefix = { Text("£ ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = goalDate,
                        onValueChange = { goalDate = it },
                        label = { Text("Target Date") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pence = MoneyUtils.parsePoundsToPence(goalTarget) ?: 0L
                        if (goalTitle.isNotBlank() && pence > 0) {
                            viewModel.createSavingsGoal(goalTitle, pence, goalDate, goalCat)
                            showNewGoalDialog = false
                        } else {
                            Toast.makeText(context, "Fill all fields correctly", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("Create Goal")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewGoalDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
