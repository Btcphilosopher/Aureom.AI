package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BudgetCategory
import com.example.model.MoneyUtils
import com.example.model.TransactionCategory
import com.example.ui.theme.*
import com.example.viewmodel.BankingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpendingInsightsScreen(
    viewModel: BankingViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentSpendPence by viewModel.currentMonthSpendPence.collectAsState()
    val currentIncomePence by viewModel.currentMonthIncomePence.collectAsState()
    val budgets by viewModel.budgets.collectAsState()
    val isPrivacyEnabled by viewModel.isPrivacyEnabled.collectAsState()

    var editingBudget by remember { mutableStateOf<BudgetCategory?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Spending & Budgets",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = DeepAubergine)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .testTag("spending_insights_content"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Net Cash Flow Header Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "October Cash Flow Overview",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Money In (Income)", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                Text(
                                    text = if (isPrivacyEnabled) "£ •••" else MoneyUtils.formatPence(currentIncomePence),
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = SuccessGreen)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Money Out (Spend)", style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText))
                                Text(
                                    text = if (isPrivacyEnabled) "£ •••" else MoneyUtils.formatPence(currentSpendPence),
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = PrimaryText)
                                )
                            }
                        }

                        val netSavings = currentIncomePence - currentSpendPence
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (netSavings >= 0) SuccessGreenLight else ErrorRedLight,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Net Cash Surplus Saved",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (netSavings >= 0) SuccessGreen else ErrorRed
                                    )
                                )
                                Text(
                                    text = if (isPrivacyEnabled) "£ •••" else MoneyUtils.formatPence(netSavings),
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (netSavings >= 0) SuccessGreen else ErrorRed
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Monthly Category Budgets Tracker
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Category Budgets & Limits",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = PrimaryText)
                    )
                }
            }

            items(budgets) { budget ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = PaleLavender,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Category,
                                            contentDescription = null,
                                            tint = DeepAubergine,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = budget.category.displayName,
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "Limit: ${budget.formattedLimit} / month",
                                        style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                                    )
                                }
                            }

                            TextButton(onClick = { editingBudget = budget }) {
                                Text("Edit Limit", color = NatWestPurple, style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        // Progress Bar
                        LinearProgressIndicator(
                            progress = { budget.progressFraction.coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (budget.isOverBudget) ErrorRed else NatWestPurple,
                            trackColor = PaleLavender
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Spent: ${if (isPrivacyEnabled) "£ •••" else budget.formattedSpent}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (budget.isOverBudget) ErrorRed else PrimaryText
                                )
                            )
                            val remaining = (budget.monthlyLimitPence - budget.currentSpentPence).coerceAtLeast(0L)
                            Text(
                                text = "Remaining: ${if (isPrivacyEnabled) "£ •••" else MoneyUtils.formatPence(remaining)}",
                                style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                            )
                        }
                    }
                }
            }

            // Recurring Subscriptions & Regular Outgoings
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Detected Recurring Subscriptions",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepAubergine)
                        )
                        Text(
                            text = "Total Monthly Subscriptions: £240.47",
                            style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText)
                        )

                        SubscriptionRow("Westminster Council Tax", "£164.00", "Monthly Direct Debit")
                        SubscriptionRow("British Gas Utilities", "£114.50", "Variable Direct Debit")
                        SubscriptionRow("PureGym London Bridge", "£34.99", "Monthly Direct Debit")
                        SubscriptionRow("Netflix UK 4K", "£15.99", "Monthly Card Charge")
                        SubscriptionRow("Spotify Premium", "£10.99", "Monthly Card Charge")
                    }
                }
            }
        }
    }

    // Edit Budget Modal
    editingBudget?.let { b ->
        var newLimitInput by remember { mutableStateOf((b.monthlyLimitPence / 100).toString()) }

        AlertDialog(
            onDismissRequest = { editingBudget = null },
            title = {
                Text("Edit ${b.category.displayName} Budget", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Set monthly spending target in pounds:")
                    OutlinedTextField(
                        value = newLimitInput,
                        onValueChange = { newLimitInput = it },
                        prefix = { Text("£ ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pence = MoneyUtils.parsePoundsToPence(newLimitInput) ?: 0L
                        if (pence > 0) {
                            viewModel.updateBudgetLimit(b.category, pence)
                            editingBudget = null
                        } else {
                            Toast.makeText(context, "Enter a valid amount", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepAubergine)
                ) {
                    Text("Save Limit")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingBudget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SubscriptionRow(name: String, amount: String, billingType: String) {
    Surface(
        color = SoftNeutralBg,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                Text(text = billingType, style = MaterialTheme.typography.bodySmall.copy(color = SecondaryText, fontSize = 11.sp))
            }
            Text(text = amount, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
        }
    }
}
