package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NatWest Design System Colors
val DeepAubergine = Color(0xFF42145F)
val NatWestPurple = Color(0xFF6A1B9A)
val VibrantViolet = Color(0xFF7B2CBF)
val PaleLavender = Color(0xFFF3ECF8)
val CleanWhite = Color(0xFFFFFFFF)
val SoftNeutralBg = Color(0xFFF7F6F8)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceCardSecondaryLight = Color(0xFFF0EBF4)

// Text Colors Light
val PrimaryText = Color(0xFF211B24)
val SecondaryText = Color(0xFF6B6570)
val TertiaryText = Color(0xFF968F9C)

// Semantic Colors
val SuccessGreen = Color(0xFF16845B)
val SuccessGreenLight = Color(0xFFE8F5EE)
val WarningAmber = Color(0xFFA65D00)
val WarningAmberLight = Color(0xFFFEF4E6)
val ErrorRed = Color(0xFFC62828)
val ErrorRedLight = Color(0xFFFDE8E8)
val InfoBlue = Color(0xFF1565C0)

// Dark Theme Colors
val DarkBackground = Color(0xFF140E1B)
val DarkSurface = Color(0xFF1F162A)
val DarkSurfaceCard = Color(0xFF2C203B)
val DarkSurfaceCardSecondary = Color(0xFF38294B)
val DarkPrimaryText = Color(0xFFF7F4FA)
val DarkSecondaryText = Color(0xFFB5ACB9)
val DarkAubergine = Color(0xFF320E4A)
val DarkViolet = Color(0xFF9D4EDD)
