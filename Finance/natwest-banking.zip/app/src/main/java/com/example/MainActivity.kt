package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.NatWestTopBar
import com.example.ui.components.TransactionDetailDialog
import com.example.ui.screens.*
import com.example.ui.theme.DeepAubergine
import com.example.ui.theme.NatWestTheme
import com.example.ui.theme.PaleLavender
import com.example.viewmodel.BankingViewModel
import com.example.viewmodel.SubScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NatWestTheme {
                NatWestBankingApp()
            }
        }
    }
}

@Composable
fun NatWestBankingApp(
    viewModel: BankingViewModel = viewModel()
) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsState()
    val activeSubScreen by viewModel.activeSubScreen.collectAsState()
    val isPrivacyEnabled by viewModel.isPrivacyEnabled.collectAsState()
    val inspectedTx by viewModel.inspectedTransaction.collectAsState()
    val toastMessage by viewModel.successToast.collectAsState()

    // Handle toast notifications
    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    // Android Hardware / Gesture Back Navigation Handling
    BackHandler(enabled = activeSubScreen != null || currentTab != 0) {
        if (activeSubScreen != null) {
            viewModel.navigateToSubScreen(null)
        } else if (currentTab != 0) {
            viewModel.selectTab(0)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (activeSubScreen == null) {
                NatWestTopBar(
                    isPrivacyEnabled = isPrivacyEnabled,
                    onTogglePrivacy = { viewModel.togglePrivacy() },
                    onOpenSecurity = { viewModel.navigateToSubScreen(SubScreen.SECURITY_HUB) },
                    onOpenCora = { viewModel.navigateToSubScreen(SubScreen.SUPPORT_CORA) },
                    modifier = Modifier.statusBarsPadding()
                )
            }
        },
        bottomBar = {
            if (activeSubScreen == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 3.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.testTag("bottom_navigation_bar")
                ) {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { viewModel.selectTab(0) },
                        icon = {
                            Icon(
                                if (currentTab == 0) Icons.Default.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = { Text("Home") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepAubergine,
                            indicatorColor = PaleLavender
                        ),
                        modifier = Modifier.testTag("nav_tab_home")
                    )

                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = { viewModel.selectTab(1) },
                        icon = {
                            Icon(
                                if (currentTab == 1) Icons.Default.AccountBalance else Icons.Outlined.AccountBalance,
                                contentDescription = "Accounts"
                            )
                        },
                        label = { Text("Accounts") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepAubergine,
                            indicatorColor = PaleLavender
                        ),
                        modifier = Modifier.testTag("nav_tab_accounts")
                    )

                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { viewModel.selectTab(2) },
                        icon = {
                            Icon(
                                if (currentTab == 2) Icons.Default.Send else Icons.Outlined.Send,
                                contentDescription = "Payments"
                            )
                        },
                        label = { Text("Payments") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepAubergine,
                            indicatorColor = PaleLavender
                        ),
                        modifier = Modifier.testTag("nav_tab_payments")
                    )

                    NavigationBarItem(
                        selected = currentTab == 3,
                        onClick = { viewModel.selectTab(3) },
                        icon = {
                            Icon(
                                if (currentTab == 3) Icons.Default.CreditCard else Icons.Outlined.CreditCard,
                                contentDescription = "Cards"
                            )
                        },
                        label = { Text("Cards") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepAubergine,
                            indicatorColor = PaleLavender
                        ),
                        modifier = Modifier.testTag("nav_tab_cards")
                    )

                    NavigationBarItem(
                        selected = currentTab == 4,
                        onClick = { viewModel.selectTab(4) },
                        icon = {
                            Icon(
                                if (currentTab == 4) Icons.Default.Person else Icons.Outlined.Person,
                                contentDescription = "Profile"
                            )
                        },
                        label = { Text("Profile") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepAubergine,
                            indicatorColor = PaleLavender
                        ),
                        modifier = Modifier.testTag("nav_tab_profile")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeSubScreen) {
                SubScreen.SAVINGS_HUB -> {
                    SavingsScreen(
                        viewModel = viewModel,
                        onNavigateBack = { viewModel.navigateToSubScreen(null) }
                    )
                }
                SubScreen.SPENDING_INSIGHTS -> {
                    SpendingInsightsScreen(
                        viewModel = viewModel,
                        onNavigateBack = { viewModel.navigateToSubScreen(null) }
                    )
                }
                SubScreen.BORROWING_HUB -> {
                    BorrowingScreen(
                        viewModel = viewModel,
                        onNavigateBack = { viewModel.navigateToSubScreen(null) }
                    )
                }
                SubScreen.SUPPORT_CORA -> {
                    CoraAssistantScreen(
                        viewModel = viewModel,
                        onNavigateBack = { viewModel.navigateToSubScreen(null) }
                    )
                }
                SubScreen.SECURITY_HUB -> {
                    SecurityHubScreen(
                        viewModel = viewModel,
                        onNavigateBack = { viewModel.navigateToSubScreen(null) }
                    )
                }
                null -> {
                    when (currentTab) {
                        0 -> HomeScreen(
                            viewModel = viewModel,
                            onNavigateToTab = { viewModel.selectTab(it) }
                        )
                        1 -> AccountsScreen(
                            viewModel = viewModel,
                            onNavigateToPayment = { viewModel.selectTab(2) }
                        )
                        2 -> PaymentScreen(
                            viewModel = viewModel,
                            onNavigateBack = { viewModel.selectTab(0) }
                        )
                        3 -> CardsScreen(viewModel = viewModel)
                        4 -> ProfileScreen(viewModel = viewModel)
                    }
                }
                else -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToTab = { viewModel.selectTab(it) }
                    )
                }
            }
        }
    }

    // Modal Transaction Inspection
    inspectedTx?.let { tx ->
        TransactionDetailDialog(
            transaction = tx,
            onDismiss = { viewModel.inspectTransaction(null) },
            onCategoryChange = { newCat ->
                viewModel.updateTxCategory(tx.id, newCat)
            }
        )
    }
}
