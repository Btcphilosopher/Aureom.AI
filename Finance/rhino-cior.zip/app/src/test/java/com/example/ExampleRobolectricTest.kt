package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.*
import com.example.domain.engine.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches RHINO CIOR`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("RHINO CIOR", appName)
    }

    @Test
    fun `benchmark engine generates valid transactions and methodologies`() {
        val txs = BenchmarkCalculationEngine.generateSyntheticTransactions(3.84)
        assertTrue(txs.isNotEmpty())
        assertTrue(txs.size > 200)

        val methodA = BenchmarkCalculationEngine.calculateMethodA(txs, Tenor.ON)
        val methodB = BenchmarkCalculationEngine.calculateMethodB(txs, Tenor.ON)
        val methodC = BenchmarkCalculationEngine.calculateMethodC(txs, Tenor.ON)
        val methodD = BenchmarkCalculationEngine.calculateMethodD(txs, Tenor.ON)

        assertTrue(methodA.calculatedRate in 3.50..4.50)
        assertTrue(methodB.calculatedRate in 3.50..4.50)
        assertTrue(methodC.calculatedRate in 3.50..4.50)
        assertTrue(methodD.calculatedRate in 3.50..4.50)
        assertTrue(methodB.excludedTransactions > 0)

        val quality = BenchmarkCalculationEngine.calculateQualityScore(txs)
        assertTrue(quality.totalScore in 70..100)
    }

    @Test
    fun `yield curve engine interpolates and calculates discount factors correctly`() {
        val spot = YieldCurveEngine.interpolate(0.25, CurveModelType.MONOTONIC_HERMITE, 3.84)
        assertTrue(spot in 3.80..4.20)

        val nsSpot = YieldCurveEngine.interpolate(1.0, CurveModelType.NELSON_SIEGEL, 3.84)
        assertTrue(nsSpot in 3.80..4.60)

        val df = YieldCurveEngine.calculateDiscountFactor(4.0, 1.0)
        assertTrue(df in 0.95..0.98)

        val matrix = YieldCurveEngine.generateForwardMatrix(CurveModelType.MONOTONIC_HERMITE, 3.84)
        assertTrue(matrix.isNotEmpty())
        assertEquals("1Mx3M", matrix.first().label)
    }

    @Test
    fun `pricing engine calculates loan, swap, option and futures correctly`() {
        val loan = PricingEngine.priceLoan(500.0, 3.0, 4.01, 175.0)
        assertEquals(5.76, loan.allInCouponPct, 0.01)
        assertTrue(loan.annualCashInterestMillionUsd > 20.0)
        assertTrue(loan.modifiedDurationYears in 2.0..3.5)
        assertTrue(loan.dv01ThousandsUsd > 100.0)

        val swap = PricingEngine.priceSwap(SwapType.CIOR_VS_SOFR, 100.0, 5.0, 3.84, 3.71)
        assertTrue(swap.fixedParRatePct > 0)
        assertEquals(13.0, swap.basisSpreadBp, 0.1)

        val option = PricingEngine.priceOption(OptionInstrument.CAP, 4.25, 100.0, 3.0)
        assertTrue(option.premiumUsdThousands > 0)
        assertTrue(option.delta in 0.0..1.0)
    }

    @Test
    fun `stress engine calculates indices and shifts correctly`() {
        val scenarios = StressTestEngine.getStandardScenarios()
        assertTrue(scenarios.size >= 6)

        val baseScenario = scenarios.first()
        val baseLiq = StressTestEngine.calculateLiquidityIndex(baseScenario)
        assertTrue(baseLiq.cliScore >= 65.0)
        assertEquals(StressLevel.NORMAL, baseLiq.cfsiStatus)

        val extremeScenario = scenarios.find { it.id == "SCEN-300" }!!
        val extremeLiq = StressTestEngine.calculateLiquidityIndex(extremeScenario)
        assertTrue(extremeLiq.cliScore < baseLiq.cliScore)
        assertEquals(StressLevel.CRISIS, extremeLiq.cfsiStatus)
    }
}
