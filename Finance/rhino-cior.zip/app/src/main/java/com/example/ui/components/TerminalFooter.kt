package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TerminalFooter(
    qualityScore: Int = 87,
    cliScore: Double = 71.4,
    onOpenDisclaimer: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(width = 0.5.dp, color = TerminalBorder)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.horizontalScroll(rememberScrollState())
        ) {
            Text(
                text = "RHINOBANK / RHINOQUANT",
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "•",
                fontFamily = RobotoMonoFontFamily,
                fontSize = 10.sp,
                color = TextMuted
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "CIOR RESEARCH TERMINAL",
                fontFamily = InterFontFamily,
                fontSize = 10.sp,
                color = TextMuted
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .background(TerminalBackground)
                    .border(0.5.dp, TerminalBorder)
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "Q-SCORE: $qualityScore/100",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    color = RateGreen,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .background(TerminalBackground)
                    .border(0.5.dp, TerminalBorder)
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "CLI: $cliScore",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    color = CyanAccent,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .testTag("regulatory_disclaimer_button")
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, AmberMuted)
                    .clickable { onOpenDisclaimer() }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "DISCLAIMER",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    color = AmberAccent,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
