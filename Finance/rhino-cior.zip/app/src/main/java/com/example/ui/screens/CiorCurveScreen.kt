package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CurveModelType
import com.example.data.model.CurvePoint
import com.example.data.model.ForwardRateMatrixItem
import com.example.ui.components.InstitutionalCanvasChart
import com.example.ui.theme.*

@Composable
fun CiorCurveScreen(
    curvePoints: List<CurvePoint>,
    forwardMatrix: List<ForwardRateMatrixItem>,
    activeModel: CurveModelType,
    onSelectModel: (CurveModelType) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Curve Model Selector Bar
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INTERPOLATION ENGINE & FITTING MODEL",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = CyanAccent
                    )
                    Text(
                        text = "MODEL: ${activeModel.displayName.uppercase()}",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 10.sp,
                        color = AmberAccent
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CurveModelType.values().forEach { model ->
                        val isSelected = model == activeModel
                        Box(
                            modifier = Modifier
                                .testTag("curve_model_${model.name.lowercase()}")
                                .background(if (isSelected) CyanAccentMuted.copy(alpha = 0.3f) else TerminalSurfaceElevated)
                                .border(1.dp, if (isSelected) CyanAccent else TerminalBorderSubtle)
                                .clickable { onSelectModel(model) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = model.displayName,
                                fontFamily = RobotoMonoFontFamily,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) TextPrimary else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Institutional Canvas Curve Rendering
        item {
            InstitutionalCanvasChart(
                curvePoints = curvePoints,
                showForwardCurve = true,
                showZeroCurve = true
            )
        }

        // Curve Points Tabular Breakdown Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "TENOR", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                Text(text = "SPOT", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CiorAmber)
                Text(text = "FORWARD", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CyanAccent)
                Text(text = "ZERO", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = SofrBlue)
                Text(text = "DF", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextSecondary)
                Text(text = "PAR", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
            }
        }

        // Curve Points Rows
        items(curvePoints) { pt ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(horizontal = 6.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = pt.tenor.code,
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
                Text(
                    text = String.format("%.3f%%", pt.spotRate),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CiorAmber
                )
                Text(
                    text = String.format("%.3f%%", pt.forwardRate),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = String.format("%.3f%%", pt.zeroRate),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = SofrBlue
                )
                Text(
                    text = String.format("%.4f", pt.discountFactor),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Text(
                    text = String.format("%.3f%%", pt.parRate),
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
        }

        // Forward Rate Matrix Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FORWARD RATE MATRIX F(t1, t2) = [(DF1/DF2) - 1] / Δt",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = "DISCOUNT BASIS: ACT/360",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    color = TextMuted
                )
            }
        }

        // Forward Matrix Grid
        items(forwardMatrix) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(TerminalBackground)
                            .border(0.5.dp, CyanAccentMuted)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = item.label,
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = CyanAccent
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "${item.startTenor} into ${item.endTenor} Forward",
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = String.format("%.3f%%", item.forwardRatePct),
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = CiorAmber
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = String.format("%+.1f bp", item.spreadVsSpotBp),
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 11.sp,
                        color = if (item.spreadVsSpotBp >= 0) RateGreen else RateRed
                    )
                }
            }
        }
    }
}
