package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BasisMetric
import com.example.data.model.MoneyMarketItem
import com.example.ui.theme.*

@Composable
fun SpreadsBasisScreen(
    basisMetrics: List<BasisMetric>,
    moneyMarketRates: List<MoneyMarketItem>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Basis Screen Title
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "CIOR-SOFR BASIS & SPREAD ANALYTICS",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = CyanAccent
                )
                Text(
                    text = "Unsecured Regional California Premium Over Secured Treasury Repo (SOFR)",
                    fontFamily = InterFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        // Basis Table Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "TENOR", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                Text(text = "CIOR", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CiorAmber)
                Text(text = "SOFR", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = SofrBlue)
                Text(text = "BASIS", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CyanAccent)
                Text(text = "1D Δ", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                Text(text = "1M Δ", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                Text(text = "Z-SCR", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = AmberAccent)
                Text(text = "PCTILE", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextSecondary)
            }
        }

        // Basis Rows
        items(basisMetrics) { m ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = m.tenor.code,
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
                Text(
                    text = String.format("%.2f%%", m.cior),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = CiorAmber
                )
                Text(
                    text = String.format("%.2f%%", m.sofr),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = SofrBlue
                )
                Text(
                    text = String.format("+%.0fbp", m.basisBp),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = String.format("%+.1f", m.dayDeltaBp),
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = RateGreen
                )
                Text(
                    text = String.format("%+.1f", m.monthDeltaBp),
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = RateGreen
                )
                Text(
                    text = String.format("%.2fσ", m.zScore),
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = AmberAccent
                )
                Text(
                    text = "${m.percentile}th",
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        // Relative Value & Policy Rate Anchor Note
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "POLICY RATE ARCHITECTURE: SOFR represents overnight Treasury-secured wholesale repo. " +
                            "Effective Federal Funds (EFFR) represents interbank reserve lending. " +
                            "IORB is the Fed's administered floor. CIOR models the synthetic marginal cost of " +
                            "unsecured wholesale USD borrowing for California banks, reflecting regional liquidity & credit risk.",
                    fontFamily = InterFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    lineHeight = 14.sp
                )
            }
        }

        // Money Market Comparative Matrix Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "USD MONEY MARKET INSTRUMENT COMPARISON",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = "RATES & VOLUME DEPTH",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    color = TextMuted
                )
            }
        }

        // Money Market Table Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "INSTRUMENT", modifier = Modifier.weight(2.0f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                Text(text = "RATE", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CiorAmber)
                Text(text = "1D CHG", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                Text(text = "VS SOFR", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = CyanAccent)
                Text(text = "LIQUIDITY", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextSecondary)
            }
        }

        // Money Market Rows
        items(moneyMarketRates) { mm ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("mm_${mm.instrument.take(4).lowercase()}")
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(horizontal = 6.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(2.0f)) {
                    Text(
                        text = mm.instrument,
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${mm.category} • ${mm.tenorLabel}",
                        fontFamily = InterFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }
                Text(
                    text = String.format("%.2f%%", mm.ratePct),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (mm.instrument.contains("CIOR")) CiorAmber else TextPrimary
                )
                Text(
                    text = String.format("%+.1fbp", mm.changeBp),
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = if (mm.changeBp >= 0) RateGreen else RateRed
                )
                Text(
                    text = String.format("%+.0fbp", mm.spreadVsSofrBp),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = CyanAccent
                )
                Text(
                    text = mm.liquidityRating,
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    color = when (mm.liquidityRating) {
                        "MAXIMUM" -> RateGreen
                        "HIGH" -> CyanAccent
                        "MEDIUM" -> AmberAccent
                        else -> TextMuted
                    }
                )
            }
        }
    }
}
