package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EconometricRegression
import com.example.data.model.ForecastScenario
import com.example.data.model.HistoricalDataPoint
import com.example.data.model.StatisticalSummary
import com.example.ui.theme.*

@Composable
fun HistoricalResearchScreen(
    historicalData: List<HistoricalDataPoint>,
    statistics: StatisticalSummary?,
    regression: EconometricRegression,
    forecasts: List<ForecastScenario>,
    selectedTimeframe: String,
    onSelectTimeframe: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: Timeframe & Historical Statistics
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "HISTORICAL RESEARCH & STATISTICAL PROFILE",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = CyanAccent
                    )
                    Text(
                        text = "SAMPLE: ${historicalData.size} OBSERVATIONS",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Timeframe Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val timeframes = listOf("1D", "1W", "1M", "3M", "6M", "1Y", "5Y", "10Y")
                    timeframes.forEach { tf ->
                        val isSel = tf == selectedTimeframe
                        Box(
                            modifier = Modifier
                                .testTag("hist_tf_${tf.lowercase()}")
                                .background(if (isSel) CyanAccentMuted.copy(alpha = 0.3f) else TerminalSurface)
                                .border(1.dp, if (isSel) CyanAccent else TerminalBorderSubtle)
                                .clickable { onSelectTimeframe(tf) }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = tf,
                                fontFamily = RobotoMonoFontFamily,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) TextPrimary else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Statistical Distribution Metrics
        statistics?.let { s ->
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "PARAMETRIC & EMPIRICAL DISTRIBUTION STATS:",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatChip(label = "Mean", value = String.format("%.3f%%", s.mean), modifier = Modifier.weight(1f))
                        StatChip(label = "Median", value = String.format("%.3f%%", s.median), modifier = Modifier.weight(1f))
                        StatChip(label = "Min / Max", value = "${s.min} / ${s.max}%", modifier = Modifier.weight(1f))
                        StatChip(label = "Std Dev (σ)", value = "${s.stdDev}%", modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatChip(label = "25th / 75th", value = "${s.p25} / ${s.p75}%", modifier = Modifier.weight(1f))
                        StatChip(label = "Z-Score", value = "${s.zScore}σ", modifier = Modifier.weight(1f))
                        StatChip(label = "Max Drawdown", value = "${s.maxDrawdownBp} bp", modifier = Modifier.weight(1f))
                        StatChip(label = "99% VaR (1D)", value = "${s.var99Pct}%", modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Section 2: Econometric Multi-Factor Regression Engine
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "ECONOMETRIC MULTI-FACTOR REGRESSION SPECIFICATION",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = "CIOR(t) = α + β1·SOFR + β2·CreditSpread + β3·LiquidityIndex + β4·Term + ε",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    color = CiorAmber
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatChip(label = "SOFR Beta (β1)", value = "${regression.sofrBeta} (t=${regression.tStatSofr})", modifier = Modifier.weight(1f))
                    StatChip(label = "Credit Beta (β2)", value = "+${regression.creditSpreadBeta}", modifier = Modifier.weight(1f))
                    StatChip(label = "Liquidity Beta (β3)", value = "${regression.liquidityBeta}", modifier = Modifier.weight(1f))
                    StatChip(label = "R-Squared", value = "94.2% (F=${regression.fStatistic})", modifier = Modifier.weight(1f))
                }
            }
        }

        // Section 3: Econometric Forecast Scenarios
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ECONOMETRIC RATE FORECAST SCENARIOS (ARIMA / NS)",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = CiorAmber
                    )
                    Text(
                        text = "95% CONFIDENCE INTERVALS",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // Forecast Table Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "HORIZON", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                Text(text = "BASE", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CyanAccent)
                Text(text = "BULL", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = RateGreen)
                Text(text = "BEAR", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = AmberAccent)
                Text(text = "STRESS", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = RateRed)
                Text(text = "95% CI RANGE", modifier = Modifier.weight(1.6f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextSecondary)
            }
        }

        items(forecasts) { f ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("forecast_${f.horizon.lowercase()}")
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(horizontal = 6.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = f.horizon,
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
                Text(
                    text = String.format("%.3f%%", f.baseRate),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = String.format("%.3f%%", f.bullRate),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = RateGreen
                )
                Text(
                    text = String.format("%.3f%%", f.bearRate),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = AmberAccent
                )
                Text(
                    text = String.format("%.3f%%", f.stressRate),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = RateRed
                )
                Text(
                    text = "[${f.confidenceLower95}% - ${f.confidenceUpper95}%]",
                    modifier = Modifier.weight(1.6f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun StatChip(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalBackground)
            .border(0.5.dp, TerminalBorderSubtle)
            .padding(4.dp)
    ) {
        Column {
            Text(text = label, fontFamily = InterFontFamily, fontSize = 8.sp, color = TextMuted)
            Text(text = value, fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextPrimary)
        }
    }
}
