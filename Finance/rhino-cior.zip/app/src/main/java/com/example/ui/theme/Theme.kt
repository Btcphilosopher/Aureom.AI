package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TerminalColorScheme = darkColorScheme(
    primary = CyanAccent,
    onPrimary = TerminalBackground,
    primaryContainer = CyanAccentMuted,
    onPrimaryContainer = TextPrimary,
    secondary = AmberAccent,
    onSecondary = TerminalBackground,
    secondaryContainer = AmberMuted,
    onSecondaryContainer = TextPrimary,
    background = TerminalBackground,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder,
    outlineVariant = TerminalBorderSubtle,
    error = RateRed,
    onError = TextPrimary
)

@Composable
fun RhinoTerminalTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = AppTypography,
        content = content
    )
}
