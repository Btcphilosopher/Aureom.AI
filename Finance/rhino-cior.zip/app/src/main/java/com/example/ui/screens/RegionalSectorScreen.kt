package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RegionalFundingPremium
import com.example.data.model.SectorFundingCurve
import com.example.ui.theme.*

@Composable
fun RegionalSectorScreen(
    regionalPremiums: List<RegionalFundingPremium>,
    sectorCurves: List<SectorFundingCurve>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1 Header: California Regional Funding Premiums
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "CALIFORNIA REGIONAL FUNDING PREMIUMS (CA-PREM)",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = "Synthetic regional cost differences based on deposit depth, tech/CRE concentration and liquidity",
                    fontFamily = InterFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        // Regional Table Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "REGION / HUB", modifier = Modifier.weight(2.0f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                Text(text = "PREMIUM", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CyanAccent)
                Text(text = "ALL-IN", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CiorAmber)
                Text(text = "TECH %", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                Text(text = "CRE %", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                Text(text = "LIQUIDITY", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = RateGreen)
            }
        }

        // Regional Rows
        items(regionalPremiums) { reg ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reg_${reg.regionName.take(3).lowercase()}")
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(horizontal = 6.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(2.0f)) {
                    Text(
                        text = reg.regionName,
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Text(
                        text = reg.primaryHub,
                        fontFamily = InterFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }
                Text(
                    text = String.format("+%.1f bp", reg.regionalPremiumBp),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = String.format("%.3f%%", reg.allInRate),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CiorAmber
                )
                Text(
                    text = "${reg.techExposurePct.toInt()}%",
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
                Text(
                    text = "${reg.creExposurePct.toInt()}%",
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
                Text(
                    text = "${reg.liquidityScore}/100",
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 10.sp,
                    color = RateGreen
                )
            }
        }

        // Section 2 Header: Industry Sector Funding Curves
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "SYNTHETIC SECTOR FUNDING RATES & SPREADS",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CiorAmber
                )
                Text(
                    text = "CIOR + Sector Base Spread + Credit Spread + Liquidity Premium = All-in Rate",
                    fontFamily = InterFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        // Sector Rows
        items(sectorCurves) { sec ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("sec_${sec.industryCode.lowercase()}")
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(2.0f)) {
                    Text(
                        text = sec.sectorName,
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Code: ${sec.industryCode} • Duration: ${sec.durationYears}Y • Vol: ${'$'}${sec.averageBorrowingVolumeBn}B",
                        fontFamily = InterFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }

                Column(
                    modifier = Modifier.weight(1.2f),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = String.format("%.2f%%", sec.finalFundingRate),
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = CiorAmber
                    )
                    Text(
                        text = "Spread +${sec.sectorSpreadBp.toInt()}bp",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 9.sp,
                        color = CyanAccent
                    )
                }
            }
        }
    }
}
