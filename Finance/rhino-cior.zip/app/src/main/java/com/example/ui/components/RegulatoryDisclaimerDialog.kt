package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun RegulatoryDisclaimerDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceElevated)
                .border(1.dp, AmberAccent)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "REGULATORY & DATA NOTICE",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = AmberAccent
                )

                Box(
                    modifier = Modifier
                        .testTag("close_disclaimer_x")
                        .clickable { onDismiss() }
                        .padding(4.dp)
                ) {
                    Text(
                        text = "[X]",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalBackground)
                    .border(1.dp, TerminalBorder)
                    .padding(10.dp)
            ) {
                Text(
                    text = "CIOR (California Interbank Offered Rate) is a synthetic analytical benchmark created exclusively for software demonstration and quantitative rates research purposes.",
                    fontFamily = InterFontFamily,
                    fontSize = 12.sp,
                    color = TextPrimary,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "NON-REGULATED SYNTHETIC SYSTEM:\n" +
                        "CIOR is not an official California benchmark, does not represent an administered financial benchmark, and must not be used as a contractual reference rate without appropriate legal, regulatory, and benchmark-administration review.\n\n" +
                        "DEMONSTRATION MARKET DATA:\n" +
                        "All market data, contributing institutions, transacted volumes, funding curves, and historical time series shown in demonstration mode are entirely synthetic.\n\n" +
                        "NO AFFILIATION OR ENDORSEMENT:\n" +
                        "This research system does not imply any affiliation with or endorsement by the Federal Reserve, Federal Reserve Bank of San Francisco, State of California, California Department of Financial Protection and Innovation (DFPI), SEC, CFTC, FINRA, American Financial Exchange (AFX), CME Group, NYSE, NASDAQ, or any contributing financial institution.",
                fontFamily = InterFontFamily,
                fontSize = 11.sp,
                color = TextSecondary,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dismiss_disclaimer_button")
                    .background(TerminalSurface)
                    .border(1.dp, AmberMuted)
                    .clickable { onDismiss() }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ACKNOWLEDGE & RETURN TO TERMINAL",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = AmberAccent
                )
            }
        }
    }
}
