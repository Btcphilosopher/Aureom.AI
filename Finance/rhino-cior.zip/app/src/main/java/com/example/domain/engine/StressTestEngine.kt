package com.example.domain.engine

import com.example.data.model.*
import kotlin.math.round

object StressTestEngine {

    fun getStandardScenarios(): List<StressScenario> {
        return listOf(
            StressScenario(
                id = "SCEN-00",
                name = "Baseline Conditions",
                description = "Current orderly California wholesale funding market conditions",
                shiftBp = 0.0,
                ciorShiftBp = 0.0,
                sofrShiftBp = 0.0,
                basisWideningBp = 0.0,
                bankNimImpactBp = 0.0,
                debtServiceIncreasePct = 0.0,
                level = StressLevel.NORMAL
            ),
            StressScenario(
                id = "SCEN-25",
                name = "+25 bp Parallel Hike",
                description = "Standard Federal Reserve monetary policy tightening increment",
                shiftBp = 25.0,
                ciorShiftBp = 26.5,
                sofrShiftBp = 25.0,
                basisWideningBp = 1.5,
                bankNimImpactBp = 3.2,
                debtServiceIncreasePct = 6.2,
                level = StressLevel.NORMAL
            ),
            StressScenario(
                id = "SCEN-50",
                name = "+50 bp Accelerated Hike",
                description = "Interbank term rate adjustment under sticky inflation expectations",
                shiftBp = 50.0,
                ciorShiftBp = 54.0,
                sofrShiftBp = 50.0,
                basisWideningBp = 4.0,
                bankNimImpactBp = 5.8,
                debtServiceIncreasePct = 12.5,
                level = StressLevel.WATCH
            ),
            StressScenario(
                id = "SCEN-100",
                name = "+100 bp Liquidity Squeeze",
                description = "Rapid bank deposit repricing with moderate wholesale spread blowout",
                shiftBp = 100.0,
                ciorShiftBp = 112.0,
                sofrShiftBp = 100.0,
                basisWideningBp = 12.0,
                bankNimImpactBp = -8.4,
                debtServiceIncreasePct = 25.8,
                level = StressLevel.ELEVATED
            ),
            StressScenario(
                id = "SCEN-200",
                name = "+200 bp Severe Shock",
                description = "Systemic regional credit spread widening with interbank risk rationing",
                shiftBp = 200.0,
                ciorShiftBp = 238.0,
                sofrShiftBp = 200.0,
                basisWideningBp = 38.0,
                bankNimImpactBp = -22.5,
                debtServiceIncreasePct = 52.0,
                level = StressLevel.STRESSED
            ),
            StressScenario(
                id = "SCEN-300",
                name = "+300 bp Extreme Crisis",
                description = "Unprecedented funding market dislocation; fallback tier activation test",
                shiftBp = 300.0,
                ciorShiftBp = 375.0,
                sofrShiftBp = 300.0,
                basisWideningBp = 75.0,
                bankNimImpactBp = -41.0,
                debtServiceIncreasePct = 81.5,
                level = StressLevel.CRISIS
            ),
            StressScenario(
                id = "SCEN-CA-BANK",
                name = "California Banking Stress",
                description = "Simulated deposit outflows at regional institutions; CP and CD funding spreads widen",
                shiftBp = 85.0,
                ciorShiftBp = 142.0,
                sofrShiftBp = 45.0,
                basisWideningBp = 97.0,
                bankNimImpactBp = -34.0,
                debtServiceIncreasePct = 36.0,
                level = StressLevel.STRESSED
            ),
            StressScenario(
                id = "SCEN-TECH-CREDIT",
                name = "Silicon Valley Tech Credit Shock",
                description = "Contraction in venture debt, private credit repricing, cash burn acceleration",
                shiftBp = 65.0,
                ciorShiftBp = 105.0,
                sofrShiftBp = 35.0,
                basisWideningBp = 70.0,
                bankNimImpactBp = -18.2,
                debtServiceIncreasePct = 28.5,
                level = StressLevel.ELEVATED
            ),
            StressScenario(
                id = "SCEN-CRE-DISTRESS",
                name = "Commercial Property Refinance Crisis",
                description = "San Francisco & Los Angeles office valuation haircuts trigger mortgage loan stress",
                shiftBp = 75.0,
                ciorShiftBp = 118.0,
                sofrShiftBp = 40.0,
                basisWideningBp = 78.0,
                bankNimImpactBp = -24.6,
                debtServiceIncreasePct = 31.0,
                level = StressLevel.STRESSED
            )
        )
    }

    fun calculateLiquidityIndex(activeScenario: StressScenario): LiquidityStressIndex {
        val baseScore = 71.4
        val penalty = (activeScenario.basisWideningBp * 0.45) + (activeScenario.ciorShiftBp * 0.15)
        val finalScore = (baseScore - penalty).coerceIn(12.0, 95.0)

        val status = when {
            finalScore >= 80.0 -> "HIGH LIQUIDITY"
            finalScore >= 65.0 -> "NORMAL"
            finalScore >= 50.0 -> "WATCH"
            finalScore >= 35.0 -> "ELEVATED STRESS"
            else -> "SEVERE LIQUIDITY STRESS"
        }

        return LiquidityStressIndex(
            cliScore = round(finalScore * 10.0) / 10.0,
            cliStatus = status,
            cfsiStatus = activeScenario.level,
            moneyMarketDepthScore = round((82.0 - penalty * 0.4).coerceIn(10.0, 98.0) * 10.0) / 10.0,
            bankFundingScore = round((78.5 - penalty * 0.5).coerceIn(10.0, 98.0) * 10.0) / 10.0,
            depositGrowthScore = round((69.0 - penalty * 0.3).coerceIn(10.0, 98.0) * 10.0) / 10.0,
            transactionVolumeScore = round((84.0 - penalty * 0.2).coerceIn(10.0, 98.0) * 10.0) / 10.0,
            bidOfferConditionsScore = round((75.0 - penalty * 0.6).coerceIn(10.0, 98.0) * 10.0) / 10.0,
            fundingStressPenalty = round(penalty * 10.0) / 10.0
        )
    }
}
