package com.example.domain.engine

import com.example.data.model.*
import kotlin.math.*

object YieldCurveEngine {

    // Calibration points for the synthetic CIOR term structure
    fun getPillarPoints(baseOnRate: Double = 3.84): List<Pair<Double, Double>> {
        return listOf(
            (1.0 / 360.0) to baseOnRate,
            (7.0 / 360.0) to (baseOnRate + 0.03),
            (30.0 / 360.0) to (baseOnRate + 0.08),
            (90.0 / 360.0) to (baseOnRate + 0.17),
            (180.0 / 360.0) to (baseOnRate + 0.28),
            (360.0 / 360.0) to (baseOnRate + 0.41),
            2.0 to (baseOnRate + 0.58),
            3.0 to (baseOnRate + 0.72),
            5.0 to (baseOnRate + 0.94)
        )
    }

    // Nelson-Siegel parametric rate calculation
    fun nelsonSiegelRate(t: Double, beta0: Double, beta1: Double, beta2: Double, tau: Double): Double {
        if (t <= 0.0001) return beta0 + beta1
        val tRatio = t / tau
        val expTerm = exp(-tRatio)
        val factor1 = (1.0 - expTerm) / tRatio
        val factor2 = factor1 - expTerm
        return beta0 + beta1 * factor1 + beta2 * factor2
    }

    // Nelson-Siegel-Svensson parametric rate
    fun nelsonSiegelSvenssonRate(
        t: Double,
        beta0: Double,
        beta1: Double,
        beta2: Double,
        beta3: Double,
        tau1: Double,
        tau2: Double
    ): Double {
        if (t <= 0.0001) return beta0 + beta1
        val tRatio1 = t / tau1
        val exp1 = exp(-tRatio1)
        val f1 = (1.0 - exp1) / tRatio1
        val f2 = f1 - exp1

        val tRatio2 = t / tau2
        val exp2 = exp(-tRatio2)
        val f3 = ((1.0 - exp2) / tRatio2) - exp2

        return beta0 + beta1 * f1 + beta2 * f2 + beta3 * f3
    }

    // Monotonic Cubic Hermite (PCHIP) Interpolator
    fun pchipInterpolate(xVal: Double, points: List<Pair<Double, Double>>): Double {
        val n = points.size
        if (xVal <= points.first().first) return points.first().second
        if (xVal >= points.last().first) return points.last().second

        val x = points.map { it.first }
        val y = points.map { it.second }
        val h = DoubleArray(n - 1)
        val delta = DoubleArray(n - 1)

        for (i in 0 until n - 1) {
            h[i] = x[i + 1] - x[i]
            delta[i] = (y[i + 1] - y[i]) / h[i]
        }

        val d = DoubleArray(n)
        d[0] = delta[0]
        d[n - 1] = delta[n - 2]
        for (i in 1 until n - 1) {
            if (delta[i - 1] * delta[i] <= 0.0) {
                d[i] = 0.0
            } else {
                val w1 = 2 * h[i] + h[i - 1]
                val w2 = h[i] + 2 * h[i - 1]
                d[i] = (w1 + w2) / (w1 / delta[i - 1] + w2 / delta[i])
            }
        }

        // Find segment
        var k = 0
        while (k < n - 2 && xVal > x[k + 1]) {
            k++
        }

        val tNorm = (xVal - x[k]) / h[k]
        val t2 = tNorm * tNorm
        val t3 = t2 * tNorm

        val h00 = 2 * t3 - 3 * t2 + 1
        val h10 = t3 - 2 * t2 + tNorm
        val h01 = -2 * t3 + 3 * t2
        val h11 = t3 - t2

        return h00 * y[k] + h10 * h[k] * d[k] + h01 * y[k + 1] + h11 * h[k] * d[k + 1]
    }

    // Cubic Spline Natural
    fun cubicSplineInterpolate(xVal: Double, points: List<Pair<Double, Double>>): Double {
        val n = points.size
        if (xVal <= points.first().first) return points.first().second
        if (xVal >= points.last().first) return points.last().second

        val x = points.map { it.first }
        val y = points.map { it.second }

        val h = DoubleArray(n - 1) { i -> x[i + 1] - x[i] }
        val alpha = DoubleArray(n - 1)
        for (i in 1 until n - 1) {
            alpha[i] = (3.0 / h[i]) * (y[i + 1] - y[i]) - (3.0 / h[i - 1]) * (y[i] - y[i - 1])
        }

        val l = DoubleArray(n)
        val mu = DoubleArray(n)
        val z = DoubleArray(n)
        l[0] = 1.0

        for (i in 1 until n - 1) {
            l[i] = 2.0 * (x[i + 1] - x[i - 1]) - h[i - 1] * mu[i - 1]
            mu[i] = h[i] / l[i]
            z[i] = (alpha[i] - h[i - 1] * z[i - 1]) / l[i]
        }
        l[n - 1] = 1.0

        val c = DoubleArray(n)
        val b = DoubleArray(n - 1)
        val d = DoubleArray(n - 1)

        for (j in n - 2 downTo 0) {
            c[j] = z[j] - mu[j] * c[j + 1]
            b[j] = (y[j + 1] - y[j]) / h[j] - h[j] * (c[j + 1] + 2.0 * c[j]) / 3.0
            d[j] = (c[j + 1] - c[j]) / (3.0 * h[j])
        }

        var i = 0
        while (i < n - 2 && xVal > x[i + 1]) {
            i++
        }
        val dx = xVal - x[i]
        return y[i] + b[i] * dx + c[i] * dx * dx + d[i] * dx * dx * dx
    }

    fun interpolate(xVal: Double, model: CurveModelType, baseOnRate: Double = 3.84): Double {
        val pillars = getPillarPoints(baseOnRate)
        return when (model) {
            CurveModelType.CUBIC_SPLINE -> cubicSplineInterpolate(xVal, pillars)
            CurveModelType.MONOTONIC_HERMITE -> pchipInterpolate(xVal, pillars)
            CurveModelType.NELSON_SIEGEL -> {
                // Calibrated params for synthetic curve
                val beta0 = baseOnRate + 0.95
                val beta1 = -0.95
                val beta2 = -0.35
                val tau = 1.2
                nelsonSiegelRate(xVal, beta0, beta1, beta2, tau)
            }
            CurveModelType.NELSON_SIEGEL_SVENSSON -> {
                val beta0 = baseOnRate + 1.02
                val beta1 = -1.02
                val beta2 = -0.40
                val beta3 = 0.25
                val tau1 = 1.1
                val tau2 = 3.0
                nelsonSiegelSvenssonRate(xVal, beta0, beta1, beta2, beta3, tau1, tau2)
            }
        }
    }

    fun calculateDiscountFactor(ratePct: Double, yearFraction: Double): Double {
        val r = ratePct / 100.0
        return exp(-r * yearFraction)
    }

    fun generateCurvePoints(model: CurveModelType, baseOnRate: Double = 3.84): List<CurvePoint> {
        val tenors = listOf(Tenor.ON, Tenor.W1, Tenor.M1, Tenor.M3, Tenor.M6, Tenor.M12, Tenor.Y2, Tenor.Y3, Tenor.Y5)
        return tenors.map { tenor ->
            val spot = interpolate(tenor.yearFraction, model, baseOnRate)
            val df = calculateDiscountFactor(spot, tenor.yearFraction)
            val zero = spot + (0.01 * tenor.yearFraction)
            val fwd = if (tenor.yearFraction <= 0.05) spot else spot + 0.12 * sqrt(tenor.yearFraction)
            val par = spot - 0.02

            CurvePoint(
                tenor = tenor,
                yearFraction = tenor.yearFraction,
                spotRate = round(spot * 1000.0) / 1000.0,
                forwardRate = round(fwd * 1000.0) / 1000.0,
                zeroRate = round(zero * 1000.0) / 1000.0,
                discountFactor = round(df * 10000.0) / 10000.0,
                parRate = round(par * 1000.0) / 1000.0
            )
        }
    }

    // Forward Rate Matrix: F(t1, t2) = [(DF(t1)/DF(t2)) - 1] / (t2 - t1)
    fun generateForwardMatrix(model: CurveModelType, baseOnRate: Double = 3.84): List<ForwardRateMatrixItem> {
        val pairs = listOf(
            Triple("1M", "3M", (90.0 - 30.0) / 360.0),
            Triple("3M", "6M", (180.0 - 90.0) / 360.0),
            Triple("6M", "9M", (270.0 - 180.0) / 360.0),
            Triple("9M", "12M", (360.0 - 270.0) / 360.0),
            Triple("1M", "6M", (180.0 - 30.0) / 360.0),
            Triple("3M", "12M", (360.0 - 90.0) / 360.0),
            Triple("1Y", "2Y", 1.0),
            Triple("2Y", "3Y", 1.0)
        )

        return pairs.map { (t1, t2, dt) ->
            val y1 = when (t1) {
                "1M" -> 30.0 / 360.0
                "3M" -> 90.0 / 360.0
                "6M" -> 180.0 / 360.0
                "9M" -> 270.0 / 360.0
                "1Y" -> 1.0
                else -> 2.0
            }
            val y2 = y1 + dt

            val r1 = interpolate(y1, model, baseOnRate)
            val r2 = interpolate(y2, model, baseOnRate)

            val df1 = calculateDiscountFactor(r1, y1)
            val df2 = calculateDiscountFactor(r2, y2)

            val fwdRate = ((df1 / df2) - 1.0) / dt * 100.0
            val spotBase = interpolate(y1, model, baseOnRate)
            val spreadBp = (fwdRate - spotBase) * 100.0

            ForwardRateMatrixItem(
                startTenor = t1,
                endTenor = t2,
                forwardRatePct = round(fwdRate * 1000.0) / 1000.0,
                spreadVsSpotBp = round(spreadBp * 10.0) / 10.0,
                label = "${t1}x${t2}"
            )
        }
    }
}
