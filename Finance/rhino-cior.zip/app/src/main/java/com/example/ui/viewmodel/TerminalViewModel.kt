package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.BenchmarkRepository
import com.example.domain.engine.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class TerminalScreen(val code: String, val title: String, val shortKey: String) {
    MARKETS("MARKETS", "CIOR Markets & Fixings", "F1"),
    CURVE("CURVE", "Term Structure & Curves", "F2"),
    SPREADS("SPREADS", "Basis & Money Markets", "F3"),
    BANKS("BANKS", "California Bank Funding", "F4"),
    REGIONAL_SECTORS("SECTOR", "Regional & Sector Curves", "F5"),
    PRICING("PRICING", "Corporate Treasury & Pricing", "F6"),
    STRESS("STRESS", "Stress Testing & Liquidity", "F7"),
    HISTORICAL("HIST", "Historical & Econometrics", "F8"),
    METHODOLOGY("GOV", "Methodology & Governance", "F9")
}

data class TerminalUiState(
    val currentScreen: TerminalScreen = TerminalScreen.MARKETS,
    val currentTimePt: String = "10:42:17 PT",
    val isLiveSynthetic: Boolean = true,
    val tickerCiorOn: Double = 3.840,
    val tickerCiorChangeBp: Double = 4.2,
    val tickerSofr: Double = 3.710,
    val tickerBasisBp: Double = 13.0,
    val tickerFedFunds: Double = 3.750,
    val tickerUst2y: Double = 3.620,
    val tickerUst10y: Double = 4.180,
    val benchmarkRates: List<BenchmarkRate> = emptyList(),
    val basisMetrics: List<BasisMetric> = emptyList(),
    val moneyMarketRates: List<MoneyMarketItem> = emptyList(),
    val institutions: List<SyntheticInstitution> = emptyList(),
    val regionalPremiums: List<RegionalFundingPremium> = emptyList(),
    val sectorCurves: List<SectorFundingCurve> = emptyList(),
    val transactions: List<SyntheticTransaction> = emptyList(),
    // Curve state
    val curveModel: CurveModelType = CurveModelType.MONOTONIC_HERMITE,
    val curvePoints: List<CurvePoint> = emptyList(),
    val forwardMatrix: List<ForwardRateMatrixItem> = emptyList(),
    // Pricing state
    val loanNotional: Double = 500.0, // $500M
    val loanTenorYears: Double = 3.0,
    val loanMarginBp: Double = 175.0,
    val loanPricing: LoanPricing? = null,
    val swapType: SwapType = SwapType.CIOR_VS_SOFR,
    val swapNotional: Double = 100.0, // $100M
    val swapTenorYears: Double = 5.0,
    val swapPricing: SwapPricing? = null,
    val optionInstrument: OptionInstrument = OptionInstrument.CAP,
    val optionStrikePct: Double = 4.25,
    val optionPricing: OptionPricing? = null,
    val futuresContracts: List<FuturesContract> = emptyList(),
    // Stress & Liquidity state
    val stressScenarios: List<StressScenario> = emptyList(),
    val activeScenario: StressScenario = StressTestEngine.getStandardScenarios().first(),
    val liquidityIndex: LiquidityStressIndex = StressTestEngine.calculateLiquidityIndex(StressTestEngine.getStandardScenarios().first()),
    // Historical state
    val historicalTimeframe: String = "3M",
    val historicalData: List<HistoricalDataPoint> = emptyList(),
    val historicalStats: StatisticalSummary? = null,
    val econometricRegression: EconometricRegression = EconometricEngine.getEconometricRegression(),
    val forecastScenarios: List<ForecastScenario> = emptyList(),
    // Methodology state
    val selectedMethodology: MethodologyType = MethodologyType.ROBUST_CIOR,
    val methodologyResults: Map<MethodologyType, MethodologyResult> = emptyMap(),
    val qualityMetrics: QualityMetrics? = null,
    val fallbackTiers: List<FallbackTier> = emptyList(),
    // RQQL Command Line State
    val commandInput: String = "",
    val commandOutputMessage: String? = null,
    val isCommandSuccess: Boolean = true,
    val commandHistory: List<String> = listOf("CIOR", "CURVE", "SPREADS", "STRESS", "LOAN")
)

class TerminalViewModel : ViewModel() {

    private val repository = BenchmarkRepository()
    private val _uiState = MutableStateFlow(TerminalUiState())
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    init {
        loadData()
        startClock()
    }

    private fun loadData() {
        val scenario = StressTestEngine.getStandardScenarios().first()
        val rates = repository.getBenchmarkRates(scenario.shiftBp)
        val basis = repository.getBasisMetrics(rates)
        val mm = repository.getMoneyMarketRates(rates.first().ciorRate, rates.first().sofrRate)
        val insts = BenchmarkCalculationEngine.syntheticInstitutions
        val regional = repository.getRegionalPremiums(rates.first().ciorRate)
        val sectors = repository.getSectorFundingCurves(rates.first().ciorRate)
        val txs = repository.getTransactions()
        val curve = YieldCurveEngine.generateCurvePoints(CurveModelType.MONOTONIC_HERMITE, rates.first().ciorRate)
        val fwdMat = YieldCurveEngine.generateForwardMatrix(CurveModelType.MONOTONIC_HERMITE, rates.first().ciorRate)
        val loan = PricingEngine.priceLoan(500.0, 3.0, rates.find { it.tenor == Tenor.M3 }?.ciorRate ?: 4.01, 175.0)
        val swap = PricingEngine.priceSwap(SwapType.CIOR_VS_SOFR, 100.0, 5.0, rates.first().ciorRate, rates.first().sofrRate)
        val opt = PricingEngine.priceOption(OptionInstrument.CAP, 4.25, 100.0, 3.0)
        val fut = PricingEngine.getFuturesContracts(rates)
        val scenarios = StressTestEngine.getStandardScenarios()
        val liq = StressTestEngine.calculateLiquidityIndex(scenario)
        val hist = EconometricEngine.getHistoricalSeries("3M")
        val stats = EconometricEngine.computeStatistics(hist)
        val forecasts = EconometricEngine.getForecastScenarios(rates.find { it.tenor == Tenor.M3 }?.ciorRate ?: 4.01)
        val methodResults = repository.getMethodologyResults()
        val quality = repository.getQualityMetrics()
        val fallbacks = BenchmarkCalculationEngine.getFallbackTiers(rates.first().ciorRate, rates.first().sofrRate)

        _uiState.update {
            it.copy(
                benchmarkRates = rates,
                basisMetrics = basis,
                moneyMarketRates = mm,
                institutions = insts,
                regionalPremiums = regional,
                sectorCurves = sectors,
                transactions = txs,
                curvePoints = curve,
                forwardMatrix = fwdMat,
                loanPricing = loan,
                swapPricing = swap,
                optionPricing = opt,
                futuresContracts = fut,
                stressScenarios = scenarios,
                activeScenario = scenario,
                liquidityIndex = liq,
                historicalData = hist,
                historicalStats = stats,
                forecastScenarios = forecasts,
                methodologyResults = methodResults,
                qualityMetrics = quality,
                fallbackTiers = fallbacks,
                tickerCiorOn = rates.first().ciorRate,
                tickerSofr = rates.first().sofrRate,
                tickerBasisBp = rates.first().spreadBp
            )
        }
    }

    private fun startClock() {
        viewModelScope.launch {
            val tz = TimeZone.getTimeZone("America/Los_Angeles")
            val sdf = SimpleDateFormat("HH:mm:ss 'PT'", Locale.US)
            sdf.timeZone = tz
            while (true) {
                val nowStr = sdf.format(Date())
                _uiState.update { it.copy(currentTimePt = nowStr) }
                delay(1000)
            }
        }
    }

    fun selectScreen(screen: TerminalScreen) {
        _uiState.update { it.copy(currentScreen = screen, commandOutputMessage = "Switched to ${screen.title}") }
    }

    fun selectCurveModel(model: CurveModelType) {
        val baseRate = _uiState.value.tickerCiorOn
        val pts = YieldCurveEngine.generateCurvePoints(model, baseRate)
        val fwdMat = YieldCurveEngine.generateForwardMatrix(model, baseRate)
        _uiState.update {
            it.copy(
                curveModel = model,
                curvePoints = pts,
                forwardMatrix = fwdMat,
                commandOutputMessage = "Interpolation model set to ${model.displayName}"
            )
        }
    }

    fun selectStressScenario(scenario: StressScenario) {
        val rates = repository.getBenchmarkRates(scenario.shiftBp)
        val basis = repository.getBasisMetrics(rates)
        val mm = repository.getMoneyMarketRates(rates.first().ciorRate, rates.first().sofrRate)
        val pts = YieldCurveEngine.generateCurvePoints(_uiState.value.curveModel, rates.first().ciorRate)
        val fwdMat = YieldCurveEngine.generateForwardMatrix(_uiState.value.curveModel, rates.first().ciorRate)
        val liq = StressTestEngine.calculateLiquidityIndex(scenario)
        val loan = PricingEngine.priceLoan(
            _uiState.value.loanNotional,
            _uiState.value.loanTenorYears,
            rates.find { it.tenor == Tenor.M3 }?.ciorRate ?: 4.01,
            _uiState.value.loanMarginBp
        )
        val swap = PricingEngine.priceSwap(
            _uiState.value.swapType,
            _uiState.value.swapNotional,
            _uiState.value.swapTenorYears,
            rates.first().ciorRate,
            rates.first().sofrRate
        )

        _uiState.update {
            it.copy(
                activeScenario = scenario,
                benchmarkRates = rates,
                basisMetrics = basis,
                moneyMarketRates = mm,
                curvePoints = pts,
                forwardMatrix = fwdMat,
                liquidityIndex = liq,
                loanPricing = loan,
                swapPricing = swap,
                tickerCiorOn = rates.first().ciorRate,
                tickerSofr = rates.first().sofrRate,
                tickerBasisBp = rates.first().spreadBp,
                commandOutputMessage = "Applied stress scenario: ${scenario.name} (+${scenario.shiftBp} bp)"
            )
        }
    }

    fun updateLoanParameters(notional: Double, tenor: Double, margin: Double) {
        val baseRate = _uiState.value.benchmarkRates.find { it.tenor == Tenor.M3 }?.ciorRate ?: 4.01
        val pricing = PricingEngine.priceLoan(notional, tenor, baseRate, margin)
        _uiState.update {
            it.copy(
                loanNotional = notional,
                loanTenorYears = tenor,
                loanMarginBp = margin,
                loanPricing = pricing,
                commandOutputMessage = "Loan recalculated: ${'$'}${notional.toInt()}M ${tenor.toInt()}Y @ CIOR+${margin.toInt()}bp"
            )
        }
    }

    fun updateSwapParameters(type: SwapType, notional: Double, tenor: Double) {
        val cior = _uiState.value.tickerCiorOn
        val sofr = _uiState.value.tickerSofr
        val pricing = PricingEngine.priceSwap(type, notional, tenor, cior, sofr)
        _uiState.update {
            it.copy(
                swapType = type,
                swapNotional = notional,
                swapTenorYears = tenor,
                swapPricing = pricing,
                commandOutputMessage = "Swap priced: ${type.label} ${'$'}${notional.toInt()}M ${tenor.toInt()}Y"
            )
        }
    }

    fun updateOptionParameters(instrument: OptionInstrument, strike: Double, notional: Double, tenor: Double) {
        val fwd = _uiState.value.benchmarkRates.find { it.tenor == Tenor.M3 }?.ciorRate ?: 4.01
        val pricing = PricingEngine.priceOption(instrument, strike, notional, tenor, fwd)
        _uiState.update {
            it.copy(
                optionInstrument = instrument,
                optionStrikePct = strike,
                optionPricing = pricing,
                commandOutputMessage = "Option priced: ${instrument.label} K=${strike}%"
            )
        }
    }

    fun selectHistoricalTimeframe(tf: String) {
        val hist = EconometricEngine.getHistoricalSeries(tf)
        val stats = EconometricEngine.computeStatistics(hist)
        _uiState.update {
            it.copy(
                historicalTimeframe = tf,
                historicalData = hist,
                historicalStats = stats,
                commandOutputMessage = "Historical timeframe loaded: $tf"
            )
        }
    }

    fun selectMethodology(type: MethodologyType) {
        _uiState.update {
            it.copy(
                selectedMethodology = type,
                commandOutputMessage = "Benchmark methodology switched to ${type.displayName}"
            )
        }
    }

    fun onCommandInputChange(cmd: String) {
        _uiState.update { it.copy(commandInput = cmd) }
    }

    fun executeCommand(rawCommand: String) {
        val clean = rawCommand.trim().uppercase()
        if (clean.isBlank()) return

        val history = (_uiState.value.commandHistory + clean).takeLast(10)

        when {
            clean == "CIOR" || clean == "MARKET" || clean == "MARKETS" -> {
                _uiState.update { it.copy(currentScreen = TerminalScreen.MARKETS, commandInput = "", commandOutputMessage = "RQQL: Displaying CIOR Benchmark Rates", isCommandSuccess = true, commandHistory = history) }
            }
            clean == "CURVE" || clean == "YIELD" || clean == "TERMS" -> {
                _uiState.update { it.copy(currentScreen = TerminalScreen.CURVE, commandInput = "", commandOutputMessage = "RQQL: Displaying CIOR Term Structure & Yield Curve", isCommandSuccess = true, commandHistory = history) }
            }
            clean == "SPREADS" || clean == "BASIS" || clean == "MM" -> {
                _uiState.update { it.copy(currentScreen = TerminalScreen.SPREADS, commandInput = "", commandOutputMessage = "RQQL: Displaying CIOR-SOFR Basis & Money Market Matrix", isCommandSuccess = true, commandHistory = history) }
            }
            clean == "BANKS" || clean == "BANK" || clean == "FUNDING" -> {
                _uiState.update { it.copy(currentScreen = TerminalScreen.BANKS, commandInput = "", commandOutputMessage = "RQQL: Displaying California Contributing Institutions & Bank Curves", isCommandSuccess = true, commandHistory = history) }
            }
            clean == "REGIONAL" || clean == "SECTOR" || clean == "CA" -> {
                _uiState.update { it.copy(currentScreen = TerminalScreen.REGIONAL_SECTORS, commandInput = "", commandOutputMessage = "RQQL: Displaying Regional Funding Premiums & Sector Curves", isCommandSuccess = true, commandHistory = history) }
            }
            clean == "TREASURY" || clean == "PRICING" || clean == "LOAN" || clean == "SWAP" || clean == "OPTIONS" -> {
                _uiState.update { it.copy(currentScreen = TerminalScreen.PRICING, commandInput = "", commandOutputMessage = "RQQL: Displaying Corporate Treasury & Derivatives Pricing Desk", isCommandSuccess = true, commandHistory = history) }
            }
            clean == "STRESS" || clean == "LIQUIDITY" || clean == "CLI" || clean == "CFSI" -> {
                _uiState.update { it.copy(currentScreen = TerminalScreen.STRESS, commandInput = "", commandOutputMessage = "RQQL: Displaying Stress Scenarios & California Liquidity Index", isCommandSuccess = true, commandHistory = history) }
            }
            clean == "HIST" || clean == "HISTORICAL" || clean == "ECONOMETRICS" -> {
                _uiState.update { it.copy(currentScreen = TerminalScreen.HISTORICAL, commandInput = "", commandOutputMessage = "RQQL: Displaying Historical Research & Multi-Factor Econometrics", isCommandSuccess = true, commandHistory = history) }
            }
            clean == "GOV" || clean == "METHODOLOGY" || clean == "AUDIT" -> {
                _uiState.update { it.copy(currentScreen = TerminalScreen.METHODOLOGY, commandInput = "", commandOutputMessage = "RQQL: Displaying Governance, Methodology & Fallback Engine", isCommandSuccess = true, commandHistory = history) }
            }
            clean.startsWith("STRESS +") || clean.startsWith("STRESS -") -> {
                val numStr = clean.substringAfter("STRESS").replace("BP", "").trim()
                val bp = numStr.toDoubleOrNull() ?: 50.0
                val matched = _uiState.value.stressScenarios.find { it.shiftBp == bp }
                    ?: _uiState.value.stressScenarios[2]
                selectStressScenario(matched)
                _uiState.update { it.copy(currentScreen = TerminalScreen.STRESS, commandInput = "", isCommandSuccess = true, commandHistory = history) }
            }
            clean.contains("RESET") -> {
                selectStressScenario(_uiState.value.stressScenarios.first())
                _uiState.update { it.copy(commandInput = "", commandOutputMessage = "RQQL: Terminal parameters reset to baseline", isCommandSuccess = true, commandHistory = history) }
            }
            clean == "HELP" -> {
                _uiState.update {
                    it.copy(
                        commandInput = "",
                        commandOutputMessage = "RQQL: Available commands: CIOR, CURVE, SPREADS, BANKS, REGIONAL, PRICING, STRESS, HIST, GOV, RESET, STRESS +50BP",
                        isCommandSuccess = true,
                        commandHistory = history
                    )
                }
            }
            else -> {
                _uiState.update {
                    it.copy(
                        commandInput = "",
                        commandOutputMessage = "RQQL Error: Unrecognized command '$clean'. Type HELP for supported commands.",
                        isCommandSuccess = false,
                        commandHistory = history
                    )
                }
            }
        }
    }
}
