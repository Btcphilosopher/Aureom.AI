package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.TerminalBackground
import com.example.ui.viewmodel.TerminalScreen
import com.example.ui.viewmodel.TerminalViewModel

@Composable
fun TerminalMainScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showDisclaimerDialog by remember { mutableStateOf(false) }

    // Android Back button handling: return to MARKETS screen if on any other screen
    BackHandler(enabled = uiState.currentScreen != TerminalScreen.MARKETS) {
        viewModel.selectScreen(TerminalScreen.MARKETS)
    }

    if (showDisclaimerDialog) {
        RegulatoryDisclaimerDialog(onDismiss = { showDisclaimerDialog = false })
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground),
        topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
                TerminalTopBar(
                    ciorRate = uiState.tickerCiorOn,
                    ciorChangeBp = uiState.tickerCiorChangeBp,
                    sofrRate = uiState.tickerSofr,
                    basisBp = uiState.tickerBasisBp,
                    fedFundsRate = uiState.tickerFedFunds,
                    ust2yRate = uiState.tickerUst2y,
                    ust10yRate = uiState.tickerUst10y,
                    currentTimePt = uiState.currentTimePt,
                    onLogoClick = { showDisclaimerDialog = true }
                )
                TerminalNavBar(
                    currentScreen = uiState.currentScreen,
                    onSelectScreen = { viewModel.selectScreen(it) }
                )
            }
        },
        bottomBar = {
            Column(modifier = Modifier.navigationBarsPadding()) {
                RqqlCommandLine(
                    commandInput = uiState.commandInput,
                    onCommandChange = { viewModel.onCommandInputChange(it) },
                    onExecute = { viewModel.executeCommand(it) },
                    outputMessage = uiState.commandOutputMessage,
                    isSuccess = uiState.isCommandSuccess
                )
                TerminalFooter(
                    qualityScore = uiState.qualityMetrics?.totalScore ?: 87,
                    cliScore = uiState.liquidityIndex.cliScore,
                    onOpenDisclaimer = { showDisclaimerDialog = true }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.currentScreen) {
                TerminalScreen.MARKETS -> {
                    CiorMarketsScreen(
                        rates = uiState.benchmarkRates,
                        transactions = uiState.transactions,
                        onSelectTenor = { /* Selected tenor inspection */ }
                    )
                }
                TerminalScreen.CURVE -> {
                    CiorCurveScreen(
                        curvePoints = uiState.curvePoints,
                        forwardMatrix = uiState.forwardMatrix,
                        activeModel = uiState.curveModel,
                        onSelectModel = { viewModel.selectCurveModel(it) }
                    )
                }
                TerminalScreen.SPREADS -> {
                    SpreadsBasisScreen(
                        basisMetrics = uiState.basisMetrics,
                        moneyMarketRates = uiState.moneyMarketRates
                    )
                }
                TerminalScreen.BANKS -> {
                    BankFundingScreen(
                        institutions = uiState.institutions,
                        baseRate = uiState.tickerCiorOn
                    )
                }
                TerminalScreen.REGIONAL_SECTORS -> {
                    RegionalSectorScreen(
                        regionalPremiums = uiState.regionalPremiums,
                        sectorCurves = uiState.sectorCurves
                    )
                }
                TerminalScreen.PRICING -> {
                    TreasuryPricingScreen(
                        loanPricing = uiState.loanPricing,
                        swapPricing = uiState.swapPricing,
                        optionPricing = uiState.optionPricing,
                        futuresContracts = uiState.futuresContracts,
                        onUpdateLoan = { n, t, m -> viewModel.updateLoanParameters(n, t, m) },
                        onUpdateSwap = { t, n, yrs -> viewModel.updateSwapParameters(t, n, yrs) },
                        onUpdateOption = { inst, k, n, yrs -> viewModel.updateOptionParameters(inst, k, n, yrs) }
                    )
                }
                TerminalScreen.STRESS -> {
                    StressTestingScreen(
                        scenarios = uiState.stressScenarios,
                        activeScenario = uiState.activeScenario,
                        liquidityIndex = uiState.liquidityIndex,
                        onSelectScenario = { viewModel.selectStressScenario(it) }
                    )
                }
                TerminalScreen.HISTORICAL -> {
                    HistoricalResearchScreen(
                        historicalData = uiState.historicalData,
                        statistics = uiState.historicalStats,
                        regression = uiState.econometricRegression,
                        forecasts = uiState.forecastScenarios,
                        selectedTimeframe = uiState.historicalTimeframe,
                        onSelectTimeframe = { viewModel.selectHistoricalTimeframe(it) }
                    )
                }
                TerminalScreen.METHODOLOGY -> {
                    GovernanceMethodologyScreen(
                        selectedMethodology = uiState.selectedMethodology,
                        methodologyResults = uiState.methodologyResults,
                        qualityMetrics = uiState.qualityMetrics,
                        fallbackTiers = uiState.fallbackTiers,
                        onSelectMethodology = { viewModel.selectMethodology(it) }
                    )
                }
            }
        }
    }
}
