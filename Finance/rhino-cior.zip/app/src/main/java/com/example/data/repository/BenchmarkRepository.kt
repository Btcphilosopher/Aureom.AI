package com.example.data.repository

import com.example.data.model.*
import com.example.domain.engine.BenchmarkCalculationEngine
import kotlin.math.round

class BenchmarkRepository {

    private var activeTransactions: List<SyntheticTransaction> =
        BenchmarkCalculationEngine.generateSyntheticTransactions(3.84)

    fun getBenchmarkRates(shiftBp: Double = 0.0): List<BenchmarkRate> {
        val s = shiftBp / 100.0
        return listOf(
            BenchmarkRate(Tenor.ON, 3.840 + s, 4.2, 3.710 + s * 0.95, 13.0, 3.750 + s * 0.96, 3.720 + s * 0.95, 3.720, 84.7, 1482),
            BenchmarkRate(Tenor.W1, 3.870 + s, 3.8, 3.720 + s * 0.95, 15.0, 3.750 + s * 0.96, 3.730 + s * 0.95, 3.725, 42.1, 740),
            BenchmarkRate(Tenor.M1, 3.920 + s, 4.1, 3.730 + s * 0.95, 19.0, 3.760 + s * 0.96, 3.750 + s * 0.95, 3.735, 68.4, 912),
            BenchmarkRate(Tenor.M3, 4.010 + s, 5.3, 3.760 + s * 0.95, 25.0, 3.780 + s * 0.96, 3.790 + s * 0.95, 3.770, 95.2, 1120),
            BenchmarkRate(Tenor.M6, 4.120 + s, 6.2, 3.820 + s * 0.95, 30.0, 3.840 + s * 0.96, 3.850 + s * 0.95, 3.830, 71.5, 834),
            BenchmarkRate(Tenor.M12, 4.250 + s, 7.1, 3.910 + s * 0.95, 34.0, 3.920 + s * 0.96, 3.930 + s * 0.95, 3.920, 53.8, 620)
        )
    }

    fun getBasisMetrics(rates: List<BenchmarkRate>): List<BasisMetric> {
        val deltas = mapOf(
            Tenor.ON to Triple(0.8, 2.1, 4.5),
            Tenor.W1 to Triple(0.6, 1.8, 3.9),
            Tenor.M1 to Triple(1.1, 2.4, 5.2),
            Tenor.M3 to Triple(1.4, 3.2, 6.8),
            Tenor.M6 to Triple(1.8, 4.1, 8.4),
            Tenor.M12 to Triple(2.2, 5.0, 9.8)
        )

        return rates.map { r ->
            val d = deltas[r.tenor] ?: Triple(1.0, 2.5, 5.0)
            val zScore = when (r.tenor) {
                Tenor.ON -> 0.42
                Tenor.W1 -> 0.65
                Tenor.M1 -> 1.15
                Tenor.M3 -> 1.48
                Tenor.M6 -> 1.82
                Tenor.M12 -> 2.15
                else -> 1.0
            }
            val percentile = when (r.tenor) {
                Tenor.ON -> 58
                Tenor.W1 -> 64
                Tenor.M1 -> 71
                Tenor.M3 -> 73
                Tenor.M6 -> 81
                Tenor.M12 -> 88
                else -> 70
            }

            BasisMetric(
                tenor = r.tenor,
                cior = r.ciorRate,
                sofr = r.sofrRate,
                basisBp = r.spreadBp,
                dayDeltaBp = d.first,
                weekDeltaBp = d.second,
                monthDeltaBp = d.third,
                zScore = zScore,
                percentile = percentile
            )
        }
    }

    fun getMoneyMarketRates(ciorOnRate: Double = 3.84, sofrRate: Double = 3.71): List<MoneyMarketItem> {
        return listOf(
            MoneyMarketItem("CIOR (Overnight)", "Synthetic Unsecured Regional", ciorOnRate, 4.2, 84.7, (ciorOnRate - sofrRate) * 100.0, "O/N", "HIGH"),
            MoneyMarketItem("SOFR (Secured Overnight)", "Secured Treasury Repo", sofrRate, -1.1, 1850.0, 0.0, "O/N", "MAXIMUM"),
            MoneyMarketItem("Effective Fed Funds (EFFR)", "Central Bank Anchor", 3.75, 0.0, 95.0, 4.0, "O/N", "HIGH"),
            MoneyMarketItem("IORB (Interest on Reserves)", "Fed Administered Floor", 3.90, 0.0, 3100.0, 19.0, "Target", "ADMIN"),
            MoneyMarketItem("US Treasury Bill (4-Week)", "Sovereign Risk-Free", 3.65, -2.4, 420.0, -6.0, "4W", "HIGH"),
            MoneyMarketItem("US Treasury Bill (3-Month)", "Sovereign Risk-Free", 3.62, -1.8, 510.0, -9.0, "13W", "HIGH"),
            MoneyMarketItem("Commercial Paper (AA Tier)", "Wholesale Corporate Short", 3.88, 3.5, 38.0, 17.0, "30D", "MEDIUM"),
            MoneyMarketItem("Commercial Paper (A2/P2 Tier)", "Lower Tier Short Term", 4.18, 7.2, 14.5, 47.0, "30D", "MODERATE"),
            MoneyMarketItem("Certificates of Deposit (CD)", "Bank Wholesale Deposit", 3.95, 2.1, 62.0, 24.0, "90D", "HIGH"),
            MoneyMarketItem("Tri-Party General Repo", "Overnight Collateralized", 3.70, -0.8, 1200.0, -1.0, "O/N", "MAXIMUM"),
            MoneyMarketItem("OIS (3-Month)", "Fed Policy Swap Index", 3.78, 1.2, 85.0, 7.0, "3M", "HIGH"),
            MoneyMarketItem("Term SOFR (3-Month)", "Secured Forward Benchmark", 3.76, 2.0, 140.0, 5.0, "3M", "HIGH"),
            MoneyMarketItem("AMERIBOR (Unsecured AFX)", "US Regional Bank Overnight", 3.82, 3.1, 18.2, 11.0, "O/N", "MEDIUM")
        )
    }

    fun getRegionalPremiums(baseCior: Double = 3.84): List<RegionalFundingPremium> {
        return listOf(
            RegionalFundingPremium("SF Bay Area", "San Francisco / Silicon Valley", baseCior, 14.5, baseCior + 0.145, 92, 54.0, 38.0, "A+", 88, "Tightening (+1.2 bp)"),
            RegionalFundingPremium("Los Angeles Metro", "Los Angeles / Long Beach", baseCior, 12.0, baseCior + 0.120, 88, 22.0, 48.0, "A", 84, "Stable (-0.4 bp)"),
            RegionalFundingPremium("Silicon Valley / South Bay", "San Jose / Santa Clara", baseCior, 16.8, baseCior + 0.168, 85, 68.0, 32.0, "A", 82, "Widening (+2.8 bp)"),
            RegionalFundingPremium("Orange County", "Irvine / Newport Beach", baseCior, 11.5, baseCior + 0.115, 78, 28.0, 44.0, "A", 81, "Orderly (-0.2 bp)"),
            RegionalFundingPremium("San Diego Regional", "San Diego / La Jolla", baseCior, 10.8, baseCior + 0.108, 74, 34.0, 36.0, "A-", 79, "Orderly (0.0 bp)"),
            RegionalFundingPremium("Sacramento Valley", "Sacramento State Capital", baseCior, 9.2, baseCior + 0.092, 70, 14.0, 28.0, "BBB+", 75, "Tight (-0.8 bp)"),
            RegionalFundingPremium("Inland Empire", "Riverside / San Bernardino", baseCior, 13.8, baseCior + 0.138, 65, 12.0, 58.0, "BBB", 70, "Widening (+1.9 bp)"),
            RegionalFundingPremium("Central Valley", "Fresno / Bakersfield", baseCior, 15.2, baseCior + 0.152, 60, 8.0, 34.0, "BBB", 68, "Elevated (+2.1 bp)")
        )
    }

    fun getSectorFundingCurves(baseCior: Double = 3.84): List<SectorFundingCurve> {
        return listOf(
            SectorFundingCurve("Technology & Cloud Software", "TECH-01", baseCior, 65.0, 45.0, 15.0, baseCior + 1.25, 3.2, 42.5),
            SectorFundingCurve("Commercial Real Estate (Office)", "CRE-OFF", baseCior, 145.0, 110.0, 45.0, baseCior + 3.00, 4.5, 28.0),
            SectorFundingCurve("Clean Energy & Solar Grid", "ENERGY-CA", baseCior, 80.0, 50.0, 20.0, baseCior + 1.50, 7.0, 34.0),
            SectorFundingCurve("Data Centres & AI Infrastructure", "DC-AI", baseCior, 72.0, 48.0, 18.0, baseCior + 1.38, 5.0, 39.5),
            SectorFundingCurve("Venture Debt / Growth Equity", "VENT-DEBT", baseCior, 185.0, 140.0, 60.0, baseCior + 3.85, 2.5, 16.2),
            SectorFundingCurve("California Municipal Infrastructure", "CA-MUNI", baseCior, 35.0, 20.0, 8.0, baseCior + 0.63, 10.0, 52.0),
            SectorFundingCurve("Biomedical & Life Sciences", "BIO-TECH", baseCior, 90.0, 60.0, 22.0, baseCior + 1.72, 4.0, 24.8),
            SectorFundingCurve("Aerospace & Defense (SoCal)", "AERO-DEF", baseCior, 55.0, 38.0, 12.0, baseCior + 1.05, 5.5, 19.4),
            SectorFundingCurve("Logistics & Port Facilities", "LOG-PORT", baseCior, 58.0, 40.0, 14.0, baseCior + 1.12, 6.0, 31.0),
            SectorFundingCurve("Entertainment & Media (Hollywood)", "MEDIA-LA", baseCior, 78.0, 52.0, 20.0, baseCior + 1.50, 3.8, 21.5)
        )
    }

    fun getTransactions(): List<SyntheticTransaction> = activeTransactions

    fun getMethodologyResults(tenor: Tenor = Tenor.ON): Map<MethodologyType, MethodologyResult> {
        return mapOf(
            MethodologyType.TRANSACTION_WEIGHTED to BenchmarkCalculationEngine.calculateMethodA(activeTransactions, tenor),
            MethodologyType.TRIMMED_WEIGHTED to BenchmarkCalculationEngine.calculateMethodB(activeTransactions, tenor),
            MethodologyType.MEDIAN to BenchmarkCalculationEngine.calculateMethodC(activeTransactions, tenor),
            MethodologyType.ROBUST_CIOR to BenchmarkCalculationEngine.calculateMethodD(activeTransactions, tenor)
        )
    }

    fun getQualityMetrics(): QualityMetrics {
        return BenchmarkCalculationEngine.calculateQualityScore(activeTransactions)
    }
}
