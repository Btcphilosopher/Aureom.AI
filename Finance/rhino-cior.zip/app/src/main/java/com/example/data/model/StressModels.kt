package com.example.data.model

enum class StressLevel(val label: String) {
    NORMAL("NORMAL"),
    WATCH("WATCH"),
    ELEVATED("ELEVATED"),
    STRESSED("STRESSED"),
    CRISIS("CRISIS")
}

data class StressScenario(
    val id: String,
    val name: String,
    val description: String,
    val shiftBp: Double,
    val ciorShiftBp: Double,
    val sofrShiftBp: Double,
    val basisWideningBp: Double,
    val bankNimImpactBp: Double,
    val debtServiceIncreasePct: Double,
    val level: StressLevel
)

data class LiquidityStressIndex(
    val cliScore: Double, // 0 - 100
    val cliStatus: String,
    val cfsiStatus: StressLevel,
    val moneyMarketDepthScore: Double,
    val bankFundingScore: Double,
    val depositGrowthScore: Double,
    val transactionVolumeScore: Double,
    val bidOfferConditionsScore: Double,
    val fundingStressPenalty: Double
)
