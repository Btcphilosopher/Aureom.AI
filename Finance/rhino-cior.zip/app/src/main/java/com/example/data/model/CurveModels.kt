package com.example.data.model

enum class CurveModelType(val displayName: String, val description: String) {
    CUBIC_SPLINE("Cubic Spline", "Piecewise 3rd-degree polynomials with C2 continuity"),
    MONOTONIC_HERMITE("Monotonic PCHIP", "Shape-preserving cubic Hermite interpolation avoiding overshoots"),
    NELSON_SIEGEL("Nelson-Siegel", "Parametric 3-factor model: Level, Slope, and Curvature"),
    NELSON_SIEGEL_SVENSSON("Nelson-Siegel-Svensson", "Extended 4-factor model with secondary curvature hump")
}

data class CurvePoint(
    val tenor: Tenor,
    val yearFraction: Double,
    val spotRate: Double,
    val forwardRate: Double,
    val zeroRate: Double,
    val discountFactor: Double,
    val parRate: Double
)

data class ForwardRateMatrixItem(
    val startTenor: String,
    val endTenor: String,
    val forwardRatePct: Double,
    val spreadVsSpotBp: Double,
    val label: String
)
