package com.example.data.model

enum class MethodologyType(val code: String, val displayName: String, val formula: String) {
    TRANSACTION_WEIGHTED(
        "METHOD_A",
        "Transaction-Weighted",
        "Σ(Rate × Vol) / Σ(Vol)"
    ),
    TRIMMED_WEIGHTED(
        "METHOD_B",
        "10% Trimmed Weighted Mean",
        "Volume-weighted mean after removing top & bottom 10% outliers"
    ),
    MEDIAN(
        "METHOD_C",
        "Transaction Median",
        "50th percentile volume-ranked transaction rate"
    ),
    ROBUST_CIOR(
        "METHOD_D",
        "Robust Composite CIOR",
        "Trimmed mean weighted with contributor diversity & liquidity stability"
    )
}

data class MethodologyResult(
    val method: MethodologyType,
    val calculatedRate: Double,
    val eligibleTransactions: Int,
    val excludedTransactions: Int,
    val totalVolumeUsd: Double,
    val trimPercent: Double,
    val confidenceGrade: String,
    val dispersionBp: Double
)

data class QualityMetrics(
    val totalScore: Int, // 0 - 100
    val liquidityScore: Int,
    val transactionDepthScore: Int,
    val contributorDiversityScore: Int,
    val dispersionScore: Int,
    val dataFreshnessScore: Int,
    val outlierCount: Int,
    val coefficientOfVariationPct: Double
)

data class FallbackTier(
    val tier: Int,
    val name: String,
    val condition: String,
    val ratePct: Double,
    val isActive: Boolean
)

data class SyntheticInstitution(
    val id: String,
    val name: String,
    val location: String,
    val creditRating: String,
    val ciorContributionRate: Double,
    val fundingVolumeUsd: Double,
    val fundingSpreadBp: Double,
    val lcrPct: Double,
    val nsfrPct: Double,
    val depositGrowthPct: Double,
    val wholesaleFundingPct: Double,
    val cdFundingPct: Double,
    val cpFundingPct: Double,
    val repoFundingPct: Double,
    val tier1CapitalRatioPct: Double
)

data class SyntheticTransaction(
    val id: String,
    val timestamp: String,
    val institutionName: String,
    val tenor: Tenor,
    val ratePct: Double,
    val volumeMillionUsd: Double,
    val counterpartyType: String,
    val fundingChannel: String,
    val isEligible: Boolean,
    val statusDetail: String
)
