package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FallbackTier
import com.example.data.model.MethodologyResult
import com.example.data.model.MethodologyType
import com.example.data.model.QualityMetrics
import com.example.ui.theme.*

@Composable
fun GovernanceMethodologyScreen(
    selectedMethodology: MethodologyType,
    methodologyResults: Map<MethodologyType, MethodologyResult>,
    qualityMetrics: QualityMetrics?,
    fallbackTiers: List<FallbackTier>,
    onSelectMethodology: (MethodologyType) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: Governance & Fixing Overview
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BENCHMARK METHODOLOGY & GOVERNANCE DESK",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = CyanAccent
                    )
                    Text(
                        text = "VER: CIOR-2026.4",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 9.sp,
                        color = AmberAccent
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Multi-Methodology Benchmark Calculation, Robust Outlier Trimming & Fallback Cascade",
                    fontFamily = InterFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        // Section 2: Benchmark Calculation Methods Comparison
        item {
            Text(
                text = "CALCULATION METHODOLOGY COMPARISON (SELECT ACTIVE):",
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextPrimary
            )
        }

        items(MethodologyType.values().toList()) { mType ->
            val res = methodologyResults[mType]
            val isSelected = mType == selectedMethodology

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("method_${mType.code.lowercase()}")
                    .background(if (isSelected) TerminalSurfaceElevated else TerminalSurface)
                    .border(
                        width = if (isSelected) 1.dp else 0.5.dp,
                        color = if (isSelected) CyanAccent else TerminalBorderSubtle
                    )
                    .clickable { onSelectMethodology(mType) }
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(TerminalBackground)
                                .border(0.5.dp, if (isSelected) CyanAccent else TerminalBorderSubtle)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = mType.code,
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = if (isSelected) CyanAccent else TextMuted
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = mType.displayName,
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) TextPrimary else TextSecondary
                        )
                    }

                    res?.let {
                        Text(
                            text = String.format("%.3f%%", it.calculatedRate),
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = CiorAmber
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = mType.formula,
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 9.sp,
                    color = TextMuted
                )

                res?.let {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GovChip(label = "Eligible Trades", value = "${it.eligibleTransactions}", modifier = Modifier.weight(1f))
                        GovChip(label = "Excluded Trades", value = "${it.excludedTransactions}", modifier = Modifier.weight(1f))
                        GovChip(label = "Volume (USD B)", value = "${'$'}${it.totalVolumeUsd}M", modifier = Modifier.weight(1f))
                        GovChip(label = "Confidence", value = it.confidenceGrade, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Section 3: Benchmark Quality Engine (0 - 100 Score)
        qualityMetrics?.let { q ->
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder)
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CIOR BENCHMARK QUALITY SCORE",
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = CyanAccent
                        )
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "${q.totalScore}",
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = RateGreen
                            )
                            Text(
                                text = " / 100",
                                fontFamily = RobotoMonoFontFamily,
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        GovChip(label = "Liquidity", value = "${q.liquidityScore}", modifier = Modifier.weight(1f))
                        GovChip(label = "Tx Depth", value = "${q.transactionDepthScore}", modifier = Modifier.weight(1f))
                        GovChip(label = "Diversity", value = "${q.contributorDiversityScore}", modifier = Modifier.weight(1f))
                        GovChip(label = "Dispersion", value = "${q.dispersionScore}", modifier = Modifier.weight(1f))
                        GovChip(label = "Freshness", value = "${q.dataFreshnessScore}", modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Section 4: Fallback Hierarchy Framework
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "BENCHMARK FALLBACK HIERARCHY (TIERS 1 - 5)",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CiorAmber
                )
                Text(
                    text = "Automated contingency cascade when transaction criteria thresholds are breached",
                    fontFamily = InterFontFamily,
                    fontSize = 9.sp,
                    color = TextSecondary
                )
            }
        }

        items(fallbackTiers) { fb ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("fallback_tier_${fb.tier}")
                    .background(TerminalSurface)
                    .border(
                        width = if (fb.isActive) 1.dp else 0.5.dp,
                        color = if (fb.isActive) RateGreen else TerminalBorderSubtle
                    )
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(2.0f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = fb.name,
                            fontFamily = InterFontFamily,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (fb.isActive) RateGreen else TextPrimary
                        )
                        if (fb.isActive) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(RateGreenBg)
                                    .border(0.5.dp, RateGreen)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "ACTIVE TIER",
                                    fontFamily = RobotoMonoFontFamily,
                                    fontSize = 8.sp,
                                    color = RateGreen
                                )
                            }
                        }
                    }
                    Text(
                        text = fb.condition,
                        fontFamily = InterFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }

                Text(
                    text = String.format("%.3f%%", fb.ratePct),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = CiorAmber
                )
            }
        }
    }
}

@Composable
private fun GovChip(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalBackground)
            .border(0.5.dp, TerminalBorderSubtle)
            .padding(4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = label, fontFamily = InterFontFamily, fontSize = 8.sp, color = TextMuted, maxLines = 1)
            Text(text = value, fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextPrimary)
        }
    }
}
