package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SyntheticInstitution
import com.example.ui.theme.*

@Composable
fun BankFundingScreen(
    institutions: List<SyntheticInstitution>,
    baseRate: Double = 3.84,
    modifier: Modifier = Modifier
) {
    var selectedBank by remember(institutions) { mutableStateOf(institutions.firstOrNull()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Bank Screen Banner
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CALIFORNIA CONTRIBUTING INSTITUTIONS & BANK FUNDING",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = CyanAccent
                    )
                    Text(
                        text = "12 SYNTHETIC BANKS",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 10.sp,
                        color = AmberAccent
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Formula: Funding Rate = Base CIOR + Credit Spread + Liquidity Premium + Term Premium",
                    fontFamily = InterFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        // Institutions Table Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "INSTITUTION", modifier = Modifier.weight(2.0f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                Text(text = "RATING", modifier = Modifier.weight(0.9f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CyanAccent)
                Text(text = "CIOR CONTR", modifier = Modifier.weight(1.2f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CiorAmber)
                Text(text = "SPREAD", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                Text(text = "VOL (USD B)", modifier = Modifier.weight(1.0f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextSecondary)
                Text(text = "LCR", modifier = Modifier.weight(0.9f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = RateGreen)
            }
        }

        // Institutions Rows
        items(institutions) { bank ->
            val isSelected = bank == selectedBank

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bank_${bank.id.lowercase()}")
                    .background(if (isSelected) TerminalSurfaceElevated else TerminalSurface)
                    .border(
                        width = if (isSelected) 1.dp else 0.5.dp,
                        color = if (isSelected) CyanAccent else TerminalBorderSubtle
                    )
                    .clickable { selectedBank = bank }
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(2.0f)) {
                    Text(
                        text = bank.name,
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isSelected) CyanAccent else TextPrimary
                    )
                    Text(
                        text = "${bank.id} • ${bank.location}",
                        fontFamily = InterFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }
                Text(
                    text = bank.creditRating,
                    modifier = Modifier.weight(0.9f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = String.format("%.3f%%", bank.ciorContributionRate),
                    modifier = Modifier.weight(1.2f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CiorAmber
                )
                Text(
                    text = String.format("+%.0fbp", bank.fundingSpreadBp),
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
                Text(
                    text = String.format("$%.1fB", bank.fundingVolumeUsd),
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Text(
                    text = String.format("%.0f%%", bank.lcrPct),
                    modifier = Modifier.weight(0.9f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 10.sp,
                    color = RateGreen
                )
            }
        }

        // Selected Bank Funding Curve & Wholesale Breakdown
        selectedBank?.let { b ->
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "FUNDING STRUCTURE: ${b.name.uppercase()}",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = CyanAccent
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DetailChip(label = "CET1 Ratio", value = "${b.tier1CapitalRatioPct}%", modifier = Modifier.weight(1f))
                        DetailChip(label = "LCR Ratio", value = "${b.lcrPct}%", modifier = Modifier.weight(1f))
                        DetailChip(label = "NSFR Ratio", value = "${b.nsfrPct}%", modifier = Modifier.weight(1f))
                        DetailChip(label = "Dep. Growth", value = "+${b.depositGrowthPct}%", modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Wholesale Liability Composition:",
                        fontFamily = InterFontFamily,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DetailChip(label = "Wholesale CD", value = "${b.cdFundingPct}%", modifier = Modifier.weight(1f))
                        DetailChip(label = "Commercial Paper", value = "${b.cpFundingPct}%", modifier = Modifier.weight(1f))
                        DetailChip(label = "Interbank Borrowing", value = "${b.wholesaleFundingPct}%", modifier = Modifier.weight(1f))
                        DetailChip(label = "Secured Repo", value = "${b.repoFundingPct}%", modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Synthetic Term Funding Curve:",
                        fontFamily = InterFontFamily,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val tenors = listOf("O/N" to 0.0, "1M" to 0.08, "3M" to 0.17, "6M" to 0.28, "1Y" to 0.41, "3Y" to 0.72)
                        tenors.forEach { (t, bump) ->
                            val r = b.ciorContributionRate + bump
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(TerminalBackground)
                                    .border(0.5.dp, TerminalBorderSubtle)
                                    .padding(4.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = t, fontFamily = RobotoMonoFontFamily, fontSize = 9.sp, color = TextMuted)
                                    Text(
                                        text = String.format("%.2f%%", r),
                                        fontFamily = RobotoMonoFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        color = CiorAmber
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailChip(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalBackground)
            .border(0.5.dp, TerminalBorderSubtle)
            .padding(4.dp)
    ) {
        Column {
            Text(text = label, fontFamily = InterFontFamily, fontSize = 8.sp, color = TextMuted)
            Text(text = value, fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextPrimary)
        }
    }
}
