package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CurvePoint
import com.example.ui.theme.*

@Composable
fun InstitutionalCanvasChart(
    curvePoints: List<CurvePoint>,
    showForwardCurve: Boolean = true,
    showZeroCurve: Boolean = true,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder)
            .padding(8.dp)
    ) {
        // Chart Header & Legend
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CIOR TERM STRUCTURE & FORWARD CURVE",
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextPrimary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LegendBadge(color = CiorAmber, label = "CIOR Spot")
                if (showForwardCurve) {
                    LegendBadge(color = CyanAccent, label = "Forward")
                }
                if (showZeroCurve) {
                    LegendBadge(color = SofrBlue, label = "Zero")
                }
            }
        }

        // Custom High-Precision Rates Canvas
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(TerminalBackground)
                .border(0.5.dp, TerminalBorderSubtle)
        ) {
            val width = size.width
            val height = size.height

            val padLeft = 40f
            val padRight = 20f
            val padTop = 15f
            val padBottom = 25f

            val chartWidth = width - padLeft - padRight
            val chartHeight = height - padTop - padBottom

            if (curvePoints.isEmpty()) return@Canvas

            // Compute rate domain
            val allRates = curvePoints.flatMap {
                listOfNotNull(
                    it.spotRate,
                    if (showForwardCurve) it.forwardRate else null,
                    if (showZeroCurve) it.zeroRate else null
                )
            }
            val minRate = (allRates.minOrNull() ?: 3.7) - 0.15
            val maxRate = (allRates.maxOrNull() ?: 4.9) + 0.15
            val rateSpan = (maxRate - minRate).coerceAtLeast(0.1)

            // Draw horizontal grid lines
            val numGridLines = 5
            for (i in 0..numGridLines) {
                val ratio = i.toFloat() / numGridLines.toFloat()
                val y = padTop + chartHeight * (1f - ratio)
                drawLine(
                    color = Color(0xFF16233B),
                    start = Offset(padLeft, y),
                    end = Offset(width - padRight, y),
                    strokeWidth = 1f
                )
            }

            // Draw points & lines
            val numPoints = curvePoints.size
            fun getX(index: Int): Float {
                return padLeft + chartWidth * (index.toFloat() / (numPoints - 1).toFloat())
            }
            fun getY(rate: Double): Float {
                val norm = ((rate - minRate) / rateSpan).toFloat()
                return padTop + chartHeight * (1f - norm)
            }

            // Draw Spot Line (CIOR)
            val spotPath = Path()
            curvePoints.forEachIndexed { i, pt ->
                val x = getX(i)
                val y = getY(pt.spotRate)
                if (i == 0) spotPath.moveTo(x, y) else spotPath.lineTo(x, y)
            }
            drawPath(
                path = spotPath,
                color = CiorAmber,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // Draw Forward Curve Line
            if (showForwardCurve) {
                val fwdPath = Path()
                curvePoints.forEachIndexed { i, pt ->
                    val x = getX(i)
                    val y = getY(pt.forwardRate)
                    if (i == 0) fwdPath.moveTo(x, y) else fwdPath.lineTo(x, y)
                }
                drawPath(
                    path = fwdPath,
                    color = CyanAccent,
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }

            // Draw Zero Curve Line
            if (showZeroCurve) {
                val zeroPath = Path()
                curvePoints.forEachIndexed { i, pt ->
                    val x = getX(i)
                    val y = getY(pt.zeroRate)
                    if (i == 0) zeroPath.moveTo(x, y) else zeroPath.lineTo(x, y)
                }
                drawPath(
                    path = zeroPath,
                    color = SofrBlue.copy(alpha = 0.7f),
                    style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }

            // Draw Pillar Circles for Spot Curve
            curvePoints.forEachIndexed { i, pt ->
                val x = getX(i)
                val y = getY(pt.spotRate)
                drawCircle(
                    color = TerminalBackground,
                    radius = 4.dp.toPx(),
                    center = Offset(x, y)
                )
                drawCircle(
                    color = CiorAmber,
                    radius = 3.dp.toPx(),
                    center = Offset(x, y)
                )
            }
        }

        // Bottom Tenor Axis Labels
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 28.dp, top = 4.dp, end = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            curvePoints.forEach { pt ->
                Text(
                    text = pt.tenor.code,
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }
        }
    }
}

@Composable
private fun LegendBadge(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontFamily = InterFontFamily,
            fontSize = 10.sp,
            color = TextSecondary
        )
    }
}
