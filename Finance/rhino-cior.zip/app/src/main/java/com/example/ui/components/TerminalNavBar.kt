package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.TerminalScreen

@Composable
fun TerminalNavBar(
    currentScreen: TerminalScreen,
    onSelectScreen: (TerminalScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(width = 0.5.dp, color = TerminalBorder)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TerminalScreen.values().forEach { screen ->
            val isSelected = screen == currentScreen

            Box(
                modifier = Modifier
                    .testTag("nav_tab_${screen.code.lowercase()}")
                    .background(if (isSelected) CyanAccentMuted.copy(alpha = 0.25f) else Color.Transparent)
                    .border(
                        width = 1.dp,
                        color = if (isSelected) CyanAccent else TerminalBorderSubtle
                    )
                    .clickable { onSelectScreen(screen) }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${screen.shortKey}:",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) CyanAccent else TextDim
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = screen.code,
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) TextPrimary else TextSecondary
                    )
                }
            }
        }
    }
}
