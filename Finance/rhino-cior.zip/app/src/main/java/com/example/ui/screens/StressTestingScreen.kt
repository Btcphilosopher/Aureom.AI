package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LiquidityStressIndex
import com.example.data.model.StressLevel
import com.example.data.model.StressScenario
import com.example.ui.theme.*

@Composable
fun StressTestingScreen(
    scenarios: List<StressScenario>,
    activeScenario: StressScenario,
    liquidityIndex: LiquidityStressIndex,
    onSelectScenario: (StressScenario) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Section 1: California Liquidity Index (CLI) & Funding Stress Index (CFSI)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CALIFORNIA LIQUIDITY & FUNDING STRESS INDICES",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = CyanAccent
                    )
                    Text(
                        text = "COMPOSITE GAUGE: 0 - 100",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // CLI Box
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(TerminalSurface)
                            .border(1.dp, CyanAccent)
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(text = "CALIFORNIA LIQUIDITY INDEX (CLI)", fontFamily = InterFontFamily, fontSize = 9.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = "${liquidityIndex.cliScore}",
                                    fontFamily = RobotoMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = CyanAccent
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "/ 100",
                                    fontFamily = RobotoMonoFontFamily,
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                            Text(
                                text = liquidityIndex.cliStatus,
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = RateGreen
                            )
                        }
                    }

                    // CFSI Box
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(TerminalSurface)
                            .border(
                                1.dp,
                                when (liquidityIndex.cfsiStatus) {
                                    StressLevel.NORMAL -> RateGreen
                                    StressLevel.WATCH -> AmberAccent
                                    StressLevel.ELEVATED -> StressWarning
                                    StressLevel.STRESSED, StressLevel.CRISIS -> StressCritical
                                }
                            )
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(text = "FUNDING STRESS INDEX (CFSI)", fontFamily = InterFontFamily, fontSize = 9.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = liquidityIndex.cfsiStatus.label,
                                fontFamily = RobotoMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = when (liquidityIndex.cfsiStatus) {
                                    StressLevel.NORMAL -> RateGreen
                                    StressLevel.WATCH -> AmberAccent
                                    StressLevel.ELEVATED -> StressWarning
                                    StressLevel.STRESSED, StressLevel.CRISIS -> StressCritical
                                }
                            )
                            Text(
                                text = "Penalty: -${liquidityIndex.fundingStressPenalty} pts",
                                fontFamily = RobotoMonoFontFamily,
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // CLI Sub-Scores Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SubScoreBox(label = "MM Depth", score = liquidityIndex.moneyMarketDepthScore, modifier = Modifier.weight(1f))
                    SubScoreBox(label = "Bank Fund.", score = liquidityIndex.bankFundingScore, modifier = Modifier.weight(1f))
                    SubScoreBox(label = "Dep. Velocity", score = liquidityIndex.depositGrowthScore, modifier = Modifier.weight(1f))
                    SubScoreBox(label = "Tx Volume", score = liquidityIndex.transactionVolumeScore, modifier = Modifier.weight(1f))
                    SubScoreBox(label = "Bid/Offer", score = liquidityIndex.bidOfferConditionsScore, modifier = Modifier.weight(1f))
                }
            }
        }

        // Section 2: Active Scenario Impact Summary
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "ACTIVE SCENARIO IMPACT: ${activeScenario.name.uppercase()}",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = AmberAccent
                )
                Text(
                    text = activeScenario.description,
                    fontFamily = InterFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ImpactBox(label = "CIOR Shift", value = String.format("%+.1f bp", activeScenario.ciorShiftBp), isNegative = false, modifier = Modifier.weight(1f))
                    ImpactBox(label = "SOFR Shift", value = String.format("%+.1f bp", activeScenario.sofrShiftBp), isNegative = false, modifier = Modifier.weight(1f))
                    ImpactBox(label = "Basis Widening", value = String.format("+%.1f bp", activeScenario.basisWideningBp), isNegative = true, modifier = Modifier.weight(1f))
                    ImpactBox(label = "Bank NIM Δ", value = String.format("%+.1f bp", activeScenario.bankNimImpactBp), isNegative = activeScenario.bankNimImpactBp < 0, modifier = Modifier.weight(1f))
                    ImpactBox(label = "Debt Svc Δ", value = String.format("+%.1f%%", activeScenario.debtServiceIncreasePct), isNegative = true, modifier = Modifier.weight(1f))
                }
            }
        }

        // Section 3: Scenario Selector Header
        item {
            Text(
                text = "AVAILABLE STRESS SCENARIOS (SELECT TO APPLY):",
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextPrimary
            )
        }

        // Scenario Items
        items(scenarios) { sc ->
            val isSelected = sc.id == activeScenario.id

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("scenario_${sc.id.lowercase()}")
                    .background(if (isSelected) TerminalSurfaceElevated else TerminalSurface)
                    .border(
                        width = if (isSelected) 1.dp else 0.5.dp,
                        color = if (isSelected) CyanAccent else TerminalBorderSubtle
                    )
                    .clickable { onSelectScenario(sc) }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(2.0f)) {
                    Text(
                        text = sc.name,
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) CyanAccent else TextPrimary
                    )
                    Text(
                        text = sc.description,
                        fontFamily = InterFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted,
                        maxLines = 1
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(TerminalBackground)
                            .border(0.5.dp, TerminalBorder)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (sc.shiftBp > 0) "+${sc.shiftBp.toInt()} bp" else "BASE",
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = CiorAmber
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(TerminalBackground)
                            .border(
                                0.5.dp,
                                when (sc.level) {
                                    StressLevel.NORMAL -> RateGreen
                                    StressLevel.WATCH -> AmberAccent
                                    StressLevel.ELEVATED -> StressWarning
                                    StressLevel.STRESSED, StressLevel.CRISIS -> StressCritical
                                }
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = sc.level.label,
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            color = when (sc.level) {
                                StressLevel.NORMAL -> RateGreen
                                StressLevel.WATCH -> AmberAccent
                                StressLevel.ELEVATED -> StressWarning
                                StressLevel.STRESSED, StressLevel.CRISIS -> StressCritical
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SubScoreBox(label: String, score: Double, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalBackground)
            .border(0.5.dp, TerminalBorderSubtle)
            .padding(4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = label, fontFamily = InterFontFamily, fontSize = 8.sp, color = TextMuted, maxLines = 1)
            Text(text = "$score", fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextPrimary)
        }
    }
}

@Composable
private fun ImpactBox(label: String, value: String, isNegative: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalBackground)
            .border(0.5.dp, TerminalBorderSubtle)
            .padding(4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = label, fontFamily = InterFontFamily, fontSize = 8.sp, color = TextMuted)
            Text(
                text = value,
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = if (isNegative) RateRed else RateGreen
            )
        }
    }
}
