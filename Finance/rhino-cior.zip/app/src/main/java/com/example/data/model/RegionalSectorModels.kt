package com.example.data.model

data class RegionalFundingPremium(
    val regionName: String,
    val primaryHub: String,
    val baseCiorRate: Double,
    val regionalPremiumBp: Double,
    val allInRate: Double,
    val bankConcentrationScore: Int,
    val techExposurePct: Double,
    val creExposurePct: Double,
    val depositDepthGrade: String,
    val liquidityScore: Int,
    val fundingTrend: String
)

data class SectorFundingCurve(
    val sectorName: String,
    val industryCode: String,
    val baseCior: Double,
    val sectorSpreadBp: Double,
    val creditSpreadBp: Double,
    val liquidityPremiumBp: Double,
    val finalFundingRate: Double,
    val durationYears: Double,
    val averageBorrowingVolumeBn: Double
)
