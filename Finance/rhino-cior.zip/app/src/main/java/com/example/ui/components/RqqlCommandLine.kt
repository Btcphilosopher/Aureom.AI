package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun RqqlCommandLine(
    commandInput: String,
    onCommandChange: (String) -> Unit,
    onExecute: (String) -> Unit,
    outputMessage: String?,
    isSuccess: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(width = 1.dp, color = TerminalBorder)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        // Output Message banner if present
        if (!outputMessage.isNullOrBlank()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SYS> ",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSuccess) CyanAccent else RateRed
                )
                Text(
                    text = outputMessage,
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = if (isSuccess) TextPrimary else RateRed
                )
            }
        }

        // RQQL Prompt Input Field
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalBackground)
                .border(1.dp, CyanAccentMuted)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "RQQL> ",
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = CyanAccent
            )

            BasicTextField(
                value = commandInput,
                onValueChange = onCommandChange,
                modifier = Modifier
                    .weight(1f)
                    .testTag("rqql_command_input"),
                textStyle = TextStyle(
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 12.sp,
                    color = TextPrimary
                ),
                cursorBrush = SolidColor(CyanAccent),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onExecute(commandInput) }),
                decorationBox = { innerTextField ->
                    if (commandInput.isEmpty()) {
                        Text(
                            text = "Enter RQQL command (e.g. CIOR, CURVE, SPREADS, BANKS, STRESS, HELP)...",
                            fontFamily = RobotoMonoFontFamily,
                            fontSize = 11.sp,
                            color = TextDim
                        )
                    }
                    innerTextField()
                }
            )

            Box(
                modifier = Modifier
                    .testTag("rqql_execute_button")
                    .background(TerminalSurfaceElevated)
                    .border(0.5.dp, CyanAccent)
                    .clickable { onExecute(commandInput) }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "EXEC",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
            }
        }

        // Quick Command Shortcut Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SHORTCUTS:",
                fontFamily = InterFontFamily,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = TextDim
            )

            val quickCommands = listOf("CIOR", "CURVE", "SPREADS", "BANKS", "SECTOR", "PRICING", "STRESS", "HIST", "GOV", "RESET")
            quickCommands.forEach { cmd ->
                Box(
                    modifier = Modifier
                        .testTag("quick_cmd_$cmd")
                        .background(TerminalSurfaceElevated)
                        .border(0.5.dp, TerminalBorderSubtle)
                        .clickable { onExecute(cmd) }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = cmd,
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}
