package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TerminalTopBar(
    ciorRate: Double,
    ciorChangeBp: Double,
    sofrRate: Double,
    basisBp: Double,
    fedFundsRate: Double,
    ust2yRate: Double,
    ust10yRate: Double,
    currentTimePt: String,
    onLogoClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(width = 1.dp, color = TerminalBorder)
    ) {
        // Upper Primary Identity Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .testTag("terminal_identity_logo")
                    .clickable { onLogoClick() }
            ) {
                Box(
                    modifier = Modifier
                        .background(TerminalSurfaceElevated)
                        .border(1.dp, CyanAccent)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "RHINO",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = CyanAccent,
                        letterSpacing = 1.5.sp
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "CIOR",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "RATES TERMINAL",
                    fontFamily = InterFontFamily,
                    fontWeight = FontWeight.Normal,
                    fontSize = 10.sp,
                    color = TextMuted,
                    letterSpacing = 0.5.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Live PT Clock
                Box(
                    modifier = Modifier
                        .background(TerminalBackground)
                        .border(1.dp, TerminalBorderSubtle)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = currentTimePt,
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = CyanAccent
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                // Synthetic Data Badge
                Box(
                    modifier = Modifier
                        .background(AmberMuted.copy(alpha = 0.25f))
                        .border(1.dp, AmberAccent)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "SYNTHETIC DEMO",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberAccent
                    )
                }
            }
        }

        // Lower High-Density Financial Rates Ticker Row (Scrollable on narrow mobile)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalBackground)
                .border(width = 0.5.dp, color = TerminalBorderSubtle)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            TickerItem(
                label = "CIOR O/N",
                value = String.format("%.2f%%", ciorRate),
                change = String.format("+%.1f bp", ciorChangeBp),
                isPositive = true,
                valueColor = CiorAmber
            )

            TickerDivider()

            TickerItem(
                label = "SOFR",
                value = String.format("%.2f%%", sofrRate),
                change = "-1.1 bp",
                isPositive = false,
                valueColor = SofrBlue
            )

            TickerDivider()

            TickerItem(
                label = "CIOR-SOFR",
                value = String.format("+%.0f bp", basisBp),
                change = "+1.4 bp",
                isPositive = true,
                valueColor = CyanAccent
            )

            TickerDivider()

            TickerItem(
                label = "FED FUNDS",
                value = String.format("%.2f%%", fedFundsRate),
                change = "0.0 bp",
                isPositive = true,
                valueColor = FedFundsPurple
            )

            TickerDivider()

            TickerItem(
                label = "UST 2Y",
                value = String.format("%.2f%%", ust2yRate),
                change = "-2.4 bp",
                isPositive = false,
                valueColor = TreasuryGreen
            )

            TickerDivider()

            TickerItem(
                label = "UST 10Y",
                value = String.format("%.2f%%", ust10yRate),
                change = "+1.8 bp",
                isPositive = true,
                valueColor = TreasuryGreen
            )

            TickerDivider()

            Text(
                text = "CCY: USD",
                fontFamily = RobotoMonoFontFamily,
                fontSize = 11.sp,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun TickerItem(
    label: String,
    value: String,
    change: String,
    isPositive: Boolean,
    valueColor: androidx.compose.ui.graphics.Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "$label: ",
            fontFamily = InterFontFamily,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = TextMuted
        )
        Text(
            text = value,
            fontFamily = RobotoMonoFontFamily,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = valueColor
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = change,
            fontFamily = RobotoMonoFontFamily,
            fontSize = 10.sp,
            color = if (isPositive) RateGreen else RateRed
        )
    }
}

@Composable
private fun TickerDivider() {
    Text(
        text = "|",
        fontFamily = RobotoMonoFontFamily,
        fontSize = 11.sp,
        color = TerminalBorder
    )
}
