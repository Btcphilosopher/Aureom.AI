package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BenchmarkRate
import com.example.data.model.SyntheticTransaction
import com.example.ui.theme.*

@Composable
fun CiorMarketsScreen(
    rates: List<BenchmarkRate>,
    transactions: List<SyntheticTransaction>,
    onSelectTenor: (BenchmarkRate) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTenorRate by remember(rates) { mutableStateOf(rates.firstOrNull()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Screen Title Banner
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CIOR BENCHMARK FIXINGS & WHOLESALE SPREADS",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = CyanAccent
                    )
                    Text(
                        text = "California Interbank Offered Rate vs Reference USD Benchmarks",
                        fontFamily = InterFontFamily,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }

                Box(
                    modifier = Modifier
                        .background(TerminalBackground)
                        .border(0.5.dp, TerminalBorder)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "FIXING: 11:00 PT",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 10.sp,
                        color = AmberAccent
                    )
                }
            }
        }

        // CIOR Tenor Fixings Table Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "TENOR", modifier = Modifier.weight(1.1f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                Text(text = "CIOR", modifier = Modifier.weight(1.2f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CiorAmber)
                Text(text = "1D CHG", modifier = Modifier.weight(1.2f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                Text(text = "SOFR", modifier = Modifier.weight(1.2f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = SofrBlue)
                Text(text = "SPREAD", modifier = Modifier.weight(1.2f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = CyanAccent)
                Text(text = "VOL (USD)", modifier = Modifier.weight(1.2f), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
            }
        }

        // Table Rows
        items(rates) { rate ->
            val isSelected = rate == selectedTenorRate

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("cior_row_${rate.tenor.code.lowercase()}")
                    .background(if (isSelected) TerminalSurfaceElevated else TerminalSurface)
                    .border(
                        width = if (isSelected) 1.dp else 0.5.dp,
                        color = if (isSelected) CyanAccent else TerminalBorderSubtle
                    )
                    .clickable {
                        selectedTenorRate = rate
                        onSelectTenor(rate)
                    }
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = rate.tenor.code,
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (isSelected) CyanAccent else TextPrimary
                )
                Text(
                    text = String.format("%.3f%%", rate.ciorRate),
                    modifier = Modifier.weight(1.2f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = CiorAmber
                )
                Text(
                    text = String.format("+%.1fbp", rate.changeBp),
                    modifier = Modifier.weight(1.2f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = RateGreen
                )
                Text(
                    text = String.format("%.3f%%", rate.sofrRate),
                    modifier = Modifier.weight(1.2f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = SofrBlue
                )
                Text(
                    text = String.format("+%.0fbp", rate.spreadBp),
                    modifier = Modifier.weight(1.2f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = String.format("$%.1fB", rate.volumeUsdBillions),
                    modifier = Modifier.weight(1.2f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }

        // Selected Tenor Deep Dive Card
        selectedTenorRate?.let { r ->
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder)
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TENOR PROFILE: ${r.tenor.label.uppercase()} (${r.tenor.code})",
                            fontFamily = RobotoMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = CyanAccent
                        )
                        Text(
                            text = "TRADES: ${r.transactionCount}",
                            fontFamily = RobotoMonoFontFamily,
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricBox(label = "CIOR-SOFR", value = String.format("+%.0f bp", r.spreadBp), modifier = Modifier.weight(1f))
                        MetricBox(label = "CIOR-EFFR", value = String.format("+%.0f bp", (r.ciorRate - r.ffRate) * 100.0), modifier = Modifier.weight(1f))
                        MetricBox(label = "CIOR-OIS", value = String.format("+%.0f bp", (r.ciorRate - r.oisRate) * 100.0), modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Live Synthetic Transactions Ingestion Feed Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "WHOLESALE UNSECURED TRANSACTIONS INGESTION",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
                Text(
                    text = "TOTAL: ${transactions.size} TRADES",
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        // Display recent 8 transactions
        items(transactions.take(8)) { tx ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tx.timestamp,
                    modifier = Modifier.weight(1.2f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = TextMuted
                )
                Column(modifier = Modifier.weight(2.2f)) {
                    Text(
                        text = tx.institutionName,
                        fontFamily = InterFontFamily,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextPrimary
                    )
                    Text(
                        text = "${tx.fundingChannel} • ${tx.counterpartyType}",
                        fontFamily = InterFontFamily,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }
                Text(
                    text = tx.tenor.code,
                    modifier = Modifier.weight(0.8f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = CyanAccent
                )
                Text(
                    text = String.format("%.3f%%", tx.ratePct),
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CiorAmber
                )
                Text(
                    text = String.format("$%.1fM", tx.volumeMillionUsd),
                    modifier = Modifier.weight(1.0f),
                    fontFamily = RobotoMonoFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
                Text(
                    text = if (tx.isEligible) "ELIGIBLE" else "OUTLIER",
                    modifier = Modifier.weight(1.1f),
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    color = if (tx.isEligible) RateGreen else RateRed
                )
            }
        }
    }
}

@Composable
private fun MetricBox(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalBackground)
            .border(0.5.dp, TerminalBorderSubtle)
            .padding(6.dp)
    ) {
        Column {
            Text(
                text = label,
                fontFamily = InterFontFamily,
                fontSize = 9.sp,
                color = TextMuted
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = CyanAccent
            )
        }
    }
}
