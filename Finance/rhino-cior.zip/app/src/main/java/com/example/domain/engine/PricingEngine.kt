package com.example.domain.engine

import com.example.data.model.*
import kotlin.math.*

object PricingEngine {

    // Standard Normal CDF approximation (Abramowitz & Stegun)
    fun normalCdf(x: Double): Double {
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429
        val p = 0.2316419
        val c = 0.39894228

        if (x >= 0.0) {
            val t = 1.0 / (1.0 + p * x)
            return (1.0 - c * exp(-x * x / 2.0) * t *
                    (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        } else {
            val t = 1.0 / (1.0 - p * x)
            return (c * exp(-x * x / 2.0) * t *
                    (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        }
    }

    // Normal probability density function
    fun normalPdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
    }

    // 1. Corporate Loan Pricer
    fun priceLoan(
        notionalMillionUsd: Double,
        tenorYears: Double,
        baseCiorPct: Double,
        marginBp: Double,
        commitmentFeeBp: Double = 25.0
    ): LoanPricing {
        val marginPct = marginBp / 100.0
        val feePct = commitmentFeeBp / 100.0
        val allInCoupon = baseCiorPct + marginPct
        val annualInterest = notionalMillionUsd * (allInCoupon / 100.0)

        // Modified duration approximation: D_mod = (1 / y) * (1 - 1 / (1 + y)^T) for par bond
        val y = allInCoupon / 100.0
        val duration = if (y > 0) (1.0 / y) * (1.0 - 1.0 / (1.0 + y).pow(tenorYears)) else tenorYears
        val totalNotionalUsd = notionalMillionUsd * 1_000_000.0
        val dv01 = (totalNotionalUsd * duration * 0.0001) / 1000.0 // in thousands

        // NPV discounted at base rate
        var npv = 0.0
        for (year in 1..tenorYears.toInt().coerceAtLeast(1)) {
            val df = 1.0 / (1.0 + baseCiorPct / 100.0).pow(year.toDouble())
            npv += annualInterest * df
        }
        val terminalDf = 1.0 / (1.0 + baseCiorPct / 100.0).pow(tenorYears)
        npv += notionalMillionUsd * terminalDf

        val effectiveApr = allInCoupon + feePct * 0.5
        val irr = effectiveApr
        val dscr = 1.42 // Simulated debt service coverage based on CA corporate earnings

        return LoanPricing(
            notionalMillionUsd = notionalMillionUsd,
            tenorYears = tenorYears,
            baseCiorPct = baseCiorPct,
            marginBp = marginBp,
            commitmentFeeBp = commitmentFeeBp,
            allInCouponPct = round(allInCoupon * 1000.0) / 1000.0,
            annualCashInterestMillionUsd = round(annualInterest * 100.0) / 100.0,
            effectiveAprPct = round(effectiveApr * 1000.0) / 1000.0,
            npvMillionUsd = round(npv * 100.0) / 100.0,
            irrPct = round(irr * 100.0) / 100.0,
            dscr = round(dscr * 100.0) / 100.0,
            modifiedDurationYears = round(duration * 100.0) / 100.0,
            dv01ThousandsUsd = round(dv01 * 10.0) / 10.0
        )
    }

    // 2. Interest Rate Swaps
    fun priceSwap(
        swapType: SwapType,
        notionalMillionUsd: Double,
        tenorYears: Double,
        baseCiorRate: Double,
        sofrRate: Double
    ): SwapPricing {
        val basisBp = (baseCiorRate - sofrRate) * 100.0
        val parFixedRate = when (swapType) {
            SwapType.CIOR_VS_FIXED -> baseCiorRate + 0.15 * sqrt(tenorYears)
            SwapType.CIOR_VS_SOFR -> sofrRate + (basisBp / 100.0)
            SwapType.CIOR_VS_TERM_SOFR -> sofrRate + 0.05 + (basisBp / 100.0)
        }

        val floatingLeg = when (swapType) {
            SwapType.CIOR_VS_FIXED -> baseCiorRate
            SwapType.CIOR_VS_SOFR -> sofrRate
            SwapType.CIOR_VS_TERM_SOFR -> sofrRate + 0.05
        }

        val duration = (1.0 - (1.0 / (1.0 + parFixedRate / 100.0).pow(tenorYears))) / (parFixedRate / 100.0)
        val dv01 = (notionalMillionUsd * 1_000_000.0 * duration * 0.0001) / 1000.0 // in thousands
        val npv = notionalMillionUsd * (parFixedRate - floatingLeg) * 0.01 * duration

        return SwapPricing(
            swapType = swapType,
            notionalMillionUsd = notionalMillionUsd,
            tenorYears = tenorYears,
            fixedParRatePct = round(parFixedRate * 1000.0) / 1000.0,
            floatingLegRatePct = round(floatingLeg * 1000.0) / 1000.0,
            basisSpreadBp = round(basisBp * 10.0) / 10.0,
            npvMillionUsd = round(npv * 100.0) / 100.0,
            dv01ThousandsUsd = round(dv01 * 10.0) / 10.0,
            hedgeRatio = 1.05
        )
    }

    // 3. Options (Caps, Floors, Swaptions) using Black-76
    fun priceOption(
        instrument: OptionInstrument,
        strikeRatePct: Double,
        notionalMillionUsd: Double,
        tenorYears: Double,
        forwardRatePct: Double = 4.01,
        impliedVolPct: Double = 22.5
    ): OptionPricing {
        val f = forwardRatePct / 100.0
        val k = strikeRatePct / 100.0
        val vol = impliedVolPct / 100.0
        val t = tenorYears
        val r = forwardRatePct / 100.0
        val df = exp(-r * t)

        val sigmaSqrtT = vol * sqrt(t).coerceAtLeast(0.0001)
        val d1 = (ln(f / k) + 0.5 * vol * vol * t) / sigmaSqrtT
        val d2 = d1 - sigmaSqrtT

        val notionalUsd = notionalMillionUsd * 1_000_000.0

        val (rawPrice, delta) = when (instrument) {
            OptionInstrument.CAP, OptionInstrument.PAYER_SWAPTION -> {
                val price = df * (f * normalCdf(d1) - k * normalCdf(d2))
                val d = df * normalCdf(d1)
                price to d
            }
            OptionInstrument.FLOOR, OptionInstrument.RECEIVER_SWAPTION -> {
                val price = df * (k * normalCdf(-d2) - f * normalCdf(-d1))
                val d = -df * normalCdf(-d1)
                price to d
            }
            OptionInstrument.COLLAR -> {
                val cap = df * (f * normalCdf(d1) - (k + 0.005) * normalCdf(d2))
                val floor = df * ((k - 0.005) * normalCdf(-d2) - f * normalCdf(-d1))
                val price = abs(cap - floor)
                price to 0.45
            }
        }

        val premiumThousands = (notionalUsd * rawPrice * t) / 1000.0
        val gamma = df * normalPdf(d1) / (f * sigmaSqrtT)
        val vega = notionalUsd * df * f * sqrt(t) * normalPdf(d1) * 0.01 / 1000.0 // per 1% vol
        val theta = -(notionalUsd * df * f * vol * normalPdf(d1)) / (2.0 * sqrt(t)) / 365.0 / 1000.0

        return OptionPricing(
            instrument = instrument,
            strikeRatePct = strikeRatePct,
            notionalMillionUsd = notionalMillionUsd,
            tenorYears = tenorYears,
            impliedVolPct = impliedVolPct,
            premiumUsdThousands = round(premiumThousands * 10.0) / 10.0,
            delta = round(delta * 1000.0) / 1000.0,
            gamma = round(gamma * 100.0) / 100.0,
            vega = round(vega * 10.0) / 10.0,
            theta = round(theta * 100.0) / 100.0
        )
    }

    // 4. Futures Simulator
    fun getFuturesContracts(ciorRates: List<BenchmarkRate>): List<FuturesContract> {
        val m1 = ciorRates.find { it.tenor == Tenor.M1 }?.ciorRate ?: 3.92
        val m3 = ciorRates.find { it.tenor == Tenor.M3 }?.ciorRate ?: 4.01
        val m6 = ciorRates.find { it.tenor == Tenor.M6 }?.ciorRate ?: 4.12

        return listOf(
            FuturesContract(
                symbol = "C1M-Z6",
                name = "CIOR 1-Month Futures",
                tenorLabel = "1-Month Dec-2026",
                impliedRatePct = m1 + 0.04,
                futuresPrice = 100.0 - (m1 + 0.04),
                basisVsSpotBp = 4.0,
                convexityAdjustmentBp = 0.4,
                initialMarginUsd = 1250.0,
                simulatedDailyPnlUsd = 175.0
            ),
            FuturesContract(
                symbol = "C3M-H7",
                name = "CIOR 3-Month Futures",
                tenorLabel = "3-Month Mar-2027",
                impliedRatePct = m3 + 0.08,
                futuresPrice = 100.0 - (m3 + 0.08),
                basisVsSpotBp = 8.0,
                convexityAdjustmentBp = 1.2,
                initialMarginUsd = 2100.0,
                simulatedDailyPnlUsd = -320.0
            ),
            FuturesContract(
                symbol = "C6M-M7",
                name = "CIOR 6-Month Futures",
                tenorLabel = "6-Month Jun-2027",
                impliedRatePct = m6 + 0.12,
                futuresPrice = 100.0 - (m6 + 0.12),
                basisVsSpotBp = 12.0,
                convexityAdjustmentBp = 2.8,
                initialMarginUsd = 3400.0,
                simulatedDailyPnlUsd = 450.0
            )
        )
    }
}
