package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun TreasuryPricingScreen(
    loanPricing: LoanPricing?,
    swapPricing: SwapPricing?,
    optionPricing: OptionPricing?,
    futuresContracts: List<FuturesContract>,
    onUpdateLoan: (Double, Double, Double) -> Unit,
    onUpdateSwap: (SwapType, Double, Double) -> Unit,
    onUpdateOption: (OptionInstrument, Double, Double, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedNotional by remember { mutableStateOf(500.0) }
    var selectedTenor by remember { mutableStateOf(3.0) }
    var selectedMargin by remember { mutableStateOf(175.0) }

    var selectedSwapType by remember { mutableStateOf(SwapType.CIOR_VS_SOFR) }
    var selectedOptionType by remember { mutableStateOf(OptionInstrument.CAP) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Module 1: Corporate Loan Pricer Banner
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "CORPORATE TREASURY — CIOR SYNDICATED LOAN PRICER",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )
                Text(
                    text = "Calculate All-In Borrowing Cost, Interest Expense, Duration & DV01",
                    fontFamily = InterFontFamily,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        // Loan Inputs Controls
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                // Notional Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "NOTIONAL:", modifier = Modifier.width(80.dp), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(100.0, 250.0, 500.0, 1000.0).forEach { notional ->
                            val isSel = selectedNotional == notional
                            Box(
                                modifier = Modifier
                                    .testTag("loan_notional_${notional.toInt()}")
                                    .background(if (isSel) CyanAccentMuted.copy(alpha = 0.3f) else TerminalBackground)
                                    .border(1.dp, if (isSel) CyanAccent else TerminalBorderSubtle)
                                    .clickable {
                                        selectedNotional = notional
                                        onUpdateLoan(selectedNotional, selectedTenor, selectedMargin)
                                    }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "${'$'}${notional.toInt()}M",
                                    fontFamily = RobotoMonoFontFamily,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) TextPrimary else TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Tenor Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "TENOR:", modifier = Modifier.width(80.dp), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1.0, 3.0, 5.0, 7.0).forEach { tenor ->
                            val isSel = selectedTenor == tenor
                            Box(
                                modifier = Modifier
                                    .testTag("loan_tenor_${tenor.toInt()}")
                                    .background(if (isSel) CyanAccentMuted.copy(alpha = 0.3f) else TerminalBackground)
                                    .border(1.dp, if (isSel) CyanAccent else TerminalBorderSubtle)
                                    .clickable {
                                        selectedTenor = tenor
                                        onUpdateLoan(selectedNotional, selectedTenor, selectedMargin)
                                    }
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "${tenor.toInt()}Y",
                                    fontFamily = RobotoMonoFontFamily,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) TextPrimary else TextSecondary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Margin Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "MARGIN:", modifier = Modifier.width(80.dp), fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(125.0, 175.0, 225.0, 300.0).forEach { margin ->
                            val isSel = selectedMargin == margin
                            Box(
                                modifier = Modifier
                                    .testTag("loan_margin_${margin.toInt()}")
                                    .background(if (isSel) CyanAccentMuted.copy(alpha = 0.3f) else TerminalBackground)
                                    .border(1.dp, if (isSel) CyanAccent else TerminalBorderSubtle)
                                    .clickable {
                                        selectedMargin = margin
                                        onUpdateLoan(selectedNotional, selectedTenor, selectedMargin)
                                    }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "+${margin.toInt()}bp",
                                    fontFamily = RobotoMonoFontFamily,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) TextPrimary else TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Loan Output Results
        loanPricing?.let { lp ->
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "LOAN PRICING & DEBT SERVICE METRICS",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = CiorAmber
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PricingStat(label = "All-In Coupon", value = String.format("%.3f%%", lp.allInCouponPct), highlight = true, modifier = Modifier.weight(1f))
                        PricingStat(label = "Annual Cash Int.", value = String.format("$%.2fM", lp.annualCashInterestMillionUsd), highlight = false, modifier = Modifier.weight(1f))
                        PricingStat(label = "Effective APR", value = String.format("%.3f%%", lp.effectiveAprPct), highlight = false, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PricingStat(label = "Net Present Value", value = String.format("$%.1fM", lp.npvMillionUsd), highlight = false, modifier = Modifier.weight(1f))
                        PricingStat(label = "Mod. Duration", value = "${lp.modifiedDurationYears}Y", highlight = false, modifier = Modifier.weight(1f))
                        PricingStat(label = "DV01 Sensitivity", value = "${'$'}${lp.dv01ThousandsUsd}k/bp", highlight = true, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Module 2: Interest Rate Swaps
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "CIOR INTEREST RATE SWAP (IRS) DESK",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CyanAccent
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SwapType.values().forEach { st ->
                        val isSel = st == selectedSwapType
                        Box(
                            modifier = Modifier
                                .testTag("swap_tab_${st.name.lowercase()}")
                                .background(if (isSel) CyanAccentMuted.copy(alpha = 0.3f) else TerminalSurface)
                                .border(1.dp, if (isSel) CyanAccent else TerminalBorderSubtle)
                                .clickable {
                                    selectedSwapType = st
                                    onUpdateSwap(st, 100.0, 5.0)
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = st.label,
                                fontFamily = RobotoMonoFontFamily,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) TextPrimary else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        swapPricing?.let { sp ->
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PricingStat(label = "Par Fixed Rate", value = String.format("%.3f%%", sp.fixedParRatePct), highlight = true, modifier = Modifier.weight(1f))
                    PricingStat(label = "Floating Leg", value = String.format("%.3f%%", sp.floatingLegRatePct), highlight = false, modifier = Modifier.weight(1f))
                    PricingStat(label = "Basis Spread", value = String.format("+%.1f bp", sp.basisSpreadBp), highlight = false, modifier = Modifier.weight(1f))
                    PricingStat(label = "Swap DV01", value = "${'$'}${sp.dv01ThousandsUsd}k", highlight = true, modifier = Modifier.weight(1f))
                }
            }
        }

        // Module 3: Options (Caps / Floors / Swaptions)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Text(
                    text = "CIOR INTEREST RATE OPTIONS (BLACK-76 MODEL)",
                    fontFamily = RobotoMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = CiorAmber
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OptionInstrument.values().forEach { opt ->
                        val isSel = opt == selectedOptionType
                        Box(
                            modifier = Modifier
                                .testTag("opt_tab_${opt.name.lowercase()}")
                                .background(if (isSel) AmberMuted.copy(alpha = 0.3f) else TerminalSurface)
                                .border(1.dp, if (isSel) AmberAccent else TerminalBorderSubtle)
                                .clickable {
                                    selectedOptionType = opt
                                    onUpdateOption(opt, 4.25, 100.0, 3.0)
                                }
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = opt.label,
                                fontFamily = RobotoMonoFontFamily,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) AmberAccent else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        optionPricing?.let { op ->
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PricingStat(label = "Premium (k USD)", value = "${'$'}${op.premiumUsdThousands}k", highlight = true, modifier = Modifier.weight(1f))
                    PricingStat(label = "Delta (Δ)", value = String.format("%.3f", op.delta), highlight = false, modifier = Modifier.weight(1f))
                    PricingStat(label = "Gamma (Γ)", value = String.format("%.2f", op.gamma), highlight = false, modifier = Modifier.weight(1f))
                    PricingStat(label = "Vega (ν)", value = "${'$'}${op.vega}k", highlight = false, modifier = Modifier.weight(1f))
                }
            }
        }

        // Module 4: Synthetic Futures Simulator
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .background(TerminalSurfaceElevated)
                    .border(1.dp, TerminalBorder)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SIMULATED CIOR MONEY MARKET FUTURES",
                        fontFamily = RobotoMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = CyanAccent
                    )
                    Text(
                        text = "SIMULATED CONTRACTS",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 9.sp,
                        color = AmberAccent
                    )
                }
            }
        }

        items(futuresContracts.size) { idx ->
            val fc = futuresContracts[idx]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("fut_${fc.symbol.lowercase()}")
                    .background(TerminalSurface)
                    .border(0.5.dp, TerminalBorderSubtle)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = fc.symbol, fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = CyanAccent)
                    Text(text = fc.tenorLabel, fontFamily = InterFontFamily, fontSize = 9.sp, color = TextMuted)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = String.format("Price: %.3f", fc.futuresPrice), fontFamily = RobotoMonoFontFamily, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextPrimary)
                    Text(text = String.format("Rate: %.3f%% (Basis +%.1f bp)", fc.impliedRatePct, fc.basisVsSpotBp), fontFamily = RobotoMonoFontFamily, fontSize = 9.sp, color = CiorAmber)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Margin: ${'$'}${fc.initialMarginUsd.toInt()}", fontFamily = RobotoMonoFontFamily, fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = if (fc.simulatedDailyPnlUsd >= 0) "+${'$'}${fc.simulatedDailyPnlUsd.toInt()}" else "-${'$'}${(-fc.simulatedDailyPnlUsd).toInt()}",
                        fontFamily = RobotoMonoFontFamily,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (fc.simulatedDailyPnlUsd >= 0) RateGreen else RateRed
                    )
                }
            }
        }
    }
}

@Composable
private fun PricingStat(label: String, value: String, highlight: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(TerminalBackground)
            .border(0.5.dp, if (highlight) CyanAccentMuted else TerminalBorderSubtle)
            .padding(6.dp)
    ) {
        Column {
            Text(text = label, fontFamily = InterFontFamily, fontSize = 8.sp, color = TextMuted)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontFamily = RobotoMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (highlight) CyanAccent else TextPrimary
            )
        }
    }
}
