package com.example.domain.engine

import com.example.data.model.*
import kotlin.math.*

object EconometricEngine {

    fun getHistoricalSeries(timeframe: String): List<HistoricalDataPoint> {
        val count = when (timeframe) {
            "1D" -> 24
            "1W" -> 35
            "1M" -> 30
            "3M" -> 60
            "6M" -> 90
            "1Y" -> 120
            "5Y" -> 180
            "10Y" -> 240
            else -> 60
        }

        val list = mutableListOf<HistoricalDataPoint>()
        var cior = 3.84
        var sofr = 3.71
        var ff = 3.75
        var tbill = 3.65

        for (i in 0 until count) {
            val progress = i.toDouble() / count.toDouble()
            // Synthetic mean-reverting macroeconomic cycle
            val cycle = sin(progress * 4.0 * Math.PI) * 0.45
            val noise = (sin(i * 1.7) * 0.04)

            val s = (3.50 + cycle * 0.8 + noise).coerceAtLeast(1.50)
            val spread = (0.13 + 0.06 * sin(i * 0.8) + (if (i % 17 == 0) 0.12 else 0.0)).coerceAtLeast(0.04)
            val c = s + spread
            val f = s + 0.04
            val tb = s - 0.06
            val vol = (14.2 + 8.5 * abs(sin(i * 0.5))).coerceIn(8.0, 38.0)

            val day = (i * 3) % 28 + 1
            val month = (i % 12) + 1
            val year = 2026 - (count - i) / 25
            val date = String.format("%04d-%02d-%02d", year, month, day)

            list.add(
                HistoricalDataPoint(
                    dateStr = date,
                    ciorRate = round(c * 1000.0) / 1000.0,
                    sofrRate = round(s * 1000.0) / 1000.0,
                    basisBp = round(spread * 10000.0) / 100.0,
                    fedFundsRate = round(f * 1000.0) / 1000.0,
                    tbillRate = round(tb * 1000.0) / 1000.0,
                    volatilityAnnualizedPct = round(vol * 10.0) / 10.0
                )
            )
        }
        return list
    }

    fun computeStatistics(data: List<HistoricalDataPoint>): StatisticalSummary {
        val rates = data.map { it.ciorRate }.sorted()
        if (rates.isEmpty()) {
            return StatisticalSummary(3.84, 3.84, 3.80, 3.90, 0.05, 3.82, 3.86, 0.0, 15.0, 0.12)
        }

        val mean = rates.average()
        val median = rates[rates.size / 2]
        val min = rates.first()
        val max = rates.last()
        val variance = rates.map { (it - mean).pow(2) }.average()
        val stdDev = sqrt(variance)

        val p25 = rates[(rates.size * 0.25).toInt()]
        val p75 = rates[(rates.size * 0.75).toInt()]
        val zScore = if (stdDev > 0) (rates.last() - mean) / stdDev else 0.0

        // Max drawdown in bp
        var peak = rates.first()
        var maxDd = 0.0
        for (r in rates) {
            if (r > peak) peak = r
            val dd = (peak - r) * 100.0
            if (dd > maxDd) maxDd = dd
        }

        // 99% Parametric VaR (1-day)
        val var99 = 2.326 * stdDev

        return StatisticalSummary(
            mean = round(mean * 1000.0) / 1000.0,
            median = round(median * 1000.0) / 1000.0,
            min = round(min * 1000.0) / 1000.0,
            max = round(max * 1000.0) / 1000.0,
            stdDev = round(stdDev * 1000.0) / 1000.0,
            p25 = round(p25 * 1000.0) / 1000.0,
            p75 = round(p75 * 1000.0) / 1000.0,
            zScore = round(zScore * 100.0) / 100.0,
            maxDrawdownBp = round(maxDd * 10.0) / 10.0,
            var99Pct = round(var99 * 1000.0) / 1000.0
        )
    }

    fun getEconometricRegression(): EconometricRegression {
        // Multi-factor econometric regression: CIOR = f(SOFR, CreditSpread, Liquidity, Term)
        return EconometricRegression(
            sofrBeta = 0.964,
            creditSpreadBeta = 0.428,
            liquidityBeta = -0.015,
            termBeta = 0.182,
            interceptAlpha = 0.082,
            rSquared = 0.942,
            tStatSofr = 28.4,
            fStatistic = 142.6
        )
    }

    fun getForecastScenarios(currentCior3M: Double = 4.01): List<ForecastScenario> {
        val horizons = listOf("1D", "1W", "1M", "3M", "6M", "12M")
        return horizons.mapIndexed { idx, horiz ->
            val drift = when (horiz) {
                "1D" -> 0.001
                "1W" -> 0.005
                "1M" -> 0.02
                "3M" -> 0.06
                "6M" -> 0.14
                "12M" -> 0.28
                else -> 0.35
            }
            val unc = 0.03 * sqrt((idx + 1).toDouble())

            val base = currentCior3M + drift
            val bull = currentCior3M + drift - 0.08 * (idx + 1)
            val bear = currentCior3M + drift + 0.11 * (idx + 1)
            val stress = currentCior3M + drift + 0.25 * (idx + 1)

            ForecastScenario(
                horizon = horiz,
                baseRate = round(base * 1000.0) / 1000.0,
                bullRate = round(bull * 1000.0) / 1000.0,
                bearRate = round(bear * 1000.0) / 1000.0,
                stressRate = round(stress * 1000.0) / 1000.0,
                confidenceLower95 = round((base - 1.96 * unc) * 1000.0) / 1000.0,
                confidenceUpper95 = round((base + 1.96 * unc) * 1000.0) / 1000.0
            )
        }
    }
}
