package com.example.data.model

data class HistoricalDataPoint(
    val dateStr: String,
    val ciorRate: Double,
    val sofrRate: Double,
    val basisBp: Double,
    val fedFundsRate: Double,
    val tbillRate: Double,
    val volatilityAnnualizedPct: Double
)

data class StatisticalSummary(
    val mean: Double,
    val median: Double,
    val min: Double,
    val max: Double,
    val stdDev: Double,
    val p25: Double,
    val p75: Double,
    val zScore: Double,
    val maxDrawdownBp: Double,
    val var99Pct: Double
)

data class EconometricRegression(
    val sofrBeta: Double,
    val creditSpreadBeta: Double,
    val liquidityBeta: Double,
    val termBeta: Double,
    val interceptAlpha: Double,
    val rSquared: Double,
    val tStatSofr: Double,
    val fStatistic: Double
)

data class ForecastScenario(
    val horizon: String,
    val baseRate: Double,
    val bullRate: Double,
    val bearRate: Double,
    val stressRate: Double,
    val confidenceLower95: Double,
    val confidenceUpper95: Double
)
