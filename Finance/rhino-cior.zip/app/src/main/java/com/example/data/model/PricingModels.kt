package com.example.data.model

data class LoanPricing(
    val notionalMillionUsd: Double,
    val tenorYears: Double,
    val baseCiorPct: Double,
    val marginBp: Double,
    val commitmentFeeBp: Double,
    val allInCouponPct: Double,
    val annualCashInterestMillionUsd: Double,
    val effectiveAprPct: Double,
    val npvMillionUsd: Double,
    val irrPct: Double,
    val dscr: Double,
    val modifiedDurationYears: Double,
    val dv01ThousandsUsd: Double
)

enum class SwapType(val label: String) {
    CIOR_VS_SOFR("CIOR vs SOFR Basis Swap"),
    CIOR_VS_FIXED("CIOR vs Fixed Vanilla Swap"),
    CIOR_VS_TERM_SOFR("CIOR vs Term SOFR Basis Swap")
}

data class SwapPricing(
    val swapType: SwapType,
    val notionalMillionUsd: Double,
    val tenorYears: Double,
    val fixedParRatePct: Double,
    val floatingLegRatePct: Double,
    val basisSpreadBp: Double,
    val npvMillionUsd: Double,
    val dv01ThousandsUsd: Double,
    val hedgeRatio: Double
)

enum class OptionInstrument(val label: String) {
    CAP("Interest Rate Cap"),
    FLOOR("Interest Rate Floor"),
    COLLAR("Interest Rate Collar"),
    PAYER_SWAPTION("Payer Swaption (Pay Fixed / Rec CIOR)"),
    RECEIVER_SWAPTION("Receiver Swaption (Rec Fixed / Pay CIOR)")
}

data class OptionPricing(
    val instrument: OptionInstrument,
    val strikeRatePct: Double,
    val notionalMillionUsd: Double,
    val tenorYears: Double,
    val impliedVolPct: Double,
    val premiumUsdThousands: Double,
    val delta: Double,
    val gamma: Double,
    val vega: Double,
    val theta: Double
)

data class FuturesContract(
    val symbol: String,
    val name: String,
    val tenorLabel: String,
    val impliedRatePct: Double,
    val futuresPrice: Double, // 100 - Rate
    val basisVsSpotBp: Double,
    val convexityAdjustmentBp: Double,
    val initialMarginUsd: Double,
    val simulatedDailyPnlUsd: Double
)
