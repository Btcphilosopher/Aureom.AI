package com.example.data.model

enum class Tenor(val code: String, val label: String, val days: Int, val yearFraction: Double) {
    ON("O/N", "Overnight", 1, 1.0 / 360.0),
    W1("1W", "1 Week", 7, 7.0 / 360.0),
    M1("1M", "1 Month", 30, 30.0 / 360.0),
    M3("3M", "3 Month", 90, 90.0 / 360.0),
    M6("6M", "6 Month", 180, 180.0 / 360.0),
    M12("12M", "12 Month", 360, 1.0),
    Y2("2Y", "2 Year", 720, 2.0),
    Y3("3Y", "3 Year", 1080, 3.0),
    Y5("5Y", "5 Year", 1800, 5.0)
}

data class BenchmarkRate(
    val tenor: Tenor,
    val ciorRate: Double,
    val changeBp: Double,
    val sofrRate: Double,
    val spreadBp: Double,
    val ffRate: Double,
    val oisRate: Double,
    val termSofrRate: Double,
    val volumeUsdBillions: Double,
    val transactionCount: Int
)

data class BasisMetric(
    val tenor: Tenor,
    val cior: Double,
    val sofr: Double,
    val basisBp: Double,
    val dayDeltaBp: Double,
    val weekDeltaBp: Double,
    val monthDeltaBp: Double,
    val zScore: Double,
    val percentile: Int
)

data class MoneyMarketItem(
    val instrument: String,
    val category: String,
    val ratePct: Double,
    val changeBp: Double,
    val volumeUsdBillions: Double,
    val spreadVsSofrBp: Double,
    val tenorLabel: String,
    val liquidityRating: String
)
