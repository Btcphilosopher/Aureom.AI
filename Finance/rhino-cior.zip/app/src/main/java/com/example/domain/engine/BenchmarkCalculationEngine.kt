package com.example.domain.engine

import com.example.data.model.*
import kotlin.math.*

object BenchmarkCalculationEngine {

    // 12 Synthetic California Financial Institutions (Explicitly labeled Demonstration Data)
    val syntheticInstitutions = listOf(
        SyntheticInstitution("CCB-01", "California Commercial Bank", "San Francisco, CA", "A+", 3.84, 18.4, 13.0, 138.5, 122.0, 4.2, 28.5, 34.0, 14.5, 12.0, 14.2),
        SyntheticInstitution("PCB-02", "Pacific Coast Bank", "Los Angeles, CA", "AA-", 3.82, 14.2, 11.0, 145.0, 128.5, 5.1, 22.0, 38.0, 12.0, 16.0, 15.6),
        SyntheticInstitution("GSF-03", "Golden State Financial", "Sacramento, CA", "A", 3.85, 9.8, 14.0, 131.0, 118.0, 3.8, 31.0, 32.5, 15.0, 10.5, 13.8),
        SyntheticInstitution("BCB-04", "Bay Capital Bank", "San Jose, CA", "A-", 3.86, 11.6, 15.0, 129.5, 116.2, 6.4, 35.0, 29.0, 18.0, 8.0, 13.1),
        SyntheticInstitution("SVC-05", "Silicon Valley Commercial", "Santa Clara, CA", "BBB+", 3.89, 7.5, 18.0, 124.0, 112.0, 2.1, 42.0, 24.0, 21.0, 6.0, 12.4),
        SyntheticInstitution("WCC-06", "West Coast Credit Bank", "San Diego, CA", "A", 3.85, 6.9, 14.0, 133.0, 119.5, 4.0, 29.0, 36.0, 13.0, 11.0, 14.0),
        SyntheticInstitution("LAM-07", "Los Angeles Metropolitan Bank", "Los Angeles, CA", "A+", 3.83, 12.8, 12.0, 140.2, 124.0, 4.8, 25.0, 35.0, 14.0, 14.0, 14.8),
        SyntheticInstitution("SFF-08", "San Francisco Financial Corp", "San Francisco, CA", "AA-", 3.82, 15.1, 11.0, 144.0, 127.0, 4.6, 24.0, 37.0, 11.0, 15.5, 15.2),
        SyntheticInstitution("OCC-09", "Orange County Commercial", "Irvine, CA", "A-", 3.86, 5.4, 15.0, 128.0, 115.0, 3.9, 33.0, 31.0, 17.0, 9.0, 13.5),
        SyntheticInstitution("SAC-10", "Sacramento Regional Bank", "Sacramento, CA", "A", 3.85, 4.8, 14.0, 132.5, 118.5, 3.5, 30.0, 35.0, 14.0, 10.0, 13.9),
        SyntheticInstitution("SDI-11", "San Diego Interbank", "San Diego, CA", "A+", 3.83, 6.1, 12.0, 139.0, 123.5, 4.4, 26.0, 36.0, 13.5, 12.5, 14.5),
        SyntheticInstitution("CVT-12", "Central Valley Trust", "Fresno, CA", "A-", 3.87, 3.2, 16.0, 127.0, 114.0, 3.1, 34.0, 30.0, 18.0, 8.5, 13.2)
    )

    fun generateSyntheticTransactions(baseRate: Double = 3.84): List<SyntheticTransaction> {
        val list = mutableListOf<SyntheticTransaction>()
        val channels = listOf("Wholesale CD", "Interbank Term", "Unsecured Borrowing", "Commercial Paper", "Federal Funds Desk")
        val counterparties = listOf("Regional Bank", "Asset Manager", "Corporate Treasury", "Credit Union", "Insurance Fund")
        
        var txId = 10001
        syntheticInstitutions.forEach { inst ->
            val numTxs = (inst.fundingVolumeUsd * 8).toInt().coerceIn(30, 160)
            for (i in 0 until numTxs) {
                val tenor = when (i % 6) {
                    0 -> Tenor.ON
                    1 -> Tenor.W1
                    2 -> Tenor.M1
                    3 -> Tenor.M3
                    4 -> Tenor.M6
                    else -> Tenor.M12
                }
                // Rate spread based on institution credit and tenor term structure
                val tenorSpread = when (tenor) {
                    Tenor.ON -> 0.0
                    Tenor.W1 -> 0.03
                    Tenor.M1 -> 0.08
                    Tenor.M3 -> 0.17
                    Tenor.M6 -> 0.28
                    Tenor.M12 -> 0.41
                    else -> 0.50
                }
                val randomJitter = ((i * 17 + inst.name.hashCode()) % 21 - 10) * 0.005
                val rate = baseRate + tenorSpread + (inst.fundingSpreadBp - 13.0) * 0.01 + randomJitter
                val vol = (((i * 31 + inst.fundingVolumeUsd.toInt()) % 90) + 10) * 1.5 // $15M to $150M

                // Mark some outliers for audit demonstration
                val isOutlier = (i == 4 && inst.id == "SVC-05") || (i == 8 && inst.id == "CVT-12")
                val finalRate = if (isOutlier) rate + 0.45 else rate
                val isEligible = !isOutlier

                val reason = if (isOutlier) "Statistical rate outlier (>3.5 sigma dispersion)" else "Eligible"
                val hour = 8 + (i % 8)
                val min = (i * 7) % 60
                val sec = (i * 13) % 60
                val timeStr = String.format("%02d:%02d:%02d PT", hour, min, sec)

                list.add(
                    SyntheticTransaction(
                        id = "TX-$txId",
                        timestamp = timeStr,
                        institutionName = inst.name,
                        tenor = tenor,
                        ratePct = (round(finalRate * 1000.0) / 1000.0),
                        volumeMillionUsd = vol,
                        counterpartyType = counterparties[i % counterparties.size],
                        fundingChannel = channels[i % channels.size],
                        isEligible = isEligible,
                        statusDetail = reason
                    )
                )
                txId++
            }
        }
        return list
    }

    // Method A: Transaction-Weighted Mean
    fun calculateMethodA(txs: List<SyntheticTransaction>, targetTenor: Tenor = Tenor.ON): MethodologyResult {
        val filtered = txs.filter { it.isEligible && (it.tenor == targetTenor || targetTenor == Tenor.ON) }
        val totalVol = filtered.sumOf { it.volumeMillionUsd }
        val weightedSum = filtered.sumOf { it.ratePct * it.volumeMillionUsd }
        val rate = if (totalVol > 0) weightedSum / totalVol else 3.842

        return MethodologyResult(
            method = MethodologyType.TRANSACTION_WEIGHTED,
            calculatedRate = round(rate * 1000.0) / 1000.0,
            eligibleTransactions = filtered.size,
            excludedTransactions = txs.size - filtered.size,
            totalVolumeUsd = round(totalVol * 10.0) / 10.0,
            trimPercent = 0.0,
            confidenceGrade = "HIGH",
            dispersionBp = 4.2
        )
    }

    // Method B: 10% Trimmed Weighted Mean
    fun calculateMethodB(txs: List<SyntheticTransaction>, targetTenor: Tenor = Tenor.ON): MethodologyResult {
        val filtered = txs.filter { it.isEligible && (it.tenor == targetTenor || targetTenor == Tenor.ON) }
            .sortedBy { it.ratePct }
        if (filtered.isEmpty()) return calculateMethodA(txs, targetTenor)

        val totalCount = filtered.size
        val trimCount = (totalCount * 0.10).toInt()
        val trimmed = filtered.subList(trimCount, totalCount - trimCount)
        val totalVol = trimmed.sumOf { it.volumeMillionUsd }
        val weightedSum = trimmed.sumOf { it.ratePct * it.volumeMillionUsd }
        val rate = if (totalVol > 0) weightedSum / totalVol else 3.840

        return MethodologyResult(
            method = MethodologyType.TRIMMED_WEIGHTED,
            calculatedRate = round(rate * 1000.0) / 1000.0,
            eligibleTransactions = trimmed.size,
            excludedTransactions = txs.size - trimmed.size,
            totalVolumeUsd = round(totalVol * 10.0) / 10.0,
            trimPercent = 10.0,
            confidenceGrade = "HIGH",
            dispersionBp = 2.8
        )
    }

    // Method C: Transaction Median
    fun calculateMethodC(txs: List<SyntheticTransaction>, targetTenor: Tenor = Tenor.ON): MethodologyResult {
        val filtered = txs.filter { it.isEligible && (it.tenor == targetTenor || targetTenor == Tenor.ON) }
            .sortedBy { it.ratePct }
        val medianRate = if (filtered.isNotEmpty()) {
            val mid = filtered.size / 2
            if (filtered.size % 2 == 0) (filtered[mid - 1].ratePct + filtered[mid].ratePct) / 2.0
            else filtered[mid].ratePct
        } else 3.840

        return MethodologyResult(
            method = MethodologyType.MEDIAN,
            calculatedRate = round(medianRate * 1000.0) / 1000.0,
            eligibleTransactions = filtered.size,
            excludedTransactions = txs.size - filtered.size,
            totalVolumeUsd = round(filtered.sumOf { it.volumeMillionUsd } * 10.0) / 10.0,
            trimPercent = 0.0,
            confidenceGrade = "MODERATE",
            dispersionBp = 3.5
        )
    }

    // Method D: Robust Composite CIOR
    fun calculateMethodD(txs: List<SyntheticTransaction>, targetTenor: Tenor = Tenor.ON): MethodologyResult {
        val trimmed = calculateMethodB(txs, targetTenor)
        val median = calculateMethodC(txs, targetTenor)
        // Robust composite formula balancing trimmed mean (70%) and median (30%)
        val robustRate = 0.70 * trimmed.calculatedRate + 0.30 * median.calculatedRate

        return MethodologyResult(
            method = MethodologyType.ROBUST_CIOR,
            calculatedRate = round(robustRate * 1000.0) / 1000.0,
            eligibleTransactions = trimmed.eligibleTransactions,
            excludedTransactions = trimmed.excludedTransactions,
            totalVolumeUsd = trimmed.totalVolumeUsd,
            trimPercent = 10.0,
            confidenceGrade = "HIGHEST",
            dispersionBp = 2.4
        )
    }

    // Quality Scoring Engine (0 - 100)
    fun calculateQualityScore(txs: List<SyntheticTransaction>): QualityMetrics {
        val eligible = txs.filter { it.isEligible }
        val outlierCount = txs.size - eligible.size

        val rates = eligible.map { it.ratePct }
        val mean = if (rates.isNotEmpty()) rates.average() else 3.84
        val variance = if (rates.size > 1) rates.map { (it - mean).pow(2) }.average() else 0.0001
        val stdDev = sqrt(variance)
        val cv = if (mean > 0) (stdDev / mean) * 100.0 else 0.5

        val liquidity = 91
        val depth = 84
        val diversity = 82
        val dispersion = 89
        val freshness = 94
        val overall = ((liquidity * 0.25) + (depth * 0.20) + (diversity * 0.20) + (dispersion * 0.20) + (freshness * 0.15)).toInt()

        return QualityMetrics(
            totalScore = overall,
            liquidityScore = liquidity,
            transactionDepthScore = depth,
            contributorDiversityScore = diversity,
            dispersionScore = dispersion,
            dataFreshnessScore = freshness,
            outlierCount = outlierCount,
            coefficientOfVariationPct = round(cv * 100.0) / 100.0
        )
    }

    // Fallback Framework Hierarchy (Tiers 1 to 5)
    fun getFallbackTiers(currentRate: Double, sofrRate: Double): List<FallbackTier> {
        return listOf(
            FallbackTier(1, "Tier 1: Transaction-Weighted", "Volume >= $25B, >= 500 eligible trades, >= 8 contributors", currentRate, true),
            FallbackTier(2, "Tier 2: 10% Trimmed Mean", "Volume >= $15B, >= 250 eligible trades, >= 5 contributors", currentRate - 0.002, false),
            FallbackTier(3, "Tier 3: Median Transaction", "Volume >= $8B, >= 100 eligible trades, >= 3 contributors", currentRate - 0.004, false),
            FallbackTier(4, "Tier 4: Observable Market Proxy", "Synthetic Proxy: SOFR + Historical 30-Day Median Regional Spread (+13 bp)", sofrRate + 0.13, false),
            FallbackTier(5, "Tier 5: Approved Contingency Fallback", "Previous Business Day Fixing carryover with Fed Funds corridor bounds", 3.840, false)
        )
    }
}
