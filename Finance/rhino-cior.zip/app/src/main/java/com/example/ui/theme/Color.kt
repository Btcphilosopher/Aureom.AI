package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Terminal Institutional Palette - Late 2020s Rates Desk
val TerminalBackground = Color(0xFF070B12)
val TerminalSurface = Color(0xFF0D1422)
val TerminalSurfaceElevated = Color(0xFF131D31)
val TerminalSurfaceHighlight = Color(0xFF1A2742)

val TerminalBorder = Color(0xFF1E2D4A)
val TerminalBorderSubtle = Color(0xFF152238)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextDim = Color(0xFF475569)

// Quantitative Rates Desk Accents
val CyanAccent = Color(0xFF38BDF8)
val CyanAccentMuted = Color(0xFF0284C7)
val AmberAccent = Color(0xFFF59E0B)
val AmberMuted = Color(0xFFB45309)

// Financial Up/Down Indicators (Restrained Institutional)
val RateGreen = Color(0xFF10B981)
val RateGreenBg = Color(0xFF063A26)
val RateRed = Color(0xFFF43F5E)
val RateRedBg = Color(0xFF3B0B14)
val RateNeutral = Color(0xFF94A3B8)

// Specialized Institutional Colors
val SofrBlue = Color(0xFF60A5FA)
val CiorAmber = Color(0xFFFBBF24)
val FedFundsPurple = Color(0xFFA78BFA)
val TreasuryGreen = Color(0xFF34D399)
val StressWarning = Color(0xFFFB923C)
val StressCritical = Color(0xFFF87171)
