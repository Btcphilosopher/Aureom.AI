import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  initialIndicators,
  initialOrganisations,
  initialMaterialListings,
  initialMatches,
  initialTransactions,
  initialRepairProviders,
  initialMunicipalIndicators,
  initialInvestmentProjects,
  initialEnvironmentalFactors,
} from './src/data/initialSeedData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Memory store for backend API state
let indicators = [...initialIndicators];
let organisations = [...initialOrganisations];
let listings = [...initialMaterialListings];
let matches = [...initialMatches];
let transactions = [...initialTransactions];
let repairProviders = [...initialRepairProviders];
let municipalIndicators = [...initialMunicipalIndicators];
let investmentProjects = [...initialInvestmentProjects];
let environmentalFactors = [...initialEnvironmentalFactors];

// API v1 Endpoints

// GET /api/v1/dashboard/indicators
app.get('/api/v1/dashboard/indicators', (req, res) => {
  const { region, sector, category } = req.query;
  let result = [...indicators];
  
  if (region || sector || category) {
    // Return region/sector adjusted metrics
    result = result.map((ind) => {
      let multiplier = 1;
      if (region) multiplier *= 0.18;
      if (sector) multiplier *= 0.25;
      if (category) multiplier *= 0.15;
      
      const val = Math.round(ind.value * multiplier);
      return {
        ...ind,
        value: val,
        formattedValue: ind.unit === 'EUR' ? `€${(val / 1000000).toFixed(2)}M` : `${val.toLocaleString()} ${ind.unit === 'tonnes' ? 'τ.' : ''}`,
      };
    });
  }
  
  res.json(result);
});

// GET /api/v1/materials
app.get('/api/v1/materials', (req, res) => {
  const { type, category, region, query } = req.query;
  let filtered = [...listings];
  if (type) filtered = filtered.filter((l) => l.type === type);
  if (category) filtered = filtered.filter((l) => l.category === category);
  if (region) filtered = filtered.filter((l) => l.region === region);
  if (query) {
    const q = String(query).toLowerCase();
    filtered = filtered.filter(
      (l) =>
        l.titleEl.toLowerCase().includes(q) ||
        l.titleEn.toLowerCase().includes(q) ||
        l.classificationCode.toLowerCase().includes(q) ||
        l.locationName.toLowerCase().includes(q)
    );
  }
  res.json(filtered);
});

// POST /api/v1/materials
app.post('/api/v1/materials', (req, res) => {
  const newListing = {
    ...req.body,
    id: `mat_${Date.now()}`,
    createdAt: new Date().toISOString().split('T')[0],
  };
  listings.unshift(newListing);
  res.status(201).json(newListing);
});

// GET /api/v1/materials/:id
app.get('/api/v1/materials/:id', (req, res) => {
  const item = listings.find((l) => l.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Material listing not found' });
  res.json(item);
});

// POST /api/v1/materials/:id/enquiries
app.post('/api/v1/materials/:id/enquiries', (req, res) => {
  const item = listings.find((l) => l.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Material listing not found' });
  res.json({
    message: 'Enquiry received successfully',
    enquiryId: `enq_${Date.now()}`,
    listingId: item.id,
    timestamp: new Date().toISOString(),
  });
});

// GET /api/v1/repair-network
app.get('/api/v1/repair-network', (req, res) => {
  res.json(repairProviders);
});

// GET /api/v1/municipalities/indicators
app.get('/api/v1/municipalities/indicators', (req, res) => {
  res.json(municipalIndicators);
});

// GET /api/v1/investment/projects
app.get('/api/v1/investment/projects', (req, res) => {
  res.json(investmentProjects);
});

// GET /api/v1/organisations
app.get('/api/v1/organisations', (req, res) => {
  res.json(organisations);
});

// POST /api/v1/reports/generate
app.post('/api/v1/reports/generate', (req, res) => {
  const { reportType, period, language } = req.body;
  res.json({
    reportId: `KYKLOS-REP-${Date.now()}`,
    type: reportType || 'national_summary',
    period: period || '2026-YTD',
    language: language || 'el',
    generatedAt: new Date().toISOString(),
    downloadUrl: `/api/v1/reports/download/KYKLOS-REP-${Date.now()}.pdf`,
  });
});

// Vite Middleware for Dev, Static serving for Prod
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[KYKLOS SERVER] Listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
