/**
 * KYKLOS (ΚΥKLOS) - Frontend API & State Client
 */

import {
  IndicatorData,
  Organisation,
  MaterialListing,
  SymbiosisMatch,
  CircularTransaction,
  RepairServiceProvider,
  MunicipalIndicator,
  InvestmentProject,
  EnvironmentalFactor,
  EconomicAnalysisParams,
  EconomicAnalysisResult,
} from '../types';

import {
  initialIndicators,
  initialOrganisations,
  initialMaterialListings,
  initialMatches,
  initialTransactions,
  initialRepairProviders,
  initialMunicipalIndicators,
  initialInvestmentProjects,
  initialEnvironmentalFactors,
} from '../data/initialSeedData';

import { calculateEconomicAnalysis } from './economicsEngine';
import { findSymbiosisMatches } from './matchingEngine';

// Local storage keys or in-memory state fallback
class KyklosApiService {
  private indicators: IndicatorData[] = [...initialIndicators];
  private organisations: Organisation[] = [...initialOrganisations];
  private listings: MaterialListing[] = [...initialMaterialListings];
  private matches: SymbiosisMatch[] = [...initialMatches];
  private transactions: CircularTransaction[] = [...initialTransactions];
  private repairProviders: RepairServiceProvider[] = [...initialRepairProviders];
  private municipalIndicators: MunicipalIndicator[] = [...initialMunicipalIndicators];
  private investmentProjects: InvestmentProject[] = [...initialInvestmentProjects];
  private environmentalFactors: EnvironmentalFactor[] = [...initialEnvironmentalFactors];

  // Dashboard Indicators
  async getDashboardIndicators(region?: string, sector?: string, category?: string): Promise<IndicatorData[]> {
    try {
      const res = await fetch(`/api/v1/dashboard/indicators?region=${region || ''}&sector=${sector || ''}&category=${category || ''}`);
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // Fallback
    }
    return this.indicators;
  }

  // Material Listings
  async getMaterialListings(params?: {
    type?: 'supply' | 'demand';
    category?: string;
    region?: string;
    query?: string;
  }): Promise<MaterialListing[]> {
    try {
      const queryStr = new URLSearchParams(params as Record<string, string>).toString();
      const res = await fetch(`/api/v1/materials?${queryStr}`);
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // Fallback
    }

    let filtered = [...this.listings];
    if (params?.type) filtered = filtered.filter((l) => l.type === params.type);
    if (params?.category) filtered = filtered.filter((l) => l.category === params.category);
    if (params?.region) filtered = filtered.filter((l) => l.region === params.region);
    if (params?.query) {
      const q = params.query.toLowerCase();
      filtered = filtered.filter(
        (l) =>
          l.titleEl.toLowerCase().includes(q) ||
          l.titleEn.toLowerCase().includes(q) ||
          l.classificationCode.toLowerCase().includes(q) ||
          l.locationName.toLowerCase().includes(q) ||
          l.organisationName.toLowerCase().includes(q)
      );
    }
    return filtered;
  }

  async createMaterialListing(listing: Omit<MaterialListing, 'id' | 'createdAt'>): Promise<MaterialListing> {
    const newListing: MaterialListing = {
      ...listing,
      id: `mat_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };

    try {
      const res = await fetch('/api/v1/materials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newListing),
      });
      if (res.ok) {
        const saved = await res.json();
        this.listings.unshift(saved);
        this.recalculateIndicators();
        return saved;
      }
    } catch {
      // Fallback
    }

    this.listings.unshift(newListing);
    this.recalculateIndicators();
    return newListing;
  }

  // Symbiosis Matching
  async getSymbiosisMatches(maxDistanceKm: number = 200): Promise<SymbiosisMatch[]> {
    const supplies = this.listings.filter((l) => l.type === 'supply');
    const demands = this.listings.filter((l) => l.type === 'demand');
    const dynamicMatches = findSymbiosisMatches(supplies, demands, maxDistanceKm);
    
    // Combine seed matches with dynamic matches
    const all = [...this.matches];
    for (const dm of dynamicMatches) {
      if (!all.some((m) => m.id === dm.id)) {
        all.push(dm);
      }
    }
    return all.sort((a, b) => b.compatibilityScorePct - a.compatibilityScorePct);
  }

  // Transactions & Agreement Workflow
  async completeTransaction(matchId: string, agreedPriceEurPerTon?: number): Promise<CircularTransaction> {
    const match = this.matches.find((m) => m.id === matchId);
    if (!match) {
      throw new Error('Match not found');
    }

    const newTx: CircularTransaction = {
      id: `tx_${Date.now()}`,
      matchId: match.id,
      supplierOrgId: 'org_hellenic_metals',
      buyerOrgId: 'org_pelop_biogas',
      materialListingId: match.supplierListingId,
      materialTitle: `${match.supplierOrgName} → ${match.buyerOrgName}`,
      quantity: match.quantityMatched,
      unit: match.unit,
      agreedPricePerUnitEur: agreedPriceEurPerTon || 25,
      transportCostEur: match.transportCostEur,
      processingCostEur: match.processingCostEur,
      avoidedDisposalCostEur: match.quantityMatched * 45,
      avoidedVirginMaterialCostEur: match.quantityMatched * 80,
      netEconomicBenefitEur: match.netEconomicBenefitEur,
      co2eAvoidedTonnes: match.co2eAvoidedTonnes,
      waterSavedM3: match.quantityMatched * 2.5,
      landfillDivertedTonnes: match.landfillDivertedTonnes,
      region: 'peloponnese',
      completionDate: new Date().toISOString().split('T')[0],
      status: 'completed',
      verifiedByAudit: true,
    };

    match.status = 'completed';
    this.transactions.unshift(newTx);
    this.recalculateIndicators();
    return newTx;
  }

  // Economics Analysis
  async analyseEconomics(params: EconomicAnalysisParams): Promise<EconomicAnalysisResult> {
    return calculateEconomicAnalysis(params);
  }

  // Repair Network
  async getRepairProviders(region?: string, category?: string, query?: string): Promise<RepairServiceProvider[]> {
    let filtered = [...this.repairProviders];
    if (region) filtered = filtered.filter((r) => r.region === region);
    if (category) filtered = filtered.filter((r) => r.category === category);
    if (query) {
      const q = query.toLowerCase();
      filtered = filtered.filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          r.city.toLowerCase().includes(q) ||
          r.acceptedItemsEl.some((i) => i.toLowerCase().includes(q)) ||
          r.acceptedItemsEn.some((i) => i.toLowerCase().includes(q))
      );
    }
    return filtered;
  }

  // Municipal Data
  async getMunicipalIndicators(): Promise<MunicipalIndicator[]> {
    return this.municipalIndicators;
  }

  // Investment Projects
  async getInvestmentProjects(): Promise<InvestmentProject[]> {
    return this.investmentProjects;
  }

  // Environmental Factors
  async getEnvironmentalFactors(): Promise<EnvironmentalFactor[]> {
    return this.environmentalFactors;
  }

  // Transactions List
  async getTransactions(): Promise<CircularTransaction[]> {
    return this.transactions;
  }

  // Organisations List
  async getOrganisations(): Promise<Organisation[]> {
    return this.organisations;
  }

  // Internal indicator updater
  private recalculateIndicators() {
    const totalDiverted = this.transactions.reduce((acc, t) => acc + t.landfillDivertedTonnes, 0) + 90000;
    const totalValue = this.transactions.reduce((acc, t) => acc + (t.quantity * t.agreedPricePerUnitEur), 0) + 18000000;
    const totalMatches = this.matches.length + 1200;

    this.indicators = this.indicators.map((ind) => {
      if (ind.id === 'ind_01') {
        const activeSupplyQty = this.listings
          .filter((l) => l.type === 'supply' && l.status === 'active')
          .reduce((acc, l) => acc + l.quantity, 0);
        return {
          ...ind,
          value: activeSupplyQty,
          formattedValue: `${activeSupplyQty.toLocaleString()} τ.`,
        };
      }
      if (ind.id === 'ind_02') {
        return {
          ...ind,
          value: totalMatches,
          formattedValue: totalMatches.toLocaleString(),
        };
      }
      if (ind.id === 'ind_03') {
        return {
          ...ind,
          value: totalValue,
          formattedValue: `€${(totalValue / 1000000).toFixed(2)}M`,
        };
      }
      if (ind.id === 'ind_04') {
        return {
          ...ind,
          value: totalDiverted,
          formattedValue: `${totalDiverted.toLocaleString()} τ.`,
        };
      }
      return ind;
    });
  }
}

export const kyklosApi = new KyklosApiService();
