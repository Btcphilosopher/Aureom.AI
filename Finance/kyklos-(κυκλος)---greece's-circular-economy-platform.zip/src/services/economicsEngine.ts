/**
 * KYKLOS (ΚΥKLOS) - Circular Business Economics Engine
 * Formula: Net Economic Benefit =
 *   Avoided Disposal Cost + Avoided Virgin Material Cost + Additional Product Revenue
 *   - Collection & Transport Cost - Processing Cost - Testing & Certification Cost
 */

import { EconomicAnalysisParams, EconomicAnalysisResult } from '../types';

export function calculateEconomicAnalysis(params: EconomicAnalysisParams): EconomicAnalysisResult {
  const quantity = Math.max(0.1, params.quantityTonnes);
  
  // 1. Benefits (Positive cash flow)
  const avoidedDisposalTotalEur = quantity * Math.max(0, params.disposalFeeEurPerTon);
  const avoidedVirginMaterialTotalEur = quantity * Math.max(0, params.virginMaterialPriceEurPerTon) * (1 - Math.min(0.5, params.materialQualityDowngradePct / 100));
  const additionalProductRevenueEur = quantity * Math.max(0, params.askingPriceEurPerTon);
  
  // CO2 economic benefit (e.g., EU ETS carbon price savings)
  // Estimated 1.2 t CO2e avoided per tonne of average secondary material
  const estimatedCo2AvoidedTonnes = quantity * 1.2;
  const carbonBenefitTotalEur = estimatedCo2AvoidedTonnes * Math.max(0, params.carbonPriceEurPerTon);

  // 2. Costs (Negative cash flow)
  const adjustedTransportRate = params.transportRateEurPerTonKm * (1 + (params.fuelPriceOffset / 100));
  const collectionTransportCostTotalEur = quantity * params.transportDistanceKm * adjustedTransportRate;
  const processingCostTotalEur = quantity * Math.max(0, params.processingCostEurPerTon);
  const testingCertCostTotalEur = Math.max(0, params.testingCertificationEur);

  // 3. Totals
  const totalBenefits = avoidedDisposalTotalEur + avoidedVirginMaterialTotalEur + additionalProductRevenueEur + carbonBenefitTotalEur;
  const totalCosts = collectionTransportCostTotalEur + processingCostTotalEur + testingCertCostTotalEur;
  const netEconomicBenefitEur = totalBenefits - totalCosts;
  const unitNetBenefitEurPerTon = netEconomicBenefitEur / quantity;

  // Payback & ROI
  const capex = Math.max(0, params.capexInvestmentEur);
  const annualCashflow = netEconomicBenefitEur; // assuming 1 transaction batch = annual or baseline run
  const simplePaybackMonths = capex > 0 && annualCashflow > 0 ? (capex / annualCashflow) * 12 : 0;
  const roiPct = capex > 0 ? (annualCashflow / capex) * 100 : 0;

  // Breakdown array for visual UI chart
  const breakdown = [
    {
      labelEl: 'Αποφευχθέν Κόστος Διάθεσης / ΧΥΤΑ',
      labelEn: 'Avoided Disposal / Landfill Cost',
      valueEur: avoidedDisposalTotalEur,
      type: 'positive' as const,
    },
    {
      labelEl: 'Αποφευχθέν Κόστος Παρθένου Υλικού',
      labelEn: 'Avoided Virgin Material Purchase',
      valueEur: avoidedVirginMaterialTotalEur,
      type: 'positive' as const,
    },
    {
      labelEl: 'Έσοδα Πώλησης Δευτερογενούς Υλικού',
      labelEn: 'Secondary Material Sales Revenue',
      valueEur: additionalProductRevenueEur,
      type: 'positive' as const,
    },
    {
      labelEl: 'Οικονομική Αξία Αποφευχθεισών Εκπομπών Άνθρακα',
      labelEn: 'Avoided Carbon Allowance Value',
      valueEur: carbonBenefitTotalEur,
      type: 'positive' as const,
    },
    {
      labelEl: 'Κόστος Συλλογής & Μεταφοράς',
      labelEn: 'Collection & Transport Cost',
      valueEur: -collectionTransportCostTotalEur,
      type: 'negative' as const,
    },
    {
      labelEl: 'Κόστος Διαλογής & Επεξεργασίας',
      labelEn: 'Sorting & Processing Cost',
      valueEur: -processingCostTotalEur,
      type: 'negative' as const,
    },
    {
      labelEl: 'Κόστος Ελέγχου & Πιστοποίησης',
      labelEn: 'Testing & Certification Fee',
      valueEur: -testingCertCostTotalEur,
      type: 'negative' as const,
    },
  ];

  // Stress testing scenarios
  const sensitivityScenarios = [
    {
      scenarioEl: 'Βασικό Σενάριο (Baseline)',
      scenarioEn: 'Baseline Scenario',
      fuelPriceChangePct: 0,
      recoveredPriceChangePct: 0,
      netBenefitEur: netEconomicBenefitEur,
    },
    {
      scenarioEl: 'Αύξηση Καυσίμων +25% & Μείωση Τιμής Υλικού −15%',
      scenarioEn: 'Fuel +25% & Material Price −15%',
      fuelPriceChangePct: 25,
      recoveredPriceChangePct: -15,
      netBenefitEur:
        totalBenefits -
        (additionalProductRevenueEur * 0.15) -
        (collectionTransportCostTotalEur * 1.25) -
        processingCostTotalEur -
        testingCertCostTotalEur,
    },
    {
      scenarioEl: 'Αύξηση Τιμής Άνθρακα (€120/t CO₂) & Μείωση Μεταφορικού Κόστους −10%',
      scenarioEn: 'Carbon Price €120/t & Logistics −10%',
      fuelPriceChangePct: -10,
      recoveredPriceChangePct: 10,
      netBenefitEur:
        (totalBenefits + (estimatedCo2AvoidedTonnes * Math.max(0, 120 - params.carbonPriceEurPerTon))) -
        (collectionTransportCostTotalEur * 0.9) -
        processingCostTotalEur -
        testingCertCostTotalEur,
    },
  ];

  return {
    avoidedDisposalTotalEur,
    avoidedVirginMaterialTotalEur,
    additionalProductRevenueEur,
    collectionTransportCostTotalEur,
    processingCostTotalEur,
    testingCertCostTotalEur,
    carbonBenefitTotalEur,
    netEconomicBenefitEur,
    unitNetBenefitEurPerTon,
    simplePaybackMonths,
    roiPct,
    breakdown,
    sensitivityScenarios,
  };
}
