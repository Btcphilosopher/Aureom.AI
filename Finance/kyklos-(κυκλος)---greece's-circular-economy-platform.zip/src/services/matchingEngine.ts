/**
 * KYKLOS (ΚΥKLOS) - Industrial Symbiosis Matching Engine
 */

import { MaterialListing, SymbiosisMatch } from '../types';

// Haversine distance in km between two lat/lng coordinates
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

export function findSymbiosisMatches(
  supplies: MaterialListing[],
  demands: MaterialListing[],
  maxDistanceKm: number = 250
): SymbiosisMatch[] {
  const matches: SymbiosisMatch[] = [];

  for (const supply of supplies) {
    if (supply.type !== 'supply' || supply.status !== 'active') continue;

    for (const demand of demands) {
      if (demand.type !== 'demand' || demand.status !== 'active') continue;

      // 1. Category check
      if (supply.category !== demand.category) continue;

      // 2. Geographic distance
      const distanceKm = calculateDistanceKm(
        supply.coordinates[0],
        supply.coordinates[1],
        demand.coordinates[0],
        demand.coordinates[1]
      );

      if (distanceKm > maxDistanceKm) continue;

      // 3. Compatibility Scoring
      let score = 50; // baseline for category match
      const matchReasonsEl: string[] = [];
      const matchReasonsEn: string[] = [];
      const feasibilityEl: string[] = [];
      const feasibilityEn: string[] = [];

      // EWC classification code match
      if (supply.classificationCode === demand.classificationCode) {
        score += 20;
        matchReasonsEl.push('Πλήρης ταύτιση κωδικού ταξινόμησης αποβλήτων/υλικού (EWC Code).');
        matchReasonsEn.push('Exact match on European Waste Catalogue (EWC) classification code.');
      } else {
        matchReasonsEl.push('Συμβατή κατηγορία υλικού με παραπλήσια τεχνικά χαρακτηριστικά.');
        matchReasonsEn.push('Compatible material family with aligned technical properties.');
      }

      // Quantity overlap
      const matchedQty = Math.min(supply.quantity, demand.quantity);
      if (matchedQty >= demand.minOrderQuantity) {
        score += 15;
        matchReasonsEl.push(`Ικανοποιητική κάλυψη ποσότητας (${matchedQty} ${supply.unit}).`);
        matchReasonsEn.push(`Sufficient volume match (${matchedQty} ${supply.unit}).`);
      } else {
        feasibilityEl.push('Η διαθέσιμη ποσότητα είναι μικρότερη από την ελάχιστη παραγγελία.');
        feasibilityEn.push('Available supply volume is below the requested minimum batch size.');
      }

      // Distance score bonus
      if (distanceKm <= 50) {
        score += 15;
        matchReasonsEl.push(`Άμεση τοπική εγγύτητα (${distanceKm} km). Χαμηλό περιβαλλοντικό και μεταφορικό αποτύπωμα.`);
        matchReasonsEn.push(`Close geographic proximity (${distanceKm} km). Low transport emissions.`);
      } else if (distanceKm <= 120) {
        score += 10;
        matchReasonsEl.push(`Περιφερειακή εγγύτητα (${distanceKm} km).`);
        matchReasonsEn.push(`Regional proximity (${distanceKm} km).`);
      } else {
        feasibilityEl.push(`Αυξημένο μεταφορικό κόστος λόγω απόστασης (${distanceKm} km).`);
        feasibilityEn.push(`Higher logistics cost due to extended transport distance (${distanceKm} km).`);
      }

      // Regulatory certification
      if (supply.endOfWasteCertified) {
        score += 10;
        matchReasonsEl.push('Πιστοποιημένο καθεστώς End-of-Waste (Αποβληθέν Υλικό).');
        matchReasonsEn.push('Certified End-of-Waste regulatory status.');
      } else {
        feasibilityEl.push('Απαιτείται περιβαλλοντική αδειοδότηση για τη διακίνηση του υλικού.');
        feasibilityEn.push('Environmental permit validation required for waste transport.');
      }

      // Safety docs
      if (supply.safetyDocsAvailable) {
        matchReasonsEl.push('Διαθέσιμα πλήρη δελτία δεδομένων ασφαλείας (SDS).');
        matchReasonsEn.push('Complete Safety Data Sheets (SDS) available.');
      }

      const finalScore = Math.min(99, Math.max(30, score));

      // Financials
      const transportCostEur = Math.round(matchedQty * distanceKm * 0.12); // 0.12 €/t-km
      const processingCostEur = Math.round(matchedQty * 3.5); // €3.5/t
      const avoidedDisposalEur = Math.round(matchedQty * 45); // €45/t disposal fee
      const avoidedVirginEur = Math.round(matchedQty * (demand.askingPricePerUnit || 80));
      const netEconomicBenefitEur = Math.round(avoidedDisposalEur + avoidedVirginEur - transportCostEur - processingCostEur);
      const co2eAvoidedTonnes = Math.round(matchedQty * 0.85);

      matches.push({
        id: `match_auto_${supply.id}_${demand.id}`,
        supplierListingId: supply.id,
        buyerListingId: demand.id,
        supplierOrgName: supply.organisationName,
        buyerOrgName: demand.organisationName,
        materialCategory: supply.category,
        quantityMatched: matchedQty,
        unit: supply.unit,
        compatibilityScorePct: finalScore,
        distanceKm,
        transportCostEur,
        processingCostEur,
        netEconomicBenefitEur,
        co2eAvoidedTonnes,
        landfillDivertedTonnes: matchedQty,
        matchReasons: {
          el: matchReasonsEl,
          en: matchReasonsEn,
        },
        feasibilityConstraints: {
          el: feasibilityEl.length > 0 ? feasibilityEl : ['Δεν εντοπίστηκαν σοβαρά τεχνικά εμπόδια.'],
          en: feasibilityEn.length > 0 ? feasibilityEn : ['No critical technical constraints identified.'],
        },
        status: 'recommended',
        createdAt: new Date().toISOString().split('T')[0],
      });
    }
  }

  return matches.sort((a, b) => b.compatibilityScorePct - a.compatibilityScorePct);
}
