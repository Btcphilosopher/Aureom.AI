/**
 * KYKLOS (ΚΥΚΛΟΣ) - Greece's National Circular Economy Platform
 * Root Component
 */

import React, { useState } from 'react';
import { Language, UserRole } from './types';
import { translations } from './i18n/translations';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { DashboardView } from './components/DashboardView';
import { MaterialsExchangeView } from './components/MaterialsExchangeView';
import { IndustrialSymbiosisView } from './components/IndustrialSymbiosisView';
import { EconomicsView } from './components/EconomicsView';
import { SectorAgricultureView } from './components/SectorAgricultureView';
import { SectorConstructionView } from './components/SectorConstructionView';
import { SectorEnergyWaterView } from './components/SectorEnergyWaterView';
import { RepairNetworkView } from './components/RepairNetworkView';
import { MunicipalConsoleView } from './components/MunicipalConsoleView';
import { InvestmentHubView } from './components/InvestmentHubView';
import { EnvironmentalImpactView } from './components/EnvironmentalImpactView';
import { ReportsView } from './components/ReportsView';

export default function App() {
  const [lang, setLang] = useState<Language>('el');
  const [userRole, setUserRole] = useState<UserRole>('business_user');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isOpenCreateModal, setIsOpenCreateModal] = useState<boolean>(false);

  const t = translations[lang];

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#1E293B] flex flex-col font-sans selection:bg-[#0F2B48] selection:text-white">
      
      {/* 1. Top Header Bar (3 Zone Contract) */}
      <Header
        lang={lang}
        onLanguageChange={setLang}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        userRole={userRole}
        onRoleChange={setUserRole}
        onOpenCreateListing={() => setIsOpenCreateModal(true)}
      />

      {/* 2. Sub-Navigation Workspace Toolbar */}
      <Navigation
        lang={lang}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      {/* 3. Main Viewport Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'dashboard' && (
          <DashboardView lang={lang} onNavigateToTab={setActiveTab} />
        )}

        {activeTab === 'materialsExchange' && (
          <MaterialsExchangeView
            lang={lang}
            isOpenCreateModal={isOpenCreateModal}
            onCloseCreateModal={() => setIsOpenCreateModal(false)}
            onOpenCreateModal={() => setIsOpenCreateModal(true)}
          />
        )}

        {activeTab === 'symbiosis' && (
          <IndustrialSymbiosisView
            lang={lang}
            onTransactionCompleted={() => {
              // Smooth refresh or indicator sync
            }}
          />
        )}

        {activeTab === 'economics' && <EconomicsView lang={lang} />}

        {activeTab === 'sectorAgriculture' && <SectorAgricultureView lang={lang} />}

        {activeTab === 'sectorConstruction' && <SectorConstructionView lang={lang} />}

        {activeTab === 'sectorEnergyWater' && <SectorEnergyWaterView lang={lang} />}

        {activeTab === 'repairNetwork' && <RepairNetworkView lang={lang} />}

        {activeTab === 'municipalities' && <MunicipalConsoleView lang={lang} />}

        {activeTab === 'investments' && <InvestmentHubView lang={lang} />}

        {activeTab === 'environmental' && <EnvironmentalImpactView lang={lang} />}

        {activeTab === 'reports' && <ReportsView lang={lang} />}
      </main>

      {/* 4. Footer */}
      <footer className="mt-auto bg-[#0F2B48] text-slate-300 border-t border-[#1A3E61] py-8 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-5 h-5 rounded-full border border-amber-400 flex items-center justify-center p-0.5">
              <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            </div>
            <div>
              <span className="font-bold text-white tracking-wide">KYKLOS (ΚΥΚΛΟΣ)</span>
              <span className="text-slate-400 ml-2">— {t.tagline}</span>
            </div>
          </div>

          <div className="text-slate-400 text-[11px]">
            © {new Date().getFullYear()} KYKLOS Platform · Greece's Circular Economy Platform. All rights reserved.
          </div>
        </div>
      </footer>

    </div>
  );
}
