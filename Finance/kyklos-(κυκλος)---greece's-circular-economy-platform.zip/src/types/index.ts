/**
 * KYKLOS (ΚΥΚΛΟΣ) - Core Data Types & Schemas
 */

export type Language = 'el' | 'en';

export type UserRole =
  | 'citizen'
  | 'business_user'
  | 'supplier'
  | 'buyer'
  | 'recycler'
  | 'municipality_officer'
  | 'project_developer'
  | 'analyst'
  | 'admin';

export type GreekRegion =
  | 'attica'
  | 'central_macedonia'
  | 'thessaly'
  | 'peloponnese'
  | 'western_greece'
  | 'central_greece'
  | 'eastern_macedonia_thrace'
  | 'western_macedonia'
  | 'epirus'
  | 'crete'
  | 'south_aegean'
  | 'north_aegean'
  | 'ionian_islands';

export type Sector =
  | 'manufacturing'
  | 'agriculture_food'
  | 'construction_demolition'
  | 'utilities_water_energy'
  | 'waste_recycling'
  | 'logistics_transport'
  | 'municipalities'
  | 'retail_repair';

export type DataVerificationStatus = 'verified' | 'user_reported' | 'modeled' | 'unverified';

export type MaterialCategory =
  | 'metals_alloys'
  | 'paper_cardboard'
  | 'glass'
  | 'plastics_polymers'
  | 'wood_timber'
  | 'construction_demolition'
  | 'textile_fibres'
  | 'agricultural_residues'
  | 'food_processing_byproducts'
  | 'industrial_minerals'
  | 'reusable_components'
  | 'waste_heat_energy'
  | 'reclaimed_water';

export interface Organisation {
  id: string;
  name: string;
  vatNumber: string; // ΑΦΜ
  region: GreekRegion;
  municipality: string;
  sector: Sector;
  type: 'enterprise' | 'sme' | 'cooperative' | 'municipality' | 'utility' | 'research';
  address: string;
  coordinates: [number, number]; // [lat, lng]
  verified: boolean;
  contactEmail: string;
  contactPhone: string;
  createdAt: string;
}

export interface MaterialListing {
  id: string;
  titleEl: string;
  titleEn: string;
  organisationId: string;
  organisationName: string;
  type: 'supply' | 'demand';
  category: MaterialCategory;
  classificationCode: string; // EWC / LoW code
  quantity: number;
  unit: 'tonnes' | 'kg' | 'm3' | 'litres' | 'kWh' | 'units';
  qualityGrade: 'A_premium' | 'B_standard' | 'C_raw' | 'D_mixed';
  compositionSpec?: string;
  physicalCondition: string;
  region: GreekRegion;
  locationName: string;
  coordinates: [number, number];
  availabilityWindow: {
    start: string;
    end: string;
    recurring: boolean;
  };
  minOrderQuantity: number;
  askingPricePerUnit: number; // in €
  isNegotiable: boolean;
  packagingRequirements: string;
  storageConditions: string;
  transportRequirements: string;
  safetyDocsAvailable: boolean;
  regulatoryClassification: 'waste' | 'by_product' | 'end_of_waste' | 'reusable_product';
  endOfWasteCertified: boolean;
  verificationStatus: DataVerificationStatus;
  descriptionEl: string;
  descriptionEn: string;
  moistureContentPct?: number;
  temperatureCelsius?: number;
  status: 'active' | 'matched' | 'completed' | 'draft';
  createdAt: string;
}

export interface SymbiosisMatch {
  id: string;
  supplierListingId: string;
  buyerListingId: string;
  supplierOrgName: string;
  buyerOrgName: string;
  materialCategory: MaterialCategory;
  quantityMatched: number;
  unit: string;
  compatibilityScorePct: number; // 0-100%
  distanceKm: number;
  transportCostEur: number;
  processingCostEur: number;
  netEconomicBenefitEur: number;
  co2eAvoidedTonnes: number;
  landfillDivertedTonnes: number;
  matchReasons: {
    el: string[];
    en: string[];
  };
  feasibilityConstraints: {
    el: string[];
    en: string[];
  };
  status: 'recommended' | 'enquired' | 'negotiating' | 'agreed' | 'completed';
  createdAt: string;
}

export interface CircularTransaction {
  id: string;
  matchId?: string;
  supplierOrgId: string;
  buyerOrgId: string;
  materialListingId: string;
  materialTitle: string;
  quantity: number;
  unit: string;
  agreedPricePerUnitEur: number;
  transportCostEur: number;
  processingCostEur: number;
  avoidedDisposalCostEur: number;
  avoidedVirginMaterialCostEur: number;
  netEconomicBenefitEur: number;
  co2eAvoidedTonnes: number;
  waterSavedM3: number;
  landfillDivertedTonnes: number;
  region: GreekRegion;
  completionDate: string;
  status: 'completed' | 'in_transit' | 'pending';
  verifiedByAudit: boolean;
}

export interface EconomicAnalysisParams {
  quantityTonnes: number;
  askingPriceEurPerTon: number;
  virginMaterialPriceEurPerTon: number;
  disposalFeeEurPerTon: number;
  transportDistanceKm: number;
  transportRateEurPerTonKm: number; // e.g. 0.12 €/t-km
  processingCostEurPerTon: number;
  testingCertificationEur: number;
  capexInvestmentEur: number;
  carbonPriceEurPerTon: number; // e.g. 85 €/t CO2
  fuelPriceOffset: number; // e.g. 0% or +25%
  materialQualityDowngradePct: number; // 0-50%
}

export interface EconomicAnalysisResult {
  avoidedDisposalTotalEur: number;
  avoidedVirginMaterialTotalEur: number;
  additionalProductRevenueEur: number;
  collectionTransportCostTotalEur: number;
  processingCostTotalEur: number;
  testingCertCostTotalEur: number;
  carbonBenefitTotalEur: number;
  netEconomicBenefitEur: number;
  unitNetBenefitEurPerTon: number;
  simplePaybackMonths: number;
  roiPct: number;
  breakdown: {
    labelEl: string;
    labelEn: string;
    valueEur: number;
    type: 'positive' | 'negative';
  }[];
  sensitivityScenarios: {
    scenarioEl: string;
    scenarioEn: string;
    fuelPriceChangePct: number;
    recoveredPriceChangePct: number;
    netBenefitEur: number;
  }[];
}

export interface EnvironmentalFactor {
  id: string;
  materialCategory: MaterialCategory;
  functionalUnit: string; // e.g., "1 tonne of secondary aluminum"
  virginEmissionFactorKgCo2e: number;
  secondaryEmissionFactorKgCo2e: number;
  netAvoidedCo2ePerUnit: number;
  waterSavingsM3PerUnit: number;
  energySavingsKwhPerUnit: number;
  landfillAvoidanceTonnesPerUnit: number;
  sourceName: string;
  sourceYear: number;
  systemBoundary: 'cradle_to_gate' | 'gate_to_gate' | 'cradle_to_grave';
  uncertaintyPct: number;
}

export interface RepairServiceProvider {
  id: string;
  name: string;
  category: 'electronics' | 'clothing_textiles' | 'furniture' | 'machinery' | 'appliances' | 'bicycles' | 'remanufacturing';
  region: GreekRegion;
  city: string;
  address: string;
  phone: string;
  email: string;
  website?: string;
  acceptedItemsEl: string[];
  acceptedItemsEn: string[];
  verificationStatus: DataVerificationStatus;
  lastVerifiedDate: string;
  rating: number;
  coordinates: [number, number];
}

export interface MunicipalIndicator {
  municipalityId: string;
  municipalityNameEl: string;
  municipalityNameEn: string;
  region: GreekRegion;
  population: number;
  totalSolidWasteTonnesYear: number;
  recyclingRatePct: number;
  diversionFromLandfillTonnes: number;
  foodWasteCollectedTonnes: number;
  reuseCentersCount: number;
  activeTendersCount: number;
  publicProcurementCircularProjects: number;
  lastReportPeriod: string;
}

export interface InvestmentProject {
  id: string;
  titleEl: string;
  titleEn: string;
  sponsorName: string;
  region: GreekRegion;
  municipality: string;
  category: 'materials_recovery' | 'bio_refinery' | 'waste_heat' | 'recycled_aggregates' | 'water_reuse' | 'battery_recycling';
  technologyDescriptionEl: string;
  technologyDescriptionEn: string;
  capexTotalEur: number;
  opexAnnualEur: number;
  capacityPerYear: string;
  fundingRequiredEur: number;
  projectedIrrPct: number;
  paybackYears: number;
  co2eAvoidedPerYearTonnes: number;
  permittingStage: 'concept' | 'feasibility' | 'permitting_in_progress' | 'permitted' | 'shovel_ready';
  developmentStage: 'early_stage' | 'mid_stage' | 'ready_for_construction';
  contactPerson: string;
  contactEmail: string;
}

export interface IndicatorData {
  id: string;
  labelEl: string;
  labelEn: string;
  value: number;
  unit: string;
  formattedValue: string;
  trendPct: number; // e.g. +14.2%
  timePeriod: string;
  dataOrigin: DataVerificationStatus;
  definitionEl: string;
  definitionEn: string;
  calculationMethodEl: string;
  calculationMethodEn: string;
}
