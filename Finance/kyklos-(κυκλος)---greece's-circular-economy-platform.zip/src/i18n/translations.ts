/**
 * KYKLOS (ΚΥΚΛΟΣ) - Bilingual Translation Dictionary
 * Greek (EL - Primary) & English (EN - Secondary)
 */

export const translations = {
  el: {
    // Brand & General
    appName: 'KYKLOS',
    appFullName: 'ΚΥΚΛΟΣ — Εθνική Πλατφόρμα Κυκλικής Οικονομίας',
    tagline: 'Από τους πόρους στην αξία.',
    subTagline: 'Διασύνδεση της φυσικής οικονομίας της Ελλάδας για παραγωγική αξιοποίηση πόρων.',
    language: 'Γλώσσα',
    greek: 'Ελληνικά',
    english: 'English',
    role: 'Ρόλος Χρήστη',
    organisation: 'Οργανισμός',
    
    // Top Bar & Navigation
    nav: {
      dashboard: 'Εθνικός Πίνακας',
      materialsExchange: 'Αγορά Υλικών',
      symbiosis: 'Βιομηχανική Συμβίωση',
      economics: 'Οικονομική Ανάλυση',
      sectors: 'Τομεακές Εφαρμογές',
      repairNetwork: 'Δίκτυο Επισκευών',
      municipalities: 'Δήμοι & Περιφέρειες',
      investments: 'Επενδύσεις',
      environmental: 'Περιβαλλοντικό Αποτύπωμα',
      reports: 'Αναφορές',
    },

    // Sectors Submenu
    sectorsMenu: {
      agriculture: 'Γεωργία & Βιοοικονομία',
      construction: 'Κατασκευές & Κτίρια',
      energyWater: 'Ενέργεια & Νερό',
    },

    // Verification Status Badges
    verification: {
      verified: 'Επαληθευμένα Δεδομένα',
      userReported: 'Δηλωθέντα από Χρήστη',
      modeled: 'Μοντελοποιημένες Εκτιμήσεις',
      unverified: 'Μη Επαληθευμένα',
      provenanceTitle: 'Προέλευση & Μεθοδολογία Δεδομένων',
    },

    // Dashboard View
    dashboard: {
      title: 'Εθνικός Πίνακας Δεικτών Κυκλικής Οικονομίας',
      subtitle: 'Δεδομένα σε πραγματικό χρόνο για τη διακίνηση δευτερογενών υλικών και την ανάκτηση πόρων στην Ελλάδα.',
      filterRegion: 'Περιφέρεια',
      filterSector: 'Τομέας Οικονομίας',
      filterCategory: 'Κατηγορία Υλικού',
      allRegions: 'Όλες οι Περιφέρειες (Ελλάδα)',
      allSectors: 'Όλοι οι Τομείς',
      allCategories: 'Όλες οι Κατηγορίες',
      indicatorsHeading: 'Κύριοι Λειτουργικοί Δείκτες',
      mapHeading: 'Γεωγραφική Κατανεμημένη Δραστηριότητα & Βιομηχανικά Σύμπλεγματα',
      recentTransactions: 'Πρόσφατες Ολοκληρωμένες Συναλλαγές Υλικών',
      dataNote: 'Κάθε δείκτης συνοδεύεται από ορισμό, μονάδα μέτρησης, περίοδο αναφοράς και μεθοδολογία υπολογισμού.',
      kpis: {
        materialsAvailable: 'Διαθέσιμα Υλικά προς Επανάχρηση',
        materialsMatched: 'Επιτυχείς Συζεύξεις Υλικών',
        recoveredValue: 'Εκτιμώμενη Αξία Ανακτημένων Υλικών',
        landfillDiverted: 'Ποσότητα που Αποτράπηκε από Ταφή',
        symbiosisExchanges: 'Ανταλλαγές Βιομηχανικής Συμβίωσης',
        wasteHeatWater: 'Έργα Ανάκτησης Θερμότητας & Νερού',
        circularConstruction: 'Ανακυκλωμένα Κατασκευαστικά Υλικά',
        netEconomicSavings: 'Δυνητικές Οικονομικές Αποταμιεύσεις',
        co2eAvoided: 'Αποφευχθείσες Εκπομπές CO₂e',
      },
    },

    // Materials Exchange Marketplace
    materialsExchange: {
      title: 'Κεντρική Αγορά Δευτερογενών Υλικών & Υποπροϊόντων',
      subtitle: 'B2B πλατφόρμα καταχώρησης, αναζήτησης και συναλλαγής βιομηχανικών υλικών.',
      createListing: 'Νέα Καταχώρηση Υλικού',
      searchPlaceholder: 'Αναζήτηση υλικού, κωδικού EWC, ποιότητας ή τοποθεσίας...',
      tabSupply: 'Διαθέσιμα Υλικά (Προσφορά)',
      tabDemand: 'Ζητούμενα Υλικά (Ζήτηση)',
      listingDetails: 'Τεχνικές Προδιαγραφές Υλικού',
      regulatoryClassification: 'Ρυθμιστικό Καθεστώς',
      endOfWaste: 'Χαρακτηρισμός ως Αποβληθέν Υλικό (End-of-Waste)',
      qualityGrade: 'Βαθμός Ποιότητας',
      availabilityWindow: 'Παράθυρο Διαθεσιμότητας',
      minOrder: 'Ελάχιστη Παραγγελία',
      askingPrice: 'Τιμή Αξίωσης',
      negotiable: 'Διαπραγματεύσιμη',
      location: 'Τοποθεσία & Περιφέρεια',
      safetyDocs: 'Δελτία Ασφαλείας (SDS/MSDS)',
      sendEnquiry: 'Αποστολή Εκδήλωσης Ενδιαφέροντος',
      enquirySuccess: 'Η εκδήλωση ενδιαφέροντος απεστάλη επιτυχώς στον κάτοχο του υλικού.',
      categories: {
        metals_alloys: 'Μέταλλα & Κράματα',
        paper_cardboard: 'Χαρτί & Χαρτόνι',
        glass: 'Γυαλί',
        plastics_polymers: 'Πλάστικα & Πολυμερή',
        wood_timber: 'Ξυλεία & Ξύλινα Στοιχεία',
        construction_demolition: 'Δομικά & Αποβλήτα Κατασκευών (ΑΕΚΚ)',
        textile_fibres: 'Κλωστοϋφαντουργικές Ίνες',
        agricultural_residues: 'Γεωργικά Υπολείμματα',
        food_processing_byproducts: 'Υποπροϊόντα Βιομηχανίας Τροφίμων',
        industrial_minerals: 'Βιομηχανικά Ορυκτά',
        reusable_components: 'Επαναχρησιμοποιήσιμα Εξαρτήματα',
        waste_heat_energy: 'Αποβληθείσα Θερμότητα & Ενέργεια',
        reclaimed_water: 'Ανακτημένο Νερό',
      },
    },

    // Industrial Symbiosis Engine
    symbiosis: {
      title: 'Μηχανή Βιομηχανικής Συμβίωσης (Industrial Symbiosis)',
      subtitle: 'Αυτόματος αλγόριθμος εντοπισμού συμβατών ροών πόρων μεταξύ βιομηχανικών μονάδων.',
      matchScore: 'Δείκτης Συμβατότητας',
      runMatching: 'Εκτέλεση Αλγορίθμου Συζεύξεων',
      filterDistance: 'Μέγιστη Απόσταση Transport (km)',
      supplierFacility: 'Μονάδα Προμηθευτή',
      buyerFacility: 'Μονάδα Παραλήπτη',
      distance: 'Γεωγραφική Απόσταση',
      transportCost: 'Εκτιμώμενο Κόστος Μεταφοράς',
      netBenefit: 'Καθαρό Οικονομικό Όφελος',
      co2Saved: 'Αποφυγή Εκπομπών',
      whyRecommended: 'Αιτιολογία Σύστασης Σύζευξης',
      feasibilityCheck: 'Έλεγχος Τεχνικής & Ρυθμιστικής Εφικτότητας',
      initiateExchange: 'Έναρξη Συναλλαγής',
    },

    // Economic Analysis Engine
    economics: {
      title: 'Μηχανή Οικονομικής Αξιολόγησης Κυκλικών Συναλλαγών',
      subtitle: 'Ποσοτικός υπολογισμός εμπορικής βιωσιμότητας, κόστους μεταφοράς και ανάλυση ευαισθησίας.',
      calculatorTitle: 'Παράμετροι Υπολογισμού',
      resultsTitle: 'Ανάλυση Καθαρού Οικονομικού Οφέλους (Net Economic Benefit)',
      sensitivityTitle: 'Ανάλυση Ευαισθησίας & Σενάρια Πίεσης (Stress Testing)',
      avoidedDisposal: 'Αποφευχθέν Κόστος Υγειονομικής Ταφής/Διάθεσης',
      avoidedVirgin: 'Αποφευχθέν Κόστος Αγοράς Παρθένου Υλικού',
      productRevenue: 'Έσοδα από Πώληση Ανακτημένου Υλικού',
      collectionTransport: 'Κόστος Συλλογής & Μεταφοράς (€/t-km)',
      processingCost: 'Κόστος Διαλογής & Επεξεργασίας',
      testingCert: 'Κόστος Ελέγχου & Πιστοποίησης',
      carbonBenefit: 'Οικονομική Αξία Αποφευχθεισών Εκπομπών Άνθρακα',
      netBenefitResult: 'Καθαρό Οικονομικό Όφελος Συναλλαγής',
      paybackPeriod: 'Περίοδος Αποπληρωμής CapEx',
      roi: 'Απόδοση Επένδυσης (ROI)',
      sliders: {
        quantity: 'Ποσότητα Υλικού (Τόνοι)',
        askingPrice: 'Τιμή Αγοράς Δευτερογενούς (€/t)',
        virginPrice: 'Τιμή Παρθένου Υλικού (€/t)',
        disposalFee: 'Τέλος Ταφής/Διάθεσης (€/t)',
        distance: 'Απόσταση Μεταφοράς (km)',
        fuelPriceOffset: 'Μεταβολή Τιμής Καυσίμων (%)',
        carbonPrice: 'Τιμή Δικαιωμάτων Άνθρακα (€/t CO₂)',
        qualityDowngrade: 'Υποβάθμιση Ποιότητας Υλικού (%)',
      },
    },

    // Agriculture Module
    agriculture: {
      title: 'Γεωργία & Βιοοικονομία (Greek Bioeconomy)',
      subtitle: 'Διαχείριση αγροτικών υπολειμμάτων, ελαιοουργικών αποβλήτων (κατσιγάρος, πυρήνας) και οινοποιίας.',
      residueType: 'Τύπος Αγροτικού Υπολείμματος',
      moistureContent: 'Περιεκτικότητα σε Υγρασία (%)',
      seasonality: 'Εποχικό Παράθυρο Συλλογής',
      biomassOpportunity: 'Ευκαιρίες Παραγωγής Βιοενέργειας & Εδαφοβελτιωτικών',
      safetyWarning: 'Προσοχή: Απαιτείται υγειονομική και περιβαλλοντική πιστοποίηση για χρήση σε ζωοτροφές ή λιπάσματα.',
    },

    // Construction Module
    construction: {
      title: 'Κυκλικές Κατασκευές & Διαβατήρια Υλικών Κτιρίων',
      subtitle: 'Διαχείριση ΑΕΚΚ, επανάχρηση δομικής ξυλείας, χάλυβα, ανακυκλωμένων αδρανών και stone masonry.',
      buildingPassport: 'Διαβατήριο Υλικών Κτιρίου (Material Passport)',
      structuralGrade: 'Δομική Καταλληλότητα & Πιστοποίηση',
      chainOfCustody: 'Αλυσίδα Αποδεικτικών Στοιχείων (Chain of Custody)',
      testingNotice: 'Τα ανακτημένα υλικά απαιτούν εργαστηριακό έλεγχο αντοχής πριν τη δομική τους χρήση.',
    },

    // Energy & Water Module
    energyWater: {
      title: 'Ανάκτηση Ενέργειας & Ανακτημένο Νερό',
      subtitle: 'Αξιοποίηση αποβληθείσας θερμότητας (Waste Heat), βιομηχανικών λυμάτων και ανακύκλωση μπαταριών.',
      thermalPower: 'Θερμική Ισχύς (kW / MWh)',
      temperature: 'Θερμοκρασία Ροής (°C)',
      heatExchangerNeeds: 'Απαιτήσεις Εναλλάκτη Θερμότητας',
      reclaimedWaterQuality: 'Ποιότητα Ανακτημένου Νερού (ISO 16075)',
    },

    // Repair Network
    repairNetwork: {
      title: 'Δίκτυο Επισκευής, Ανακατασκευής & Επανάχρησης',
      subtitle: 'Πιστοποιημένα εργαστήρια επισκευών, κέντρα ανακατασκευής και σημεία επανάχρησης στην Ελλάδα.',
      searchWorkshop: 'Αναζήτηση επισκευαστή ανά πόλη ή είδος εξοπλισμού...',
      calculatorTitle: 'Υπολογιστής: Επισκευή vs. Αντικατάσταση',
      repairCost: 'Κόστος Επισκευής (€)',
      newProductCost: 'Κόστος Αγοράς Νέου Προϊόντος (€)',
      lifespanExtension: 'Επέκταση Διάρκειας Ζωής (Έτη)',
      savingsCalculated: 'Καθαρό Οικονομικό Όφελος Επισκευής',
      co2Calculated: 'Αποφευχθείσα Επιβάρυνση Κατασκευής Νέου',
    },

    // Municipal Console
    municipalities: {
      title: 'Κονσόλα Κυκλικής Οικονομίας Δήμων & Περιφερειών',
      subtitle: 'Παρακολούθηση δημοτικών ροών υλικών, πράσινων σημείων, κέντρων επανάχρησης και δημόσιων συμβάσεων.',
      selectMunicipality: 'Επιλογή Δήμου',
      recyclingRate: 'Ποσοστό Ανακύκλωσης Δήμου',
      landfillDiverted: 'Ετήσια Εκτροπή από ΧΥΤΑ (Τόνοι)',
      foodWasteCollection: 'Συλλογή Οργανικών/Καφέ Κάδων',
      publicProcurement: 'Πράσινες Δημόσιες Συμβάσεις (GPP)',
      createTender: 'Δημοσίευση Πρόσκλησης Εκδήλωσης Ενδιαφέροντος Υλικών',
    },

    // Investments Hub
    investments: {
      title: 'Επενδυτικά Έργα & Χρηματοδότηση Κυκλικής Υποδομής',
      subtitle: 'Τράπεζα ώριμων επενδυτικών σχεδίων κυκλικής οικονομίας στην Ελλάδα.',
      capex: 'Απαιτούμενο CapEx (€)',
      irr: 'Προβλεπόμενο IRR (%)',
      payback: 'Περίοδος Αποπληρωμής',
      permittingStage: 'Στάδιο Αδειοδότησης',
      contactSponsor: 'Επικοινωνία με Φορέα Υλοποίησης',
      disclaimer: 'Σημείωση: Οι υπολογισμοί αποτελούν ενδεικτική ανάλυση και όχι επενδυτική συμβουλή.',
    },

    // Environmental Impact Accounting
    environmental: {
      title: 'Περιβαλλοντική Λογιστική & Μεθοδολογία LCA',
      subtitle: 'Διαφανής υπολογισμός αποφευχθεισών εκπομπών, εξοικονόμησης νερού και πόρων.',
      functionalUnit: 'Λειτουργική Μονάδα (Functional Unit)',
      baselineScenario: 'Σενάριο Βάσης (Baseline)',
      emissionFactor: 'Συντελεστής Εκπομπών (Kg CO₂e/unit)',
      systemBoundary: 'Όρια Συστήματος (Cradle-to-Gate)',
      grossVsNet: 'Μεικτές vs Καθαρές Αποφευχθείσες Εκπομπές',
    },

    // Common Actions
    actions: {
      save: 'Αποθήκευση',
      cancel: 'Ακύρωση',
      filter: 'Φιλτράρισμα',
      reset: 'Επαναφορά',
      downloadCsv: 'Εξαγωγή CSV',
      exportReport: 'Εξαγωγή Αναφοράς PDF',
      close: 'Κλείσιμο',
      viewDetails: 'Προβολή Λεπτομερειών',
      contact: 'Επικοινωνία',
      submit: 'Υποβολή',
    },
  },

  en: {
    // Brand & General
    appName: 'KYKLOS',
    appFullName: "KYKLOS — Greece's National Circular Economy Platform",
    tagline: 'From resources to value.',
    subTagline: "Interconnecting Greece's physical economy for productive resource recovery.",
    language: 'Language',
    greek: 'Ελληνικά',
    english: 'English',
    role: 'User Role',
    organisation: 'Organisation',

    // Top Bar & Navigation
    nav: {
      dashboard: 'National Dashboard',
      materialsExchange: 'Materials Exchange',
      symbiosis: 'Industrial Symbiosis',
      economics: 'Economic Analysis',
      sectors: 'Sector Modules',
      repairNetwork: 'Repair Network',
      municipalities: 'Municipalities',
      investments: 'Investments',
      environmental: 'Environmental Impact',
      reports: 'Reports',
    },

    // Sectors Submenu
    sectorsMenu: {
      agriculture: 'Agriculture & Bioeconomy',
      construction: 'Construction & Buildings',
      energyWater: 'Energy & Water',
    },

    // Verification Status Badges
    verification: {
      verified: 'Verified Data',
      userReported: 'User-Reported',
      modeled: 'Modelled Estimates',
      unverified: 'Unverified',
      provenanceTitle: 'Data Provenance & Methodology',
    },

    // Dashboard View
    dashboard: {
      title: "National Circular Economy Operational Dashboard",
      subtitle: "Real-time national indicators tracking secondary material flows and resource recovery across Greece.",
      filterRegion: 'Region',
      filterSector: 'Economic Sector',
      filterCategory: 'Material Category',
      allRegions: 'All Regions (Greece)',
      allSectors: 'All Sectors',
      allCategories: 'All Categories',
      indicatorsHeading: 'Key Operational Indicators',
      mapHeading: 'Geographic Activity & Industrial Clusters',
      recentTransactions: 'Recent Completed Material Exchanges',
      dataNote: 'Every indicator includes explicit definitions, units, reporting periods, and calculation methods.',
      kpis: {
        materialsAvailable: 'Materials Available for Reuse',
        materialsMatched: 'Successful Material Matches',
        recoveredValue: 'Estimated Recovered Material Value',
        landfillDiverted: 'Landfill Diversion Volume',
        symbiosisExchanges: 'Industrial Symbiosis Exchanges',
        wasteHeatWater: 'Waste Heat & Water Recovery Projects',
        circularConstruction: 'Recycled Construction Materials',
        netEconomicSavings: 'Potential Economic Savings',
        co2eAvoided: 'Avoided CO₂e Emissions',
      },
    },

    // Materials Exchange Marketplace
    materialsExchange: {
      title: 'Secondary Materials & By-Products Exchange',
      subtitle: 'Central B2B marketplace for listing, discovering, and trading industrial resources.',
      createListing: 'New Material Listing',
      searchPlaceholder: 'Search materials, EWC codes, grades, or locations...',
      tabSupply: 'Available Materials (Supply)',
      tabDemand: 'Required Materials (Demand)',
      listingDetails: 'Material Technical Specifications',
      regulatoryClassification: 'Regulatory Classification',
      endOfWaste: 'Certified End-of-Waste Status',
      qualityGrade: 'Quality Grade',
      availabilityWindow: 'Availability Window',
      minOrder: 'Minimum Order Quantity',
      askingPrice: 'Asking Price',
      negotiable: 'Negotiable',
      location: 'Location & Region',
      safetyDocs: 'Safety Data Sheets (SDS/MSDS)',
      sendEnquiry: 'Send Transaction Enquiry',
      enquirySuccess: 'Enquiry sent successfully to the material holder.',
      categories: {
        metals_alloys: 'Metals & Alloys',
        paper_cardboard: 'Paper & Cardboard',
        glass: 'Glass',
        plastics_polymers: 'Plastics & Polymers',
        wood_timber: 'Wood & Timber',
        construction_demolition: 'Construction & Demolition Waste (CDW)',
        textile_fibres: 'Textile Fibres',
        agricultural_residues: 'Agricultural Residues',
        food_processing_byproducts: 'Food Processing By-Products',
        industrial_minerals: 'Industrial Minerals',
        reusable_components: 'Reusable Components',
        waste_heat_energy: 'Waste Heat & Energy',
        reclaimed_water: 'Reclaimed Water',
      },
    },

    // Industrial Symbiosis Engine
    symbiosis: {
      title: 'Industrial Symbiosis Engine',
      subtitle: 'Algorithmic matching of compatible resource flows between neighboring industrial facilities.',
      matchScore: 'Compatibility Score',
      runMatching: 'Run Symbiosis Matcher',
      filterDistance: 'Max Transport Distance (km)',
      supplierFacility: 'Supplier Facility',
      buyerFacility: 'Receiver Facility',
      distance: 'Geographic Distance',
      transportCost: 'Estimated Transport Cost',
      netBenefit: 'Net Economic Benefit',
      co2Saved: 'Emissions Avoided',
      whyRecommended: 'Match Recommendation Rationale',
      feasibilityCheck: 'Technical & Regulatory Feasibility Check',
      initiateExchange: 'Initiate Transaction',
    },

    // Economic Analysis Engine
    economics: {
      title: 'Circular Business Economics Engine',
      subtitle: 'Quantitative valuation of transaction viability, logistics costs, and stress testing.',
      calculatorTitle: 'Calculation Assumptions',
      resultsTitle: 'Net Economic Benefit Analysis',
      sensitivityTitle: 'Sensitivity Analysis & Scenario Stress Testing',
      avoidedDisposal: 'Avoided Disposal/Landfill Fee',
      avoidedVirgin: 'Avoided Virgin Material Purchase',
      productRevenue: 'Recovered Material Sales Revenue',
      collectionTransport: 'Collection & Transport Cost (€/t-km)',
      processingCost: 'Sorting & Processing Cost',
      testingCert: 'Testing & Certification Cost',
      carbonBenefit: 'Avoided Carbon Emissions Value',
      netBenefitResult: 'Transaction Net Economic Benefit',
      paybackPeriod: 'CapEx Payback Period',
      roi: 'Return on Investment (ROI)',
      sliders: {
        quantity: 'Material Quantity (Tonnes)',
        askingPrice: 'Secondary Purchase Price (€/t)',
        virginPrice: 'Virgin Material Price (€/t)',
        disposalFee: 'Disposal/Landfill Fee (€/t)',
        distance: 'Transport Distance (km)',
        fuelPriceOffset: 'Fuel Price Change (%)',
        carbonPrice: 'Carbon Offset Price (€/t CO₂)',
        qualityDowngrade: 'Quality Downgrade Factor (%)',
      },
    },

    // Agriculture Module
    agriculture: {
      title: 'Agriculture & Bioeconomy Module',
      subtitle: 'Valorisation of Greek agricultural residues, olive mill wastewater/pomace, and winery by-products.',
      residueType: 'Residue Type',
      moistureContent: 'Moisture Content (%)',
      seasonality: 'Seasonal Harvest Window',
      biomassOpportunity: 'Bioenergy & Soil Amendment Opportunities',
      safetyWarning: 'Notice: Regulatory compliance and testing are mandatory prior to feed or soil application.',
    },

    // Construction Module
    construction: {
      title: 'Circular Construction & Building Passports',
      subtitle: 'CDW management, timber reuse, structural steel recovery, recycled aggregates, and stone masonry.',
      buildingPassport: 'Building Material Passport',
      structuralGrade: 'Structural Integrity Certification',
      chainOfCustody: 'Chain of Custody Record',
      testingNotice: 'Recovered structural materials require professional laboratory testing prior to reuse.',
    },

    // Energy & Water Module
    energyWater: {
      title: 'Energy & Resource Efficiency',
      subtitle: 'Industrial waste heat recovery, process water reuse, and EV battery recycling pathways.',
      thermalPower: 'Thermal Output (kW / MWh)',
      temperature: 'Stream Temperature (°C)',
      heatExchangerNeeds: 'Heat Exchanger Specification',
      reclaimedWaterQuality: 'Reclaimed Water Grade (ISO 16075)',
    },

    // Repair Network
    repairNetwork: {
      title: 'Repair, Refurbishment & Reuse Directory',
      subtitle: 'Verified repair workshops, remanufacturers, and community reuse points across Greece.',
      searchWorkshop: 'Search repair providers by city or equipment category...',
      calculatorTitle: 'Repair vs. Replace Calculator',
      repairCost: 'Repair Cost (€)',
      newProductCost: 'New Product Price (€)',
      lifespanExtension: 'Lifespan Extension (Years)',
      savingsCalculated: 'Net Financial Savings from Repair',
      co2Calculated: 'Manufacturing Footprint Avoided',
    },

    // Municipal Console
    municipalities: {
      title: 'Municipal Circular Economy Console',
      subtitle: 'Monitoring local material balance, civic reuse centers, and circular public procurement.',
      selectMunicipality: 'Select Municipality',
      recyclingRate: 'Municipal Recycling Rate',
      landfillDiverted: 'Annual Landfill Diversion (Tonnes)',
      foodWasteCollection: 'Organic/Biowaste Collection Volume',
      publicProcurement: 'Green Public Procurement Tenders',
      createTender: 'Publish Circular Material Tender',
    },

    // Investments Hub
    investments: {
      title: 'Circular Infrastructure Investment Pipeline',
      subtitle: 'Bankable circular infrastructure projects across Greece looking for capital.',
      capex: 'Required CapEx (€)',
      irr: 'Projected IRR (%)',
      payback: 'Payback Period',
      permittingStage: 'Permitting Stage',
      contactSponsor: 'Contact Project Sponsor',
      disclaimer: 'Note: Indicative analysis only. Does not constitute financial advice or an investment offer.',
    },

    // Environmental Impact Accounting
    environmental: {
      title: 'Environmental Accounting & LCA Methodology',
      subtitle: 'Transparent accounting for avoided emissions, water savings, and resource conservation.',
      functionalUnit: 'Functional Unit',
      baselineScenario: 'Baseline Reference Scenario',
      emissionFactor: 'Emission Factor (Kg CO₂e/unit)',
      systemBoundary: 'System Boundary (Cradle-to-Gate)',
      grossVsNet: 'Gross vs. Net Avoided Emissions',
    },

    // Common Actions
    actions: {
      save: 'Save',
      cancel: 'Cancel',
      filter: 'Filter',
      reset: 'Reset',
      downloadCsv: 'Export CSV',
      exportReport: 'Export PDF Report',
      close: 'Close',
      viewDetails: 'View Details',
      contact: 'Contact',
      submit: 'Submit',
    },
  },
};
