/**
 * KYKLOS (ΚΥΚΛΟΣ) - Sector Module: Energy & Resource Efficiency (Waste Heat, Reclaimed Water)
 */

import React from 'react';
import { Language } from '../types';
import { translations } from '../i18n/translations';

interface SectorEnergyWaterViewProps {
  lang: Language;
}

export const SectorEnergyWaterView: React.FC<SectorEnergyWaterViewProps> = ({ lang }) => {
  const t = translations[lang];

  const projects = [
    {
      titleEl: 'Ανάκτηση Αποβληθείσας Θερμότητας Χαλυβουργίας (85°C)',
      titleEn: 'Steel Mill Waste Heat Recovery Circuit (85°C)',
      location: 'Θριάσιο Πεδίο, Αττική',
      thermalPower: '2.4 MW thermal',
      temp: '85°C / 55°C',
      useEl: 'Τροφοδοσία Τοπικής Θερμοκηπιακής Μονάδας & Ξήρανση Βιομάζας',
      useEn: 'Adjacent Agricultural Greenhouse Heating & Biomass Drying',
      savingsEur: '€185,000 / έτος',
    },
    {
      titleEl: 'Επανάχρηση Βιομηχανικού Νερού Διυλιστηρίου (ISO 16075)',
      titleEn: 'Industrial Process Water Reclamation (ISO 16075 Grade A)',
      location: 'ΒΙ.ΠΕ. Θεσσαλονίκης - Σίνδος',
      thermalPower: '1,200 m3 / ημέρα',
      temp: '22°C',
      useEl: 'Ψύξη Πύργων & Πλύση Δευτερογενών Πλαστικών',
      useEn: 'Cooling Tower Feed & Secondary Plastics Washing Line',
      savingsEur: '€92,000 / έτος',
    },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Banner */}
      <div className="p-6 bg-[#0F2B48] text-white rounded-xl border border-[#1A3E61] shadow-sm">
        <h1 className="text-xl font-extrabold text-white">
          {t.energyWater.title}
        </h1>
        <p className="text-xs text-slate-300 mt-1">
          {t.energyWater.subtitle}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {projects.map((p, idx) => (
          <div key={idx} className="kyklos-card p-5 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm">
                {lang === 'el' ? p.titleEl : p.titleEn}
              </h3>
              <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 shrink-0">
                {p.savingsEur}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono p-2.5 bg-slate-50 rounded border border-slate-200">
              <div>
                <div className="text-slate-400 font-sans uppercase text-[10px]">{t.energyWater.thermalPower}</div>
                <div className="font-bold text-slate-900">{p.thermalPower}</div>
              </div>
              <div>
                <div className="text-slate-400 font-sans uppercase text-[10px]">{t.energyWater.temperature}</div>
                <div className="font-bold text-amber-700">{p.temp}</div>
              </div>
            </div>

            <div className="text-xs">
              <div className="font-bold text-slate-800 mb-1">{lang === 'el' ? 'Εφαρμογή / Παραλήπτης:' : 'Application / Offtaker:'}</div>
              <p className="p-2.5 bg-white rounded border border-slate-200 text-slate-700">
                {lang === 'el' ? p.useEl : p.useEn}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
