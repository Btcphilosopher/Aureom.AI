/**
 * KYKLOS (ΚΥΚΛΟΣ) - Sub-Navigation Workspace Toolbar
 */

import React from 'react';
import { Language } from '../types';
import { translations } from '../i18n/translations';

interface NavigationProps {
  lang: Language;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ lang, activeTab, onTabChange }) => {
  const t = translations[lang];

  const tabs = [
    { id: 'dashboard', label: t.nav.dashboard },
    { id: 'materialsExchange', label: t.nav.materialsExchange },
    { id: 'symbiosis', label: t.nav.symbiosis },
    { id: 'economics', label: t.nav.economics },
    { id: 'sectorAgriculture', label: t.sectorsMenu.agriculture },
    { id: 'sectorConstruction', label: t.sectorsMenu.construction },
    { id: 'sectorEnergyWater', label: t.sectorsMenu.energyWater },
    { id: 'repairNetwork', label: t.nav.repairNetwork },
    { id: 'municipalities', label: t.nav.municipalities },
    { id: 'investments', label: t.nav.investments },
    { id: 'environmental', label: t.nav.environmental },
    { id: 'reports', label: t.nav.reports },
  ];

  return (
    <div className="bg-[#1A3E61] border-b border-[#25527A] shadow-inner text-white overflow-x-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-1 py-2 text-xs font-medium min-w-max">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-[#0F2B48] text-amber-400 font-semibold border border-amber-500/40 shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-[#25527A]/50'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
