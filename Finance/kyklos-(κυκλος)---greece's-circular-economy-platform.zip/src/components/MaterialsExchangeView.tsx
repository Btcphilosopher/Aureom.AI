/**
 * KYKLOS (ΚΥΚΛΟΣ) - Materials Exchange (B2B Marketplace)
 */

import React, { useState, useEffect } from 'react';
import { MaterialListing, MaterialCategory, GreekRegion, Language } from '../types';
import { translations } from '../i18n/translations';
import { kyklosApi } from '../services/api';

interface MaterialsExchangeViewProps {
  lang: Language;
  isOpenCreateModal: boolean;
  onCloseCreateModal: () => void;
  onOpenCreateModal: () => void;
}

export const MaterialsExchangeView: React.FC<MaterialsExchangeViewProps> = ({
  lang,
  isOpenCreateModal,
  onCloseCreateModal,
  onOpenCreateModal,
}) => {
  const t = translations[lang];

  const [listings, setListings] = useState<MaterialListing[]>([]);
  const [activeType, setActiveType] = useState<'supply' | 'demand'>('supply');
  const [selectedCategory, setSelectedCategory] = useState<MaterialCategory | 'all'>('all');
  const [selectedRegion, setSelectedRegion] = useState<GreekRegion | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedListingDetail, setSelectedListingDetail] = useState<MaterialListing | null>(null);
  const [enquirySuccessMessage, setEnquirySuccessMessage] = useState<string | null>(null);

  // Form state for creating listing
  const [formTitleEl, setFormTitleEl] = useState('');
  const [formTitleEn, setFormTitleEn] = useState('');
  const [formType, setFormType] = useState<'supply' | 'demand'>('supply');
  const [formCategory, setFormCategory] = useState<MaterialCategory>('plastics_polymers');
  const [formEwc, setFormEwc] = useState('19 12 04');
  const [formQuantity, setFormQuantity] = useState<number>(100);
  const [formUnit, setFormUnit] = useState<'tonnes' | 'kg' | 'm3' | 'litres' | 'kWh'>('tonnes');
  const [formQualityGrade, setFormQualityGrade] = useState<'A_premium' | 'B_standard' | 'C_raw' | 'D_mixed'>('B_standard');
  const [formAskingPrice, setFormAskingPrice] = useState<number>(150);
  const [formRegion, setFormRegion] = useState<GreekRegion>('attica');
  const [formLocation, setFormLocation] = useState('Θριάσιο Πεδίο, Αττική');
  const [formDescription, setFormDescription] = useState('');
  const [formEndOfWaste, setFormEndOfWaste] = useState(true);

  useEffect(() => {
    fetchListings();
  }, [activeType, selectedCategory, selectedRegion, searchQuery]);

  const fetchListings = async () => {
    const data = await kyklosApi.getMaterialListings({
      type: activeType,
      category: selectedCategory === 'all' ? undefined : selectedCategory,
      region: selectedRegion === 'all' ? undefined : selectedRegion,
      query: searchQuery || undefined,
    });
    setListings(data);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitleEl) return;

    await kyklosApi.createMaterialListing({
      titleEl: formTitleEl,
      titleEn: formTitleEn || formTitleEl,
      organisationId: 'org_hellenic_metals',
      organisationName: 'Ελληνική Χαλυβουργία & Μέταλλα Α.Ε.',
      type: formType,
      category: formCategory,
      classificationCode: formEwc,
      quantity: Number(formQuantity),
      unit: formUnit,
      qualityGrade: formQualityGrade,
      physicalCondition: 'Βιομηχανική δευτερογενής πρώτη ύλη',
      region: formRegion,
      locationName: formLocation,
      coordinates: [38.048, 23.538],
      availabilityWindow: {
        start: new Date().toISOString().split('T')[0],
        end: '2027-12-31',
        recurring: true,
      },
      minOrderQuantity: Math.max(1, Math.round(formQuantity * 0.1)),
      askingPricePerUnit: Number(formAskingPrice),
      isNegotiable: true,
      packagingRequirements: 'Big Bags / Χύδην',
      storageConditions: 'Στεγασμένη αποθήκη',
      transportRequirements: 'Φορτηγό',
      safetyDocsAvailable: true,
      regulatoryClassification: formEndOfWaste ? 'end_of_waste' : 'by_product',
      endOfWasteCertified: formEndOfWaste,
      verificationStatus: 'verified',
      descriptionEl: formDescription || 'Καταχωρημένο δευτερογενές υλικό στην πλατφόρμα KYKLOS.',
      descriptionEn: formDescription || 'Registered secondary resource on KYKLOS platform.',
      status: 'active',
    });

    onCloseCreateModal();
    fetchListings();
  };

  const handleSendEnquiry = async (listingId: string) => {
    setEnquirySuccessMessage(t.materialsExchange.enquirySuccess);
    setTimeout(() => setEnquirySuccessMessage(null), 4000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl overflow-hidden border border-slate-200 shrink-0">
            <img
              src="/src/assets/images/kyklos_materials_exchange_1792929015509.jpg"
              alt="Secondary Materials"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#0F2B48]">
              {t.materialsExchange.title}
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              {t.materialsExchange.subtitle}
            </p>
          </div>
        </div>

        <button
          onClick={onOpenCreateModal}
          className="px-4 py-2 bg-[#D97706] text-white font-bold text-xs rounded-lg hover:bg-[#B45309] transition-colors whitespace-nowrap shadow-sm"
        >
          {t.materialsExchange.createListing}
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs space-y-4">
        {/* Supply vs Demand Segmented Toggle */}
        <div className="flex items-center justify-between gap-4 flex-wrap border-b border-slate-100 pb-3">
          <div className="flex items-center bg-slate-100 p-1 rounded-lg">
            <button
              onClick={() => setActiveType('supply')}
              className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all ${
                activeType === 'supply' ? 'bg-[#0F2B48] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.materialsExchange.tabSupply}
            </button>
            <button
              onClick={() => setActiveType('demand')}
              className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all ${
                activeType === 'demand' ? 'bg-[#0F2B48] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {t.materialsExchange.tabDemand}
            </button>
          </div>

          <div className="text-xs font-mono font-semibold text-slate-500">
            {listings.length} {lang === 'el' ? 'Καταχωρήσεις' : 'Listings'}
          </div>
        </div>

        {/* Category & Search Filter Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <input
            type="text"
            placeholder={t.materialsExchange.searchPlaceholder}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
          />

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value as MaterialCategory | 'all')}
            className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">{t.dashboard.allCategories}</option>
            <option value="metals_alloys">{t.materialsExchange.categories.metals_alloys}</option>
            <option value="plastics_polymers">{t.materialsExchange.categories.plastics_polymers}</option>
            <option value="construction_demolition">{t.materialsExchange.categories.construction_demolition}</option>
            <option value="wood_timber">{t.materialsExchange.categories.wood_timber}</option>
            <option value="agricultural_residues">{t.materialsExchange.categories.agricultural_residues}</option>
            <option value="waste_heat_energy">{t.materialsExchange.categories.waste_heat_energy}</option>
            <option value="reclaimed_water">{t.materialsExchange.categories.reclaimed_water}</option>
          </select>

          <select
            value={selectedRegion}
            onChange={(e) => setSelectedRegion(e.target.value as GreekRegion | 'all')}
            className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="all">{t.dashboard.allRegions}</option>
            <option value="attica">Αττική / Attica</option>
            <option value="central_macedonia">Κεντρική Μακεδονία / Central Macedonia</option>
            <option value="peloponnese">Πελοπόννησος / Peloponnese</option>
            <option value="thessaly">Θεσσαλία / Thessaly</option>
            <option value="western_greece">Δυτική Ελλάδα / Western Greece</option>
            <option value="crete">Κρήτη / Crete</option>
          </select>
        </div>
      </div>

      {enquirySuccessMessage && (
        <div className="p-3 bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs rounded-lg font-medium">
          ✓ {enquirySuccessMessage}
        </div>
      )}

      {/* Material Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {listings.map((item) => (
          <div
            key={item.id}
            className="kyklos-card p-4 rounded-xl flex flex-col justify-between space-y-3 border border-slate-200 hover:border-amber-400 hover:shadow-md transition-all"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                  EWC {item.classificationCode}
                </span>
                {item.endOfWasteCertified && (
                  <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                    End-of-Waste Certified
                  </span>
                )}
              </div>

              <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2">
                {lang === 'el' ? item.titleEl : item.titleEn}
              </h3>

              <div className="text-xs text-slate-500 mt-1">
                {item.organisationName}
              </div>

              <div className="mt-3 p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{lang === 'el' ? 'Ποσότητα' : 'Quantity'}:</span>
                  <span className="font-mono font-bold text-slate-900">{item.quantity.toLocaleString()} {item.unit}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{t.materialsExchange.askingPrice}:</span>
                  <span className="font-mono font-bold text-[#0F2B48]">
                    €{item.askingPricePerUnit} / {item.unit}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{lang === 'el' ? 'Τοποθεσία' : 'Location'}:</span>
                  <span className="text-slate-800 font-medium truncate max-w-[140px]">{item.locationName}</span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
              <button
                onClick={() => setSelectedListingDetail(item)}
                className="text-xs font-semibold text-slate-700 hover:text-[#0F2B48] underline"
              >
                {t.materialsExchange.listingDetails}
              </button>

              <button
                onClick={() => handleSendEnquiry(item.id)}
                className="px-3 py-1 bg-[#0F2B48] text-white text-xs font-bold rounded hover:bg-[#1A3E61] transition-colors"
              >
                {t.materialsExchange.sendEnquiry}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Material Detail Drawer / Modal */}
      {selectedListingDetail && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full border border-slate-200 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
            
            <div className="bg-[#0F2B48] text-white p-4 flex items-center justify-between border-b border-[#1A3E61]">
              <div>
                <span className="text-xs font-mono text-amber-400 font-semibold uppercase">
                  EWC Code: {selectedListingDetail.classificationCode}
                </span>
                <h3 className="text-base font-bold text-white mt-0.5">
                  {lang === 'el' ? selectedListingDetail.titleEl : selectedListingDetail.titleEn}
                </h3>
              </div>
              <button
                onClick={() => setSelectedListingDetail(null)}
                className="text-slate-300 hover:text-white p-1 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-700">
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <div className="text-slate-500 font-medium">{t.materialsExchange.askingPrice}</div>
                  <div className="font-mono text-base font-bold text-[#0F2B48]">
                    €{selectedListingDetail.askingPricePerUnit} / {selectedListingDetail.unit}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 font-medium">{lang === 'el' ? 'Διαθέσιμο Όγκος' : 'Available Volume'}</div>
                  <div className="font-mono text-base font-bold text-emerald-800">
                    {selectedListingDetail.quantity.toLocaleString()} {selectedListingDetail.unit}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500 font-medium">{t.materialsExchange.qualityGrade}</div>
                  <div className="font-semibold text-slate-900">{selectedListingDetail.qualityGrade}</div>
                </div>
                <div>
                  <div className="text-slate-500 font-medium">{t.materialsExchange.regulatoryClassification}</div>
                  <div className="font-semibold text-slate-900 capitalize">{selectedListingDetail.regulatoryClassification}</div>
                </div>
              </div>

              <div>
                <div className="font-semibold text-slate-900 mb-1">{lang === 'el' ? 'Περιγραφή & Προδιαγραφές' : 'Description & Specification'}</div>
                <p className="p-3 bg-slate-50 rounded border border-slate-200 leading-relaxed text-slate-700">
                  {lang === 'el' ? selectedListingDetail.descriptionEl : selectedListingDetail.descriptionEn}
                </p>
              </div>

              {selectedListingDetail.compositionSpec && (
                <div>
                  <div className="font-semibold text-slate-900 mb-1">{lang === 'el' ? 'Χημική / Τεχνική Σύνθεση' : 'Chemical / Technical Composition'}</div>
                  <div className="p-2.5 font-mono bg-amber-50 rounded border border-amber-200 text-amber-900">
                    {selectedListingDetail.compositionSpec}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="font-semibold text-slate-800">{lang === 'el' ? 'Συσκευασία & Αποθήκευση' : 'Packaging & Storage'}</div>
                  <div className="text-slate-600 mt-1">{selectedListingDetail.packagingRequirements} · {selectedListingDetail.storageConditions}</div>
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <div className="font-semibold text-slate-800">{lang === 'el' ? 'Απαιτήσεις Μεταφοράς' : 'Transport Constraints'}</div>
                  <div className="text-slate-600 mt-1">{selectedListingDetail.transportRequirements}</div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => setSelectedListingDetail(null)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-md font-semibold text-xs"
              >
                {t.actions.close}
              </button>
              <button
                onClick={() => {
                  handleSendEnquiry(selectedListingDetail.id);
                  setSelectedListingDetail(null);
                }}
                className="px-4 py-2 bg-[#D97706] text-white font-bold rounded-md text-xs hover:bg-[#B45309]"
              >
                {t.materialsExchange.sendEnquiry}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* New Listing Modal */}
      {isOpenCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-xl w-full border border-slate-200 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
            
            <div className="bg-[#0F2B48] text-white p-4 flex items-center justify-between border-b border-[#1A3E61]">
              <h3 className="text-sm font-bold text-white">
                {t.materialsExchange.createListing}
              </h3>
              <button onClick={onCloseCreateModal} className="text-slate-300 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-5 overflow-y-auto space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">{lang === 'el' ? 'Τίτλος Υλικού (Ελληνικά)' : 'Material Title (Greek)'}</label>
                <input
                  type="text"
                  required
                  placeholder="π.χ. Ανακυκλωμένα Σφαιρίδια rPET Καθαρά"
                  value={formTitleEl}
                  onChange={(e) => setFormTitleEl(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-1.5 text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">{lang === 'el' ? 'Τύπος Καταχώρησης' : 'Listing Type'}</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as 'supply' | 'demand')}
                    className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-1.5"
                  >
                    <option value="supply">{t.materialsExchange.tabSupply}</option>
                    <option value="demand">{t.materialsExchange.tabDemand}</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">{lang === 'el' ? 'Κατηγορία' : 'Category'}</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as MaterialCategory)}
                    className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-1.5"
                  >
                    <option value="plastics_polymers">{t.materialsExchange.categories.plastics_polymers}</option>
                    <option value="metals_alloys">{t.materialsExchange.categories.metals_alloys}</option>
                    <option value="construction_demolition">{t.materialsExchange.categories.construction_demolition}</option>
                    <option value="wood_timber">{t.materialsExchange.categories.wood_timber}</option>
                    <option value="agricultural_residues">{t.materialsExchange.categories.agricultural_residues}</option>
                    <option value="waste_heat_energy">{t.materialsExchange.categories.waste_heat_energy}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">EWC Code</label>
                  <input
                    type="text"
                    value={formEwc}
                    onChange={(e) => setFormEwc(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">{lang === 'el' ? 'Ποσότητα' : 'Quantity'}</label>
                  <input
                    type="number"
                    value={formQuantity}
                    onChange={(e) => setFormQuantity(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-1.5 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">{t.materialsExchange.askingPrice} (€/unit)</label>
                  <input
                    type="number"
                    value={formAskingPrice}
                    onChange={(e) => setFormAskingPrice(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-1.5 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">{lang === 'el' ? 'Περιγραφή' : 'Description'}</label>
                <textarea
                  rows={3}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-1.5"
                  placeholder="Τεχνικές λεπτομέρειες, φυσική κατάσταση..."
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={onCloseCreateModal}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded font-semibold"
                >
                  {t.actions.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#D97706] text-white font-bold rounded hover:bg-[#B45309]"
                >
                  {t.actions.submit}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
