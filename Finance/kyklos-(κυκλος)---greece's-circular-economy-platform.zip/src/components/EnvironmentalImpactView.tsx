/**
 * KYKLOS (ΚΥΚΛΟΣ) - Environmental Accounting & Impact Methodology
 */

import React, { useState, useEffect } from 'react';
import { EnvironmentalFactor, Language } from '../types';
import { translations } from '../i18n/translations';
import { kyklosApi } from '../services/api';

interface EnvironmentalImpactViewProps {
  lang: Language;
}

export const EnvironmentalImpactView: React.FC<EnvironmentalImpactViewProps> = ({ lang }) => {
  const t = translations[lang];

  const [factors, setFactors] = useState<EnvironmentalFactor[]>([]);

  useEffect(() => {
    loadFactors();
  }, []);

  const loadFactors = async () => {
    const data = await kyklosApi.getEnvironmentalFactors();
    setFactors(data);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Banner */}
      <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <h1 className="text-xl font-extrabold text-[#0F2B48]">
          {t.environmental.title}
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          {t.environmental.subtitle}
        </p>
      </div>

      {/* Factors Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden p-5 space-y-4">
        <h2 className="text-sm font-bold text-[#0F2B48] uppercase tracking-wider">
          {lang === 'el' ? 'Βάση Δεδομένων Συντελεστών Εκπομπών (LCA Emission Factors)' : 'LCA Emission Factors Database'}
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50">
                <th className="p-3">{t.environmental.functionalUnit}</th>
                <th className="p-3 font-mono text-right">{t.environmental.emissionFactor}</th>
                <th className="p-3 font-mono text-right">{lang === 'el' ? 'Καθαρή Αποφυγή CO₂e' : 'Net CO₂e Avoided'}</th>
                <th className="p-3 font-mono text-right">{lang === 'el' ? 'Εξοικονόμηση Νερού (m3)' : 'Water Saved (m3)'}</th>
                <th className="p-3">{lang === 'el' ? 'Πηγή & Όρια' : 'Source & Boundary'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {factors.map((f) => (
                <tr key={f.id} className="hover:bg-slate-50/80">
                  <td className="p-3 font-sans font-medium text-slate-900">{f.functionalUnit}</td>
                  <td className="p-3 text-right text-slate-700">{f.virginEmissionFactorKgCo2e} kg</td>
                  <td className="p-3 text-right text-emerald-700 font-bold">-{f.netAvoidedCo2ePerUnit} t</td>
                  <td className="p-3 text-right text-amber-700 font-bold">{f.waterSavingsM3PerUnit} m3</td>
                  <td className="p-3 font-sans text-slate-600 text-[11px]">{f.sourceName} ({f.systemBoundary})</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
