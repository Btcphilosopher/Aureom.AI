/**
 * KYKLOS (ΚΥΚΛΟΣ) - Data Provenance & Methodology Modal
 */

import React from 'react';
import { IndicatorData, Language } from '../types';
import { translations } from '../i18n/translations';

interface DataProvenanceModalProps {
  indicator: IndicatorData | null;
  lang: Language;
  onClose: () => void;
}

export const DataProvenanceModal: React.FC<DataProvenanceModalProps> = ({ indicator, lang, onClose }) => {
  if (!indicator) return null;
  const t = translations[lang];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-lg w-full border border-slate-200 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-[#0F2B48] text-white p-4 flex items-center justify-between border-b border-[#1A3E61]">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-amber-400" />
            <span className="text-sm font-bold tracking-tight">
              {t.verification.provenanceTitle}
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-slate-300 hover:text-white p-1 rounded transition-colors text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700">
          <div>
            <div className="text-slate-500 font-medium mb-1">
              {lang === 'el' ? 'Δείκτης' : 'Indicator Name'}
            </div>
            <div className="text-base font-bold text-[#0F2B48]">
              {lang === 'el' ? indicator.labelEl : indicator.labelEn}
            </div>
            <div className="mt-1 font-mono text-lg font-bold text-[#3A533F]">
              {indicator.formattedValue}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div>
              <div className="text-slate-500 text-[11px] font-medium">{lang === 'el' ? 'Μονάδα Μέτρησης' : 'Unit'}</div>
              <div className="font-mono font-semibold text-slate-900">{indicator.unit}</div>
            </div>
            <div>
              <div className="text-slate-500 text-[11px] font-medium">{lang === 'el' ? 'Περίοδος Αναφοράς' : 'Reporting Period'}</div>
              <div className="font-mono font-semibold text-slate-900">{indicator.timePeriod}</div>
            </div>
            <div>
              <div className="text-slate-500 text-[11px] font-medium">{lang === 'el' ? 'Κατάσταση Επαλήθευσης' : 'Verification Status'}</div>
              <div className="font-semibold text-emerald-700 capitalize">
                {indicator.dataOrigin === 'verified' ? (lang === 'el' ? 'Επαληθευμένο' : 'Verified') : indicator.dataOrigin}
              </div>
            </div>
            <div>
              <div className="text-slate-500 text-[11px] font-medium">{lang === 'el' ? 'Τάση (YoY)' : 'Trend (YoY)'}</div>
              <div className="font-mono font-semibold text-amber-600">+{indicator.trendPct}%</div>
            </div>
          </div>

          <div>
            <div className="font-semibold text-slate-900 mb-1">{lang === 'el' ? 'Επίσημος Ορισμός' : 'Formal Definition'}</div>
            <p className="p-2.5 bg-white rounded border border-slate-200 leading-relaxed text-slate-600">
              {lang === 'el' ? indicator.definitionEl : indicator.definitionEn}
            </p>
          </div>

          <div>
            <div className="font-semibold text-slate-900 mb-1">{lang === 'el' ? 'Μεθοδολογία Υπολογισμού' : 'Calculation Methodology'}</div>
            <p className="p-2.5 bg-amber-50/50 rounded border border-amber-200/60 font-mono text-[11px] leading-relaxed text-amber-900">
              {lang === 'el' ? indicator.calculationMethodEl : indicator.calculationMethodEn}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-slate-100 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#0F2B48] text-white font-medium rounded-md text-xs hover:bg-[#1A3E61] transition-colors"
          >
            {t.actions.close}
          </button>
        </div>

      </div>
    </div>
  );
};
