/**
 * KYKLOS (ΚΥΚΛΟΣ) - Circular Business Economics Engine View
 */

import React, { useState, useEffect } from 'react';
import { EconomicAnalysisParams, EconomicAnalysisResult, Language } from '../types';
import { translations } from '../i18n/translations';
import { kyklosApi } from '../services/api';

interface EconomicsViewProps {
  lang: Language;
}

export const EconomicsView: React.FC<EconomicsViewProps> = ({ lang }) => {
  const t = translations[lang];

  const [params, setParams] = useState<EconomicAnalysisParams>({
    quantityTonnes: 500,
    askingPriceEurPerTon: 180,
    virginMaterialPriceEurPerTon: 450,
    disposalFeeEurPerTon: 60,
    transportDistanceKm: 110,
    transportRateEurPerTonKm: 0.12,
    processingCostEurPerTon: 25,
    testingCertificationEur: 1500,
    capexInvestmentEur: 45000,
    carbonPriceEurPerTon: 85,
    fuelPriceOffset: 0,
    materialQualityDowngradePct: 10,
  });

  const [result, setResult] = useState<EconomicAnalysisResult | null>(null);

  useEffect(() => {
    calculate();
  }, [params]);

  const calculate = async () => {
    const res = await kyklosApi.analyseEconomics(params);
    setResult(res);
  };

  const updateParam = (key: keyof EconomicAnalysisParams, value: number) => {
    setParams((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <h1 className="text-xl font-extrabold text-[#0F2B48]">
          {t.economics.title}
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          {t.economics.subtitle}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Interactive Sliders (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-4">
          <h2 className="text-sm font-bold text-[#0F2B48] border-b border-slate-100 pb-2">
            {t.economics.calculatorTitle}
          </h2>

          <div className="space-y-3.5 text-xs">
            {/* Quantity */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>{t.economics.sliders.quantity}:</span>
                <span className="font-mono text-[#0F2B48]">{params.quantityTonnes.toLocaleString()} t</span>
              </div>
              <input
                type="range"
                min="10"
                max="5000"
                step="50"
                value={params.quantityTonnes}
                onChange={(e) => updateParam('quantityTonnes', Number(e.target.value))}
                className="w-full accent-[#D97706] cursor-pointer"
              />
            </div>

            {/* Secondary Asking Price */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>{t.economics.sliders.askingPrice}:</span>
                <span className="font-mono text-[#0F2B48]">€{params.askingPriceEurPerTon}/t</span>
              </div>
              <input
                type="range"
                min="0"
                max="1000"
                step="10"
                value={params.askingPriceEurPerTon}
                onChange={(e) => updateParam('askingPriceEurPerTon', Number(e.target.value))}
                className="w-full accent-[#D97706] cursor-pointer"
              />
            </div>

            {/* Virgin Material Price */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>{t.economics.sliders.virginPrice}:</span>
                <span className="font-mono text-[#0F2B48]">€{params.virginMaterialPriceEurPerTon}/t</span>
              </div>
              <input
                type="range"
                min="50"
                max="2000"
                step="25"
                value={params.virginMaterialPriceEurPerTon}
                onChange={(e) => updateParam('virginMaterialPriceEurPerTon', Number(e.target.value))}
                className="w-full accent-[#D97706] cursor-pointer"
              />
            </div>

            {/* Landfill / Disposal Fee */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>{t.economics.sliders.disposalFee}:</span>
                <span className="font-mono text-slate-800">€{params.disposalFeeEurPerTon}/t</span>
              </div>
              <input
                type="range"
                min="0"
                max="150"
                step="5"
                value={params.disposalFeeEurPerTon}
                onChange={(e) => updateParam('disposalFeeEurPerTon', Number(e.target.value))}
                className="w-full accent-[#D97706] cursor-pointer"
              />
            </div>

            {/* Transport Distance */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>{t.economics.sliders.distance}:</span>
                <span className="font-mono text-slate-800">{params.transportDistanceKm} km</span>
              </div>
              <input
                type="range"
                min="5"
                max="400"
                step="5"
                value={params.transportDistanceKm}
                onChange={(e) => updateParam('transportDistanceKm', Number(e.target.value))}
                className="w-full accent-[#D97706] cursor-pointer"
              />
            </div>

            {/* Carbon Offset Price */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>{t.economics.sliders.carbonPrice}:</span>
                <span className="font-mono text-slate-800">€{params.carbonPriceEurPerTon}/t CO₂</span>
              </div>
              <input
                type="range"
                min="0"
                max="150"
                step="5"
                value={params.carbonPriceEurPerTon}
                onChange={(e) => updateParam('carbonPriceEurPerTon', Number(e.target.value))}
                className="w-full accent-[#D97706] cursor-pointer"
              />
            </div>

            {/* Quality Downgrade Factor */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>{t.economics.sliders.qualityDowngrade}:</span>
                <span className="font-mono text-slate-800">{params.materialQualityDowngradePct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                step="5"
                value={params.materialQualityDowngradePct}
                onChange={(e) => updateParam('materialQualityDowngradePct', Number(e.target.value))}
                className="w-full accent-[#D97706] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Net Benefit Waterfall Chart & Sensitivity Scenarios (7 cols) */}
        {result && (
          <div className="lg:col-span-7 space-y-6">
            
            {/* Net Economic Benefit Highlight Card */}
            <div className="bg-[#0F2B48] text-white p-6 rounded-xl border border-[#1A3E61] shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <div className="text-xs uppercase font-semibold text-slate-300 tracking-wider">
                  {t.economics.netBenefitResult}
                </div>
                <div className="text-3xl font-black font-mono tracking-tight text-emerald-400 mt-1 tabular-nums">
                  €{Math.round(result.netEconomicBenefitEur).toLocaleString()}
                </div>
                <div className="text-xs text-slate-300 mt-1 font-mono">
                  €{result.unitNetBenefitEurPerTon.toFixed(2)} / {lang === 'el' ? 'τόνο υλικού' : 'tonne of material'}
                </div>
              </div>

              <div className="p-3 bg-[#1A3E61] rounded-lg border border-white/10 text-xs font-mono space-y-1 shrink-0">
                <div>
                  <span className="text-slate-300">{t.economics.paybackPeriod}:</span>{' '}
                  <span className="font-bold text-amber-400">{result.simplePaybackMonths.toFixed(1)} months</span>
                </div>
                <div>
                  <span className="text-slate-300">{t.economics.roi}:</span>{' '}
                  <span className="font-bold text-emerald-400">{result.roiPct.toFixed(1)}%</span>
                </div>
              </div>
            </div>

            {/* Financial Waterfall Breakdown List */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-3">
              <h3 className="text-sm font-bold text-[#0F2B48]">
                {t.economics.resultsTitle}
              </h3>

              <div className="space-y-2 text-xs">
                {result.breakdown.map((item, idx) => {
                  const isPos = item.type === 'positive';
                  return (
                    <div key={idx} className="flex items-center justify-between p-2.5 bg-slate-50 rounded border border-slate-200">
                      <span className="font-medium text-slate-800">
                        {lang === 'el' ? item.labelEl : item.labelEn}
                      </span>
                      <span className={`font-mono font-bold ${isPos ? 'text-emerald-700' : 'text-amber-800'}`}>
                        {isPos ? '+' : ''}€{Math.abs(Math.round(item.valueEur)).toLocaleString()}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Sensitivity Analysis & Scenario Table */}
            <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-2xs space-y-3">
              <h3 className="text-sm font-bold text-[#0F2B48]">
                {t.economics.sensitivityTitle}
              </h3>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50">
                      <th className="p-2.5">{lang === 'el' ? 'Σενάριο' : 'Scenario'}</th>
                      <th className="p-2.5 font-mono text-right">{lang === 'el' ? 'Καθαρό Όφελος (€)' : 'Net Benefit (€)'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {result.sensitivityScenarios.map((sc, i) => (
                      <tr key={i} className="hover:bg-slate-50/80">
                        <td className="p-2.5 font-sans font-medium text-slate-800">
                          {lang === 'el' ? sc.scenarioEl : sc.scenarioEn}
                        </td>
                        <td className={`p-2.5 text-right font-bold ${sc.netBenefitEur >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                          €{Math.round(sc.netBenefitEur).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
