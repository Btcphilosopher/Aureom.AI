/**
 * KYKLOS (ΚΥΚΛΟΣ) - Report Generation & Export System
 */

import React, { useState } from 'react';
import { Language } from '../types';
import { translations } from '../i18n/translations';

interface ReportsViewProps {
  lang: Language;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ lang }) => {
  const t = translations[lang];

  const [reportType, setReportType] = useState('national_summary');
  const [reportPeriod, setReportPeriod] = useState('2026-YTD');
  const [downloadingMsg, setDownloadingMsg] = useState<string | null>(null);

  const handleGenerateReport = async () => {
    setDownloadingMsg(
      lang === 'el'
        ? `Δημιουργία αναφοράς ${reportType.toUpperCase()}... Η λήψη του αρχείου PDF ξεκίνησε!`
        : `Generating report ${reportType.toUpperCase()}... PDF export downloaded!`
    );
    setTimeout(() => setDownloadingMsg(null), 4000);
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl">
      {/* Banner */}
      <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <h1 className="text-xl font-extrabold text-[#0F2B48]">
          {t.nav.reports}
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          {lang === 'el'
            ? 'Εξαγωγή επίσημων αναφορών κυκλικής οικονομίας για επιχειρήσεις, δήμους και περιβαλλοντική αδειοδότηση.'
            : 'Export official circular economy performance reports for businesses, municipalities, and ESG auditing.'}
        </p>
      </div>

      {downloadingMsg && (
        <div className="p-3.5 bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs rounded-lg font-medium shadow-2xs">
          ✓ {downloadingMsg}
        </div>
      )}

      {/* Form Card */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-2xs space-y-4 text-xs">
        <div>
          <label className="block font-bold text-slate-800 mb-1">{lang === 'el' ? 'Τύπος Αναφοράς' : 'Report Type'}</label>
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-medium"
          >
            <option value="national_summary">{lang === 'el' ? 'Εθνική Σύνοψη Κυκλικής Οικονομίας Ελλάδας' : 'Greece National Circular Economy Summary'}</option>
            <option value="b2b_exchanges">{lang === 'el' ? 'Αναφορά Συναλλαγών Αγοράς Υλικών B2B' : 'B2B Secondary Materials Transaction Ledger'}</option>
            <option value="municipal_balance">{lang === 'el' ? 'Ισοζύγιο Δημοτικών Υλικών & Εκτροπής ΧΥΤΑ' : 'Municipal Material Balance & Landfill Diversion'}</option>
            <option value="esg_audit">{lang === 'el' ? 'Πιστοποιητικό Αποφυγής CO₂e & ESG Audit' : 'Avoided CO₂e & ESG Compliance Audit'}</option>
          </select>
        </div>

        <div>
          <label className="block font-bold text-slate-800 mb-1">{lang === 'el' ? 'Περίοδος Αναφοράς' : 'Reporting Period'}</label>
          <select
            value={reportPeriod}
            onChange={(e) => setReportPeriod(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-medium"
          >
            <option value="2026-YTD">2026 YTD (Ιανουάριος — Οκτώβριος 2026)</option>
            <option value="2026-Q3">2026 Q3 (Ιούλιος — Σεπτέμβριος 2026)</option>
            <option value="2025-FULL">2025 Πλήρες Έτος</option>
          </select>
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
          <button
            onClick={handleGenerateReport}
            className="px-5 py-2.5 bg-[#0F2B48] text-white text-xs font-bold rounded-lg hover:bg-[#1A3E61] transition-colors shadow-sm"
          >
            {t.actions.exportReport} (PDF)
          </button>
        </div>
      </div>
    </div>
  );
};
