/**
 * KYKLOS (ΚΥΚΛΟΣ) - Sector Module: Agriculture & Bioeconomy
 */

import React from 'react';
import { Language } from '../types';
import { translations } from '../i18n/translations';

interface SectorAgricultureViewProps {
  lang: Language;
}

export const SectorAgricultureView: React.FC<SectorAgricultureViewProps> = ({ lang }) => {
  const t = translations[lang];

  const bioItems = [
    {
      titleEl: 'Πυρήνας Ελαίας & Ελαιουργικά Υπόλοιπα (Κατσιγάρος)',
      titleEn: 'Olive Pomace & Mill Wastewater Streams (Katsigaros)',
      regionEl: 'Μεσσηνία, Ηράκλειο, Χανιά, Λακωνία',
      regionEn: 'Messinia, Heraklion, Chania, Lakonia',
      volume: '185,000 τ./έτος',
      usesEl: 'Μονάδες Βιοαερίου, Εκχύλιση Πολυφαινολών, Παραγωγή Πυρηνέλαιου, Κομποστοποίηση',
      usesEn: 'Biogas Plants, Polyphenol Extraction, Pomace Oil, Composting',
      window: 'Νοέμβριος — Φεβρουάριος',
    },
    {
      titleEl: 'Στέμφυλα & Υπολείμματα Οινοποιίας',
      titleEn: 'Grape Marcs & Winery Residues',
      regionEl: 'Νεμέα, Νάουσα, Ηράκλειο, Σαντορίνη',
      regionEn: 'Nemea, Naoussa, Heraklion, Santorini',
      volume: '42,000 τ./έτος',
      usesEl: 'Εκχύλιση Τρυγικού Οξέος, Παραγωγή Βιοαιθανόλης, Ζωοτροφές (κατόπιν ξήρανσης)',
      usesEn: 'Tartaric Acid Extraction, Bioethanol, Animal Feed (post-drying)',
      window: 'Σεπτέμβριος — Οκτώβριος',
    },
    {
      titleEl: 'Υποπροϊόντα Χυμοποίησης Εσπεριδοειδών',
      titleEn: 'Citrus Processing Peel & Pulp By-Products',
      regionEl: 'Αργολίδα, Άρτα, Λακωνία',
      regionEn: 'Argolida, Arta, Lakonia',
      volume: '65,000 τ./έτος',
      usesEl: 'Παραγωγή Πηκτίνης, Αιθέρια Έλαια, Ζωοτροφές, Υπόστρωμα Βιοαερίου',
      usesEn: 'Pectin Extraction, Essential Oils, Feedstock, Biogas Substrate',
      window: 'Δεκέμβριος — Απρίλιος',
    },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl overflow-hidden border border-slate-200 shrink-0">
            <img
              src="/src/assets/images/kyklos_agriculture_bio_1792929016616.jpg"
              alt="Greek Agriculture & Bioeconomy"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#0F2B48]">
              {t.agriculture.title}
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              {t.agriculture.subtitle}
            </p>
          </div>
        </div>

        <div className="p-3 bg-[#3A533F] text-white rounded-lg text-xs font-mono shrink-0">
          <div>{lang === 'el' ? 'Ετήσια Δυνητική Βιομάζα:' : 'Annual Biomass Potential:'}</div>
          <div className="font-bold text-amber-300 text-sm">~450,000 τ.</div>
        </div>
      </div>

      <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-medium">
        ⚠️ {t.agriculture.safetyWarning}
      </div>

      {/* Bio Residues Inventory Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {bioItems.map((item, idx) => (
          <div key={idx} className="kyklos-card p-5 rounded-xl border border-slate-200 space-y-3">
            <div>
              <span className="text-[10px] font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                {lang === 'el' ? 'Αγροτοδιατροφικό Υπόλειμμα' : 'Agri-Food Residue'}
              </span>
              <h3 className="font-bold text-slate-900 text-sm mt-2">
                {lang === 'el' ? item.titleEl : item.titleEn}
              </h3>
            </div>

            <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5 font-mono">
              <div className="flex justify-between">
                <span className="text-slate-500 font-sans">{lang === 'el' ? 'Περιοχή' : 'Region'}:</span>
                <span className="font-semibold text-slate-900">{lang === 'el' ? item.regionEl : item.regionEn}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-sans">{lang === 'el' ? 'Δυναμικότητα' : 'Volume'}:</span>
                <span className="font-bold text-emerald-700">{item.volume}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-sans">{t.agriculture.seasonality}:</span>
                <span className="font-semibold text-amber-700">{item.window}</span>
              </div>
            </div>

            <div>
              <div className="text-[11px] font-bold text-slate-800 mb-1">{t.agriculture.biomassOpportunity}:</div>
              <p className="text-xs text-slate-600 bg-white p-2.5 rounded border border-slate-200 leading-relaxed">
                {lang === 'el' ? item.usesEl : item.usesEn}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
