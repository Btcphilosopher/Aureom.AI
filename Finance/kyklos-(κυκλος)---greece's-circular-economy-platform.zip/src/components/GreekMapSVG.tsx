/**
 * KYKLOS (ΚΥKLOS) - Interactive Vector SVG Map of Greece
 * Displays 13 Regions, Industrial Clusters & Active Exchange Counts
 */

import React from 'react';
import { GreekRegion, Language } from '../types';

interface GreekMapSVGProps {
  selectedRegion: GreekRegion | 'all';
  onSelectRegion: (region: GreekRegion | 'all') => void;
  lang: Language;
}

interface RegionData {
  id: GreekRegion;
  nameEl: string;
  nameEn: string;
  path: string;
  activeCount: number;
  exchangedValueEur: string;
  labelCoords: [number, number];
  clusterName?: string;
}

const REGIONS: RegionData[] = [
  {
    id: 'attica',
    nameEl: 'Αττική',
    nameEn: 'Attica',
    path: 'M 290 280 L 320 285 L 325 310 L 305 320 L 285 300 Z',
    activeCount: 420,
    exchangedValueEur: '€5.8M',
    labelCoords: [300, 295],
    clusterName: 'Θριάσιο Πεδίο & Οινοφύτα',
  },
  {
    id: 'central_macedonia',
    nameEl: 'Κεντρική Μακεδονία',
    nameEn: 'Central Macedonia',
    path: 'M 220 70 L 290 80 L 310 130 L 250 140 L 200 110 Z',
    activeCount: 310,
    exchangedValueEur: '€4.2M',
    labelCoords: [250, 105],
    clusterName: 'ΒΙ.ΠΕ. Σίνδου',
  },
  {
    id: 'peloponnese',
    nameEl: 'Πελοπόννησος',
    nameEn: 'Peloponnese',
    path: 'M 210 300 L 260 300 L 280 360 L 220 380 L 190 330 Z',
    activeCount: 195,
    exchangedValueEur: '€2.6M',
    labelCoords: [235, 335],
    clusterName: 'Μεγαλόπολη & Μεσσηνία',
  },
  {
    id: 'thessaly',
    nameEl: 'Θεσσαλία',
    nameEn: 'Thessaly',
    path: 'M 200 150 L 250 145 L 260 200 L 190 200 Z',
    activeCount: 140,
    exchangedValueEur: '€1.9M',
    labelCoords: [225, 175],
    clusterName: 'ΒΙ.ΠΕ. Βόλου & Λάρισας',
  },
  {
    id: 'western_greece',
    nameEl: 'Δυτική Ελλάδα',
    nameEn: 'Western Greece',
    path: 'M 160 220 L 210 210 L 220 280 L 170 290 Z',
    activeCount: 110,
    exchangedValueEur: '€1.4M',
    labelCoords: [190, 250],
    clusterName: 'ΒΙ.ΠΕ. Πατρών',
  },
  {
    id: 'central_greece',
    nameEl: 'Στερεά Ελλάδα',
    nameEn: 'Central Greece',
    path: 'M 220 210 L 280 205 L 290 260 L 210 260 Z',
    activeCount: 95,
    exchangedValueEur: '€1.1M',
    labelCoords: [250, 235],
    clusterName: 'Οινόφυτα & Χαλκίδα',
  },
  {
    id: 'eastern_macedonia_thrace',
    nameEl: 'Αν. Μακεδονία & Θράκη',
    nameEn: 'E. Macedonia & Thrace',
    path: 'M 295 50 L 390 40 L 400 90 L 315 95 Z',
    activeCount: 85,
    exchangedValueEur: '€0.9M',
    labelCoords: [350, 70],
    clusterName: 'ΒΙ.ΠΕ. Καβάλας & Ξάνθης',
  },
  {
    id: 'western_macedonia',
    nameEl: 'Δυτική Μακεδονία',
    nameEn: 'Western Macedonia',
    path: 'M 160 80 L 215 80 L 200 145 L 150 140 Z',
    activeCount: 75,
    exchangedValueEur: '€0.8M',
    labelCoords: [180, 110],
    clusterName: 'Ζώνη Κοζάνης & Πτολεμαΐδας',
  },
  {
    id: 'epirus',
    nameEl: 'Ήπειρος',
    nameEn: 'Epirus',
    path: 'M 125 140 L 165 145 L 160 210 L 120 200 Z',
    activeCount: 60,
    exchangedValueEur: '€0.6M',
    labelCoords: [140, 175],
    clusterName: 'Ιωάννινα & Πρέβεζα',
  },
  {
    id: 'crete',
    nameEl: 'Κρήτη',
    nameEn: 'Crete',
    path: 'M 260 410 L 370 410 L 380 435 L 255 435 Z',
    activeCount: 165,
    exchangedValueEur: '€2.1M',
    labelCoords: [315, 422],
    clusterName: 'ΒΙ.ΠΕ. Ηρακλείου & Χανίων',
  },
  {
    id: 'south_aegean',
    nameEl: 'Νότιο Αιγαίο',
    nameEn: 'South Aegean',
    path: 'M 350 290 L 410 300 L 430 380 L 360 360 Z',
    activeCount: 50,
    exchangedValueEur: '€0.5M',
    labelCoords: [390, 330],
    clusterName: 'Ρόδος & Σύρος',
  },
  {
    id: 'north_aegean',
    nameEl: 'Βόρειο Αιγαίο',
    nameEn: 'North Aegean',
    path: 'M 340 130 L 390 140 L 400 220 L 330 210 Z',
    activeCount: 45,
    exchangedValueEur: '€0.4M',
    labelCoords: [365, 175],
    clusterName: 'Λέσβος & Χίος',
  },
  {
    id: 'ionian_islands',
    nameEl: 'Ιόνια Νησιά',
    nameEn: 'Ionian Islands',
    path: 'M 95 160 L 115 160 L 110 270 L 90 260 Z',
    activeCount: 40,
    exchangedValueEur: '€0.3M',
    labelCoords: [100, 210],
    clusterName: 'Κέρκυρα & Κεφαλλονιά',
  },
];

export const GreekMapSVG: React.FC<GreekMapSVGProps> = ({ selectedRegion, onSelectRegion, lang }) => {
  return (
    <div className="relative w-full bg-[#0F2B48] rounded-xl p-4 text-white overflow-hidden shadow-inner border border-[#1A3E61]">
      <div className="flex items-center justify-between mb-2 pb-2 border-b border-[#1A3E61]/60">
        <div className="flex items-center gap-2">
          {/* Abstract Circular Geometric Logo */}
          <div className="w-5 h-5 rounded-full border-2 border-[#D97706] flex items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-[#D97706]" />
          </div>
          <span className="text-xs font-semibold tracking-wider uppercase text-slate-200">
            {lang === 'el' ? 'Χάρτης Κυκλικής Δραστηριότητας Ελλάδας' : 'Greece Circular Activity Map'}
          </span>
        </div>
        <button
          onClick={() => onSelectRegion('all')}
          className={`px-2.5 py-1 text-xs rounded transition-colors ${
            selectedRegion === 'all' ? 'bg-[#D97706] text-white font-medium' : 'bg-[#1A3E61] text-slate-300 hover:text-white'
          }`}
        >
          {lang === 'el' ? 'Εμφάνιση Όλων' : 'Show All'}
        </button>
      </div>

      <div className="relative aspect-[4/3] w-full flex items-center justify-center">
        <svg viewBox="0 0 460 460" className="w-full h-full drop-shadow-md">
          {/* Subtle background coastline grid */}
          <path d="M 50 50 L 410 50 L 410 410 L 50 410 Z" fill="none" stroke="#1A3E61" strokeWidth="0.5" strokeDasharray="4 4" />

          {REGIONS.map((r) => {
            const isSelected = selectedRegion === r.id;
            const isAll = selectedRegion === 'all';
            return (
              <g key={r.id} className="cursor-pointer group" onClick={() => onSelectRegion(r.id)}>
                <path
                  d={r.path}
                  fill={isSelected ? '#D97706' : isAll ? '#1A3E61' : '#112D4B'}
                  stroke={isSelected ? '#FFFFFF' : '#3A533F'}
                  strokeWidth={isSelected ? '2' : '1'}
                  className="transition-all duration-200 group-hover:fill-[#25527A]"
                />
                <circle
                  cx={r.labelCoords[0]}
                  cy={r.labelCoords[1]}
                  r={isSelected ? 6 : 4}
                  fill={isSelected ? '#FFFFFF' : '#D97706'}
                  className="transition-all duration-200"
                />
                <text
                  x={r.labelCoords[0]}
                  y={r.labelCoords[1] - 8}
                  fill="#E2E8F0"
                  fontSize="9"
                  fontWeight="600"
                  textAnchor="middle"
                  className="pointer-events-none select-none drop-shadow-sm"
                >
                  {lang === 'el' ? r.nameEl : r.nameEn}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Selected Region Summary Panel Overlay */}
        {selectedRegion !== 'all' && (
          <div className="absolute bottom-3 left-3 right-3 p-3 bg-[#0F2B48]/95 backdrop-blur border border-[#D97706] rounded-lg text-xs flex items-center justify-between gap-4 animate-in fade-in duration-200">
            {(() => {
              const reg = REGIONS.find((r) => r.id === selectedRegion);
              if (!reg) return null;
              return (
                <>
                  <div>
                    <div className="font-semibold text-white text-sm">
                      {lang === 'el' ? reg.nameEl : reg.nameEn}
                    </div>
                    <div className="text-slate-300 text-[11px]">
                      {lang === 'el' ? `Βιομηχανικό Σύμπλεγμα: ${reg.clusterName}` : `Industrial Cluster: ${reg.clusterName}`}
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-right shrink-0">
                    <div>
                      <div className="text-slate-400 text-[10px] uppercase">
                        {lang === 'el' ? 'Ενεργές Καταχωρήσεις' : 'Active Listings'}
                      </div>
                      <div className="font-mono text-amber-400 font-bold">{reg.activeCount}</div>
                    </div>
                    <div>
                      <div className="text-slate-400 text-[10px] uppercase">
                        {lang === 'el' ? 'Αξία Ανακτημένων' : 'Recovered Value'}
                      </div>
                      <div className="font-mono text-emerald-400 font-bold">{reg.exchangedValueEur}</div>
                    </div>
                  </div>
                </>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};
