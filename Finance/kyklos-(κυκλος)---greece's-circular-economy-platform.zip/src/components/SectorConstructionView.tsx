/**
 * KYKLOS (ΚΥΚΛΟΣ) - Sector Module: Construction & Buildings
 */

import React from 'react';
import { Language } from '../types';
import { translations } from '../i18n/translations';

interface SectorConstructionViewProps {
  lang: Language;
}

export const SectorConstructionView: React.FC<SectorConstructionViewProps> = ({ lang }) => {
  const t = translations[lang];

  const passports = [
    {
      buildingNameEl: 'Ανάπλαση Βιομηχανικού Συγκροτήματος Ελαιουργείου (Ελευσίνα)',
      buildingNameEn: 'Elefsina Historic Olive Mill Industrial Regeneration',
      location: 'Ελευσίνα, Αττική',
      reclaimedMaterials: [
        { nameEl: 'Δομικός Χάλυβας IPE 300', nameEn: 'Structural Steel Beams IPE 300', qty: '120 tonnes', certified: true },
        { nameEl: 'Πέτρινοι Λιθόπλινθοι Πωρόλιθου', nameEn: 'Hand-Cut Limestone Blocks', qty: '850 m3', certified: true },
        { nameEl: 'Ξυλεία Κααστανιάς Στέγης', nameEn: 'Structural Chestnut Timber Beams', qty: '45 m3', certified: true },
      ],
      circularityIndexPct: 82,
    },
    {
      buildingNameEl: 'Πράσινο Κτήριο Γραφείων ΒΙ.ΠΕ. Σίνδου',
      buildingNameEn: 'Sindos Eco-Industrial Office Hub',
      location: 'Σίνδος, Θεσσαλονίκη',
      reclaimedMaterials: [
        { nameEl: 'Ανακυκλωμένο Σκυρόδεμα Αδρανών (EN 13242)', nameEn: 'Recycled Aggregate Concrete', qty: '3,200 tonnes', certified: true },
        { nameEl: 'Πάνελ Αλουμινίου Πρόσοψης', nameEn: 'Recycled Aluminum Facade Cladding', qty: '1,400 m2', certified: true },
      ],
      circularityIndexPct: 76,
    },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl overflow-hidden border border-slate-200 shrink-0">
            <img
              src="/src/assets/images/kyklos_construction_circular_1792929016839.jpg"
              alt="Circular Construction"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#0F2B48]">
              {t.construction.title}
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              {t.construction.subtitle}
            </p>
          </div>
        </div>
      </div>

      <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-medium">
        ⚠️ {t.construction.testingNotice}
      </div>

      {/* Building Passports Cards */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-[#0F2B48] uppercase tracking-wider">
          {t.construction.buildingPassport}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {passports.map((b, idx) => (
            <div key={idx} className="kyklos-card p-5 rounded-xl border border-slate-200 space-y-4">
              <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">
                    {lang === 'el' ? b.buildingNameEl : b.buildingNameEn}
                  </h3>
                  <div className="text-xs text-slate-500 mt-0.5">{b.location}</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-[10px] text-slate-400 uppercase font-sans">Circularity Index</div>
                  <div className="font-mono text-emerald-700 font-black text-lg">{b.circularityIndexPct}%</div>
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-slate-800 mb-2">{lang === 'el' ? 'Καταγεγραμμένα Ανακτημένα Υλικά:' : 'Logged Reclaimed Materials:'}</div>
                <div className="space-y-2 text-xs">
                  {b.reclaimedMaterials.map((m, i) => (
                    <div key={i} className="flex items-center justify-between p-2.5 bg-slate-50 rounded border border-slate-200">
                      <div>
                        <div className="font-semibold text-slate-900">{lang === 'el' ? m.nameEl : m.nameEn}</div>
                        <div className="text-[11px] text-emerald-700 font-medium">✓ {t.construction.structuralGrade}</div>
                      </div>
                      <div className="font-mono font-bold text-[#0F2B48]">{m.qty}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
