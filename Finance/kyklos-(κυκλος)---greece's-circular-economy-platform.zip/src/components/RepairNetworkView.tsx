/**
 * KYKLOS (ΚΥΚΛΟΣ) - Repair, Refurbishment & Reuse Directory & Calculator
 */

import React, { useState, useEffect } from 'react';
import { RepairServiceProvider, Language } from '../types';
import { translations } from '../i18n/translations';
import { kyklosApi } from '../services/api';

interface RepairNetworkViewProps {
  lang: Language;
}

export const RepairNetworkView: React.FC<RepairNetworkViewProps> = ({ lang }) => {
  const t = translations[lang];

  const [providers, setProviders] = useState<RepairServiceProvider[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Repair Calculator State
  const [repairCost, setRepairCost] = useState<number>(120);
  const [newProductCost, setNewProductCost] = useState<number>(650);
  const [lifespanYears, setLifespanYears] = useState<number>(3);

  useEffect(() => {
    loadProviders();
  }, [searchQuery]);

  const loadProviders = async () => {
    const data = await kyklosApi.getRepairProviders(undefined, undefined, searchQuery);
    setProviders(data);
  };

  const netSavings = Math.max(0, newProductCost - repairCost);
  const co2eAvoidedKg = Math.round((newProductCost / 10) * 1.8);

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <h1 className="text-xl font-extrabold text-[#0F2B48]">
          {t.repairNetwork.title}
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          {t.repairNetwork.subtitle}
        </p>
      </div>

      {/* Repair vs Replace Interactive Calculator */}
      <div className="bg-[#0F2B48] text-white p-6 rounded-xl border border-[#1A3E61] shadow-sm space-y-4">
        <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wider">
          {t.repairNetwork.calculatorTitle}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-200 mb-1">{t.repairNetwork.repairCost}:</label>
            <input
              type="number"
              value={repairCost}
              onChange={(e) => setRepairCost(Number(e.target.value))}
              className="w-full bg-[#1A3E61] border border-slate-600 rounded p-2 text-white font-mono"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-200 mb-1">{t.repairNetwork.newProductCost}:</label>
            <input
              type="number"
              value={newProductCost}
              onChange={(e) => setNewProductCost(Number(e.target.value))}
              className="w-full bg-[#1A3E61] border border-slate-600 rounded p-2 text-white font-mono"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-200 mb-1">{t.repairNetwork.lifespanExtension}:</label>
            <input
              type="number"
              value={lifespanYears}
              onChange={(e) => setLifespanYears(Number(e.target.value))}
              className="w-full bg-[#1A3E61] border border-slate-600 rounded p-2 text-white font-mono"
            />
          </div>
        </div>

        <div className="p-4 bg-[#1A3E61] rounded-lg border border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div>
            <div className="text-slate-300 font-sans uppercase text-[10px]">{t.repairNetwork.savingsCalculated}</div>
            <div className="font-bold text-emerald-400 text-2xl">€{netSavings.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-slate-300 font-sans uppercase text-[10px]">{t.repairNetwork.co2Calculated}</div>
            <div className="font-bold text-amber-400 text-2xl">~{co2eAvoidedKg} kg CO₂e</div>
          </div>
        </div>
      </div>

      {/* Directory Search & Cards */}
      <div className="space-y-4">
        <input
          type="text"
          placeholder={t.repairNetwork.searchWorkshop}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-white border border-slate-300 rounded-lg p-3 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-amber-500 shadow-2xs"
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {providers.map((p) => (
            <div key={p.id} className="kyklos-card p-4 rounded-xl border border-slate-200 space-y-2.5">
              <div className="flex items-start justify-between gap-2">
                <span className="text-[10px] font-mono font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 capitalize">
                  {p.category}
                </span>
                <span className="text-xs font-bold text-emerald-700">★ {p.rating}</span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm">
                {p.name}
              </h3>

              <div className="text-xs text-slate-500">{p.address}</div>

              <div className="p-2 bg-slate-50 rounded border border-slate-200 text-xs text-slate-700">
                <div className="font-semibold mb-1 text-[11px]">{lang === 'el' ? 'Δεχόμενα Είδη:' : 'Accepted Items:'}</div>
                <div className="flex flex-wrap gap-1">
                  {(lang === 'el' ? p.acceptedItemsEl : p.acceptedItemsEn).map((item, i) => (
                    <span key={i} className="px-1.5 py-0.5 bg-white rounded border border-slate-200 text-[10px] text-slate-600">
                      {item}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-mono text-slate-600">
                <span>{p.phone}</span>
                <span className="text-emerald-700 font-semibold">✓ {lang === 'el' ? 'Πιστοποιημένο' : 'Verified'}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
