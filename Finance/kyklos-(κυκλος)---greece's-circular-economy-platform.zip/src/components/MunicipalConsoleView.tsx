/**
 * KYKLOS (ΚΥΚΛΟΣ) - Municipal Circular Economy Console (Δήμοι & Περιφέρειες)
 */

import React, { useState, useEffect } from 'react';
import { MunicipalIndicator, Language } from '../types';
import { translations } from '../i18n/translations';
import { kyklosApi } from '../services/api';

interface MunicipalConsoleViewProps {
  lang: Language;
}

export const MunicipalConsoleView: React.FC<MunicipalConsoleViewProps> = ({ lang }) => {
  const t = translations[lang];

  const [municipalities, setMunicipalities] = useState<MunicipalIndicator[]>([]);
  const [selectedMuni, setSelectedMuni] = useState<MunicipalIndicator | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const data = await kyklosApi.getMunicipalIndicators();
    setMunicipalities(data);
    if (data.length > 0) setSelectedMuni(data[0]);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="p-6 bg-[#0F2B48] text-white rounded-xl border border-[#1A3E61] shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-white">
            {t.municipalities.title}
          </h1>
          <p className="text-xs text-slate-300 mt-1">
            {t.municipalities.subtitle}
          </p>
        </div>

        {/* Municipality Selector */}
        {selectedMuni && (
          <select
            value={selectedMuni.municipalityId}
            onChange={(e) => {
              const found = municipalities.find((m) => m.municipalityId === e.target.value);
              if (found) setSelectedMuni(found);
            }}
            className="bg-[#1A3E61] border border-[#25527A] text-white text-xs font-semibold rounded-lg px-3 py-2 focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            {municipalities.map((m) => (
              <option key={m.municipalityId} value={m.municipalityId}>
                {lang === 'el' ? m.municipalityNameEl : m.municipalityNameEn}
              </option>
            ))}
          </select>
        )}
      </div>

      {selectedMuni && (
        <div className="space-y-6">
          {/* Key Municipal Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="kyklos-card p-4 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-medium">{t.municipalities.recyclingRate}</div>
              <div className="text-2xl font-black font-mono text-[#0F2B48] mt-1">{selectedMuni.recyclingRatePct}%</div>
              <div className="text-[11px] text-emerald-700 font-semibold mt-1">✓ {selectedMuni.lastReportPeriod}</div>
            </div>

            <div className="kyklos-card p-4 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-medium">{t.municipalities.landfillDiverted}</div>
              <div className="text-2xl font-black font-mono text-emerald-800 mt-1">{selectedMuni.diversionFromLandfillTonnes.toLocaleString()} τ.</div>
              <div className="text-[11px] text-slate-500 mt-1">Ετήσια Εκτροπή από ΧΥΤΑ</div>
            </div>

            <div className="kyklos-card p-4 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-medium">{t.municipalities.foodWasteCollection}</div>
              <div className="text-2xl font-black font-mono text-amber-800 mt-1">{selectedMuni.foodWasteCollectedTonnes.toLocaleString()} τ.</div>
              <div className="text-[11px] text-slate-500 mt-1">Καφέ Κάδος / Οργανικά</div>
            </div>

            <div className="kyklos-card p-4 rounded-xl border border-slate-200">
              <div className="text-xs text-slate-500 font-medium">{t.municipalities.publicProcurement}</div>
              <div className="text-2xl font-black font-mono text-[#0F2B48] mt-1">{selectedMuni.publicProcurementCircularProjects}</div>
              <div className="text-[11px] text-slate-500 mt-1">Πράσινες Δημόσιες Συμβάσεις</div>
            </div>
          </div>

          {/* Action Row */}
          <div className="p-4 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-4">
            <div>
              <div className="font-bold text-slate-900 text-sm">
                {lang === 'el' ? 'Δημόσια Πρόσκληση Εκδήλωσης Ενδιαφέροντος για Δευτερογενή Υλικά' : 'Public Circular Procurement Tender'}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                {lang === 'el' ? 'Πρόσκληση προς επιλέξιμες επιχειρήσεις για ανάκτηση και επανάχρηση δημοτικών υλικών.' : 'Invite eligible businesses to recover municipal secondary material streams.'}
              </div>
            </div>
            <button className="px-4 py-2 bg-[#D97706] text-white text-xs font-bold rounded-lg hover:bg-[#B45309]">
              {t.municipalities.createTender}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
