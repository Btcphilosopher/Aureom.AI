/**
 * KYKLOS (ΚΥΚΛΟΣ) - Top Navigation Header
 * Enforces strict Top Bar Contract (3 Zones, Single-Line links)
 */

import React from 'react';
import { Language, UserRole } from '../types';
import { translations } from '../i18n/translations';

interface HeaderProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  userRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onOpenCreateListing: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onLanguageChange,
  activeTab,
  onTabChange,
  userRole,
  onRoleChange,
  onOpenCreateListing,
}) => {
  const t = translations[lang];

  return (
    <header className="sticky top-0 z-40 bg-[#0F2B48] text-white border-b border-[#1A3E61] shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        
        {/* Zone 1: Brand Wordmark with Abstract Circular Geometric Logo */}
        <div className="flex items-center gap-3 shrink-0 cursor-pointer" onClick={() => onTabChange('dashboard')}>
          <div className="w-8 h-8 rounded-full border-2 border-[#D97706] flex items-center justify-center p-1 bg-[#1A3E61]">
            <div className="w-full h-full rounded-full border border-white/80 flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-[#D97706]" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-extrabold tracking-tight text-white whitespace-nowrap">
              KYKLOS <span className="font-normal text-slate-300 text-sm ml-1">(ΚΥΚΛΟΣ)</span>
            </span>
          </div>
        </div>

        {/* Zone 2: Single-Line Primary Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-200">
          <button
            onClick={() => onTabChange('dashboard')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'dashboard' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            {t.nav.dashboard}
          </button>
          <button
            onClick={() => onTabChange('materialsExchange')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'materialsExchange' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            {t.nav.materialsExchange}
          </button>
          <button
            onClick={() => onTabChange('symbiosis')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'symbiosis' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            {t.nav.symbiosis}
          </button>
          <button
            onClick={() => onTabChange('economics')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'economics' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            {t.nav.economics}
          </button>
          <button
            onClick={() => onTabChange('sectors')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab.startsWith('sector') ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            {t.nav.sectors}
          </button>
        </nav>

        {/* Zone 3: Language & Role Controls + Primary Action Button */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Language Switcher */}
          <div className="flex items-center bg-[#1A3E61] p-1 rounded-md text-xs font-semibold">
            <button
              onClick={() => onLanguageChange('el')}
              className={`px-2 py-1 rounded transition-colors whitespace-nowrap ${
                lang === 'el' ? 'bg-[#D97706] text-white' : 'text-slate-300 hover:text-white'
              }`}
            >
              ΕΛ
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-2 py-1 rounded transition-colors whitespace-nowrap ${
                lang === 'en' ? 'bg-[#D97706] text-white' : 'text-slate-300 hover:text-white'
              }`}
            >
              EN
            </button>
          </div>

          {/* User Role Switcher Dropdown */}
          <select
            value={userRole}
            onChange={(e) => onRoleChange(e.target.value as UserRole)}
            className="hidden sm:block text-xs bg-[#1A3E61] text-slate-200 border border-[#25527A] rounded-md px-2.5 py-1.5 font-medium focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="business_user">{lang === 'el' ? 'Βιομηχανία / Επιχείρηση' : 'Business User'}</option>
            <option value="supplier">{lang === 'el' ? 'Προμηθευτής Υλικών' : 'Material Supplier'}</option>
            <option value="buyer">{lang === 'el' ? 'Αγοραστής / Παραλήπτης' : 'Material Buyer'}</option>
            <option value="municipality_officer">{lang === 'el' ? 'Στέλεχος Δήμου' : 'Municipality Officer'}</option>
            <option value="analyst">{lang === 'el' ? 'Αναλυτής / Ερευνητής' : 'Analyst / Researcher'}</option>
            <option value="admin">{lang === 'el' ? 'Διαχειριστής KYKLOS' : 'KYKLOS Admin'}</option>
          </select>

          {/* Primary Action Button */}
          <button
            onClick={onOpenCreateListing}
            className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#D97706] rounded-md hover:bg-[#B45309] transition-colors whitespace-nowrap shrink-0 shadow-sm"
          >
            {lang === 'el' ? '+ Νέα Καταχώρηση' : '+ New Listing'}
          </button>
        </div>

      </div>
    </header>
  );
};
