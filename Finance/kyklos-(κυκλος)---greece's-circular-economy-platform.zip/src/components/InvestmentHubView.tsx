/**
 * KYKLOS (ΚΥΚΛΟΣ) - Circular Infrastructure Investment Hub
 */

import React, { useState, useEffect } from 'react';
import { InvestmentProject, Language } from '../types';
import { translations } from '../i18n/translations';
import { kyklosApi } from '../services/api';

interface InvestmentHubViewProps {
  lang: Language;
}

export const InvestmentHubView: React.FC<InvestmentHubViewProps> = ({ lang }) => {
  const t = translations[lang];

  const [projects, setProjects] = useState<InvestmentProject[]>([]);
  const [selectedProject, setSelectedProject] = useState<InvestmentProject | null>(null);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    const data = await kyklosApi.getInvestmentProjects();
    setProjects(data);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Banner */}
      <div className="p-6 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <h1 className="text-xl font-extrabold text-[#0F2B48]">
          {t.investments.title}
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          {t.investments.subtitle}
        </p>
      </div>

      <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 font-medium">
        ℹ️ {t.investments.disclaimer}
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {projects.map((proj) => (
          <div key={proj.id} className="kyklos-card p-5 rounded-xl border border-slate-200 space-y-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[10px] font-mono font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 uppercase">
                  {proj.category.replace('_', ' ')}
                </span>
                <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 capitalize">
                  {proj.permittingStage.replace('_', ' ')}
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm">
                {lang === 'el' ? proj.titleEl : proj.titleEn}
              </h3>

              <div className="text-xs text-slate-500 mt-0.5">
                {proj.sponsorName} · {proj.municipality}
              </div>

              <p className="mt-3 p-2.5 bg-slate-50 rounded border border-slate-200 text-xs text-slate-700 leading-relaxed">
                {lang === 'el' ? proj.technologyDescriptionEl : proj.technologyDescriptionEn}
              </p>

              <div className="mt-3 grid grid-cols-3 gap-2 text-xs font-mono text-center p-2.5 bg-white rounded-lg border border-slate-200">
                <div>
                  <div className="text-[10px] text-slate-400 font-sans uppercase">{t.investments.capex}</div>
                  <div className="font-bold text-[#0F2B48]">€{(proj.capexTotalEur / 1000000).toFixed(1)}M</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 font-sans uppercase">{t.investments.irr}</div>
                  <div className="font-bold text-emerald-700">{proj.projectedIrrPct}%</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 font-sans uppercase">{t.investments.payback}</div>
                  <div className="font-bold text-amber-700">{proj.paybackYears} yrs</div>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-500 font-mono">
                CO₂e Avoided: {proj.co2eAvoidedPerYearTonnes.toLocaleString()} t/yr
              </span>
              <button
                onClick={() => setSelectedProject(proj)}
                className="px-3.5 py-1.5 bg-[#0F2B48] text-white text-xs font-bold rounded hover:bg-[#1A3E61]"
              >
                {t.investments.contactSponsor}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Sponsor Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full border border-slate-200 shadow-xl overflow-hidden p-5 space-y-4 text-xs">
            <h3 className="font-bold text-slate-900 text-sm">{t.investments.contactSponsor}</h3>
            <div className="p-3 bg-slate-50 rounded border border-slate-200 space-y-1 font-mono">
              <div><span className="text-slate-500 font-sans">Contact:</span> {selectedProject.contactPerson}</div>
              <div><span className="text-slate-500 font-sans">Email:</span> {selectedProject.contactEmail}</div>
            </div>
            <button
              onClick={() => setSelectedProject(null)}
              className="w-full py-2 bg-[#0F2B48] text-white font-bold rounded text-xs"
            >
              {t.actions.close}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
