/**
 * KYKLOS (ΚΥΚΛΟΣ) - Industrial Symbiosis Engine
 */

import React, { useState, useEffect } from 'react';
import { SymbiosisMatch, Language } from '../types';
import { translations } from '../i18n/translations';
import { kyklosApi } from '../services/api';

interface IndustrialSymbiosisViewProps {
  lang: Language;
  onTransactionCompleted: () => void;
}

export const IndustrialSymbiosisView: React.FC<IndustrialSymbiosisViewProps> = ({
  lang,
  onTransactionCompleted,
}) => {
  const t = translations[lang];

  const [matches, setMatches] = useState<SymbiosisMatch[]>([]);
  const [maxDistanceKm, setMaxDistanceKm] = useState<number>(200);
  const [selectedMatch, setSelectedMatch] = useState<SymbiosisMatch | null>(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    loadMatches();
  }, [maxDistanceKm]);

  const loadMatches = async () => {
    const data = await kyklosApi.getSymbiosisMatches(maxDistanceKm);
    setMatches(data);
  };

  const handleInitiateExchange = async (match: SymbiosisMatch) => {
    await kyklosApi.completeTransaction(match.id, 30);
    setActionSuccessMsg(
      lang === 'el'
        ? `Η συμφωνία βιομηχανικής συμβίωσης ολοκληρώθηκε επιτυχώς! Οι δείκτες της πλατφόρμας ενημερώθηκαν.`
        : `Industrial symbiosis transaction successfully agreed and completed! Platform indicators updated.`
    );
    loadMatches();
    onTransactionCompleted();
    setTimeout(() => setActionSuccessMsg(null), 5000);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 bg-white rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl overflow-hidden border border-slate-200 shrink-0">
            <img
              src="/src/assets/images/kyklos_industrial_symbiosis_1792929016280.jpg"
              alt="Industrial Symbiosis"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-[#0F2B48]">
              {t.symbiosis.title}
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              {t.symbiosis.subtitle}
            </p>
          </div>
        </div>

        {/* Distance Filter Slider */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1 shrink-0">
          <div className="flex items-center justify-between gap-3 font-semibold text-slate-700">
            <span>{t.symbiosis.filterDistance}:</span>
            <span className="font-mono text-[#0F2B48]">{maxDistanceKm} km</span>
          </div>
          <input
            type="range"
            min="20"
            max="350"
            step="10"
            value={maxDistanceKm}
            onChange={(e) => setMaxDistanceKm(Number(e.target.value))}
            className="w-36 accent-[#D97706] cursor-pointer"
          />
        </div>
      </div>

      {actionSuccessMsg && (
        <div className="p-3.5 bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs rounded-lg font-medium shadow-2xs">
          ✓ {actionSuccessMsg}
        </div>
      )}

      {/* Symbiosis Match Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {matches.map((match) => (
          <div
            key={match.id}
            className="kyklos-card p-5 rounded-xl border border-slate-200 hover:border-amber-400 hover:shadow-md transition-all flex flex-col justify-between space-y-4"
          >
            <div>
              {/* Header Score Badge */}
              <div className="flex items-center justify-between gap-2 mb-3 pb-2 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    {match.materialCategory.replace('_', ' ')}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 text-amber-900 border border-amber-300 rounded-full text-xs font-mono font-bold">
                  <span>{t.symbiosis.matchScore}:</span>
                  <span>{match.compatibilityScorePct}%</span>
                </div>
              </div>

              {/* Connected Facilities */}
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs mb-3">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase font-semibold">{t.symbiosis.supplierFacility}</div>
                  <div className="font-bold text-slate-900 line-clamp-1 mt-0.5">{match.supplierOrgName}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase font-semibold">{t.symbiosis.buyerFacility}</div>
                  <div className="font-bold text-slate-900 line-clamp-1 mt-0.5">{match.buyerOrgName}</div>
                </div>
              </div>

              {/* Logistics & Financial Metrics */}
              <div className="grid grid-cols-3 gap-2 text-xs font-mono text-center p-2.5 bg-white rounded-lg border border-slate-200">
                <div>
                  <div className="text-[10px] text-slate-400 font-sans uppercase">{t.symbiosis.distance}</div>
                  <div className="font-bold text-slate-800">{match.distanceKm} km</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 font-sans uppercase">{t.symbiosis.transportCost}</div>
                  <div className="font-bold text-amber-700">€{match.transportCostEur.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 font-sans uppercase">{t.symbiosis.netBenefit}</div>
                  <div className="font-bold text-emerald-700">+€{match.netEconomicBenefitEur.toLocaleString()}</div>
                </div>
              </div>

              {/* Rationale Excerpt */}
              <div className="mt-3 text-xs text-slate-600 space-y-1">
                <div className="font-semibold text-slate-800">{t.symbiosis.whyRecommended}:</div>
                <ul className="list-disc list-inside space-y-0.5 text-[11px] text-slate-600 pl-1">
                  {(lang === 'el' ? match.matchReasons.el : match.matchReasons.en).slice(0, 2).map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
              <button
                onClick={() => setSelectedMatch(match)}
                className="text-xs font-semibold text-slate-700 hover:text-[#0F2B48] underline"
              >
                {t.symbiosis.feasibilityCheck} →
              </button>

              {match.status === 'completed' ? (
                <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded">
                  ✓ {lang === 'el' ? 'Ολοκληρώθηκε' : 'Completed'}
                </span>
              ) : (
                <button
                  onClick={() => handleInitiateExchange(match)}
                  className="px-3.5 py-1.5 bg-[#D97706] text-white text-xs font-bold rounded hover:bg-[#B45309] transition-colors shadow-2xs"
                >
                  {t.symbiosis.initiateExchange}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Feasibility Drawer Modal */}
      {selectedMatch && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-xl w-full border border-slate-200 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-[#0F2B48] text-white p-4 flex items-center justify-between border-b border-[#1A3E61]">
              <h3 className="text-sm font-bold text-white">
                {t.symbiosis.feasibilityCheck}
              </h3>
              <button onClick={() => setSelectedMatch(null)} className="text-slate-300 hover:text-white font-bold">✕</button>
            </div>

            <div className="p-5 space-y-4 text-xs text-slate-700">
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 font-semibold text-amber-900">
                {selectedMatch.supplierOrgName} → {selectedMatch.buyerOrgName}
              </div>

              <div>
                <div className="font-bold text-slate-900 mb-1">{t.symbiosis.whyRecommended}</div>
                <ul className="list-disc list-inside space-y-1 bg-slate-50 p-3 rounded border border-slate-200 text-slate-700">
                  {(lang === 'el' ? selectedMatch.matchReasons.el : selectedMatch.matchReasons.en).map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>

              <div>
                <div className="font-bold text-slate-900 mb-1">{lang === 'el' ? 'Περιορισμοί & Προϋποθέσεις' : 'Constraints & Requirements'}</div>
                <ul className="list-disc list-inside space-y-1 bg-slate-50 p-3 rounded border border-slate-200 text-slate-700">
                  {(lang === 'el' ? selectedMatch.feasibilityConstraints.el : selectedMatch.feasibilityConstraints.en).map((f, i) => (
                    <li key={i}>{f}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="p-3.5 bg-slate-100 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedMatch(null)}
                className="px-4 py-1.5 bg-[#0F2B48] text-white font-bold rounded text-xs"
              >
                {t.actions.close}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
