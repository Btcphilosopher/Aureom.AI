/**
 * KYKLOS (ΚΥΚΛΟΣ) - National Circular Economy Operational Dashboard
 */

import React, { useState, useEffect } from 'react';
import { IndicatorData, GreekRegion, Sector, MaterialCategory, CircularTransaction, Language } from '../types';
import { translations } from '../i18n/translations';
import { GreekMapSVG } from './GreekMapSVG';
import { DataProvenanceModal } from './DataProvenanceModal';
import { kyklosApi } from '../services/api';

interface DashboardViewProps {
  lang: Language;
  onNavigateToTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ lang, onNavigateToTab }) => {
  const t = translations[lang];

  const [indicators, setIndicators] = useState<IndicatorData[]>([]);
  const [transactions, setTransactions] = useState<CircularTransaction[]>([]);
  const [selectedRegion, setSelectedRegion] = useState<GreekRegion | 'all'>('all');
  const [selectedSector, setSelectedSector] = useState<Sector | 'all'>('all');
  const [selectedCategory, setSelectedCategory] = useState<MaterialCategory | 'all'>('all');
  const [selectedIndicatorForModal, setSelectedIndicatorForModal] = useState<IndicatorData | null>(null);

  useEffect(() => {
    loadDashboardData();
  }, [selectedRegion, selectedSector, selectedCategory]);

  const loadDashboardData = async () => {
    const reg = selectedRegion === 'all' ? undefined : selectedRegion;
    const sec = selectedSector === 'all' ? undefined : selectedSector;
    const cat = selectedCategory === 'all' ? undefined : selectedCategory;

    const indData = await kyklosApi.getDashboardIndicators(reg, sec, cat);
    const txData = await kyklosApi.getTransactions();
    setIndicators(indData);
    setTransactions(txData);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Hero Section */}
      <div className="relative rounded-2xl overflow-hidden bg-[#0F2B48] text-white shadow-md border border-[#1A3E61]">
        <div className="absolute inset-0 z-0 opacity-25 mix-blend-overlay">
          <img
            src="/src/assets/images/kyklos_hero_aegean_1792929015218.jpg"
            alt="KYKLOS Industrial Facility"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="relative z-10 p-6 sm:p-8 max-w-4xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#1A3E61] border border-amber-500/40 rounded-full text-amber-400 text-xs font-medium mb-3">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            {lang === 'el' ? 'Εθνικό Επιχειρησιακό Σύστημα' : 'National Operational Platform'}
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2 text-balance">
            {t.dashboard.title}
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed max-w-2xl">
            {t.dashboard.subtitle}
          </p>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 text-xs font-medium">
          {/* Region Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-semibold">{t.dashboard.filterRegion}:</span>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value as GreekRegion | 'all')}
              className="bg-slate-50 border border-slate-300 rounded-md px-2.5 py-1.5 font-medium text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              <option value="all">{t.dashboard.allRegions}</option>
              <option value="attica">Αττική / Attica</option>
              <option value="central_macedonia">Κεντρική Μακεδονία / Central Macedonia</option>
              <option value="peloponnese">Πελοπόννησος / Peloponnese</option>
              <option value="thessaly">Θεσσαλία / Thessaly</option>
              <option value="western_greece">Δυτική Ελλάδα / Western Greece</option>
              <option value="central_greece">Στερεά Ελλάδα / Central Greece</option>
              <option value="crete">Κρήτη / Crete</option>
              <option value="western_macedonia">Δυτική Μακεδονία / Western Macedonia</option>
            </select>
          </div>

          {/* Sector Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-semibold">{t.dashboard.filterSector}:</span>
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value as Sector | 'all')}
              className="bg-slate-50 border border-slate-300 rounded-md px-2.5 py-1.5 font-medium text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
            >
              <option value="all">{t.dashboard.allSectors}</option>
              <option value="manufacturing">Βιομηχανία / Manufacturing</option>
              <option value="agriculture_food">Γεωργία & Τρόφιμα / Agriculture</option>
              <option value="construction_demolition">Κατασκευές / Construction</option>
              <option value="utilities_water_energy">Ενέργεια & Νερό / Utilities</option>
              <option value="waste_recycling">Ανακύκλωση / Recycling</option>
            </select>
          </div>
        </div>

        {(selectedRegion !== 'all' || selectedSector !== 'all') && (
          <button
            onClick={() => {
              setSelectedRegion('all');
              setSelectedSector('all');
              setSelectedCategory('all');
            }}
            className="text-xs font-semibold text-amber-700 hover:underline"
          >
            {t.actions.reset}
          </button>
        )}
      </div>

      {/* Indicators Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700">
            {t.dashboard.indicatorsHeading}
          </h2>
          <span className="text-xs text-slate-500">
            {t.dashboard.dataNote}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {indicators.map((ind) => (
            <div
              key={ind.id}
              onClick={() => setSelectedIndicatorForModal(ind)}
              className="kyklos-card p-4 rounded-xl cursor-pointer hover:border-amber-400 hover:shadow-md transition-all group"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="text-xs font-semibold text-slate-600 line-clamp-1 group-hover:text-[#0F2B48]">
                  {lang === 'el' ? ind.labelEl : ind.labelEn}
                </span>
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 shrink-0">
                  +{ind.trendPct}%
                </span>
              </div>

              <div className="text-2xl font-black font-mono tracking-tight text-[#0F2B48] mb-1 tabular-nums">
                {ind.formattedValue}
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100 mt-2">
                <span>{ind.timePeriod}</span>
                <span className="text-amber-700 font-medium hover:underline">
                  {lang === 'el' ? 'Προέλευση & Ορισμός →' : 'Provenance →'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Split: Greek Map & Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left: Greek Map SVG (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-xl p-4 border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#0F2B48]">
              {t.dashboard.mapHeading}
            </h3>
            <span className="text-xs text-slate-500 font-mono">13 {lang === 'el' ? 'Περιφέρειες' : 'Regions'}</span>
          </div>

          <GreekMapSVG
            selectedRegion={selectedRegion}
            onSelectRegion={(reg) => setSelectedRegion(reg)}
            lang={lang}
          />
        </div>

        {/* Right: Recent Completed Transactions (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-xl p-4 border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="text-sm font-bold text-[#0F2B48]">
              {t.dashboard.recentTransactions}
            </h3>
            <button
              onClick={() => onNavigateToTab('symbiosis')}
              className="text-xs font-semibold text-amber-700 hover:underline"
            >
              {lang === 'el' ? 'Όλες οι Συζεύξεις →' : 'All Symbiosis →'}
            </button>
          </div>

          <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
            {transactions.map((tx) => (
              <div key={tx.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5">
                <div className="flex items-center justify-between font-semibold text-slate-900">
                  <span className="truncate max-w-[200px]">{tx.materialTitle}</span>
                  <span className="font-mono text-emerald-700 font-bold">
                    +€{tx.netEconomicBenefitEur.toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-500 text-[11px]">
                  <span>{tx.quantity} {tx.unit} · {tx.region.toUpperCase()}</span>
                  <span className="font-mono text-slate-600">{tx.completionDate}</span>
                </div>
                <div className="flex items-center gap-2 pt-1 border-t border-slate-200/60 text-[10px] text-slate-600">
                  <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded font-medium">
                    ✓ {lang === 'el' ? 'Επαληθευμένο' : 'Verified'}
                  </span>
                  <span>CO₂e Avoided: {tx.co2eAvoidedTonnes}t</span>
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900 space-y-1">
            <div className="font-bold">{lang === 'el' ? 'Οικονομική Αρχή KYKLOS' : 'KYKLOS Core Principle'}</div>
            <p className="text-[11px] leading-relaxed text-amber-800">
              {lang === 'el'
                ? 'Η κυκλική οικονομία είναι οικονομικό σύστημα, όχι απλά εκστρατεία ανακύκλωσης. Κάθε καταχωρημένη συναλλαγή βασίζεται σε ποσοτικά δεδομένα υλικών, τιμών και κόστους logistics.'
                : 'The circular economy is an economic system. Every logged exchange reflects precise material quantities, prices, transport costs, and measurable value creation.'}
            </p>
          </div>
        </div>

      </div>

      {/* Data Provenance Modal */}
      <DataProvenanceModal
        indicator={selectedIndicatorForModal}
        lang={lang}
        onClose={() => setSelectedIndicatorForModal(null)}
      />
    </div>
  );
};
