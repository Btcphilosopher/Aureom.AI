package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TerminalColorScheme = darkColorScheme(
    primary = TerminalCyan,
    onPrimary = TerminalBg,
    primaryContainer = TerminalDarkBlue,
    onPrimaryContainer = TerminalCyan,
    secondary = TerminalGold,
    onSecondary = TerminalBg,
    secondaryContainer = TerminalMutedAmber,
    onSecondaryContainer = TerminalAmber,
    tertiary = TermGreen,
    onTertiary = TerminalBg,
    background = TerminalBg,
    onBackground = TermWhite,
    surface = TerminalSurface,
    onSurface = TermOffWhite,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TermGray,
    surfaceTint = TerminalCyan,
    outline = TerminalBorder,
    outlineVariant = TerminalBorderSubtle,
    error = TermRed,
    onError = TermWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
