package com.example.domain.model

data class Constituent(
    val securityId: String,
    val ticker: String,
    val companyName: String,
    val sharesMillion: Double,
    val floatFactor: Double, // IWF (Investable Weight Factor 0.0 to 1.0)
    val price: Double,
    val previousClose: Double,
    val sector: SectorGICS,
    val industry: String,
    val primaryExchange: ExchangeVenue,
    val dailyReturn: Double = ((price - previousClose) / previousClose) * 100.0,
    val weight: Double = 0.0, // calculated dynamically
    val contribution: Double = 0.0, // weight * dailyReturn / 100.0
    val isEligible: Boolean = true,
    val isRecentAddition: Boolean = false,
    val isRecentDeletion: Boolean = false,
    val beta: Double = 1.0,
    val peRatio: Double = 22.0,
    val roePct: Double = 18.0,
    val dividendYieldPct: Double = 1.5,
    val momentumScore: Double = 0.0
) {
    val floatAdjustedSharesMillion: Double
        get() = sharesMillion * floatFactor

    val marketCapBillions: Double
        get() = (sharesMillion * price) / 1000.0

    val floatMarketCapBillions: Double
        get() = (floatAdjustedSharesMillion * price) / 1000.0
}

data class SectorBreakdown(
    val sector: SectorGICS,
    val weightPercent: Double,
    val returnPercent: Double,
    val contributionPercent: Double,
    val constituentCount: Int,
    val marketCapTrillions: Double
)

data class MarketBreadthData(
    val advancers: Int,
    val decliners: Int,
    val unchanged: Int,
    val adRatio: Double,
    val adLine: Int,
    val newHighs52W: Int,
    val newLows52W: Int,
    val pctAbove50Dma: Double,
    val pctAbove200Dma: Double,
    val equalWeightReturnPct: Double,
    val capWeightReturnPct: Double,
    val divergenceSpreadPct: Double = equalWeightReturnPct - capWeightReturnPct
)

data class CorporateActionEvent(
    val eventId: String,
    val ticker: String,
    val companyName: String,
    val type: CorporateActionType,
    val effectiveDate: String,
    val description: String,
    val oldValue: String,
    val newValue: String,
    val oldDivisor: Double,
    val newDivisor: Double,
    val indexImpactPoints: Double,
    val status: String = "AUDITED_SETTLED",
    val provenance: DataProvenance = DataProvenance.SYNTHETIC
)

data class HistoricalPoint(
    val timestamp: Long,
    val dateStr: String,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long,
    val divisor: Double
)

data class IndexAttributionItem(
    val category: String, // "SECTOR", "SECURITY_CONTRIBUTOR", "SECURITY_DETRACTOR", "STYLE_FACTOR"
    val name: String,
    val weightPct: Double,
    val returnPct: Double,
    val contributionPct: Double,
    val details: String = ""
)

data class RiskMetrics(
    val annualizedVolPct: Double,
    val sharpeRatio: Double,
    val sortinoRatio: Double,
    val maxDrawdownPct: Double,
    val beta: Double,
    val trackingErrorPct: Double,
    val var95DailyPct: Double,
    val var99DailyPct: Double,
    val cvar95DailyPct: Double,
    val herfindahlIndex: Double, // HHI concentration (e.g. 0.024)
    val effectiveConstituentCount: Double // 1 / sum(w^2)
)

data class IndexDefinition(
    val indexId: String,
    val ticker: String,
    val name: String,
    val family: IndexFamily,
    val provider: String,
    val weightingMethod: WeightingMethod,
    val currentLevel: Double,
    val previousClose: Double,
    val changePoints: Double = currentLevel - previousClose,
    val changePercent: Double = if (previousClose > 0) ((currentLevel - previousClose) / previousClose) * 100.0 else 0.0,
    val divisor: Double,
    val constituentCount: Int,
    val totalMarketCapTrillions: Double,
    val baseDate: String = "1957-03-04",
    val baseValue: Double = 10.0,
    val methodologyVersion: String = "v2026.3.1",
    val calculationFrequency: CalculationFrequency = CalculationFrequency.FREQ_1S,
    val reviewSchedule: ReviewSchedule = ReviewSchedule.QUARTERLY,
    val provenance: DataProvenance = DataProvenance.SYNTHETIC,
    val description: String,
    val constituents: List<Constituent> = emptyList(),
    val sectors: List<SectorBreakdown> = emptyList(),
    val breadth: MarketBreadthData? = null,
    val riskMetrics: RiskMetrics? = null,
    val sparkline: List<Double> = emptyList(),
    val intradayPoints: List<Pair<String, Double>> = emptyList()
)
