package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CorporateActionEvent
import com.example.domain.model.IndexDefinition
import com.example.domain.model.TerminalAlert
import com.example.ui.TerminalTab
import com.example.ui.components.MetricBadge
import com.example.ui.components.SectorWaterfallChart
import com.example.ui.theme.TermDarkGray
import com.example.ui.theme.TermGray
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermOffWhite
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBlue
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalDarkBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import java.util.Locale

@Composable
fun MarketMonitorScreen(
    indices: Map<String, IndexDefinition>,
    alerts: List<TerminalAlert>,
    auditedActions: List<CorporateActionEvent>,
    onSelectIndex: (String) -> Unit,
    onNavigateToTab: (TerminalTab) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBg)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Live Index Ticker Cards Grid
        item {
            Text(
                text = "INSTITUTIONAL U.S. INDEX BENCHMARK BOARD",
                style = MaterialTheme.typography.labelLarge,
                color = TerminalCyan,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                indices.values.chunked(2).forEach { rowIndices ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        rowIndices.forEach { indexDef ->
                            val isPos = indexDef.changePercent >= 0
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        onSelectIndex(indexDef.ticker)
                                        onNavigateToTab(TerminalTab.DETAIL)
                                    }
                                    .testTag("index_card_${indexDef.ticker}"),
                                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                                shape = RoundedCornerShape(6.dp),
                                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = indexDef.ticker,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = TerminalCyan
                                        )
                                        Text(
                                            text = indexDef.weightingMethod.name.take(12),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TermGray,
                                            fontSize = 9.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = String.format(Locale.US, "%,.2f", indexDef.currentLevel),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = TermWhite
                                    )

                                    Spacer(modifier = Modifier.height(2.dp))

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (isPos) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                            contentDescription = null,
                                            tint = if (isPos) TermGreen else TermRed,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(
                                            text = "${if (isPos) "+" else ""}${String.format(Locale.US, "%.2f", indexDef.changePoints)} (${if (isPos) "+" else ""}${String.format(Locale.US, "%.2f", indexDef.changePercent)}%)",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            color = if (isPos) TermGreen else TermRed
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Divisor: ${String.format(Locale.US, "%.3f", indexDef.divisor)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TermGray,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Text(
                                            text = "Cap: $${String.format(Locale.US, "%.1f", indexDef.totalMarketCapTrillions)}T",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TerminalGold,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Market Breadth Summary Metrics
        item {
            val sp500 = indices["SP500"]
            val b = sp500?.breadth
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "S&P 500 INTRADAY MARKET BREADTH & SPREAD",
                    style = MaterialTheme.typography.labelLarge,
                    color = TerminalGold,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MetricBadge(
                        label = "Adv / Dec Ratio",
                        value = "${b?.advancers ?: 0} / ${b?.decliners ?: 0}",
                        delta = b?.adRatio,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBadge(
                        label = "Above 200 DMA",
                        value = "${b?.pctAbove200Dma ?: 74.2}%",
                        modifier = Modifier.weight(1f)
                    )
                    MetricBadge(
                        label = "Equal vs Cap",
                        value = "${if ((b?.divergenceSpreadPct ?: 0.0) >= 0) "+" else ""}${String.format(Locale.US, "%.2f", b?.divergenceSpreadPct ?: 0.0)}%",
                        delta = b?.divergenceSpreadPct,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 3. Sector Waterfall Attribution
        item {
            indices["SP500"]?.sectors?.let { sectors ->
                SectorWaterfallChart(sectors = sectors)
            }
        }

        // 4. Top Movers & Contributors (Why it moved)
        item {
            val sp500 = indices["SP500"]
            val constituents = sp500?.constituents ?: emptyList()
            val topContributors = constituents.sortedByDescending { it.contribution }.take(4)
            val topDetractors = constituents.sortedBy { it.contribution }.take(4)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Top Contributors
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(TerminalSurface, RoundedCornerShape(6.dp))
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "TOP CONTRIBUTORS (+)",
                        style = MaterialTheme.typography.labelMedium,
                        color = TermGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    topContributors.forEach { c ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = c.ticker,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = TermWhite
                            )
                            Text(
                                text = "+${String.format(Locale.US, "%.3f", c.contribution)}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = TermGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Top Detractors
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(TerminalSurface, RoundedCornerShape(6.dp))
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "TOP DETRACTORS (-)",
                        style = MaterialTheme.typography.labelMedium,
                        color = TermRed,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    topDetractors.forEach { c ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = c.ticker,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = TermWhite
                            )
                            Text(
                                text = "${String.format(Locale.US, "%.3f", c.contribution)}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = TermRed,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 5. Audited Corporate Actions Feed
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AUDITED CORPORATE ACTIONS & DIVISOR LOG",
                        style = MaterialTheme.typography.labelLarge,
                        color = TerminalCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "CONTINUITY PRESERVED",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermGreen,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                auditedActions.take(3).forEach { act ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${act.ticker} • ${act.type.label}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TerminalGold
                                )
                                Text(
                                    text = act.effectiveDate,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TermGray,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = act.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = TermOffWhite,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
