package com.example.ui

enum class TerminalTab(val label: String, val shortcut: String) {
    MONITOR("MARKET MONITOR", "M"),
    DETAIL("INDEX DETAIL", "I"),
    COMPARISON("COMPARISON & OVERLAP", "C"),
    RECONSTITUTION("RECONSTITUTION LAB", "R"),
    SCENARIOS("SCENARIO LAB", "S"),
    MONTE_CARLO("MONTE CARLO QUANT", "Q"),
    CUSTOM_BUILDER("CUSTOM INDEX LAB", "B"),
    API_PORTAL("API & SDK CONSOLE", "A")
}

enum class DetailSubTab(val label: String) {
    OVERVIEW("Overview & Level"),
    CONSTITUENTS("Constituent Master"),
    SECTORS("Sector Allocations"),
    ATTRIBUTION("Attribution & Drivers"),
    BREADTH("Market Breadth"),
    RISK("Risk & Concentration"),
    DIVISOR_AUDIT("Divisor & Actions"),
    METHODOLOGY("Methodology Rules")
}

enum class ConstituentSortBy {
    WEIGHT,
    TICKER,
    PRICE,
    DAILY_RETURN,
    CONTRIBUTION,
    FLOAT_CAP
}
