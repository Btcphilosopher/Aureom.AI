package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.RemoveCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ExchangeVenue
import com.example.domain.model.IndexDefinition
import com.example.domain.model.RebalanceSimulationResult
import com.example.ui.components.MetricBadge
import com.example.ui.theme.TermDarkGray
import com.example.ui.theme.TermGray
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermOffWhite
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalDarkBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalMutedAmber
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import java.util.Locale

@Composable
fun ReconstitutionScreen(
    rebalanceResult: RebalanceSimulationResult?,
    allIndices: Map<String, IndexDefinition>,
    selectedTicker: String,
    onSelectIndex: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (rebalanceResult == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select an index to simulate reconstitution.", color = TermGray)
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBg)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Reconstitution Header & Selector
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INDEX RECONSTITUTION & REBALANCE SIMULATOR",
                        style = MaterialTheme.typography.labelLarge,
                        color = TerminalCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "SIMULATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = TerminalGold,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(TerminalMutedAmber, RoundedCornerShape(3.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "TARGET RECONSTITUTION INDEX:",
                    style = MaterialTheme.typography.labelSmall,
                    color = TermGray
                )
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("RUSSELL2000", "SP500", "SPMID400", "NASDAQ100").forEach { t ->
                        val isSel = t == selectedTicker
                        Box(
                            modifier = Modifier
                                .background(if (isSel) TerminalCyan else TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                                .clickable { onSelectIndex(t) }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .testTag("rebal_select_$t")
                        ) {
                            Text(
                                text = t,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) TerminalBg else TermOffWhite
                            )
                        }
                    }
                }
            }
        }

        // 2. Projected Turnover & Calendar Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricBadge(
                    label = "Projected Turnover",
                    value = "${String.format(Locale.US, "%.2f", rebalanceResult.expectedTurnoverPct)}%",
                    modifier = Modifier.weight(1f)
                )
                MetricBadge(
                    label = "Est. Flow Volume",
                    value = "$${String.format(Locale.US, "%.1f", rebalanceResult.expectedTurnoverBillions)}B",
                    modifier = Modifier.weight(1f)
                )
                MetricBadge(
                    label = "Tracking Shift",
                    value = "${String.format(Locale.US, "%.2f", rebalanceResult.projectedTrackingErrorPct * 100)} bps",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 3. Rebalance Calendar & Schedule
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "RECONSTITUTION TIMETABLE & BUFFER RULES",
                        style = MaterialTheme.typography.labelMedium,
                        color = TerminalGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Preliminary Ranking Date:", style = MaterialTheme.typography.bodySmall, color = TermGray)
                        Text(rebalanceResult.reviewDate, style = MaterialTheme.typography.bodySmall, color = TermWhite, fontFamily = FontFamily.Monospace)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Effective Post-Close Settlement:", style = MaterialTheme.typography.bodySmall, color = TermGray)
                        Text(rebalanceResult.effectiveDate, style = MaterialTheme.typography.bodySmall, color = TermGreen, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Exchange Eligibility:", style = MaterialTheme.typography.bodySmall, color = TermGray)
                        Text("NYSE, NASDAQ, CBOE, TXSE (Continuous)", style = MaterialTheme.typography.bodySmall, color = TerminalCyan)
                    }
                }
            }
        }

        // 4. Expected Additions List
        item {
            Text(
                text = "EXPECTED CONSTITUENT ADDITIONS (+)",
                style = MaterialTheme.typography.labelMedium,
                color = TermGreen,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(rebalanceResult.additions) { c ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AddCircle,
                            contentDescription = null,
                            tint = TermGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(c.ticker, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TermWhite)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = c.primaryExchange.code,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (c.primaryExchange == ExchangeVenue.TXSE) TerminalGold else TermGray,
                                    fontSize = 8.sp,
                                    fontWeight = if (c.primaryExchange == ExchangeVenue.TXSE) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                            Text(c.companyName, style = MaterialTheme.typography.bodySmall, color = TermGray, fontSize = 10.sp)
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("Float Cap: $${String.format(Locale.US, "%.1f", c.floatMarketCapBillions)}B", style = MaterialTheme.typography.labelSmall, color = TerminalCyan, fontFamily = FontFamily.Monospace)
                        Text(c.sector.sectorName, style = MaterialTheme.typography.labelSmall, color = TermGray, fontSize = 9.sp)
                    }
                }
            }
        }

        // 5. Expected Deletions List
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "EXPECTED CONSTITUENT DELETIONS (-)",
                style = MaterialTheme.typography.labelMedium,
                color = TermRed,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(rebalanceResult.deletions) { c ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RemoveCircle,
                            contentDescription = null,
                            tint = TermRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(c.ticker, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TermWhite)
                            Text(c.companyName, style = MaterialTheme.typography.bodySmall, color = TermGray, fontSize = 10.sp)
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("Current W: ${String.format(Locale.US, "%.2f", c.weight)}%", style = MaterialTheme.typography.labelSmall, color = TerminalGold, fontFamily = FontFamily.Monospace)
                        Text(c.sector.sectorName, style = MaterialTheme.typography.labelSmall, color = TermGray, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}
