package com.example.domain.model

data class ConstituentOverlapItem(
    val ticker: String,
    val companyName: String,
    val weightA: Double,
    val weightB: Double,
    val minWeightOverlap: Double = Math.min(weightA, weightB),
    val sector: SectorGICS
)

data class SectorDivergenceItem(
    val sector: SectorGICS,
    val weightA: Double,
    val weightB: Double,
    val differencePct: Double = weightA - weightB
)

data class OverlapResult(
    val indexTickerA: String,
    val indexTickerB: String,
    val sharedCount: Int,
    val uniqueCountA: Int,
    val uniqueCountB: Int,
    val totalWeightOverlapPct: Double,
    val topSharedItems: List<ConstituentOverlapItem>,
    val sectorDivergences: List<SectorDivergenceItem>,
    val correlation1Y: Double,
    val trackingDifference1Y: Double
)

data class RebalanceSimulationResult(
    val indexTicker: String,
    val reviewDate: String,
    val effectiveDate: String,
    val expectedTurnoverPct: Double,
    val expectedTurnoverBillions: Double,
    val additions: List<Constituent>,
    val deletions: List<Constituent>,
    val topWeightIncreases: List<Pair<String, Double>>,
    val topWeightDecreases: List<Pair<String, Double>>,
    val sectorWeightShifts: List<SectorDivergenceItem>,
    val projectedTrackingErrorPct: Double,
    val notes: String
)

data class ScenarioStressResult(
    val scenarioName: String,
    val targetIndexTicker: String,
    val baselineLevel: Double,
    val stressedLevel: Double,
    val deltaPoints: Double = stressedLevel - baselineLevel,
    val deltaPercent: Double = if (baselineLevel > 0) ((stressedLevel - baselineLevel) / baselineLevel) * 100.0 else 0.0,
    val techShockPct: Double = 0.0,
    val finShockPct: Double = 0.0,
    val ratesShockBps: Double = 0.0,
    val energyShockPct: Double = 0.0,
    val usdShockPct: Double = 0.0,
    val sectorImpacts: List<Pair<SectorGICS, Double>>,
    val topPositiveDrivers: List<Pair<String, Double>>,
    val topNegativeDrivers: List<Pair<String, Double>>
)

data class MonteCarloResult(
    val indexTicker: String,
    val initialLevel: Double,
    val numSimulations: Int = 10000,
    val horizonDays: Int = 252,
    val medianTerminalLevel: Double,
    val p95TerminalLevel: Double,
    val p05TerminalLevel: Double,
    val var95Pct: Double,
    val var99Pct: Double,
    val cvar95Pct: Double,
    val probDrawdownExceeds10Pct: Double,
    val probDrawdownExceeds20Pct: Double,
    // Step-by-step percentile bands across horizon: key is step (0..20), value is percentile price
    val p10Path: List<Double>,
    val p25Path: List<Double>,
    val p50Path: List<Double>,
    val p75Path: List<Double>,
    val p90Path: List<Double>,
    val terminalDistributionBuckets: List<Pair<Double, Int>> // (bucketPrice, frequency)
)

data class CustomIndexConfig(
    val customId: String,
    val ticker: String,
    val name: String,
    val baseUniverse: String = "US_ALL_EQUITY",
    val weightingMethod: WeightingMethod = WeightingMethod.FACTOR_WEIGHTED,
    val primaryFactor: FactorType = FactorType.QUALITY,
    val targetConstituentCount: Int = 100,
    val maxWeightCapPct: Double = 5.0,
    val minimumFloatCapBillions: Double = 5.0,
    val excludeSectors: Set<SectorGICS> = emptySet(),
    val calculationDivisor: Double = 1250.45,
    val calculatedLevel: Double = 2450.80,
    val backtestedReturn1YPct: Double = 18.4,
    val backtestedSharpe: Double = 1.34,
    val backtestedMaxDrawdownPct: Double = -11.2,
    val constituents: List<Constituent> = emptyList()
)

data class ApiEndpointDoc(
    val method: String,
    val path: String,
    val category: String,
    val title: String,
    val description: String,
    val sampleRequest: String,
    val sampleResponseJson: String,
    val latencyMs: Int = 12
)

data class TerminalAlert(
    val alertId: String,
    val timestampStr: String,
    val level: String, // "INFO", "WARNING", "ACTION", "DIVISOR"
    val category: String, // "REBALANCE", "DIVISOR_CHANGE", "DISPERSION", "CORPORATE_ACTION"
    val title: String,
    val details: String,
    val affectedTicker: String
)
