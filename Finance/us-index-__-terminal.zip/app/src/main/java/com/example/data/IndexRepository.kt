package com.example.data

import com.example.calculation.IndexCalculationEngine
import com.example.domain.model.CalculationFrequency
import com.example.domain.model.Constituent
import com.example.domain.model.CustomIndexConfig
import com.example.domain.model.DataProvenance
import com.example.domain.model.FactorType
import com.example.domain.model.HistoricalPoint
import com.example.domain.model.IndexDefinition
import com.example.domain.model.IndexFamily
import com.example.domain.model.ReviewSchedule
import com.example.domain.model.SectorGICS
import com.example.domain.model.TerminalAlert
import com.example.domain.model.WeightingMethod
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random

class IndexRepository(private val scope: CoroutineScope) {

    private val rng = Random(12345)
    private val _indices = MutableStateFlow<Map<String, IndexDefinition>>(emptyMap())
    val indices: StateFlow<Map<String, IndexDefinition>> = _indices.asStateFlow()

    private val _customIndices = MutableStateFlow<List<CustomIndexConfig>>(emptyList())
    val customIndices: StateFlow<List<CustomIndexConfig>> = _customIndices.asStateFlow()

    private val _alerts = MutableStateFlow<List<TerminalAlert>>(emptyList())
    val alerts: StateFlow<List<TerminalAlert>> = _alerts.asStateFlow()

    private val _tickCounter = MutableStateFlow(0L)
    val tickCounter: StateFlow<Long> = _tickCounter.asStateFlow()

    private var activeConstituents: MutableList<Constituent> = SyntheticMarketUniverse.getAllSecurities().toMutableList()

    init {
        initializeIndices()
        initializeAlerts()
        startLiveSimulationEngine()
    }

    private fun initializeIndices() {
        val allSecurities = activeConstituents

        // 1. S&P 500 Representation
        val sp500 = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-SP500",
            ticker = "SP500",
            name = "S&P 500 Index (Synthetic Model)",
            family = IndexFamily.SPDJI,
            provider = "S&P Dow Jones Indices",
            weightingMethod = WeightingMethod.CAP_WEIGHTED,
            divisor = 8421.458,
            rawConstituents = allSecurities.take(28),
            baseDate = "1957-03-04",
            baseValue = 10.0,
            description = "The leading benchmark of U.S. large-cap equity covering 500 leading companies with 2026 TXSE inclusion rules enabled.",
            methodologyVersion = "v2026.4.1",
            provenance = DataProvenance.SYNTHETIC,
            previousClose = 6012.40
        )

        // 2. NASDAQ-100
        val nasdaqSecurities = allSecurities.filter {
            it.primaryExchange.code in listOf("NASDAQ", "NTX") || it.sector == SectorGICS.INFORMATION_TECHNOLOGY
        }
        val nasdaq100 = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-NDX100",
            ticker = "NASDAQ100",
            name = "Nasdaq-100 Index (Modified Cap)",
            family = IndexFamily.NASDAQ,
            provider = "Nasdaq Global Indexes",
            weightingMethod = WeightingMethod.MODIFIED_CAP,
            divisor = 2125.80,
            rawConstituents = nasdaqSecurities,
            baseDate = "1985-01-31",
            baseValue = 250.0,
            description = "Top 100 non-financial large cap innovators on Nasdaq with modified quarterly tier weight capping.",
            methodologyVersion = "v2026.2.0",
            provenance = DataProvenance.SYNTHETIC,
            previousClose = 21450.80
        )

        // 3. Dow Jones Industrial Average (Price-Weighted)
        val dowSecurities = allSecurities.filter { it.ticker in listOf("AAPL", "MSFT", "NVDA", "AMZN", "JPM", "V", "UNH", "CAT", "HD", "MCD", "DIS", "JNJ", "PG", "KO", "WMT", "BA", "HON", "CRM", "GS", "CVX") }
        val dow30 = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-DJIA",
            ticker = "DOW30",
            name = "Dow Jones Industrial Average",
            family = IndexFamily.DOW,
            provider = "S&P Dow Jones Indices",
            weightingMethod = WeightingMethod.PRICE_WEIGHTED,
            divisor = 0.1534,
            rawConstituents = dowSecurities,
            baseDate = "1896-05-26",
            baseValue = 40.94,
            description = "Price-weighted measure of 30 prominent blue-chip U.S. corporate giants.",
            methodologyVersion = "v2026.1.0",
            provenance = DataProvenance.SYNTHETIC,
            previousClose = 43910.20
        )

        // 4. Russell 2000 (Small Cap)
        val r2kSecurities = allSecurities.filter { it.isRecentAddition || it.marketCapBillions < 150.0 }
        val r2k = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-RUT2000",
            ticker = "RUSSELL2000",
            name = "Russell 2000 Small-Cap Index",
            family = IndexFamily.RUSSELL,
            provider = "FTSE Russell",
            weightingMethod = WeightingMethod.CAP_WEIGHTED,
            divisor = 1420.10,
            rawConstituents = r2kSecurities,
            baseDate = "1984-01-01",
            baseValue = 135.0,
            description = "The premier barometer of American small-cap equities with June/December reconstitution models.",
            methodologyVersion = "v2026.3.0",
            provenance = DataProvenance.SYNTHETIC,
            previousClose = 2280.40
        )

        // 5. S&P MidCap 400
        val midSecurities = allSecurities.filter { it.marketCapBillions in 10.0..250.0 }
        val mid400 = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-MID400",
            ticker = "SPMID400",
            name = "S&P MidCap 400 Index",
            family = IndexFamily.SPDJI,
            provider = "S&P Dow Jones Indices",
            weightingMethod = WeightingMethod.CAP_WEIGHTED,
            divisor = 2310.50,
            rawConstituents = midSecurities,
            baseDate = "1991-06-19",
            baseValue = 100.0,
            description = "Distinct mid-sized U.S. corporations reflecting the core domestic growth engine.",
            methodologyVersion = "v2026.1.0",
            provenance = DataProvenance.SYNTHETIC,
            previousClose = 3180.60
        )

        // 6. AIS Quality 100 (Factor Index)
        val qualitySecurities = allSecurities.filter { it.roePct > 20.0 }
        val quality100 = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-AIS-Q100",
            ticker = "USQUALITY100",
            name = "AIS US High-Quality 100 Index",
            family = IndexFamily.AIS_QUANT,
            provider = "American Index Systems",
            weightingMethod = WeightingMethod.FACTOR_WEIGHTED,
            divisor = 980.20,
            rawConstituents = qualitySecurities,
            baseDate = "2015-01-01",
            baseValue = 1000.0,
            description = "Quantitative factor index targeting high Return on Equity, low leverage, and earnings stability.",
            methodologyVersion = "v2026.2.0",
            provenance = DataProvenance.SYNTHETIC,
            previousClose = 2640.10
        )

        // 7. AIS AI & Semi Thematic 100
        val aiSecurities = allSecurities.filter {
            it.ticker in listOf("NVDA", "AVGO", "MSFT", "AMD", "QCOM", "PLTR", "APP", "TXROB", "NTXAI", "SMCI", "ORCL")
        }
        val ai100 = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-AIS-AI100",
            ticker = "USAI100",
            name = "AIS Next-Gen AI & Silicon 100",
            family = IndexFamily.AIS_QUANT,
            provider = "American Index Systems",
            weightingMethod = WeightingMethod.CAP_WEIGHTED,
            divisor = 340.20,
            rawConstituents = aiSecurities,
            baseDate = "2023-01-01",
            baseValue = 1000.0,
            description = "Pure-play thematic index tracking the full AI infrastructure stack, custom silicon, and robotics.",
            methodologyVersion = "v2026.3.0",
            provenance = DataProvenance.SYNTHETIC,
            previousClose = 3890.50
        )

        // 8. Total US Market (Broad Composite)
        val usTotal = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-USTOTAL",
            ticker = "USTOTAL",
            name = "AIS Broad US Total Market Index",
            family = IndexFamily.WILSHIRE,
            provider = "American Index Systems",
            weightingMethod = WeightingMethod.CAP_WEIGHTED,
            divisor = 14200.0,
            rawConstituents = allSecurities,
            baseDate = "1970-12-31",
            baseValue = 100.0,
            description = "Exhaustive representation of investable U.S. equities across all cap tiers and trading venues.",
            methodologyVersion = "v2026.4.0",
            provenance = DataProvenance.SYNTHETIC,
            previousClose = 58240.10
        )

        _indices.value = mapOf(
            "SP500" to sp500,
            "NASDAQ100" to nasdaq100,
            "DOW30" to dow30,
            "RUSSELL2000" to r2k,
            "SPMID400" to mid400,
            "USQUALITY100" to quality100,
            "USAI100" to ai100,
            "USTOTAL" to usTotal
        )
    }

    private fun initializeAlerts() {
        _alerts.value = listOf(
            TerminalAlert(
                alertId = "ALT-2026-904",
                timestampStr = "14:28:10 ET",
                level = "ACTION",
                category = "REBALANCE",
                title = "Russell 2000 Rank Date Finalized",
                details = "Preliminary reconstitution addition list published with 42 new qualifying small caps including TXSE continuous listings.",
                affectedTicker = "RUSSELL2000"
            ),
            TerminalAlert(
                alertId = "ALT-2026-903",
                timestampStr = "13:45:00 ET",
                level = "DIVISOR",
                category = "DIVISOR_CHANGE",
                title = "S&P 500 Divisor Settlement Audit",
                details = "Divisor successfully updated for buyback share retirement. Price continuity preserved without drift.",
                affectedTicker = "SP500"
            ),
            TerminalAlert(
                alertId = "ALT-2026-902",
                timestampStr = "11:15:22 ET",
                level = "INFO",
                category = "DISPERSION",
                title = "Equal Weight vs Cap Weight Spread Widening",
                details = "Equal weight outperforming cap weight by +42 bps intraday on strong regional & industrial breadth.",
                affectedTicker = "SP500"
            )
        )
    }

    private fun startLiveSimulationEngine() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(1200L) // 1.2s continuous simulation cycle
                _tickCounter.value += 1

                // Apply slight random walk to a few constituents
                val updatedConstituents = activeConstituents.map { c ->
                    val delta = (rng.nextGaussian() * 0.08) // 0.08% std deviation
                    val newPrice = (c.price * (1.0 + delta / 100.0)).coerceAtLeast(1.0)
                    c.copy(price = String.format(Locale.US, "%.2f", newPrice).toDouble())
                }
                activeConstituents = updatedConstituents.toMutableList()

                // Recalculate all registered indices with updated prices
                val currentMap = _indices.value.toMutableMap()
                currentMap.keys.forEach { ticker ->
                    val oldDef = currentMap[ticker] ?: return@forEach
                    val filteredSecurities = when (ticker) {
                        "DOW30" -> updatedConstituents.filter { it.ticker in listOf("AAPL", "MSFT", "NVDA", "AMZN", "JPM", "V", "UNH", "CAT", "HD", "MCD", "DIS", "JNJ", "PG", "KO", "WMT", "BA", "HON", "CRM", "GS", "CVX") }
                        "NASDAQ100" -> updatedConstituents.filter { it.primaryExchange.code in listOf("NASDAQ", "NTX") || it.sector == SectorGICS.INFORMATION_TECHNOLOGY }
                        "RUSSELL2000" -> updatedConstituents.filter { it.isRecentAddition || it.marketCapBillions < 150.0 }
                        "SPMID400" -> updatedConstituents.filter { it.marketCapBillions in 10.0..250.0 }
                        "USQUALITY100" -> updatedConstituents.filter { it.roePct > 20.0 }
                        "USAI100" -> updatedConstituents.filter { it.ticker in listOf("NVDA", "AVGO", "MSFT", "AMD", "QCOM", "PLTR", "APP", "TXROB", "NTXAI", "SMCI", "ORCL") }
                        "USTOTAL" -> updatedConstituents
                        else -> updatedConstituents.take(28)
                    }

                    val recalculated = IndexCalculationEngine.computeIndexState(
                        indexId = oldDef.indexId,
                        ticker = oldDef.ticker,
                        name = oldDef.name,
                        family = oldDef.family,
                        provider = oldDef.provider,
                        weightingMethod = oldDef.weightingMethod,
                        divisor = oldDef.divisor,
                        rawConstituents = filteredSecurities,
                        baseDate = oldDef.baseDate,
                        baseValue = oldDef.baseValue,
                        description = oldDef.description,
                        methodologyVersion = oldDef.methodologyVersion,
                        calculationFrequency = oldDef.calculationFrequency,
                        provenance = oldDef.provenance,
                        previousClose = oldDef.previousClose
                    )
                    currentMap[ticker] = recalculated
                }
                _indices.value = currentMap
            }
        }
    }

    fun addCustomIndex(config: CustomIndexConfig) {
        val list = _customIndices.value.toMutableList()
        list.add(config)
        _customIndices.value = list
    }

    fun getHistorical10YPoints(ticker: String): List<HistoricalPoint> {
        val basePrice = when (ticker) {
            "SP500" -> 6042.0
            "NASDAQ100" -> 21540.0
            "DOW30" -> 44100.0
            "RUSSELL2000" -> 2290.0
            else -> 3500.0
        }

        val points = mutableListOf<HistoricalPoint>()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        var level = basePrice * 0.42 // 10 years ago starting level

        for (i in 20 downTo 0) {
            val date = Date(System.currentTimeMillis() - (i * 180L * 86400000L))
            level *= (1.0 + (0.045 + (i % 3) * 0.012))
            points.add(
                HistoricalPoint(
                    timestamp = date.time,
                    dateStr = sdf.format(date),
                    open = level * 0.995,
                    high = level * 1.015,
                    low = level * 0.990,
                    close = level,
                    volume = (3500000000L + (i * 50000000L)),
                    divisor = 8421.0 + (i * 2.1)
                )
            )
        }
        return points
    }
}
