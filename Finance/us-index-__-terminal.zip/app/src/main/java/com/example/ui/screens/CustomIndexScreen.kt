package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CustomIndexConfig
import com.example.domain.model.FactorType
import com.example.domain.model.WeightingMethod
import com.example.ui.components.MetricBadge
import com.example.ui.theme.TermDarkGray
import com.example.ui.theme.TermGray
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermOffWhite
import com.example.ui.theme.TermWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalDarkBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import java.util.Locale

@Composable
fun CustomIndexScreen(
    customIndices: List<CustomIndexConfig>,
    onCreateCustomIndex: (name: String, ticker: String, weighting: WeightingMethod, factor: FactorType, maxCap: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var nameInput by remember { mutableStateOf("US Large Cap Quality 50") }
    var tickerInput by remember { mutableStateOf("USQUAL50") }
    var selectedMethod by remember { mutableStateOf(WeightingMethod.FACTOR_WEIGHTED) }
    var selectedFactor by remember { mutableStateOf(FactorType.QUALITY) }
    var maxWeightCap by remember { mutableStateOf(5.0f) }
    var showSuccessMessage by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBg)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Builder Form Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "CUSTOM INDEX SPECIFICATION & CONSTRUCTION LAB",
                    style = MaterialTheme.typography.labelLarge,
                    color = TerminalCyan,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Name & Ticker Fields
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Index Name", style = MaterialTheme.typography.labelSmall, color = TermGray) },
                        modifier = Modifier
                            .weight(2f)
                            .testTag("custom_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TerminalCyan,
                            unfocusedBorderColor = TerminalBorder,
                            focusedTextColor = TermWhite,
                            unfocusedTextColor = TermWhite
                        ),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = tickerInput,
                        onValueChange = { tickerInput = it },
                        label = { Text("Ticker", style = MaterialTheme.typography.labelSmall, color = TermGray) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("custom_ticker_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TerminalCyan,
                            unfocusedBorderColor = TerminalBorder,
                            focusedTextColor = TermWhite,
                            unfocusedTextColor = TermWhite
                        ),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Weighting Method Selector
                Text("WEIGHTING METHODOLOGY:", style = MaterialTheme.typography.labelSmall, color = TerminalGold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        WeightingMethod.FACTOR_WEIGHTED to "Factor Weighted",
                        WeightingMethod.CAP_WEIGHTED to "Float Cap",
                        WeightingMethod.EQUAL_WEIGHTED to "Equal (1/N)"
                    ).forEach { (method, label) ->
                        val isSel = selectedMethod == method
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (isSel) TerminalCyan else TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                                .clickable { selectedMethod = method }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, style = MaterialTheme.typography.labelSmall, color = if (isSel) TerminalBg else TermOffWhite, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Primary Factor Bias Selector
                Text("PRIMARY FACTOR SCREEN:", style = MaterialTheme.typography.labelSmall, color = TerminalCyan)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        FactorType.QUALITY to "Quality (ROE)",
                        FactorType.MOMENTUM to "Momentum (12-1M)",
                        FactorType.VALUE to "Value (E/P)",
                        FactorType.DIVIDEND_YIELD to "Dividend Yield"
                    ).forEach { (factor, label) ->
                        val isSel = selectedFactor == factor
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (isSel) TerminalGold else TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                                .clickable { selectedFactor = factor }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, style = MaterialTheme.typography.labelSmall, color = if (isSel) TerminalBg else TermOffWhite, fontWeight = FontWeight.Bold, fontSize = 8.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Max Weight Cap Slider
                Text(
                    text = "Maximum Single Stock Cap: ${String.format(Locale.US, "%.1f", maxWeightCap)}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = TermOffWhite
                )
                Slider(
                    value = maxWeightCap,
                    onValueChange = { maxWeightCap = it },
                    valueRange = 2.0f..15.0f,
                    colors = SliderDefaults.colors(thumbColor = TerminalCyan, activeTrackColor = TerminalCyan)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Submit Build Button
                Button(
                    onClick = {
                        onCreateCustomIndex(nameInput, tickerInput, selectedMethod, selectedFactor, maxWeightCap.toDouble())
                        showSuccessMessage = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("build_custom_index_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalCyan, contentColor = TerminalBg),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "CALCULATE DIVISOR & PUBLISH CUSTOM INDEX",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (showSuccessMessage) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "✓ Index '$tickerInput' built, verified, and divisor settled at D=1,240.50",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 2. Published Custom Indices List
        item {
            Text(
                text = "ACTIVE CUSTOM INSTITUTIONAL INDICES",
                style = MaterialTheme.typography.labelMedium,
                color = TerminalGold,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        if (customIndices.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "No custom indices published yet. Configure above to compute custom divisor and backtested risk metrics.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TermGray
                        )
                    }
                }
            }
        } else {
            items(customIndices) { cfg ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${cfg.name} [${cfg.ticker}]",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TerminalCyan
                            )
                            Text(
                                text = "ACTIVE // D=${cfg.calculationDivisor}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TermGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Method: ${cfg.weightingMethod.name} • Factor: ${cfg.primaryFactor.factorName} • Cap: ${cfg.maxWeightCapPct}%",
                            style = MaterialTheme.typography.bodySmall,
                            color = TermGray,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            MetricBadge(
                                label = "Level Value",
                                value = String.format(Locale.US, "%,.2f", cfg.calculatedLevel),
                                modifier = Modifier.weight(1f)
                            )
                            MetricBadge(
                                label = "1Y Backtest Ret",
                                value = "+${cfg.backtestedReturn1YPct}%",
                                modifier = Modifier.weight(1f)
                            )
                            MetricBadge(
                                label = "Sharpe",
                                value = "${cfg.backtestedSharpe}",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
