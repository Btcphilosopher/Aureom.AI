package com.example.domain.model

enum class IndexFamily(val displayName: String, val provider: String) {
    SPDJI("S&P Dow Jones", "S&P Dow Jones Indices"),
    NASDAQ("Nasdaq Index", "Nasdaq Global Indexes"),
    RUSSELL("FTSE Russell", "FTSE Russell"),
    DOW("Dow Jones Averages", "S&P Dow Jones Indices"),
    WILSHIRE("Wilshire Market", "Wilshire Indexes"),
    NYSE("NYSE Indices", "Intercontinental Exchange"),
    AIS_QUANT("AIS Institutional Factors", "American Index Systems"),
    CUSTOM("Custom User Index", "AIS Custom Index Builder")
}

enum class WeightingMethod(val label: String) {
    CAP_WEIGHTED("Market-Cap Weighted (Float Adjusted)"),
    PRICE_WEIGHTED("Price Weighted (Divisor Adjusted)"),
    EQUAL_WEIGHTED("Equal Weighted (1/N)"),
    MODIFIED_CAP("Modified Cap Weighted (Capped Tier)"),
    FACTOR_WEIGHTED("Factor Multi-Weighted (Z-Score)")
}

enum class ExchangeVenue(val code: String, val venueName: String, val status: String) {
    NYSE("NYSE", "New York Stock Exchange", "Continuous Trading"),
    NASDAQ("NASDAQ", "Nasdaq Stock Market", "Continuous Trading"),
    TXSE("TXSE", "Texas Stock Exchange (2026+)", "Continuous Trading"),
    CBOE("CBOE", "Cboe BZX Exchange", "Continuous Trading"),
    NYSE_ARCA("ARCA", "NYSE Arca Equities", "Continuous Trading"),
    NYSE_AMERICAN("AMEX", "NYSE American", "Continuous Trading"),
    NTX("NTX", "Nasdaq Texas (Dallas)", "Continuous Trading")
}

enum class MarketSession(val label: String, val hours: String) {
    PRE_MARKET("Pre-Market", "04:00 - 09:30 ET"),
    REGULAR("Core Regular Session", "09:30 - 16:00 ET"),
    POST_MARKET("After-Hours", "16:00 - 20:00 ET"),
    OVERNIGHT_23_5("23/5 Continuous Session", "20:00 - 04:00 ET"),
    CLOSED("Weekend / Holiday", "Closed")
}

enum class DataProvenance(val code: String, val description: String) {
    SYNTHETIC("SYNTHETIC", "Deterministic AIS Synthetic Market Engine"),
    SIMULATED("SIMULATED", "Monte Carlo & Reconstitution Model"),
    RECONSTRUCTED("RECONSTRUCTED", "Historical Event-Sourced Replay"),
    BACKTESTED("BACKTESTED", "Methodology Simulation Run"),
    OFFICIAL_DOC("METHODOLOGY SPEC", "Public Rules Formulation")
}

enum class CorporateActionType(val label: String) {
    STOCK_SPLIT("Stock Split (Ratio Adjustment)"),
    REVERSE_SPLIT("Reverse Stock Split"),
    SPECIAL_DIVIDEND("Special Cash Dividend (Divisor Adjustment)"),
    CASH_DIVIDEND("Regular Quarterly Dividend"),
    SPINOFF("Spinoff Distribution"),
    MERGER_ACQUISITION("Merger & Acquisition Cash/Stock"),
    CONSTITUENT_ADD("Constituent Addition (Rebalance)"),
    CONSTITUENT_DELETE("Constituent Removal (Delisting/Cap Drop)"),
    FLOAT_CHANGE("Float Factor / IWF Revision"),
    BUYBACK("Share Repurchase / Share Count Update")
}

enum class FactorType(val factorName: String, val metric: String) {
    QUALITY("Quality", "Return on Equity (ROE) & Debt/Equity"),
    MOMENTUM("Momentum", "12-1 Month Relative Return"),
    VALUE("Value", "Earnings Yield & Book-to-Price"),
    SIZE("Size", "Inverse Log Float Market Cap"),
    LOW_VOLATILITY("Low Volatility", "1Y Realized Volatility"),
    DIVIDEND_YIELD("Dividend Yield", "Trailing 12M Yield %"),
    PROFITABILITY("Profitability", "Gross Margin & Free Cash Flow Yield")
}

enum class CalculationFrequency(val label: String, val intervalMs: Long) {
    FREQ_1S("1 Second (High Frequency)", 1000L),
    FREQ_5S("5 Seconds (Intraday)", 5000L),
    FREQ_1M("1 Minute", 60000L),
    FREQ_5M("5 Minutes", 300000L),
    FREQ_EOD("End of Day (Official Close)", 86400000L)
}

enum class ReviewSchedule(val label: String) {
    MONTHLY("Monthly Review"),
    QUARTERLY("Quarterly Rebalance (Mar/Jun/Sep/Dec)"),
    SEMIANNUALLY("Semiannual Reconstitution (Jun/Dec)"),
    ANNUALLY("Annual Reconstitution"),
    CONTINUOUS("Continuous / As-needed")
}

enum class SectorGICS(val code: String, val sectorName: String) {
    INFORMATION_TECHNOLOGY("TECH", "Information Technology"),
    FINANCIALS("FIN", "Financials"),
    HEALTH_CARE("HLTH", "Health Care"),
    CONSUMER_DISCRETIONARY("DISC", "Consumer Discretionary"),
    COMMUNICATION_SERVICES("COMM", "Communication Services"),
    INDUSTRIALS("IND", "Industrials"),
    CONSUMER_STAPLES("STAP", "Consumer Staples"),
    ENERGY("NRG", "Energy"),
    UTILITIES("UTIL", "Utilities"),
    REAL_ESTATE("RE", "Real Estate"),
    MATERIALS("MAT", "Materials")
}
