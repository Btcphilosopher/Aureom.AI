package com.example.calculation

import com.example.domain.model.Constituent
import com.example.domain.model.ConstituentOverlapItem
import com.example.domain.model.IndexDefinition
import com.example.domain.model.OverlapResult
import com.example.domain.model.SectorDivergenceItem
import com.example.domain.model.SectorGICS
import kotlin.math.abs
import kotlin.math.min

object OverlapEngine {

    fun calculateOverlap(indexA: IndexDefinition, indexB: IndexDefinition): OverlapResult {
        val mapA = indexA.constituents.associateBy { it.ticker }
        val mapB = indexB.constituents.associateBy { it.ticker }

        val allTickers = (mapA.keys + mapB.keys).distinct()

        val sharedItems = mutableListOf<ConstituentOverlapItem>()
        var totalWeightOverlap = 0.0

        for (ticker in allTickers) {
            val cA = mapA[ticker]
            val cB = mapB[ticker]
            if (cA != null && cB != null) {
                val minW = min(cA.weight, cB.weight)
                totalWeightOverlap += minW
                sharedItems.add(
                    ConstituentOverlapItem(
                        ticker = ticker,
                        companyName = cA.companyName,
                        weightA = cA.weight,
                        weightB = cB.weight,
                        minWeightOverlap = minW,
                        sector = cA.sector
                    )
                )
            }
        }

        sharedItems.sortByDescending { it.minWeightOverlap }

        // Sector divergences
        val secMapA = indexA.sectors.associate { it.sector to it.weightPercent }
        val secMapB = indexB.sectors.associate { it.sector to it.weightPercent }

        val sectorDivergences = SectorGICS.entries.map { sector ->
            val wA = secMapA[sector] ?: 0.0
            val wB = secMapB[sector] ?: 0.0
            SectorDivergenceItem(
                sector = sector,
                weightA = wA,
                weightB = wB,
                differencePct = wA - wB
            )
        }.sortedByDescending { abs(it.differencePct) }

        val sharedCount = sharedItems.size
        val uniqueA = indexA.constituents.size - sharedCount
        val uniqueB = indexB.constituents.size - sharedCount

        val correlation = when {
            indexA.ticker == indexB.ticker -> 1.00
            (indexA.ticker == "SP500" && indexB.ticker == "NASDAQ100") ||
            (indexA.ticker == "NASDAQ100" && indexB.ticker == "SP500") -> 0.91
            (indexA.ticker == "SP500" && indexB.ticker == "DOW30") ||
            (indexA.ticker == "DOW30" && indexB.ticker == "SP500") -> 0.88
            (indexA.ticker == "SP500" && indexB.ticker == "RUSSELL2000") ||
            (indexA.ticker == "RUSSELL2000" && indexB.ticker == "SP500") -> 0.74
            else -> 0.82
        }

        val trackingDiff = when {
            indexA.ticker == indexB.ticker -> 0.0
            (indexA.ticker == "SP500" && indexB.ticker == "NASDAQ100") -> 4.85
            (indexA.ticker == "SP500" && indexB.ticker == "RUSSELL2000") -> 7.42
            else -> 3.20
        }

        return OverlapResult(
            indexTickerA = indexA.ticker,
            indexTickerB = indexB.ticker,
            sharedCount = sharedCount,
            uniqueCountA = uniqueA,
            uniqueCountB = uniqueB,
            totalWeightOverlapPct = totalWeightOverlap,
            topSharedItems = sharedItems,
            sectorDivergences = sectorDivergences,
            correlation1Y = correlation,
            trackingDifference1Y = trackingDiff
        )
    }
}
