package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.DataProvenance
import com.example.domain.model.SectorBreakdown
import com.example.ui.TerminalTab
import com.example.ui.theme.SectorCommColor
import com.example.ui.theme.SectorConsDiscColor
import com.example.ui.theme.SectorConsStapColor
import com.example.ui.theme.SectorEnergyColor
import com.example.ui.theme.SectorFinColor
import com.example.ui.theme.SectorHealthColor
import com.example.ui.theme.SectorIndColor
import com.example.ui.theme.SectorMatColor
import com.example.ui.theme.SectorRealEstColor
import com.example.ui.theme.SectorTechColor
import com.example.ui.theme.SectorUtilColor
import com.example.ui.theme.TermDarkGray
import com.example.ui.theme.TermGray
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermGreenDim
import com.example.ui.theme.TermOffWhite
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermRedDim
import com.example.ui.theme.TermWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBlue
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalDarkBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceBright
import com.example.ui.theme.TerminalSurfaceVariant
import java.util.Locale

@Composable
fun TerminalHeader(
    tickCount: Long,
    onOpenCommandPalette: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("terminal_header"),
        color = TerminalSurface,
        shadowElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Product & Company Title
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(TermGreen, RoundedCornerShape(2.dp))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "US INDEX // TERMINAL",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TermWhite,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "AIS v26.4",
                        style = MaterialTheme.typography.labelSmall,
                        color = TerminalGold,
                        modifier = Modifier
                            .background(TerminalDarkBlue, RoundedCornerShape(3.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }

                // Quick Command Trigger Button
                IconButton(
                    onClick = onOpenCommandPalette,
                    modifier = Modifier
                        .size(36.dp)
                        .background(TerminalSurfaceBright, RoundedCornerShape(6.dp))
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .testTag("cmd_palette_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Open Command Palette",
                        tint = TerminalCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Sub-status Banner: Session, Venues, Provenance
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "NYSE • NASDAQ • TXSE 23/5",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermGray
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CONTINUOUS CALC",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "PROVENANCE: SYNTHETIC",
                        style = MaterialTheme.typography.labelSmall,
                        color = TerminalAmber,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "TICK #$tickCount",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermGray,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun TerminalNavTabBar(
    activeTab: TerminalTab,
    onTabSelected: (TerminalTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = TerminalBg
    ) {
        Row(
            modifier = Modifier
                .horizontalScroll(scrollState)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TerminalTab.entries.forEach { tab ->
                val isSelected = tab == activeTab
                Box(
                    modifier = Modifier
                        .background(
                            if (isSelected) TerminalCyan else TerminalSurfaceVariant,
                            RoundedCornerShape(4.dp)
                        )
                        .border(
                            1.dp,
                            if (isSelected) TerminalCyan else TerminalBorder,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                        .testTag("tab_${tab.shortcut}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "[${tab.shortcut}]",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) TerminalBg else TerminalAmber
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) TerminalBg else TermOffWhite
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MetricBadge(
    label: String,
    value: String,
    delta: Double? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(4.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(TerminalBorder, TerminalBorder)))
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(
                text = label.uppercase(Locale.US),
                style = MaterialTheme.typography.labelSmall,
                color = TermGray
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TermWhite
                )
                if (delta != null) {
                    Spacer(modifier = Modifier.width(4.dp))
                    val isPos = delta >= 0
                    Text(
                        text = if (isPos) "+${String.format(Locale.US, "%.2f", delta)}%" else "${String.format(Locale.US, "%.2f", delta)}%",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (isPos) TermGreen else TermRed,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun SparklineCanvas(
    points: List<Double>,
    color: Color = TerminalCyan,
    modifier: Modifier = Modifier
) {
    if (points.size < 2) return

    Canvas(modifier = modifier) {
        val minVal = points.minOrNull() ?: 0.0
        val maxVal = points.maxOrNull() ?: 1.0
        val range = if (maxVal > minVal) maxVal - minVal else 1.0

        val w = size.width
        val h = size.height
        val stepX = w / (points.size - 1)

        val path = Path()
        points.forEachIndexed { i, pt ->
            val x = i * stepX
            val y = h - ((pt - minVal) / range * (h * 0.85f) + h * 0.05f).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

@Composable
fun SectorWaterfallChart(
    sectors: List<SectorBreakdown>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Text(
            text = "SECTOR ATTRIBUTION & CONTRIBUTION (WATERFALL)",
            style = MaterialTheme.typography.labelLarge,
            color = TerminalGold,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))

        sectors.take(7).forEach { sec ->
            val isPos = sec.contributionPercent >= 0
            val color = when (sec.sector.code) {
                "TECH" -> SectorTechColor
                "FIN" -> SectorFinColor
                "HLTH" -> SectorHealthColor
                "DISC" -> SectorConsDiscColor
                "COMM" -> SectorCommColor
                "IND" -> SectorIndColor
                "NRG" -> SectorEnergyColor
                "UTIL" -> SectorUtilColor
                "RE" -> SectorRealEstColor
                "MAT" -> SectorMatColor
                else -> SectorConsStapColor
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = sec.sector.sectorName,
                    style = MaterialTheme.typography.bodySmall,
                    color = TermOffWhite,
                    modifier = Modifier.width(130.dp),
                    maxLines = 1
                )
                Text(
                    text = "${String.format(Locale.US, "%.1f", sec.weightPercent)}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = TermGray,
                    modifier = Modifier.width(42.dp),
                    fontFamily = FontFamily.Monospace
                )

                // Contribution Bar
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(14.dp)
                        .background(TerminalSurfaceVariant, RoundedCornerShape(2.dp))
                ) {
                    val barWidthFraction = (kotlin.math.abs(sec.contributionPercent) / 0.8).coerceIn(0.05, 1.0).toFloat()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(barWidthFraction)
                            .height(14.dp)
                            .background(if (isPos) TermGreen else TermRed, RoundedCornerShape(2.dp))
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isPos) "+${String.format(Locale.US, "%.3f", sec.contributionPercent)}%" else "${String.format(Locale.US, "%.3f", sec.contributionPercent)}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isPos) TermGreen else TermRed,
                    modifier = Modifier.width(62.dp),
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun MonteCarloFanChart(
    p10: List<Double>,
    p25: List<Double>,
    p50: List<Double>,
    p75: List<Double>,
    p90: List<Double>,
    modifier: Modifier = Modifier
) {
    if (p50.isEmpty()) return

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface, RoundedCornerShape(6.dp))
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "10,000 PATH STOCHASTIC TRAJECTORY FAN",
                style = MaterialTheme.typography.labelLarge,
                color = TerminalCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "90% CI BAND",
                style = MaterialTheme.typography.labelSmall,
                color = TermGray
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            val minVal = p10.minOrNull() ?: 1000.0
            val maxVal = p90.maxOrNull() ?: 2000.0
            val range = if (maxVal > minVal) maxVal - minVal else 1.0

            val w = size.width
            val h = size.height
            val steps = p50.size
            val stepX = w / (steps - 1)

            // Draw 90% Confidence Area (p10 to p90)
            val path90Area = Path()
            for (i in 0 until steps) {
                val x = i * stepX
                val y = h - ((p90[i] - minVal) / range * (h * 0.85f) + h * 0.05f).toFloat()
                if (i == 0) path90Area.moveTo(x, y) else path90Area.lineTo(x, y)
            }
            for (i in steps - 1 downTo 0) {
                val x = i * stepX
                val y = h - ((p10[i] - minVal) / range * (h * 0.85f) + h * 0.05f).toFloat()
                path90Area.lineTo(x, y)
            }
            path90Area.close()
            drawPath(path90Area, color = TerminalDarkBlue.copy(alpha = 0.5f))

            // Draw 50% Area (p25 to p75)
            val path50Area = Path()
            for (i in 0 until steps) {
                val x = i * stepX
                val y = h - ((p75[i] - minVal) / range * (h * 0.85f) + h * 0.05f).toFloat()
                if (i == 0) path50Area.moveTo(x, y) else path50Area.lineTo(x, y)
            }
            for (i in steps - 1 downTo 0) {
                val x = i * stepX
                val y = h - ((p25[i] - minVal) / range * (h * 0.85f) + h * 0.05f).toFloat()
                path50Area.lineTo(x, y)
            }
            path50Area.close()
            drawPath(path50Area, color = TerminalBlue.copy(alpha = 0.35f))

            // Median Path (p50 line)
            val medianPath = Path()
            p50.forEachIndexed { i, pt ->
                val x = i * stepX
                val y = h - ((pt - minVal) / range * (h * 0.85f) + h * 0.05f).toFloat()
                if (i == 0) medianPath.moveTo(x, y) else medianPath.lineTo(x, y)
            }
            drawPath(medianPath, color = TerminalCyan, style = Stroke(width = 2.5.dp.toPx()))
        }

        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Day 0", style = MaterialTheme.typography.labelSmall, color = TermGray)
            Text("Day 63", style = MaterialTheme.typography.labelSmall, color = TermGray)
            Text("Day 126", style = MaterialTheme.typography.labelSmall, color = TermGray)
            Text("Day 189", style = MaterialTheme.typography.labelSmall, color = TermGray)
            Text("Day 252 (Terminal)", style = MaterialTheme.typography.labelSmall, color = TermGray)
        }
    }
}

@Composable
fun CommandPaletteModal(
    isOpen: Boolean,
    commandInput: String,
    onInputChange: (String) -> Unit,
    onExecute: (String) -> Unit,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, TerminalCyan, RoundedCornerShape(8.dp)),
            shape = RoundedCornerShape(8.dp),
            color = TerminalSurface
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TERMINAL COMMAND PALETTE",
                        style = MaterialTheme.typography.titleSmall,
                        color = TerminalGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "ESC / CLOSE",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermGray,
                        modifier = Modifier.clickable { onDismiss() }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = commandInput,
                    onValueChange = onInputChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cmd_input_field"),
                    placeholder = {
                        Text(
                            "e.g. INDEX SP500, COMPARE NASDAQ100, SCENARIO",
                            style = MaterialTheme.typography.bodySmall,
                            color = TermDarkGray
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalCyan,
                        unfocusedBorderColor = TerminalBorder,
                        focusedTextColor = TermWhite,
                        unfocusedTextColor = TermWhite,
                        cursorColor = TerminalCyan
                    ),
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = TerminalCyan
                        )
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "QUICK INSTITUTIONAL COMMANDS:",
                    style = MaterialTheme.typography.labelSmall,
                    color = TermGray
                )

                Spacer(modifier = Modifier.height(6.dp))

                val quickCommands = listOf(
                    "INDEX SP500" to "View S&P 500 Index Deep Dive",
                    "INDEX NASDAQ100" to "View Nasdaq-100 Modified Cap Index",
                    "INDEX DOW30" to "View Price-Weighted Dow Jones Industrial Average",
                    "INDEX RUSSELL2000" to "View Russell 2000 Small-Cap Universe",
                    "COMPARE SP500 NASDAQ100" to "Constituent & Weight Overlap Matrix",
                    "REBALANCE RUSSELL2000" to "Reconstitution & Turnover Simulator",
                    "SCENARIO" to "Open Multi-Factor Stress Test Lab",
                    "API" to "Open Institutional API & SDK Console"
                )

                quickCommands.forEach { (cmd, desc) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onExecute(cmd) }
                            .padding(vertical = 5.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = cmd,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = TerminalCyan,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = desc,
                            style = MaterialTheme.typography.bodySmall,
                            color = TermGray,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
