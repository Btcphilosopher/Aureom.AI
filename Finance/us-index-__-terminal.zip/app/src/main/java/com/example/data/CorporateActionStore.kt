package com.example.data

import com.example.domain.model.CorporateActionEvent
import com.example.domain.model.CorporateActionType
import com.example.domain.model.DataProvenance

object CorporateActionStore {

    fun getAuditedCorporateActions(): List<CorporateActionEvent> {
        return listOf(
            CorporateActionEvent(
                eventId = "CA-2026-089",
                ticker = "NVDA",
                companyName = "NVIDIA Corporation",
                type = CorporateActionType.STOCK_SPLIT,
                effectiveDate = "2026-06-10",
                description = "10-for-1 forward stock split. Shares multiplied by 10, nominal price divided by 10. Index continuity maintained via constituent share multiplier.",
                oldValue = "1 share @ $1,486.00",
                newValue = "10 shares @ $148.60",
                oldDivisor = 8421.458,
                newDivisor = 8421.458,
                indexImpactPoints = 0.00,
                status = "AUDITED_SETTLED",
                provenance = DataProvenance.SYNTHETIC
            ),
            CorporateActionEvent(
                eventId = "CA-2026-074",
                ticker = "PLTR",
                companyName = "Palantir Technologies Inc.",
                type = CorporateActionType.CONSTITUENT_ADD,
                effectiveDate = "2026-03-23",
                description = "Quarterly rebalance inclusion into S&P 500 family replacing delisted regional component. Divisor recalculated from 8412.22 to 8438.90 to absorb market-cap addition.",
                oldValue = "Not in index",
                newValue = "2,240M shares, Float 0.91 @ $68.20",
                oldDivisor = 8412.220,
                newDivisor = 8438.902,
                indexImpactPoints = 0.00,
                status = "AUDITED_SETTLED",
                provenance = DataProvenance.SYNTHETIC
            ),
            CorporateActionEvent(
                eventId = "CA-2026-068",
                ticker = "TXROB",
                companyName = "Texas Autonomous Robotics Corp",
                type = CorporateActionType.CONSTITUENT_ADD,
                effectiveDate = "2026-05-18",
                description = "Inclusion following TXSE continuous trading qualification under 2026 Exchange Eligibility Engine ruleset.",
                oldValue = "Not in index",
                newValue = "185M shares, Float 0.88 @ $86.40",
                oldDivisor = 1450.301,
                newDivisor = 1458.210,
                indexImpactPoints = 0.00,
                status = "AUDITED_SETTLED",
                provenance = DataProvenance.SYNTHETIC
            ),
            CorporateActionEvent(
                eventId = "CA-2026-052",
                ticker = "COST",
                companyName = "Costco Wholesale Corporation",
                type = CorporateActionType.SPECIAL_DIVIDEND,
                effectiveDate = "2026-01-12",
                description = "$15.00 per share special cash dividend distribution. Ex-date market cap adjustment requiring divisor reduction from 8445.10 to 8443.82 to prevent artificial downward index return.",
                oldValue = "Cumulative $15.00/sh ($6.64B total cash)",
                newValue = "Ex-dividend price adjusted -$15.00",
                oldDivisor = 8445.104,
                newDivisor = 8443.821,
                indexImpactPoints = 0.00,
                status = "AUDITED_SETTLED",
                provenance = DataProvenance.SYNTHETIC
            ),
            CorporateActionEvent(
                eventId = "CA-2026-041",
                ticker = "GE",
                companyName = "GE Aerospace",
                type = CorporateActionType.SPINOFF,
                effectiveDate = "2026-04-02",
                description = "Completed spinoff of GE Vernova (GEV). 1 GEV share for every 4 GE shares held. Base price and divisor adjusted at effective market open.",
                oldValue = "Combined Conglomerate",
                newValue = "Pure-play Aerospace",
                oldDivisor = 8450.000,
                newDivisor = 8446.512,
                indexImpactPoints = 0.00,
                status = "AUDITED_SETTLED",
                provenance = DataProvenance.SYNTHETIC
            ),
            CorporateActionEvent(
                eventId = "CA-2026-033",
                ticker = "AAPL",
                companyName = "Apple Inc.",
                type = CorporateActionType.BUYBACK,
                effectiveDate = "2026-02-15",
                description = "Quarterly share count reduction: 110M shares repurchased and retired. Total outstanding shares reduced from 15,314M to 15,204M.",
                oldValue = "15,314M shares",
                newValue = "15,204M shares",
                oldDivisor = 8448.200,
                newDivisor = 8445.104,
                indexImpactPoints = 0.00,
                status = "AUDITED_SETTLED",
                provenance = DataProvenance.SYNTHETIC
            )
        )
    }
}
