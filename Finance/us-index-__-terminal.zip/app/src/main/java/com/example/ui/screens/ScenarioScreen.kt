package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ScenarioStressResult
import com.example.ui.components.MetricBadge
import com.example.ui.theme.TermGray
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermOffWhite
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBlue
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalDarkBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import java.util.Locale

@Composable
fun ScenarioScreen(
    scenarioResult: ScenarioStressResult?,
    techShock: Double,
    finShock: Double,
    energyShock: Double,
    ratesShockBps: Double,
    usdShock: Double,
    megaCapShock: Double,
    onUpdateShocks: (tech: Double?, fin: Double?, energy: Double?, rates: Double?, usd: Double?, megaCap: Double?) -> Unit,
    onApplyPreset: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (scenarioResult == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Initializing scenario parameters...", color = TermGray)
        }
        return
    }

    val isPos = scenarioResult.deltaPercent >= 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBg)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Scenario Title & Presets
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "MACROECONOMIC & SECTOR STRESS TESTING LAB",
                    style = MaterialTheme.typography.labelLarge,
                    color = TerminalCyan,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Text("PRESET SCENARIOS:", style = MaterialTheme.typography.labelSmall, color = TerminalGold)
                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val presets = listOf(
                        "TECH_SELLOFF" to "Tech -15%",
                        "RATE_HIKE_100BP" to "Rates +100bp",
                        "ENERGY_CRISIS" to "Energy +25%",
                        "SMALL_CAP_ROTATION" to "Small-Cap Rot",
                        "RESET" to "Reset"
                    )
                    presets.forEach { (key, label) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(if (key == "RESET") TerminalSurfaceVariant else TerminalDarkBlue, RoundedCornerShape(3.dp))
                                .border(1.dp, if (key == "RESET") TerminalBorder else TerminalCyan, RoundedCornerShape(3.dp))
                                .clickable { onApplyPreset(key) }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (key == "RESET") TermGray else TerminalCyan,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }

        // 2. Instant Recalculated Stressed Index Level
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "RECALCULATED STRESSED INDEX VALUE",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermGray
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = String.format(Locale.US, "%,.2f", scenarioResult.stressedLevel),
                                style = MaterialTheme.typography.displayMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TermWhite
                            )
                            Text(
                                text = "Baseline Level: ${String.format(Locale.US, "%,.2f", scenarioResult.baselineLevel)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TermGray,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${if (isPos) "+" else ""}${String.format(Locale.US, "%.2f", scenarioResult.deltaPoints)} pts",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isPos) TermGreen else TermRed
                            )
                            Text(
                                text = "${if (isPos) "+" else ""}${String.format(Locale.US, "%.2f", scenarioResult.deltaPercent)}%",
                                style = MaterialTheme.typography.titleSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isPos) TermGreen else TermRed
                            )
                        }
                    }
                }
            }
        }

        // 3. Interactive Shock Sliders
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "CUSTOM SHOCK PARAMETERS",
                    style = MaterialTheme.typography.labelMedium,
                    color = TerminalGold,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Tech Shock Slider
                Text(
                    text = "Technology Sector Shock: ${if (techShock >= 0) "+" else ""}${String.format(Locale.US, "%.1f", techShock)}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = TermOffWhite
                )
                Slider(
                    value = techShock.toFloat(),
                    onValueChange = { onUpdateShocks(it.toDouble(), null, null, null, null, null) },
                    valueRange = -30f..30f,
                    colors = SliderDefaults.colors(thumbColor = TerminalCyan, activeTrackColor = TerminalCyan),
                    modifier = Modifier.testTag("slider_tech")
                )

                // Interest Rates Shock Slider (bps)
                Text(
                    text = "10Y Treasury Yield Shock: ${if (ratesShockBps >= 0) "+" else ""}${ratesShockBps.toInt()} bps",
                    style = MaterialTheme.typography.bodySmall,
                    color = TermOffWhite
                )
                Slider(
                    value = ratesShockBps.toFloat(),
                    onValueChange = { onUpdateShocks(null, null, null, it.toDouble(), null, null) },
                    valueRange = -150f..200f,
                    colors = SliderDefaults.colors(thumbColor = TerminalGold, activeTrackColor = TerminalGold),
                    modifier = Modifier.testTag("slider_rates")
                )

                // Energy Shock Slider
                Text(
                    text = "Energy / Crude Shock: ${if (energyShock >= 0) "+" else ""}${String.format(Locale.US, "%.1f", energyShock)}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = TermOffWhite
                )
                Slider(
                    value = energyShock.toFloat(),
                    onValueChange = { onUpdateShocks(null, null, it.toDouble(), null, null, null) },
                    valueRange = -30f..40f,
                    colors = SliderDefaults.colors(thumbColor = TerminalAmber, activeTrackColor = TerminalAmber),
                    modifier = Modifier.testTag("slider_energy")
                )

                // Mega-Cap Shock Slider
                Text(
                    text = "Mega-Cap Idiosyncratic Shock: ${if (megaCapShock >= 0) "+" else ""}${String.format(Locale.US, "%.1f", megaCapShock)}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = TermOffWhite
                )
                Slider(
                    value = megaCapShock.toFloat(),
                    onValueChange = { onUpdateShocks(null, null, null, null, null, it.toDouble()) },
                    valueRange = -25f..25f,
                    colors = SliderDefaults.colors(thumbColor = TermRed, activeTrackColor = TermRed),
                    modifier = Modifier.testTag("slider_megacap")
                )
            }
        }

        // 4. Sector & Constituent Shock Drivers
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Top Positive Drivers
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(TerminalSurface, RoundedCornerShape(6.dp))
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "RESILIENT DRIVERS (+)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    scenarioResult.topPositiveDrivers.forEach { (t, c) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(t, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TermWhite)
                            Text("+${String.format(Locale.US, "%.3f", c)}%", style = MaterialTheme.typography.labelSmall, color = TermGreen, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                // Top Negative Drivers
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(TerminalSurface, RoundedCornerShape(6.dp))
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "VULNERABLE DETRACTORS (-)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermRed,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    scenarioResult.topNegativeDrivers.forEach { (t, c) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(t, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TermWhite)
                            Text("${String.format(Locale.US, "%.3f", c)}%", style = MaterialTheme.typography.labelSmall, color = TermRed, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}
