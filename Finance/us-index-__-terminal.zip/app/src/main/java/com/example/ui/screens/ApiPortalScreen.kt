package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ApiEndpointDoc
import com.example.ui.components.MetricBadge
import com.example.ui.theme.TermDarkGray
import com.example.ui.theme.TermGray
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermOffWhite
import com.example.ui.theme.TermWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalDarkBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant

@Composable
fun ApiPortalScreen(
    endpointDocs: List<ApiEndpointDoc>,
    selectedDoc: ApiEndpointDoc?,
    onSelectEndpoint: (ApiEndpointDoc) -> Unit,
    apiInput: String,
    onApiInputChange: (String) -> Unit,
    apiOutput: String,
    onExecuteQuery: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBg)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. API Status & Gateway Banner
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "US INDEX // REST & WEBSOCKET API GATEWAY",
                        style = MaterialTheme.typography.labelLarge,
                        color = TerminalCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "200 OK • 12ms",
                        style = MaterialTheme.typography.labelSmall,
                        color = TermGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "High-throughput deterministic index distribution engine serving asset managers, quantitative hedge funds, and institutional risk desks.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TermGray
                )
            }
        }

        // 2. Interactive Console
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "INTERACTIVE QUERY CONSOLE",
                    style = MaterialTheme.typography.labelMedium,
                    color = TerminalGold,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = apiInput,
                        onValueChange = onApiInputChange,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("api_query_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TerminalCyan,
                            unfocusedBorderColor = TerminalBorder,
                            focusedTextColor = TermWhite,
                            unfocusedTextColor = TermWhite
                        ),
                        singleLine = true
                    )

                    Button(
                        onClick = onExecuteQuery,
                        colors = ButtonDefaults.buttonColors(containerColor = TerminalCyan, contentColor = TerminalBg),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("api_execute_btn")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("SEND", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // JSON Output Container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalBg, RoundedCornerShape(4.dp))
                        .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = apiOutput.ifBlank { "// Enter query above or choose an endpoint below to execute." },
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (apiOutput.contains("error")) TerminalAmber else TermGreen,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // 3. API Documentation Endpoints
        item {
            Text(
                text = "CORE REST ENDPOINTS & OPENAPI SPECS",
                style = MaterialTheme.typography.labelMedium,
                color = TerminalCyan,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(endpointDocs) { doc ->
            val isSel = doc == selectedDoc
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectEndpoint(doc) }
                    .testTag("api_doc_${doc.path}"),
                colors = CardDefaults.cardColors(containerColor = if (isSel) TerminalSurfaceVariant else TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (isSel) TerminalCyan else TerminalBorder)
                ),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = doc.method,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (doc.method == "GET") TermGreen else TerminalGold,
                                modifier = Modifier
                                    .background(TerminalBg, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = doc.path,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = TermWhite,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Text(
                            text = doc.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = TermGray,
                            fontSize = 9.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = doc.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TermOffWhite,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // 4. Python SDK (`usindex-python`) Sample Code
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "PYTHON SDK (usindex-python)",
                    style = MaterialTheme.typography.labelMedium,
                    color = TerminalGold,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalBg, RoundedCornerShape(4.dp))
                        .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = """
from usindex import IndexClient

client = IndexClient(api_key="ais_live_sec_token")

# 1. Fetch S&P 500 Real-Time State & Divisor
sp500 = client.indices.get("SP500")
print(f"Level: {sp500.level} | Divisor: {sp500.divisor}")

# 2. Retrieve Full Constituent Float Weights
constituents = client.indices.constituents("SP500")

# 3. Execute Scenario Stress Simulation
scenario = client.research.scenario(
    index="SP500",
    tech_shock=-0.15,
    rates_shock_bps=100
)
print(f"Stressed Level: {scenario.stressed_level}")
                        """.trimIndent(),
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalCyan,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
