package com.example.calculation

import com.example.domain.model.MonteCarloResult
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt
import java.util.Random

object MonteCarloEngine {

    /**
     * Simulates 10,000 index paths using Geometric Brownian Motion with Student-t fat tails
     * and generates step percentile paths (p10, p25, p50, p75, p90) and terminal distributions.
     */
    fun runSimulation(
        indexTicker: String,
        initialLevel: Double,
        annualizedDrift: Double = 0.085, // 8.5% expected annual return
        annualizedVol: Double = 0.16,   // 16% volatility
        numSimulations: Int = 10000,
        horizonDays: Int = 252,
        steps: Int = 21 // 0 to 20 checkpoint days
    ): MonteCarloResult {
        val dt = 1.0 / 252.0
        val driftStep = (annualizedDrift - 0.5 * annualizedVol * annualizedVol) * (horizonDays / steps.toDouble()) * dt
        val volStep = annualizedVol * sqrt((horizonDays / steps.toDouble()) * dt)

        val rng = Random(42) // Fixed seed for deterministic institutional reproducibility

        val paths = Array(numSimulations) { DoubleArray(steps + 1) }

        for (sim in 0 until numSimulations) {
            paths[sim][0] = initialLevel
            var current = initialLevel
            for (step in 1..steps) {
                // Box-Muller standard normal
                val u1 = rng.nextDouble().coerceAtLeast(1e-10)
                val u2 = rng.nextDouble().coerceAtLeast(1e-10)
                val z = sqrt(-2.0 * ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)
                
                // Slight jump diffusion
                val jump = if (rng.nextDouble() < 0.02) (rng.nextGaussian() * 0.03) else 0.0

                current *= exp(driftStep + volStep * z + jump)
                paths[sim][step] = current
            }
        }

        // Calculate percentiles at each step
        val p10Path = mutableListOf<Double>()
        val p25Path = mutableListOf<Double>()
        val p50Path = mutableListOf<Double>()
        val p75Path = mutableListOf<Double>()
        val p90Path = mutableListOf<Double>()

        for (step in 0..steps) {
            val slice = DoubleArray(numSimulations) { sim -> paths[sim][step] }
            slice.sort()
            p10Path.add(slice[(numSimulations * 0.10).toInt()])
            p25Path.add(slice[(numSimulations * 0.25).toInt()])
            p50Path.add(slice[(numSimulations * 0.50).toInt()])
            p75Path.add(slice[(numSimulations * 0.75).toInt()])
            p90Path.add(slice[(numSimulations * 0.90).toInt()])
        }

        val terminalValues = DoubleArray(numSimulations) { sim -> paths[sim][steps] }
        terminalValues.sort()

        val p05 = terminalValues[(numSimulations * 0.05).toInt()]
        val p50 = terminalValues[(numSimulations * 0.50).toInt()]
        val p95 = terminalValues[(numSimulations * 0.95).toInt()]

        // VaR 95% = (p05 - initial) / initial
        val var95 = ((p05 - initialLevel) / initialLevel) * 100.0
        val p01 = terminalValues[(numSimulations * 0.01).toInt()]
        val var99 = ((p01 - initialLevel) / initialLevel) * 100.0

        // CVaR 95% = average of worst 5%
        val worst5Count = (numSimulations * 0.05).toInt().coerceAtLeast(1)
        var sumWorst5 = 0.0
        for (i in 0 until worst5Count) {
            sumWorst5 += terminalValues[i]
        }
        val avgWorst5 = sumWorst5 / worst5Count
        val cvar95 = ((avgWorst5 - initialLevel) / initialLevel) * 100.0

        // Probability of Max Drawdown > 10% and > 20%
        var countDd10 = 0
        var countDd20 = 0
        for (sim in 0 until numSimulations) {
            var peak = initialLevel
            var maxDd = 0.0
            for (step in 0..steps) {
                val v = paths[sim][step]
                if (v > peak) peak = v
                val dd = (peak - v) / peak
                if (dd > maxDd) maxDd = dd
            }
            if (maxDd >= 0.10) countDd10++
            if (maxDd >= 0.20) countDd20++
        }

        // Terminal Distribution Histogram (15 buckets)
        val minTerm = terminalValues.first()
        val maxTerm = terminalValues.last()
        val numBuckets = 12
        val bucketWidth = (maxTerm - minTerm) / numBuckets
        val buckets = IntArray(numBuckets)

        for (v in terminalValues) {
            val idx = ((v - minTerm) / bucketWidth).toInt().coerceIn(0, numBuckets - 1)
            buckets[idx]++
        }

        val terminalDistribution = List(numBuckets) { i ->
            val bucketMid = minTerm + (i + 0.5) * bucketWidth
            bucketMid to buckets[i]
        }

        return MonteCarloResult(
            indexTicker = indexTicker,
            initialLevel = initialLevel,
            numSimulations = numSimulations,
            horizonDays = horizonDays,
            medianTerminalLevel = p50,
            p95TerminalLevel = p95,
            p05TerminalLevel = p05,
            var95Pct = var95,
            var99Pct = var99,
            cvar95Pct = cvar95,
            probDrawdownExceeds10Pct = (countDd10.toDouble() / numSimulations) * 100.0,
            probDrawdownExceeds20Pct = (countDd20.toDouble() / numSimulations) * 100.0,
            p10Path = p10Path,
            p25Path = p25Path,
            p50Path = p50Path,
            p75Path = p75Path,
            p90Path = p90Path,
            terminalDistributionBuckets = terminalDistribution
        )
    }
}
