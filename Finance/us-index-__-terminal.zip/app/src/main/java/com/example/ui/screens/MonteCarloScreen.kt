package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MonteCarloResult
import com.example.ui.components.MetricBadge
import com.example.ui.components.MonteCarloFanChart
import com.example.ui.theme.TermGray
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermOffWhite
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalDarkBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import java.util.Locale

@Composable
fun MonteCarloScreen(
    monteCarloResult: MonteCarloResult?,
    modifier: Modifier = Modifier
) {
    if (monteCarloResult == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Simulating 10,000 stochastic index paths...", color = TermGray)
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBg)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Monte Carlo Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MONTE CARLO 10,000-PATH QUANTITATIVE SIMULATION",
                        style = MaterialTheme.typography.labelLarge,
                        color = TerminalCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "STUDENT-T JUMP",
                        style = MaterialTheme.typography.labelSmall,
                        color = TerminalGold,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Geometric Brownian motion with fat-tail jump diffusion across 252 forward trading days for ${monteCarloResult.indexTicker}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TermGray
                )
            }
        }

        // 2. Trajectory Fan Chart
        item {
            MonteCarloFanChart(
                p10 = monteCarloResult.p10Path,
                p25 = monteCarloResult.p25Path,
                p50 = monteCarloResult.p50Path,
                p75 = monteCarloResult.p75Path,
                p90 = monteCarloResult.p90Path
            )
        }

        // 3. Tail Risk & Terminal Distribution Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricBadge(
                    label = "Median Terminal",
                    value = String.format(Locale.US, "%,.1f", monteCarloResult.medianTerminalLevel),
                    modifier = Modifier.weight(1f)
                )
                MetricBadge(
                    label = "95th Percentile",
                    value = String.format(Locale.US, "%,.1f", monteCarloResult.p95TerminalLevel),
                    delta = ((monteCarloResult.p95TerminalLevel - monteCarloResult.initialLevel) / monteCarloResult.initialLevel) * 100.0,
                    modifier = Modifier.weight(1f)
                )
                MetricBadge(
                    label = "5th Percentile",
                    value = String.format(Locale.US, "%,.1f", monteCarloResult.p05TerminalLevel),
                    delta = ((monteCarloResult.p05TerminalLevel - monteCarloResult.initialLevel) / monteCarloResult.initialLevel) * 100.0,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 4. VaR & CVaR Tail Metrics
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "VALUE AT RISK (VaR) & CONDITIONAL VaR (EXPECTED SHORTFALL)",
                        style = MaterialTheme.typography.labelMedium,
                        color = TerminalGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MetricBadge(
                            label = "1Y VaR (95% CI)",
                            value = "${String.format(Locale.US, "%.2f", monteCarloResult.var95Pct)}%",
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "1Y VaR (99% CI)",
                            value = "${String.format(Locale.US, "%.2f", monteCarloResult.var99Pct)}%",
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "1Y CVaR (95%)",
                            value = "${String.format(Locale.US, "%.2f", monteCarloResult.cvar95Pct)}%",
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MetricBadge(
                            label = "Prob Drawdown >10%",
                            value = "${String.format(Locale.US, "%.1f", monteCarloResult.probDrawdownExceeds10Pct)}%",
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "Prob Drawdown >20%",
                            value = "${String.format(Locale.US, "%.1f", monteCarloResult.probDrawdownExceeds20Pct)}%",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 5. Terminal Distribution Frequency Histogram
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "TERMINAL DENSITY HISTOGRAM (N=10,000)",
                    style = MaterialTheme.typography.labelMedium,
                    color = TerminalCyan,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                val maxFreq = monteCarloResult.terminalDistributionBuckets.maxOfOrNull { it.second } ?: 1
                monteCarloResult.terminalDistributionBuckets.forEach { (price, count) ->
                    val fraction = (count.toFloat() / maxFreq).coerceIn(0.02f, 1.0f)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = String.format(Locale.US, "%,.0f", price),
                            style = MaterialTheme.typography.labelSmall,
                            color = TermGray,
                            modifier = Modifier.width(60.dp),
                            fontFamily = FontFamily.Monospace
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(12.dp)
                                .background(TerminalSurfaceVariant, RoundedCornerShape(2.dp))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(fraction)
                                    .height(12.dp)
                                    .background(TerminalCyan, RoundedCornerShape(2.dp))
                            )
                        }
                        Text(
                            text = "$count",
                            style = MaterialTheme.typography.labelSmall,
                            color = TermOffWhite,
                            modifier = Modifier.width(50.dp),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
