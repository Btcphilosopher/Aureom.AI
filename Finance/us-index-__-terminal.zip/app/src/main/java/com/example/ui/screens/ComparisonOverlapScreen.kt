package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.IndexDefinition
import com.example.domain.model.OverlapResult
import com.example.ui.components.MetricBadge
import com.example.ui.theme.TermGray
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermOffWhite
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBlue
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalDarkBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import java.util.Locale

@Composable
fun ComparisonOverlapScreen(
    overlapResult: OverlapResult?,
    allIndices: Map<String, IndexDefinition>,
    selectedTickerA: String,
    selectedTickerB: String,
    onSelectIndexA: (String) -> Unit,
    onSelectIndexB: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (overlapResult == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select two indices to compute overlap analytics.", color = TermGray)
        }
        return
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBg)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Selector Row for Pair
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "INDEX COMPARISON & CONSTITUENT OVERLAP MATRIX",
                    style = MaterialTheme.typography.labelLarge,
                    color = TerminalCyan,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Selector Index A
                Text("PRIMARY INDEX [A]:", style = MaterialTheme.typography.labelSmall, color = TerminalGold)
                val scrollA = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollA)
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    allIndices.keys.forEach { t ->
                        val isSel = t == selectedTickerA
                        Box(
                            modifier = Modifier
                                .background(if (isSel) TerminalGold else TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                                .clickable { onSelectIndexA(t) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("cmp_select_a_$t")
                        ) {
                            Text(t, style = MaterialTheme.typography.labelSmall, color = if (isSel) TerminalBg else TermOffWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Selector Index B
                Text("BENCHMARK INDEX [B]:", style = MaterialTheme.typography.labelSmall, color = TerminalCyan)
                val scrollB = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollB)
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    allIndices.keys.forEach { t ->
                        val isSel = t == selectedTickerB
                        Box(
                            modifier = Modifier
                                .background(if (isSel) TerminalCyan else TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                                .clickable { onSelectIndexB(t) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("cmp_select_b_$t")
                        ) {
                            Text(t, style = MaterialTheme.typography.labelSmall, color = if (isSel) TerminalBg else TermOffWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. Overlap Key Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricBadge(
                    label = "Weight Overlap",
                    value = "${String.format(Locale.US, "%.1f", overlapResult.totalWeightOverlapPct)}%",
                    modifier = Modifier.weight(1f)
                )
                MetricBadge(
                    label = "Shared Stocks",
                    value = "${overlapResult.sharedCount}",
                    modifier = Modifier.weight(1f)
                )
                MetricBadge(
                    label = "1Y Correlation",
                    value = String.format(Locale.US, "%.3f", overlapResult.correlation1Y),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 3. Visual Overlap Ratio Bar
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "PAIRWISE WEIGHT OVERLAP VISUALIZATION",
                    style = MaterialTheme.typography.labelMedium,
                    color = TerminalGold,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                val overlapFraction = (overlapResult.totalWeightOverlapPct / 100.0).coerceIn(0.05, 0.95).toFloat()
                val uniqueAFraction = ((100.0 - overlapResult.totalWeightOverlapPct) / 200.0).coerceIn(0.02, 0.5).toFloat()
                val uniqueBFraction = ((100.0 - overlapResult.totalWeightOverlapPct) / 200.0).coerceIn(0.02, 0.5).toFloat()

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .background(TerminalBg, RoundedCornerShape(4.dp))
                        .padding(2.dp)
                ) {
                    // Index A Unique
                    Box(
                        modifier = Modifier
                            .weight(uniqueAFraction)
                            .fillMaxSize()
                            .background(TerminalGold, RoundedCornerShape(topStart = 3.dp, bottomStart = 3.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(selectedTickerA, style = MaterialTheme.typography.labelSmall, color = TerminalBg, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    }
                    // Overlap
                    Box(
                        modifier = Modifier
                            .weight(overlapFraction)
                            .fillMaxSize()
                            .background(TermGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("OVERLAP ${String.format(Locale.US, "%.1f", overlapResult.totalWeightOverlapPct)}%", style = MaterialTheme.typography.labelSmall, color = TerminalBg, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    }
                    // Index B Unique
                    Box(
                        modifier = Modifier
                            .weight(uniqueBFraction)
                            .fillMaxSize()
                            .background(TerminalCyan, RoundedCornerShape(topEnd = 3.dp, bottomEnd = 3.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(selectedTickerB, style = MaterialTheme.typography.labelSmall, color = TerminalBg, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    }
                }
            }
        }

        // 4. Sector Allocation Divergence
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "SECTOR WEIGHT DIVERGENCE (INDEX A - INDEX B)",
                    style = MaterialTheme.typography.labelMedium,
                    color = TerminalCyan,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                overlapResult.sectorDivergences.take(6).forEach { sec ->
                    val isPos = sec.differencePct >= 0
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(sec.sector.sectorName, style = MaterialTheme.typography.bodySmall, color = TermOffWhite, modifier = Modifier.width(140.dp), maxLines = 1)
                        Text("${String.format(Locale.US, "%.1f", sec.weightA)}%", style = MaterialTheme.typography.labelSmall, color = TerminalGold, fontFamily = FontFamily.Monospace)
                        Text("${String.format(Locale.US, "%.1f", sec.weightB)}%", style = MaterialTheme.typography.labelSmall, color = TerminalCyan, fontFamily = FontFamily.Monospace)
                        Text(
                            text = "${if (isPos) "+" else ""}${String.format(Locale.US, "%.1f", sec.differencePct)}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (isPos) TermGreen else TermRed
                        )
                    }
                }
            }
        }

        // 5. Shared Constituents Breakdown Table
        item {
            Text(
                text = "TOP SHARED CONSTITUENTS BREAKDOWN",
                style = MaterialTheme.typography.labelMedium,
                color = TermWhite,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(overlapResult.topSharedItems.take(15)) { item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.width(120.dp)) {
                    Text(item.ticker, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TermWhite)
                    Text(item.companyName, style = MaterialTheme.typography.bodySmall, color = TermGray, fontSize = 10.sp, maxLines = 1)
                }

                Text(
                    text = "A: ${String.format(Locale.US, "%.2f", item.weightA)}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = TerminalGold,
                    fontFamily = FontFamily.Monospace
                )

                Text(
                    text = "B: ${String.format(Locale.US, "%.2f", item.weightB)}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = TerminalCyan,
                    fontFamily = FontFamily.Monospace
                )

                Text(
                    text = "Min: ${String.format(Locale.US, "%.2f", item.minWeightOverlap)}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = TermGreen,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
