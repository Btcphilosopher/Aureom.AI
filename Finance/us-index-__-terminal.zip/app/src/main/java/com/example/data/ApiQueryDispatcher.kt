package com.example.data

import com.example.domain.model.ApiEndpointDoc
import com.example.domain.model.IndexDefinition
import java.util.Locale

object ApiQueryDispatcher {

    fun getAllEndpointDocs(): List<ApiEndpointDoc> {
        return listOf(
            ApiEndpointDoc(
                method = "GET",
                path = "/api/v1/indices",
                category = "Core Indices",
                title = "List All Active Indices",
                description = "Returns real-time and synthetic index states, calculation frequencies, and divisors.",
                sampleRequest = "curl -H \"Authorization: Bearer ais_live_sec_key\" https://api.usindex.ais.io/v1/indices",
                sampleResponseJson = """
{
  "status": "success",
  "provenance": "SYNTHETIC",
  "count": 8,
  "data": [
    {
      "index_id": "IDX-SP500",
      "ticker": "SP500",
      "name": "S&P 500 Index",
      "level": 6042.85,
      "change_pct": 0.51,
      "divisor": 8421.458,
      "methodology_version": "v2026.4.1"
    }
  ]
}
                """.trimIndent()
            ),
            ApiEndpointDoc(
                method = "GET",
                path = "/api/v1/indices/{index_id}/constituents",
                category = "Constituent Master",
                title = "Get Index Constituents & Weights",
                description = "Returns complete constituent table with float factor, shares, price, weight, and 1D contribution.",
                sampleRequest = "curl -H \"Authorization: Bearer ais_live_sec_key\" https://api.usindex.ais.io/v1/indices/SP500/constituents?sort=weight&direction=desc",
                sampleResponseJson = """
{
  "index_id": "IDX-SP500",
  "as_of_timestamp": "2026-10-06T14:30:00Z",
  "total_float_market_cap_billions": 50820.4,
  "constituents_count": 503,
  "data": [
    {
      "ticker": "NVDA",
      "company_name": "NVIDIA Corporation",
      "weight_pct": 7.24,
      "shares_million": 24500.0,
      "float_factor": 0.954,
      "price": 148.60,
      "daily_return_pct": 2.55,
      "contribution_pct": 0.184,
      "exchange": "NASDAQ"
    },
    {
      "ticker": "AAPL",
      "company_name": "Apple Inc.",
      "weight_pct": 7.18,
      "shares_million": 15204.0,
      "float_factor": 0.998,
      "price": 238.50,
      "daily_return_pct": 1.02,
      "contribution_pct": 0.073,
      "exchange": "NASDAQ"
    }
  ]
}
                """.trimIndent()
            ),
            ApiEndpointDoc(
                method = "GET",
                path = "/api/v1/indices/{index_id}/attribution",
                category = "Attribution & Analytics",
                title = "Sector & Factor Performance Attribution",
                description = "Mathematical Brinson-style attribution explaining why the index moved.",
                sampleRequest = "curl https://api.usindex.ais.io/v1/indices/SP500/attribution?period=1D",
                sampleResponseJson = """
{
  "index_ticker": "SP500",
  "period": "1D",
  "index_return_pct": 0.51,
  "sector_contributions": [
    { "sector": "Information Technology", "weight_pct": 32.4, "return_pct": 1.14, "contribution_pct": 0.369 },
    { "sector": "Financials", "weight_pct": 13.8, "return_pct": 0.62, "contribution_pct": 0.086 },
    { "sector": "Health Care", "weight_pct": 11.5, "return_pct": -0.34, "contribution_pct": -0.039 }
  ]
}
                """.trimIndent()
            ),
            ApiEndpointDoc(
                method = "GET",
                path = "/api/v1/indices/{index_id}/breadth",
                category = "Market Microstructure",
                title = "Index Breadth & Moving Average Dispersion",
                description = "Advance/Decline counts, 50DMA/200DMA proportions, and Cap-Weighted vs Equal-Weighted spread.",
                sampleRequest = "curl https://api.usindex.ais.io/v1/indices/SP500/breadth",
                sampleResponseJson = """
{
  "index_ticker": "SP500",
  "advancers": 318,
  "decliners": 164,
  "unchanged": 21,
  "ad_ratio": 1.94,
  "pct_above_50dma": 68.4,
  "pct_above_200dma": 74.2,
  "equal_weight_return_pct": 0.68,
  "cap_weight_return_pct": 0.51,
  "divergence_bps": 17.0
}
                """.trimIndent()
            ),
            ApiEndpointDoc(
                method = "POST",
                path = "/api/v1/research/rebalance",
                category = "Quantitative Research",
                title = "Simulate Index Reconstitution",
                description = "Simulates Russell-style or S&P-style reconstitution turnover, additions, deletions, and sector shifts.",
                sampleRequest = "curl -X POST https://api.usindex.ais.io/v1/research/rebalance -d '{\"index\":\"RUSSELL2000\",\"date\":\"2026-06-26\"}'",
                sampleResponseJson = """
{
  "target_index": "RUSSELL2000",
  "projected_turnover_pct": 7.45,
  "projected_turnover_billions": 170.2,
  "expected_additions_count": 42,
  "expected_deletions_count": 39,
  "projected_tracking_error_bps": 8.0
}
                """.trimIndent()
            ),
            ApiEndpointDoc(
                method = "POST",
                path = "/api/v1/research/scenario",
                category = "Quantitative Research",
                title = "Stress Test Scenario Engine",
                description = "Applies instantaneous multi-factor and sector shocks to recalculate index levels.",
                sampleRequest = "curl -X POST https://api.usindex.ais.io/v1/research/scenario -d '{\"index\":\"SP500\",\"tech_shock\":-15.0,\"rates_shock_bps\":100}'",
                sampleResponseJson = """
{
  "scenario": "Custom Shock",
  "baseline_level": 6042.85,
  "stressed_level": 5740.71,
  "points_delta": -302.14,
  "percent_delta": -5.00,
  "top_negative_driver": "NVDA (-1.08% contribution)"
}
                """.trimIndent()
            )
        )
    }

    fun executeTerminalQuery(query: String, indexMap: Map<String, IndexDefinition>): String {
        val q = query.trim()
        val upper = q.uppercase(Locale.US)

        return when {
            upper.startsWith("INDEX ") -> {
                val parts = upper.removePrefix("INDEX ").trim().split(" ")
                val ticker = parts.firstOrNull() ?: "SP500"
                val index = indexMap[ticker] ?: indexMap.values.find { it.ticker.equals(ticker, ignoreCase = true) }
                if (index == null) {
                    """{ "error": "Index '$ticker' not found in Security Master.", "status": 404 }"""
                } else if (parts.contains("CONSTITUENTS")) {
                    """
{
  "status": 200,
  "index": "${index.ticker}",
  "name": "${index.name}",
  "constituent_count": ${index.constituents.size},
  "top_constituents": [
${index.constituents.take(5).joinToString(",\n") { c ->
    "    { \"ticker\": \"${c.ticker}\", \"weight_pct\": ${String.format(Locale.US, "%.2f", c.weight)}, \"price\": ${c.price}, \"sector\": \"${c.sector.sectorName}\" }"
}}
  ]
}
                    """.trimIndent()
                } else {
                    """
{
  "status": 200,
  "index_id": "${index.indexId}",
  "ticker": "${index.ticker}",
  "name": "${index.name}",
  "level": ${String.format(Locale.US, "%.2f", index.currentLevel)},
  "change_points": ${String.format(Locale.US, "%.2f", index.changePoints)},
  "change_pct": ${String.format(Locale.US, "%.2f", index.changePercent)}%,
  "weighting_method": "${index.weightingMethod.name}",
  "divisor": ${index.divisor},
  "market_cap_trillions": ${String.format(Locale.US, "%.2f", index.totalMarketCapTrillions)}
}
                    """.trimIndent()
                }
            }
            upper.startsWith("BREADTH") -> {
                val ticker = upper.removePrefix("BREADTH").trim().ifEmpty { "SP500" }
                val index = indexMap[ticker] ?: indexMap["SP500"]!!
                val b = index.breadth
                """
{
  "status": 200,
  "index": "${index.ticker}",
  "advancers": ${b?.advancers ?: 0},
  "decliners": ${b?.decliners ?: 0},
  "ad_ratio": ${String.format(Locale.US, "%.2f", b?.adRatio ?: 1.0)},
  "pct_above_50dma": ${b?.pctAbove50Dma ?: 0.0}%,
  "pct_above_200dma": ${b?.pctAbove200Dma ?: 0.0}%,
  "equal_weight_spread_pct": ${String.format(Locale.US, "%.2f", b?.divergenceSpreadPct ?: 0.0)}%
}
                """.trimIndent()
            }
            upper.startsWith("ATTRIBUTION") -> {
                val ticker = upper.removePrefix("ATTRIBUTION").trim().ifEmpty { "SP500" }
                val index = indexMap[ticker] ?: indexMap["SP500"]!!
                """
{
  "status": 200,
  "index": "${index.ticker}",
  "daily_return_pct": ${String.format(Locale.US, "%.2f", index.changePercent)}%,
  "sector_attribution": [
${index.sectors.joinToString(",\n") { s ->
    "    { \"sector\": \"${s.sector.sectorName}\", \"weight_pct\": ${String.format(Locale.US, "%.2f", s.weightPercent)}, \"contrib_pct\": ${String.format(Locale.US, "%.3f", s.contributionPercent)} }"
}}
  ]
}
                """.trimIndent()
            }
            upper.startsWith("COMPARE ") || upper.startsWith("OVERLAP ") -> {
                val parts = upper.replace("COMPARE ", "").replace("OVERLAP ", "").trim().split(" ")
                val a = parts.getOrNull(0) ?: "SP500"
                val b = parts.getOrNull(1) ?: "NASDAQ100"
                """
{
  "status": 200,
  "pair": "$a vs $b",
  "weight_overlap_pct": 58.42,
  "shared_constituents": 78,
  "correlation_1y": 0.914,
  "tracking_diff_1y": 4.85
}
                """.trimIndent()
            }
            upper.startsWith("REBALANCE") -> {
                val ticker = upper.removePrefix("REBALANCE").trim().ifEmpty { "RUSSELL2000" }
                """
{
  "status": 200,
  "action": "SIMULATED_RECONSTITUTION",
  "index": "$ticker",
  "expected_turnover_pct": 7.45,
  "expected_turnover_billions": 170.2,
  "venue_eligibility": "NYSE, NASDAQ, CBOE, TXSE continuous trading qualified"
}
                """.trimIndent()
            }
            upper.startsWith("SCENARIO") -> {
                """
{
  "status": 200,
  "scenario": "Stress Shock Executed",
  "query": "$query",
  "result": "Stressed Index Level recalculated deterministically."
}
                """.trimIndent()
            }
            else -> {
                """
{
  "status": 200,
  "query_echo": "$query",
  "message": "Query executed against AIS Institutional Index Server.",
  "timestamp": "${System.currentTimeMillis()}"
}
                """.trimIndent()
            }
        }
    }
}
