package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Constituent
import com.example.domain.model.CorporateActionEvent
import com.example.domain.model.ExchangeVenue
import com.example.domain.model.IndexDefinition
import com.example.domain.model.SectorGICS
import com.example.ui.ConstituentSortBy
import com.example.ui.DetailSubTab
import com.example.ui.components.MetricBadge
import com.example.ui.components.SectorWaterfallChart
import com.example.ui.theme.TermDarkGray
import com.example.ui.theme.TermGray
import com.example.ui.theme.TermGreen
import com.example.ui.theme.TermOffWhite
import com.example.ui.theme.TermRed
import com.example.ui.theme.TermWhite
import com.example.ui.theme.TerminalAmber
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBlue
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCyan
import com.example.ui.theme.TerminalDarkBlue
import com.example.ui.theme.TerminalGold
import com.example.ui.theme.TerminalMutedAmber
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceBright
import com.example.ui.theme.TerminalSurfaceVariant
import java.util.Locale

@Composable
fun IndexDetailScreen(
    indexDef: IndexDefinition?,
    allIndices: Map<String, IndexDefinition>,
    activeSubTab: DetailSubTab,
    onSubTabSelected: (DetailSubTab) -> Unit,
    onSelectIndex: (String) -> Unit,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedSector: SectorGICS?,
    onSectorFilter: (SectorGICS?) -> Unit,
    sortOption: ConstituentSortBy,
    onSortOptionSelected: (ConstituentSortBy) -> Unit,
    filteredConstituents: List<Constituent>,
    auditedActions: List<CorporateActionEvent>,
    modifier: Modifier = Modifier
) {
    if (indexDef == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select an index from the top monitor.", color = TermGray)
        }
        return
    }

    val isPos = indexDef.changePercent >= 0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBg)
    ) {
        // 1. Index Selector Pill Row
        val indexScroll = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(indexScroll)
                .background(TerminalSurface)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            allIndices.keys.forEach { ticker ->
                val selected = ticker == indexDef.ticker
                Box(
                    modifier = Modifier
                        .background(
                            if (selected) TerminalCyan else TerminalSurfaceVariant,
                            RoundedCornerShape(3.dp)
                        )
                        .clickable { onSelectIndex(ticker) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("detail_select_$ticker")
                ) {
                    Text(
                        text = ticker,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (selected) TerminalBg else TermOffWhite
                    )
                }
            }
        }

        // 2. Index Hero Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = TerminalSurfaceVariant,
            shadowElevation = 2.dp
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(
                            text = "${indexDef.name} [${indexDef.ticker}]",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TermWhite
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${indexDef.provider} • ${indexDef.methodologyVersion}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TermGray,
                            fontSize = 11.sp
                        )
                    }

                    // Provenance & Venue Badge
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = indexDef.provenance.code,
                            style = MaterialTheme.typography.labelSmall,
                            color = TerminalGold,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(TerminalMutedAmber, RoundedCornerShape(3.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = String.format(Locale.US, "%,.2f", indexDef.currentLevel),
                            style = MaterialTheme.typography.displayMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TermWhite
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isPos) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                contentDescription = null,
                                tint = if (isPos) TermGreen else TermRed,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "${if (isPos) "+" else ""}${String.format(Locale.US, "%.2f", indexDef.changePoints)} (${if (isPos) "+" else ""}${String.format(Locale.US, "%.2f", indexDef.changePercent)}%)",
                                style = MaterialTheme.typography.titleSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isPos) TermGreen else TermRed
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Divisor: ${String.format(Locale.US, "%.4f", indexDef.divisor)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TermGray,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Float Cap: $${String.format(Locale.US, "%.2f", indexDef.totalMarketCapTrillions)}T",
                            style = MaterialTheme.typography.labelSmall,
                            color = TerminalCyan,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 3. Sub-Tabs Bar
        val subTabScroll = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(subTabScroll)
                .background(TerminalSurface)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            DetailSubTab.entries.forEach { subTab ->
                val isSelected = subTab == activeSubTab
                Box(
                    modifier = Modifier
                        .background(
                            if (isSelected) TerminalCyan else TerminalBg,
                            RoundedCornerShape(3.dp)
                        )
                        .border(
                            1.dp,
                            if (isSelected) TerminalCyan else TerminalBorder,
                            RoundedCornerShape(3.dp)
                        )
                        .clickable { onSubTabSelected(subTab) }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                        .testTag("subtab_${subTab.name}")
                ) {
                    Text(
                        text = subTab.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) TerminalBg else TermOffWhite
                    )
                }
            }
        }

        // 4. Sub-Tab Body Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            when (activeSubTab) {
                DetailSubTab.OVERVIEW -> {
                    OverviewSubScreen(indexDef = indexDef)
                }
                DetailSubTab.CONSTITUENTS -> {
                    ConstituentsSubScreen(
                        indexDef = indexDef,
                        searchQuery = searchQuery,
                        onSearchChange = onSearchChange,
                        selectedSector = selectedSector,
                        onSectorFilter = onSectorFilter,
                        sortOption = sortOption,
                        onSortOptionSelected = onSortOptionSelected,
                        constituents = filteredConstituents
                    )
                }
                DetailSubTab.SECTORS -> {
                    SectorWaterfallChart(sectors = indexDef.sectors)
                }
                DetailSubTab.ATTRIBUTION -> {
                    AttributionSubScreen(indexDef = indexDef)
                }
                DetailSubTab.BREADTH -> {
                    BreadthSubScreen(indexDef = indexDef)
                }
                DetailSubTab.RISK -> {
                    RiskSubScreen(indexDef = indexDef)
                }
                DetailSubTab.DIVISOR_AUDIT -> {
                    DivisorAuditSubScreen(indexDef = indexDef, auditedActions = auditedActions)
                }
                DetailSubTab.METHODOLOGY -> {
                    MethodologySubScreen(indexDef = indexDef)
                }
            }
        }
    }
}

@Composable
private fun OverviewSubScreen(indexDef: IndexDefinition) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "METHODOLOGY & WEIGHTING SPECIFICATION",
                        style = MaterialTheme.typography.labelMedium,
                        color = TerminalGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = indexDef.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TermOffWhite
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MetricBadge(
                            label = "Weight Method",
                            value = indexDef.weightingMethod.name.take(10),
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "Review Cycle",
                            value = indexDef.reviewSchedule.name,
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "Constituents",
                            value = "${indexDef.constituentCount}",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "BASE SPECIFICATION & METRIC LEDGER",
                        style = MaterialTheme.typography.labelMedium,
                        color = TerminalCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Base Date:", style = MaterialTheme.typography.bodySmall, color = TermGray)
                        Text(indexDef.baseDate, style = MaterialTheme.typography.bodySmall, color = TermWhite, fontFamily = FontFamily.Monospace)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Base Level Value:", style = MaterialTheme.typography.bodySmall, color = TermGray)
                        Text("${indexDef.baseValue}", style = MaterialTheme.typography.bodySmall, color = TermWhite, fontFamily = FontFamily.Monospace)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Active Divisor (D):", style = MaterialTheme.typography.bodySmall, color = TermGray)
                        Text("${indexDef.divisor}", style = MaterialTheme.typography.bodySmall, color = TerminalGold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Calculation Frequency:", style = MaterialTheme.typography.bodySmall, color = TermGray)
                        Text(indexDef.calculationFrequency.label, style = MaterialTheme.typography.bodySmall, color = TermGreen, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
private fun ConstituentsSubScreen(
    indexDef: IndexDefinition,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedSector: SectorGICS?,
    onSectorFilter: (SectorGICS?) -> Unit,
    sortOption: ConstituentSortBy,
    onSortOptionSelected: (ConstituentSortBy) -> Unit,
    constituents: List<Constituent>
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Search & Filter controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("constituent_search"),
                placeholder = { Text("Filter Ticker / Company...", style = MaterialTheme.typography.bodySmall, color = TermDarkGray) },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TerminalCyan, modifier = Modifier.size(16.dp)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TerminalCyan,
                    unfocusedBorderColor = TerminalBorder,
                    focusedTextColor = TermWhite,
                    unfocusedTextColor = TermWhite
                )
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Sector filter horizontal scroll
        val sectorScroll = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(sectorScroll),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .background(if (selectedSector == null) TerminalCyan else TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                    .clickable { onSectorFilter(null) }
                    .padding(horizontal = 6.dp, vertical = 3.dp)
            ) {
                Text("ALL SECTORS", style = MaterialTheme.typography.labelSmall, color = if (selectedSector == null) TerminalBg else TermGray, fontSize = 9.sp)
            }
            SectorGICS.entries.forEach { s ->
                val isSel = selectedSector == s
                Box(
                    modifier = Modifier
                        .background(if (isSel) TerminalCyan else TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                        .clickable { onSectorFilter(s) }
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(s.code, style = MaterialTheme.typography.labelSmall, color = if (isSel) TerminalBg else TermOffWhite, fontSize = 9.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalSurfaceVariant)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "TICKER / CO",
                style = MaterialTheme.typography.labelSmall,
                color = TermGray,
                modifier = Modifier.clickable { onSortOptionSelected(ConstituentSortBy.TICKER) }
            )
            Text(
                text = "PRICE / RET",
                style = MaterialTheme.typography.labelSmall,
                color = TermGray,
                modifier = Modifier.clickable { onSortOptionSelected(ConstituentSortBy.DAILY_RETURN) }
            )
            Text(
                text = "WEIGHT %",
                style = MaterialTheme.typography.labelSmall,
                color = TerminalGold,
                modifier = Modifier.clickable { onSortOptionSelected(ConstituentSortBy.WEIGHT) }
            )
            Text(
                text = "CONTRIB %",
                style = MaterialTheme.typography.labelSmall,
                color = TerminalCyan,
                modifier = Modifier.clickable { onSortOptionSelected(ConstituentSortBy.CONTRIBUTION) }
            )
        }

        // Constituents Rows
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(constituents) { c ->
                val isPos = c.dailyReturn >= 0
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalSurface)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.width(110.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = c.ticker,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TermWhite
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = c.primaryExchange.code,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (c.primaryExchange == ExchangeVenue.TXSE) TerminalGold else TermDarkGray,
                                fontSize = 8.sp,
                                fontWeight = if (c.primaryExchange == ExchangeVenue.TXSE) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                        Text(
                            text = c.companyName,
                            style = MaterialTheme.typography.bodySmall,
                            color = TermGray,
                            fontSize = 10.sp,
                            maxLines = 1
                        )
                    }

                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.width(70.dp)) {
                        Text(
                            text = "$${String.format(Locale.US, "%.2f", c.price)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = TermWhite
                        )
                        Text(
                            text = "${if (isPos) "+" else ""}${String.format(Locale.US, "%.2f", c.dailyReturn)}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (isPos) TermGreen else TermRed
                        )
                    }

                    Text(
                        text = "${String.format(Locale.US, "%.2f", c.weight)}%",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = TerminalGold,
                        modifier = Modifier.width(60.dp)
                    )

                    Text(
                        text = "${if (c.contribution >= 0) "+" else ""}${String.format(Locale.US, "%.3f", c.contribution)}%",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (c.contribution >= 0) TermGreen else TermRed,
                        modifier = Modifier.width(70.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AttributionSubScreen(indexDef: IndexDefinition) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "BRINSON SECTOR ALLOCATION & SELECTION ATTRIBUTION",
                        style = MaterialTheme.typography.labelMedium,
                        color = TerminalGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Mathematical decomposition of index movement into systematic sector allocation effect, stock selection contribution, and interaction effect.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TermGray
                    )
                }
            }
        }

        item {
            SectorWaterfallChart(sectors = indexDef.sectors)
        }
    }
}

@Composable
private fun BreadthSubScreen(indexDef: IndexDefinition) {
    val b = indexDef.breadth ?: return
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "ADVANCE / DECLINE & MOVING AVERAGE METRICS",
                        style = MaterialTheme.typography.labelMedium,
                        color = TerminalCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MetricBadge(label = "Advancing", value = "${b.advancers}", modifier = Modifier.weight(1f))
                        MetricBadge(label = "Declining", value = "${b.decliners}", modifier = Modifier.weight(1f))
                        MetricBadge(label = "Unchanged", value = "${b.unchanged}", modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MetricBadge(label = "A/D Ratio", value = String.format(Locale.US, "%.2f", b.adRatio), modifier = Modifier.weight(1f))
                        MetricBadge(label = "Above 50 DMA", value = "${b.pctAbove50Dma}%", modifier = Modifier.weight(1f))
                        MetricBadge(label = "Above 200 DMA", value = "${b.pctAbove200Dma}%", modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun RiskSubScreen(indexDef: IndexDefinition) {
    val r = indexDef.riskMetrics ?: return
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "PORTFOLIO CONCENTRATION & HERFINDAHL INDEX",
                        style = MaterialTheme.typography.labelMedium,
                        color = TerminalGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MetricBadge(
                            label = "HHI Concentration",
                            value = String.format(Locale.US, "%.4f", r.herfindahlIndex),
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "Effective Stocks (N_eff)",
                            value = String.format(Locale.US, "%.1f", r.effectiveConstituentCount),
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "Beta vs Market",
                            value = String.format(Locale.US, "%.2f", r.beta),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MetricBadge(
                            label = "Daily 95% VaR",
                            value = "${String.format(Locale.US, "%.2f", r.var95DailyPct)}%",
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "Daily 95% CVaR",
                            value = "${String.format(Locale.US, "%.2f", r.cvar95DailyPct)}%",
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "Sharpe (Rf=4.25%)",
                            value = String.format(Locale.US, "%.2f", r.sharpeRatio),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DivisorAuditSubScreen(indexDef: IndexDefinition, auditedActions: List<CorporateActionEvent>) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "DIVISOR ADJUSTMENT AUDIT LEDGER",
                        style = MaterialTheme.typography.labelMedium,
                        color = TerminalCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Every corporate action triggers a deterministic divisor formula D_new = D_old * (Cap_after / Cap_before) so that index points reflect only legitimate economic price movement.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TermGray
                    )
                }
            }
        }

        items(auditedActions) { act ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${act.eventId} • ${act.ticker}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = TerminalGold
                        )
                        Text(
                            text = act.effectiveDate,
                            style = MaterialTheme.typography.labelSmall,
                            color = TermGray,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = act.type.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = TerminalCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = act.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TermOffWhite,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Divisor: ${String.format(Locale.US, "%.3f", act.oldDivisor)} → ${String.format(Locale.US, "%.3f", act.newDivisor)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TermGray,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Impact: ${String.format(Locale.US, "%.2f", act.indexImpactPoints)} pts",
                            style = MaterialTheme.typography.labelSmall,
                            color = TermGreen,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MethodologySubScreen(indexDef: IndexDefinition) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(TerminalBorder))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "VERSIONED METHODOLOGY RULES & EXCHANGE ELIGIBILITY",
                        style = MaterialTheme.typography.labelMedium,
                        color = TerminalGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "1. Security Universe: U.S. common stocks listed on eligible national securities exchanges.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TermWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "2. Exchange Eligibility Engine: NYSE, NYSE American, NYSE Arca, Nasdaq, Cboe, and Texas Stock Exchange (TXSE continuous trading qualified).",
                        style = MaterialTheme.typography.bodySmall,
                        color = TermOffWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "3. Float Adjustment: Investable Weight Factor (IWF) applied to remove non-free-float insider and strategic holdings.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TermOffWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "4. Rebalance & Review: Semiannual / quarterly rank dates with 2.5% buffer bands to minimize portfolio turnover.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TermOffWhite
                    )
                }
            }
        }
    }
}
