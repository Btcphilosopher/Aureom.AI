package com.example.calculation

import com.example.domain.model.IndexDefinition
import com.example.domain.model.ScenarioStressResult
import com.example.domain.model.SectorGICS

object ScenarioEngine {

    fun executeStressScenario(
        index: IndexDefinition,
        scenarioName: String,
        techShockPct: Double = 0.0,
        finShockPct: Double = 0.0,
        energyShockPct: Double = 0.0,
        ratesShockBps: Double = 0.0,
        usdShockPct: Double = 0.0,
        megaCapShockPct: Double = 0.0
    ): ScenarioStressResult {
        val constituents = index.constituents
        if (constituents.isEmpty()) {
            return ScenarioStressResult(
                scenarioName = scenarioName,
                targetIndexTicker = index.ticker,
                baselineLevel = index.currentLevel,
                stressedLevel = index.currentLevel,
                sectorImpacts = emptyList(),
                topPositiveDrivers = emptyList(),
                topNegativeDrivers = emptyList()
            )
        }

        // Rate sensitivity mapping (Growth down on rate spike, Financials slight up)
        val rateEffectTech = -(ratesShockBps / 100.0) * 1.8
        val rateEffectUtilities = -(ratesShockBps / 100.0) * 2.2
        val rateEffectRealEstate = -(ratesShockBps / 100.0) * 2.5
        val rateEffectFin = (ratesShockBps / 100.0) * 0.9

        // FX sensitivity
        val usdEffectEnergy = -(usdShockPct * 0.6)
        val usdEffectTech = -(usdShockPct * 0.4)

        val sectorShockMap = mapOf(
            SectorGICS.INFORMATION_TECHNOLOGY to (techShockPct + rateEffectTech + usdEffectTech),
            SectorGICS.FINANCIALS to (finShockPct + rateEffectFin),
            SectorGICS.ENERGY to (energyShockPct + usdEffectEnergy),
            SectorGICS.UTILITIES to rateEffectUtilities,
            SectorGICS.REAL_ESTATE to rateEffectRealEstate,
            SectorGICS.COMMUNICATION_SERVICES to (techShockPct * 0.8 + rateEffectTech * 0.7),
            SectorGICS.CONSUMER_DISCRETIONARY to (techShockPct * 0.5 - (ratesShockBps / 100.0) * 0.8),
            SectorGICS.HEALTH_CARE to 0.0,
            SectorGICS.INDUSTRIALS to -(ratesShockBps / 100.0) * 0.5,
            SectorGICS.CONSUMER_STAPLES to 0.0,
            SectorGICS.MATERIALS to -(usdShockPct * 0.5)
        )

        val constituentImpacts = constituents.map { c ->
            var stockReturn = sectorShockMap[c.sector] ?: 0.0
            if (c.weight > 3.0 && megaCapShockPct != 0.0) {
                stockReturn += megaCapShockPct
            }
            // Contribution = weight * return / 100
            val contrib = (c.weight * stockReturn) / 100.0
            Triple(c.ticker, stockReturn, contrib)
        }

        val totalReturnPct = constituentImpacts.sumOf { it.third }
        val stressedLevel = index.currentLevel * (1.0 + (totalReturnPct / 100.0))

        val sectorImpacts = SectorGICS.entries.map { sector ->
            val secItems = constituentImpacts.filter { item ->
                constituents.find { it.ticker == item.first }?.sector == sector
            }
            val secContrib = secItems.sumOf { it.third }
            sector to secContrib
        }.sortedByDescending { it.second }

        val topPos = constituentImpacts.filter { it.second > 0 }.sortedByDescending { it.third }.take(5).map { it.first to it.third }
        val topNeg = constituentImpacts.filter { it.second < 0 }.sortedBy { it.third }.take(5).map { it.first to it.third }

        return ScenarioStressResult(
            scenarioName = scenarioName,
            targetIndexTicker = index.ticker,
            baselineLevel = index.currentLevel,
            stressedLevel = stressedLevel,
            techShockPct = techShockPct,
            finShockPct = finShockPct,
            energyShockPct = energyShockPct,
            ratesShockBps = ratesShockBps,
            usdShockPct = usdShockPct,
            sectorImpacts = sectorImpacts,
            topPositiveDrivers = topPos,
            topNegativeDrivers = topNeg
        )
    }
}
