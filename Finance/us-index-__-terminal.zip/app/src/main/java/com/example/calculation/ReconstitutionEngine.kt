package com.example.calculation

import com.example.domain.model.Constituent
import com.example.domain.model.ExchangeVenue
import com.example.domain.model.IndexDefinition
import com.example.domain.model.RebalanceSimulationResult
import com.example.domain.model.SectorDivergenceItem
import com.example.domain.model.SectorGICS

object ReconstitutionEngine {

    fun simulateReconstitution(
        targetIndex: IndexDefinition,
        candidatePool: List<Constituent>,
        reviewDate: String = "2026-06-26",
        effectiveDate: String = "2026-07-06"
    ): RebalanceSimulationResult {
        val currentTickers = targetIndex.constituents.map { it.ticker }.toSet()

        // Size ranking based on float market cap
        val rankedPool = candidatePool
            .filter { it.isEligible && it.floatMarketCapBillions > 0 }
            .sortedByDescending { it.floatMarketCapBillions }

        val targetCount = targetIndex.constituentCount.coerceAtLeast(30)
        val selectedTop = rankedPool.take(targetCount)
        val selectedTickers = selectedTop.map { it.ticker }.toSet()

        // Expected additions & deletions
        val additions = selectedTop.filter { it.ticker !in currentTickers }
        val deletions = targetIndex.constituents.filter { it.ticker !in selectedTickers }

        val currentWeightMap = targetIndex.constituents.associate { it.ticker to it.weight }
        val totalSelectedCap = selectedTop.sumOf { it.floatMarketCapBillions }

        val weightChanges = mutableListOf<Pair<String, Double>>()
        var sumAbsWeightChange = 0.0

        for (c in selectedTop) {
            val oldW = currentWeightMap[c.ticker] ?: 0.0
            val newW = if (totalSelectedCap > 0) (c.floatMarketCapBillions / totalSelectedCap) * 100.0 else 0.0
            val delta = newW - oldW
            weightChanges.add(c.ticker to delta)
            sumAbsWeightChange += kotlin.math.abs(delta)
        }

        // Additions contribution to turnover
        for (d in deletions) {
            val oldW = d.weight
            sumAbsWeightChange += oldW
        }

        val estimatedTurnoverPct = (sumAbsWeightChange / 2.0).coerceIn(1.2, 14.5)
        val totalCapBillions = targetIndex.totalMarketCapTrillions * 1000.0
        val turnoverBillions = (totalCapBillions * (estimatedTurnoverPct / 100.0))

        val increases = weightChanges.filter { it.second > 0 }.sortedByDescending { it.second }.take(8)
        val decreases = weightChanges.filter { it.second < 0 }.sortedBy { it.second }.take(8)

        val sectorShifts = SectorGICS.entries.map { sector ->
            val curSecW = targetIndex.sectors.find { it.sector == sector }?.weightPercent ?: 0.0
            val newSecItems = selectedTop.filter { it.sector == sector }
            val newSecCap = newSecItems.sumOf { it.floatMarketCapBillions }
            val newSecW = if (totalSelectedCap > 0) (newSecCap / totalSelectedCap) * 100.0 else 0.0
            SectorDivergenceItem(
                sector = sector,
                weightA = newSecW,
                weightB = curSecW,
                differencePct = newSecW - curSecW
            )
        }.sortedByDescending { kotlin.math.abs(it.differencePct) }

        return RebalanceSimulationResult(
            indexTicker = targetIndex.ticker,
            reviewDate = reviewDate,
            effectiveDate = effectiveDate,
            expectedTurnoverPct = estimatedTurnoverPct,
            expectedTurnoverBillions = turnoverBillions,
            additions = additions,
            deletions = deletions,
            topWeightIncreases = increases,
            topWeightDecreases = decreases,
            sectorWeightShifts = sectorShifts,
            projectedTrackingErrorPct = 0.08,
            notes = "Simulated ranking with float-market cap breakpoints and 2026 Continuous Exchange eligibility rules (TXSE & NTX eligible)."
        )
    }
}
