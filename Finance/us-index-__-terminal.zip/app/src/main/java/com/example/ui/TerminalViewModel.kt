package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.calculation.MonteCarloEngine
import com.example.calculation.OverlapEngine
import com.example.calculation.ReconstitutionEngine
import com.example.calculation.ScenarioEngine
import com.example.data.ApiQueryDispatcher
import com.example.data.CorporateActionStore
import com.example.data.IndexRepository
import com.example.data.SyntheticMarketUniverse
import com.example.domain.model.ApiEndpointDoc
import com.example.domain.model.Constituent
import com.example.domain.model.CorporateActionEvent
import com.example.domain.model.CustomIndexConfig
import com.example.domain.model.FactorType
import com.example.domain.model.IndexDefinition
import com.example.domain.model.MonteCarloResult
import com.example.domain.model.OverlapResult
import com.example.domain.model.RebalanceSimulationResult
import com.example.domain.model.ScenarioStressResult
import com.example.domain.model.SectorGICS
import com.example.domain.model.TerminalAlert
import com.example.domain.model.WeightingMethod
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

data class StressParams(
    val tech: Double = -10.0,
    val fin: Double = 5.0,
    val energy: Double = 15.0,
    val rates: Double = 75.0,
    val usd: Double = 3.0,
    val megaCap: Double = -5.0
)

class TerminalViewModel : ViewModel() {

    private val repository = IndexRepository(viewModelScope)

    val indices: StateFlow<Map<String, IndexDefinition>> = repository.indices
    val customIndices: StateFlow<List<CustomIndexConfig>> = repository.customIndices
    val alerts: StateFlow<List<TerminalAlert>> = repository.alerts
    val tickCounter: StateFlow<Long> = repository.tickCounter

    private val _activeTab = MutableStateFlow(TerminalTab.MONITOR)
    val activeTab: StateFlow<TerminalTab> = _activeTab.asStateFlow()

    private val _selectedIndexTicker = MutableStateFlow("SP500")
    val selectedIndexTicker: StateFlow<String> = _selectedIndexTicker.asStateFlow()

    private val _selectedComparativeTicker = MutableStateFlow("NASDAQ100")
    val selectedComparativeTicker: StateFlow<String> = _selectedComparativeTicker.asStateFlow()

    private val _activeDetailSubTab = MutableStateFlow(DetailSubTab.OVERVIEW)
    val activeDetailSubTab: StateFlow<DetailSubTab> = _activeDetailSubTab.asStateFlow()

    // Constituent filtering & sorting
    private val _constituentSearch = MutableStateFlow("")
    val constituentSearch: StateFlow<String> = _constituentSearch.asStateFlow()

    private val _sectorFilter = MutableStateFlow<SectorGICS?>(null)
    val sectorFilter: StateFlow<SectorGICS?> = _sectorFilter.asStateFlow()

    private val _constituentSort = MutableStateFlow(ConstituentSortBy.WEIGHT)
    val constituentSort: StateFlow<ConstituentSortBy> = _constituentSort.asStateFlow()

    // Scenario Stress Test Parameters encapsulated
    private val _stressParams = MutableStateFlow(StressParams())
    val stressParams: StateFlow<StressParams> = _stressParams.asStateFlow()

    // Command palette
    private val _commandPaletteOpen = MutableStateFlow(false)
    val commandPaletteOpen: StateFlow<Boolean> = _commandPaletteOpen.asStateFlow()

    private val _commandInput = MutableStateFlow("")
    val commandInput: StateFlow<String> = _commandInput.asStateFlow()

    // API Console
    private val _apiConsoleInput = MutableStateFlow("GET /api/v1/indices/SP500/constituents")
    val apiConsoleInput: StateFlow<String> = _apiConsoleInput.asStateFlow()

    private val _apiConsoleOutput = MutableStateFlow("")
    val apiConsoleOutput: StateFlow<String> = _apiConsoleOutput.asStateFlow()

    private val _selectedEndpointDoc = MutableStateFlow<ApiEndpointDoc?>(null)
    val selectedEndpointDoc: StateFlow<ApiEndpointDoc?> = _selectedEndpointDoc.asStateFlow()

    val auditedCorporateActions: List<CorporateActionEvent> = CorporateActionStore.getAuditedCorporateActions()
    val apiEndpointDocs: List<ApiEndpointDoc> = ApiQueryDispatcher.getAllEndpointDocs()

    // Selected Index Definition
    val selectedIndex: StateFlow<IndexDefinition?> = combine(indices, _selectedIndexTicker) { map, ticker ->
        map[ticker] ?: map["SP500"]
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Filtered constituents for the selected index
    val filteredConstituents: StateFlow<List<Constituent>> = combine(
        selectedIndex,
        _constituentSearch,
        _sectorFilter,
        _constituentSort
    ) { index, query, sector, sort ->
        val raw = index?.constituents ?: emptyList()
        val filtered = raw.filter { c ->
            val matchQuery = query.isBlank() || c.ticker.contains(query, ignoreCase = true) || c.companyName.contains(query, ignoreCase = true)
            val matchSector = sector == null || c.sector == sector
            matchQuery && matchSector
        }
        when (sort) {
            ConstituentSortBy.WEIGHT -> filtered.sortedByDescending { it.weight }
            ConstituentSortBy.TICKER -> filtered.sortedBy { it.ticker }
            ConstituentSortBy.PRICE -> filtered.sortedByDescending { it.price }
            ConstituentSortBy.DAILY_RETURN -> filtered.sortedByDescending { it.dailyReturn }
            ConstituentSortBy.CONTRIBUTION -> filtered.sortedByDescending { it.contribution }
            ConstituentSortBy.FLOAT_CAP -> filtered.sortedByDescending { it.floatMarketCapBillions }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Overlap Analysis State
    val overlapAnalysis: StateFlow<OverlapResult?> = combine(
        indices,
        _selectedIndexTicker,
        _selectedComparativeTicker
    ) { map, tA, tB ->
        val idxA = map[tA] ?: map["SP500"]
        val idxB = map[tB] ?: map["NASDAQ100"]
        if (idxA != null && idxB != null) {
            OverlapEngine.calculateOverlap(idxA, idxB)
        } else null
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Reconstitution Simulation State
    val reconstitutionResult: StateFlow<RebalanceSimulationResult?> = combine(
        selectedIndex,
        indices
    ) { target, _ ->
        if (target != null) {
            ReconstitutionEngine.simulateReconstitution(
                targetIndex = target,
                candidatePool = SyntheticMarketUniverse.getAllSecurities()
            )
        } else null
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Scenario Stress Test Result State
    val scenarioResult: StateFlow<ScenarioStressResult?> = combine(
        selectedIndex,
        _stressParams
    ) { index, p ->
        if (index != null) {
            ScenarioEngine.executeStressScenario(
                index = index,
                scenarioName = "Multi-Factor Institutional Stress Test",
                techShockPct = p.tech,
                finShockPct = p.fin,
                energyShockPct = p.energy,
                ratesShockBps = p.rates,
                usdShockPct = p.usd,
                megaCapShockPct = p.megaCap
            )
        } else null
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Monte Carlo Simulation Result
    val monteCarloResult: StateFlow<MonteCarloResult?> = combine(selectedIndex, _selectedIndexTicker) { index, _ ->
        if (index != null) {
            MonteCarloEngine.runSimulation(
                indexTicker = index.ticker,
                initialLevel = index.currentLevel
            )
        } else null
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    init {
        _selectedEndpointDoc.value = apiEndpointDocs.firstOrNull()
        executeApiConsoleQuery()
    }

    // Navigation and tab selection
    fun selectTab(tab: TerminalTab) {
        _activeTab.value = tab
    }

    fun selectDetailSubTab(subTab: DetailSubTab) {
        _activeDetailSubTab.value = subTab
    }

    fun selectIndex(ticker: String) {
        _selectedIndexTicker.value = ticker
    }

    fun selectComparativeIndex(ticker: String) {
        _selectedComparativeTicker.value = ticker
    }

    fun setConstituentSearch(query: String) {
        _constituentSearch.value = query
    }

    fun setSectorFilter(sector: SectorGICS?) {
        _sectorFilter.value = sector
    }

    fun setConstituentSort(sort: ConstituentSortBy) {
        _constituentSort.value = sort
    }

    // Scenario controls
    fun updateScenarioShocks(
        tech: Double? = null,
        fin: Double? = null,
        energy: Double? = null,
        rates: Double? = null,
        usd: Double? = null,
        megaCap: Double? = null
    ) {
        val cur = _stressParams.value
        _stressParams.value = cur.copy(
            tech = tech ?: cur.tech,
            fin = fin ?: cur.fin,
            energy = energy ?: cur.energy,
            rates = rates ?: cur.rates,
            usd = usd ?: cur.usd,
            megaCap = megaCap ?: cur.megaCap
        )
    }

    fun applyPresetScenario(preset: String) {
        when (preset) {
            "TECH_SELLOFF" -> {
                _stressParams.value = StressParams(tech = -15.0, fin = 2.0, energy = 4.0, rates = 50.0, usd = 2.0, megaCap = -12.0)
            }
            "RATE_HIKE_100BP" -> {
                _stressParams.value = StressParams(tech = -8.0, fin = 8.0, energy = -3.0, rates = 100.0, usd = 5.0, megaCap = -4.0)
            }
            "ENERGY_CRISIS" -> {
                _stressParams.value = StressParams(tech = -4.0, fin = -2.0, energy = 25.0, rates = 40.0, usd = -3.0, megaCap = 0.0)
            }
            "SMALL_CAP_ROTATION" -> {
                _stressParams.value = StressParams(tech = -6.0, fin = 6.0, energy = 8.0, rates = -25.0, usd = -2.0, megaCap = -8.0)
            }
            "RESET" -> {
                _stressParams.value = StressParams(tech = 0.0, fin = 0.0, energy = 0.0, rates = 0.0, usd = 0.0, megaCap = 0.0)
            }
        }
    }

    // Command palette
    fun setCommandPaletteOpen(open: Boolean) {
        _commandPaletteOpen.value = open
    }

    fun setCommandInput(input: String) {
        _commandInput.value = input
    }

    fun executeTerminalCommand(cmd: String) {
        val trimmed = cmd.trim()
        if (trimmed.isBlank()) return

        val upper = trimmed.uppercase(Locale.US)
        when {
            upper.startsWith("I ") || upper.startsWith("INDEX ") -> {
                val ticker = upper.replace("INDEX ", "").replace("I ", "").trim()
                if (indices.value.containsKey(ticker)) {
                    _selectedIndexTicker.value = ticker
                    _activeTab.value = TerminalTab.DETAIL
                }
            }
            upper.startsWith("C ") || upper.startsWith("COMPARE ") -> {
                val parts = upper.replace("COMPARE ", "").replace("C ", "").trim().split(" ")
                parts.getOrNull(0)?.let { if (indices.value.containsKey(it)) _selectedIndexTicker.value = it }
                parts.getOrNull(1)?.let { if (indices.value.containsKey(it)) _selectedComparativeTicker.value = it }
                _activeTab.value = TerminalTab.COMPARISON
            }
            upper.startsWith("B ") || upper.startsWith("BREADTH") -> {
                _activeTab.value = TerminalTab.DETAIL
                _activeDetailSubTab.value = DetailSubTab.BREADTH
            }
            upper.startsWith("A ") || upper.startsWith("ATTRIBUTION") -> {
                _activeTab.value = TerminalTab.DETAIL
                _activeDetailSubTab.value = DetailSubTab.ATTRIBUTION
            }
            upper.startsWith("R ") || upper.startsWith("REBALANCE") -> {
                _activeTab.value = TerminalTab.RECONSTITUTION
            }
            upper.startsWith("S ") || upper.startsWith("SCENARIO") -> {
                _activeTab.value = TerminalTab.SCENARIOS
            }
            upper == "M" || upper == "MONITOR" -> {
                _activeTab.value = TerminalTab.MONITOR
            }
            upper == "API" || upper == "DEV" -> {
                _activeTab.value = TerminalTab.API_PORTAL
            }
            upper == "MC" || upper == "QUANT" -> {
                _activeTab.value = TerminalTab.MONTE_CARLO
            }
            upper == "CUSTOM" || upper == "BUILDER" -> {
                _activeTab.value = TerminalTab.CUSTOM_BUILDER
            }
        }
        _commandPaletteOpen.value = false
        _commandInput.value = ""
    }

    // API Console
    fun setApiConsoleInput(input: String) {
        _apiConsoleInput.value = input
    }

    fun selectEndpointDoc(doc: ApiEndpointDoc) {
        _selectedEndpointDoc.value = doc
        _apiConsoleInput.value = "${doc.method} ${doc.path}"
        _apiConsoleOutput.value = doc.sampleResponseJson
    }

    fun executeApiConsoleQuery() {
        val res = ApiQueryDispatcher.executeTerminalQuery(_apiConsoleInput.value, indices.value)
        _apiConsoleOutput.value = res
    }

    // Custom Index Builder
    fun createCustomIndex(
        name: String,
        ticker: String,
        weightingMethod: WeightingMethod,
        factor: FactorType,
        maxCapPct: Double
    ) {
        val universe = SyntheticMarketUniverse.getAllSecurities()
        val config = CustomIndexConfig(
            customId = "IDX-CUSTOM-${System.currentTimeMillis() % 10000}",
            ticker = ticker.ifBlank { "USCUSTOM1" }.uppercase(Locale.US),
            name = name.ifBlank { "Custom Quantitative Index" },
            weightingMethod = weightingMethod,
            primaryFactor = factor,
            targetConstituentCount = 20,
            maxWeightCapPct = maxCapPct,
            calculationDivisor = 1240.50,
            calculatedLevel = 2480.20,
            backtestedReturn1YPct = 21.4,
            backtestedSharpe = 1.48,
            backtestedMaxDrawdownPct = -10.5,
            constituents = universe.take(20)
        )
        repository.addCustomIndex(config)
    }
}
