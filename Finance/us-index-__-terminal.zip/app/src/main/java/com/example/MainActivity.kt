package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.TerminalTab
import com.example.ui.TerminalViewModel
import com.example.ui.components.CommandPaletteModal
import com.example.ui.components.TerminalHeader
import com.example.ui.components.TerminalNavTabBar
import com.example.ui.screens.ApiPortalScreen
import com.example.ui.screens.ComparisonOverlapScreen
import com.example.ui.screens.CustomIndexScreen
import com.example.ui.screens.IndexDetailScreen
import com.example.ui.screens.MarketMonitorScreen
import com.example.ui.screens.MonteCarloScreen
import com.example.ui.screens.ReconstitutionScreen
import com.example.ui.screens.ScenarioScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TerminalBg

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: TerminalViewModel = viewModel()
                TerminalAppRoot(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun TerminalAppRoot(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val activeTab by viewModel.activeTab.collectAsState()
    val indices by viewModel.indices.collectAsState()
    val customIndices by viewModel.customIndices.collectAsState()
    val alerts by viewModel.alerts.collectAsState()
    val tickCounter by viewModel.tickCounter.collectAsState()

    val selectedIndex by viewModel.selectedIndex.collectAsState()
    val selectedIndexTicker by viewModel.selectedIndexTicker.collectAsState()
    val selectedComparativeTicker by viewModel.selectedComparativeTicker.collectAsState()
    val activeDetailSubTab by viewModel.activeDetailSubTab.collectAsState()

    val constituentSearch by viewModel.constituentSearch.collectAsState()
    val sectorFilter by viewModel.sectorFilter.collectAsState()
    val constituentSort by viewModel.constituentSort.collectAsState()
    val filteredConstituents by viewModel.filteredConstituents.collectAsState()

    val overlapResult by viewModel.overlapAnalysis.collectAsState()
    val reconstitutionResult by viewModel.reconstitutionResult.collectAsState()
    val scenarioResult by viewModel.scenarioResult.collectAsState()
    val monteCarloResult by viewModel.monteCarloResult.collectAsState()
    val stressParams by viewModel.stressParams.collectAsState()

    val commandPaletteOpen by viewModel.commandPaletteOpen.collectAsState()
    val commandInput by viewModel.commandInput.collectAsState()

    val apiConsoleInput by viewModel.apiConsoleInput.collectAsState()
    val apiConsoleOutput by viewModel.apiConsoleOutput.collectAsState()
    val selectedEndpointDoc by viewModel.selectedEndpointDoc.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TerminalBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(TerminalBg)
        ) {
            // Institutional Top Bar
            TerminalHeader(
                tickCount = tickCounter,
                onOpenCommandPalette = { viewModel.setCommandPaletteOpen(true) }
            )

            // Horizontal Tab Bar with hotkeys
            TerminalNavTabBar(
                activeTab = activeTab,
                onTabSelected = { viewModel.selectTab(it) }
            )

            // Tab Screen Routing
            Box(modifier = Modifier.weight(1f)) {
                when (activeTab) {
                    TerminalTab.MONITOR -> {
                        MarketMonitorScreen(
                            indices = indices,
                            alerts = alerts,
                            auditedActions = viewModel.auditedCorporateActions,
                            onSelectIndex = { viewModel.selectIndex(it) },
                            onNavigateToTab = { viewModel.selectTab(it) }
                        )
                    }
                    TerminalTab.DETAIL -> {
                        IndexDetailScreen(
                            indexDef = selectedIndex,
                            allIndices = indices,
                            activeSubTab = activeDetailSubTab,
                            onSubTabSelected = { viewModel.selectDetailSubTab(it) },
                            onSelectIndex = { viewModel.selectIndex(it) },
                            searchQuery = constituentSearch,
                            onSearchChange = { viewModel.setConstituentSearch(it) },
                            selectedSector = sectorFilter,
                            onSectorFilter = { viewModel.setSectorFilter(it) },
                            sortOption = constituentSort,
                            onSortOptionSelected = { viewModel.setConstituentSort(it) },
                            filteredConstituents = filteredConstituents,
                            auditedActions = viewModel.auditedCorporateActions
                        )
                    }
                    TerminalTab.COMPARISON -> {
                        ComparisonOverlapScreen(
                            overlapResult = overlapResult,
                            allIndices = indices,
                            selectedTickerA = selectedIndexTicker,
                            selectedTickerB = selectedComparativeTicker,
                            onSelectIndexA = { viewModel.selectIndex(it) },
                            onSelectIndexB = { viewModel.selectComparativeIndex(it) }
                        )
                    }
                    TerminalTab.RECONSTITUTION -> {
                        ReconstitutionScreen(
                            rebalanceResult = reconstitutionResult,
                            allIndices = indices,
                            selectedTicker = selectedIndexTicker,
                            onSelectIndex = { viewModel.selectIndex(it) }
                        )
                    }
                    TerminalTab.SCENARIOS -> {
                        ScenarioScreen(
                            scenarioResult = scenarioResult,
                            techShock = stressParams.tech,
                            finShock = stressParams.fin,
                            energyShock = stressParams.energy,
                            ratesShockBps = stressParams.rates,
                            usdShock = stressParams.usd,
                            megaCapShock = stressParams.megaCap,
                            onUpdateShocks = { tech, fin, energy, rates, usd, megaCap ->
                                viewModel.updateScenarioShocks(tech, fin, energy, rates, usd, megaCap)
                            },
                            onApplyPreset = { viewModel.applyPresetScenario(it) }
                        )
                    }
                    TerminalTab.MONTE_CARLO -> {
                        MonteCarloScreen(
                            monteCarloResult = monteCarloResult
                        )
                    }
                    TerminalTab.CUSTOM_BUILDER -> {
                        CustomIndexScreen(
                            customIndices = customIndices,
                            onCreateCustomIndex = { name, ticker, weighting, factor, maxCap ->
                                viewModel.createCustomIndex(name, ticker, weighting, factor, maxCap)
                            }
                        )
                    }
                    TerminalTab.API_PORTAL -> {
                        ApiPortalScreen(
                            endpointDocs = viewModel.apiEndpointDocs,
                            selectedDoc = selectedEndpointDoc,
                            onSelectEndpoint = { viewModel.selectEndpointDoc(it) },
                            apiInput = apiConsoleInput,
                            onApiInputChange = { viewModel.setApiConsoleInput(it) },
                            apiOutput = apiConsoleOutput,
                            onExecuteQuery = { viewModel.executeApiConsoleQuery() }
                        )
                    }
                }
            }
        }

        // Command Palette Dialog
        CommandPaletteModal(
            isOpen = commandPaletteOpen,
            commandInput = commandInput,
            onInputChange = { viewModel.setCommandInput(it) },
            onExecute = { viewModel.executeTerminalCommand(it) },
            onDismiss = { viewModel.setCommandPaletteOpen(false) }
        )
    }
}
