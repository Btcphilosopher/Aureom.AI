package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Dark Financial Terminal Palette
val TerminalBg = Color(0xFF080B10)
val TerminalSurface = Color(0xFF0E141F)
val TerminalSurfaceVariant = Color(0xFF141C2B)
val TerminalSurfaceBright = Color(0xFF1C273C)
val TerminalBorder = Color(0xFF223047)
val TerminalBorderSubtle = Color(0xFF182333)

// Brand and Accent Colors
val TerminalCyan = Color(0xFF38BDF8)
val TerminalBlue = Color(0xFF0284C7)
val TerminalDarkBlue = Color(0xFF032B45)
val TerminalAmber = Color(0xFFF59E0B)
val TerminalGold = Color(0xFFE5A93C)
val TerminalMutedAmber = Color(0xFF452E07)

// Quantitative Indicators
val TermGreen = Color(0xFF10B981)
val TermGreenDim = Color(0xFF064E3B)
val TermRed = Color(0xFFF43F5E)
val TermRedDim = Color(0xFF4C0519)
val TermGray = Color(0xFF94A3B8)
val TermDarkGray = Color(0xFF475569)
val TermWhite = Color(0xFFF8FAFC)
val TermOffWhite = Color(0xFFE2E8F0)

// Sector Colors for High-Density Attribution & Visual Maps
val SectorTechColor = Color(0xFF38BDF8)
val SectorFinColor = Color(0xFF3B82F6)
val SectorHealthColor = Color(0xFF10B981)
val SectorConsDiscColor = Color(0xFFF59E0B)
val SectorCommColor = Color(0xFFA855F7)
val SectorIndColor = Color(0xFF6366F1)
val SectorConsStapColor = Color(0xFF14B8A6)
val SectorEnergyColor = Color(0xFFEF4444)
val SectorUtilColor = Color(0xFF84CC16)
val SectorRealEstColor = Color(0xFFEC4899)
val SectorMatColor = Color(0xFFEAB308)
