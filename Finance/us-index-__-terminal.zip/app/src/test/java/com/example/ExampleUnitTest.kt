package com.example

import com.example.calculation.IndexCalculationEngine
import com.example.calculation.MonteCarloEngine
import com.example.calculation.OverlapEngine
import com.example.calculation.ScenarioEngine
import com.example.data.SyntheticMarketUniverse
import com.example.domain.model.DataProvenance
import com.example.domain.model.IndexFamily
import com.example.domain.model.WeightingMethod
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun test_market_cap_index_weights_sum_to_100() {
        val universe = SyntheticMarketUniverse.getAllSecurities()
        val index = IndexCalculationEngine.computeIndexState(
            indexId = "TEST-CAP",
            ticker = "TEST500",
            name = "Test Cap Index",
            family = IndexFamily.SPDJI,
            provider = "AIS",
            weightingMethod = WeightingMethod.CAP_WEIGHTED,
            divisor = 1000.0,
            rawConstituents = universe
        )
        val sumWeights = index.constituents.sumOf { it.weight }
        assertEquals(100.0, sumWeights, 0.01)
        assertTrue("Index level must be positive", index.currentLevel > 0)
    }

    @Test
    fun test_price_weighted_index() {
        val universe = SyntheticMarketUniverse.getAllSecurities().take(5)
        val index = IndexCalculationEngine.computeIndexState(
            indexId = "TEST-PRICE",
            ticker = "TESTDOW",
            name = "Test Dow",
            family = IndexFamily.DOW,
            provider = "AIS",
            weightingMethod = WeightingMethod.PRICE_WEIGHTED,
            divisor = 0.5,
            rawConstituents = universe
        )
        val expectedLevel = universe.sumOf { it.price } / 0.5
        assertEquals(expectedLevel, index.currentLevel, 0.001)
    }

    @Test
    fun test_divisor_adjustment_preserves_continuity() {
        val divisorBefore = 1000.0
        val capBefore = 5000.0
        val capAfter = 5500.0 // addition of new component
        val divisorAfter = IndexCalculationEngine.adjustDivisorForCorporateAction(
            currentDivisor = divisorBefore,
            totalCapBeforeMillion = capBefore,
            totalCapAfterMillion = capAfter
        )
        // Level before = 5000 / 1000 = 5.0
        // Level after = 5500 / 1100 = 5.0 (exact continuity preserved)
        assertEquals(1100.0, divisorAfter, 0.001)
        val levelBefore = capBefore / divisorBefore
        val levelAfter = capAfter / divisorAfter
        assertEquals(levelBefore, levelAfter, 0.0001)
    }

    @Test
    fun test_index_overlap_calculation() {
        val universe = SyntheticMarketUniverse.getAllSecurities()
        val indexA = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-A",
            ticker = "IDXA",
            name = "Index A",
            family = IndexFamily.SPDJI,
            provider = "AIS",
            weightingMethod = WeightingMethod.CAP_WEIGHTED,
            divisor = 1000.0,
            rawConstituents = universe.take(15)
        )
        val indexB = IndexCalculationEngine.computeIndexState(
            indexId = "IDX-B",
            ticker = "IDXB",
            name = "Index B",
            family = IndexFamily.NASDAQ,
            provider = "AIS",
            weightingMethod = WeightingMethod.CAP_WEIGHTED,
            divisor = 1000.0,
            rawConstituents = universe.take(20)
        )
        val overlap = OverlapEngine.calculateOverlap(indexA, indexB)
        assertEquals(15, overlap.sharedCount)
        assertTrue("Overlap weight must be > 0", overlap.totalWeightOverlapPct > 0)
    }

    @Test
    fun test_monte_carlo_determinism() {
        val res1 = MonteCarloEngine.runSimulation(indexTicker = "SP500", initialLevel = 6000.0, numSimulations = 500)
        val res2 = MonteCarloEngine.runSimulation(indexTicker = "SP500", initialLevel = 6000.0, numSimulations = 500)
        assertEquals(res1.medianTerminalLevel, res2.medianTerminalLevel, 0.0001)
    }
}
