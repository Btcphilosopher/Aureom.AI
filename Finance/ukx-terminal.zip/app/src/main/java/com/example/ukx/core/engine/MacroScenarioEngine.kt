package com.example.ukx.core.engine

import com.example.ukx.domain.model.IndexConstituent
import com.example.ukx.domain.model.MacroScenarioImpact
import com.example.ukx.domain.model.MacroScenarioType
import com.example.ukx.domain.model.UkSector

/**
 * Macro Scenario & Stress-Testing Engine (UKX Digital Twin)
 * 
 * Computes the simulated impact of currency moves, interest rate shifts, and commodity shocks
 * across the 100 FTSE constituents using constituent-level beta and foreign revenue exposures.
 */
object MacroScenarioEngine {

    fun runScenario(
        scenarioType: MacroScenarioType,
        constituents: List<IndexConstituent>,
        currentIndexLevel: Double
    ): MacroScenarioImpact {
        val sectorImpacts = mutableMapOf<UkSector, Double>()
        val stockReturns = mutableListOf<Pair<String, Double>>()

        for (c in constituents) {
            val stockReturn = when (scenarioType) {
                MacroScenarioType.GBP_STRENGTH -> {
                    // Foreign revenue translation penalty: -3.8% on global exporters, +1.2% on domestic
                    val internationalDrag = -4.2 * 0.75
                    val domesticBoost = 1.2 * 0.25
                    internationalDrag + domesticBoost
                }
                MacroScenarioType.GBP_WEAKNESS -> {
                    // Sterling depreciation boost to overseas dollar earnings
                    val internationalBoost = 4.5 * 0.75
                    val domesticDrag = -1.1 * 0.25
                    internationalBoost + domesticDrag
                }
                MacroScenarioType.UK_RATES_UP -> {
                    when (c.sector) {
                        UkSector.FINANCIALS -> 3.20
                        UkSector.REAL_ESTATE -> -4.50
                        UkSector.UTILITIES -> -2.80
                        UkSector.CONSUMER_DISCRETIONARY -> -1.90
                        else -> -0.40
                    }
                }
                MacroScenarioType.UK_RATES_DOWN -> {
                    when (c.sector) {
                        UkSector.REAL_ESTATE -> 4.80
                        UkSector.CONSUMER_DISCRETIONARY -> 2.60
                        UkSector.UTILITIES -> 2.10
                        UkSector.FINANCIALS -> -2.90
                        else -> 0.60
                    }
                }
                MacroScenarioType.OIL_SHOCK_UP -> {
                    when (c.sector) {
                        UkSector.ENERGY -> 12.50
                        UkSector.MATERIALS -> 3.10
                        UkSector.CONSUMER_DISCRETIONARY -> -2.20
                        UkSector.INDUSTRIALS -> -1.40
                        else -> 0.10
                    }
                }
                MacroScenarioType.OIL_SHOCK_DOWN -> {
                    when (c.sector) {
                        UkSector.ENERGY -> -14.20
                        UkSector.MATERIALS -> -4.00
                        UkSector.CONSUMER_DISCRETIONARY -> 2.10
                        else -> -0.30
                    }
                }
                MacroScenarioType.BANKING_STRESS -> {
                    when (c.sector) {
                        UkSector.FINANCIALS -> -15.00
                        UkSector.REAL_ESTATE -> -3.80
                        else -> -0.80
                    }
                }
                MacroScenarioType.GLOBAL_RECESSION -> {
                    when (c.sector) {
                        UkSector.HEALTHCARE -> -1.20
                        UkSector.CONSUMER_STAPLES -> -1.80
                        UkSector.UTILITIES -> -0.90
                        UkSector.ENERGY -> -11.50
                        UkSector.MATERIALS -> -13.20
                        UkSector.FINANCIALS -> -8.40
                        else -> -5.50
                    }
                }
            }
            stockReturns.add(Pair(c.ticker, stockReturn))
        }

        // Sector aggregated impacts
        for (sector in UkSector.values()) {
            val sectorStocks = constituents.filter { it.sector == sector }
            if (sectorStocks.isNotEmpty()) {
                val weightedReturn = sectorStocks.sumOf { s ->
                    val r = stockReturns.find { it.first == s.ticker }?.second ?: 0.0
                    r * s.weightPct
                } / sectorStocks.sumOf { it.weightPct }
                sectorImpacts[sector] = weightedReturn
            }
        }

        // Total index weighted return
        val totalIndexReturnPct = constituents.sumOf { c ->
            val r = stockReturns.find { it.first == c.ticker }?.second ?: 0.0
            (r * (c.weightPct / 100.0))
        }

        val pointChange = currentIndexLevel * (totalIndexReturnPct / 100.0)

        val fxPart = when (scenarioType) {
            MacroScenarioType.GBP_STRENGTH -> -2.40
            MacroScenarioType.GBP_WEAKNESS -> 2.65
            else -> 0.0
        }
        val equityPart = totalIndexReturnPct - fxPart

        val sortedStocks = stockReturns.sortedByDescending { it.second }
        val topBeneficiaries = sortedStocks.take(5)
        val topImpacted = sortedStocks.reversed().take(5)

        return MacroScenarioImpact(
            scenario = scenarioType,
            estimatedUkxReturnPct = totalIndexReturnPct,
            estimatedIndexPointChange = pointChange,
            equityReturnPct = equityPart,
            fxTranslationalReturnPct = fxPart,
            sectorImpacts = sectorImpacts,
            topBeneficiaries = topBeneficiaries,
            topImpacted = topImpacted,
            methodologyNote = "Modelled estimate using constituent foreign earnings sensitivity and sector factor exposures. Synthetic simulation."
        )
    }
}
