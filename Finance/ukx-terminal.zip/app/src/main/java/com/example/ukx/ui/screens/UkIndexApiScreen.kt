package com.example.ukx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxSurfaceElevated
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.ui.UkxTerminalUiState

@Composable
fun UkIndexApiScreen(
    uiState: UkxTerminalUiState,
    onExecuteQuery: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var queryInput by remember { mutableStateOf(uiState.apiQueryInput) }

    val presetQueries = listOf(
        "INDEX FTSE100",
        "CONSTITUENTS FTSE100",
        "REVIEW FTSE100",
        "GET /api/v1/indices/FTSE100",
        "GET /api/v1/reviews",
        "SCENARIO FTSE100 GBP +5%"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UkxObsidian)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("developer_api_screen")
    ) {
        Text(
            text = "UK INDEX API // DEVELOPER & QUANTITATIVE SANDBOX",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxTextPrimary
        )
        Text(
            text = "Institutional REST, WebSocket, Python (`ukx-python`), and R (`ukx-r`) API integration",
            fontSize = 10.sp,
            color = UkxTextMuted
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Preset Quick Queries
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(presetQueries) { preset ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(UkxSurfaceElevated)
                        .border(1.dp, UkxCardBorder, RoundedCornerShape(4.dp))
                        .clickable {
                            queryInput = preset
                            onExecuteQuery(preset)
                        }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = preset,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = UkxSteelBlue
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Interactive API Query Input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = queryInput,
                onValueChange = { queryInput = it },
                label = { Text("API Endpoint or CLI Query", fontSize = 11.sp) },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = UkxSteelBlue,
                    unfocusedBorderColor = UkxCardBorder,
                    focusedTextColor = UkxTextPrimary,
                    unfocusedTextColor = UkxTextPrimary
                ),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = { onExecuteQuery(queryInput) },
                colors = ButtonDefaults.buttonColors(containerColor = UkxSteelBlue),
                modifier = Modifier.height(52.dp)
            ) {
                Text("RUN", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // JSON Response Payload Box
        Text(
            text = "RESPONSE PAYLOAD (application/json)",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = UkxGoldAccent
        )

        Spacer(modifier = Modifier.height(6.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(UkxSurface)
                .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
                .padding(12.dp)
        ) {
            Text(
                text = uiState.apiOutputJson,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                lineHeight = 15.sp,
                color = UkxGainGreen
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Python SDK (`ukx-python`) Snippet
        Text(
            text = "PYTHON SDK (ukx-python) CLIENT EXAMPLE",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = UkxSteelBlue
        )

        Spacer(modifier = Modifier.height(6.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(UkxSurface)
                .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Text(
                text = """
from ukx import UKIndexClient

client = UKIndexClient(api_key="ukx_live_auth_token")

# Fetch real-time Laspeyres level and total return
ftse100 = client.indices.get("FTSE100")
print(f"Level: {ftse100.level} | Gross TR: {ftse100.total_return}")

# Query 100 constituents with free float weights
constituents = client.indices.constituents("FTSE100")
for c in constituents.top(5):
    print(c.ticker, c.weight_pct, c.investable_market_cap)

# Simulate December 2026 reconstitution
review = client.reviews.simulate("FTSE100", cutoff="2026-12-01")
print(f"Turnover: {review.turnover_pct}% | Passive Flow: £{review.flow_gbp}M")
""".trimIndent(),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                lineHeight = 14.sp,
                color = UkxTextSecondary
            )
        }
    }
}
