package com.example.ukx.core.engine

import com.example.ukx.domain.model.BufferStatus
import com.example.ukx.domain.model.MethodologyVersion
import com.example.ukx.domain.model.ReviewCandidate
import com.example.ukx.domain.model.SecurityMasterRecord

/**
 * FTSE 100 Selection Engine
 * 
 * Implements quarterly review buffer zones (90 upper insertion band / 111 lower deletion band)
 * to minimize unnecessary index turnover while ensuring the 100 largest UK companies are represented.
 */
object FTSE100SelectionEngine {

    fun determineBufferStatus(
        rank: Int,
        isCurrentConstituent: Boolean,
        upperBufferRank: Int = 90,
        lowerBufferRank: Int = 111
    ): BufferStatus {
        return if (isCurrentConstituent) {
            when {
                rank <= upperBufferRank -> BufferStatus.SECURE_CONSTITUENT
                rank in (upperBufferRank + 1)..100 -> BufferStatus.BORDERLINE_INCUMBENT
                rank in 101 until lowerBufferRank -> BufferStatus.BUFFER_ZONE_AT_RISK
                else -> BufferStatus.AUTOMATIC_DEMOTION
            }
        } else {
            when {
                rank <= upperBufferRank -> BufferStatus.AUTOMATIC_PROMOTION
                rank in (upperBufferRank + 1)..100 -> BufferStatus.CHALLENGER_CANDIDATE
                else -> BufferStatus.BUFFER_ZONE_AT_RISK
            }
        }
    }

    fun selectConstituents(
        eligibleSecurities: List<SecurityMasterRecord>,
        currentConstituentTickers: Set<String>,
        methodology: MethodologyVersion = MethodologyVersion.VERSION_2026_JUN
    ): Pair<List<SecurityMasterRecord>, List<ReviewCandidate>> {
        // Step 1: Rank by FULL Market Cap
        val ranked = eligibleSecurities.sortedByDescending { it.fullMarketCapGbp }

        val candidates = mutableListOf<ReviewCandidate>()
        val selected = mutableListOf<SecurityMasterRecord>()

        // Analyze candidate buffer states
        ranked.forEachIndexed { index, sec ->
            val rank = index + 1
            val isCurrent = currentConstituentTickers.contains(sec.ticker)
            val bufferStatus = determineBufferStatus(
                rank = rank,
                isCurrentConstituent = isCurrent,
                upperBufferRank = methodology.bufferInclusionRank,
                lowerBufferRank = methodology.bufferExclusionRank
            )
            val projectedIndex = if (rank <= 100) "FTSE 100" else "FTSE 250"
            val flowEstimate = if (isCurrent && projectedIndex == "FTSE 250") {
                -sec.investableMarketCapGbp * 0.045
            } else if (!isCurrent && projectedIndex == "FTSE 100") {
                sec.investableMarketCapGbp * 0.045
            } else 0.0

            candidates.add(
                ReviewCandidate(
                    rank = rank,
                    ticker = sec.ticker,
                    companyName = sec.companyName,
                    currentIndex = if (isCurrent) "FTSE 100" else "FTSE 250",
                    projectedIndex = projectedIndex,
                    fullMarketCapGbp = sec.fullMarketCapGbp,
                    investableMarketCapGbp = sec.investableMarketCapGbp,
                    freeFloatPct = sec.freeFloatPct,
                    liquidityRatio = UKLiquidityEngine.calculateLiquidityRatio(
                        sec.medianDailyVolume,
                        sec.sharesInIssue,
                        sec.freeFloatFactor
                    ),
                    bufferStatus = bufferStatus,
                    estimatedWeightChangePct = 0.0,
                    estimatedPassiveFlowGbp = flowEstimate
                )
            )
        }

        // Selection algorithm respecting FTSE rules:
        // 1. All eligible ranked 1..90 are included
        val autoIncluded = ranked.filterIndexed { index, _ -> (index + 1) <= methodology.bufferInclusionRank }
        selected.addAll(autoIncluded)

        // 2. Incumbent constituents ranked 91..110 remain in place unless replaced
        val incumbents91to110 = ranked.filterIndexed { index, sec ->
            val rank = index + 1
            rank in (methodology.bufferInclusionRank + 1) until methodology.bufferExclusionRank &&
                    currentConstituentTickers.contains(sec.ticker)
        }

        for (incumbent in incumbents91to110) {
            if (selected.size < 100 && !selected.contains(incumbent)) {
                selected.add(incumbent)
            }
        }

        // 3. Fill any remaining vacancies from highest ranked available non-constituents
        for (sec in ranked) {
            if (selected.size >= 100) break
            if (!selected.contains(sec)) {
                selected.add(sec)
            }
        }

        return Pair(selected.take(100), candidates)
    }
}
