package com.example.ukx.domain.model

enum class LseListingType(val code: String) {
    PRIMARY_EQUITY("Primary Commercial Company"),
    SECONDARY_LISTING("Secondary Listing"),
    INVESTMENT_ENTITY("Closed-Ended Investment Fund"),
    REIT("Real Estate Investment Trust"),
    DEPOSITORY_RECEIPT("Depository Receipt")
}

enum class TradingExchange(val code: String) {
    LSE_SETS("London Stock Exchange (SETS Continuous Order Book)"),
    LSE_SEAQ("London Stock Exchange (SEAQ Quoted)"),
    LSE_AIM("AIM Market")
}

enum class UkSector(val code: String, val displayName: String, val colorHex: Long) {
    FINANCIALS("FIN", "Financials", 0xFF58A6FF),
    ENERGY("ENG", "Energy", 0xFFD29922),
    HEALTHCARE("HLT", "Healthcare", 0xFF3FB950),
    CONSUMER_STAPLES("CNS", "Consumer Staples", 0xFF8957E5),
    CONSUMER_DISCRETIONARY("CND", "Consumer Discretionary", 0xFFF0883E),
    INDUSTRIALS("IND", "Industrials", 0xFF79C0FF),
    MATERIALS("MAT", "Basic Materials", 0xFFDB6D28),
    TECHNOLOGY("TEC", "Technology", 0xFF56D364),
    UTILITIES("UTL", "Utilities", 0xFF1F6FEB),
    REAL_ESTATE("REA", "Real Estate", 0xFFE3B341),
    TELECOMS("TEL", "Telecoms", 0xFFBC8CFF)
}

data class SecurityMasterRecord(
    val securityId: String,
    val companyId: String,
    val ticker: String,
    val companyName: String,
    val isin: String,
    val sedol: String,
    val exchange: TradingExchange = TradingExchange.LSE_SETS,
    val listingType: LseListingType = LseListingType.PRIMARY_EQUITY,
    val shareClass: String = "Ordinary 1p",
    val tradingCurrency: String = "GBP", // GBP, EUR, USD
    val countryOfIncorporation: String = "GB",
    val countryOfListing: String = "GB",
    val countryOfOperation: String = "GB",
    val sector: UkSector,
    val industry: String,
    val sharesInIssue: Long,
    val freeFloatFactor: Double, // 0.0 to 1.0 (e.g. 0.85 = 85%)
    val priceGbp: Double, // in pence or pounds? Stored in Pounds (GBP)
    val priceChangePct: Double,
    val volumeToday: Long,
    val medianDailyVolume: Long,
    val dividendPerShareGbp: Double,
    val isSuspended: Boolean = false,
    val daysTradedPct: Double = 1.0, // 100% of available trading days
    val betaToUkx: Double = 1.0,
    val foreignSalesPct: Double = 0.65 // % of revenue generated internationally
) {
    val fullMarketCapGbp: Double
        get() = priceGbp * sharesInIssue

    val investableMarketCapGbp: Double
        get() = fullMarketCapGbp * freeFloatFactor

    val dividendYieldPct: Double
        get() = if (priceGbp > 0) (dividendPerShareGbp / priceGbp) * 100.0 else 0.0

    val freeFloatPct: Double
        get() = freeFloatFactor * 100.0
}
