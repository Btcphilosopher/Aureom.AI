package com.example.ukx.domain.model

data class IndexConstituent(
    val rank: Int,
    val securityId: String,
    val ticker: String,
    val companyName: String,
    val sector: UkSector,
    val industry: String,
    val sharePriceGbp: Double,
    val dailyReturnPct: Double,
    val sharesInIssue: Long,
    val freeFloatFactor: Double,
    val fullMarketCapGbp: Double,
    val investableMarketCapGbp: Double,
    val weightPct: Double,
    val contributionPoints: Double,
    val contributionPct: Double,
    val dividendYieldPct: Double,
    val dma50: Double = sharePriceGbp * 0.98,
    val dma200: Double = sharePriceGbp * 0.95,
    val isAbove50Dma: Boolean = true,
    val isAbove200Dma: Boolean = true
) {
    val freeFloatPct: Double
        get() = freeFloatFactor * 100.0

    val fullMarketCapBillionsGbp: Double
        get() = fullMarketCapGbp / 1_000_000_000.0

    val investableMarketCapBillionsGbp: Double
        get() = investableMarketCapGbp / 1_000_000_000.0
}

data class SectorExposure(
    val sector: UkSector,
    val weightPct: Double,
    val constituentCount: Int,
    val totalInvestableCapGbp: Double,
    val sectorReturnPct: Double,
    val sectorContributionPct: Double,
    val topConstituentTicker: String
)

data class MarketBreadth(
    val advancers: Int,
    val decliners: Int,
    val unchanged: Int,
    val advanceDeclineRatio: Double,
    val new52WeekHighs: Int,
    val new52WeekLows: Int,
    val stocksAbove50DmaCount: Int,
    val stocksAbove50DmaPct: Double,
    val stocksAbove200DmaCount: Int,
    val stocksAbove200DmaPct: Double
)

data class IndexState(
    val index: FTSEIndex,
    val timestamp: String,
    val tradeDate: String,
    val sessionName: String = "SETS Continuous Trading",
    val indexLevel: Double,
    val dailyChangePoints: Double,
    val dailyReturnPct: Double,
    val totalReturnLevel: Double,
    val netTotalReturnLevel: Double,
    val divisor: Double,
    val totalFullMarketCapGbp: Double,
    val totalInvestableMarketCapGbp: Double,
    val constituents: List<IndexConstituent>,
    val sectorExposures: List<SectorExposure>,
    val breadth: MarketBreadth,
    val topContributors: List<IndexConstituent>,
    val topDetractors: List<IndexConstituent>,
    val methodologyVersion: String,
    val dataStatus: DataStatus = DataStatus.SYNTHETIC,
    val provenance: ProvenanceRecord
) {
    val herfindahlIndex: Double
        get() = constituents.sumOf { (it.weightPct) * (it.weightPct) }

    val effectiveConstituentCount: Double
        get() = if (herfindahlIndex > 0) 10000.0 / herfindahlIndex else 100.0

    val top5WeightPct: Double
        get() = constituents.take(5).sumOf { it.weightPct }

    val top10WeightPct: Double
        get() = constituents.take(10).sumOf { it.weightPct }

    val top20WeightPct: Double
        get() = constituents.take(20).sumOf { it.weightPct }

    val bottom20WeightPct: Double
        get() = constituents.takeLast(20).sumOf { it.weightPct }
}
