package com.example.ukx.core.engine

import com.example.ukx.domain.model.SecurityMasterRecord

/**
 * Full Market Capitalisation Engine
 * 
 * Formula: full_market_cap = share_price * shares_in_issue
 * 
 * CRITICAL METHODOLOGY RULE:
 * The FTSE 100 constituent ranking engine ranks eligible companies strictly by 
 * FULL MARKET CAPITALISATION BEFORE investability / free-float weighting is applied.
 */
object FullMarketCapitalisationEngine {

    fun calculateFullMarketCap(sharePriceGbp: Double, sharesInIssue: Long): Double {
        if (sharePriceGbp <= 0.0 || sharesInIssue <= 0) return 0.0
        return sharePriceGbp * sharesInIssue.toDouble()
    }

    fun rankSecuritiesByFullMarketCap(securities: List<SecurityMasterRecord>): List<SecurityMasterRecord> {
        return securities.sortedByDescending { it.fullMarketCapGbp }
    }
}
