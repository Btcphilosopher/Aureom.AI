package com.example.ukx.core.engine

import com.example.ukx.domain.model.DataStatus
import com.example.ukx.domain.model.FTSEIndex
import com.example.ukx.domain.model.FactorScore
import com.example.ukx.domain.model.IndexFamily
import com.example.ukx.domain.model.IndexState
import com.example.ukx.domain.model.SecurityMasterRecord

enum class FactorTilt(val label: String) {
    EQUAL_WEIGHT("Equal Weighted (1/N)"),
    HIGH_DIVIDEND("High Dividend Yield (Top 50)"),
    QUALITY_PROFITABILITY("High Quality / ROE (Top 50)"),
    LOW_VOLATILITY("Minimum Volatility (Top 50)"),
    MOMENTUM("12-Month Momentum (Top 50)"),
    VALUE_TILT("Value / Low P/B (Top 50)")
}

data class CustomIndexConfig(
    val indexName: String,
    val indexCode: String,
    val factorTilt: FactorTilt,
    val maxWeightCapPct: Double = 10.0,
    val constituentCount: Int = 50
)

object CustomIndexLabEngine {

    fun generateFactorScores(securities: List<SecurityMasterRecord>): List<FactorScore> {
        return securities.mapIndexed { idx, sec ->
            val divScore = ((sec.dividendYieldPct - 3.5) / 1.2).coerceIn(-3.0, 3.0)
            val qualityScore = (1.5 - (idx % 5) * 0.5).coerceIn(-2.5, 2.5)
            val momentumScore = ((sec.priceChangePct * 1.5) / 2.0).coerceIn(-3.0, 3.0)
            val lowVolScore = (2.0 - (sec.betaToUkx - 0.7) * 2.5).coerceIn(-3.0, 3.0)
            val valueScore = ((sec.dividendYieldPct * 0.8) - (sec.priceChangePct * 0.2)).coerceIn(-3.0, 3.0)

            FactorScore(
                ticker = sec.ticker,
                companyName = sec.companyName,
                sector = sec.sector,
                valueScore = valueScore,
                qualityScore = qualityScore,
                momentumScore = momentumScore,
                lowVolatilityScore = lowVolScore,
                sizeScore = (sec.fullMarketCapGbp / 1e10).coerceIn(-2.0, 3.0),
                dividendYieldScore = divScore,
                compositeQuantRank = idx + 1
            )
        }
    }

    fun buildCustomIndex(
        config: CustomIndexConfig,
        allSecurities: List<SecurityMasterRecord>,
        factorScores: List<FactorScore>
    ): IndexState {
        val selectedSecurities = when (config.factorTilt) {
            FactorTilt.EQUAL_WEIGHT -> allSecurities.take(100)
            FactorTilt.HIGH_DIVIDEND -> allSecurities.sortedByDescending { it.dividendYieldPct }.take(config.constituentCount)
            FactorTilt.QUALITY_PROFITABILITY -> {
                val sorted = factorScores.sortedByDescending { it.qualityScore }.map { it.ticker }
                allSecurities.filter { sorted.take(config.constituentCount).contains(it.ticker) }
            }
            FactorTilt.LOW_VOLATILITY -> {
                val sorted = factorScores.sortedByDescending { it.lowVolatilityScore }.map { it.ticker }
                allSecurities.filter { sorted.take(config.constituentCount).contains(it.ticker) }
            }
            FactorTilt.MOMENTUM -> {
                val sorted = factorScores.sortedByDescending { it.momentumScore }.map { it.ticker }
                allSecurities.filter { sorted.take(config.constituentCount).contains(it.ticker) }
            }
            FactorTilt.VALUE_TILT -> {
                val sorted = factorScores.sortedByDescending { it.valueScore }.map { it.ticker }
                allSecurities.filter { sorted.take(config.constituentCount).contains(it.ticker) }
            }
        }

        val customIndexMeta = FTSEIndex(
            indexId = "CUSTOM_${config.indexCode}",
            indexName = config.indexName,
            indexCode = config.indexCode,
            provider = "UKX Quant Lab",
            indexFamily = IndexFamily.CUSTOM_QUANT,
            constituentCount = selectedSecurities.size,
            status = DataStatus.BACKTESTED,
            isCustom = true
        )

        return IndexCalculator.calculateIndexState(
            index = customIndexMeta,
            selectedSecurities = selectedSecurities,
            divisor = 1500000.0,
            methodologyVersion = "UKX-CUSTOM-FACTOR-2026",
            dataStatus = DataStatus.BACKTESTED
        )
    }
}
