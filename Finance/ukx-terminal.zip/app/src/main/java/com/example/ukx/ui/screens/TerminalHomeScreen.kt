package com.example.ukx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxAmberWarn
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxLossRed
import com.example.ui.theme.UkxNavyBlue
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxSurfaceElevated
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.domain.model.IndexConstituent
import com.example.ukx.domain.model.IndexState
import com.example.ukx.ui.UkxTerminalUiState
import com.example.ukx.ui.components.HeroIndexTile
import com.example.ukx.ui.components.MetricStatTile

@Composable
fun TerminalHomeScreen(
    uiState: UkxTerminalUiState,
    modifier: Modifier = Modifier
) {
    val state = uiState.currentIndexState ?: return
    val currency = uiState.selectedCurrency

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UkxObsidian)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("terminal_home_screen")
    ) {
        // Hero Index Display
        HeroIndexTile(
            indexCode = state.index.indexCode,
            indexName = state.index.indexName,
            level = state.indexLevel,
            changePoints = state.dailyChangePoints,
            changePct = state.dailyReturnPct,
            currencySymbol = currency.symbol,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Key Metric Grid: TR, Divisor, Full MCap vs Investable MCap
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricStatTile(
                label = "Gross Total Return",
                value = String.format("%,.2f", state.totalReturnLevel),
                subValue = "Reinvested Ex-Date",
                subValueColor = UkxGainGreen,
                modifier = Modifier.weight(1f)
            )
            MetricStatTile(
                label = "Net Total Return",
                value = String.format("%,.2f", state.netTotalReturnLevel),
                subValue = "Tax Adjusted (95%)",
                subValueColor = UkxSteelBlue,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val fullCapB = (state.totalFullMarketCapGbp / 1e9) * currency.rateToGbp
            val invCapB = (state.totalInvestableMarketCapGbp / 1e9) * currency.rateToGbp

            MetricStatTile(
                label = "Full Market Cap (Ranking)",
                value = "${currency.symbol}${String.format("%,.1f", fullCapB)}B",
                subValue = "100% Shares in Issue",
                subValueColor = UkxTextMuted,
                modifier = Modifier.weight(1f)
            )
            MetricStatTile(
                label = "Investable Cap (Weighting)",
                value = "${currency.symbol}${String.format("%,.1f", invCapB)}B",
                subValue = "Free Float Weighted",
                subValueColor = UkxGoldAccent,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricStatTile(
                label = "Index Divisor",
                value = String.format("%,.2f", state.divisor),
                subValue = "Continuity Preserved",
                subValueColor = UkxTextSecondary,
                modifier = Modifier.weight(1f)
            )
            MetricStatTile(
                label = "Herfindahl Index",
                value = String.format("%.1f", state.herfindahlIndex),
                subValue = "Eff. Count: ${String.format("%.1f", state.effectiveConstituentCount)}",
                subValueColor = UkxSteelBlue,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Market Breadth Panel
        MarketBreadthCard(state = state)

        Spacer(modifier = Modifier.height(14.dp))

        // Top 5 Contributors & Detractors
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AttributionColumn(
                title = "TOP CONTRIBUTORS",
                items = state.topContributors,
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
            AttributionColumn(
                title = "TOP DETRACTORS",
                items = state.topDetractors,
                isPositive = false,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Sector Attribution Summary
        SectorAttributionSummaryCard(state = state)

        Spacer(modifier = Modifier.height(14.dp))

        // Reconstitution & Methodology Status
        MethodologyStatusFooter(state = state, uiState = uiState)
    }
}

@Composable
fun MarketBreadthCard(state: IndexState) {
    val b = state.breadth

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FTSE 100 MARKET BREADTH",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxTextPrimary
                )
                Text(
                    text = "A/D Ratio: ${String.format("%.2f", b.advanceDeclineRatio)}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = if (b.advanceDeclineRatio >= 1.0) UkxGainGreen else UkxLossRed
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Advance / Decline Bar
            val totalAdvDec = (b.advancers + b.decliners + b.unchanged).coerceAtLeast(1)
            val advWeight = (b.advancers.toFloat() / totalAdvDec)
            val decWeight = (b.decliners.toFloat() / totalAdvDec)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(UkxDivider)
            ) {
                if (advWeight > 0) {
                    Box(
                        modifier = Modifier
                            .weight(advWeight)
                            .height(6.dp)
                            .background(UkxGainGreen)
                    )
                }
                if (decWeight > 0) {
                    Box(
                        modifier = Modifier
                            .weight(decWeight)
                            .height(6.dp)
                            .background(UkxLossRed)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "▲ ${b.advancers} Advancers",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = UkxGainGreen
                )
                Text(
                    text = "■ ${b.unchanged} Flat",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = UkxTextMuted
                )
                Text(
                    text = "▼ ${b.decliners} Decliners",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = UkxLossRed
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Above 50 DMA: ${b.stocksAbove50DmaCount}%",
                    fontSize = 10.sp,
                    color = UkxTextSecondary
                )
                Text(
                    text = "Above 200 DMA: ${b.stocksAbove200DmaCount}%",
                    fontSize = 10.sp,
                    color = UkxTextSecondary
                )
            }
        }
    }
}

@Composable
fun AttributionColumn(
    title: String,
    items: List<IndexConstituent>,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    val accent = if (isPositive) UkxGainGreen else UkxLossRed

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(
                text = title,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = accent
            )
            Spacer(modifier = Modifier.height(6.dp))

            items.forEach { c ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = c.ticker,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = UkxTextPrimary
                        )
                        Text(
                            text = c.sector.code,
                            fontSize = 9.sp,
                            color = UkxTextMuted
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = String.format("%+.2f pts", c.contributionPoints),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = accent
                        )
                        Text(
                            text = String.format("%+.2f%%", c.dailyReturnPct),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = UkxTextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectorAttributionSummaryCard(state: IndexState) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SECTOR WEIGHT & ATTRIBUTION",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxTextPrimary
                )
                Text(
                    text = "11 ICB Sectors",
                    fontSize = 10.sp,
                    color = UkxTextMuted
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            state.sectorExposures.take(6).forEach { s ->
                val isPos = s.sectorContributionPct >= 0
                val color = if (isPos) UkxGainGreen else UkxLossRed

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = s.sector.displayName,
                        fontSize = 11.sp,
                        color = UkxTextSecondary,
                        modifier = Modifier.width(130.dp)
                    )
                    Text(
                        text = String.format("%.1f%%", s.weightPct),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = UkxTextMuted,
                        modifier = Modifier.width(48.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(UkxDivider)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth((s.weightPct / 25.0).toFloat().coerceIn(0.05f, 1.0f))
                                .height(4.dp)
                                .background(Color(s.sector.colorHex))
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = String.format("%+.2f%%", s.sectorContributionPct),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = color
                    )
                }
            }
        }
    }
}

@Composable
fun MethodologyStatusFooter(state: IndexState, uiState: UkxTerminalUiState) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurfaceElevated)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "METHODOLOGY: ${uiState.activeMethodology.version}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = UkxGoldAccent
                )
                Text(
                    text = "NEXT REVIEW: DEC 2026",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = UkxSteelBlue
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Unified 10% Free Float Threshold (June 2026 rulebook) | Multi-Currency (GBP/EUR/USD) | Buffer Zones 90/111",
                fontSize = 10.sp,
                color = UkxTextMuted
            )
        }
    }
}
