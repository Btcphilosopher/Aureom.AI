package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// City of London Institutional Dealing Room Palette (UKX-CORE)
val UkxObsidian = Color(0xFF090D12)
val UkxSurface = Color(0xFF101924)
val UkxSurfaceElevated = Color(0xFF162232)
val UkxCardBorder = Color(0xFF22354A)
val UkxDivider = Color(0xFF1A2A3C)

val UkxNavyBlue = Color(0xFF388BFD)
val UkxSteelBlue = Color(0xFF58A6FF)
val UkxGoldAccent = Color(0xFFD4AF37)
val UkxAmberWarn = Color(0xFFD29922)

val UkxGainGreen = Color(0xFF2EA043)
val UkxGainGreenBg = Color(0xFF122C1C)
val UkxLossRed = Color(0xFFF85149)
val UkxLossRedBg = Color(0xFF3B181A)
val UkxNeutralGray = Color(0xFF8B949E)

val UkxTextPrimary = Color(0xFFF0F6FC)
val UkxTextSecondary = Color(0xFFC9D1D9)
val UkxTextMuted = Color(0xFF8B949E)
val UkxTextDim = Color(0xFF6E7681)

val UkxTagOfficial = Color(0xFF238636)
val UkxTagSynthetic = Color(0xFF8957E5)
val UkxTagSimulated = Color(0xFF1F6FEB)
val UkxTagWarning = Color(0xFFD29922)
