package com.example.ukx.domain.model

data class FactorScore(
    val ticker: String,
    val companyName: String,
    val sector: UkSector,
    val valueScore: Double, // z-score -3 to +3
    val qualityScore: Double,
    val momentumScore: Double,
    val lowVolatilityScore: Double,
    val sizeScore: Double, // Large cap = positive
    val dividendYieldScore: Double,
    val compositeQuantRank: Int
)

enum class MacroScenarioType(val id: String, val title: String, val description: String) {
    GBP_STRENGTH("GBP_PLUS_5", "Sterling Appreciation (+5.0%)", "GBP strengthens against USD and EUR; dampens foreign-currency translational earnings of UK multinationals."),
    GBP_WEAKNESS("GBP_MINUS_5", "Sterling Depreciation (-5.0%)", "GBP drops; boosts overseas earnings translation for mega-cap commodity and global exporters."),
    UK_RATES_UP("UK_RATES_PLUS_100", "BoE Bank Rate Spike (+100 bps)", "Aggressive tightening; benefits high-street banks margin spread, pressures real estate and utilities."),
    UK_RATES_DOWN("UK_RATES_MINUS_100", "BoE Rate Easing (-100 bps)", "Monetary easing cycle; stimulates homebuilders, REITs, consumer cyclicals."),
    OIL_SHOCK_UP("OIL_PLUS_20", "Brent Crude Rally (+20.0%)", "Commodity supply squeeze; major tailwind for Shell & BP (approx 13% index weight)."),
    OIL_SHOCK_DOWN("OIL_MINUS_20", "Brent Crude Plunge (-20.0%)", "Commodity deflation; drags energy and materials sector earnings."),
    BANKING_STRESS("BANK_MINUS_15", "UK Banking Sector Stress (-15.0%)", "Systemic credit margin compression hitting HSBC, Barclays, Lloyds, NatWest."),
    GLOBAL_RECESSION("GLOBAL_RECESSION", "Global Stagflation / Equity Drawdown", "Synchronized global demand downturn impacting multinational exporters and miners.")
}

data class MacroScenarioImpact(
    val scenario: MacroScenarioType,
    val estimatedUkxReturnPct: Double,
    val estimatedIndexPointChange: Double,
    val equityReturnPct: Double,
    val fxTranslationalReturnPct: Double,
    val sectorImpacts: Map<UkSector, Double>,
    val topBeneficiaries: List<Pair<String, Double>>,
    val topImpacted: List<Pair<String, Double>>,
    val methodologyNote: String
)
