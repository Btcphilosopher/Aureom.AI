package com.example.ukx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxLossRed
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxSurfaceElevated
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.domain.model.IndexConstituent
import com.example.ukx.domain.model.SectorExposure
import com.example.ukx.domain.model.UkSector
import com.example.ukx.ui.UkxTerminalUiState

@Composable
fun HeatmapAndSectorsScreen(
    uiState: UkxTerminalUiState,
    onConstituentSelected: (IndexConstituent?) -> Unit,
    modifier: Modifier = Modifier
) {
    val state = uiState.currentIndexState ?: return
    val currency = uiState.selectedCurrency

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UkxObsidian)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("heatmap_sectors_screen")
    ) {
        Text(
            text = "FTSE 100 // MARKET-CAP TREEMAP & HEATMAP",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxTextPrimary
        )
        Text(
            text = "Area: Investable Market Capitalisation | Color: Daily Return",
            fontSize = 10.sp,
            color = UkxTextMuted
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Heatmap Grid of Top Constituents
        HeatmapGrid(
            constituents = state.constituents,
            onSelect = onConstituentSelected
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Complete 11 ICB Sector Exposure Table
        Text(
            text = "ICB SECTOR COMPOSITION & ATTRIBUTION DECOMPOSITION",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxGoldAccent
        )

        Spacer(modifier = Modifier.height(8.dp))

        state.sectorExposures.forEach { secExp ->
            SectorDetailRowCard(
                sectorExposure = secExp,
                currencySymbol = currency.symbol,
                currencyRate = currency.rateToGbp
            )
            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
fun HeatmapGrid(
    constituents: List<IndexConstituent>,
    onSelect: (IndexConstituent) -> Unit
) {
    val displayList = constituents.take(36)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(displayList) { c ->
                val ret = c.dailyReturnPct
                val cellColor = when {
                    ret > 2.0 -> UkxGainGreen
                    ret > 0.5 -> UkxGainGreen.copy(alpha = 0.75f)
                    ret > 0.0 -> UkxGainGreen.copy(alpha = 0.45f)
                    ret < -2.0 -> UkxLossRed
                    ret < -0.5 -> UkxLossRed.copy(alpha = 0.75f)
                    ret < 0.0 -> UkxLossRed.copy(alpha = 0.45f)
                    else -> UkxSurfaceElevated
                }

                Box(
                    modifier = Modifier
                        .height(42.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(cellColor)
                        .clickable { onSelect(c) }
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = c.ticker,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = Color.White
                        )
                        Text(
                            text = String.format("%+.1f%%", c.dailyReturnPct),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectorDetailRowCard(
    sectorExposure: SectorExposure,
    currencySymbol: String,
    currencyRate: Double
) {
    val sec = sectorExposure.sector
    val isPos = sectorExposure.sectorContributionPct >= 0
    val retColor = if (isPos) UkxGainGreen else UkxLossRed

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color(sec.colorHex))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = sec.displayName.uppercase(),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = UkxTextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "(${sectorExposure.constituentCount} stocks)",
                        fontSize = 10.sp,
                        color = UkxTextMuted
                    )
                }
                Text(
                    text = "Weight: ${String.format("%.2f%%", sectorExposure.weightPct)}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxSteelBlue
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Cap: ${currencySymbol}${String.format("%.1fB", (sectorExposure.totalInvestableCapGbp / 1e9) * currencyRate)}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = UkxTextSecondary
                )
                Text(
                    text = "Sector Return: ${String.format("%+.2f%%", sectorExposure.sectorReturnPct)}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = retColor
                )
                Text(
                    text = "Contribution: ${String.format("%+.2f%%", sectorExposure.sectorContributionPct)}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = retColor
                )
            }
        }
    }
}
