package com.example.ukx.core.engine

import com.example.ukx.domain.model.IndexConstituent
import com.example.ukx.domain.model.MarketBreadth
import com.example.ukx.domain.model.SectorExposure
import com.example.ukx.domain.model.UkSector

/**
 * Sector Breakdown & Market Breadth Engine
 * Computes ICB sector weightings, sector contribution points, advance/decline ratios,
 * and 50DMA/200DMA dispersion.
 */
object SectorAndBreadthEngine {

    fun calculateSectorExposures(
        constituents: List<IndexConstituent>,
        totalInvestableCapGbp: Double
    ): List<SectorExposure> {
        if (totalInvestableCapGbp <= 0.0) return emptyList()

        return UkSector.values().mapNotNull { sector ->
            val sectorStocks = constituents.filter { it.sector == sector }
            if (sectorStocks.isEmpty()) null
            else {
                val sectorInvestableCap = sectorStocks.sumOf { it.investableMarketCapGbp }
                val weightPct = (sectorInvestableCap / totalInvestableCapGbp) * 100.0
                val sectorContributionPct = sectorStocks.sumOf { it.contributionPct }
                val weightedReturnPct = if (weightPct > 0) (sectorContributionPct / (weightPct / 100.0)) else 0.0
                val topStock = sectorStocks.maxByOrNull { it.investableMarketCapGbp }?.ticker ?: ""

                SectorExposure(
                    sector = sector,
                    weightPct = weightPct,
                    constituentCount = sectorStocks.size,
                    totalInvestableCapGbp = sectorInvestableCap,
                    sectorReturnPct = weightedReturnPct,
                    sectorContributionPct = sectorContributionPct,
                    topConstituentTicker = topStock
                )
            }
        }.sortedByDescending { it.weightPct }
    }

    fun calculateMarketBreadth(constituents: List<IndexConstituent>): MarketBreadth {
        var adv = 0
        var dec = 0
        var unch = 0
        var above50 = 0
        var above200 = 0
        var newHighs = 0
        var newLows = 0

        for (c in constituents) {
            when {
                c.dailyReturnPct > 0.02 -> adv++
                c.dailyReturnPct < -0.02 -> dec++
                else -> unch++
            }
            if (c.isAbove50Dma) above50++
            if (c.isAbove200Dma) above200++
            if (c.dailyReturnPct > 2.5) newHighs++
            if (c.dailyReturnPct < -2.5) newLows++
        }

        val adRatio = if (dec > 0) adv.toDouble() / dec.toDouble() else adv.toDouble()
        val total = constituents.size.coerceAtLeast(1)

        return MarketBreadth(
            advancers = adv,
            decliners = dec,
            unchanged = unch,
            advanceDeclineRatio = adRatio,
            new52WeekHighs = newHighs,
            new52WeekLows = newLows,
            stocksAbove50DmaCount = above50,
            stocksAbove50DmaPct = (above50.toDouble() / total) * 100.0,
            stocksAbove200DmaCount = above200,
            stocksAbove200DmaPct = (above200.toDouble() / total) * 100.0
        )
    }
}
