package com.example.ukx.core.engine

import com.example.ukx.domain.model.CorporateActionEvent
import com.example.ukx.domain.model.CorporateActionType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * UKX Divisor Engine
 * 
 * Preserves price index continuity across corporate actions, share issuances,
 * buybacks, mergers, spinoffs, and quarterly constituent replacements.
 * 
 * Divisor Formula:
 * D_new = D_old * (Sum(P_new * S_new * FF_new) / Sum(P_old * S_old * FF_old))
 */
object UKXDivisorEngine {

    fun calculateNewDivisor(
        currentDivisor: Double,
        preEventInvestableCapGbp: Double,
        postEventInvestableCapGbp: Double
    ): Double {
        if (preEventInvestableCapGbp <= 0.0) return currentDivisor
        val ratio = postEventInvestableCapGbp / preEventInvestableCapGbp
        return currentDivisor * ratio
    }

    fun applyCorporateAction(
        currentDivisor: Double,
        totalInvestableCapGbp: Double,
        action: CorporateActionEvent
    ): Pair<Double, CorporateActionEvent> {
        val postCap = totalInvestableCapGbp + action.marketCapImpactGbp
        val newDivisor = calculateNewDivisor(currentDivisor, totalInvestableCapGbp, postCap)
        val appliedAction = action.copy(
            oldDivisor = currentDivisor,
            newDivisor = newDivisor,
            status = "APPLIED"
        )
        return Pair(newDivisor, appliedAction)
    }

    fun generateStandardCorporateActionHistory(baseDivisor: Double): List<CorporateActionEvent> {
        return listOf(
            CorporateActionEvent(
                eventId = "CA-2026-0812-SHEL-BB",
                ticker = "SHEL",
                companyName = "Shell plc",
                actionType = CorporateActionType.BUYBACK,
                exDate = "2026-08-12",
                effectiveDate = "2026-08-15",
                termsDescription = "Share buyback cancellation of 18,500,000 Ordinary Shares",
                oldDivisor = baseDivisor * 1.0004,
                newDivisor = baseDivisor,
                adjustmentFactor = 0.9996,
                marketCapImpactGbp = -520_000_000.0
            ),
            CorporateActionEvent(
                eventId = "CA-2026-0619-REV-Q2",
                ticker = "MULTIPLE",
                companyName = "Quarterly Reconstitution Q2 2026",
                actionType = CorporateActionType.CONSTITUENT_ADDITION,
                exDate = "2026-06-19",
                effectiveDate = "2026-06-22",
                termsDescription = "Addition of ABDN, CCC, INVP and deletion of BKG, MNDI, RMV",
                oldDivisor = baseDivisor * 1.0018,
                newDivisor = baseDivisor * 1.0004,
                adjustmentFactor = 0.9986,
                marketCapImpactGbp = 1_840_000_000.0
            ),
            CorporateActionEvent(
                eventId = "CA-2026-0504-AZN-DIVSP",
                ticker = "AZN",
                companyName = "AstraZeneca plc",
                actionType = CorporateActionType.SPECIAL_DIVIDEND,
                exDate = "2026-05-04",
                effectiveDate = "2026-05-04",
                termsDescription = "Special Capital Return Dividend of 85.0p per Ordinary Share",
                oldDivisor = baseDivisor * 1.0029,
                newDivisor = baseDivisor * 1.0018,
                adjustmentFactor = 0.9989,
                marketCapImpactGbp = -1_320_000_000.0
            ),
            CorporateActionEvent(
                eventId = "CA-2026-0320-REV-Q1",
                ticker = "MULTIPLE",
                companyName = "Quarterly Reconstitution Q1 2026",
                actionType = CorporateActionType.FREE_FLOAT_CHANGE,
                exDate = "2026-03-20",
                effectiveDate = "2026-03-23",
                termsDescription = "Quarterly free-float factor updates across 14 constituents",
                oldDivisor = baseDivisor * 1.0042,
                newDivisor = baseDivisor * 1.0029,
                adjustmentFactor = 0.9987,
                marketCapImpactGbp = 890_000_000.0
            )
        )
    }
}
