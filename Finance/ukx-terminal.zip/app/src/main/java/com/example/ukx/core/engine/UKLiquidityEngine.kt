package com.example.ukx.core.engine

import com.example.ukx.domain.model.SecurityMasterRecord

/**
 * UK Liquidity Engine
 * Computes median daily volume, turnover ratio, and trading frequency.
 * Non-constituents require monthly median daily volume >= 0.05% of free-float shares
 * in at least 10 of 12 months; existing constituents require >= 0.04% in at least 8 of 12 months.
 */
object UKLiquidityEngine {

    fun calculateLiquidityRatio(
        medianDailyVolume: Long,
        sharesInIssue: Long,
        freeFloatFactor: Double
    ): Double {
        val freeFloatShares = sharesInIssue.toDouble() * freeFloatFactor.coerceAtLeast(0.01)
        if (freeFloatShares <= 0.0) return 0.0
        return (medianDailyVolume.toDouble() / freeFloatShares) * 100.0
    }

    fun isLiquidityEligible(
        security: SecurityMasterRecord,
        isExistingConstituent: Boolean = false
    ): Boolean {
        val ratio = calculateLiquidityRatio(
            security.medianDailyVolume,
            security.sharesInIssue,
            security.freeFloatFactor
        )
        val threshold = if (isExistingConstituent) 0.03 else 0.05
        return ratio >= threshold && security.daysTradedPct >= 0.90
    }
}
