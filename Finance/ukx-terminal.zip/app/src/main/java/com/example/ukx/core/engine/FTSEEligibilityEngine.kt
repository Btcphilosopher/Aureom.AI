package com.example.ukx.core.engine

import com.example.ukx.domain.model.EligibilityTestResult
import com.example.ukx.domain.model.MethodologyVersion
import com.example.ukx.domain.model.RejectionReason
import com.example.ukx.domain.model.SecurityMasterRecord
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * FTSE Eligibility Engine: 7-Stage Pipeline
 * 
 * Pipeline:
 * SECURITY UNIVERSE
 *        ↓
 * 1. LISTING TEST
 *        ↓
 * 2. NATIONALITY TEST
 *        ↓
 * 3. SECURITY TYPE TEST
 *        ↓
 * 4. CURRENCY TEST
 *        ↓
 * 5. FREE FLOAT TEST
 *        ↓
 * 6. LIQUIDITY TEST
 *        ↓
 * 7. SUSPENSION / CORPORATE STATE TEST
 *        ↓
 * ELIGIBLE UNIVERSE
 */
object FTSEEligibilityEngine {

    fun testEligibility(
        security: SecurityMasterRecord,
        methodology: MethodologyVersion = MethodologyVersion.VERSION_2026_JUN,
        isExistingConstituent: Boolean = false
    ): EligibilityTestResult {
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK).format(Date())

        val listingOk = NationalityEligibilityEngine.isListingEligible(security)
        val nationalityOk = NationalityEligibilityEngine.isNationalityEligible(security)
        val securityTypeOk = security.listingType != com.example.ukx.domain.model.LseListingType.DEPOSITORY_RECEIPT
        val currencyOk = NationalityEligibilityEngine.isCurrencyEligible(security, methodology)
        val freeFloatOk = FreeFloatEngine.isFreeFloatEligible(security.freeFloatFactor, methodology)
        val liquidityOk = UKLiquidityEngine.isLiquidityEligible(security, isExistingConstituent)
        val suspensionOk = !security.isSuspended

        val rejectionReason = when {
            !suspensionOk -> RejectionReason.INELIGIBLE_SUSPENSION
            !listingOk -> RejectionReason.INELIGIBLE_LISTING
            !nationalityOk -> RejectionReason.INELIGIBLE_NATIONALITY
            !securityTypeOk -> RejectionReason.INELIGIBLE_SECURITY_TYPE
            !currencyOk -> RejectionReason.INELIGIBLE_CURRENCY
            !freeFloatOk -> RejectionReason.INELIGIBLE_FREE_FLOAT
            !liquidityOk -> RejectionReason.INELIGIBLE_LIQUIDITY
            else -> RejectionReason.NONE
        }

        val isEligible = rejectionReason == RejectionReason.NONE

        return EligibilityTestResult(
            securityId = security.securityId,
            ticker = security.ticker,
            listingEligible = listingOk,
            nationalityEligible = nationalityOk,
            securityTypeEligible = securityTypeOk,
            currencyEligible = currencyOk,
            freeFloatEligible = freeFloatOk,
            liquidityEligible = liquidityOk,
            suspensionEligible = suspensionOk,
            isEligible = isEligible,
            primaryRejectionReason = rejectionReason,
            methodologyVersion = methodology.version,
            testedAt = now
        )
    }

    fun filterEligibleUniverse(
        securities: List<SecurityMasterRecord>,
        methodology: MethodologyVersion = MethodologyVersion.VERSION_2026_JUN
    ): List<SecurityMasterRecord> {
        return securities.filter { sec ->
            testEligibility(sec, methodology).isEligible
        }
    }
}
