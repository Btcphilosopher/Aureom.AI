package com.example.ukx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxLossRed
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxSurfaceElevated
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.core.engine.CustomIndexConfig
import com.example.ukx.core.engine.FactorTilt
import com.example.ukx.domain.model.MacroScenarioImpact
import com.example.ukx.domain.model.MacroScenarioType
import com.example.ukx.ui.UkxTerminalUiState
import com.example.ukx.ui.components.MetricStatTile

@Composable
fun MacroScenarioLabScreen(
    uiState: UkxTerminalUiState,
    onScenarioSelected: (MacroScenarioType) -> Unit,
    onCustomIndexBuild: (CustomIndexConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    val impact = uiState.activeScenarioImpact ?: return
    val currency = uiState.selectedCurrency

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UkxObsidian)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("macro_scenario_screen")
    ) {
        Text(
            text = "MACRO SCENARIOS & DIGITAL TWIN LAB",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxTextPrimary
        )
        Text(
            text = "Simulate currency translation, commodity shocks, and interest rate impacts",
            fontSize = 10.sp,
            color = UkxTextMuted
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Scenario Selector Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(MacroScenarioType.values()) { scn ->
                val isSel = scn == uiState.activeScenario
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) UkxSteelBlue.copy(alpha = 0.25f) else UkxSurfaceElevated)
                        .border(1.dp, if (isSel) UkxSteelBlue else UkxCardBorder, RoundedCornerShape(6.dp))
                        .clickable { onScenarioSelected(scn) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = scn.title,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 10.sp,
                        color = if (isSel) UkxSteelBlue else UkxTextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Scenario Impact Overview
        ScenarioImpactHeroCard(impact = impact)

        Spacer(modifier = Modifier.height(14.dp))

        // Top Beneficiaries vs Top Impacted
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ScenarioStockColumn("TOP BENEFICIARIES", impact.topBeneficiaries, isPositive = true, modifier = Modifier.weight(1f))
            ScenarioStockColumn("MOST NEGATIVE", impact.topImpacted, isPositive = false, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Custom Institutional Index Lab
        Text(
            text = "CUSTOM UK INDEX LAB // FACTOR TILTS & QUANT BACKTEST",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxGoldAccent
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(FactorTilt.values()) { tilt ->
                val isCurrent = uiState.customIndexConfig.factorTilt == tilt
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isCurrent) UkxGoldAccent.copy(alpha = 0.2f) else UkxSurface)
                        .border(1.dp, if (isCurrent) UkxGoldAccent else UkxCardBorder, RoundedCornerShape(6.dp))
                        .clickable {
                            onCustomIndexBuild(
                                CustomIndexConfig(
                                    indexName = tilt.label,
                                    indexCode = "UKX_${tilt.name.take(4)}",
                                    factorTilt = tilt
                                )
                            )
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = tilt.label,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = if (isCurrent) UkxGoldAccent else UkxTextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        uiState.customIndexState?.let { cis ->
            CustomIndexResultCard(state = cis)
        }
    }
}

@Composable
fun ScenarioImpactHeroCard(impact: MacroScenarioImpact) {
    val isPos = impact.estimatedUkxReturnPct >= 0
    val color = if (isPos) UkxGainGreen else UkxLossRed

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = impact.scenario.description,
                fontSize = 11.sp,
                color = UkxTextSecondary
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "FTSE 100 Impact",
                    value = String.format("%+.2f%%", impact.estimatedUkxReturnPct),
                    subValue = String.format("%+,.1f pts", impact.estimatedIndexPointChange),
                    subValueColor = color,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Equity vs FX Split",
                    value = "Eq: ${String.format("%+.1f%%", impact.equityReturnPct)}",
                    subValue = "FX: ${String.format("%+.1f%%", impact.fxTranslationalReturnPct)}",
                    subValueColor = UkxSteelBlue,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun ScenarioStockColumn(
    title: String,
    items: List<Pair<String, Double>>,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    val color = if (isPositive) UkxGainGreen else UkxLossRed

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(
                text = title,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = color
            )
            Spacer(modifier = Modifier.height(6.dp))
            items.forEach { (ticker, ret) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = ticker, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = UkxTextPrimary)
                    Text(text = String.format("%+.2f%%", ret), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = color)
                }
            }
        }
    }
}

@Composable
fun CustomIndexResultCard(state: com.example.ukx.domain.model.IndexState) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurfaceElevated)
            .border(1.dp, UkxGoldAccent.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${state.index.indexName.uppercase()} (${state.index.constituentCount} Constituents)",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxGoldAccent
                )
                Text(
                    text = "BACKTESTED",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = UkxTextMuted
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Index Level",
                    value = String.format("%,.2f", state.indexLevel),
                    subValue = String.format("%+.2f%% today", state.dailyReturnPct),
                    subValueColor = if (state.dailyReturnPct >= 0) UkxGainGreen else UkxLossRed,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Investable Cap",
                    value = "£${String.format("%.1fB", state.totalInvestableMarketCapGbp / 1e9)}",
                    subValue = "Top 5: ${String.format("%.1f%%", state.top5WeightPct)}",
                    subValueColor = UkxSteelBlue,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
