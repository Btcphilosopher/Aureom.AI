package com.example.ukx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RemoveCircle
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxLossRed
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxSurfaceElevated
import com.example.ui.theme.UkxTagSimulated
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.domain.model.QuarterlyReviewEvent
import com.example.ukx.domain.model.ReviewCandidate
import com.example.ukx.domain.model.ReviewConstituentChange
import com.example.ukx.ui.UkxTerminalUiState
import com.example.ukx.ui.components.MetricStatTile

@Composable
fun QuarterlyReviewScreen(
    uiState: UkxTerminalUiState,
    onReviewSelected: (QuarterlyReviewEvent) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeReview = uiState.activeReviewEvent ?: return
    val currency = uiState.selectedCurrency

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UkxObsidian)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("quarterly_review_screen")
    ) {
        Text(
            text = "QUARTERLY REVIEW ENGINE // RECONSTITUTION TWIN",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxTextPrimary
        )
        Text(
            text = "Methodology: Rank <= 90 (Auto Inclusion) | Rank >= 111 (Auto Demotion)",
            fontSize = 10.sp,
            color = UkxTextMuted
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Review Cycle Selector Tabs
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val allEvents = listOfNotNull(activeReview) + uiState.historicalReviews.filter { it.reviewId != activeReview.reviewId }
            items(allEvents) { rev ->
                val isSel = rev.reviewId == activeReview.reviewId
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSel) UkxSteelBlue.copy(alpha = 0.25f) else UkxSurfaceElevated)
                        .border(1.dp, if (isSel) UkxSteelBlue else UkxCardBorder, RoundedCornerShape(6.dp))
                        .clickable { onReviewSelected(rev) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Column {
                        Text(
                            text = rev.reviewQuarter,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (isSel) UkxSteelBlue else UkxTextPrimary
                        )
                        Text(
                            text = if (rev.status == com.example.ukx.domain.model.DataStatus.SIMULATED) "SIMULATED" else "HISTORICAL REPLAY",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = if (rev.status == com.example.ukx.domain.model.DataStatus.SIMULATED) UkxTagSimulated else UkxGoldAccent
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Review Timetable & Turnover Stats
        ReviewTimetableCard(review = activeReview)

        Spacer(modifier = Modifier.height(14.dp))

        // Additions & Deletions
        Text(
            text = "CONSTITUENT ADDITIONS & DELETIONS",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxGoldAccent
        )

        Spacer(modifier = Modifier.height(6.dp))

        if (activeReview.additions.isNotEmpty()) {
            activeReview.additions.forEach { add ->
                ConstituentChangeCard(item = add, isAddition = true, currencySymbol = currency.symbol, currencyRate = currency.rateToGbp)
                Spacer(modifier = Modifier.height(4.dp))
            }
        }

        if (activeReview.deletions.isNotEmpty()) {
            activeReview.deletions.forEach { del ->
                ConstituentChangeCard(item = del, isAddition = false, currencySymbol = currency.symbol, currencyRate = currency.rateToGbp)
                Spacer(modifier = Modifier.height(4.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Buffer Monitor & Challenger List (Ranks 85 to 115)
        Text(
            text = "FTSE REVIEW BUFFER MONITOR // BOUNDARY RANKS 85–115",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxTextPrimary
        )

        Spacer(modifier = Modifier.height(6.dp))

        val boundaryCandidates = uiState.reviewCandidates.filter { it.rank in 80..115 }
        boundaryCandidates.forEach { cand ->
            ReviewCandidateRowCard(candidate = cand, currencySymbol = currency.symbol, currencyRate = currency.rateToGbp)
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}

@Composable
fun ReviewTimetableCard(review: QuarterlyReviewEvent) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = review.title.uppercase(),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxTextPrimary
                )
                Text(
                    text = "Method: ${review.methodologyVersion}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = UkxGoldAccent
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Ranking Cutoff",
                    value = review.calendar.rankingCutoff.take(10),
                    subValue = "Data Close",
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Effective Date",
                    value = review.calendar.effectiveDate.take(10),
                    subValue = "Monday Open",
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "One-Way Turnover",
                    value = String.format("%.2f%%", review.oneWayTurnoverPct),
                    subValue = "Passive £${String.format("%.0fM", review.estimatedPassiveRebalanceGbp / 1e6)}",
                    subValueColor = UkxSteelBlue,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = review.officialAnnouncementNotice,
                fontSize = 10.sp,
                color = UkxTextMuted
            )
        }
    }
}

@Composable
fun ConstituentChangeCard(
    item: ReviewConstituentChange,
    isAddition: Boolean,
    currencySymbol: String,
    currencyRate: Double
) {
    val color = if (isAddition) UkxGainGreen else UkxLossRed
    val icon = if (isAddition) Icons.Default.AddCircle else Icons.Default.RemoveCircle

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = if (isAddition) "Addition" else "Deletion",
                tint = color,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.ticker,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = UkxTextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.companyName,
                        fontSize = 11.sp,
                        color = UkxTextSecondary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Rank #${item.rank}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = UkxGoldAccent
                    )
                }
                Text(
                    text = item.reason,
                    fontSize = 10.sp,
                    color = UkxTextMuted
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (isAddition) "+ ADDED" else "- REMOVED",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = color
                )
                Text(
                    text = "${currencySymbol}${String.format("%.1fB", (item.investableMarketCapGbp / 1e9) * currencyRate)}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = UkxTextSecondary
                )
            }
        }
    }
}

@Composable
fun ReviewCandidateRowCard(
    candidate: ReviewCandidate,
    currencySymbol: String,
    currencyRate: Double
) {
    val statusColor = Color(candidate.bufferStatus.badgeColorHex)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(UkxSurface)
            .border(0.5.dp, UkxDivider, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "#${candidate.rank}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = UkxGoldAccent,
                    modifier = Modifier.width(36.dp)
                )
                Text(
                    text = candidate.ticker,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxTextPrimary,
                    modifier = Modifier.width(55.dp)
                )
                Column {
                    Text(
                        text = candidate.companyName,
                        fontSize = 11.sp,
                        color = UkxTextSecondary,
                        maxLines = 1
                    )
                    Text(
                        text = candidate.bufferStatus.label,
                        fontSize = 9.sp,
                        color = statusColor
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${candidate.currentIndex} → ${candidate.projectedIndex}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = UkxSteelBlue
                )
                Text(
                    text = "Full: ${currencySymbol}${String.format("%.1fB", (candidate.fullMarketCapGbp / 1e9) * currencyRate)}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = UkxTextMuted
                )
            }
        }
    }
}
