package com.example.ukx.domain.model

enum class CorporateActionType(val displayName: String) {
    CASH_DIVIDEND("Cash Dividend"),
    SPECIAL_DIVIDEND("Special Dividend (Capital Adjustment)"),
    STOCK_SPLIT("Stock Split / Consolidation"),
    RIGHTS_ISSUE("Rights Issue"),
    OPEN_OFFER("Open Offer"),
    BUYBACK("Share Buyback / Cancellation"),
    SPINOFF("Demerger / Spinoff"),
    MERGER_ACQUISITION("Merger & Acquisition"),
    FREE_FLOAT_CHANGE("Free Float Factor Review"),
    CONSTITUENT_ADDITION("Constituent Fast Entry / Review Addition"),
    CONSTITUENT_DELETION("Constituent Takeover / Demotion Deletion")
}

data class CorporateActionEvent(
    val eventId: String,
    val ticker: String,
    val companyName: String,
    val actionType: CorporateActionType,
    val exDate: String,
    val effectiveDate: String,
    val termsDescription: String,
    val oldDivisor: Double,
    val newDivisor: Double,
    val adjustmentFactor: Double,
    val marketCapImpactGbp: Double,
    val preservesIndexContinuity: Boolean = true,
    val status: String = "APPLIED"
) {
    val divisorChangePct: Double
        get() = if (oldDivisor > 0) ((newDivisor - oldDivisor) / oldDivisor) * 100.0 else 0.0
}
