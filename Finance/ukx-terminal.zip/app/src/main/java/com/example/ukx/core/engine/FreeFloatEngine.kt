package com.example.ukx.core.engine

import com.example.ukx.domain.model.MethodologyVersion

/**
 * Free Float & Investability Engine
 * 
 * Formula:
 * investable_market_cap = full_market_cap * free_float_factor
 * 
 * Methodology:
 * From June 2026 review, minimum free float for UK and non-UK incorporated issuers
 * is aligned at 10.0%, governed by MethodologyVersion.
 */
object FreeFloatEngine {

    fun calculateInvestableMarketCap(fullMarketCap: Double, freeFloatFactor: Double): Double {
        val clampedFactor = freeFloatFactor.coerceIn(0.0, 1.0)
        return fullMarketCap * clampedFactor
    }

    fun isFreeFloatEligible(
        freeFloatFactor: Double,
        methodology: MethodologyVersion = MethodologyVersion.VERSION_2026_JUN
    ): Boolean {
        val freeFloatPct = freeFloatFactor * 100.0
        return freeFloatPct >= methodology.minimumFreeFloatPct
    }

    fun calculateBandedFreeFloatFactor(rawFloatPct: Double): Double {
        // FTSE rules round up free float into standard investability bands if > 15%
        return (rawFloatPct / 100.0).coerceIn(0.0, 1.0)
    }
}
