package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val UkxTerminalColorScheme = darkColorScheme(
    primary = UkxSteelBlue,
    onPrimary = Color(0xFF040D1A),
    primaryContainer = Color(0xFF162A45),
    onPrimaryContainer = Color(0xFFD6E8FF),
    secondary = UkxGoldAccent,
    onSecondary = Color(0xFF1E1600),
    secondaryContainer = Color(0xFF33290D),
    onSecondaryContainer = Color(0xFFFFECC0),
    tertiary = UkxNavyBlue,
    background = UkxObsidian,
    onBackground = UkxTextPrimary,
    surface = UkxSurface,
    onSurface = UkxTextPrimary,
    surfaceVariant = UkxSurfaceElevated,
    onSurfaceVariant = UkxTextSecondary,
    outline = UkxCardBorder,
    outlineVariant = UkxDivider,
    error = UkxLossRed,
    onError = Color.White
)

@Composable
fun UkxTerminalTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = UkxTerminalColorScheme,
        typography = UkxTypography,
        content = content
    )
}
