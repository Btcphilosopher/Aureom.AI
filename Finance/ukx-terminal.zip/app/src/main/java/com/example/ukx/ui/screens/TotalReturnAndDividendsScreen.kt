package com.example.ukx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.domain.model.DividendPointRecord
import com.example.ukx.ui.UkxTerminalUiState
import com.example.ukx.ui.components.MetricStatTile

@Composable
fun TotalReturnAndDividendsScreen(
    uiState: UkxTerminalUiState,
    modifier: Modifier = Modifier
) {
    val state = uiState.currentIndexState ?: return
    val divState = uiState.dividendState

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UkxObsidian)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("total_return_screen")
    ) {
        Text(
            text = "FTSE 100 // TOTAL RETURN & DIVIDEND POINTS ENGINE",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxTextPrimary
        )
        Text(
            text = "Gross Total Return (reinvested on ex-date) vs Net of Tax vs Price Index",
            fontSize = 10.sp,
            color = UkxTextMuted
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Comparative Index Trio
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricStatTile(
                label = "Price Index (UKX)",
                value = String.format("%,.2f", state.indexLevel),
                subValue = "Capital Only",
                subValueColor = UkxTextMuted,
                modifier = Modifier.weight(1f)
            )
            MetricStatTile(
                label = "Gross TR Index",
                value = String.format("%,.2f", state.totalReturnLevel),
                subValue = "+49.8% Cumulative Alpha",
                subValueColor = UkxGainGreen,
                modifier = Modifier.weight(1f)
            )
            MetricStatTile(
                label = "Net TR Index",
                value = String.format("%,.2f", state.netTotalReturnLevel),
                subValue = "Tax Adjusted",
                subValueColor = UkxSteelBlue,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Annual Dividend Points Run Rate
        divState?.let { ds ->
            DividendRunRateCard(dividendState = ds)
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Upcoming Ex-Dividend Schedule & Points Impact
        Text(
            text = "FTSE 100 EX-DIVIDEND SCHEDULE & INDEX IMPACT",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxGoldAccent
        )

        Spacer(modifier = Modifier.height(8.dp))

        divState?.topDividendContributors?.forEach { div ->
            ExDividendRowCard(record = div)
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}

@Composable
fun DividendRunRateCard(dividendState: com.example.ukx.domain.model.DividendSeriesState) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ANNUAL DIVIDEND POINTS METRICS (2026)",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxTextPrimary
                )
                Text(
                    text = "Fwd Yield: ${String.format("%.2f%%", dividendState.estimatedForwardAnnualYieldPct)}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = UkxGainGreen
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricStatTile(
                    label = "Annual Declared",
                    value = "${String.format("%.2f", dividendState.annualDeclaredPoints)} pts",
                    subValue = "Full Year Run-Rate",
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "YTD Cumulative",
                    value = "${String.format("%.2f", dividendState.cumulativeYearToDatePoints)} pts",
                    subValue = "80% of annual total",
                    subValueColor = UkxSteelBlue,
                    modifier = Modifier.weight(1f)
                )
                MetricStatTile(
                    label = "Rolling 12M",
                    value = "${String.format("%.2f", dividendState.rolling12mPoints)} pts",
                    subValue = "Trailing LTM",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun ExDividendRowCard(record: DividendPointRecord) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(UkxSurface)
            .border(0.5.dp, UkxDivider, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = record.ticker,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = UkxGoldAccent
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = record.companyName,
                        fontSize = 11.sp,
                        color = UkxTextPrimary
                    )
                }
                Text(
                    text = "Ex-Date: ${record.exDate} • Pay: ${record.paymentDate} • DPS: £${String.format("%.3f", record.dividendPerShareGbp)}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = UkxTextMuted
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${String.format("+%.2f pts", record.dividendPoints)}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxGainGreen
                )
                Text(
                    text = "Yield Impact: ${String.format("%.1f bps", record.indexYieldImpactBps)}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = UkxTextSecondary
                )
            }
        }
    }
}
