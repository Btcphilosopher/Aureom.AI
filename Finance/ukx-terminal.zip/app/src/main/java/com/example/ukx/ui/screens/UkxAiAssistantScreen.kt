package com.example.ukx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxSurfaceElevated
import com.example.ui.theme.UkxTagSynthetic
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.ui.UkxAiChatMessage
import com.example.ukx.ui.UkxTerminalUiState

@Composable
fun UkxAiAssistantScreen(
    uiState: UkxTerminalUiState,
    onSendMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }

    val samplePrompts = listOf(
        "Why did UKX rise today?",
        "What is the next quarterly review schedule?",
        "Simulate impact of GBP +5% FX shock",
        "Explain divisor continuity in corporate actions",
        "Which constituents are near the 111 demotion boundary?"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UkxObsidian)
            .padding(12.dp)
            .testTag("ukx_ai_assistant_screen")
    ) {
        // Header info
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = "Verified Quant",
                    tint = UkxSteelBlue,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "UKX AI // QUANTITATIVE ATTRIBUTION ENGINE",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxTextPrimary
                )
            }
            Text(
                text = "ZERO-HALLUCINATION",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = UkxGainGreen
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Preset Prompt Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(samplePrompts) { prompt ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(UkxSurfaceElevated)
                        .border(1.dp, UkxCardBorder, RoundedCornerShape(4.dp))
                        .clickable { onSendMessage(prompt) }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = prompt,
                        fontSize = 10.sp,
                        color = UkxTextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Messages List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(uiState.aiMessages, key = { it.id }) { msg ->
                AiMessageBubble(message = msg)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Ask UKX attribution or reconstitution query...", fontSize = 11.sp, color = UkxTextMuted) },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("ai_query_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = UkxSteelBlue,
                    unfocusedBorderColor = UkxCardBorder,
                    focusedTextColor = UkxTextPrimary,
                    unfocusedTextColor = UkxTextPrimary,
                    focusedContainerColor = UkxSurface,
                    unfocusedContainerColor = UkxSurface
                ),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(6.dp))
            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        onSendMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(UkxSteelBlue)
                    .testTag("ai_send_button")
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.Black)
            }
        }
    }
}

@Composable
fun AiMessageBubble(message: UkxAiChatMessage) {
    val isUser = message.sender == "USER"

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(if (isUser) 0.85f else 1.0f)
                .clip(RoundedCornerShape(6.dp))
                .background(if (isUser) UkxSurfaceElevated else UkxSurface)
                .border(
                    width = 1.dp,
                    color = if (isUser) UkxSteelBlue.copy(alpha = 0.5f) else UkxCardBorder,
                    shape = RoundedCornerShape(6.dp)
                )
                .padding(10.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isUser) "PORTFOLIO MANAGER" else "UKX-CORE QUANT ANALYST",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = if (isUser) UkxSteelBlue else UkxGoldAccent
                    )
                    Text(
                        text = message.timestamp,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = UkxTextMuted
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = message.content,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = UkxTextPrimary
                )

                if (message.calculationDetails != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(UkxObsidian)
                            .border(0.5.dp, UkxDivider, RoundedCornerShape(4.dp))
                            .padding(6.dp)
                    ) {
                        Column {
                            Text(
                                text = "CALCULATION TRACE:",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 8.sp,
                                color = UkxGainGreen
                            )
                            Text(
                                text = message.calculationDetails,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                color = UkxTextSecondary
                            )
                        }
                    }
                }

                if (message.provenance != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Provenance: ${message.provenance} | Checksum: ${message.methodologyChecksum}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.sp,
                        color = UkxTagSynthetic
                    )
                }
            }
        }
    }
}
