package com.example.ukx.domain.model

enum class DataStatus(val displayName: String, val badgeColorHex: Long) {
    OFFICIAL("OFFICIAL", 0xFF238636),
    LICENSED("LICENSED", 0xFF1F6FEB),
    VENDOR("VENDOR", 0xFF388BFD),
    SYNTHETIC("SYNTHETIC", 0xFF8957E5),
    RECONSTRUCTED("RECONSTRUCTED", 0xFFD29922),
    SIMULATED("SIMULATED", 0xFFDB6D28),
    BACKTESTED("BACKTESTED", 0xFF6E7681)
}

data class ProvenanceRecord(
    val source: String = "UKX-CORE Synthetic Engine",
    val provider: String = "SyntheticFTSEProvider",
    val timestamp: String,
    val effectiveAt: String,
    val status: DataStatus = DataStatus.SYNTHETIC,
    val methodologyChecksum: String = "SHA256:8f4c91a02b3e77"
)

enum class IndexFamily(val label: String) {
    FTSE_UK_SERIES("FTSE UK Index Series"),
    FTSE_DERIVED_FACTORS("FTSE Derived Factor Series"),
    CUSTOM_QUANT("Custom Institutional Quant")
}

data class FTSEIndex(
    val indexId: String,
    val indexName: String,
    val indexCode: String,
    val provider: String = "UKX-CORE / Synthetic",
    val currency: String = "GBP",
    val country: String = "United Kingdom",
    val indexFamily: IndexFamily = IndexFamily.FTSE_UK_SERIES,
    val methodologyVersion: String = "UKX-METH-2026.2",
    val baseDate: String = "1984-01-03",
    val baseValue: Double = 1000.00,
    val divisor: Double = 23749281.45,
    val reviewFrequency: String = "Quarterly (Mar/Jun/Sep/Dec)",
    val calculationFrequency: String = "Real-time continuous (15s)",
    val constituentCount: Int = 100,
    val status: DataStatus = DataStatus.SYNTHETIC,
    val isCustom: Boolean = false
) {
    companion object {
        val UKX_100 = FTSEIndex(
            indexId = "FTSE100",
            indexName = "FTSE 100 Index",
            indexCode = "UKX",
            currency = "GBP",
            constituentCount = 100
        )
        val MCX_250 = FTSEIndex(
            indexId = "FTSE250",
            indexName = "FTSE 250 Index",
            indexCode = "MCX",
            currency = "GBP",
            constituentCount = 250
        )
        val NMX_350 = FTSEIndex(
            indexId = "FTSE350",
            indexName = "FTSE 350 Index",
            indexCode = "NMX",
            currency = "GBP",
            constituentCount = 350
        )
        val ASX_ALL_SHARE = FTSEIndex(
            indexId = "FTSE_ALL_SHARE",
            indexName = "FTSE All-Share Index",
            indexCode = "ASX",
            currency = "GBP",
            constituentCount = 574
        )
        val SMX_SMALLCAP = FTSEIndex(
            indexId = "FTSE_SMALLCAP",
            indexName = "FTSE SmallCap Index",
            indexCode = "SMX",
            currency = "GBP",
            constituentCount = 224
        )
        val UKX_EQUAL_WEIGHT = FTSEIndex(
            indexId = "UKX_EQW",
            indexName = "FTSE 100 Equal Weight",
            indexCode = "UKXEW",
            indexFamily = IndexFamily.FTSE_DERIVED_FACTORS,
            isCustom = true
        )
        val UKX_DIVIDEND_PLUS = FTSEIndex(
            indexId = "UKX_DIV50",
            indexName = "FTSE UK Dividend 50",
            indexCode = "UKDIV",
            indexFamily = IndexFamily.FTSE_DERIVED_FACTORS,
            constituentCount = 50,
            isCustom = true
        )
        val UKX_QUALITY_50 = FTSEIndex(
            indexId = "UKX_QUAL50",
            indexName = "FTSE UK Quality 50",
            indexCode = "UKQUAL",
            indexFamily = IndexFamily.FTSE_DERIVED_FACTORS,
            constituentCount = 50,
            isCustom = true
        )
        val UKX_LOW_VOL = FTSEIndex(
            indexId = "UKX_LOWVOL",
            indexName = "FTSE UK Low Volatility 50",
            indexCode = "UKLVOL",
            indexFamily = IndexFamily.FTSE_DERIVED_FACTORS,
            constituentCount = 50,
            isCustom = true
        )
        val UKX_MOMENTUM = FTSEIndex(
            indexId = "UKX_MOM50",
            indexName = "FTSE UK Momentum 50",
            indexCode = "UKMOM",
            indexFamily = IndexFamily.FTSE_DERIVED_FACTORS,
            constituentCount = 50,
            isCustom = true
        )
    }
}
