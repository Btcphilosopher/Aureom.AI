package com.example.ukx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxLossRed
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxSurfaceElevated
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.domain.model.IndexConstituent
import com.example.ukx.domain.model.UkSector
import com.example.ukx.ui.ConstituentSortField
import com.example.ukx.ui.SortDirection
import com.example.ukx.ui.UkxTerminalUiState
import com.example.ukx.ui.components.MetricStatTile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConstituentMatrixScreen(
    uiState: UkxTerminalUiState,
    onSearchQueryChanged: (String) -> Unit,
    onSectorFilterSelected: (UkSector?) -> Unit,
    onSortFieldSelected: (ConstituentSortField) -> Unit,
    onConstituentSelected: (IndexConstituent?) -> Unit,
    modifier: Modifier = Modifier
) {
    val state = uiState.currentIndexState ?: return
    val currency = uiState.selectedCurrency

    var filtered = state.constituents.filter { c ->
        (uiState.searchQuery.isEmpty() ||
                c.ticker.contains(uiState.searchQuery.trim(), ignoreCase = true) ||
                c.companyName.contains(uiState.searchQuery.trim(), ignoreCase = true) ||
                c.sector.displayName.contains(uiState.searchQuery.trim(), ignoreCase = true)) &&
                (uiState.selectedSectorFilter == null || c.sector == uiState.selectedSectorFilter)
    }

    filtered = when (uiState.sortField) {
        ConstituentSortField.RANK -> if (uiState.sortDirection == SortDirection.ASCENDING) filtered.sortedBy { it.rank } else filtered.sortedByDescending { it.rank }
        ConstituentSortField.TICKER -> if (uiState.sortDirection == SortDirection.ASCENDING) filtered.sortedBy { it.ticker } else filtered.sortedByDescending { it.ticker }
        ConstituentSortField.FULL_MCAP -> if (uiState.sortDirection == SortDirection.ASCENDING) filtered.sortedBy { it.fullMarketCapGbp } else filtered.sortedByDescending { it.fullMarketCapGbp }
        ConstituentSortField.INVESTABLE_MCAP -> if (uiState.sortDirection == SortDirection.ASCENDING) filtered.sortedBy { it.investableMarketCapGbp } else filtered.sortedByDescending { it.investableMarketCapGbp }
        ConstituentSortField.FREE_FLOAT -> if (uiState.sortDirection == SortDirection.ASCENDING) filtered.sortedBy { it.freeFloatFactor } else filtered.sortedByDescending { it.freeFloatFactor }
        ConstituentSortField.WEIGHT -> if (uiState.sortDirection == SortDirection.ASCENDING) filtered.sortedBy { it.weightPct } else filtered.sortedByDescending { it.weightPct }
        ConstituentSortField.RETURN -> if (uiState.sortDirection == SortDirection.ASCENDING) filtered.sortedBy { it.dailyReturnPct } else filtered.sortedByDescending { it.dailyReturnPct }
        ConstituentSortField.CONTRIBUTION -> if (uiState.sortDirection == SortDirection.ASCENDING) filtered.sortedBy { it.contributionPoints } else filtered.sortedByDescending { it.contributionPoints }
        ConstituentSortField.DIVIDEND_YIELD -> if (uiState.sortDirection == SortDirection.ASCENDING) filtered.sortedBy { it.dividendYieldPct } else filtered.sortedByDescending { it.dividendYieldPct }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UkxObsidian)
            .testTag("constituent_matrix_screen")
    ) {
        // Search & Filter Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(UkxSurface)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchQueryChanged,
                placeholder = { Text("Filter constituent ticker, name, sector...", fontSize = 12.sp, color = UkxTextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = UkxTextMuted, modifier = Modifier.size(16.dp)) },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChanged("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = UkxTextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("constituent_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = UkxSteelBlue,
                    unfocusedBorderColor = UkxCardBorder,
                    focusedTextColor = UkxTextPrimary,
                    unfocusedTextColor = UkxTextPrimary,
                    focusedContainerColor = UkxSurfaceElevated,
                    unfocusedContainerColor = UkxSurfaceElevated
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Sector Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                item {
                    val isAll = uiState.selectedSectorFilter == null
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isAll) UkxSteelBlue else UkxSurfaceElevated)
                            .clickable { onSectorFilterSelected(null) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "ALL SECTORS (${state.constituents.size})",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isAll) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 10.sp,
                            color = if (isAll) Color.Black else UkxTextSecondary
                        )
                    }
                }
                items(UkSector.values()) { sector ->
                    val isSel = uiState.selectedSectorFilter == sector
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSel) Color(sector.colorHex) else UkxSurfaceElevated)
                            .clickable { onSectorFilterSelected(sector) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = sector.displayName,
                            fontSize = 10.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSel) Color.Black else UkxTextSecondary
                        )
                    }
                }
            }
        }

        // Table Header
        ConstituentTableHeader(
            sortField = uiState.sortField,
            sortDirection = uiState.sortDirection,
            onSortFieldSelected = onSortFieldSelected
        )

        // Constituent Table List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp)
        ) {
            items(filtered, key = { it.securityId }) { c ->
                ConstituentRowItem(
                    constituent = c,
                    currencySymbol = currency.symbol,
                    currencyRate = currency.rateToGbp,
                    onClick = { onConstituentSelected(c) }
                )
            }
        }
    }

    // Drilldown Bottom Sheet
    uiState.selectedConstituent?.let { sel ->
        ModalBottomSheet(
            onDismissRequest = { onConstituentSelected(null) },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = UkxSurfaceElevated
        ) {
            ConstituentDetailSheet(
                constituent = sel,
                currencySymbol = currency.symbol,
                currencyRate = currency.rateToGbp,
                onClose = { onConstituentSelected(null) }
            )
        }
    }
}

@Composable
fun ConstituentTableHeader(
    sortField: ConstituentSortField,
    sortDirection: SortDirection,
    onSortFieldSelected: (ConstituentSortField) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(UkxSurface)
            .border(1.dp, UkxDivider)
            .padding(horizontal = 8.dp, vertical = 8.dp)
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TableSortHeaderItem("RANK", ConstituentSortField.RANK, 45.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("TICKER", ConstituentSortField.TICKER, 65.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("COMPANY", ConstituentSortField.TICKER, 110.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("PRICE", ConstituentSortField.RANK, 60.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("FULL CAP", ConstituentSortField.FULL_MCAP, 75.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("FLOAT CAP", ConstituentSortField.INVESTABLE_MCAP, 75.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("FLOAT", ConstituentSortField.FREE_FLOAT, 55.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("WEIGHT", ConstituentSortField.WEIGHT, 60.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("RETURN", ConstituentSortField.RETURN, 65.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("CONTRIB", ConstituentSortField.CONTRIBUTION, 65.dp, sortField, sortDirection, onSortFieldSelected)
        TableSortHeaderItem("DIV YLD", ConstituentSortField.DIVIDEND_YIELD, 60.dp, sortField, sortDirection, onSortFieldSelected)
    }
}

@Composable
fun TableSortHeaderItem(
    title: String,
    field: ConstituentSortField,
    width: androidx.compose.ui.unit.Dp,
    currentSort: ConstituentSortField,
    direction: SortDirection,
    onSelect: (ConstituentSortField) -> Unit
) {
    val isCurrent = currentSort == field
    val arrow = if (isCurrent) (if (direction == SortDirection.DESCENDING) "▼" else "▲") else ""

    Box(
        modifier = Modifier
            .width(width)
            .clickable { onSelect(field) }
            .padding(horizontal = 2.dp)
    ) {
        Text(
            text = "$title $arrow",
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
            fontSize = 9.sp,
            color = if (isCurrent) UkxSteelBlue else UkxTextMuted
        )
    }
}

@Composable
fun ConstituentRowItem(
    constituent: IndexConstituent,
    currencySymbol: String,
    currencyRate: Double,
    onClick: () -> Unit
) {
    val isPos = constituent.dailyReturnPct >= 0
    val retColor = if (isPos) UkxGainGreen else UkxLossRed

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(0.5.dp, UkxDivider)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 7.dp)
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "#${constituent.rank}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            color = UkxGoldAccent,
            modifier = Modifier.width(45.dp)
        )
        Text(
            text = constituent.ticker,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = UkxTextPrimary,
            modifier = Modifier.width(65.dp)
        )
        Text(
            text = constituent.companyName,
            fontSize = 11.sp,
            color = UkxTextSecondary,
            maxLines = 1,
            modifier = Modifier.width(110.dp)
        )
        Text(
            text = "${currencySymbol}${String.format("%.2f", constituent.sharePriceGbp * currencyRate)}",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = UkxTextPrimary,
            modifier = Modifier.width(60.dp)
        )
        Text(
            text = "${currencySymbol}${String.format("%.1fB", constituent.fullMarketCapBillionsGbp * currencyRate)}",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = UkxTextSecondary,
            modifier = Modifier.width(75.dp)
        )
        Text(
            text = "${currencySymbol}${String.format("%.1fB", constituent.investableMarketCapBillionsGbp * currencyRate)}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            fontSize = 10.sp,
            color = UkxGoldAccent,
            modifier = Modifier.width(75.dp)
        )
        Text(
            text = "${String.format("%.0f%%", constituent.freeFloatPct)}",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = UkxTextMuted,
            modifier = Modifier.width(55.dp)
        )
        Text(
            text = "${String.format("%.2f%%", constituent.weightPct)}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = UkxSteelBlue,
            modifier = Modifier.width(60.dp)
        )
        Text(
            text = "${String.format("%+.2f%%", constituent.dailyReturnPct)}",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = retColor,
            modifier = Modifier.width(65.dp)
        )
        Text(
            text = "${String.format("%+.2f", constituent.contributionPoints)}",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = retColor,
            modifier = Modifier.width(65.dp)
        )
        Text(
            text = "${String.format("%.1f%%", constituent.dividendYieldPct)}",
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = UkxTextMuted,
            modifier = Modifier.width(60.dp)
        )
    }
}

@Composable
fun ConstituentDetailSheet(
    constituent: IndexConstituent,
    currencySymbol: String,
    currencyRate: Double,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = constituent.ticker,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = UkxGoldAccent
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Rank #${constituent.rank} in FTSE 100",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = UkxTextMuted
                    )
                }
                Text(
                    text = constituent.companyName,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = UkxTextPrimary
                )
                Text(
                    text = "${constituent.sector.displayName} • ${constituent.industry}",
                    fontSize = 12.sp,
                    color = UkxTextSecondary
                )
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = UkxTextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricStatTile(
                label = "Share Price",
                value = "${currencySymbol}${String.format("%.2f", constituent.sharePriceGbp * currencyRate)}",
                subValue = String.format("%+.2f%% today", constituent.dailyReturnPct),
                subValueColor = if (constituent.dailyReturnPct >= 0) UkxGainGreen else UkxLossRed,
                modifier = Modifier.weight(1f)
            )
            MetricStatTile(
                label = "Index Weight",
                value = "${String.format("%.3f%%", constituent.weightPct)}",
                subValue = "Investable Cap Weighted",
                subValueColor = UkxSteelBlue,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricStatTile(
                label = "Full Market Cap (Ranking)",
                value = "${currencySymbol}${String.format("%.2fB", constituent.fullMarketCapBillionsGbp * currencyRate)}",
                subValue = "Price × Shares in Issue",
                subValueColor = UkxTextMuted,
                modifier = Modifier.weight(1f)
            )
            MetricStatTile(
                label = "Investable Cap (Weighting)",
                value = "${currencySymbol}${String.format("%.2fB", constituent.investableMarketCapBillionsGbp * currencyRate)}",
                subValue = "Free Float Factor: ${String.format("%.2f", constituent.freeFloatFactor)}",
                subValueColor = UkxGoldAccent,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricStatTile(
                label = "Point Contribution",
                value = String.format("%+.2f pts", constituent.contributionPoints),
                subValue = String.format("%+.3f%% to UKX", constituent.contributionPct),
                subValueColor = if (constituent.contributionPoints >= 0) UkxGainGreen else UkxLossRed,
                modifier = Modifier.weight(1f)
            )
            MetricStatTile(
                label = "Dividend Yield",
                value = String.format("%.2f%%", constituent.dividendYieldPct),
                subValue = "Ex-Dividend Reinvested",
                subValueColor = UkxGainGreen,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Technical Moving Averages & Buffer status
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(UkxSurface)
                .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
                .padding(10.dp)
        ) {
            Column {
                Text(
                    text = "TECHNICAL DISPERSION & BUFFER CLASSIFICATION",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = UkxTextPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "50 DMA: ${currencySymbol}${String.format("%.2f", constituent.dma50 * currencyRate)} (${if (constituent.isAbove50Dma) "ABOVE" else "BELOW"})",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = if (constituent.isAbove50Dma) UkxGainGreen else UkxLossRed
                    )
                    Text(
                        text = "200 DMA: ${currencySymbol}${String.format("%.2f", constituent.dma200 * currencyRate)}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = UkxTextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
