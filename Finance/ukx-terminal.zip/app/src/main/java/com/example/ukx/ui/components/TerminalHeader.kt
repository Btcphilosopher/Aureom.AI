package com.example.ukx.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxSurfaceElevated
import com.example.ui.theme.UkxTagSynthetic
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.domain.model.FTSEIndex
import com.example.ukx.ui.DisplayCurrency

@Composable
fun TerminalHeader(
    selectedIndex: FTSEIndex,
    selectedCurrency: DisplayCurrency,
    isStreaming: Boolean,
    onIndexSelected: (FTSEIndex) -> Unit,
    onCurrencySelected: (DisplayCurrency) -> Unit,
    modifier: Modifier = Modifier
) {
    var indexDropdownOpen by remember { mutableStateOf(false) }
    var currencyDropdownOpen by remember { mutableStateOf(false) }

    val availableIndices = listOf(
        FTSEIndex.UKX_100,
        FTSEIndex.MCX_250,
        FTSEIndex.NMX_350,
        FTSEIndex.ASX_ALL_SHARE,
        FTSEIndex.UKX_EQUAL_WEIGHT,
        FTSEIndex.UKX_DIVIDEND_PLUS,
        FTSEIndex.UKX_QUALITY_50,
        FTSEIndex.UKX_LOW_VOL
    )

    Surface(
        color = UkxSurface,
        modifier = modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = UkxDivider)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Top Bar: System ID, Session status, Provenance badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isStreaming) UkxGainGreen else UkxGoldAccent)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "FTSE 100 // TERMINAL",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        letterSpacing = 0.8.sp,
                        color = UkxTextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "[UKX-CORE]",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = UkxGoldAccent
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Provenance badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(UkxTagSynthetic.copy(alpha = 0.18f))
                            .border(1.dp, UkxTagSynthetic.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "SYNTHETIC DATA",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            color = UkxTagSynthetic
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sub Bar: Index Selector, London Market Session clock, Currency layer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Index Selector
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(UkxSurfaceElevated)
                            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
                            .clickable { indexDropdownOpen = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("index_selector_button"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "Index",
                            tint = UkxSteelBlue,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = selectedIndex.indexCode,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = UkxTextPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "(${selectedIndex.constituentCount})",
                            fontSize = 10.sp,
                            color = UkxTextMuted
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Select Index",
                            tint = UkxTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = indexDropdownOpen,
                        onDismissRequest = { indexDropdownOpen = false },
                        modifier = Modifier.background(UkxSurfaceElevated)
                    ) {
                        availableIndices.forEach { idx ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = "${idx.indexCode} — ${idx.indexName}",
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = if (idx.indexId == selectedIndex.indexId) FontWeight.Bold else FontWeight.Normal,
                                            color = if (idx.indexId == selectedIndex.indexId) UkxSteelBlue else UkxTextPrimary,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "${idx.indexFamily.label} | ${idx.constituentCount} constituents",
                                            fontSize = 10.sp,
                                            color = UkxTextMuted
                                        )
                                    }
                                },
                                onClick = {
                                    onIndexSelected(idx)
                                    indexDropdownOpen = false
                                }
                            )
                        }
                    }
                }

                // Session Status
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = "Session",
                        tint = UkxTextMuted,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "LSE SETS: CONTINUOUS (15s)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = UkxTextSecondary
                    )
                }

                // Currency Toggle
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(UkxSurfaceElevated)
                            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
                            .clickable { currencyDropdownOpen = true }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("currency_selector_button"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${selectedCurrency.symbol} ${selectedCurrency.code}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = UkxGoldAccent
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Select Currency",
                            tint = UkxTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = currencyDropdownOpen,
                        onDismissRequest = { currencyDropdownOpen = false },
                        modifier = Modifier.background(UkxSurfaceElevated)
                    ) {
                        DisplayCurrency.values().forEach { curr ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${curr.symbol} ${curr.code} (${curr.name})",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        color = if (curr == selectedCurrency) UkxGoldAccent else UkxTextPrimary
                                    )
                                },
                                onClick = {
                                    onCurrencySelected(curr)
                                    currencyDropdownOpen = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
