package com.example.ukx.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxLossRed
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary

@Composable
fun MetricStatTile(
    label: String,
    value: String,
    subValue: String? = null,
    subValueColor: Color = UkxTextMuted,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, UkxCardBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Column {
            Text(
                text = label.uppercase(),
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.5.sp,
                color = UkxTextMuted
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = value,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = UkxTextPrimary
            )
            if (subValue != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subValue,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = subValueColor
                )
            }
        }
    }
}

@Composable
fun HeroIndexTile(
    indexCode: String,
    indexName: String,
    level: Double,
    changePoints: Double,
    changePct: Double,
    currencySymbol: String,
    modifier: Modifier = Modifier
) {
    val isPositive = changePct >= 0
    val color = if (isPositive) UkxGainGreen else UkxLossRed

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(UkxSurface)
            .border(1.dp, UkxSteelBlue.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = indexCode,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = UkxGoldAccent
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = indexName,
                        fontSize = 12.sp,
                        color = UkxTextSecondary
                    )
                }
                Text(
                    text = "OFFICIAL LASPEYRES CALC",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = UkxTextMuted
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = String.format("%,.2f", level),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    letterSpacing = (-0.5).sp,
                    color = UkxTextPrimary
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = String.format("%+,.2f", changePoints),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = color
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(color.copy(alpha = 0.16f))
                            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = String.format("%+.2f%%", changePct),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = color
                        )
                    }
                }
            }
        }
    }
}
