package com.example.ukx.core.engine

import com.example.ukx.domain.model.QuarterlyReviewEvent
import com.example.ukx.domain.model.ReviewCalendar
import com.example.ukx.domain.model.ReviewCandidate
import com.example.ukx.domain.model.ReviewConstituentChange
import com.example.ukx.domain.model.SecurityMasterRecord
import com.example.ukx.domain.model.UkSector

/**
 * Quarterly Review Engine (FTSE UK Reconstitution Twin)
 * 
 * Replays past review cycles (March 2024 to September 2026) and simulates forward reviews (December 2026).
 */
object QuarterlyReviewEngine {

    fun getHistoricalReviews(): List<QuarterlyReviewEvent> {
        return listOf(
            QuarterlyReviewEvent(
                reviewId = "REV-2026-Q3-SEP",
                title = "FTSE UK Index Series September 2026 Review",
                reviewQuarter = "September 2026",
                calendar = ReviewCalendar(
                    reviewMonth = "September 2026",
                    rankingCutoff = "2026-09-01 (Close)",
                    dataCutoff = "2026-09-01",
                    announcementDate = "2026-09-02 (Post-Close)",
                    implementationDate = "2026-09-18 (Third Friday Close)",
                    effectiveDate = "2026-09-21 (Monday Open)"
                ),
                additions = listOf(
                    ReviewConstituentChange(
                        ticker = "EZJ",
                        companyName = "easyJet plc",
                        sector = UkSector.CONSUMER_DISCRETIONARY,
                        rank = 88,
                        fullMarketCapGbp = 4_850_000_000.0,
                        investableMarketCapGbp = 4_120_000_000.0,
                        reason = "Ranked 88th at cutoff; satisfied upper inclusion buffer (<=90)"
                    ),
                    ReviewConstituentChange(
                        ticker = "ITH",
                        companyName = "Ithaca Energy plc",
                        sector = UkSector.ENERGY,
                        rank = 89,
                        fullMarketCapGbp = 4_720_000_000.0,
                        investableMarketCapGbp = 3_980_000_000.0,
                        reason = "Ranked 89th at cutoff; satisfied upper inclusion buffer (<=90)"
                    )
                ),
                deletions = listOf(
                    ReviewConstituentChange(
                        ticker = "ENT",
                        companyName = "Entain plc",
                        sector = UkSector.CONSUMER_DISCRETIONARY,
                        rank = 112,
                        fullMarketCapGbp = 3_450_000_000.0,
                        investableMarketCapGbp = 3_100_000_000.0,
                        reason = "Ranked 112th at cutoff; triggered automatic demotion buffer (>=111)"
                    ),
                    ReviewConstituentChange(
                        ticker = "PSN",
                        companyName = "Persimmon plc",
                        sector = UkSector.CONSUMER_DISCRETIONARY,
                        rank = 114,
                        fullMarketCapGbp = 3_380_000_000.0,
                        investableMarketCapGbp = 3_200_000_000.0,
                        reason = "Ranked 114th at cutoff; triggered automatic demotion buffer (>=111)"
                    )
                ),
                promotions = emptyList(),
                demotions = emptyList(),
                oneWayTurnoverPct = 0.42,
                estimatedPassiveRebalanceGbp = 890_000_000.0,
                methodologyVersion = "UKX-METH-2026.2",
                officialAnnouncementNotice = "LSEG Official Reconstitution Announcement (September 2026). Implementation post-close 18 Sep 2026."
            ),
            QuarterlyReviewEvent(
                reviewId = "REV-2026-Q2-JUN",
                title = "FTSE UK Index Series June 2026 Review",
                reviewQuarter = "June 2026",
                calendar = ReviewCalendar(
                    reviewMonth = "June 2026",
                    rankingCutoff = "2026-06-02 (Close)",
                    dataCutoff = "2026-06-02",
                    announcementDate = "2026-06-03 (Post-Close)",
                    implementationDate = "2026-06-19 (Third Friday Close)",
                    effectiveDate = "2026-06-22 (Monday Open)"
                ),
                additions = listOf(
                    ReviewConstituentChange(
                        ticker = "ABDN",
                        companyName = "Aberdeen Group plc",
                        sector = UkSector.FINANCIALS,
                        rank = 86,
                        fullMarketCapGbp = 5_120_000_000.0,
                        investableMarketCapGbp = 4_600_000_000.0,
                        reason = "Ranked 86th; promoted to FTSE 100 under unified 10% free float methodology"
                    ),
                    ReviewConstituentChange(
                        ticker = "CCC",
                        companyName = "Computacenter plc",
                        sector = UkSector.TECHNOLOGY,
                        rank = 87,
                        fullMarketCapGbp = 4_980_000_000.0,
                        investableMarketCapGbp = 4_350_000_000.0,
                        reason = "Ranked 87th; promoted to FTSE 100"
                    ),
                    ReviewConstituentChange(
                        ticker = "INVP",
                        companyName = "Investec plc",
                        sector = UkSector.FINANCIALS,
                        rank = 90,
                        fullMarketCapGbp = 4_650_000_000.0,
                        investableMarketCapGbp = 4_100_000_000.0,
                        reason = "Ranked 90th; promoted to FTSE 100 at boundary cutoff"
                    )
                ),
                deletions = listOf(
                    ReviewConstituentChange(
                        ticker = "BKG",
                        companyName = "Berkeley Group Holdings plc",
                        sector = UkSector.CONSUMER_DISCRETIONARY,
                        rank = 111,
                        fullMarketCapGbp = 3_550_000_000.0,
                        investableMarketCapGbp = 3_400_000_000.0,
                        reason = "Ranked 111th; automatic demotion to FTSE 250"
                    ),
                    ReviewConstituentChange(
                        ticker = "MNDI",
                        companyName = "Mondi plc",
                        sector = UkSector.MATERIALS,
                        rank = 113,
                        fullMarketCapGbp = 3_420_000_000.0,
                        investableMarketCapGbp = 3_300_000_000.0,
                        reason = "Ranked 113th; automatic demotion to FTSE 250"
                    ),
                    ReviewConstituentChange(
                        ticker = "RMV",
                        companyName = "Rightmove plc",
                        sector = UkSector.TECHNOLOGY,
                        rank = 115,
                        fullMarketCapGbp = 3_350_000_000.0,
                        investableMarketCapGbp = 3_250_000_000.0,
                        reason = "Ranked 115th; automatic demotion to FTSE 250"
                    )
                ),
                promotions = emptyList(),
                demotions = emptyList(),
                oneWayTurnoverPct = 0.61,
                estimatedPassiveRebalanceGbp = 1_280_000_000.0,
                methodologyVersion = "UKX-METH-2026.2",
                officialAnnouncementNotice = "LSEG Official Reconstitution Announcement (June 2026). Effective 22 June 2026."
            ),
            QuarterlyReviewEvent(
                reviewId = "REV-2026-Q1-MAR",
                title = "FTSE UK Index Series March 2026 Review",
                reviewQuarter = "March 2026",
                calendar = ReviewCalendar(
                    reviewMonth = "March 2026",
                    rankingCutoff = "2026-03-03 (Close)",
                    dataCutoff = "2026-03-03",
                    announcementDate = "2026-03-04 (Post-Close)",
                    implementationDate = "2026-03-20 (Third Friday Close)",
                    effectiveDate = "2026-03-23 (Monday Open)"
                ),
                additions = listOf(
                    ReviewConstituentChange(
                        ticker = "HLN",
                        companyName = "Haleon plc",
                        sector = UkSector.HEALTHCARE,
                        rank = 32,
                        fullMarketCapGbp = 28_400_000_000.0,
                        investableMarketCapGbp = 24_200_000_000.0,
                        reason = "Fast entry qualification following secondary block unbundling"
                    )
                ),
                deletions = listOf(
                    ReviewConstituentChange(
                        ticker = "SDR",
                        companyName = "Schroders plc",
                        sector = UkSector.FINANCIALS,
                        rank = 116,
                        fullMarketCapGbp = 3_150_000_000.0,
                        investableMarketCapGbp = 2_800_000_000.0,
                        reason = "Ranked 116th; demoted to FTSE 250"
                    )
                ),
                promotions = emptyList(),
                demotions = emptyList(),
                oneWayTurnoverPct = 0.28,
                estimatedPassiveRebalanceGbp = 590_000_000.0,
                methodologyVersion = "UKX-METH-2025.3",
                officialAnnouncementNotice = "LSEG Official Reconstitution Announcement (March 2026)."
            )
        )
    }

    fun simulateDecember2026Review(
        allSecurities: List<SecurityMasterRecord>,
        currentConstituentTickers: Set<String>
    ): Pair<List<ReviewCandidate>, QuarterlyReviewEvent> {
        val (selected, candidates) = FTSE100SelectionEngine.selectConstituents(
            eligibleSecurities = allSecurities,
            currentConstituentTickers = currentConstituentTickers
        )

        val newConstituentTickers = selected.map { it.ticker }.toSet()

        val expectedAdditions = selected
            .filter { !currentConstituentTickers.contains(it.ticker) }
            .map { sec ->
                val cand = candidates.find { it.ticker == sec.ticker }
                ReviewConstituentChange(
                    ticker = sec.ticker,
                    companyName = sec.companyName,
                    sector = sec.sector,
                    rank = cand?.rank ?: 90,
                    fullMarketCapGbp = sec.fullMarketCapGbp,
                    investableMarketCapGbp = sec.investableMarketCapGbp,
                    reason = "Projected addition: Rank ${cand?.rank} qualifies under 90-buffer rule"
                )
            }

        val expectedDeletions = allSecurities
            .filter { currentConstituentTickers.contains(it.ticker) && !newConstituentTickers.contains(it.ticker) }
            .map { sec ->
                val cand = candidates.find { it.ticker == sec.ticker }
                ReviewConstituentChange(
                    ticker = sec.ticker,
                    companyName = sec.companyName,
                    sector = sec.sector,
                    rank = cand?.rank ?: 111,
                    fullMarketCapGbp = sec.fullMarketCapGbp,
                    investableMarketCapGbp = sec.investableMarketCapGbp,
                    reason = "Projected deletion: Rank ${cand?.rank} breaches lower 111-buffer boundary"
                )
            }

        val simulatedEvent = QuarterlyReviewEvent(
            reviewId = "REV-2026-Q4-DEC-SIM",
            title = "SIMULATED FTSE 100 December 2026 Review",
            reviewQuarter = "December 2026 (Simulated)",
            calendar = ReviewCalendar(
                reviewMonth = "December 2026",
                rankingCutoff = "2026-12-01 (Close)",
                dataCutoff = "2026-12-01",
                announcementDate = "2026-12-02 (Post-Close)",
                implementationDate = "2026-12-18 (Third Friday Close)",
                effectiveDate = "2026-12-21 (Monday Open)"
            ),
            additions = expectedAdditions,
            deletions = expectedDeletions,
            promotions = emptyList(),
            demotions = emptyList(),
            oneWayTurnoverPct = if (expectedAdditions.isNotEmpty()) expectedAdditions.size * 0.22 else 0.15,
            estimatedPassiveRebalanceGbp = (expectedAdditions.sumOf { it.investableMarketCapGbp } * 0.045),
            methodologyVersion = "UKX-METH-2026.2",
            status = com.example.ukx.domain.model.DataStatus.SIMULATED,
            officialAnnouncementNotice = "SIMULATED REVIEW — NOT OFFICIAL FTSE RUSSELL REVIEW OUTPUT. For institutional research and backtesting only."
        )

        return Pair(candidates, simulatedEvent)
    }
}
