package com.example.ukx.core.engine

import com.example.ukx.domain.model.MethodologyVersion
import com.example.ukx.domain.model.SecurityMasterRecord

/**
 * Fast-Entry Engine
 * 
 * Under current FTSE UK rules, qualifying new London Stock Exchange listings
 * that rank 225th or above by full market cap with at least £1.0bn investable market cap
 * can qualify for early inclusion (fast entry) after their 5th trading day.
 */
object FastEntryEngine {

    data class FastEntryEvaluation(
        val ticker: String,
        val isQualified: Boolean,
        val assignedIndex: String,
        val rank: Int,
        val fullMarketCapGbp: Double,
        val investableMarketCapGbp: Double,
        val reason: String
    )

    fun evaluateIpoListing(
        newListing: SecurityMasterRecord,
        universeSecurities: List<SecurityMasterRecord>,
        methodology: MethodologyVersion = MethodologyVersion.VERSION_2026_JUN
    ): FastEntryEvaluation {
        // Step 1: Rank among total universe by full market cap
        val combined = (universeSecurities + newListing).sortedByDescending { it.fullMarketCapGbp }
        val rank = combined.indexOfFirst { it.ticker == newListing.ticker } + 1

        val hasInvestableCap = newListing.investableMarketCapGbp >= methodology.fastEntryMinInvestableCapGbp
        val isRankQualified = rank <= methodology.fastEntryRankCutoff
        val isEligible = FTSEEligibilityEngine.testEligibility(newListing, methodology).isEligible

        val qualified = hasInvestableCap && isRankQualified && isEligible

        val targetIndex = when {
            !qualified -> "Ineligible for Fast Entry (Regular Quarterly Review Queue)"
            rank <= 90 -> "FTSE 100 (Direct Fast Entry Insertion)"
            rank <= 225 -> "FTSE 250 (Direct Fast Entry Insertion)"
            else -> "FTSE SmallCap"
        }

        val reason = when {
            !isEligible -> "Ineligible under general UK nationality/listing criteria"
            !hasInvestableCap -> "Investable Market Cap (£${String.format("%.2f", newListing.investableMarketCapGbp / 1e9)}B) is below required £1.0B threshold"
            !isRankQualified -> "Rank #$rank exceeds fast entry cutoff limit (Rank <= ${methodology.fastEntryRankCutoff})"
            else -> "Qualified: Rank #$rank (Full MCap £${String.format("%.2f", newListing.fullMarketCapGbp / 1e9)}B) with £${String.format("%.2f", newListing.investableMarketCapGbp / 1e9)}B investable float"
        }

        return FastEntryEvaluation(
            ticker = newListing.ticker,
            isQualified = qualified,
            assignedIndex = targetIndex,
            rank = rank,
            fullMarketCapGbp = newListing.fullMarketCapGbp,
            investableMarketCapGbp = newListing.investableMarketCapGbp,
            reason = reason
        )
    }
}
