package com.example.ukx.domain.model

enum class RejectionReason(val code: String, val message: String) {
    NONE("ELIGIBLE", "Security fulfills all FTSE UK index eligibility criteria"),
    INELIGIBLE_LISTING("INELIGIBLE_LISTING", "Listing venue or category is ineligible for FTSE UK Index Series"),
    INELIGIBLE_NATIONALITY("INELIGIBLE_NATIONALITY", "Nationality test failed (fails UK incorporation/headquarters test)"),
    INELIGIBLE_SECURITY_TYPE("INELIGIBLE_SECURITY_TYPE", "Security type is excluded (e.g. secondary line or debt instrument)"),
    INELIGIBLE_CURRENCY("INELIGIBLE_CURRENCY", "Trading currency is not eligible under current methodology rule"),
    INELIGIBLE_FREE_FLOAT("INELIGIBLE_FREE_FLOAT", "Public free float is below the methodology minimum threshold (10%)"),
    INELIGIBLE_LIQUIDITY("INELIGIBLE_LIQUIDITY", "Monthly median turnover or trading volume is below minimum liquidity ratio"),
    INELIGIBLE_SUSPENSION("INELIGIBLE_SUSPENSION", "Security trading is currently suspended on London Stock Exchange")
}

data class EligibilityTestResult(
    val securityId: String,
    val ticker: String,
    val listingEligible: Boolean,
    val nationalityEligible: Boolean,
    val securityTypeEligible: Boolean,
    val currencyEligible: Boolean,
    val freeFloatEligible: Boolean,
    val liquidityEligible: Boolean,
    val suspensionEligible: Boolean,
    val isEligible: Boolean,
    val primaryRejectionReason: RejectionReason,
    val methodologyVersion: String,
    val testedAt: String
)
