package com.example.ukx.core.engine

import com.example.ukx.domain.model.DividendPointRecord
import com.example.ukx.domain.model.DividendSeriesState

/**
 * FTSE 100 Dividend & Total Return Engine
 * 
 * Computes:
 * - Gross and Net Total Return indices
 * - Declared, Cumulative, and Annual Dividend Points
 * - Ex-dividend date index impact points
 */
object DividendEngine {

    fun calculateDividendPoints(
        dividendPerShareGbp: Double,
        sharesInIssue: Long,
        freeFloatFactor: Double,
        indexDivisor: Double
    ): Double {
        if (indexDivisor <= 0.0) return 0.0
        val totalDividendsGbp = dividendPerShareGbp * sharesInIssue.toDouble() * freeFloatFactor
        return totalDividendsGbp / indexDivisor
    }

    fun calculateTotalReturnLevel(
        previousTrLevel: Double,
        dailyPriceReturnPct: Double,
        dailyDividendYieldPct: Double
    ): Double {
        val totalDailyFactor = 1.0 + (dailyPriceReturnPct / 100.0) + (dailyDividendYieldPct / 100.0)
        return previousTrLevel * totalDailyFactor
    }

    fun calculateNetTotalReturnLevel(
        previousNetTrLevel: Double,
        dailyPriceReturnPct: Double,
        dailyDividendYieldPct: Double,
        averageTaxRate: Double = 0.05 // Typical blended withholding for non-resident holdings
    ): Double {
        val netDivYield = dailyDividendYieldPct * (1.0 - averageTaxRate)
        val totalDailyFactor = 1.0 + (dailyPriceReturnPct / 100.0) + (netDivYield / 100.0)
        return previousNetTrLevel * totalDailyFactor
    }

    fun generateStandardDividendSchedule(indexDivisor: Double): DividendSeriesState {
        val list = listOf(
            DividendPointRecord(
                recordId = "DIV-2026-SHEL",
                ticker = "SHEL",
                companyName = "Shell plc",
                exDate = "2026-10-15",
                recordDate = "2026-10-16",
                paymentDate = "2026-11-20",
                dividendPerShareGbp = 0.285,
                constituentWeightPct = 8.42,
                dividendPoints = 48.20,
                indexYieldImpactBps = 58.0
            ),
            DividendPointRecord(
                recordId = "DIV-2026-AZN",
                ticker = "AZN",
                companyName = "AstraZeneca plc",
                exDate = "2026-10-22",
                recordDate = "2026-10-23",
                paymentDate = "2026-11-27",
                dividendPerShareGbp = 0.770,
                constituentWeightPct = 8.10,
                dividendPoints = 42.15,
                indexYieldImpactBps = 51.0
            ),
            DividendPointRecord(
                recordId = "DIV-2026-HSBA",
                ticker = "HSBA",
                companyName = "HSBC Holdings plc",
                exDate = "2026-10-29",
                recordDate = "2026-10-30",
                paymentDate = "2026-12-05",
                dividendPerShareGbp = 0.100,
                constituentWeightPct = 6.20,
                dividendPoints = 34.80,
                indexYieldImpactBps = 42.0
            ),
            DividendPointRecord(
                recordId = "DIV-2026-ULVR",
                ticker = "ULVR",
                companyName = "Unilever plc",
                exDate = "2026-11-05",
                recordDate = "2026-11-06",
                paymentDate = "2026-12-10",
                dividendPerShareGbp = 0.380,
                constituentWeightPct = 5.15,
                dividendPoints = 28.60,
                indexYieldImpactBps = 34.0
            ),
            DividendPointRecord(
                recordId = "DIV-2026-BP",
                ticker = "BP.",
                companyName = "BP plc",
                exDate = "2026-11-12",
                recordDate = "2026-11-13",
                paymentDate = "2026-12-18",
                dividendPerShareGbp = 0.062,
                constituentWeightPct = 3.90,
                dividendPoints = 21.40,
                indexYieldImpactBps = 26.0
            ),
            DividendPointRecord(
                recordId = "DIV-2026-RIO",
                ticker = "RIO",
                companyName = "Rio Tinto plc",
                exDate = "2026-11-19",
                recordDate = "2026-11-20",
                paymentDate = "2026-12-23",
                dividendPerShareGbp = 1.380,
                constituentWeightPct = 3.45,
                dividendPoints = 24.50,
                indexYieldImpactBps = 29.5
            )
        )
        return DividendSeriesState(
            indexCode = "UKX",
            tradeYear = 2026,
            annualDeclaredPoints = 312.45,
            cumulativeYearToDatePoints = 248.80,
            estimatedForwardAnnualYieldPct = 3.82,
            rolling12mPoints = 318.20,
            topDividendContributors = list
        )
    }
}
