package com.example.ukx.core.engine

import com.example.ukx.domain.model.DataStatus
import com.example.ukx.domain.model.FTSEIndex
import com.example.ukx.domain.model.IndexConstituent
import com.example.ukx.domain.model.IndexState
import com.example.ukx.domain.model.ProvenanceRecord
import com.example.ukx.domain.model.SecurityMasterRecord
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Deterministic Index Calculation Engine (UKX-CORE)
 * 
 * Computes:
 * - Total Full Market Cap
 * - Total Investable Market Cap
 * - Constituent Weights: weight_i = investable_cap_i / sum(investable_cap)
 * - Index Level: Level = sum(P_i * S_i * FF_i) / Divisor
 * - Daily Point Change & Return
 * - Individual Stock Attribution & Sector Attribution
 */
object IndexCalculator {

    fun calculateIndexState(
        index: FTSEIndex,
        selectedSecurities: List<SecurityMasterRecord>,
        divisor: Double = index.divisor,
        baseTrLevel: Double = 12450.80,
        baseNetTrLevel: Double = 11120.40,
        methodologyVersion: String = "UKX-METH-2026.2",
        dataStatus: DataStatus = DataStatus.SYNTHETIC
    ): IndexState {
        val totalFullCapGbp = selectedSecurities.sumOf { it.fullMarketCapGbp }
        val totalInvestableCapGbp = selectedSecurities.sumOf { it.investableMarketCapGbp }

        val calculatedIndexLevel = if (divisor > 0) totalInvestableCapGbp / divisor else 8350.0

        // Build constituent items with weights and attribution
        val constituents = selectedSecurities.mapIndexed { indexIdx, sec ->
            val weight = if (totalInvestableCapGbp > 0) {
                (sec.investableMarketCapGbp / totalInvestableCapGbp) * 100.0
            } else 1.0

            val contributionPct = (sec.priceChangePct * (weight / 100.0))
            val contributionPoints = calculatedIndexLevel * (contributionPct / 100.0)

            IndexConstituent(
                rank = indexIdx + 1,
                securityId = sec.securityId,
                ticker = sec.ticker,
                companyName = sec.companyName,
                sector = sec.sector,
                industry = sec.industry,
                sharePriceGbp = sec.priceGbp,
                dailyReturnPct = sec.priceChangePct,
                sharesInIssue = sec.sharesInIssue,
                freeFloatFactor = sec.freeFloatFactor,
                fullMarketCapGbp = sec.fullMarketCapGbp,
                investableMarketCapGbp = sec.investableMarketCapGbp,
                weightPct = weight,
                contributionPoints = contributionPoints,
                contributionPct = contributionPct,
                dividendYieldPct = sec.dividendYieldPct,
                dma50 = sec.priceGbp * (1.0 - (sec.priceChangePct * 0.01)),
                dma200 = sec.priceGbp * 0.94,
                isAbove50Dma = sec.priceChangePct >= -0.5,
                isAbove200Dma = sec.priceChangePct >= -1.5
            )
        }

        val totalDailyReturnPct = constituents.sumOf { it.contributionPct }
        val totalDailyChangePoints = calculatedIndexLevel * (totalDailyReturnPct / 100.0)

        val totalReturnLevel = DividendEngine.calculateTotalReturnLevel(
            previousTrLevel = baseTrLevel,
            dailyPriceReturnPct = totalDailyReturnPct,
            dailyDividendYieldPct = 3.82 / 252.0
        )

        val netTotalReturnLevel = DividendEngine.calculateNetTotalReturnLevel(
            previousNetTrLevel = baseNetTrLevel,
            dailyPriceReturnPct = totalDailyReturnPct,
            dailyDividendYieldPct = 3.82 / 252.0,
            averageTaxRate = 0.05
        )

        val sectorExposures = SectorAndBreadthEngine.calculateSectorExposures(
            constituents = constituents,
            totalInvestableCapGbp = totalInvestableCapGbp
        )

        val breadth = SectorAndBreadthEngine.calculateMarketBreadth(constituents)

        val topContributors = constituents.sortedByDescending { it.contributionPoints }.take(5)
        val topDetractors = constituents.sortedBy { it.contributionPoints }.take(5)

        val nowStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK).format(Date())
        val tradeDateStr = SimpleDateFormat("yyyy-MM-dd", Locale.UK).format(Date())

        return IndexState(
            index = index,
            timestamp = nowStr,
            tradeDate = tradeDateStr,
            sessionName = "SETS Continuous Trading",
            indexLevel = calculatedIndexLevel,
            dailyChangePoints = totalDailyChangePoints,
            dailyReturnPct = totalDailyReturnPct,
            totalReturnLevel = totalReturnLevel,
            netTotalReturnLevel = netTotalReturnLevel,
            divisor = divisor,
            totalFullMarketCapGbp = totalFullCapGbp,
            totalInvestableMarketCapGbp = totalInvestableCapGbp,
            constituents = constituents,
            sectorExposures = sectorExposures,
            breadth = breadth,
            topContributors = topContributors,
            topDetractors = topDetractors,
            methodologyVersion = methodologyVersion,
            dataStatus = dataStatus,
            provenance = ProvenanceRecord(
                timestamp = nowStr,
                effectiveAt = tradeDateStr,
                status = dataStatus
            )
        )
    }
}
