package com.example.ukx.domain.model

data class MethodologyRule(
    val ruleId: String,
    val ruleName: String,
    val ruleCategory: String,
    val description: String,
    val parameterValue: String,
    val effectiveDate: String,
    val status: String = "ACTIVE"
)

data class MethodologyVersion(
    val methodologyId: String,
    val version: String,
    val effectiveDate: String,
    val publicationDate: String,
    val summary: String,
    val minimumFreeFloatPct: Double,
    val eligibleCurrencies: List<String>,
    val fastEntryRankCutoff: Int,
    val fastEntryMinInvestableCapGbp: Double,
    val bufferInclusionRank: Int, // e.g. 90 (Rank 1-90 auto included)
    val bufferExclusionRank: Int, // e.g. 111 (Rank 111+ auto demoted)
    val rules: List<MethodologyRule>,
    val checksum: String
) {
    companion object {
        val VERSION_2026_JUN = MethodologyVersion(
            methodologyId = "FTSE-UK-2026-V2",
            version = "2026.2 (June 2026)",
            effectiveDate = "2026-06-22",
            publicationDate = "2026-05-15",
            summary = "Unified 10% minimum free float for UK and non-UK incorporated issuers; multi-currency (GBP/EUR/USD) inclusion; revised fast-entry threshold.",
            minimumFreeFloatPct = 10.0,
            eligibleCurrencies = listOf("GBP", "EUR", "USD"),
            fastEntryRankCutoff = 225,
            fastEntryMinInvestableCapGbp = 1_000_000_000.0,
            bufferInclusionRank = 90,
            bufferExclusionRank = 111,
            rules = listOf(
                MethodologyRule(
                    ruleId = "METH-RULE-FF-01",
                    ruleName = "Unified Free Float Threshold",
                    ruleCategory = "Free Float",
                    description = "Minimum public free float of 10% applies equally to UK and non-UK incorporated companies",
                    parameterValue = "10.0%",
                    effectiveDate = "2026-06-22"
                ),
                MethodologyRule(
                    ruleId = "METH-RULE-CURR-01",
                    ruleName = "Trading Currency Scope",
                    ruleCategory = "Currency",
                    description = "Securities trading in EUR or USD on the London Stock Exchange are eligible if other UK criteria are satisfied",
                    parameterValue = "GBP, EUR, USD",
                    effectiveDate = "2025-09-22"
                ),
                MethodologyRule(
                    ruleId = "METH-RULE-RANK-01",
                    ruleName = "Full Market Cap Ranking",
                    ruleCategory = "Ranking",
                    description = "Constituent selection ranks eligible UK securities by Full Market Capitalisation before investability weightings are applied",
                    parameterValue = "Price × Shares in Issue",
                    effectiveDate = "1984-01-03"
                ),
                MethodologyRule(
                    ruleId = "METH-RULE-BUF-01",
                    ruleName = "Quarterly Review Buffer Rules",
                    ruleCategory = "Selection Buffer",
                    description = "A security ranking 90th or above is automatically inserted into FTSE 100; a current constituent ranking 111th or below is demoted to FTSE 250",
                    parameterValue = "Upper: 90 / Lower: 111",
                    effectiveDate = "1984-01-03"
                ),
                MethodologyRule(
                    ruleId = "METH-RULE-FAST-01",
                    ruleName = "Fast Entry Mechanism",
                    ruleCategory = "Fast Entry",
                    description = "Qualifying new LSE listings ranking 225th or above with >= £1bn investable market cap can enter FTSE 100/250 on fifth trading day",
                    parameterValue = "Rank <= 225 & Cap >= £1.0B",
                    effectiveDate = "2025-03-24"
                )
            ),
            checksum = "SHA256:0d72bc194a8e312f"
        )

        val VERSION_2025_SEP = MethodologyVersion(
            methodologyId = "FTSE-UK-2025-V3",
            version = "2025.3 (September 2025)",
            effectiveDate = "2025-09-22",
            publicationDate = "2025-08-18",
            summary = "Introduction of EUR and USD eligibility for London Main Market equities; standard free float thresholds (15% non-UK / 25% legacy UK).",
            minimumFreeFloatPct = 25.0,
            eligibleCurrencies = listOf("GBP", "EUR", "USD"),
            fastEntryRankCutoff = 225,
            fastEntryMinInvestableCapGbp = 1_000_000_000.0,
            bufferInclusionRank = 90,
            bufferExclusionRank = 111,
            rules = listOf(
                MethodologyRule(
                    ruleId = "METH-RULE-FF-00",
                    ruleName = "Differentiated Free Float Thresholds",
                    ruleCategory = "Free Float",
                    description = "25% standard free float for UK incorporated entities; 15% for non-UK secondary lines",
                    parameterValue = "UK: 25.0% / Non-UK: 15.0%",
                    effectiveDate = "2025-09-22"
                )
            ),
            checksum = "SHA256:7f49c0d1192e48aa"
        )
    }
}
