package com.example.ukx.domain.model

data class ApiEndpoint(
    val method: String, // "GET" or "POST"
    val path: String,
    val description: String,
    val sampleQueryParam: String = "",
    val sampleRequestBody: String = "",
    val sampleJsonResponse: String
)

data class CliCommandTemplate(
    val command: String,
    val description: String,
    val outputType: String
)
