package com.example.ukx.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.UkxCardBorder
import com.example.ui.theme.UkxDivider
import com.example.ui.theme.UkxGainGreen
import com.example.ui.theme.UkxGoldAccent
import com.example.ui.theme.UkxLossRed
import com.example.ui.theme.UkxObsidian
import com.example.ui.theme.UkxSteelBlue
import com.example.ui.theme.UkxSurface
import com.example.ui.theme.UkxSurfaceElevated
import com.example.ui.theme.UkxTextMuted
import com.example.ui.theme.UkxTextPrimary
import com.example.ui.theme.UkxTextSecondary
import com.example.ukx.domain.model.CorporateActionEvent
import com.example.ukx.domain.model.EligibilityTestResult
import com.example.ukx.domain.model.MethodologyRule
import com.example.ukx.domain.model.MethodologyVersion
import com.example.ukx.ui.UkxTerminalUiState
import com.example.ukx.ui.components.MetricStatTile

@Composable
fun MethodologyAndRulesScreen(
    uiState: UkxTerminalUiState,
    onMethodologySelected: (MethodologyVersion) -> Unit,
    onTestSecurityTicker: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeMethodology = uiState.activeMethodology
    var tickerInput by remember { mutableStateOf(uiState.testSecurityTicker) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(UkxObsidian)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("methodology_screen")
    ) {
        Text(
            text = "FTSE UK METHODOLOGY RULEBOOK // VERSION CONTROL",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxTextPrimary
        )
        Text(
            text = "Audit trail of ground rules, free float criteria, and divisor adjustments",
            fontSize = 10.sp,
            color = UkxTextMuted
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Methodology Version Switcher (2026 vs 2025)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val is2026 = activeMethodology.version.startsWith("2026")
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (is2026) UkxSteelBlue.copy(alpha = 0.2f) else UkxSurface)
                    .border(1.dp, if (is2026) UkxSteelBlue else UkxCardBorder, RoundedCornerShape(6.dp))
                    .clickable { onMethodologySelected(MethodologyVersion.VERSION_2026_JUN) }
                    .padding(10.dp)
            ) {
                Column {
                    Text(
                        text = "VERSION 2026.2 (JUNE 2026)",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (is2026) UkxSteelBlue else UkxTextPrimary
                    )
                    Text(
                        text = "Unified 10% Free Float Threshold (UK & Non-UK) | Multi-Currency EUR/USD",
                        fontSize = 9.sp,
                        color = UkxTextMuted
                    )
                }
            }

            val is2025 = activeMethodology.version.startsWith("2025")
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (is2025) UkxSteelBlue.copy(alpha = 0.2f) else UkxSurface)
                    .border(1.dp, if (is2025) UkxSteelBlue else UkxCardBorder, RoundedCornerShape(6.dp))
                    .clickable { onMethodologySelected(MethodologyVersion.VERSION_2025_SEP) }
                    .padding(10.dp)
            ) {
                Column {
                    Text(
                        text = "VERSION 2025.3 (SEP 2025)",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (is2025) UkxSteelBlue else UkxTextPrimary
                    )
                    Text(
                        text = "Legacy 25% Free Float (UK) / 15% (Non-UK) Thresholds",
                        fontSize = 9.sp,
                        color = UkxTextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Active Rules Breakdown
        Text(
            text = "ACTIVE GOVERNING RULES & PARAMETERS",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxGoldAccent
        )

        Spacer(modifier = Modifier.height(6.dp))

        activeMethodology.rules.forEach { rule ->
            RuleCard(rule = rule)
            Spacer(modifier = Modifier.height(4.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 7-Stage Eligibility Test on Any Security
        Text(
            text = "7-STAGE SECURITY ELIGIBILITY PIPELINE VERIFIER",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxTextPrimary
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = tickerInput,
                onValueChange = { tickerInput = it.uppercase() },
                label = { Text("Ticker (e.g. SHEL, EZJ, ABDN, RMV)", fontSize = 11.sp) },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = UkxSteelBlue,
                    unfocusedBorderColor = UkxCardBorder,
                    focusedTextColor = UkxTextPrimary,
                    unfocusedTextColor = UkxTextPrimary
                ),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = { onTestSecurityTicker(tickerInput) },
                colors = ButtonDefaults.buttonColors(containerColor = UkxSteelBlue),
                modifier = Modifier.height(52.dp)
            ) {
                Text("TEST", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        uiState.eligibilityTestResult?.let { elig ->
            EligibilityVerificationCard(result = elig)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Divisor Continuity & Corporate Action Log
        Text(
            text = "DIVISOR CONTINUITY & CORPORATE ACTIONS AUDIT TRAIL",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            color = UkxGoldAccent
        )

        Spacer(modifier = Modifier.height(6.dp))

        uiState.corporateActions.forEach { ca ->
            CorporateActionRowCard(event = ca)
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}

@Composable
fun RuleCard(rule: MethodologyRule) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(UkxSurface)
            .border(0.5.dp, UkxDivider, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${rule.ruleCategory}: ${rule.ruleName}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UkxTextPrimary
                )
                Text(
                    text = rule.description,
                    fontSize = 10.sp,
                    color = UkxTextSecondary
                )
            }
            Text(
                text = rule.parameterValue,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = UkxSteelBlue
            )
        }
    }
}

@Composable
fun EligibilityVerificationCard(result: EligibilityTestResult) {
    val isElig = result.isEligible
    val color = if (isElig) UkxGainGreen else UkxLossRed

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(UkxSurface)
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ELIGIBILITY PIPELINE: ${result.ticker}",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = UkxTextPrimary
                )
                Text(
                    text = if (isElig) "QUALIFIED / ELIGIBLE" else "INELIGIBLE",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = color
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 7-Stage Checks Checklist
            StageItem("1. London Main Market / SETS Listing Test", result.listingEligible)
            StageItem("2. UK Nationality / Incorporation Test", result.nationalityEligible)
            StageItem("3. Eligible Security Type (Ordinary Shares)", result.securityTypeEligible)
            StageItem("4. Currency Eligibility (GBP, EUR, USD)", result.currencyEligible)
            StageItem("5. Free Float Minimum Threshold (>= 10.0%)", result.freeFloatEligible)
            StageItem("6. UK Market Liquidity Ratio (Turnover >= 0.05%)", result.liquidityEligible)
            StageItem("7. Trading Status / No Suspension", result.suspensionEligible)

            if (!isElig) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Rejection Reason: ${result.primaryRejectionReason.message}",
                    fontSize = 10.sp,
                    color = UkxLossRed
                )
            }
        }
    }
}

@Composable
fun StageItem(name: String, isOk: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = if (isOk) "✓" else "✕",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = if (isOk) UkxGainGreen else UkxLossRed,
            modifier = Modifier.width(18.dp)
        )
        Text(
            text = name,
            fontSize = 10.sp,
            color = if (isOk) UkxTextSecondary else UkxLossRed
        )
    }
}

@Composable
fun CorporateActionRowCard(event: CorporateActionEvent) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(UkxSurface)
            .border(0.5.dp, UkxDivider, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = event.ticker,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = UkxGoldAccent
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = event.actionType.displayName,
                        fontSize = 11.sp,
                        color = UkxTextPrimary
                    )
                }
                Text(
                    text = "${event.effectiveDate} • ${event.termsDescription}",
                    fontSize = 9.sp,
                    color = UkxTextMuted
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Divisor: ${String.format("%,.0f", event.newDivisor)}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = UkxSteelBlue
                )
                Text(
                    text = "Factor: ${String.format("%.4f", event.adjustmentFactor)}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    color = UkxTextSecondary
                )
            }
        }
    }
}
