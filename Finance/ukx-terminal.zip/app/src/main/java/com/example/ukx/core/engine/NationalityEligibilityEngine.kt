package com.example.ukx.core.engine

import com.example.ukx.domain.model.LseListingType
import com.example.ukx.domain.model.MethodologyVersion
import com.example.ukx.domain.model.SecurityMasterRecord
import com.example.ukx.domain.model.TradingExchange

/**
 * Nationality & Listing Eligibility Engine
 * 
 * Verifies that a company meets the UK Nationality criteria (incorporation or tax residence
 * in UK, or operational headquarters and primary listing on London Main Market).
 */
object NationalityEligibilityEngine {

    fun isNationalityEligible(security: SecurityMasterRecord): Boolean {
        // UK incorporated companies with primary listing
        if (security.countryOfIncorporation.equals("GB", ignoreCase = true) &&
            security.countryOfListing.equals("GB", ignoreCase = true)) {
            return true
        }
        // Non-UK incorporated with primary operations & sole primary listing in London
        if (security.countryOfListing.equals("GB", ignoreCase = true) &&
            security.listingType == LseListingType.PRIMARY_EQUITY) {
            return true
        }
        // International holdings with major operations in UK
        if (security.countryOfOperation.equals("GB", ignoreCase = true)) {
            return true
        }
        return false
    }

    fun isListingEligible(security: SecurityMasterRecord): Boolean {
        return security.exchange == TradingExchange.LSE_SETS &&
                (security.listingType == LseListingType.PRIMARY_EQUITY ||
                 security.listingType == LseListingType.REIT ||
                 security.listingType == LseListingType.INVESTMENT_ENTITY)
    }

    fun isCurrencyEligible(
        security: SecurityMasterRecord,
        methodology: MethodologyVersion
    ): Boolean {
        return methodology.eligibleCurrencies.any { it.equals(security.tradingCurrency, ignoreCase = true) }
    }
}
